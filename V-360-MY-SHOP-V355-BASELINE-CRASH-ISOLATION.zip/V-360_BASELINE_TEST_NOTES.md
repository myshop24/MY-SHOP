# MY SHOP V-360 — V-355 Baseline Isolation Test

Purpose: controlled crash isolation without editing the GitHub workflow.

- Android application source/resources are the V-355 baseline.
- No feature, UI, navigation, Live, Coin/Gold Coin, Admin, Profile, gift, or dashboard behavior was intentionally redesigned.
- Only release identity was advanced so the existing highest-V workflow selects this package: SOURCE_BUILD_ID, SOURCE_VERSION_NAME, Android versionCode/versionName, Worker health build/version marker, and current handoff header/version.
- The existing V-355 palette migration comment/name remains unchanged because it describes that historical migration and is not release identity.
- Test path: install the GitHub-built APK, open MY SHOP, wait through startup, reach Dashboard, and observe whether the process exits.
- If V-360 baseline crashes the same way, the failure is present in the V-355 baseline/runtime/environment. If V-360 baseline stays stable, investigate changes introduced after V-355.
