MY SHOP V-59 — COMPLETE RELEASE PACKAGE
=======================================

This is the complete V-59 source package, not a partial workflow-only package.

Contents:
1. Full Android project source, including app/, backend/, design-reference/, tools/, docs and configuration.
2. Exactly ONE active GitHub Actions workflow:
   .github/workflows/MY_SHOP_V59_ONE_RELEASE_APK.yml
3. Original V-59 source ZIP preserved under:
   _BACKUP_ORIGINAL/V-59_MY_SHOP_FINAL_LOGIN_DASHBOARD_SOURCE.zip
4. Previous V-59 workflows preserved only as backup under:
   _BACKUP_WORKFLOWS/

Build rules enforced by the active workflow:
- Release build only (assembleRelease)
- Exactly one source ZIP is expected when using ZIP-mode; this complete package is intended for direct GitHub project upload.
- Exactly one Release APK is produced.
- Package: com.myshop.app
- Version: 5.9 release identity is enforced as versionCode 59 / versionName 2.9.59 in the temporary build copy.
- Duplicate-class check
- ZIP integrity check
- zipalign check
- apksigner verification
- Final APK package/version verification
- Final artifact contains ONE APK only: MY-SHOP-V59-RELEASE.apk

IMPORTANT:
The original source files are preserved. The active workflow is the only build workflow.
Do not add another Android ZIP or another build workflow to the active root unless intentionally replacing it.
