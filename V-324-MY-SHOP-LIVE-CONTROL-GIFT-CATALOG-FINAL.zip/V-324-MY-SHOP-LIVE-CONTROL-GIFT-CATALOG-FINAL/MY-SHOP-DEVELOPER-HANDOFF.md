# MY SHOP Developer Handoff — V-324

## Base
- Base source: V-323-MY-SHOP-FINAL.zip
- V-321 source was retained as the catalog regression reference.

## Completed in V-324
- Speaker self-controls: Leave Call, Change Seat, Mute/Unmute.
- Muted speaker gets a compact microphone-cross marker on the seat avatar.
- Special Guest duplicate-seat presentation removed while the original backend seat remains reserved.
- Profile/avatar no longer scales/jumps when speaking; only the surrounding speaking ring pulses.
- Avatar bitmap cache added to reduce repeated reload/blank flicker.
- Live room state refresh accelerated to 650 ms; Gift event channel remains 350 ms.
- Comments now append by event/comment IDs rather than rebuilding the full board every refresh; optimistic local comments remain immediate.
- Gift overlay now shows sender, gift name, Coin/Gold Coin price in a compact gold-accent block.
- Gift seat visuals polished to compact golden circles/borders.
- Gift Store cards reduced/polished for a denser smart catalog presentation while preserving existing send animation behavior.
- Admin Gift Coin & Gold Coin Catalog adds per-gift Gift Display Duration and Sound Duration settings (0.5–15s effect, 0–15s sound).
- Backend schema/migrations, Admin save, live gift event payloads, local/remote playback all carry the new duration fields.
- Dedicated Coin • Gold Coin package catalog restored in Admin Finance with separate Coin / Gold tabs, package cards, Add/Edit/Publish/Delete controls.
- Coin and Gold Coin remain separate catalogs; existing membership/badge manager remains unchanged.

## Regression / safety gates
- Preserve 12-seat 6+6 Live board structure and host separation.
- Preserve Cloudflare D1/R2 bindings and existing table ownership/history.
- Live comments remain ephemeral only.
- Purchased digital currency remains non-withdrawable; no payout rule changed.
- Existing gift send animations were preserved; catalog/presentation and metadata were polished only.
- Digital paid package editor retains Google Play Product ID field; no external digital-payment flow was added.

## Pending external verification
- Final Android compile/signing should be run in the existing GitHub Actions Android environment if local Android SDK is unavailable.
- Real-device RTC/voice behavior, multi-device seat movement, remote comment latency, and audio playback duration require device/network verification.
- Cloudflare migration/deploy must use the existing release workflow so D1 ALTER columns are applied safely.

## Phase / checkpoint
- Phase: Live stability + gift/catalog regression repair.
- Last checkpoint: source/static validation and release packaging.
- Next: GitHub Actions compile → install on test device → multi-user Live QA → Play compliance console checks.
