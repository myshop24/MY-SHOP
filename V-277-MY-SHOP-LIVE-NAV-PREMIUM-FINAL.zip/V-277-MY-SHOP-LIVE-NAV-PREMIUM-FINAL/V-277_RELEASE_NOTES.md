# MY SHOP V-277

- Reworked LIVE STREAMING into a premium dark navy/purple reference-style banner.
- Added stronger animated broadcast icon with pulse, glow, color cycling and subtle motion.
- Preserved Go Live / Join Live behavior and enforced 35% / 65% CTA width ratio.
- Join Live receives the stronger primary animation; Go Live remains smoothly animated.
- Reworked bottom navigation into dark floating premium tiles with selected Home cyan glow.
- Existing backend, live presence calls, Admin long-press access, feed, D1/R2 and navigation behavior preserved.

## Packaging identity correction
- SOURCE_BUILD_ID.txt = MY SHOP V-277
- SOURCE_VERSION_NAME.txt = 2.9.277
- Android versionCode = 276 / versionName = 2.9.277
- Worker health/build markers = 2.9.277 / V-277
- Corrects the stale V-275 identity that caused the GitHub Actions preflight SOURCE_BUILD_ID mismatch.
