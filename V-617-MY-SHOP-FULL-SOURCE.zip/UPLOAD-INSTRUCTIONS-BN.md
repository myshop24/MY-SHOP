# V-617 / 2.9.617 — GitHub APK ফুল সোর্স প্যাকেজ

এই ZIP-এ APK নেই; GitHub Android build সফল হলে Artifacts থেকে APK পাওয়া যাবে। স্থানীয় Android build Gradle ডাউনলোডে Network is unreachable হওয়ায় তৈরি হয়নি। এটিকে ১৪টি কাজ সম্পূর্ণ বা Play অনুমোদিত রিলিজ বলা যাবে না; হ্যান্ডঅফ পড়ুন।

১. V-617-MY-SHOP-FULL-SOURCE.zip Extract করে আগের MY SHOP repository root-এ সব files/folders দিন। .github/workflows/my-shop-apk.yml অবশ্যই root-এ থাকবে। .github বাদ দিলে build workflow তৈরি হবে না।
২. আগের package ও signing key রাখুন। GitHub Secrets-এ MYSHOP_KEYSTORE_PASSWORD, MYSHOP_KEY_ALIAS, MYSHOP_KEY_PASSWORD এবং original MYSHOP_KEYSTORE_BASE64 দিন; পুরোনো cache/encrypted-key restore ব্যবস্থাও সংরক্ষিত। নতুন signing key তৈরি করবেন না।
৩. Firebase Secrets: MYSHOP_FIREBASE_API_KEY, MYSHOP_FIREBASE_APP_ID, MYSHOP_FIREBASE_PROJECT_ID, MYSHOP_FIREBASE_SENDER_ID। Source/log/chat-এ আসল secret লিখবেন না।
৪. Commit → Actions → MY SHOP Android APK → নতুন commit-এর Run workflow। Workflow clean build, local tests, Android unit tests, lint, original certificate, package/version, embedded SOURCE_BUILD_ID ও commit যাচাই করবে।
৫. সফল হলে Artifacts → MY-SHOP-V-617-APK download করুন। এতে শুধু একটি MY_SHOP_FINAL_RELEASE.apk থাকবে। Pages success বা পুরোনো run নতুন Android APK নয়।
৬. শুধু ZIP upload করতে চাইলে root-এ একই APK workflow আগে install করুন। তারপর V-617-MY-SHOP-FULL-SOURCE.zip root-এ দিন। Selector সবচেয়ে নতুন source বাছবে; ভেতরের identity না মিললে build বন্ধ হবে।
৭. APK build Worker deploy করে না। Rare catalog/offer/index/community changes চালু করতে matching V-617 Worker প্রয়োজন; production deploy এই কাজের মধ্যে করা হয়নি। DB reset করবেন না।
৮. নতুন ফোনে Store/Admin, ৩২০/৩৬০/৪১২dp ও বড় ফন্টে layout, live multi-device gifts/comments/join, audio/moderation/minimize এবং account deletion পরীক্ষা না হওয়া পর্যন্ত চূড়ান্ত গ্রহণযোগ্যতা বাকি।
