package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** V-252 public profile: live social counts, follow state, cover photo, coin level and premium badge. */
public class UserProfileActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(7,9,20),DARK=Color.WHITE,MUTED=Color.rgb(161,171,201),BLUE=Color.rgb(58,96,230),PURPLE=Color.rgb(126,55,232),GREEN=Color.rgb(20,153,92),CARD=Color.rgb(18,23,42);
    private String userId="",name="MY SHOP User",avatarUrl="",coverUrl="",relation="NONE";
    private boolean isFollowing=false, loading=false;
    private LinearLayout root;
    private ImageView avatar,cover,badgeAnim;
    private TextView title,bio,state,badge,levelBadge,friendsCount,followersCount,followingCount;
    private Button friend,follow;
    private final ExecutorService io=Executors.newFixedThreadPool(2);

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        userId=getIntent().getStringExtra("userId"); if(userId==null)userId="";
        setContentView(build());
    }

    @Override protected void onResume(){super.onResume();load();}

    private View build(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root=col(); root.setBackgroundColor(BG); root.setPadding(dp(14),dp(10),dp(14),dp(24));
        root.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(dp(14),Math.max(dp(10),i.getSystemWindowInsetTop()+dp(5)),dp(14),dp(24));return i;});

        LinearLayout h=row(); Button back=btn("‹",Color.TRANSPARENT,DARK); back.setTextSize(28); back.setOnClickListener(v->finish()); h.addView(back,lp(dp(48),dp(48)));
        TextView ht=txt("Profile",DARK,18,true); ht.setGravity(Gravity.CENTER_VERTICAL); h.addView(ht,weight(1,dp(48))); root.addView(h,lp(-1,dp(52)));

        FrameLayout hero=new FrameLayout(this); hero.setBackground(round(CARD,Color.rgb(39,47,80),18));
        cover=new ImageView(this); cover.setScaleType(ImageView.ScaleType.CENTER_CROP); cover.setBackground(round(Color.rgb(26,34,64),Color.TRANSPARENT,18)); cover.setClipToOutline(true);
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,dp(150),Gravity.TOP); hero.addView(cover,cp);
        avatar=new ImageView(this); avatar.setImageResource(R.drawable.myshop_profile_avatar); avatar.setScaleType(ImageView.ScaleType.CENTER_CROP); avatar.setPadding(dp(4),dp(4),dp(4),dp(4)); avatar.setBackground(round(Color.rgb(118,67,224),Color.rgb(255,208,98),60)); avatar.setClipToOutline(true);
        FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(dp(108),dp(108),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL); ap.bottomMargin=dp(4); hero.addView(avatar,ap);
        root.addView(hero,lp(-1,dp(206)));

        LinearLayout nr=row(); nr.setGravity(Gravity.CENTER); title=txt("Loading profile…",DARK,21,true); nr.addView(title,lp(-2,dp(38)));
        levelBadge=txt("👑 Lv. 0",Color.WHITE,9,true); levelBadge.setGravity(Gravity.CENTER); levelBadge.setPadding(dp(9),0,dp(9),0); levelBadge.setBackground(gradientRound(Color.rgb(45,107,255),Color.rgb(139,54,244),15)); nr.addView(levelBadge,margin(lp(-2,dp(28)),7,0,0,0));
        badge=txt("",Color.WHITE,9,true); badge.setGravity(Gravity.CENTER); badge.setVisibility(View.GONE); nr.addView(badge,margin(lp(-2,dp(26)),6,0,0,0));
        badgeAnim=new ImageView(this); badgeAnim.setScaleType(ImageView.ScaleType.CENTER_INSIDE); badgeAnim.setVisibility(View.GONE); nr.addView(badgeAnim,margin(lp(dp(34),dp(34)),5,0,0,0)); root.addView(nr,lp(-1,dp(42)));

        state=txt("MY SHOP ID  •  "+userId,MUTED,10,true); state.setGravity(Gravity.CENTER); root.addView(state,lp(-1,dp(28)));

        LinearLayout stats=row(); stats.setPadding(dp(4),dp(4),dp(4),dp(4)); stats.setBackground(round(CARD,Color.rgb(39,47,80),15));
        LinearLayout s1=statBox("Friends"); friendsCount=(TextView)s1.getChildAt(0); stats.addView(s1,weight(1,dp(66)));
        LinearLayout s2=statBox("Followers"); followersCount=(TextView)s2.getChildAt(0); stats.addView(s2,weight(1,dp(66)));
        LinearLayout s3=statBox("Following"); followingCount=(TextView)s3.getChildAt(0); stats.addView(s3,weight(1,dp(66))); root.addView(stats,margin(lp(-1,dp(74)),0,6,0,0));

        bio=txt("",DARK,11,false); bio.setGravity(Gravity.CENTER); bio.setPadding(dp(14),dp(12),dp(14),dp(12)); bio.setBackground(round(CARD,Color.rgb(40,50,82),16)); root.addView(bio,margin(lp(-1,-2),0,8,0,0));

        LinearLayout a=row(); Button message=btn("Message",PURPLE,Color.WHITE); message.setOnClickListener(v->openChat()); a.addView(message,weight(1,dp(46))); a.addView(new Space(this),lp(dp(7),1));
        friend=btn("Add Friend",BLUE,Color.WHITE); friend.setOnClickListener(v->friendAction()); a.addView(friend,weight(1,dp(46))); a.addView(new Space(this),lp(dp(7),1));
        follow=btn("Follow",Color.rgb(35,114,208),Color.WHITE); follow.setOnClickListener(v->followAction()); a.addView(follow,weight(1,dp(46))); root.addView(a,margin(lp(-1,dp(46)),0,dp(14),0,0));
        smooth(message); smooth(friend); smooth(follow); smooth(back);
        LinearLayout social=row(); Button posts=btn("Posts",Color.rgb(69,52,132),Color.WHITE);posts.setOnClickListener(v->openSocial("posts"));social.addView(posts,weight(1,dp(42)));social.addView(new Space(this),lp(dp(7),1));Button media=btn("Photos / Videos",Color.rgb(69,52,132),Color.WHITE);media.setOnClickListener(v->openSocial("media"));social.addView(media,weight(1,dp(42)));root.addView(social,margin(lp(-1,dp(42)),0,dp(8),0,0));
        smooth(posts);smooth(media);
        Button creator=btn("✨ Creator Center / Live",Color.rgb(93,55,182),Color.WHITE);creator.setOnClickListener(v->{Intent i=new Intent(this,CreatorCenterActivity.class);i.putExtra("userId",userId);startActivity(i);});root.addView(creator,margin(lp(-1,dp(44)),0,dp(7),0,0));smooth(creator);

        scroll.addView(root,new ScrollView.LayoutParams(-1,-2)); root.post(root::requestApplyInsets); return scroll;
    }

    private LinearLayout statBox(String label){LinearLayout b=col();b.setGravity(Gravity.CENTER);TextView n=txt("0",DARK,20,true);n.setGravity(Gravity.CENTER);TextView l=txt(label,MUTED,9,false);l.setGravity(Gravity.CENTER);b.addView(n,lp(-1,dp(30)));b.addView(l,lp(-1,dp(22)));return b;}

    private void load(){
        if(userId.isEmpty()){title.setText("User unavailable");return;} if(loading)return; loading=true;
        BackendClient.userProfile(SessionManager.getToken(this),userId,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){JSONObject p=d.optJSONObject("profile");runOnUiThread(()->{loading=false;if(p==null){title.setText("Profile unavailable");return;}renderProfile(p);});}
            public void onError(String m){runOnUiThread(()->{loading=false;title.setText("Profile unavailable");});}
        });
    }

    private void renderProfile(JSONObject p){
        name=p.optString("name","MY SHOP User"); avatarUrl=p.optString("avatarUrl",""); coverUrl=p.optString("coverUrl",""); relation=p.optString("state","NONE"); isFollowing=p.optBoolean("isFollowing",false);
        title.setText(name); if(levelBadge!=null)levelBadge.setText("👑 Lv. "+Math.max(0,p.optInt("level",0))); String relationText="FRIEND".equals(relation)?"  •  Friend":"REQUESTED".equals(relation)?"  •  Requested":"INCOMING".equals(relation)?"  •  Sent you a request":""; state.setText("MY SHOP ID  •  "+userId+relationText);
        String bioText=p.optString("bio","").trim(); bio.setText(bioText.isEmpty()?"No bio yet":bioText);
        JSONObject st=p.optJSONObject("stats"); if(st!=null)renderStats(st);
        org.json.JSONArray ba=p.optJSONArray("badges"); String badgeCode=""; if(ba!=null&&ba.length()>0){JSONObject bb=ba.optJSONObject(0);if(bb!=null){badgeCode=bb.optString("badge_code","MEMBER").trim().toUpperCase();String au=bb.optString("animation_url","");String pu=bb.optString("preview_url","");if(!au.isEmpty()||!pu.isEmpty()){badgeAnim.setVisibility(View.VISIBLE);AnimatedAssetLoader.load(badgeAnim,!au.isEmpty()?au:pu);}else badgeAnim.setVisibility(View.GONE);}} else badgeAnim.setVisibility(View.GONE); applyBadge(badgeCode);
        avatar.setImageResource(R.drawable.myshop_profile_avatar); if(!avatarUrl.isEmpty())loadImage(avatarUrl,avatar);
        cover.setImageDrawable(null); cover.setBackground(round(Color.rgb(26,34,64),Color.TRANSPARENT,18)); if(!coverUrl.isEmpty())loadImage(coverUrl,cover);
        applyButtons();
    }

    private void renderStats(JSONObject st){animateCount(friendsCount,st.optInt("friends",0));animateCount(followersCount,st.optInt("followers",0));animateCount(followingCount,st.optInt("following",0));}
    private void animateCount(TextView v,int n){v.animate().alpha(.45f).setDuration(60).withEndAction(()->{v.setText(String.valueOf(n));v.animate().alpha(1f).setDuration(110).start();}).start();}

    private void applyButtons(){
        if("SELF".equals(relation)){friend.setVisibility(View.GONE);follow.setVisibility(View.GONE);return;} friend.setVisibility(View.VISIBLE);follow.setVisibility(View.VISIBLE);
        if("FRIEND".equals(relation)){friend.setText("✓ Friends");friend.setEnabled(true);friend.setBackground(round(GREEN,GREEN,13));}
        else if("REQUESTED".equals(relation)){friend.setText("✕ Cancel Request");friend.setEnabled(true);friend.setBackground(round(Color.rgb(83,91,115),Color.rgb(83,91,115),13));}
        else if("INCOMING".equals(relation)){friend.setText("✓ / ✕ Respond");friend.setEnabled(true);friend.setBackground(round(BLUE,BLUE,13));}
        else{friend.setText("＋ Add Friend");friend.setEnabled(true);friend.setBackground(round(BLUE,BLUE,13));}
        follow.setText(isFollowing?"✓ Following":"＋ Follow"); follow.setBackground(round(isFollowing?Color.rgb(76,83,108):Color.rgb(35,114,208),isFollowing?Color.rgb(76,83,108):Color.rgb(35,114,208),13)); follow.setEnabled(true);
    }

    private void applyBadge(String code){if(code==null||code.isEmpty()){badge.setVisibility(View.GONE);return;}int bg=Color.rgb(65,77,116),fg=Color.WHITE;String label=code;if("BLUE".equals(code)){bg=Color.rgb(55,120,242);label="BLUE ✓";}else if("VIP".equals(code)){bg=Color.rgb(255,190,72);fg=Color.rgb(45,28,0);}else if("VVIP".equals(code)){bg=Color.rgb(181,74,238);}else if("ROYAL".equals(code)){bg=Color.rgb(215,157,28);fg=Color.rgb(45,28,0);}badge.setText(label);badge.setTextColor(fg);badge.setBackground(round(bg,Color.argb(150,255,255,255),13));badge.setPadding(dp(9),0,dp(9),0);badge.setVisibility(View.VISIBLE);}

    private void friendAction(){
        if("INCOMING".equals(relation)){showIncomingRequestDialog();return;}
        if("FRIEND".equals(relation)){new AlertDialog.Builder(this).setTitle("Unfriend").setMessage("Remove "+name+" from your friends?").setNegativeButton("Keep Friend",null).setPositiveButton("Unfriend",(d,w)->removeFriend()).show();return;}
        if("REQUESTED".equals(relation)){friend.setEnabled(false);friend.setText("Cancelling…");BackendClient.cancelFriendRequest(SessionManager.getToken(this),userId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{relation="NONE";JSONObject st=d.optJSONObject("peerStats");if(st!=null)renderStats(st);applyButtons();Toast.makeText(UserProfileActivity.this,"Friend request cancelled",Toast.LENGTH_SHORT).show();});}public void onError(String m){runOnUiThread(()->{applyButtons();Toast.makeText(UserProfileActivity.this,m,Toast.LENGTH_SHORT).show();});}});return;}
        friend.setEnabled(false); friend.setText("Sending…");
        BackendClient.sendFriendRequest(SessionManager.getToken(this),userId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{relation="REQUESTED";applyButtons();Toast.makeText(UserProfileActivity.this,"Friend request sent",Toast.LENGTH_SHORT).show();});}public void onError(String m){runOnUiThread(()->{friend.setEnabled(true);applyButtons();Toast.makeText(UserProfileActivity.this,m,Toast.LENGTH_SHORT).show();});}});
    }

    private void showIncomingRequestDialog(){
        new AlertDialog.Builder(this).setTitle("Friend Request").setMessage(name+" sent you a friend request.")
                .setNegativeButton("✕ Decline",(d,w)->respondIncoming("DECLINE"))
                .setPositiveButton("✓ Accept",(d,w)->respondIncoming("ACCEPT")).show();
    }
    private void respondIncoming(String action){
        friend.setEnabled(false); friend.setText("ACCEPT".equals(action)?"Accepting…":"Declining…");
        BackendClient.respondFriendRequest(SessionManager.getToken(this),userId,action,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{relation="ACCEPT".equals(action)?"FRIEND":"NONE";JSONObject st=d.optJSONObject("peerStats");if(st!=null)renderStats(st);applyButtons();Toast.makeText(UserProfileActivity.this,"ACCEPT".equals(action)?"Friend added":"Request declined",Toast.LENGTH_SHORT).show();});}
            public void onError(String m){runOnUiThread(()->{applyButtons();Toast.makeText(UserProfileActivity.this,m,Toast.LENGTH_SHORT).show();});}
        });
    }

    private void removeFriend(){friend.setEnabled(false);BackendClient.removeFriend(SessionManager.getToken(this),userId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{relation="NONE";JSONObject st=d.optJSONObject("peerStats");if(st!=null)renderStats(st);applyButtons();});}public void onError(String m){runOnUiThread(()->{applyButtons();Toast.makeText(UserProfileActivity.this,m,Toast.LENGTH_SHORT).show();});}});}

    private void followAction(){
        follow.setEnabled(false); follow.setText(isFollowing?"Unfollowing…":"Following…");
        BackendClient.toggleFollow(SessionManager.getToken(this),userId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{isFollowing=d.optBoolean("following",!isFollowing);JSONObject st=d.optJSONObject("stats");if(st!=null)renderStats(st);applyButtons();});}public void onError(String m){runOnUiThread(()->{applyButtons();Toast.makeText(UserProfileActivity.this,m,Toast.LENGTH_SHORT).show();});}});
    }

    private void openSocial(String tab){Intent q=new Intent(this,ProfileSocialActivity.class);q.putExtra("userId",userId);q.putExtra("tab",tab);startActivity(q);}

    private void openChat(){if(userId.equals(SessionManager.getUserId(this)))return;Intent q=new Intent(this,ChatActivity.class);q.putExtra("userId",userId);q.putExtra("name",name);q.putExtra("avatarUrl",avatarUrl);startActivity(q);}

    private void loadImage(String u,ImageView target){io.execute(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(5000);c.setReadTimeout(7000);try(InputStream in=c.getInputStream()){Bitmap bm=BitmapFactory.decodeStream(in);if(bm!=null)runOnUiThread(()->{target.setImageBitmap(bm);target.setAlpha(0f);target.animate().alpha(1f).setDuration(160).start();});}}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}});}
    private void smooth(View v){v.setOnTouchListener((x,e)->{if(e.getAction()==android.view.MotionEvent.ACTION_DOWN)x.animate().scaleX(.97f).scaleY(.97f).alpha(.9f).setDuration(60).start();else if(e.getAction()==android.view.MotionEvent.ACTION_UP||e.getAction()==android.view.MotionEvent.ACTION_CANCEL)x.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(100).start();return false;});}
    @Override protected void onDestroy(){io.shutdownNow();super.onDestroy();}

    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView txt(String s,int c,float z,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button btn(String s,int bg,int fg){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(fg);b.setTextSize(11.5f);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setMinHeight(0);b.setMinWidth(0);b.setBackground(bg==Color.TRANSPARENT?null:round(bg,bg,13));return b;}
    private GradientDrawable gradientRound(int a,int b,int r){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{a,b});g.setCornerRadius(dp(r));g.setStroke(dp(1),Color.argb(110,255,255,255));return g;}
    private GradientDrawable round(int f,int st,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(st!=Color.TRANSPARENT)g.setStroke(dp(1),st);return g;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}private LinearLayout.LayoutParams margin(LinearLayout.LayoutParams p,int l,int t,int r,int b){p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
