package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** V-297 বাংলা six-slot ad manager + startup 9:16 guidance/preview/ratio warning. */
public class DashboardAdsAdminActivity extends AppCompatActivity {
    private final String[] BOXES={"startup_ad","live_now","my_feed","go_live","live_tv","my_shop","external_movie","gallery","social_media","earn_reward","share","chat","more_apps"};
    private final String[] LABELS={"অ্যাপ ওপেন বিজ্ঞাপন","লাইভ চলছে","MY FEED","গো লাইভ","লাইভ টিভি","MY SHOP","এক্সটার্নাল মুভি","গ্যালারি","সোশ্যাল মিডিয়া","আয় ও রিওয়ার্ড","শেয়ার","চ্যাট","আরও অ্যাপ"};
    private LinearLayout list;private String box="live_now";private int slot=1;private boolean fixedBox=false;private static final int PICK=9301;private final ExecutorService imageIo=Executors.newFixedThreadPool(2);
    private final int BG=Color.rgb(248,249,253),DARK=Color.rgb(18,32,75),PURPLE=Color.rgb(91,38,214),ORANGE=Color.rgb(238,132,15),RED=Color.rgb(238,35,52),GREEN=Color.rgb(24,169,98),MUTED=Color.rgb(100,110,138);

    @Override protected void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)){finish();return;}build();load();}
    private void build(){
        LinearLayout root=col();fixedBox=getIntent().hasExtra("box_key");String requested=getIntent().getStringExtra("box_key");if(requested!=null&&!requested.trim().isEmpty())box=requested.trim();root.setPadding(dp(12),dp(12),dp(12),dp(18));root.setBackgroundColor(BG);
        LinearLayout h=row();TextView back=action("‹",DARK);back.setTextSize(27);back.setBackgroundColor(Color.TRANSPARENT);back.setTextColor(DARK);back.setOnClickListener(v->finish());h.addView(back,lp(dp(42),dp(44)));String title=getIntent().getStringExtra("box_title");if(title==null||title.trim().isEmpty())title=box.replace('_',' ').toUpperCase();LinearLayout hb=col();hb.addView(txt(title,19,DARK,true));hb.addView(txt("বিজ্ঞাপন ব্যবস্থাপনা",10,MUTED,false));h.addView(hb,weight(1,dp(46)));root.addView(h,lp(-1,dp(50)));
        root.addView(note("প্রতি ফোল্ডারে সর্বোচ্চ ৬টি বিজ্ঞাপন। Add → Preview → Save/Publish → Edit/Delete করুন।"));
        if("startup_ad".equals(box))root.addView(startupGuide());
        if(!fixedBox){Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,LABELS));int current=0;for(int i=0;i<BOXES.length;i++)if(BOXES[i].equals(box))current=i;sp.setSelection(current);sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){box=BOXES[pos];load();}});root.addView(sp,lp(-1,dp(52)));}
        list=col();ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(list);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }
    private View startupGuide(){LinearLayout c=card();TextView h=txt("📐 অ্যাপ ওপেন বিজ্ঞাপনের সঠিক মাপ",13,DARK,true);c.addView(h);TextView g=txt("প্রস্তাবিত: 1080 × 1920 px • 9:16\nসর্বনিম্ন: 720 × 1280 px\nভুল অনুপাত হলে Crop Warning দেখাবে। ছবি/ভিডিও টেনে বিকৃত করা হবে না; স্ক্রিন অনুযায়ী responsive crop/fit হবে।",10,MUTED,false);g.setPadding(0,dp(6),0,0);c.addView(g);return c;}
    private void load(){if(list==null)return;BackendClient.adminAds(SessionManager.getToken(this),box,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->render(d.optJSONArray("ads")));}public void onError(String m){runOnUiThread(()->{render(null);toast("বিজ্ঞাপন load হয়নি: "+m);});}});}
    private void render(JSONArray a){list.removeAllViews();JSONObject[] slots=new JSONObject[6];if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null){int s=x.optInt("slot",0);if(s>=1&&s<=6)slots[s-1]=x;}}for(int i=0;i<6;i++)slotCard(i+1,slots[i]);}
    private void slotCard(int s,JSONObject x){
        boolean saved=x!=null;LinearLayout c=card();c.addView(txt("বিজ্ঞাপন Slot "+s+(saved?"  •  সংরক্ষিত":"  •  খালি"),14,DARK,true));c.addView(txt(saved?"বর্তমান media নিচে preview করা হয়েছে। প্রয়োজন হলে তথ্য বদলে Save করুন।":"এই slot খালি। ‘ছবি/ভিডিও যোগ করুন’ চাপুন।",10,MUTED,false));
        if(saved){String media=x.optString("image_url","");String mt=x.optString("media_type","image");if(!media.isEmpty()&&!"video".equalsIgnoreCase(mt)){ImageView p=new ImageView(this);p.setScaleType(ImageView.ScaleType.CENTER_CROP);p.setBackground(round(Color.rgb(240,242,247),Color.rgb(224,226,235),10));LinearLayout.LayoutParams pp=lp(-1,dp("startup_ad".equals(box)?190:128));pp.topMargin=dp(7);c.addView(p,pp);loadPreview(p,media);}else if("video".equalsIgnoreCase(mt)){TextView vp=txt("▶ বর্তমান ভিডিও বিজ্ঞাপন",12,PURPLE,true);vp.setGravity(Gravity.CENTER);vp.setBackground(round(Color.rgb(246,242,255),Color.rgb(225,217,246),10));c.addView(vp,top(lp(-1,dp(72)),dp(7)));}}
        c.addView(fieldHelp("ক্যাপশন","চাইলে বিজ্ঞাপনের সাথে ছোট লেখা দিন।"));EditText cap=field("ক্যাপশন (ঐচ্ছিক)",saved?x.optString("caption",""):"");c.addView(cap,lp(-1,dp(48)));
        c.addView(fieldHelp("ক্লিক লিংক","বিজ্ঞাপনে চাপলে কোথায় যাবে; না লাগলে খালি রাখুন।"));EditText target=field("লিংক URL (ঐচ্ছিক)",saved?x.optString("target_url",""):"");c.addView(target,lp(-1,dp(48)));
        c.addView(fieldHelp("দেখানোর সময়","অ্যাপ খোলার বিজ্ঞাপন: ১–৪ সেকেন্ড। অন্য ব্যানার প্রয়োজন অনুযায়ী।"));EditText duration=field("সময় (সেকেন্ড)",saved?String.valueOf(x.optInt("duration_sec",3)):"3");duration.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);c.addView(duration,lp(-1,dp(48)));
        Switch active=new Switch(this);active.setText("চালু / Publish");active.setTextSize(11);active.setChecked(!saved||x.optInt("active",1)==1);active.setEnabled(saved);c.addView(active,lp(-1,dp(42)));
        LinearLayout actions=row();TextView add=action("➕ যোগ করুন",PURPLE);add.setOnClickListener(v->{slot=s;pick();});actions.addView(add,wt(1));actions.addView(space(dp(4)));TextView save=action("💾 সংরক্ষণ",GREEN);save.setOnClickListener(v->{if(saved)BackendClient.adminAdUpdate(SessionManager.getToken(this),x.optLong("id"),cap.getText().toString().trim(),target.getText().toString().trim(),active.isChecked(),parseDuration(duration.getText().toString()),new Cb("✓ সংরক্ষণ হয়েছে",this::load));else{slot=s;pick();}});actions.addView(save,wt(1));actions.addView(space(dp(4)));TextView del=action("🗑 মুছুন",RED);del.setAlpha(saved?1f:.45f);del.setOnClickListener(v->{if(!saved){toast("স্লট খালি");return;}new AlertDialog.Builder(this).setTitle("বিজ্ঞাপন মুছবেন?").setMessage("শুধু এই স্লটের বিজ্ঞাপন সরানো হবে।").setPositiveButton("DELETE",(d,w)->BackendClient.adminAdDelete(SessionManager.getToken(this),x.optLong("id"),new Cb("✓ মুছে গেছে",this::load))).setNegativeButton("বাতিল",null).show();});actions.addView(del,wt(1));c.addView(actions,top(lp(-1,dp(44)),dp(7)));list.addView(c);}

    private void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","video/*"});i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r!=PICK||c!=RESULT_OK||d==null||d.getData()==null)return;Uri u=d.getData();String mime=getContentResolver().getType(u);showUpload(u,mime==null?"application/octet-stream":mime);}
    private void showUpload(Uri uri,String mime){
        LinearLayout b=col();b.setPadding(dp(6),dp(4),dp(6),dp(4));TextView ratio=txt(mediaInfo(uri,mime),10,MUTED,false);b.addView(ratio);
        if(mime.startsWith("image/")){ImageView p=new ImageView(this);p.setScaleType(ImageView.ScaleType.CENTER_CROP);p.setImageURI(uri);b.addView(p,lp(-1,dp(210)));}else if(mime.startsWith("video/")){VideoView v=new VideoView(this);v.setVideoURI(uri);MediaController mc=new MediaController(this);mc.setAnchorView(v);v.setMediaController(mc);b.addView(v,lp(-1,dp(210)));v.setOnPreparedListener(mp->{mp.setLooping(true);v.start();});}
        EditText cap=field("ক্যাপশন (ঐচ্ছিক)",""),target=field("লিংক URL (ঐচ্ছিক)",""),duration=field("সময় (সেকেন্ড)","3");duration.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);Switch active=new Switch(this);active.setText("চালু / Publish");active.setChecked(true);b.addView(cap,lp(-1,dp(48)));b.addView(target,lp(-1,dp(48)));b.addView(duration,lp(-1,dp(48)));b.addView(active,lp(-1,dp(42)));
        new AlertDialog.Builder(this).setTitle("প্রিভিউ • স্লট "+slot).setView(b).setNegativeButton("বাতিল",null).setPositiveButton("আপলোড + সংরক্ষণ",(d,w)->{try{InputStream in=getContentResolver().openInputStream(uri);BackendClient.adminAdUpload(SessionManager.getToken(this),in,fileNameForMime(mime),mime,box,slot,cap.getText().toString().trim(),target.getText().toString().trim(),active.isChecked(),parseDuration(duration.getText().toString()),new Cb("✓ বিজ্ঞাপন Save হয়েছে",this::load));}catch(Exception e){toast("Media খোলা যায়নি");}}).show();
    }
    private String mediaInfo(Uri u,String mime){if(!"startup_ad".equals(box))return "নির্বাচিত media Preview করুন, তারপর Upload + Save চাপুন।";int w=0,h=0;try{if(mime.startsWith("image/")){BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;try(InputStream in=getContentResolver().openInputStream(u)){BitmapFactory.decodeStream(in,null,o);}w=o.outWidth;h=o.outHeight;}else if(mime.startsWith("video/")){MediaMetadataRetriever r=new MediaMetadataRetriever();r.setDataSource(this,u);w=parseInt(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));h=parseInt(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));r.release();}}catch(Exception ignored){}if(w<=0||h<=0)return "প্রস্তাবিত: 1080×1920 • 9:16 • সর্বনিম্ন 720×1280";float ratio=w/(float)h;boolean ok=Math.abs(ratio-(9f/16f))<.045f;String min=(w>=720&&h>=1280)?"রেজোলিউশন ঠিক আছে":"রেজোলিউশন ছোট";return w+" × "+h+" • "+min+"\n"+(ok?"✓ 9:16 ratio ঠিক আছে":"⚠ ক্রপ সতর্কতা: 9:16 নয়। টেনে বিকৃত করা হবে না; স্ক্রিন অনুযায়ী ক্রপ/ফিট হবে।");}
    private int parseInt(String s){try{return Integer.parseInt(s);}catch(Exception e){return 0;}}
    private void loadPreview(ImageView target,String url){imageIo.execute(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(5000);c.setReadTimeout(7000);try(InputStream in=c.getInputStream()){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null)runOnUiThread(()->target.setImageBitmap(b));}}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}});}
    private int parseDuration(String s){try{return Math.max(1,Math.min("startup_ad".equals(box)?4:60,Integer.parseInt(s.trim())));}catch(Exception e){return 3;}}
    private String fileNameForMime(String mime){String m=mime==null?"":mime.toLowerCase();if(m.contains("mp4"))return "ad.mp4";if(m.contains("webm"))return "ad.webm";if(m.contains("png"))return "ad.png";if(m.contains("webp"))return "ad.webp";return m.startsWith("video/")?"ad.mp4":"ad.jpg";}
    @Override protected void onDestroy(){imageIo.shutdownNow();super.onDestroy();}

    private LinearLayout card(){LinearLayout c=col();c.setPadding(dp(10),dp(10),dp(10),dp(10));c.setBackground(round(Color.WHITE,Color.rgb(224,226,235),12));c.setElevation(dp(1));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(8);c.setLayoutParams(p);return c;}
    private TextView note(String s){TextView t=txt(s,10,MUTED,false);t.setPadding(dp(9),dp(8),dp(9),dp(8));t.setBackground(round(Color.WHITE,Color.rgb(229,232,242),11));LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(8);t.setLayoutParams(p);return t;}
    private TextView fieldHelp(String title,String desc){TextView t=txt(title+" — "+desc,9.5f,MUTED,false);t.setPadding(0,dp(7),0,dp(3));return t;}
    private EditText field(String h,String v){EditText e=new EditText(this);e.setHint(h);e.setText(v);e.setSingleLine(true);e.setTextSize(12);e.setPadding(dp(10),0,dp(10),0);e.setBackground(round(Color.WHITE,Color.rgb(215,218,228),9));return e;}
    private TextView action(String s,int c){TextView t=txt(s,10,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setBackground(round(c,c,9));return t;}private TextView txt(String s,float z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private View space(int w){Space s=new Space(this);s.setLayoutParams(new LinearLayout.LayoutParams(w,1));return s;}
    private GradientDrawable round(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}private LinearLayout.LayoutParams wt(float w){return new LinearLayout.LayoutParams(0,dp(44),w);}private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=m;return p;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}
    private class Cb implements BackendClient.Callback{String ok;Runnable done;Cb(String ok,Runnable done){this.ok=ok;this.done=done;}public void onSuccess(JSONObject d){runOnUiThread(()->{toast(ok);if(done!=null)done.run();});}public void onError(String m){runOnUiThread(()->toast(m));}}
}
