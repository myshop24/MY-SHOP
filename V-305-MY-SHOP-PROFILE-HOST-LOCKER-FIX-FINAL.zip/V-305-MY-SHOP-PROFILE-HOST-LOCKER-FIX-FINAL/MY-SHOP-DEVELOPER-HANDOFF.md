# MY SHOP Developer Handoff — V-305

## Version
V-305 / Android 2.9.305

## Completed in this checkpoint
- Host rendered only in the dedicated top Host area; duplicate Host display removed from the 12-seat board without redesigning the seat layout.
- Admin Locker local persistence hardened for normal APK upgrades with stable hash/salt mirror/migration logic.
- Profile Share button visibility corrected while keeping native sharing.
- Quick Tools redesigned to show My Coins, Gold Coin, Badge / Member and My Items together in one compact premium row without horizontal scrolling.
- Existing four Quick Tools functions preserved.
- Profile Photos/Videos/Reels media-grid zero-width rendering issue fixed with responsive explicit tile sizing.

## Preserved / regression locks
- 12-seat 6+6 visual seat board.
- Existing Live request/invite/moderation/gift/theme flows.
- Feed/Profile Timeline/Back navigation.
- Existing D1/R2 bindings/schema and application ID.
- Live comments remain ephemeral/session-only.

## Validation checkpoint
Static XML/version/feature guards and Worker JavaScript syntax passed. Full Android compilation and real-device interaction remain for GitHub Actions/device QA because the local environment has no Android Gradle CLI/SDK.

## Next runtime checks
1. Install V-305 directly over V-304 without uninstalling and confirm existing Admin Locker opens Login instead of Create Locker.
2. Enter Audio Live and confirm Host appears only at the top while all 12 seat visuals remain in their original 6+6 positions.
3. Confirm all four Quick Tools are visible simultaneously on the user's target phone and every original action still opens the same destination.
4. Confirm Share Profile label/icon remains visible and Android share sheet opens.
5. Open Photos, Videos and Reels and verify real uploaded media thumbnails/cards render and open correctly.
