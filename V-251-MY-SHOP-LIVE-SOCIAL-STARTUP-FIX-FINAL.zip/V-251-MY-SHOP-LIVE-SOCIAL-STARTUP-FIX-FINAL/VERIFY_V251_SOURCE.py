from pathlib import Path
import sys, subprocess, xml.etree.ElementTree as ET
R=Path(__file__).parent
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
app=(R/'app/build.gradle').read_text()
main=(R/'app/src/main/java/com/myshop/app/MainActivity.java').read_text()
notif=(R/'app/src/main/java/com/myshop/app/NotificationActivity.java').read_text()
startup=(R/'app/src/main/java/com/myshop/app/StartupAdActivity.java').read_text()
ads=(R/'app/src/main/java/com/myshop/app/DashboardAdsAdminActivity.java').read_text()
account=(R/'app/src/main/java/com/myshop/app/AccountActivity.java').read_text()
layout=(R/'app/src/main/res/layout/activity_account.xml').read_text()
people=(R/'app/src/main/java/com/myshop/app/NewPeopleActivity.java').read_text()
backend=(R/'backend/worker/src/index.js').read_text()
ck('source id', (R/'SOURCE_BUILD_ID.txt').read_text().strip()=='MY SHOP V-251')
ck('source version', (R/'SOURCE_VERSION_NAME.txt').read_text().strip()=='2.9.251')
ck('android version', 'versionCode 251' in app and "versionName '2.9.251'" in app)
ck('worker identity', "version:'2.9.251'" in backend and "build:'V-251'" in backend)
ck('animated two-side live signals', main.count('text("📶"')>=2 and 'ObjectAnimator.ofFloat(signalL' in main and 'ObjectAnimator.ofFloat(signalR' in main)
ck('bold live actions', '🎙  Go Live' in main and '👥  Join Live' in main and 'setDuration(980)' in main)
ck('live/new fallback and profile', 'liveCount' in backend and "fillMode" in backend and 'ID: "+uid' in main and 'UserProfileActivity.class' in main and 'showAllNewPeople()' in main)
ck('friend-aware directory', "THEN 'FRIEND'" in backend and 'Friends ✓' in main and 'Friends ✓' in people)
ck('filtered notification inbox', "n.audience='USER'" in backend and "'LIKE','COMMENT','FRIEND_REQUEST','FRIEND_ACCEPT','LIVE_START'" in backend and 'Join Now' in notif)
ck('no broad notification query', "(n.audience='ALL' OR (n.audience='USER'" not in backend[backend.find('async function notificationsList'):backend.find('async function notificationReadOne')])
ck('banner ratio improvement', 'hero.setScaleType(ImageView.ScaleType.FIT_CENTER)' in main and 'dp(136)' in main)
ck('facebook profile structure', 'android:layout_height="210dp"' in layout and 'android:layout_marginTop="-58dp"' in layout and 'Edit Cover' in layout and 'Share Profile' in layout)
ck('cover persistence flow', 'coverActions()' in account and 'BackendClient.uploadCover' in account and 'SessionManager.saveProfile' in account)
ck('real social counters backend', 'SELECT COUNT(*) c FROM myshop_follows WHERE following_id=?' in backend and 'SELECT COUNT(*) c FROM myshop_follows WHERE follower_id=?' in backend and "status='ACCEPTED'" in backend)
ck('startup 1-6 client', startup.count('Math.min(6')>=3 and 'setConnectTimeout(3500)' in startup and 'setReadTimeout(5500)' in startup)
ck('startup 1-6 admin/backend', 'STARTUP: 1-6' in ads and backend.count("box==='startup_ad'?Math.max(1,Math.min(6,requestedDuration))")>=1 and "adBox?.box_key==='startup_ad'?Math.max(1,Math.min(6,requestedDuration))" in backend)
ck('startup image and video backend', 'AD_MUST_BE_IMAGE_OR_VIDEO' in backend and "mime.startsWith('video/')" in backend and "mime.startsWith('image/')" in backend)
try:
    for f in (R/'app/src/main/res').rglob('*.xml'): ET.parse(f)
    ET.parse(R/'app/src/main/AndroidManifest.xml'); xmlok=True
except Exception as e:
    print('XML ERROR',e); xmlok=False
ck('android xml parse', xmlok)
try:
    r=subprocess.run(['node','--check',str(R/'backend/worker/src/index.js')],capture_output=True,text=True)
    if r.returncode: print(r.stderr)
    jsok=r.returncode==0
except Exception as e:
    print('NODE ERROR',e); jsok=False
ck('worker javascript syntax', jsok)
for n,v in checks: print(('PASS' if v else 'FAIL'),n)
if not all(v for _,v in checks): sys.exit(1)
