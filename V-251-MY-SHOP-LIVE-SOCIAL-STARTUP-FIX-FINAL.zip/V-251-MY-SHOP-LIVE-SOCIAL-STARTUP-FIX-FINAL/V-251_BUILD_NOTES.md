# MY SHOP V-251 — Live / Social / Profile / Startup Ad Fix

Base: V-250-MY-SHOP-COMPACT-LIVE-DASHBOARD-FINAL
Version: 2.9.251 (versionCode 251)

## Implemented
1. LIVE STREAMING title now uses animated broadcast/wave signals on both sides.
2. Go Live / Join Live typography is bolder with stronger smooth pulse/glow animation.
3. Live strip prioritizes active live users; when no/too few live users exist it fills with newest users. Offline cards show larger avatar, name, MY SHOP ID, relationship-aware Friend action, full-profile tap, and See All opens the full newest-first user directory. Middle advertisement slider is preserved.
4. Notification inbox is user-centric: own-post Like/Comment, Friend Request/Accept, and Live Start only. Routine admin/banner/gallery/update broadcasts are filtered out. Live Start includes Join Now.
5. Dashboard advertisement hero uses a taller display area and FIT_CENTER/adjust-bounds scaling to reduce squashing/blurry text while preserving the slider.
6. Own Profile header changed to Facebook-style structure: wide cover, overlapping larger avatar, edit-cover/edit-avatar controls, name/info/actions, real social stats, timeline/media/privacy. Existing cover upload/save backend path is preserved.
7. Friends / Followers / Following remain database-derived. Relationship directory state now includes FRIEND; follow/unfollow and friend acceptance return real stats and Profile refreshes them from backend.
8. Startup image/video ad supports 1–6 seconds. Admin UI/backend clamps to 1–6; image/video media types are supported; startup fetch/render timeouts are more tolerant while preserving fail-open behavior.

## Verification performed in this workspace
- Worker JavaScript syntax: node --check PASS.
- Android XML parse: PASS for all resource XML files.
- Version/build identity checks: PASS.
- Java source was syntax-screened with javac; only expected missing Android SDK/classpath errors were observed, with no Java syntax-pattern errors.
- Full Android APK compile/device runtime test is not performed in this container because Android SDK/Gradle toolchain is not installed here.
