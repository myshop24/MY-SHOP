# MY SHOP Developer Handoff — V-251

## Current base/version
- Current source: **V-251 / 2.9.251 / versionCode 251**.
- Created from preserved **V-250-MY-SHOP-COMPACT-LIVE-DASHBOARD-FINAL** base.

## Completed in V-251
- Animated two-sided LIVE STREAMING broadcast signals.
- Stronger/bolder Go Live and Join Live controls.
- Live-first/new-user fallback cards with Name + MY SHOP ID + Friend action + full profile navigation + See All user directory.
- User-centric Facebook-like notifications (own-post Like/Comment, Friend Request/Accept, Live Start + Join Now); routine admin content notices hidden from user inbox.
- Dashboard ad banner aspect/height/readability improvement while preserving slider.
- Facebook-style own Profile header with editable/persistent cover photo and existing avatar edit flow.
- Real backend social counters/relationship state preserved and surfaced for Friends/Followers/Following.
- App-open startup image/video ad duration expanded and fixed to **1–6 seconds** with more reliable remote media loading and fail-open safety.

## Preserved behavior
- Existing V-250 dashboard/live/social/media/backend features remain in place unless specifically changed above.
- Startup ad ON/OFF, Add/Edit/Save/Delete, caption/target link, R2 media storage and dashboard ad slots remain supported.
- User cover upload uses the existing authenticated backend upload flow and persisted `cover_url`.

## Verification / current phase
- Worker JavaScript syntax checked successfully.
- All Android resource XML parses successfully.
- V-251 source identity/version and key feature markers pass `VERIFY_V251_SOURCE.py`.
- Java files received a syntax-pattern screen; the local container lacks Android SDK/Gradle, so a real Android compile/runtime result is intentionally **not claimed** here.

## Exact next checkpoint
1. Run GitHub Actions Android build from this V-251 source.
2. Install the generated APK on a test device.
3. Device-test: Live title/button animation, live/new fallback, See All/profile/friend actions, notification filtering + Join Now, ad-banner visual ratio, profile cover change/persistence/social counts, and startup image/video ads at 1/2/3/4/5/6 seconds.
4. If a build/runtime failure occurs, fix from this V-251 checkpoint without reverting to older project roots.
