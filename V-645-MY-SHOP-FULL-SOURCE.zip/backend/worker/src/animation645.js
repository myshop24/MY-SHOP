import {schemaOnce} from './schema-once.js';
export const schema645=[
`CREATE TABLE IF NOT EXISTS animation_settings645(id INTEGER PRIMARY KEY CHECK(id=1),revision INTEGER NOT NULL DEFAULT 0,draft TEXT NOT NULL DEFAULT '{}',published TEXT NOT NULL DEFAULT '{}')`,
`INSERT OR IGNORE INTO animation_settings645(id) VALUES(1)`,
`CREATE TABLE IF NOT EXISTS animation_audit645(id INTEGER PRIMARY KEY AUTOINCREMENT,actor TEXT NOT NULL,action TEXT NOT NULL,data TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
`CREATE TABLE IF NOT EXISTS animation_events645(event_id TEXT PRIMARY KEY,event_type TEXT NOT NULL,gift_id INTEGER NOT NULL,created_ms INTEGER NOT NULL,expires_ms INTEGER NOT NULL)`,
`CREATE INDEX IF NOT EXISTS animation_events645_expiry ON animation_events645(expires_ms,created_ms)`,
`CREATE TABLE IF NOT EXISTS animation_boxes645(id TEXT PRIMARY KEY,amount INTEGER NOT NULL CHECK(amount>0 AND amount<=1000000),starts INTEGER NOT NULL,expires INTEGER NOT NULL,enabled INTEGER NOT NULL DEFAULT 1,actor TEXT NOT NULL)`,
`CREATE TABLE IF NOT EXISTS animation_rooms645(box_id TEXT NOT NULL,host_id TEXT NOT NULL,session_id TEXT NOT NULL,PRIMARY KEY(box_id,host_id))`,
`CREATE TABLE IF NOT EXISTS animation_claims645(box_id TEXT NOT NULL,host_id TEXT NOT NULL,user_id TEXT NOT NULL,amount INTEGER NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(box_id,host_id),UNIQUE(box_id,user_id))`,
`CREATE TRIGGER IF NOT EXISTS animation_gift_insert645 AFTER INSERT ON myshop_live_gift_events WHEN NEW.status='COMPLETED' AND EXISTS(SELECT 1 FROM animation_settings645 s WHERE s.id=1 AND json_extract(s.published,'$.gifts.enabled')=1 AND ((NEW.currency='COIN' AND NEW.price>=json_extract(s.published,'$.gifts.minCoin')) OR (NEW.currency='GOLD' AND NEW.price>=json_extract(s.published,'$.gifts.minGold')))) BEGIN INSERT OR IGNORE INTO animation_events645(event_id,event_type,gift_id,created_ms,expires_ms) VALUES('gift:'||NEW.id,'GIFT',NEW.id,CAST((julianday('now')-2440587.5)*86400000 AS INTEGER),CAST((julianday('now')-2440587.5)*86400000 AS INTEGER)+30000); END`,
`CREATE TRIGGER IF NOT EXISTS animation_gift_complete645 AFTER UPDATE OF status ON myshop_live_gift_events WHEN NEW.status='COMPLETED' AND EXISTS(SELECT 1 FROM animation_settings645 s WHERE s.id=1 AND json_extract(s.published,'$.gifts.enabled')=1 AND ((NEW.currency='COIN' AND NEW.price>=json_extract(s.published,'$.gifts.minCoin')) OR (NEW.currency='GOLD' AND NEW.price>=json_extract(s.published,'$.gifts.minGold')))) AND OLD.status<>'COMPLETED' BEGIN INSERT OR IGNORE INTO animation_events645(event_id,event_type,gift_id,created_ms,expires_ms) VALUES('gift:'||NEW.id,'GIFT',NEW.id,CAST((julianday('now')-2440587.5)*86400000 AS INTEGER),CAST((julianday('now')-2440587.5)*86400000 AS INTEGER)+30000); END`,
`CREATE TRIGGER IF NOT EXISTS animation_claim_check645 BEFORE INSERT ON animation_claims645 BEGIN
SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM animation_boxes645 b JOIN animation_rooms645 r ON r.box_id=b.id JOIN myshop_live_room_meta m ON m.host_id=r.host_id AND m.session_id=r.session_id JOIN myshop_live_presence p ON p.user_id=r.host_id AND p.active=1 AND datetime(p.last_seen)>datetime('now','-90 seconds') WHERE b.id=NEW.box_id AND r.host_id=NEW.host_id AND b.enabled=1 AND b.amount=NEW.amount AND b.starts<=CAST((julianday('now')-2440587.5)*86400000 AS INTEGER) AND b.expires>CAST((julianday('now')-2440587.5)*86400000 AS INTEGER) AND (NEW.user_id=r.host_id OR EXISTS(SELECT 1 FROM myshop_live_visits v WHERE v.host_id=r.host_id AND v.user_id=NEW.user_id AND v.session_id=r.session_id AND EXISTS(SELECT 1 FROM myshop_live_viewers w WHERE w.host_id=r.host_id AND w.user_id=NEW.user_id AND datetime(w.last_seen)>datetime('now','-90 seconds'))))) THEN RAISE(ABORT,'BOX_NOT_ELIGIBLE') END; END`,
`CREATE TRIGGER IF NOT EXISTS animation_claim_credit645 AFTER INSERT ON animation_claims645 BEGIN
INSERT INTO myshop_coin_wallets(user_id,balance) VALUES(NEW.user_id,NEW.amount) ON CONFLICT(user_id) DO UPDATE SET balance=balance+NEW.amount,updated_at=CURRENT_TIMESTAMP;
INSERT INTO myshop_coin_transactions(user_id,kind,amount,reference,metadata) VALUES(NEW.user_id,'LIVE_BOX_REWARD',NEW.amount,'box645:'||NEW.box_id||':'||NEW.host_id,'Admin live gift box');
INSERT INTO myshop_wallet_sources(user_id,currency,official_balance) VALUES(NEW.user_id,'COIN',NEW.amount) ON CONFLICT(user_id,currency) DO UPDATE SET official_balance=official_balance+NEW.amount,updated_at=CURRENT_TIMESTAMP;
INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,host_id,gross_amount,net_amount,reference) VALUES('LIVE_BOX_REWARD','COIN','OFFICIAL',NEW.user_id,NEW.host_id,NEW.amount,NEW.amount,'box645:'||NEW.box_id||':'||NEW.host_id); END`
];
export function ensure645(env){return schemaOnce(env.DB,'animation645',()=>env.DB.batch(schema645.map(s=>env.DB.prepare(s))));}
const pages=['live_room','home','live','shop'];
const types=['MEMBERSHIP','AVATAR_FRAME','RARE_ID','COMMENT_STYLE','ENTRY_ANIMATION','ANNOUNCEMENT','LIVE_INVITE','COMING_SOON','GIFT_BOX','GLOBAL_GIFT'];
export function validate645(raw){
 if(!raw||!Array.isArray(raw.cards)||raw.cards.length>100)throw Error('Maximum 100 cards');
 const ids=new Set();const cards=raw.cards.map(c=>{if(!/^[a-zA-Z0-9_-]{1,64}$/.test(c.id)||ids.has(c.id)||!types.includes(c.type))throw Error('Invalid card identity');ids.add(c.id);
 const ps=[...new Set(c.pages||[])];if(ps.some(p=>!pages.includes(p)))throw Error('Invalid page');
 const positions={};for(const p of pages){const v=c.positions?.[p]||{},x=Number(v.x??.03),y=Number(v.y??.22),width=Number(v.width??.52);if(![x,y,width].every(Number.isFinite)||x<0||x>1||y<0||y>.85||width<.25||width>1)throw Error('Invalid position');positions[p]={x,y,width};}
 const bg=String(c.background||'#F4B82A'),end=String(c.backgroundEnd||bg),ink=String(c.textColor||'#FFFFFF');if([bg,end,ink].some(v=>!/^#[0-9a-f]{6}$/i.test(v)))throw Error('Invalid colour');
 const start=Number(c.starts||0),expires=Number(c.expires||0);if(!Number.isSafeInteger(start)||!Number.isSafeInteger(expires)||start<0||expires<0||expires&&expires<=start)throw Error('Invalid schedule');
 const seconds=Number(c.duration??6);if(!Number.isFinite(seconds)||seconds<2||seconds>30)throw Error('Duration 2–30 seconds');
 return {id:c.id,type:c.type,title:String(c.title||'').slice(0,300),caption:String(c.caption||'').slice(0,300),catalogId:Math.max(0,Math.trunc(Number(c.catalogId)||0)),enabled:c.enabled===true,animation:c.animation!==false,pages:ps,positions,background:bg,backgroundEnd:end,textColor:ink,duration:seconds,starts:start,expires,priority:Math.max(0,Math.min(10,Math.trunc(Number(c.priority)||0)))};});
 const r=raw.gifts||{};for(const k of ['minCoin','minGold'])if(!Number.isSafeInteger(Number(r[k]??1000))||Number(r[k]??1000)<1)throw Error('Invalid gift threshold');
 return {cards,gifts:{enabled:r.enabled===true,minCoin:Number(r.minCoin??10000),minGold:Number(r.minGold??1000)},maxPerMinute:Math.max(1,Math.min(30,Math.trunc(Number(raw.maxPerMinute)||10)))};
}
// One short-lived public snapshot per existing Durable Object; never cache auth or balances.
export async function buildSnapshot645(env){
 const row=await env.DB.prepare('SELECT * FROM animation_settings645 WHERE id=1').first(),config=JSON.parse(row.published),ids=[...new Set((config.cards||[]).map(c=>c.catalogId).filter(Boolean))];
 const items=ids.length?(await env.DB.prepare('SELECT id,title,preview_url,animation_url,code,item_type FROM myshop_store_catalog WHERE enabled=1 AND id IN ('+ids.map(()=>'?').join(',')+')').bind(...ids).all()).results||[]:[];
 const now=Date.now(),gifts=(await env.DB.prepare(`SELECT e.id,e.host_id,e.sender_id,e.receiver_id,e.price,e.currency,e.created_at,g.name,g.preview_url,a.event_id,a.expires_ms,a.created_ms,s.full_name sender_name,r.full_name receiver_name FROM animation_events645 a JOIN myshop_live_gift_events e ON e.id=a.gift_id JOIN myshop_live_gifts g ON g.id=e.gift_id LEFT JOIN myshop_auth_users_v108 s ON s.user_id=e.sender_id LEFT JOIN myshop_auth_users_v108 r ON r.user_id=e.receiver_id WHERE e.status='COMPLETED' AND a.expires_ms>? ORDER BY e.id DESC LIMIT 100`).bind(now).all()).results||[];
 return {revision:row.revision,config,items,gifts,cursorTime:now};
}
async function publicSnapshot645(env){if(!env.LIVE_ROOM_HUB)return buildSnapshot645(env);const stub=env.LIVE_ROOM_HUB.get(env.LIVE_ROOM_HUB.idFromName('animation645-global'));const response=await stub.fetch('https://live-hub/animation645/snapshot');if(!response.ok)throw Error('ANNOUNCEMENT_SNAPSHOT_UNAVAILABLE');return response.json();}
export async function animation645(request,env,h){
 const u=new URL(request.url),path=u.pathname,admin=path.startsWith('/v1/admin/animation645');
 let me;if(admin){const a=await h.adminOnly(request,env);if(a.error)return a.error;me=a.user;}else{me=await h.getUser(request,env);if(!me)return h.json({error:'UNAUTHORIZED'},401,h.cors);}
 await h.ensureLiveRoomSchema(env);await ensure645(env);
 const reply=(v,status=200)=>h.json(v,status,h.cors),row=admin?await env.DB.prepare('SELECT * FROM animation_settings645 WHERE id=1').first():null;
 if(admin&&request.method==='GET')return reply({ok:true,revision:row.revision,config:JSON.parse(row.draft),history:(await env.DB.prepare('SELECT * FROM animation_audit645 ORDER BY id DESC LIMIT 50').all()).results||[],claims:(await env.DB.prepare('SELECT * FROM animation_claims645 ORDER BY created_at DESC LIMIT 50').all()).results||[],events:(await env.DB.prepare('SELECT a.*,e.sender_id,e.receiver_id,e.host_id,e.currency,e.price FROM animation_events645 a JOIN myshop_live_gift_events e ON e.id=a.gift_id ORDER BY a.created_ms DESC LIMIT 50').all()).results||[]});
 if(admin&&request.method==='POST'){
 const b=await request.json().catch(()=>({}));
 if(['save','publish'].includes(b.action)){
 let config;try{config=validate645(b.config);}catch(e){return reply({error:e.message},400);}
 for(const c of config.cards){if(c.catalogId){const item=await env.DB.prepare('SELECT id FROM myshop_store_catalog WHERE id=? AND item_type=? AND enabled=1').bind(c.catalogId,c.type).first();if(!item)return reply({error:'INVALID_CATALOG_ITEM'},400);}else if(c.enabled&&types.indexOf(c.type)<5)return reply({error:'SELECT_REAL_CATALOG_ITEM'},400);}
 const result=await env.DB.batch([env.DB.prepare(`UPDATE animation_settings645 SET revision=revision+1,draft=?,published=CASE WHEN ?='publish' THEN ? ELSE published END WHERE id=1 AND revision=?`).bind(JSON.stringify(config),b.action,JSON.stringify(config),Number(b.revision)),env.DB.prepare('INSERT INTO animation_audit645(actor,action,data) SELECT ?,?,? WHERE changes()=1').bind(me.user_id,b.action,JSON.stringify(config))]);if(!result[0].meta.changes)return reply({error:'CONFIG_CHANGED_RELOAD'},409);return reply({ok:true,revision:Number(row.revision)+1});
 }
 if(b.action==='box'){
 if(!['0001','0002','0003'].includes(me.user_id))return reply({error:'MAIN_ADMIN_ONLY'},403);
 const amount=Number(b.amount),seconds=Number(b.seconds),id=String(b.requestId||'');if(!Number.isSafeInteger(amount)||amount<1||amount>1000000||!Number.isSafeInteger(seconds)||seconds<10||seconds>300||!/^[a-zA-Z0-9_-]{16,80}$/.test(id))return reply({error:'INVALID_BOX'},400);
 const existing=await env.DB.prepare('SELECT * FROM animation_boxes645 WHERE id=?').bind(id).first();if(existing)return existing.actor===me.user_id&&existing.amount===amount?reply({ok:true,id,alreadyPublished:true}):reply({error:'REQUEST_KEY_CONFLICT'},409);
 const now=Date.now();try{await env.DB.batch([env.DB.prepare('INSERT INTO animation_boxes645(id,amount,starts,expires,actor) VALUES(?,?,?,?,?)').bind(id,amount,now,now+seconds*1000,me.user_id),env.DB.prepare(`INSERT INTO animation_rooms645(box_id,host_id,session_id) SELECT ?,m.host_id,m.session_id FROM myshop_live_room_meta m JOIN myshop_live_presence p ON p.user_id=m.host_id WHERE p.active=1 AND datetime(p.last_seen)>datetime('now','-90 seconds') AND COALESCE(m.session_id,'')<>''`).bind(id),env.DB.prepare('INSERT INTO animation_audit645(actor,action,data) VALUES(?,?,?)').bind(me.user_id,'box',JSON.stringify({id,amount,seconds}))]);}catch(e){return reply({error:'BOX_PUBLICATION_CONFLICT'},409);}return reply({ok:true,id});
 }
 if(b.action==='stopBox'){await env.DB.batch([env.DB.prepare('UPDATE animation_boxes645 SET enabled=0 WHERE id=?').bind(String(b.id)),env.DB.prepare('INSERT INTO animation_audit645(actor,action,data) VALUES(?,?,?)').bind(me.user_id,'stopBox',String(b.id))]);return reply({ok:true});}
 return reply({error:'INVALID_ACTION'},400);
 }
 if(path==='/v1/animation645/claim'&&request.method==='POST'){
 const b=await request.json().catch(()=>({}));const box=await env.DB.prepare('SELECT amount FROM animation_boxes645 WHERE id=?').bind(String(b.boxId||'')).first();if(!box)return reply({error:'BOX_CLOSED'},409);
 try{await env.DB.prepare('INSERT INTO animation_claims645(box_id,host_id,user_id,amount) VALUES(?,?,?,?)').bind(String(b.boxId),String(b.hostId),me.user_id,box.amount).run();return reply({ok:true,amount:box.amount});}catch(e){return reply({error:'ALREADY_CLAIMED_OR_NOT_ELIGIBLE'},409);}
 }
 if(request.method!=='GET')return reply({error:'METHOD_NOT_ALLOWED'},405);
 const page=u.searchParams.get('page')||'',host=u.searchParams.get('hostId')||'',session=u.searchParams.get('sessionId')||'';if(!pages.includes(page))return reply({error:'INVALID_PAGE'},400);
 const snapshot=await publicSnapshot645(env),now=Date.now(),config=snapshot.config,cards=(config.cards||[]).filter(c=>c.enabled&&c.pages.includes(page)&&(!c.starts||c.starts<=now)&&(!c.expires||c.expires>now));
 for(const c of cards){if(c.catalogId){c.item=snapshot.items.find(item=>item.id===c.catalogId);if(!c.item)c.enabled=false;}}
 let gifts=[],boxes=[];if(page==='live_room'){
 const active=await env.DB.prepare(`SELECT m.host_id FROM myshop_live_room_meta m JOIN myshop_live_presence p ON p.user_id=m.host_id WHERE m.host_id=? AND m.session_id=? AND p.active=1 AND datetime(p.last_seen)>datetime('now','-90 seconds') AND (m.host_id=? OR EXISTS(SELECT 1 FROM myshop_live_visits v WHERE v.host_id=m.host_id AND v.user_id=? AND v.session_id=m.session_id AND EXISTS(SELECT 1 FROM myshop_live_viewers w WHERE w.host_id=v.host_id AND w.user_id=v.user_id AND datetime(w.last_seen)>datetime('now','-90 seconds'))))`).bind(host,session,me.user_id,me.user_id).first();
 if(active){
 const since=Math.max(now-30000,Math.min(now,Number(u.searchParams.get('since'))||now));
 if(config.gifts?.enabled&&(config.cards||[]).find(c=>c.type==='GLOBAL_GIFT')?.enabled!==false)gifts=snapshot.gifts.filter(g=>g.host_id!==host&&g.created_ms>=since&&g.expires_ms>now).sort((a,b)=>a.id-b.id).slice(0,30);
 if((config.cards||[]).find(c=>c.type==='GIFT_BOX')?.enabled!==false)boxes=(await env.DB.prepare(`SELECT b.id,b.amount,b.expires FROM animation_boxes645 b JOIN animation_rooms645 r ON r.box_id=b.id WHERE r.host_id=? AND r.session_id=? AND b.enabled=1 AND b.starts<=? AND b.expires>? AND NOT EXISTS(SELECT 1 FROM animation_claims645 c WHERE c.box_id=b.id AND (c.host_id=? OR c.user_id=?)) ORDER BY b.starts LIMIT 1`).bind(host,session,now,now,host,me.user_id).all()).results||[];
 }
 }
 return reply({ok:true,serverTime:now,cursorTime:snapshot.cursorTime,revision:snapshot.revision,cards:cards.filter(c=>c.enabled),gifts,boxes,giftEnabled:config.gifts?.enabled===true&&(config.cards||[]).find(c=>c.type==='GLOBAL_GIFT')?.enabled!==false,maxPerMinute:config.maxPerMinute||10});
}
