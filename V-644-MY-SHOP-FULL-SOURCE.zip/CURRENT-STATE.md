Current V644. Next delivery V645. Read MY-SHOP-DEVELOPER-HANDOFF.md.
