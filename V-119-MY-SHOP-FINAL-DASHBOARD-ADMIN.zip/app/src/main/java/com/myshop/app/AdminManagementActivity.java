package com.myshop.app;

import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;

/** Server-authorized admin content console. Additive content changes only; user IDs/data are never reset. */
public class AdminManagementActivity extends AppCompatActivity {
    private EditText news, shopUrl, tvUrl, movieUrl, chatUrl, modId;
    private EditText[] heroUrls = new EditText[6], promoUrls = new EditText[3];
    private EditText[] socialPlatforms = new EditText[6], socialUrls = new EditText[6];
    private EditText[] galleryTitles = new EditText[3], galleryUrls = new EditText[3];
    private EditText[] featureTitles = new EditText[8], featureUrls = new EditText[8], featureIcons = new EditText[8];
    private CheckBox[] featureActive = new CheckBox[8];
    private final String[] featureKeys={"my_feed","live_now","go_live","live_tv","my_shop","external_movie","gallery","social_media"};
    private final String[] featureNames={"MY FEED","LIVE","GO LIVE","LIVE TV","MY SHOP","EXTERNAL MOVIE","GALLERY","SOCIAL MEDIA"};
    private LinearLayout root;
    private final int purple=Color.rgb(83,32,180), dark=Color.rgb(20,28,60), bg=Color.rgb(247,248,252);

    @Override protected void onCreate(Bundle savedInstanceState){super.onCreate(savedInstanceState);if(!SessionManager.isAdmin(this)){finish();return;}buildUi();loadCurrentConfig();}

    private void buildUi(){
        ScrollView scroll=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(18,18,18,42);root.setBackgroundColor(bg);
        TextView title=text("MY SHOP • ADMIN CONTROL",25,dark,true);title.setGravity(Gravity.CENTER);root.addView(title,lp(-1,58));
        TextView sub=text("Admin ID: "+SessionManager.getUserId(this)+"  •  Server authorized",13,Color.DKGRAY,false);sub.setGravity(Gravity.CENTER);root.addView(sub,lp(-1,32));

        root.addView(section("① Dashboard / Headline"));
        news=field("Breaking News headline");shopUrl=field("MY SHOP URL");tvUrl=field("LIVE TV URL");movieUrl=field("External Movie URL");chatUrl=field("Chat URL");

        root.addView(section("② Main Hero Banners • 6 slots"));
        for(int i=0;i<6;i++) heroUrls[i]=field("Hero Banner "+(i+1)+" image URL (https://...)");
        root.addView(section("Promo Banners • 3 slots"));
        for(int i=0;i<3;i++) promoUrls[i]=field("Promo Banner "+(i+1)+" image URL (https://...)");
        TextView bnNote=text("Remote banner changes do not require an APK rebuild after the Worker is deployed.",12,Color.DKGRAY,false);bnNote.setPadding(0,4,0,8);root.addView(bnNote);

        root.addView(section("③ Final Dashboard Features • rename / link / show-hide / icon"));
        for(int i=0;i<8;i++) addFeatureEditor(i);
        TextView fNote=text("Feature cards are controlled remotely. Leave Icon URL blank to keep the built-in high-quality icon. Hide/Show only changes dashboard visibility; it does not delete the feature record.",12,Color.DKGRAY,false);fNote.setPadding(0,4,0,8);root.addView(fNote);

        root.addView(section("④ Social Links • edit / disable"));
        for(int i=0;i<6;i++){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);socialPlatforms[i]=field("Platform "+(i+1));socialUrls[i]=field("URL");r.addView(socialPlatforms[i],weight(.35f));r.addView(socialUrls[i],weight(.65f));root.addView(r);}

        root.addView(section("⑤ Gallery • photo / video / audio links"));
        for(int i=0;i<3;i++){galleryTitles[i]=field("Gallery item "+(i+1)+" title");galleryUrls[i]=field("Media URL (https://...)");}
        TextView gNote=text("Gallery entries are stored as remote media links. Saving dashboard content does not reset existing users or permanent IDs.",12,Color.DKGRAY,false);gNote.setPadding(0,4,0,8);root.addView(gNote);

        Button save=button("SAVE ALL DASHBOARD CONTENT");save.setOnClickListener(v->saveAll());root.addView(save,lp(-1,58));

        root.addView(section("⑥ Moderators • maximum 5"));modId=field("4-digit User ID");LinearLayout mr=new LinearLayout(this);mr.setOrientation(LinearLayout.HORIZONTAL);Button add=button("ADD MODERATOR"),remove=button("REMOVE MODERATOR");add.setOnClickListener(v->moderator("add_moderator"));remove.setOnClickListener(v->moderator("remove_moderator"));mr.addView(add,weight(1));mr.addView(remove,weight(1));root.addView(mr);
        TextView note=text("Admin-only controls stay hidden from normal users. Permanent User IDs and existing database records are never reset here.",12,Color.DKGRAY,false);note.setPadding(0,18,0,12);root.addView(note);
        Button back=button("BACK");back.setOnClickListener(v->finish());root.addView(back,lp(-1,52));scroll.addView(root);setContentView(scroll);
    }

    private void addFeatureEditor(int i){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(0,4,0,6);
        TextView name=text(featureNames[i]+"  •  "+featureKeys[i],13,dark,true);box.addView(name,lp(-1,28));
        featureTitles[i]=makeField("Display title"); featureUrls[i]=makeField("Target URL (optional)"); featureIcons[i]=makeField("Icon URL (optional)"); box.addView(featureTitles[i],lp(-1,52)); box.addView(featureUrls[i],lp(-1,52)); box.addView(featureIcons[i],lp(-1,52));
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);featureActive[i]=new CheckBox(this);featureActive[i].setText("Show on dashboard");featureActive[i].setChecked(true);row.addView(featureActive[i],weight(1));box.addView(row,lp(-1,48));
        root.addView(box);
    }

    private void loadCurrentConfig(){BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{try{
        JSONObject c=d.optJSONObject("config");if(c!=null){news.setText(c.optString("breaking_news",""));shopUrl.setText(c.optString("my_shop_url",""));tvUrl.setText(c.optString("live_tv_url",""));movieUrl.setText(c.optString("external_movie_url",""));chatUrl.setText(c.optString("chat_url",""));}
        JSONArray bs=d.optJSONArray("banners");if(bs!=null)for(int i=0;i<bs.length();i++){JSONObject x=bs.optJSONObject(i);if(x!=null){int slot=x.optInt("slot",0);if("hero".equalsIgnoreCase(x.optString("folder",""))&&slot>=1&&slot<=6)heroUrls[slot-1].setText(x.optString("image_url",""));if("promo".equalsIgnoreCase(x.optString("folder",""))&&slot>=1&&slot<=3)promoUrls[slot-1].setText(x.optString("image_url",""));}}
        JSONArray ss=d.optJSONArray("socialLinks");if(ss!=null)for(int i=0;i<Math.min(6,ss.length());i++){JSONObject x=ss.optJSONObject(i);if(x!=null){socialPlatforms[i].setText(x.optString("platform",""));socialUrls[i].setText(x.optString("url",""));}}
        JSONArray gg=d.optJSONArray("gallery");if(gg!=null)for(int i=0;i<Math.min(3,gg.length());i++){JSONObject x=gg.optJSONObject(i);if(x!=null){galleryTitles[i].setText(x.optString("title",""));galleryUrls[i].setText(x.optString("media_url",""));}}
        JSONArray ff=d.optJSONArray("featureButtons");if(ff!=null)for(int i=0;i<ff.length();i++){JSONObject x=ff.optJSONObject(i);if(x==null)continue;String key=x.optString("key","");for(int j=0;j<featureKeys.length;j++)if(featureKeys[j].equals(key)){featureTitles[j].setText(x.optString("title",featureNames[j]));featureUrls[j].setText(x.optString("target_url",""));featureIcons[j].setText(x.optString("icon_url",""));featureActive[j].setChecked(x.optInt("active",1)==1);}}
    }catch(Exception e){toast("Config read error");}});}public void onError(String m){runOnUiThread(()->toast("Config load: "+m));}});}

    private void saveAll(){
        try{
            BackendClient.adminDashboardPut(SessionManager.getToken(this),news.getText().toString().trim(),shopUrl.getText().toString().trim(),tvUrl.getText().toString().trim(),movieUrl.getText().toString().trim(),chatUrl.getText().toString().trim(),new BackendClient.Callback(){public void onSuccess(JSONObject d){saveRemoteContent();}public void onError(String m){toast("Dashboard save failed: "+m);}});
        }catch(Exception e){toast("Invalid dashboard content");}
    }

    private void saveRemoteContent(){try{
        JSONObject p=new JSONObject();
        JSONArray bs=new JSONArray();for(int i=0;i<6;i++)bs.put(new JSONObject().put("folder","hero").put("slot",i+1).put("imageUrl",heroUrls[i].getText().toString().trim()).put("caption","Hero "+(i+1)).put("active",!heroUrls[i].getText().toString().trim().isEmpty()));for(int i=0;i<3;i++)bs.put(new JSONObject().put("folder","promo").put("slot",i+1).put("imageUrl",promoUrls[i].getText().toString().trim()).put("caption","Promo "+(i+1)).put("active",!promoUrls[i].getText().toString().trim().isEmpty()));p.put("banners",bs);
        JSONArray ss=new JSONArray();for(int i=0;i<6;i++){String platform=socialPlatforms[i].getText().toString().trim(),url=socialUrls[i].getText().toString().trim();if(!platform.isEmpty())ss.put(new JSONObject().put("platform",platform).put("url",url).put("active",!url.isEmpty()));}p.put("socialLinks",ss);
        JSONArray gg=new JSONArray();for(int i=0;i<3;i++){String title=galleryTitles[i].getText().toString().trim(),url=galleryUrls[i].getText().toString().trim();if(!url.isEmpty())gg.put(new JSONObject().put("title",title).put("mediaUrl",url).put("mediaType","image").put("active",true).put("displayOrder",i+1));}p.put("gallery",gg);
        JSONArray ff=new JSONArray();for(int i=0;i<8;i++){ff.put(new JSONObject().put("key",featureKeys[i]).put("title",featureTitles[i].getText().toString().trim()).put("iconUrl",featureIcons[i].getText().toString().trim()).put("targetUrl",featureUrls[i].getText().toString().trim()).put("active",featureActive[i].isChecked()).put("displayOrder",i+1));}p.put("featureButtons",ff);
        BackendClient.adminContentPut(SessionManager.getToken(this),p,new BackendClient.Callback(){public void onSuccess(JSONObject d){toast("All dashboard + feature controls saved.");}public void onError(String m){toast("Remote content save failed: "+m);}});
    }catch(Exception e){toast("Invalid remote content");}}

    private void moderator(String action){String id=modId.getText().toString().trim();if(!id.matches("\\d{4}")){toast("Enter a valid 4-digit User ID.");return;}BackendClient.adminAction(SessionManager.getToken(this),id,action,new BackendClient.Callback(){public void onSuccess(JSONObject d){toast(action.equals("add_moderator")?"Moderator added.":"Moderator removed.");}public void onError(String m){toast("Action failed: "+m);}});}
    private TextView section(String s){TextView t=text(s,18,purple,true);t.setPadding(0,16,0,7);return t;}
    private EditText makeField(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(14);e.setSingleLine(true);e.setPadding(14,0,14,0);return e;}
    private EditText field(String hint){EditText e=makeField(hint);root.addView(e,lp(-1,52));return e;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setAllCaps(false);return b;}
    private TextView text(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return t;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams weight(float w){return new LinearLayout.LayoutParams(0,52,w);}private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
}
