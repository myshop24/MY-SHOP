# MY SHOP Developer Handoff — V-303

## Current version
V-303 (versionCode 303 / versionName 2.9.303)

## Completed in V-303
- Live duration timer now updates as HH:MM:SS.
- Live comments are separate premium cards/bubbles with larger text and inline `Name LV.x : comment` layout.
- Gift panel gives immediate tap feedback and caches the catalog for faster subsequent opens.
- Muted microphone state shows a red crossed-mic marker on the local mic control and occupied seat avatars.
- Host receives a compact inline Join Request card with Accept/Decline; full request list remains available.
- Join-request lookup was hardened for current/legacy live session-id rows.
- Speaking state drives animated avatar-ring emphasis for Host/Speaker seats.
- Live room refresh cadence tightened to 1.2s for request/state responsiveness.

## Preserved / do not regress
- 12-seat Audio Live layout and role model.
- Existing Live request/invite APIs and user identity records.
- Gifts/themes, Dashboard navigation, D1/R2 bindings, applicationId, master workflow, and permanent signing configuration.

## Validation state
- SOURCE_BUILD_ID = `MY SHOP V-303`.
- SOURCE_VERSION_NAME = `2.9.303`.
- Android = versionCode `303`, versionName `2.9.303`.
- Worker health/build markers = `2.9.303` / `V-303`.
- Worker JavaScript syntax check passed.
- ZIP integrity verification passed.
- Full Android APK compile is not available in this local environment; GitHub Actions remains the definitive compile verification.

## V-301 GitHub identity correction
- `SOURCE_BUILD_ID.txt` is exactly `MY SHOP V-301`.
- `SOURCE_VERSION_NAME.txt` remains `2.9.301`.
- Android remains `versionCode 301` / `versionName 2.9.301`.
- Worker health/build markers synchronized to `2.9.301` / `V-301`.
- Existing master GitHub Actions workflow and signing controls were preserved unchanged.

## V-301 Compile Fix — Bottom Navigation Scope
- Fixed GitHub Java compilation failure in `MainActivity.java` where the scroll listener referenced `bottomNav` before the local variable was declared.
- The same `bottomNav` View is now initialized before `setOnScrollChangeListener`, then added to the root with the existing layout params.
- Preserved V-301 bottom-nav hide/show behavior, safe-area positioning, full-width intent, workflow, signing, D1/R2 configuration, and release identity.
- Release identity remains `MY SHOP V-301` / `2.9.301`.
- Worker JavaScript syntax check passed; source-level bottomNav scope guard passed.
- Local APK compilation was not available in this environment because Gradle/wrapper runtime is absent; GitHub Actions remains the definitive compile verification.


## V-302 Version Promotion
- V-302 is the corrected compile-fix successor to V-301.
- `SOURCE_BUILD_ID.txt` = `MY SHOP V-302`.
- `SOURCE_VERSION_NAME.txt` = `2.9.302`.
- Android = `versionCode 302` / `versionName 2.9.302`.
- Worker health/build markers = `2.9.302` / `V-302`.
- Bottom navigation compile-scope fix from the prior corrected package is preserved.
- Master GitHub Actions workflow, permanent signing configuration, Cloudflare D1/R2 bindings, and existing working features were not intentionally changed.


## V-303 checkpoint
- Fixed Live timer, comments UI, Gift first-open responsiveness, mic mute markers, compact Host join-request card, request session compatibility, and active-speaker visual state.
- Added microphone permission only for voice-activity detection used by speaker-ring state.
- Preserved 12-seat architecture and existing backend/signing/workflow contracts.
- Next verification: GitHub release compile and two-device Host/Audience live interaction test.
