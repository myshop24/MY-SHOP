# V-324 Google Play Compliance QA

- PASS — versionCode 324 / versionName 2.9.324 prepared for update sequencing.
- PASS — no new sensitive Android permission added by this scope.
- PASS — no external payment flow added for digital Coin/Gold Coin packages.
- PASS — money-priced digital catalog items still require a Google Play Product ID server-side.
- PASS — purchased vs earned/withdrawable balance rules were not weakened.
- PASS — account identity/deletion/privacy behavior unchanged.
- PASS — UGC/live moderation controls were not removed.
- PASS — Live comments remain ephemeral; no new D1/R2 comment persistence.
- PASS — existing Cloudflare D1/R2 bindings/schema ownership preserved; only additive gift-duration columns are migrated.
- NEEDS CONSOLE SETUP — verify Play Console products match any money-priced Coin/Gold Coin packages before release.
- NEEDS CI — final signed APK/AAB compile and manifest/SDK checks in the existing Android GitHub Actions environment.
- NEEDS DEVICE QA — microphone/RTC, multi-user Live room, gift audio, and animation timing on real Android devices.
