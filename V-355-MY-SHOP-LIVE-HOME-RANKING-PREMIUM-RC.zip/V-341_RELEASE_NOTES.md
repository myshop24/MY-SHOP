# MY SHOP V-341 — Agora RTC Audio Live

- Added Agora Android RTC SDK 4.6.4 for Audio Live transport.
- Added authenticated `/v1/live/rtc/token` endpoint using Agora AccessToken2 (`agora-token` 2.0.3).
- App Certificate is server-only: `AGORA_APP_CERTIFICATE`; it is never embedded in APK/source.
- MY SHOP backend remains authority for Host / Speaker / Audience roles and 12-seat state.
- Host/Speaker publish microphone audio; Audience subscribes only.
- Speaker Leave Call switches RTC back to audience without leaving the Live room.
- Token renewal is wired to Agora expiry callbacks.
- Existing AudioRecord VAD is disabled while Agora owns microphone capture; Agora volume indication drives speaking state.
- Host End Live leaves RTC immediately; normal Back still backgrounds the task rather than ending Live.
- Agora Cloud Recording is not integrated. Live audio is not saved to D1/R2.
- Worker config includes public AGORA_APP_ID. Certificate must remain a Cloudflare/GitHub Actions secret.
