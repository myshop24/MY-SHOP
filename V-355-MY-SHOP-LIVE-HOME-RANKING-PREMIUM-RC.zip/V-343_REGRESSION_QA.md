# V-343 Regression QA

PASS (source/static): version identity 343; Android versionCode/versionName; RECORD_AUDIO + MODIFY_AUDIO_SETTINGS retained; 12-seat/Host-separate source untouched; ephemeral live comments untouched; no Cloud Recording integration; Agora certificate not embedded in app/source.

REQUIRES GITHUB RUN: active repository workflow must deploy the Worker source; APK compile/sign; Worker deployment; live content write suite.

REQUIRES TWO-PHONE TEST: host microphone publish, audience playback, speaker promotion, mute/unmute, leave/end-live.
