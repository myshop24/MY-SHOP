# V-350 System Push Runtime Requirements

V-350 preserves the V-349 Android FCM client/service/channel implementation.

Real device push still requires secrets/config that must NOT be stored in this ZIP:
- Firebase Android project/app values supplied to the GitHub build as expected by the existing workflow.
- Worker secret `FCM_SERVICE_ACCOUNT_JSON` containing the Firebase service-account JSON.
- Android 13+ notification permission granted by the user.

If these runtime values are missing, in-app notifications can still work while Android notification-shade push will not.
