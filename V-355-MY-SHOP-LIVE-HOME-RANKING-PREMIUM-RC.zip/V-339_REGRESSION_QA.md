# V-339 Regression QA
PASS (static): version identity; Worker JS syntax; border 0 path; Selected User controls; preset edit/assign source path; pin permission backend gate; unpin empty pinned message path; top stats no individual background cards; Host typography/photo enlarged; 12-seat render logic not intentionally changed.
NEEDS GITHUB CI: Android compile/release APK.
NEEDS WORKER DEPLOY: new pin/unpin authorization behavior.
NEEDS DEVICE TEST: visual sizing, border 0–6, user assignment/edit, multi-role pin/unpin, real-time propagation.
