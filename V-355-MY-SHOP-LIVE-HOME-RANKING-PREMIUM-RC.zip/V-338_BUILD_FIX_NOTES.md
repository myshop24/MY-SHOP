# MY SHOP V-338 Build Fix

Scope: build-blocker-only fix from V-337.

- Fixed `AudioLiveRoomActivity.java` compilation error by importing `android.widget.HorizontalScrollView`.
- No Live Room seat count/layout/logic redesign.
- No Home Dashboard redesign.
- V-337 feature scope otherwise preserved.
- versionCode: 338
- versionName: 2.9.338
- SOURCE_BUILD_ID: MY SHOP V-338

Verification status:
- Static source check: PASS (HorizontalScrollView import + usages resolve at source level)
- Full Android/GitHub build: NEEDS GITHUB CI
- Runtime/device QA: NEEDS DEVICE TEST
