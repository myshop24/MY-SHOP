# V-328 Google Play Compliance QA

- Existing package/signing/update path: PRESERVED IN SOURCE.
- Existing POST_NOTIFICATIONS permission: PRESERVED; no new sensitive permission added.
- RECORD_AUDIO Live permission behavior: PRESERVED.
- Digital goods/payment architecture: NOT CHANGED by V-328.
- UGC moderation/report/block architecture: NOT CHANGED by V-328.
- Account/privacy/deletion/Data Safety implementation: NOT CHANGED by V-328.
- D1/R2/FCM secrets: no secrets embedded by V-328.
- Full manifest/target SDK/build verification: NEEDS CI/Play release pipeline.
- Real notification permission behavior Android 13+: NEEDS DEVICE.

Status: SOURCE-SCOPE PASS / CI + DEVICE VERIFICATION REQUIRED.
