# V-335 Regression QA

PASS (source/static):
- Home Dashboard files not redesigned by this change.
- Live Host/12-seat layout code not intentionally modified.
- Existing Coin/Gold transaction modules untouched.
- Manifest still has one LiveCommentAdminActivity registration.
- Worker JS parses successfully.
- Previous 10-slot Live Comment Admin UI removed from active source.

NEEDS GITHUB CI TEST:
- `:app:assembleRelease` compile and package.

NEEDS WORKER DEPLOY + DEVICE TEST:
- Global style save/publish and persistence.
- Ready-made badge preset save/edit.
- User ID search returns correct name/ID/level.
- Assign preset to searched user.
- Assign custom style to searched user.
- Runtime priority Custom > Preset > Global.
- Border Glow/Background Glow appearance.
- Animation ON/OFF/type/speed on real device.
- Preview/test must not publish until Save/Publish is tapped.
- Reopen Admin screen restores saved settings.
