# MY SHOP V-347 — Final Live Seat Asset / Profile / Build Fix

## Completed source changes
- Re-encoded the approved MY SHOP MS Live empty-seat artwork as a real RGBA PNG. The V-346 file had a `.png` filename but JPEG/JFIF bytes, which caused `:app:mergeReleaseResources` / AAPT compilation failure.
- Empty Guest seats now use the approved MY SHOP MS artwork inside the circular seat treatment; the old chair-style visual is no longer used.
- Empty Guest seats show their seat number beneath the circular image while preserving existing seat allocation/count/behavior.
- Host rendering now has a safe local fallback to the signed-in Host's real profile avatar/name/ID if the first room-state skeleton arrives before seat-1 profile data.
- Occupied Guest seats continue to render the guest's real `avatar_url` profile photo.
- Preserved the V-346 Back-to-PiP/mini flow, full-screen low-light Live background, Exit control, Join/Leave state, role-based pin UI, prominent Gift comment rows, larger/longer Gift effects and speech-first Agora tuning.
- Release identity synchronized to V-347 / 2.9.347; Worker health/build markers synchronized to V-347.

## Regression lock
No schema, D1/R2 binding, Coin/Gold Coin accounting, Gift catalog/pricing, Join Request, Host Invite, seat allocation logic, Live comment storage behavior, Admin controls or unrelated Java module was changed in this V-347 source pass.
