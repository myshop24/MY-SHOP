# MY SHOP Developer Handoff — V-353

## Scope
Audio recovery only. Preserve all V-352 D1/realtime/comment/stability work.

## Completed
- Fixed V-352 Agora idempotency regression that could skip the first post-join publish/mic application.
- Always restore remote-audio subscription and speaker route even when role state is unchanged.
- Gift sound now uses normal MEDIA/MUSIC audio attributes instead of SONIFICATION/transient focus.
- Gift playback no longer requests transient audio focus that could duck/interfere with live RTC voice.
- Volume keys in Live Room target STREAM_MUSIC.

## Locked / unchanged
- D1 polling reduction/realtime hub
- Live comments
- Gift catalog/economy/transactions
- 12-seat layout and Live UI
- Admin controls and backend contracts

## Runtime QA required
1. Host -> audience voice audible.
2. Speaker -> host voice audible.
3. Built-in gift sound audible.
4. Remote/admin-uploaded gift sound audible.
5. Gift sound does not mute live voice permanently.
6. D1 rows-read optimization remains intact.
