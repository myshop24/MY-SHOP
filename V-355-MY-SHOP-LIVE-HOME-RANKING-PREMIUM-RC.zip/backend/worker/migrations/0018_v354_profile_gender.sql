-- V-354 optional profile gender for user-selected Live comment styling.
ALTER TABLE myshop_auth_users_v108 ADD COLUMN gender TEXT NOT NULL DEFAULT 'UNSPECIFIED';
