-- V-355: adopt the approved dark navy / blue / purple / pink default palette.
-- Only legacy default values are migrated; Admin-customized colors remain untouched.
UPDATE dashboard_config
SET dashboard_bg_color = CASE WHEN upper(dashboard_bg_color) = '#F8F9FD' THEN '#07122F' ELSE dashboard_bg_color END,
    dashboard_blue_color = CASE WHEN upper(dashboard_blue_color) = '#2E2FBE' THEN '#2D72F6' ELSE dashboard_blue_color END,
    dashboard_purple_color = CASE WHEN upper(dashboard_purple_color) = '#5B26D6' THEN '#7B3FF2' ELSE dashboard_purple_color END,
    dashboard_pink_color = CASE WHEN upper(dashboard_pink_color) = '#EB24A8' THEN '#F02BB7' ELSE dashboard_pink_color END,
    updated_at = CURRENT_TIMESTAMP
WHERE id = 1;
