-- MY SHOP V-352: additive indexes only. No existing table/data is dropped or rewritten.
CREATE INDEX IF NOT EXISTS idx_live_viewers_host_seen ON myshop_live_viewers(host_id,last_seen,user_id);
CREATE INDEX IF NOT EXISTS idx_live_requests_host_session_status ON myshop_live_requests(host_id,session_id,status,created_at);
CREATE INDEX IF NOT EXISTS idx_live_gift_events_fast ON myshop_live_gift_events(host_id,session_id,status,id,created_at);
CREATE INDEX IF NOT EXISTS idx_live_entry_events_host_time ON myshop_live_entry_events(host_id,created_at,id);
CREATE INDEX IF NOT EXISTS idx_live_history_host_id ON myshop_live_history(host_id,id DESC);
CREATE INDEX IF NOT EXISTS idx_live_room_admins_fast ON myshop_live_room_admins(host_id,user_id,active);
CREATE INDEX IF NOT EXISTS idx_live_fan_club_fast ON myshop_live_fan_club(host_id,user_id,active,points);
