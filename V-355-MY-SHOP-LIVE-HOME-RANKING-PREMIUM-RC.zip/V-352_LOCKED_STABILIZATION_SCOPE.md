# V-352 Locked Stabilization Scope

Base: V-351. Fix only D1 Live read pressure, cross-isolate Live comment delivery, and app-side Agora reconfiguration churn.

LOCKED / DO NOT REDESIGN:
- Approved V-350/V-351 Live Room appearance and the current 8 guest seats (seats 2–9).
- Host/Main Guest presentation, Exit control, comment styling/stack, Gift activity rows/effects/sound.
- Join Request / Host Invite business rules and seat allocation limits.
- Coin/Gold Coin balances, purchased/earned separation, fee/Star/Level rules, Gift ledger and Admin Gift catalog controls.
- End Live semantics, Profile, Feed/Dashboard, Notification/Chat, Admin, Store and navigation.
- D1/R2 existing tables/data contracts except the additive V-352 indexes.

Regression rule: if an unrelated protected file changes, treat it as a release blocker and restore it before delivery.
