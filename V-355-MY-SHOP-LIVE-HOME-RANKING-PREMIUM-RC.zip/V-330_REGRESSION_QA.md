# V-330 Regression QA

PASS (source-level)
- Version identity is 330 / 2.9.330.
- Gift Studio source retains COIN/GOLD tabs, GridLayout, direct sound picker, TrimWaveformView, drag/drop reorder, box selector, VAT, preview, add/edit/save/publish/delete controls.
- Admin navigation has distinct Gift Studio vs Purchase Package names.
- Finance endpoint retains existing today/allTime/categories/recent/config fields and only adds currencySummary.
- MainActivity unchanged from V-329.
- AdminWalletActivity unchanged from V-329.

NEEDS CI/DEVICE
- Android release compilation.
- Tap every Admin route.
- Load 50 COIN gifts and 50 GOLD gifts.
- Drag/drop persistence after app relaunch.
- Sound picker -> trim -> preview -> upload -> live playback.
- Animation duration/size/board position preview and live behavior.
- Per-gift/global VAT persistence.
- Finance COIN/GOLD numbers against real D1 ledger.
