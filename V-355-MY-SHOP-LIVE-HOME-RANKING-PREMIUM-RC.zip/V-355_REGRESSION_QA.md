# MY SHOP V-355 — Regression QA

Baseline: V-354-MY-SHOP-LIVE-INTERACTION-COMMENT-GENDER-AUDIO-FINAL

## Source diff
- Changed baseline files before V-355 docs: 12
- Added implementation files before V-355 docs: 2
- Deleted baseline files: 0
- Deleted file check: PASS

## Protected working modules
- `AgoraRtcManager.java`: PASS — unchanged
- `CatalogGiftAnimator.java`: PASS — unchanged
- Bundled WAV assets: PASS — all V-354 WAV hashes unchanged.
- Manifest permissions: PASS — no permission added/removed.
- Guest seats: PASS — source still uses seats 2–9; no seat-count redesign.

## Static gates
- Worker syntax: PASS.
- Manifest XML parse: PASS.
- Java delimiter/bracket scan on modified Java files: PASS.
- Android full compile: NOT AVAILABLE LOCALLY (Gradle wrapper/JAR + Android SDK absent).

## Runtime/device checklist before release
- [ ] Edit Profile Gender dropdown readable and saves all three options.
- [ ] Comment avatar/name/comment readable over bright, dark and photo wallpapers.
- [ ] Male/Female/neutral visual treatments display correctly; no Level in normal comment row.
- [ ] Host top user line starts immediately after host info; avatars/serials are large and horizontal swipe works.
- [ ] User-line ordering: Top #1–3 → membership tier → Coin → Level.
- [ ] Host profile opens Top 20 Gift Summary for both host and audience.
- [ ] Live Home has one Top Live row only; highest 4 appear first and additional rooms swipe horizontally.
- [ ] Join Live opens the full active-live list.
- [ ] Six Live Home banner slots upload/save/disable/delete and carousel smoothly.
- [ ] Bottom nav routes Home / Store / Video / My Feed / Profile correctly.
- [ ] Existing Voice and Gift Sound still work on real devices without regression.
- [ ] Existing Gift send / Coin / Gold balances and ledger remain correct.
