# MY SHOP V-350 — LOCKED STABILIZATION SCOPE

Base: V-349 Stabilization source. No redesign outside this list.

## Locked runtime / UI fixes
1. Live Room must continue to match `APPROVED-V350-LIVE-ROOM-FINAL-REFERENCE.png`.
2. Main Guest remains the locked MY SHOP LIVE crown/logo area; occupied state uses real guest profile photo.
3. Guest seats remain exactly 8 seats, numbered 2–9 in 4+4 layout.
4. Empty guest seats use the approved soft translucent grey circular seat + centered white chair treatment from `APPROVED-V350-SEAT-REFERENCE.png`; occupied seats use profile photos.
5. Exit remains a borderless red X.
6. Gift sound must be audible when Admin sound is enabled: custom sound first; built-in mapped fallback if custom loading fails; Admin volume retained.
7. Short built-in/custom gift sounds are allowed to repeat briefly so the configured effect is actually noticeable, without changing Coin/Gold pricing or transaction logic.
8. Gift activity must show a prominent but compact comment entry containing sender, sender level, gift visual/name, quantity/value and receiver.
9. Live comments/events must arrive in chronological order (oldest to newest in the stream) and auto-scroll to the newest row.
10. Comment rows are compacted so more recent comments remain visible; they must not overlap or disappear after 3–4 entries.
11. Join/Live-not-ready feedback must use the in-room floating status banner instead of a large bottom Toast over the comments.
12. Persistent login/session from V-349 remains locked and must not regress.
13. Android system push plumbing from V-349 remains locked and must not regress; production runtime still requires Firebase build values + Worker FCM service-account secret.
14. Source/package size remains controlled; no old APK/AAB/build cache or duplicate runtime asset is added.
15. Audience `Join` button gets a smooth premium pulse/glow/scale animation only while it is actually a Join action. When promoted to speaker, it becomes `Leave` and the Join animation stops. Host `End` is unchanged.

## Regression locks
- Coin/Gold Coin balances, purchased-vs-earned separation, service fee, gifts, transactions and ledgers.
- Gift Admin catalog controls: sound ON/OFF, volume, animation size, order, Add/Edit/Delete/Save/Publish.
- Join Request -> Host accept -> speaker seat, and Host invite -> user accept.
- End Live first-tap flow, timer, PiP/back behavior, RTC, profile, feed, navigation, Admin Panel and backend contracts.
- No D1/R2 schema change is introduced for this stabilization pass.

## Acceptance rule
Green build alone is not Final. Install the CI-built APK and verify the locked references plus real gift sound, comment flow, session persistence and notification behavior on device.
