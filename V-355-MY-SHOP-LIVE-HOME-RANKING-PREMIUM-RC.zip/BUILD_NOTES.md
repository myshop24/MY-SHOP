# MY SHOP V-230 — REFERENCE DASHBOARD + ADMIN FOLDER BUILD NOTES

- Build target: Android release APK
- Package: `com.myshop.app`
- versionCode: `230`
- versionName: `2.9.230`
- Java build target in GitHub Actions: 17
- Gradle: 8.11.1
- Permanent signing key: existing cached key only; never regenerate for an update.
- Final user artifact: one APK only.

## User-approved UI lock
- Visual reference: `design-reference/V-230_USER_APPROVED_REFERENCE.png`.
- Default palette: Background `#F8F9FD`, Blue `#2E2FBE`, Purple `#5B26D6`, Pink `#EB24A8`.
- Profile avatar opens left drawer.
- MORE opens the shortcut grid; Store/Gallery/External/Earn remain inside MORE.
- Smooth ripple/transition behavior retained.

## Admin + banners
- `AdminFolderActivity` is Admin-only and requires `admin_context=true`.
- Each folder panel exposes separate ADD / EDIT / DELETE / SAVE actions.
- `DashboardAdsAdminActivity` manages independent 1–6 ad slots per `box_key`.
- User-facing module banner carousels auto-rotate up to 6 configured images and expose no Admin controls.

## Data safety
- `backend/worker/wrangler.toml` bindings must remain unchanged.
- Permanent User ID/session classes are protected and must remain unchanged.
- Dashboard color schema changes are additive only; no destructive D1 migration is introduced.

Build PASS and Function PASS are separate. Runtime verification is required after install.

## V-335
Live Comment style system rebuilt: Global default + ready-made badge presets + searched-user preset/custom assignment + preview-before-save + glow/animation controls. Worker deploy and CI/device QA required.


## V-336
- Finalized approved visual Live Comment Designer, 40 membership presets, animation controls, user assignment restore/change/remove, and global fallback.
- Static checks only locally; GitHub CI + Worker deploy + device test required.

## V-337
Final scoped source update: Live Comment ready-made/assignment simplification, long-comment cap, join-time realtime visibility, gift activity comment, and TOP-only Live Room information redesign. `renderSeats()` intentionally unchanged. Worker JS syntax checked locally. Full Android compile requires GitHub CI because wrapper binary/JAR is not included in source snapshot.

V-338: Fixed missing `android.widget.HorizontalScrollView` import that caused V-337 `compileReleaseJavaWithJavac` failure. No feature/layout redesign.

V-339: scoped Live Comment Designer + pin permission/unpin + Live top presentation fixes. Full Android compile unavailable locally because Gradle wrapper executable/JAR is absent. GitHub CI required.
