# V-349 System Push Runtime Requirements

Android source support is included, but real phone notifications require Firebase credentials at build/deploy time.

GitHub Actions build environment:
- MYSHOP_FIREBASE_API_KEY
- MYSHOP_FIREBASE_APP_ID
- MYSHOP_FIREBASE_PROJECT_ID
- MYSHOP_FIREBASE_SENDER_ID

Cloudflare Worker secret:
- FCM_SERVICE_ACCOUNT_JSON

After deploy/install, open Admin Panel -> System Health and verify:
- Push Client Config: OK
- Notification Permission: GRANTED
- push.fcmServerConfigured: true
- push.activePushTokens: at least 1 after a logged-in Android device has registered

Do not place any of these secrets inside the source ZIP or commit them to GitHub.
