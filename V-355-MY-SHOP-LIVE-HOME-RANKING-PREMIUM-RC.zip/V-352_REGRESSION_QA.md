# MY SHOP V-352 — Regression / Acceptance QA

## Source/static checks
- [x] versionCode = 352
- [x] versionName = 2.9.352
- [x] SOURCE_BUILD_ID = MY SHOP V-352
- [x] SOURCE_VERSION_NAME = 2.9.352
- [x] Worker identity = 2.9.352 / V-352
- [x] Worker JavaScript syntax check passes
- [x] wrangler.toml parses and contains LIVE_ROOM_HUB binding/migration
- [x] 0017 index migration parses against matching SQLite table shapes
- [x] Old `giftTick` high-frequency D1 gift polling removed from Live activity
- [x] Full room D1 poll is 12 s; compatibility fallback is 10 s
- [x] Agora publish/mic state reconfiguration is idempotent
- [x] Protected-file hash comparison performed; only intended V-352 files changed

## Required Cloud/runtime acceptance
- [ ] Deploy Worker V-352 successfully (Durable Object migration accepted)
- [ ] Apply D1 migration 0017 successfully
- [ ] Cloudflare D1 row reads remain controlled during a 20–30 minute Live test
- [ ] Two devices: User comment appears on Host board promptly and exactly once
- [ ] Two devices: Host comment/User comment chronological order remains correct
- [ ] Two devices: Host voice is heard continuously without new delay/jitter/regression
- [ ] Host Join Request receives promptly; Accept promotes user to speaker
- [ ] Host Invite reaches user; Accept promotes user to speaker
- [ ] Leave speaker seat returns to audience correctly
- [ ] Seats 2–9 layout/locking/appearance remains unchanged
- [ ] Gift animation and sound remain working
- [ ] Coin gift and Gold Coin gift balances/ledger remain correct
- [ ] Admin Gift controls remain present
- [ ] End Live ends on first action and clears temporary realtime room state
- [ ] Profile/Dashboard/Admin/Store/navigation regression smoke test passes
- [ ] Google Play release/compliance checks run before production release

## Compile status
A full Android Gradle compile is NOT marked PASS in this execution environment because the incoming project intentionally has no Gradle wrapper JAR/scripts and system Gradle is unavailable. GitHub CI/Gradle 8.11.1 remains the build acceptance gate. Java source was syntax-screened with javac; only expected missing Android/Agora classpath diagnostics occurred, with no Java parse diagnostics found.
