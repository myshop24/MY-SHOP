# MY SHOP V-340 — Live Presence, Messaging & Notification UX

- Preserves the approved top Live card gradient; removes its visible outline/border.
- Replaces top Gift statistic with real room Users count (host + server-confirmed active viewers).
- Keeps the existing Gift action/system intact.
- Host and live-user mini profiles expose Message; chat opens the existing 1:1 ChatActivity.
- Existing FCM message notifications retain expandable BigText preview and direct chat deep-link.
- Live-start notifications are narrowed to actual followers of the host with active registered push tokens.
- Android Back while inside an active Live backgrounds the task instead of ending/leaving the room.
- Existing speaker Leave Call flow remains: speaker seat is released and user stays audience.

## Important deployment note
Real push requires Firebase client config in CI/build and FCM_SERVICE_ACCOUNT_JSON on the Worker. Worker changes must be deployed for follower-only live alerts.
