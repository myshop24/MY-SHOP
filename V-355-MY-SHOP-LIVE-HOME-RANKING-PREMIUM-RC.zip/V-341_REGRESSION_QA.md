# V-341 Regression / Release QA

PASS (static/source):
- versionCode 341 / versionName 2.9.341 / SOURCE_BUILD_ID MY SHOP V-341.
- Agora SDK dependency present; RECORD_AUDIO permission preserved.
- Secure token endpoint derives role from backend seat state; client cannot choose Publisher role.
- App Certificate absent from source and APK config.
- Gift, Coin, Gold Coin, Star, comments, reactions, 12-seat backend logic preserved.
- Leave Call remains seat-only and keeps user in Live as Audience.
- Cloud Recording not added; no live-audio persistence path added.
- Worker JavaScript passes `node --check`.

NEEDS CI / REAL DEVICE:
- Android compile could not be run in this workspace because this source archive has no Gradle wrapper script/JAR and no system Gradle.
- Two-device real RTC audio test (Host + Audience), Speaker promotion, mute/unmute, Leave Call, token renewal and network reconnect must pass before Play release.
- GitHub Actions must have `AGORA_APP_CERTIFICATE` secret before V-341 upload/deploy; workflow now fails closed if missing and carries it into the same Worker version.
