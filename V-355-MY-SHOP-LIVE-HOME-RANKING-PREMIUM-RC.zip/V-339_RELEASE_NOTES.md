# MY SHOP V-339 Release Notes

Scoped fixes only; approved Home Dashboard and Host + 12-seat (6+6) structure are unchanged.

- Live Comment Designer: Border Width now supports 0–6; 0 removes the border at runtime and preview.
- Added top All Users / Selected User mode shortcuts. Selected User uses ID search, profile preview, custom design, Save & Assign, edit/reload, and Remove/Default.
- Ready-made membership cards remain directly assignable by User ID and their Advanced editor can update the selected preset.
- Pin/Unpin permissions expanded to Host, Room Admin, MY SHOP Admin, and Moderator; ordinary users are backend-forbidden. Long-press pinned banner unpins.
- Live top stats: removed four individual Gift/Coin/Gold/Star boxes and increased text/icon size.
- Host profile photo, name, ID, and Level are larger.
- No seat numbering or seat-layout changes.
