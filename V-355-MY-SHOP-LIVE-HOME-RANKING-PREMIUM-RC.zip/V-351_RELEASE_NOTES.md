# MY SHOP V-351 — GitHub Highest-Version Source Identity Fix

Android: versionCode 351 / versionName 2.9.351
Worker: version 2.9.351 / build V-351
SOURCE_BUILD_ID: MY SHOP V-351

Purpose:
- Resolve GitHub workflow guard failure caused by more than one ZIP sharing the highest version V-350.
- Preserve all V-350 stabilization implementation and locked Live/Gift/Comment/Login/Notification/Join-button work.
- No intentional feature redesign in this version; this is a source identity / release packaging correction.

GitHub rule:
- Upload exactly ONE V-351 source ZIP.
- Older V-350 ZIPs may remain; the workflow should select the single highest V-351 source.
- Do not upload a second V-351 ZIP with another filename.

Runtime acceptance remains required after CI: install the built APK and verify the locked regression checklist.
