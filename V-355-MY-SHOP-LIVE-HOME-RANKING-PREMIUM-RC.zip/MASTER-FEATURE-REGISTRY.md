# MY SHOP MASTER FEATURE REGISTRY — V-329

## Release rule
A version is not complete merely because the target change works. It must also preserve every previously approved working module.

## Protected baseline for V-329
- Main Home Dashboard: LOCKED / no redesign in this version.
- Gift Coin & Gold Coin Catalog: LOCKED full admin editing system.
- Live room 12 guest seats + separate Host: LOCKED structure/logic.
- Cloudflare Worker / D1 / R2 contracts: DO NOT CHANGE unless specifically required.
- Coin/Gold Coin economy and accounting rules: DO NOT CHANGE.

## Required checks for every future version
1. Identify target feature and target files before editing.
2. Identify unaffected protected modules/files.
3. Apply smallest scoped change.
4. Diff protected files against previous stable source.
5. Confirm approved controls/options are still present.
6. Confirm API/backend contracts were not unintentionally changed.
7. Confirm Android versionCode/versionName/source build ID match the V-number.
8. Run CI and device tests where required; mark untested items NEEDS CI/DEVICE TEST.

## V-330 Production Admin Registry
- Coin & Gold Coin Catalog -> LiveGiftAdminActivity -> LOCKED FULL GIFT STUDIO.
- Coin / Gold Coin Purchase Packages -> CoinGoldCatalogActivity -> purchase/package management only.
- Give Coin / Gold Coin to User -> existing Admin Wallet flow -> LOCKED, preserve.
- Finance -> AdminFinanceActivity -> total accounting + separate COIN/GOLD summaries.
