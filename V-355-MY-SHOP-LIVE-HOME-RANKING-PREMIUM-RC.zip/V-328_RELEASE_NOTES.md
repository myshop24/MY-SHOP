# V-328 — MY SHOP PREMIUM EXPERIENCE + STABILITY FOUNDATION

## Completed source changes
1. Added reusable `PremiumUi` design/micro-interaction foundation.
2. Polished Live Streaming Hub cards/actions/navigation with compact premium depth and consistent press feedback.
3. Polished Audio Live Room surface and action controls while preserving seat/role logic.
4. Fixed sender-side Live comment acknowledgement flow: optimistic row remains visible until exact server echo is reconciled, avoiding remove-refresh-readd gaps.
5. Reused returned `/v1/live/comment` payload for immediate acknowledgement; no Worker API/schema change required.
6. Polished Chat input/send button and own-message bubble visual language.
7. Polished Inbox action chips and conversation cards.
8. Refined existing FCM message notification channel presentation; preserved existing Worker push contract.
9. Applied shared premium touch behavior to generic FeatureActivity cards/buttons.
10. Added permanent recovery/source-of-truth documents for future chat-loss recovery.

## Intentionally not changed
- Main Home Dashboard.
- Worker/backend source.
- D1/R2 schema/bindings.
- Gift economy/catalog behavior.
- 12-seat Live architecture.
- Wallet/transaction/membership/profile/feed logic outside the scoped visual component use.

## Pending verification
- GitHub CI full Android compile.
- Real-device UI/performance review.
- Real-device background/terminated FCM test with production secrets.
