#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
checks=[]
def ok(name, cond, detail=''):
    checks.append((name,bool(cond),detail))

def text(rel): return (ROOT/rel).read_text(errors='replace')

gradle=text('app/build.gradle')
live=text('app/src/main/java/com/myshop/app/AudioLiveRoomActivity.java')
session=text('app/src/main/java/com/myshop/app/SessionManager.java')
startup=text('app/src/main/java/com/myshop/app/StartupAdActivity.java')
login=text('app/src/main/java/com/myshop/app/LoginActivity.java')
main=text('app/src/main/java/com/myshop/app/MainActivity.java')
push=text('app/src/main/java/com/myshop/app/PushRegistration.java')
msg=text('app/src/main/java/com/myshop/app/MyShopMessagingService.java')
manifest=text('app/src/main/AndroidManifest.xml')
worker=text('backend/worker/src/index.js')
health=text('app/src/main/java/com/myshop/app/AdminSystemHealthActivity.java')

ok('versionCode 349','versionCode 349' in gradle)
ok('versionName 2.9.349','versionName "2.9.349"' in gradle)
ok('source build id',text('SOURCE_BUILD_ID.txt').strip()=='MY SHOP V-349')
ok('source version name',text('SOURCE_VERSION_NAME.txt').strip()=='2.9.349')
ok('worker V-349',"version:'2.9.349',build:'V-349'" in worker)

# Locked Live reference implementation
ok('8 seats / 4+4','int[] counts={4,4}' in live and 'n<=9' in live)
ok('Main Guest locked logo','R.drawable.live_main_guest_logo' in live and 'Main Guest' in live)
ok('empty chair icon','R.drawable.live_guest_chair' in live)
ok('old empty-seat logo asset removed',not (ROOT/'app/src/main/res/drawable/live_empty_seat_myshop.png').exists())
ok('red borderless exit','onlineCountView=t("✕",22f,Color.rgb(255,59,48),true)' in live and 'onlineCountView.setBackgroundColor(Color.TRANSPARENT)' in live)
ok('Main Guest crown','visible gold crown centered above Main Guest' in live and 'Path crown=new Path()' in live)

# Gift runtime fixes
ok('sender immediate gift row','JSONObject localGiftEvent=new JSONObject()' in live and 'renderGiftActivityComment(localGiftEvent)' in live)
ok('generic small gift event suppressed','"GIFT".equalsIgnoreCase(e.optString("event_type","")' in live)
ok('prominent gift row','🎁  sent ' in live and '15.3f' in live)
ok('gift sound built-in player','playBuiltInGiftSound' in live and 'LoudnessEnhancer' in live)
ok('gift custom URL watchdog','handler.postDelayed(watchdog,1400L)' in live and 'playFallback.run()' in live)
ok('gift event sender level','AS sender_level' in worker and 'senderLevel:Number' in worker)

# Persistent login
ok('keystore token encryption','AndroidKeyStore' in session and 'AES/GCM/NoPadding' in session and 'token_enc_v349' in session)
ok('stored session helper','hasUsableSession' in session)
ok('startup direct session resume','resumeSession ? MainActivity.class : LoginActivity.class' in startup)
ok('login direct resume','SessionManager.hasUsableSession(this)' in login and 'MainActivity.class' in login)
ok('main validates session','validateStoredSession()' in main and 'UNAUTHORIZED' in main and 'routeToLoginForExpiredSession' in main)

# Push notification plumbing
ok('notification permission','android.permission.POST_NOTIFICATIONS' in manifest)
ok('FCM service','MyShopMessagingService' in manifest and 'com.google.firebase.MESSAGING_EVENT' in manifest)
ok('Firebase build flag','PUSH_CLIENT_CONFIGURED' in gradle and 'BuildConfig.PUSH_CLIENT_CONFIGURED' in push)
ok('monochrome notification icon',(ROOT/'app/src/main/res/drawable/ic_myshop_notification.xml').exists() and 'R.drawable.ic_myshop_notification' in msg)
ok('high importance channels','NotificationManager.IMPORTANCE_HIGH' in msg)
ok('server push health diagnostics','fcmServerConfigured' in worker and 'activePushTokens' in worker and 'localPushHealth' in health)

# Size stabilization
ok('Agora audio-only dependency',"io.agora.rtc:voice-sdk:4.6.4" in gradle and 'io.agora.rtc:full-sdk' not in gradle)

# Final reference + PNG validation
ref=ROOT/'APPROVED-V349-LIVE-ROOM-FINAL-REFERENCE.png'
ok('V349 locked reference exists',ref.exists())
if ref.exists():
    try:
        with Image.open(ref) as im:
            ok('V349 reference is real PNG', im.format=='PNG', f'{im.size}')
    except Exception as e: ok('V349 reference is real PNG',False,str(e))

png_bad=[];png_count=0
for p in (ROOT/'app/src/main/res').rglob('*.png'):
    png_count+=1
    try:
        with Image.open(p) as im:
            if im.format!='PNG': png_bad.append(str(p.relative_to(ROOT)))
            im.verify()
    except Exception: png_bad.append(str(p.relative_to(ROOT)))
ok('all Android PNG resources valid',not png_bad,f'{png_count} PNG; bad={len(png_bad)}')

passed=sum(1 for _,v,_ in checks if v); failed=[x for x in checks if not x[1]]
print(f'V-349 STATIC STABILIZATION VALIDATION: {passed}/{len(checks)} PASS')
for name,value,detail in checks:
    print(('PASS' if value else 'FAIL')+' | '+name+((' | '+detail) if detail else ''))
if failed:
    print('\nFAILED:')
    for x in failed: print(x[0])
    sys.exit(1)
