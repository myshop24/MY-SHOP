# MY SHOP V-354 — Live User Interaction, Universal Comments & Audio Polish

## Implemented scope
1. Voice noise/feedback risk reduced by restoring neutral Agora recording/playback signal gain while preserving the proven V-353 join/publish recovery logic.
2. Replaced all 10 bundled built-in gift WAVs with newly synthesized, short, original/copyright-safe premium effects. Gift engine/admin controls remain intact.
3. Live Gift Store now has an explicit recipient selector using actual MY SHOP user_id; self-gifting is blocked in UI and seated guests can be targeted.
4. Occupied guest-seat avatar opens the actual MY SHOP user profile; host speaker actions also include Open Profile and Send Gift.
5. Top Live user line avatars enlarged from 28dp to 36dp; name/tap area enlarged.
6. Live comment rows open the commenter profile using user_id.
7. Universal comment glass layer: dark translucent high-contrast background remains readable over arbitrary Live themes; Level removed from normal comment display; format is Name : Comment.
8. Optional Edit Profile Gender: Male / Female / Prefer not to say. User-selected only. Male and Female receive distinct Live name treatments; unspecified uses neutral treatment.

## Locked / preserved
- Exactly 8 guest seats: 2–9.
- V-353 Agora join/publish recovery behavior.
- Gift transaction, Coin/Gold Coin accounting, gift animation engine and Admin gift controls.
- Ephemeral Live comments; no D1/R2 comment persistence introduced.
- D1/Durable Object optimization architecture.

## Backend additive change
- Adds `gender` to `myshop_auth_users_v108`, default `UNSPECIFIED`.
- Migration: `0018_v354_profile_gender.sql`.

## QA status
- Worker JavaScript syntax: PASS (`node --check`).
- Version/build metadata: PASS.
- Source/static regression diff: PASS.
- Full Android compile: NOT RUN locally because this source archive has no Gradle wrapper.
- Real-device Voice/Gift/Profile/Live runtime test: REQUIRED before Play release.
