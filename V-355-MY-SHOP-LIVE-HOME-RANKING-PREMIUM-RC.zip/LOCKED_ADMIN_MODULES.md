# MY SHOP — LOCKED ADMIN MODULES (V-329)

## Gift Coin & Gold Coin Catalog — PROTECTED / DO NOT REGRESS
The following approved capabilities must survive every future unrelated version unchanged unless the owner explicitly requests a change:
- Separate Gift Coin and Gold Coin catalog modes.
- Up to 50 gifts per catalog, all visible/manageable.
- Tap gift card to edit.
- Long-press + drag/reorder/position handling.
- Gift name, currency price, category, active/published state.
- Image/preview asset add/replace.
- Live animation asset add/replace.
- Catalog animation asset add/replace + preview/test.
- Sound add/replace from device file/gallery.
- Sound preview/test before save.
- Sound trim/crop start/end selection with waveform guide.
- Sound volume and sound duration controls.
- Gift effect duration and animation board coverage/scale.
- Board position: center/top/bottom/full-screen.
- Per-gift VAT and global VAT apply-all.
- Live-board preview.
- Save/Publish/Delete flows and historical transaction-safe soft delete.

## Regression rule
Unrelated work must not rewrite, simplify, delete, rename, or replace this module. Before release, compare protected files against the previous stable source and investigate any unexpected change.

## V-330 Coin & Gold Coin Catalog FINAL LOCK
- Admin-facing name: Coin & Gold Coin Catalog.
- This name/routes ONLY to LiveGiftAdminActivity full Gift Studio.
- Purchase packages are a separate module named Coin / Gold Coin Purchase Packages.
- Gift Studio required preserved controls: separate COIN/GOLD tabs, all gifts grid (up to 50), tap edit, long-press drag/drop reorder, add-new per selected currency, price, box/position, image/animation asset, direct device sound picker (no sound link entry), trim/test waveform selection, volume 0-100%, sound seconds, animation seconds, screen coverage 0-100%, board position, per-gift VAT, global VAT, preview, draft/publish/delete.
- Unrelated releases MUST NOT simplify/replace/remove this module.
