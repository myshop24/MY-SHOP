# MY SHOP V-345 — Live Room Speaker / Comment / Gift UX

## Target scope
- Active speaker identification: large high-intensity animated speaking glow driven by Agora audio-volume indication.
- Host avatar enlarged; guest board changed to 5 + 5 seats (10 guest seats) with larger profile photos.
- Live comments keep up to the active-session in-memory history for scrolling; dynamic-height rows prevent overlap and clipping.
- Gift success activity is rendered into the live comment stream with sender, level, gift thumbnail/name, quantity, receiver and currency value.
- Existing gift animation/sound and financial ledger behavior preserved.
- Live comments remain ephemeral and are cleared after the live session; no Cloud Recording added.

## Audio
- Existing working Agora audio path is preserved. This release does not claim a measured clarity improvement without device testing.
