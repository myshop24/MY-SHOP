# V-326 — Focused Gift Catalog UX Fix

This release changes only the Gift Coin / Gold Coin admin catalog workflow.

- Compact 4-column live-store-style gift grid.
- Tap card to edit.
- Long-press and drag to swap gift slots; backend order persists.
- Audio file is selected locally first instead of immediate upload.
- Local audio duration, trim Start/End and Preview/Test before Save.
- Upload occurs only during Save/Publish.
- Existing price, VAT, volume, sound duration, effect duration, board size/position and publish controls preserved.
- Live/Message mobile push notifications are not part of V-326.
