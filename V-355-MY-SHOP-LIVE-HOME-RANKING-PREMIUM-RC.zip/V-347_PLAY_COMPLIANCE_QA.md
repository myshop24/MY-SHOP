# MY SHOP V-347 — GOOGLE PLAY COMPLIANCE QA

- PASS — No new dangerous/sensitive permission was added in V-347.
- PASS — No external payment path was added for digital Coin/Gold Coin/Gifts.
- PASS — Purchased-vs-earned balance logic was not changed.
- PASS — Account/profile, UGC, moderation and existing privacy behavior were not changed.
- PASS — D1/R2 bindings and backend schema were not changed.
- NEEDS CI/CONSOLE CHECK — Confirm final signed APK/AAB target/compile SDK, signing continuity, Data Safety and current Play Console declarations before production upload.
