# MY SHOP V-352 — D1 + Live Realtime Comment + Audio Stability Fix

Android: versionCode 352 / versionName 2.9.352
Worker: version 2.9.352 / build V-352
Base: V-351

## Target fixes
1. Stop abnormal D1 row-read growth during Live.
2. Make user comments reach the Host reliably across Cloudflare Worker isolates.
3. Reduce app-side causes of Host audio delay/jitter without changing the Agora audio transport.
4. Preserve every unrelated working V-351/V-350 feature and approved Live UI.

## D1 usage changes
- Removed the old sub-second full Live-room D1 snapshot loop from the Android Live screen.
- Full room snapshot is now a 12-second safety/reconciliation poll.
- Host/viewer presence heartbeat is 12 seconds; speaker participant-state heartbeat is 8 seconds.
- High-frequency comments, highlights, gift-event delivery, and state-dirty signals use `LIVE_ROOM_HUB` Durable Object instead of repeatedly reading the full D1 Live state.
- Realtime compatibility fallback is throttled to 10 seconds so a Worker rollout mismatch cannot recreate a D1 read storm.
- Automatic gift-catalog background refresh is reduced to 60 seconds; opening the Gift Store still refreshes as needed.
- Added additive Live read indexes in migration `0017_v352_live_read_indexes.sql`.

Static cadence comparison for one active Live client:
- Full room D1 snapshot: ~1,846 calls/20 min at 650 ms -> ~100 calls/20 min at 12 s (about 18.5x fewer).
- Presence heartbeat: ~1,846/20 min -> ~100/20 min (about 18.5x fewer).
- Participant-state heartbeat: sub-second path -> ~150/20 min at 8 s.
- Gift event high-frequency delivery: moved off D1 polling to the realtime hub; D1 remains the authoritative financial ledger.

These are source-level call-count reductions, not a promise of a specific Cloudflare dashboard percentage. Production row-read usage must be verified after Worker + migration deployment.

## Host comment delivery
- Live comments/highlights remain temporary and are NOT written to D1 or R2.
- A per-host Durable Object supplies a single coherent active-room event stream across Worker isolates.
- Sender acknowledgement remains immediate; Host and other active participants receive the same comment event through `/v1/live/realtime`.
- Durable Object state is cleared at Live end and has a safety alarm cleanup.
- Cross-isolate comment nonce/message deduplication is included.

## Host audio stability
- Agora remains the only audio media transport; audio is not routed through D1/Worker.
- `AgoraRtcManager` now makes publish-role and microphone changes idempotent, preventing repeated room renders from re-applying the same Agora media configuration.
- The former sub-second D1/render loop no longer repeatedly drives Agora role/mic updates.
- Join/Invite/seat mutations emit realtime dirty signals so speaker role refresh can happen promptly without restoring the old D1 polling storm.

## Regression lock
No intentional redesign or business-logic change was made to the approved Live UI, seats 2–9, Gift catalog/admin controls, Coin/Gold Coin accounting, Gift financial ledger, Join Request/Host Invite rules, End Live, Profile, Dashboard, Admin, Store, notification system, or navigation.

## Deployment requirement
V-352 needs BOTH parts deployed together:
1. Worker deploy with `LIVE_ROOM_HUB` Durable Object migration.
2. D1 migration `0017_v352_live_read_indexes.sql`.
Then install/test the V-352 Android build. If the new app is installed before the V-352 Worker is deployed, the app has a throttled compatibility fallback, but the intended D1 savings and cross-isolate comment fix require the V-352 Worker.
