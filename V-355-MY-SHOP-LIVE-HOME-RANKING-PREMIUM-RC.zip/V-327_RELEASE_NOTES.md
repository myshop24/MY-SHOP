# V-327 — Premium Gift Coin / Gold Coin Admin Catalog

Focused, regression-safe update based on V-326.

## Updated
- Keeps Gift Coin and Gold Coin as separate catalogs.
- Full gift grid remains visible; tap any gift to open its full editor.
- Added simple Box / Position selector inside the editor; drag-and-drop reorder remains available.
- Position save is normalized through the existing reorder API so two gifts do not occupy the same logical slot.
- Added visible trim waveform-style selection guide tied to Start/End trim controls.
- Sound volume 0–100%, sound duration in seconds, effect duration in seconds and animation size/board coverage 0–100% remain separate.
- Added dedicated Live Board Preview for size/position/duration before publishing.
- Added clear Save Draft and Save / Publish actions.
- Added clear Delete Gift action inside the selected gift editor with existing confirmation/soft-delete behavior.
- Per-gift VAT and Global VAT remain available.
- Add New Gift continues to use the same full editor.

## Regression boundary
No schema migration and no unrelated Admin, Live, wallet, transaction, membership, profile or dashboard redesign in V-327. Existing backend gift APIs and live gift delivery path are preserved.
