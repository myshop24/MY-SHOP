# START HERE — MY SHOP V-324

Current source identity: `MY SHOP V-324` / `2.9.324`  
Android: `versionCode 324`, `versionName 2.9.324`  
Worker: `2.9.324 / V-324`

Scope: requested Live speaker controls/stability + gift presentation/duration controls + Coin/Gold Coin catalog regression repair.

Read first:
1. `MY-SHOP-DEVELOPER-HANDOFF.md`
2. `V-324-RELEASE-NOTES.md`
3. `V-324_PLAY_COMPLIANCE_QA.md`
4. `V-324_VALIDATION_REPORT.txt`
