# MY SHOP RELEASE HISTORY — RECOVERY INDEX

- V-327: Premium Gift Admin Catalog baseline; source used for V-328.
- V-328: Premium Experience + Stability Foundation. Shared PremiumUi, Live Hub/Room polish, gap-free live-comment acknowledgement, Feature/Chat/Inbox polish, existing FCM notification presentation refinement, Master State recovery system added.

Rule: Never delete this file. Append each future V-number with scope, base version, key modified modules, regression status and rollback source.

## V-330
Coin & Gold Coin Catalog admin completion pass: navigation disambiguation, full Gift Studio lock/preservation, separate COIN/GOLD finance summary, version 2.9.330. Runtime acceptance pending CI/device.

## V-352
Base V-351. Live stabilization pass: D1 full-room polling reduced from sub-second to 12-second reconciliation; temporary Live comments/highlights and gift delivery use a per-room Durable Object realtime hub; join/invite/seat/moderation mutations trigger lightweight dirty signals; additive D1 read indexes added; repeated Agora publish/mic reconfiguration suppressed. Approved V-350/V-351 Live UI and unrelated working modules locked. Runtime Cloud + two-device acceptance pending.
## V-353
Base V-352. Audio-only recovery pass: restored Agora live voice playback/publish application after V-352 idempotency regression; remote audio/speaker route kept active; gift sounds switched to MEDIA/MUSIC playback and no longer steal transient audio focus from RTC. V-352 D1/realtime/comment work and unrelated modules locked. Runtime two-device acceptance pending.

