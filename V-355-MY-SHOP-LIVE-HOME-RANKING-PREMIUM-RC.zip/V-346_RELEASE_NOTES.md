# MY SHOP V-346 — Live Mini Mode / Seat / Gift / Audio Polish

## Completed source changes
- Added Android Picture-in-Picture support for the Live Room and Back-to-mini behavior (Android 8+); legacy fallback keeps the task alive instead of ending Live.
- Added approved dark low-light full-screen Live background asset.
- Removed the outer guest-seat board frame and changed empty seats to circular MY SHOP LIVE placeholders.
- Replaced duplicate top-right Users chip with an Exit control while retaining the Host-area Users stat.
- Preserved Join -> Leave behavior and added a subtle glow to the audience Join action.
- Kept Host End Live authority separate from audience Leave.
- Expanded gift activity rows in the comment stream (larger avatar, gift art, text, and card presence).
- Increased global gift effect footprint and presentation duration while preserving per-gift Admin scale/duration values as relative controls.
- Increased perceived gift sound presence; full-clip sounds can loop only for the extended configured playback window, then release safely.
- Added speech-first Agora audio tuning for voice clarity (speech profile + chatroom scenario, capture/playback gain adjustment).
- Added local permission fallback so Host, Room Admin, MY SHOP Admin, and Moderator can pin comments when backend authorization permits those roles.
- Release identity synchronized to V-346 / 2.9.346; Worker health/build markers synchronized to V-346.

## Preserved
- Existing V-345 Host-separate + 5+5 guest board seat allocation/logic.
- Join Request / Host Invite flow.
- Coin and Gold Coin gift catalogs, prices, ledger, balances, VAT/service-fee behavior, and Admin gift controls.
- Ephemeral Live comments.
- Existing Admin theme override behavior.
- D1/R2 bindings and schema.
