# MY SHOP V-335 — Live Comment Style System Rebuild

Base: V-334
Build identity: MY SHOP V-335
versionCode: 335
versionName: 2.9.335

## Implemented
- Removed the previous 10 large Banner Slot Admin UI and disabled its active backend path.
- Added Global Style (All Users) as the first/top Live Comment control.
- Added live preview/test-before-save for Global, Badge Preset and per-user Custom style editing.
- Added style controls for background, text, name, level, border, font size/weight, border width, corner radius, opacity.
- Added Border Glow ON/OFF, Glow Color, Glow Intensity, Background Glow ON/OFF.
- Added Animation ON/OFF, type and speed, with preview animation test.
- Added ready-made preset families: VIP, VVIP, ROYAL (Male/Female x5), KING (Male x5), QUEEN (Female x5).
- Added MY SHOP User ID search using the existing user profile backend; name/ID/level are shown before assignment.
- Added per-user assignment: ready-made preset or fully custom style.
- Added runtime priority: User Custom > Assigned Preset > Global Style.
- Live Room renderer now loads the new Global/Preset/Assignment configuration and applies it to normal live comments.
- Old 10-slot banner strings/routes/UI are no longer referenced by the V-335 active source.

## Backend deployment required
Deploy `backend/worker/src/index.js` before testing these new Admin controls on production devices. New D1 tables are created non-destructively by schema bootstrap.

## Verification status
- Worker JavaScript syntax: PASS (`node --check`).
- Source identity consistency: PASS.
- Legacy 10-slot active source references: PASS (none found).
- Full Android release compile: NEEDS GITHUB CI TEST (local source has no Gradle wrapper/runtime build environment).
- Real-device visual/interaction/backend persistence test: NEEDS DEVICE TEST.
