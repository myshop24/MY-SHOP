# MY SHOP V-348 — Final Live Room Visual Lock + Gift Sound Fix

- Base: V-347.
- Final approved Live Room reference is included as `APPROVED-V348-LIVE-ROOM-FINAL-REFERENCE.png`.
- Full-screen dark navy/purple background remains one continuous visual surface.
- Main Guest position: MY SHOP LIVE logo while empty; guest profile photo when occupied.
- User seats: exactly 8 visible seats, numbered 2–9, 4 + 4 layout, large translucent gray circular seat design with centered white chair icon when empty.
- Occupied user seat shows that user's real profile photo.
- Top-right exit is a red X with no circular border/background.
- Gift sound playback hardened for snake_case/camelCase configuration, remote sound URL failures, and built-in fallback sounds.
- Coin/Gold Coin accounting, gift pricing, transaction logic, comments, RTC, join request/invite and protected modules preserved.
