# MY SHOP V-343 — Agora Audio Trace + Worker Deploy Ready

- Preserves V-342 Live Room, 12-seat structure, backend contracts and existing features.
- Adds persistent RTC diagnostics that are no longer overwritten by the 1.2s room refresh.
- Captures Agora join return code, connection state/reason, local audio state/error, remote user join, and remote audio state/reason.
- Explicitly enables local audio for publishers, remote audio subscription/playback, speaker route, playback/recording volume at 100.
- Does not log or display RTC token or Agora App Certificate.
- Bundled master workflow contains the verified Worker deployment path using GitHub `AGORA_APP_CERTIFICATE` secret.
- Cloud Recording remains disabled; Live comments remain ephemeral.
