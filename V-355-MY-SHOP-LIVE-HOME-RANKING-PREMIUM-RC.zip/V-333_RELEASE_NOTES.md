# MY SHOP V-333 Release Notes

- Live Room cleanup: removed visible AudioLive/caption bar, HOST/room premium strip, and LIVE COMMENTS heading/container chrome.
- Pinned comment retained directly under 12-seat area; Host can long-press any normal comment and pin it.
- Normal Live comments use larger, timestamp-free, theme-independent dark rounded presentation; automatic VIP/VVIP/ROYAL color treatment removed from normal comments.
- Added Admin > Live Comments & Banners: global comment font size 12–24 and 10 assignable banner slots by MY SHOP User ID.
- Added Worker/D1 configuration for comment font and 10 banner assignments. Worker deployment required.
- Gift Sound trim waveform is now explicitly interactive: selected audio reveals waveform guidance and green/red trim handles can be dragged directly as well as via sliders.
- Preserved Host separate + 12 seats (6+6), Home Dashboard, Coin/Gold flows and existing Live controls.
