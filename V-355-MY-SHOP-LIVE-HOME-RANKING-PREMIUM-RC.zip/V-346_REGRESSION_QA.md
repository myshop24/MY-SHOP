# V-346 Regression QA

## Static checks completed
- PASS: SOURCE_BUILD_ID = MY SHOP V-346.
- PASS: SOURCE_VERSION_NAME = 2.9.346.
- PASS: Android versionCode = 346 / versionName = 2.9.346.
- PASS: Worker /health and deep-health identity markers = 2.9.346 / V-346.
- PASS: Android manifest declares Picture-in-Picture support only for AudioLiveRoomActivity; no new sensitive permission added.
- PASS: existing non-target Java modules hash-identical to the V-345 input source.
- PASS: Live seat backend allocation remains seats 2..11; Host remains separate at seat 1 source state.
- PASS: D1/R2 schema/bindings unchanged.
- PASS: Gift financial transaction/ledger code untouched.
- PASS: Join Request / Host Invite backend flow untouched.
- PASS: Live comments remain ephemeral; no persistence was added.
- PASS: Worker JavaScript syntax check (`node --check`) completed.
- PASS: target Java source brace-balance/static structure check completed.

## Runtime acceptance still required on Android devices
- DEVICE CHECK: Back -> Picture-in-Picture/mini Live -> audio continues -> tap mini restores full Live.
- DEVICE CHECK: navigate to another app while PiP is visible and verify Live audio continuity.
- DEVICE CHECK: Host/Guest voice clarity on speakerphone and headset on two devices.
- DEVICE CHECK: large gift comment card, larger/longer gift effect, and louder/longer sound without clipping.
- DEVICE CHECK: empty-seat MY SHOP LIVE placeholder and occupied-seat profile photo replacement.
- DEVICE CHECK: Host / Room Admin / Main Admin / Moderator pin permission against deployed backend session roles.
- DEVICE CHECK: top-right Exit and bottom Join -> Leave state behavior.

## Build note
The incoming project does not include `gradlew`, `gradlew.bat`, or `gradle-wrapper.jar`, and this execution environment has no system Gradle/Android SDK. Therefore local APK compilation is not claimed as PASS. Use the existing Gradle 8.11.1 CI/build environment and complete the device checks above before production release.
