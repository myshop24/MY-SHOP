# MY SHOP MASTER SPEC — V-328+

This file is the permanent source-of-truth entry point. If chat history is lost, read this file, CURRENT-STATE.md, REGRESSION-CHECKLIST.md, RELEASE-HISTORY.md and MY-SHOP-DEVELOPER-HANDOFF.md before changing code.

## Locked product rules
- Current Main Home Dashboard is LOCKED / DO NOT REDESIGN unless Admin explicitly requests it.
- Preserve all known-working features and backend behavior when changing another module.
- Preserve Cloudflare D1/R2 bindings, schemas and environment variables.
- Preserve user identity records; deactivate/ban/soft-delete only.
- Admin controls stay admin-only.
- Google Play compliance is a release gate.

## Premium Design System
- Reuse shared premium components instead of inventing new styles per screen.
- Primary visual identity: clean light surfaces + vivid blue/purple, controlled pink/cyan highlights, gold only for premium/coin emphasis.
- Buttons: compact, clear, touch-friendly, consistent radius, subtle gradient, thin highlight edge, controlled elevation, 65–135 ms press/release micro-motion.
- Cards: consistent rounded radius, restrained border, clean padding, soft elevation, no oversized bulky boxes.
- Typography hierarchy must remain consistent across title/section/body/caption/action states.
- Avoid excessive neon/glow, random colors, inconsistent emoji-as-icons and oversized controls.
- Premium acceptance requires Visual + Interaction + Performance review, not only functional correctness.

## Live experience
- Audio Live launch architecture remains 12 speaking seats total: Host + up to 11 guests/speakers; audience separate.
- Preserve join-request, host invite, mic, seat, gift, moderation, reconnect and end-live behavior.
- Live comments are ephemeral and must not be permanently stored in D1/R2.
- Live comment UI must show sender input immediately and reconcile with server echo without visible disappear/re-add flicker.

## Messaging
- Existing FCM push architecture is the canonical notification path.
- Message notification should use a high-importance message channel, show sender/message preview subject to lockscreen privacy, and deep-link to the correct chat.
- Real background/terminated notification delivery must be verified on a real Android device with Firebase/Worker production secrets configured.
