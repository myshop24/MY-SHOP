# MY SHOP V-329 — Build Version Alignment + Gift Catalog Preservation

## Fixed
- GitHub Actions version guard mismatch fixed by aligning Android metadata to the permanent workflow convention:
  - versionCode = 329
  - versionName = 2.9.329
  - SOURCE_BUILD_ID = MY SHOP V-329
- This specifically prevents the previous failure where V-328 source used 3.0.328 while the workflow expected 2.9.328.

## Preserved / locked
- Gift Coin & Gold Coin Catalog full admin editing system is preserved, including drag/reorder, sound upload, trim/test, animation, board position/coverage, VAT, preview and save/publish/delete controls.
- Home Dashboard remains untouched.
- Existing Worker/backend contracts remain untouched.

## QA status
- Source/version guard: PASS (static validation).
- Gift Catalog control-presence audit: PASS (static source audit).
- Full Android CI build: NEEDS GITHUB CI.
- Real-device Gift Catalog interaction: NEEDS DEVICE TEST.
