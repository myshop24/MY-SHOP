# MY SHOP V-351 — Regression / Acceptance QA

## Source identity
- [x] versionCode = 351
- [x] versionName = 2.9.351
- [x] SOURCE_BUILD_ID = MY SHOP V-351
- [x] SOURCE_VERSION_NAME = 2.9.351
- [x] Worker identity = 2.9.351 / V-351
- [x] Exactly one V-351 ZIP should be uploaded to GitHub

## Locked runtime acceptance after GitHub Green
- [ ] Final Live Room reference matches installed APK
- [ ] Seats 2–9 and locked seat styling match reference
- [ ] Gift sound works on real device
- [ ] Gift sender entry is prominent and chronological
- [ ] Comment stack/height/scroll behavior passes
- [ ] Persistent login passes restart test
- [ ] System push notification passes background/closed-app test
- [ ] Join button animation works without changing Join/Leave logic
- [ ] Coin/Gold/Admin/backend/Live regression checks pass
