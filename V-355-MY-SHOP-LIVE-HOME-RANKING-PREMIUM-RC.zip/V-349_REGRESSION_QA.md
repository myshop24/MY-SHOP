# V-349 Regression / Acceptance QA

## Source/static gate
- [x] versionCode/versionName/source/Worker identity = 349 / 2.9.349 / V-349
- [x] 8 seats only (2–9, 4+4)
- [x] Main Guest locked logo + crown/laurel
- [x] empty seats = gray circle + white chair; obsolete MS-logo seat resource removed
- [x] red borderless Exit X
- [x] prominent Gift Activity sender row + duplicate small GIFT suppression
- [x] built-in Gift sound fallback + remote sound watchdog
- [x] Keystore-backed persistent session implementation
- [x] POST_NOTIFICATIONS + FCM service/channels + notification icon
- [x] Worker push diagnostics added
- [x] Agora voice-only dependency for audio Live
- [x] Android PNG resource integrity checked
- [x] Worker JavaScript syntax checked

## CI/device acceptance — MUST be completed on produced APK
- [ ] GitHub Android release compile succeeds
- [ ] Installed Live Room screenshot matches approved V-349 reference
- [ ] Main Guest/8 seats/white chairs/red X verified on device
- [ ] Two-device Join Request + Host Invite + audio seats regression test
- [ ] Coin Gift sound audible; Gold Gift sound audible; custom Admin sound audible; Volume 0/100 behavior checked
- [ ] Gift sender/name/image/value appears prominently and only once
- [ ] Kill/reopen app with valid session -> direct Dashboard without Login
- [ ] Logout / expired or revoked session -> Login shown
- [ ] Message push appears in Android notification shade while app background/closed; tap opens correct chat
- [ ] Live-start push appears for eligible follower while app background/closed; tap opens correct Live room
- [ ] Admin System Health: Push Client Config=OK, Notification Permission=GRANTED, Worker push.fcmServerConfigured=true, activePushTokens>0
- [ ] Coin/Gold balances/ledger, gift catalog/Admin settings, comments, End Live, PiP, Profile, Dashboard, Store/Admin/navigation regressions pass
- [ ] APK/AAB size compared with V-348; investigate any unexpected increase

Runtime status remains PENDING until all unchecked items are tested against the actual CI-built APK.
