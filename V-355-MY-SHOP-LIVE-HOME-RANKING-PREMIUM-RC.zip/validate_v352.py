#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, sys, tomllib
ROOT=Path(__file__).resolve().parent
errors=[]
def need(cond,msg):
    if not cond: errors.append(msg)
def text(p): return (ROOT/p).read_text(encoding='utf-8')

# Identity
need(text('SOURCE_BUILD_ID.txt').strip()=='MY SHOP V-352','SOURCE_BUILD_ID mismatch')
need(text('SOURCE_VERSION_NAME.txt').strip()=='2.9.352','SOURCE_VERSION_NAME mismatch')
gradle=text('app/build.gradle')
need(re.search(r'\bversionCode\s+352\b',gradle) is not None,'versionCode != 352')
need('versionName "2.9.352"' in gradle,'versionName != 2.9.352')
worker=text('backend/worker/src/index.js')
need("version:'2.9.352',build:'V-352'" in worker,'Worker V-352 identity missing')

# D1/realtime fix contract
activity=text('app/src/main/java/com/myshop/app/AudioLiveRoomActivity.java')
client=text('app/src/main/java/com/myshop/app/BackendClient.java')
rtc=text('app/src/main/java/com/myshop/app/AgoraRtcManager.java')
need('giftTick' not in activity,'legacy giftTick still present')
need('handler.postDelayed(this, 12000L);' in activity,'12s reconciliation/heartbeat missing')
need('handler.postDelayed(this, 8000L);' in activity,'8s participant heartbeat missing')
need('handler.postDelayed(this, 650L);' in activity,'realtime event cadence missing')
need('now-lastRealtimeFallbackMs>10000L' in activity,'D1 fallback is not throttled')
need('liveRealtime(' in client and '/v1/live/realtime?' in client,'Android realtime endpoint missing')
need('export class LiveRoomHub' in worker,'LiveRoomHub class missing')
need("p==='/v1/live/realtime'" in worker,'Worker realtime route missing')
need("kind==='DIRTY'?await this.bumpState()" in worker,'state-only revision semantics missing')
need('liveHubRegister(request,env,hostId,sessionId,me.user_id)' in worker,'room ticket registration missing')
need("liveHubPush(env,hostId,sessionId,'COMMENT'" in worker,'comment realtime push missing')
need("liveHubPush(env,hostId,sessionId,'GIFT'" in worker,'gift realtime push missing')
need('lastPublishAudio' in rtc and 'lastMicEnabled' in rtc,'Agora idempotent media guards missing')

# Current approved seat structure remains 8 guest seats: 2..9.
need('if(seatNo<2||seatNo>9)' in worker,'Worker seat 2..9 lock missing')
need('for(int seatNo=2;seatNo<=9;seatNo++)' in activity,'Android seat 2..9 structure missing')

# Worker config and additive SQL migration.
with (ROOT/'backend/worker/wrangler.toml').open('rb') as f: cfg=tomllib.load(f)
binds=cfg.get('durable_objects',{}).get('bindings',[])
need(any(x.get('name')=='LIVE_ROOM_HUB' and x.get('class_name')=='LiveRoomHub' for x in binds),'LIVE_ROOM_HUB binding missing')
need(any(x.get('tag')=='v352_live_room_hub' and 'LiveRoomHub' in x.get('new_sqlite_classes',[]) for x in cfg.get('migrations',[])),'Durable Object migration missing')
sql=text('backend/worker/migrations/0017_v352_live_read_indexes.sql')
need('DROP TABLE' not in sql.upper() and 'DELETE FROM' not in sql.upper(),'V-352 D1 migration is not additive-only')
need(sql.upper().count('CREATE INDEX IF NOT EXISTS')>=7,'Expected V-352 Live indexes missing')

# Protected baseline integrity: every listed file must still match V-351 hash.
prot=ROOT/'V-352_PROTECTED_INTEGRITY.sha256'
need(prot.exists(),'protected integrity file missing')
if prot.exists():
    for line in prot.read_text().splitlines():
        if not line.strip(): continue
        try: h,p=line.split('  ',1)
        except ValueError: errors.append('bad integrity line: '+line); continue
        p=p[2:] if p.startswith('./') else p
        fp=ROOT/p
        if not fp.is_file(): errors.append('protected file missing: '+p); continue
        now=hashlib.sha256(fp.read_bytes()).hexdigest()
        if now!=h: errors.append('protected file changed: '+p)

if errors:
    print('V-352 STATIC VALIDATION: FAIL')
    for e in errors: print(' -',e)
    sys.exit(1)
print('V-352 STATIC VALIDATION: PASS')
print('Identity, D1/realtime contract, 8-seat lock, Worker binding/migration, Agora guards, and protected-file hashes passed.')
