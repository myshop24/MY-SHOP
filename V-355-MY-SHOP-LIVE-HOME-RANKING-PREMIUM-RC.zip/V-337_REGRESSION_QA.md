# V-337 Regression QA

## Static/source checks — PASS
- Worker JavaScript syntax (`node --check`) — PASS
- Android versionCode/versionName/source build identity aligned — PASS
- `renderSeats()` block byte-for-byte unchanged from V-336 — PASS
- Viewer row uses horizontal scrolling — PASS
- Viewer row has no `>` navigation arrow — PASS
- Long comment max visible lines source rule present — PASS
- Direct Ready-made -> User ID assignment flow present — PASS
- Join-time visibility filter present for comments/highlights — PASS
- Join-time visibility filter present for gift events — PASS
- Gift activity feed includes sender avatar/name + receiver + gift/value — PASS
- Host top stats source includes Gift count, Coin, Gold Coin, Star — PASS

## Required runtime verification — NOT YET PASS
- GitHub/Android compile: NEEDS CI (Gradle wrapper JAR/executable is not included in this source snapshot).
- Worker migration/deploy: NEEDS DEPLOY TEST.
- Two-account late-join test: NEEDS DEVICE TEST.
- Long comment visual test on real phone: NEEDS DEVICE TEST.
- Gift activity comment real-time test: NEEDS DEVICE TEST.
- Horizontal viewer scroll + Online count + balances/stars: NEEDS DEVICE TEST.
- Ready-made assignment to a real User ID and subsequent Live comment rendering: NEEDS DEVICE TEST.

Do not mark runtime PASS until these checks are observed on CI/backend/device.
