package com.myshop.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.MotionEvent;
import android.view.View;

/** V-328 shared premium visual/micro-interaction foundation. */
public final class PremiumUi {
    private PremiumUi() {}

    public static final int NAVY = Color.rgb(10, 24, 68);
    public static final int BLUE = Color.rgb(49, 111, 245);
    public static final int PURPLE = Color.rgb(111, 63, 232);
    public static final int PINK = Color.rgb(238, 54, 177);
    public static final int CYAN = Color.rgb(71, 213, 255);
    public static final int GOLD = Color.rgb(255, 198, 72);

    public static GradientDrawable gradient(Context c, int[] colors, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeColor != Color.TRANSPARENT && strokeDp > 0) g.setStroke(dp(c, strokeDp), strokeColor);
        return g;
    }

    public static GradientDrawable solid(Context c, int fill, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeColor != Color.TRANSPARENT && strokeDp > 0) g.setStroke(dp(c, strokeDp), strokeColor);
        return g;
    }

    public static void press(View v) {
        if (v == null) return;
        v.setClickable(true);
        v.setFocusable(true);
        v.setOnTouchListener((view, event) -> {
            int a = event.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(.975f).scaleY(.975f).alpha(.92f).translationY(dp(view.getContext(), 1)).setDuration(65).start();
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).alpha(1f).translationY(0f).setDuration(135).start();
            }
            return false;
        });
    }

    public static void premiumElevation(View v, int dp) {
        if (v != null) v.setElevation(dp(v.getContext(), dp));
    }

    private static int dp(Context c, int n) {
        return Math.round(n * c.getResources().getDisplayMetrics().density);
    }
}
