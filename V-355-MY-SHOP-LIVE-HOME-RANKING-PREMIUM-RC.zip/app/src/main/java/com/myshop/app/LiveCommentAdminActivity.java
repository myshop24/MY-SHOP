package com.myshop.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

/**
 * Live Comment Style Designer
 * Visual-first Admin UI: no HEX/code input is exposed to Admin.
 * Priority: User Custom > Assigned Badge Preset > Global.
 */
public class LiveCommentAdminActivity extends AppCompatActivity {
    private final int BG=Color.rgb(5,18,39), CARD=Color.rgb(10,32,67), CARD2=Color.rgb(13,42,82), BORDER=Color.rgb(33,88,160);
    private final int TEXT=Color.WHITE, MUTED=Color.rgb(158,181,215), BLUE=Color.rgb(24,119,255), PURPLE=Color.rgb(141,47,255), GREEN=Color.rgb(15,190,101), PINK=Color.rgb(245,36,157);
    private final int[] PALETTE={
            Color.rgb(18,28,48), Color.rgb(25,56,97), Color.rgb(19,107,255), Color.rgb(115,48,227),
            Color.rgb(225,48,177), Color.rgb(252,92,65), Color.rgb(238,179,32), Color.rgb(26,186,132),
            Color.rgb(33,206,235), Color.rgb(235,240,248), Color.rgb(255,255,255), Color.rgb(255,88,116)
    };

    private LinearLayout root;
    private StyleEditor globalEditor, presetEditor, customEditor;
    private JSONObject loaded=new JSONObject();
    private Spinner badgeSpinner;
    private LinearLayout genderTabs,presetCards,userCard,assignmentPanel;
    private String selectedBadge="VIP",selectedGender="MALE",selectedPresetKey="VIP-MALE-1",foundUserId="";
    private int selectedPresetNo=1;
    private EditText userIdInput;
    private TextView foundName,foundMeta,currentAssignment;
    private ImageView foundAvatar;
    private Spinner assignPresetSpinner;
    private RadioButton useReady,useCustom;
    private Button removeAssignmentBtn;

    @Override protected void onCreate(Bundle b){super.onCreate(b);build();load();}

    private void build(){
        ScrollView sv=new ScrollView(this); root=col(); root.setPadding(dp(14),dp(14),dp(14),dp(30)); root.setBackgroundColor(BG);
        root.addView(title("💬  Comment Style Designer",23));
        TextView sub=txt("সব রং চোখে দেখে নির্বাচন করুন • Preview/Test করুন • Save না করা পর্যন্ত Live-এ পরিবর্তন হবে না",11,MUTED,false);root.addView(sub);
        LinearLayout userMode=row(); Button allMode=primary("👥 All Users",BLUE); Button selectedMode=primary("👤 Selected User",GREEN); userMode.addView(allMode,new LinearLayout.LayoutParams(0,dp(46),1)); LinearLayout.LayoutParams smp=new LinearLayout.LayoutParams(0,dp(46),1);smp.leftMargin=dp(8);userMode.addView(selectedMode,smp);root.addView(userMode); selectedMode.setOnClickListener(v->{userIdInput.requestFocus(); ((ScrollView)root.getParent()).smoothScrollTo(0,userIdInput.getTop());}); allMode.setOnClickListener(v->((ScrollView)root.getParent()).smoothScrollTo(0,0));


        // 1 GLOBAL
        root.addView(sectionHeader("1","All Users - Default Comment Style","নতুন user বা যাদের কোনো assigned style নেই, তারা এই design ব্যবহার করবে।",BLUE));
        globalEditor=new StyleEditor("Live Preview (All Users)"); root.addView(globalEditor.view);
        Button saveGlobal=primary("✓  Save & Publish Global Style",BLUE);root.addView(saveGlobal,fullButton());saveGlobal.setOnClickListener(v->saveGlobal());

        // 2 BADGE PRESETS
        root.addView(sectionHeader("2","Ready-made Membership Comment Styles","VIP / VVIP / ROYAL: Male 5 + Female 5 • KING: Male 5 • QUEEN: Female 5",PINK));
        badgeSpinner=spinner(new String[]{"VIP","VVIP","ROYAL","KING","QUEEN"});root.addView(label("Membership / Badge"));root.addView(badgeSpinner,new LinearLayout.LayoutParams(-1,dp(48)));
        genderTabs=row();root.addView(genderTabs);buildGenderTabs();
        presetCards=row();HorizontalScrollView ph=new HorizontalScrollView(this);ph.setHorizontalScrollBarEnabled(false);ph.addView(presetCards);root.addView(ph,new LinearLayout.LayoutParams(-1,dp(96)));buildPresetCards();
        presetEditor=new StyleEditor("Selected Membership Preview");root.addView(presetEditor.view);presetEditor.view.setVisibility(View.GONE);
        Button advancedPreset=primary("⚙  Customize Selected Banner (Advanced)",Color.rgb(57,76,125));root.addView(advancedPreset,fullButton());
        Button savePreset=primary("✓  Save Selected Ready-made Style",PURPLE);root.addView(savePreset,fullButton());savePreset.setVisibility(View.GONE);savePreset.setOnClickListener(v->savePreset());
        advancedPreset.setOnClickListener(v->{boolean show=presetEditor.view.getVisibility()!=View.VISIBLE;presetEditor.view.setVisibility(show?View.VISIBLE:View.GONE);savePreset.setVisibility(show?View.VISIBLE:View.GONE);advancedPreset.setText(show?"▲ Hide Advanced Designer":"⚙  Customize Selected Banner (Advanced)");});
        badgeSpinner.setOnItemSelectedListener(simpleListener(()->{selectedBadge=String.valueOf(badgeSpinner.getSelectedItem());syncGenderForBadge();buildGenderTabs();buildPresetCards();loadSelectedPreset();}));

        // 3 SEARCH / ASSIGN
        root.addView(sectionHeader("3","Search User & Assign / Custom Design","MY SHOP User ID দিয়ে Search করুন, তারপর ready-made style assign করুন অথবা আলাদা custom design বানান।",GREEN));
        LinearLayout search=row();userIdInput=input("Enter MY SHOP User ID");Button sb=primary("🔎 Search",BLUE);search.addView(userIdInput,new LinearLayout.LayoutParams(0,dp(48),1));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(110),dp(48));sp.leftMargin=dp(8);search.addView(sb,sp);root.addView(search);sb.setOnClickListener(v->searchUser());
        userCard=buildUserCard();root.addView(userCard);userCard.setVisibility(View.GONE);
        assignmentPanel=col();assignmentPanel.setPadding(dp(10),dp(10),dp(10),dp(10));assignmentPanel.setBackground(round(CARD2,BORDER,16));
        TextView choose=txt("Choose Style",14,TEXT,true);assignmentPanel.addView(choose);
        RadioGroup rg=new RadioGroup(this);rg.setOrientation(RadioGroup.HORIZONTAL);useReady=new RadioButton(this);useReady.setText("Ready-made");styleRadio(useReady);useReady.setChecked(true);useCustom=new RadioButton(this);useCustom.setText("Custom Design");styleRadio(useCustom);rg.addView(useReady);rg.addView(useCustom);assignmentPanel.addView(rg);
        assignPresetSpinner=spinner(buildPresetKeys());assignmentPanel.addView(label("Ready-made Style"));assignmentPanel.addView(assignPresetSpinner,new LinearLayout.LayoutParams(-1,dp(48)));
        customEditor=new StyleEditor("Custom Preview for Selected User");customEditor.view.setVisibility(View.GONE);assignmentPanel.addView(customEditor.view);
        rg.setOnCheckedChangeListener((g,id)->{boolean custom=useCustom.isChecked();assignPresetSpinner.setVisibility(custom?View.GONE:View.VISIBLE);customEditor.view.setVisibility(custom?View.VISIBLE:View.GONE);});
        currentAssignment=txt("Current: All Users Default",11,Color.rgb(132,220,255),true);assignmentPanel.addView(currentAssignment);
        LinearLayout assignActions=row();Button assign=primary("✓  Save & Assign",GREEN);removeAssignmentBtn=primary("Remove / Default",Color.rgb(177,50,65));assignActions.addView(assign,new LinearLayout.LayoutParams(0,dp(50),1));LinearLayout.LayoutParams rm=new LinearLayout.LayoutParams(0,dp(50),.70f);rm.leftMargin=dp(8);assignActions.addView(removeAssignmentBtn,rm);assignmentPanel.addView(assignActions);assign.setOnClickListener(v->assignUser());removeAssignmentBtn.setOnClickListener(v->removeAssignment());root.addView(assignmentPanel);assignmentPanel.setVisibility(View.GONE);

        TextView foot=txt("Priority: User Custom Style  >  Assigned Membership Style  >  All Users Default",11,Color.rgb(104,213,255),true);foot.setPadding(dp(4),dp(18),dp(4),dp(4));root.addView(foot);
        sv.addView(root);setContentView(sv);
    }

    private View sectionHeader(String no,String title,String desc,int accent){
        LinearLayout c=row();c.setPadding(dp(10),dp(14),dp(10),dp(8));TextView n=txt(no,17,TEXT,true);n.setGravity(Gravity.CENTER);n.setBackground(round(accent,accent,50));c.addView(n,new LinearLayout.LayoutParams(dp(40),dp(40)));LinearLayout info=col();info.setPadding(dp(10),0,0,0);info.addView(txt(title,17,TEXT,true));info.addView(txt(desc,10,MUTED,false));c.addView(info,new LinearLayout.LayoutParams(0,-2,1));return c;
    }

    private LinearLayout buildUserCard(){
        LinearLayout c=row();c.setPadding(dp(10),dp(10),dp(10),dp(10));c.setBackground(round(CARD2,BORDER,16));foundAvatar=new ImageView(this);foundAvatar.setImageResource(R.drawable.myshop_profile_avatar);foundAvatar.setScaleType(ImageView.ScaleType.CENTER_CROP);c.addView(foundAvatar,new LinearLayout.LayoutParams(dp(54),dp(54)));LinearLayout info=col();info.setPadding(dp(10),0,0,0);foundName=txt("User",14,TEXT,true);foundMeta=txt("",10,MUTED,false);info.addView(foundName);info.addView(foundMeta);c.addView(info,new LinearLayout.LayoutParams(0,-2,1));return c;
    }

    private void buildGenderTabs(){
        genderTabs.removeAllViews();String[] genders="KING".equals(selectedBadge)?new String[]{"MALE"}:"QUEEN".equals(selectedBadge)?new String[]{"FEMALE"}:new String[]{"MALE","FEMALE"};
        for(String g:genders){Button b=mini(("MALE".equals(g)?"♂  Male (5)":"♀  Female (5)"));boolean on=g.equals(selectedGender);b.setTextColor(TEXT);b.setBackground(round(on?BLUE:CARD2,on?BLUE:BORDER,12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(44),1);p.setMargins(dp(3),dp(6),dp(3),dp(8));genderTabs.addView(b,p);b.setOnClickListener(v->{selectedGender=g;buildGenderTabs();buildPresetCards();loadSelectedPreset();});}
    }

    private void syncGenderForBadge(){if("KING".equals(selectedBadge))selectedGender="MALE";else if("QUEEN".equals(selectedBadge))selectedGender="FEMALE";}

    private void buildPresetCards(){
        presetCards.removeAllViews();
        for(int i=1;i<=5;i++){
            final int no=i;final String key=selectedBadge+"-"+selectedGender+"-"+i;JSONObject s=findPreset(key);if(s==null)s=defaultPreset(key);final JSONObject style=s;
            TextView card=txt("♛ "+selectedBadge+"  •  "+("MALE".equals(selectedGender)?"♂":"♀")+"\nRoyalUser  ⭐ LV.8\nHello everyone ✨",10.4f,TEXT,true);
            card.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);card.setPadding(dp(10),dp(7),dp(10),dp(7));
            int bg=parse(style.optString("backgroundColor"),CARD2),border=parse(style.optString("borderColor"),BLUE),glow=parse(style.optString("borderGlowColor"),border);
            card.setBackground(styleDrawable(bg,border,Math.max(0,style.optInt("borderWidth",2)),Math.max(10,style.optInt("cornerRadius",16)),style.optBoolean("borderGlow",true),glow,style.optInt("borderGlowIntensity",65)));
            card.setTextSize(Math.max(9,Math.min(12,style.optInt("fontSize",17)-6)));card.setTypeface(Typeface.DEFAULT,"BOLD".equalsIgnoreCase(style.optString("fontWeight","BOLD"))?Typeface.BOLD:Typeface.NORMAL);
            if(i==selectedPresetNo){card.setScaleX(1.03f);card.setScaleY(1.03f);card.setElevation(dp(7));}
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(174),dp(84));p.setMargins(dp(4),dp(6),dp(4),dp(6));presetCards.addView(card,p);
            card.setOnClickListener(v->{selectedPresetNo=no;selectedPresetKey=key;buildPresetCards();loadSelectedPreset();showPresetAssignDialog(key);});
        }
    }

    private void showPresetAssignDialog(String presetKey){
        final EditText uid=input("Enter MY SHOP User ID");
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Assign "+presetKey)
                .setMessage("User ID নির্বাচন করুন। User preview দেখে Save & Assign চাপলেই banner ওই ID-তে active হবে।")
                .setView(uid)
                .setPositiveButton("Search",(dlg,w)->{
                    final String id=uid.getText().toString().trim();if(id.isEmpty()){toast("User ID লিখুন");return;}
                    BackendClient.userProfile(SessionManager.getToken(this),id,new BackendClient.Callback(){
                        public void onSuccess(JSONObject d){runOnUiThread(()->{JSONObject p=d.optJSONObject("profile");if(p==null){toast("User পাওয়া যায়নি");return;}String userId=p.optString("userId",id),name=p.optString("name","MY SHOP User");int lv=p.optInt("level",0);new androidx.appcompat.app.AlertDialog.Builder(LiveCommentAdminActivity.this)
                                .setTitle("Confirm Banner Assignment")
                                .setMessage("Name: "+name+"\nUser ID: "+userId+"\nLevel: "+lv+"\n\nBanner: "+presetKey)
                                .setPositiveButton("Save & Assign",(x,y)->BackendClient.adminLiveCommentAssignmentSave(SessionManager.getToken(LiveCommentAdminActivity.this),userId,presetKey,new JSONObject(),false,true,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{toast("Banner assigned to "+userId);load();});}public void onError(String m){toast(m);}}))
                                .setNegativeButton("Cancel",null).show();});}
                        public void onError(String m){toast("User পাওয়া যায়নি");}
                    });
                })
                .setNegativeButton("Preview only",null).show();
    }

    private JSONObject findPreset(String key){JSONArray a=loaded.optJSONArray("presets");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&key.equalsIgnoreCase(x.optString("presetKey")))return x;}return null;}
    private void loadSelectedPreset(){if(presetEditor==null)return;selectedPresetKey=selectedBadge+"-"+selectedGender+"-"+selectedPresetNo;JSONObject s=findPreset(selectedPresetKey);presetEditor.fromJson(s==null?defaultPreset(selectedPresetKey):s);}

    private void load(){BackendClient.liveCommentUi(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{loaded=o;JSONObject g=o.optJSONObject("globalStyle");if(g!=null)globalEditor.fromJson(g);buildPresetCards();loadSelectedPreset();});}public void onError(String m){toast(m);}});}
    private void saveGlobal(){BackendClient.adminLiveCommentGlobalSave(SessionManager.getToken(this),globalEditor.toJson(),new CallbackToast("Global style published"));}
    private void savePreset(){JSONObject s=presetEditor.toJson();try{s.put("presetKey",selectedPresetKey);s.put("badge",selectedBadge);s.put("gender",selectedGender);s.put("presetNo",selectedPresetNo);}catch(Exception ignored){}BackendClient.adminLiveCommentPresetSave(SessionManager.getToken(this),s,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{toast(selectedPresetKey+" saved");load();});}public void onError(String m){toast(m);}});}

    private void searchUser(){String uid=userIdInput.getText().toString().trim();if(uid.isEmpty()){toast("User ID লিখুন");return;}BackendClient.userProfile(SessionManager.getToken(this),uid,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONObject p=d.optJSONObject("profile");if(p==null){toast("User পাওয়া যায়নি");return;}foundUserId=p.optString("userId",uid);String name=p.optString("name","MY SHOP User");int lv=p.optInt("level",0);String badge=p.optString("badge",p.optString("membership","None"));foundName.setText(name);foundMeta.setText("ID: "+foundUserId+"   •   Level "+lv+"   •   Badge: "+badge);String av=p.optString("avatarUrl","");if(!av.isEmpty())AnimatedAssetLoader.load(foundAvatar,av);userCard.setVisibility(View.VISIBLE);assignmentPanel.setVisibility(View.VISIBLE);customEditor.previewName=name+"  •  LV."+lv;applyExistingAssignment(foundUserId);customEditor.updatePreview();});}public void onError(String m){toast("User পাওয়া যায়নি");}});}
    private JSONObject findAssignment(String uid){JSONArray a=loaded.optJSONArray("assignments");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&uid.equals(x.optString("userId")))return x;}return null;}
    private void applyExistingAssignment(String uid){JSONObject a=findAssignment(uid);if(a==null){currentAssignment.setText("Current: All Users Default");useReady.setChecked(true);return;}if(a.optBoolean("isCustom",false)){currentAssignment.setText("Current: Custom User Style");useCustom.setChecked(true);JSONObject c=a.optJSONObject("customStyle");if(c!=null)customEditor.fromJson(c);}else{String key=a.optString("presetKey","");currentAssignment.setText("Current: "+(key.isEmpty()?"All Users Default":key));useReady.setChecked(true);select(assignPresetSpinner,key);}}
    private void assignUser(){if(foundUserId.isEmpty()){toast("আগে User Search করুন");return;}boolean custom=useCustom.isChecked();String preset=custom?"":String.valueOf(assignPresetSpinner.getSelectedItem());JSONObject style=custom?customEditor.toJson():new JSONObject();BackendClient.adminLiveCommentAssignmentSave(SessionManager.getToken(this),foundUserId,preset,style,custom,true,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{toast("Style assigned");load();currentAssignment.setText("Current: "+(custom?"Custom User Style":preset));});}public void onError(String m){toast(m);}});}
    private void removeAssignment(){if(foundUserId.isEmpty()){toast("আগে User Search করুন");return;}BackendClient.adminLiveCommentAssignmentSave(SessionManager.getToken(this),foundUserId,"",new JSONObject(),false,false,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{toast("User returned to All Users Default");currentAssignment.setText("Current: All Users Default");load();});}public void onError(String m){toast(m);}});}

    private class StyleEditor{
        LinearLayout view,swatchArea;TextView preview,fontVal,borderVal,radiusVal,opacityVal,glowVal,speedVal;
        int backgroundColor=Color.rgb(18,28,48),textColor=Color.WHITE,nameColor=Color.rgb(255,211,75),levelColor=Color.rgb(69,215,255),borderColor=Color.rgb(61,117,231),glowColor=Color.rgb(208,47,255);
        int font=16,border=1,radius=14;SeekBar opacity,glowIntensity,animSpeed;
        CheckBox boxAnim,borderAnim,textAnim,nameAnim,levelAnim,borderGlow,bgGlow;
        Spinner fontWeight,boxAnimType,borderAnimType,textAnimType,nameAnimType,levelAnimType;
        EditText testText;String previewName="Sample User  •  LV.5";
        StyleEditor(String previewTitle){
            view=col();view.setTag(previewTitle.startsWith("Live Preview (All Users)")?"GLOBAL":previewTitle.startsWith("Selected Membership")?"PRESET":"CUSTOM");view.setPadding(dp(10),dp(10),dp(10),dp(10));view.setBackground(round(CARD,BORDER,16));
            // ready color themes row
            view.addView(label("Ready Colors"));HorizontalScrollView themes=new HorizontalScrollView(LiveCommentAdminActivity.this);LinearLayout tr=row();String[] names={"Classic","Blue","Purple","Pink","Dark","Green","Gold","Red","Cyan"};int[] tc={0xFF1B2435,0xFF075CDA,0xFF5B24C5,0xFFC51E7E,0xFF101722,0xFF087A58,0xFF8A6410,0xFF981F34,0xFF0A7E97};for(int i=0;i<names.length;i++){final int c=tc[i];Button b=mini(names[i]);b.setTextColor(TEXT);b.setBackground(round(c,lighten(c),12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(86),dp(48));p.setMargins(dp(3),dp(3),dp(3),dp(3));tr.addView(b,p);b.setOnClickListener(v->{backgroundColor=c;borderColor=lighten(c);glowColor=lighten(lighten(c));updatePreview();});}themes.addView(tr);view.addView(themes,new LinearLayout.LayoutParams(-1,dp(58)));
            addColorRow("Background",0);addColorRow("Text Color",1);addColorRow("Name Color",2);addColorRow("Level Color",3);addColorRow("Border Color",4);addColorRow("Glow Color",5);
            LinearLayout steps=row();fontVal=addStepper(steps,"Font",12,28,font,v->{font=v;});borderVal=addStepper(steps,"Border",0,6,border,v->{border=v;});radiusVal=addStepper(steps,"Radius",4,30,radius,v->{radius=v;});view.addView(steps);
            fontWeight=spinner(new String[]{"NORMAL","BOLD"});view.addView(label("Font Weight"));view.addView(fontWeight,new LinearLayout.LayoutParams(-1,dp(46)));
            borderGlow=check("✨ Border Glow");bgGlow=check("🌟 Background Glow");LinearLayout glowRow=row();glowRow.addView(borderGlow,new LinearLayout.LayoutParams(0,-2,1));glowRow.addView(bgGlow,new LinearLayout.LayoutParams(0,-2,1));view.addView(glowRow);
            glowIntensity=seek(0,100,60);glowVal=txt("60%",10,MUTED,true);addSeek("Glow Intensity",glowIntensity,glowVal);
            opacity=seek(30,100,95);opacityVal=txt("95%",10,MUTED,true);addSeek("Opacity",opacity,opacityVal);
            view.addView(label("Animations"));boxAnim=check("Box Animation");boxAnimType=spinner(new String[]{"FADE","PULSE","POP","NONE"});addAnimLine(boxAnim,boxAnimType);borderAnim=check("Border Animation");borderAnimType=spinner(new String[]{"GLOW BORDER","PULSE BORDER","SOFT FLASH","NONE"});addAnimLine(borderAnim,borderAnimType);textAnim=check("Text / Font Animation");textAnimType=spinner(new String[]{"FADE TEXT","PULSE TEXT","NONE"});addAnimLine(textAnim,textAnimType);nameAnim=check("Name Animation");nameAnimType=spinner(new String[]{"SOFT GLOW","FADE","NONE"});addAnimLine(nameAnim,nameAnimType);levelAnim=check("Level Animation");levelAnimType=spinner(new String[]{"SOFT GLOW","FADE","NONE"});addAnimLine(levelAnim,levelAnimType);
            animSpeed=seek(10,100,55);speedVal=txt("55",10,MUTED,true);addSeek("Animation Speed",animSpeed,speedVal);
            view.addView(label("Preview Comment (type to test)"));testText=input("This is a sample live comment");testText.setText("This is a sample live comment");view.addView(testText,new LinearLayout.LayoutParams(-1,dp(46)));
            view.addView(txt(previewTitle,11,Color.rgb(119,210,255),true));preview=txt("",16,TEXT,false);preview.setPadding(dp(12),dp(10),dp(12),dp(10));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2);pp.setMargins(0,dp(6),0,dp(8));view.addView(preview,pp);
            LinearLayout actions=row();Button test=primary("▶ Test Preview",PURPLE);Button reset=primary("↻ Reset",Color.rgb(57,76,108));actions.addView(test,new LinearLayout.LayoutParams(0,dp(46),1));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,dp(46),.55f);rp.leftMargin=dp(6);actions.addView(reset,rp);view.addView(actions);test.setOnClickListener(v->{updatePreview();playPreviewAnimation();});reset.setOnClickListener(v->reset());
            android.text.TextWatcher tw=new TextWatcherLite(this::updatePreview);testText.addTextChangedListener(tw);fontWeight.setOnItemSelectedListener(simpleListener(this::updatePreview));for(CheckBox c:new CheckBox[]{boxAnim,borderAnim,textAnim,nameAnim,levelAnim,borderGlow,bgGlow})c.setOnCheckedChangeListener((b,cx)->updatePreview());opacity.setOnSeekBarChangeListener(seekListener(v->{opacityVal.setText(v+"%");updatePreview();}));glowIntensity.setOnSeekBarChangeListener(seekListener(v->{glowVal.setText(v+"%");updatePreview();}));animSpeed.setOnSeekBarChangeListener(seekListener(v->speedVal.setText(String.valueOf(v))));updatePreview();
        }
        private void addColorRow(String name,int target){LinearLayout block=col();block.addView(label(name));HorizontalScrollView hs=new HorizontalScrollView(LiveCommentAdminActivity.this);hs.setHorizontalScrollBarEnabled(false);LinearLayout r=row();for(int c:PALETTE){TextView sw=new TextView(LiveCommentAdminActivity.this);sw.setBackground(round(c,Color.argb(120,255,255,255),50));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(34),dp(34));p.setMargins(dp(3),dp(2),dp(3),dp(5));r.addView(sw,p);sw.setOnClickListener(v->{setColor(target,c);updatePreview();});}hs.addView(r);block.addView(hs,new LinearLayout.LayoutParams(-1,dp(42)));view.addView(block);}
        private void setColor(int target,int c){if(target==0)backgroundColor=c;else if(target==1)textColor=c;else if(target==2)nameColor=c;else if(target==3)levelColor=c;else if(target==4)borderColor=c;else glowColor=c;}
        private void addAnimLine(CheckBox c,Spinner s){LinearLayout r=row();r.addView(c,new LinearLayout.LayoutParams(0,dp(46),1));r.addView(s,new LinearLayout.LayoutParams(dp(150),dp(46)));view.addView(r);}
        private void addSeek(String name,SeekBar s,TextView val){LinearLayout h=row();h.addView(label(name),new LinearLayout.LayoutParams(0,-2,1));h.addView(val);view.addView(h);view.addView(s,new LinearLayout.LayoutParams(-1,dp(36)));}
        private void reset(){
            String title=String.valueOf(view.getTag());
            if("GLOBAL".equals(title)){JSONObject g=loaded.optJSONObject("globalStyle");fromJson(g==null?defaultGlobal():g);}
            else if("PRESET".equals(title)){fromJson(defaultPreset(selectedPresetKey));}
            else {JSONObject g=loaded.optJSONObject("globalStyle");fromJson(g==null?defaultGlobal():g);}
        }
        void updatePreview(){String message=testText==null?"This is a sample live comment":testText.getText().toString();String line=previewName+" : "+message;android.text.SpannableString sp=new android.text.SpannableString(line);int levelMark=previewName.indexOf("  •  LV.");int nameEnd=levelMark<0?previewName.length():levelMark;int prefixEnd=Math.min(line.length(),previewName.length()+3);sp.setSpan(new android.text.style.ForegroundColorSpan(nameColor),0,nameEnd,android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);sp.setSpan(new android.text.style.ForegroundColorSpan(levelColor),nameEnd,prefixEnd,android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);sp.setSpan(new android.text.style.ForegroundColorSpan(textColor),prefixEnd,line.length(),android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);preview.setText(sp);preview.setTextSize(font);preview.setTypeface(Typeface.DEFAULT,"BOLD".equals(String.valueOf(fontWeight.getSelectedItem()))?Typeface.BOLD:Typeface.NORMAL);int fill=Color.argb((int)(255*(opacity.getProgress()/100f)),Color.red(backgroundColor),Color.green(backgroundColor),Color.blue(backgroundColor));preview.setBackground(styleDrawable(fill,borderColor,border,radius,borderGlow.isChecked(),glowColor,glowIntensity.getProgress()));preview.setElevation(dp(bgGlow.isChecked()?8:2));}
        void playPreviewAnimation(){int speed=animSpeed.getProgress();long d=Math.max(220,1200-speed*8L);Animation a;if(boxAnim.isChecked()&&"POP".equals(String.valueOf(boxAnimType.getSelectedItem()))){a=new ScaleAnimation(.92f,1f,.92f,1f,Animation.RELATIVE_TO_SELF,.5f,Animation.RELATIVE_TO_SELF,.5f);}else{a=new AlphaAnimation(.45f,1f);}a.setDuration(d);a.setRepeatMode(Animation.REVERSE);a.setRepeatCount((boxAnim.isChecked()||borderAnim.isChecked()||textAnim.isChecked()||nameAnim.isChecked()||levelAnim.isChecked())?1:0);preview.startAnimation(a);}
        JSONObject toJson(){JSONObject o=new JSONObject();try{o.put("backgroundColor",hex(backgroundColor)).put("textColor",hex(textColor)).put("nameColor",hex(nameColor)).put("levelColor",hex(levelColor)).put("borderColor",hex(borderColor)).put("fontSize",font).put("fontWeight",String.valueOf(fontWeight.getSelectedItem())).put("borderWidth",border).put("cornerRadius",radius).put("opacity",opacity.getProgress()).put("borderGlow",borderGlow.isChecked()).put("borderGlowColor",hex(glowColor)).put("borderGlowIntensity",glowIntensity.getProgress()).put("backgroundGlow",bgGlow.isChecked()).put("animation",boxAnim.isChecked()||borderAnim.isChecked()||textAnim.isChecked()||nameAnim.isChecked()||levelAnim.isChecked()).put("animationType",boxAnim.isChecked()?String.valueOf(boxAnimType.getSelectedItem()):"NONE").put("animationSpeed",animSpeed.getProgress()).put("boxAnimation",boxAnim.isChecked()).put("boxAnimationType",String.valueOf(boxAnimType.getSelectedItem())).put("borderAnimation",borderAnim.isChecked()).put("borderAnimationType",String.valueOf(borderAnimType.getSelectedItem())).put("textAnimation",textAnim.isChecked()).put("textAnimationType",String.valueOf(textAnimType.getSelectedItem())).put("nameAnimation",nameAnim.isChecked()).put("nameAnimationType",String.valueOf(nameAnimType.getSelectedItem())).put("levelAnimation",levelAnim.isChecked()).put("levelAnimationType",String.valueOf(levelAnimType.getSelectedItem()));}catch(Exception ignored){}return o;}
        void fromJson(JSONObject o){if(o==null)return;backgroundColor=parse(o.optString("backgroundColor"),backgroundColor);textColor=parse(o.optString("textColor"),textColor);nameColor=parse(o.optString("nameColor"),nameColor);levelColor=parse(o.optString("levelColor"),levelColor);borderColor=parse(o.optString("borderColor"),borderColor);glowColor=parse(o.optString("borderGlowColor"),glowColor);font=o.optInt("fontSize",16);border=o.optInt("borderWidth",1);radius=o.optInt("cornerRadius",14);opacity.setProgress(o.optInt("opacity",95));glowIntensity.setProgress(o.optInt("borderGlowIntensity",60));animSpeed.setProgress(o.optInt("animationSpeed",55));borderGlow.setChecked(o.optBoolean("borderGlow",false));bgGlow.setChecked(o.optBoolean("backgroundGlow",false));boxAnim.setChecked(o.optBoolean("boxAnimation",o.optBoolean("animation",false)));borderAnim.setChecked(o.optBoolean("borderAnimation",false));textAnim.setChecked(o.optBoolean("textAnimation",false));nameAnim.setChecked(o.optBoolean("nameAnimation",false));levelAnim.setChecked(o.optBoolean("levelAnimation",false));select(fontWeight,o.optString("fontWeight","NORMAL"));select(boxAnimType,o.optString("boxAnimationType",o.optString("animationType","FADE")));select(borderAnimType,o.optString("borderAnimationType","GLOW BORDER"));select(textAnimType,o.optString("textAnimationType","FADE TEXT"));select(nameAnimType,o.optString("nameAnimationType","SOFT GLOW"));select(levelAnimType,o.optString("levelAnimationType","SOFT GLOW"));fontVal.setText(String.valueOf(font));borderVal.setText(String.valueOf(border));radiusVal.setText(String.valueOf(radius));updatePreview();}
    }

    private JSONObject defaultGlobal(){JSONObject o=new JSONObject();try{o.put("backgroundColor","#121C30").put("textColor","#FFFFFF").put("nameColor","#FFD34B").put("levelColor","#45D7FF").put("borderColor","#3D75E7").put("fontSize",16).put("fontWeight","NORMAL").put("borderWidth",1).put("cornerRadius",14).put("opacity",95).put("borderGlow",false).put("borderGlowColor","#D02FFF").put("borderGlowIntensity",60).put("backgroundGlow",false).put("animation",false).put("animationType","NONE").put("animationSpeed",55).put("boxAnimation",false).put("boxAnimationType","FADE").put("borderAnimation",false).put("borderAnimationType","GLOW BORDER").put("textAnimation",false).put("textAnimationType","FADE TEXT").put("nameAnimation",false).put("nameAnimationType","SOFT GLOW").put("levelAnimation",false).put("levelAnimationType","SOFT GLOW");}catch(Exception ignored){}return o;}
    private JSONObject defaultPreset(String key){JSONObject o=new JSONObject();try{int bg=0xFF512DA8,border=0xFFE040FB,glow=0xFFFF40F8;if(key.startsWith("VVIP")){bg=0xFF8E145F;border=0xFFFF5DB1;glow=0xFFFF4AA8;}else if(key.startsWith("ROYAL")){bg=0xFF76520A;border=0xFFFFD45A;glow=0xFFFFD45A;}else if(key.startsWith("KING")){bg=0xFF083A8C;border=0xFF42A5FF;glow=0xFF42A5FF;}else if(key.startsWith("QUEEN")){bg=0xFF9C145F;border=0xFFFF63C4;glow=0xFFFF63C4;}int no=1;try{no=Integer.parseInt(key.substring(key.lastIndexOf('-')+1));}catch(Exception ignored){}bg=shift(bg,(no-1)*14);border=shift(border,(no-1)*9);if(key.contains("FEMALE"))bg=lighten(bg,18);String[] nameColors={"#FFD54F","#7CFFEA","#FF9AD8","#FFFFFF","#FFE082"};String[] levelColors={"#40D9FF","#B69CFF","#FFCA6A","#76FFB6","#FF8EA6"};String[] boxTypes={"PULSE","POP","FADE","POP","PULSE"};o.put("backgroundColor",hex(bg)).put("textColor","#FFFFFF").put("nameColor",nameColors[no-1]).put("levelColor",levelColors[no-1]).put("borderColor",hex(border)).put("fontSize",16+(no%2)).put("fontWeight","BOLD").put("borderWidth",1+(no%3)).put("cornerRadius",12+(no*2)).put("opacity",100).put("borderGlow",no!=3).put("borderGlowColor",hex(glow)).put("borderGlowIntensity",45+(no*9)).put("backgroundGlow",no==4||no==5).put("animation",true).put("animationType",boxTypes[no-1]).put("animationSpeed",42+(no*8)).put("boxAnimation",true).put("boxAnimationType",boxTypes[no-1]).put("borderAnimation",no!=3).put("borderAnimationType","GLOW BORDER").put("textAnimation",no==2||no==5).put("textAnimationType","FADE TEXT").put("nameAnimation",no==1||no==4).put("nameAnimationType","SOFT GLOW").put("levelAnimation",no==3||no==5).put("levelAnimationType","SOFT GLOW");}catch(Exception ignored){}return o;}
    private String[] buildPresetKeys(){ArrayList<String> x=new ArrayList<>();for(String b:new String[]{"VIP","VVIP","ROYAL"})for(String g:new String[]{"MALE","FEMALE"})for(int i=1;i<=5;i++)x.add(b+"-"+g+"-"+i);for(int i=1;i<=5;i++)x.add("KING-MALE-"+i);for(int i=1;i<=5;i++)x.add("QUEEN-FEMALE-"+i);return x.toArray(new String[0]);}

    private TextView addStepper(LinearLayout parent,String name,int min,int max,int start,IntSink sink){LinearLayout b=col();b.addView(label(name));LinearLayout r=row();Button m=mini("−"),p=mini("+");TextView v=txt(String.valueOf(start),13,TEXT,true);v.setGravity(Gravity.CENTER);r.addView(m,new LinearLayout.LayoutParams(dp(36),dp(38)));r.addView(v,new LinearLayout.LayoutParams(dp(38),dp(38)));r.addView(p,new LinearLayout.LayoutParams(dp(36),dp(38)));b.addView(r);parent.addView(b,new LinearLayout.LayoutParams(0,-2,1));m.setOnClickListener(q->{int cur=start;try{cur=Integer.parseInt(v.getText().toString());}catch(Exception ignored){}cur=Math.max(min,cur-1);v.setText(String.valueOf(cur));sink.set(cur);});p.setOnClickListener(q->{int cur=start;try{cur=Integer.parseInt(v.getText().toString());}catch(Exception ignored){}cur=Math.min(max,cur+1);v.setText(String.valueOf(cur));sink.set(cur);});return v;}
    private CheckBox check(String s){CheckBox c=new CheckBox(this);c.setText(s);c.setTextColor(TEXT);c.setTextSize(11);return c;}
    private void styleRadio(RadioButton r){r.setTextColor(TEXT);r.setTextSize(12);}
    private LinearLayout.LayoutParams fullButton(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(50));p.setMargins(0,dp(8),0,dp(10));return p;}
    private Button primary(String s,int c){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(TEXT);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(round(c,c,12));return b;}
    private Button mini(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setMinWidth(0);b.setMinimumWidth(0);return b;}
    private TextView title(String s,float z){return txt(s,z,TEXT,true);}
    private TextView label(String s){return txt(s,10,MUTED,true);}
    private TextView txt(String s,float z,int c,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setPadding(dp(4),dp(5),dp(4),dp(5));return v;}
    private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(MUTED);e.setTextColor(TEXT);e.setSingleLine();e.setPadding(dp(10),0,dp(10),0);e.setBackground(round(CARD2,BORDER,10));return e;}
    private Spinner spinner(String[] items){Spinner s=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,items);s.setAdapter(a);return s;}
    private SeekBar seek(int min,int max,int value){SeekBar s=new SeekBar(this);if(Build.VERSION.SDK_INT>=26)s.setMin(min);s.setMax(max);s.setProgress(value);return s;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private android.graphics.drawable.Drawable styleDrawable(int fill,int stroke,int strokeWidth,int radius,boolean glow,int glowColor,int intensity){GradientDrawable inner=new GradientDrawable();inner.setColor(fill);inner.setCornerRadius(dp(radius));if(strokeWidth>0)inner.setStroke(dp(strokeWidth),stroke);if(!glow)return inner;GradientDrawable outer=round(Color.TRANSPARENT,Color.argb(Math.max(30,(int)(255*(intensity/100f))),Color.red(glowColor),Color.green(glowColor),Color.blue(glowColor)),radius+3);outer.setStroke(dp(Math.max(2,strokeWidth+2)),Color.argb(Math.max(30,(int)(255*(intensity/100f))),Color.red(glowColor),Color.green(glowColor),Color.blue(glowColor)));android.graphics.drawable.LayerDrawable layers=new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{outer,inner});layers.setLayerInset(1,dp(3),dp(3),dp(3),dp(3));return layers;}
    private int lighten(int c,int a){return Color.rgb(Math.min(255,Color.red(c)+a),Math.min(255,Color.green(c)+a),Math.min(255,Color.blue(c)+a));}
    private int lighten(int c){return lighten(c,42);}private int shift(int c,int a){return Color.rgb(Math.min(255,Color.red(c)+a),Math.min(255,Color.green(c)+(a/2)),Math.min(255,Color.blue(c)+a));}
    private int parse(String s,int fallback){try{return Color.parseColor(s);}catch(Exception e){return fallback;}}
    private String hex(int c){return String.format("#%02X%02X%02X",Color.red(c),Color.green(c),Color.blue(c));}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
    private void select(Spinner s,String v){for(int i=0;i<s.getCount();i++)if(String.valueOf(s.getItemAtPosition(i)).equalsIgnoreCase(v)){s.setSelection(i);return;}}
    private AdapterView.OnItemSelectedListener simpleListener(VoidRun r){return new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int pos,long id){r.run();}public void onNothingSelected(AdapterView<?> p){}};}
    private SeekBar.OnSeekBarChangeListener seekListener(IntSink s){return new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean u){s.set(p);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}};}
    private interface IntSink{void set(int v);}private interface VoidRun{void run();}
    private class CallbackToast implements BackendClient.Callback{private final String msg;CallbackToast(String m){msg=m;}public void onSuccess(JSONObject o){runOnUiThread(()->{toast(msg);load();});}public void onError(String m){toast(m);}}
    private static class TextWatcherLite implements android.text.TextWatcher{private final VoidRun r;TextWatcherLite(VoidRun r){this.r=r;}public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){r.run();}public void afterTextChanged(android.text.Editable e){}}
}
