package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** V-355 dedicated 6-slot Live Streaming Home Page banner manager. */
public class LiveHomeAdminActivity extends AppCompatActivity {
    private static final int PICK=9551;
    private final int BG=Color.rgb(6,15,47),CARD=Color.rgb(17,29,77),WHITE=Color.WHITE,MUTED=Color.rgb(184,196,230),BLUE=Color.rgb(45,114,246),PURPLE=Color.rgb(123,63,242),PINK=Color.rgb(240,43,183),GREEN=Color.rgb(36,177,111),RED=Color.rgb(224,61,82),GOLD=Color.rgb(255,201,74);
    private LinearLayout list;
    private int pendingSlot=0;
    private String pendingCaption="",pendingLink="";
    private final ExecutorService imageIo=Executors.newFixedThreadPool(2);

    @Override protected void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)){finish();return;}setContentView(build());load();}

    private View build(){
        LinearLayout page=col();page.setBackgroundColor(BG);page.setPadding(dp(12),dp(8),dp(12),dp(18));page.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(dp(12),Math.max(dp(8),i.getSystemWindowInsetTop()+dp(4)),dp(12),Math.max(dp(18),i.getSystemWindowInsetBottom()+dp(8)));return i;});
        LinearLayout top=row();TextView back=txt("‹",30,WHITE,true);back.setGravity(Gravity.CENTER);back.setOnClickListener(v->finish());top.addView(back,lp(dp(46),dp(48)));LinearLayout copy=col();copy.addView(txt("Live Streaming Home Page",20,WHITE,true),lp(-1,dp(28)));copy.addView(txt("Admin Banner Control • 6 Slots",9.5f,MUTED,false),lp(-1,dp(18)));top.addView(copy,new LinearLayout.LayoutParams(0,dp(48),1));page.addView(top,lp(-1,dp(52)));
        TextView size=txt("Recommended Banner Size: 1200 × 560 px  •  Ratio ≈ 2.14:1",11,GOLD,true);size.setGravity(Gravity.CENTER);size.setPadding(dp(8),dp(7),dp(8),dp(7));size.setBackground(gradient(new int[]{Color.rgb(48,36,104),Color.rgb(89,37,126)},14));page.addView(size,lp(-1,dp(42)));
        TextView help=txt("Banner 1–6 এখান থেকেই Add/Replace, Save/Publish, Enable/Disable, Link এবং Delete করুন। Live Home-এ smooth carousel হিসেবে দেখাবে।",9.3f,MUTED,false);help.setPadding(dp(8),dp(8),dp(8),dp(8));page.addView(help,lp(-1,-2));
        list=col();ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setVerticalScrollBarEnabled(false);sv.addView(list);page.addView(sv,new LinearLayout.LayoutParams(-1,0,1));page.post(page::requestApplyInsets);return page;
    }

    private void load(){BackendClient.adminLiveHomeBanners(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->render(d.optJSONArray("banners")));}public void onError(String m){runOnUiThread(()->{render(null);toast("Banner data load হয়নি • "+m);});}});}

    private void render(JSONArray a){list.removeAllViews();JSONObject[] slots=new JSONObject[6];if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;int s=x.optInt("slot",0);if(s>=1&&s<=6)slots[s-1]=x;}for(int i=1;i<=6;i++)slotCard(i,slots[i-1]);}

    private void slotCard(int slot,JSONObject x){
        boolean exists=x!=null;boolean enabled=exists&&x.optInt("active",1)==1;String image=exists?x.optString("image_url",""):"",caption=exists?x.optString("caption",""):"",target=exists?x.optString("target_url",""):"";
        LinearLayout card=col();card.setPadding(dp(10),dp(10),dp(10),dp(10));card.setBackground(gradient(new int[]{Color.rgb(18,31,82),Color.rgb(30,27,88)},17));LinearLayout.LayoutParams cp=lp(-1,-2);cp.bottomMargin=dp(10);card.setLayoutParams(cp);
        LinearLayout head=row();TextView name=txt("Banner "+slot,14,WHITE,true);head.addView(name,new LinearLayout.LayoutParams(0,dp(32),1));TextView st=txt(!exists?"EMPTY":enabled?"PUBLISHED":"DISABLED",8.5f,!exists?MUTED:enabled?Color.rgb(88,235,166):Color.rgb(255,139,148),true);st.setGravity(Gravity.CENTER);st.setBackground(round(Color.argb(45,255,255,255),Color.argb(60,255,255,255),10));head.addView(st,lp(dp(86),dp(28)));card.addView(head,lp(-1,dp(34)));
        FrameLayout previewBox=new FrameLayout(this);previewBox.setBackground(round(Color.rgb(8,18,52),Color.rgb(68,84,153),13));ImageView preview=new ImageView(this);preview.setScaleType(ImageView.ScaleType.CENTER_CROP);preview.setImageResource(R.drawable.startup_ad_myshop_live);previewBox.addView(preview,new FrameLayout.LayoutParams(-1,-1));TextView empty=txt(exists?"Loading preview…":"No banner in this slot",9.5f,MUTED,true);empty.setGravity(Gravity.CENTER);previewBox.addView(empty,new FrameLayout.LayoutParams(-1,-1));if(exists&&!image.isEmpty())loadImage(preview,image,empty);card.addView(previewBox,lp(-1,dp(132)));
        TextView guide=txt("1200×560 px recommended • keep important text away from extreme edges",8.4f,MUTED,false);card.addView(guide,lp(-1,dp(28)));
        EditText cap=field("Caption (optional)",caption);card.addView(cap,lp(-1,dp(46)));EditText link=field("Link URL (optional)",target);card.addView(link,top(lp(-1,dp(46)),5));
        Switch active=new Switch(this);active.setText("Enable / Publish");active.setTextColor(WHITE);active.setTextSize(10.5f);active.setChecked(!exists||enabled);card.addView(active,lp(-1,dp(42)));
        LinearLayout a1=row();TextView add=button(exists?"Replace":"Add",PURPLE);add.setOnClickListener(v->{pendingSlot=slot;pendingCaption=cap.getText().toString().trim();pendingLink=link.getText().toString().trim();pick();});a1.addView(add,wt(1));a1.addView(space(dp(5)));TextView save=button("Save / Publish",GREEN);save.setOnClickListener(v->{if(!exists){toast("আগে Banner Add করুন");return;}BackendClient.adminBannerUpdate(SessionManager.getToken(this),"live_home",slot,cap.getText().toString().trim(),link.getText().toString().trim(),active.isChecked(),new Cb("✓ Banner saved",this::load));});a1.addView(save,wt(1));card.addView(a1,lp(-1,dp(44)));
        LinearLayout a2=row();TextView toggle=button(active.isChecked()?"Disable":"Enable",BLUE);toggle.setOnClickListener(v->{if(!exists){toast("Slot empty");return;}BackendClient.adminBannerUpdate(SessionManager.getToken(this),"live_home",slot,cap.getText().toString().trim(),link.getText().toString().trim(),!enabled,new Cb(!enabled?"✓ Enabled":"✓ Disabled",this::load));});a2.addView(toggle,wt(1));a2.addView(space(dp(5)));TextView del=button("Delete",RED);del.setAlpha(exists?1f:.45f);del.setOnClickListener(v->{if(!exists){toast("Slot empty");return;}new AlertDialog.Builder(this).setTitle("Delete Banner "+slot+"?").setMessage("এই banner এবং তার link সরানো হবে।").setPositiveButton("DELETE",(d,w)->BackendClient.adminBannerDelete(SessionManager.getToken(this),"live_home",slot,new Cb("✓ Banner deleted",this::load))).setNegativeButton("Cancel",null).show();});a2.addView(del,wt(1));card.addView(a2,top(lp(-1,dp(44)),5));list.addView(card);
    }

    private void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r!=PICK||c!=RESULT_OK||d==null||d.getData()==null)return;Uri u=d.getData();try{if((d.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION)!=0)getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}upload(u);}
    private void upload(Uri u){try{InputStream in=getContentResolver().openInputStream(u);String mime=getContentResolver().getType(u);BackendClient.adminBannerUpload(SessionManager.getToken(this),in,"live-home-banner.jpg",mime==null?"image/jpeg":mime,"live_home",pendingSlot,pendingCaption,pendingLink,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{toast("✓ Banner "+pendingSlot+" added");load();});}public void onError(String m){runOnUiThread(()->toast("Upload failed • "+m));}});}catch(Exception e){toast("Selected image open হয়নি");}}

    private void loadImage(ImageView v,String url,TextView ph){imageIo.execute(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(5000);c.setReadTimeout(7000);try(InputStream in=c.getInputStream()){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null)runOnUiThread(()->{v.setImageBitmap(b);ph.setVisibility(View.GONE);});}}catch(Exception e){runOnUiThread(()->ph.setText("Preview unavailable"));}finally{if(c!=null)c.disconnect();}});}
    @Override protected void onDestroy(){imageIo.shutdownNow();super.onDestroy();}

    private EditText field(String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.rgb(126,139,181));e.setText(value);e.setTextColor(WHITE);e.setSingleLine(true);e.setTextSize(11.5f);e.setPadding(dp(11),0,dp(11),0);e.setBackground(round(Color.rgb(9,20,55),Color.rgb(69,84,146),11));return e;}
    private TextView button(String s,int color){TextView t=txt(s,10,WHITE,true);t.setGravity(Gravity.CENTER);t.setBackground(round(color,Color.argb(90,255,255,255),11));PremiumUi.press(t);return t;}
    private TextView txt(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private View space(int w){Space s=new Space(this);s.setLayoutParams(new LinearLayout.LayoutParams(w,1));return s;}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams wt(float w){return new LinearLayout.LayoutParams(0,dp(44),w);}private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}private GradientDrawable gradient(int[] colors,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(radius));return g;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}
    private class Cb implements BackendClient.Callback{private final String ok;private final Runnable done;Cb(String ok,Runnable done){this.ok=ok;this.done=done;}public void onSuccess(JSONObject d){runOnUiThread(()->{toast(ok);if(done!=null)done.run();});}public void onError(String m){runOnUiThread(()->toast(m));}}
}
