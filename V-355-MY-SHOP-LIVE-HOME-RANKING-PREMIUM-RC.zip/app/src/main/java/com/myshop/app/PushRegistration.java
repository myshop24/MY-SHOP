package com.myshop.app;

import android.content.Context;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;

/** V-323: safely registers this Android install for real FCM push when Firebase CI config is present. */
public final class PushRegistration {
    private PushRegistration() {}
    public static boolean firebaseConfigured(){return BuildConfig.PUSH_CLIENT_CONFIGURED&&BuildConfig.FIREBASE_APP_ID!=null&&!BuildConfig.FIREBASE_APP_ID.isEmpty()&&BuildConfig.FIREBASE_PROJECT_ID!=null&&!BuildConfig.FIREBASE_PROJECT_ID.isEmpty()&&BuildConfig.FIREBASE_SENDER_ID!=null&&!BuildConfig.FIREBASE_SENDER_ID.isEmpty()&&BuildConfig.FIREBASE_API_KEY!=null&&!BuildConfig.FIREBASE_API_KEY.isEmpty();}
    public static void sync(Context c){
        if(c==null||!firebaseConfigured()||FirebaseApp.getApps(c).isEmpty())return;String auth=SessionManager.getToken(c);if(auth==null||auth.trim().isEmpty())return;
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task->{if(!task.isSuccessful()||task.getResult()==null)return;BackendClient.registerPushToken(auth,task.getResult(),new BackendClient.Callback(){public void onSuccess(org.json.JSONObject d){c.getSharedPreferences("myshop_push_v349",Context.MODE_PRIVATE).edit().putBoolean("token_registered",true).putLong("registered_at",System.currentTimeMillis()).remove("last_error").apply();}public void onError(String m){c.getSharedPreferences("myshop_push_v349",Context.MODE_PRIVATE).edit().putBoolean("token_registered",false).putString("last_error",String.valueOf(m)).apply();}});});
    }
}
