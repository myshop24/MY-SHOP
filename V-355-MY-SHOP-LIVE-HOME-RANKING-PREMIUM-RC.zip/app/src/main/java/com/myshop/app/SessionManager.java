package com.myshop.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * V-349 persistent session shell.
 * Auth tokens are kept in Android Keystore-backed AES/GCM storage; profile/role metadata
 * remains in private SharedPreferences. Existing plaintext V-348 tokens are migrated once.
 */
public final class SessionManager {
    private static final String PREF = "myshop_session";
    private static final String ROLE = "role";
    private static final String USER_ID = "user_id";
    private static final String TOKEN_LEGACY = "token";
    private static final String TOKEN_ENC = "token_enc_v349";
    private static final String TOKEN_IV = "token_iv_v349";
    private static final String KEY_ALIAS = "myshop_session_token_v349";
    private static volatile boolean ADMIN_GATE_UNLOCKED = false;

    private SessionManager() {}

    public static void setSession(Context c, Role role, String userId) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString(ROLE, role.name())
                .putString(USER_ID, userId == null ? "" : userId)
                .putBoolean("logged_in", role != Role.GUEST)
                .apply();
    }

    public static void setRemoteSession(Context c, String token, Role role, String userId) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        SharedPreferences.Editor e = p.edit()
                .putString(ROLE, role.name())
                .putString(USER_ID, userId == null ? "" : userId)
                .putBoolean("logged_in", role != Role.GUEST);
        String raw = token == null ? "" : token.trim();
        if (raw.isEmpty()) {
            e.remove(TOKEN_ENC).remove(TOKEN_IV).remove(TOKEN_LEGACY).apply();
            return;
        }
        try {
            EncryptedToken enc = encrypt(raw);
            e.putString(TOKEN_ENC, enc.value)
                    .putString(TOKEN_IV, enc.iv)
                    .remove(TOKEN_LEGACY)
                    .apply();
        } catch (Throwable cryptoFailure) {
            // Do not destroy a successful login if a vendor Keystore temporarily fails.
            // Legacy fallback stays inside MODE_PRIVATE and will be migrated on the next read.
            e.putString(TOKEN_LEGACY, raw).remove(TOKEN_ENC).remove(TOKEN_IV).apply();
        }
    }

    public static String getToken(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String encrypted = p.getString(TOKEN_ENC, "");
        String iv = p.getString(TOKEN_IV, "");
        if (!encrypted.isEmpty() && !iv.isEmpty()) {
            try { return decrypt(encrypted, iv); }
            catch (Throwable ignored) { /* try legacy migration/fallback below */ }
        }
        String legacy = p.getString(TOKEN_LEGACY, "");
        if (!legacy.isEmpty()) {
            try {
                EncryptedToken enc = encrypt(legacy);
                p.edit().putString(TOKEN_ENC, enc.value).putString(TOKEN_IV, enc.iv).remove(TOKEN_LEGACY).apply();
            } catch (Throwable ignored) { }
        }
        return legacy;
    }

    public static boolean hasUsableSession(Context c) {
        return isLoggedIn(c) && !getUserId(c).isEmpty() && !getToken(c).isEmpty();
    }

    private static EncryptedToken encrypt(String raw) throws Exception {
        SecretKey key = getOrCreateKey();
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] ciphertext = cipher.doFinal(raw.getBytes(StandardCharsets.UTF_8));
        return new EncryptedToken(
                Base64.encodeToString(ciphertext, Base64.NO_WRAP),
                Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP));
    }

    private static String decrypt(String value, String iv) throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        java.security.Key key = ks.getKey(KEY_ALIAS, null);
        if (!(key instanceof SecretKey)) throw new IllegalStateException("Session key unavailable");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, (SecretKey) key,
                new GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)));
        byte[] plain = cipher.doFinal(Base64.decode(value, Base64.NO_WRAP));
        return new String(plain, StandardCharsets.UTF_8);
    }

    private static SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        java.security.Key existing = ks.getKey(KEY_ALIAS, null);
        if (existing instanceof SecretKey) return (SecretKey) existing;
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build();
        kg.init(spec);
        return kg.generateKey();
    }

    private static final class EncryptedToken {
        final String value, iv;
        EncryptedToken(String value, String iv) { this.value = value; this.iv = iv; }
    }

    public static Role getRole(Context c) {
        String value = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getString(ROLE, Role.GUEST.name());
        try { return Role.valueOf(value); } catch (Exception ignored) { return Role.GUEST; }
    }

    public static String getUserId(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(USER_ID, "");
    }

    public static boolean isLoggedIn(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("logged_in", false);
    }

    public static boolean isAdmin(Context c) { return getRole(c) == Role.ADMIN; }
    public static boolean isModerator(Context c) { return getRole(c) == Role.MODERATOR; }
    public static boolean isAdminGateUnlocked(){ return ADMIN_GATE_UNLOCKED; }
    public static void setAdminGateUnlocked(boolean unlocked){ ADMIN_GATE_UNLOCKED=unlocked; }

    public static void saveProfile(Context c, String name, String email, String mobile) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("full_name", name == null ? "" : name)
                .putString("email", email == null ? "" : email)
                .putString("mobile", mobile == null ? "" : mobile)
                .apply();
    }

    public static void saveProfile(Context c, String name, String email, String mobile, String avatarUrl, String bio) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("full_name", name == null ? "" : name)
                .putString("email", email == null ? "" : email)
                .putString("mobile", mobile == null ? "" : mobile)
                .putString("avatar_url", avatarUrl == null ? "" : avatarUrl)
                .putString("bio", bio == null ? "" : bio)
                .apply();
    }

    public static void saveProfile(Context c, String name, String email, String mobile, String avatarUrl, String coverUrl, String bio) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("full_name", name == null ? "" : name)
                .putString("email", email == null ? "" : email)
                .putString("mobile", mobile == null ? "" : mobile)
                .putString("avatar_url", avatarUrl == null ? "" : avatarUrl)
                .putString("cover_url", coverUrl == null ? "" : coverUrl)
                .putString("bio", bio == null ? "" : bio)
                .apply();
    }

    public static String getFullName(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("full_name", ""); }
    public static String getEmail(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("email", ""); }
    public static String getMobile(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("mobile", ""); }
    public static String getAvatarUrl(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("avatar_url", ""); }
    public static String getCoverUrl(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("cover_url", ""); }
    public static String getBio(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("bio", ""); }

    public static void clear(Context c) {
        ADMIN_GATE_UNLOCKED=false;
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply();
        try {
            KeyStore ks=KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            if(ks.containsAlias(KEY_ALIAS))ks.deleteEntry(KEY_ALIAS);
        } catch(Throwable ignored) { }
    }
}
