package com.myshop.app;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Build;
import android.app.PictureInPictureParams;
import android.util.Rational;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.HorizontalScrollView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.TimeZone;

/**
 * MY SHOP V-350 Premium Audio Live Room with light right-action spacing and bottom safe-area protection.
 * V-305 visual host separation: Host is rendered in the dedicated top Host area; the approved 8 guest seats (2–9) are preserved unchanged.
 * The bundled Guitar Blue wallpaper is the safe default while Admin themes
 * can override it remotely without changing the Dashboard.
 */
public class AudioLiveRoomActivity extends AppCompatActivity {
    private final Handler handler = new Handler();
    private boolean host;
    private boolean hostStarted;
    private volatile boolean endLiveInProgress = false;
    private volatile boolean roomEnded = false;
    private boolean localMicOn = true;
    private boolean roomAdmin = false;
    private boolean canPinComments = false;
    private boolean listenOnly = false;
    private String hostId;
    private String specialGuestId = "";
    private String myRole = "AUDIENCE";
    private long startedAtMs = 0L;
    private String activeSessionId = "";
    private long serverElapsedSec = 0L;
    private long serverElapsedSyncMs = 0L;
    private boolean endedSummaryShown = false;
    private boolean commentSending = false;
    private float liveCommentFontSize=15.2f; private JSONObject globalCommentStyle=new JSONObject(); private final java.util.HashMap<String,JSONObject> commentPresets=new java.util.HashMap<>(); private final java.util.HashMap<String,JSONObject> commentAssignments=new java.util.HashMap<>();
    private final Map<String,String> pendingComments = new LinkedHashMap<>();
    private final Set<String> shownMilestones = new HashSet<>();
    private long lastEntryEventId = 0L;
    private long lastGiftEventId = 0L;
    private final Set<Long> renderedGiftEventIds = new HashSet<>();
    private final Set<Long> renderedCommentIds = new HashSet<>();
    private final Set<Long> renderedRoomEventIds = new HashSet<>();
    private final Set<Long> renderedHighlightCommentIds = new HashSet<>();
    private int shareCount = 0;
    private long reactCount = 0L;
    private ImageView wallpaper;
    private LinearLayout hostArea, audienceRow, specialArea, seats, requests, commentsList;
    private ScrollView commentScroll;
    private TextView viewers, status, syncState, durationView, roomTitle, roomTopic, pinnedView, shareView, reactView, premiumStrip, welcomeView, productView, pkView;
    private Button sendButton;
    private String currentLiveName = "Host";
    private final Set<Integer> lockedSeats = new HashSet<>();
    private JSONArray currentViewerProfiles = new JSONArray();
    private JSONArray currentTopSupporters = new JSONArray();
    private JSONObject currentHostStats = new JSONObject();
    private HorizontalScrollView audienceScroll;
    private TextView onlineCountView, topGiftView, topCoinView, topGoldView, topStarView;
    private JSONArray currentSeats = new JSONArray();
    private int currentSeatNo = 0;
    private final Map<String,Bitmap> avatarCache = new LinkedHashMap<>();
    private JSONArray currentRequests = new JSONArray();
    private int currentViewerCount = 0;
    private String lastInviteNotice = "";
    private String lastRequestNotice = "";
    private boolean inviteDialogOpen = false;
    private boolean requestDialogOpen = false;
    private String lastCommentsSignature = "";
    private int highlightPrice = 1000;
    private boolean highlightSelected = false;
    private long lastHighlightId = 0L;
    private TextView micButton, speakerActionButton;
    private ObjectAnimator joinPulseAlpha, joinPulseX, joinPulseY;
    private LinearLayout requestNoticeBar;
    private JSONObject cachedGiftCatalog;
    private long cachedGiftCatalogAt = 0L;
    private volatile boolean giftCatalogFetchInFlight = false;
    private AlertDialog giftLoadingDialog;
    private AlertDialog giftStoreDialog;
    private String giftReceiverId="",giftReceiverName="";
    private volatile boolean giftPollInFlight = false;
    private volatile boolean refreshInFlight = false;
    private volatile boolean realtimeInFlight = false;
    private int realtimeFailures = 0;
    private int realtimeRevision = 0;
    private long lastRealtimeCommentId = 0L;
    private long lastRealtimeHighlightId = 0L;
    private long lastRealtimeFallbackMs = 0L;
    private int myLevel = 0;
    private volatile boolean localSpeaking = false;
    private volatile boolean voiceMonitorRunning = false;
    private android.media.AudioRecord voiceRecorder;
    private Thread voiceThread;
    private long lastVoiceAboveMs = 0L;
    private boolean micPermissionAsked = false;
    private AgoraRtcManager rtcManager;
    private volatile String rtcDiagnosticStatus="RTC waiting";
    private volatile int activeRtcSpeakerUid=-1;
    private volatile long activeRtcSpeakerAt=0L;
    private boolean rtcJoinRequested=false;
    private String rtcRole="";

    // V-352: expensive full D1 room snapshots are no longer polled sub-second.
    // Realtime comments/gifts/control-dirty signals use the Durable Object hub.
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (roomEnded || endLiveInProgress) return;
            if (hostStarted || !host) refresh();
            if (!roomEnded && !endLiveInProgress) handler.postDelayed(this, 12000L);
        }
    };

    private final Runnable presenceTick = new Runnable() {
        @Override public void run() {
            if (roomEnded || endLiveInProgress) return;
            if (hostStarted || !host) {
                if (host) BackendClient.setLivePresence(token(), true, new Silent());
                else BackendClient.liveViewer(token(), hostId, true, new Silent());
            }
            if (!roomEnded && !endLiveInProgress) handler.postDelayed(this, 12000L);
        }
    };

    private final Runnable participantTick = new Runnable() {
        @Override public void run() {
            if (roomEnded || endLiveInProgress) return;
            if (hostStarted || !host) {
                if (host || "SPEAKER".equals(myRole)) {
                    BackendClient.liveParticipantState(token(), hostId, localMicOn, localSpeaking, networkQuality(), new Silent());
                }
            }
            if (!roomEnded && !endLiveInProgress) handler.postDelayed(this, 8000L);
        }
    };

    private final Runnable durationTick = new Runnable() {
        @Override public void run() {
            if (durationView != null && !activeSessionId.isEmpty()) {
                long sec = Math.max(0, serverElapsedSec + (System.currentTimeMillis() - serverElapsedSyncMs) / 1000L);
                durationView.setText(hhmmss(sec));
            }
            handler.postDelayed(this, 1000);
        }
    };

    private final Runnable realtimeTick = new Runnable() {
        @Override public void run() {
            if (roomEnded || endLiveInProgress) return;
            if (!activeSessionId.isEmpty() && !realtimeInFlight) {
                realtimeInFlight = true;
                final String expectedSession = activeSessionId;
                final int knownRevision = realtimeRevision;
                BackendClient.liveRealtime(token(), hostId, expectedSession, lastRealtimeCommentId, lastRealtimeHighlightId, lastGiftEventId, knownRevision, new BackendClient.Callback(){
                    public void onSuccess(JSONObject d){runOnUiThread(()->{
                        realtimeInFlight=false;
                        if(roomEnded||!expectedSession.equals(activeSessionId))return;
                        realtimeFailures=0;
                        String sid=d.optString("sessionId","");
                        if(!sid.isEmpty()&&!sid.equals(activeSessionId))return;
                        JSONArray cs=d.optJSONArray("comments"),hs=d.optJSONArray("highlights"),gs=d.optJSONArray("gifts");
                        if(cs!=null){for(int i=0;i<cs.length();i++){JSONObject c=cs.optJSONObject(i);if(c!=null)lastRealtimeCommentId=Math.max(lastRealtimeCommentId,c.optLong("id",0));}}
                        if(hs!=null){for(int i=0;i<hs.length();i++){JSONObject h=hs.optJSONObject(i);if(h!=null)lastRealtimeHighlightId=Math.max(lastRealtimeHighlightId,h.optLong("id",0));}}
                        renderComments(cs,null,hs);
                        renderGiftEvents(gs);
                        int revision=Math.max(0,d.optInt("revision",knownRevision));
                        boolean stateDirty=d.optBoolean("changed",false)&&revision>realtimeRevision;
                        realtimeRevision=revision;
                        if(stateDirty && System.currentTimeMillis()-lastRealtimeFallbackMs>900L){
                            lastRealtimeFallbackMs=System.currentTimeMillis();
                            refresh();
                        }
                    });}
                    public void onError(String m){runOnUiThread(()->{
                        realtimeInFlight=false;
                        realtimeFailures++;
                        long now=System.currentTimeMillis();
                        // Compatibility fallback if Worker has not yet been upgraded/deployed.
                        if(realtimeFailures>=3 && now-lastRealtimeFallbackMs>10000L){
                            lastRealtimeFallbackMs=now;
                            refresh();
                            if(!giftPollInFlight){
                                giftPollInFlight=true;
                                BackendClient.liveGiftEvents(token(),hostId,lastGiftEventId,new BackendClient.Callback(){
                                    public void onSuccess(JSONObject x){runOnUiThread(()->{giftPollInFlight=false;renderGiftEvents(x.optJSONArray("events"));});}
                                    public void onError(String e){giftPollInFlight=false;}
                                });
                            }
                        }
                    });}
                });
            }
            if (System.currentTimeMillis()-cachedGiftCatalogAt>60000L) prefetchGiftCatalog();
            handler.postDelayed(this, 650L);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        // V-353: Live voice and gift effects share the audible media output path.
        setVolumeControlStream(android.media.AudioManager.STREAM_MUSIC);
        host = getIntent().getBooleanExtra("hostMode", false);
        hostId = host ? SessionManager.getUserId(this) : getIntent().getStringExtra("hostId");
        if (hostId == null || hostId.trim().isEmpty()) hostId = SessionManager.getUserId(this);
        build();
        rtcManager=new AgoraRtcManager(new AgoraRtcManager.Listener(){
            public void onJoined(){rtcDiagnosticStatus="RTC connected";runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);});}
            public void onRemoteUserJoined(int uid){rtcDiagnosticStatus="RTC peer "+uid+" connected";runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);});}
            public void onRemoteAudioState(int uid,int state,int reason){rtcDiagnosticStatus="RTC remote audio uid="+uid+" state="+state+" reason="+reason;runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);});}
            public void onLocalAudioState(int state,int error){rtcDiagnosticStatus="RTC local audio state="+state+" error="+error;runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);});}
            public void onConnectionState(int state,int reason){rtcDiagnosticStatus="RTC connection state="+state+" reason="+reason;runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);});}
            public void onError(String m){rtcDiagnosticStatus=m;runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);});}
            public void onTokenWillExpire(){rtcDiagnosticStatus="RTC token renewing";runOnUiThread(()->requestRtcToken(true));}
            public void onAudioLevel(boolean speaking){localSpeaking=speaking;}
            public void onActiveSpeaker(int uid,int volume){activeRtcSpeakerUid=uid;activeRtcSpeakerAt=System.currentTimeMillis();}
        });
        try{rtcManager.init(this);}catch(Exception e){Toast.makeText(this,"RTC init failed",Toast.LENGTH_LONG).show();}
        loadCommentUi();
        renderLocalSkeleton();
        handler.post(durationTick);
        handler.post(realtimeTick);
        handler.post(presenceTick);
        handler.post(participantTick);
        prefetchGiftCatalog();
        if (host) showHostSetup();
        else {
            BackendClient.liveViewer(token(), hostId, true, new Silent());
            requestRtcToken(false);
            handler.post(tick);
        }
    }

    private void showHostSetup() {
        final android.app.Dialog d=new android.app.Dialog(this);
        LinearLayout box=col();box.setPadding(dp(20),dp(18),dp(20),dp(18));box.setBackground(bg(Color.rgb(10,18,58),Color.rgb(170,69,255),24));
        TextView hd=t("🎙  START AUDIO LIVE",18,Color.WHITE,true);hd.setGravity(Gravity.CENTER);box.addView(hd,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView sub=t("Create your MY SHOP audio room",10.5f,Color.rgb(188,202,244),false);sub.setGravity(Gravity.CENTER);box.addView(sub,new LinearLayout.LayoutParams(-1,dp(30)));
        EditText title=new EditText(this);title.setHint("Live Name");title.setText(SessionManager.getFullName(this).isEmpty()?"My Live":SessionManager.getFullName(this));title.setTextColor(Color.WHITE);title.setHintTextColor(Color.rgb(155,166,205));title.setSingleLine(true);title.setPadding(dp(14),0,dp(14),0);title.setBackground(bg(Color.rgb(17,31,79),Color.rgb(94,110,225),16));LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(50));tp.topMargin=dp(10);box.addView(title,tp);
        EditText topic=new EditText(this);topic.setHint("Caption");topic.setText("");topic.setTextColor(Color.WHITE);topic.setHintTextColor(Color.rgb(155,166,205));topic.setSingleLine(true);topic.setPadding(dp(14),0,dp(14),0);topic.setBackground(bg(Color.rgb(17,31,79),Color.rgb(94,110,225),16));LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,dp(50));op.topMargin=dp(10);box.addView(topic,op);
        LinearLayout actions=row();Button cancel=small("Cancel");cancel.setBackground(bg(Color.rgb(27,38,83),Color.rgb(96,111,185),18));Button go=btn("GO LIVE");go.setBackground(bg(Color.rgb(126,43,218),Color.rgb(255,71,192),18));cancel.setOnClickListener(v->{d.dismiss();finish();});go.setOnClickListener(v->{String t=title.getText().toString().trim(),p=topic.getText().toString().trim();if(t.isEmpty())t=SessionManager.getFullName(AudioLiveRoomActivity.this);if(t==null||t.trim().isEmpty())t="My Live";d.dismiss();startHostLive(t,p);});LinearLayout.LayoutParams c=new LinearLayout.LayoutParams(0,dp(46),.38f);c.rightMargin=dp(8);actions.addView(cancel,c);actions.addView(go,new LinearLayout.LayoutParams(0,dp(46),.62f));LinearLayout.LayoutParams ax=new LinearLayout.LayoutParams(-1,dp(46));ax.topMargin=dp(16);box.addView(actions,ax);
        d.setContentView(box);d.setCancelable(false);d.setOnShowListener(x->{android.view.Window w=d.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.72f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.88f),-2);}});d.show();
    }

    private void startHostLive(String title, String topic) {
        BackendClient.setLivePresence(token(), true, new BackendClient.Callback() {
            @Override public void onSuccess(JSONObject data) {
                hostStarted = true;
                BackendClient.liveRoomConfig(token(), title, topic, null, null, new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(() -> { syncState.setText("● LIVE • Room connected"); requestRtcToken(false); refresh(); handler.post(tick); });}public void onError(String e){BackendClient.setLivePresence(token(),false,new Silent());hostStarted=false;runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_LONG).show();showHostSetup();});}});
            }
            @Override public void onError(String m) { runOnUiThread(() -> { syncState.setText("Could not start live"); Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show(); }); }
        });
    }

    private void build() {
        FrameLayout page = new FrameLayout(this);
        wallpaper = new ImageView(this);
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        wallpaper.setImageResource(R.drawable.live_dark_lowlight_bg);
        page.addView(wallpaper, new FrameLayout.LayoutParams(-1,-1));

        // V-320 premium depth layer: visual polish only; guest-seat structure/logic remains untouched.
        View ambience=new View(this);
        ambience.setBackground(gradient(new int[]{Color.argb(150,8,16,58),Color.argb(92,69,24,126),Color.argb(120,5,20,54)},Color.TRANSPARENT,0));
        page.addView(ambience,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout root = col(); root.setPadding(dp(10), dp(4), dp(10), dp(10));
        root.setBackgroundColor(Color.TRANSPARENT);
        page.addView(root, new FrameLayout.LayoutParams(-1,-1));

        // V-292: preserve V-291 bottom safe-area and add only light spacing to right-side actions.
        // clearly above Android gesture/navigation controls on every device.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int navBottom = insets == null ? 0 : insets.getSystemWindowInsetBottom();
            root.setPadding(dp(10), dp(4), dp(10), Math.max(dp(8), navBottom + dp(6)));
            return insets;
        });
        root.post(root::requestApplyInsets);

        roomTitle = t("", 1, Color.TRANSPARENT, false);
        viewers = t("", 1, Color.TRANSPARENT, false); viewers.setVisibility(View.GONE);
        LinearLayout meta = row();
        status = t((host?"👑 Host":"🎧 Audience")+" • ID "+SessionManager.getUserId(this),11,Color.rgb(226,199,255),true);
        meta.addView(status,new LinearLayout.LayoutParams(0,dp(28),1));
        shareView=t("↗ 0",11,Color.rgb(226,199,255),true); shareView.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); meta.addView(shareView,new LinearLayout.LayoutParams(dp(70),dp(28)));
        meta.setVisibility(View.GONE); root.addView(meta,new LinearLayout.LayoutParams(1,1));
        syncState=t("",1,Color.TRANSPARENT,false); syncState.setVisibility(View.GONE); root.addView(syncState,new LinearLayout.LayoutParams(1,1));

        hostArea=col(); hostArea.setPadding(dp(7),dp(4),dp(7),dp(4)); hostArea.setBackground(PremiumUi.gradient(this,new int[]{Color.argb(215,13,30,82),Color.argb(195,74,36,137)},20,Color.TRANSPARENT,0));PremiumUi.premiumElevation(hostArea,3);
        audienceRow=row(); audienceRow.setGravity(Gravity.CENTER_VERTICAL);
        audienceScroll=new HorizontalScrollView(this); audienceScroll.setHorizontalScrollBarEnabled(false); audienceScroll.setFillViewport(false); audienceScroll.addView(audienceRow,new HorizontalScrollView.LayoutParams(-2,dp(76)));
        root.addView(hostArea,new LinearLayout.LayoutParams(-1,dp(138)));
        roomTopic = t("",1,Color.TRANSPARENT,false); roomTopic.setVisibility(View.GONE); root.addView(roomTopic,new LinearLayout.LayoutParams(1,1));
        specialArea=col(); specialArea.setGravity(Gravity.CENTER_HORIZONTAL); LinearLayout.LayoutParams sgp=new LinearLayout.LayoutParams(-1,-2); sgp.topMargin=dp(2); root.addView(specialArea,sgp);

        seats=col(); seats.setPadding(dp(2),dp(2),dp(2),dp(2)); seats.setBackgroundColor(Color.TRANSPARENT); root.addView(seats,new LinearLayout.LayoutParams(-1,-2));

        if(host){
            requestNoticeBar=row();
            requestNoticeBar.setGravity(Gravity.CENTER_VERTICAL);
            requestNoticeBar.setPadding(dp(8),dp(3),dp(6),dp(3));
            requestNoticeBar.setVisibility(View.GONE);
            requestNoticeBar.setBackground(gradient(new int[]{Color.argb(235,28,46,112),Color.argb(235,91,42,151)},Color.rgb(84,214,255),14));
            LinearLayout.LayoutParams rnp=new LinearLayout.LayoutParams(-1,dp(44)); rnp.topMargin=dp(2); rnp.bottomMargin=dp(2); root.addView(requestNoticeBar,rnp);
            requests=col(); requests.setVisibility(View.GONE); root.addView(requests,new LinearLayout.LayoutParams(1,1)); requests.addView(t("No pending requests",11,Color.LTGRAY,false));
        }

        pinnedView=t("📌 No pinned comment",13.8f,Color.rgb(255,224,138),true); pinnedView.setOnLongClickListener(v->{if(canPinComments){unpinComment();return true;}return false;}); pinnedView.setPadding(dp(10),dp(7),dp(10),dp(7)); pinnedView.setBackground(gradient(new int[]{Color.argb(205,74,26,119),Color.argb(205,26,35,88)},Color.rgb(255,199,80),14));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(42)); pp.topMargin=dp(3); root.addView(pinnedView,pp);

        premiumStrip=t("⚡ Live Room • Connecting…",9.3f,Color.WHITE,true);premiumStrip.setGravity(Gravity.CENTER_VERTICAL);premiumStrip.setSingleLine(true);premiumStrip.setEllipsize(android.text.TextUtils.TruncateAt.END);premiumStrip.setPadding(dp(8),0,dp(8),0);premiumStrip.setBackground(gradient(new int[]{Color.argb(165,21,56,122),Color.argb(165,91,42,151)},Color.argb(190,89,207,255),12));premiumStrip.setVisibility(View.GONE); root.addView(premiumStrip,new LinearLayout.LayoutParams(1,1));
        welcomeView=t("",9.4f,Color.rgb(255,231,166),true);welcomeView.setPadding(dp(8),0,dp(8),0);welcomeView.setGravity(Gravity.CENTER_VERTICAL);welcomeView.setVisibility(View.GONE);root.addView(welcomeView,new LinearLayout.LayoutParams(-1,dp(21)));
        productView=t("",9.5f,Color.WHITE,true);productView.setPadding(dp(8),0,dp(8),0);productView.setGravity(Gravity.CENTER_VERTICAL);productView.setBackground(bg(Color.argb(170,26,97,79),Color.rgb(80,234,165),11));productView.setVisibility(View.GONE);productView.setOnClickListener(v->startActivity(new Intent(this,StoreActivity.class)));root.addView(productView,new LinearLayout.LayoutParams(-1,dp(22)));
        pkView=t("",9.6f,Color.WHITE,true);pkView.setPadding(dp(8),0,dp(8),0);pkView.setGravity(Gravity.CENTER_VERTICAL);pkView.setBackground(gradient(new int[]{Color.argb(190,151,31,76),Color.argb(190,67,41,185)},Color.rgb(255,92,159),11));pkView.setVisibility(View.GONE);root.addView(pkView,new LinearLayout.LayoutParams(-1,dp(22)));

        TextView chatTitle=t("",1,Color.TRANSPARENT,false); chatTitle.setVisibility(View.GONE); root.addView(chatTitle,new LinearLayout.LayoutParams(1,1));
        FrameLayout commentStage=new FrameLayout(this); commentStage.setBackgroundColor(Color.TRANSPARENT);
        commentScroll=new ScrollView(this); commentScroll.setVerticalScrollBarEnabled(false); commentScroll.setFillViewport(true); commentsList=col(); commentsList.setPadding(dp(5),dp(2),dp(5),dp(2)); commentsList.setBackgroundColor(Color.TRANSPARENT); commentScroll.setBackgroundColor(Color.TRANSPARENT); commentScroll.addView(commentsList);
        FrameLayout.LayoutParams csp=new FrameLayout.LayoutParams(-1,-1); csp.rightMargin=dp(48); commentStage.addView(commentScroll,csp);
        LinearLayout floating=col(); floating.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView request=t("✋",18,Color.WHITE,true); request.setGravity(Gravity.CENTER); request.setClickable(true); request.setFocusable(true); request.setElevation(dp(6)); request.setBackground(bg(Color.argb(220,18,49,118),Color.rgb(69,208,255),21)); PremiumUi.press(request); request.setOnClickListener(v->{if(host)showJoinRequestsDialog();else requestJoinToCall();}); floating.addView(request,new LinearLayout.LayoutParams(dp(42),dp(42))); request.bringToFront();
        TextView gift=t("🎁",19,Color.WHITE,true); gift.setGravity(Gravity.CENTER); gift.setClickable(true); gift.setFocusable(true); gift.setElevation(dp(6)); gift.setBackground(bg(Color.argb(220,80,37,138),Color.rgb(255,195,72),21)); PremiumUi.press(gift); gift.setOnClickListener(v->showGiftPanel()); LinearLayout.LayoutParams gfp=new LinearLayout.LayoutParams(dp(42),dp(42)); gfp.topMargin=dp(8); floating.addView(gift,gfp); gift.bringToFront();
        reactView=t("❤️",16,Color.WHITE,true); reactView.setGravity(Gravity.CENTER); reactView.setBackground(bg(Color.argb(220,111,22,125),Color.rgb(255,74,189),21)); PremiumUi.press(reactView); reactView.setOnClickListener(v->{BackendClient.liveReact(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{reactCount=d.optLong("reactCount",0);reactView.setText("❤️\n"+compact(reactCount));if(d.optInt("rewardCoin",0)>0&&host)Toast.makeText(AudioLiveRoomActivity.this,"React reward +"+d.optInt("rewardCoin")+" Coin",Toast.LENGTH_LONG).show();showReaction();});}public void onError(String e){runOnUiThread(()->showReaction());}});}); LinearLayout.LayoutParams frp=new LinearLayout.LayoutParams(dp(42),dp(42)); frp.topMargin=dp(8); floating.addView(reactView,frp);
        TextView share=t("↗",18,Color.WHITE,true); share.setGravity(Gravity.CENTER); share.setBackground(bg(Color.argb(220,15,59,118),Color.rgb(42,206,255),21)); PremiumUi.press(share); share.setOnClickListener(v->shareRoom()); LinearLayout.LayoutParams sfp=new LinearLayout.LayoutParams(dp(42),dp(42)); sfp.topMargin=dp(8); floating.addView(share,sfp);
        FrameLayout.LayoutParams fap=new FrameLayout.LayoutParams(dp(42),dp(192),Gravity.RIGHT|Gravity.BOTTOM); fap.rightMargin=dp(1); fap.bottomMargin=dp(2); commentStage.addView(floating,fap);
        root.addView(commentStage,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout sendRow=row(); sendRow.setGravity(Gravity.CENTER_VERTICAL); sendRow.setPadding(dp(4),dp(3),dp(4),dp(3)); sendRow.setBackground(PremiumUi.gradient(this,new int[]{Color.argb(185,9,24,69),Color.argb(175,74,38,125)},20,Color.argb(120,116,139,230),1));PremiumUi.premiumElevation(sendRow,3);
        FrameLayout commentBox=new FrameLayout(this);
        EditText commentInput=new EditText(this); commentInput.setHint("Write a comment…"); commentInput.setTextColor(Color.WHITE); commentInput.setHintTextColor(Color.rgb(155,165,195)); commentInput.setSingleLine(true); commentInput.setTextSize(11); commentInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_SHORT_MESSAGE); commentInput.setBackground(bg(Color.argb(170,10,24,61),Color.rgb(67,91,171),17)); commentInput.setPadding(dp(10),0,dp(38),0); commentBox.addView(commentInput,new FrameLayout.LayoutParams(-1,-1));
        TextView highlight=t("✨",15,Color.rgb(255,219,96),true); highlight.setGravity(Gravity.CENTER); FrameLayout.LayoutParams hlp=new FrameLayout.LayoutParams(dp(36),-1,Gravity.RIGHT); commentBox.addView(highlight,hlp);
        highlight.setOnClickListener(v->{highlightSelected=!highlightSelected;highlight.setBackground(highlightSelected?bg(Color.argb(170,112,48,170),Color.rgb(255,216,89),15):null);Toast.makeText(this,highlightSelected?"Highlight ON • "+highlightPrice+" Coin":"Highlight OFF",Toast.LENGTH_SHORT).show();});
        BackendClient.liveHighlightConfig(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{highlightPrice=d.optInt("coinPrice",1000);if(d.optBoolean("free",false))highlightPrice=0;});}public void onError(String e){}});
        sendButton=small("Send"); sendButton.setTextSize(9.5f); sendButton.setBackground(PremiumUi.gradient(this,new int[]{Color.rgb(45,113,245),Color.rgb(103,63,229)},16,Color.argb(120,255,255,255),1)); PremiumUi.press(sendButton); sendButton.setOnClickListener(v->sendLiveComment(commentInput,highlight));
        micButton=t("🎙",17,Color.WHITE,true); micButton.setGravity(Gravity.CENTER); micButton.setBackground(gradient(new int[]{Color.rgb(22,68,187),Color.rgb(67,42,214)},Color.rgb(42,232,255),18)); PremiumUi.press(micButton); micButton.setOnClickListener(v->toggleMic()); updateLocalMicUi();
        speakerActionButton=t(host?"End":"Join",11,Color.WHITE,true); speakerActionButton.setGravity(Gravity.CENTER); speakerActionButton.setBackground(gradient(new int[]{Color.rgb(110,37,224),Color.rgb(242,45,206)},Color.rgb(255,132,245),18)); PremiumUi.press(speakerActionButton); speakerActionButton.setOnClickListener(v->{if(host){confirmEndLive();return;}if("SPEAKER".equals(myRole)){confirmLeaveSeat();return;}if(listenOnly){showFloatingBanner("🔇 Listen-only mode");return;}requestJoinToCall();});
        LinearLayout.LayoutParams cip=new LinearLayout.LayoutParams(0,dp(38),1); cip.rightMargin=dp(4); sendRow.addView(commentBox,cip);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(58),dp(38)); sp.rightMargin=dp(4); sendRow.addView(sendButton,sp);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(dp(48),dp(38)); mp.rightMargin=dp(4); sendRow.addView(micButton,mp);
        speakerActionButton.setElevation(dp(4));
        sendRow.addView(speakerActionButton,new LinearLayout.LayoutParams(dp(70),dp(38)));
        updateJoinButtonAnimation();
        LinearLayout.LayoutParams srp=new LinearLayout.LayoutParams(-1,dp(44)); srp.topMargin=dp(4); srp.bottomMargin=dp(2); root.addView(sendRow,srp);
        
        setContentView(page);
    }

    private void addControls(LinearLayout root){
        LinearLayout bottom=row(); bottom.setGravity(Gravity.CENTER_VERTICAL);
        String[] labels=host?new String[]{"🎙","➕","🪑","📌","↗","⚙"}:new String[]{"✋","➕","💬","📩","↗","⚙"};
        for(int i=0;i<labels.length;i++){final int idx=i;TextView v=t(labels[i],16,Color.WHITE,true);v.setGravity(Gravity.CENTER);v.setBackground(PremiumUi.gradient(this,new int[]{Color.argb(215,18,38,96),Color.argb(215,79,44,154)},18,Color.argb(135,109,205,255),1));PremiumUi.press(v);v.setOnClickListener(x->handleCompactControl(idx));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(40),1);lp.setMargins(dp(2),0,dp(2),0);bottom.addView(v,lp);}
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(42)); bp.topMargin=dp(3); root.addView(bottom,bp);
    }

    private void handleCompactControl(int i){
        if(host){if(i==0)toggleMic();else if(i==1)showAudienceList();else if(i==2)Toast.makeText(this,"Tap a sofa to lock/unlock or manage speaker",Toast.LENGTH_SHORT).show();else if(i==3)editPinned();else if(i==4)shareRoom();else if(i==5)showHostRoomMenu();}
        else{if(i==0)BackendClient.liveSpeakRequest(token(),hostId,new ToastCb("Request sent"));else if(i==1)BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));else if(i==2)Toast.makeText(this,"Live chat is above",Toast.LENGTH_SHORT).show();else if(i==3)Toast.makeText(this,"Open Inbox",Toast.LENGTH_SHORT).show();else if(i==4)shareRoom();else showLiveCommunityMenu();}
    }

    private void showHostRoomMenu(){String[] a={"Theme","Live Name / Caption","Pinned announcement","Welcome / Rules","Live Goal","Pin Shop Item","Top Supporters / Fan Club","Creator Center","Schedule Live","PK / Battle","End Live"};new AlertDialog.Builder(this).setTitle("Host Room Controls • V-304").setItems(a,(d,w)->{if(w==0)chooseTheme();else if(w==1)editRoomInfo();else if(w==2)editPinned();else if(w==3)editWelcome();else if(w==4)editGoal();else if(w==5)choosePinnedProduct();else if(w==6)showFanClub();else if(w==7)openCreatorCenter(hostId);else if(w==8)showScheduleDialog();else if(w==9)showPkDialog();else confirmEndLive();}).show();}

    private void handleControl(int i){
        if(host){
            if(i==0) toggleMic(); else if(i==2) Toast.makeText(this,"Tap any sofa to lock/unlock or manage speaker",Toast.LENGTH_SHORT).show();
            else if(i==3) editPinned(); else if(i==4) chooseTheme(); else if(i==5) shareRoom(); else if(i==6) showReaction(); else if(i==7) editRoomInfo();
            else Toast.makeText(this,"Host control ready",Toast.LENGTH_SHORT).show();
        } else {
            if(i==0) toggleMic(); else if(i==1) BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));
            else if(i==3) showReaction(); else if(i==5) shareRoom(); else Toast.makeText(this,"Live control",Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleMic(){
        localMicOn=!localMicOn;
        if(!localMicOn)localSpeaking=false;
        updateLocalMicUi();
        updateVoiceMonitor();
        if(rtcManager!=null)rtcManager.setMicEnabled(localMicOn&&(host||"SPEAKER".equals(myRole))&&!listenOnly);
        BackendClient.liveParticipantState(token(),hostId,localMicOn,localSpeaking,networkQuality(),new ToastCb(localMicOn?"Mic on":"Mic muted"));
    }

    private void updateLocalMicUi(){
        if(micButton==null)return;
        if(localMicOn){
            micButton.setText("🎙");
            micButton.setTextColor(Color.WHITE);
            micButton.setBackground(gradient(new int[]{Color.rgb(22,68,187),Color.rgb(67,42,214)},Color.rgb(42,232,255),18));
        }else{
            micButton.setText("🎙✕");
            micButton.setTextColor(Color.rgb(255,92,92));
            micButton.setBackground(gradient(new int[]{Color.rgb(92,24,48),Color.rgb(132,28,55)},Color.rgb(255,76,92),18));
        }
    }

    private void updateVoiceMonitor(){
        boolean publish=(host||"SPEAKER".equals(myRole))&&!listenOnly;
        stopVoiceMonitor(false); // Agora owns microphone capture; never open a competing AudioRecord.
        if(rtcManager!=null){rtcManager.setPublishAudio(publish);rtcManager.setMicEnabled(publish&&localMicOn);}
        if(!publish)localSpeaking=false;
    }

    private void startVoiceMonitor(){ updateVoiceMonitor(); }
    private void stopVoiceMonitor(boolean publish){
        voiceMonitorRunning=false;localSpeaking=false;
        try{if(voiceRecorder!=null){voiceRecorder.stop();voiceRecorder.release();}}catch(Exception ignored){}
        voiceRecorder=null;voiceThread=null;
    }

    private boolean ensureRtcMicPermission(){
        boolean publish=(host||"SPEAKER".equals(myRole))&&!listenOnly;
        if(!publish)return true;
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},9021);
            if(syncState!=null)syncState.setText("● LIVE • Allow microphone to connect audio");
            return false;
        }
        return true;
    }

    private void requestRtcToken(boolean renew){
        if(roomEnded||endLiveInProgress||hostId==null||hostId.isEmpty()||rtcManager==null)return;
        if(!ensureRtcMicPermission())return;
        if(rtcJoinRequested&&!renew)return;
        rtcJoinRequested=true;
        BackendClient.agoraRtcToken(token(),hostId,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                rtcJoinRequested=false;String t=d.optString("token","");String ch=d.optString("channel","");int uid=d.optInt("uid",0);String role=d.optString("role","AUDIENCE");
                boolean publish="PUBLISHER".equals(role)&&!listenOnly;rtcRole=role;
                if(renew){rtcManager.renewToken(t);rtcDiagnosticStatus="RTC token renewed";}else{int rc=rtcManager.join(t,ch,uid,publish);rtcDiagnosticStatus=(rc==0?"RTC joining ch="+ch+" uid="+uid+" role="+role:"RTC join failed rc="+rc);}
                rtcManager.setMicEnabled(publish&&localMicOn);
            });}
            public void onError(String m){rtcJoinRequested=false;runOnUiThread(()->{rtcDiagnosticStatus="RTC token unavailable: "+m;if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);});}
        });
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==9021 && grantResults.length>0 && grantResults[0]==android.content.pm.PackageManager.PERMISSION_GRANTED){updateVoiceMonitor();requestRtcToken(false);}
        else if(requestCode==9021){Toast.makeText(this,"Microphone permission is required to speak in Live",Toast.LENGTH_LONG).show();}
    }

    private void loadCommentUi(){BackendClient.liveCommentUi(token(),new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{globalCommentStyle=o.optJSONObject("globalStyle");if(globalCommentStyle==null)globalCommentStyle=new JSONObject();liveCommentFontSize=(float)Math.max(12,Math.min(28,globalCommentStyle.optInt("fontSize",15)));commentPresets.clear();JSONArray p=o.optJSONArray("presets");if(p!=null)for(int i=0;i<p.length();i++){JSONObject x=p.optJSONObject(i);if(x!=null&&!x.optString("presetKey","").isEmpty())commentPresets.put(x.optString("presetKey"),x);}commentAssignments.clear();JSONArray a=o.optJSONArray("assignments");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&x.optBoolean("enabled",true)&&!x.optString("userId","").isEmpty())commentAssignments.put(x.optString("userId"),x);}});}public void onError(String m){}});}
    private JSONObject commentStyleFor(String userId){JSONObject a=commentAssignments.get(userId);if(a!=null){if(a.optBoolean("isCustom",false)){JSONObject c=a.optJSONObject("customStyle");if(c!=null)return c;}String key=a.optString("presetKey","");JSONObject p=commentPresets.get(key);if(p!=null)return p;}return globalCommentStyle==null?new JSONObject():globalCommentStyle;}
    private int commentColor(JSONObject s,String k,int fallback){try{return Color.parseColor(s.optString(k,""));}catch(Exception e){return fallback;}}
    private android.graphics.drawable.Drawable commentStyleDrawable(JSONObject s){int fill=commentColor(s,"backgroundColor",Color.rgb(10,24,65)),stroke=commentColor(s,"borderColor",Color.rgb(75,103,189));int op=Math.max(30,Math.min(100,s.optInt("opacity",92)));fill=Color.argb((int)(255*(op/100f)),Color.red(fill),Color.green(fill),Color.blue(fill));int radius=Math.max(4,Math.min(30,s.optInt("cornerRadius",14))),width=Math.max(0,Math.min(6,s.optInt("borderWidth",1)));android.graphics.drawable.GradientDrawable inner=new android.graphics.drawable.GradientDrawable();inner.setColor(fill);inner.setCornerRadius(dp(radius));if(width>0)inner.setStroke(dp(width),stroke);if(!s.optBoolean("borderGlow",false))return inner;int gc=commentColor(s,"borderGlowColor",Color.rgb(168,85,247)),gi=Math.max(0,Math.min(100,s.optInt("borderGlowIntensity",55)));gc=Color.argb(Math.max(30,(int)(255*(gi/100f))),Color.red(gc),Color.green(gc),Color.blue(gc));android.graphics.drawable.GradientDrawable outer=new android.graphics.drawable.GradientDrawable();outer.setColor(Color.TRANSPARENT);outer.setCornerRadius(dp(radius+3));outer.setStroke(dp(Math.max(2,width+2)),gc);android.graphics.drawable.LayerDrawable layers=new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{outer,inner});layers.setLayerInset(1,dp(3),dp(3),dp(3),dp(3));return layers;}
    private void applyCommentStyle(TextView row,String userId){JSONObject s=commentStyleFor(userId);row.setTextSize((float)Math.max(12,Math.min(28,s.optInt("fontSize",15))));row.setTextColor(commentColor(s,"textColor",Color.WHITE));row.setTypeface(Typeface.DEFAULT,"BOLD".equalsIgnoreCase(s.optString("fontWeight","NORMAL"))?Typeface.BOLD:Typeface.NORMAL);row.setBackground(commentStyleDrawable(s));row.setElevation(dp(s.optBoolean("backgroundGlow",false)?5:1));boolean any=s.optBoolean("animation",false)||s.optBoolean("boxAnimation",false)||s.optBoolean("borderAnimation",false)||s.optBoolean("textAnimation",false)||s.optBoolean("nameAnimation",false)||s.optBoolean("levelAnimation",false);if(any){long d=Math.max(220,1200-(Math.max(10,Math.min(100,s.optInt("animationSpeed",55)))*8L));String type=s.optBoolean("boxAnimation",false)?s.optString("boxAnimationType",s.optString("animationType","FADE")):s.optString("animationType","FADE");android.view.animation.Animation a;if("POP".equalsIgnoreCase(type)){a=new android.view.animation.ScaleAnimation(.92f,1f,.92f,1f,android.view.animation.Animation.RELATIVE_TO_SELF,.5f,android.view.animation.Animation.RELATIVE_TO_SELF,.5f);}else{a=new android.view.animation.AlphaAnimation(.62f,1f);}a.setDuration(d);a.setRepeatMode(android.view.animation.Animation.REVERSE);a.setRepeatCount(1);row.startAnimation(a);if(s.optBoolean("borderAnimation",false))row.animate().translationZ(dp(4)).setDuration(d/2).withEndAction(()->row.animate().translationZ(0).setDuration(d/2).start()).start();}}

    private void pinCommentText(String text){if(!canPinComments)return;new AlertDialog.Builder(this).setTitle("📌 Pin this comment?").setMessage(text).setPositiveButton("PIN",(d,w)->BackendClient.livePinnedMessage(token(),hostId,text,new ToastCb("Comment pinned"))).setNegativeButton("Cancel",null).show();}
    private void unpinComment(){if(!canPinComments)return;BackendClient.livePinnedMessage(token(),hostId,"",new ToastCb("Comment unpinned"));}

    private void editPinned(){EditText e=new EditText(this);e.setHint("Pinned announcement");new AlertDialog.Builder(this).setTitle("Pinned message").setView(e).setPositiveButton("Save",(d,w)->BackendClient.liveRoomConfig(token(),null,null,e.getText().toString().trim(),null,new ToastCb("Pinned message updated"))).setNegativeButton("Cancel",null).show();}
    private void editRoomInfo(){LinearLayout b=col();EditText t1=new EditText(this);t1.setHint("Live Name");t1.setText(currentLiveName);EditText t2=new EditText(this);t2.setHint("Caption");t2.setText(roomTopic.getText());b.addView(t1);b.addView(t2);TextView note=t("Live Name: 24 ঘণ্টায় ১বার ফ্রি • আগে বদলালে 5,000 Coin. ID কখনো বদলাবে না।",10,Color.DKGRAY,false);b.addView(note);new AlertDialog.Builder(this).setTitle("Live Name & Caption").setView(b).setPositiveButton("Save",(d,w)->BackendClient.liveRoomConfig(token(),t1.getText().toString(),t2.getText().toString(),null,null,new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,"Live info updated",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String e){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_LONG).show());}})).setNegativeButton("Cancel",null).show();}
    private void editCaptionOnly(){final EditText e=new EditText(this);e.setHint("Caption");e.setSingleLine(true);e.setText(roomTopic.getText());new AlertDialog.Builder(this).setTitle("Edit Caption").setView(e).setPositiveButton("Save",(d,w)->BackendClient.liveRoomConfig(token(),null,e.getText().toString(),null,null,new ToastCb("Caption updated"))).setNegativeButton("Cancel",null).show();}

    private void chooseTheme(){BackendClient.liveThemes(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("themes");if(a==null||a.length()==0){Toast.makeText(AudioLiveRoomActivity.this,"No enabled themes",Toast.LENGTH_SHORT).show();return;}String[] names=new String[a.length()];String[] keys=new String[a.length()];for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);names[i]=x==null?"Theme":x.optString("name","Theme");keys[i]=x==null?"GUITAR_BLUE":x.optString("theme_key","GUITAR_BLUE");}new AlertDialog.Builder(AudioLiveRoomActivity.this).setTitle("Live Theme").setItems(names,(q,which)->BackendClient.liveRoomConfig(token(),null,null,null,keys[which],new ToastCb("Theme changed"))).show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}

    private void shareRoom(){BackendClient.liveShare(token(),hostId,new Silent()); Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,"Join my MY SHOP Audio Live • Host ID "+hostId);startActivity(Intent.createChooser(send,"Share Live"));}

    private void showReaction(){
        if(commentsList==null)return;
        TextView r=t("❤️",28,Color.WHITE,true);
        r.setGravity(Gravity.CENTER);
        commentsList.addView(r,0,new LinearLayout.LayoutParams(-1,dp(42)));
        r.setAlpha(.2f);
        r.setTranslationY(dp(20));
        r.animate().alpha(1f).translationY(0).setDuration(220).withEndAction(() -> {
            r.animate().alpha(0f).translationY(-dp(20)).setDuration(650).withEndAction(() -> commentsList.removeView(r)).start();
        }).start();
    }

    private void showUserModeration(JSONObject u){
        String uid=u.optString("user_id","");if(uid.isEmpty()||uid.equals(hostId))return;
        String[] actions=host?new String[]{"📞 Invite to Call","Kick from Live","Mute • listen/gift only","Unmute","Block from this Live","Add as Room Admin","Remove Room Admin","⚑ Report / Block Account"}:new String[]{"Mute • listen/gift only","Unmute","⚑ Report / Block Account"};
        new AlertDialog.Builder(this).setTitle(u.optString("full_name","User")+" • ID "+uid).setItems(actions,(d,w)->{if(host&&w==0){inviteToCall(u);return;}if((host&&w==7)||(!host&&w==2)){SafetyActions.show(this,uid,"LIVE_USER",hostId);return;}int idx=host?w-1:w;String a=host?new String[]{"KICK","MUTE","UNMUTE","BLOCK","ADD_ROOM_ADMIN","REMOVE_ROOM_ADMIN"}[idx]:(idx==0?"MUTE":"UNMUTE");BackendClient.liveModeration(token(),hostId,uid,a,new ToastCb("Moderation updated"));}).setNegativeButton("Close",null).show();
    }

    private void prefetchGiftCatalog(){
        if(giftCatalogFetchInFlight)return;giftCatalogFetchInFlight=true;
        BackendClient.liveGifts(token(),new BackendClient.Callback(){public void onSuccess(JSONObject o){cachedGiftCatalog=o;cachedGiftCatalogAt=System.currentTimeMillis();giftCatalogFetchInFlight=false;}public void onError(String m){giftCatalogFetchInFlight=false;}});
    }

    private void showGiftPanel(){
        if(giftReceiverId.isEmpty()||giftReceiverId.equals(SessionManager.getUserId(this))){giftReceiverId="";giftReceiverName="";if(!hostId.equals(SessionManager.getUserId(this))){giftReceiverId=hostId;giftReceiverName="Host";}else{for(int si=2;si<=9;si++){JSONObject su=findSeat(currentSeats,si);if(su!=null&&!su.optString("user_id","").equals(SessionManager.getUserId(this))){giftReceiverId=su.optString("user_id","");giftReceiverName=su.optString("full_name","User");break;}}}if(giftReceiverId.isEmpty()){Toast.makeText(this,"No eligible gift recipient",Toast.LENGTH_SHORT).show();return;}}
        long age=System.currentTimeMillis()-cachedGiftCatalogAt;
        if(cachedGiftCatalog!=null&&age<10000L){openGiftChart(cachedGiftCatalog);prefetchGiftCatalog();return;}
        if(giftLoadingDialog!=null&&giftLoadingDialog.isShowing())return;
        LinearLayout loading=col();loading.setPadding(dp(18),dp(14),dp(18),dp(14));loading.setBackground(bg(Color.rgb(13,14,38),Color.rgb(112,71,225),20));
        TextView title=t("🎁  LIVE GIFT STORE",16,Color.WHITE,true);loading.addView(title,new LinearLayout.LayoutParams(-1,dp(34)));
        TextView msg=t("Syncing current Admin prices & gift settings…",11.5f,Color.rgb(205,207,239),false);loading.addView(msg,new LinearLayout.LayoutParams(-1,dp(38)));
        giftLoadingDialog=new AlertDialog.Builder(this).setView(loading).setNegativeButton("Close",null).create();giftLoadingDialog.show();
        BackendClient.liveGifts(token(),new BackendClient.Callback(){
            public void onSuccess(JSONObject o){runOnUiThread(()->{cachedGiftCatalog=o;cachedGiftCatalogAt=System.currentTimeMillis();if(giftLoadingDialog!=null&&giftLoadingDialog.isShowing())giftLoadingDialog.dismiss();giftLoadingDialog=null;if(!isFinishing())openGiftChart(o);});}
            public void onError(String m){runOnUiThread(()->{if(giftLoadingDialog!=null&&giftLoadingDialog.isShowing())giftLoadingDialog.dismiss();giftLoadingDialog=null;Toast.makeText(AudioLiveRoomActivity.this,"Could not sync current gift prices. "+m,Toast.LENGTH_LONG).show();});}
        });
    }
    private void openGiftChart(JSONObject o){
        if(giftStoreDialog!=null&&giftStoreDialog.isShowing())giftStoreDialog.dismiss();
        final JSONArray gifts=o.optJSONArray("gifts")==null?new JSONArray():o.optJSONArray("gifts");
        LinearLayout box=col();box.setPadding(dp(10),dp(8),dp(10),dp(10));box.setBackground(gradient(new int[]{Color.rgb(10,12,34),Color.rgb(31,20,71),Color.rgb(16,18,52)},Color.rgb(121,78,236),22));
        LinearLayout giftHead=row();giftHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=t("🎁  SEND A GIFT",17,Color.WHITE,true);title.setGravity(Gravity.CENTER);giftHead.addView(title,new LinearLayout.LayoutParams(0,dp(40),1));
        TextView closeGift=t("✕",17,Color.rgb(235,229,255),true);closeGift.setGravity(Gravity.CENTER);closeGift.setBackground(bg(Color.argb(120,79,57,145),Color.argb(180,150,119,240),17));giftHead.addView(closeGift,new LinearLayout.LayoutParams(dp(38),dp(38)));
        box.addView(giftHead,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView sub=t("Tap a gift once → press Send",10,Color.rgb(207,207,239),false);sub.setGravity(Gravity.CENTER);box.addView(sub,new LinearLayout.LayoutParams(-1,dp(21)));
        TextView balance=t("🪙 Coin  "+o.optLong("coinBalance",0)+"      👑 Gold Coin  "+o.optLong("goldBalance",0),12,Color.WHITE,true);balance.setGravity(Gravity.CENTER);balance.setBackground(bg(Color.argb(130,58,44,130),Color.argb(190,135,92,235),14));box.addView(balance,new LinearLayout.LayoutParams(-1,dp(42)));
        final TextView receiver=t("🎯 Sending to: "+(giftReceiverName.isEmpty()?giftReceiverId:giftReceiverName)+" • ID "+giftReceiverId,10.5f,Color.WHITE,true);receiver.setGravity(Gravity.CENTER);receiver.setPadding(dp(6),0,dp(6),0);receiver.setBackground(bg(Color.argb(150,15,65,83),Color.argb(200,70,220,255),12));receiver.setOnClickListener(v->{java.util.ArrayList<JSONObject> choices=new java.util.ArrayList<>();JSONObject hu=findSeat(currentSeats,1);if(hu!=null&&!hostId.equals(SessionManager.getUserId(this)))choices.add(hu);for(int si=2;si<=9;si++){JSONObject su=findSeat(currentSeats,si);if(su!=null&&!su.optString("user_id","").equals(SessionManager.getUserId(this)))choices.add(su);}if(choices.isEmpty()){Toast.makeText(this,"No eligible gift recipient",Toast.LENGTH_SHORT).show();return;}String[] labels=new String[choices.size()];for(int k=0;k<choices.size();k++){JSONObject cu=choices.get(k);labels[k]=cu.optString("full_name","User")+" • ID "+cu.optString("user_id","");}new AlertDialog.Builder(this).setTitle("Send Gift To").setItems(labels,(dd,which)->{JSONObject cu=choices.get(which);giftReceiverId=cu.optString("user_id",hostId);giftReceiverName=cu.optString("full_name","User");receiver.setText("🎯 Sending to: "+giftReceiverName+" • ID "+giftReceiverId);}).setNegativeButton("Cancel",null).show();});box.addView(receiver,new LinearLayout.LayoutParams(-1,dp(40)));

        LinearLayout tabs=row();Button coin=small("🪙 Gift Coin"),gold=small("👑 Gold Coin");coin.setBackground(bg(Color.rgb(93,53,202),Color.rgb(176,101,255),16));gold.setBackground(bg(Color.rgb(135,89,30),Color.rgb(245,179,60),16));tabs.addView(coin,new LinearLayout.LayoutParams(0,dp(44),1));tabs.addView(gold,new LinearLayout.LayoutParams(0,dp(44),1));box.addView(tabs);

        ScrollView sc=new ScrollView(this);final GridLayout grid=new GridLayout(this);grid.setColumnCount(3);grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);grid.setPadding(dp(1),dp(7),dp(1),dp(7));sc.setFillViewport(false);sc.addView(grid);box.addView(sc,new LinearLayout.LayoutParams(-1,dp(300)));
        final Map<ImageView,JSONObject> catalogAnimConfigs=new LinkedHashMap<>();
        final Map<ImageView,TextView> catalogSparkles=new LinkedHashMap<>();

        LinearLayout selectedBar=row();selectedBar.setPadding(dp(10),dp(6),dp(10),dp(6));selectedBar.setBackground(bg(Color.argb(200,30,27,78),Color.rgb(109,79,210),16));
        final TextView selectedText=t("Select a gift",11.5f,Color.WHITE,true);selectedText.setGravity(Gravity.CENTER_VERTICAL);selectedBar.addView(selectedText,new LinearLayout.LayoutParams(0,dp(52),1));
        final Button sendButton=small("SEND");sendButton.setEnabled(false);sendButton.setAlpha(.48f);sendButton.setTextSize(12);sendButton.setBackground(gradient(new int[]{Color.rgb(238,63,153),Color.rgb(116,75,239)},Color.rgb(255,180,225),18));selectedBar.addView(sendButton,new LinearLayout.LayoutParams(dp(104),dp(48)));box.addView(selectedBar,new LinearLayout.LayoutParams(-1,dp(60)));

        final String[] currency={"COIN"};final JSONObject[] chosen={null};final View[] chosenTile={null};
        final Runnable[] renderHolder=new Runnable[1];
        renderHolder[0]=()->{
            for(ImageView oldArt:catalogAnimConfigs.keySet())CatalogGiftAnimator.stop(oldArt,catalogSparkles.get(oldArt));
            catalogAnimConfigs.clear();catalogSparkles.clear();grid.removeAllViews();chosen[0]=null;chosenTile[0]=null;sendButton.setEnabled(false);sendButton.setAlpha(.48f);sendButton.setText("SEND");selectedText.setText("Select a gift");
            boolean isCoin="COIN".equals(currency[0]);coin.setAlpha(isCoin?1f:.55f);gold.setAlpha(isCoin ? .55f : 1f);
            int count=0;
            for(int i=0;i<gifts.length();i++){
                final JSONObject g=gifts.optJSONObject(i);if(g==null||!currency[0].equals(g.optString("currency")))continue;count++;
                final LinearLayout tile=col();tile.setGravity(Gravity.CENTER);tile.setPadding(dp(5),dp(5),dp(5),dp(5));tile.setBackground(giftTileBg(false,"GOLD".equals(currency[0])));tile.setElevation(dp(1));
                FrameLayout iconBox=new FrameLayout(this);iconBox.setClipChildren(false);tile.setClipChildren(false);ImageView icon=new ImageView(this);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                String catalogAsset=g.optString("catalog_animation_url","").trim();String preview=g.optString("preview_url","").trim();if(preview.isEmpty())preview=g.optString("animation_url","").trim();
                if(!catalogAsset.isEmpty())AnimatedAssetLoader.load(icon,catalogAsset,false);else if(!preview.isEmpty())loadImage(icon,preview);else icon.setImageResource(builtInGiftArt(g.optString("name","Gift")));
                int previewDp=CatalogGiftAnimator.iconDp(g);FrameLayout.LayoutParams iconLp=new FrameLayout.LayoutParams(dp(previewDp),dp(previewDp),Gravity.CENTER);iconBox.addView(icon,iconLp);
                TextView sparkle=t("✦   ✧",12,Color.rgb(255,226,118),true);sparkle.setGravity(Gravity.CENTER);sparkle.setAlpha(.12f);iconBox.addView(sparkle,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));tile.addView(iconBox,new LinearLayout.LayoutParams(-1,dp(54)));
                catalogAnimConfigs.put(icon,g);catalogSparkles.put(icon,sparkle);
                TextView nm=t(g.optString("name","Gift"),9.6f,Color.WHITE,true);nm.setGravity(Gravity.CENTER);nm.setMaxLines(1);tile.addView(nm,new LinearLayout.LayoutParams(-1,dp(22)));
                TextView pr=t(("GOLD".equals(currency[0])?"👑 ":"🪙 ")+g.optInt("price",1),10.0f,Color.rgb(255,219,91),true);pr.setGravity(Gravity.CENTER);tile.addView(pr,new LinearLayout.LayoutParams(-1,dp(21)));
                tile.setOnClickListener(v->{
                    if(chosenTile[0]!=null)chosenTile[0].setBackground(giftTileBg(false,"GOLD".equals(currency[0])));
                    chosen[0]=g;chosenTile[0]=tile;tile.setBackground(giftTileBg(true,"GOLD".equals(currency[0])));tile.animate().scaleX(1.045f).scaleY(1.045f).setDuration(100).withEndAction(()->tile.animate().scaleX(1f).scaleY(1f).setDuration(100).start()).start();
                    selectedText.setText("✓ "+g.optString("name","Gift")+"  •  "+("GOLD".equals(currency[0])?"👑 ":"🪙 ")+g.optInt("price",1));sendButton.setEnabled(true);sendButton.setAlpha(1f);sendButton.setText("SEND");
                });
                GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=0;gp.height=dp(102);gp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);gp.setMargins(dp(3),dp(3),dp(3),dp(3));grid.addView(tile,gp);
            }
            if(count==0){TextView empty=t("No published gifts in this catalog.",11,Color.rgb(200,202,229),false);empty.setGravity(Gravity.CENTER);grid.addView(empty,new GridLayout.LayoutParams(GridLayout.spec(0),GridLayout.spec(0,3)));}
            sc.post(()->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles));
            sc.postDelayed(()->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles),650L);
        };
        sc.setOnScrollChangeListener((v,sx,sy,ox,oy)->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles));
        coin.setOnClickListener(v->{currency[0]="COIN";renderHolder[0].run();});gold.setOnClickListener(v->{currency[0]="GOLD";renderHolder[0].run();});
        sendButton.setOnClickListener(v->{
            final JSONObject gift=chosen[0];if(gift==null)return;sendButton.setEnabled(false);sendButton.setText("SENDING…");
            final long giftId=gift.optLong("id");final String nonce="gift-"+SessionManager.getUserId(this)+"-"+UUID.randomUUID();
            final String receiverId=giftReceiverId;BackendClient.liveGiftSend(token(),hostId,receiverId,giftId,nonce,new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->{
                    long sentEventId=d.optLong("eventId",0);JSONObject serverGift=d.optJSONObject("gift");final JSONObject effectGift=serverGift==null?gift:serverGift;
                    JSONObject localGiftEvent=new JSONObject();try{
                        localGiftEvent.put("id",sentEventId).put("sender_id",SessionManager.getUserId(AudioLiveRoomActivity.this)).put("sender_name",d.optString("senderName",SessionManager.getFullName(AudioLiveRoomActivity.this))).put("sender_avatar",d.optString("senderAvatar",SessionManager.getAvatarUrl(AudioLiveRoomActivity.this))).put("sender_level",d.optInt("senderLevel",myLevel)).put("receiver_id",d.optString("receiverId",hostId)).put("receiver_name",currentLiveName).put("name",effectGift.optString("name","Gift")).put("currency",effectGift.optString("currency","COIN")).put("price",effectGift.optInt("price",d.optInt("grossAmount",1))).put("combo",Math.max(1,d.optInt("combo",1))).put("preview_url",effectGift.optString("preview_url","")).put("animation_url",effectGift.optString("animation_url",""));
                    }catch(Exception ignored){}
                    renderGiftActivityComment(localGiftEvent);
                    if(sentEventId>0){renderedGiftEventIds.add(sentEventId);lastGiftEventId=Math.max(lastGiftEventId,sentEventId);}
                    if(giftStoreDialog!=null&&giftStoreDialog.isShowing())giftStoreDialog.dismiss();giftStoreDialog=null;cachedGiftCatalog=null;cachedGiftCatalogAt=0L;
                    showGiftEffect(effectGift,d);prefetchGiftCatalog();
                });}
                public void onError(String m){runOnUiThread(()->{sendButton.setEnabled(true);sendButton.setAlpha(1f);sendButton.setText("SEND");Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show();});}
            });
        });
        renderHolder[0].run();
        giftStoreDialog=new AlertDialog.Builder(this).setView(box).create();
        closeGift.setOnClickListener(v->{if(giftStoreDialog!=null&&giftStoreDialog.isShowing())giftStoreDialog.dismiss();});
        giftStoreDialog.setOnDismissListener(d->{for(ImageView art:catalogAnimConfigs.keySet())CatalogGiftAnimator.stop(art,catalogSparkles.get(art));catalogAnimConfigs.clear();catalogSparkles.clear();giftStoreDialog=null;});
        giftStoreDialog.setOnShowListener(d->{android.view.Window w=giftStoreDialog.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.72f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.94f),-2);}});
        giftStoreDialog.show();
        sc.postDelayed(()->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles),150L);
        sc.postDelayed(()->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles),1300L);
        sc.postDelayed(()->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles),3200L);
    }

    private void updateCatalogPreviewAnimations(ScrollView sc,Map<ImageView,JSONObject> configs,Map<ImageView,TextView> sparkles){
        if(sc==null||configs==null)return;Rect scrollRect=new Rect();boolean scrollVisible=sc.getGlobalVisibleRect(scrollRect);
        for(Map.Entry<ImageView,JSONObject> e:configs.entrySet()){
            ImageView art=e.getKey();if(art==null)continue;Rect artRect=new Rect();boolean visible=scrollVisible&&art.getGlobalVisibleRect(artRect)&&Rect.intersects(scrollRect,artRect);
            if(visible)CatalogGiftAnimator.start(art,sparkles.get(art),e.getValue());else CatalogGiftAnimator.stop(art,sparkles.get(art));
        }
    }

    private android.graphics.drawable.GradientDrawable giftTileBg(boolean selected,boolean gold){
        int[] colors=gold?new int[]{Color.rgb(58,39,76),Color.rgb(95,59,45)}:new int[]{Color.rgb(31,29,78),Color.rgb(63,38,110)};
        int stroke=selected?(gold?Color.rgb(255,213,89):Color.rgb(255,102,214)):(gold?Color.rgb(181,132,65):Color.rgb(101,83,191));
        return gradient(colors,stroke,16);
    }

    private void renderLocalSkeleton(){renderHost(null);renderAudience(null,0);renderSpecialGuest(null);renderSeats(null);}

    private void refresh(){if(roomEnded||endLiveInProgress||refreshInFlight)return;refreshInFlight=true;BackendClient.liveRoomState(token(),hostId,new BackendClient.Callback(){@Override public void onSuccess(JSONObject d){runOnUiThread(()->{refreshInFlight=false;if(roomEnded||endLiveInProgress)return;syncState.setText("● LIVE • "+rtcDiagnosticStatus+" • "+networkQuality());render(d);});}@Override public void onError(String m){runOnUiThread(()->{refreshInFlight=false;if(roomEnded)return;if(endLiveInProgress){syncState.setText("Ending live…");return;}if(!host && m!=null && m.contains("LIVE_NOT_ACTIVE")){handler.removeCallbacks(tick);handler.removeCallbacks(realtimeTick);handler.removeCallbacks(presenceTick);handler.removeCallbacks(participantTick);showAudienceEndSummary();return;}syncState.setText("● LIVE • Weak network • Reconnecting…");if(premiumStrip!=null)premiumStrip.setText("⚠ Reconnecting… • "+networkQuality());if(seats.getChildCount()==0)renderLocalSkeleton();});}});}

    private void render(JSONObject d){
        int vc=d.optInt("viewerCount",0),peak=d.optInt("peakViewers",0); currentViewerCount=vc; viewers.setText("");
        String previousRtcRole=myRole; myRole=d.optString("myRole",host?"HOST":"AUDIENCE"); if(!myRole.equals(previousRtcRole))requestRtcToken(false); myLevel=Math.max(0,d.optInt("myLevel",myLevel)); roomAdmin=d.optBoolean("myRoomAdmin",false); canPinComments=d.optBoolean("canPinComments",host||roomAdmin)||SessionManager.isAdmin(this)||SessionManager.isModerator(this); String sanction=d.optString("mySanction","NONE"); listenOnly="MUTED".equals(sanction); if("BLOCKED".equals(sanction)||"KICKED".equals(sanction)){Toast.makeText(this,"You were removed from this live",Toast.LENGTH_SHORT).show();finish();return;} status.setText((host?"👑 Host":(roomAdmin?"🛡 Admin":"🎧 "+myRole))+" • ID "+SessionManager.getUserId(this)+(listenOnly?" • Listen only":"")); updateVoiceMonitor(); updateLocalMicUi();
        specialGuestId=d.optString("specialGuestId",""); shareCount=d.optInt("shareCount",0); shareView.setText("↗ "+shareCount);
        currentLiveName=d.optString("title","Host"); roomTitle.setText("🎙 "+currentLiveName); String cap=d.optString("topic","").trim(); roomTopic.setText(cap.isEmpty()?"Add caption":cap); reactCount=d.optLong("reactCount",0); if(reactView!=null)reactView.setText("❤️\n"+compact(reactCount));
        String pin=d.optString("pinnedMessage",""); pinnedView.setText(pin.isEmpty()?"📌 No pinned announcement":"📌 "+pin);
        String sid=d.optString("sessionId","");long elapsed=Math.max(0,d.optLong("elapsedSeconds",0));long parsed=parseServerTime(d.optString("startedAt",""));
        if(!sid.equals(activeSessionId)){activeSessionId=sid;serverElapsedSec=elapsed;serverElapsedSyncMs=System.currentTimeMillis();startedAtMs=parsed;pendingComments.clear();shownMilestones.clear();lastEntryEventId=0L;lastGiftEventId=0L;lastRealtimeCommentId=0L;lastRealtimeHighlightId=0L;realtimeRevision=0;realtimeFailures=0;renderedGiftEventIds.clear();renderedCommentIds.clear();renderedRoomEventIds.clear();renderedHighlightCommentIds.clear();commentsList.removeAllViews();giftPollInFlight=false;}else{serverElapsedSec=elapsed;serverElapsedSyncMs=System.currentTimeMillis();if(parsed>0)startedAtMs=parsed;}
        renderPremiumState(d);
        lockedSeats.clear();JSONArray locks=d.optJSONArray("lockedSeats");if(locks!=null)for(int i=0;i<locks.length();i++)lockedSeats.add(locks.optInt(i));
        currentHostStats=d.optJSONObject("hostStats"); if(currentHostStats==null)currentHostStats=new JSONObject(); currentTopSupporters=d.optJSONArray("topSupporters"); if(currentTopSupporters==null)currentTopSupporters=new JSONArray();
        JSONArray a=d.optJSONArray("seats"); currentSeats=a==null?new JSONArray():a; currentSeatNo=0; JSONObject meSeat=findUser(currentSeats,SessionManager.getUserId(this)); if(meSeat!=null)currentSeatNo=meSeat.optInt("seat_no",0); updateSpeakerControls(); renderHost(findSeat(a,1));renderAudience(d.optJSONArray("viewerProfiles"),vc);renderSpecialGuest(findUser(a,specialGuestId));renderSeats(a);
        currentRequests=d.optJSONArray("requests")==null?new JSONArray():d.optJSONArray("requests");
        if(host&&requests!=null){renderRequests(currentRequests);notifyHostOfNewRequest(currentRequests);}
        JSONArray highlights=d.optJSONArray("highlightComments");JSONArray giftEvents=d.optJSONArray("giftEvents");renderComments(d.optJSONArray("comments"),d.optJSONArray("events"),highlights);renderGiftActivityEventsOnly(giftEvents);renderHighlightComments(highlights);renderGiftEffectsOnly(giftEvents);
        if(!host)showIncomingInvite(d.optJSONObject("incomingInvite"));
        JSONObject theme=d.optJSONObject("theme"); if(theme!=null){String bg=theme.optString("background_url","");if(!bg.trim().isEmpty())loadImage(wallpaper,bg);}
    }

    private void renderHost(JSONObject x){
        hostArea.removeAllViews();
        LinearLayout top=row(); top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout hostBlock=row(); hostBlock.setGravity(Gravity.CENTER_VERTICAL); hostBlock.setPadding(0,0,dp(5),0);
        JSONObject hostDisplay=x;
        if(hostDisplay==null&&host){
            hostDisplay=new JSONObject();
            try{
                hostDisplay.put("user_id",SessionManager.getUserId(this));
                hostDisplay.put("full_name",SessionManager.getFullName(this));
                hostDisplay.put("avatar_url",SessionManager.getAvatarUrl(this));
                hostDisplay.put("mic_on",localMicOn?1:0);
            }catch(Exception ignored){}
        }
        boolean speaking=hostDisplay!=null&&hostDisplay.optInt("speaking",0)==1;
        speaking=speaking||isRtcSpeaking(hostDisplay,true);
        FrameLayout av=avatarWithMicState(hostDisplay,dp(64),speaking);hostBlock.addView(av,new LinearLayout.LayoutParams(dp(64),dp(64)));
        String name=currentLiveName==null||currentLiveName.trim().isEmpty()?(hostDisplay==null?"Host":hostDisplay.optString("full_name","Host")):currentLiveName;
        String id=hostDisplay==null?hostId:hostDisplay.optString("user_id",hostId);int lv=hostDisplay==null?0:hostDisplay.optInt("level",0);
        TextView info=t("👑 "+name+"\nID "+id+"  •  LV."+lv,11.8f,Color.WHITE,true);info.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        hostBlock.addView(info,new LinearLayout.LayoutParams(dp(112),dp(68)));
        hostBlock.setClickable(true);hostBlock.setFocusable(true);PremiumUi.press(hostBlock);hostBlock.setContentDescription("Open Live Gift Summary");hostBlock.setOnClickListener(v->showGiftSummary());
        top.addView(hostBlock,new LinearLayout.LayoutParams(dp(184),dp(78)));
        if(audienceScroll.getParent()!=null)((android.view.ViewGroup)audienceScroll.getParent()).removeView(audienceScroll);
        top.addView(audienceScroll,new LinearLayout.LayoutParams(0,dp(78),1));
        onlineCountView=t("✕",22f,Color.rgb(255,59,48),true);onlineCountView.setGravity(Gravity.CENTER);onlineCountView.setContentDescription("Exit Live");onlineCountView.setBackgroundColor(Color.TRANSPARENT);
        onlineCountView.setOnClickListener(v->{if(host)confirmEndLive();else confirmLeaveLive();});
        LinearLayout.LayoutParams ocp=new LinearLayout.LayoutParams(dp(42),dp(36));ocp.leftMargin=dp(4);top.addView(onlineCountView,ocp);
        hostArea.addView(top,new LinearLayout.LayoutParams(-1,dp(82)));

        long gift=currentHostStats.optLong("totalGift",0),coin=currentHostStats.optLong("coinBalance",x==null?0:x.optLong("coin_balance",0)),gold=currentHostStats.optLong("goldBalance",x==null?0:x.optLong("gold_balance",0)),stars=currentHostStats.optLong("stars",0);
        LinearLayout stats=row();stats.setGravity(Gravity.CENTER);stats.setPadding(0,dp(2),0,0);
        topGiftView=statPill("👥 Users",compact(currentViewerCount+1),Color.rgb(245,79,196));topCoinView=statPill("🪙 Coin",compact(coin),Color.rgb(75,121,255));topGoldView=statPill("🟡 Gold",compact(gold),Color.rgb(219,157,32));topStarView=statPill("⭐ Star",compact(stars),Color.rgb(131,74,236));
        stats.addView(topGiftView,statLp());stats.addView(topCoinView,statLp());stats.addView(topGoldView,statLp());stats.addView(topStarView,statLp());
        hostArea.addView(stats,new LinearLayout.LayoutParams(-1,dp(50)));
    }

    private LinearLayout.LayoutParams statLp(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(45),1);p.setMargins(dp(1),0,dp(1),0);return p;}
    private TextView statPill(String label,String value,int accent){TextView v=t(label+"\n"+value,10.8f,Color.WHITE,true);v.setGravity(Gravity.CENTER);v.setBackgroundColor(Color.TRANSPARENT);return v;}

    private void renderAudience(JSONArray a,int total){
        currentViewerProfiles=a==null?new JSONArray():a; currentViewerCount=total; audienceRow.removeAllViews(); audienceRow.setPadding(dp(2),0,dp(2),0);
        for(int i=0;i<currentViewerProfiles.length();i++){
            JSONObject u=currentViewerProfiles.optJSONObject(i); if(u==null)continue;
            final int serial=i+1;
            LinearLayout cell=col(); cell.setGravity(Gravity.CENTER);cell.setPadding(dp(3),0,dp(3),0);cell.setClickable(true);cell.setFocusable(true);PremiumUi.press(cell);cell.setOnClickListener(v->openUserProfile(u));
            FrameLayout av=circleAvatar(u.optString("avatar_url",""),dp(50),false,u.optString("tier","STANDARD"));
            TextView sn=t("#"+serial,7.2f,serial<=3?Color.rgb(75,45,5):Color.WHITE,true);sn.setGravity(Gravity.CENTER);sn.setBackground(bg(serial<=3?Color.rgb(255,205,78):Color.argb(220,64,74,135),serial<=3?Color.rgb(255,232,158):Color.rgb(120,145,230),8));FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(27),dp(17),Gravity.LEFT|Gravity.TOP);sp.leftMargin=-dp(1);sp.topMargin=-dp(1);av.addView(sn,sp);
            int supporter=u.optInt("supporterRank",0);String tier=u.optString("tier","STANDARD").toUpperCase();String badge=supporter>=1&&supporter<=3?"🏆 ":("KING".equals(tier)?"♔ ":"QUEEN".equals(tier)?"♕ ":"ROYAL".equals(tier)?"👑 ":"VVIP".equals(tier)?"◆ ":"VIP".equals(tier)?"✦ ":"");
            cell.addView(av,new LinearLayout.LayoutParams(dp(50),dp(50)));
            TextView nm=t(badge+shortName(u.optString("full_name","User")),8.4f,Color.WHITE,true);nm.setGravity(Gravity.CENTER);nm.setSingleLine(true);nm.setOnClickListener(v->openUserProfile(u));cell.addView(nm,new LinearLayout.LayoutParams(dp(76),dp(20)));
            audienceRow.addView(cell,new LinearLayout.LayoutParams(dp(82),dp(74)));
        }
        if(currentViewerProfiles.length()==0){TextView empty=t("No viewers yet",8.5f,Color.rgb(180,196,231),false);empty.setGravity(Gravity.CENTER_VERTICAL);audienceRow.addView(empty,new LinearLayout.LayoutParams(dp(100),dp(62)));}
        // V-355 ordering is server-authoritative: Top Gifter #1-3, membership tier, Coin balance, then Level.
    }

    private void showGiftSummary(){
        LinearLayout wrap=col();wrap.setPadding(dp(8),dp(4),dp(8),dp(6));
        TextView note=t("Current Live session • Top 20 supporters",10,Color.rgb(183,196,232),false);note.setGravity(Gravity.CENTER);wrap.addView(note,new LinearLayout.LayoutParams(-1,dp(32)));
        ScrollView scroll=new ScrollView(this);LinearLayout rows=col();scroll.addView(rows,new ScrollView.LayoutParams(-1,-2));
        int n=currentTopSupporters==null?0:Math.min(20,currentTopSupporters.length());
        if(n==0){TextView empty=t("No gifts in this Live yet",12,Color.rgb(190,200,225),true);empty.setGravity(Gravity.CENTER);rows.addView(empty,new LinearLayout.LayoutParams(-1,dp(100)));}
        for(int i=0;i<n;i++){
            JSONObject x=currentTopSupporters.optJSONObject(i);if(x==null)continue;final int rank=i+1;final String uid=x.optString("sender_id","");
            LinearLayout r=row();r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(7),dp(6),dp(7),dp(6));r.setBackground(bg(rank<=3?Color.argb(235,55,38,84):Color.argb(225,15,29,72),rank==1?Color.rgb(255,208,72):rank==2?Color.rgb(199,211,231):rank==3?Color.rgb(222,151,91):Color.rgb(68,91,160),13));
            TextView rr=t(rank==1?"🥇":rank==2?"🥈":rank==3?"🥉":"#"+rank,11,rank<=3?Color.rgb(255,224,145):Color.WHITE,true);rr.setGravity(Gravity.CENTER);r.addView(rr,new LinearLayout.LayoutParams(dp(42),dp(46)));
            FrameLayout av=circleAvatar(x.optString("avatar_url",""),dp(42),false);r.addView(av,new LinearLayout.LayoutParams(dp(42),dp(42)));
            LinearLayout meta=col();meta.setPadding(dp(8),0,dp(3),0);TextView nm=t(x.optString("full_name","Supporter")+"  •  ID "+uid,10,Color.WHITE,true);nm.setSingleLine(true);meta.addView(nm,new LinearLayout.LayoutParams(-1,dp(22)));long gifts=x.optLong("gift_count",0),coins=x.optLong("coin_value",0),gold=x.optLong("gold_value",0);TextView vals=t("🎁 "+gifts+"   •   🪙 "+compact(coins)+" Coin   •   🟡 "+compact(gold)+" Gold",8.6f,Color.rgb(219,226,255),false);vals.setSingleLine(true);meta.addView(vals,new LinearLayout.LayoutParams(-1,dp(21)));r.addView(meta,new LinearLayout.LayoutParams(0,dp(46),1));
            if(!uid.isEmpty()){r.setOnClickListener(v->{Intent q=new Intent(this,UserProfileActivity.class);q.putExtra("userId",uid);startActivity(q);});PremiumUi.press(r);}LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(58));rp.bottomMargin=dp(5);rows.addView(r,rp);
        }
        wrap.addView(scroll,new LinearLayout.LayoutParams(-1,dp(430)));
        new AlertDialog.Builder(this).setTitle("🎁 Live Gift Summary • Top 20").setView(wrap).setNeutralButton("Host Profile",(d,w)->{Intent q=new Intent(this,UserProfileActivity.class);q.putExtra("userId",hostId);startActivity(q);}).setPositiveButton("Close",null).show();
    }

    private String compact(long n){if(n>=1000000)return (n%1000000==0?(n/1000000)+"M":String.format(Locale.US,"%.1fM",n/1000000f));if(n>=1000)return (n%1000==0?(n/1000)+"K":String.format(Locale.US,"%.1fK",n/1000f));return String.valueOf(n);}

    private String shortName(String n){ if(n==null||n.trim().isEmpty())return "User"; n=n.trim(); int sp=n.indexOf(' '); if(sp>0)n=n.substring(0,sp); return n.length()>7?n.substring(0,7):n; }

    private void showAudienceList(){
        int n=currentViewerProfiles==null?0:currentViewerProfiles.length();
        if(n==0){Toast.makeText(this,"No active users right now",Toast.LENGTH_SHORT).show();return;}
        String[] items=new String[n]; for(int i=0;i<n;i++){JSONObject u=currentViewerProfiles.optJSONObject(i); items[i]=u==null?"User":u.optString("full_name","User")+"  •  ID "+u.optString("user_id","")+"  •  🏅LV."+u.optInt("level",0);}
        new AlertDialog.Builder(this).setTitle("Active Users • "+currentViewerCount).setItems(items,(d,w)->{JSONObject u=currentViewerProfiles.optJSONObject(w);if(u==null)return;if(host)showUserModeration(u);else showMiniProfile(u);}).setNegativeButton("Close",null).show();
    }

    private void inviteToCall(JSONObject u){
        if(!host||u==null)return;String uid=u.optString("user_id","");if(uid.isEmpty()||uid.equals(hostId))return;
        BackendClient.liveInvite(token(),uid,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,"Call invitation sent to "+u.optString("full_name","User"),Toast.LENGTH_SHORT).show());}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}});
    }

    private void showIncomingInvite(JSONObject inv){
        if(inv==null||host||inviteDialogOpen)return;String key=inv.optString("host_id",hostId)+"|"+inv.optString("session_id","")+"|"+inv.optString("created_at","");if(key.equals(lastInviteNotice))return;lastInviteNotice=key;inviteDialogOpen=true;
        String hostName=inv.optString("host_name","Host");
        new AlertDialog.Builder(this).setTitle("📞 Live Call Invitation").setMessage(hostName+" আপনাকে Live Call-এ speaker হিসেবে আমন্ত্রণ জানিয়েছে। Accept করলে available seat-এ উঠবেন।")
                .setPositiveButton("ACCEPT",(d,w)->{inviteDialogOpen=false;BackendClient.liveInviteAction(token(),hostId,true,new ToastCb("Invitation accepted • joining call"));})
                .setNegativeButton("DECLINE",(d,w)->{inviteDialogOpen=false;BackendClient.liveInviteAction(token(),hostId,false,new ToastCb("Invitation declined"));})
                .setOnCancelListener(d->inviteDialogOpen=false).show();
    }

    private void notifyHostOfNewRequest(JSONArray q){
        if(!host||requestNoticeBar==null)return;
        if(q==null||q.length()==0){requestNoticeBar.setVisibility(View.GONE);requestNoticeBar.removeAllViews();return;}
        JSONObject x=q.optJSONObject(0);if(x==null)return;
        String uid=x.optString("user_id","");String nm=x.optString("full_name","User");String key=uid+"|"+x.optString("created_at","");
        requestNoticeBar.removeAllViews();
        TextView who=t("✋ "+shortName(nm)+(q.length()>1?"  +"+(q.length()-1):""),10.5f,Color.WHITE,true);who.setSingleLine(true);who.setEllipsize(android.text.TextUtils.TruncateAt.END);requestNoticeBar.addView(who,new LinearLayout.LayoutParams(0,dp(36),1));
        Button ok=small("✓ Accept");ok.setTextSize(8.8f);ok.setBackground(bg(Color.rgb(28,120,92),Color.rgb(83,244,178),12));ok.setOnClickListener(v->BackendClient.liveRequestAction(token(),uid,true,new ToastCb("Speaker accepted")));
        Button no=small("✕");no.setTextSize(10);no.setTextColor(Color.rgb(255,210,215));no.setBackground(bg(Color.rgb(116,34,57),Color.rgb(255,91,116),12));no.setOnClickListener(v->BackendClient.liveRequestAction(token(),uid,false,new ToastCb("Request declined")));
        LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(dp(72),dp(34));op.rightMargin=dp(4);requestNoticeBar.addView(ok,op);requestNoticeBar.addView(no,new LinearLayout.LayoutParams(dp(38),dp(34)));
        requestNoticeBar.setVisibility(View.VISIBLE);
        if(!key.equals(lastRequestNotice)){lastRequestNotice=key;requestNoticeBar.setAlpha(.2f);requestNoticeBar.setTranslationY(-dp(8));requestNoticeBar.animate().alpha(1f).translationY(0).setDuration(180).start();}
    }

    private void showJoinRequestsDialog(){
        if(!host)return;if(currentRequests==null||currentRequests.length()==0){Toast.makeText(this,"No pending join requests",Toast.LENGTH_SHORT).show();return;}
        int n=currentRequests.length();String[] items=new String[n];for(int i=0;i<n;i++){JSONObject x=currentRequests.optJSONObject(i);items[i]=x==null?"User":x.optString("full_name","User")+" • ID "+x.optString("user_id","");}
        new AlertDialog.Builder(this).setTitle("Join Requests • "+n).setItems(items,(d,w)->{JSONObject x=currentRequests.optJSONObject(w);if(x==null)return;String uid=x.optString("user_id","");new AlertDialog.Builder(this).setTitle(items[w]).setItems(new String[]{"Accept to Call","Decline"},(dd,which)->BackendClient.liveRequestAction(token(),uid,which==0,new ToastCb(which==0?"Speaker accepted":"Request declined"))).show();}).setNegativeButton("Close",null).show();
    }

    private void renderSpecialGuest(JSONObject x){
        specialArea.removeAllViews();
        FrameLayout stage=new FrameLayout(this);
        long elapsed=!activeSessionId.isEmpty()?Math.max(0,serverElapsedSec+(System.currentTimeMillis()-serverElapsedSyncMs)/1000L):0;
        durationView=t(hhmmss(elapsed),9.5f,Color.WHITE,true); durationView.setGravity(Gravity.CENTER); durationView.setBackground(bg(Color.argb(145,41,20,83),Color.rgb(236,73,179),14));
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(dp(82),dp(28),Gravity.LEFT|Gravity.TOP); tp.leftMargin=dp(3); tp.topMargin=dp(5); stage.addView(durationView,tp);

        boolean speaking=x!=null&&x.optInt("speaking",0)==1;speaking=speaking||isRtcSpeaking(x,false);
        FrameLayout guestFrame=new FrameLayout(this); GoldenGuestHalo halo=new GoldenGuestHalo(this); guestFrame.addView(halo,new FrameLayout.LayoutParams(-1,-1));
        if(x==null){
            ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.live_main_guest_logo);logo.setScaleType(ImageView.ScaleType.CENTER_CROP);logo.setClipToOutline(true);logo.setBackground(bg(Color.rgb(10,20,66),Color.rgb(255,193,58),44));
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(92),dp(92),Gravity.CENTER);guestFrame.addView(logo,lp);
        }else{
            FrameLayout av=avatarWithMicState(x,dp(92),speaking); FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(dp(92),dp(92),Gravity.CENTER); guestFrame.addView(av,ap);
        }
        TextView label=t("Main Guest",9.2f,Color.rgb(255,215,63),true);label.setGravity(Gravity.CENTER);label.setBackground(bg(Color.argb(205,11,31,75),Color.rgb(73,201,255),13));
        FrameLayout.LayoutParams lpLabel=new FrameLayout.LayoutParams(dp(90),dp(25),Gravity.CENTER_HORIZONTAL|Gravity.BOTTOM);lpLabel.bottomMargin=0;guestFrame.addView(label,lpLabel);
        ObjectAnimator pulseX=ObjectAnimator.ofFloat(halo,"scaleX",1f,1.045f,1f); pulseX.setDuration(1650); pulseX.setRepeatCount(ValueAnimator.INFINITE); pulseX.start();
        ObjectAnimator pulseY=ObjectAnimator.ofFloat(halo,"scaleY",1f,1.045f,1f); pulseY.setDuration(1650); pulseY.setRepeatCount(ValueAnimator.INFINITE); pulseY.start();
        ObjectAnimator glow=ObjectAnimator.ofFloat(halo,"alpha",.78f,1f,.78f); glow.setDuration(1400); glow.setRepeatCount(ValueAnimator.INFINITE); glow.start();
        FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(dp(142),dp(122),Gravity.CENTER); stage.addView(guestFrame,gp);
        specialArea.addView(stage,new LinearLayout.LayoutParams(-1,dp(124)));
        if(host&&x!=null)guestFrame.setOnClickListener(v->clearSpecialGuest()); else guestFrame.setOnClickListener(null);
    }

    private void renderSeats(JSONArray a){
        seats.removeAllViews();
        int n=2; int[] counts={4,4};
        for(int rr=0;rr<counts.length;rr++){
            LinearLayout r=row();r.setGravity(Gravity.CENTER);
            for(int c=0;c<counts[rr]&&n<=9;c++,n++){
                JSONObject found=findSeat(a,n);
                if(found!=null&&hostId.equals(found.optString("user_id","")))found=null;
                boolean specialReserved=found!=null&&!specialGuestId.isEmpty()&&specialGuestId.equals(found.optString("user_id",""));
                if(specialReserved)found=null;
                boolean locked=(n>1&&lockedSeats.contains(n))||specialReserved;
                LinearLayout tile=seatTile(n,found,locked); final int seatNo=n; final JSONObject clicked=found;
                if(seatNo>1) tile.setOnClickListener(v->{
                    if(host){if(clicked!=null)showSpeakerActions(clicked);else toggleSeatLock(seatNo,locked);return;}
                    if("SPEAKER".equals(myRole)){
                        if(clicked==null&&!locked){moveMySeat(seatNo);return;}
                        if(clicked!=null&&SessionManager.getUserId(this).equals(clicked.optString("user_id",""))){showSelfSpeakerMenu();return;}
                    }
                    if(clicked!=null)showMiniProfile(clicked);
                });
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(96),1);lp.setMargins(dp(3),dp(2),dp(3),dp(2));r.addView(tile,lp);
            }
            seats.addView(r,new LinearLayout.LayoutParams(-1,dp(100)));
        }
    }

    private LinearLayout seatTile(int seatNo,JSONObject x,boolean locked){
        LinearLayout v=col(); v.setGravity(Gravity.CENTER); v.setPadding(dp(1),dp(1),dp(1),dp(1)); v.setBackgroundColor(Color.TRANSPARENT);
        boolean occupied=x!=null,speaking=occupied&&x.optInt("speaking",0)==1;speaking=speaking||isRtcSpeaking(x,false);
        if(occupied){
            FrameLayout av=avatarWithMicState(x,dp(76),speaking); av.setOnClickListener(z->openUserProfile(x)); v.addView(av,new LinearLayout.LayoutParams(dp(76),dp(76)));
            TextView seatNoView=t(String.valueOf(seatNo),8.4f,Color.WHITE,true);seatNoView.setGravity(Gravity.CENTER);v.addView(seatNoView,new LinearLayout.LayoutParams(-1,dp(18)));
        }else{
            FrameLayout stage=new FrameLayout(this); stage.addView(sofaIcon(locked),new FrameLayout.LayoutParams(dp(78),dp(78),Gravity.CENTER)); v.addView(stage,new LinearLayout.LayoutParams(dp(80),dp(80)));
            TextView seatNoView=t(String.valueOf(seatNo),8.4f,Color.rgb(245,247,255),true);seatNoView.setGravity(Gravity.CENTER);v.addView(seatNoView,new LinearLayout.LayoutParams(-1,dp(18)));
        }
        return v;
    }

    private View sofaIcon(boolean locked){
        FrameLayout f=new FrameLayout(this);f.setPadding(dp(2),dp(2),dp(2),dp(2));f.setElevation(dp(1));
        GradientDrawable seatBg=new GradientDrawable();
        seatBg.setShape(GradientDrawable.OVAL);
        seatBg.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        seatBg.setGradientCenter(.40f,.34f);
        seatBg.setGradientRadius(dp(58));
        seatBg.setColors(locked
                ?new int[]{Color.argb(188,78,79,90),Color.argb(160,54,55,66),Color.argb(132,35,36,48)}
                :new int[]{Color.argb(198,132,132,136),Color.argb(166,91,91,98),Color.argb(132,56,56,66)});
        seatBg.setStroke(dp(1),locked?Color.argb(145,155,158,176):Color.argb(165,221,224,235));
        f.setBackground(seatBg);
        ImageView chair=new ImageView(this);chair.setImageResource(R.drawable.live_guest_chair);chair.setScaleType(ImageView.ScaleType.CENTER_INSIDE);chair.setAlpha(.97f);
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(36),dp(36),Gravity.CENTER);f.addView(chair,cp);
        if(locked){TextView mark=t("🔒",8,Color.WHITE,true);mark.setGravity(Gravity.CENTER);mark.setBackground(bg(Color.argb(170,20,20,24),Color.argb(190,220,220,230),18));FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(20),dp(20),Gravity.RIGHT|Gravity.BOTTOM);f.addView(mark,mp);}
        return f;
    }

    private void toggleSeatLock(int seatNo,boolean locked){BackendClient.liveSeatLock(token(),seatNo,!locked,new ToastCb(!locked?"Seat locked":"Seat unlocked"));}


    private void renderHighlightComments(JSONArray arr){
        if(arr==null||arr.length()==0)return; JSONObject c=arr.optJSONObject(arr.length()-1); if(c==null)return; long hid=c.optLong("id",0); if(hid<=lastHighlightId)return; lastHighlightId=hid; final TextView banner=t("✨ "+c.optString("full_name","User")+": "+c.optString("message",""),11,Color.WHITE,true); banner.setPadding(dp(14),0,dp(14),0); banner.setGravity(Gravity.CENTER_VERTICAL); banner.setBackground(gradient(new int[]{Color.argb(235,76,34,145),Color.argb(235,184,54,156)},Color.rgb(255,209,92),18)); addContentView(banner,new android.view.ViewGroup.LayoutParams(dp(310),dp(42))); banner.setX(getResources().getDisplayMetrics().widthPixels); banner.setY(getResources().getDisplayMetrics().heightPixels*0.46f); banner.animate().translationX(-getResources().getDisplayMetrics().widthPixels-dp(340)).setDuration(6500).withEndAction(()->((android.view.ViewGroup)banner.getParent()).removeView(banner)).start();
    }

    private void renderRequests(JSONArray q){
        requests.removeAllViews();
        if(q==null||q.length()==0){requests.addView(t("No pending requests",11,Color.LTGRAY,false));return;}
        for(int i=0;i<q.length();i++){
            JSONObject x=q.optJSONObject(i);if(x==null)continue;
            LinearLayout rr=row();rr.setGravity(Gravity.CENTER_VERTICAL);
            String tier=x.optString("tier","STANDARD");long fan=x.optLong("fan_points",0);
            String badge="STANDARD".equals(tier)?"":(" • "+tier);
            TextView nm=t(x.optString("full_name","User")+badge+" • ID "+x.optString("user_id")+(fan>0?" • ⭐"+fan:""),10.5f,Color.WHITE,true);
            rr.addView(nm,new LinearLayout.LayoutParams(0,dp(36),1));
            Button ok=small("Accept"),no=small("Decline");String id=x.optString("user_id");
            ok.setOnClickListener(v->BackendClient.liveRequestAction(token(),id,true,new ToastCb("Speaker accepted")));
            no.setOnClickListener(v->BackendClient.liveRequestAction(token(),id,false,new ToastCb("Request declined")));
            rr.addView(ok,new LinearLayout.LayoutParams(dp(72),dp(38)));rr.addView(no,new LinearLayout.LayoutParams(dp(74),dp(38)));requests.addView(rr);
        }
    }

    private void compactCommentRow(TextView row){if(row==null)return;row.setMaxLines(Integer.MAX_VALUE);row.setEllipsize(null);row.setMinHeight(0);row.setGravity(Gravity.CENTER_VERTICAL);}

    private FrameLayout liveCommentAvatar(String url,String gender,int size){
        int stroke="FEMALE".equalsIgnoreCase(gender)?Color.rgb(255,83,190):"MALE".equalsIgnoreCase(gender)?Color.rgb(70,205,255):Color.rgb(153,132,255);
        FrameLayout frame=new FrameLayout(this);frame.setBackground(bg(Color.argb(210,13,20,48),stroke,size/2));
        ImageView v=new ImageView(this);v.setImageResource(android.R.drawable.sym_def_app_icon);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setClipToOutline(true);v.setBackground(bg(Color.rgb(31,40,84),stroke,size/2));
        FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,-1);ip.setMargins(dp(2),dp(2),dp(2),dp(2));frame.addView(v,ip);if(url!=null&&!url.trim().isEmpty())loadImage(v,url);return frame;
    }

    private LinearLayout buildUniversalCommentRow(JSONObject c,String name,String message,String gender){
        LinearLayout row=row();row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(6),dp(4),dp(8),dp(4));
        int accent="FEMALE".equalsIgnoreCase(gender)?Color.rgb(255,91,194):"MALE".equalsIgnoreCase(gender)?Color.rgb(77,205,255):Color.rgb(158,137,255);
        row.setBackground(bg(Color.argb(200,6,11,31),Color.argb(170,Color.red(accent),Color.green(accent),Color.blue(accent)),13));
        String avatar=c==null?"":c.optString("avatar_url",c.optString("sender_avatar",""));FrameLayout av=liveCommentAvatar(avatar,gender,dp(38));row.addView(av,new LinearLayout.LayoutParams(dp(38),dp(38)));
        String mark="MALE".equalsIgnoreCase(gender)?"◆ ":"";String displayName=mark+(name==null||name.trim().isEmpty()?"User":name.trim());String prefix=displayName+" : ";
        android.text.SpannableStringBuilder line=new android.text.SpannableStringBuilder(prefix+(message==null?"":message));
        line.setSpan(new android.text.style.StyleSpan(Typeface.BOLD),0,displayName.length(),android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        line.setSpan(new android.text.style.ForegroundColorSpan(accent),0,displayName.length(),android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        TextView text=t("",Math.max(12.0f,liveCommentFontSize-1.0f),Color.WHITE,false);text.setText(line);text.setLineSpacing(0,1.02f);text.setPadding(dp(8),0,0,0);compactCommentRow(text);row.addView(text,new LinearLayout.LayoutParams(0,-2,1));
        if(c!=null){final JSONObject profile=c;row.setClickable(true);row.setFocusable(true);PremiumUi.press(row);row.setOnClickListener(v->openUserProfile(profile));}
        return row;
    }

    private void renderComments(JSONArray comments,JSONArray events,JSONArray highlights){
        if(commentsList==null)return;
        final int before=commentsList.getChildCount();
        if(events!=null){int start=Math.max(0,events.length()-8);for(int i=start;i<events.length();i++){JSONObject e=events.optJSONObject(i);if(e==null)continue;if("GIFT".equalsIgnoreCase(e.optString("event_type","")))continue;long id=e.optLong("id",0);if(id>0&&!renderedRoomEventIds.add(id))continue;TextView n=t("• "+e.optString("full_name","Someone")+" "+e.optString("message",""),9.7f,Color.rgb(190,209,250),false);n.setPadding(dp(7),dp(3),dp(7),dp(3));n.setBackground(bg(Color.argb(108,13,30,70),Color.argb(105,87,110,194),10));LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,-2);ep.bottomMargin=dp(3);commentsList.addView(n,ep);}}
        if(highlights!=null){for(int i=0;i<highlights.length();i++){JSONObject h=highlights.optJSONObject(i);if(h==null)continue;long id=h.optLong("id",0);if(id>0&&!renderedHighlightCommentIds.add(id))continue;LinearLayout hi=buildUniversalCommentRow(h,"✨ "+h.optString("full_name","User"),h.optString("message",""),h.optString("gender","UNSPECIFIED"));hi.setBackground(gradient(new int[]{Color.argb(220,76,34,145),Color.argb(220,184,54,156)},Color.rgb(255,209,92),13));LinearLayout.LayoutParams hlp=new LinearLayout.LayoutParams(-1,-2);hlp.bottomMargin=dp(3);commentsList.addView(hi,hlp);}}
        if(comments!=null){for(int i=0;i<comments.length();i++){
            JSONObject c=comments.optJSONObject(i);if(c==null)continue;long id=c.optLong("id",0);if(id>0&&!renderedCommentIds.add(id))continue;
            String nonce=c.optString("client_nonce","");if(!nonce.isEmpty()){pendingComments.remove(nonce);removePendingCommentView(nonce);}
            String name=c.optString("full_name","User"),message=c.optString("message",""),gender=c.optString("gender","UNSPECIFIED");
            LinearLayout row=buildUniversalCommentRow(c,name,message,gender);if(canPinComments){final String pinText=name+" : "+message;row.setOnLongClickListener(v->{pinCommentText(pinText);return true;});}
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(3);commentsList.addView(row,rp);
        }}
        if(commentsList.getChildCount()==0&&pendingComments.isEmpty()){TextView empty=t("Comments will appear here",10.6f,Color.rgb(180,190,220),false);empty.setTag("comments-empty");empty.setPadding(dp(8),dp(5),dp(8),dp(5));commentsList.addView(empty);}
        trimCommentRows();
        if(commentScroll!=null&&commentsList.getChildCount()>before)commentScroll.post(()->commentScroll.fullScroll(View.FOCUS_DOWN));
    }
    private void removePendingCommentView(String nonce){if(commentsList==null)return;String tag="pending:"+nonce;for(int i=commentsList.getChildCount()-1;i>=0;i--){View v=commentsList.getChildAt(i);if(tag.equals(String.valueOf(v.getTag())))commentsList.removeViewAt(i);}}
    private void trimCommentRows(){if(commentsList==null)return;for(int i=commentsList.getChildCount()-1;i>=0;i--){View v=commentsList.getChildAt(i);if("comments-empty".equals(String.valueOf(v.getTag()))&&commentsList.getChildCount()>1)commentsList.removeViewAt(i);}while(commentsList.getChildCount()>100)commentsList.removeViewAt(0);}




    private void sendLiveComment(EditText input,TextView highlight){
        if(listenOnly){Toast.makeText(this,"Muted • listen and gift only",Toast.LENGTH_SHORT).show();return;}
        final String m=input.getText().toString().trim();if(m.isEmpty())return;
        final boolean hi=highlightSelected;final String nonce="c-"+SessionManager.getUserId(this)+"-"+UUID.randomUUID().toString();
        input.setText("");highlightSelected=false;highlight.setBackground(null);
        if(!hi){pendingComments.put(nonce,m);renderPendingOnly(nonce,m);}
        BackendClient.Callback cb=new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                if(sendButton!=null){sendButton.setEnabled(true);sendButton.setText("Send");}
                JSONObject ack=d.optJSONObject("comment");
                if(!hi && ack!=null) renderAcknowledgedComment(ack,nonce);
                else if(!roomEnded&&!endLiveInProgress) refresh();
            });}
            public void onError(String e){runOnUiThread(()->{
                pendingComments.remove(nonce);removePendingCommentView(nonce);
                if(sendButton!=null){sendButton.setEnabled(true);sendButton.setText("Send");}
                Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_SHORT).show();
                if(!roomEnded&&!endLiveInProgress)refresh();
            });}
        };
        if(hi)BackendClient.liveHighlightComment(token(),hostId,m,cb);else BackendClient.liveComment(token(),hostId,m,nonce,cb);
    }
    private void renderAcknowledgedComment(JSONObject c,String nonce){
        if(commentsList==null||c==null)return;
        long id=c.optLong("id",0);if(id>0&&!renderedCommentIds.add(id)){pendingComments.remove(nonce);removePendingCommentView(nonce);return;}
        pendingComments.remove(nonce);removePendingCommentView(nonce);
        String name=c.optString("full_name",SessionManager.getFullName(this)),message=c.optString("message",""),gender=c.optString("gender","UNSPECIFIED");
        LinearLayout row=buildUniversalCommentRow(c,name,message,gender);if(canPinComments){final String pinText=name+" : "+message;row.setOnLongClickListener(v->{pinCommentText(pinText);return true;});}
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(3);commentsList.addView(row,rp);trimCommentRows();if(commentScroll!=null)commentScroll.post(()->commentScroll.smoothScrollTo(0,commentsList.getBottom()));
    }

    private void renderPendingOnly(String nonce,String message){
        if(commentsList==null)return;JSONObject self=new JSONObject();try{self.put("user_id",SessionManager.getUserId(this));self.put("full_name",SessionManager.getFullName(this));self.put("avatar_url",SessionManager.getAvatarUrl(this));}catch(Exception ignored){}
        LinearLayout pr=buildUniversalCommentRow(self,SessionManager.getFullName(this),message,"UNSPECIFIED");pr.setTag("pending:"+nonce);pr.setAlpha(.84f);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(3);commentsList.addView(pr,rp);if(commentScroll!=null)commentScroll.post(()->commentScroll.smoothScrollTo(0,commentsList.getBottom()));
    }
    private void renderEntryEffects(JSONArray a){if(a==null||a.length()==0)return;JSONObject x=a.optJSONObject(a.length()-1);if(x==null)return;long id=x.optLong("id",0);if(id<=lastEntryEventId)return;lastEntryEventId=id;String tier=x.optString("tier","STANDARD");if("STANDARD".equals(tier))return;showFloatingBanner("✨ "+tier+" ENTRY • "+x.optString("full_name","Member"));}
    private void renderMilestones(JSONArray a){if(a==null)return;for(int i=0;i<a.length();i++){String k=a.optString(i,"");if(!k.isEmpty()&&shownMilestones.add(k))showFloatingBanner("🏆 "+k.replace('_',' '));}}
    private void showFloatingBanner(String text){final TextView b=t(text,12,Color.WHITE,true);b.setGravity(Gravity.CENTER);b.setBackground(gradient(new int[]{Color.argb(235,102,43,178),Color.argb(235,219,64,143)},Color.rgb(255,223,101),18));addContentView(b,new android.view.ViewGroup.LayoutParams(dp(300),dp(42)));b.setX((getResources().getDisplayMetrics().widthPixels-dp(300))/2f);b.setY(dp(110));b.setAlpha(0f);b.animate().alpha(1f).translationY(dp(10)).setDuration(220).withEndAction(()->handler.postDelayed(()->b.animate().alpha(0f).setDuration(350).withEndAction(()->{if(b.getParent()!=null)((android.view.ViewGroup)b.getParent()).removeView(b);}).start(),1800)).start();}
    private void renderGiftActivityComment(JSONObject e){
        if(commentsList==null||e==null)return;
        LinearLayout giftRow=row();giftRow.setGravity(Gravity.CENTER_VERTICAL);giftRow.setPadding(dp(7),dp(4),dp(8),dp(4));giftRow.setBackground(gradient(new int[]{Color.argb(218,31,73,153),Color.argb(218,83,35,145)},Color.rgb(68,207,255),13));
        FrameLayout av=circleAvatar(e.optString("sender_avatar",""),dp(40),false);giftRow.addView(av,new LinearLayout.LayoutParams(dp(40),dp(40)));
        ImageView giftThumb=new ImageView(this);giftThumb.setScaleType(ImageView.ScaleType.CENTER_INSIDE);String giftAsset=e.optString("preview_url","");if(giftAsset.isEmpty())giftAsset=e.optString("animation_url","");if(!giftAsset.isEmpty())AnimatedAssetLoader.load(giftThumb,giftAsset);else giftThumb.setImageResource(builtInGiftArt(e.optString("name","Gift")));LinearLayout.LayoutParams gtp=new LinearLayout.LayoutParams(dp(48),dp(48));gtp.leftMargin=dp(6);giftRow.addView(giftThumb,gtp);
        String sender=e.optString("sender_name","Supporter"),gift=e.optString("name","Gift"),receiver=e.optString("receiver_name",currentLiveName);int price=e.optInt("price",0),level=e.optInt("sender_level",e.optInt("level",0)),qty=Math.max(1,e.optInt("combo",e.optInt("quantity",1)));String currency="GOLD".equalsIgnoreCase(e.optString("currency","COIN"))?"Gold":"Coin";
        LinearLayout body=col();body.setPadding(dp(6),0,0,0);
        TextView who=t(sender+"  ⭐ LV."+level,13.6f,Color.rgb(255,231,111),true);who.setMaxLines(1);body.addView(who,new LinearLayout.LayoutParams(-1,-2));
        TextView what=t("🎁 sent "+gift+" ×"+qty+"  •  "+price+" "+currency,14.2f,Color.WHITE,true);what.setMaxLines(1);what.setEllipsize(android.text.TextUtils.TruncateAt.END);body.addView(what,new LinearLayout.LayoutParams(-1,-2));
        TextView to=t("to "+receiver,9.8f,Color.rgb(205,225,255),false);to.setMaxLines(1);body.addView(to,new LinearLayout.LayoutParams(-1,-2));
        giftRow.addView(body,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(4);commentsList.addView(giftRow,rp);trimCommentRows();if(commentScroll!=null)commentScroll.post(()->commentScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void renderGiftActivityEventsOnly(JSONArray arr){
        if(arr==null||arr.length()==0)return;
        for(int i=0;i<arr.length();i++){
            JSONObject e=arr.optJSONObject(i);if(e==null)continue;long id=e.optLong("id",0);if(id>0&&!renderedGiftEventIds.add(id))continue;
            renderGiftActivityComment(e);
        }
    }

    private void renderGiftEffectsOnly(JSONArray arr){
        if(arr==null||arr.length()==0)return;
        for(int i=0;i<arr.length();i++){
            JSONObject e=arr.optJSONObject(i);if(e==null)continue;long id=e.optLong("id",0);if(id<=lastGiftEventId)continue;
            lastGiftEventId=id;
            JSONObject g=new JSONObject();try{g.put("name",e.optString("name","Gift")).put("currency",e.optString("currency","COIN")).put("price",e.optInt("price",1)).put("preview_url",e.optString("preview_url","")).put("animation_url",e.optString("animation_url","")).put("animation_mime",e.optString("animation_mime","")).put("animation_enabled",e.optInt("animation_enabled",1)).put("sound_url",e.optString("sound_url","")).put("sound_enabled",e.optInt("sound_enabled",1)).put("sound_volume",e.optInt("sound_volume",92)).put("effect_duration_ms",e.optInt("effect_duration_ms",4200)).put("sound_duration_ms",e.optInt("sound_duration_ms",3800)).put("sound_trim_start_pct",e.optInt("sound_trim_start_pct",0)).put("sound_trim_end_pct",e.optInt("sound_trim_end_pct",100)).put("vat_percent",e.optInt("vat_percent",10)).put("board_position",e.optString("board_position","CENTER")).put("animation_scale",e.optInt("animation_scale",82)).put("size_mode",e.optString("size_mode","MEDIUM"));}catch(Exception ignored){}
            JSONObject r=new JSONObject();try{r.put("eventId",id).put("receiverId",e.optString("receiver_id",hostId)).put("combo",Math.max(1,e.optInt("combo",1))).put("senderName",e.optString("sender_name","Supporter"));}catch(Exception ignored){}
            showGiftEffect(g,r);
        }
    }

    private void renderGiftEvents(JSONArray arr){renderGiftActivityEventsOnly(arr);renderGiftEffectsOnly(arr);}


    private int builtInGiftArt(String name){
        String n=String.valueOf(name).toLowerCase(Locale.US);
        if(n.contains("rose"))return R.drawable.gift_rose;
        if(n.contains("heart"))return R.drawable.gift_heart;
        if(n.contains("teddy"))return R.drawable.gift_teddy;
        if(n.contains("chocolate"))return R.drawable.gift_chocolate;
        if(n.equals("star")||n.contains("super star"))return R.drawable.gift_star;
        if(n.contains("diamond"))return R.drawable.gift_diamond;
        if(n.contains("crown"))return R.drawable.gift_crown;
        if(n.contains("car"))return R.drawable.gift_car;
        if(n.contains("jet"))return R.drawable.gift_jet;
        if(n.contains("castle"))return R.drawable.gift_castle;
        return R.drawable.gift_star;
    }
    private int builtInGiftSound(String name){
        String n=String.valueOf(name).toLowerCase(Locale.US);
        if(n.contains("rose"))return R.raw.gift_rose_sound;
        if(n.contains("heart"))return R.raw.gift_heart_sound;
        if(n.contains("teddy"))return R.raw.gift_teddy_sound;
        if(n.contains("chocolate"))return R.raw.gift_chocolate_sound;
        if(n.equals("star")||n.contains("super star"))return R.raw.gift_star_sound;
        if(n.contains("diamond"))return R.raw.gift_diamond_sound;
        if(n.contains("crown"))return R.raw.gift_crown_sound;
        if(n.contains("car"))return R.raw.gift_car_sound;
        if(n.contains("jet"))return R.raw.gift_jet_sound;
        if(n.contains("castle"))return R.raw.gift_castle_sound;
        return 0;
    }
    private void setGiftArt(ImageView art,JSONObject gift){
        String asset=gift.optString("animation_url","");if(asset.isEmpty())asset=gift.optString("preview_url","");
        if(!asset.isEmpty())AnimatedAssetLoader.load(art,asset);else art.setImageResource(builtInGiftArt(gift.optString("name","Gift")));
    }
    private int giftInt(JSONObject gift,String snake,String camel,int def){
        if(gift==null)return def;Object v=gift.opt(snake);if(v==null||v==JSONObject.NULL)v=gift.opt(camel);if(v==null||v==JSONObject.NULL)return def;
        if(v instanceof Number)return ((Number)v).intValue();if(v instanceof Boolean)return ((Boolean)v)?1:0;try{return Integer.parseInt(String.valueOf(v).trim());}catch(Exception ignored){return def;}
    }
    private String giftString(JSONObject gift,String snake,String camel){if(gift==null)return "";String v=gift.optString(snake,"").trim();if(v.isEmpty())v=gift.optString(camel,"").trim();return v;}
    private void playBuiltInGiftSound(int resId,float volume,int maxDuration){
        if(resId==0||volume<=0f)return;
        try{
            final android.media.MediaPlayer fb=new android.media.MediaPlayer();
            // V-353: gift audio uses the normal media stream. SONIFICATION + transient focus
            // could be inaudible on some devices and could also duck/interrupt Agora voice.
            android.media.AudioAttributes aa=new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build();fb.setAudioAttributes(aa);
            android.content.res.AssetFileDescriptor afd=getResources().openRawResourceFd(resId);if(afd==null){fb.release();return;}fb.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());afd.close();fb.prepare();fb.setVolume(volume,volume);
            final int targetDuration=Math.max(1500,Math.min(maxDuration,3600));if(fb.getDuration()>0&&fb.getDuration()<1200&&targetDuration>fb.getDuration()+150)fb.setLooping(true);
            final android.media.audiofx.LoudnessEnhancer[] boost={null};try{boost[0]=new android.media.audiofx.LoudnessEnhancer(fb.getAudioSessionId());boost[0].setTargetGain(900);boost[0].setEnabled(true);}catch(Throwable ignored){}
            final boolean[] done={false};final Runnable release=()->{if(done[0])return;done[0]=true;try{if(fb.isPlaying())fb.stop();}catch(Exception ignored){}try{if(boost[0]!=null){boost[0].setEnabled(false);boost[0].release();}}catch(Exception ignored){}try{fb.release();}catch(Exception ignored){}};
            fb.setOnCompletionListener(x->release.run());fb.setOnErrorListener((x,w,e)->{release.run();return true;});fb.start();handler.postDelayed(release,targetDuration);
        }catch(Exception ignored){}
    }
    private void playGiftSound(JSONObject gift){
        if(giftInt(gift,"sound_enabled","soundEnabled",1)!=1)return;
        final float volume=Math.max(0f,Math.min(1f,giftInt(gift,"sound_volume","soundVolume",92)/100f));if(volume<=0f)return;
        final int configuredDuration=Math.max(600,giftInt(gift,"sound_duration_ms","soundDurationMs",3800));final int maxDuration=Math.max(1200,Math.min(18000,Math.round(configuredDuration*1.45f)));
        final String url=giftString(gift,"sound_url","soundUrl");final String giftName=gift.optString("name","Gift");final int fallbackRes=builtInGiftSound(giftName);final boolean[] fallbackUsed={false};
        final Runnable playFallback=()->{if(fallbackUsed[0])return;fallbackUsed[0]=true;playBuiltInGiftSound(fallbackRes,volume,maxDuration);};
        if(url.isEmpty()){playFallback.run();return;}
        try{
            final android.media.MediaPlayer mp=new android.media.MediaPlayer();android.media.AudioAttributes aa=new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build();mp.setAudioAttributes(aa);mp.setDataSource(url);
            final boolean[] released={false},prepared={false};final android.media.audiofx.LoudnessEnhancer[] boost={null};
            final Runnable release=()->{if(released[0])return;released[0]=true;try{if(mp.isPlaying())mp.stop();}catch(Exception ignored){}try{if(boost[0]!=null){boost[0].setEnabled(false);boost[0].release();}}catch(Exception ignored){}try{mp.reset();}catch(Exception ignored){}try{mp.release();}catch(Exception ignored){}};
            final Runnable watchdog=()->{if(!prepared[0]&&!released[0]){release.run();playFallback.run();}};handler.postDelayed(watchdog,1200L);
            mp.setOnPreparedListener(x->{prepared[0]=true;handler.removeCallbacks(watchdog);if(released[0])return;try{x.setVolume(volume,volume);try{boost[0]=new android.media.audiofx.LoudnessEnhancer(x.getAudioSessionId());boost[0].setTargetGain(750);boost[0].setEnabled(true);}catch(Throwable ignored){}int total=Math.max(1,x.getDuration());int startPct=Math.max(0,Math.min(99,giftInt(gift,"sound_trim_start_pct","soundTrimStartPct",0)));int endPct=Math.max(startPct+1,Math.min(100,giftInt(gift,"sound_trim_end_pct","soundTrimEndPct",100)));int startMs=(int)((long)total*startPct/100L);int endMs=(int)((long)total*endPct/100L);int segmentMs=Math.max(100,endMs-startMs);int playMs=segmentMs<1400?Math.min(maxDuration,Math.max(1800,segmentMs*4)):Math.min(maxDuration,segmentMs);if(startMs>0)x.seekTo(startMs);if(segmentMs<1400&&playMs>segmentMs+150)x.setLooping(true);x.start();handler.postDelayed(release,playMs);}catch(Exception ex){release.run();playFallback.run();}});
            mp.setOnCompletionListener(x->release.run());mp.setOnErrorListener((x,w,e)->{handler.removeCallbacks(watchdog);release.run();playFallback.run();return true;});mp.prepareAsync();
        }catch(Exception ex){playFallback.run();}
    }

    private int giftScale(JSONObject gift){
        if(gift.has("animation_scale"))return Math.max(0,Math.min(100,gift.optInt("animation_scale",70)));
        String m=gift.optString("size_mode","MEDIUM").toUpperCase(Locale.US);if("SMALL".equals(m))return 15;if("LARGE".equals(m))return 75;if("FULL_SCREEN".equals(m))return 100;return 48;
    }
    private String giftModeForScale(int scale){if(scale<=20)return "SMALL";if(scale<=58)return "MEDIUM";if(scale<=84)return "LARGE";return "FULL_SCREEN";}
    private int giftArtPx(int scale){
        int w=getResources().getDisplayMetrics().widthPixels,h=getResources().getDisplayMetrics().heightPixels,base=Math.min(w,h);
        float pct=.46f+(1.00f*(Math.max(0,Math.min(100,scale))/100f));
        return Math.max(dp(156),Math.min((int)(base*1.34f),(int)(base*pct)));
    }
    private void addGiftParticles(FrameLayout overlay,String name,int count){
        String n=name.toLowerCase(Locale.US);String symbol=n.contains("rose")?"🌹":n.contains("heart")?"❤":n.contains("diamond")?"✦":n.contains("crown")?"✧":"✦";
        int w=getResources().getDisplayMetrics().widthPixels,h=getResources().getDisplayMetrics().heightPixels;
        for(int i=0;i<count;i++){
            final TextView p=t(symbol,14+(i%4)*3,Color.WHITE,true);p.setGravity(Gravity.CENTER);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(34),dp(34));overlay.addView(p,lp);
            float x=(w*.08f)+((i*73)%(Math.max(1,(int)(w*.84f))));float y=h*(.70f+(i%5)*.035f);p.setX(x);p.setY(y);p.setAlpha(0f);p.setScaleX(.3f);p.setScaleY(.3f);
            long delay=(i%7)*70L;p.animate().alpha(.95f).scaleX(1f).scaleY(1f).translationY(-h*(.28f+(i%5)*.065f)).translationX(((i%2==0)?1:-1)*dp(18+(i%4)*9)).rotationBy((i%2==0?1:-1)*(80+(i%5)*22)).setStartDelay(delay).setDuration(1250+(i%4)*180L).withEndAction(()->p.animate().alpha(0f).setDuration(260).start()).start();
        }
    }
    private void animateGiftArt(ImageView art,String name,String sizeMode){
        String n=name.toLowerCase(Locale.US);art.setAlpha(0f);art.setScaleX(.35f);art.setScaleY(.35f);
        if(n.contains("car")){art.setTranslationX(-getResources().getDisplayMetrics().widthPixels*.85f);art.setTranslationY(dp(55));art.setRotation(-4f);art.setAlpha(1f);art.setScaleX(.9f);art.setScaleY(.9f);art.animate().translationX(getResources().getDisplayMetrics().widthPixels*.88f).translationY(-dp(10)).rotation(3f).scaleX(1.15f).scaleY(1.15f).setDuration(3200).start();return;}
        if(n.contains("jet")){art.setTranslationX(-getResources().getDisplayMetrics().widthPixels*.72f);art.setTranslationY(getResources().getDisplayMetrics().heightPixels*.28f);art.setRotation(-18f);art.setAlpha(1f);art.animate().translationX(getResources().getDisplayMetrics().widthPixels*.76f).translationY(-getResources().getDisplayMetrics().heightPixels*.30f).rotation(8f).scaleX(1.25f).scaleY(1.25f).setDuration(3400).start();return;}
        if(n.contains("rose")){art.setTranslationY(dp(170));art.setRotation(-14f);art.animate().alpha(1f).translationY(-dp(35)).rotation(10f).scaleX(1.08f).scaleY(1.08f).setDuration(1450).withEndAction(()->art.animate().rotation(-4f).scaleX(.98f).scaleY(.98f).setDuration(820).start()).start();return;}
        if(n.contains("heart")||n.contains("teddy")){art.animate().alpha(1f).scaleX(1.18f).scaleY(1.18f).setDuration(330).withEndAction(()->art.animate().scaleX(.92f).scaleY(.92f).setDuration(220).withEndAction(()->art.animate().scaleX(1.08f).scaleY(1.08f).setDuration(260).withEndAction(()->art.animate().scaleX(1f).scaleY(1f).setDuration(260).start()).start()).start()).start();return;}
        if(n.contains("crown")||n.contains("diamond")||n.contains("star")){art.setRotation(-28f);art.animate().alpha(1f).rotation(14f).scaleX(1.22f).scaleY(1.22f).setDuration(820).withEndAction(()->art.animate().rotation(-7f).scaleX(.94f).scaleY(.94f).setDuration(340).withEndAction(()->art.animate().rotation(0f).scaleX(1.06f).scaleY(1.06f).setDuration(340).start()).start()).start();return;}
        if(n.contains("castle")){art.setTranslationY(dp(90));art.animate().alpha(1f).translationY(-dp(18)).scaleX(1.08f).scaleY(1.08f).setDuration(1750).withEndAction(()->art.animate().scaleX(1f).scaleY(1f).setDuration(500).start()).start();return;}
        art.animate().alpha(1f).scaleX(1.08f).scaleY(1.08f).rotationBy(360f).setDuration(1850).start();
    }
    private void showGiftEffect(JSONObject gift,JSONObject result){
        cachedGiftCatalog=null;cachedGiftCatalogAt=0L;
        final int combo=Math.max(1,result.optInt("combo",1));final String name=gift.optString("name","Gift");final int scale=giftScale(gift);final String sizeMode=giftModeForScale(scale);final int price=gift.optInt("price",0);final String receiver=result.optString("receiverId",hostId);final String streak=combo>1?"  ×"+combo+" COMBO":"";
        playGiftSound(gift);
        if(giftInt(gift,"animation_enabled","animationEnabled",1)!=1){prefetchGiftCatalog();return;}
        final boolean cinematic=scale>=62||price>=1000;
        final FrameLayout overlay=new FrameLayout(this);overlay.setClickable(false);overlay.setBackgroundColor(Color.argb(cinematic?("FULL_SCREEN".equals(sizeMode)?150:95):24,5,7,25));addContentView(overlay,new android.view.ViewGroup.LayoutParams(-1,-1));
        addGiftParticles(overlay,name,cinematic?34:18);
        final ImageView art=new ImageView(this);art.setScaleType(ImageView.ScaleType.CENTER_INSIDE);setGiftArt(art,gift);int artPx=giftArtPx(scale);String boardPos=gift.optString("board_position","CENTER").toUpperCase(Locale.US);int giftGravity="TOP".equals(boardPos)?(Gravity.TOP|Gravity.CENTER_HORIZONTAL):"BOTTOM".equals(boardPos)?(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL):Gravity.CENTER;if("FULL_SCREEN".equals(boardPos))artPx=Math.max(artPx,Math.min(getResources().getDisplayMetrics().widthPixels,getResources().getDisplayMetrics().heightPixels));FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(artPx,artPx,giftGravity);if("TOP".equals(boardPos))ap.topMargin=dp(115);else if("BOTTOM".equals(boardPos))ap.bottomMargin=dp(115);overlay.addView(art,ap);
        TextView glow=t("✦     ✧     ✦",cinematic?34:24,Color.rgb(255,230,125),true);glow.setGravity(Gravity.CENTER);glow.setAlpha(.25f);FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(-1,dp(70),Gravity.CENTER);overlay.addView(glow,gp);ObjectAnimator pulse=ObjectAnimator.ofFloat(glow,"alpha",.18f,.9f,.18f);pulse.setDuration(780);pulse.setRepeatCount(3);pulse.start();
        animateGiftArt(art,name,sizeMode);
        String sender=result.optString("senderName",SessionManager.getFullName(this));if(sender==null||sender.trim().isEmpty())sender="Supporter";String currency=gift.optString("currency","COIN");
        LinearLayout giftMeta=col();giftMeta.setGravity(Gravity.CENTER);giftMeta.setPadding(dp(10),dp(4),dp(10),dp(5));giftMeta.setBackground(bg(Color.argb(175,10,13,37),Color.argb(220,255,201,78),14));
        TextView who=t(sender+"  •  "+name+(streak.isEmpty()?"":streak),9.2f,Color.WHITE,true);who.setGravity(Gravity.CENTER);giftMeta.addView(who,new LinearLayout.LayoutParams(-2,dp(21)));
        TextView val=t(("GOLD".equals(currency)?"👑 ":"🪙 ")+price+("GOLD".equals(currency)?" Gold Coin":" Coin"),8.8f,Color.rgb(255,210,71),true);val.setGravity(Gravity.CENTER);giftMeta.addView(val,new LinearLayout.LayoutParams(-2,dp(20)));
        FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(-2,dp(47),Gravity.CENTER);mp.topMargin=Math.min(dp(245),Math.max(dp(115),artPx/2+dp(30)));overlay.addView(giftMeta,mp);
        long configuredStay=Math.max(500,gift.optInt("effect_duration_ms",scale>=90?4200:cinematic?3600:3000));long stay=Math.max(3200,Math.min(18000,Math.round(configuredStay*1.45f)));handler.postDelayed(()->overlay.animate().alpha(0f).setDuration(420).withEndAction(()->{if(overlay.getParent()!=null)((android.view.ViewGroup)overlay.getParent()).removeView(overlay);}).start(),stay);
        prefetchGiftCatalog();
    }

    private void openUserProfile(JSONObject u){if(u==null)return;String uid=u.optString("user_id",u.optString("userId",""));if(uid.isEmpty())return;Intent i=new Intent(this,UserProfileActivity.class);i.putExtra("userId",uid);startActivity(i);}

    private void showMiniProfile(JSONObject u){String uid=u.optString("user_id",u.optString("userId",""));if(uid.isEmpty())return;String tier=u.optString("tier","STANDARD"),name=u.optString("full_name",u.optString("name","User"));String[] actions=uid.equals(hostId)?new String[]{"Open Creator Profile","Follow Host","Message","Fan Club","⚑ Report / Block"}:new String[]{"Open Profile","Follow","Message","⚑ Report / Block"};new AlertDialog.Builder(this).setTitle(name+" • "+tier).setMessage("ID "+uid+"  •  🏅LV."+u.optInt("level",0)+(u.optInt("fan_points",u.optInt("fanPoints",0))>0?"\n⭐ Fan Points "+u.optInt("fan_points",u.optInt("fanPoints",0)):"")).setItems(actions,(d,w)->{if((uid.equals(hostId)&&w==4)||(!uid.equals(hostId)&&w==3)){SafetyActions.show(this,uid,"LIVE_USER",hostId);return;}if(w==0){if(uid.equals(hostId))openCreatorCenter(uid);else{Intent i=new Intent(this,UserProfileActivity.class);i.putExtra("userId",uid);startActivity(i);}}else if(w==1){BackendClient.toggleFollow(token(),uid,new ToastCb("Follow updated"));}else if(w==2){Intent i=new Intent(this,ChatActivity.class);i.putExtra("userId",uid);i.putExtra("name",name);startActivity(i);}else if(uid.equals(hostId)&&w==3)showFanClub();}).setNegativeButton("Close",null).show();}
    private void showLiveCommunityMenu(){new AlertDialog.Builder(this).setTitle("Live Community").setItems(new String[]{"Host Creator Profile","Fan Club / Supporters","Scheduled Lives","Follow Host"},(d,w)->{if(w==0)openCreatorCenter(hostId);else if(w==1)showFanClub();else if(w==2)showSchedules(hostId);else BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));}).show();}
    private void openCreatorCenter(String uid){Intent i=new Intent(this,CreatorCenterActivity.class);i.putExtra("userId",uid);startActivity(i);}
    private void showFanClub(){BackendClient.liveFanClub(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("members");StringBuilder z=new StringBuilder("Members: ").append(d.optInt("memberCount",0)).append("\nYour points: ").append(d.optLong("points",0)).append("\n\n");if(a!=null)for(int i=0;i<Math.min(8,a.length());i++){JSONObject x=a.optJSONObject(i);if(x!=null)z.append(i+1).append(". ").append(x.optString("full_name","User")).append(" • ").append(x.optLong("points",0)).append(" pts\n");}AlertDialog.Builder b=new AlertDialog.Builder(AudioLiveRoomActivity.this).setTitle("⭐ Fan Club").setMessage(z.toString()).setNegativeButton("Close",null);if(!host)b.setPositiveButton(d.optBoolean("joined",false)?"Leave Fan Club":"Join Fan Club",(q,w)->BackendClient.liveFanClubToggle(token(),hostId,new ToastCb("Fan Club updated")));b.show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}
    private void editWelcome(){EditText e=new EditText(this);e.setHint("Welcome message / room rules");new AlertDialog.Builder(this).setTitle("Room Welcome").setView(e).setPositiveButton("Save",(d,w)->BackendClient.livePremiumConfig(token(),e.getText().toString().trim(),null,-1,-1,new ToastCb("Welcome updated"))).setNegativeButton("Cancel",null).show();}
    private void editGoal(){String[] types={"COIN","SUPPORTERS","MINUTES","VIEWERS","NONE"};new AlertDialog.Builder(this).setTitle("Live Goal Type").setItems(types,(d,w)->{String type=types[w];if("NONE".equals(type)){BackendClient.livePremiumConfig(token(),null,"NONE",0,-1,new ToastCb("Goal cleared"));return;}EditText e=new EditText(this);e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);e.setHint("Target");new AlertDialog.Builder(this).setTitle(type+" target").setView(e).setPositiveButton("Save",(q,x)->{long target=0;try{target=Long.parseLong(e.getText().toString().trim());}catch(Exception ignored){}BackendClient.livePremiumConfig(token(),null,type,target,-1,new ToastCb("Live Goal updated"));}).setNegativeButton("Cancel",null).show();}).show();}
    private void choosePinnedProduct(){BackendClient.storeCatalog(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray raw=d.optJSONArray("products");if(raw==null)raw=d.optJSONArray("catalog");final JSONArray a=raw;if(a==null||a.length()==0){Toast.makeText(AudioLiveRoomActivity.this,"No enabled Shop items",Toast.LENGTH_SHORT).show();return;}String[] names=new String[a.length()+1];long[] ids=new long[a.length()+1];names[0]="Clear pinned product";ids[0]=0;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);names[i+1]=x==null?"Item":x.optString("title","Item")+" • "+x.optLong("coin_price",x.optLong("coinPrice",0))+" Coin";ids[i+1]=x==null?0:x.optLong("id",0);}new AlertDialog.Builder(AudioLiveRoomActivity.this).setTitle("🛍 Live Shop • Pin Item").setItems(names,(q,w)->BackendClient.livePremiumConfig(token(),null,null,-1,ids[w],new ToastCb(w==0?"Product pin cleared":"Product pinned"))).show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}
    private void showSchedules(String uid){BackendClient.liveSchedules(token(),uid,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("schedules");if(a==null||a.length()==0){Toast.makeText(AudioLiveRoomActivity.this,"No scheduled live",Toast.LENGTH_SHORT).show();return;}String[] x=new String[a.length()];for(int i=0;i<a.length();i++){JSONObject z=a.optJSONObject(i);x[i]=(z==null?"Scheduled Live":z.optString("title","Scheduled Live")+" • "+z.optString("scheduled_at",""));}new AlertDialog.Builder(AudioLiveRoomActivity.this).setTitle("🔔 Scheduled Lives").setItems(x,(q,w)->{JSONObject z=a.optJSONObject(w);if(z!=null&&!host)BackendClient.liveScheduleReminder(token(),z.optLong("id"),new ToastCb("Reminder updated"));}).setNegativeButton("Close",null).show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}
    private void showScheduleDialog(){LinearLayout box=col();EditText title=new EditText(this);title.setHint("Live title");EditText topic=new EditText(this);topic.setHint("Topic");EditText at=new EditText(this);at.setHint("YYYY-MM-DD HH:MM:SS");box.addView(title);box.addView(topic);box.addView(at);new AlertDialog.Builder(this).setTitle("🔔 Schedule Live").setView(box).setPositiveButton("Save",(d,w)->BackendClient.liveScheduleSave(token(),0,title.getText().toString().trim(),topic.getText().toString().trim(),at.getText().toString().trim(),new ToastCb("Live scheduled"))).setNeutralButton("View Schedules",(d,w)->showSchedules(hostId)).setNegativeButton("Cancel",null).show();}
    private void showPkDialog(){EditText e=new EditText(this);e.setHint("Other LIVE Host ID");e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);new AlertDialog.Builder(this).setTitle("⚔ Friendly PK / Battle").setMessage("Both hosts must already be live. V-304 foundation scores completed gifts during the PK.").setView(e).setPositiveButton("Invite",(d,w)->BackendClient.livePkStart(token(),e.getText().toString().trim(),new ToastCb("PK invitation sent"))).setNegativeButton("Cancel",null).show();}
    private void showIncomingPk(long id){new AlertDialog.Builder(this).setTitle("⚔ PK Invitation").setMessage("Another live host invited this room to a friendly PK.").setPositiveButton("Accept",(d,w)->BackendClient.livePkAction(token(),id,"ACCEPT",new ToastCb("PK started"))).setNegativeButton("Decline",(d,w)->BackendClient.livePkAction(token(),id,"DECLINE",new ToastCb("PK declined"))).show();}
    private void showAudienceEndSummary(){if(endedSummaryShown)return;endedSummaryShown=true;BackendClient.liveSummary(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONObject x=d.optJSONObject("summary");if(x!=null)showSummary(x);else{Toast.makeText(AudioLiveRoomActivity.this,"Live ended",Toast.LENGTH_SHORT).show();finish();}});}public void onError(String m){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,"Live ended",Toast.LENGTH_SHORT).show();finish();});}});}


    private void updateSpeakerControls(){
        if(speakerActionButton!=null){speakerActionButton.setText(host?"End":("SPEAKER".equals(myRole)?"Leave":"Join"));}
        if(micButton!=null){boolean canTalk=host||"SPEAKER".equals(myRole);micButton.setAlpha(canTalk?1f:.42f);micButton.setEnabled(canTalk&&!listenOnly);}
        updateJoinButtonAnimation();
    }
    private void updateJoinButtonAnimation(){
        if(speakerActionButton==null)return;
        boolean animate=!host&&!"SPEAKER".equals(myRole)&&!listenOnly;
        if(!animate){
            if(joinPulseAlpha!=null){joinPulseAlpha.cancel();joinPulseAlpha=null;}
            if(joinPulseX!=null){joinPulseX.cancel();joinPulseX=null;}
            if(joinPulseY!=null){joinPulseY.cancel();joinPulseY=null;}
            speakerActionButton.setAlpha(1f);speakerActionButton.setScaleX(1f);speakerActionButton.setScaleY(1f);return;
        }
        if(joinPulseAlpha!=null)return;
        joinPulseAlpha=ObjectAnimator.ofFloat(speakerActionButton,"alpha",.86f,1f);joinPulseAlpha.setDuration(1250);joinPulseAlpha.setRepeatCount(ValueAnimator.INFINITE);joinPulseAlpha.setRepeatMode(ValueAnimator.REVERSE);
        joinPulseX=ObjectAnimator.ofFloat(speakerActionButton,"scaleX",1f,1.055f);joinPulseX.setDuration(1250);joinPulseX.setRepeatCount(ValueAnimator.INFINITE);joinPulseX.setRepeatMode(ValueAnimator.REVERSE);
        joinPulseY=ObjectAnimator.ofFloat(speakerActionButton,"scaleY",1f,1.055f);joinPulseY.setDuration(1250);joinPulseY.setRepeatCount(ValueAnimator.INFINITE);joinPulseY.setRepeatMode(ValueAnimator.REVERSE);
        joinPulseAlpha.start();joinPulseX.start();joinPulseY.start();
    }
    private void requestJoinToCall(){
        if(roomEnded||endLiveInProgress)return;
        BackendClient.liveSpeakRequest(token(),hostId,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->showFloatingBanner("✋ Join request sent"));}
            public void onError(String m){runOnUiThread(()->showFloatingBanner("⚠ "+(m==null||m.trim().isEmpty()?"Join request failed":m)));}
        });
    }
    private void confirmLeaveSeat(){
        new AlertDialog.Builder(this).setTitle("Leave call?").setMessage("You will leave the speaker seat but stay in the Live as audience.").setPositiveButton("Leave Call",(d,w)->BackendClient.liveLeaveSeat(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->{myRole="AUDIENCE";currentSeatNo=0;localMicOn=true;if(rtcManager!=null){rtcManager.setPublishAudio(false);rtcManager.setMicEnabled(false);}requestRtcToken(false);updateSpeakerControls();Toast.makeText(AudioLiveRoomActivity.this,"Left the call • still watching Live",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}})).setNegativeButton("Stay",null).show();
    }
    private void moveMySeat(int seatNo){
        if(!"SPEAKER".equals(myRole)||seatNo<2||seatNo>9||seatNo==currentSeatNo)return;
        BackendClient.liveSelfSeatAssign(token(),hostId,seatNo,new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->{currentSeatNo=seatNo;Toast.makeText(AudioLiveRoomActivity.this,"Moved to seat "+seatNo,Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});
    }
    private void showSelfSeatChooser(){
        java.util.ArrayList<Integer> nums=new java.util.ArrayList<>();java.util.ArrayList<String> labels=new java.util.ArrayList<>();
        for(int seatNo=2;seatNo<=9;seatNo++){if(seatNo==currentSeatNo||lockedSeats.contains(seatNo))continue;JSONObject x=findSeat(currentSeats,seatNo);if(x!=null)continue;nums.add(seatNo);labels.add("Guest Seat "+seatNo);}
        if(nums.isEmpty()){Toast.makeText(this,"No free seat available",Toast.LENGTH_SHORT).show();return;}
        new AlertDialog.Builder(this).setTitle("Change Seat").setItems(labels.toArray(new String[0]),(d,w)->moveMySeat(nums.get(w))).setNegativeButton("Cancel",null).show();
    }
    private void showSelfSpeakerMenu(){
        String mic=localMicOn?"Mute microphone":"Unmute microphone";
        new AlertDialog.Builder(this).setTitle("My Call Controls").setItems(new String[]{"Change seat",mic,"Leave call"},(d,w)->{if(w==0)showSelfSeatChooser();else if(w==1)toggleMic();else confirmLeaveSeat();}).setNegativeButton("Close",null).show();
    }

    private void showSpeakerActions(JSONObject x){final String uid=x.optString("user_id","");final boolean special=uid.equals(specialGuestId);String[] actions=special?new String[]{"Open Profile","🎁 Send Gift","Remove from Special Guest","Move to Guest Seat","Remove Speaker from Seat"}:new String[]{"Open Profile","🎁 Send Gift","Make Special Guest","Move to Guest Seat","Remove Speaker from Seat"};new AlertDialog.Builder(this).setTitle(x.optString("full_name","Speaker")).setItems(actions,(d,which)->{if(which==0){openUserProfile(x);return;}if(which==1){if(uid.equals(SessionManager.getUserId(this))){Toast.makeText(this,"You cannot gift yourself",Toast.LENGTH_SHORT).show();return;}giftReceiverId=uid;giftReceiverName=x.optString("full_name","User");showGiftPanel();return;}int a=which-2;if(a==0)BackendClient.liveSpecialGuest(token(),uid,special,new ToastCb(special?"Special Guest removed":"Special Guest selected"));else if(a==1)showSeatChooser(uid);else BackendClient.liveSpeakerRemove(token(),uid,new ToastCb("Speaker removed"));}).show();}
    private void showSeatChooser(String uid){String[] items=new String[8];for(int i=0;i<8;i++)items[i]="Guest Seat "+(i+2)+(lockedSeats.contains(i+2)?" • Locked":"");new AlertDialog.Builder(this).setTitle("Move Speaker to Guest Seat").setItems(items,(d,w)->BackendClient.liveSeatAssign(token(),uid,w+2,new ToastCb("Guest seat updated"))).setNegativeButton("Cancel",null).show();}
    private void clearSpecialGuest(){if(!host||specialGuestId.isEmpty())return;new AlertDialog.Builder(this).setTitle("Special Guest").setMessage("Return this guest to a normal speaker seat?").setPositiveButton("Remove Spotlight",(d,w)->BackendClient.liveSpecialGuest(token(),specialGuestId,true,new ToastCb("Spotlight cleared"))).setNegativeButton("Cancel",null).show();}

    private void confirmLeaveLive(){new AlertDialog.Builder(this).setTitle("Leave Live?").setMessage("Leave this live room?").setPositiveButton("Leave",(d,w)->finish()).setNegativeButton("Stay",null).show();}
    private void confirmEndLive(){
        if(endLiveInProgress||roomEnded)return;
        new AlertDialog.Builder(this).setTitle("End Live?").setMessage("This will end the room for everyone.")
                .setPositiveButton("End Live",(d,w)->endHostLive()).setNegativeButton("Cancel",null).show();
    }
    private void endHostLive(){
        if(endLiveInProgress||roomEnded)return;
        endLiveInProgress=true;hostStarted=false;
        handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);handler.removeCallbacks(realtimeTick);handler.removeCallbacks(presenceTick);handler.removeCallbacks(participantTick);
        stopVoiceMonitor(false);
        if(rtcManager!=null)rtcManager.leave();
        syncState.setText("Ending live…");
        if(premiumStrip!=null)premiumStrip.setText("Ending live…");
        // First tap is authoritative locally: leave the room UI immediately; backend end is idempotent and auto-retried.
        endHostLiveAttempt(1);
        handler.postDelayed(()->{if(!isFinishing()){roomEnded=true;finish();}},220L);
    }
    private void endHostLiveAttempt(final int attempt){
        if(roomEnded)return;
        BackendClient.endLive(token(),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                if(roomEnded)return;
                if(!d.optBoolean("closed",false)){
                    handler.postDelayed(()->endHostLiveAttempt(attempt+1),Math.min(3000L,500L+attempt*350L));
                    return;
                }
                roomEnded=true;endLiveInProgress=false;hostStarted=false;
                handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);handler.removeCallbacks(realtimeTick);handler.removeCallbacks(presenceTick);handler.removeCallbacks(participantTick);pendingComments.clear();
                final JSONObject closeSummary=d.optJSONObject("summary");
                BackendClient.liveSummary(token(),hostId,new BackendClient.Callback(){
                    public void onSuccess(JSONObject ss){runOnUiThread(()->{JSONObject x=ss.optJSONObject("summary");if(x!=null)showSummary(x);else if(closeSummary!=null)showSummary(closeSummary);else showClosedWithoutSummary("The room is closed.");});}
                    public void onError(String m){runOnUiThread(()->{if(closeSummary!=null)showSummary(closeSummary);else showClosedWithoutSummary("The room is closed.");});}
                });
            });}
            public void onError(String m){
                if(roomEnded)return;
                // One tap is enough: keep retrying automatically. Do not return the room to LIVE/Reconnecting.
                handler.postDelayed(()->endHostLiveAttempt(attempt+1),Math.min(4000L,650L+attempt*450L));
            }
        });
    }
    private void endLiveFailed(String message){
        // V-311 compatibility method: never re-activate an End request.
        if(roomEnded)return;endLiveInProgress=true;hostStarted=false;syncState.setText("Ending live…");
        handler.postDelayed(()->endHostLiveAttempt(1),1200L);
    }
    private void showClosedWithoutSummary(String message){
        roomEnded=true;endLiveInProgress=false;syncState.setText("Live ended • server confirmed");hostStarted=false;
        handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);handler.removeCallbacks(realtimeTick);handler.removeCallbacks(presenceTick);handler.removeCallbacks(participantTick);pendingComments.clear();
        new AlertDialog.Builder(this).setTitle("Live ended").setMessage(message).setPositiveButton("DONE",(d,w)->finish()).setCancelable(false).show();
    }

    private void showSummary(JSONObject x){
        if(x==null){showClosedWithoutSummary("The room is closed.");return;}
        long duration=Math.max(0,x.optLong("duration_seconds",x.optLong("elapsedSeconds",0)));
        long peak=Math.max(0,x.optLong("peak_viewers",x.optLong("peakViewers",0)));
        long listeners=Math.max(0,x.optLong("total_listeners",x.optLong("totalListeners",0)));
        long reactions=Math.max(0,x.optLong("react_count",x.optLong("reactCount",0)));
        String msg="Duration  "+hhmmss(duration)+"\nPeak viewers  "+peak+"\nListeners  "+listeners+"\nReactions  "+reactions;
        new AlertDialog.Builder(this).setTitle("Live ended").setMessage(msg).setPositiveButton("DONE",(d,w)->finish()).setCancelable(false).show();
    }

    private void renderPremiumState(JSONObject d){
        if(d==null||premiumStrip==null)return;
        String tier=d.optString("myTier",d.optString("membershipTier","")).trim();
        String role=d.optString("myRole",host?"HOST":"AUDIENCE");
        String net=networkQuality();
        StringBuilder line=new StringBuilder("✦ ").append(role).append(" • ").append(net);
        if(!tier.isEmpty()&&!"FREE".equalsIgnoreCase(tier))line.append(" • ").append(tier);
        premiumStrip.setText(line.toString());
    }

    private JSONObject findSeat(JSONArray a,int seatNo){if(a==null)return null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&x.optInt("seat_no")==seatNo)return x;}return null;}
    private JSONObject findUser(JSONArray a,String userId){if(a==null||userId==null||userId.isEmpty())return null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&userId.equals(x.optString("user_id")))return x;}return null;}

    private boolean isRtcSpeaking(JSONObject x,boolean hostAvatar){
        if(System.currentTimeMillis()-activeRtcSpeakerAt>900L)return false;
        if(activeRtcSpeakerUid<0)return false;
        if(activeRtcSpeakerUid==0)return (hostAvatar&&host)||(!hostAvatar&&x!=null&&SessionManager.getUserId(this).equals(x.optString("user_id","")));
        String uid=x==null?(hostAvatar?hostId:""):x.optString("user_id",hostAvatar?hostId:"");
        try{return Integer.parseInt(uid)==activeRtcSpeakerUid;}catch(Exception ignored){return false;}
    }

    private FrameLayout avatarWithMicState(JSONObject x,int size,boolean speaking){
        FrameLayout wrap=new FrameLayout(this);
        String url=x==null?"":x.optString("avatar_url","");
        String tier=x==null?"STANDARD":x.optString("tier","STANDARD");
        FrameLayout av=circleAvatar(url,size,speaking,tier);wrap.addView(av,new FrameLayout.LayoutParams(-1,-1));
        boolean muted=x!=null&&(x.optInt("mic_on",1)==0||x.optInt("muted",0)==1);
        if(muted){TextView m=t("🎙✕",Math.max(6.8f,size/7.0f),Color.rgb(255,82,94),true);m.setGravity(Gravity.CENTER);m.setBackground(bg(Color.argb(225,45,10,24),Color.rgb(255,70,84),9));FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(24),dp(16),Gravity.RIGHT|Gravity.BOTTOM);mp.rightMargin=-dp(2);mp.bottomMargin=-dp(1);wrap.addView(m,mp);}
        return wrap;
    }

    private FrameLayout circleAvatar(String url,int size,boolean speaking){return circleAvatar(url,size,speaking,"STANDARD");}
    private FrameLayout circleAvatar(String url,int size,boolean speaking,String tier){
        FrameLayout frame=new FrameLayout(this);int premiumStroke="KING".equalsIgnoreCase(tier)?Color.rgb(76,173,255):"QUEEN".equalsIgnoreCase(tier)?Color.rgb(255,92,194):"ROYAL".equalsIgnoreCase(tier)?Color.rgb(255,203,69):"VVIP".equalsIgnoreCase(tier)?Color.rgb(221,91,255):"VIP".equalsIgnoreCase(tier)?Color.rgb(79,170,255):Color.rgb(212,165,61);
        int stroke=speaking?Color.rgb(255,214,84):premiumStroke;frame.setBackground(bg(Color.argb(210,25,33,82),stroke,size/2));
        ImageView v=new ImageView(this);v.setImageResource(android.R.drawable.sym_def_app_icon);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(bg(Color.rgb(34,45,105),stroke,size/2));v.setClipToOutline(true);
        int pad=dp("STANDARD".equals(tier)?3:4);FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,-1);ip.setMargins(pad,pad,pad,pad);frame.addView(v,ip);
        if(url!=null&&!url.trim().isEmpty())loadImage(v,url);
        // Speaking effect animates only the ring/glow. The profile photo itself stays perfectly still.
        if(speaking){TextView ring=t("",1,Color.TRANSPARENT,false);ring.setBackground(bg(Color.TRANSPARENT,Color.rgb(255,221,102),size/2));FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(-1,-1);rp.setMargins(dp(1),dp(1),dp(1),dp(1));frame.addView(ring,rp);ObjectAnimator glow=ObjectAnimator.ofFloat(ring,"alpha",.22f,1f,.22f);glow.setDuration(520);ObjectAnimator gx=ObjectAnimator.ofFloat(ring,"scaleX",1.02f,1.34f,1.02f);gx.setDuration(620);gx.setRepeatCount(ValueAnimator.INFINITE);gx.start();ObjectAnimator gy=ObjectAnimator.ofFloat(ring,"scaleY",1.02f,1.34f,1.02f);gy.setDuration(620);gy.setRepeatCount(ValueAnimator.INFINITE);gy.start();glow.setRepeatCount(ValueAnimator.INFINITE);glow.start();ring.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View x){}public void onViewDetachedFromWindow(View x){glow.cancel();gx.cancel();gy.cancel();}});}
        return frame;
    }
    private void loadImage(ImageView v,String u){Bitmap cached=avatarCache.get(u);if(cached!=null){v.setImageBitmap(cached);return;}new Thread(()->{try{Bitmap b=BitmapFactory.decodeStream(new URL(u).openStream());if(b!=null){synchronized(avatarCache){avatarCache.put(u,b);while(avatarCache.size()>80){String k=avatarCache.keySet().iterator().next();avatarCache.remove(k);}}runOnUiThread(()->v.setImageBitmap(b));}}catch(Exception ignored){}}).start();}

    private String networkQuality(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);NetworkInfo n=cm==null?null:cm.getActiveNetworkInfo();if(n==null||!n.isConnected())return "OFFLINE";return n.getType()==ConnectivityManager.TYPE_WIFI?"GOOD":"FAIR";}catch(Exception e){return "GOOD";}}
    private String signal(String q){q=q==null?"GOOD":q.toUpperCase();if("WEAK".equals(q)||"OFFLINE".equals(q))return "▂";if("FAIR".equals(q))return "▂▄";return "▂▄▆";}
    private long parseServerTime(String s){if(s==null||s.trim().isEmpty())return 0;String[] patterns={"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd'T'HH:mm:ss.SSS'Z'","yyyy-MM-dd'T'HH:mm:ss'Z'"};for(String p:patterns){try{SimpleDateFormat f=new SimpleDateFormat(p,Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));Date d=f.parse(s);if(d!=null)return d.getTime();}catch(Exception ignored){}}return 0;}
    private String summaryTime(String s){if(s==null||s.trim().isEmpty())return "—";String x=s.trim();return x.length()>=19?x.substring(11,19):x;}
    private String hhmm(long sec){long h=sec/3600,m=(sec%3600)/60;return String.format(Locale.US,"%02d:%02d",h,m);}
    private String hhmmss(long sec){long h=sec/3600,m=(sec%3600)/60,s=sec%60;return String.format(Locale.US,"%02d:%02d:%02d",h,m,s);}
    private String token(){return SessionManager.getToken(this);}

    @Override public void onBackPressed(){
        if(!roomEnded && !endLiveInProgress && Build.VERSION.SDK_INT>=26){
            try{PictureInPictureParams params=new PictureInPictureParams.Builder().setAspectRatio(new Rational(9,16)).build();enterPictureInPictureMode(params);return;}catch(Exception ignored){}
        }
        moveTaskToBack(true);
    }
    @Override protected void onDestroy(){handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);handler.removeCallbacks(realtimeTick);handler.removeCallbacks(presenceTick);handler.removeCallbacks(participantTick);if(joinPulseAlpha!=null)joinPulseAlpha.cancel();if(joinPulseX!=null)joinPulseX.cancel();if(joinPulseY!=null)joinPulseY.cancel();joinPulseAlpha=null;joinPulseX=null;joinPulseY=null;activeSessionId="";serverElapsedSec=0;serverElapsedSyncMs=0;pendingComments.clear();stopVoiceMonitor(false);if(rtcManager!=null){rtcManager.destroy();rtcManager=null;}if(giftLoadingDialog!=null&&giftLoadingDialog.isShowing())giftLoadingDialog.dismiss();if(giftStoreDialog!=null&&giftStoreDialog.isShowing())giftStoreDialog.dismiss();if(isFinishing()&&!roomEnded&&!host){BackendClient.liveLeaveSeat(token(),hostId,new Silent());BackendClient.liveViewer(token(),hostId,false,new Silent());}super.onDestroy();}


    private class GoldenGuestHalo extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF oval=new RectF();
        GoldenGuestHalo(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f;float r=Math.min(w,h)*.36f;
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2.2f));p.setColor(Color.rgb(255,194,47));p.setShadowLayer(dp(8),0,0,Color.rgb(255,139,22));c.drawCircle(cx,cy,r,p);p.clearShadowLayer();
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(255,190,42));
            for(int side=-1;side<=1;side+=2){for(int i=0;i<7;i++){float y=cy-r*.72f+i*r*.24f;float x=cx+side*(r+dp(5)+i*dp(.7f));c.save();c.rotate(side*(-32+i*5),x,y);oval.set(x-dp(5),y-dp(2.3f),x+dp(5),y+dp(2.3f));c.drawOval(oval,p);c.restore();}}
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));p.setColor(Color.rgb(255,221,97));oval.set(cx-r-dp(10),cy+r*.66f,cx+r+dp(10),cy+r+dp(12));c.drawArc(oval,188,164,false,p);
            // V-350 locked Final Reference: visible gold crown centered above Main Guest.
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(255,190,38));p.setShadowLayer(dp(6),0,dp(1),Color.rgb(255,116,20));
            float crownTop=cy-r-dp(12), crownBase=cy-r+dp(3), half=dp(25);Path crown=new Path();crown.moveTo(cx-half,crownBase);crown.lineTo(cx-half+dp(3),crownTop+dp(8));crown.lineTo(cx-dp(12),crownTop+dp(15));crown.lineTo(cx,crownTop);crown.lineTo(cx+dp(12),crownTop+dp(15));crown.lineTo(cx+half-dp(3),crownTop+dp(8));crown.lineTo(cx+half,crownBase);crown.close();c.drawPath(crown,p);p.clearShadowLayer();
            p.setColor(Color.rgb(255,226,94));c.drawCircle(cx,crownTop+dp(1.5f),dp(2.5f),p);c.drawCircle(cx-dp(21),crownTop+dp(9),dp(2.2f),p);c.drawCircle(cx+dp(21),crownTop+dp(9),dp(2.2f),p);
        }
    }

    class ToastCb implements BackendClient.Callback{String ok;ToastCb(String s){ok=s;}public void onSuccess(JSONObject d){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,ok,Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}}
    static class Silent implements BackendClient.Callback{public void onSuccess(JSONObject d){}public void onError(String m){}}

    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private Button btn(String s){Button b=new Button(this);b.setAllCaps(false);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setBackground(bg(Color.rgb(76,45,205),Color.rgb(217,46,255),18));return b;}
    private Button small(String s){Button b=btn(s);b.setTextSize(9.5f);b.setMinWidth(0);b.setMinimumWidth(0);return b;}
    private TextView t(String s,float z,int c,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private GradientDrawable bg(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private GradientDrawable gradient(int[] colors,int stroke,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private int dp(float x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
}
