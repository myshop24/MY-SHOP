package com.myshop.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import org.json.JSONObject;

/** V-230 server-backed dashboard palette cache. Defaults exactly match the approved MY SHOP reference palette. */
public final class ThemeConfig {
    public static final String DEF_BG="#07122F";
    public static final String DEF_BLUE="#2D72F6";
    public static final String DEF_PURPLE="#7B3FF2";
    public static final String DEF_PINK="#F02BB7";
    private static final String PREF="myshop_theme_v230";
    private ThemeConfig(){}

    public static int bg(Context c){return parse(migrated(c,"bg",DEF_BG,"#F8F9FD"),Color.rgb(7,18,47));}
    public static int blue(Context c){return parse(migrated(c,"blue",DEF_BLUE,"#2E2FBE"),Color.rgb(45,114,246));}
    public static int purple(Context c){return parse(migrated(c,"purple",DEF_PURPLE,"#5B26D6"),Color.rgb(123,63,242));}
    public static int pink(Context c){return parse(migrated(c,"pink",DEF_PINK,"#EB24A8"),Color.rgb(240,43,183));}
    public static String bgHex(Context c){return migrated(c,"bg",DEF_BG,"#F8F9FD");}
    public static String blueHex(Context c){return migrated(c,"blue",DEF_BLUE,"#2E2FBE");}
    public static String purpleHex(Context c){return migrated(c,"purple",DEF_PURPLE,"#5B26D6");}
    public static String pinkHex(Context c){return migrated(c,"pink",DEF_PINK,"#EB24A8");}

    /** Returns true when the cached palette changed. Invalid server values are ignored. */
    public static boolean cacheFromConfig(Context c, JSONObject config){
        if(config==null)return false;
        String bg=valid(config.optString("dashboard_bg_color",""))?config.optString("dashboard_bg_color"):bgHex(c);
        String blue=valid(config.optString("dashboard_blue_color",""))?config.optString("dashboard_blue_color"):blueHex(c);
        String purple=valid(config.optString("dashboard_purple_color",""))?config.optString("dashboard_purple_color"):purpleHex(c);
        String pink=valid(config.optString("dashboard_pink_color",""))?config.optString("dashboard_pink_color"):pinkHex(c);
        String old=bgHex(c)+blueHex(c)+purpleHex(c)+pinkHex(c); String now=bg+blue+purple+pink;
        if(old.equalsIgnoreCase(now))return false;
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("bg",bg.toUpperCase()).putString("blue",blue.toUpperCase()).putString("purple",purple.toUpperCase()).putString("pink",pink.toUpperCase()).apply();
        return true;
    }
    public static boolean valid(String s){return s!=null&&s.trim().matches("#[0-9A-Fa-f]{6}");}
    private static String get(Context c,String k,String d){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(k,d);}
    private static String migrated(Context c,String k,String d,String oldDefault){String v=get(c,k,d);return oldDefault.equalsIgnoreCase(v)?d:v;}
    private static int parse(String s,int fallback){try{return Color.parseColor(s);}catch(Exception e){return fallback;}}
}
