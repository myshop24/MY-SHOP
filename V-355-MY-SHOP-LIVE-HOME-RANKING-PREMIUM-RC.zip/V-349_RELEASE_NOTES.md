# MY SHOP V-349 — Stabilization Release Notes

Base: V-348 correct source branch (`v348_work`), NOT the older compact branch that produced the wrong runtime Live layout.
Android: versionCode 349 / versionName 2.9.349
Worker identity: 2.9.349 / V-349

## Implemented
- Locked Live Room source to the final approved 8-seat (2–9, 4+4) layout.
- Main Guest uses MY SHOP LIVE logo, Main Guest label and crown/laurel halo when empty; real guest avatar when occupied.
- Empty user seats use the white chair icon in gray translucent circles; obsolete MS-logo empty-seat asset removed.
- Top-right Exit is red X with transparent background.
- Gift sender now gets the prominent Gift Activity row immediately after successful send; remote viewers receive the same structured gift row from gift events. Generic small GIFT event rows are suppressed.
- Gift sound playback hardened: explicit media/sonification audio attributes, built-in raw fallback, custom-URL timeout fallback, volume handling and loudness enhancement.
- Persistent login restored using valid backend sessions. Session token is Android Keystore AES/GCM encrypted, with migration from the legacy preference token.
- Message/Live notification plumbing retained and hardened with a notification-safe monochrome icon, client config flag, token-registration state and Admin System Health diagnostics for client permission/config + Worker FCM server configuration/token count.
- Current audio-only Live now depends on Agora `voice-sdk:4.6.4` instead of the video/full SDK to reduce release size while preserving current audio RTC APIs.
- V-349 static stabilization validator added.

## External runtime requirements
System push cannot work from source code alone. The GitHub release build must receive `MYSHOP_FIREBASE_API_KEY`, `MYSHOP_FIREBASE_APP_ID`, `MYSHOP_FIREBASE_PROJECT_ID`, `MYSHOP_FIREBASE_SENDER_ID`, and the deployed Worker must have `FCM_SERVICE_ACCOUNT_JSON`. These secrets are intentionally not stored in the source ZIP.

## Acceptance rule
Do not call V-349 runtime-final merely because GitHub is Green. Install the produced APK and compare the Live Room against `APPROVED-V349-LIVE-ROOM-FINAL-REFERENCE.png`, then test Gift sound/comment, restart login persistence and background/closed-app message + Live push on real devices.
