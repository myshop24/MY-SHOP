# MY SHOP V-347 — REGRESSION QA

- PASS — SOURCE_BUILD_ID is `MY SHOP V-347`.
- PASS — Android versionCode/versionName are 347 / 2.9.347.
- PASS — Worker health/build identity is 2.9.347 / V-347.
- PASS — `live_empty_seat_myshop.png` is a true PNG (not JPEG bytes with a PNG extension).
- PASS — approved MY SHOP MS image is referenced by the empty Guest-seat renderer.
- PASS — occupied Guest seats still use backend `avatar_url`.
- PASS — Host has signed-in profile-avatar fallback if seat-1 data is temporarily null.
- PASS — existing seat range/allocation logic is unchanged.
- PASS — Back/PiP, Join/Leave, Exit, pin permissions, Gift presentation and Agora speech tuning remain present.
- PASS — backend D1/R2 schema/bindings and transaction code were not touched.
- PASS — diff against V-346 is limited to release identity, `AudioLiveRoomActivity.java`, the approved seat PNG, Worker release identity and V-347 documentation.

## Device/CI acceptance still required
- GitHub Android CI compile/sign.
- Real device PiP/background-audio continuity and tap-to-restore.
- Two-device Host/Guest avatar swap and seat-leave restore.
- Two-device Agora voice clarity.
- Gift animation/sound and Gift comment-stream presentation.
