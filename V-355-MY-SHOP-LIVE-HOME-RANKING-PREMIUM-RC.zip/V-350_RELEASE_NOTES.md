# MY SHOP V-350 — Stabilization Release Notes

Android: versionCode 350 / versionName 2.9.350
Worker: version 2.9.350 / build V-350

## Changes from V-349
- Guest-seat empty state polished to a softer, brighter translucent grey radial circle with a cleaner white chair presentation; 2–9 / 4+4 structure unchanged.
- Live comment stream now consumes backend comments oldest-to-newest, auto-scrolls when new rows arrive, and uses tighter vertical spacing.
- Room join/leave events retain up to the recent 8 rows instead of only 3, with dedupe preserved.
- Gift activity comment remains visually stronger than a normal comment but is compact enough not to consume the whole comment panel.
- Gift audio playback hardened: transient media focus, sonification route, louder safe boost, short-sound repeat window, custom-sound watchdog and built-in fallback.
- Join request errors/status now use the small in-room floating banner rather than a large bottom Toast covering comments.
- Join button now has a smooth premium alpha + scale breathing animation only for audience Join state; it stops/reset on Leave/Host/listen-only state.
- V-349 persistent login and FCM notification plumbing preserved.
- No Coin/Gold/admin/backend economy contract was intentionally changed.

## Runtime gate
This source package is not claimed as device-final until the GitHub-built APK is installed and the following are observed: Gift sound audible, gift sender card visible, comments remain sequential and newest visible, Join animation correct, seats visually match reference, persistent login works, and system notifications work with Firebase runtime secrets/config present.
