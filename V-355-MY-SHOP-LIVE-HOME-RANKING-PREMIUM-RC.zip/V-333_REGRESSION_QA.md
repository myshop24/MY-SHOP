# V-333 Regression QA
- Worker JavaScript syntax: PASS (`node --check`).
- Source version identity: PASS (333 / 2.9.333 / MY SHOP V-333).
- Host separate + 12 seat architecture: PRESERVED.
- Main Home Dashboard: NOT MODIFIED.
- Coin/Gold grant/economy: NOT MODIFIED.
- Full Android compile: NEEDS CI (archive has no gradle-wrapper.jar).
- Live comment pin/font/banner behavior: NEEDS REAL DEVICE + DEPLOYED WORKER TEST.
- Gift waveform drag/preview/persist: NEEDS REAL DEVICE TEST.
