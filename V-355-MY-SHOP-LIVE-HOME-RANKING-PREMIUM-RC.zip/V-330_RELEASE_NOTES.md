# MY SHOP V-330 — Coin & Gold Coin Admin Completion

## Target
Stop version-only churn and make the approved Coin/Gold Coin admin architecture explicit and functional.

## Implemented
1. Removed Admin navigation ambiguity: `Coin & Gold Coin Catalog` now identifies the full Live Gift Studio; purchase packages are clearly named separately.
2. Full existing Gift Studio preserved: COIN/GOLD separate catalogs, up-to-50 grid, tap edit, long-press drag/drop reorder, add-new, price, position, direct sound file picker, waveform trim/test, volume, sound duration, animation duration/size, board position, VAT, preview, draft/publish/delete.
3. Finance API extended backward-compatibly with `currencySummary` for COIN/GOLD without removing existing fields.
4. Finance UI now presents separate Today/All-time COIN and GOLD gross/platform/net cards.
5. Build identity advanced to versionCode 330 / versionName 2.9.330 / MY SHOP V-330.

## Protected / unchanged by intent
- Main Home Dashboard.
- Existing Give Coin / Gold Coin to User flow.
- Live 12-seat + host architecture.
- Existing Coin/Gold economy conversion rules.
- Existing D1 schema and bindings.

## Verification status
- Source-level diff/regression verification: performed.
- Android CI compile: NEEDS CI RUN.
- Real-device Gift Studio UI/function acceptance: NEEDS DEVICE TEST.
- Backend Worker deployment: REQUIRED for new currencySummary fields to appear in Finance; old API response remains compatible if not yet deployed.
