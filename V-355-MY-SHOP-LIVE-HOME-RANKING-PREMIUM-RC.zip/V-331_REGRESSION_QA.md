# V-332 Regression QA

| Gate | Status | Evidence |
|---|---|---|
| Worker JavaScript syntax | PASS | `node --check backend/worker/src/index.js` |
| Java structural brace check (changed classes) | PASS | AdminHub, LiveGiftAdmin, MyShopMessagingService balance = 0 |
| MainActivity unchanged | PASS | hash compared against pristine V-330 |
| AdminWalletActivity unchanged | PASS | hash compared against pristine V-330 |
| Obsolete Purchase Packages admin menu removed | PASS (source) | no seedModules entry |
| Gift sound URL field visible to Admin | PASS | hidden; phone picker is primary flow |
| Message heads-up | NEEDS DEVICE TEST | requires Android permission + production FCM |
| Live heads-up | NEEDS WORKER DEPLOY + DEVICE TEST | new LIVE_START FCM path |
| Gift audio play/trim/upload | NEEDS DEVICE TEST | Android document provider/media codec required |
| Full Android compile | NEEDS CI | gradle-wrapper.jar absent locally |
| Google Play policy regression | PASS (source-level) | no new sensitive permission/payment flow |
