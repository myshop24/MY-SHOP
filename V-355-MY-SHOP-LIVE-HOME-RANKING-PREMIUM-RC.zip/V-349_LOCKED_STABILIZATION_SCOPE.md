# MY SHOP V-349 — LOCKED STABILIZATION SCOPE

Golden Live Room reference: APPROVED-V349-LIVE-ROOM-FINAL-REFERENCE.png
Reference SHA-256: 22b93574f4d2243a16223b2719d70f8fcce3ddb24686008406188f6f87e3ecfe

No new feature/design is allowed in this stabilization release. The following 11 defects are locked:

1. Live Room must match the approved final reference, not the old V-348 runtime layout.
2. Main Guest must use MY SHOP LIVE logo + crown/laurel frame when empty; real guest photo when occupied.
3. Guest seats must be exactly 8 seats: 2–5 top row and 6–9 bottom row (4+4).
4. Empty seats must be gray translucent circles with white chair icon; no MS/MY SHOP seat logo.
5. Top-right Exit must be a red X with transparent/no circular border.
6. Gift sound must play reliably, honoring Admin sound ON/OFF, volume, custom URL, trim/duration, with built-in fallback.
7. Gift activity must appear immediately and prominently in comments with sender, level, gift visual/name, quantity/value and receiver; suppress the old small duplicate GIFT event row.
8. Persistent login: a valid stored backend session opens the app directly; logout/expired/deactivated session returns to Login. Token is Keystore-backed AES/GCM encrypted with migration from the prior token key.
9. Android system notifications: POST_NOTIFICATIONS + FCM service + high-importance message/live channels + monochrome notification icon + push-token registration. Firebase client build config and Worker FCM service-account secret are mandatory external runtime requirements.
10. Release verification: Green compile alone is not Final. CI build + installed APK screenshot comparison + gift/audio/login/push tests are required before runtime acceptance.
11. Size stabilization: remove the obsolete 1.3 MB empty-seat logo resource, use Agora voice-only SDK for the current audio-only Live implementation, and ship a compact current-source ZIP without historical screenshots/release archives.

Regression lock: preserve Coin/Gold Coin economy, gift catalog/Admin controls, balance/ledger rules, D1/R2 contracts, Join Request/Host Invite, comments, End Live, PiP/mini live, profile, dashboard, navigation, Admin and Google Play safeguards.
