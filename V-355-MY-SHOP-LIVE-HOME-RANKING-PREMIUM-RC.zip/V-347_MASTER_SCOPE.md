# MY SHOP V-347 — MASTER LOCKED SCOPE

1. Back from an active Live must not end the session; use Android PiP/mini behavior and keep Live audio active while the task remains alive.
2. Successful Coin/Gold Coin gifts must also appear as prominent gift entries in the Live comment stream with sender + gift visual/name.
3. Live voice must use speech-first RTC tuning for clear, strong, natural audio without intentional distortion.
4. Host area must show the real Host profile photo. Local Host fallback uses the signed-in profile avatar when room-state avatar data is temporarily unavailable.
5. Empty Guest seats use the user-approved MY SHOP MS Live image; occupied Guest seats show that guest's real profile photo; leaving restores the MS image.
6. Comment pin permission covers Host, Room Admin, MY SHOP Admin and Moderator when backend authorization permits the role.
7. Duplicate top-right Users control remains removed; top-right Exit/Leave control stays in its place while Host-area users count remains.
8. Audience action is Join; when on a call/seat it becomes Leave. Leave only leaves the call/seat. Host retains End Live authority.
9. Guest seat presentation remains circular, frameless and clean. Existing seat allocation/count/logic remains locked.
10. Approved low-light dark navy/purple background remains full-screen across the active Live Room.
11. Existing gift animation/sound presentation stays enlarged/extended while Admin gift catalog, pricing, balance and transaction logic remain locked.
12. Fix V-346 AAPT resource failure by replacing the mislabeled JPEG-as-PNG empty-seat file with a true Android-compatible PNG.
13. Preserve the established MY SHOP premium visual language and micro-interactions; V-347 changes must remain visual-layer-safe and must not redesign navigation, feature placement or backend behavior.
14. Permanent regression lock: no unrelated working feature, Admin control, API/backend contract, Coin/Gold Coin logic, Gift system, comments, seats, Join Request, Host Invite, timer, End Live, profile or navigation may regress.
