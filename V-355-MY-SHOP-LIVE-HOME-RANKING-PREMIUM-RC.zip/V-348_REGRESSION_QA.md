# V-348 Regression QA

- [PASS static] versionCode 348 / versionName 2.9.348
- [PASS static] source build identity V-348
- [PASS static] 8 visible user seats: 2–9, 4 + 4
- [PASS static] empty user seats use gray circular chair design
- [PASS static] Main Guest empty logo resource is valid PNG
- [PASS static] occupied seats continue to use real avatar_url
- [PASS static] top-right Exit X has transparent background
- [PASS static] Gift playback retains admin sound enabled/volume/duration/trim and adds fallback path
- [PASS static] D1/R2 bindings and Coin/Gold Coin transaction SQL untouched
- [NEEDS DEVICE] real-device audio routing / custom R2 gift sound test
- [NEEDS CI] release APK build/signing through permanent GitHub workflow
