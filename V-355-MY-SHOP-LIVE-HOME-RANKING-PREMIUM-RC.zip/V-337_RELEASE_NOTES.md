# MY SHOP V-337 — Final Live Comment + Live Top UX Scope

Version: V-337  
Android versionCode: 337  
Android versionName: 2.9.337

## Implemented in source
1. Live Comment Admin preset flow simplified: ready-made cards are front-and-center; advanced preset editor is collapsed by default.
2. Ready-made VIP/VVIP/ROYAL/KING/QUEEN Male/Female cards now render actual styled comment previews instead of plain `Style 1/2/3` labels. Existing server/admin-saved presets remain authoritative; missing presets use richer distinct defaults.
3. Direct ready-made assignment shortcut: tap a preset card -> enter MY SHOP User ID -> user preview/confirmation -> Save & Assign.
4. Long Live comments are capped to 4 visible lines with ellipsis so one comment cannot expand into a giant board card.
5. Join-time comment privacy: audience members receive only comments/highlights created after their current Live join time. Live comments remain ephemeral/in-memory; no new D1/R2 comment persistence was added.
6. Gift activity feed: completed gifts add a compact real-time comment-feed card with sender avatar/name, gift, receiver and Coin/Gold value. Gift activity is also filtered by current join time.
7. Live Room TOP section redesigned only: Host identity, horizontally scrollable viewer avatars, Online count, and compact Gift/Coin/Gold/Star stats.

## Locked / intentionally unchanged
- Existing 12-seat board rendering/count/placement/behavior was not changed.
- No seat numbers were added.
- Existing Home Dashboard was not redesigned.
- Existing Live controls, request/invite, gifts, comments, moderation and backend contracts were preserved except for the scoped fields above.
