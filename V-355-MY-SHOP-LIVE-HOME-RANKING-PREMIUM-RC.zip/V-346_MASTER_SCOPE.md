# MY SHOP V-346 — Locked Master Scope

This release is intentionally limited to the 10 approved Live Room changes below. Unrelated working modules are protected by the permanent regression lock.

1. Android Back during an active Live enters mini/Picture-in-Picture when supported; it must not end the Live. Audio remains active while the user moves to other apps/screens. Tapping the mini window restores the Live Room.
2. Successful Coin/Gold Coin gifts render as a large, prominent gift activity entry inside the Live comment stream.
3. Live speech clarity is tuned for voice/chat with Agora speech profile/chatroom scenario and safer capture/playback gain.
4. Host/guest avatars continue to use real profile photos; empty guest seats use the approved MY SHOP LIVE image as the default placeholder.
5. Comment pinning is available to Host, Room Admin, MY SHOP Admin, and Moderator.
6. The duplicate top-right Users display is replaced by a clear Exit/Close control. The existing Users stat under the Host area remains.
7. Audience bottom-right action is Join with subtle glow; after promotion to speaker/call it becomes Leave. Host keeps End Live authority.
8. Guest seat visuals are circular/clean like the approved reference, with no outer rectangular/neon frame around the seat board. Existing V-345 seat count/logic is preserved.
9. The approved low-light dark navy/purple theme fills the complete Live Room screen by default; published Admin themes may still override it.
10. Existing gift effects are globally presented larger and longer, with stronger/longer sound while preserving each gift's Admin-configured controls, pricing, and transaction logic.

## Permanent regression lock
- No unrelated feature redesign.
- No D1/R2 schema change for this release.
- Preserve RTC token flow, seat allocation logic, Join Request/Host Invite, comments, gift ledger/economy, Admin controls, and all non-Live modules.
