# MY SHOP V-355 — Live Home, User Ranking & Premium Theme RC

## Confirmed scope implemented
1. Edit Profile Gender dropdown contrast fixed for the dark UI. `Male / Female / Prefer not to say` remain optional and user-selected.
2. Universal Live comments now render **Photo + Name : Comment** with no Level badge. Male/Female/neutral name/avatar treatments remain readable over arbitrary wallpapers using a protected dark glass layer. Highlight comments keep a separate gold/purple premium treatment.
3. Host top user line enlarged: 50dp avatars, visible `#1/#2/#3...` serials, wider tap targets, horizontal scrolling, and profile navigation. Approved guest-seat board remains exactly seats **2–9**.
4. Host profile block opens **Live Gift Summary • Top 20** for host and audience. It shows rank, avatar, name, MY SHOP ID, gift count, Coin Gift and Gold Gift totals; Top 1–3 receive medal treatment.
5. Live user-line ordering is server-authoritative: present Top Gifter #1 → #2 → #3 first; then King/Queen → Royal → VVIP → VIP; ties inside a tier use Coin balance descending, then Level descending; normal users also use Coin then Level. Only currently present viewers are included.
6. Live Streaming Home redesigned to the approved simplified structure: 6-banner carousel → Go Live / Join Live → one Top Live row → four reserved future folders. No duplicate Trending/second Live row.
7. Top Live is ordered by viewer count, shows four cards across first, and horizontally scrolls for additional active rooms. Join Live / See All opens all active rooms.
8. Dedicated Admin module **Live Streaming Home Page** manages Banner 1–6 with preview, Add/Replace, Save/Publish, Enable/Disable, Link URL and Delete. Recommended size displayed: **1200 × 560 px (~2.14:1)**.
9. Live Home bottom navigation finalized as **Home | Store | Video | My Feed | Profile** with the requested routes.
10. Main Dashboard default palette migrated to the same premium family: dark navy `#07122F`, blue `#2D72F6`, purple `#7B3FF2`, pink `#F02BB7`. Only legacy default values migrate; Admin-custom colors are preserved.

## Backend / data behavior
- Reuses the existing `banners` + R2 banner system under folder `live_home`; no destructive banner/schema replacement.
- New Admin endpoint: `GET /v1/admin/live-home/banners` returns all six admin slots including disabled entries.
- Live Room `viewerProfiles` includes Coin balance only for server-side sorting; exact balances are not exposed in the visible user line.
- Live `topSupporters` returns separate Coin/Gold totals for the current session summary.
- Added migration `0019_v355_live_home_palette.sql`, which changes only legacy default dashboard colors.
- Ephemeral Live comments remain ephemeral; no D1/R2 comment persistence was introduced.

## Locked / preserved
- V-353/V-354 working Agora voice connection path.
- Gift Sound engine and all 10 current gift WAV assets.
- Coin/Gold transaction and ledger logic.
- Gift animation engine.
- Approved 8 guest seats: **2–9**.
- Existing D1/Durable Object realtime architecture.

## Validation status
- Worker JavaScript syntax: PASS (`node --check`).
- AndroidManifest XML parse: PASS.
- Modified Java delimiter/static parse checks: PASS.
- Version identity: PASS (`versionCode 355`, `versionName 2.9.355`, `MY SHOP V-355`).
- Baseline deletions: 0.
- Full Android Gradle compile: **NOT RUN locally** because this source snapshot does not contain a runnable Gradle wrapper/JAR and no system Gradle/Android SDK is available here.
- Real-device acceptance: **REQUIRED** for Live Home banner carousel, Admin banner CRUD, user-line ordering, Gift Summary, comment rendering and dashboard contrast.
