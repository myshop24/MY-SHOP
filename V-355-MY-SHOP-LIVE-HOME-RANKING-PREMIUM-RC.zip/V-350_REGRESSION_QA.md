# V-350 Regression / Acceptance QA

## Source/static
- [ ] versionCode = 350
- [ ] versionName = 2.9.350
- [ ] SOURCE_BUILD_ID = MY SHOP V-350
- [ ] Worker identity = 2.9.350 / V-350
- [ ] Worker syntax passes
- [ ] Android PNG resources decode as PNG
- [ ] Android XML resources parse
- [ ] Live seat range remains 2–9 / 4+4
- [ ] No MS logo used for empty guest seats
- [ ] Comment backend returns comments oldest-to-newest
- [ ] Comment stream auto-scrolls to newest rows
- [ ] Gift custom sound -> fallback path present
- [ ] Built-in gift sound repeat/boost path present
- [ ] Join button animation starts only for Join and stops for Leave/End
- [ ] Persistent session and FCM source files still present

## Installed APK — mandatory before calling runtime-final
- [ ] Live Room matches `APPROVED-V350-LIVE-ROOM-FINAL-REFERENCE.png`
- [ ] Empty seats match `APPROVED-V350-SEAT-REFERENCE.png`
- [ ] Gift sound is clearly audible on at least two real devices when Admin sound = ON
- [ ] Admin sound OFF truly disables that gift sound
- [ ] Custom gift sound works; invalid custom URL falls back safely
- [ ] Gift sender/name/visual/value appears prominently in comment stream
- [ ] 6+ comments/events can be generated and newest entries stay reachable/visible in serial order
- [ ] Join/leave events do not reorder/overlap normal comments
- [ ] Join button visibly pulses/glows as audience, becomes Leave on seat, animation stops on Leave
- [ ] Join Request reaches Host and Host accept promotes user
- [ ] Host invite reaches audience and accept promotes user
- [ ] Restart app while session is valid -> opens directly without repeated login
- [ ] Logout/invalid session -> returns to login
- [ ] Background/closed-app message notification appears in Android notification shade
- [ ] Background/closed-app Live alert appears when configured
- [ ] Coin/Gold gift balances and ledgers remain correct
- [ ] End Live works first tap
