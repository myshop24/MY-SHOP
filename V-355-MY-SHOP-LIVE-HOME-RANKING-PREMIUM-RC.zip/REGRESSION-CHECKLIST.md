# MY SHOP REGRESSION CHECKLIST — V-328

## Must remain unchanged / functional
- [ ] Main Home Dashboard visual structure unchanged.
- [ ] Dashboard navigation to Live still works.
- [ ] Go Live opens host flow.
- [ ] Join Live opens real active-live flow.
- [ ] 12-seat Audio Live architecture unchanged.
- [ ] Join Request -> Host -> Accept -> speaker promotion works.
- [ ] Host Invite -> User Accept -> speaker promotion works.
- [ ] Mic on/off and role transitions work.
- [ ] End Live closes reliably first confirmed action.
- [ ] Gift send/catalog/animation/backend behavior unchanged.
- [ ] Coin/Gold Coin balances and economy rules unchanged.
- [ ] Wallet/transactions/accounting unchanged.
- [ ] Membership/Badge unchanged.
- [ ] Profile/Feed existing behavior unchanged.
- [ ] D1/R2 bindings and Worker routes unchanged.

## V-328 acceptance
- [ ] Live Hub buttons/cards feel compact, consistent and premium.
- [ ] Live Room controls use consistent depth/press feedback.
- [ ] Comment appears immediately after Send.
- [ ] Sender comment does not disappear then reappear on server ack.
- [ ] Comments do not visibly jump on normal refresh.
- [ ] Chat send feels immediate and bubble styling is consistent.
- [ ] Inbox cards/buttons feel consistent with premium system.
- [ ] Background message produces Android heads-up notification when permission/configuration allow.
- [ ] Notification tap opens correct Chat.
- [ ] No major frame drops on target Android device.
