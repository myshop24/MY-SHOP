# MY SHOP V-344

## Scope
- Preserves V-343 Android/RTC diagnostics and all locked modules.
- Version identity advanced to V-344 / 2.9.344.
- Bundles the verified Worker deployment workflow inside the source for handoff/reference.
- No Agora App Certificate is embedded in source or APK.

## Important deployment gate
The repository-root `.github/workflows/my-shop-apk.yml` must contain the Worker deployment step. A source ZIP upload cannot replace GitHub's repository-root workflow by itself.
