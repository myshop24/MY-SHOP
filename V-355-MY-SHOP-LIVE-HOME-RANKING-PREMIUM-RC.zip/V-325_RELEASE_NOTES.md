# MY SHOP V-325 — Focused Gift Catalog Fix

This version deliberately changes only the Admin Gift Coin / Gold Coin catalog flow.

The catalog now opens as two separate premium sections, lists all gifts for the selected currency, and opens a full per-gift editor on tap. The editor includes price, box/order, sound upload/replace, 0–100% volume, sound duration, sound trim range, live-effect duration, board size/position, VAT, image/animation assets, publish state, Save and Delete. Each catalog also has Add New Gift and an Apply VAT to All control.
