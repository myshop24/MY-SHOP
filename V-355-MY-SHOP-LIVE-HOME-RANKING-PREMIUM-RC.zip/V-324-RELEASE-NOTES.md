# MY SHOP V-324 — Release Notes

V-324 focuses only on the requested Live Streaming control/stability fixes and Coin/Gold Coin catalog regression.

Key changes: speaker self leave/change-seat/mute controls; stable speaking avatar ring; duplicate Special Guest seat suppression; append-only live comments; compact golden seats; gift sender/name/value overlay; configurable Gift Display Duration and Sound Duration; dedicated Coin/Gold Coin Admin package catalog restored; gift catalog compact visual polish.

No intentional changes to account identity, withdrawal rules, Cloudflare bindings, purchased-vs-earned balance separation, 12-seat structure, or existing gift send animation behavior.
