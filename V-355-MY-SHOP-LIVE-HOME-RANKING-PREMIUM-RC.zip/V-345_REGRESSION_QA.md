# V-345 Regression QA

- PASS static: versionCode 345 / versionName 2.9.345 / SOURCE_BUILD_ID aligned.
- PASS static: Agora RTC audio join/publish/token flow preserved.
- PASS static: active-speaker callback uses Agora audio volume indication; no audio recording/storage added.
- PASS static: Host remains separate; guest board is 5 + 5, seats 2..11.
- PASS static: backend seat allocation/lock/move constrained to 2..11 to match UI.
- PASS static: live comments remain ephemeral; active-session memory cap increased to 80; UI cap 100.
- PASS static: gift event continues to trigger animation/sound and now also renders a gift activity row.
- NEEDS REAL DEVICE: verify glow visibility, speaker mapping, comment scroll behavior, gift row, and audio clarity on two devices.
- NEEDS CLOUDFLARE DEPLOY: Worker changes must deploy successfully before backend seat/comment behavior is live.
