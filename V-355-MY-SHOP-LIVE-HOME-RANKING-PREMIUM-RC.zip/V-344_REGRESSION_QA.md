# V-344 Regression QA

- [PASS] SOURCE_BUILD_ID = MY SHOP V-344
- [PASS] Android versionCode = 344
- [PASS] Android versionName = 2.9.344
- [PASS] Agora certificate not embedded in source
- [PASS] Existing V-343 RTC diagnostics preserved
- [GATE] Repository-root GitHub workflow must be updated/deployed separately for Worker automation
- [PENDING REAL DEVICE] Agora audio end-to-end test on two physical devices
