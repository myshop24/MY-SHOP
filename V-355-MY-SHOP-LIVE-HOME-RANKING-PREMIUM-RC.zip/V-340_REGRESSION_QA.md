# V-340 Regression QA

PASS (source inspection): version identity 340; Gift send action retained; 12-seat code untouched; Leave Call endpoint retained; expandable message notification retained; Live deep-link retained.
NEEDS CI/DEVICE: Android Java compile/build because this source archive does not contain the Gradle wrapper JAR/script; FCM delivery/lock-screen preview; background audio behavior; real multi-device viewer presence; Worker deployment smoke test.
NEEDS DEPLOYMENT: backend/worker/src/index.js for follower-only LIVE_START push targeting.
