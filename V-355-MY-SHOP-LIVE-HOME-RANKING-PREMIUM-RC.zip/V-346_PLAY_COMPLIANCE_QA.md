# V-346 Google Play Compliance QA

- PASS (source): targetSdk/compileSdk remain 36.
- PASS (source): no new dangerous/sensitive Android permission added.
- PASS (source): Picture-in-Picture is declared only for the Live Room activity.
- PASS (source): digital Coin/Gold Coin purchase/ledger logic was not changed.
- PASS (source): purchased-vs-earned balance safeguards were not removed.
- PASS (source): Live comments remain ephemeral; no recording/storage feature added.
- PASS (source): UGC moderation/report/block code was not removed.
- NEEDS CI: compile/sign the V-346 Android build in the established release environment.
- NEEDS REAL DEVICE: PiP/background-audio behavior across supported Android versions.
- NEEDS PLAY CONSOLE REVIEW: keep Data Safety, microphone use, UGC/moderation, billing, and account-deletion declarations accurate for the production build.
