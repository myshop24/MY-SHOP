Current V609 / 2.9.609: read handoffs/MY-SHOP-V609-HANDOFF.md. Approved Store/frame/comment source changes and local checks complete; full Android and phone acceptance pending. D1 optimization excluded. Next delivery V610.

Current V608 /2.9.608: read handoffs/MY-SHOP-V608-HANDOFF.md. Scoped missing-key compilation fix; next deliveryV609.

Current V607 /2.9.607: read handoffs/MY-SHOP-V607-HANDOFF.md. Eight approved source correction groups checked locally; signed APK/device acceptance and Admin animation reproduction pending. Next deliveryV608.

Current V606 /2.9.606: read handoffs/MY-SHOP-V606-HANDOFF.md. Seven approved source groups implemented; signed APK/full Android/device checks pending. Next new deliveryV607.

Current V605 /2.9.605: read handoffs/MY-SHOP-V605-HANDOFF.md. Six-group correction is PARTIAL; new30 rides and signed APK/device checks remain pending. Next deliveryV606.

Current V604 /2.9.604: read handoffs/MY-SHOP-V604-HANDOFF.md. Canonical source<=25,000,000 bytes. Next deliveryV605. No APK; inherited partial work recorded.

Current V603 partial checkpoint: read handoffs/MY-SHOP-V603-HANDOFF.md. All9 are NOT completed; rides blocked. Next delivery V604.

Current V602 checkpoint: read handoffs/MY-SHOP-V602-HANDOFF.md. Next delivery V603.

# MY SHOP — Mandatory Developer Entry Point

Read `DEVELOPER-POLICY-BN.md` and `MY-SHOP-DEVELOPER-INSTRUCTIONS.md` BEFORE inspecting implementation, editing, building or producing a delivery. Read `V575-APPROVED-WORK-BN.md` for current scope and `MY-SHOP-DEVELOPER-HANDOFF.md` for the last verified checkpoint. The latest owner instruction overrides historical notes. Never infer completion from a requirement document or an old log.

Current continuation: **V603 / 2.9.603**. Read `V600-APPROVED-WORK-BN.md` and `handoffs/MY-SHOP-V600-HANDOFF.md` after the entry rules. V600's membership visuals, General filters and Host lifetime Top1 ranking were explicitly discussed and authorized by the owner; no repeated approval is needed inside that scope. Other Live changes still require their own scope discussion. Read `handoffs/MY-SHOP-V601-HANDOFF.md` and `BUILD-ASSETS-BN.md`; prepare generated assets before local checks/build. Cleanup only changes source storage/build generation; runtime GIF/WAV bytes and image pixels are verified unchanged. Next new delivery is V604.

**LIVE IS A CRITICAL / HIGH-RISK ZONE.** Before changing Live Streaming code, design, audio, realtime, or its related backend, explain the exact proposed change and impact to the owner, discuss it and obtain explicit owner approval. This includes shared helpers, bug fixes, optimization, deletion and styling that would alter Live. Read-only inspection/testing is allowed. Continue independent non-Live work while a Live decision is pending.

Keep unrelated approved modules locked. Make scoped changes, preserve data/signing/package identity and run target plus regression verification. Never publish, deploy, overwrite an old version or claim a real-device test that was not performed.
