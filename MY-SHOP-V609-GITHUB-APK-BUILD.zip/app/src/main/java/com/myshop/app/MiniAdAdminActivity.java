package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** V-566: 20 premium mini-card looks, palettes, per-card motion, preview and expiry. */
public class MiniAdAdminActivity extends androidx.appcompat.app.AppCompatActivity {
    private final String[] scopes={"live_room","home","live","shop","store"};
    private final String[] names={"লাইভ রুম পেইজ","মেইন হোম পেইজ","লাইভ পেইজ","মাইশপ পেইজ","Store বিজ্ঞাপন"};
    private final String[] colors={"#123B9A","#6332C9","#ED2788","#079BB6","#128358","#C46C13","#563524","#152047","#05070D","#63B5E8","#6D4C41","#4E342E","#FF7A24","#E9447A","#00A896","#7B2CBF","#2D6A4F","#D4A017","#34495E","#F1F4F9"};
    private final String[] templates={"01 • Royal","02 • Aurora","03 • Electric","04 • Sunset","05 • Ocean","06 • Crystal","07 • Velvet","08 • Diamond Edge","09 • Shimmer","10 • Spark","11 • Wave","12 • Spotlight","13 • Neon Line","14 • Soft Glow","15 • Prism","16 • Pulse","17 • Ribbon","18 • Starlight","19 • Motion","20 • Classic"};
    private Button placements;private LinearLayout root,items; private TextView status; private Switch enabled;
    private JSONObject config; private JSONArray cards; private int selected; private boolean loading; private EditText imageTarget;

    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView text(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return t;}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private Button button(String s,LinearLayout parent,Runnable action){Button b=new Button(this);b.setText(s);parent.addView(b);b.setOnClickListener(v->action.run());return b;}

    @Override public void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)||!SessionManager.isAdminGateUnlocked()){finish();return;}
        ScrollView scroll=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(24),dp(16),dp(24));root.setBackgroundColor(0xfff5f7fc);scroll.addView(root);setContentView(scroll);
        TextView h=text(getIntent().getBooleanExtra("store_ads",false)?"Store • বিজ্ঞাপন":"মিনিকার্ড বিজ্ঞাপন",22,0xff172047,true);h.setGravity(Gravity.CENTER);root.addView(h,new LinearLayout.LayoutParams(-1,dp(42)));
        Spinner folder=new Spinner(this);folder.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));root.addView(folder);
        enabled=new Switch(this);enabled.setText("এই পেইজের মিনি কার্ড চালু");root.addView(enabled);
        status=text("লোড হচ্ছে…",12,0xff67718b,false);root.addView(status);
        items=new LinearLayout(this);items.setOrientation(LinearLayout.VERTICAL);root.addView(items);
        button("কার্ড যোগ করুন (সর্বোচ্চ ২০)",root,()->{if(cards==null||cards.length()>=20){Toast.makeText(this,"সর্বোচ্চ ২০টি কার্ড রাখা যাবে",Toast.LENGTH_SHORT).show();return;}edit(-1);});
        button("প্রিভিউ • চেপে ধরে জায়গা ঠিক করুন",root,this::preview);
        button("সেভ করুন",root,()->save(false));placements=button("সেভ করা একই কার্ড অন্য পেইজে দেখান",root,()->OverlayPlacements.show(this,"mini",scopes[selected]));if(getIntent().getBooleanExtra("store_ads",false))placements.setVisibility(View.GONE);button("আগের সেভ করা সেটিংস ফিরিয়ে আনুন",root,()->save(true));
        if(getIntent().getBooleanExtra("store_ads",false)){folder.setSelection(4);folder.setVisibility(View.GONE);}
        folder.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?>p,View v,int n,long id){selected=n;load();}public void onNothingSelected(android.widget.AdapterView<?>p){}});
    }
    private void load(){loading=true;final int requested=selected;BackendClient.miniAds(SessionManager.getToken(this),scopes[selected],true,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{if(requested!=selected||isFinishing())return;config=d;cards=d.optJSONArray("cards");if(cards==null)cards=new JSONArray();enabled.setChecked(d.optBoolean("enabled"));loading=false;if(placements!=null)placements.setVisibility("store".equals(scopes[selected])?View.GONE:View.VISIBLE);render();status.setText("২০টি রেডিমেড ডিজাইন • ২০টি রং • প্রতিটি কার্ডের সময় ও মেয়াদ আলাদা");});}public void onError(String m){runOnUiThread(()->{loading=false;status.setText("লোড হয়নি • "+m);});}});}
    private void render(){items.removeAllViews();if(cards==null)return;for(int i=0;i<cards.length();i++){final int at=i;JSONObject c=cards.optJSONObject(i);if(c==null)continue;
        LinearLayout block=new LinearLayout(this);block.setOrientation(LinearLayout.VERTICAL);block.setPadding(dp(8),dp(8),dp(8),dp(8));block.setBackground(round(Color.WHITE,15));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(8);items.addView(block,bp);
        TextView label=text((i+1)+". "+c.optString("title","মিনি কার্ড")+" • ডিজাইন "+Math.max(1,c.optInt("template",1))+" • "+c.optInt("seconds",3)+"s"+(c.optBoolean("enabled",true)?"":" • OFF"),13,0xff172047,true);block.addView(label,new LinearLayout.LayoutParams(-1,dp(28)));
        LinearLayout preview=cardView(c,dp(210),dp(88));LinearLayout.LayoutParams pv=new LinearLayout.LayoutParams(-1,dp(88));pv.topMargin=dp(5);block.addView(preview,pv);
        TextView metrics= text(metricsFor(c.optString("id")),10,0xff65708a,false);block.addView(metrics,new LinearLayout.LayoutParams(-1,dp(22)));
        LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER_VERTICAL);block.addView(actions);
        Button edit=new Button(this);edit.setText("Edit");actions.addView(edit,new LinearLayout.LayoutParams(0,dp(42),1));edit.setOnClickListener(v->edit(at));
        Button up=new Button(this);up.setText("↑");actions.addView(up);up.setEnabled(at>0);up.setOnClickListener(v->move(at,at-1));
        Button down=new Button(this);down.setText("↓");actions.addView(down);down.setEnabled(at<cards.length()-1);down.setOnClickListener(v->move(at,at+1));
        Button del=new Button(this);del.setText("Delete");actions.addView(del);del.setOnClickListener(v->{cards.remove(at);render();});
    }}
    private String metricsFor(String id){if(config==null)return "";int views=0,clicks=0;JSONArray metrics=config.optJSONArray("metrics");if(metrics!=null)for(int j=0;j<metrics.length();j++){JSONObject m=metrics.optJSONObject(j);if(m!=null&&id.equals(m.optString("card_id"))){if("VIEW".equals(m.optString("event")))views=m.optInt("total");else clicks=m.optInt("total");}}return "Views "+views+" • Clicks "+clicks;}
    private void move(int from,int to){if(cards==null||from<0||to<0||from>=cards.length()||to>=cards.length())return;try{JSONObject moving=cards.getJSONObject(from),other=cards.getJSONObject(to);cards.put(from,other);cards.put(to,moving);render();}catch(Exception ignored){}}
    private EditText field(LinearLayout p,String label,String value){EditText e=new EditText(this);e.setHint(label);e.setText(value);p.addView(e);return e;}
    private void edit(int n){JSONObject existing=n<0?null:cards.optJSONObject(n);final JSONObject c=existing==null?new JSONObject():existing;
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(14),0,dp(14),dp(12));
        EditText title=field(form,"শিরোনাম",c.optString("title")),caption=field(form,"ব্যাখ্যা / লেখা",c.optString("caption")),image=field(form,"ছবির HTTPS লিংক",c.optString("imageUrl")),link=field(form,"চাপলে খোলার HTTPS লিংক",c.optString("link")),start=field(form,"শুরুর সময় (ঐচ্ছিক ISO)",c.optString("startsAt")),end=field(form,"শেষ সময় (ঐচ্ছিক ISO)",c.optString("endsAt"));
        EditText days=field(form,"মেয়াদ (দিন)",String.valueOf(c.optInt("validityDays",30)));days.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        imageTarget=image;button("গ্যালারি থেকে ছবি দিন",form,()->{Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.setType("image/*");pick.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(pick,563);});
        Spinner template=new Spinner(this);template.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,templates));template.setSelection(Math.max(0,Math.min(19,c.optInt("template",1)-1)));form.addView(text("২০টি রেডিমেড অ্যানিমেটেড ডিজাইন",12,0xff172047,true));form.addView(template);
        Spinner seconds=new Spinner(this);seconds.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"১ সেকেন্ড","২ সেকেন্ড","৩ সেকেন্ড","৪ সেকেন্ড","৫ সেকেন্ড"}));seconds.setSelection(Math.max(0,Math.min(4,c.optInt("seconds",3)-1)));form.addView(seconds);
        Switch on=new Switch(this);on.setText("এই কার্ড চালু");on.setChecked(c.optBoolean("enabled",true));form.addView(on);
        Switch animate=new Switch(this);animate.setText("কার্ড অ্যানিমেশন চালু");animate.setChecked(c.optBoolean("animationEnabled",true));form.addView(animate);
        Switch flash=new Switch(this);flash.setText("ওপরে বিদ্যুৎ/আলোর ফ্ল্যাশ চালু");flash.setChecked(c.optBoolean("flashEnabled",true));form.addView(flash);
        final String[] color={c.optString("color",colors[0])};final String[] color2={c.optString("color2",c.optString("color",colors[0]))};GridLayout palette=new GridLayout(this);palette.setColumnCount(5);palette.setRowCount(4);form.addView(text("২০টি রঙের প্যালেট",12,0xff172047,true));form.addView(palette);
        for(String value:colors){TextView swatch=text("●",24,Color.parseColor(value),true);swatch.setGravity(Gravity.CENTER);GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.height=dp(42);p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);palette.addView(swatch,p);swatch.setOnClickListener(v->{color[0]=value;for(int j=0;j<palette.getChildCount();j++)palette.getChildAt(j).setAlpha(.55f);swatch.setAlpha(1f);});if(value.equalsIgnoreCase(color[0]))swatch.setAlpha(1f);else swatch.setAlpha(.55f);}
        button("সব রং • রঙের চাকা",form,()->{String selectedScope=scopes[selected];if("home".equals(selectedScope)||"shop".equals(selectedScope)){ColorPicker.show(this,Color.parseColor(color[0]),value->color[0]=String.format(Locale.US,"#%06X",value&0xffffff));return;}ThemeColorWheel wheel=new ThemeColorWheel(this,Color.parseColor(color[0]));new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("রং বাছুন").setView(wheel).setPositiveButton("রাখুন",(d,w)->color[0]=String.format(Locale.US,"#%06X",wheel.color()&0xffffff)).setNegativeButton("বাতিল",null).show();});
        button("মিক্স রং • দ্বিতীয় রং",form,()->{ThemeColorWheel wheel=new ThemeColorWheel(this,Color.parseColor(color2[0]));new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("দ্বিতীয় রং বাছুন").setView(wheel).setPositiveButton("রাখুন",(d,w)->color2[0]=String.format(Locale.US,"#%06X",wheel.color()&0xffffff)).setNegativeButton("বাতিল",null).show();});
        ScrollView sc=new ScrollView(this);sc.addView(form);androidx.appcompat.app.AlertDialog dialog=new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("মিনিকার্ড সেটিংস").setView(sc).setNegativeButton("বাতিল",null).setPositiveButton("রাখুন",null).create();
        dialog.setOnShowListener(x->dialog.getButton(-1).setOnClickListener(v->{if(!image.getText().toString().trim().isEmpty()&&!image.getText().toString().trim().startsWith("https://")){image.setError("HTTPS ছবির লিংক দিন");return;}if(!link.getText().toString().trim().isEmpty()&&!link.getText().toString().trim().startsWith("https://")){link.setError("HTTPS লিংক দিন");return;}int validity;try{validity=Math.max(1,Math.min(3650,Integer.parseInt(days.getText().toString().trim())));}catch(Exception ex){days.setError("দিনের সংখ্যা দিন");return;}
            try{JSONObject next=new JSONObject();next.put("id",c.optString("id","card_"+java.util.UUID.randomUUID()));next.put("title",title.getText().toString());next.put("caption",caption.getText().toString());next.put("imageUrl",image.getText().toString().trim());next.put("link",link.getText().toString().trim());next.put("startsAt",start.getText().toString().trim());String finish=end.getText().toString().trim();if(finish.isEmpty())finish=isoAfterDays(validity);next.put("endsAt",finish);next.put("validityDays",validity);next.put("template",template.getSelectedItemPosition()+1);next.put("color",color[0]);next.put("color2",color2[0]);next.put("seconds",seconds.getSelectedItemPosition()+1);next.put("enabled",on.isChecked());next.put("animationEnabled",animate.isChecked());next.put("flashEnabled",flash.isChecked());if(n<0)cards.put(next);else cards.put(n,next);render();dialog.dismiss();}catch(Exception ex){status.setText("কার্ড সংরক্ষণ করা যায়নি: "+ex.getMessage());}}));dialog.show();
    }
    private String isoAfterDays(int days){java.util.Calendar c=java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));c.add(java.util.Calendar.DAY_OF_YEAR,days);return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.US).format(new Date(c.getTimeInMillis()));}
    private LinearLayout cardView(JSONObject card,int width,int height){LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.HORIZONTAL);shell.setGravity(Gravity.CENTER_VERTICAL);int ci=0xff123b9a;try{ci=Color.parseColor(card.optString("color",colors[0]));}catch(Exception ignored){}GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{lighten(ci,.20f),ci});bg.setCornerRadius(dp(14));bg.setStroke(dp(card.optInt("template",1)%3==0?2:1),0x55ffffff);shell.setBackground("store".equals(scopes[selected])?new StoreAdBackground(ci,parseSecond(card,ci),card.optInt("template",1)):bg);shell.setClipToOutline(true);
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(LinearLayout.VERTICAL);copy.setGravity(Gravity.CENTER_VERTICAL);copy.setPadding(dp(10),dp(7),dp(5),dp(7));TextView title=text(card.optString("title","মিনি কার্ড"),13,PanelDesign.foreground(ci),true);title.setMaxLines(1);copy.addView(title,new LinearLayout.LayoutParams(-1,dp(24)));TextView caption=text(card.optString("caption","ছোট ব্যাখ্যা এখানে থাকবে"),10,PanelDesign.foreground(ci),false);caption.setMaxLines(2);copy.addView(caption,new LinearLayout.LayoutParams(-1,dp(36)));shell.addView(copy,new LinearLayout.LayoutParams(0,-1,1f));
        if(!card.optString("imageUrl","").isEmpty()){ImageView photo=new ImageView(this);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);shell.addView(photo,new LinearLayout.LayoutParams(Math.max(dp(86),width/3), -1));AnimatedAssetLoader.load(photo,card.optString("imageUrl"));}
        if(card.optBoolean("animationEnabled",true)){shell.setAlpha(.97f);shell.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420).start();}
        return shell;
    }
    private int parseSecond(JSONObject c,int fallback){try{return Color.parseColor(c.optString("color2",String.format(Locale.US,"#%06X",fallback&0xffffff)));}catch(Exception e){return fallback;}}
    private int lighten(int c,float f){return Color.rgb(Math.min(255,(int)(Color.red(c)+(255-Color.red(c))*f)),Math.min(255,(int)(Color.green(c)+(255-Color.green(c))*f)),Math.min(255,(int)(Color.blue(c)+(255-Color.blue(c))*f)));}
    private void preview(){if("store".equals(scopes[selected])&&cards!=null&&cards.length()>0){int width=getResources().getDisplayMetrics().widthPixels-dp(64);new androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Store • বিজ্ঞাপন প্রিভিউ").setView(cardView(cards.optJSONObject(0),width,dp(92))).setPositiveButton("Done",null).show();return;}if(config==null||cards==null||cards.length()==0){Toast.makeText(this,"আগে একটি কার্ড যোগ করুন",Toast.LENGTH_SHORT).show();return;}FrameLayout phone=new FrameLayout(this);phone.setBackgroundColor(0xffe7edfa);phone.setMinimumHeight(dp(350));JSONObject c=cards.optJSONObject(0);int cardWidth=Math.max(dp(120),Math.min(dp(252),getResources().getDisplayMetrics().widthPixels-dp(76))),cardHeight=dp(88);LinearLayout card=cardView(c,cardWidth,cardHeight);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(cardWidth,cardHeight);phone.addView(card,lp);phone.post(()->{float x=(float)config.optDouble("x",.68)*(phone.getWidth()-card.getWidth());float y=(float)config.optDouble("y",.65)*(phone.getHeight()-card.getHeight());card.setX(Math.max(0,Math.min(phone.getWidth()-card.getWidth(),x)));card.setY(Math.max(0,Math.min(phone.getHeight()-card.getHeight(),y)));});final boolean[] drag={false};final float[] offset=new float[2];card.setOnLongClickListener(v->{drag[0]=true;return true;});card.setOnTouchListener((v,e)->{if(e.getAction()==0){offset[0]=e.getX();offset[1]=e.getY();return false;}if(!drag[0])return false;if(e.getAction()==1||e.getAction()==3){drag[0]=false;try{config.put("x",card.getX()/Math.max(1,phone.getWidth()-card.getWidth()));config.put("y",card.getY()/Math.max(1,phone.getHeight()-card.getHeight()));}catch(Exception ignored){}return true;}if(e.getAction()==2){float x=card.getX()+e.getX()-offset[0],y=card.getY()+e.getY()-offset[1];card.setX(Math.max(0,Math.min(phone.getWidth()-card.getWidth(),x)));card.setY(Math.max(0,Math.min(phone.getHeight()-card.getHeight(),y)));return true;}return true;});
        new androidx.appcompat.app.AlertDialog.Builder(this).setTitle(names[selected]+" • Preview").setView(phone).setPositiveButton("Done",null).show();}
    private void save(boolean restore){if(config==null||loading)return;try{JSONObject payload=new JSONObject();payload.put("scope",scopes[selected]);payload.put("revision",config.optInt("revision"));payload.put("restore",restore);payload.put("enabled",enabled.isChecked());payload.put("cards",cards);payload.put("x",config.optDouble("x",.68));payload.put("y",config.optDouble("y",.65));loading=true;BackendClient.miniAdsSave(SessionManager.getToken(this),payload,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{loading=false;load();Toast.makeText(MiniAdAdminActivity.this,"সেভ হয়েছে",Toast.LENGTH_SHORT).show();});}public void onError(String m){runOnUiThread(()->{loading=false;status.setText("সেভ হয়নি • "+m);});}});}catch(Exception e){status.setText("সেভ হয়নি • "+e.getMessage());}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=563||result!=RESULT_OK||data==null||data.getData()==null||imageTarget==null)return;final EditText target=imageTarget;try{Uri uri=data.getData();String mime=getContentResolver().getType(uri);status.setText("ছবি আপলোড হচ্ছে…");BackendClient.adminAssetUpload(SessionManager.getToken(this),getContentResolver().openInputStream(uri),"mini-card.jpg",mime==null?"image/jpeg":mime,"mini_ads",new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{target.setText(d.optString("image_url"));status.setText("ছবি আপলোড হয়েছে • কার্ডটি রেখে সেভ করুন");});}public void onError(String m){runOnUiThread(()->status.setText("ছবি আপলোড হয়নি • "+m));}});}catch(Exception e){status.setText("ছবি আপলোড হয়নি");}}
}
