# MY SHOP DEVELOPER HANDOFF — V-328

## Version
- V-328
- versionCode 328
- versionName 3.0.328
- Base: V-327-MY-SHOP-PREMIUM-GIFT-ADMIN-CATALOG-FINAL

## Phase
Premium Experience + Stability Foundation.

## Completed
- Added shared PremiumUi component.
- Live Hub premium polish.
- Audio Live Room premium action/surface polish with 12-seat layout preserved.
- Gap-free optimistic Live comment -> server echo reconciliation.
- FeatureActivity premium card/button foundation.
- Chat + Inbox premium polish.
- Existing FCM notification presentation refinement.
- Added permanent Master State / recovery documents.

## Pending
- Full Android compile in GitHub CI because this source snapshot lacks executable Gradle wrapper/JAR.
- Real-device visual smoothness and latency QA.
- Real-device background/terminated FCM delivery QA with configured Firebase + Worker service-account secret.

## Last checkpoint
Scoped source diff confirms Worker/backend and MainActivity/Home Dashboard were not modified by V-328.

## Next tasks
1. CI build.
2. Device install.
3. Verify Live comment no-flicker and latency.
4. Verify heads-up message notification and chat deep-link.
5. Capture screenshots/video for Premium Visual PASS.
6. Mark V-328 GOLDEN-STABLE only after acceptance; otherwise create V-329 patch.

## Known issues / limitations
- Full compile not proven locally because gradle-wrapper.jar/gradlew are absent in the source snapshot.
- Notification delivery depends on Android notification permission, Firebase client config and Worker FCM service account configuration.
- Premium makeover is a reusable foundation plus key Live/Message/Feature screens; untouched screens should migrate incrementally rather than via risky full-app rewrite.

## V-329 checkpoint
- Fixed V-328 GitHub build guard failure caused by Android versionName 3.0.328 vs workflow-required 2.9.328.
- V-329 now uses versionCode 329 / versionName 2.9.329 / SOURCE_BUILD_ID MY SHOP V-329.
- Gift Coin & Gold Coin Catalog is explicitly protected as a locked modular admin system.
- No Home Dashboard redesign in V-329.
- Do not modify Worker/D1/R2 contracts for this release.
- CI/device verification still required before calling the build Golden Stable.


# V-330 Checkpoint
- Phase: Coin & Gold Coin Admin completion + regression hardening.
- Completed: navigation disambiguation, Gift Studio preservation lock, COIN/GOLD finance summary API/UI, version identity.
- Pending: GitHub CI compile, Worker deploy for finance summary, real-device acceptance.
- Last checkpoint: source-level regression audit.
- Next: run CI; device-test all required Gift Studio functions before Golden Stable.
- Known issues: no runtime PASS claimed before CI/device validation.
