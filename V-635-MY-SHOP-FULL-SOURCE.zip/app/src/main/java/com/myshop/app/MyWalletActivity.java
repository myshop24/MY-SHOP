package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;

/** Wallet overview. Spendable and creator earnings are independently fetched, never conflated. */
public final class MyWalletActivity extends androidx.appcompat.app.AppCompatActivity {
    private static final int BG=0xff070b25,PANEL=0xff151334,INK=Color.WHITE,MUTED=0xffbab9d4;
    private TextView coin,gold,coinEarned,goldEarned,state;private int generation;private PlayBillingManager billing;private final android.os.Handler balanceHandler=new android.os.Handler(android.os.Looper.getMainLooper());
    @Override protected void onCreate(Bundle b){super.onCreate(b);build();}
    @Override protected void onResume(){super.onResume();load();}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,dp(5),0,dp(5));return t;}
    private GradientDrawable shape(int fill){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(16));return g;}
    private GradientDrawable gradient(){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff8624ff,0xff4a087c});g.setCornerRadius(dp(18));return g;}
    private void add(LinearLayout parent,View child,int height){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,height);p.topMargin=dp(10);parent.addView(child,p);}
    private Button button(String label,Runnable action){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextColor(INK);b.setBackgroundTintList(null);b.setBackground(gradient());b.setOnClickListener(v->action.run());return b;}
    private void build(){ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);LinearLayout page=col();page.setBackgroundColor(BG);page.setPadding(dp(16),dp(12),dp(16),dp(20));Appearance.preserve(page);scroll.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(i.getSystemWindowInsetLeft(),i.getSystemWindowInsetTop(),i.getSystemWindowInsetRight(),i.getSystemWindowInsetBottom());return i;});
        LinearLayout header=new LinearLayout(this);Button back=button("‹",this::finish);header.addView(back,new LinearLayout.LayoutParams(dp(44),dp(44)));TextView heading=text(UiStrings.label(MyWalletActivity.this,"My Wallet"),22,INK);heading.setTypeface(null,1);header.addView(heading,new LinearLayout.LayoutParams(0,dp(48),1));page.addView(header);
        LinearLayout hero=col();hero.setPadding(dp(14),dp(12),dp(14),dp(12));hero.setBackground(gradient());hero.addView(text("Your Coins & Diamonds",13,INK));LinearLayout balances=new LinearLayout(this);coin=balanceCard(balances,"🪙 Coin Balance",()->startActivity(new Intent(this,CoinWalletActivity.class)));gold=balanceCard(balances,"⭐ Diamond Balance",()->startActivity(new Intent(this,DiamondWalletActivity.class)));hero.addView(balances);add(page,hero,-2);
        LinearLayout actions=new LinearLayout(this);Button buy=button("🛒 Buy",this::showBuyPackages),withdraw=button("↥ Withdraw",()->startActivity(new Intent(this,CoinWithdrawalActivity.class)));actions.addView(buy,new LinearLayout.LayoutParams(0,dp(50),1));LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(0,dp(50),1);wp.leftMargin=dp(8);actions.addView(withdraw,wp);add(page,actions,dp(50));
        LinearLayout earnings=col();earnings.setPadding(dp(12),dp(10),dp(12),dp(10));earnings.setBackground(shape(PANEL));earnings.addView(text("Creator Earnings • Withdrawable",14,INK));coinEarned=text("Coin • loading…",15,0xff61e5b2);goldEarned=text("Diamond • loading…",15,0xff61e5b2);earnings.addView(coinEarned);earnings.addView(goldEarned);earnings.addView(text("কেনা Coin / Diamond উত্তোলনযোগ্য নয়।",12,MUTED));add(page,earnings,-2);
        add(page,button("⇄ Transfer • Coin / Diamond",()->WalletTransferEntry.show(this)),dp(48));add(page,button("লেনদেন হিস্ট্রি • সর্বশেষ ৩০টি",()->startActivity(new Intent(this,WalletHistoryActivity.class))),dp(48));state=text("",12,MUTED);state.setOnClickListener(v->load());add(page,state,-2);scroll.addView(page);setContentView(scroll);VisualDesign.apply(this,page,"wallet");}
    private void showBuyPackages(){
        state.setText("Loading published Coin / Diamond packages…");
        BackendClient.storeCatalog(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject data){runOnUiThread(()->{if(isFinishing()||isDestroyed())return;
                java.util.ArrayList<JSONObject> items=new java.util.ArrayList<>();java.util.ArrayList<String> labels=new java.util.ArrayList<>();org.json.JSONArray catalog=data.optJSONArray("catalog");
                if(catalog!=null)for(int i=0;i<catalog.length();i++){JSONObject item=catalog.optJSONObject(i);if(item==null)continue;String type=item.optString("item_type");if(!"COIN".equals(type)&&!"GOLD".equals(type)&&!"GOLD_COIN".equals(type))continue;if(!item.optBoolean("enabled",true))continue;items.add(item);labels.add(item.optString("title")+" • "+format(item.optLong("units")));}
                state.setText(items.isEmpty()?"এখন কোনো Coin / Diamond package প্রকাশিত নেই।":"Google Play checkout-এ চূড়ান্ত মূল্য দেখুন।");if(items.isEmpty())return;
                new MyShopDialogBuilder(MyWalletActivity.this).setTitle("Buy Coin / Diamond").setItems(labels.toArray(new String[0]),(dialog,index)->{if(billing==null)billing=new PlayBillingManager(MyWalletActivity.this);billing.purchase(items.get(index));}).setNegativeButton("Cancel",null).show();
            });}
            public void onError(String message){runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())state.setText("Packages unavailable • "+message);});}
        });
    }
    private TextView balanceCard(LinearLayout parent,String label,Runnable action){LinearLayout card=col();card.setPadding(dp(9),dp(6),dp(9),dp(6));card.setBackground(shape(PANEL));card.addView(text(label,12,INK));TextView value=text("…",22,INK);value.setTypeface(null,1);card.addView(value);card.setOnClickListener(v->action.run());LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(dp(3),dp(8),dp(3),0);parent.addView(card,p);return value;}
    private void load(){final int run=++generation;balanceHandler.removeCallbacksAndMessages(null);state.setText("Loading current balances…");String token=SessionManager.getToken(this);coin.setText("…");gold.setText("…");coinEarned.setText("Coin • loading…");goldEarned.setText("Diamond • loading…");
        BackendClient.coins(token,callback(run,coin,"Coin","balance",d->coin.setText(format(d.optLong("balance")))));
        BackendClient.walletProfile(token,callback(run,gold,"Diamond","goldBalance",d->gold.setText(format(d.optLong("goldBalance")))));
        BackendClient.payoutInbox(token,false,"COIN",0,callback(run,coinEarned,"Coin","availableEarnings",d->coinEarned.setText(format(d.optLong("availableEarnings"))+" Coin")));
        BackendClient.payoutInbox(token,false,"GOLD",0,callback(run,goldEarned,"Diamond","availableEarnings",d->goldEarned.setText(format(d.optLong("availableEarnings"))+" Diamond")));}
    @Override protected void onDestroy(){generation++;balanceHandler.removeCallbacksAndMessages(null);if(billing!=null)billing.close();super.onDestroy();}
    private String format(long n){return String.format(java.util.Locale.US,"%,d",n);}
    private BackendClient.Callback callback(int run,TextView target,String label,String field,java.util.function.Consumer<JSONObject> update){final boolean[] finished={false};final Runnable timeout=()->{if(!finished[0]&&run==generation&&!isFinishing()&&!isDestroyed()){finished[0]=true;unavailable(target,label);}};balanceHandler.postDelayed(timeout,25000L);return new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{if(finished[0]||run!=generation||isFinishing()||isDestroyed())return;finished[0]=true;balanceHandler.removeCallbacks(timeout);if(d==null||!d.has(field)||d.isNull(field)){unavailable(target,label);return;}update.accept(d);target.setOnClickListener(null);if(state.getText().toString().startsWith("Loading"))state.setText("Balances update independently • tap to refresh");});}public void onError(String m){runOnUiThread(()->{if(finished[0]||run!=generation||isFinishing()||isDestroyed())return;finished[0]=true;balanceHandler.removeCallbacks(timeout);unavailable(target,label);});}};}
    private void unavailable(TextView target,String label){target.setText(label+" • লোড হয়নি — আবার চেষ্টা করুন");target.setOnClickListener(v->load());state.setText("কিছু ব্যালেন্স পাওয়া যায়নি • আবার চেষ্টা করতে চাপুন");}
}
