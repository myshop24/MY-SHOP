V635 continued from delivered V634; FolderNoticeActivity lambda conflict fixed. Target compiler negative/positive test included; Android full build locally blocked.
