V635: scoped compiler fix, details MY-SHOP-DEVELOPER-HANDOFF.md. Phase2 pending; next V636.
