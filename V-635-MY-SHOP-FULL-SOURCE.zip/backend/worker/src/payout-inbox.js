// Read-only inbox over the SAME creator-withdrawal table used by both wallets.
// No external payout or wallet-balance mutation is performed by this module.
export async function payoutInbox(request,env,h,admin=false){
 const me=await h.getUser(request,env);
 if(!me)return h.json({error:'UNAUTHORIZED'},401,h.cors);
 if(admin){const a=await h.adminOnly(request,env);if(a.error)return a.error;}
 if(request.method!=='GET')return h.json({error:'METHOD_NOT_ALLOWED'},405,h.cors);
 await h.ensureContentSchema(env);
 const u=new URL(request.url),currency=u.searchParams.get('currency')||'COIN';
 if(!['COIN','GOLD'].includes(currency))return h.json({error:'INVALID_CURRENCY'},400,h.cors);
 const before=Number(u.searchParams.get('before')||Number.MAX_SAFE_INTEGER);
 if(!Number.isSafeInteger(before)||before<1)return h.json({error:'INVALID_CURSOR'},400,h.cors);
 const where=admin?'':' AND r.user_id=?',args=admin?[currency,before]:[currency,before,me.user_id];
 const rows=(await env.DB.prepare(`SELECT r.*,u.full_name,u.avatar_url FROM myshop_creator_withdraw_requests r LEFT JOIN myshop_auth_users_v108 u ON u.user_id=r.user_id WHERE r.currency=? AND r.id<?${where} ORDER BY r.id DESC LIMIT 51`).bind(...args).all()).results||[];
 const more=rows.length>50,requests=rows.slice(0,50);
 const termsTable=await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='myshop_withdraw_terms'").first();
 if(termsTable&&requests.length){
  const terms=(await env.DB.prepare(`SELECT request_id,payload FROM myshop_withdraw_terms WHERE request_id IN (${requests.map(()=>'?').join(',')})`).bind(...requests.map(r=>r.id)).all()).results||[];
  const byId=new Map(terms.map(t=>[Number(t.request_id),t.payload]));
  for(const r of requests){try{const t=JSON.parse(byId.get(Number(r.id))||'null');if(t)r.terms={processingDays:t.processingDays,processingDeadline:t.processingDeadline,catalogRevision:t.catalogRevision,grossAmount:t.grossAmount,totalDeducted:t.totalDeducted,feeMode:t.feeMode};}catch(_){}}
 }
 const pending=await env.DB.prepare(`SELECT COUNT(*) count,COALESCE(SUM(gross_units),0) units FROM myshop_creator_withdraw_requests r WHERE r.currency=? AND r.status IN ('PENDING','PROCESSING')${where}`).bind(...(admin?[currency]:[currency,me.user_id])).first();
 let available=null;
 if(!admin){const table=currency==='COIN'?'myshop_coin_wallets':'myshop_gold_wallets';const w=await env.DB.prepare(`SELECT balance FROM ${table} WHERE user_id=?`).bind(me.user_id).first();const exists=await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='myshop_wallet_locks634'").first();const locked=exists?await env.DB.prepare('SELECT amount FROM myshop_wallet_locks634 WHERE user_id=? AND currency=?').bind(me.user_id,currency).first():null;available=Math.max(0,Number(w?.balance||0)-Number(locked?.amount||0));}
 return h.json({ok:true,currency,requests,pendingCount:Number(pending?.count||0),availableEarnings:available,nextCursor:more?requests[requests.length-1].id:null,readOnly:true},200,h.cors);
}
