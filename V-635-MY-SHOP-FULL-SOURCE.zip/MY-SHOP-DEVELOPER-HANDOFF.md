# MY SHOP V635 / 2.9.635 — compiler correction

Base: delivered V-634-MY-SHOP-FULL-SOURCE.zip. Scope is only the GitHub Android compilation failure shown by the owner (run697), with version/provenance and a targeted compiler regression check. No phase-2 Story edit/draft, Live priority, cleanup or D1 optimization was implemented here. Preserve those approved instructions for later work.

## Correction

FolderNoticeActivity.load() creates a Callback whose onSuccess(JSONObject d) contains a related-records dialog lambda also declaring (d,at). Java forbids redeclaring an enclosing method parameter in a lambda. Rename only the inner unused parameter to relatedDialog. Routing, data and UI behavior are unchanged.

The test tests/v635-folder-compile.spec.py extracts the exact production setItems lambda and compiles/runs it against narrow API doubles. Both routes execute. Reintroducing the old d parameter must fail javac with already defined. This test is included in preBuild and the CI build script. It is not a substitute for complete Android type compilation.

## Identity and preservation

SOURCE_BUILD_ID MY SHOP V-635; versionCode635; versionName2.9.635; Worker health V-635/2.9.635. Original com.myshop.app, signing setup, D1/R2 binding, banner, RTC, wallet and all other V634 behavior remain. The preservation test normalizer now recognizes the new version only. Complete V634 scope and remaining limitations are retained in handoffs/MY-SHOP-V634-HANDOFF.md.

## Build and delivery

Upload V-635-MY-SHOP-FULL-SOURCE.zip unchanged to the existing permanent repository pipeline with its current root workflow and Secrets. New repositories require extraction including .github at root. The included source selector supports versioned ZIPs. Preserve the original signing key and Firebase/Cloudflare/Agora setup; secret values are not included.

Verify Actions selects V635, the intended commit, clean Android compilation, package/version/signing and artifact provenance. Download MY_SHOP_FINAL_RELEASE.apk only from that exact successful Android run. A source ZIP name or green Worker deployment alone does not prove an APK was built. No remote deployment or GitHub run was performed here. No APK is bundled.

## Verification / continuation

See verification/V635-RESULTS.md and logs. Full Android build is still locally blocked at Gradle download by network restrictions. Device tests and exact GitHub signed artifact acceptance remain pending. V634 inherited unfinished accounting/internal currency naming work remains unfinished. Next changed delivery V636.
