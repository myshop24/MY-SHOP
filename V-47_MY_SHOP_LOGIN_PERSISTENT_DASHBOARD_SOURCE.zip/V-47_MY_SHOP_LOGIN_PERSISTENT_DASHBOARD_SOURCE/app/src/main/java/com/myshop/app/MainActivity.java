package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** V-46: Home Dashboard rebuilt around the approved dashboard reference. */
public class MainActivity extends AppCompatActivity {
    private static final int WHITE = Color.WHITE;
    private static final int TEXT = Color.rgb(35, 40, 55);
    private static final int PURPLE = Color.rgb(83, 27, 220);
    private static final int BLUE = Color.rgb(24, 105, 232);
    private static final int RED = Color.rgb(238, 35, 45);
    private static final int GREEN = Color.rgb(28, 165, 72);
    private static final int PINK = Color.rgb(230, 35, 128);

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try { setContentView(buildDashboard()); }
        catch (Throwable t) { setContentView(buildSafeHome()); }
    }

    private View buildDashboard() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(247,248,252));

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(12, 10, 12, 18);

        // Approved dashboard visual header: exact reference artwork, kept as design only.
        ImageView header = new ImageView(this);
        header.setImageResource(R.drawable.myshop_dashboard_header);
        header.setScaleType(ImageView.ScaleType.CENTER_CROP);
        header.setContentDescription("MY SHOP Home Dashboard");
        content.addView(header, lp(-1, 330));

        TextView liveHeading = title("🔴  লাইভ এখন চলছে                                      সব দেখুন ›");
        content.addView(liveHeading, lp(-1, 50));
        LinearLayout lives = row();
        lives.addView(liveCard("1\n🔴 LIVE\nCute Girl Live\n@user1"), weight(1, 150));
        lives.addView(liveCard("2\n🔴 LIVE\nMusic Live\n@user2"), weight(1, 150));
        lives.addView(liveCard("3\n🔴 LIVE\nGaming Live\n@user3"), weight(1, 150));
        lives.addView(liveCard("4\n🔴 LIVE\nTalk & Fun\n@user4"), weight(1, 150));
        content.addView(lives, lp(-1, 158));

        LinearLayout liveActions = row();
        liveActions.addView(action("📡\nLIVE\nলাইভ দেখুন", RED, "live_now"), weight(1, 96));
        liveActions.addView(action("🎥\nGO LIVE\nনিজে লাইভ যান", RED, "go_live"), weight(1, 96));
        liveActions.addView(action("✨\nMy Feed\nআপনার ফিড দেখুন", PURPLE, "my_feed"), weight(1, 96));
        content.addView(liveActions, lp(-1, 102));

        LinearLayout grid1 = row();
        grid1.addView(feature("🛒", "MY SHOP\nঅনলাইনে শপিং করুন", "my_shop", PINK), weight(1, 102));
        grid1.addView(feature("🖼️", "GALLERY\nফটো, অডিও, ভিডিও", "gallery", PURPLE), weight(1, 102));
        grid1.addView(feature("🎬", "EXTERNAL MOVIE\nমুভি ও ভিডিও", "external_movie", BLUE), weight(1, 102));
        grid1.addView(feature("📺", "LIVE TV\nলাইভ টিভি দেখুন", "live_tv", PURPLE), weight(1, 102));
        content.addView(grid1, lp(-1, 108));

        LinearLayout grid2 = row();
        grid2.addView(feature("📱", "SOCIAL MEDIA\nসব সোশ্যাল মিডিয়া", "social_media", BLUE), weight(1, 102));
        grid2.addView(feature("🎁", "EARN & REWARD\nরিওয়ার্ড, গিফট", "earn_reward", Color.rgb(245,145,20)), weight(1, 102));
        grid2.addView(feature("🔗", "SHARE\nশেয়ার করুন", "share", PURPLE), weight(1, 102));
        grid2.addView(feature("▦", "MORE APPS\nআরও অ্যাপস দেখুন", "more_apps", Color.rgb(30,170,160)), weight(1, 102));
        content.addView(grid2, lp(-1, 108));

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = row();
        nav.setPadding(4, 4, 4, 4);
        nav.setBackgroundResource(R.drawable.bg_nav);
        Button home = navButton("⌂\nHome", PURPLE);
        Button store = navButton("🛒\nStore", PINK);
        Button live = navButton("◉\nLive", RED);
        Button chat = navButton("💬\nChat", BLUE);
        Button profile = navButton("◉\nProfile", GREEN);
        nav.addView(home, weight(1, 76)); nav.addView(store, weight(1, 76)); nav.addView(live, weight(1, 76)); nav.addView(chat, weight(1, 76)); nav.addView(profile, weight(1, 76));
        root.addView(nav, lp(-1, 84));

        home.setOnClickListener(v -> scroll.fullScroll(View.FOCUS_UP));
        store.setOnClickListener(v -> openFeature("MY SHOP", "my_shop"));
        live.setOnClickListener(v -> openFeature("LIVE", "live_now"));
        chat.setOnClickListener(v -> openFeature("CHAT", "chat"));
        profile.setOnClickListener(v -> startActivity(new Intent(this, AccountActivity.class)));
        return root;
    }

    private Button navButton(String label, int color) {
        Button b = button(label); b.setTextColor(color); b.setTextSize(14); return b;
    }
    private Button action(String label, int color, String key) {
        Button b = button(label); b.setTextColor(color); b.setTextSize(14); b.setOnClickListener(v -> openFeature(label, key)); return b;
    }
    private Button feature(String icon, String label, String key, int color) {
        Button b = button(icon + "\n" + label); b.setTextColor(color); b.setTextSize(12); b.setOnClickListener(v -> openFeature(label, key)); return b;
    }
    private Button button(String text) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setBackgroundResource(R.drawable.bg_card); return b;
    }
    private TextView liveCard(String text) { return card(text, TEXT, WHITE); }
    private TextView title(String text) { return card(text, TEXT, WHITE); }
    private TextView card(String text, int fg, int bg) {
        TextView t = new TextView(this); t.setText(text); t.setTextColor(fg); t.setTextSize(14); t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setGravity(Gravity.CENTER); t.setPadding(8,8,8,8); t.setBackgroundResource(R.drawable.bg_card); return t;
    }
    private void openFeature(String title, String key) {
        try { Intent i = new Intent(this, FeatureActivity.class); i.putExtra("title", title); i.putExtra("feature_key", key); startActivity(i); }
        catch (Throwable t) { Toast.makeText(this, title + " is ready for the next module.", Toast.LENGTH_SHORT).show(); }
    }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER); return l; }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w,h); }
    private LinearLayout.LayoutParams weight(float w, int h) { return new LinearLayout.LayoutParams(0,h,w); }
    private View buildSafeHome() {
        LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setGravity(Gravity.CENTER); r.setBackgroundColor(WHITE);
        TextView t = new TextView(this); t.setText("MY SHOP\nHome Dashboard"); t.setTextSize(26); t.setTextColor(PURPLE); t.setGravity(Gravity.CENTER); r.addView(t, lp(-1,-2));
        Button retry = button("OPEN DASHBOARD"); retry.setOnClickListener(v -> recreate()); r.addView(retry, lp(-1,64)); return r;
    }
}
