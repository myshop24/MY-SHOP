V-221 MY SHOP BUILD-SAFE FIX

Based on V-220. Version raised to 2.9.221 / versionCode 221.
Release signing is configured to use the existing permanent key at:
.signing/myshop-release.jks
when GitHub Actions provides the signing environment variables.
No old V-number files are removed.
