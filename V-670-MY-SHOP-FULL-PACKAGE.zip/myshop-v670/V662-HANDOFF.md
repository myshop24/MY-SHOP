# MY SHOP V-662 — Live and App Settings handoff

This complete source package continues the provided V-661 source. Android `versionCode` is 662, `versionName` is 2.9.662, and the Worker health marker is V-662.

## Completed in this source

- The video Live bottom bar has one direct camera on/off control. Its icon and accessibility label reflect the current state. The owner can turn the camera on after Android grants camera permission.
- A small front/back switch appears in the local video tile only while the camera is on. Existing seat actions, host consent, camera permissions, mic controls, and Beauty settings remain in place.
- The host viewer count appears beneath the host name; the redundant ID/level line is replaced to match the supplied reference and the next profile tiles move left.
- Gift comment cards use the sender's assigned comment appearance or equipped custom comment design. The Live gift feed now includes stored gift quantity, so comment rows can show the actual `×N`. Displayed totals no longer multiply an already quantity-inclusive server amount a second time. The paid gift transaction/ledger methods remain byte-identical to the locked V-655 baseline.
- Gift motion uses larger existing authored movements. Gift audio receives a moderate 5 dB loudness boost; the More menu's existing on/off and volume slider still control playback.
- The Home/Live first-page control is available directly in Admin Hub → App Settings. The existing Draft/Preview/Publish behavior and app-start routing remain in place.

## Verification

`verification/V662-SOURCE-MANIFEST.json` records the V-661 source ZIP hash, all 10 changed files, five new source/test/handoff files, and confirms no source files were removed. The manifest itself is included as a sixth new file.

`bash tools/v662_target_verify.sh` passes: V-662 identity, financial-path hash preservation, 11 owner-scope guards, Worker syntax, Java parsing of 294 sources and callback-context audit, 8 Node behavior tests, RTC facade checks for up to eight distinct UIDs, gift recovery, and five animated-scene timeline checks.

These checks do not establish a full Android compile, signed APK, actual gift loudness/visual quality on a phone, or Agora video delivery between 2–8 physical phones. The existing remote-UID subscription/bind path remains present and its facade checks pass. Confirm host, multiple seated camera publishers, and audience viewing on real devices before declaring multi-person video fixed in production.

## Build and setup

The current MY SHOP GitHub root release pipeline selects the highest `V-*.zip`, deploys its matching Worker first, then builds/signs the APK using the existing protected Cloudflare, Firebase, and original V-661 signing setup. This package changes the Worker gift-feed response, so uploading it through that root pipeline also deploys this backend change to production before APK compilation. The bundled `tools/ci-apk-build.sh` is a build-only verification script; the permanent root pipeline controls production deployment. Do not add secret values to this source package.

After the root pipeline completes, verify the actual run, Worker version, APK package/version, original signing certificate, alignment, provenance, and APK size. Build success alone does not confirm the changed Live behavior; test the downloaded APK on devices as described above. No APK is bundled here because this workspace has no `javac`/Android SDK or original signing credentials.

## Pending

- Run the V-662 GitHub Actions build and inspect the exact APK identity, signature, size, and provenance.
- Test gift audio, animation, comment colors, host header, camera on/off and front/back on a phone.
- Test 2, 3, 4, 5, 6, 7 and 8 simultaneous video participants, including a separate audience device and reconnection.
- Check the published Home/Live choice after a fresh app launch.

No Android APK, real-device test, or production release is claimed by this handoff.
