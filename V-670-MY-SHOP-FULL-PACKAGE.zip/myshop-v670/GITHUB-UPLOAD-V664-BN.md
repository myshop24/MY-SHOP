# V-664 — GitHub APK build

আগের স্থায়ী pipeline-এ V-664 source ZIP অপরিবর্তিত আপলোড করুন। পুরোনো signing key এবং protected Firebase/Cloudflare/Agora configuration বজায় রাখুন। pipeline সর্বোচ্চ V-number-এর ZIP বেছে matching Worker deploy করে তারপর Android APK build/sign করে; আপলোড করলে backend পরিবর্তন হতে পারে। এই কাজ থেকে কোনো push/deploy করা হয়নি।

প্রয়োজনীয় dependencies ও media generation: BUILD-ASSETS-BN.md। গোপন মান source-এ দেবেন না; আগের GitHub Secrets ব্যবহার করুন। মূল workflow ও build scripts প্যাকেজে আছে। .github-সহ project root অক্ষত রাখুন; বর্তমান pipeline-এর ZIP extraction পদ্ধতিই ব্যবহার করুন।

Actions-এর run শেষ হলে Artifacts থেকে MY_SHOP_FINAL_RELEASE.apk নামের signed APK download করুন। versionCode 664 / versionName 2.9.664, original signing certificate এবং current implementation markers মিলতে হবে। APK size মেপে জানান এবং V664-HANDOFF.md-এর বহু-ফোন পরীক্ষা করুন। শুধু Build successful যথেষ্ট নয়।

এই ZIP-এ APK নেই; এখানে Gradle download network blocked হওয়ায় পূর্ণ Android build হয়নি। GitHub Android build সফল ও artifact প্রকাশিত হলে সেখান থেকে নতুন APK পাওয়া যাবে। সব source preBuild gate: bash tools/prepare-build-assets.sh তারপর python3 tools/v664_prebuild_verify.py। Android compile ও বাস্তব ফোনের ফল আলাদা।
