# V656 GitHub আপলোড
১. V-656-MY-SHOP-FULL-SOURCE.zip অপরিবর্তিতভাবে আগের repository root-এ Upload files দিয়ে আপলোড করুন। ZIP খুলতে হবে না। প্যাকেজ কঠোরভাবে25,000,000bytes-এর কম যাচাই করা।
২. Commit changes চাপুন। আগের স্থায়ী .github/workflows/my-shop-apk.yml থাকতে হবে। প্রথমবারের নতুন repository হলে প্যাকেজের ওই workflow একই path-এ আগে স্থাপন করুন।
৩. Actions → MY SHOP Android APK → V656 run দেখুন। পুরোনো signing ও Firebase Secrets অক্ষত রাখুন; setup মূল handoff-এ আছে।
৪. নতুন signed APK তৈরি/পরিচয় যাচাই সফল হলে MY-SHOP-V-656-APK Artifacts থেকে ডাউনলোড করুন। version2.9.656/code656 মিলিয়ে নিন। এই ZIP-এ APK নেই; স্থানীয় Android build করা হয়নি।
