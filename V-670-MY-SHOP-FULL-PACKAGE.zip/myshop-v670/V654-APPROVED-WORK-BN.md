# V654 — অনুমোদিত কাজ, ২০২৬-১০-২১
01/08 baseline/source/build verification; next version654; preserve signing/package.
02/08 gift opening/cache, bounded media/resource isolation; financial idempotency unchanged.
03/08 animation ads per-card Publish in Edit, ON/OFF persists only that card; drafts isolated.
04/08 Go Live label slightly larger; original emoji/colors unchanged.
05/08 isolated server-authoritative Cricket engine, permissions, recovery, expiry, audit.
06/08 Game Hub → 🏏 ক্রিকেট, reference navy/purple/pink/blue, green SCORE; independent local movable/resizable panels for Host/controller/Super Admin. No seats/RTC/comments redesign.
07/08 target/regression/Android/CI checks and exact APK provenance. No production deploy.
08/08 full source ZIP, handoff, durable checkpoint, measured size and large visible link.

## Cricket final owner decisions
Teams equal size set by controller, locked after start; select players from comments, one team per ID per match. Outs consume a slot, including replacement; restore cannot reopen an out slot. Each valid delivery credits actual player ID, never transfers replacement records.
Bowler0–6 once then locked; controller Ball Reset clears both ball/run before SCORE. Batsman0–6 latest input visible to everyone including before ball. Controller decides whether to reset. SCORE finalizes once, ball=run OUT except fourth consecutive same ball DOT counts run/no out/no legal ball. Same-ball chain resets after DOT and new over, survives bowler replacement in same over. Six counted balls per over. Full-over bowler cannot bowl next over; split-over participants may.
Controller controls setup, digital toss, sponsor current profile lookup/preview, batting/bowling, score, assignments, correction, pause/end. Host opens and replaces controller; no automatic room-admin privilege. Super Admin sees all including code/secrets and controls all. Assigned authorized moderator may inspect secrets. No public secret payload/history. Previous controller immediately loses access.
First innings overs editable (integer not below completed progress), lock at first innings end; target score+1. End on all configured slots out or overs. Tie leads6-ball Super Overs until winner; controller sets super-out limit. Main-innings outs eligible again; super-out players not eligible subsequent supers unless controller special permission after exhausted tie; otherwise Draw. Best points runs+10*wickets including all supers; tied points prefer wickets, fully tied joint winners.
One active match per room. Unique ID, unchanged high-entropy recovery code private. Any authenticated code holder can recover to new Live and replace controller; only one room binding, old control revoked. Automatic state restore plus controller audited manual correction of team/player runs/wickets/outs/balls/innings/target (not ordinary reset). No secret access via code alone.
24h summary from match end; unfinished recovery24h from Live interruption. Multiple summaries allowed; expiry cleanup. No voice/comments storage. Hide/move/resize does not change match. Position per local account/screen, no forced broadcast. Preserve original Main Guest/seat visuals; controller main guest uses established seat permission/consent.
