# V652 GitHub APK বিল্ড

V-652-MY-SHOP-FULL-SOURCE.zip সম্পূর্ণ সোর্স ও বিল্ড প্যাকেজ; APK নয়। বিদ্যমান MY SHOP GitHub pipeline-এ ZIP অপরিবর্তিত আপলোড করুন। SOURCE_BUILD_ID=MY SHOP V-652, versionCode652, versionName2.9.652 থাকতে হবে। পুরনো APK পুনরায় নাম দিয়ে দেবেন না।

সঠিক Commit → Actions run → original signing certificate → package/version → provenance → V652 DEX marker → artifact hash/সাইজ মিলিয়ে নিন। শুধু Build successful যথেষ্ট নয়। tools/ci-apk-build.sh এসব গেট চালায়। নতুন markers: LiveSeatPolicy652, PremiumGift652, LivePreflight652, renderAdaptive652, camera-request/reply ও consent handlers।

মূল signing/Firebase Secrets আগেরগুলোই থাকবে। হ্যান্ডঅফে প্রয়োজনীয় setup আছে, কোনো গোপন মান নেই। Worker code ও0064 migration মিলিয়ে চালাতে হবে; APK build Worker deploy করে না।

এই পরিবেশে Gradle ডাউনলোড নেটওয়ার্কে বাধাপ্রাপ্ত; Android build, নতুন APK বা দুই ফোনে অডিও/ভিডিও পাস দাবি করা হয়নি। Source tests পাস করা actual Live acceptance নয়। বিল্ড শেষে APK-এর প্রকৃত সাইজ জানাতে হবে।
