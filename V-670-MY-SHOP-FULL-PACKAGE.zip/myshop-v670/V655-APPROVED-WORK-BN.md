# V655 owner-approved scope — 2026-10-22
Latest chat decisions override older locks only where explicitly authorized below.
- Gift open/send issue: keep original financial Send/quote/commission/idempotency, add strict committed receipt validation/read-only recovery and isolate comment/effect failures. Actual reported phone failure still needs verification; no root-cause certainty claim.
- Remove commission WORDING from gift panel, retain total debit and financial calculation.
- Small approved Cricket board: Team A(number) left, score middle, Team B(number) right; green innings; clear over line; smaller drag/resize grips; independent line-size/scroll controls; independent sponsor/player panels and local account layout. Existing backend privacy/score rules retained. Run Reset may clear only pending run; Ball Reset clears both.
- Game catalog uses existing Game entry; icon with Cricket label and corner info mark. Reuse separate existing PanelDesign backend scope for admin background/templates. Future games are not fake placeholders.
- Public Bengali/English instructions start “Host opens board”, explain setup/toss/sponsor/comment selection/ball/run/reset/DOT/score/overs/replacement/recovery/summary. No mention of private administrative visibility.
- Camera OFF round profiles; names below occupied audio/video/main guest seats; small names still, overflow left-to-right in clipped line; same on profile card/page. Persistent decorative ring + audio-only speech pulse. Muted icon visible to all. Preserve chair, seat shape, RTC/consent.
- Host avatar/name opens existing mini-profile sheet; currency counters retain Top20. Existing sheet actions and moderation remain.
- Remove decorative MOVING_MIC from selectable/admin list and room rendering; preserve historic stored configuration compatibility.
- Admin Coin Box keeps financial/claim rules, shows box burst and coin shower only after valid claim.
- Lucky tab order Coin / Diamond / Lucky / Favourite, five flowers50k/100k/200k/300k/500k. 6sec flowers from top. Fixed total shared to all fresh current session users including host/sender; deterministic 1-coin remainder, no extra fee; disclosed before Send. Original gift categories unchanged in Coin/Diamond. Sender eligibility had not been explicitly resolved earlier; these disclosed defaults follow “everyone present”, may be revised by owner. No game-linked payout/random prize.
- Ads validity error clarity; ON/Publish remain per-card. Scheduled expiry observed in supplied video. Production config still unknown, do not claim every ad outage fixed.
- Size: exact-PCM WAV→FLAC runtime assets and explicit build ABI; no RTC SDK removal. Current original high-res animated frames retained.
- Full source/handoff/workflow, sequential release655, clear large download link, measured file size, no falseAPK.
- Store homepage redesign was discussed but not selected/approved; preserve current shop and catalog instead of guessing final design.
