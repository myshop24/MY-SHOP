# V667 — কাজের তালিকা ও যাচাইয়ের প্রকৃত অবস্থা

এই তালিকা কাজ বাদ পড়া ঠেকানোর জন্য। “সোর্সে আছে” মানে ফোনে বা signed APK-তে সফল প্রমাণ নয়। সর্বশেষ মালিকের নির্দেশ পুরোনো নথির ওপরে প্রাধান্য পাবে। মূল কাজের অনুমোদন বহাল; অকারণে আবার অনুমতি চাইতে হবে না।

| কাজ | সোর্স/পরীক্ষার অবস্থা | বাকি |
|---|---|---|
| 01. রাইডার ডান থেকে বামে, একই Demo/Live | একই রেন্ডারার; প্রথম ফ্রেমে পৃথক সাউন্ড; mute/cleanup/replay পরীক্ষা | রেফারেন্স মানের প্রকৃত cinematic ভিডিও/চরিত্র/মোশন অসম্পূর্ণ |
| 02. পাঁচ রঙের অতিরিক্ত কার | V665-এর পাঁচ disabled Admin-priced draft অক্ষত | এগুলো আগের ছবির tint; নতুন 3D car video নয় |
| 03. রাইডারের চাকা/neon/smoke customization | আগের wheel motion অক্ষত | পূর্ণ customization ও নতুন rider media বাকি |
| 04. পুরোনো কেনা rider পরিবর্তন | কোনো paid entitlement বা ইতিহাস মুছিনি | নতুন replacement প্রস্তুত করে audited retirement/regrant বাকি |
| 05. সাত original avatar frame | V665 input/build generation ও own-photo composition অক্ষত | ফোনে visual acceptance |
| 06. সাত animated wallpaper, catalog/demo/Live | MIME/video/poster/owned projection/retry/release ঠিক; local tests pass | ফোনে decoder/expired/disable acceptance |
| 07. Admin wallpaper Add/Price/Duration/Enable/Disable/Delete | বিদ্যমান uploader ও paid ownership flow অক্ষত; poster correction | production acceptance; wallpaper ফ্রি নয় |
| 08. My Collection/owned/active/expired/renew | Theme/Guardian categories, expired renew; existing favorites retained | ফোনে owned-item acceptance |
| 09. Guardian price/host/renew/multiple members | host-specific held purchase/atomic grant/idempotence tests | external purchase/phone acceptance |
| 10. Original animated Guardian frame/MS/member portraits | audio central stage; actual main guest preserved | dedicated video-mode presentation ও member badges অসম্পূর্ণ |
| 11. 20 Coin +20 Diamond music gifts | 40 distinct native layered animation drafts ও 40 original music; Admin sets prices/publish | ফোনে sound/decoder/visual acceptance; familiar Hindi recording নয় |
| 12. নতুন gift rail icon | আগের জায়গা/মাপ/click action; box lid/gifts animation; lifecycle tests | Android screenshot/reference acceptance |
| 13. PK reference layout | দুই রঙের স্কোরবারে দুই প্রান্তে সংখ্যা; ছয় circular ranked supporter; PK/countdown; COIN label বাদ | ফোনে same/cross-room reference acceptance |
| 14. PK supporter/Love overlap | measured clearance adjusts PK video footprint; fixed rail unchanged; stability test | ছোট/বড় ফোনে acceptance |
| 15. ভিডিওর নিচেই নাম | 20dp name band, no vertical padding; same video/cover bottom anchor; long text travels right-to-left without reversing letters | সব layouts/বড় নামে ফোন পরীক্ষা |
| 16. Gift comment above composer | existing comment-stream child retained, stage clipping explicit, composer separate | ছোট screen/font scale/keyboard screenshot acceptance; flow/height বাড়াইনি |
| 17. ভিডিও সবাইকে দেখা/ক্যামেরা consent | V663–665 UID/surface/permission/rollback protections retained and regression tests | 2–8 physical devices, reconnect/background acceptance |
| 18. Bluetooth/wired/USB audio | V665 route/permission/SCO fallback retained; model tests | বাস্তব দুমুখী audio/headphone tests |
| 19. Individual listening volume | actual RTC UID, per-account setting, recovery retained | বহু ফোনে acceptance |
| 20. Floating Live | same View/engine transfer, drag/restore/close confirmation | Activity/account/phone acceptance; background camera privacy retained |
| 21. Launcher notification badge | permission/channel settings + existing notification/read sync | OEM launcher অনুযায়ী count/dot; numeric badge force করার নিশ্চয়তা নেই |
| 22. Selected navigation colorful/tap motion | shared navigation source implemented | bespoke page navigation/phone visual acceptance |
| 23. Nameplate/mic effect/sticker, five colors | V665-এর 30 variant retained | Messenger sticker integration বাকি |
| 24. Animated profile cover/character/clothing/entry/showcase/gallery | আলাদা নতুন পূর্ণ ব্যবহারযোগ্য product implementation নেই | নতুন media, schema, buy/gift/grant/apply/expiry/rendering দরকার |
| 25. Matching sets/personal likes/camera-off portrait/profile tabs | নতুন সম্পূর্ণ product নয় | পাঁচ রং ও actual rendering/ownership/admin controls বাকি |
| 26. Gift boxes/cards/celebration/admin templates | আগের কার্যকর gift/bundle flow অক্ষত | নতুন celebration product/template builder অসম্পূর্ণ |
| 27. Room entrance/delivery/festive decor/applause | নতুন পূর্ণ product implementation নেই | media/ownership/preview/apply/admin scope বাকি |
| 28. Welcome board/virtual trophies | নতুন পূর্ণ product implementation নেই | media/ownership/preview/apply/admin বাকি |
| 29. Messenger backgrounds/bubbles/voice/envelope effects | আগের Messenger অক্ষত | নতুন product integration অসম্পূর্ণ |
| 30. অন্য আগে গ্রহণ করা Live কাজ | V665-approved backlog retained | production D1 profiling, low network/load/heat, admin diagnostics, mode switching, private room/queue/live shopping, draggable/resizable gallery TV, quiz/photo sharing acceptance/remaining scope |
| 31. Regression/build/source delivery | local preBuild gates চালাতে হবে; protected normal gift financial methods unchanged | full Android/signing/physical devices/production/load acceptance |

প্রত্যেক নতুন সত্যিকারের product-এর ক্ষেত্রে প্রযোজ্য own-photo demo, Buy/Gift/Admin grant, পাঁচ রং, My Collection, expiry/renew ও Admin Enable/Disable/Delete একসঙ্গে করতে হবে। ব্যবহার করার ব্যবস্থা ছাড়া শুধু catalog row যোগ করে কাজ সম্পন্ন বলা যাবে না। iOS এবং বাতিল shopping redesign এই ধাপে নেই।

পরের developer এই সোর্স থেকে চালাবেন। সব historical কাজ শেষ দাবি করে এই checkpoint publish করবেন না।
