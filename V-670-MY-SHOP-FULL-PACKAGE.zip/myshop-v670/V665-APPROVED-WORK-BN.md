# V-665 — অনুমোদিত কাজ ও প্রকৃত অবস্থা

মালিকের ২০২৬-১০-২২ “বিসমিল্লাহ বলে কাজ শুরু করেন” অনুযায়ী V664 থেকে কাজ। এই ডেলিভারি পূর্ণ প্রজেক্টের **আংশিক বাস্তবায়ন চেকপয়েন্ট**; পুরো আলোচনার সব ফিচার শেষ নয়। ভবিষ্যৎ কাজের জন্য একই অনুমোদন বহাল; আবার সাধারণ অনুমতি চাইতে হবে না।

1. লাইভ হেডারের অতিরিক্ত Follow সরানো, দর্শক সারি বামে; প্রোফাইল সাইজ অপরিবর্তিত। বড় নাম সঠিক অক্ষরক্রমে ডান থেকে বামে। সোর্সে সম্পন্ন; ফোনে পরীক্ষা বাকি।
2. Bluetooth/wired/USB যোগাযোগ রাউটিং, Bluetooth অনুমতির পর নির্বাচন, disconnect fallback, legacy SCO timeout, সেশন শেষে পরিষ্কার। মডেল পরীক্ষা হয়েছে; বাস্তব দ্বিমুখী অডিও পরীক্ষা বাকি।
3. রাইডারের একই Demo/Live player, বড় stage, ডিকোড হওয়ার পর video sound/timing; ৫ রঙের Supercar **আগের native artwork-এর রঙের ভ্যারিয়েন্ট**, নতুন সিনেম্যাটিক 3D মডেল নয়। রেফারেন্সের সমমানের ভিডিও/চরিত্রসহ পূর্ণ rider upgrade অসম্পূর্ণ। পুরোনো কেনা rider বাতিল করা হয়নি; ledger/entitlement রাখা আছে। অনুমোদিত audited retirement/replacement ব্যবস্থা বানানো বাকি।
4. সরবরাহকৃত ৭টি frame ভিডিও থেকে transparent WebP/GIF, নিজের প্রোফাইল দিয়ে catalog/profile/live-এ বিদ্যমান composition। ৭টি নতুন draft; পুরোনো frame অক্ষত। ফ্রেমের মাস্ক/স্বচ্ছতা পরীক্ষিত; Android-এ সব frame-এর visual acceptance বাকি।
5. সরবরাহকৃত ৭টি animated wallpaper: ৬ muted video + ১ GIF। Wallpaper/Animated Wallpaper আলাদা shelf; owned Theme/My Collection, demo এবং live playback; admin upload, price/duration, enable/disable/delete আগের ব্যবস্থায়। দুর্বল ফোনে ভিডিও default off, স্থানীয় switch ও poster fallback। APK/ফোনে decoder/expiry/background পরীক্ষা বাকি।
6. Royal/Crystal nameplate, Orbit/Pulse mic effect, Heart/Star sticker — প্রতিটি ডিজাইনে Gold/Ruby/Sapphire/Emerald/Violet, মোট ৩০ variant। নিজস্ব নাম/ছবির preview, catalog/collection, server-owned style, authorized sticker send। Admin CRUD/Grant এবং Buy/Gift আগের premium flow-তে। স্টিকার বর্তমানে Live comment-এ; Messenger sticker integration করা হয়নি।
7. My Collection-এ সব ব্যবহারকারীর category access, Favourite এবং তিন দিনের কম মেয়াদের in-app Renew reminder। আলাদা push expiry notification নয়। বিদ্যমান gift greeting/bundle flow রাখা হয়েছে; নতুন আলাদা five-color pack payment logic যোগ হয়নি।
8. regression, source/asset verification, sequential identity, পূর্ণ source packaging ও handoff। প্রকৃত Android build এবং physical phone acceptance হয়নি।

## আগের আলোচনা থেকে বাকি কাজ

D1-এর production query profiling/index/cache review, low-network/device/load/heat validation, gift retry UI-এর পূর্ণ acceptance, admin health diagnostics-এর সম্প্রসারণ, চলমান audio/video mode switching-এর acceptance, private room, queue, live shopping-এর পরবর্তী কাজ, gallery TV box resize/drag/playback, quiz ও photo sharing—এই ব্যাচে নতুন করে সম্পন্ন বলা হচ্ছে না। পুরোনো কার্যকর implementation থাকলে তা অক্ষত; প্রয়োজন অনুযায়ী পরের ধাপে পরিদর্শন ও অনুমোদিত scope বাস্তবায়ন করতে হবে। iOS ও বাতিল shopping redesign এই কাজে নেই।
