# V667 source checkpoint

একটাই ZIP,25,000,000 বাইটের নিচে। ভাগ করতে বা আলাদা media upload করতে হবে না।

এটি signed APK নয়। V667-HANDOFF.md-তে সম্পন্ন source কাজ, অসম্পূর্ণ অনুমোদিত কাজ এবং ফোনে পরীক্ষার বাকি অংশ লেখা আছে। গিফটে৪০টি নিজস্ব মিউজিক আছে। রেফারেন্সমতো cinematic rider ও হ্যান্ডঅফে লেখা অন্য অসম্পূর্ণ পণ্যগুলো শেষ হয়েছে ধরে আপলোড করবেন না। আগের INCOMPLETE-CHECKPOINT ZIP আপলোডের জন্য নয়।

উপযুক্ত হলে নতুন V-667 source ZIP অপরিবর্তিত অবস্থায় আগের GitHub repository root-এ upload করবেন। পুরোনো signing key/Firebase/Agora/D1/R2 তথ্য বদলাবেন না। বিল্ডে যাচাইকৃত V664 থেকে পুরোনো media স্বয়ংক্রিয়ভাবে নেওয়া হয়; internet বা আগের সঠিক V664 archive প্রয়োজন।
