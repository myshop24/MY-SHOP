# GitHub-এ V-669 APK বিল্ড

এই সোর্স ZIP-এ APK নেই। GitHub-এ মূল workflow একবার বদলাতে হবে; ZIP-এর ভেতরের workflow নিজে থেকে চালু হয় না।

১. repository-র `.github/workflows/my-shop-apk.yml` খুলে এই প্যাকেজের একই পথের ফাইলের সম্পূর্ণ লেখা বসিয়ে Commit করুন। আলাদাভাবে দেওয়া my-shop-apk.yml-ও একই ফাইল। এই পরিবর্তনে স্বয়ংক্রিয় APK build শুরু হবে না।
২. `V-669-MY-SHOP-FULL-SOURCE.zip` না খুলে repository-র প্রথম পাতায় Upload files দিয়ে আপলোড ও Commit করুন। পুরোনো source ZIP মুছবেন না; V664 baseline media dependency প্রয়োজন।
৩. Actions → MY SHOP Android APK → V669 source commit-এর run দেখুন। সফল হলে Artifacts → MY-SHOP-V-669-APK ডাউনলোড করে খুলুন; ভেতরে MY_SHOP_FINAL_RELEASE.apk। Summary-তে V-669 / 2.9.669, certificate/package/version check ও SHA256 থাকবে।

Original signing ও Firebase Secrets আগেরগুলোই রাখবেন; SIGNING-SETUP.md অনুযায়ী না থাকলে সেটআপ লাগবে। key/password সোর্সে দেবেন না। এই workflow Worker/D1 deploy বা website publish করে না। Official Inbox feature-এর backend আলাদাভাবে অনুমোদিত release না হওয়া পর্যন্ত production-এ কার্যকর হবে না।

GitHub Pages আলাদা service। Repository Settings → Pages-এ site প্রকাশ চালু থাকলে Unpublish করুন এবং publishing source বন্ধ করুন, যাতে অপ্রয়োজনীয় Pages run না হয়। এই workflow দিয়ে Pages settings বদলায় না।

বর্তমান অবস্থা: source gates passed; genuine signed Android build ও ফোনে Live/ভিডিও/অডিও পরীক্ষা এখনো হয়নি। Build success ফোনে Live সফলতার প্রমাণ নয়।
