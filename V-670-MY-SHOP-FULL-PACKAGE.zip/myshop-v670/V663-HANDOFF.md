# MY SHOP V-663 handoff

Continues the exact delivered V-662 archive. Android versionCode 663, versionName 2.9.663 and Worker health V-663. This is source delivery; no signed APK or physical-phone acceptance is claimed.

## Completed

- Reproduced GitHub run723 failure: tests/v575-preservation.spec.cjs normalized only versions through 661, so the V662 adminSystemHealth version metadata broke its locked function hash. The guard now reads the current release identity and normalizes only the exact version/build literals. It still compares the entire remaining function against the original hash; no test was disabled. All 146 Node tests pass.
- The actual Gradle preBuild source gate and APK finalizer now call V663 verifiers. V662 accidentally retained V661 source/APK verifiers; both would fail even after the first preservation error was repaired.
- Normal startup resolves the published Home/Live setting before building Home or starting its feed/image requests. A small neutral loading page waits at most 1500 ms, then uses the last saved setting (HOME for a first offline launch). A later response updates the next-start cache without navigating twice. Touch cannot cancel the selected page. Existing push/deep-link/composer and preview destinations bypass normal landing-page routing. Onboarding completion also follows the published launch page.
- API request work uses separate bounded Live/control and background queues, four workers per queue with 128 pending requests per queue; overflow reports a retryable error on the main callback thread. HTTP is never run on the UI thread. Existing upload workers are capped at three. Existing nonce/financial retry rules are unchanged.
- Non-Live theme updates coalesce layout-triggered refreshes, avoid unchanged background/color/direction setters, and cancel pending theme work when an Activity is destroyed. Dynamic children still receive the palette. Live skin is excluded as before.
- Video surfaces rebind when their SurfaceTexture actually becomes available. Render identity includes media UID, and old UID bindings detach before replacement. Invalid remote UID 0 is rejected instead of binding a wrong canvas. The SDK connected callback repairs subscriptions. A refused camera publish rolls back local capture/preview. Selected headset routing is reapplied on foreground recovery, and a new peer no longer resets the listener's manual remote-audio mute.
- The existing More > Report slot now distinguishes connection help from live content/user Report/Block, using existing authenticated safety APIs. No bottom-bar icon was added.
- V662 camera/flip/header/gift colors/quantity/animation/sound controls remain. Avatar size, image-loading implementation, seats, consent, paid gift transaction methods and original signing setup are retained.

## Verification and limits

Run `python3 tools/v663_prebuild_verify.py` to execute every actual preBuild Exec command, including historical scopes, and `bash tools/v663_target_verify.sh` for the current release. See verification/V663-PREBUILD-RESULTS.json for command results. This is distinct from Gradle/Android compilation.

The local Gradle wrapper cannot download Gradle because services.gradle.org is unreachable in this environment. No full Android compile, signed APK, emulator or physical Agora session was possible here. SDK facade tests exercise the shipped media methods for every 2-8 participant/guest/audience combination; they do not establish actual remote frames on phones. Real-device acceptance remains mandatory.

Run723 logs also show about 12 minutes in checkout (05:42:37 to 05:54:38), before Java/Node/SDK setup. Its build/test step failed after about 5m35s. Disabling build cache was not the main checkout delay. No root workflow or repository history has been changed. Repository package download/checkout optimization is a separate root-pipeline improvement; no claim of faster CI is made.

## GitHub / setup

Upload this ZIP unchanged using the existing owner-managed pipeline. It selects the highest V-*.zip, deploys its matching Worker, then builds/signs Android. Uploading therefore changes production backend before APK compilation. This source-edit task did not push or deploy anything.

Preserve original signing key/cache and protected Firebase/Cloudflare/Agora configuration. Do not paste secrets into source or docs. Build dependencies and generated assets remain documented in BUILD-ASSETS-BN.md. Generated runtime media are reproduced during CI; they are not duplicate source ZIP payloads.

After the run, inspect the exact APK version (663/2.9.663), original signing fingerprint, DEX implementation markers, ABI, alignment, native 16KB-page compatibility and size. GitHub green status alone is insufficient. APK size cannot be stated until an actual APK is built. The source package is kept below 25 MB without dropping required source inputs.

## Required phone acceptance / next work

- Fresh launch: publish HOME and LIVE; fast/slow/offline launches, tap during routing, rotation, login/onboarding and push/deep-link bypass. Offline first install has no knowledge of unpublished remote settings and defaults HOME.
- Host + 1-7 guests + separate audience: own vs remote frames, camera off/on/flip, approval, seat leave/rejoin, layout changes, token renewal and reconnect. Backend camera-on state does not bypass consent.
- Wi-Fi/mobile switch, short loss, foreground/background/PiP, headset add/remove, explicit listener mute and 30+ minute sessions. Android background restrictions must be tested; no new background microphone/camera permission/service was introduced.
- Simultaneous gift/comment traffic: exact quantity/totals, each sender's equipped colors, sound slider/off, no duplicate debit, no UI stalling. Measure cold/warm start, first audio/video and frame/CPU/memory behavior on actual low/mid-range phones; no invented performance timings.
- Google Play: current UGC Report/Block/moderation, privacy/Data Safety, account deletion, camera/mic disclosures/consent and digital-goods billing must be checked in the actual release/configuration. In particular billing product/server setup, safety operations, 16KB native support, target rules and declarations cannot be certified by source inspection. Do not call the app Play-approved in advance.

No iOS work or avatar-loading optimization is included. No features were removed and no financial paths rewritten.

Policy references checked for this source edit (recheck at publication):
- https://support.google.com/googleplay/android-developer/answer/9876937 (UGC)
- https://support.google.com/googleplay/android-developer/answer/9858738 (payments)
- https://developer.android.com/guide/practices/page-sizes (native page-size compatibility)
- https://support.google.com/googleplay/android-developer/answer/9877032 (review game/reward/cash-out combinations if any involve wagering; no such financial behavior was changed here).
