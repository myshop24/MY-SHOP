package com.myshop.app;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.SystemClock;
import android.view.*;
import android.widget.*;
import org.json.*;

/** PK presentation only: server scores/expiry and existing purchase logic remain authoritative. */
final class PkBar648 extends LinearLayout {
 private final Strip strip;private final LinearLayout leftPeople,rightPeople;private final TextView clock;
 private String people="";private long deadline;private boolean expired;
 PkBar648(Context c){super(c);setOrientation(VERTICAL);setClipChildren(true);strip=new Strip(c);addView(strip,new LayoutParams(-1,dp(18)));
  LinearLayout bottom=new LinearLayout(c);bottom.setGravity(Gravity.CENTER_VERTICAL);bottom.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xaab72476,0x99321d62,0xaa356ac1}));addView(bottom,new LayoutParams(-1,dp(42)));
  leftPeople=new LinearLayout(c);leftPeople.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);bottom.addView(leftPeople,new LayoutParams(0,-1,1));
  clock=new TextView(c);clock.setTextColor(Color.WHITE);clock.setTextSize(12);clock.setGravity(Gravity.CENTER);clock.setSingleLine(true);clock.setBackgroundColor(0x44251143);bottom.addView(clock,new LayoutParams(dp(86),dp(30)));
  rightPeople=new LinearLayout(c);rightPeople.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);bottom.addView(rightPeople,new LayoutParams(0,-1,1));
 }
 void update(long left,long right,long remaining,String currency,JSONArray users,String host){strip.set(left,right);expired=remaining<=0;deadline=SystemClock.elapsedRealtime()+Math.max(0,remaining)*1000;tick.run();String key=host+String.valueOf(users);if(key.equals(people))return;people=key;
  for(int side=0;side<2;side++){LinearLayout group=side==0?leftPeople:rightPeople;group.removeAllViews();JSONObject[] selected=new JSONObject[3];int count=0;for(int i=0;users!=null&&i<users.length()&&count<3;i++){JSONObject u=users.optJSONObject(i);if(u!=null&&host.equals(u.optString("host_id"))==(side==0))selected[count++]=u;}
   for(int index=0;index<3;index++){int rank=side==0?index:2-index;JSONObject person=selected[rank];FrameLayout holder=new FrameLayout(getContext());holder.setContentDescription(person==null?"PK supporter rank "+(rank+1):person.optString("full_name")+" • "+person.optLong("score")+" • rank "+(rank+1));
    ImageView photo=new ImageView(getContext());photo.setScaleType(ImageView.ScaleType.CENTER_CROP);photo.setImageResource(person==null?R.drawable.live_guest_chair:R.drawable.myshop_profile_avatar);GradientDrawable circle=new GradientDrawable();circle.setShape(GradientDrawable.OVAL);circle.setColor(side==0?0x66872686:0x665b74dc);circle.setStroke(dp(1),side==0?0xfff6aedb:0xff9cccff);photo.setBackground(circle);photo.setClipToOutline(true);photo.setPadding(dp(person==null?6:1),dp(person==null?6:1),dp(person==null?6:1),dp(person==null?6:1));if(person!=null&&!person.optString("avatar_url").isEmpty())CachedImages.load(photo,person.optString("avatar_url"));FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(28),dp(28),Gravity.CENTER);pp.bottomMargin=dp(5);holder.addView(photo,pp);
    TextView badge=new TextView(getContext());badge.setText(String.valueOf(rank+1));badge.setTextSize(8);badge.setTextColor(side==0?0xffb7641a:0xff6049b8);badge.setGravity(Gravity.CENTER);badge.setTypeface(null,Typeface.BOLD);GradientDrawable tile=new GradientDrawable();tile.setColor(side==0?0xffffe0ad:0xffd9deff);tile.setCornerRadius(dp(3));badge.setBackground(tile);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(12),dp(12),Gravity.BOTTOM|Gravity.RIGHT);bp.rightMargin=dp(1);bp.bottomMargin=dp(2);holder.addView(badge,bp);group.addView(holder,new LayoutParams(0,-1,1));
   }
  }
 }
 private final Runnable tick=new Runnable(){public void run(){removeCallbacks(this);long seconds=expired?0:Math.max(0,(deadline-SystemClock.elapsedRealtime()+999)/1000);String time=String.format(java.util.Locale.US,"%02d:%02d",seconds/60,seconds%60);android.text.SpannableString text=new android.text.SpannableString("PK  "+time);text.setSpan(new android.text.style.StyleSpan(Typeface.BOLD_ITALIC),0,2,0);text.setSpan(new android.text.style.ForegroundColorSpan(0xffff78dc),0,2,0);clock.setText(text);clock.setContentDescription("PK "+time);if(seconds>0&&isAttachedToWindow()&&isShown()&&getWindowVisibility()==VISIBLE)postDelayed(this,250);}};
 @Override protected void onAttachedToWindow(){super.onAttachedToWindow();tick.run();}
 @Override protected void onDetachedFromWindow(){removeCallbacks(tick);super.onDetachedFromWindow();}
 @Override protected void onVisibilityChanged(View v,int visibility){super.onVisibilityChanged(v,visibility);if(clock!=null)tick.run();}
 @Override protected void onWindowVisibilityChanged(int visibility){super.onWindowVisibilityChanged(visibility);if(clock!=null)tick.run();}
 private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 static float ratio(long left,long right){double total=(double)Math.max(0,left)+Math.max(0,right);return total==0?.5f:(float)(Math.max(0,left)/total);}
 private static final class Strip extends View {
  final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);final Path bolt=new Path();long a,b;Shader pink,blue;
  Strip(Context c){super(c);}
  void set(long left,long right){a=Math.max(0,left);b=Math.max(0,right);setContentDescription("PK "+a+" : "+b);invalidate();}
  @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){pink=new LinearGradient(0,0,w,0,new int[]{0xffff147a,0xffff8dd7},null,Shader.TileMode.CLAMP);blue=new LinearGradient(0,0,w,0,new int[]{0xff6be8f7,0xff5838ff},null,Shader.TileMode.CLAMP);}
  @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),split=w*ratio(a,b);if(w<=0||h<=0)return;int saved=c.save();Path clip=new Path();clip.addRoundRect(new RectF(0,0,w,h),h*.16f,h*.16f,Path.Direction.CW);c.clipPath(clip);p.setShader(pink);c.drawRect(0,0,split,h,p);p.setShader(blue);c.drawRect(split,0,w,h,p);p.setShader(null);
   float x=Math.max(h*.45f,Math.min(w-h*.45f,split));p.setColor(0xfffeee85);bolt.reset();bolt.moveTo(x+3,0);bolt.lineTo(x-5,h*.57f);bolt.lineTo(x,h*.54f);bolt.lineTo(x-3,h);bolt.lineTo(x+6,h*.40f);bolt.lineTo(x+1,h*.45f);bolt.close();c.drawPath(bolt,p);
   p.setColor(Color.WHITE);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD_ITALIC));p.setTextSize(h*.70f);p.setShadowLayer(1,0,1,0x665a1b72);float baseline=(h-p.ascent()-p.descent())/2;c.drawText(String.valueOf(a),h*.35f,baseline,p);String right=String.valueOf(b);c.drawText(right,w-p.measureText(right)-h*.35f,baseline,p);p.clearShadowLayer();c.restoreToCount(saved);
  }
 }
}
