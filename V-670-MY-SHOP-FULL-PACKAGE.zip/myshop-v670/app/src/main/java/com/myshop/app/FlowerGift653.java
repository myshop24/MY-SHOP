package com.myshop.app;
import android.content.Context;import android.graphics.*;import android.graphics.drawable.*;import android.os.SystemClock;
/** Authored flower presentation reusing the original rose artwork; no external creation service. */
final class FlowerGift653 extends Drawable implements Animatable {
 private final GiftArt620 rose;private final Paint paint=new Paint(3);private final boolean gold;private long start;private boolean running;private int alpha=255;private final Runnable frame=new Runnable(){public void run(){if(running){invalidateSelf();scheduleSelf(this,SystemClock.uptimeMillis()+33);}}};
 FlowerGift653(Context c,String uri,boolean autoplay){gold=uri.endsWith("gold");rose=new GiftArt620(c,"myshop-gift620://coin/0",false);if(autoplay)start();}
 void playOnce(int duration){rose.playOnce(duration);start();}
 @Override public void draw(Canvas canvas){Rect bounds=getBounds();rose.setBounds(bounds);rose.draw(canvas);if(bounds.isEmpty())return;float phase=(SystemClock.uptimeMillis()-start)/1000f;paint.setColor(gold?0xffffce65:0xffff72aa);paint.setAlpha(alpha);for(int n=0;n<12;n++){float x=bounds.left+bounds.width()*(.08f+((n*73)%89)/100f),y=bounds.top+bounds.height()*((phase*.14f+n*.083f)%1f);int save=canvas.save();canvas.rotate(phase*42+n*31,x,y);canvas.drawOval(x-3,y-7,x+3,y+7,paint);canvas.restoreToCount(save);}}
 @Override public void start(){if(running)return;running=true;start=SystemClock.uptimeMillis();rose.playOnce(6000);invalidateSelf();scheduleSelf(frame,start+33);}
 @Override public void stop(){running=false;rose.stop();unscheduleSelf(frame);}
 @Override public boolean isRunning(){return running;}@Override public boolean setVisible(boolean visible,boolean restart){if(!visible)stop();else if(restart)start();return super.setVisible(visible,restart);}
 @Override public void setAlpha(int value){alpha=value;rose.setAlpha(value);invalidateSelf();}@Override public void setColorFilter(ColorFilter value){rose.setColorFilter(value);}@Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
