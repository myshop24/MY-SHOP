package com.myshop.app;
import android.content.Context;import android.graphics.*;import android.view.View;
/** One shared atlas; each gift samples its own cell, never five full decoded bitmaps. */
final class LuckyArt655 extends View {
 private static Bitmap atlas;private final int tier;private final Paint paint=new Paint(3);private final Rect source=new Rect();private final RectF target=new RectF();
 LuckyArt655(Context c,int index){super(c);tier=Math.max(0,Math.min(4,index));if(atlas==null)try(java.io.InputStream in=c.getAssets().open("lucky655.webp")){BitmapFactory.Options o=new BitmapFactory.Options();o.inSampleSize=2;atlas=BitmapFactory.decodeStream(in,null,o);}catch(Exception|OutOfMemoryError ignored){}setContentDescription("ফুলের বৃষ্টি "+(index+1));}
 protected void onDraw(Canvas c){super.onDraw(c);if(atlas==null)return;int cell=atlas.getWidth()/5;source.set(cell*tier,0,cell*(tier+1),atlas.getHeight());float ratio=cell/(float)atlas.getHeight(),h=Math.min(getHeight(),getWidth()/ratio),w=h*ratio;target.set((getWidth()-w)/2,(getHeight()-h)/2,(getWidth()+w)/2,(getHeight()+h)/2);c.drawBitmap(atlas,source,target,paint);}
}
