package com.myshop.app;

/** One navigation, even when the network response races the offline fallback. */
final class LaunchDecision663 {
    private boolean resolved;
    synchronized boolean claim() { if (resolved) return false; resolved = true; return true; }
    static String page(String value) { return "LIVE".equals(value) ? "LIVE" : "HOME"; }
}
