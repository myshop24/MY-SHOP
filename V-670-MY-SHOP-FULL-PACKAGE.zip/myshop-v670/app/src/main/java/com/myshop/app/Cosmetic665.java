package com.myshop.app;
import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
/** Decorative products: no identity, moderation or financial authority. */
public final class Cosmetic665 {
 private Cosmetic665(){}
 public static boolean item(JSONObject x){String t=x.optString("item_type");return t.equals("NAMEPLATE")||t.equals("MIC_EFFECT")||t.equals("STICKER_PACK");}
 public static int color(String code){if(code.endsWith("_RUBY"))return 0xffff628c;if(code.endsWith("_SAPPHIRE"))return 0xff56caff;if(code.endsWith("_EMERALD"))return 0xff52e9a7;if(code.endsWith("_VIOLET"))return 0xffc58aff;return 0xffffce70;}
 public static boolean valid(String code){return code!=null&&code.matches("(?:NP665_(?:ROYAL|CRYSTAL)|MIC665_(?:ORBIT|PULSE)|SP665_(?:HEART|STAR))_(?:GOLD|RUBY|SAPPHIRE|EMERALD|VIOLET)");}
 public static void nameplate(TextView view,String code){if(!valid(code)||!code.startsWith("NP665_"))return;view.setBackground(new Plate(code));view.setTextColor(Color.WHITE);float d=view.getResources().getDisplayMetrics().density;view.setPadding((int)(9*d),(int)(3*d),(int)(9*d),(int)(3*d));}
 public static final class Preview extends FrameLayout {
  public Preview(Context c,JSONObject item){super(c);String code=item.optString("code",item.optString("item_code"));setBackgroundColor(0xff10142c);if(code.startsWith("NP665_")){LinearLayout row=new LinearLayout(c);row.setGravity(Gravity.CENTER_VERTICAL);ImageView photo=new ImageView(c);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);photo.setImageResource(R.drawable.myshop_profile_avatar);CachedImages.load(photo,SessionManager.getAvatarUrl(c));row.addView(photo,new LinearLayout.LayoutParams(dp(c,38),dp(c,38)));TextView name=new TextView(c);name.setText(SessionManager.getFullName(c));name.setSingleLine(true);nameplate(name,code);row.addView(name,new LinearLayout.LayoutParams(0,-2,1));addView(row,new LayoutParams(-1,dp(c,62),Gravity.CENTER));}else if(code.startsWith("MIC665_")){ImageView photo=new ImageView(c);photo.setImageResource(R.drawable.myshop_profile_avatar);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);CachedImages.load(photo,SessionManager.getAvatarUrl(c));LayoutParams p=new LayoutParams(dp(c,64),dp(c,64),Gravity.CENTER);addView(photo,p);SpeakingWaveView wave=new SpeakingWaveView(c);wave.setCosmetic665(code);wave.setSpeaking(true);addView(wave,new LayoutParams(dp(c,96),dp(c,96),Gravity.CENTER));}else addView(new Sticker(c,code),new LayoutParams(-1,-1));setContentDescription(item.optString("title","Cosmetic preview"));}
 }
 public static final class Sticker extends View {
  private final String code;private final Paint p=new Paint(3);
  public Sticker(Context c,String code){super(c);this.code=code;setContentDescription(code.contains("HEART")?"Heart sticker":"Star sticker");}
  @Override protected void onDraw(Canvas c){super.onDraw(c);float s=Math.min(getWidth(),getHeight())*.72f,x=getWidth()/2f,y=getHeight()/2f;float phase=(android.os.SystemClock.uptimeMillis()%1800)/1800f;int save=c.save();c.translate(x,y+(float)Math.sin(phase*6.283)*s*.04f);p.setStyle(Paint.Style.FILL);p.setShader(new LinearGradient(-s/2,-s/2,s/2,s/2,new int[]{Color.WHITE,color(code),color(code)&0xffbfbfbf},null,Shader.TileMode.CLAMP));Path path=new Path();if(code.contains("HEART")){path.moveTo(0,s*.43f);path.cubicTo(-s*.85f,-s*.12f,-s*.40f,-s*.73f,0,-s*.28f);path.cubicTo(s*.40f,-s*.73f,s*.85f,-s*.12f,0,s*.43f);}else{for(int i=0;i<10;i++){double a=-Math.PI/2+i*Math.PI/5;float r=i%2==0?s*.53f:s*.25f;float px=(float)Math.cos(a)*r,py=(float)Math.sin(a)*r;if(i==0)path.moveTo(px,py);else path.lineTo(px,py);}path.close();}c.drawPath(path,p);p.setShader(null);p.setColor(0xff202342);c.drawOval(-s*.19f,-s*.03f,-s*.12f,s*.09f,p);c.drawOval(s*.12f,-s*.03f,s*.19f,s*.09f,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(s*.025f);c.drawArc(new RectF(-s*.1f,s*.05f,s*.1f,s*.19f),0,180,false,p);c.restoreToCount(save);if(isShown())postInvalidateDelayed(50);}
 }
 private static final class Plate extends Drawable {
  private final String code;private final Paint p=new Paint(3);private final Runnable tick=this::invalidateSelf;
  Plate(String code){this.code=code;}
  public void draw(Canvas c){Rect b=getBounds();float r=Math.min(b.height()*.3f,16);RectF box=new RectF(b);box.inset(1,1);p.setStyle(Paint.Style.FILL);p.setShader(new LinearGradient(b.left,b.top,b.right,b.bottom,new int[]{0xff14203e,0xff311c4f,0xff12172e},null,Shader.TileMode.CLAMP));c.drawRoundRect(box,r,r,p);p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);p.setColor(color(code));c.drawRoundRect(box,r,r,p);box.inset(3,3);p.setAlpha(130);c.drawRoundRect(box,r,r,p);p.setAlpha(255);if(code.contains("_CRYSTAL_")){p.setStrokeWidth(2);for(float x:new float[]{box.left+7,box.right-7}){c.drawLine(x-3,box.centerY(),x,box.centerY()-4,p);c.drawLine(x,box.centerY()-4,x+3,box.centerY(),p);c.drawLine(x+3,box.centerY(),x,box.centerY()+4,p);c.drawLine(x,box.centerY()+4,x-3,box.centerY(),p);}}float phase=(android.os.SystemClock.uptimeMillis()%3000)/3000f;p.setStyle(Paint.Style.FILL);c.drawCircle(box.left+box.width()*phase,box.top,2,p);if(getCallback()!=null){unscheduleSelf(tick);scheduleSelf(tick,android.os.SystemClock.uptimeMillis()+60);}}
  public void setAlpha(int a){p.setAlpha(a);}public void setColorFilter(ColorFilter f){p.setColorFilter(f);}public int getOpacity(){return PixelFormat.TRANSLUCENT;}
 }
 private static int dp(Context c,int n){return Math.round(n*c.getResources().getDisplayMetrics().density);}
}
