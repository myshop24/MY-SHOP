package com.myshop.app;

import android.app.Activity;
import android.content.Intent;
import android.view.*;
import android.widget.*;
import java.lang.ref.WeakReference;

/** In-app only: moves the existing room view, never creates a second RTC session or overlay permission. */
final class LiveMini667 {
    private static WeakReference<AudioLiveRoomActivity> owner=new WeakReference<>(null);
    private static View room;
    private static ViewGroup home;
    private static ViewGroup.LayoutParams homeParams;
    private static FrameLayout shell;
    private static String account="";
    private static int fullWidth,fullHeight;
    private static boolean moving;
    private static WeakReference<AudioLiveRoomActivity> pendingExit667=new WeakReference<>(null);
    static boolean active(){return room!=null&&owner.get()!=null;}
    static boolean resumeExisting667(Activity candidate){AudioLiveRoomActivity live=owner.get();if(!active()||live==candidate)return false;open();return true;}
    static boolean minimize(AudioLiveRoomActivity live){
        if(active()){restore();return false;}
        ViewGroup content=live.findViewById(android.R.id.content);
        if(content==null||content.getChildCount()!=1)return false;
        View view=content.getChildAt(0);if(view.getWidth()<=0||view.getHeight()<=0)return false;
        owner=new WeakReference<>(live);home=content;homeParams=view.getLayoutParams();room=view;fullWidth=view.getWidth();fullHeight=view.getHeight();account=SessionManager.getUserId(live);
        content.removeView(view);
        try{live.startActivity(new Intent(live,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));return true;}
        catch(RuntimeException error){restore();return false;}
    }
    static void resumed(Activity page){
        if(pendingExit667.get()==page){pendingExit667.clear();page.getWindow().getDecorView().post(()->{if(!page.isFinishing()&&!page.isDestroyed())((AudioLiveRoomActivity)page).confirmMiniExit667();});}
        AudioLiveRoomActivity live=owner.get();if(live==null||room==null)return;
        if(!account.equals(SessionManager.getUserId(page))||!SessionManager.hasUsableSession(page)){dispose(live);live.finish();return;}
        if(page==live){restore();return;}
        if(page instanceof AudioLiveRoomActivity){open();return;}
        if(page.isFinishing()||page.isDestroyed())return;
        detachShell();ViewGroup decor=(ViewGroup)page.getWindow().getDecorView();
        FrameLayout box=new FrameLayout(page);shell=box;box.setBackgroundColor(0xff111b38);box.setElevation(dp(page,16));box.setClipChildren(true);
        MiniContent content=new MiniContent(page);content.addView(room,new FrameLayout.LayoutParams(fullWidth,fullHeight));box.addView(content,new FrameLayout.LayoutParams(-1,-1));
        View touch=new View(page);touch.setContentDescription("Live • drag to move, tap to return");box.addView(touch,new FrameLayout.LayoutParams(-1,-1));
        touch.setOnTouchListener(new View.OnTouchListener(){float downX,downY,startX,startY;boolean dragged;
            public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:downX=e.getRawX();downY=e.getRawY();startX=box.getTranslationX();startY=box.getTranslationY();dragged=false;return true;
                case MotionEvent.ACTION_MOVE:float dx=e.getRawX()-downX,dy=e.getRawY()-downY;if(Math.abs(dx)+Math.abs(dy)>dp(page,8))dragged=true;box.setTranslationX(Math.max(-box.getLeft(),Math.min(decor.getWidth()-box.getRight(),startX+dx)));box.setTranslationY(Math.max(-box.getTop(),Math.min(decor.getHeight()-box.getBottom(),startY+dy)));return true;
                case MotionEvent.ACTION_UP:if(!dragged)open();return true;
                case MotionEvent.ACTION_CANCEL:return true;default:return true;}}
        });
        TextView close=new TextView(page);close.setText("×");close.setTextColor(-1);close.setTextSize(22);close.setGravity(Gravity.CENTER);close.setBackgroundColor(0xb3111b38);close.setContentDescription("Return to Live to leave or end");close.setOnClickListener(v->{pendingExit667=new WeakReference<>(live);open();});box.addView(close,new FrameLayout.LayoutParams(dp(page,36),dp(page,36),Gravity.TOP|Gravity.RIGHT));
        FrameLayout.LayoutParams position=new FrameLayout.LayoutParams(dp(page,112),dp(page,184),Gravity.RIGHT|Gravity.BOTTOM);position.rightMargin=dp(page,12);position.bottomMargin=dp(page,92);decor.addView(box,position);box.post(()->{if(shell==box&&!live.isDestroyed())live.rebindMiniVideo667(false);});
    }
    static void paused(Activity page){if(shell!=null&&shell.getContext()==page)detachShell();}
    private static void open(){AudioLiveRoomActivity live=owner.get();if(live==null)return;restore();live.startActivity(new Intent(live,AudioLiveRoomActivity.class).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT));}
    private static void detachShell(){if(room!=null&&room.getParent() instanceof ViewGroup)((ViewGroup)room.getParent()).removeView(room);if(shell!=null&&shell.getParent() instanceof ViewGroup)((ViewGroup)shell.getParent()).removeView(shell);shell=null;}
    private static void restore(){if(moving||room==null)return;moving=true;detachShell();if(home!=null){room.setScaleX(1);room.setScaleY(1);room.setTranslationX(0);room.setTranslationY(0);home.addView(room,homeParams);AudioLiveRoomActivity live667=owner.get();if(live667!=null)home.post(()->{if(!live667.isDestroyed())live667.rebindMiniVideo667(true);});}room=null;home=null;homeParams=null;owner.clear();account="";moving=false;}
    static void dispose(Activity page){if(owner.get()!=page)return;detachShell();room=null;home=null;homeParams=null;owner.clear();account="";}
    private static int dp(Activity a,int n){return Math.round(n*a.getResources().getDisplayMetrics().density);}
    private static final class MiniContent extends FrameLayout{
        MiniContent(Activity a){super(a);setClipChildren(true);}
        @Override protected void onMeasure(int widthSpec,int heightSpec){int w=MeasureSpec.getSize(widthSpec),h=MeasureSpec.getSize(heightSpec);setMeasuredDimension(w,h);if(getChildCount()>0)getChildAt(0).measure(MeasureSpec.makeMeasureSpec(fullWidth,MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(fullHeight,MeasureSpec.EXACTLY));}
        @Override protected void onLayout(boolean changed,int l,int t,int r,int b){if(getChildCount()==0)return;View child=getChildAt(0);child.layout(0,0,fullWidth,fullHeight);float scale=Math.min(getWidth()/(float)fullWidth,getHeight()/(float)fullHeight);child.setPivotX(0);child.setPivotY(0);child.setScaleX(scale);child.setScaleY(scale);child.setTranslationX((getWidth()-fullWidth*scale)/2);child.setTranslationY((getHeight()-fullHeight*scale)/2);}
    }
    private LiveMini667(){}
}
