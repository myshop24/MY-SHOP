package com.myshop.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import org.json.JSONObject;

/** Resolve the published landing page before building either page. */
public final class LaunchRouter663Activity extends Activity {
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LaunchDecision663 decision = new LaunchDecision663();
    private final Runnable fallback = () -> open(getSharedPreferences("launch661", 0).getString("page", "HOME"));

    static boolean shouldRoute(Intent i) {
        return i != null && i.getBooleanExtra("launch661", false)
                && !i.getBooleanExtra("launch_preview661", false)
                && i.getData() == null && !i.hasExtra("type") && !i.hasExtra("focusPostId")
                && !i.hasExtra("openMyFeed") && !i.hasExtra("openTextComposer");
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        FrameLayout screen = new FrameLayout(this);
        screen.setBackgroundColor(0xff071846);
        screen.addView(new ProgressBar(this), new FrameLayout.LayoutParams(72, 72, Gravity.CENTER));
        setContentView(screen);
        if (!SessionManager.hasUsableSession(this)) {
            startActivity(new Intent(this, LoginActivity.class)); finish(); return;
        }
        main.postDelayed(fallback, 1500);
        BackendClient.controls661(SessionManager.getToken(this), "/v1/app/launch661", null, new BackendClient.Callback() {
            public void onSuccess(JSONObject d) {
                String page = LaunchDecision663.page(d.optString("page", "HOME"));
                getSharedPreferences("launch661", 0).edit().putString("page", page).apply();
                open(page);
            }
            public void onError(String message) { fallback.run(); }
        });
    }

    private void open(String value) {
        if (isFinishing() || isDestroyed() || !decision.claim()) return;
        main.removeCallbacks(fallback);
        Intent target = new Intent(getIntent());
        target.removeExtra("launch661");
        target.setClass(this, "LIVE".equals(LaunchDecision663.page(value)) ? LiveHomeActivity.class : MainActivity.class);
        startActivity(target);
        finish();
    }
    @Override protected void onDestroy() { main.removeCallbacksAndMessages(null); super.onDestroy(); }
}
