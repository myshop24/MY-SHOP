package com.myshop.app;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.SystemClock;

/** Original transparent artwork with native particles/reveal/choreography, not a rigged 3D video. */
final class GiftArt667 extends Drawable implements Animatable {
 private static final Bitmap[] CACHE=new Bitmap[2];
 private final Bitmap atlas;private final int index;private final Rect source;private final Paint paint=new Paint(3);
 private int alpha=255,duration=7000;private boolean running,preview=true;private long epoch;
 private final Runnable tick=this::invalidateSelf;
 static synchronized void preload(Context c,boolean gold)throws java.io.IOException {int n=gold?1:0;if(CACHE[n]!=null)return;try(java.io.InputStream in=c.getApplicationContext().getAssets().open("gifts667/"+(gold?"diamond":"coin")+".webp")){Bitmap b=BitmapFactory.decodeStream(in);if(b==null)throw new java.io.IOException("Gift atlas unavailable");CACHE[n]=b;}}
 GiftArt667(Context c,String uri,boolean play){index=GiftMotion667.index(uri);int n=index>=20?1:0;atlas=CACHE[n];int slot=Math.max(0,index)%20;source=new Rect(slot%5*192,slot/5*256,(slot%5+1)*192,(slot/5+1)*256);if(play)start();}
 void playPreview667(int ms){preview=false;playOnce(ms);}
 void playOnce(int ms){preview=false;duration=Math.max(1000,Math.min(15000,ms));start();}
 public void draw(Canvas c){Rect b=getBounds();if(index<0||atlas==null||b.isEmpty())return;float elapsed=(SystemClock.uptimeMillis()-epoch)/(float)duration,p=running?(preview?elapsed%1:Math.min(1,elapsed)):(preview?.5f:1);float a=preview?1:GiftMotion667.opacity(p),u=Math.min(b.width(),b.height()),x=b.exactCenterX(),y=b.exactCenterY();int family=GiftMotion667.family(index),save=c.save();c.clipRect(b);paint.setAlpha((int)(alpha*a));
  if(!preview){float radius=u*(.15f+.38f*GiftMotion667.reveal(p));paint.setShader(new RadialGradient(x,y,Math.max(1,radius),new int[]{index>=20?0x88876bff:0x88ff6697,0x00000000},null,Shader.TileMode.CLAMP));c.drawCircle(x,y,radius,paint);paint.setShader(null);}
  float scale=preview?1:0.55f+.45f*GiftMotion667.reveal(p);float drift=preview?0:(float)Math.sin(p*Math.PI)*u*.018f;
  c.translate(x,y+drift);if(!preview&&family==1)c.rotate((float)Math.sin(p*22+index)*2);c.scale(scale,scale);
  float fit=Math.min(u*.78f/source.width(),u*.86f/source.height());RectF dest=new RectF(-source.width()*fit/2,-source.height()*fit/2,source.width()*fit/2,source.height()*fit/2);
  if(!preview&&family==3){int clip=c.save();float open=GiftMotion667.reveal(p);c.clipRect(dest.left,dest.bottom-dest.height()*open,dest.right,dest.bottom);c.drawBitmap(atlas,source,dest,paint);c.restoreToCount(clip);}else c.drawBitmap(atlas,source,dest,paint);
  c.restoreToCount(save);
  if(!preview){int count=index>=20?26:16;for(int k=0;k<count;k++){float t=(p*1.15f+k/(float)count)%1;double angle=k*2.399+index*.31;float px=x+(float)Math.cos(angle)*u*(.10f+.37f*t),py=y+(float)Math.sin(angle)*u*.32f*t-u*.12f*t;float r=u*(.004f+.007f*(1-t));paint.setAlpha((int)(alpha*a*(1-t)));paint.setColor(k%3==0?0xffffffff:index>=20?0xffffd871:0xffff86bf);
   if(family==1){paint.setStrokeWidth(Math.max(1,u*.003f));c.drawCircle(px,py,r*1.3f,paint);c.drawLine(px+r,py,px+r,py-r*5,paint);c.drawLine(px+r,py-r*5,px+r*3,py-r*4,paint);}
   else if(family==2){int layer=c.save();c.scale(.4f+.6f*Math.abs((float)Math.cos(t*18)),1,px,py);c.drawOval(px-r*3,py-r,px,py+r,paint);c.drawOval(px,py-r,px+r*3,py+r,paint);c.restoreToCount(layer);}
   else if(family==0){c.drawOval(px-r,py-r*2,px+r,py+r*2,paint);}
   else {paint.setStrokeWidth(Math.max(1,u*.002f));c.drawLine(px-r*2,py,px+r*2,py,paint);c.drawLine(px,py-r*2,px,py+r*2,paint);}
  }}
  if(preview){paint.setColor(index>=20?0xffffdc8a:0xffffd1e2);paint.setAlpha((int)(alpha*.65f));paint.setStrokeWidth(Math.max(1,u*.002f));for(int k=0;k<4;k++){float px=b.left+b.width()*(.22f+k*.19f),py=b.top+b.height()*(.18f+(k*37%59)/100f),r=u*.017f*(float)Math.pow(Math.sin((p+k*.21)*Math.PI),10);c.drawLine(px-r,py,px+r,py,paint);c.drawLine(px,py-r,px,py+r,paint);}}
  paint.setAlpha(alpha);if(running&&!preview&&elapsed>=1)running=false;if(running&&isVisible()&&getCallback()!=null){unscheduleSelf(tick);scheduleSelf(tick,SystemClock.uptimeMillis()+(preview?80:33));}
 }
 public void start(){epoch=SystemClock.uptimeMillis();running=true;invalidateSelf();}public void stop(){running=false;unscheduleSelf(tick);}public boolean isRunning(){return running;}
 public boolean setVisible(boolean visible,boolean restart){boolean changed=super.setVisible(visible,restart);if(!visible)unscheduleSelf(tick);else if(running)invalidateSelf();return changed;}
 public void setAlpha(int a){alpha=Math.max(0,Math.min(255,a));invalidateSelf();}public void setColorFilter(ColorFilter f){paint.setColorFilter(f);invalidateSelf();}public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
