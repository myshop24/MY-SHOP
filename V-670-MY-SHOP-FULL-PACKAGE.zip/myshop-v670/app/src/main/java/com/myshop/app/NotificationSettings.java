package com.myshop.app;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;
import androidx.core.app.NotificationManagerCompat;

/** User-controlled system alert settings; never silently reset a muted channel. */
public final class NotificationSettings {
    private NotificationSettings(){}
    public static String blockedChannel(Activity activity){
        if(!NotificationManagerCompat.from(activity).areNotificationsEnabled())return "APP";
        NotificationManager manager=(NotificationManager)activity.getSystemService(Activity.NOTIFICATION_SERVICE);
        if(manager!=null&&Build.VERSION.SDK_INT>=26){MyShopMessagingService.ensureChannels(manager);for(String id:new String[]{MyShopMessagingService.MESSAGE_CHANNEL,MyShopMessagingService.LIVE_CHANNEL}){NotificationChannel channel=manager.getNotificationChannel(id);if(channel!=null&&channel.getImportance()<NotificationManager.IMPORTANCE_HIGH)return id;}}
        return "";
    }
    public static void open(Activity activity){if(Build.VERSION.SDK_INT<26){activity.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+activity.getPackageName())));return;}String channel=blockedChannel(activity);Intent i=new Intent(Build.VERSION.SDK_INT>=26&&!channel.isEmpty()&&!"APP".equals(channel)?Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS:Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,activity.getPackageName());if(!channel.isEmpty())i.putExtra(Settings.EXTRA_CHANNEL_ID,channel);try{activity.startActivity(i);}catch(Exception e){activity.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+activity.getPackageName())));}}
    public static void badge(Activity activity){
        StringBuilder report=new StringBuilder();String blocked="";
        boolean allowed=NotificationManagerCompat.from(activity).areNotificationsEnabled();
        report.append(allowed?"অ্যাপের নোটিফিকেশন চালু আছে।":"অ্যাপের নোটিফিকেশন বন্ধ আছে।");
        NotificationManager manager=(NotificationManager)activity.getSystemService(Activity.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26&&manager!=null){MyShopMessagingService.ensureChannels(manager);String[] channels={MyShopMessagingService.MESSAGE_CHANNEL,MyShopMessagingService.LIVE_CHANNEL,MyShopMessagingService.GENERAL_CHANNEL,"myshop_friend_badge_v590"};for(String id:channels){NotificationChannel channel=manager.getNotificationChannel(id);if(channel!=null&&(!channel.canShowBadge()||channel.getImportance()==NotificationManager.IMPORTANCE_NONE)){report.append("\n").append(channel.getName()).append(": ব্যাজ বা নোটিফিকেশন বন্ধ।");if(blocked.isEmpty())blocked=id;}}}
        report.append("\n\nফোনের Settings-এ App icon badges চালু করুন। সমর্থিত launcher-এ সংখ্যা, অন্যটিতে ডট দেখাবে। সক্রিয় unread notification থাকলেই ব্যাজ দেখা যায়।");
        final String target=blocked;new MyShopDialogBuilder(activity).setTitle("অ্যাপ আইকনের নোটিফিকেশন").setMessage(report.toString()).setPositiveButton("Open settings",(d,w)->{if(Build.VERSION.SDK_INT>=26&&!target.isEmpty()){try{activity.startActivity(new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,activity.getPackageName()).putExtra(Settings.EXTRA_CHANNEL_ID,target));return;}catch(Exception ignored){}}open(activity);}).setNegativeButton(UiStrings.ui636("Close"),null).show();
    }
    public static void explain(Activity activity){new MyShopDialogBuilder(activity).setTitle("মেসেজ ও Live notification চালু করুন").setMessage("Settings-এ myshop notifications চালু করুন। Messages ও Live Alerts-এর Sound, Pop on screen / Banner এবং Lock screen notification অনুমতি দিন। ফোন Silent বা Do Not Disturb থাকলে popup বা sound বন্ধ থাকতে পারে।").setPositiveButton("Open settings",(d,w)->open(activity)).setNegativeButton("পরে",null).show();}
}
