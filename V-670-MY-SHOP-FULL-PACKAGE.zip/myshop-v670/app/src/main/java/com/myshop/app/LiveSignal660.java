package com.myshop.app;
import android.os.Handler;import android.os.Looper;import java.util.concurrent.TimeUnit;import okhttp3.*;
/** Authenticated wake-only socket; existing HTTP feed remains event/ACL authority and fallback. */
final class LiveSignal660 {
 private final Handler main=new Handler(Looper.getMainLooper());private final Runnable changed,ended;
 private final OkHttpClient client=new OkHttpClient.Builder().connectTimeout(8,TimeUnit.SECONDS).pingInterval(20,TimeUnit.SECONDS).build();
 private WebSocket socket;private int epoch,failures,attempt;private String key="",auth="",host="",session="";private boolean closed;volatile boolean connected;
 LiveSignal660(Runnable changed,Runnable ended){this.changed=changed;this.ended=ended;}
 void watch(String token,String room,String sid){if(closed||token==null||token.isEmpty()||sid==null||sid.isEmpty())return;String next=token+"|"+room+"|"+sid;if(next.equals(key))return;key=next;auth=token;host=room;session=sid;epoch++;connected=false;main.removeCallbacksAndMessages(null);if(socket!=null)socket.cancel();socket=null;connect(epoch);}
 private void connect(final int generation){if(closed||generation!=epoch)return;
  final int connection=++attempt;
  String base=BuildConfig.MYSHOP_BACKEND_URL.replaceAll("/$","");if(!base.startsWith("https://"))return;
  String url="wss://"+base.substring(8)+"/v1/live/realtime?hostId="+android.net.Uri.encode(host)+"&sessionId="+android.net.Uri.encode(session);
  Request request=new Request.Builder().url(url).header("Authorization","Bearer "+auth).build();
  socket=client.newWebSocket(request,new WebSocketListener(){
   public void onOpen(WebSocket ws,Response response){main.post(()->{if(closed||generation!=epoch||connection!=attempt){ws.cancel();return;}connected=true;failures=0;changed.run();ping(generation);});}
   public void onMessage(WebSocket ws,String text){if(text.length()>256)return;main.post(()->{if(!closed&&generation==epoch&&connection==attempt){if(text.contains("\"changed\""))changed.run();else if(text.contains("\"ended\""))ended.run();}});}
   public void onClosing(WebSocket ws,int code,String reason){ws.close(code,null);}
   public void onClosed(WebSocket ws,int code,String reason){lost(generation,connection);}
   public void onFailure(WebSocket ws,Throwable error,Response response){lost(generation,connection);}
  });
 }
 private void ping(int generation){main.postDelayed(()->{if(!closed&&generation==epoch&&connected&&socket!=null){socket.send("{\"type\":\"ping\"}");ping(generation);}},25000);}
 private void lost(int generation,int connection){main.post(()->{if(closed||generation!=epoch||connection!=attempt)return;connected=false;main.removeCallbacksAndMessages(null);long delay=Math.min(15000L,1000L<<Math.min(4,failures++));main.postDelayed(()->connect(generation),delay);});}
 void close(){closed=true;epoch++;connected=false;main.removeCallbacksAndMessages(null);if(socket!=null)socket.cancel();client.connectionPool().evictAll();client.dispatcher().executorService().shutdown();}
}
