package com.myshop.app;
import android.graphics.*;import android.graphics.drawable.Drawable;
/** Only the Live rail artwork; no changes to gift transactions or media. */
final class PremiumGift652 extends Drawable {
 private final Paint p=new Paint(3);private int alpha=255;private ColorFilter filter;
 public void draw(Canvas c){Rect b=getBounds();float z=Math.min(b.width(),b.height());int save=c.save();c.translate(b.centerX()-z/2,b.centerY()-z/2);c.scale(z/40,z/40);p.setAlpha(alpha);p.setColorFilter(filter);p.setStyle(Paint.Style.FILL);p.setShader(new LinearGradient(5,10,35,36,new int[]{0xffff93ed,0xffd327e8,0xff6734cb},null,Shader.TileMode.CLAMP));c.drawRoundRect(7,17,33,36,3,3,p);c.drawRoundRect(4,13,36,20,2,2,p);p.setShader(new LinearGradient(13,1,26,37,new int[]{0xfffff5b5,0xffffd04f,0xffe48c21},null,Shader.TileMode.CLAMP));c.drawRect(17,13,23,36,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.8f);c.drawOval(8,5,20,14,p);c.drawOval(20,5,32,14,p);p.setShader(null);p.setColor(0xfffff7dc);p.setStrokeWidth(1);c.drawLine(9,21,15,21,p);c.drawLine(25,21,31,21,p);p.setStyle(Paint.Style.FILL);Path spark=new Path();spark.moveTo(34,1);spark.lineTo(35,5);spark.lineTo(39,6);spark.lineTo(35,7);spark.lineTo(34,11);spark.lineTo(33,7);spark.lineTo(29,6);spark.lineTo(33,5);spark.close();c.drawPath(spark,p);c.restoreToCount(save);}
 public void setAlpha(int a){alpha=a;invalidateSelf();}public void setColorFilter(ColorFilter f){filter=f;invalidateSelf();}public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
