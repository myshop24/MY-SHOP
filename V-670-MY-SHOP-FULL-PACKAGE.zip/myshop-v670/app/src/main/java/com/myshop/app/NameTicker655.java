package com.myshop.app;
import android.content.Context;import android.graphics.Canvas;import android.text.Layout;import android.text.StaticLayout;import android.view.Gravity;import android.widget.TextView;
/** Single-line, clipped right-to-left travel; glyph order is preserved. No animation or allocation for fitting names. */
final class NameTicker655 extends TextView {
 private StaticLayout cached;private String last="";private float size;private long start;
 NameTicker655(Context c){super(c);setSingleLine(true);setGravity(Gravity.CENTER_VERTICAL);}
 @Override protected void onDraw(Canvas canvas){CharSequence value=getText();if(value==null)return;float width=getWidth()-getCompoundPaddingLeft()-getCompoundPaddingRight(),actual=Layout.getDesiredWidth(value,getPaint());if(width<=0)return;if(actual<=width){super.onDraw(canvas);return;}String text=value.toString();if(cached==null||!last.equals(text)||size!=getTextSize()){last=text;size=getTextSize();cached=StaticLayout.Builder.obtain(value,0,value.length(),getPaint(),Math.max(1,(int)Math.ceil(actual))).setIncludePad(false).setMaxLines(1).build();start=android.os.SystemClock.uptimeMillis();}long elapsed=android.os.SystemClock.uptimeMillis()-start;float progress=(elapsed%11000)/11000f;float x=width-progress*(actual+width);canvas.save();canvas.clipRect(getCompoundPaddingLeft(),0,getWidth()-getCompoundPaddingRight(),getHeight());canvas.translate(getCompoundPaddingLeft()+x,(getHeight()-cached.getHeight())/2f);cached.draw(canvas);canvas.restore();if(isShown())postInvalidateDelayed(40);}
 @Override protected void onAttachedToWindow(){super.onAttachedToWindow();start=android.os.SystemClock.uptimeMillis();invalidate();}
}
