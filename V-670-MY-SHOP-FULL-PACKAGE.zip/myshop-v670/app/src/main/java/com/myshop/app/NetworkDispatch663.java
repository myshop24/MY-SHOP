package com.myshop.app;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/** Keep live controls independent of downloads/dashboard calls; never run HTTP on the UI thread. */
final class NetworkDispatch663 {
    private final ThreadPoolExecutor live;
    private final ThreadPoolExecutor background;

    NetworkDispatch663() { this(4, 4, 128); }
    NetworkDispatch663(int liveThreads, int backgroundThreads, int capacity) {
        live = pool(liveThreads, capacity);
        background = pool(backgroundThreads, capacity);
    }
    private static ThreadPoolExecutor pool(int threads, int capacity) {
        ThreadPoolExecutor result = new ThreadPoolExecutor(threads, threads, 30, TimeUnit.SECONDS,
                new ArrayBlockingQueue<>(capacity), new ThreadPoolExecutor.AbortPolicy());
        result.allowCoreThreadTimeOut(true);
        return result;
    }
    static boolean urgent(String path) {
        return path != null && (path.startsWith("/v1/live/") || path.startsWith("/v1/live649/") || path.startsWith("/v1/pk")
                || path.equals("/v1/app/launch661"));
    }
    boolean submit(String path, Runnable work) {
        try { (urgent(path) ? live : background).execute(work); return true; }
        catch (RejectedExecutionException busy) { return false; }
    }
    void shutdown() { live.shutdownNow(); background.shutdownNow(); }
}
