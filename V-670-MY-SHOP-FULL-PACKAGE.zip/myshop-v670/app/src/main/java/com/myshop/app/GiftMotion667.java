package com.myshop.app;

/** Shared finite animation timeline; catalog idle never moves a tile outside its cell. */
final class GiftMotion667 {
 static int index(String uri){if(uri==null)return -1;java.util.regex.Matcher m=java.util.regex.Pattern.compile("myshop-gift667://(coin|gold)/(\\d{1,2})").matcher(uri);if(!m.matches())return -1;int n=Integer.parseInt(m.group(2));return n<20?n+(m.group(1).equals("gold")?20:0):-1;}
 static float ease(float value){float v=Math.max(0,Math.min(1,value));return v*v*(3-2*v);}
 static float opacity(float progress){return ease(progress/.13f)*(1-ease((progress-.86f)/.14f));}
 static float reveal(float progress){return ease(progress/.45f);}
 static int family(int index){int slot=Math.floorMod(index,20);if(slot==0||slot==7||slot==15)return 0;if(slot==2||slot==3||slot==6||slot==13||slot==14||slot==16)return 1;if(slot==5||slot==8||slot==12)return 2;if(slot==4||slot==11||slot==19)return 3;return 4;}
 private GiftMotion667(){}
}
