package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * V-314 premium Admin Control Center.
 * Login/gate/backend routes are intentionally preserved; this class only reorganizes the admin UX.
 */
public class AdminHubActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG = Color.rgb(246, 248, 254);
    private final int NAVY = Color.rgb(20, 32, 73);
    private final int MUTED = Color.rgb(100, 108, 130);
    private final int BLUE = Color.rgb(44, 106, 238);
    private final int PURPLE = Color.rgb(116, 55, 225);
    private final int PINK = Color.rgb(232, 49, 168);
    private final int CYAN = Color.rgb(32, 174, 222);
    private final int GREEN = Color.rgb(29, 159, 101);
    private final int ORANGE = Color.rgb(236, 138, 30);
    private final int RED = Color.rgb(220, 63, 79);
    private final int WHITE = Color.WHITE;

    private AdminMonitorPanels monitor;
    private AdminDashboard634 dashboard634;
    private LinearLayout moduleHost;
    private FrameLayout shell;
    private LinearLayout sideMenuPanel;
    private TextView requestBadge634;
    private View drawerShade634;
    private EditText searchBox;
    private final List<Module> modules = new ArrayList<>();
    private final Map<String, Category> categories = new LinkedHashMap<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        String uid = SessionManager.getUserId(this);
        if (AdminIdentifiers.isAdminIdentifier(uid)) {
            SessionManager.setRemoteSession(this, SessionManager.getToken(this), Role.ADMIN, AdminIdentifiers.adminIdFor(uid));
        }
        if (!SessionManager.isAdmin(this)) { finish(); return; }
        if (!getIntent().getBooleanExtra("gate_passed", false) && !SessionManager.isAdminGateUnlocked()) {
            startActivity(new Intent(this, AdminGateActivity.class));
            finish(); return;
        }
        seedModules();
        restoreFolderOrder();
        build();String requested=getIntent().getStringExtra("open_module");if(requested!=null&&!requested.isEmpty())open(requested);
    }

    @Override protected void onResume(){super.onResume();if(monitor!=null)monitor.resume();if(dashboard634!=null)dashboard634.resume();}
    @Override protected void onPause(){if(monitor!=null)monitor.pause();if(dashboard634!=null)dashboard634.pause();super.onPause();}

    private boolean bn() { return LanguageManager.BN.equals(LanguageManager.get(this)); }
    private String tr(String bangla, String english) { return bn() ? bangla : english; }
    private String langLabel() {
        String l = LanguageManager.get(this);
        if (LanguageManager.BN.equals(l)) return "🌐 বাংলা";
        if (LanguageManager.HI.equals(l)) return "🌐 हिन्दी";
        if (LanguageManager.AR.equals(l)) return "🌐 العربية";
        return "🌐 English";
    }

    private void seedModules() {
        categories.clear(); modules.clear();
        addCategory("finance","📺",tr("লাইভ হিসাব মনিটর","Live Accounting Monitor"),tr("বর্তমান ব্যালেন্স, ছাড়া, সরানো, কমিশন ও বিস্তারিত","Balances, issuance, removals, commission and details"),BLUE);
        addCategory("users","👤",tr("ইউজার নিয়ন্ত্রণ","User Controls"),tr("অ্যাকাউন্ট, আইডি ও অফিস গ্রান্ট","Accounts, IDs and office grants"),RED);
        addCategory("requests","📥",tr("রিকোয়েস্ট ও সাপোর্ট","Requests & Support"),tr("আবেদন, রিপোর্ট ও সাপোর্ট","Requests, reports and support"),GREEN);
        addCategory("commission","%",tr("মাইশপ কমিশন কয়েন & ডায়মন্ড","Myshop Commission Coin & Diamond"),tr("হার, হাইলাইট ফি ও হোস্টের ভাগ","Rates, highlight fee and host share"),PURPLE);
        addCategory("page1","🏠",tr("হোম ডিজাইন ও ব্যানার","Home Design & Banners"),tr("ব্যানার ম্যানেজার, হোম সাজান, হেডলাইন ও আইকন","Banner manager, Home layout, headline and icons"),BLUE);
        addCategory("live","📡",tr("লাইভ পরিচালনা","Live Management"),tr("রুম, গিফট, থীম ও সাউন্ড","Rooms, gifts, themes and sound"),PINK);
        addCategory("store","🛒",tr("স্টোর ও প্রোডাক্ট","Store & Products"),tr("পণ্য, Rare ID, ফ্রেম ও রাইডার","Products, Rare IDs, frames and rides"),ORANGE);
        addCategory("system","⚙",tr("অ্যাপ সেটিংস ও অ্যাডমিন লগ","App Settings & Admin Logs"),tr("ভাষা, অনুমতি, কনটেন্ট ও সিস্টেম","Language, access, content and system"),CYAN);

        add("page1","🖼",tr("পেইজ ১ • ব্যানার", "Page 1 • Banners"),tr("Hero 1–20 + Promo 1–20 • size guide • swipe • link", "Hero 1–20 + Promo 1–20 • size guide • swipe • link"),"banner",BLUE);
        add("page1","🧩",tr("পেইজ ১ • আইকন ও পজিশন", "Page 1 • Icons & Positions"),tr("নাম, লিংক, show/hide, ১–১০ position", "Name, link, show/hide and 1–10 position"),"page1_icons",PURPLE);
        add("page1","📣",tr("পেইজ ১ • হেডলাইন", "Page 1 • Headline"),tr("Breaking News লেখা, সাইজ ও রং", "Breaking News text, size and colors"),"dashboard",PINK);
        add("page2","🏞",tr("পেইজ ২ • ২০টি ব্যানার", "Page 2 • 20 Banners"),tr("Recommended size, preview, link, publish, delete", "Recommended size, preview, link, publish and delete"),"live_home_page",BLUE);
        add("page2","🧩",tr("পেইজ ২ • আইকন ও পজিশন", "Page 2 • Icons & Positions"),tr("Live Categories name, show/hide and position", "Live Categories name, show/hide and position"),"page2_icons",PURPLE);

        add("finance","💰",tr("লেনদেনের লেজার ও বিস্তারিত", "Transaction Ledger & Details"),tr("আজকের হিসাব, মোট, User ID খোঁজ ও audit", "Daily totals, user lookup and audit"),"finance_center",BLUE);
        add("finance","🛡",tr("মূল ইউজার নিয়ন্ত্রণ", "Main User Controls"),tr("ID দিয়ে Coin, Diamond ও সুবিধা পরিচালনা", "Manage user balances and benefits by ID"),"main_user_control",RED);
        add("finance","🕘",tr("ইউজার হিস্ট্রি", "User History"),tr("User ID দিয়ে full audit, transaction, moderation ও control", "Full user audit, transactions, moderation and controls"),"user_history",PURPLE);
        add("finance","↗",tr("Coin / Diamond উত্তোলনের আবেদন", "Withdrawal Requests"),tr("নতুন আবেদন, ইউজার ও পৃথক মুদ্রার হিসাব", "Requests, users and separate currencies"),"payout_inbox",RED);
        add("finance","💳",tr("পেমেন্ট পদ্ধতি", "Payment Methods"),tr("নাম, লিংক/মান, চালু/বন্ধ", "Name, link/value and visibility"),"payment_methods",PURPLE);
        add("finance","➕",tr("ইউজারকে Coin / Diamond দিন", "Give Coin / Diamond to User"),tr("User ID যাচাই করে Official grant দিন", "Verify User ID and send an Official grant"),"admin_wallet",GREEN);

        add("finance","🎁",tr("কয়েন ও ডায়মন্ড ক্যাটালগ", "Coin & Diamond Catalog"),tr("পূর্ণ Gift Studio • Grid, Edit, Drag, Sound Trim, Animation, Box, VAT, Publish", "Full Gift Studio • Grid, Edit, Drag, Sound Trim, Animation, Box, VAT, Publish"),"live_gifts",PINK);
        add("live","📹","Video Live • ON / OFF","Maintenance switch • Audio remains available","live_video648",PURPLE);
        add("live","✨","এনিমেশন বিজ্ঞাপন","Add • Edit • Save • Preview • Publish • Enable/Disable","animation645",PURPLE);
        add("live","🚀",tr("হাইলাইট কমেন্ট ফি ও হোস্টের ভাগ", "Highlight Fee & Host Share"),tr("Coin মূল্য • Host Enable/Disable • শতাংশ • Save", "Coin price • Host Enable/Disable • percentage • Save"),"highlight_settings",PURPLE);
        add("live","💬",tr("লাইভ কমেন্ট ও ব্যানার", "Live Comments & Banners"),tr("Global style, Badge presets, User search ও custom assignment", "Global style, badge presets, user search and custom assignment"),"live_comments",PINK);
        add("live","🏠",tr("লাইভ স্ট্রিমিং হোম পেইজ", "Live Streaming Home Page"),tr("২০টি ব্যানার, preview, link, publish ও delete", "20 banners, preview, links, publish and delete"),"live_home_page",BLUE);
        add("live","🎨",tr("অডিও লাইভ থিম", "Audio Live Themes"),tr("ব্যাকগ্রাউন্ড, accent, publish", "Background, accent and publish"),"live_themes",PURPLE);
        add("live","👑",tr("মেম্বারশিপ ম্যানেজমেন্ট", "Membership Management"),tr("KING/QUEEN/ROYAL/VVIP/VIP • Add/Edit/Delete • Price/Duration • Requests/Grant", "KING/QUEEN/ROYAL/VVIP/VIP • Add/Edit/Delete • Price/Duration • Requests/Grant"),"membership_admin",ORANGE);
        add("live","🚘",tr("রাইড / এন্ট্রি ম্যানেজমেন্ট", "Ride / Entry Management"),tr("Grid • Animation • Sound • Volume • Price • Duration • Add/Edit/Delete", "Grid • Animation • Sound • Volume • Price • Duration • Add/Edit/Delete"),"entry_ride",RED);
        add("live","🌌",tr("ওয়ালপেপার ম্যানেজমেন্ট", "Wallpaper Management"),tr("Upload • Live size guide • Crop/Fit • Order • Add/Edit/Delete • Publish", "Upload • Live size guide • Crop/Fit • Order • Add/Edit/Delete • Publish"),"wallpaper_admin",BLUE);
        add("live","♫",tr("স্থায়ী মিউজিক লাইব্রেরি", "Permanent Music Library"),tr("Album • Bulk audio • Add/Edit/Delete • Publish • Live playback", "Album • audio upload • Add/Edit/Delete • Publish • Live playback"),"live_music",CYAN);


        add("content","▣",tr("Home Upcoming Live", "Home Upcoming Live"),tr("হোমের ২০টি • স্বাধীন নিয়ন্ত্রণ", "Home • 20 independent entries"),"upcoming_live",BLUE);
        add("content","▣",tr("Live Page Upcoming Live", "Live Page Upcoming Live"),tr("লাইভ পেইজের ২০টি • স্বাধীন নিয়ন্ত্রণ", "Live page • 20 independent entries"),"upcoming_live_page",BLUE);
        add("content","🏞",tr("ব্যানার ম্যানেজমেন্ট", "Banner Management"),tr("সর্বোচ্চ ২০টি, upload/edit/save/delete", "Up to 20, upload/edit/save/delete"),"banner",BLUE);
        add("content","🖼",tr("গ্যালারি ম্যানেজমেন্ট", "Gallery Management"),tr("ছবি, অডিও, ভিডিও ও caption", "Images, audio, video and captions"),"gallery",CYAN);
        add("content","📢",tr("ড্যাশবোর্ড বিজ্ঞাপন", "Dashboard Ads"),tr("ছবি/ভিডিও, লিংক, ১–২০ বিজ্ঞাপন", "Image/video, links, 1–20 ads"),"ads",PINK);
        add("content","◐",tr("অ্যাপ থিম • লাইট / ডার্ক","App Themes • Light / Dark"),tr("১০ + ১০ • Preview / Save / Publish / Reset","20 presets • Preview / Save / Publish / Reset"),"app_theme_admin",CYAN);
        add("content","🌐",tr("কনটেন্টের চার ভাষা","Content translations"),tr("বাংলা / English / हिन्दी / العربية • Save","Four language content • Save"),"content_translations",CYAN);
        add("content","📰",tr("ড্যাশবোর্ড • ব্রেকিং নিউজ", "Dashboard • Breaking News"),tr("শিরোনাম, URL, text style ও save", "Headline, URLs, text style and save"),"dashboard",BLUE);
        add("content","✨",tr("ফিচার ম্যানেজমেন্ট", "Feature Management"),tr("নাম, icon, link, show/hide", "Name, icon, link and visibility"),"features",PURPLE);
        add("content","🔳",tr("ড্যাশবোর্ড ছোট ফিচার স্লট", "Dashboard Feature Slots"),tr("Slot 1–6, ছবি, caption, link", "Slots 1–6, image, caption and link"),"dynamic_content",CYAN);
        add("content","🌐",tr("সোশ্যাল লিংক", "Social Links"),tr("Facebook, YouTube, TikTok, WhatsApp ইত্যাদি", "Facebook, YouTube, TikTok, WhatsApp and more"),"social",BLUE);
        add("content","🎬",tr("এক্সটার্নাল মুভি", "External Movie"),tr("নাম, link, custom icon/image", "Name, link and custom icon/image"),"external_movie",PURPLE);
        add("content","📱",tr("আরও অ্যাপ", "More Apps"),tr("App name, link, icon, show/hide", "App name, link, icon and visibility"),"more_apps",GREEN);
        add("content","🚀",tr("অ্যাপ ওপেন বিজ্ঞাপন", "Startup Advertisement"),tr("Full Image/Fill Screen, image/video, 1–4 sec", "Full Image/Fill Screen, image/video, 1–4 sec"),"startup_ads",ORANGE);

        add("community","🧑‍💼",tr("মডারেটর / এডমিন", "Moderator / Admin"),tr("Moderator ID যোগ/সরান ও admin safety", "Add/remove moderator IDs and admin safety"),"moderators",PURPLE);
        add("community","📝",tr("MY FEED মডারেশন", "MY FEED Moderation"),tr("রিপোর্টেড/কুরুচিপূর্ণ পোস্ট review", "Review reported or abusive posts"),"feed_moderation",RED);
        add("community","💬",tr("কাস্টমার সাপোর্ট", "Customer Support"),tr("WhatsApp, imo, Facebook, website", "WhatsApp, imo, Facebook and website"),"help_support",GREEN);
        add("community","🛡",tr("Safety Reports • Account Deletion", "Safety Reports • Account Deletion"),tr("Report review, resolve/dismiss, deletion verification", "Report review, resolve/dismiss, deletion verification"),"safety_reports",RED);

        add("system","🏠",tr("প্রথম পেইজ—Home / Live", "First Page — Home / Live"),tr("ইউজার অ্যাপ খুললে কোন পেইজ দেখবে", "Choose the first page users see when opening the app"),"launch_settings661",CYAN);
        add("system","📣","অফিসিয়াল মেসেজ","MY SHOP Official • সব ইউজারের Inbox","official669",Color.RED);
        add("system","🩺",tr("সিস্টেম স্বাস্থ্য / পরীক্ষা", "System Health / Test"),tr("Worker, D1, R2 ও API পরীক্ষা", "Worker, D1, R2 and API checks"),"system_health",ORANGE);
        java.util.ArrayList<Module> normalized=new java.util.ArrayList<>();java.util.HashSet<String> seen=new java.util.HashSet<>();
        for(Module m:modules){if(java.util.Arrays.asList("admin_wallet","user_history").contains(m.mode))continue;if(java.util.Arrays.asList("banner","upcoming_live","upcoming_live_page","live_home_page","highlight_settings","ads","startup_ads").contains(m.mode))continue;
            String c=m.category;
            if("content".equals(c)||"community".equals(c))c="system";
            if("page2".equals(c))c="live";
            if(java.util.Arrays.asList("main_user_control","user_history","admin_wallet").contains(m.mode))c="users";
            if(java.util.Arrays.asList("payout_inbox","safety_reports","help_support").contains(m.mode))c="requests";
            if(java.util.Arrays.asList("membership_admin","entry_ride","wallpaper_admin").contains(m.mode))c="store";
            if("live_gifts".equals(m.mode))c="live";
            if(seen.add(m.mode))normalized.add(new Module(c,m.icon,m.title,m.desc,m.mode,m.color));
        }modules.clear();modules.addAll(normalized);
        add("finance","📺",tr("মার্কেটের সম্পূর্ণ হিসাব","Market Accounting Monitor"),tr("Coin / Diamond • অটো আপডেট • বিস্তারিত","Coin / Diamond • auto refresh • details"),"monitor633",BLUE);
        add("commission","%",tr("কমিশনের হার","Commission Rates"),"Coin / Diamond / Store","commission633",PURPLE);
        add("commission","💬",tr("হাইলাইট কমেন্ট—ফি ও হোস্ট কমিশন","Highlight Comment — Fee & Host Share"),tr("মূল্য, চালু/বন্ধ ও শতাংশ","Price, enable and percentage"),"highlight_settings",PURPLE);
        add("page1","🖼",tr("ব্যানার ম্যানেজার","Banner Manager"),tr("সব পেইজের বিজ্ঞাপন ও আপকামিং এক জায়গায়","All page ads and Upcoming banners"),"banners633",BLUE);
        add("page1","↕",tr("হোম সাজান—ব্যানার ও মাইফিড","Arrange Home — Banners & My Feed"),tr("ধরে টানুন • প্রিভিউ • কনফার্ম","Drag • preview • confirm"),"layout633",BLUE);
        add("store","🛍",tr("স্টোর ক্যাটালগ","Store Catalog"),tr("প্রোডাক্ট ও Rare ID","Products and Rare IDs"),"store633",ORANGE);
        add("requests","📥",tr("সব রিকোয়েস্ট","All Requests"),tr("নতুন ও অপেক্ষমাণ আবেদন","New and pending requests"),"requests633",GREEN);
        add("requests","📊",tr("রিপোর্ট সেন্টার","Reports Center"),tr("বিদ্যমান রিপোর্ট খুলুন","Open existing reports"),"reports634",BLUE);
        add("system","🔐",tr("অ্যাডমিন অনুমতি","Admin Permissions"),tr("অনুমতি নিয়ন্ত্রণ","Access controls"),"roles633",RED);
        add("system","🕘",tr("অ্যাডমিন লগ","Admin Audit"),tr("পরিবর্তনের ইতিহাস","Change history"),"audit633",PURPLE);

    }

    private android.content.SharedPreferences folderPreferences(){return getSharedPreferences("admin_folder_order_"+SessionManager.getUserId(this),MODE_PRIVATE);}
    private void restoreFolderOrder(){
        String saved=folderPreferences().getString("order","");
        Map<String,Category> ordered=new LinkedHashMap<>();
        for(String key:saved.split(",")){Category c=categories.get(key);if(c!=null)ordered.put(key,c);}
        for(Category c:categories.values())ordered.put(c.key,c);
        categories.clear();categories.putAll(ordered);
    }
    private void moveFolder(String source,String target){
        if(!SessionManager.isAdmin(this)||!SessionManager.isAdminGateUnlocked()||source.equals(target)||!categories.containsKey(source)||!categories.containsKey(target))return;
        Map<String,Category> ordered=new LinkedHashMap<>();
        for(Category c:categories.values()){if(c.key.equals(source))continue;if(c.key.equals(target))ordered.put(source,categories.get(source));ordered.put(c.key,c);}
        categories.clear();categories.putAll(ordered);
        folderPreferences().edit().putString("order",android.text.TextUtils.join(",",categories.keySet())).apply();
        renderModules(searchBox==null?"":searchBox.getText().toString());
        Toast.makeText(this,tr("ফোল্ডারের ক্রম এই ডিভাইসে সংরক্ষিত","Folder order saved on this device"),Toast.LENGTH_SHORT).show();
    }

    private void addCategory(String key, String icon, String title, String desc, int color) {
        categories.put(key, new Category(key, icon, title, desc, color));
    }
    private void add(String category, String icon, String title, String desc, String mode, int color) {
        modules.add(new Module(category, icon, title, desc, mode, color));
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setClipToPadding(false);

        LinearLayout root = col();
        root.setBackgroundColor(BG);
        root.setPadding(dp(12), dp(10), dp(12), dp(28));

        LinearLayout fixedHeader636=col();fixedHeader636.setBackgroundColor(Color.WHITE);fixedHeader636.addView(topBar(), lp(-1, dp(60)));
        LinearLayout searchRow=row();
        EditText userSearch=new EditText(this);userSearch.setSingleLine(true);userSearch.setHint(tr("ইউজার আইডি লিখে সার্চ করুন…","Search User ID…"));userSearch.setInputType(2);userSearch.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(8)});searchRow.addView(userSearch,weight(1));
        Button find=new Button(this);find.setText("🔍");searchRow.addView(find,lp(dp(58),dp(52)));find.setOnClickListener(v->{String id=userSearch.getText().toString().trim();if(!id.matches("[0-9]{4,8}")){userSearch.setError(tr("৪–৮ সংখ্যার ID দিন","Enter a 4–8 digit ID"));return;}startActivity(new Intent(this,AdminUserControlActivity.class).putExtra("userId",id));});fixedHeader636.addView(searchRow,lp(-1,dp(58)));
        dashboard634=new AdminDashboard634(this, count->{if(requestBadge634!=null)requestBadge634.setText(count<0?"🔔":"🔔 "+count);});root.addView(dashboard634.view(),lp(-1,-2));if(AuthorityBadge.isAuthority(SessionManager.getUserId(this))){TextView design=txt(tr("🎨 ডিজাইন ও রং • Preview / Save","🎨 Design & Colors • Preview / Save"),15,BLUE,true);design.setPadding(dp(12),dp(14),dp(12),dp(14));design.setOnClickListener(v->VisualDesign.edit(this,dashboard634.view(),"admin_dashboard"));root.addView(design);}
        sv.addView(root);
        shell=new FrameLayout(this);
        shell.setBackgroundColor(BG);
        LinearLayout page636=col();page636.addView(fixedHeader636,lp(-1,-2));page636.addView(sv,new LinearLayout.LayoutParams(-1,0,1));shell.addView(page636,new FrameLayout.LayoutParams(-1,-1));
        sideMenuPanel=buildSideMenu();
        drawerShade634=new View(this);drawerShade634.setBackgroundColor(0x77000000);drawerShade634.setVisibility(View.GONE);drawerShade634.setOnClickListener(v->toggleSideMenu());shell.addView(drawerShade634,new FrameLayout.LayoutParams(-1,-1));
        FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(Math.min(dp(340),Math.round(getResources().getDisplayMetrics().widthPixels*.86f)),-1,Gravity.START);
        shell.addView(sideMenuPanel,sp);
        sideMenuPanel.bringToFront();
        shell.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(i.getSystemWindowInsetLeft(),i.getSystemWindowInsetTop(),i.getSystemWindowInsetRight(),i.getSystemWindowInsetBottom());return i;});setContentView(shell);shell.requestApplyInsets();
    }

    private View topBar() {
        LinearLayout row = row(); row.setGravity(Gravity.CENTER_VERTICAL);row.setBackgroundColor(0xff064c92);Appearance.preserve(row);
        TextView back = txt("☰", 24, WHITE, true); back.setGravity(Gravity.CENTER); back.setOnClickListener(v -> toggleSideMenu()); row.addView(back, lp(dp(42), dp(48)));
        LinearLayout brand = col();
        TextView logo = txt("👑 myshop", 18, WHITE, true); logo.setLetterSpacing(.02f); brand.addView(logo, lp(-1, dp(26)));
        brand.addView(txt(tr("অ্যাডমিন প্যানেল", "Admin Panel"), 9.5f, 0xffd3eaff, true), lp(-1, dp(18)));
        row.addView(brand, weight(1));
        requestBadge634=txt("🔔",14,WHITE,true);requestBadge634.setGravity(Gravity.CENTER);requestBadge634.setOnClickListener(v->open("requests633"));row.addView(requestBadge634,lp(dp(45),dp(42)));
        TextView lang = chip(langLabel(), BLUE, BLUE); lang.setOnClickListener(v -> LanguageManager.showPicker(this, this::recreate)); row.addView(lang, lp(dp(62), dp(38)));
        TextView more = chip("👤", NAVY, BLUE); more.setTextSize(22); more.setOnClickListener(v -> showAdminMenu(more)); row.addView(more, left(lp(dp(42),dp(38)),dp(6)));
        return row;
    }

    private View heroCard() {
        LinearLayout hero = col(); hero.setPadding(dp(18), dp(16), dp(18), dp(14));
        hero.setBackground(gradient(new int[]{Color.rgb(38,83,216), Color.rgb(91,61,226), Color.rgb(219,55,180)}, 22));
        TextView crown = txt("👑  "+tr("স্বাগতম, Admin!", "Welcome, Admin!"), 21, WHITE, true); hero.addView(crown, lp(-1, dp(38)));
        TextView sub = txt(tr("myshop-কে এক জায়গা থেকে সহজে পরিচালনা করুন", "Manage myshop easily from one organized place"), 11.5f, Color.rgb(240,242,255), false); hero.addView(sub, lp(-1, dp(30)));
        TextView note = txt(tr("ফোল্ডার খুলুন → প্রয়োজনীয় অংশ বাছুন → পরিবর্তন করুন → Preview → Save/Publish", "Open a folder → choose a module → edit → Preview → Save/Publish"), 10.5f, WHITE, true);
        note.setPadding(dp(11),dp(7),dp(11),dp(7)); note.setBackground(round(Color.argb(38,255,255,255), Color.argb(75,255,255,255), 13)); hero.addView(note, top(lp(-1,-2),dp(6)));
        return hero;
    }

    private View quickStatus() {
        LinearLayout row = row(); row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(statusTile("🔐",tr("Admin", "Admin"),tr("Verified", "Verified"),BLUE),weight(1));
        row.addView(statusTile("🗂",String.valueOf(categories.size()),tr("Folders", "Folders"),PURPLE),left(weight(1),dp(7)));
        row.addView(statusTile("🧩",String.valueOf(modules.size()),tr("Tools", "Tools"),PINK),left(weight(1),dp(7)));
        return row;
    }

    private View statusTile(String icon, String big, String small, int color) {
        LinearLayout c = col(); c.setGravity(Gravity.CENTER); c.setPadding(dp(6),dp(7),dp(6),dp(5)); c.setBackground(round(WHITE,Color.rgb(224,228,241),16));
        TextView t = txt(icon+"  "+big,13,color,true); t.setGravity(Gravity.CENTER); c.addView(t,lp(-1,dp(27)));
        TextView s = txt(small,9.5f,MUTED,false); s.setGravity(Gravity.CENTER); c.addView(s,lp(-1,dp(22)));
        return c;
    }

    private void renderModules(String query) {
        if (moduleHost == null) return;
        moduleHost.removeAllViews();
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        int found = 0;
        for (Category cat : categories.values()) {
            List<Module> group = new ArrayList<>();
            for (Module m : modules) {
                if (!cat.key.equals(m.category)) continue;
                if (q.isEmpty() || (m.title+" "+m.desc+" "+cat.title).toLowerCase(Locale.ROOT).contains(q)) group.add(m);
            }
            if (group.isEmpty()) continue;
            found += group.size();
            moduleHost.addView(categoryFolder(cat, group, !q.isEmpty()), top(lp(-1,-2),dp(8)));
        }
        if (found == 0) {
            LinearLayout empty = card(); empty.setGravity(Gravity.CENTER); empty.setPadding(dp(12),dp(22),dp(12),dp(22));
            TextView t = txt(tr("কিছু পাওয়া যায়নি\nঅন্য শব্দ দিয়ে খুঁজুন", "Nothing found\nTry another search"),12,MUTED,true); t.setGravity(Gravity.CENTER); empty.addView(t,lp(-1,-2));
            moduleHost.addView(empty,lp(-1,-2));
        }
    }

    private View categoryFolder(Category cat, List<Module> group, boolean openInitially) {
        LinearLayout outer = card();
        outer.setOnDragListener((view,event)->{
            if(!(event.getLocalState() instanceof String))return false;
            if(event.getAction()==android.view.DragEvent.ACTION_DROP){moveFolder((String)event.getLocalState(),cat.key);return true;}
            return true;
        });
        outer.setPadding(0,0,0,0); outer.setClipToPadding(false);
        LinearLayout header = row(); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(12),dp(11),dp(10),dp(11));
        TextView icon = txt(cat.icon,23,WHITE,true); icon.setGravity(Gravity.CENTER); icon.setBackground(gradient(new int[]{cat.color, brighten(cat.color)},16)); header.addView(icon,lp(dp(50),dp(50)));
        LinearLayout copy = col(); copy.setPadding(dp(12),0,dp(5),0); copy.addView(txt(cat.title,14,NAVY,true),lp(-1,dp(26))); TextView d=txt(cat.desc,9.7f,MUTED,false); d.setMaxLines(2); copy.addView(d,lp(-1,dp(32))); header.addView(copy,weight(1));
        TextView count = txt(group.size()+"  ›",11,cat.color,true); count.setGravity(Gravity.CENTER); count.setBackground(round(light(cat.color),Color.TRANSPARENT,12)); header.addView(count,lp(dp(58),dp(36)));
        header.setOnLongClickListener(v->{if(!SessionManager.isAdminGateUnlocked())return false;return header.startDragAndDrop(android.content.ClipData.newPlainText("admin_folder",cat.key),new View.DragShadowBuilder(header),cat.key,0);});
        header.setContentDescription(cat.title+" • Hold and drag to move");
        outer.addView(header,lp(-1,dp(72)));if("store".equals(cat.key))AdminNoticeBadge.attach(this,outer,"SHOP");else if("requests".equals(cat.key))AdminNoticeBadge.attach(this,outer,"ALL");

        LinearLayout body = col(); body.setPadding(dp(8),0,dp(8),dp(8));
        for (Module m : group) body.addView(moduleCard(m), top(lp(-1,-2),dp(7)));
        body.setVisibility(openInitially ? View.VISIBLE : View.GONE);
        outer.addView(body,lp(-1,-2));
        header.setOnClickListener(v -> {
            boolean show = body.getVisibility() != View.VISIBLE;
            body.setVisibility(show ? View.VISIBLE : View.GONE);
            count.setText(group.size() + (show ? "  ⌄" : "  ›"));
            press(header);
        });
        count.setText(group.size() + (openInitially ? "  ⌄" : "  ›"));
        return outer;
    }

    private View moduleCard(Module m) {
        LinearLayout row = row(); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(10),dp(9),dp(9),dp(9)); row.setBackground(round(Color.rgb(251,252,255),Color.rgb(230,233,244),15));
        TextView icon = txt(m.icon,21,m.color,true); icon.setGravity(Gravity.CENTER); icon.setBackground(round(light(m.color),Color.TRANSPARENT,13)); row.addView(icon,lp(dp(46),dp(46)));
        LinearLayout copy=col(); copy.setPadding(dp(10),0,dp(4),0); TextView title=txt(m.title,12.5f,NAVY,true); title.setMaxLines(1); copy.addView(title,lp(-1,dp(24))); TextView desc=txt(m.desc,9.3f,MUTED,false); desc.setMaxLines(2); copy.addView(desc,lp(-1,dp(31))); row.addView(copy,weight(1));AdminNoticeBadge.attach(this,copy,AdminNoticeBadge.kind(m.mode));
        TextView open=txt(tr("খুলুন  ›","Open  ›"),10,m.color,true); open.setGravity(Gravity.CENTER); open.setBackground(round(light(m.color),Color.TRANSPARENT,12)); row.addView(open,lp(dp(70),dp(38)));
        if("official669".equals(m.mode)){title.setTextColor(Color.RED);Appearance.preserve(title);}
        if("main_user_control".equals(m.mode)){row.setBackground(round(RED,RED,15));Appearance.preserve(row);title.setTextColor(WHITE);desc.setTextColor(WHITE);Appearance.preserve(title);Appearance.preserve(desc);}
        row.setOnClickListener(v -> open(m.mode));
        row.setOnTouchListener((v,e)->{ if(e.getAction()==MotionEvent.ACTION_DOWN) v.animate().scaleX(.987f).scaleY(.987f).alpha(.92f).setDuration(55).start(); else if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL) v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(95).start(); return false; });
        return row;
    }

    private void toggleSideMenu(){if(sideMenuPanel==null)return;boolean show=sideMenuPanel.getVisibility()!=View.VISIBLE;sideMenuPanel.setVisibility(show?View.VISIBLE:View.GONE);if(drawerShade634!=null)drawerShade634.setVisibility(show?View.VISIBLE:View.GONE);if(show)sideMenuPanel.bringToFront();}

    private LinearLayout buildSideMenu(){
        LinearLayout wrap=col();wrap.setPadding(0,0,0,dp(10));wrap.setBackgroundColor(Color.WHITE);wrap.setVisibility(View.GONE);wrap.setElevation(dp(16));
        LinearLayout head=col();head.setPadding(dp(16),dp(18),dp(12),dp(14));head.setBackgroundColor(0xff063367);head.setOnClickListener(v->toggleSideMenu());head.addView(txt("👑  myshop     ×",17,Color.WHITE,true),lp(-1,dp(30)));head.addView(txt(UiStrings.ui636("Admin Panel"),10,Color.rgb(80,220,245),true),lp(-1,dp(22)));wrap.addView(head,lp(-1,dp(78)));
        ScrollView scroll=new ScrollView(this);LinearLayout list=col();list.setPadding(dp(8),dp(4),dp(8),dp(12));
        addSide(list,"🏠",tr("ড্যাশবোর্ড","Dashboard"),()->{},true);
        addSide(list,"↩",tr("অ্যাপে ফিরুন","Back to app"),this::finish,false);
        EditText toolSearch=new EditText(this);toolSearch.setTextColor(NAVY);toolSearch.setHintTextColor(MUTED);toolSearch.setHint(tr("Tool খুঁজুন…","Search tools…"));list.addView(toolSearch);
        LinearLayout inventory=col();list.addView(inventory);
        Runnable populate=()->{inventory.removeAllViews();String query=toolSearch.getText().toString().toLowerCase(java.util.Locale.ROOT);for(Category cat:categories.values()){LinearLayout group=col();TextView title=txt(cat.title,13,BLUE,true);title.setPadding(dp(8),dp(14),0,dp(6));group.addView(title);int n=0;for(Module m:modules){if(!m.category.equals(cat.key)||!(m.title+" "+m.desc).toLowerCase(java.util.Locale.ROOT).contains(query))continue;addSide(group,m.icon,m.title,()->open(m.mode),false);n++;}if(n>0)inventory.addView(group);}};
        toolSearch.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void afterTextChanged(Editable e){}public void onTextChanged(CharSequence s,int st,int before,int count){populate.run();}});populate.run();
        addSide(list,"⏻",tr("লগআউট","Logout"),this::logout,false);
        scroll.addView(list);wrap.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));return wrap;
    }
    private void addSide(LinearLayout host,String icon,String label,Runnable action,boolean accent){TextView v=txt(icon+"   "+label,12.5f,accent?Color.WHITE:NAVY,accent);v.setGravity(Gravity.CENTER_VERTICAL);v.setPadding(dp(10),0,dp(8),0);v.setBackground(accent?gradient(new int[]{Color.rgb(64,77,230),Color.rgb(63,175,232)},10):round(Color.TRANSPARENT,Color.TRANSPARENT,10));v.setOnClickListener(x->{press(v);toggleSideMenu();action.run();});host.addView(v,top(lp(-1,dp(42)),dp(3)));}

    private void openGiftCurrency(String currency){Intent i=new Intent(this,LiveGiftAdminActivity.class);i.putExtra("currency",currency);startActivity(i);}

    private void showAdminMenu(View anchor) {
        PopupMenu p = new PopupMenu(this, anchor);
        p.getMenu().add(tr("আমার প্রোফাইল", "My Profile"));
        p.getMenu().add(tr("সিস্টেম স্বাস্থ্য", "System Health"));
        p.getMenu().add("My Active Sessions");
        p.getMenu().add(tr("লগআউট", "Logout"));
        p.setOnMenuItemClickListener(item -> {
            String s = item.getTitle().toString();
            if (s.equals(tr("আমার প্রোফাইল","My Profile"))) startActivity(new Intent(this,UserProfileActivity.class).putExtra("userId",SessionManager.getUserId(this)));
            else if (s.equals(tr("সিস্টেম স্বাস্থ্য","System Health"))) startActivity(new Intent(this,AdminSystemHealthActivity.class));
            else if(s.equals("My Active Sessions"))AdminSessions634.show(this);
            else logout();
            return true;
        });
        p.show();
    }

    private void open(String mode) {
        if("live_video648".equals(mode)){LivePolicy648.show(this);return;}
        if("animation645".equals(mode)){startActivity(new Intent(this,AnimationAds645Activity.class));return;}
        if("monitor633".equals(mode)){startActivity(new Intent(this,FinanceMonitor633Activity.class));return;}
        if("commission633".equals(mode)){startActivity(new Intent(this,CommissionManagementActivity.class));return;}
        if("banners633".equals(mode)){startActivity(new Intent(this,BannerManager633Activity.class));return;}
        if("layout633".equals(mode)){startActivity(new Intent(this,MainActivity.class).putExtra("home_layout_preview632",true));return;}
        if("store633".equals(mode)){startActivity(new Intent(this,AdminStoreActivity.class));return;}
        if("requests633".equals(mode)){startActivity(new Intent(this,AdminRequestCenterActivity.class));return;}
        if("roles633".equals(mode)){startActivity(new Intent(this,AdminManagementActivity.class).putExtra("admin_context",true));return;}
        if("reports634".equals(mode)){AdminReports634.show(this);return;}
        if("audit633".equals(mode)){startActivity(new Intent(this,AdminModerationHistoryActivity.class));return;}

        if("main_user_control".equals(mode)){startActivity(new Intent(this,AdminUserControlActivity.class));return;}
        if ("payout_inbox".equals(mode)) { startActivity(new Intent(this,PayoutInboxActivity.class).putExtra("admin",true)); return; }
        if ("finance_center".equals(mode)) { startActivity(new Intent(this,AdminFinanceActivity.class)); return; }
        if ("upcoming_live_page".equals(mode)) { startActivity(new Intent(this,UpcomingLiveAdminActivity.class).putExtra("upcoming_scope","live")); return; }
        if ("upcoming_live".equals(mode)) { startActivity(new Intent(this,UpcomingLiveAdminActivity.class)); return; }
        if ("banner".equals(mode)) { startActivity(new Intent(this,BannerAdminActivity.class)); return; }
        if ("gallery".equals(mode)) { startActivity(new Intent(this,GalleryAdminActivity.class)); return; }
        if ("ads".equals(mode)) { startActivity(new Intent(this,DashboardAdsAdminActivity.class)); return; }
        if ("startup_ads".equals(mode)) {
            Intent i = new Intent(this,DashboardAdsAdminActivity.class);
            i.putExtra("box_key","startup_ad");
            i.putExtra("box_title",tr("অ্যাপ ওপেন ছবি / ভিডিও বিজ্ঞাপন","Startup Image / Video Advertisement"));
            startActivity(i); return;
        }
        if ("feed_moderation".equals(mode)) { startActivity(new Intent(this,FeedModerationActivity.class)); return; }
        if ("launch_settings661".equals(mode)) { startActivity(new Intent(this,LaunchSettings661Activity.class)); return; }
        if ("official669".equals(mode)) { startActivity(new Intent(this,OfficialMessageAdmin669.class)); return; }
        if ("system_health".equals(mode)) { startActivity(new Intent(this,AdminSystemHealthActivity.class)); return; }
        if ("coin_gold_catalog".equals(mode)) { startActivity(new Intent(this,CoinDiamondCatalogActivity.class)); return; }
        if ("user_history".equals(mode)) { startActivity(new Intent(this,UserHistoryAdminActivity.class)); return; }
        if ("wallet_badge".equals(mode) || "membership_admin".equals(mode)) { startActivity(new Intent(this,MembershipAdminActivity.class)); return; }
        if ("wallpaper_admin".equals(mode)) { startActivity(new Intent(this,WallpaperAdminActivity.class)); return; }
        if ("entry_ride".equals(mode)) { startActivity(new Intent(this,EntryRideAdminActivity.class)); return; }
        if ("admin_wallet".equals(mode)) { startActivity(new Intent(this,AdminWalletActivity.class)); return; }
        if ("live_home_page".equals(mode)) { startActivity(new Intent(this,LiveHomeAdminActivity.class).putExtra("admin_context",true)); return; }
        if ("page1_icons".equals(mode)) { startActivity(new Intent(this,PageIconAdminActivity.class).putExtra("page","home1").putExtra("admin_context",true)); return; }
        if ("page2_icons".equals(mode)) { startActivity(new Intent(this,PageIconAdminActivity.class).putExtra("page","live2").putExtra("admin_context",true)); return; }
        if ("live_themes".equals(mode)) { startActivity(new Intent(this,LiveThemeAdminActivity.class)); return; }
        if ("app_theme_admin".equals(mode)) { startActivity(new Intent(this,AppThemeAdminActivity.class)); return; }
        if ("content_translations".equals(mode)) { startActivity(new Intent(this,ContentTranslationsActivity.class)); return; }
        if ("highlight_settings".equals(mode)) { startActivity(new Intent(this,HighlightSettingsActivity.class)); return; }
        if ("live_comments".equals(mode)) { startActivity(new Intent(this,LiveCommentAdminActivity.class)); return; }
        if ("live_gifts".equals(mode)) { startActivity(new Intent(this,LiveGiftAdminActivity.class)); return; }
        if ("live_music".equals(mode)) { startActivity(new Intent(this,LiveMusicAdminActivity.class)); return; }
        if ("safety_reports".equals(mode)) { startActivity(new Intent(this,AdminSafetyActivity.class)); return; }
        Intent i = new Intent(this,AdminSectionActivity.class);
        i.putExtra("section", mode); i.putExtra("admin_context", true); startActivity(i);
    }

    private void logout() {
        String token = SessionManager.getToken(this);
        SessionManager.clear(this);
        Intent i = new Intent(this, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        if (token != null && !token.isEmpty()) BackendClient.logout(token,new BackendClient.Callback(){ public void onSuccess(JSONObject d){} public void onError(String m){} });
    }

    private void press(View v){ v.animate().scaleX(.99f).scaleY(.99f).setDuration(45).withEndAction(()->v.animate().scaleX(1f).scaleY(1f).setDuration(80).start()).start(); }
    private int brighten(int c){ return Color.rgb(Math.min(255,Color.red(c)+35),Math.min(255,Color.green(c)+35),Math.min(255,Color.blue(c)+35)); }
    private int light(int c){ return Color.rgb((Color.red(c)+255*4)/5,(Color.green(c)+255*4)/5,(Color.blue(c)+255*4)/5); }

    private TextView chip(String s,int color,int text){ TextView t=txt(s,10,text,true); t.setGravity(Gravity.CENTER); t.setBackground(round(WHITE,Color.rgb(217,223,239),14)); return t; }
    private LinearLayout card(){ LinearLayout c=col(); c.setPadding(dp(10),dp(10),dp(10),dp(10)); c.setBackground(round(WHITE,Color.rgb(223,227,241),18)); c.setElevation(dp(2)); return c; }
    private LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private LinearLayout col(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private TextView txt(String s,float z,int c,boolean bold){ TextView v=new TextView(this); v.setText(UiStrings.label(this,s)); v.setTextSize(z); v.setTextColor(c); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private GradientDrawable gradient(int[] colors,int r){ GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors); g.setCornerRadius(dp(r)); return g; }
    private GradientDrawable round(int fill,int stroke,int r){ GradientDrawable g=new GradientDrawable(); g.setColor(fill); g.setCornerRadius(dp(r)); if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke); return g; }
    private LinearLayout.LayoutParams lp(int w,int h){ return new LinearLayout.LayoutParams(w,h); }
    private LinearLayout.LayoutParams weight(float w){ return new LinearLayout.LayoutParams(0,-1,w); }
    private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int t){ p.topMargin=t; return p; }
    private LinearLayout.LayoutParams left(LinearLayout.LayoutParams p,int l){ p.leftMargin=l; return p; }
    private int dp(int n){ return Math.round(n*getResources().getDisplayMetrics().density); }

    private static final class Category {
        final String key,icon,title,desc; final int color;
        Category(String k,String i,String t,String d,int c){key=k;icon=i;title=t;desc=d;color=c;}
    }
    private static final class Module {
        final String category,icon,title,desc,mode; final int color;
        Module(String c,String i,String t,String d,String m,int x){category=c;icon=i;title=t;desc=d;mode=m;color=x;}
    }
}
