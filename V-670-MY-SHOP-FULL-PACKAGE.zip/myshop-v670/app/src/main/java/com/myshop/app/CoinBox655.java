package com.myshop.app;
import android.content.Context;import android.graphics.*;import android.view.View;
/** Coin claim artwork, distinct from room-wide Lucky flower gifts. */
final class CoinBox655 extends View {
 private final Paint p=new Paint(3);private final long amount;
 CoinBox655(Context c,long value){super(c);amount=value;setContentDescription("কয়েন গিফট বক্স • "+value+" কয়েন • খুলতে চাপুন");}
 protected void onDraw(Canvas canvas){super.onDraw(canvas);float w=getWidth(),h=getHeight(),x=w*.12f,y=h*.28f,bw=w*.76f,bh=h*.43f;p.setShader(new LinearGradient(x,y,x+bw,y+bh,new int[]{0xff933bfa,0xff4c24b4},null,Shader.TileMode.CLAMP));canvas.drawRoundRect(x,y,x+bw,y+bh,10,10,p);p.setShader(null);p.setColor(0xffffcd42);canvas.drawRect(w*.45f,y,w*.55f,y+bh,p);canvas.drawRoundRect(x-w*.025f,y-h*.07f,x+bw+w*.025f,y+h*.025f,6,6,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(3,w*.04f));canvas.drawOval(w*.23f,h*.08f,w*.5f,h*.23f,p);canvas.drawOval(w*.5f,h*.08f,w*.77f,h*.23f,p);p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setColor(0xffffeeb0);p.setTextSize(Math.min(14*getResources().getDisplayMetrics().scaledDensity,w*.15f));canvas.drawText("🪙 "+amount,w/2,h*.91f,p);}
}
