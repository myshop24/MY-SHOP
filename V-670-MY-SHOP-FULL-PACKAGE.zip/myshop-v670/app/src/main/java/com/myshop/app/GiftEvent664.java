package com.myshop.app;
import org.json.JSONArray;
import org.json.JSONObject;

/** Normalize an immutable send receipt for the same presentation path used by viewers. */
final class GiftEvent664 {
 static JSONObject receipt(JSONObject gift,JSONObject receipt,String sender,String name,String avatar,int level,String host){
  JSONObject event=new JSONObject();
  try{
   event=new JSONObject(gift.toString());
   int quantity=Math.max(1,receipt.optInt("quantity",1));
   String receiver=receipt.optString("receiverId",host),receiverName="";
   JSONArray names=receipt.optJSONArray("receiverNames");
   if(names!=null)for(int i=0;i<names.length();i++){
    JSONObject item=names.optJSONObject(i);
    if(item!=null&&receiver.equals(item.optString("userId")))receiverName=item.optString("name","").trim();
   }
   if(receiverName.isEmpty())receiverName=receipt.optString("receiverName","").trim();
   if(receiverName.isEmpty())receiverName="ID "+receiver;
   event.put("giftId",gift.optLong("id")).put("id",receipt.optLong("eventId"))
    .put("eventId",receipt.optLong("eventId")).put("quantity",quantity)
    .put("price",Math.max(1,gift.optLong("price",1))*quantity)
    .put("comboId",receipt.optString("comboId","")).put("comboTotal",receipt.optInt("comboTotal",quantity))
    .put("combo",receipt.optInt("combo",1)).put("receiver_id",receiver).put("receiverId",receiver)
    .put("receiver_name",receiverName).put("receiverName",receiverName)
    .put("sender_id",sender).put("sender_name",receipt.optString("senderName",name))
    .put("sender_avatar",receipt.optString("senderAvatar",avatar)).put("sender_level",receipt.optInt("senderLevel",level));
   if(names!=null)event.put("receiverNames",names);
  }catch(Exception invalid){android.util.Log.w("MYSHOP_GIFT","Receipt presentation fields unavailable",invalid);}
  return event;
 }
}
