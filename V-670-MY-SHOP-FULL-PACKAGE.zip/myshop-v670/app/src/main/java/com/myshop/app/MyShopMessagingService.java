package com.myshop.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;

/** V-328: heads-up message notification with direct Chat deep-link; uses the existing FCM backend contract. */
public class MyShopMessagingService extends FirebaseMessagingService {
    private static final java.util.concurrent.ConcurrentHashMap<String,Long> LATEST=new java.util.concurrent.ConcurrentHashMap<>();
    private static final java.util.concurrent.ExecutorService AVATAR_POOL=Executors.newSingleThreadExecutor();
    public static final String MESSAGE_CHANNEL="myshop_messages_v2",LIVE_CHANNEL="myshop_live_alerts_v1",GENERAL_CHANNEL="myshop_general";
    private static final String NO_BADGE_GENERAL="myshop_general_no_badge_v590",NO_BADGE_LIVE="myshop_live_no_badge_v590",NO_BADGE_MESSAGE="myshop_messages_no_badge_v590",FRIEND_BADGE="myshop_friend_badge_v590";
    @Override public void onNewToken(String token){super.onNewToken(token);PushRegistration.sync(this);}
    @Override public void onMessageReceived(RemoteMessage remote){super.onMessageReceived(remote);getSharedPreferences("myshop_push_v349",MODE_PRIVATE).edit().putString("last_received_at",new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",java.util.Locale.US).format(new java.util.Date())).apply();Map<String,String>d=remote.getData();String type=s(d.get("type")),actor=s(d.get("actorUserId")),title=s(d.get("title")),body=s(d.get("body")),avatar=s(d.get("actorAvatarUrl"));if(title.isEmpty()&&remote.getNotification()!=null)title=s(remote.getNotification().getTitle());if(body.isEmpty()&&remote.getNotification()!=null)body=s(remote.getNotification().getBody());if(title.isEmpty())title="myshop";String recipient=s(d.get("recipientUserId"));if(!recipient.isEmpty()&&!recipient.equals(SessionManager.getUserId(this)))return;show(type,actor,title,body,avatar,s(d.get("targetId")),"1".equals(d.get("badgeEligible"))?s(d.get("badgeEventId")):"");}
    private void show(String type,String actor,String title,String body,String avatarUrl,String target,String eventId){
        if(SessionManager.getToken(this)==null||SessionManager.getToken(this).isEmpty())return;
        if("MESSAGE".equals(type)&&AccountPreferences.get(MyShopMessagingService.this,"message_mutes").getBoolean(actor,false))return;NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(nm==null)return;ensureChannels(nm);
        boolean live=type!=null&&type.startsWith("LIVE_");if(!AccountPreferences.get(this,"notification_options").getBoolean("MESSAGE".equals(type)?"messages":live?"live":"promo",true)&&!"TEST_PUSH".equals(type))return;
        Intent i;if("SAFETY_REPORT".equals(type)&&SessionManager.isAdmin(this)){i=new Intent(this,AdminSafetyActivity.class);i.putExtra("reportId",target);}else if("MESSAGE".equals(type)&&!actor.isEmpty()){i=new Intent(this,ChatActivity.class);i.putExtra("userId",actor);i.putExtra("name",title);}else if(live&&!actor.isEmpty()){i=new Intent(this,AudioLiveRoomActivity.class);i.putExtra("hostId",target.isEmpty()?actor:target);i.putExtra("fromNotification",true);}else{i=new Intent(this,MainActivity.class);}i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);
        int request=Math.abs((type+"|"+actor).hashCode());PendingIntent pi=PendingIntent.getActivity(this,request,i,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));String channel=eventId.matches("[1-9][0-9]*")?("MESSAGE".equals(type)?MESSAGE_CHANNEL:("FRIEND_REQUEST".equals(type)||"SAFETY_REPORT".equals(type)?FRIEND_BADGE:LIVE_CHANNEL)):("MESSAGE".equals(type)?MESSAGE_CHANNEL:("LIVE_START".equals(type)?LIVE_CHANNEL:("FRIEND_REQUEST".equals(type)?GENERAL_CHANNEL:(live?NO_BADGE_LIVE:NO_BADGE_GENERAL))));
        NotificationCompat.Builder b=new NotificationCompat.Builder(this,channel).setSmallIcon(R.drawable.ic_myshop_notification).setContentTitle(title).setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body)).setAutoCancel(true).setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL).setContentIntent(pi).setPriority(NotificationCompat.PRIORITY_HIGH).setCategory("MESSAGE".equals(type)?NotificationCompat.CATEGORY_MESSAGE:(live?NotificationCompat.CATEGORY_EVENT:NotificationCompat.CATEGORY_SOCIAL)).setGroup("MESSAGE".equals(type)?"myshop_message_group":(live?"myshop_live_group":"myshop_general_group")).setLargeIcon(BitmapFactory.decodeResource(getResources(),R.drawable.myshop_profile_avatar)).setNumber(eventId.matches("[1-9][0-9]*")||"MESSAGE".equals(type)||"FRIEND_REQUEST".equals(type)||"LIVE_START".equals(type)?1:0).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setOnlyAlertOnce(false).setDefaults(NotificationCompat.DEFAULT_SOUND|NotificationCompat.DEFAULT_VIBRATE);
        final String tag=eventId.matches("[1-9][0-9]*")?"myshop_event_"+SessionManager.getUserId(this)+"_"+eventId:null;
        int id=tag!=null?0:("MESSAGE".equals(type)&&!actor.isEmpty()?100000+Math.abs(actor.hashCode()%800000):900000+Math.abs((type+body).hashCode()%90000));
        final String tracking=tag!=null?tag:String.valueOf(id);final long ticket=System.nanoTime();
        if(tag!=null){for(android.service.notification.StatusBarNotification active:nm.getActiveNotifications())if(tag.equals(active.getTag()))return;}
        synchronized(LATEST){LATEST.put(tracking,ticket);try{nm.notify(tag,id,b.build());}catch(SecurityException denied){LATEST.remove(tracking);return;}}
        if(avatarUrl!=null&&!avatarUrl.trim().isEmpty()){
            AVATAR_POOL.execute(()->{Bitmap avatar=loadAvatar(avatarUrl);if(avatar!=null){synchronized(LATEST){if(Long.valueOf(ticket).equals(LATEST.get(tracking))){b.setLargeIcon(avatar).setOnlyAlertOnce(true);try{nm.notify(tag,id,b.build());}catch(SecurityException ignored){}}}}});
        }
    }
    private Bitmap loadAvatar(String raw){HttpURLConnection c=null;try{URL u=new URL(raw);if(!"https".equalsIgnoreCase(u.getProtocol()))return null;c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(2500);c.setReadTimeout(2500);c.setInstanceFollowRedirects(true);return BitmapFactory.decodeStream(c.getInputStream());}catch(Exception ignored){return null;}finally{if(c!=null)c.disconnect();}}
    static void clearTickets629(){synchronized(LATEST){LATEST.clear();}}
    static void cancelTracked629(NotificationManager nm,String tag,int id){synchronized(LATEST){LATEST.remove(tag);nm.cancel(tag,id);}}
    public static void ensureChannels(NotificationManager nm){if(Build.VERSION.SDK_INT<26)return;NotificationChannel m=new NotificationChannel(MESSAGE_CHANNEL,"myshop Messages",NotificationManager.IMPORTANCE_HIGH);m.setDescription("New myshop chat messages");m.enableVibration(true);m.enableLights(true);m.setLightColor(Color.rgb(92,67,219));m.setShowBadge(true);m.setLockscreenVisibility(android.app.Notification.VISIBILITY_PRIVATE);NotificationChannel l=new NotificationChannel(LIVE_CHANNEL,"myshop Live Alerts",NotificationManager.IMPORTANCE_HIGH);l.setDescription("Heads-up alert when a myshop user starts a live room");l.enableVibration(true);l.enableLights(true);l.setShowBadge(true);l.setLockscreenVisibility(android.app.Notification.VISIBILITY_PRIVATE);NotificationChannel g=new NotificationChannel(GENERAL_CHANNEL,"myshop Notifications",NotificationManager.IMPORTANCE_DEFAULT);g.setDescription("myshop updates");g.setShowBadge(true);nm.createNotificationChannel(m);nm.createNotificationChannel(l);nm.createNotificationChannel(g);copyChannel(nm,MESSAGE_CHANNEL,NO_BADGE_MESSAGE,"myshop Messages (without icon count)",false);copyChannel(nm,LIVE_CHANNEL,NO_BADGE_LIVE,"myshop Live notifications (without icon count)",false);copyChannel(nm,GENERAL_CHANNEL,NO_BADGE_GENERAL,"myshop Updates (without icon count)",false);copyChannel(nm,GENERAL_CHANNEL,FRIEND_BADGE,"myshop Friend requests",true);}
    private static void copyChannel(NotificationManager nm,String sourceId,String id,String title,boolean badge){
        if(Build.VERSION.SDK_INT<26||nm.getNotificationChannel(id)!=null)return;
        NotificationChannel source=nm.getNotificationChannel(sourceId);if(source==null)return;
        NotificationChannel channel=new NotificationChannel(id,title,source.getImportance());channel.setSound(source.getSound(),source.getAudioAttributes());channel.enableVibration(source.shouldVibrate());channel.setVibrationPattern(source.getVibrationPattern());channel.enableLights(source.shouldShowLights());channel.setLightColor(source.getLightColor());channel.setLockscreenVisibility(source.getLockscreenVisibility());channel.setShowBadge(badge);if(source.getGroup()!=null)channel.setGroup(source.getGroup());nm.createNotificationChannel(channel);
    }
    /** Clear displayed push on app entry; never mark the server inbox read or cancel RTC service notifications. */
    public static void clearDisplayedPush(android.content.Context context){
        NotificationManager nm=(NotificationManager)context.getSystemService(NOTIFICATION_SERVICE);if(nm==null)return;
        try{synchronized(LATEST){for(android.service.notification.StatusBarNotification item:nm.getActiveNotifications()){
            String tag=item.getTag(),channel=Build.VERSION.SDK_INT>=26?item.getNotification().getChannelId():"";
            boolean ownedEvent=tag!=null&&tag.startsWith("myshop_event_");
            boolean pushChannel=MESSAGE_CHANNEL.equals(channel)||LIVE_CHANNEL.equals(channel)||GENERAL_CHANNEL.equals(channel)||NO_BADGE_GENERAL.equals(channel)||NO_BADGE_LIVE.equals(channel)||NO_BADGE_MESSAGE.equals(channel)||FRIEND_BADGE.equals(channel);
            boolean legacy=Build.VERSION.SDK_INT<26&&item.getId()>=100000&&item.getId()<990000;
            if((ownedEvent||pushChannel||legacy)&&(item.getNotification().flags&android.app.Notification.FLAG_FOREGROUND_SERVICE)==0){LATEST.remove(ownedEvent?tag:String.valueOf(item.getId()));nm.cancel(tag,item.getId());}
        }}}catch(RuntimeException ignored){}
    }
    private static String s(String x){return x==null?"":x;}
}
