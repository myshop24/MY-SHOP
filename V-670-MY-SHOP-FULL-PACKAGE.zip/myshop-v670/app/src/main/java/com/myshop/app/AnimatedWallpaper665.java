package com.myshop.app;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.MediaPlayer;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import org.json.JSONObject;

/** One muted decoder per visible room/demo. Explicit demos are independent of the room preference. */
public final class AnimatedWallpaper665 extends FrameLayout implements TextureView.SurfaceTextureListener {
    private final ImageView poster;
    private final TextureView texture;
    private final TextView retry667;
    private final String url,fit;
    private final boolean explicitPreview667;
    private MediaPlayer player;
    private Surface surface;
    private boolean attached,prepared,active665=true,failed667;
    private int videoWidth,videoHeight;
    public void setActive665(boolean active){active665=active;if(!active)release();else start();}
    public static String media667(JSONObject item){String s=item.optString("animation_url","").trim();return s.isEmpty()?item.optString("background_url","").trim():s;}
    public static boolean video(String url){return url!=null&&url.matches("(?i).*\\.(mp4|webm|m4v)([?#].*)?$");}
    public static boolean video667(JSONObject item){return video(media667(item))||item.optString("animation_mime","").toLowerCase(java.util.Locale.ROOT).startsWith("video/");}
    public static String poster667(JSONObject item){String s=item.optString("preview_url","").trim();String media=media667(item);if(!s.isEmpty()&&!s.equals(media)&&!video(s))return s;if(media.startsWith("asset://wallpapers665/")&&video(media))return media.replaceFirst("(?i)\\.(mp4|webm|m4v)([?#].*)?$",".jpg");return "";}
    public static boolean enabled(Context c){android.app.ActivityManager am=(android.app.ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE);return c.getSharedPreferences("live665",0).getBoolean("animatedWallpaper",am==null||!am.isLowRamDevice());}
    public AnimatedWallpaper665(Context c,JSONObject item){this(c,item,false);}
    public AnimatedWallpaper665(Context c,JSONObject item,boolean explicitPreview){super(c);url=media667(item);fit=item.optString("fit_mode","CENTER_CROP");explicitPreview667=explicitPreview;
        poster=new ImageView(c);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);poster.setImageResource(R.drawable.live_room_default_wallpaper);addView(poster,new LayoutParams(-1,-1));String preview=poster667(item);if(!preview.isEmpty())AnimatedAssetLoader.load(poster,preview,false);
        texture=new TextureView(c);texture.setOpaque(false);texture.setSurfaceTextureListener(this);addView(texture,new LayoutParams(-1,-1));
        retry667=new TextView(c);retry667.setText("Wallpaper লোড হয়নি • Retry");retry667.setTextColor(android.graphics.Color.WHITE);retry667.setTextSize(12);retry667.setGravity(android.view.Gravity.CENTER);retry667.setBackgroundColor(0xb3182340);retry667.setVisibility(GONE);addView(retry667,new LayoutParams(-1,(int)(48*c.getResources().getDisplayMetrics().density),android.view.Gravity.BOTTOM));retry667.setOnClickListener(v->{failed667=false;retry667.setVisibility(GONE);release();start();});setContentDescription("Muted animated live wallpaper");
    }
    private void start(){if(!attached||!active665||failed667||getWindowVisibility()!=VISIBLE||!texture.isAvailable()||player!=null||(!explicitPreview667&&!enabled(getContext())))return;try{
        MediaPlayer next=new MediaPlayer();player=next;surface=new Surface(texture.getSurfaceTexture());next.setSurface(surface);next.setVolume(0,0);next.setLooping(true);
        next.setOnPreparedListener(mp->{if(mp!=player)return;prepared=true;videoWidth=mp.getVideoWidth();videoHeight=mp.getVideoHeight();transform();if(attached&&active665&&getWindowVisibility()==VISIBLE)mp.start();});
        next.setOnInfoListener((mp,what,extra)->{if(mp==player&&what==MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START){poster.setVisibility(GONE);retry667.setVisibility(GONE);}return false;});
        next.setOnErrorListener((mp,what,extra)->{if(mp==player)fail667();return true;});
        if(url.startsWith("asset://")){try(android.content.res.AssetFileDescriptor fd=getContext().getAssets().openFd(url.substring(8))){next.setDataSource(fd.getFileDescriptor(),fd.getStartOffset(),fd.getLength());}}
        else if(url.startsWith("https://"))next.setDataSource(url);else throw new java.io.IOException("Unsupported wallpaper URL");next.prepareAsync();
    }catch(Exception error){fail667();}}
    private void fail667(){release();failed667=true;if(retry667!=null)retry667.setVisibility(VISIBLE);android.util.Log.w("MYSHOP_THEME","Wallpaper failed; poster retained, explicit retry available");}
    private void transform(){int w=texture.getWidth(),h=texture.getHeight();if(w<=0||h<=0||videoWidth<=0||videoHeight<=0)return;float sx=1,sy=1;if(!"FILL".equalsIgnoreCase(fit)){float scale="FIT".equalsIgnoreCase(fit)?Math.min(w/(float)videoWidth,h/(float)videoHeight):Math.max(w/(float)videoWidth,h/(float)videoHeight);sx=scale*videoWidth/w;sy=scale*videoHeight/h;}Matrix m=new Matrix();m.setScale(sx,sy,w/2f,h/2f);texture.setTransform(m);}
    private void release(){prepared=false;if(player!=null){MediaPlayer old=player;player=null;old.setOnPreparedListener(null);old.setOnErrorListener(null);old.setOnInfoListener(null);try{old.release();}catch(Exception ignored){}}if(surface!=null){surface.release();surface=null;}if(poster!=null)poster.setVisibility(VISIBLE);}
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();attached=true;start();}
    @Override protected void onDetachedFromWindow(){attached=false;release();super.onDetachedFromWindow();}
    @Override protected void onWindowVisibilityChanged(int visibility){super.onWindowVisibilityChanged(visibility);if(visibility!=VISIBLE){release();return;}if(texture!=null)start();}
    @Override public void onSurfaceTextureAvailable(SurfaceTexture s,int w,int h){start();}
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture s,int w,int h){transform();}
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture s){release();return true;}
    @Override public void onSurfaceTextureUpdated(SurfaceTexture s){}
}
