package com.myshop.app;

import android.content.Context;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.ScrollView;

/** Horizontal visibility gesture only; preserves the existing vertical scroll bounds. */
final class LiveCommentSwipe651 extends ScrollView {
    private float startX,startY;
    private boolean horizontal;
    private boolean enabled=true;
    void enabled651(boolean value){enabled=value;if(!value)horizontal=false;}
    private final int slop;
    private Runnable toggle;
    LiveCommentSwipe651(Context context){super(context);slop=ViewConfiguration.get(context).getScaledTouchSlop();}
    void onToggle(Runnable value){toggle=value;}
    @Override public boolean onInterceptTouchEvent(MotionEvent e){
        if(!enabled)return super.onInterceptTouchEvent(e);
        if(e.getActionMasked()==MotionEvent.ACTION_DOWN){startX=e.getX();startY=e.getY();horizontal=false;}
        if(e.getActionMasked()==MotionEvent.ACTION_MOVE){float dx=Math.abs(e.getX()-startX),dy=Math.abs(e.getY()-startY);if(dx>slop*3&&dx>dy*2){horizontal=true;return true;}}
        return super.onInterceptTouchEvent(e);
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        if(!enabled)return super.onTouchEvent(e);
        if(e.getActionMasked()==MotionEvent.ACTION_DOWN){startX=e.getX();startY=e.getY();horizontal=false;}
        if(e.getActionMasked()==MotionEvent.ACTION_MOVE){float dx=Math.abs(e.getX()-startX),dy=Math.abs(e.getY()-startY);if(dx>slop*3&&dx>dy*2)horizontal=true;}
        if(horizontal){if(e.getActionMasked()==MotionEvent.ACTION_UP){horizontal=false;if(toggle!=null)toggle.run();}else if(e.getActionMasked()==MotionEvent.ACTION_CANCEL)horizontal=false;return true;}
        return super.onTouchEvent(e);
    }
}
