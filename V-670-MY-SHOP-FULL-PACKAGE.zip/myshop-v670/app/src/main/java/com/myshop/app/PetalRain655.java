package com.myshop.app;
import android.content.Context;import android.graphics.*;import android.view.*;import android.animation.*;
/** Bounded native particles; no videos/bitmaps decoded per frame. */
final class PetalRain655 extends View {
 private final Paint p=new Paint(3);private final boolean coins;private final float[] x=new float[32],offset=new float[32],speed=new float[32];private ValueAnimator anim;private float time;
 PetalRain655(Context c,boolean coin){super(c);coins=coin;setClickable(false);java.util.Random rng=new java.util.Random();for(int i=0;i<32;i++){x[i]=rng.nextFloat();offset[i]=rng.nextFloat();speed[i]=.7f+rng.nextFloat()*.6f;}}
 void play(long duration,Runnable end){anim=ValueAnimator.ofFloat(0,1);anim.setDuration(duration);anim.addUpdateListener(v->{time=(Float)v.getAnimatedValue();invalidate();});anim.addListener(new AnimatorListenerAdapter(){public void onAnimationEnd(Animator a){end.run();}});anim.start();}
 protected void onDraw(Canvas c){super.onDraw(c);float d=getResources().getDisplayMetrics().density;for(int i=0;i<32;i++){float y=((time*2*speed[i]+offset[i])%1)*getHeight(),cx=(x[i]+.025f*(float)Math.sin(time*12+i))*getWidth();p.setColor(coins?0xffffcb42:i%3==0?0xffffd5e6:0xfff55b9e);p.setAlpha((int)(220*Math.min(1,(1-time)*6)));c.save();c.rotate(time*200+i*29,cx,y);if(coins){c.drawCircle(cx,y,8*d,p);p.setColor(0xffc48a15);p.setTextSize(10*d);p.setTextAlign(Paint.Align.CENTER);c.drawText("₵",cx,y+3*d,p);}else c.drawOval(cx-4*d,y-8*d,cx+4*d,y+8*d,p);c.restore();}}
 protected void onDetachedFromWindow(){if(anim!=null){anim.removeAllListeners();anim.cancel();}super.onDetachedFromWindow();}
}
