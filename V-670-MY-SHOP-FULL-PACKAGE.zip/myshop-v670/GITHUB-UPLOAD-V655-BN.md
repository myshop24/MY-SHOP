# V-655 — পূর্ণ সোর্স থেকে নতুন APK

এই সোর্স প্যাকেজে তৈরি APK নেই। এই পরিবেশে Android SDK, original signing key অনুপস্থিত এবং Gradle download network blocked। APK/GitHub/phone acceptance দাবি করা হয়নি।

## স্থায়ী GitHub workflow
বর্তমান repository ও original signing identity রাখুন। `V-655-MY-SHOP-FULL-SOURCE.zip` নাম না বদলে আগের permanent ZIP-selection pipeline-এর repository root-এ দিন। অন্যথায় ZIP খুলে `.github`-সহ সব project file repository root-এ দিন। একাধিক একই সর্বশেষ V655 source দেবেন না।
Actions → MY SHOP Android APK → Run workflow। এই workflow JDK17, Node22, Python3.12, SDK/build-tools36 এবং asset dependencies প্রস্তুত করে। Original key + Firebase Secrets সেট থাকতে হবে। Build successful হলেই নয়: intended commit SHA, V655/2.9.655/versionCode654, original certificate, artifact timestamp/hash এবং V655 DEX marker মিলবে।
Artifacts → MY-SHOP-V-655-APK → একটি `MY_SHOP_FINAL_RELEASE.apk`। নতুন APK ওই exact run-এর। পুরোনো APK নতুন নাম দিয়ে দেওয়া যাবে না।

## Secrets (আসল মান source-এ নয়)
MYSHOP_KEYSTORE_BASE64 অথবা বিদ্যমান original key restore; MYSHOP_KEYSTORE_PASSWORD, MYSHOP_KEY_ALIAS, MYSHOP_KEY_PASSWORD। Firebase: MYSHOP_FIREBASE_API_KEY, MYSHOP_FIREBASE_APP_ID, MYSHOP_FIREBASE_PROJECT_ID, MYSHOP_FIREBASE_SENDER_ID অথবা existing matching google-services.json। Package com.myshop.app ও certificate অপরিবর্তিত।

## Backend
Original D1/R2/Agora/Firebase bindings অক্ষত। আগে0065-সহ আগের migrations; নতুন0066_v655_cricket.sql additive। নতুন APK-এর Cricket/কার্ড Publish-এর জন্য একই backend code প্রয়োজন। Build workflow Worker deploy করে না। Production deploy/migration আলাদা reviewed operation; এই কাজের সময় করা হয়নি।

## Developer continuation
MY-SHOP-DEVELOPER-HANDOFF.md, CURRENT-WORK-CHECKPOINT.md, V655-APPROVED-WORK-BN.md এবং MY-SHOP-CRICKET-SYSTEM-INSTRUCTIONS.md পড়ুন। Runtime assets পুনর্নির্মাণ: bash tools/prepare-build-assets.sh। Source gates: bash tools/v655_target_verify.sh। Android: bash gradlew clean :app:testDebugUnitTest :app:assembleRelease :app:lintRelease -PmyshopOfflineTests -PrequirePush --no-daemon --no-build-cache --rerun-tasks।

## V655 অতিরিক্ত সেটআপ
CI APK ARM64 ফোনের জন্য;32-bit ফোনে `-PmyshopAbi=armeabi-v7a` দিয়ে আলাদা build করুন। Source/ZIP সাইজ APK নয়। FLAC runtime generation preBuild-এ স্বয়ংক্রিয়; অরিজিনাল WAV source/manifest বদলাবেন না। Matching Worker এবং0067_v655_lucky.sql প্রয়োজন; deployment এখানে হয়নি।
