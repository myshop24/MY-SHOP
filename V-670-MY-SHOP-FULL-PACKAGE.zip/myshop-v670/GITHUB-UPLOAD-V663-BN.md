# V-663 GitHub বিল্ড

V-663-MY-SHOP-FULL-SOURCE.zip ফাইলটি আগের স্থায়ী release pipeline অনুযায়ী অপরিবর্তিতভাবে আপলোড করুন। ভিতরের ফোল্ডারের ঐতিহাসিক নাম myshop-v661 হলেও SOURCE_BUILD_ID, Android versionCode/versionName ও Worker build সব V-663। পুরোনো সোর্স ব্যবহার করা হচ্ছে না।

সতর্কতা: এই pipeline আগে Worker deploy করে, তারপর APK build/sign করে। আপলোড মানেই production backend বদলাতে পারে। এই প্যাকেজ তৈরির সময় কোনো push/deploy করা হয়নি।

Run723-এর মূল পুরোনো version-normalization test এবং ভুল V661 source/APK gate সংশোধন করা হয়েছে। পরীক্ষা বাদ দেওয়া হয়নি। সব preBuild Exec পরীক্ষা চালাতে: python3 tools/v663_prebuild_verify.py

পুরোনো signing key ও protected Cloudflare/Firebase/Agora setup অক্ষত রাখুন। গোপন key source-এ দেবেন না। dependencies ও assets: BUILD-ASSETS-BN.md; বিস্তারিত কাজ/পরীক্ষা/বাকি গ্রহণযোগ্যতা: V663-HANDOFF.md।

Build শেষে APK version 663/2.9.663, original signature, implementation markers, APK size ও ফোনে লাইভ পরীক্ষা মিলিয়ে দেখুন। শুধু Build successful দিয়ে শেষ করবেন না। এই ZIP-এ APK নেই; এখানে Gradle download network blocked হওয়ায় পূর্ণ Android build করা যায়নি।
