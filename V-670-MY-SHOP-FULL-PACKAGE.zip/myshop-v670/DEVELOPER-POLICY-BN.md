# 🔴 MY SHOP — Developer Rules & Project Delivery Policy

স্থায়ী ডেভেলপমেন্ট, বিল্ড, ভার্সন ও ফাইল ডেলিভারি নীতিমালা। সর্বশেষ একত্রীকরণ: ২০২৬-১০-০৯।

ব্যবহারকারীর সর্বশেষ অনুমোদিত সিদ্ধান্ত প্রাধান্য পাবে। নিচের ১০টি নিয়ম সকল ভবিষ্যৎ কাজের জন্য বাধ্যতামূলক। একই সাধারণ নিয়ম একবারই রাখা হয়েছে; আলাদা ফিচারের অনুমোদিত নির্দেশনা সংশ্লিষ্ট scope/handoff নথিতে থাকবে। কোনো নথিতে নিয়ম লেখা থাকা তার বাস্তবায়ন সম্পন্ন হওয়ার প্রমাণ নয়।

### V652 স্থায়ী Live সীমা — মালিকের সর্বশেষ নির্দেশ

সিটের সাদা চেয়ার ও বেগুনি বৃত্তের মূল ডিজাইন কখনো বদলানো যাবে না। অনুমোদিত লেআউট ও দৃশ্যমান সিটসংখ্যা বদলাবে; চেয়ার ডিজাইন বদলাবে না। কমেন্টের উচ্চতা/প্রবাহ, Rocket ও Join animation আগের লজিকেই থাকবে। Gift rail icon ১৫% বড় ও নতুন রঙের হতে পারে; গিফটের ভেতরের লজিক, মূল্য, লেনদেন, মিডিয়া ও সাউন্ড অক্ষত। গেস্ট কলে ঢুকলে ক্যামেরা বন্ধ; Host কেবল চালুর অনুরোধ করবেন, গেস্টের স্পষ্ট সম্মতি ও প্রয়োজনীয় OS অনুমতি ছাড়া চালু হবে না।

## ১. রেফারেন্স অনুযায়ী নির্ভুল বাস্তবায়ন

দেওয়া ছবি, ভিডিও, ডিজাইন রেফারেন্স, কথোপকথন ও সর্বশেষ অনুমোদিত সিদ্ধান্ত একসঙ্গে মিলিয়ে কাজ করতে হবে। কাজের সময় রেফারেন্স দেখতে হবে। অনুমোদিত রং, আইকন, অবস্থান, সাইজ, অনুপাত, লেখা ও আচরণ নিজের ইচ্ছায় পরিবর্তন করা যাবে না। ছোট মোবাইল স্ক্রিনে clipping, overlap, অতিরিক্ত gap ও অস্পষ্ট লেখা পরীক্ষা করতে হবে। লক্ষ্য ১০০% নির্দেশনা অনুযায়ী বাস্তবায়ন; প্রকৃত যাচাই ছাড়া ১০০% দাবি করা যাবে না। অনুপস্থিত রেফারেন্সের বিষয় অনুমান করে তৈরি করা যাবে না।

## ২. বিল্ড ব্যর্থতা প্রতিরোধ ও প্রকৃত যাচাই

পূর্ববর্তী ব্যর্থতার লগ পড়ে নির্দিষ্ট কারণ ঠিক করতে হবে। Gradle, SDK, dependencies, Manifest, Java/Kotlin, প্রযোজ্য Flutter, resource/import, path, permission, signing এবং GitHub Actions পরীক্ষা করতে হবে। GitHub Pages success Android APK build নয়। GitHub-এ সবুজ Success-ও একা যথেষ্ট নয়: intended commit SHA, clean checkout, SOURCE_BUILD_ID, artifact timestamp/hash, APK package/version এবং আগের signing certificate মিলতে হবে। stale cache বা আগের APK গ্রহণযোগ্য নয়। ব্যর্থ হলে কারণ সংশোধন করে পুনরায় সংশ্লিষ্ট বিল্ড/পরীক্ষা চালাতে হবে। fixture/static পরীক্ষা, সম্পূর্ণ Android compilation এবং phone/RTC/payment/push পরীক্ষা আলাদাভাবে রিপোর্ট করতে হবে।

## ৩. থেমে গেলে সর্বশেষ চেকপয়েন্ট থেকে শুরু

চ্যাট/সেশন/সংযোগ বন্ধ হলে প্রথম থেকে কাজ করা যাবে না। সর্বশেষ সম্পন্ন, চলমান ও বাকি কাজ, অনুমোদন, পরীক্ষা, সমস্যা এবং ব্যবহৃত সোর্সের পরিচয় সংরক্ষণ করতে হবে। পরবর্তী সেশনে সর্বশেষ সংরক্ষিত সোর্স ও Developer Handoff দেখে কাজ চালাতে হবে। একই কাজ অকারণে পুনরাবৃত্তি করা যাবে না।

## ৪. শুরুর সামারি, অগ্রগতি ও বিস্তারিত হ্যান্ডঅফ

শুরুতে নির্দেশনার সংক্ষিপ্ত সামারি, মোট কাজ, করণীয় ও যাচাই জানাতে হবে। প্রতিটি প্রজেক্ট ZIP-এ `MY-SHOP-DEVELOPER-HANDOFF.md` থাকবে: ভার্সন, সম্পন্ন কাজ, সংশোধিত সমস্যা, সুরক্ষিত ফিচার, বিল্ড/টেস্টের প্রকৃত ফল, অসম্পূর্ণ কাজ/পরিচিত সমস্যা, সর্বশেষ চেকপয়েন্ট এবং পরবর্তী করণীয়। ব্যবহারকারী যদি কোনো নির্দিষ্ট তালিকা শুধু চ্যাটে চান, সেই তালিকার আলাদা ফাইল তৈরি করা যাবে না; হ্যান্ডঅফে কাজের সত্যিকারের অবস্থা ও continuation তথ্য বজায় থাকবে।

## ৫. ধারাবাহিক ভার্সন ও একই বিল্ড পরিচয়

শেষ আসলে দেওয়া ভার্সন যাচাই করে পরের ডেলিভারিতে পরবর্তী নম্বর দিতে হবে: V-591 → V-592 → V-593। নতুন ফিচার, correction, bug fix ও পুনরায় তৈরি প্রজেক্ট ZIP সব ক্ষেত্রেই নতুন নম্বর; পুরোনো ডেলিভারি overwrite বা V-number reuse নয়। একই ফাইলের নামের বানান সংশোধন নতুন সফটওয়্যার বিল্ড হওয়ার দাবি নয়। SOURCE_BUILD_ID, Android versionCode/versionName, Worker পরিচয় এবং ZIP/APK পরিচয় মিলতে হবে। APK নাম বদলানো বা ZIP থেকে ভার্সন জোর করে লেখা নতুন বিল্ডের বিকল্প নয়। ফাইলের নাম, ভার্সন ও মাপা সাইজ জানাতে হবে। GitHub workflow-এর filename filter ও source selector-এর সঙ্গে নাম পরীক্ষা করতে হবে; বর্তমান repository-র জন্য `V-<number>-MY-SHOP-FULL-SOURCE.zip` উপযুক্ত।

## ৬. পূর্বের ভালো কাজ ও ডেটা সুরক্ষা

একটি কাজ করতে গিয়ে অন্য ভালো কাজ নষ্ট করা যাবে না। অপ্রভাবিত অনুমোদিত module locked; সবচেয়ে ছোট সংশ্লিষ্ট পরিবর্তন করতে হবে। shared API/helper/schema বদলালে নির্ভরশীল ফিচার যাচাই করতে হবে। target পরীক্ষা এবং উপযুক্ত regression পরীক্ষা পাস ছাড়া পরিবর্তন সম্পন্ন নয়। বাইরে material ত্রুটি পেলে জানাতে হবে; নিরাপদ ও প্রয়োজনীয় সংশোধন করা যাবে, নতুবা নথিভুক্ত করে স্বাধীন নিরাপদ কাজ এগোবে। ডেটা, পুরোনো ID, financial ledger, Cloudflare D1/R2 binding, package ও signing identity অক্ষত রাখতে হবে। critical action-এ server permission, validation, confirmation, reason/audit; financial কাজ atomic/idempotent। পুরোনো request-এর শর্ত/হিস্ট্রি চুপচাপ বদলানো যাবে না।

## ৭. 🔴 সম্পূর্ণ প্রজেক্ট ZIP, APK ও নিরাপদ GitHub বিল্ড

প্রতিটি project delivery-তে স্বয়ংসম্পূর্ণ, build-ready ও developer-ready ZIP বাধ্যতামূলক; শুধু patch/পরিবর্তিত ফাইলকে পূর্ণ প্রজেক্ট বলা যাবে না। প্রযোজ্য source, Android/Flutter project files, Gradle/wrapper, workflow, assets/images/icons/resources, Manifest/permissions/dependencies, Live/RTC source/config, backend/API code, database schema/migrations, নিরাপদ signing setup, version identity, build instructions ও handoff থাকতে হবে। নতুন developer সর্বশেষ ZIP ও প্রয়োজনীয় নিরাপদ credentials দিয়েই কাজ চালাতে পারবেন; পরবর্তী ভার্সনে প্রয়োজনীয় ফাইল হারানো চলবে না।

সেই একই ভার্সনের Signed Release APK সফলভাবে তৈরি এবং উৎস/ভার্সন/সাইনিং যাচাই হলে ZIP-এ একটি নির্দিষ্ট user-facing APK থাকবে। APK তৈরি না হলে তা স্পষ্টভাবে বলতে হবে; source-ready, build-passed এবং feature-complete আলাদা অবস্থা। পুরোনো APK নতুন ভার্সন বলে জুড়ে দেওয়া যাবে না। অসম্পূর্ণ প্রজেক্টকে পূর্ণাঙ্গ বলা যাবে না। source project bundle ও আলাদা APK-only download artifact-এর উদ্দেশ্য পরিষ্কার রাখতে হবে।

Keystore/private signing key/password/API secret/token/security answer পাবলিক repository, APK source বা log/history-তে রাখা যাবে না; GitHub Secrets/নিরাপদ key storage ব্যবহার করতে হবে। আগের key থাকলে সেটিই ব্যবহার; নতুন key বানিয়ে update identity নষ্ট নয়। build-only QA-তে production Worker deploy/public APK replacement/AAB বা Play submission স্বয়ংক্রিয়ভাবে অনুমোদিত নয়। সেসব কাজের জন্য owner-এর প্রযোজ্য অনুমোদন প্রয়োজন। APK/ZIP ২৫ MB-এর নিচে রাখার চেষ্টা হবে; প্রয়োজনীয় কাজ বা নিরাপত্তা নষ্ট করে মিথ্যা size দাবি নয়। মাপ ও বাস্তব সীমাবদ্ধতা জানাতে হবে।

### GitHub আপলোড ও APK ডাউনলোড — মালিকের সংযোজন (২০২৬-১০-১১)

- প্রতিটি ভবিষ্যৎ source project ZIP-এ কার্যকর `.github/workflows/my-shop-apk.yml`, প্রয়োজনীয় build script এবং সহজ upload/build/download নির্দেশনা বাধ্যতামূলক। ZIP খুলে project-এর ভেতরের সব ফাইল, বিশেষ করে `.github`, repository root-এ আপলোড করতে হবে; শুধু ZIP আপলোডের বিকল্প থাকলে root workflow-এ সেই ZIP নির্বাচন ও extraction বাস্তবে সমর্থিত হতে হবে।
- GitHub Actions-এর সফল Android build থেকে ঠিক সেই source/version-এর একটি verified signed `MY_SHOP_FINAL_RELEASE.apk` download artifact প্রকাশ করতে হবে। Artifact না পাওয়া গেলে APK delivery ব্যবস্থা সম্পন্ন বলা যাবে না। Signing certificate, package/version, commit SHA এবং artifact পরিচয় পূর্বের যাচাই অনুযায়ী মিলবে।
- প্রয়োজনীয় original signing ও Firebase Secrets-এর নাম/setup এবং Actions → MY SHOP Android APK → Run workflow → Artifacts থেকে APK download-এর ধাপ জানাতে হবে। Secret-এর আসল মান source/নির্দেশনা/log-এ দেওয়া যাবে না।
- APK আগে তৈরি না হলে source ZIP দেওয়ার সময় স্পষ্ট বলতে হবে: “এই ZIP-এ APK নেই; GitHub Android build সফল হলে Artifacts থেকে APK পাওয়া যাবে।” Workflow inspection বা source tests-কে সফল Android build বলা যাবে না; build failure বা missing credentials থাকলে তার বাস্তব অবস্থা জানাতে হবে।
- পরবর্তী developer সর্বশেষ source ও handoff থেকেই কাজ চালাবেন। ইতোমধ্যে দেওয়া ZIP নীরবে overwrite নয়; সংশোধিত project delivery-তে পরবর্তী V-number এবং এই নিয়ম অন্তর্ভুক্ত থাকবে।

## ৮. প্রতিটি ভার্সন স্থায়ীভাবে সংরক্ষণ

প্রতিটি project ZIP ChatGPT Library-তে স্পষ্ট নাম/ভার্সনসহ সংরক্ষণ করতে হবে। আগের ভার্সন অকারণে মুছে ফেলা নয়। পরবর্তী কাজে সর্বশেষ সংরক্ষিত প্রকৃত সোর্স ব্যবহার করতে হবে। save সফল হয়েছে নিশ্চিত করে তারপর link দিতে হবে; link দেখানো মাত্র save হয়েছে নয়। ব্যর্থ হলে স্পষ্ট জানাতে হবে। সেশন হারানোর ঝুঁকি থাকলে পুনরুদ্ধারযোগ্য checkpoint সংরক্ষণ করতে হবে।

## ৯. 🔴 Live Streaming — বিশেষ সতর্কতা

আগে থেকে কার্যকর Live সুরক্ষিত থাকবে। Live code/design/audio/realtime/related backend বা তার আচরণ বদলানো shared helper পরিবর্তনের আগে exact proposed scope/impact owner-কে জানিয়ে প্রযোজ্য অনুমোদন নিশ্চিত করতে হবে। ইতোমধ্যে স্পষ্টভাবে অনুমোদিত একই কাজের জন্য আবার অনুমতি চাওয়া নয়। read-only inspection/test করা যাবে; সিদ্ধান্ত অপেক্ষমাণ হলে স্বাধীন non-Live কাজ চলবে।

পরীক্ষা: Host/Guest audio; RTC connect/reconnect; Join/Leave/End; Invite/Join Request; guest seats; realtime ephemeral comments; Coin/Gold gifts; gift animation/sound; Mute/Unmute/Kick/Block; Room Admin/Moderator; stats/Vote/Love React; minimize/restore; Live notifications; synchronization। Functional/realtime/regression এবং প্রয়োজনীয় device acceptance ছাড়া Live সম্পূর্ণ নয়। mic চালু করা ইউজারের নিজস্ব সিদ্ধান্ত; admin forced-mute override স্বয়ংক্রিয়ভাবে mic চালু করবে না।

## ১০. সিরিয়াল অনুযায়ী কাজ ও দৃশ্যমান অগ্রগতি

সব নির্দেশনা ধারাবাহিক Task 01/N, 02/N ইত্যাদি নম্বর ও শিরোনামে সাজাতে হবে। শুরুতে মোট সংখ্যা; প্রতিটি ধাপে চলছে/সম্পন্ন/বাকি এবং meaningful progress দেখাতে হবে। সময়ের হিসাব বিশ্বাসযোগ্য হলে আনুমানিক বলা যাবে; অনুমানকে প্রতিশ্রুতি করা নয়। পরীক্ষার আগে Completed নয়। অগ্রগতি দেখানোর জন্য কাজ থামিয়ে রাখা যাবে না। interruption হলে actual checkpoint লিখতে হবে।

## আগের নীতির পৃথক, বহাল শর্ত

- backend-driven configuration যেখানে নিরাপদ; Admin Add/Edit/Delete/Save/Enable/Publish/Link/Order ও প্রযোজ্য media/price/time/limit controls বাস্তবে persist ও frontend-এ কার্যকর হতে হবে। বর্তমান ১০৪টি master control-এর প্রয়োজনভিত্তিক scope বহাল; UI থাকা completion নয়।
- Remote configuration যাচাই করে last-known-good cache বদলাতে হবে। banner section সর্বোচ্চ ৬ active banner; slider interval ১–৬০ সেকেন্ড।
- অব্যবহৃত/duplicate asset শুধু Java/XML/dynamic/config/runtime reference যাচাইয়ের পরে সরানো যাবে। প্রয়োজনীয় icon/banner/Live asset সন্দেহের ভিত্তিতে বাদ নয়। lossless conversion করলে decoded pixel equality/resource compatibility যাচাই করতে হবে।
- Main Admin 0001/0002/0003; credentials hardcoded নয়। production ID backend-এ atomic allocation; আগে তৈরি immutable ID পরিবর্তন নয়। permissions server-authoritative।
- Coin ও Gold পৃথক; purchased/non-withdrawable এবং earned/withdrawable পৃথক। MY SHOP Commission-এর প্রতিষ্ঠিত নিয়ম বহাল; পুরোনো VAT/Service Fee লেখা দিয়ে সেটি প্রতিস্থাপন নয়। privacy/security/financial private তথ্য public style/summary payload-এ প্রকাশ নয়।
- Personal Details optional: শুধু populated field; Public/Friends/Only Me privacy। account recovery immutable ID-ভিত্তিক/audited; password/security answer history-তে নয়। Terms/Privacy/About/Notification/Account & Data deletion-এর অনুমোদিত scope বহাল।
- shared color wheel সব প্রযোজ্য editor-এ; Bengali grapheme-safe নির্বাচিত অংশ; Save Draft ও Publish আলাদা; version history/rollback এবং accessibility/contrast।
- approved Home/Profile/Messenger/Live feature-specific checklist ও সর্বশেষ reference সংশ্লিষ্ট scope/handoff-এ বহাল। label, quota, expiry, banner/mini-card/moving-strip আচরণ সাধারণ rules-এর duplicate হিসেবে মুছে ফেলা যাবে না।
- applicable Android/Google Play policy যাচাই করতে হবে; purchased currency non-withdrawable, billing/privacy/data safety/account deletion/startup ads প্রযোজ্য। পরীক্ষা ছাড়া Play compliance দাবি নয়।

## চূড়ান্ত ডেলিভারি যাচাই

Reference fidelity; regression safety; সব প্রয়োজনীয় source/config/resource; প্রকৃত build/test result; safe signing/workflow; একই সংস্করণের APK উৎস/পরিচয়; handoff/checkpoint; নতুন sequential version; measured size; successful permanent save; latest ZIP থেকে developer continuation—সব যাচাই করতে হবে।

**মূলনীতি: একটি কাজ করতে গিয়ে আরেকটি ভালো কাজ নষ্ট করা যাবে না। অসম্পূর্ণ প্রজেক্টকে পূর্ণাঙ্গ বলা যাবে না। প্রতিটি ডেলিভারি যাচাইযোগ্য, ধারাবাহিক এবং ভবিষ্যৎ কাজের উপযোগী হবে।**

## Owner latest source size rule2026-10-12
প্রতিবার canonical source ZIP25,000,000 bytes-এর নিচে যাচাই করে দিতে হবে। বড়ZIP ডেলিভারি নয়। tools/pack_source.py gate ব্যবহার করুন; অপ্রয়োজনীয়/duplicate source reference যাচাই করে পরিষ্কার করুন, প্রয়োজনীয় build inputs বাদ নয়। APK sourceZIP-এ না থাকলেও exact-version signed Android APK workflow বাধ্যতামূলক।
