# V653 GitHub APK build
V-653-MY-SHOP-FULL-SOURCE.zip অপরিবর্তিত অবস্থায় আগের স্থায়ী pipeline-এ দিন। Original signing ও Firebase secrets রাখুন। অন্য key, package বা পুরোনো APK ব্যবহার নয়।
CI clean source থেকে Android tests/release/lint চালাবে এবং package com.myshop.app, versionCode653/versionName2.9.653, SOURCE_BUILD_ID, signing certificate, provenance ও V653 DEX markers পরীক্ষা করবে। সঠিক commit SHA, artifact timestamp/hash ও একমাত্র signed APK যাচাই করুন।
এই source checkpoint-এ APK নেই: স্থানীয় Gradle download Network is unreachable। Worker/D1 production deploy হয়নি। Matching Worker code ও0065 migration setup হ্যান্ডঅফ অনুযায়ী লাগবে। নতুন কাজ করতে এই653source থেকে চালাবেন; next654.
