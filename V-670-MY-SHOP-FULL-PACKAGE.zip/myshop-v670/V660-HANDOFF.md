# MY SHOP V-660 / 2.9.660 — Live Room repair

Complete V659 source retained, with one exact duplicate JPEG reconstructed from its canonical drawable during asset preparation. No feature, financial transaction, original sound or approved artwork removed. Source ZIP remains below 25,000,000 bytes.

## Changes
- Authenticated, session-scoped WebSocket wake hints for live changes. Existing authorized HTTP feed remains the source of event data; socket contains no profiles, messages or Cricket secrets. Reconnect/backoff, expiring participation tickets, HTTP fallback and room-end handling included.
- Successful profile/avatar updates wake active room clients. Join/seat/state changes use the existing Hub revision. Real-time means immediate event-triggered refresh when connected; network and server delays still apply.
- Audience receives audio without microphone capture. Host/Guest publish follows original roles and permission/consent. Recover audio/video subscriptions after RTC rejoin; preserve explicit receive mute. Rebind actual remote UID views and clear departed guest view cache.
- Video caption names centered on a transparent row without black name strips. Opaque camera-off fallback prevents stale video beneath profile portraits.
- Gift comments and effects acknowledged independently, effects acknowledged after attachment. Retry missing presentations without sending another financial transaction. Keep sound once per event, bounded queue, session isolation, fallback banner after three render failures. Original gift charging/catalog functions byte-identical to approved baseline.
- Gift gallery: horizontal scrolling within multi-page categories; swipe outward at a category edge to open the next/previous category. Threshold/direction filtering cancels the tile touch before navigation, preventing accidental gift selection. Locked sends, Lucky and Favourite remain unchanged.
- New dependency: com.squareup.okhttp3:okhttp:4.12.0 for the native WebSocket client. Existing network permission and backend URL retained.

## Build / APK
Upload this ZIP as V-660-MY-SHOP-FULL-SOURCE.zip to the existing myshop24/MY-SHOP repository using the permanent release pipeline. It selects V660, normalizes version, deploys the matching Worker and builds using existing secrets/signing key. Successful run produces MY-SHOP-FINAL-V-660 artifact containing MY_SHOP_FINAL_RELEASE.apk. The ZIP alone is not an APK.

Source Android preBuild invokes V660 guards. assembleRelease finalizer checks actual APK DEX, RTC libraries, gift atlas and resource staging before artifact upload. Original V659 sole resource tree fix retained: 148 original WAVs are converted losslessly to FLAC in one complete generated resource root; original developer inputs retained. No duplicate WAV/FLAC Android resource IDs.

This environment has no usable Android SDK/original signing key and Gradle distribution retrieval was blocked. No signed V660 APK or real-device test is claimed. Physical sound/remote video delivery must be tested with host, guest and independent audience phones after the GitHub build, including reconnect, camera consent, gift animation/sound/comment, and Join/Leave/profile changes. Source/facade tests are not an Agora/device integration test. Firebase is not the transport for Live Room RTC or gift event delivery.

## Checkpoint
Implementation and local verification are in this package. Continue from V660; next release must be V661. Do not restart from V654 or replace the permanent root pipeline. No production deployment or financial request was performed during this edit. Retain original signing/Firebase/Agora/Cloudflare secrets; do not generate a replacement signing key.

## Verified in this phase
- 143 Node tests passed, zero failures.
- All 16 Android preBuild target/compile guard commands passed; Java parser, callback Context and lambda scope checks passed on 291 source files. These are not a full Android SDK compile.
- Actual-method facade checks passed for RTC roles/subscriptions/UID binding, gift comment/effect recovery, category swipe and original 221 seat-policy cases.
- Runtime staging: 577 resources, 148 lossless sounds; decoded PCM equality, zero duplicate Android resource IDs and zero WAVs in staged resource root.
- Every inherited source hash checked; original normal-gift finance functions and protected chair/comment boundaries retained.
- Permanent pipeline normalizer is byte-idempotent for V660. Prior V659 run720 succeeded and produced MY-SHOP-FINAL-V-659. That success is not a V660 build result.
- Local Gradle bootstrap failed with Network is unreachable while downloading Gradle8.11.1. Signed V660 APK still requires the GitHub runner.
