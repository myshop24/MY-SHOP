# MY SHOP V-665 handoff

Baseline is the delivered V664 source ZIP (SHA256 b915e9edbad9994ea248c547258e078951dbdf8a310dab51a3ea6a4d0cd93bb4). This is a complete source-project checkpoint with **partial feature completion**, not an accepted Android release. Read V665-APPROVED-WORK-BN.md for the complete done/pending distinction. Next changed delivery: V666.

## Implemented source

- Removed the redundant live Follow button; host identity width 94→72dp releases 22dp to the unchanged viewer portraits. Follow in profile remains. Long-name drawing enters at the right and travels left, without reversing text.
- Communication routes: modern Android system selection is not overwritten by SDK speaker calls; explicit Bluetooth permission success resumes selection. Legacy wired/USB clears SCO/speaker; connected A2DP detection attempts call SCO, confirms via broadcast and times out rather than hanging silently. Automatic device callbacks/focus recovery retry routing. Cleanup releases device selection, SCO listener/timer and prior audio mode. Actual headset input/output still requires devices.
- Shared RideEffectView demo/live; native body color variants preserve separate wheels. Five additional car drafts. Larger live stage; video completion/sound window begins at preparation. Missing/failed media can advance the queue. Cinematic reference-quality rider assets and audited retirement/replacement of old purchased riders are **not complete**; no old ownership has been revoked.
- Seven transparent owner video-derived frames in avatar665, including legacy GIF equivalents and independent geometry. Original four assets and geometry remain intact. Existing profile, comment and live avatar composition recognizes the new keys; cosmetic frames grant no membership authority.
- Seven animated wallpaper assets in wallpapers665. Six full-duration, muted 432x768/20fps videos; one original GIF and posters. The single selected full demo/room uses TextureView/MediaPlayer, releases while stopped/detached and retains a poster on failure. Catalog tiles use posters. Low-RAM devices default video effects off; More→Audio offers a per-device wallpaper switch. Admin can pick static cropped images or GIF/WebP/video. Owned theme/default/24h preference rules are retained.
- Thirty native cosmetic variants: two nameplates, two microphone effects, heart/star sticker packs, each in five colors. Catalogue and Admin/My Collection share preview renderer using current account identity. Profile and ordinary live comments show owned nameplate; speaker ring changes only while speaking. Sticker picker is inside existing comment composer, not the permanent room toolbar. The server checks unexpired sticker ownership; comments/acknowledgements carry server-owned sticker data. No charges in sticker sending.
- Bounded five-second DB-scoped cosmetic cache batches participant lookups, invalidates after equipment changes and caps lifetime by expiry. No wallet/permission fields enter style payloads.
- All 49 new catalogue entries are disabled/zero-price drafts (7 frames,7 wallpapers,30 cosmetics,5 car variants). Admin must preview, set Diamond price and publish. Seeds are additive/transactional/idempotent; they do not resurrect deleted products or alter existing prices, IDs, ownership, financial history or signing.
- My Collection exposes existing categories to ordinary users too, adds account-scoped favourites and an in-app expiry/Renew hint within three days. Existing friend gift greeting, hold/admin approval, bundle and grant/soft-delete history rules are retained. New dedicated five-color pack purchase and Messenger sticker transport are not implemented.

## Build and setup

Keep existing original package/signing/Firebase/Agora/Cloudflare setup. See SIGNING-SETUP.md, BUILD-ASSETS-BN.md and GITHUB-UPLOAD-V665-BN.md. Never print or include real credentials. New media outputs are checked-in build inputs; tools/import_owner_media665.py records how to regenerate from the owner's original supplied files, but regeneration is not required to build this delivery.

Run `bash tools/prepare-build-assets.sh`, `python3 tools/v665_prebuild_verify.py`, then `bash gradlew --no-daemon assembleRelease`. These local steps do not deploy. Existing permanent root workflow may deploy the matching Worker before Android compilation; owner upload therefore must be deliberate. No remote push/deploy or signing replacement was performed here.

Local full APK build was attempted and blocked downloading Gradle8.11.1 with `java.net.SocketException: Network is unreachable`. No APK is bundled and no successful GitHub run is claimed. verify-v665-apk.py checks actual built DEX and all14 new owner-media assets, in addition to previous ABI/content checks. Artifact identity/signature/size must be verified on the actual new APK; green Actions alone is insufficient.

## Required physical acceptance

Different phones: host+guest+audience; repeat 2–8 publishers. Video on/off/flip/consent, leave/rejoin/reconnect, gifts/ledger/more sound, comments/stickers and entry queue. Bluetooth call microphone AND output, wired/USB, permission rejection, connecting/disconnecting during call on Android24/30/31/36. Check long names/host click/viewer count and unchanged avatar/seat layout on small phones.

Preview/publish/buy/hold/approve/gift/admin-grant/equip/expiry/renew/disable/delete every new product family. Check GIF on API24 and animated WebP on API28+, all seven frame masks against the original reference, no centre obstruction, muted wallpapers, decoder release, poster fallback and low-memory behavior. Confirm all room participants see the same host theme and camera/mic permissions remain user controlled. Check duration and original signing on actual APK665.

Broader approved but incomplete Live/D1/TV/quiz/photo/private-room/queue/diagnostics plans remain listed in V665-APPROVED-WORK-BN.md. Do not silently mark them done or confuse tests/models with physical acceptance.

## Mobile-sized upload delivery

The canonical complete ZIP exceeds25MB because of all required original/new runtime media. Three upload pieces are each below25MB. The delivered root my-shop-release.sh embeds the same verified reconstruction helper and must replace the old repository-root script after all pieces are present. No remote mutation was performed. It reassembles and checks size/SHA256/CRC before any selection/deploy; wrong checkout SHA fails rather than building a moving main. Existing workflow trigger/Worker/signing flow is retained. Missing/corrupt-piece behavior is tested independently.

The updated delivered root release script builds/signs/verifies APK first and then deploys the matching Worker; the older repository-root script inspected read-only deployed first. The updated script verifies each uploaded part against the exact checked-out commit and records the reconstructed source SHA. The bundled build-only Android workflow does not deploy. No actual remote run was started.
