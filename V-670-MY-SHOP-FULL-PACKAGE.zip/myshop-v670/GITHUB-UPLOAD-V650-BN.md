# V650 — এই ধাপে তিনটি কাজ

১. অনুমোদিত প্রিমিয়াম আইকন/More মেনু, পুরোনো অ্যানিমেটেড Join ফেরত।
২. ক্যামেরা অফে শেষ ভিডিও ফ্রেম সম্পূর্ণ লুকিয়ে ইউজারের প্রোফাইল ছবি।
৩. ভিডিও ২/৪/৭ সিট, মেইন গেস্ট/গেস্ট বড়/হোস্ট ফুলস্ক্রিন; View শুধু More → Seats / Layout-এ। ভিডিও সিটে নাম/নম্বর নেই; টাচে বিস্তারিত/হোস্ট কন্ট্রোল।

এই ZIP-এ APK নেই; GitHub Android build সফল হলে Artifacts থেকে APK পাওয়া যাবে। আগের permanent upload pipeline-এ V-650-MY-SHOP-FULL-SOURCE.zip অপরিবর্তিত আপলোড করুন। সরাসরি project দিলে ZIP-এর .github-সহ সব ফাইল repository root-এ রাখুন। Actions → MY SHOP Android APK → Run workflow → সফল run-এর Artifacts → MY_SHOP_FINAL_RELEASE.apk। SOURCE_BUILD_ID MY SHOP V-650, versionCode650 / versionName2.9.650, package com.myshop.app যাচাই করুন।

আগের Firebase/original signing Secrets-ই ব্যবহার করুন। নতুন signing key বানাবেন না। প্রযোজ্য Secrets-এর পূর্ণ নির্দেশনা বিদ্যমান workflow ও developer policy-তে আছে; কোনো গোপন মান ZIP-এ নেই।

নতুন view sync-এর জন্য Worker650 এবং 0063_v650_live_view.sql লাগবে; তার আগে 0062 ও পূর্বের migration থাকতে হবে। এটি শুধু অস্থায়ী session view-state যোগ করে, পুরোনো হিসাব reset করে না। Staging-এ যাচাই করে বিদ্যমান migration/deploy পদ্ধতি অনুসরণ করুন। এই কাজ থেকে production deploy করা হয়নি। পুরোনো Worker থাকলে ক্যামেরা/আইকনের client পরিবর্তন থাকবে, কিন্তু নতুন shared view controls সফল হবে না।

দুটি speaker ও আলাদা viewer ফোনে ক্যামেরা OFF/ON, profile fallback, guest video, voice, main guest/fullscreen এবং Join animation যাচাই করতে হবে। স্থানীয় unsigned QA build original-signed update বা বাস্তব ফোন পরীক্ষার বিকল্প নয়।
