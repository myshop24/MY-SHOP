# V651 GitHub APK build package
এই ZIP-এ নতুন APK নেই। এটি source implementation checkpoint; Android/ফোনে যাচাই বাকি। পুরোনোAPK ব্যবহার করবেন না।

বর্তমান myshop24/MY-SHOP repository-এর কাজ করা স্থায়ী ZIP-selector pipeline থাকলে V-651-MY-SHOP-FULL-SOURCE.zip অপরিবর্তিতভাবে root-এ upload করুন; পুরোনো sourceZIP মুছবেন না। Selector সর্বোচ্চ651 নির্বাচন করেছে নিশ্চিত করুন। নতুন repository হলে ZIP extract করে project-এর সবফাইল, hidden .github সহ, root-এ দিন।
মূল signing/Firebase Secrets রাখুন; নতুন key বানাবেন না। Actions → MY SHOP Android APK → সর্বশেষ নির্দিষ্ট commit-এর run। build সফল হলে MY-SHOP-V-651-APK artifact-এ একটিমাত্র MY_SHOP_FINAL_RELEASE.apk থাকবে। কেবল green Success যথেষ্ট নয়: run commit,651 source/DEX gate, package/version/original certificate ও artifact origin যাচাই করুন।
বিল্ড fail হলে log অনুযায়ী ঠিক করুন; এই checkpoint-কে tested release বলবেন না। Worker/D1 deployment আলাদা; অনুমতি ছাড়া deployment নয়। বিস্তারিত current Developer Handoff-এ।
