# V-670 আপলোড
এই V-670-MY-SHOP-FULL-PACKAGE.zip না খুলে repository root-এ Upload files দিয়ে Commit করুন। পুরোনো permanent pipeline সবচেয়ে বড় V-number বেছে নেয়। সফল run-এর release artifact থেকে APK পাবেন; versionCode670/versionName2.9.670 এবং original signing যাচাই করতে হবে।
এই ZIP-এ তৈরি APK নেই। মূল workflow পুরোনো থাকলে সেটি Worker deploy-ও করে; সোর্স ZIP আপলোডে মূল workflow নিজে বদলায় না। এই প্যাকেজের workflow build-only হলেও তা repository-তে আলাদাভাবে স্থাপন না করা পর্যন্ত কার্যকর নয়।
