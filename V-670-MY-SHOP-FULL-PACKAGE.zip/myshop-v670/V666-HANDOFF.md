# MY SHOP V-666 — single ZIP under25MB

Packaging/build-input change only, continued from delivered V665. No new Live design, audio, seat, gift, payment or ownership behavior is introduced. All V665 partial-feature limitations remain in V665-APPROVED-WORK-BN.md. In particular full cinematic rider upgrades/retirement and physical phone/APK acceptance are not completed by this size repair. Next changed delivery667.

## Single-file owner workflow

Upload only `V-666-MY-SHOP-FULL-SOURCE.zip` to the existing repository root, unchanged. No `.001/.002/.003`, no extra release script, no manual joining and no manual asset upload. Do not upload the63MB V665 archive or the earlier multipart files. Existing root workflow selects666 normally.

## Exact media preservation with compact build dependencies

The archive includes the complete current text source/config/workflows/Gradle/wrapper and all seven original supplied frame-video inputs. The seven new wallpaper media/posters are included unchanged. Large transparent frame WebP/GIF outputs are regenerated during source verification/build from those included videos, using the same importer. Their SHA256 must equal V665; failure stops the build.

218 unchanged older binary media inputs are a hash-locked build dependency on the verified V664 archive. The existing GitHub checkout already contains `V-664-MY-SHOP-FULL-SOURCE.zip`; the bootstrap uses that copy first. If building from only this ZIP elsewhere, it automatically fetches the same public archive from immutable commit e2d6bacebafd80744d82f25d3fd9fb3317b07149. SHA256 b915e9edbad9994ea248c547258e078951dbdf8a310dab51a3ea6a4d0cd93bb4 and every restored file hash are verified. GitHub blob81955b0c832aaca8262d41aef89b71557e864299 was compared to the local archive. This is a network-dependent compact source distribution, **not an offline/self-contained media archive**. No baseline Java/backend source is restored or used in place of current code. Media are not removed from the built app or recompressed to lower quality.

A new developer needs this ZIP plus internet, or an exact V664 archive via `MYSHOP_BASELINE_ARCHIVE=/path/to/V-664-MY-SHOP-FULL-SOURCE.zip`. Never use an unverified previous ZIP. The full V665 archive remains retained separately as the offline reference. Dependency failure must stop rather than silently show substitutes.

`tools/prepare-compact666.sh` runs before the older source gate and asset preparation, so the existing permanent root pipeline requires no update. The original source release script replaces the obsolete multipart script inside this project. Gradle Exec tasks use the bootstrap venv when present. All original signing/package/Firebase/Agora/D1/R2 settings and financial locks remain.

## Verification and limitations

Run `bash tools/prepare-compact666.sh`, `bash tools/prepare-build-assets.sh`, and `python3 tools/v666_prebuild_verify.py`. Tests check all restored bytes, missing/corrupt dependency handling, path traversal rejection, actual clean extraction/regeneration, unchanged runtime media and source/identity/financial regression gates. Exact results are recorded in verification/V666-RESULTS.json. Local source verification is not a signed Android build.

No APK is bundled. Full Android build remains blocked locally by Gradle8.11.1 download networking, and no GitHub workflow was run or repository modified by this packaging task. A successful exact-version Android build must still verify package666/2.9.666, original certificate, DEX markers, all14 new media assets, artifact hash/time/source and physical phones/headsets. The existing root workflow may deploy the matching Worker when the owner uploads; local packaging never deployed.
