# MY SHOP V-670 source build package
Upload V-670-MY-SHOP-FULL-PACKAGE.zip directly, without extracting, to repository root. Existing permanent release selector recognizes its versioned filename. Read V670-HANDOFF.md for actual scope and blockers. APK not included; Android/signing/physical-device verification pending. Embedded workflow does not replace the repository-root workflow automatically.
