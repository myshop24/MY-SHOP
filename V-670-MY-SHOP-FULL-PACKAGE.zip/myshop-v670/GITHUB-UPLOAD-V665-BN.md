# V-665 GitHub build

এই ZIP-এ APK নেই; GitHub Android build সফল হলে Artifacts থেকে APK পাওয়া যাবে। V-665 পূর্ণ source project হলেও আলোচনার সব ফিচার শেষ নয়; V665-APPROVED-WORK-BN.md পড়ুন।

## মোবাইল থেকে ২৫ MB-এর নিচের ফাইল দিয়ে আপলোড

পূর্ণ ZIP বড়। দেওয়া `.zip.001`, `.zip.002`, `.zip.003` — তিনটি ফাইল অপরিবর্তিত নামে repository root-এ আগে আপলোড করুন। তারপর দেওয়া নতুন `my-shop-release.sh` root-এর একই নামের পুরোনো ফাইলের জায়গায় আপলোড করুন। সব চারটি একই commit-এ আপলোড করতে পারলে ভালো; আলাদা করলে script **সবার শেষে** দিন। `.001` ফাইল খুলে unzip করার প্রয়োজন নেই। পুরোনো root workflow-তে script পরিবর্তন trigger আছে; অথবা সব upload শেষে Actions→Run workflow করুন।

নতুন script তিনটি ভাগের SHA256/size/ZIP CRC যাচাই করে সম্পূর্ণ V665 ZIP তৈরি করে, তারপর আগের release flow চালায়। কোনো part অনুপস্থিত/ক্ষতিগ্রস্ত হলে Worker deploy শুরু হওয়ার আগেই থামবে। এই ব্যবস্থা স্থানীয়ভাবে valid/corrupt/missing-part দিয়ে পরীক্ষিত; remote GitHub run করা হয়নি।

মূল সম্পূর্ণ ZIP-টিও দেওয়া হয়েছে। Desktop git বা উপযুক্ত upload পথে ব্যবহার করা যাবে; GitHub mobile web-এর single-file limit পার করবে এমন দাবি নয়। ZIP খুলে project root-এর সব ফাইলও upload করা যায়। প্রয়োজনীয় media বাদ দেওয়া হয়নি।

আগের permanent pipeline/Secrets/original signing key রাখুন। bundled `.github/workflows/my-shop-apk.yml` unpacked source বা সম্পূর্ণ versioned ZIP গ্রহণ করে। শুধু source ZIP upload করলে আগে থেকেই repository root-এ ZIP-selecting workflow কার্যকর থাকা প্রয়োজন; ZIP-এর ভেতরের workflow আপনা থেকে চালু হয় না।

1. SOURCE_BUILD_ID.txt=`MY SHOP V-665`; SOURCE_VERSION_NAME.txt=`2.9.665`; app versionCode665; Worker health V-665 যাচাই।
2. আগের GitHub signing/Firebase/Agora/Cloudflare Secrets রাখুন। SIGNING-SETUP.md/BUILD-ASSETS-BN.md অনুযায়ী missing setup করুন; secret values source-এ রাখবেন না।
3. Actions→Android pipeline→সঠিক commit/run। নতুন দেওয়া root script APK build/sign/verify হওয়ার পর matching Worker deploy করে; পুরোনো repository script আগে deploy করত। স্থানীয় source যাচাই deployment করেনি।
4. ব্যর্থ হলে প্রথম failed step-এর সম্পূর্ণ log দেখুন। স্থানীয় source checks সফল মানে signed APK build সফল নয়।
5. সফল হলে exact run-এর `MY_SHOP_FINAL_RELEASE.apk` artifact download করুন। package,665/2.9.665, original certificate, commit, artifact timestamp/hash, V665 DEX এবং14 owner media asset-এর verifier মিলিয়ে নিন।
6. বাস্তব ফোনে handoff-এর পরীক্ষাগুলো করুন। APK size মাপুন; এখানে APK তৈরি হয়নি, তাই APK size জানা নেই।

নতুন49টি item disabled draft। Admin Store-এ media preview, দাম/মেয়াদ ঠিক করে Publish/Enable করুন। পুরোনো কেনা rider বাতিল হয়নি; নতুন cinematic replacement/retirement কাজ বাকি।
