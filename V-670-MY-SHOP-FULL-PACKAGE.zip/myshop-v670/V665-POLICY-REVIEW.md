# Scoped policy review — 2026-10-22

Reviewed official Android communication-device APIs and Google Play UGC/payments guidance. This is not a complete Play-readiness audit or an approval guarantee.

- Android communication routing uses getAvailableCommunicationDevices/setCommunicationDevice on API31+, which also selects the matching input device; it is cleared at session teardown. Legacy SCO remains for older Android. https://developer.android.com/reference/android/media/AudioManager and https://developer.android.com/develop/connectivity/bluetooth/ble-audio/audio-manager
- Camera/microphone consent, runtime permissions and existing moderation/report/block paths remain required. Stickers use the authenticated comment path with ownership/expiry checks. UGC policy requires effective moderation/reporting/blocking and terms; these must be verified across actual UI paths before Play submission. https://support.google.com/googleplay/android-developer/answer/9876937
- Digital cosmetic/virtual-currency sales require the applicable Play billing route or a valid applicable exception/program. This release retains the existing premium/held-Diamond flow; it does not prove that the app's currency funding or alternate billing is Play-compliant in every distribution country. A dedicated billing review is required before Play release. https://support.google.com/googleplay/android-developer/answer/10281818 and https://support.google.com/googleplay/android-developer/answer/9858738
- Supplied media attribution/licensing, privacy/Data safety, account deletion, age/content controls, target SDK/native page alignment and production security acceptance still require a complete release review. https://support.google.com/googleplay/android-developer/answer/10787469

No Play submission, production deploy, permissions expansion, currency/ledger redesign or certification was performed.
