# V-662 GitHub build নির্দেশনা

1. GitHub repository root-এ `V-662-MY-SHOP-FULL-SOURCE.zip` আপলোড করুন। একই সর্বোচ্চ V-662 নম্বরের আরেকটি ZIP রাখবেন না।
2. MY SHOP repository-এর স্থায়ী root release pipeline সর্বোচ্চ V নম্বরের ZIP বেছে নেয়। এটি আগে ZIP-এর Worker production-এ deploy করে, তারপর Android APK build/sign করে। এই V-662 ZIP-এ Worker-এর gift feed-ও বদলেছে, তাই root pipeline চালালে ওই backend পরিবর্তন production-এ যাবে। `tools/ci-apk-build.sh` আলাদা build-only যাচাই; স্থায়ী root pipeline deployment নিয়ন্ত্রণ করে।
3. GitHub Actions শেষ হলে সঠিক V-662 run খুলে Worker version এবং signed APK artifact পরীক্ষা করুন; artifact থেকে `MY_SHOP_FINAL_RELEASE.apk` ডাউনলোড করুন। APK-এর versionCode 662, versionName 2.9.662, মূল signing certificate এবং build provenance পরীক্ষা করুন।
4. APK সাইজ GitHub artifact থেকে মেপে handoff-এর সঙ্গে মিলিয়ে নিন। এই source ZIP-এ APK অন্তর্ভুক্ত নেই।
5. ফোনে পরীক্ষা না করে Live/Agora কাজ production-ready ঘোষণা করবেন না। বিশেষ করে host, 2–8 জন camera publisher এবং আলাদা audience ফোনে gift animation/sound/comment ও camera controls পরীক্ষা করুন।

Android SDK 36/build-tools 36.0.0, বিদ্যমান GitHub Actions configuration, Firebase config এবং মূল signing identity প্রয়োজন। Password, key বা API secret এই ZIP-এ লেখা নেই; existing protected GitHub secrets ও signing cache-ই ব্যবহার করতে হবে। নতুন signing key তৈরি বা পুরোনো key বদলাবেন না।

Local target checks: `bash tools/v662_target_verify.sh`। Production deploy-এর আগে এই handoff-এ বর্ণিত 2–8 জনের Live ও gift পরীক্ষা/রিভিউ করুন। বিস্তারিত সীমা ও বাকি device checks: `V662-HANDOFF.md`।
