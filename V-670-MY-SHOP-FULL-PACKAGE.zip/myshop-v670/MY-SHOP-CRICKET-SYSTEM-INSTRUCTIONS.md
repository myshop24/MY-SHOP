# MY SHOP — Cricket final implementation contract (V654)

Owner authorization:2026-10-21. BaselineV653. Latest chat decisions below supersede contradictory text in reference images. No wager, paid entry or game-linked money reward is authorized. Normal Live gifts remain their independent existing system.

## Game/Live protection
Existing Game icon → Game List → 🏏 icon with ক্রিকেট below → Cricket Board. No permanent extra large Live button. Cricket is isolated; do not replace seats, Main Guest artwork, comments, RTC, gift pricing/send, Join/Invite, music, messages, moderation, Vote/Love, minimize or end/leave. Reference navy/purple with pink-blue score strip, green SCORE. Host opens board, selects/replaces controller, does not ordinarily setup/score. Controller selected as Main Guest through existing accepted call/seat mechanism, never forced mic/camera. Cricket permission is not full room administration.

## Authority and privacy
Current commentator/controller handles setup, digital toss, assignments, sponsor, overs, score, pause/resume/end, corrections. Old commentator immediately loses current controller permission. Fixed Super Admin0001/0002/0003 sees complete match, recovery code, secret ball/history and may control all cricket. Server-authorized moderators have read-only full cricket visibility. Ordinary Host/Room Admin/Audience/Batsman must not receive secret ball/history in public payload. Bowler sees own pending ball. Match code alone grants recovery/reassignment, not secrets.

## Match
Unique ID and secret recovery code; one active match per room, multiple previous summaries allowed. Equal player count for teams, set by commentator and locked once play starts. Names and team numbers set in setup. Players selected from Live comment profile/name long press. Same user ID cannot join both teams in match. No manually preset first-innings target. Digital toss: winning side chooses batting or bowling first. Total overs editable only during first innings, never below completed balls rounded to whole overs; final limit locks after first innings, second team gets same limit.

## Delivery
Bowler chooses0–6, first submission locks. Repetition permitted; no pattern hints/counter/warning for bowler. Ball delivered privately to commentator for human voice commentary. Batsman chooses0–6; latest run before SCORE wins, publicly visible immediately even if ball not submitted yet. Commentator decides whether early run requires reset. No auto result publication.
Ball Reset by commentator/Super Admin before SCORE clears both ball and run, no historical score/ball changes. Player replacement before SCORE also clears only pending ball/run. Completed delivery records and same-ball chain remain.
SCORE is single idempotent commit: matching ball/run OUT; nonmatching count run. Public temporary red OUT/green run; no secret number revealed. No ordinary reset after SCORE; separate audited correction is permitted. Six counted deliveries = one over. All slots out ends innings, including1-person team (not traditional n-1 rule). Other team target = first score+1; chase reaching target wins immediately.

## DOT
Fourth consecutive identical finalized Secret Ball within an over counts runs, never OUT, never increments legal-ball count. Then chain resets; fifth same is first of new chain. Different number resets sequence. New over resets sequence. Bowler change mid-over retains sequence. Reset of unpublished input does not erase finalized sequence. No bowler-facing indication of impending DOT. Public result may show DOT after SCORE.

## Bowling and replacement
Full-over bowler cannot bowl immediately following over. If over split between bowlers, both may bowl next over. Commentator replaces/removes/restores via existing user identity, preserving runs/balls. Three legal deliveries completed means replacement bowls remaining three; score continues. Replacement occupies same team slot, not an extra player. Credit only actual playing IDs. Original identity retained; replacement OUT exhausts slot so original cannot return to bat in that innings. Remove only clears current role, never deletes completed performance. Offline causes no automatic OUT or loss of match.

## Super Over / Best
Tie →6-ball Super Over; if tied repeat. Commentator sets Super Over OUT limit. Original-innings outs can bat again in Super. OUT in one Super prohibits batting in later Supers. If tied and eligible players exhausted commentator may declare Draw or explicitly restore players by special permission for another Super; audit this exception. Best Player per winning/losing team: cumulative normal+all Super runs+10×wickets; tied points prefer wickets; fully equal joint award. Draw may have best per team.

## Sponsor
Commentator enters MY SHOP user ID, previews actual current photo/name/ID and confirms. Invalid ID rejected. Sponsor card uses authoritative profile; no match/admin permission gained. Sponsor resides in cricket overlay.

## Layout
Board, Sponsor, Batsman and Bowler panels separately movable and resizable (width/height) by Host/controller/Super Admin. Press/hold drag and resize grip; stay in viewport with critical-control safe area. Local account layout persists, never forces other screens. Hide/collapse never ends match. Restore current state on show. Maintain readable minimums and scroll content instead of losing controls. Match state unaffected by local layout gestures.

## Recovery / summaries
Persist lightweight current match, actual player records, history and audited corrections. No voice/comment capture. Controller disconnect pauses score acceptance until reconnect/replacement. Live crash/end keeps unfinished state24h from interruption. Automatic server state recovery using unchanged code; any authenticated code holder may recover into active Live and appoint/replace commentator. Exactly one current room binding; old room commands fail. Recovery does not transfer Cricket full role by code alone. Pending inputs cleared on rebind to avoid attribution mistakes.
Controller may manually enter previous totals on recovery or correct during play: team score/outs/balls/inning/target and player runs/wickets, with prior/new values, actor/time/reason audit. Recompute Best. Normal SCORE-lock rule does not prohibit explicit audited correction. Summary24h from match end, authorized earlier delete permitted. Multiple summaries must not block next match. Expiry cleans state/history/audit.

## Verification required before accepted release
Engine edge cases, concurrent SCORE retry, role revocation, secret payloads, reset/replacement, DOT every-over boundary, chase/all-out/Super exceptions, corrections/Best, same-code room rebind, expired matches and cleanups, sponsor identity. Actual Android compilation/signing/provenance. Phone UI at small screen and landscape, Host/Guest/Audience audio/video/gifts/comments/Join regressions; sustained session/network-loss tests. No source test implies phone acceptance or100% reliability.
