# V-668 বিল্ড
এই ZIP-এ APK নেই। বর্তমান GitHub-এর পুরোনো permanent pipeline Worker deploy করে। শুধু ZIP আপলোড করলে সেটি build-only হবে না।
নিরাপদ build-only পথ: ZIP খুলে myshop-v668-এর সব ফাইল (লুকানো .github-সহ) repository root-এ দিন; root .github/workflows/my-shop-apk.yml-টি এই প্যাকেজের workflow দিয়ে প্রতিস্থাপিত হতে হবে। প্রয়োজন হলে আলাদা build-only repository ব্যবহার করুন। আগের ZIP মুছবেন না।
Original MYSHOP signing/Firebase Secrets আগের মতো লাগবে; SIGNING-SETUP.md পড়ুন। কোনো key/password সোর্সে দেবেন না।
Actions → MY SHOP Android APK → সফল হলে MY-SHOP-V-668-APK artifact → MY_SHOP_FINAL_RELEASE.apk। SHA/identity/certificate মিলিয়ে দেখুন। সবুজ build ফোনে Live সফলতার প্রমাণ নয়।
Pages-এর failure আলাদা; website output ছাড়া পুরো repository প্রকাশ করবেন না।
