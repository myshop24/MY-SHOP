# V-666 — একটিমাত্র ZIP আপলোড

শুধু `V-666-MY-SHOP-FULL-SOURCE.zip` আগের মতো GitHub repository root-এ আপলোড করুন। আলাদা অংশ/স্ক্রিপ্ট/মিডিয়া আপলোড বা ZIP জোড়া লাগানোর কোনো কাজ নেই। আগের63MB V665 ZIP বা `.001/.002/.003` ব্যবহার করবেন না।

বিল্ডের সময় নতুন frame-এর GIF/WebP স্বয়ংক্রিয় তৈরি হবে। পুরোনো অপরিবর্তিত media আগের যাচাইকৃত V664 থেকে স্বয়ংক্রিয় নেওয়া হবে; আপনার repository-তে সেটি আছে। আলাদা জায়গায় build করলে একই pinned public archive স্বয়ংক্রিয় download হবে। সব hash মেলানো বাধ্যতামূলক; কোনো media/feature বাদ দেওয়া বা নিম্নমানের বিকল্প দেওয়া হয়নি। এই ছোট source ZIP-এর build media dependency আছে; সম্পূর্ণ offline media bundle নয়।

আগের original signing/Firebase/Agora/Cloudflare Secrets রাখুন। Actions-এ নতুন666 run দেখুন। Android build সফল হলে Artifacts-এর APK নামান। APK package/version666/2.9.666, original signature ও নতুন content যাচাই করুন। এখানে APK তৈরি হয়নি; ZIP-এ APK নেই।

V665-এর সব পরিকল্পিত ফিচার শেষ হয়নি—V665-APPROVED-WORK-BN.md ও নতুন handoff-এ বাকি কাজ লেখা আছে। V666 কেবল এক-ZIP size/build-input সংশোধন।
