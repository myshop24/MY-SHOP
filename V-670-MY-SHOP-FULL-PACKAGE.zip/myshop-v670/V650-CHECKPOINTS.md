# V650 checkpoints

- CP01: recovered exact final649 after workspace maintenance; implemented scoped icons/Join, opaque camera fallback and seat/focus source. Saved V-650-CHECKPOINT-01.zip before final Android verification. This is an intermediate checkpoint, not the final delivery.
- Verification: original V648 JoinLinkView animation body byte-identical; 341 unrelated production files byte-identical; native icon-aspect proof, 55 Android tests and 113 Node test files passed. New SQLite tests cover Host-only view/CAS/session reset/guest departures and camera-off retaining focus. Exact final result is in verification/V650-RESULTS.json.
- Final continuation: use V-650-MY-SHOP-FULL-SOURCE.zip and current developer handoff. No production deployment or signing-key replacement. Actual phone/RTC validation remains required. Next changed release651.
