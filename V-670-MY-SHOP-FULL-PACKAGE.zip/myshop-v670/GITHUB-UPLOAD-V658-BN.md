# V658 থেকে APK
১. ZIP-এর নাম না বদলে V-658-MY-SHOP-FULL-SOURCE.zip আগের myshop24/MY-SHOP repository root-এ Upload files → Commit changes করুন।
২. Actions-এ MY SHOP PERMANENT RELEASE PIPELINE খুলুন। এর job WORKER VERIFY -> APK। pages build and deployment ওয়েবসাইটের কাজ, APK নয়।
৩. Android run নিজে না এলে একই workflow → Run workflow → main বেছে চালান। আগের root my-shop-release.sh ও .github/workflows/my-shop-apk.yml রাখতে হবে। ZIP-এর workflow আপলোডমাত্র নিজে root-এ বসে না।
৪. বর্তমান pipeline আগে Worker deploy করে, তারপর APK বানায়; পুরোনো Cloudflare/Firebase/signing Secrets ও original signing cache প্রয়োজন। হ্যান্ডঅফে setup আছে। কোনো secret প্রকাশ করবেন না।
৫. সফল658 Android run-এর নিচে Artifacts → MY-SHOP-FINAL-V-658 ডাউনলোড করুন। ভেতরে MY_SHOP_FINAL_RELEASE.apk পাবেন। version2.9.658/code658 এবং sourcecommit মিলিয়ে নিন। শুধু সবুজPages success APK তৈরি হওয়ার প্রমাণ নয়।
এই sourceZIP-এ আগে থেকেAPKনেই; এখানেAndroidcompile করা সম্ভব হয়নি। APKবিল্ডের ফলGitHubAndroidrun-এই যাচাই করতে হবে।
