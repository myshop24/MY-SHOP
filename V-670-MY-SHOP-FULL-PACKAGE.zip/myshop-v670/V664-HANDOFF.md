# MY SHOP V-664 handoff

Baseline: delivered V-663. Android 664 / 2.9.664; matching Worker V-664. Source package only; no signed APK or physical-phone acceptance is claimed.

## Corrections

- Gift cards and the central animation used android.R.id.text1 as a keyed View tag. Android rejects framework resource IDs for this API. The exception sent the card to plain-text fallback and the main animation to a small fallback banner before sound readiness. Both now use an app-owned resource ID. A regression test reproduces the old exception with Android's validation rule and executes the actual replacement statements.
- Main-stage gifts use at least 88% screen-width scale when animation is enabled; existing authored native timelines restart for the stage duration (6–15 seconds). The existing flower scene uses larger art. Existing remote animation assets are retained. This restores/expands authored media; it does not create new rigged 3D violin assets or claim pixel-identical reference quality.
- Animation readiness triggers gift sound once per event. Empty or failed URLs use existing appropriate local sound samples, with a local star fallback for unknown names. More mute/volume and Admin sound/animation-disable settings remain authoritative. Delayed audio callbacks cannot start after the room changes or closes.
- Immediate sender receipt uses an immutable normalized event, authoritative receiverNames and combo totals. Missing names display ID instead of a blank/wrong room title. The server event can enrich the same card without replaying the gift.
- Gift comment backgrounds use equipped custom design, chat skin, cosmetic skin or membership background, followed by existing assigned/global style. Read-only sender style metadata is available in recovery/snapshot and once before realtime fanout; a bounded five-second sender cache avoids per-viewer SQL. Optional style lookup failure never prevents fanout.
- Video publication now explicitly applies broadcaster/audience role, camera capture, publishCameraTrack and outgoing video mute state together. Capture/options/mute failures are checked, camera-toggle failures roll back, and periodic recovery restores a stuck outgoing mute only when camera consent is active. Existing remote UID binding/subscription paths remain. Real publish callbacks and technical diagnostics distinguish publication from self-preview. No automatic camera consent or mic unmute was introduced.
- Initial viewer heartbeat waits for the fresh-visit acknowledgement and simultaneous initial visit requests are guarded. Separate legitimate rejoin events remain supported.

## Preserved scope

Admin banners/seat appearance/settings (owner's excluded item 6), seat admission logic, avatar sizing/loading, financial gift methods, original signing and previous V663 features are preserved. No iOS work. No production push, deploy, Play upload or signing-key replacement was performed.

## Build and verification

Run `bash tools/prepare-build-assets.sh`, then `python3 tools/v664_prebuild_verify.py`. This executes all actual preBuild Exec gates; current targeted verification is `bash tools/v664_target_verify.sh`. Current results are in verification/V664-PREBUILD-RESULTS.json. Java parsing, callback audit, SDK transport-model tests, SQLite/Node regressions and source hashes are separate from Android compilation.

Gradle 8.11.1 download is blocked locally with Network is unreachable. A full Android build, signed APK, decoder/sound rendering, visual reference comparison and real Agora transport have not been verified on devices. The modeled 2–8 participant/audience tests cannot establish that production phone videos arrive.

Use the unchanged existing GitHub pipeline; upload instructions are GITHUB-UPLOAD-V664-BN.md. Preserve original signing/Firebase/Agora/Cloudflare secrets; dependency and deterministic media setup is in BUILD-ASSETS-BN.md and SIGNING-SETUP.md. The pipeline deploys the matching Worker before compiling Android; uploading can therefore change production backend. No secrets are included here.

## Required phone acceptance / next work

1. Two distinct phones: host + guest both camera ON; both see each other. A third audience phone sees both. Repeat for 3–8 publishers; check incoming video uses each real UID.
2. Camera OFF, front/back, permission denial, background/foreground, audience promotion/demotion and network reconnection: no unintended camera/mic enable, no stuck black/Connecting surface. Inspect publish state and SDK return code if delivery fails; verify matching Worker, session, publisher token and Agora configuration.
3. Send a rose and authored animated gift from different styled accounts: large moving art, audible sound at readiness, correct first-frame receiver, correct sender card color, exact combo counts, no extra charge/replayed animation on recovery. Confirm More mute/volume and explicit Admin disable remain effective.
4. First room entry produces one join; leaving and genuinely returning produces a new join.
5. Download exact APK 664/2.9.664; verify original signature, implementation markers, native alignment/page compatibility and actual APK size. Green GitHub status alone is insufficient.

Policy check: Google User Data policy requires camera/mic runtime permissions, expected-use consent, privacy disclosure and secure handling (https://support.google.com/googleplay/android-developer/answer/10144311?hl=en). Existing consent remains; this scoped repair adds no permissions. Full Data safety/UGC/payment/target SDK review and Play approval remain separate before submission; no future approval guarantee is made.

Verified local result: all 18 actual preBuild Exec gates passed, including all 148 Node tests, Java syntax/callback checks and the focused V664 tag/receipt/join/RTC-model/style tests. These results do not constitute an Android APK build or physical-device acceptance. No baseline source file was removed.
