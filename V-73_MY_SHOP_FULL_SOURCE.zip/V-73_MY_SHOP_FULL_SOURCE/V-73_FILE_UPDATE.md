# V-73 file update summary

- `app/build.gradle` — versionCode 72 → 73; versionName 2.9.72 → 2.9.73.
- `.github/workflows/my-shop-v73.yml` — V-73 one-APK workflow; cleans old APK outputs, validates the source, builds one release APK, verifies package/version metadata, creates one final APK and SHA-256, and fails if the final release directory contains anything other than one APK.
- `tools/validate_v73.py` — renamed/updated V-73 source validation.
- `SOURCE_BUILD_ID.txt` — V-73 source marker.
- Previous `app/src`, resources, assets, backend, design references, and existing working source are carried forward from the V-72 full source package without deletion.

## Important build note
The V-72 full-source archive available in the project did not contain the Gradle wrapper launcher files (`gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar`). V-73 therefore preserves the real source and uses GitHub Actions' Gradle 8.11.1 setup for the build. The wrapper properties file is included as a reference, but this archive should not be described as wrapper-complete until `gradlew`, `gradlew.bat`, and `gradle-wrapper.jar` are added.
