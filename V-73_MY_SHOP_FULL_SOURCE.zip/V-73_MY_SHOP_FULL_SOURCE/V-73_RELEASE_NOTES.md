# MY SHOP V-73 — Full Source Package

V-73 is a versioned full Android source package derived from the V-72 full source.

### Included
- Full `app/src` source tree
- Full Android resources/assets carried from V-72
- `backend/` carried forward
- `settings.gradle`
- root `build.gradle`
- `app/build.gradle`
- GitHub Actions V-73 workflow
- ONE APK guard
- V-73 versioning
- Existing design references and project documentation

### Build policy
The workflow uses Java 17, Android SDK 35, Build Tools 35.0.0 and Gradle 8.11.1. It builds one release APK and fails if more than one release APK is found. Final output is named `V-73 MY SHOP FINAL RELEASE.apk`.

### Permanent identity
This source package does not replace or reset the application's backend identity data. The existing source is carried forward. Cross-device permanent IDs still depend on the production backend being configured and connected; this package does not invent a cloud backend or claim data persistence that is not present in the source.
