# MY SHOP V-72

This is the V-72 full Android source package based on the latest V-71 full source.

## V-72 update
- Full Android project source package — not a patch-only ZIP.
- Version: `2.9.72`, versionCode `72`.
- GitHub Actions workflow: `.github/workflows/my-shop-v72.yml`.
- Java 17 + Android SDK 35 + Gradle 8.11.1.
- Exactly one release APK is required; the workflow fails on zero or multiple APKs.
- Final artifact: `V-72 MY SHOP FINAL RELEASE.apk`.
- SHA-256 checksum is uploaded beside the APK.
- Existing V-71 source package remains unchanged as a backup.

## Carried-forward application features
- Login/create-account flow with email or mobile option.
- Permanent-looking four-digit local user ID allocation starting at 0100.
- Three security questions and 2-of-3 password reset.
- Admin identifiers for the three configured admin accounts.
- Bengali / English / Hindi / Arabic language picker.
- Approved dashboard reference assets and clickable feature tiles.

## Build
From the repository root, GitHub Actions runs:
`Actions → MY SHOP V-72 ONE APK → Run workflow`

## Scope warning
The current account implementation contains a local fallback store. A true permanent cloud identity across reinstalls/devices requires the Cloudflare Worker + D1 backend milestone to be connected and tested. V-72 does not claim that cloud backend is already live.
