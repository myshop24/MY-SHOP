# MY SHOP V-178 — MASTER FINAL FIX CHECKLIST

1. **Button rendering / ripple:** Ripple feedback is now placed in the background instead of the foreground, so it cannot cover button/card text, icons, labels, or input controls.
2. **Hamburger / User Menu:** Three-line hamburger remains three-color; User Menu cards keep their semantic icons and visible text.
3. **MORE:** Facebook, Page, YouTube, WhatsApp, imo, Instagram, Telegram remain Admin-controlled; number/link normalization remains; Customer Support and Share App remain.
4. **External Movie:** Six slots, each with Caption + URL + SAVE/EDIT + DELETE, with server-backed `managedLinks`.
5. **Notifications:** Inbox keeps retry/error/empty-state handling and backend schema initialization.
6. **Profile:** `/v1/me` refreshes both dashboard header avatar and MY FEED composer avatar.
7. **Like + Comment:** Small 32dp actions; visible icon + label + counts; Comment count is now returned by Worker and updates after posting a comment.
8. **GO LIVE / JOIN LIVE:** Dashboard action labels are preserved and no longer get visually covered by ripple layers.
9. **Bottom navigation:** Home/Store/LIVE/Support/More icons and labels remain crisp; active Home background is visible and no longer covered by ripple.
10. **External/MORE/admin buttons:** Save, Edit, Delete, social cards, support and share controls now retain visible text.
11. **Performance:** Existing shared image executor/LRU cache and reduced feed reload behavior retained; comment count avoids a full feed reload.
12. **Dashboard layout:** Safe bottom spacing and responsive live/feed layout retained.
13. **Search:** Retained.
14. **MY FEED Share:** Intentionally absent. **MORE Share App:** retained.
15. **Store/Cart/Wishlist/Order Tracking:** future phase only; not added.
16. **Lightweight/free-tier:** No unnecessary heavy storage or new service dependency.

**Data safety:** No destructive auth/user-table migration added.
17. **Final quality / Play Store readiness:** Source, Worker, workflow, version locking, one-APK artifact rule and backend health verification retained.

VERSION: V-178 / app 2.9.178.
BACKEND: rapid-bush-62ea / my-shop-db / MEDIA.
