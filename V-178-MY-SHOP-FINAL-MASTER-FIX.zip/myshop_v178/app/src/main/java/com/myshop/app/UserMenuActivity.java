package com.myshop.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

/**
 * V-165: permanent USER MENU rule.
 * Profile belongs to the main dashboard left side and is never duplicated in this hamburger screen. The hamburger screen contains user features only.
 * This activity NEVER opens an Admin panel, even for an Admin account.
 */
public class UserMenuActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(247,248,252), DARK=Color.rgb(24,29,62), BLUE=Color.rgb(46,47,190), PURPLE=Color.rgb(83,32,180), RED=Color.rgb(210,45,55), MUTED=Color.rgb(95,99,115);

    @Override protected void onCreate(Bundle b){super.onCreate(b); build();}

    private void build(){
        LinearLayout root=col();
        root.setBackgroundColor(BG);
        root.setPadding(dp(12),dp(10),dp(12),dp(16));

        LinearLayout title=row();
        TextView close=button("‹",DARK,22); close.setOnClickListener(v->finish()); title.addView(close,lp(dp(40),dp(42)));
        TextView t=txt("MY SHOP",18,DARK,true); t.setGravity(Gravity.CENTER_VERTICAL); title.addView(t,weight(1,dp(42)));
        TextView lang=txt("🌐 "+code(),BLUE,9,true); lang.setGravity(Gravity.CENTER); lang.setBackground(bg(Color.rgb(245,246,255),Color.TRANSPARENT,12)); lang.setOnClickListener(v->LanguageManager.showPicker(this,()->recreate())); title.addView(lang,lp(dp(62),dp(38)));
        root.addView(title,lp(-1,dp(48)));

        TextView label=txt("USER MENU",11,PURPLE,true); label.setPadding(dp(4),dp(4),0,dp(6)); root.addView(label,lp(-1,dp(30)));
        EditText search=new EditText(this); search.setHint("Search"); search.setSingleLine(true); search.setTextSize(13); search.setPadding(dp(12),0,dp(12),0); search.setBackground(bg(Color.WHITE,Color.rgb(225,227,235),12)); root.addView(search,lp(-1,dp(46)));

        ScrollView scroll=new ScrollView(this); scroll.setVerticalScrollBarEnabled(false); scroll.setFillViewport(false);
        LinearLayout list=col();
        add(list,"HOME","Main dashboard",R.drawable.dash_action_feed,()->finish());
        add(list,"MY SHOP","Shop and products",R.drawable.dash_feat_shop,()->open("MY SHOP","my_shop"));
        add(list,"GALLERY","Photo • Audio • Video",R.drawable.dash_feat_gallery,()->startActivity(new Intent(this,GalleryActivity.class)));
        add(list,"EXTERNAL MOVIE","External movie links",R.drawable.dash_feat_movie,()->open("EXTERNAL MOVIE","external_movie"));
        add(list,"GO LIVE","Start a live stream",R.drawable.dash_action_go,()->open("GO LIVE","go_live"));
        add(list,"JOIN LIVE","Join a live stream",R.drawable.dash_action_live,()->open("JOIN LIVE","live_now"));
        add(list,"EARN & REWARD","Coins, gifts and rewards",R.drawable.dash_feat_reward,()->open("EARN & REWARD","earn_reward"));
        add(list,"LIVE TV","Live TV channels",R.drawable.dash_feat_tv,()->open("LIVE TV","live_tv"));
        add(list,"LIVE","Watch live streams",R.drawable.dash_action_live,()->open("LIVE","live_now"));
        add(list,"SOCIAL MEDIA","Facebook • YouTube • TikTok • Instagram",R.drawable.feature_social_selected,()->open("SOCIAL MEDIA","social_media"));
        add(list,"CHAT","Chat and messages",R.drawable.menu_chat,()->open("CHAT","chat"));
        add(list,"MUSIC","Music",R.drawable.menu_music,()->open("MUSIC","music"));
        add(list,"BREAKING NEWS","Latest headlines",R.drawable.menu_news,()->open("BREAKING NEWS","breaking_news"));
        add(list,"MORE APPS","Facebook • Page • YouTube • WhatsApp • imo • Instagram • Telegram",R.drawable.dash_feat_apps,()->open("MORE","more_apps"));
        add(list,"SHARE APP","Share MY SHOP",R.drawable.feature_share_selected,()->shareApp());
        add(list,"HELP & SUPPORT","WhatsApp customer support",R.drawable.menu_help,()->open("CUSTOMER SUPPORT","help_support"));
        add(list,"JOBS","Jobs and opportunities",R.drawable.menu_jobs,()->open("JOBS","jobs"));
        add(list,"COUPON","Coupons and offers",R.drawable.menu_coupon,()->open("COUPON","coupon"));
        add(list,"BOOKING","Bookings",R.drawable.menu_booking,()->open("BOOKING","booking"));
        add(list,"WALLET","Wallet and coins",R.drawable.menu_wallet,()->open("WALLET","wallet"));
        add(list,"SETTINGS","App settings",R.drawable.menu_settings,()->open("SETTINGS","settings"));
        add(list,"LANGUAGE","বাংলা • English • हिन्दी • العربية",R.drawable.menu_language,()->LanguageManager.showPicker(this,()->recreate()));
        add(list,"LOGOUT","Sign out of this device",R.drawable.menu_logout,()->logout());
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence q,int st,int b,int c){String ql=q.toString().trim().toLowerCase(); for(int i=0;i<list.getChildCount();i++){View v=list.getChildAt(i);Object tag=v.getTag();String title=tag==null?"":String.valueOf(tag);v.setVisibility(ql.isEmpty()||title.toLowerCase().contains(ql)?View.VISIBLE:View.GONE);}} public void afterTextChanged(android.text.Editable e){}});
        scroll.addView(list,new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    private void add(LinearLayout list,String title,String desc,int icon,Runnable action){
        LinearLayout c=col(); c.setPadding(dp(8),dp(5),dp(8),dp(5)); c.setBackground(bg(Color.WHITE,Color.rgb(224,226,235),14)); c.setElevation(dp(2)); if(android.os.Build.VERSION.SDK_INT>=21){android.graphics.drawable.Drawable base=c.getBackground();c.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(Color.argb(42,30,55,120)),base,null));}
        LinearLayout.LayoutParams cp=lp(-1,dp(66)); cp.bottomMargin=dp(7); c.setLayoutParams(cp);
        LinearLayout r=row(); FrameLayout ib=new FrameLayout(this); ib.setBackground(bg(Color.rgb(245,246,252),Color.rgb(230,232,240),12)); ImageView iv=new ImageView(this); iv.setImageResource(icon); iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE); iv.setColorFilter(BLUE); ib.addView(iv,new FrameLayout.LayoutParams(-1,-1)); r.addView(ib,lp(dp(48),dp(48)));
        LinearLayout b=col(); b.setPadding(dp(10),0,dp(4),0); TextView a=txt(title,11.5f,DARK,true); a.setGravity(Gravity.CENTER_VERTICAL); a.setSingleLine(true); b.addView(a,lp(-1,dp(25))); TextView d=txt(desc,8.5f,MUTED,false); d.setGravity(Gravity.CENTER_VERTICAL); d.setSingleLine(true); d.setEllipsize(android.text.TextUtils.TruncateAt.END); b.addView(d,lp(-1,dp(22))); r.addView(b,weight(1,dp(48))); TextView go=txt("›",BLUE,20,true); go.setGravity(Gravity.CENTER); r.addView(go,lp(dp(28),dp(48))); c.addView(r,lp(-1,dp(48))); c.setTag(title); c.setOnClickListener(v->action.run()); list.addView(c);
    }

    private void open(String title,String key){ Intent i=new Intent(this,FeatureActivity.class); i.putExtra("title",title); i.putExtra("feature_key",key); i.putExtra("user_menu",true); startActivity(i); }
    private void openCustomerSupport(){
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(org.json.JSONObject d){ org.json.JSONArray a=d.optJSONArray("managedLinks"); String url=""; if(a!=null)for(int i=0;i<a.length();i++){org.json.JSONObject x=a.optJSONObject(i);if(x!=null&&"help_support".equals(x.optString("category",""))){String u=x.optString("url","").trim();String n=normalizeWhatsApp(u);if(!n.isEmpty()){url=n;break;}}} final String target=url; runOnUiThread(()->{if(!target.isEmpty()){try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(target)));}catch(Exception e){Toast.makeText(UserMenuActivity.this,"Unable to open support.",Toast.LENGTH_SHORT).show();}}else Toast.makeText(UserMenuActivity.this,"Customer support is not configured yet.",Toast.LENGTH_SHORT).show();}); }
            public void onError(String m){runOnUiThread(()->Toast.makeText(UserMenuActivity.this,"Customer support unavailable.",Toast.LENGTH_SHORT).show());}
        });
    }
    private String normalizeWhatsApp(String raw){String v=raw==null?"":raw.trim();if(v.isEmpty())return "";if(v.startsWith("http://")||v.startsWith("https://"))return v;String digits=v.replaceAll("[^0-9]","");return digits.length()>=8?"https://wa.me/"+digits:"";}
    private void shareApp(){try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"MY SHOP");i.putExtra(Intent.EXTRA_TEXT,"MY SHOP — https://rapid-bush-62ea.myshopsatkania.workers.dev");startActivity(Intent.createChooser(i,"Share MY SHOP"));}catch(Exception e){Toast.makeText(this,"Share is not available.",Toast.LENGTH_SHORT).show();}}
    private void logout(){String token=SessionManager.getToken(this);SessionManager.clear(this);Intent i=new Intent(this,LoginActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(i);if(token!=null&&!token.isEmpty())BackendClient.logout(token,new BackendClient.Callback(){public void onSuccess(org.json.JSONObject d){}public void onError(String m){}});}
    private void loadRemoteImage(ImageView target,String url){new Thread(()->{try{java.net.HttpURLConnection c=(java.net.HttpURLConnection)new java.net.URL(url).openConnection();c.setConnectTimeout(3000);c.setReadTimeout(5000);try(java.io.InputStream in=c.getInputStream()){android.graphics.Bitmap bm=android.graphics.BitmapFactory.decodeStream(in);if(bm!=null)runOnUiThread(()->target.setImageBitmap(bm));}}catch(Exception ignored){}}).start();}
    private String code(){String l=LanguageManager.get(this);if(LanguageManager.EN.equals(l))return "EN";if(LanguageManager.HI.equals(l))return "HI";if(LanguageManager.AR.equals(l))return "AR";return "বাং";}
    private TextView button(String s,int c,float z){TextView b=new TextView(this);b.setText(s);b.setTextColor(c);b.setTextSize(z);b.setGravity(Gravity.CENTER);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return b;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView txt(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}
    private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}
    private View topWrap(View v,int m){v.setLayoutParams(top(lp(-1,dp(32)),m));return v;}
    private GradientDrawable bg(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
