# MY SHOP V-73 — SINGLE FULL SOURCE PACKAGE

একটি ZIP-এর মধ্যেই সম্পূর্ণ V-73 source রাখা হয়েছে। আলাদা workflow ZIP নেই।

Included:
- gradlew
- gradlew.bat
- gradle/wrapper/gradle-wrapper.properties
- settings.gradle
- root build.gradle
- app/build.gradle
- complete app/src (including resources and assets)
- GitHub Actions: .github/workflows/my-shop-v73.yml
- existing V-73 working source
- V-73 versionCode/versionName
- ONE APK guard

V-73 workflow corrections in this package:
- validate_v72.py reference corrected to validate_v73.py
- APK metadata check corrected from versionCode 72 to versionCode 73
- Final APK remains exactly one: V-73 MY SHOP FINAL RELEASE.apk

Note: GitHub Actions uses Gradle 8.11.1 via gradle/actions/setup-gradle, so the workflow does not depend on a locally installed Gradle distribution.
