@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle 8.11.1 is required. GitHub Actions installs it automatically; for local builds install Gradle 8.11.1 or use Android Studio.
exit /b 1
