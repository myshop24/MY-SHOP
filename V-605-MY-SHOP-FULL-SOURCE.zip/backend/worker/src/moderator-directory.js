// Read-only owner directory. Never edits Live, roles, financial or private recovery data.
export async function moderatorDirectory(request,env,h){
 const fail=(error,status)=>h.json({error},status,h.cors);
 const actor=await h.getUser(request,env);if(!actor)return fail('UNAUTHORIZED',401);
 const current=await env.DB.prepare('SELECT active,role FROM myshop_auth_users_v108 WHERE user_id=?').bind(actor.user_id).first();
 if(!['0001','0002','0003'].includes(String(actor.user_id))||Number(current?.active)!==1||current?.role!=='ADMIN')return fail('MAIN_ADMIN_ONLY',403);
 if(request.method!=='GET')return fail('METHOD_NOT_ALLOWED',405);
 const p=new URL(request.url).searchParams,uid=p.get('userId')||'',q=(p.get('q')||'').trim(),after=p.get('after')||'',status=p.get('status')||'ALL',scope=p.get('scope')||'';
 if(uid&&!/^\d{4}$/.test(uid)||after&&!/^\d{4}$/.test(after)||q.length>100||!['ALL','ACTIVE','INACTIVE'].includes(status)||!['','folders'].includes(scope)||scope&&uid)return fail('INVALID_DIRECTORY_QUERY',400);
 const DB=env.DB,tables=new Set(((await DB.prepare("SELECT name FROM sqlite_master WHERE type='table'").all()).results||[]).map(r=>r.name));
 const hasRegistry=tables.has('myshop_moderators_v108'),hasGrants=tables.has('myshop_folder_grants');
 if(scope==='folders'){
  const folders=new Map([['feature_live_streaming',{folder:'feature_live_streaming',title:'Live Streaming • লাইভ পরিচালনা'}]]),add=(folder,title)=>{if(!/^feature_[a-z0-9_]{1,80}$/.test(folder)||/(?:^|_)(?:live|rtc|audio|gift|gifts|room)(?:_|$)/.test(folder)||['feature_go_live','feature_top_gifters'].includes(folder))return;if(!folders.has(folder)||title)folders.set(folder,{folder,title:String(title||folder.replace(/^feature_/,'').replaceAll('_',' ')).slice(0,100)});};
  if(tables.has('managed_links'))for(const row of (await DB.prepare("SELECT category,title FROM managed_links WHERE category LIKE 'feature_%' ORDER BY id LIMIT 500").all()).results||[])add(String(row.category),row.title);
  if(tables.has('feature_buttons'))for(const row of (await DB.prepare("SELECT key,title FROM feature_buttons WHERE key LIKE 'home1_%' ORDER BY display_order,key LIMIT 200").all()).results||[])add('feature_'+row.key,folders.get('feature_'+row.key)?.title||row.title);
  if(hasGrants)for(const row of (await DB.prepare('SELECT DISTINCT folder FROM myshop_folder_grants ORDER BY folder LIMIT 500').all()).results||[])if(!folders.has(row.folder))add(row.folder,'');
  return h.json({ok:true,folders:[...folders.values()].sort((a,b)=>a.folder.localeCompare(b.folder)),actions:['view','save_draft'],readOnly:true},200,h.cors);
 }
 const registry=hasRegistry?'COALESCE(m.active,0)':'0',join=hasRegistry?' LEFT JOIN myshop_moderators_v108 m ON m.user_id=u.user_id ':'';
 const projection=`u.user_id,u.full_name,u.avatar_url,u.role,u.active account_active,${registry} moderator_active`;
 if(uid){
  const user=await DB.prepare(`SELECT ${projection} FROM myshop_auth_users_v108 u ${join} WHERE u.user_id=?`).bind(uid).first();
  if(!user)return fail('USER_NOT_FOUND',404);
  const grants=hasGrants?(await DB.prepare('SELECT folder,action,enabled,revision FROM myshop_folder_grants WHERE user_id=? ORDER BY folder,action LIMIT 200').bind(uid).all()).results||[]:[];
  return h.json({ok:true,user,grants,protectedAdmin:['0001','0002','0003'].includes(uid)||user.role==='ADMIN',readOnly:true},200,h.cors);
 }
 // SQL parameters + instr give literal search: %/_ are not wildcard permissions.
 const where=`(u.role='MODERATOR'${hasRegistry?' OR m.user_id IS NOT NULL':''}) AND u.user_id>? AND (?='' OR instr(lower(u.full_name),lower(?))>0 OR instr(u.user_id,?)>0) AND (?='ALL' OR (?='ACTIVE' AND u.active=1 AND ${registry}=1 AND u.role='MODERATOR') OR (?='INACTIVE' AND NOT(u.active=1 AND ${registry}=1 AND u.role='MODERATOR')))`;
 const found=(await DB.prepare(`SELECT ${projection} FROM myshop_auth_users_v108 u ${join} WHERE ${where} ORDER BY u.user_id LIMIT 51`).bind(after,q,q,q,status,status,status).all()).results||[];
 const more=found.length>50,moderators=found.slice(0,50);
 return h.json({ok:true,moderators,nextAfter:more?moderators[49].user_id:null,readOnly:true},200,h.cors);
}
