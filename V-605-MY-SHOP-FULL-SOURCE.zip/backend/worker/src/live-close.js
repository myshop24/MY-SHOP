// Database close + history + temporary session cleanup commit together.
export async function closeLive(DB,host){
 const m=await DB.prepare("SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?").bind(host).first();
 const session=String(m?.session_id||'');
 const guard='EXISTS(SELECT 1 FROM myshop_live_room_meta WHERE host_id=? AND COALESCE(session_id,\'\')=?)';
 if(m){const statements=[
 DB.prepare(`INSERT INTO myshop_live_history(host_id,title,topic,started_at,ended_at,duration_seconds,peak_viewers,total_listeners,share_count,react_count,react_reward_coin,session_id)
 SELECT host_id,title,topic,started_at,CURRENT_TIMESTAMP,MAX(0,COALESCE(CAST((julianday('now')-julianday(started_at))*86400 AS INTEGER),0)),peak_viewers,(SELECT COUNT(*) FROM myshop_live_listener_seen s WHERE s.host_id=m.host_id AND s.started_at=m.started_at),share_count,COALESCE(react_count,0),COALESCE(react_reward_milestone,0)*1000,COALESCE(session_id,'') FROM myshop_live_room_meta m WHERE host_id=? AND COALESCE(session_id,'')=? AND COALESCE(started_at,'')<>'' AND NOT EXISTS(SELECT 1 FROM myshop_live_history h WHERE h.host_id=m.host_id AND h.session_id=COALESCE(m.session_id,''))`).bind(host,session),
 DB.prepare(`UPDATE myshop_live_presence SET active=0,viewer_count=0,last_seen=CURRENT_TIMESTAMP WHERE user_id=? AND ${guard}`).bind(host,host,session),
 ...['myshop_live_comments','myshop_live_highlight_comments'].map(t=>DB.prepare(`DELETE FROM ${t} WHERE host_id=? AND session_id=? AND ${guard}`).bind(host,session,host,session)),
 ...['myshop_live_seats_dynamic','myshop_live_requests','myshop_live_invites','myshop_live_viewers','myshop_live_seat_locks'].map(t=>DB.prepare(`DELETE FROM ${t} WHERE host_id=? AND ${guard}`).bind(host,host,session)),
 DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND state IN ('MUTED','KICKED') AND ${guard}`).bind(host,host,session),
 DB.prepare(`UPDATE myshop_live_schedules SET status='ENDED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND status='LIVE' AND ${guard}`).bind(host,host,session),
 DB.prepare(`UPDATE myshop_live_pk_rounds SET status='ENDED',ended_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE status='ACTIVE' AND (host_a=? OR host_b=?) AND ${guard}`).bind(host,host,host,session),
 DB.prepare("DELETE FROM myshop_live_room_meta WHERE host_id=? AND COALESCE(session_id,'')=?").bind(host,session)];await DB.batch(statements);
 }else await DB.prepare('UPDATE myshop_live_presence SET active=0,viewer_count=0 WHERE user_id=? AND NOT EXISTS(SELECT 1 FROM myshop_live_room_meta WHERE host_id=?)').bind(host,host).run();
 const state=await DB.prepare('SELECT active FROM myshop_live_presence WHERE user_id=?').bind(host).first();
 const summary=await DB.prepare('SELECT * FROM myshop_live_history WHERE host_id=? ORDER BY id DESC LIMIT 1').bind(host).first();
 return {ok:true,closed:Number(state?.active||0)!==1,sessionId:session,summary:summary||null};
}
