// Cache initialization promises only, never auth, permission, balance or user data.
const dbs=new WeakMap();
export function schemaOnce(DB,key,initialize){if(!DB)return Promise.reject(Error('D1_NOT_CONFIGURED'));let m=dbs.get(DB);if(!m){m=new Map();dbs.set(DB,m);}let p=m.get(key);if(!p){p=Promise.resolve().then(initialize).catch(e=>{m.delete(key);throw e;});m.set(key,p);}return p;}
export async function measureResult(env,label,promise){const r=await promise;if(String(env.D1_DIAGNOSTICS||'')==='1')console.info(JSON.stringify({kind:'D1_READ',query:label,rowsRead:Number(r?.meta?.rows_read||0),rowsWritten:Number(r?.meta?.rows_written||0),durationMs:Number(r?.meta?.duration||0)}));return r;}
