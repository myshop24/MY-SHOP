package com.myshop.app;

import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputFilter;
import android.widget.*;
import org.json.*;

/** Owner management uses the existing audited role API; folder grants remain separate. */
public final class AdminModeratorActivity extends androidx.appcompat.app.AppCompatActivity {
 private LinearLayout entries;
 private TextView status;
 private EditText search;
 private Spinner filter;
 private Button more;
 private String cursor="",query="",state="ALL";
 private int listGeneration,lookupGeneration;
 private boolean changing;
 private final java.util.ArrayList<JSONObject> loaded=new java.util.ArrayList<>();
 @Override protected void onCreate(Bundle saved){super.onCreate(saved);
  if(!SessionManager.isAdmin(this)||!SessionManager.isAdminGateUnlocked()||!java.util.Arrays.asList("0001","0002","0003").contains(SessionManager.getUserId(this))){finish();return;}
  ScrollView scroll=new ScrollView(this);LinearLayout root=column();root.setPadding(dp(16),dp(18),dp(16),dp(24));root.setBackgroundColor(0xfff4f7fd);scroll.addView(root);
  root.addView(text("মডারেটর পরিচালনা",23,0xff102650,true));root.addView(text("তালিকা → ইউজার যাচাই → নিয়োগ / সরানো → ফোল্ডার অনুমতি",12,0xff5c6b82,false));
  root.addView(button("ফিরে যান",this::finish));
  search=new EditText(this);search.setHint("মডারেটরের নাম বা ID লিখুন");search.setSingleLine(true);search.setFilters(new InputFilter[]{new InputFilter.LengthFilter(100)});root.addView(search);
  filter=new Spinner(this);filter.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"সব মডারেটর","সক্রিয়","নিষ্ক্রিয় / সরানো"}));root.addView(filter);
  root.addView(button("খুঁজুন / তালিকা আবার দেখুন",()->{query=search.getText().toString().trim();state=new String[]{"ALL","ACTIVE","INACTIVE"}[filter.getSelectedItemPosition()];load(false);}));
  root.addView(button("＋ ইউজার ID দিয়ে মডারেটর যোগ",this::selectUser));
  root.addView(text("স্থায়ী Admin ID ও অ্যাকাউন্ট মুছে যাবে না। মডারেটর সরালে তার ফোল্ডার অনুমতি বাতিল হবে।",12,0xff5c6b82,false));
  status=text("",13,0xff29466f,false);root.addView(status);entries=column();root.addView(entries);
  more=button("আরও দেখুন",()->load(true));more.setVisibility(android.view.View.GONE);root.addView(more);
  scroll.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(i.getSystemWindowInsetLeft(),i.getSystemWindowInsetTop(),i.getSystemWindowInsetRight(),i.getSystemWindowInsetBottom());return i;});setContentView(scroll);scroll.requestApplyInsets();
  if(saved!=null){query=saved.getString("query","");state=saved.getString("status","ALL");search.setText(query);filter.setSelection("ACTIVE".equals(state)?1:"INACTIVE".equals(state)?2:0);}load(false);
 }
 private boolean alive(){return !isFinishing()&&!isDestroyed();}
 private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 private LinearLayout column(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
 private TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,dp(5),0,dp(5));if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
 private Button button(String label,Runnable action){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff1768db));b.setOnClickListener(v->action.run());return b;}
 private String token(){return SessionManager.getToken(this);}
 private String encoded(String value){try{return java.net.URLEncoder.encode(value,"UTF-8");}catch(Exception e){throw new IllegalArgumentException(e);}}
 private void load(boolean append){final int generation=++listGeneration;final String before=append?cursor:"";if(append&&before.isEmpty())return;more.setEnabled(false);status.setText("তালিকা লোড হচ্ছে…");
  BackendClient.adminModeratorDirectory(token(),"q="+encoded(query)+"&status="+state+"&after="+before,new BackendClient.Callback(){public void onError(String error){runOnUiThread(()->{if(!alive()||generation!=listGeneration)return;more.setEnabled(true);status.setText("তালিকা পাওয়া যায়নি: "+error+" • আবার দেখুন চাপুন");});}public void onSuccess(JSONObject result){runOnUiThread(()->{if(!alive()||generation!=listGeneration)return;JSONArray rows=result.optJSONArray("moderators");if(rows==null){status.setText("তালিকার উত্তর সঠিক নয়; আবার চেষ্টা করুন");more.setEnabled(true);return;}if(!append)loaded.clear();for(int i=0;i<rows.length();i++){JSONObject row=rows.optJSONObject(i);if(row!=null)loaded.add(row);}cursor=result.isNull("nextAfter")?"":result.optString("nextAfter","");render();more.setEnabled(true);more.setVisibility(cursor.isEmpty()?android.view.View.GONE:android.view.View.VISIBLE);});}});
 }
 private void render(){entries.removeAllViews();status.setText(loaded.isEmpty()?"এই বাছাইয়ে কোনো মডারেটর নেই।":"দেখানো হয়েছে: "+loaded.size()+" জন • নাম চাপলে পরিচালনা খুলবে");
  for(JSONObject row:loaded){final String uid=row.optString("user_id");boolean active=row.optInt("account_active")==1&&row.optInt("moderator_active")==1&&"MODERATOR".equals(row.optString("role"));LinearLayout card=column();card.setPadding(dp(12),dp(8),dp(12),dp(8));GradientDrawable bg=new GradientDrawable();bg.setColor(Color.WHITE);bg.setCornerRadius(dp(12));card.setBackground(bg);card.addView(text(row.optString("full_name","ইউজার")+" • ID "+uid,17,0xff152a50,true));card.addView(text(active?"সক্রিয় মডারেটর":"নিষ্ক্রিয় / ভূমিকা সরানো",12,active?0xff14864e:0xffb12747,false));card.addView(button("পরিচালনা / অনুমতি",()->lookup(uid)));if(!java.util.Arrays.asList("0001","0002","0003").contains(uid))card.addView(button(active?"Remove • ভূমিকা সরান":"পুনরায় নিয়োগ",()->confirmChange(uid,row.optString("full_name"),!active)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(10);entries.addView(card,p);}
 }
 private void selectUser(){EditText id=new EditText(this);id.setHint("চার সংখ্যার ইউজার ID • যেমন 0104");id.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);id.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});new MyShopDialogBuilder(this).setTitle("ইউজার বাছাই করুন").setView(id).setNegativeButton("বাতিল",null).setPositiveButton("ইউজার যাচাই",(d,w)->{String uid=id.getText().toString().trim();if(!uid.matches("[0-9]{4}")){status.setText("সঠিক চার সংখ্যার ID দিন");return;}lookup(uid);}).show();}
 private void lookup(String uid){if(changing)return;final int generation=++lookupGeneration;status.setText("ID "+uid+" যাচাই হচ্ছে…");BackendClient.adminModeratorDirectory(token(),"userId="+uid,new BackendClient.Callback(){public void onError(String error){runOnUiThread(()->{if(alive()&&generation==lookupGeneration)status.setText("ইউজার পাওয়া যায়নি: "+error);});}public void onSuccess(JSONObject data){runOnUiThread(()->{if(!alive()||generation!=lookupGeneration)return;JSONObject user=data.optJSONObject("user");if(user==null||!uid.equals(user.optString("user_id"))){status.setText("ইউজার যাচাই হয়নি");return;}showUser(user,data.optBoolean("protectedAdmin"));});}});}
 private void showUser(JSONObject user,boolean protectedAdmin){String uid=user.optString("user_id"),name=user.optString("full_name","ইউজার");LinearLayout box=column();box.addView(text(name+" • ID "+uid,19,0xff142850,true));boolean assigned=user.optInt("moderator_active")==1;box.addView(text("ভূমিকা: "+user.optString("role")+" • অ্যাকাউন্ট: "+(user.optInt("account_active")==1?"সক্রিয়":"বন্ধ"),12,0xff5c6b82,false));
  if(protectedAdmin)box.addView(text("সুরক্ষিত Admin: এই প্যানেল থেকে ভূমিকা পরিবর্তন করা যাবে না।",14,0xffb12747,true));
  else{if(assigned){box.addView(button("মডারেটর ভূমিকা সরান",()->confirmChange(uid,name,false)));if("MODERATOR".equals(user.optString("role"))&&user.optInt("account_active")==1)box.addView(button("ফোল্ডার অনুমতি সম্পাদনা",()->startActivity(new Intent(this,AssignedAdminFoldersActivity.class).putExtra("moderator_id",uid))));}else if(user.optInt("account_active")==1)box.addView(button("মডারেটর হিসেবে নিয়োগ দিন",()->confirmChange(uid,name,true)));else box.addView(text("বন্ধ অ্যাকাউন্টে নতুন মডারেটর নিয়োগ হবে না।",13,0xffb12747,false));}
  box.addView(text("ফোল্ডার অনুমতিতে দেখা ও ব্যক্তিগত Draft Save আলাদা। Publish ও অর্থ ব্যবস্থাপনার অনুমতি এতে যোগ হয় না।",12,0xff5c6b82,false));new MyShopDialogBuilder(this).setTitle("মডারেটর পরিচালনা").setView(box).setNegativeButton("বন্ধ করুন",null).show();status.setText("ID "+uid+" যাচাই হয়েছে");
 }
 private void confirmChange(String uid,String name,boolean add){if(changing)return;EditText reason=new EditText(this);reason.setHint("কেন নিয়োগ / সরাচ্ছেন • অ্যাডমিন নোট");reason.setFilters(new InputFilter[]{new InputFilter.LengthFilter(300)});new MyShopDialogBuilder(this).setTitle(add?"মডারেটর নিয়োগ করবেন?":"মডারেটর সরাবেন?").setMessage(name+" • ID "+uid+"\n"+(add?"বিদ্যমান মডারেটর ভূমিকা দেওয়া হবে।":"ভূমিকা ও ফোল্ডার অনুমতি সরবে; ইউজারের অ্যাকাউন্ট থাকবে।")).setView(reason).setNegativeButton("বাতিল",null).setPositiveButton("নিশ্চিত করুন",(d,w)->{String note=reason.getText().toString().trim();if(note.isEmpty()){status.setText("কারণ লিখে আবার নিশ্চিত করুন");return;}change(uid,add,note);}).show();}
 private void change(String uid,boolean add,String note){if(changing)return;changing=true;status.setText("পরিবর্তন সংরক্ষণ হচ্ছে…");BackendClient.adminModeratorChange(token(),uid,add?"add_moderator":"remove_moderator",note,new BackendClient.Callback(){public void onError(String error){runOnUiThread(()->{changing=false;if(alive())status.setText("সংরক্ষণ হয়নি: "+error);});}public void onSuccess(JSONObject data){runOnUiThread(()->{changing=false;if(!alive())return;Toast.makeText(AdminModeratorActivity.this,add?"মডারেটর নিয়োগ সংরক্ষিত":"ভূমিকা সরানো হয়েছে; অ্যাকাউন্ট আছে",Toast.LENGTH_LONG).show();load(false);});}});}
 @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);out.putString("query",query);out.putString("status",state);}
}
