package com.myshop.app;

import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.Window;
import android.widget.*;
import org.json.*;

/** myshop V-516: General directory reference-parity, real backend data. */
public class GeneralUsersActivity extends androidx.appcompat.app.AppCompatActivity {
    private LinearLayout list; private EditText search; private String token;
    private String selectedMembership="";private int requestGeneration,nextOffset;private boolean loading,hasMore;private JSONArray directory=new JSONArray();private final java.util.Map<String,View> tabLines=new java.util.HashMap<>();
    private final int BG=Color.rgb(248,251,255), NAVY=Color.rgb(14,25,70), BLUE=Color.rgb(38,103,235), MUTED=Color.rgb(99,105,129), GREEN=Color.rgb(15,173,110), RED=Color.rgb(238,36,75);
    private final int[][] CARD_COLORS={{0xffff00be,0xff8b00ff},{0xff007bff,0xff12cce0},{0xff33ee00,0xff0a9d3e},{0xff6d00ff,0xffd400ff},{0xffffb100,0xffff5d00},{0xffff009d,0xffd500ff}};

    @Override protected void onCreate(Bundle b){super.onCreate(b);token=SessionManager.getToken(this);setContentView(build());load();}

    private View build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(BG);
        LinearLayout fixed=col(); fixed.setPadding(dp(4),dp(6),dp(4),0); fixed.addView(header(),lp(-1,dp(58))); fixed.addView(breaking(),top(lp(-1,dp(42)),5));
        ScrollView scroll=new ScrollView(this); scroll.setVerticalScrollBarEnabled(false); scroll.setFillViewport(true);
        LinearLayout body=col(); fixed.addView(topMenu("General"),lp(-1,dp(58)));scroll.setPadding(0,dp(169),0,dp(78));scroll.setClipToPadding(false);
        LinearLayout content=col(); content.setPadding(dp(6),dp(4),dp(6),dp(78));
        LinearLayout searchRow=row(); searchRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView refresh=t("⟳",23,BLUE,true); refresh.setGravity(Gravity.CENTER); refresh.setOnClickListener(v->load()); searchRow.addView(refresh,lp(dp(42),dp(42)));
        search=tEdit("Search myshop ID",true); searchRow.addView(search,weight(1,dp(42)));
        TextView go=t("SEARCH",9.2f,Color.WHITE,true); go.setGravity(Gravity.CENTER); go.setBackground(gradient(new int[]{0xff1877f2,0xff7e35e8},12)); go.setOnClickListener(v->search()); searchRow.addView(go,lp(dp(82),dp(38))); content.addView(searchRow,lp(-1,dp(44)));
        TextView hint=t("New members appear at the front; older members move backward automatically.",8.6f,MUTED,false); hint.setGravity(Gravity.CENTER); content.addView(hint,top(lp(-1,dp(28)),2));
        list=col(); content.addView(list,lp(-1,-2)); body.addView(content,lp(-1,-2)); scroll.addView(body,new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll,new FrameLayout.LayoutParams(-1,-1)); root.addView(fixed,new FrameLayout.LayoutParams(-1,dp(169),Gravity.TOP));
        View nav=bottomNav(); FrameLayout.LayoutParams np=new FrameLayout.LayoutParams(-1,dp(78),Gravity.BOTTOM); root.addView(nav,np);
        root.setOnApplyWindowInsetsListener((v,in)->{int ti=Math.max(0,in.getSystemWindowInsetTop()),bi=Math.max(0,in.getSystemWindowInsetBottom());fixed.setPadding(dp(4),ti+dp(6),dp(4),0);FrameLayout.LayoutParams fp=(FrameLayout.LayoutParams)fixed.getLayoutParams();fp.height=ti+dp(169);scroll.setPadding(0,ti+dp(169),0,dp(78)+bi);fixed.setLayoutParams(fp);np.bottomMargin=Math.max(0,bi);nav.setLayoutParams(np);return in;}); root.post(root::requestApplyInsets); return root;
    }

    private View header(){SharedPageHeader h=new SharedPageHeader(this);return h;}
    private FrameLayout headerAction(int res,String desc,boolean tint){FrameLayout box=new FrameLayout(this);ImageView im=new ImageView(this);im.setImageResource(res);im.setScaleType(ImageView.ScaleType.CENTER_INSIDE);if(tint)im.setImageTintList(android.content.res.ColorStateList.valueOf(Color.WHITE));box.addView(im,new FrameLayout.LayoutParams(-1,-1));return box;}
    private View breaking(){LinearLayout b=row();b.setPadding(dp(4),0,dp(4),0);b.setBackground(round(0xfffff1f7,0xffffc8db,9));TextView icon=t("📣",25,RED,true);icon.setGravity(Gravity.CENTER);b.addView(icon,lp(dp(48),dp(40)));TextView tx=t("shop অ্যাপের উন্নয়ন ও নতুন ফিচার যুক্ত করার কাজ",13.5f,RED,true);tx.setSingleLine(true);tx.setEllipsize(TextUtils.TruncateAt.MARQUEE);tx.setSelected(true);tx.setMarqueeRepeatLimit(-1);b.addView(tx,weight(1,dp(40)));return b;}
    private View topMenu(String selected){
        LinearLayout bar=row();bar.setGravity(Gravity.CENTER_VERTICAL);bar.setBackgroundColor(Color.WHITE);
        TextView menu=t("☰",28,BLUE,true);menu.setGravity(Gravity.CENTER);menu.setOnClickListener(v->showMenu());bar.addView(menu,lp(dp(48),dp(58)));
        HorizontalScrollView sc=new HorizontalScrollView(this);sc.setHorizontalScrollBarEnabled(false);LinearLayout tabs=row();
        for(String label:new String[]{"General","KING","QUEEN","ROYAL","VVIP","VIP"}){
            final String tier="General".equals(label)?"":label;LinearLayout cell=col();cell.setGravity(Gravity.CENTER);
            TextView text=t(label,11.2f,NAVY,true);text.setGravity(Gravity.CENTER);cell.addView(text,lp(dp(69),dp(51)));
            View line=new View(this);line.setBackgroundColor(tier.equals(selectedMembership)?BLUE:Color.TRANSPARENT);cell.addView(line,lp(dp(52),dp(4)));tabLines.put(tier,line);
            cell.setOnClickListener(v->{if(tier.equals(selectedMembership))return;selectedMembership=tier;for(java.util.Map.Entry<String,View> e:tabLines.entrySet())e.getValue().setBackgroundColor(e.getKey().equals(tier)?BLUE:Color.TRANSPARENT);load();});
            tabs.addView(cell,lp(dp(69),dp(58)));
        }
        sc.addView(tabs);bar.addView(sc,weight(1,dp(58)));return bar;
    }
    private void showMenu(){startActivity(new Intent(this,UserMenuActivity.class));}

    private void load(){directory=new JSONArray();nextOffset=0;hasMore=false;loadPage(false);}
    private void loadPage(boolean append){
        if(append&&loading)return;loading=true;final int generation=++requestGeneration;final String tier=selectedMembership;
        if(!append){list.removeAllViews();TextView wait=t("Loading users…",11,MUTED,false);wait.setGravity(Gravity.CENTER);list.addView(wait,lp(-1,dp(100)));}
        BackendClient.membershipPeople(token,tier,60,nextOffset,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{
            if(isFinishing()||isDestroyed()||generation!=requestGeneration)return;loading=false;
            if(!tier.isEmpty()&&!tier.equals(d.optString("membershipFilter",""))){
                list.removeAllViews();TextView update=t("Matching backend update required · Tap to retry",11,BLUE,true);update.setGravity(Gravity.CENTER);update.setOnClickListener(v->load());list.addView(update,lp(-1,dp(120)));return;
            }
            JSONArray rows=d.optJSONArray("people");if(rows!=null)for(int i=0;i<rows.length();i++)directory.put(rows.opt(i));
            hasMore=d.optBoolean("hasMore",false);nextOffset=d.optInt("nextOffset",directory.length());render(directory);
        });}public void onError(String message){runOnUiThread(()->{
            if(isFinishing()||isDestroyed()||generation!=requestGeneration)return;loading=false;render(directory);
            TextView retry=t("Could not load users · Tap to retry",11,BLUE,true);retry.setGravity(Gravity.CENTER);retry.setOnClickListener(v->loadPage(append));list.addView(retry,lp(-1,dp(48)));
        });}});
    }
    private void render(JSONArray a){list.removeAllViews();if(a==null||a.length()==0){TextView e=t("No users are available yet.",11,MUTED,false);e.setGravity(Gravity.CENTER);list.addView(e,lp(-1,dp(140)));return;}GridLayout grid=new GridLayout(this);grid.setColumnCount(2);for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;grid.addView(userCard(x,i),cardParams(i));}list.addView(grid,lp(-1,-2));if(hasMore){TextView more=t("LOAD MORE",12,BLUE,true);more.setGravity(Gravity.CENTER);more.setOnClickListener(v->loadPage(true));list.addView(more,lp(-1,dp(48)));}}
    private GridLayout.LayoutParams cardParams(int i){GridLayout.LayoutParams gp=new GridLayout.LayoutParams(GridLayout.spec(i/2,1f),GridLayout.spec(i%2,1f));gp.width=0;gp.height=dp(124);gp.setMargins(dp(4),dp(4),dp(4),dp(4));return gp;}
    private View userCard(JSONObject x,int index){
        final String id=x.optString("userId","");FrameLayout card=new FrameLayout(this);card.setBackground(gradient(CARD_COLORS[index%CARD_COLORS.length],14));
        LinearLayout inner=col();inner.setPadding(dp(7),dp(7),dp(7),dp(7));LinearLayout identity=row();identity.setGravity(Gravity.CENTER_VERTICAL);
        ImageView photo=new ImageView(this);photo.setImageResource(R.drawable.myshop_profile_avatar);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);photo.setBackground(round(Color.WHITE,Color.WHITE,30));photo.setClipToOutline(true);String avatar=x.optString("avatarUrl","");if(!avatar.isEmpty())loadImage(photo,avatar);identity.addView(photo,lp(dp(52),dp(52)));photo.setOnClickListener(v->open(id));
        LinearLayout details=col();details.setPadding(dp(6),0,0,0);String actualName=x.optString("name","myshop User");TextView name=t(actualName,11,0xfffff400,true);name.setSingleLine(true);name.setEllipsize(TextUtils.TruncateAt.END);AuthorityBadge.decorate(name,id);details.addView(name,lp(-1,dp(24)));details.addView(t("ID : "+id,10,Color.WHITE,true),lp(-1,dp(18)));details.addView(t("Vote : "+x.optInt("vote",0),10,0xfffff400,true),lp(-1,dp(18)));identity.addView(details,weight(1,dp(64)));inner.addView(identity,lp(-1,dp(64)));
        LinearLayout actions=row();actions.addView(buttonFriend(x,id),weight(1,dp(32)));actions.addView(space(),lp(dp(5),1));TextView profile=t("Profile",10,Color.WHITE,true);profile.setGravity(Gravity.CENTER);profile.setBackground(round(Color.TRANSPARENT,Color.WHITE,11));profile.setOnClickListener(v->open(id));actions.addView(profile,weight(1,dp(32)));inner.addView(actions,top(lp(-1,dp(32)),5));card.addView(inner,new FrameLayout.LayoutParams(-1,-1));
        if(isNew(x.optString("joinedAt",""))){TextView badge=t("NEW",7,Color.WHITE,true);badge.setGravity(Gravity.CENTER);badge.setBackground(round(0xffff285b,Color.TRANSPARENT,8));FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(32),dp(15),Gravity.TOP|Gravity.END);bp.topMargin=dp(2);bp.rightMargin=dp(4);card.addView(badge,bp);}
        card.setOnClickListener(v->open(id));return card;
    }
    private TextView buttonFriend(JSONObject user,String id){String state=user.optString("state","");TextView add=t("FRIEND".equalsIgnoreCase(state)?"✓  Friends":"REQUESTED".equalsIgnoreCase(state)?"Requested":"Add Friend",9.2f,Color.WHITE,true);add.setGravity(Gravity.CENTER);add.setMaxLines(1);add.setEllipsize(TextUtils.TruncateAt.END);add.setBackground(gradient(new int[]{0xff1188ff,0xff2378ff},12));add.setOnClickListener(v->{if(!"NONE".equalsIgnoreCase(user.optString("state","NONE")))return;add.setEnabled(false);BackendClient.sendFriendRequest(token,id,new BackendClient.Callback(){public void onSuccess(JSONObject d){try{user.put("state","REQUESTED");}catch(Exception ignored){}runOnUiThread(()->add.setText("Requested"));}public void onError(String m){runOnUiThread(()->{add.setEnabled(true);Toast.makeText(GeneralUsersActivity.this,m,Toast.LENGTH_SHORT).show();});}});});return add;}
    private void open(String id){startActivity(new Intent(this,UserProfileActivity.class).putExtra("userId",id));}
    private void search(){String id=search.getText().toString().trim();if(id.length()!=4){Toast.makeText(this,"Exact 4-digit myshop ID লিখুন",Toast.LENGTH_SHORT).show();return;}BackendClient.userProfile(token,id,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->open(id));}public void onError(String m){runOnUiThread(()->Toast.makeText(GeneralUsersActivity.this,"User পাওয়া যায়নি",Toast.LENGTH_SHORT).show());}});}
    private boolean isNew(String raw){raw=raw==null?"":raw.trim();if(raw.isEmpty())return false;try{long t;if(raw.matches("\\d+")){t=Long.parseLong(raw);if(t<100000000000L)t*=1000L;}else{String n=raw.replace('T',' ');if(n.endsWith("Z"))n=n.substring(0,n.length()-1);java.text.SimpleDateFormat f=new java.text.SimpleDateFormat(n.length()>19?"yyyy-MM-dd HH:mm:ss.SSS":"yyyy-MM-dd HH:mm:ss",java.util.Locale.US);f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));t=f.parse(n.substring(0,Math.min(n.length(),23))).getTime();}return t>0&&System.currentTimeMillis()>=t&&System.currentTimeMillis()-t<=7L*86400000L;}catch(Exception e){return false;}}
    private View bottomNav(){LinearLayout n=row();n.setBackgroundColor(Color.WHITE);n.setElevation(dp(7));n.addView(navItem(R.drawable.nav_home,"Home",Color.rgb(18,115,246),false,v->{startActivity(new Intent(this,MainActivity.class));finish();}),weight(1,dp(78)));n.addView(navItem(R.drawable.nav_store,"My Shop",Color.rgb(255,160,20),false,v->startActivity(new Intent(this,PhysicalStoreActivity.class))),weight(1,dp(78)));n.addView(navItem(R.drawable.nav_live,"Live",Color.rgb(255,20,86),true,v->startActivity(new Intent(this,LiveHomeActivity.class))),weight(1,dp(78)));n.addView(navItem(R.drawable.nav_support,"Support",Color.rgb(10,185,145),false,v->startActivity(new Intent(this,HelpCenterActivity.class))),weight(1,dp(78)));n.addView(navItem(R.drawable.nav_more540,"More Apps",Color.rgb(123,34,235),false,v->startActivity(new Intent(this,MainActivity.class).putExtra("openMoreApps",true).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP))),weight(1,dp(78)));return n;}
    private View navItem(int res,String label,int color,boolean live,View.OnClickListener click){String key=res==R.drawable.nav_home?"home":res==R.drawable.nav_store?"store":res==R.drawable.nav_live?"live":res==R.drawable.nav_support?"support":"more";return SharedPageNav.item(this,res,"store".equals(key)?"myshop":label,"home".equals(key),key,color,click);}
    private EditText tEdit(String h,boolean one){EditText e=new EditText(this);e.setHint(h);e.setTextSize(12);e.setTextColor(NAVY);e.setHintTextColor(MUTED);e.setSingleLine(one);e.setPadding(dp(8),0,dp(8),0);e.setBackground(round(Color.WHITE,0xffd6dfef,12));return e;}
    private TextView t(String s,float z,int c,boolean b){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(b)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private TextView buttonFriendOld(String s){return t(s,9,Color.WHITE,true);}
    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;} private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);return x;} private View space(){return new View(this);} private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);} private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;} private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);} private GradientDrawable round(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;} private GradientDrawable gradient(int[] c,int r){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,c);g.setCornerRadius(dp(r));return g;} private GradientDrawable gradient(int a,int b){return gradient(new int[]{a,b},12);} private void loadImage(ImageView v,String u){new android.os.AsyncTask<Void,Void,android.graphics.Bitmap>(){protected android.graphics.Bitmap doInBackground(Void...x){try{java.net.URL q=new java.net.URL(u);return android.graphics.BitmapFactory.decodeStream(q.openConnection().getInputStream());}catch(Exception e){return null;}}protected void onPostExecute(android.graphics.Bitmap b){if(b!=null)v.setImageBitmap(b);}}.execute();}
}
