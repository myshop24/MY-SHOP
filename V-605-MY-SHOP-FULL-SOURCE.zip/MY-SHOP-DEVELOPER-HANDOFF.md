# V605 / 2.9.605 — recovery and membership rendering corrections

Touhid ভাই authorized the six groups in the latest conversation. Baseline is canonical V604. This is a full source checkpoint; ALL SIX GROUPS ARE NOT COMPLETED. Next new delivery is V606.

## Implemented in source
1. Main Admin user audit now displays the current email and mobile. Recovery dialog shows the same contacts. New email replaces old without asking for old email; clearing a contact is explicitly separate. Recovery handlers prepare auth schema and migrate old audit tables before atomic changes. Password reset retains original hashing/session revocation and audit. API remains restricted to IDs0001/0002/0003.
2. Video-derived modern AnimatedImageDrawable explicitly repeats indefinitely while visible. Modern decoder does not force software rendering; GIF fallback does. Portrait ImageView is measured at its real hole dimensions before layout to avoid a stale1px image matrix. Original video inputs, masks and runtime animation hashes retained.
3. Premium Live comment frame is64dp rather than26dp; standard avatars remain26dp. Store demo is82dp high and shared comment preview adapts portrait size to available height. Right emblem smoothly pulses84–100% over2.4s with upper glow and jewel light. Approved backgrounds/emblem assets are preserved; no redesign.
4. Host/viewer avatars56dp; header content moves down6dp and the header row contracts68→62dp, preserving overall110dp hostArea. Viewer corner telephone badge removed. Existing profile click remains; eligible users can long-press for existing call card/invite. Bottom mic/audio functions remain. Unchanged audience visual state reuses displayed views to avoid repeatedly restarting animation on snapshot refresh. Changed audience/profile state still refreshes.

## Actual checks
Real in-memory SQLite shipped API tests pass: old audit schema migration, replacement without old email, MainAdmin permission, duplicate/last-contact validation, audit rollback, real password hashing and revocation of an existing session. Broad V575 regression passed57 Node files plus historical/source checks;209 Java sources parsed and resource references checked. V603 target/assets/provenance/source-selector checks passed. These are NOT a full Android type compile or device tests.
Android compile attempted forV605: Gradle8.11.1 distribution download failed with Network is unreachable. Original signing/Firebase secrets and local Android SDK are unavailable. No signed APK built or relabeled. No production deployment/DB mutation performed.

## Pending and limitations
5. New30 articulated ride animations/sounds and approved old-to-new catalog entitlement mapping are not implemented. Supplied boards are static design references; motion assets/layers are absent. Old purchased rides remain so entitlements/Admin price/days/grant/expiry are not lost. Existing right-to-left renderer remains; it is NOT the requested30 genuine new animations.
Membership phone acceptance remains mandatory: compare original video against catalog/profile/Host/seat/comments on two devices, check continuous loops and clipping. Right emblem currently pulse/glow, not independently articulated phoenix wing/fire video. Source artwork is the inheritedV604 resize, not pixel-identical originalDESIGN12. No claim of100% reference fidelity.
Check Live Join/Invite/seats/comments/gifts/mute/end/minimize and lock-screen notifications on devices. RTC transport, microphone behavior and financial economy were not redesigned.

## Build and delivery
Canonical V-605-MY-SHOP-FULL-SOURCE.zip contains full source and all required build inputs; generated outputs rebuild from retained clips/scripts/pinned dependencies and are hash verified. Hard source ZIP gate<25,000,000 bytes. Runtime APK can be larger; no measured APK exists.
This ZIP has NO APK. Put all extracted files including.github at repository root, or use the existing root ZIP-extracting workflow. A workflow only inside the ZIP cannot execute. Included.github/workflows/my-shop-apk.yml creates MY_SHOP_FINAL_RELEASE.apk from the exact new commit/version using original GitHub signing/Firebase secrets and verifies package/certificate/provenance. Do not reuse old artifacts. MatchingV605 Worker is needed for recovery schema repair; deploy through owner process with existing D1/R2 bindings, without resetting database.

## Next checkpoint
Complete actual30 motion media and catalog migration with purchased-ID mapping, then signed Android CI and device visual/Live regression acceptance. Pending work must never be marked completed. Keep previous versions and all approved unrelated designs/functions.

---
Historical checkpoint
# V604 /2.9.604 — under25MB source packaging correction
Owner Touhid ভাই; baseline canonical V603. Next delivery V605.
Original package/signing/economy/backend bindings preserved. No signed APK.

## Completed
Compressed7 non-runtime design reference boards as readable512px JPEG previews.
Comment backgrounds are1024px WebP quality92, emblem atlas1536px WebP quality92.
These are deliberate resize/lossy static-art optimizations, NOT pixel-identical
lossless conversion. Original membership video and generated512x512/24fps animations
are unchanged. Source manifest updated; frame generation remains byte-verified.
Renderer source rectangles use normalized geometry so new asset sizes crop correctly.
Removed unassigned AGENCY extra clip from build source (no active mapping); approved
Royal remains original140853. Removed4 images with no Java/XML/backend references,
no resource-name reflection calls: two unused legacy guest-logo refs, old chat icons.
Removed5 premium_membership JPGs after confirming active tier previews early-return
through MembershipIdentityView; unreachable fallback references now use stock avatar.
Admin price/days/purchases/entitlement/expiry unchanged. No old purchased ride deleted.

## Tests / actual release state
V603 target suite and V575 broad regression run; evidence verification/v604-*.log.
New static asset hashes and unchanged animation/sound hashes checked. Required resource
references/compiler-fragments/source selector/provenance fixtures checked.
Full Android compile/signed APK/device tests not performed forV604. V603 compile
attempt blocked by Gradle download Network is unreachable; SDK/signing unavailable.
No APK built or relabeled. Included Android workflow can produce a new signed APK
from this exact version with original GitHub signing/Firebase secrets. It supports
root ZIP extraction. Prior successful/failed run must not be reused as V604 output.

## Upload
Canonical source ZIP must be under25,000,000 bytes; pack tool rejects excess size.
Upload V-604-MY-SHOP-FULL-SOURCE.zip to repository root with existing ZIP-extracting
Android workflow. If root workflow missing, install included .github/workflows/
my-shop-apk.yml FIRST; a workflow only inside ZIP cannot execute. Alternative extract
and upload ALL project files including .github at repository root.
Use new successfulV604 Actions artifact MY_SHOP_FINAL_RELEASE.apk; package/version/
commit and original certificate must match the same run. Source ZIP contains no APK.
Matching Worker identity604/Host-exclusion is required for frontend behavior; backend
logic unchanged from603 except identity strings. No production deployment here.

## Pending inherited work
V603 is a partial implementation checkpoint:30 articulated new rides/sounds and
full right-emblem wing/fire animation still missing; old rides remain. Android/device
visual checks still required. This size fix does not claim all original9 completed.

---
Historical checkpoints
# V603 / 2.9.603 — partial implementation checkpoint, NOT all9 complete
Owner Touhid ভাই. Baseline canonical V602. Next newly delivered version V604.
Package com.myshop.app, original encrypted signing key and certificate preserved.

## Approved nine steps / actual state
1 Rules/source/reference audit completed. DESIGN12 is locked, small right emblem.
2 Source implemented: 512x512 24fps video-derived default identity, modern animated
  WebP decoder(API28+) and GIF fallback(API24-27). Explicit user reduce-animation
  preference retained; automatic low-memory freeze removed for this renderer only.
  Stable portrait layout now explicitly lays out photo; Shop refreshes /me metadata.
  Default video template supersedes legacy custom still-frame URLs without deleting
  their saved values. This intentionally means old Admin custom frame images do not
  override the approved membership template. Price/days/grant/revoke/expiry unchanged.
  Legacy PremiumTierActivity now uses same identity/comment preview. Pixel masking,
  video lettering edits and compressed WebP are NOT proven 100% reference fidelity.
3 Source implemented DESIGN12-inspired generated background assets/shared renderer,
  real name/message/portrait, smaller right emblem with moving light/jewel sparkle.
  Full articulated phoenix wings/fire emblem animation is NOT implemented. Static
  production background/emblem images are recreations, not pixel-exact source crops.
4 BLOCKED: 30 new ride articulated videos/sounds not built. Runway whoami returned Free,
  no video models and zero credits. No paid action/purchase performed. Six approved
  numbered design boards included. A still image sliding is not accepted completion.
5 Pending dependent on4: no old ride catalog/entitlement removed or migrated. All old
  purchased IDs/Admin controls/expiry retained. No production DB writes or deployment.
6 Shared existing RideEffectView now travels right-to-left. Existing runtime sound
  setup/callbacks retained. New30 ride/demo/event integration awaits real animation.
7 Implemented both sides: lifetime ranking excludes e.sender_id=e.host_id. Historical
  self gifts remain in ledger; other-user tie/+1/GOLD*100 rules preserved. Frontend
  also excludes hostId from TOP1 and removes extra corner crown overlay.
8 Tests below; Android/device acceptance pending.
9 Full source checkpoint packaging only, not complete9/9 delivery. No APK.

## True verification
Local broad V575 regression and V599 target suites passed after generated inputs were
prepared.209 Java files pass syntax/resource/compiler-fragment checks, NOT Android
full type compilation. Actual SQLite API tests now include historical self-gift
exclusion and preserve tie/+1/Host isolation/GOLD conversion/member filter cases.
Source visual-contract checks pass. Generated assets hashes verified. First broad
resource run failed because compact source outputs were not yet prepared; after
preparation rerun passed. No ignored failure.
Android compile attempted: Gradle8.11.1 download Network is unreachable. SDK and
original decrypted signing/Firebase secrets unavailable. Signed APK not built;
real-device catalog/profile/Live/RTC/audio/lock-screen notification tests not run.

## Build/size
Use included .github/workflows/my-shop-apk.yml at repository root, original signing
and Firebase secrets. New source identity isV603. Matching Worker update is needed
for server Host-exclusion; never reset DB. Build-only workflow never deploys Worker.
Generated animations excluded from ZIP and reconstructed from retained source clips,
legacy/current generators and pinned requirements; source SHA manifest guards output.
High-resolution runtime GIF fallback is large; APK size may exceed25MB. No APK size
claim before real build. Source ZIP includes all required source plus reference boards
and skins; size target cannot override quality/source completeness.

## Next checkpoint
Obtain/produce accepted articulated videos for all30rides and matching sounds, full
right-emblem wing/fire animation, explicit old-to-new entitlement mapping then actual
Admin catalog migration/regressions. Validate original videos against phone rendering;
current background removal mask may clip highlight details. Latest additional140469
clip depicts AGENCY, not previously-approved Royal: do not silently remap Royal to it.
Current Royal source remains original140853. Keep newest raw reference mapping correct.
Complete signed Android CI/device acceptance before claiming all9 finished. V604next.

---
Historical checkpoints
# V602 / 2.9.602 — direct Gradle asset setup fix

Touhid ভাই; latest source V601, next delivery V603. Package/signing identity retained.
Owner screenshots show the external permanent release pipeline successfully deployed
V601 Worker then failed :app:prepareMyShopAssets: Install ffmpeg before preparing
membership assets. That root workflow invoked Gradle directly and did not execute the
included new workflow dependency steps or ci-apk-build.sh setup. Node/Java deprecation
and compileSdk warnings shown are not the demonstrated fatal error.

## Completed
Gradle asset task now calls tools/prepare-build-assets.sh. On GitHub Actions only,
missing ffmpeg/font packages are installed and missing PIL/numpy/scipy imports trigger
an isolated venv with the included pinned requirements. Local builds never auto-sudo;
they get a clear setup error. Existing assets still require exact V600 SHA256 and
113 lossless image pixel checks. Existing root ZIP selector can select V602 and its
Gradle task now prepares itself even when the root release workflow is older.
Included Android workflow and signed-build/provenance gates retained. No runtime
membership animation/design, financial, RTC, Live controls or database logic changed.
Worker health identity advances to V602; functional code unchanged from V601.

## Actual verification
Direct-Gradle CI bootstrap fixture: passed missing ffmpeg/Python setup order.
Actual local asset preparation: passed all generated file/pixel hashes.
V601 inherited target suite: passed SQLite/API ranking/filter tests, Java syntax,
asset/provenance/source-selector checks. Full V575 regression result in verification.
Full Android compile/signed APK/device tests remain pending: local Android SDK and
original decrypted signing credentials unavailable; previous Gradle download blocked.
No production deployment performed here. User screenshot shows their earlier Worker
V601 deployment succeeded; their APK failed, so no APK from that run exists.

## Upload / checkpoint
Canonical V-602-MY-SHOP-FULL-SOURCE.zip is a full compact source, not a patch.
With the existing ZIP-extracting permanent pipeline, upload the new ZIP and run a NEW
commit/build; rerunning old V601 commit cannot pick up this fix. If using the included
build-only workflow, replace root .github/workflows/my-shop-apk.yml with the included
file first, then upload ZIP or extracted full root project. Preserve original secrets.
Do not duplicate workflows that deploy production unnecessarily. This source's
build-only workflow does not deploy Worker. Backend functional change is not required
for this build fix; matching V602 health identity may be deployed separately.
This ZIP contains no APK. Download one signed MY_SHOP_FINAL_RELEASE.apk only from the
new successful exact-V602 run; check embedded version/commit and original certificate.
Legacy membership JPG/custom Admin overrides and device visual acceptance remain
pending as documented V601; this build fix does not claim all old logos were replaced.


---
Historical checkpoints
# Current checkpoint: MY SHOP V-601 / 2.9.601

Read handoffs/MY-SHOP-V601-HANDOFF.md and BUILD-ASSETS-BN.md first. Complete compact
source is below25,000,000 bytes; generated runtime assets rebuild from included inputs,
matching V600 byte-for-byte. Five unused old frames removed; still-referenced legacy
assets retained. Local/fresh-extract regressions passed. Android compile/signing and
real-device Live/UI remain blocked/pending. No V601 APK/deployment. Next delivery V602.
Older sections below are historical.

# Current checkpoint: MY SHOP V-600 / 2.9.600

Read handoffs/MY-SHOP-V600-HANDOFF.md and V600-APPROVED-WORK-BN.md first.
Membership video frames/comments, General active-member filtering and lifetime Host
Top1 order are implemented in source. Local source/backend regressions passed.
Android compile/signed APK are blocked locally; real-device Live/UI/notification QA
is pending. Matching V600 Worker is required; nothing was deployed. No V600 APK is
included. Next newly created delivery is V601. Older sections below are historical.

# Current checkpoint: MY SHOP V-599 / 2.9.599

Read handoffs/MY-SHOP-V599-HANDOFF.md first. Agent route and operational Live permissions corrected. Local tests passed; Android build/device QA pending. Matching Worker update required; not deployed here.

# Current checkpoint: MY SHOP V-598 / 2.9.598

Packaging/build-entry correction only. Application behavior preserved from V597. Read handoffs/MY-SHOP-V598-HANDOFF.md first.

# Current checkpoint: MY SHOP V-597 / 2.9.597

Read handoffs/MY-SHOP-V597-HANDOFF.md first. Local source checks passed; signed APK/Android type/device QA remain pending. Latest owner instructions take priority.

# বর্তমান checkpoint: MY SHOP V-596 / 2.9.596

প্রথমে handoffs/MY-SHOP-V596-HANDOFF.md পড়ুন। V-596-এর ৯টি scoped source পরিবর্তন ও local regression যাচাই হয়েছে। APK/Android type/device/production পরীক্ষা এখনো হয়নি। Older checkpoint নিচে ইতিহাস হিসেবে আছে; নতুন নির্দেশনা অগ্রাধিকার পাবে।

# MY SHOP V-595 — owner-authorized tasks 1–9

Baseline: uploaded V-594 full source, 24,999,761 bytes; SHA-256 411b821692001b6ab32c6f1c545c130400bc32fd9b5303dad61c6bb9e979667c.
Identity: SOURCE_BUILD_ID MY SHOP V-595; versionCode 595; versionName 2.9.595. Worker health and Android identity match. This is a full source continuation, not a patch. Prior V594 handoff retained in handoffs/MY-SHOP-V594-HANDOFF.md.

## 1. D1 reads
Normal safety snapshot 1s → 15s; degraded fallback bounded to 5s. Realtime dirty signals still refresh immediately, comments/gifts remain on original Durable Object path. Healthy Gift event recovery 1.2s → 30s; degraded recovery 5s. Participant state sends only on change or 15s safety retry, no concurrent state sends; backend skips unchanged seat writes. Avatar completion updates its bound ImageViews without issuing another full room API request. Live list refresh 1s → 15s with in-flight deduplication. Unused Live directory discovery/people/ranking loads removed from lifecycle; their independently-used handlers remain. Viewer-count maintenance and seven public aggregates coalesce per DB + host + session for at most 5s; Gift/DIRTY invalidates in the local Worker isolate. Private state/auth/wallet/permissions are never shared through this cache. Redundant meta query reused; global request expiry write removed from room snapshots while room/session expiry remains.
This materially reduces polling requests, but does NOT prove a production rows-read reduction or capacity for 50 rooms/1000 users. Cache is isolate-local and bounded. Remaining common room data is still queried per snapshot; profile subqueries and historical aggregates need production profiling and future summary-table/index work. Measure D1 meta rows_read/rows_written and endpoint latency before/after; full production load test remains required.

## 2–4. Scoped cleanup
Remove only the nominated More popup links; keep Page, Website, My Level, Top Up, Earn Rewards, Share App and authorized Admin in a 3-column layout. Main Home shortcut row and General under headline remain. General hamburger retains Agent/My Links/What's New/Safety & Privacy; Invite now Share with share action. Shared backend records, other routes and existing items are retained.

## 5. Live directory
Live Menu contains only Agent/Support/Share App. Top row has Membership/Games, Earn removed. Tabs LIVE NOW/Following/New; Explore removed. Shared Home/Live header dimensions and bottom icon dimensions/color/spacing agree; Go Live label retains directory action. Both existing ad and Upcoming Live banners remain. Live Room seat/audio/comment UI was not redesigned.

## 6. Premium
Tabs All/Membership/Ride Entry/Wallpaper/My Items only. Avatar Frame/Comment Box/Ring Badge/Theme Effect/Combo Special tabs removed; owned items, membership bundle preview/equipping and independent functional entry routes remain. The owner's video showed category labels, not proof of every category's runtime implementation, so shared ownership/entitlements were not deleted.

## 7. Diamond
Gold Coin display labels rebranded Diamond in Android and backend user-facing messages/default headings; Live gem uses cyan/blue/purple faceted drawable. Internal GOLD API/DB/product keys, prices, balances, signing/package identity and ledger remain unchanged. No 1:1 ledger rewrite is required. Admin/custom remote titles are user-managed and can still contain legacy text; review actual remote configuration after deployment. Ordinary Coin remains separate.

## 8. Commission Management
Owner-only Admin catalog route and real persisted /v1/admin/commission-management API. Centered Coin/Diamond global controls; enable/disable and rate. Four lower entries per row: Gift, Transfer, Withdraw, Ledger. Currency-specific per-feature rates; global timed Free up to 720h; precedence Free > enabled central rate > feature-specific/default. Automatic expiry is evaluated on server time; earlier config remains intact. Atomic revision guard and active-owner recheck with audit. Gift and Transfer retain established purchased/official origin exemptions; no unauthorized charge added to top-up or premium purchases. Central management covers existing Gift/Transfer/Withdrawal commissions; broader new commission types/agency shares are NOT introduced in this release. Existing underlying finance settings remain compatible with older APKs. New APK finance commission button routes here. Withdrawal catalog quote uses the same effective rate. Saved historical request snapshots are unchanged.

## 9. Withdrawal
Cause: old Pending reservations reduced eligible-earnings availability but did not debit the spendable wallet. New requests atomically debit amount plus ADDITIONAL commission from the matching spendable wallet, retaining original earned-reservation model. Hold records distinguish HELD/SETTLED/RELEASED. Paid settles the physical hold without another wallet debit and retains original final earned debit. Reject refunds physical hold exactly once. Request-key/ledger transaction rollback and purchased-source exclusion tested. Wallet screens reload after returning from withdrawal; confirmation screen shows authoritative wallet balance.
Defaults and catalogs without an explicit feeMode now use ADDITIONAL; explicitly saved INCLUDED catalogs remain deliberate compatible settings. Prior requests/terms are not silently repriced. Existing pre-V595 pending requests have no new physical-hold marker; preserve their legacy settlement behavior and do not run a blanket debit/backfill. Reconcile legacy pending balances manually before accepting high-volume financial production. No external bank/payment was sent by these changes.

## Verification / release limits
V590 retained fixture/regression suite and V595 focused tests run locally. V593/V594 appearance tests retained; 206 Java files passed javac syntax and callback Context audits (not Android type compilation). Public cache coalescing/isolation/failure retry; commission API persistence/active owner/revision/audit rollback/Free expiry; withdrawal immediate debit/concurrent retry/no double Paid/exact refund/rollback/purchased protection pass.
Full Android compile, lint, Robolectric runtime, signed APK, phone/RTC/audio/gift/invite/End/reconnect tests and production D1 load test NOT performed here. Build-only script stops because ANDROID_HOME is unavailable; original signing secrets also belong to the user's GitHub setup. No APK is included or relabeled. No production Worker deploy, DB migration, Play upload or external publish performed.
Use existing GitHub signing/Firebase settings. CI runs tools/v595_verify.sh before clean Android test/assembleRelease/lintRelease, preserves certificate check and one canonical APK. APK from a green run still requires exact commit/SOURCE_BUILD_ID/artifact/certificate verification.
Deploy matching Worker with APK through owner's deployment process; backend changes do not appear from APK build alone. Runtime schema creation is additive. Comments stay ephemeral; D1/R2 bindings unchanged.

## Next checkpoint
Complete actual Android CI, then device acceptance for the 9 changes and all locked Live controls. Inspect custom remote labels for Diamond wording. Profile residual room queries before claiming any scaling guarantee. Resolve additional commission folder/agency requirements separately, never infer them from old diagrams.

Final V602 verification: tools/v575_verify.sh passed all56 top-level Node files plus historical checks. tools/v602_verify.sh passed. Version602 literals were added to the preservation-test normalization only; locked function hashes remain checked. Live/Home/Manifest/Wrangler bytes match V601; Worker exact except version literals.

Final checkpoint: fresh extracted compact source rebuilt all old29 + new12 generated outputs; SHA256 matched. Fresh v603 target suite passed. Static skin/reference hashes guarded. Exact duplicate skin PNGs were removed only after RGBA comparison with WebP; app references WebP. Legacy V600 GIF test fixtures excluded from APK assets because no runtime Java refers to them. No signed APK.

Final verification: targetV603 suite + broadV575 regression passed for604. Asset manifest was updated to remove hashes of verified unused deleted images; all retained sources/static skins/generated sounds/animations pass preparation. Source selector/provenance fixtures and bootstrap checks passed. APK/Android/device still not verified.
