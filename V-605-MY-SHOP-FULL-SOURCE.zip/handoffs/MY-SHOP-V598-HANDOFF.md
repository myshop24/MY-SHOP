# MY SHOP V-598 handoff
Baseline: complete V597 project. All source, assets, backend, migrations, tests, developer rules and original signing setup retained.
Changes: Android/source/Worker identity 598 / 2.9.598; ZIP files directly at root (no project wrapper); Android workflow runs on main/master push or manual dispatch.
Upload: extract ZIP, upload ALL contents including .github to repository root. GitHub cannot run workflows inside an uploaded ZIP. Existing root workflow also supports versioned source ZIP selection.
Successful signed Android build uploads MY-SHOP-V-598-APK with one MY_SHOP_FINAL_RELEASE.apk. Original repository signing and Firebase Secrets required; do not invent a new key.
Local Android SDK and private signing credentials unavailable. No signed APK is included or relabeled; Android build/device QA not performed here. V597 behavioral tests remain relevant. Live Game revenue provider and physical Live/UI acceptance remain pending.
Next developer: run Android workflow; verify source ID, commit, package/version/certificate and artifact from that exact run. Deploy matching backend only through owner deployment process.
