# V605 / 2.9.605 — recovery and membership rendering corrections

Touhid ভাই authorized the six groups in the latest conversation. Baseline is canonical V604. This is a full source checkpoint; ALL SIX GROUPS ARE NOT COMPLETED. Next new delivery is V606.

## Implemented in source
1. Main Admin user audit now displays the current email and mobile. Recovery dialog shows the same contacts. New email replaces old without asking for old email; clearing a contact is explicitly separate. Recovery handlers prepare auth schema and migrate old audit tables before atomic changes. Password reset retains original hashing/session revocation and audit. API remains restricted to IDs0001/0002/0003.
2. Video-derived modern AnimatedImageDrawable explicitly repeats indefinitely while visible. Modern decoder does not force software rendering; GIF fallback does. Portrait ImageView is measured at its real hole dimensions before layout to avoid a stale1px image matrix. Original video inputs, masks and runtime animation hashes retained.
3. Premium Live comment frame is64dp rather than26dp; standard avatars remain26dp. Store demo is82dp high and shared comment preview adapts portrait size to available height. Right emblem smoothly pulses84–100% over2.4s with upper glow and jewel light. Approved backgrounds/emblem assets are preserved; no redesign.
4. Host/viewer avatars56dp; header content moves down6dp and the header row contracts68→62dp, preserving overall110dp hostArea. Viewer corner telephone badge removed. Existing profile click remains; eligible users can long-press for existing call card/invite. Bottom mic/audio functions remain. Unchanged audience visual state reuses displayed views to avoid repeatedly restarting animation on snapshot refresh. Changed audience/profile state still refreshes.

## Actual checks
Real in-memory SQLite shipped API tests pass: old audit schema migration, replacement without old email, MainAdmin permission, duplicate/last-contact validation, audit rollback, real password hashing and revocation of an existing session. Broad V575 regression passed57 Node files plus historical/source checks;209 Java sources parsed and resource references checked. V603 target/assets/provenance/source-selector checks passed. These are NOT a full Android type compile or device tests.
Android compile attempted forV605: Gradle8.11.1 distribution download failed with Network is unreachable. Original signing/Firebase secrets and local Android SDK are unavailable. No signed APK built or relabeled. No production deployment/DB mutation performed.

## Pending and limitations
5. New30 articulated ride animations/sounds and approved old-to-new catalog entitlement mapping are not implemented. Supplied boards are static design references; motion assets/layers are absent. Old purchased rides remain so entitlements/Admin price/days/grant/expiry are not lost. Existing right-to-left renderer remains; it is NOT the requested30 genuine new animations.
Membership phone acceptance remains mandatory: compare original video against catalog/profile/Host/seat/comments on two devices, check continuous loops and clipping. Right emblem currently pulse/glow, not independently articulated phoenix wing/fire video. Source artwork is the inheritedV604 resize, not pixel-identical originalDESIGN12. No claim of100% reference fidelity.
Check Live Join/Invite/seats/comments/gifts/mute/end/minimize and lock-screen notifications on devices. RTC transport, microphone behavior and financial economy were not redesigned.

## Build and delivery
Canonical V-605-MY-SHOP-FULL-SOURCE.zip contains full source and all required build inputs; generated outputs rebuild from retained clips/scripts/pinned dependencies and are hash verified. Hard source ZIP gate<25,000,000 bytes. Runtime APK can be larger; no measured APK exists.
This ZIP has NO APK. Put all extracted files including.github at repository root, or use the existing root ZIP-extracting workflow. A workflow only inside the ZIP cannot execute. Included.github/workflows/my-shop-apk.yml creates MY_SHOP_FINAL_RELEASE.apk from the exact new commit/version using original GitHub signing/Firebase secrets and verifies package/certificate/provenance. Do not reuse old artifacts. MatchingV605 Worker is needed for recovery schema repair; deploy through owner process with existing D1/R2 bindings, without resetting database.

## Next checkpoint
Complete actual30 motion media and catalog migration with purchased-ID mapping, then signed Android CI and device visual/Live regression acceptance. Pending work must never be marked completed. Keep previous versions and all approved unrelated designs/functions.
