# V604 /2.9.604 — under25MB source packaging correction
Owner Touhid ভাই; baseline canonical V603. Next delivery V605.
Original package/signing/economy/backend bindings preserved. No signed APK.

## Completed
Compressed7 non-runtime design reference boards as readable512px JPEG previews.
Comment backgrounds are1024px WebP quality92, emblem atlas1536px WebP quality92.
These are deliberate resize/lossy static-art optimizations, NOT pixel-identical
lossless conversion. Original membership video and generated512x512/24fps animations
are unchanged. Source manifest updated; frame generation remains byte-verified.
Renderer source rectangles use normalized geometry so new asset sizes crop correctly.
Removed unassigned AGENCY extra clip from build source (no active mapping); approved
Royal remains original140853. Removed4 images with no Java/XML/backend references,
no resource-name reflection calls: two unused legacy guest-logo refs, old chat icons.
Removed5 premium_membership JPGs after confirming active tier previews early-return
through MembershipIdentityView; unreachable fallback references now use stock avatar.
Admin price/days/purchases/entitlement/expiry unchanged. No old purchased ride deleted.

## Tests / actual release state
V603 target suite and V575 broad regression run; evidence verification/v604-*.log.
New static asset hashes and unchanged animation/sound hashes checked. Required resource
references/compiler-fragments/source selector/provenance fixtures checked.
Full Android compile/signed APK/device tests not performed forV604. V603 compile
attempt blocked by Gradle download Network is unreachable; SDK/signing unavailable.
No APK built or relabeled. Included Android workflow can produce a new signed APK
from this exact version with original GitHub signing/Firebase secrets. It supports
root ZIP extraction. Prior successful/failed run must not be reused as V604 output.

## Upload
Canonical source ZIP must be under25,000,000 bytes; pack tool rejects excess size.
Upload V-604-MY-SHOP-FULL-SOURCE.zip to repository root with existing ZIP-extracting
Android workflow. If root workflow missing, install included .github/workflows/
my-shop-apk.yml FIRST; a workflow only inside ZIP cannot execute. Alternative extract
and upload ALL project files including .github at repository root.
Use new successfulV604 Actions artifact MY_SHOP_FINAL_RELEASE.apk; package/version/
commit and original certificate must match the same run. Source ZIP contains no APK.
Matching Worker identity604/Host-exclusion is required for frontend behavior; backend
logic unchanged from603 except identity strings. No production deployment here.

## Pending inherited work
V603 is a partial implementation checkpoint:30 articulated new rides/sounds and
full right-emblem wing/fire animation still missing; old rides remain. Android/device
visual checks still required. This size fix does not claim all original9 completed.

Final verification: targetV603 suite + broadV575 regression passed for604. Asset manifest was updated to remove hashes of verified unused deleted images; all retained sources/static skins/generated sounds/animations pass preparation. Source selector/provenance fixtures and bootstrap checks passed. APK/Android/device still not verified.
