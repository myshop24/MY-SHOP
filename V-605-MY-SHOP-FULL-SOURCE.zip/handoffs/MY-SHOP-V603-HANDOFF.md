# V603 / 2.9.603 — partial implementation checkpoint, NOT all9 complete
Owner Touhid ভাই. Baseline canonical V602. Next newly delivered version V604.
Package com.myshop.app, original encrypted signing key and certificate preserved.

## Approved nine steps / actual state
1 Rules/source/reference audit completed. DESIGN12 is locked, small right emblem.
2 Source implemented: 512x512 24fps video-derived default identity, modern animated
  WebP decoder(API28+) and GIF fallback(API24-27). Explicit user reduce-animation
  preference retained; automatic low-memory freeze removed for this renderer only.
  Stable portrait layout now explicitly lays out photo; Shop refreshes /me metadata.
  Default video template supersedes legacy custom still-frame URLs without deleting
  their saved values. This intentionally means old Admin custom frame images do not
  override the approved membership template. Price/days/grant/revoke/expiry unchanged.
  Legacy PremiumTierActivity now uses same identity/comment preview. Pixel masking,
  video lettering edits and compressed WebP are NOT proven 100% reference fidelity.
3 Source implemented DESIGN12-inspired generated background assets/shared renderer,
  real name/message/portrait, smaller right emblem with moving light/jewel sparkle.
  Full articulated phoenix wings/fire emblem animation is NOT implemented. Static
  production background/emblem images are recreations, not pixel-exact source crops.
4 BLOCKED: 30 new ride articulated videos/sounds not built. Runway whoami returned Free,
  no video models and zero credits. No paid action/purchase performed. Six approved
  numbered design boards included. A still image sliding is not accepted completion.
5 Pending dependent on4: no old ride catalog/entitlement removed or migrated. All old
  purchased IDs/Admin controls/expiry retained. No production DB writes or deployment.
6 Shared existing RideEffectView now travels right-to-left. Existing runtime sound
  setup/callbacks retained. New30 ride/demo/event integration awaits real animation.
7 Implemented both sides: lifetime ranking excludes e.sender_id=e.host_id. Historical
  self gifts remain in ledger; other-user tie/+1/GOLD*100 rules preserved. Frontend
  also excludes hostId from TOP1 and removes extra corner crown overlay.
8 Tests below; Android/device acceptance pending.
9 Full source checkpoint packaging only, not complete9/9 delivery. No APK.

## True verification
Local broad V575 regression and V599 target suites passed after generated inputs were
prepared.209 Java files pass syntax/resource/compiler-fragment checks, NOT Android
full type compilation. Actual SQLite API tests now include historical self-gift
exclusion and preserve tie/+1/Host isolation/GOLD conversion/member filter cases.
Source visual-contract checks pass. Generated assets hashes verified. First broad
resource run failed because compact source outputs were not yet prepared; after
preparation rerun passed. No ignored failure.
Android compile attempted: Gradle8.11.1 download Network is unreachable. SDK and
original decrypted signing/Firebase secrets unavailable. Signed APK not built;
real-device catalog/profile/Live/RTC/audio/lock-screen notification tests not run.

## Build/size
Use included .github/workflows/my-shop-apk.yml at repository root, original signing
and Firebase secrets. New source identity isV603. Matching Worker update is needed
for server Host-exclusion; never reset DB. Build-only workflow never deploys Worker.
Generated animations excluded from ZIP and reconstructed from retained source clips,
legacy/current generators and pinned requirements; source SHA manifest guards output.
High-resolution runtime GIF fallback is large; APK size may exceed25MB. No APK size
claim before real build. Source ZIP includes all required source plus reference boards
and skins; size target cannot override quality/source completeness.

## Next checkpoint
Obtain/produce accepted articulated videos for all30rides and matching sounds, full
right-emblem wing/fire animation, explicit old-to-new entitlement mapping then actual
Admin catalog migration/regressions. Validate original videos against phone rendering;
current background removal mask may clip highlight details. Latest additional140469
clip depicts AGENCY, not previously-approved Royal: do not silently remap Royal to it.
Current Royal source remains original140853. Keep newest raw reference mapping correct.
Complete signed Android CI/device acceptance before claiming all9 finished. V604next.

Final checkpoint: fresh extracted compact source rebuilt all old29 + new12 generated outputs; SHA256 matched. Fresh v603 target suite passed. Static skin/reference hashes guarded. Exact duplicate skin PNGs were removed only after RGBA comparison with WebP; app references WebP. Legacy V600 GIF test fixtures excluded from APK assets because no runtime Java refers to them. No signed APK.
