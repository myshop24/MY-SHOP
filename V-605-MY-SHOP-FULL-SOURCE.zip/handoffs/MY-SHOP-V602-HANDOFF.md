# V602 / 2.9.602 — direct Gradle asset setup fix

Touhid ভাই; latest source V601, next delivery V603. Package/signing identity retained.
Owner screenshots show the external permanent release pipeline successfully deployed
V601 Worker then failed :app:prepareMyShopAssets: Install ffmpeg before preparing
membership assets. That root workflow invoked Gradle directly and did not execute the
included new workflow dependency steps or ci-apk-build.sh setup. Node/Java deprecation
and compileSdk warnings shown are not the demonstrated fatal error.

## Completed
Gradle asset task now calls tools/prepare-build-assets.sh. On GitHub Actions only,
missing ffmpeg/font packages are installed and missing PIL/numpy/scipy imports trigger
an isolated venv with the included pinned requirements. Local builds never auto-sudo;
they get a clear setup error. Existing assets still require exact V600 SHA256 and
113 lossless image pixel checks. Existing root ZIP selector can select V602 and its
Gradle task now prepares itself even when the root release workflow is older.
Included Android workflow and signed-build/provenance gates retained. No runtime
membership animation/design, financial, RTC, Live controls or database logic changed.
Worker health identity advances to V602; functional code unchanged from V601.

## Actual verification
Direct-Gradle CI bootstrap fixture: passed missing ffmpeg/Python setup order.
Actual local asset preparation: passed all generated file/pixel hashes.
V601 inherited target suite: passed SQLite/API ranking/filter tests, Java syntax,
asset/provenance/source-selector checks. Full V575 regression result in verification.
Full Android compile/signed APK/device tests remain pending: local Android SDK and
original decrypted signing credentials unavailable; previous Gradle download blocked.
No production deployment performed here. User screenshot shows their earlier Worker
V601 deployment succeeded; their APK failed, so no APK from that run exists.

## Upload / checkpoint
Canonical V-602-MY-SHOP-FULL-SOURCE.zip is a full compact source, not a patch.
With the existing ZIP-extracting permanent pipeline, upload the new ZIP and run a NEW
commit/build; rerunning old V601 commit cannot pick up this fix. If using the included
build-only workflow, replace root .github/workflows/my-shop-apk.yml with the included
file first, then upload ZIP or extracted full root project. Preserve original secrets.
Do not duplicate workflows that deploy production unnecessarily. This source's
build-only workflow does not deploy Worker. Backend functional change is not required
for this build fix; matching V602 health identity may be deployed separately.
This ZIP contains no APK. Download one signed MY_SHOP_FINAL_RELEASE.apk only from the
new successful exact-V602 run; check embedded version/commit and original certificate.
Legacy membership JPG/custom Admin overrides and device visual acceptance remain
pending as documented V601; this build fix does not claim all old logos were replaced.

Final V602 verification: tools/v575_verify.sh passed all56 top-level Node files plus historical checks. tools/v602_verify.sh passed. Version602 literals were added to the preservation-test normalization only; locked function hashes remain checked. Live/Home/Manifest/Wrangler bytes match V601; Worker exact except version literals.
