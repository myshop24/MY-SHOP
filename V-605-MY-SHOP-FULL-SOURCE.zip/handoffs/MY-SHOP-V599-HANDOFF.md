# MY SHOP V-599 / 2.9.599 — continuation checkpoint
Baseline: complete V598, all original package/signing/data identities preserved. Owner approved three fixes on 2026-10-11 after 140770.mp4 and 140772.jpg review.

## 1. Agent entry
Main Home General Menu Agent now opens existing AgencyActivity for Admin and User before generic Admin feature editor routing. FeatureAccess still gates entry. Long-press retains separate name/icon feature management. Agency appointment/card/WhatsApp+Inbox/Host Join+Leave/Remove/design code from V597 preserved, not rewritten or claimed pixel-perfect.

## 2. Moderator Live permissions
Directory always contains explicit Live Streaming (feature_live_streaming), even if no saved shortcut exists. Main Admin permission page has a direct Live selector and readable confirmation-backed switches. API returns per-scope action list. Existing feature View/Save Draft controls preserved.
Actions: View tools, Mute, Unmute, Kick, Block, Unblock, Invite, Join Request Approve/Reject, Pin/Unpin, Room Admin appointment/removal, settings, End another Host Live.
Live endpoints check fresh DB role/active and saved grants. Moderator acting in their own Host room retains Host authority. Main Admin retains authority. Explicit OFF applies even when Moderator is also a Room Admin. View OFF disables these Moderator operations but does not block audience listening or owner's guaranteed direct call Join.
For compatibility, existing Moderator operational rights remain enabled if no grant was saved; new requests/room_admin/end powers default OFF until owner enables. Existing Room Admin powers retain original scope. Non-Main ADMIN retains existing backend admin semantics.
Grants use existing revision/audit table. Role removal revokes saved grants through existing removal system. Private account/password data is not exposed. In-Live UI reads authoritative action flags; Community → Live পরিচালনা contains request decisions, Pin, Unblock ID, slow mode, confirmed End. Target-user seat/audience actions also use flags. Gift catalog editing remains the existing owner/Admin system, not a newly delegated catalog permission. No automatic financial/publish/global-ban grant.

## 3. Direct call Join
Existing shipped liveSpeakRequest already supports Main Admin, Moderator and host-appointed Room Admin auto-join. Preserve it and test actual endpoint with SQLite; ordinary User remains Pending, repeated Join does not create duplicate seat. Host/guest RTC and audio behavior not redesigned. Valid active room/session, free/unlocked seat and sanctions remain checked.

## Verification
Local v575 suite passed: 207 Java parser/resource/import and scoped compiler contracts, plus SQLite regression. New v599 real Worker/SQLite tests verify owner-only grants, conflict/audit, OFF action enforcement, enabled Mute, enabled request Reject, enabled End through actual closeLive, role revocation and direct Join for three roles + ordinary Pending/repeat Join. v597 source/finance/agency/Level tests passed. GitHub pre-Gradle test gates run locally (see final delivery status).
No Android SDK/private signing credentials here: no Gradle Android compile, signed APK, phone/UI/RTC/push/performance acceptance. No old APK relabeled. No production deploy or DB mutation. Live Game revenue provider remains pending from V597; previous source limitations retained.

## Next developer / deployment
Extract all ZIP files incl .github into repository root. Android workflow runs on main/master push or manual dispatch; original GitHub signing/Firebase Secrets required. Successful build uploads MY-SHOP-V-599-APK containing one canonical MY_SHOP_FINAL_RELEASE.apk. Check exact commit/build ID/package/version/certificate and artifact from that run.
Matching backend Worker MUST be updated through owner's deployment process: APK alone cannot activate new permission endpoints or role checks on an old server. Runtime grant schema is existing additive DDL, D1/R2 bindings unchanged. Actual device acceptance remains required before claiming visual fidelity or Live reliability.
