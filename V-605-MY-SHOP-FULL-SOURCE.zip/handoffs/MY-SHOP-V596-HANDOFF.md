# MY SHOP V-596 — ১১ অক্টোবর ২০২৬

## বর্তমান কাজ — ১ থেকে ৯
1. Existing Agent entry থেকে সর্বোচ্চ ৬টি agency। Owner real MY SHOP ID দিয়ে নিয়োগ করবেন। প্রথম খালি slot-এ myshop ও WhatsApp https://wa.me/8801860626700 প্রস্তাবিত; কাউকে স্বয়ংক্রিয়ভাবে নিয়োগ করা হয়নি। Profile/name/ID, WhatsApp, app Message, Host list; Join Request/Cancel, Agent Invite, mutual Accept/Reject, reason-required Remove/Leave এবং audit। পুরোনো ৬ যোগাযোগ slot-ও খোলা যায়। Agent share Gift/Transfer/paid Withdrawal-এর platform commission-এর শতাংশ; default ০, owner নির্ধারণ করবেন। Coin/Diamond পৃথক আয়, wallet/earned credit এবং platform net একই transaction-এ। Retry-তে duplicate credit নয়। শেষ ১০০ আয় report private। Agency ছাড়লেও পূর্বের আর্থিক record থাকবে। Agent permission Live admin permission নয়।
2. Agora microphone/playback gain ১০০। Connecting অবস্থায় duplicate Join আটকানো এবং pending Join-এও Leave। Speech scenario, headset routing, music, mic mute ও RTC options সংরক্ষিত। Real-device echo/distortion পরীক্ষা বাকি।
3. X-এর touch area ৪৮×৪৮। End Live history/presence/temporary cleanup atomic batch, failed batch rollback, retry-তে summary একবার। Permanent BLOCK, অন্য room এবং finance history অপরিবর্তিত। D1 quota/network failure হলে successful close দাবি করবে না।
4. Master Feature Controls light button-এর dark text ও readable search/header।
5. একই canonical feature_my_shop-এ 🛒 MY SHOP ই-কমার্স নাম। Coming Soon করা হয়নি; owner করবেন। Premium catalog বা e-commerce data মোছা হয়নি।
6. Schema/migration initialization per DB instance coalesced, repeated content/auth/friend/notification/level bootstrap বন্ধ; failed initialization retry। Finance column checks একবার; Live-এর targeted indexes migration শেষে। Permission/wallet/auth result cache নয়। D1_DIAGNOSTICS=1 করলে room.seats/room.viewers query metadata log; ব্যক্তিগত তথ্য বা SQL parameters log নয়। পুরোনো realtime ও bounded recovery retained। Production read reduction/capacity এখনও মাপা হয়নি।
7. Header notification/message badge red circle, white readable number, icon-এর top-right। Existing per-event push deduplication ও lockscreen sound/deep link/channel retained। Native launcher-এ badge shape/count ফোনের launcher নির্ধারণ করে; সব ফোনে Facebook-এর হুবহু চেহারা নিশ্চিত নয়।
8. Same-token concurrent Dashboard request coalesced। Account-separated bounded Home appearance cache আগে দেখায়, fresh network refresh পরে। Cache-এ balance/financial result নেই। Feature permission check live/fresh থাকে। বাস্তব phone startup timing এখনও মাপা হয়নি।
9. Host/viewer avatar ৪৬×৪৬ একই মাপ; name-এর পাশে এক horizontal strip, uniform gap, সর্বোচ্চ ২০ profile scroll; বাকিরা overflow viewer list-এ। Call action, mini profile, membership frame ও overflow viewer list retained। Seats/Main Guest/comments/controls redesign করা হয়নি।

## সীমা
এটি নির্ধারিত ৯টি পরিবর্তনের source checkpoint। ক্রিকেট module নতুন করে তৈরি করা হয়নি। নতুন Level/Live Game অর্থনৈতিক নিয়ম বা অনির্ধারিত agent commission rate বানানো হয়নি। Agent share হলো platform commission-এর অংশ—অতিরিক্ত customer fee নয়; UI-তেও base স্পষ্ট লেখা আছে। পুরোনো pending withdrawal নিজে থেকে পুনরায় debit/reconcile করা হয়নি।

## যাচাই
- bash tools/v590_verify.sh — inherited regression passed।
- bash tools/v596_verify.sh — syntax, manifest/import, scoped preservation, commission/withdrawal, agency permissions/consent/share allocation, atomic close and schema/index tests passed।
- Node 22 actual SQLite tests use transactions and failure injection; production D1 metrics নয়।
- Java syntax/callback/import যাচাই হয়েছে; full Android type compilation, signed APK, emulator/device, lockscreen push এবং production ৫০ Live/১০০০ user load পরীক্ষা হয়নি। এই workspace-এ Android SDK/original signing secret নেই।

## GitHub থেকে APK
ZIP-এর MY-SHOP-V596 folder-এর ভেতরের contents repository root-এ দিন; .github folder অবশ্যই থাকবে। Existing source ZIP workflow থাকলে V-596 ZIP select করে একই project build করবে। Actions → MY SHOP APK workflow run; successful job → Artifacts → MY_SHOP_FINAL_RELEASE.apk। Original signing/Firebase secrets ব্যবহার করতে হবে; values public source-এ দেবেন না। Workflow package com.myshop.app, V-596/2.9.596 এবং original certificate verify করে একটি canonical APK দেয়। ZIP-এ APK নেই; GitHub build এখনও চালানো হয়নি।

## Backend
APK build Worker deploy করে না। Tested V-596 Worker আলাদাভাবে deploy করতে হবে। Database ID/namespace/signing/package identity unchanged। Deploy-এর পরে /health V-596 নিশ্চিত করুন; একই test window-তে D1 Row Metrics/Insights, join/leave, gift/score-free Live, X summary, ২-device audio ও lockscreen push যাচাই করুন। Diagnostic log প্রয়োজন হলে সাময়িকভাবে D1_DIAGNOSTICS=1, পরে বন্ধ।

References: https://developers.cloudflare.com/d1/observability/metrics-analytics/ এবং https://developers.cloudflare.com/d1/best-practices/use-indexes/ ।
