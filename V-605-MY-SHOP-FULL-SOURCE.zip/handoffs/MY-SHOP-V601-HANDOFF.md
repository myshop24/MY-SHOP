# MY SHOP V601 / 2.9.601 — compact complete-source checkpoint

Owner: Touhid ভাই. Baseline: verified V600 full-source ZIP. Date: 2026-10-12 Asia/Riyadh.
Source ID MY SHOP V-601; versionCode601; versionName2.9.601; com.myshop.app.
Next new delivery V602. V600 remains unchanged. No new signed APK is included.
Read the V600 handoff for inherited membership/Top1 behavior and pending device checks.

## Completed

- Compact full source remains below 25,000,000 bytes using normal ZIP/Deflate.
- Removed only five unused member430_king/queen/royal/vvip/vip WebP ornaments and their
  uncalled MembershipUi.ornament helper. These are the old native frame files that
  were still retained in V600. Static/dynamic name searches found no other references.
- The five premium_membership JPGs remain: PremiumTierActivity and legacy helpers
  still reference them. They were not blindly deleted. Existing custom Admin frame
  URLs, catalog price/day/grant/remove/expiry controls remain unchanged.
- 113 PNG resources are stored as lossless WebP with the same resource basenames,
  qualifier folders, dimensions and every decoded RGBA pixel. No resizing, colour
  loss or reduction of animation frame count/rate occurred. ICC/EXIF/XMP were retained
  where present. Original PNG source copies were removed only after exact comparison.
- 29 generated runtime files are reconstructed from included source before building:
  six GIF frames, twelve procedural ride WAVs, ten legacy gift WAVs and one duplicate
  Queen raw video. They are intentionally absent from the compact ZIP, not from APKs.
- Original video source is included. Four unused reference AAC tracks were removed
  by stream-copy while the complete runtime RGB frame stream remained identical.
  Royal was left intact because a trial affected timing; that trial was rejected.
  Queen's byte-identical source is retained once and copied to the legacy raw resource
  during preparation. No Live/gift/RTC audio code or actual runtime sound bytes changed.
- Gift sound source is stored as lossless FLAC outside Android resources, with the
  original WAV headers. Preparation restores byte-identical original WAVs; Android
  continues using the same WAV resources, not a new playback codec.
- tools/prepare_build_assets.py enforces the V600 SHA256 of every generated runtime
  file plus image pixel/dimension checks. Its manifest includes all sources and hashes.
- Gradle preBuild automatically runs asset preparation. The signed-build script
  installs isolated asset dependencies and prepares assets before source checks/build.
  Included GitHub workflow installs generation dependencies and supports actual root
  ZIP selection/extraction. No file needs to be fetched from an older ZIP.

## Real verification

- Fresh compact ZIP extracted into an empty project: all29 runtime outputs initially
  absent. Included source/scripts rebuilt all29, matching the V600 file bytes exactly.
- tools/v601_verify.sh: passed, including V600/V599 regression, actual SQLite/API
  membership/ranking tests, Java syntax/Context/resource checks, provenance fixtures
  and source ZIP selection tests. Fresh extracted project target verification passed.
- tools/v575_verify.sh: passed; 56 top-level Node test files, zero failed, plus historic
  Worker/SQLite and Java fragment/package/preflight checks. Java source count208.
- Lossless image checks: all113 dimensions and complete RGBA pixel hashes matched.
  Duplicate original PNG copies were detected during verification and removed after
  exact comparison; the final project has no such duplicate resource extensions.
- Android compile attempted: blocked downloading Gradle8.11.1 by Network is unreachable.
  Android SDK unavailable. Parser/fragment checks are not Android compilation.
- Signed build attempted: blocked at ANDROID_HOME missing; original decrypted signing
  key/password credentials are unavailable. No substitute key or renamed old APK.
- Real-device Live/UI/audio/RTC/lock-screen notification checks: not run, pending.
- Production deployment/database modification: none. Wallet/ledger/Level/economy,
  IDs0001/0002/0003, package/signing identity, D1/R2 bindings and realtime logic preserved.

Evidence: verification/v601-*.log and tools/build-assets-manifest.json.
The inherited V600 source/device limitations still apply; compression does not certify
pixel-perfect Android rendering, solve production D1 quota or claim Google Play approval.

## Build/start from this ZIP

Local Linux asset generation is verified; WSL setup is documented but was not tested. Java17 + AndroidSDK36 and
normal Gradle/Firebase/original signing setup are still required. Also install:
ffmpeg, fonts-dejavu-core, Python3.11+ and tools/requirements-build-assets.txt.
GitHub uses Python3.12; the local tested interpreter was 3.12.14.
Run `python3 tools/prepare_build_assets.py`, then local verification or Android build.
Gradle calls preparation automatically; MYSHOP_PYTHON can select the Python interpreter.
The GitHub Android workflow and CI build script handle generation/setup themselves.

Generated files are gitignored and excluded from source ZIP packaging. Always preserve
all source videos, compressed sound sources, scripts, manifest and requirements.
Changing generation inputs requires an owner-approved change and updated expected
hashes; do not silently bypass a mismatch. Re-running old PNG generators may re-create
PNG/WebP duplicates: resolve them before building, preserving approved pixel data.

## Next steps

1. Upload the canonical V601 ZIP through GitHub browser; it is below the25MiB limit.
   Repository root must already contain the actual Android workflow, or install the
   included .github/workflows/my-shop-apk.yml first. ZIP-contained workflow alone
   cannot run. Extracted-root upload is also supported.
2. Run the signed Android workflow with original signing/Firebase secrets. Download
   MY-SHOP-V-601-APK only from that new successful run and verify its provenance.
3. Backend functional logic is unchanged from V600; health/version identity is V601.
   Deploy this Worker if matching V601 identity is needed, using existing authorization
   and bindings; do not reset the database. Original V600 filter/ranking support remains.
4. Perform the V600 real-device visual/Live/notification checklist and accept/refine
   frame edges/custom override behavior. Those tests remain pending.
5. Keep one genuinely built, same-source signed APK only after real build verification.
   Next code/source delivery uses V602, never a second V601 package.
