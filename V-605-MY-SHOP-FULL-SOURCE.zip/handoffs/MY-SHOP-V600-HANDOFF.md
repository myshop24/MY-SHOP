# MY SHOP V600 / 2.9.600 — developer checkpoint

Date: 2026-10-11 UTC. Owner: Touhid ভাই.
Baseline: uploaded V-599-MY-SHOP-FULL-SOURCE.zip, not the APK-only V599 archive.
Source ID: MY SHOP V-600. versionCode600; versionName2.9.600; com.myshop.app.
Next newly created delivery: V601. Do not overwrite V599/V600 or relabel an old APK.

## Completed in source

1. Five membership identities and room-only TOP1 use original supplied video-derived,
   transparent looping GIFs through one shared MembershipIdentityView. Photos stay
   still underneath; the frame uses actual successive video frames, not picture sway.
   KING plaque is corrected to KING; VVIP/VIP labels are present. Original clips,
   hashes, conversion script and all runtime assets are included.
2. Shared membership comment gradients, ornamental double border/corner gems and
   travelling border light; animated identity at the left. Catalog and Live use the
   same palette/background renderer. Paid highlighted comments retain their previous
   distinct treatment. Text/portraits do not sway.
3. Host lifetime completed-gift Top20/Top1 ordering is shared by Live snapshot,
   gift Summary/Your Rank and Creator/Profile Summary. Ties use the earlier last
   positive gift event ID: with positive immutable gift credits this preserves the
   giver who reached the equal total first, i.e. the incumbent. Example: Touhid5000,
   Jabbar4000+1000 → Touhid stays; Jabbar+1 → Jabbar becomes Top1; Touhid+1 back to
   a tie → Jabbar stays. Failed/non-completed gifts are excluded by existing SQL.
4. Existing valuation GOLD price*100 + COIN price is preserved. Separate displayed
   Coin/Diamond totals, commissions, Level/Star thresholds and gift accounting remain
   unchanged. This release does not introduce a currency conversion policy.
5. Top1 is prioritised before the viewer query's LIMIT100, even when the Top1 joined
   behind 100 other users. Only Top1 has membership-overriding priority; Top2/Top3 do
   not. KING/QUEEN share the same tier; wallet Coin descending orders that tier,
   followed by ROYAL, VVIP, VIP. Existing request/seat permissions are untouched.
6. Top1 avatar/comment/mini-profile/entry are contextual to the active Host's Live.
   No purchased membership is required. No global Top1 badge is granted, no automatic
   guest seating occurs, and no MS centre/logo/seat layout replacement occurs.
   Old comment decorations refresh when lifetime leadership changes. Departed users
   can trigger a new entry after returning. Existing gift revision/cache invalidation
   updates the room; no new periodic network polling was added.
7. UserProfile opens with membership frame; Account uses the same renderer. Frame
   expiry is scheduled locally from the server's UTC expiry and restores the plain
   avatar. Backend active/expiry checks remain authoritative. Badge text/detail labels
   refresh with the existing profile API/onResume flow.
8. Main Home/feed/status/composer code is preserved. GeneralUsersActivity alone gets
   ☰, General, KING, QUEEN, ROYAL, VVIP, VIP. General initially shows All Users with
   existing two-column cards, Add Friend/Profile and exact-ID search. Active membership
   filters are server-side, including expiry/revocation, authentication and blocks.
   Pagination is 60 per page with Load More; stale filter responses cannot replace a
   newer selection. A matching-backend echo prevents old Workers displaying All Users
   as a membership-filtered result.
9. Existing Membership shortcut/Store/catalog remains the destination. Own photo/name
   are used for demo and comment; price/day are read from Admin catalog. Supplied
   blue/purple diamond image is placed before Diamond price. Buy Request, Admin red
   entries, ID search/grant/remove and expiry flows are retained, not replaced.
10. Android workflow supports root-source extraction/upload and actual newest-ZIP
    selection/extraction when the workflow is separately installed at repository root.
    The signed APK artifact additionally contains build-provenance.json, tying embedded
    source build/version/package/Git commit, original certificate, APK hash/size and
    source input hash to the same build. No deployment occurs in this workflow.

## Preserved and scope evidence

No wallet/ledger/database records were changed and no production API was called.
D1/R2/Durable Object bindings, package, original encrypted signing setup and expected
certificate are retained. Main Admin IDs remain 0001/0002/0003.
RTC/audio, locked-device push, notification services and unrelated modules are unchanged.
V575 preservation test checks 310 locked V573 Worker functions exactly; the three newly
allowed functions are newPeople, liveGiftSummary and liveCreatorCenter, tested separately.
The existing allowed liveRoomState changes are limited to lifetime ranking/roster order.
Full baseline delta is recorded in verification/v600-change-manifest.json.
No source/asset/schema/migration/test/workflow/historical handoff was removed. No temporary
build output or old APK is packaged. Historical files were kept when references/usage
could not justify removal; size was not reduced by dropping required material.

## Actual verification

| Check | Result / limitation |
| --- | --- |
| tools/v575_verify.sh | PASS; 56 top-level Node test files passed, 0 failed; additional historical Worker/SQLite, Java targeted checks and package/preflight checks passed. |
| tools/v600_verify.sh | PASS; includes V599 regression, Java syntax/Context/package checks, V600 API/SQLite ranking/filter/pagination tests, source-selector and asset/provenance checks. |
| V600 ranking/filter tests | Actual shipped Worker functions and SQL run against real in-memory SQLite. Tie/+1/room restart/Host isolation, original conversion, active/expired filters, invalid TOP1 filter, auth, pagination, pre-LIMIT priority and KING/QUEEN Coin ordering passed. |
| Assets | Six original clip hashes, animated GIF frame differences, loops and transparent portrait centres checked. Conversion frames were visually inspected locally; not Android/device screenshots. |
| Provenance verifier | DEX-string fixtures passed matching identity and rejected stale version/commit/package. Fixtures are not signed APKs. |
| Android full compile | BLOCKED: Gradle8.11.1 distribution download returned Network is unreachable. Android SDK unavailable locally. Parser/type-fragment checks are not Android compilation. |
| New signed release APK | NOT BUILT; build-only script also stops at ANDROID_HOME missing. Original decrypted key/password credentials are unavailable locally; no replacement key was created. No V600 APK in this ZIP. |
| Real device / Live / RTC / lock-screen notification | NOT RUN. Remain pending; source regression is not a device pass. |
| Production Worker / D1 / R2 deployment | NOT PERFORMED. Matching V600 Worker update is required. |

Evidence logs: verification/v600-regression.log, v600-target.log, v600-compile.log,
v600-signed.log. They contain no supplied signing credential values.

## Known issues / acceptance still needed

- Exact animation edges, profile placement, comment clipping, frame smoothness, entry
  effect placement and reference parity need Android/device visual acceptance. GIFs are
  256×256/12fps for bounded cost, not full-resolution original video playback. Source
  background extraction can affect fine white highlights and Top1's bright diagonal
  sweep; retain/refine from original clips if device review rejects those edges.
- Existing reduced-animation/low-memory policy and system disabled animators show a
  still frame instead of playing motion. Profile expiry trusts local time for visual
  removal; entitlement/API expiry remains server-authoritative.
- Existing Admin custom PNG/GIF/WebP frame URLs retain precedence and their previous
  320×275 portrait geometry. A blank URL uses the new original-video template. Shop,
  profile and Live/comment identity share the configured frame; TOP1 ignores custom
  membership URLs and stays contextual. Exact reference acceptance must check for any
  old production-configured custom override. Remote MP4 frame upload playback is not
  added; original supplied videos are bundled as supported transparent GIF frames.
- Overall production D1 quota/row-read usage and loading performance were not measured
  or fixed globally. This release reduces the General first page from500 to60 and uses
  local/shared frame assets, but does not claim the production quota problem is solved.
- Source/backend changes do not certify Google Play approval or audit the full existing
  billing/privacy policies. Existing payment logic was preserved.
- An older Worker cannot provide the new membership filter or ranking behavior. Follow
  UPLOAD-INSTRUCTIONS-BN.md for matching backend/build; old source/APKs are unnecessary.

## Next steps from this exact ZIP

1. Install all extracted project files at repository root including .github; retain
   original signing/Firebase secrets. Run MY SHOP Android APK for the new commit.
2. Resolve any actual Android compile/lint/unit-test failure using the first failing
   step. Confirm package/version/source/commit/certificate/hash from the new artifact.
3. Deploy the matching Worker only with the owner's existing deployment authorization,
   retaining current bindings/data. No new schema migration/data reset is needed for
   these read-model changes. Existing V599 permission support is included.
4. On real devices, test a non-member Top1 joining and leaving, switching Hosts,
   gift ties/+1/restarts, >100 viewers, equal-tier Coin order, membership grant/remove/
   expiry, catalog/Live/profile visual parity and plain post/status avatars.
5. Regression on two devices: Join, Invite, all seats, comments, gifts, Mute/Unmute,
   End/❌, minimize, foreground/background and locked-device notifications. Test slow
   network/error/retry and low-memory/reduce-motion behavior separately.
6. After a genuine same-source V600 signed build, keep one explicitly verified release
   APK in a release package with its provenance; do not invent success or rename V599.
   Any new source changes/new delivery must use V601 and update this checkpoint.
