# Exact legacy gift sound source

These FLAC files losslessly store the original PCM. The asset manifest also retains
each original44-byte WAV header. prepare_build_assets.py restores the exact original
WAV file and checks its V600 SHA256. Android keeps its existing WAV playback resources;
there is no Live/RTC/playback codec change. Procedural ride sources are in the existing
tools/generate_ride_sounds.py and all twelve outputs are likewise byte-verified.
