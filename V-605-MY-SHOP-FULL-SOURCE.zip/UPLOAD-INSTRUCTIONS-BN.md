## V604 compact source
২৫MB-এর নিচের V604 ZIP repository root-এ upload করে নতুন commit/build চালান। Root Android workflow আগে থাকতে হবে; ZIP-এর ভিতরের workflow নিজে থেকে চলবে না। নতুন সফলV604 run-এর Artifacts থেকে MY_SHOP_FINAL_RELEASE.apk পাবেন। ZIP-এ APK নেই। Original signing/Firebase secrets লাগবে।

## V603 আংশিক checkpoint
নতুন30 ride animation অসম্পূর্ণ; handoff পড়ুন। ZIP-এ APK নেই। Root workflow install করে নতুন V603 build চালাতে হবে। Source ZIP25MB ছাড়ালে Git CLI দিয়ে upload করুন অথবা Extract করে সব filesসহ .github root-এ দিন। Worker matching update Host-exclusion-এর জন্য প্রয়োজন; DB reset নয়।

## V602 build সংশোধন
পুরোনো permanent pipeline সরাসরি Gradle চালালেও GitHub Actions-এ ffmpeg/font/Python dependency প্রস্তুত হবে। নতুন V602 ZIP upload করে নতুন commit/run চালান; পুরোনো V601 run Re-run করলে নতুন fix আসবে না। এই ZIP-এ APK নেই। নতুন সফল V602 build থেকে signed APK নিন।

# V602 / 2.9.602 — পূর্ণ project আপলোড ও signed APK

## পদ্ধতি ১ — Extract করে repository root (প্রস্তাবিত)

১. V-602-MY-SHOP-FULL-SOURCE.zip Extract করুন। ZIP-এর ভেতরে project root সরাসরি আছে।
২. একই MY SHOP repository-এর root-এ সব source files/folders দিন: app, backend, gradle,
   gradlew, build.gradle, settings.gradle, tools, tests, design, verification, handoffs,
   rules এবং SOURCE_BUILD_ID.txt/SOURCE_VERSION_NAME.txt। লুকানো `.github`-ও দিতে হবে।
   app আর .github-কে অতিরিক্ত V601 folder-এর ভেতরে রেখে শুধু সেই folder আপলোড করবেন না।
৩. `.github/workflows/my-shop-apk.yml` root-এ বাস্তবে আছে নিশ্চিত করুন। পুরোনো original
   signing/Firebase/Cloudflare credentials, package ও certificate অক্ষত রাখুন।
   Plaintext password/key source বা log-এ দেবেন না।
৪. Commit করুন। Actions → **MY SHOP Android APK** → নতুন commit-এর run দেখুন;
   প্রয়োজন হলে Run workflow দিন। Pages success APK build নয়।

## পদ্ধতি ২ — শুধু ZIP দিয়ে source নির্বাচন

Root-এ `.github/workflows/my-shop-apk.yml` আগে থেকেই install করতে হবে; ZIP-এর ভিতরের
workflow GitHub নিজে চালায় না। তারপর canonical ZIP root-এ অপরিবর্তিত নামে commit দিন।
Workflow বাস্তবে newest versioned ZIP নির্বাচন, safe extraction, identity check করে
ওই extracted source build করে। Stale root source-এর চেয়ে নতুন V601 ZIP নির্বাচন হবে।
একই newest version-এর একাধিক source ZIP রাখবেন না।

এই canonical ZIP ২৫,০০০,০০০ bytes-এর নিচে, তাই GitHub browser-এর25MiB single-file
limit-এর মধ্যে আছে। শুধু ZIP upload-এর আগে root-এ Android workflow install থাকতে হবে।
Build-এ generated assets নিজস্ব source থেকে তৈরি হয়; BUILD-ASSETS-BN.md পড়ুন।
পুরোনো ZIP থেকে ফাইল লাগবে না। Included workflow/CI script generation dependencies
প্রস্তুত করে। পুরোনো অজানা Pages/permanent workflow-এর বদলে included Android workflow
install/update করুন; সবুজ Pages build APK নয়।

## Original signing ও Firebase

Repo Actions secrets আগের মতো ব্যবহার করুন:
MYSHOP_KEYSTORE_PASSWORD, MYSHOP_KEY_ALIAS, MYSHOP_KEY_PASSWORD এবং original key-এর
MYSHOP_KEYSTORE_BASE64 অথবা আগে ব্যবহৃত encrypted-key restore/cache setup।
নতুন key তৈরি করবেন না। Expected original certificate SHA256:
4c6784cd027679169b60168a3dec744858c56ab681f860880cea435bb2992acd

Firebase client config app/google-services.json বা আগের MYSHOP_FIREBASE_API_KEY,
MYSHOP_FIREBASE_APP_ID, MYSHOP_FIREBASE_PROJECT_ID, MYSHOP_FIREBASE_SENDER_ID secrets।
Secret-এর আসল মান ZIP/চ্যাট/log-এ নয়। প্রয়োজনীয় নিরাপদ credentials ছাড়া signed build হবে না।

## একই build-এর APK download ও যাচাই

সফল নতুন **Android** run → Artifacts → **MY-SHOP-V-602-APK** download/unzip করুন।
একটি MY_SHOP_FINAL_RELEASE.apk এবং একই run-এর build-provenance.json পাওয়া যাবে।
Workflow apksigner, original certificate, zipalign, package/version এবং APK DEX-এ
embedded SOURCE_BUILD_ID/version/Git commit SHA যাচাই করে artifact দেয়।
Provenance-এ একই APK hash/size, source input hash, commit SHA ও run ID থাকবে।
Expected: com.myshop.app; versionCode601; versionName2.9.601; MY SHOP V-602।
পুরোনো run/APK download করবেন না। Build ব্যর্থ হলে ওই run-এর প্রথম failed step ঠিক করুন।

## Matching backend

এই APK-এর General tier filter এবং Host lifetime tie/order-এর জন্য এই ZIP-এর
backend/worker update দরকার। V599 থেকে পাওয়া operational permission update-ও এই
source-এ আছে। Existing Wrangler D1/R2/Durable Object bindings/secrets অপরিবর্তিত রাখুন।
Authorized deployment আলাদাভাবে করুন; Android workflow Worker deploy করে না।
নতুন table/data reset প্রয়োজন নেই; বিদ্যমান completed gift ledger ও active badges ব্যবহৃত।

## এই ZIP-এর প্রকৃত APK অবস্থা

**নতুন signed V601 APK নেই।** Local compile Gradle distribution download-এ
Network is unreachable দিয়ে আটকে গেছে; Android SDK ও original signing credentials
এই environment-এ নেই। পুরোনো V599 APK নতুন নামে রাখা হয়নি। Source/backend checks
signed APK বা device/RTC/UI/lock-screen notification পরীক্ষা নয়। Device checklist
handoffs/MY-SHOP-V601-HANDOFF.md-তে আছে।
