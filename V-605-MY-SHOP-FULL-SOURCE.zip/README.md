Current V604 /2.9.604: read handoffs/MY-SHOP-V604-HANDOFF.md. Canonical source<=25,000,000 bytes. Next deliveryV605. No APK; inherited partial work recorded.

# MY SHOP V603 /2.9.603 — PARTIAL CHECKPOINT

All9 work is NOT complete. See handoffs/MY-SHOP-V603-HANDOFF.md. New30 articulated rides and full wing/fire emblem animations pending. No signed APK/device verification.

# MY SHOP V602 / 2.9.602

Complete compact source; start with AGENTS.md and the developer policy/instructions.
Read MY-SHOP-DEVELOPER-HANDOFF.md, handoffs/MY-SHOP-V601-HANDOFF.md and BUILD-ASSETS-BN.md.
Upload/build: UPLOAD-INSTRUCTIONS-BN.md. All inputs/scripts are included; no older ZIP needed.

Generated GIF/WAV/runtime duplicate assets are restored byte-for-byte before build.
Lossless images retain every original RGBA pixel. Local/fresh-extract source/backend
checks passed; Android compile/signed APK and real-device Live/UI are not verified.
No new V601 APK or production deployment is included. Original package, signing,
user IDs, economy and bindings are preserved. Next newly created delivery: V602.
