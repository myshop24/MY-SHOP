# MY SHOP — Developer Instructions (Permanent Master Rules)

## 0. READ THIS FIRST — NON-NEGOTIABLE
Before opening, editing, replacing, deploying, building, or otherwise working on ANY MY SHOP project file, a developer/AI must read this document first.

This file is the project's permanent handoff/continuation guide. It must remain at the project root with the `00-` prefix so it is encountered before ordinary project files.

**Do not treat MY SHOP as a new project.** Continue from the latest valid sequential V-number and preserve all older versions.

## 1. LIVE VERSION / VERSIONING RULE
- Current development line: **V-183**.
- Previous protected version: **V-182**.
- Next release must use the next sequential V-number: V-184, then V-185, etc.
- Never overwrite or delete V-179, V-180, V-181, V-182, or any older protected version.
- Before creating a new release, make a complete backup/copy of the previous release.
- Every new release must contain its own SOURCE_BUILD_ID and release notes.
- The newest V-numbered source is the only source allowed for the next build/release.

## 2. HOW THIS DOCUMENT STAYS CURRENT
Whenever a new requirement, confirmed bug, architectural decision, security rule, deployment rule, or completed feature is learned during development:
1. Add it to this document in the appropriate section.
2. If it is a new historical event/decision, append it to **Section 12 — Running Project Change Log** with the V-number and date.
3. Do not silently remove older rules unless the rule was explicitly superseded; if superseded, record what changed and why.
4. The newest confirmed information has priority over older notes, but protected historical versions must not be rewritten.

## 3. PROJECT PURPOSE
MY SHOP is a mobile-first shopping/live-streaming platform with:
- User registration/login and account management.
- Dashboard, live categories, feed, gallery, banners and managed links.
- Live-streaming related features such as GO LIVE / JOIN LIVE.
- Admin-controlled content, ads, banners and media.
- Cloudflare Worker backend, D1 database and R2 media storage.
- Future monetization including startup advertisements and Google Ads-compatible placement.

## 4. CORE SAFETY / PRESERVATION RULES
- Do not remove or replace a working feature unless the user explicitly asks for it.
- Prefer additive, backward-compatible changes.
- Never overwrite a protected version.
- Before modifying/deploying production-related code, preserve a rollback copy.
- Never claim an APK or live deployment succeeded without actual build/deployment evidence.
- If live Cloudflare credentials/status are unavailable, say so instead of guessing.

## 5. PERMANENT USER / ADMIN IDENTITY RULE — CRITICAL
The Permanent User/Admin ID is immutable and globally unique.

- Never change, delete, recycle, overwrite, or reassign a Permanent User/Admin ID.
- A deleted/deactivated account's Permanent ID must never be reused by another account.
- Identity history must remain available for audit, transactions, moderation and account history.
- Email/mobile/password are credentials and may be reset/updated by authorized Admin without changing the Permanent ID.
- User may change profile photo and normal profile settings, but cannot change Permanent ID.
- Account removal must use a soft status such as ACTIVE / SUSPENDED / DISABLED / DEACTIVATED instead of hard-deleting the identity record.
- Enforce this rule in Android UI, Worker backend and D1 database constraints/logic.
- Passwords must never be stored in plaintext.
- Credential changes should be auditable.

## 6. AUTHENTICATION / GOOGLE LOGIN
Existing login must remain available:
- Email / Mobile / User ID + Password.
- Existing session/token backend flow must remain intact.
- Existing roles: USER / ADMIN / MODERATOR.
- Forgot-password/security-question flow must remain intact.

Google Login is an additional login option, not a replacement.
- Current V-183 state: Google button/UI exists, but real Google OAuth is not live without valid Google Cloud configuration.
- Never grant ADMIN based only on a Gmail address.
- Google identity must be linked to the existing account/Permanent ID and backend role must determine Admin access.
- When implementing real OAuth, prefer current Google-recommended Credential Manager / Google Identity Services.
- Verify Google ID tokens server-side; use Google's stable `sub` identifier for account linkage.

## 7. STARTUP AD
Desired flow:
**App Open → Startup Advertisement → countdown/Skip → Login → Google or normal Login → Dashboard**

Current implementation:
- Startup ad is managed from Admin Dashboard Ads.
- Slot key: `startup_ad`, slot `1`.
- Display duration is configurable (1–60 seconds; current default/fallback is 3 seconds).
- Admin can change photo, save, delete, set target link and display duration.
- If backend is unavailable, app uses bundled fallback startup artwork.
- Future Google Ads integration must respect Google's actual ad format/policy; do not assume an arbitrary forced duration for Google-served ads.

## 8. ADMIN / CONTENT MANAGEMENT
Admin panels must remain Admin-only and must not expose management controls to ordinary users.

Managed areas include, as applicable:
- Dashboard ads/startup ad.
- Banners.
- Gallery/media.
- Dashboard configuration.
- Feature buttons.
- Social links.
- Managed external links.
- Other content-management folders already present in the project.

Known V-182 issue to solve in the next release:
- User reported that **all Admin Add/Save/Link/content features** fail, not only Banner upload.
- Banner error shown: `Upload failed: Banner save failed safely; the previous banner was kept.`
- This strongly suggests a shared backend/D1 write-path, schema, active Worker/database mismatch, or related infrastructure problem rather than one isolated UI feature.
- Do not assume the exact root cause without logs/probes.

## 9. BACKEND / CLOUDFLARE
Architecture:
- Cloudflare Worker backend.
- D1 database: `my-shop-db`.
- R2 media bucket: `my-shop-media`.
- Worker name: `rapid-bush-62ea`.
- App/backend URL currently configured in source: `https://rapid-bush-62ea.myshopsatkania.workers.dev`.

Important:
- Live environment cannot be assumed healthy from source code alone.
- Current deep health is mostly read-only; it must be strengthened before relying on it as a write-health guarantee.
- Do not silently swallow schema/migration errors.

## 10. REQUIRED NEXT BACKEND HARDENING
For the next appropriate release, implement and verify:
1. D1 table + required column + index/constraint checks.
2. D1 write → verify → cleanup probe.
3. R2 put → verify/head → delete probe.
4. Auto schema repair with surfaced errors, not silent catches.
5. Safe compensation/rollback if R2 succeeds but D1 fails.
6. Atomic/batched D1 writes where appropriate.
7. Admin System Health diagnostics showing the actual failing layer.
8. GitHub Actions must refuse release/build when required D1/R2 write probes fail.
9. Protect production write probes with appropriate admin/secret authorization.

## 11. BUILD / RELEASE RULES
- Android Java project.
- Expected build environment: Java 17, Android SDK 36, Gradle 8.11.1.
- GitHub Actions is the expected build path when local Gradle/SDK is unavailable.
- Release must use the newest V-numbered source ZIP.
- Workflow must reject older source versions.
- Preserve permanent signing configuration.
- Produce one release APK artifact.
- Verify Worker health and version/build identity after deployment.

## 12. RUNNING PROJECT CHANGE LOG
### V-183 — 2026-09-04
- Added this permanent Developer Instructions master file.
- Established the rule that this document must be read before any project file is handled.
- Established automatic accumulation of new confirmed project information in this document.
- Added permanent identity/ID immutability rules to the handoff guide.
- Recorded the V-182 Admin content save failure as an unresolved shared backend/infrastructure issue for the next fix cycle.

### V-182 — 2026-09-04
- Added startup advertisement management and bundled startup artwork.
- Added Admin startup-ad controls.
- Added configurable startup-ad duration.
- Fixed dashboard ad upload handling around file type.
- Preserved earlier login and dashboard functionality.

### V-181 — 2026-09-04
- Fixed startup ad image presentation to avoid unwanted cropping.
- Fixed LoginActivity so an existing session does not silently skip the login screen when user needs to choose Google/normal login.

### V-180 — 2026-09-04
- Added Google Login UI/config placeholder.
- Added startup advertisement concept.
- Preserved existing login backend/session logic.

## 13. WORKING PRINCIPLE FOR EVERY FUTURE DEVELOPER/AI
At the start of every task:
1. Read `00-MY-SHOP-DEVELOPER-INSTRUCTIONS.md`.
2. Identify the latest V-number.
3. Identify the exact feature/bug being changed.
4. Preserve the previous version before editing.
5. Make the smallest safe change that solves the requested issue.
6. Update this document with every new confirmed project fact.
7. Add release notes and SOURCE_BUILD_ID.
8. Validate syntax/integrity and, where possible, build/test.
9. Never claim success without evidence.
10. Deliver the new sequential V-number without replacing older versions.

**This document is the first source of truth for project continuation.**
