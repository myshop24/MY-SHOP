package com.myshop.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;

public class AudioLiveRoomActivity extends AppCompatActivity {
    private final Handler handler = new Handler();
    private boolean host;
    private String hostId;
    private LinearLayout seats;
    private LinearLayout requests;
    private TextView viewers;
    private TextView status;
    private TextView syncState;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            refresh();
            if (host) {
                BackendClient.setLivePresence(SessionManager.getToken(AudioLiveRoomActivity.this), true, new Silent());
            }
            handler.postDelayed(this, 5000);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        host = getIntent().getBooleanExtra("hostMode", false);
        hostId = host ? SessionManager.getUserId(this) : getIntent().getStringExtra("hostId");
        if (hostId == null || hostId.trim().isEmpty()) hostId = SessionManager.getUserId(this);

        build();
        // Render immediately so the 12-seat room never collapses while the backend is loading.
        renderLocalSeatSkeleton();

        if (host) {
            BackendClient.setLivePresence(SessionManager.getToken(this), true, new BackendClient.Callback() {
                @Override public void onSuccess(JSONObject d) { runOnUiThread(() -> { syncState.setText("● LIVE • Room connected"); refresh(); }); }
                @Override public void onError(String m) { runOnUiThread(() -> syncState.setText("● LIVE • Connecting room…")); }
            });
        } else {
            BackendClient.liveViewer(SessionManager.getToken(this), hostId, true, new Silent());
        }
        handler.post(tick);
    }

    private void build() {
        ScrollView sc = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(22));
        root.setBackgroundColor(Color.rgb(3, 8, 34));
        sc.addView(root);

        LinearLayout top = row();
        TextView brand = t("👑  MY SHOP\nLIVE AUDIO ROOM", 18, Color.WHITE, true);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(brand, new LinearLayout.LayoutParams(0, dp(58), 1));
        TextView badge = t("● AUDIO LIVE", 13, Color.rgb(255, 75, 130), true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(bg(Color.rgb(35, 16, 67), Color.rgb(255, 67, 149), 20));
        top.addView(badge, new LinearLayout.LayoutParams(dp(118), dp(42)));
        root.addView(top);

        TextView title = t("🎙️  আড্ডা, গান আর ভালো মানুষের গল্প\nLet's Talk Together", 18, Color.WHITE, true);
        title.setPadding(0, dp(12), 0, dp(6));
        root.addView(title);

        viewers = t("👁 0 Listeners     🎧 High Quality Audio", 13, Color.rgb(177, 208, 255), true);
        root.addView(viewers);

        status = t((host ? "👑 Host" : "🎧 Audience") + " • ID " + SessionManager.getUserId(this), 13, Color.rgb(226, 199, 255), true);
        status.setPadding(0, dp(8), 0, dp(2));
        root.addView(status);

        syncState = t("● LIVE • Connecting room…", 11, Color.rgb(149, 172, 232), false);
        syncState.setPadding(0, 0, 0, dp(10));
        root.addView(syncState);

        TextView seatTitle = t("12-SPEAKER AUDIO ROOM", 13, Color.rgb(220, 225, 255), true);
        seatTitle.setGravity(Gravity.CENTER);
        seatTitle.setPadding(0, dp(6), 0, dp(8));
        root.addView(seatTitle);

        seats = new LinearLayout(this);
        seats.setOrientation(LinearLayout.VERTICAL);
        seats.setPadding(dp(7), dp(7), dp(7), dp(7));
        seats.setMinimumHeight(dp(360));
        seats.setBackground(bg(Color.rgb(8, 20, 66), Color.rgb(88, 71, 218), 20));
        root.addView(seats, new LinearLayout.LayoutParams(-1, -2));

        if (host) {
            TextView rq = t("Join Requests", 16, Color.WHITE, true);
            rq.setPadding(0, dp(14), 0, dp(6));
            root.addView(rq);
            requests = new LinearLayout(this);
            requests.setOrientation(LinearLayout.VERTICAL);
            root.addView(requests);
            requests.addView(t("No pending requests", 12, Color.LTGRAY, false));
        } else {
            Button req = btn("🎤 Request to Speak");
            req.setOnClickListener(v -> BackendClient.liveSpeakRequest(SessionManager.getToken(this), hostId, new ToastCb("Request sent")));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(52));
            rp.topMargin = dp(12);
            root.addView(req, rp);
        }

        TextView chat = t("💬 Live Chat     ❤️ Reactions     ↗ Share", 14, Color.WHITE, true);
        chat.setGravity(Gravity.CENTER);
        chat.setPadding(0, dp(18), 0, dp(14));
        root.addView(chat);

        LinearLayout controls = row();
        String[] items = host
                ? new String[]{"🔇\nMute All", "➕\nInvite", "👥\nGuests", "💬\nComments", "⚙\nMore"}
                : new String[]{"🎤\nMic", "💬\nComments", "❤️\nReact", "↗\nShare", "⚙\nMore"};
        for (String item : items) {
            TextView v = t(item, 11, Color.WHITE, true);
            v.setGravity(Gravity.CENTER);
            v.setBackground(bg(Color.rgb(13, 29, 76), Color.rgb(72, 78, 176), 14));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(58), 1);
            lp.setMargins(dp(2), 0, dp(2), 0);
            controls.addView(v, lp);
        }
        root.addView(controls);

        Button end = btn(host ? "End Live" : "Leave Room");
        end.setBackground(bg(Color.rgb(111, 41, 211), Color.rgb(226, 55, 255), 18));
        end.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, dp(56));
        ep.topMargin = dp(14);
        root.addView(end, ep);

        setContentView(sc);
    }

    private void renderLocalSeatSkeleton() {
        seats.removeAllViews();
        for (int base = 1; base <= 12; base += 4) {
            LinearLayout r = row();
            for (int n = base; n < base + 4; n++) {
                String text;
                if (n == 1) {
                    text = "1\n👑\nHost\nID " + hostId;
                } else {
                    text = n + "\n＋\nOpen Seat";
                }
                TextView v = seat(text, n == 1, false);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(112), 1);
                lp.setMargins(dp(3), dp(3), dp(3), dp(3));
                r.addView(v, lp);
            }
            seats.addView(r);
        }
    }

    private void refresh() {
        BackendClient.liveRoomState(SessionManager.getToken(this), hostId, new BackendClient.Callback() {
            @Override public void onSuccess(JSONObject d) {
                runOnUiThread(() -> {
                    syncState.setText("● LIVE • Synced");
                    render(d);
                });
            }
            @Override public void onError(String m) {
                runOnUiThread(() -> {
                    syncState.setText("● LIVE • Waiting for room sync");
                    // Keep the visible 12-seat room instead of collapsing it on network/backend failure.
                    if (seats.getChildCount() == 0) renderLocalSeatSkeleton();
                });
            }
        });
    }

    private void render(JSONObject d) {
        viewers.setText("👁 " + d.optInt("viewerCount", 0) + " Listeners     🎧 High Quality Audio");
        status.setText((host ? "👑 Host" : "🎧 " + d.optString("myRole", "AUDIENCE")) + " • ID " + SessionManager.getUserId(this));

        seats.removeAllViews();
        JSONArray a = d.optJSONArray("seats");
        for (int base = 1; base <= 12; base += 4) {
            LinearLayout r = row();
            for (int n = base; n < base + 4; n++) {
                JSONObject found = null;
                if (a != null) {
                    for (int i = 0; i < a.length(); i++) {
                        JSONObject x = a.optJSONObject(i);
                        if (x != null && x.optInt("seat_no") == n) { found = x; break; }
                    }
                }
                String text;
                boolean occupied = found != null;
                if (occupied) {
                    String name = found.optString("full_name", n == 1 ? "Host" : "Speaker");
                    text = n + "\n" + (n == 1 ? "👑" : "🎙") + "\n" + name + "\nID " + found.optString("user_id");
                } else {
                    text = n + "\n＋\nOpen Seat";
                }
                TextView v = seat(text, n == 1, occupied);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(112), 1);
                lp.setMargins(dp(3), dp(3), dp(3), dp(3));
                r.addView(v, lp);
            }
            seats.addView(r);
        }

        if (host && requests != null) {
            requests.removeAllViews();
            JSONArray q = d.optJSONArray("requests");
            if (q == null || q.length() == 0) {
                requests.addView(t("No pending requests", 12, Color.LTGRAY, false));
            } else {
                for (int i = 0; i < q.length(); i++) {
                    JSONObject x = q.optJSONObject(i);
                    if (x == null) continue;
                    LinearLayout rr = row();
                    TextView nm = t(x.optString("full_name", "User") + "  • ID " + x.optString("user_id"), 13, Color.WHITE, true);
                    rr.addView(nm, new LinearLayout.LayoutParams(0, dp(48), 1));
                    Button ok = small("Accept");
                    Button no = small("Decline");
                    String id = x.optString("user_id");
                    ok.setOnClickListener(v -> BackendClient.liveRequestAction(SessionManager.getToken(this), id, true, new ToastCb("Speaker accepted")));
                    no.setOnClickListener(v -> BackendClient.liveRequestAction(SessionManager.getToken(this), id, false, new ToastCb("Request declined")));
                    rr.addView(ok);
                    rr.addView(no);
                    requests.addView(rr);
                }
            }
        }
    }

    private TextView seat(String s, boolean isHost, boolean occupied) {
        TextView v = t(s, 11, Color.WHITE, true);
        v.setGravity(Gravity.CENTER);
        int fill = isHost ? Color.rgb(28, 34, 102) : (occupied ? Color.rgb(16, 47, 99) : Color.rgb(11, 28, 74));
        int stroke = isHost ? Color.rgb(173, 84, 255) : (occupied ? Color.rgb(46, 175, 255) : Color.rgb(74, 74, 151));
        v.setBackground(bg(fill, stroke, 16));
        return v;
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(tick);
        if (host) {
            BackendClient.setLivePresence(SessionManager.getToken(this), false, new Silent());
        } else {
            BackendClient.liveLeaveSeat(SessionManager.getToken(this), hostId, new Silent());
            BackendClient.liveViewer(SessionManager.getToken(this), hostId, false, new Silent());
        }
        super.onDestroy();
    }

    class ToastCb implements BackendClient.Callback {
        String ok;
        ToastCb(String s) { ok = s; }
        @Override public void onSuccess(JSONObject d) { runOnUiThread(() -> { Toast.makeText(AudioLiveRoomActivity.this, ok, Toast.LENGTH_SHORT).show(); refresh(); }); }
        @Override public void onError(String m) { runOnUiThread(() -> Toast.makeText(AudioLiveRoomActivity.this, m, Toast.LENGTH_SHORT).show()); }
    }

    static class Silent implements BackendClient.Callback {
        @Override public void onSuccess(JSONObject d) {}
        @Override public void onError(String m) {}
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private Button btn(String s) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setBackground(bg(Color.rgb(76, 45, 205), Color.rgb(217, 46, 255), 18));
        return b;
    }

    private Button small(String s) {
        Button b = btn(s);
        b.setTextSize(11);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        return b;
    }

    private TextView t(String s, float z, int c, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(z);
        v.setTextColor(c);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private GradientDrawable bg(int a, int st, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(a);
        g.setCornerRadius(dp(r));
        g.setStroke(dp(1), st);
        return g;
    }

    private int dp(float x) { return (int) (x * getResources().getDisplayMetrics().density + .5f); }
}
