package com.myshop.app;

import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;

/**
 * V-284 premium Audio Live room batch.
 * UI is intentionally programmatic so it can be introduced without replacing
 * the approved Dashboard/activity_main.xml structure.
 */
public class AudioLiveRoomActivity extends AppCompatActivity {
    private final Handler handler = new Handler();
    private boolean host;
    private String hostId;
    private LinearLayout hostArea;
    private LinearLayout specialArea;
    private LinearLayout seats;
    private LinearLayout requests;
    private TextView viewers;
    private TextView status;
    private TextView syncState;
    private String specialGuestId = "";

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (host) {
                BackendClient.setLivePresence(SessionManager.getToken(AudioLiveRoomActivity.this), true, new Silent());
            } else {
                // Viewer heartbeat makes listener count de-duplicated and self-healing.
                BackendClient.liveViewer(SessionManager.getToken(AudioLiveRoomActivity.this), hostId, true, new Silent());
            }
            refresh();
            handler.postDelayed(this, 5000);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        host = getIntent().getBooleanExtra("hostMode", false);
        hostId = host ? SessionManager.getUserId(this) : getIntent().getStringExtra("hostId");
        if (hostId == null || hostId.trim().isEmpty()) hostId = SessionManager.getUserId(this);

        build();
        renderLocalSkeleton();

        if (host) {
            BackendClient.setLivePresence(SessionManager.getToken(this), true, new BackendClient.Callback() {
                @Override public void onSuccess(JSONObject d) { runOnUiThread(() -> { syncState.setText("● LIVE • Room connected"); refresh(); }); }
                @Override public void onError(String m) { runOnUiThread(() -> syncState.setText("● LIVE • Reconnecting…")); }
            });
        } else {
            BackendClient.liveViewer(SessionManager.getToken(this), hostId, true, new Silent());
        }
        handler.post(tick);
    }

    private void build() {
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        LinearLayout root = col();
        root.setPadding(dp(12), dp(12), dp(12), dp(26));
        root.setBackgroundColor(Color.rgb(3, 8, 34));
        sc.addView(root);

        LinearLayout top = row();
        TextView brand = t("👑 MY SHOP\nAUDIO LIVE", 18, Color.WHITE, true);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(brand, new LinearLayout.LayoutParams(0, dp(58), 1));
        TextView badge = t("● LIVE", 13, Color.rgb(255, 92, 158), true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(bg(Color.rgb(35, 16, 67), Color.rgb(255, 67, 149), 20));
        top.addView(badge, new LinearLayout.LayoutParams(dp(92), dp(40)));
        root.addView(top);

        TextView title = t("🎙️ Let's Talk Together", 17, Color.WHITE, true);
        title.setPadding(0, dp(9), 0, dp(4));
        root.addView(title);

        viewers = t("👁 0 Listeners   •   🎧 Audio Live", 13, Color.rgb(177, 208, 255), true);
        root.addView(viewers);
        status = t((host ? "👑 Host" : "🎧 Audience") + " • ID " + SessionManager.getUserId(this), 12, Color.rgb(226, 199, 255), true);
        status.setPadding(0, dp(6), 0, 0);
        root.addView(status);
        syncState = t("● LIVE • Connecting…", 11, Color.rgb(149, 172, 232), false);
        syncState.setPadding(0, dp(2), 0, dp(10));
        root.addView(syncState);

        // Host stays fixed at upper-left. Special Guest is a separate center spotlight.
        LinearLayout hero = row();
        hero.setGravity(Gravity.TOP);
        hostArea = col();
        hero.addView(hostArea, new LinearLayout.LayoutParams(dp(122), -2));
        specialArea = col();
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, -2, 1);
        sp.leftMargin = dp(8);
        hero.addView(specialArea, sp);
        root.addView(hero);

        TextView seatTitle = t("SPEAKER SOFA • SEATS 2–12", 12, Color.rgb(220, 225, 255), true);
        seatTitle.setGravity(Gravity.CENTER);
        seatTitle.setPadding(0, dp(12), 0, dp(7));
        root.addView(seatTitle);

        seats = col();
        seats.setPadding(dp(5), dp(5), dp(5), dp(5));
        seats.setBackground(bg(Color.rgb(8, 20, 66), Color.rgb(88, 71, 218), 20));
        root.addView(seats, new LinearLayout.LayoutParams(-1, -2));

        if (host) {
            TextView rq = t("Join Requests", 15, Color.WHITE, true);
            rq.setPadding(0, dp(13), 0, dp(5));
            root.addView(rq);
            requests = col();
            root.addView(requests);
            requests.addView(t("No pending requests", 12, Color.LTGRAY, false));
        } else {
            Button req = btn("🎤 Request to Speak");
            req.setOnClickListener(v -> BackendClient.liveSpeakRequest(SessionManager.getToken(this), hostId, new ToastCb("Request sent")));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(48));
            rp.topMargin = dp(12);
            root.addView(req, rp);
        }

        TextView chat = t("💬 Live Chat     ❤️ Reactions     ↗ Share", 13, Color.WHITE, true);
        chat.setGravity(Gravity.CENTER);
        chat.setPadding(0, dp(15), 0, dp(8));
        root.addView(chat);

        // Two rows keep controls comfortably inside narrow phones.
        String[] items = host
                ? new String[]{"🔇\nMute All", "➕\nInvite", "👥\nGuests", "💬\nChat", "📩\nInbox", "↗\nShare", "✨\nEffects", "⚙\nMore"}
                : new String[]{"🎤\nMic", "🪑\nLeave Seat", "💬\nChat", "❤️\nReact", "📩\nInbox", "↗\nShare", "✨\nEffects", "⚙\nMore"};
        for (int start = 0; start < items.length; start += 4) {
            LinearLayout controls = row();
            for (int i = start; i < Math.min(start + 4, items.length); i++) {
                TextView v = t(items[i], 10, Color.WHITE, true);
                v.setGravity(Gravity.CENTER);
                v.setBackground(bg(Color.rgb(13, 29, 76), Color.rgb(72, 78, 176), 14));
                if (!host && i == 1) {
                    v.setOnClickListener(x -> BackendClient.liveLeaveSeat(SessionManager.getToken(this), hostId, new ToastCb("Seat left")));
                }
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(52), 1);
                lp.setMargins(dp(2), dp(2), dp(2), dp(2));
                controls.addView(v, lp);
            }
            root.addView(controls);
        }

        Button end = btn(host ? "End Live" : "Leave Room");
        end.setBackground(bg(Color.rgb(111, 41, 211), Color.rgb(226, 55, 255), 18));
        end.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, dp(52));
        ep.topMargin = dp(10);
        root.addView(end, ep);

        setContentView(sc);
    }

    private void renderLocalSkeleton() {
        renderHost(null);
        renderSpecialGuest(null);
        seats.removeAllViews();
        int n = 2;
        while (n <= 12) {
            LinearLayout r = row();
            for (int c = 0; c < 3 && n <= 12; c++, n++) {
                TextView v = sofaSeat(n, null);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(112), 1);
                lp.setMargins(dp(3), dp(3), dp(3), dp(3));
                r.addView(v, lp);
            }
            while (r.getChildCount() < 3) {
                View spacer = new View(this);
                r.addView(spacer, new LinearLayout.LayoutParams(0, dp(112), 1));
            }
            seats.addView(r);
        }
    }

    private void refresh() {
        BackendClient.liveRoomState(SessionManager.getToken(this), hostId, new BackendClient.Callback() {
            @Override public void onSuccess(JSONObject d) { runOnUiThread(() -> { syncState.setText("● LIVE • Synced"); render(d); }); }
            @Override public void onError(String m) { runOnUiThread(() -> { syncState.setText("● LIVE • Weak network • Reconnecting…"); if (seats.getChildCount() == 0) renderLocalSkeleton(); }); }
        });
    }

    private void render(JSONObject d) {
        viewers.setText("👁 " + d.optInt("viewerCount", 0) + " Listeners   •   🎧 Audio Live");
        status.setText((host ? "👑 Host" : "🎧 " + d.optString("myRole", "AUDIENCE")) + " • ID " + SessionManager.getUserId(this));
        specialGuestId = d.optString("specialGuestId", "");

        JSONArray a = d.optJSONArray("seats");
        JSONObject hostSeat = findSeat(a, 1);
        JSONObject special = findUser(a, specialGuestId);
        renderHost(hostSeat);
        renderSpecialGuest(special);

        seats.removeAllViews();
        int n = 2;
        while (n <= 12) {
            LinearLayout r = row();
            for (int c = 0; c < 3 && n <= 12; c++, n++) {
                JSONObject found = findSeat(a, n);
                TextView v = sofaSeat(n, found);
                final JSONObject clicked = found;
                if (host && found != null) v.setOnClickListener(x -> showSpeakerActions(clicked));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(112), 1);
                lp.setMargins(dp(3), dp(3), dp(3), dp(3));
                r.addView(v, lp);
            }
            while (r.getChildCount() < 3) r.addView(new View(this), new LinearLayout.LayoutParams(0, dp(112), 1));
            seats.addView(r);
        }

        if (host && requests != null) renderRequests(d.optJSONArray("requests"));
    }

    private void renderHost(JSONObject x) {
        hostArea.removeAllViews();
        LinearLayout card = col();
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(7), dp(8), dp(7), dp(8));
        card.setBackground(bg(Color.rgb(19, 28, 78), Color.rgb(161, 81, 255), 18));
        TextView crown = t("👑 HOST", 11, Color.rgb(255, 220, 92), true);
        crown.setGravity(Gravity.CENTER);
        card.addView(crown);
        ImageView av = avatar(x == null ? "" : x.optString("avatar_url", ""), dp(52));
        card.addView(av, new LinearLayout.LayoutParams(dp(52), dp(52)));
        String name = x == null ? "Host" : x.optString("full_name", "Host");
        String id = x == null ? hostId : x.optString("user_id", hostId);
        int lv = x == null ? 0 : x.optInt("level", 0);
        long coin = x == null ? 0 : x.optLong("coin_balance", 0);
        long gold = x == null ? 0 : x.optLong("gold_balance", 0);
        TextView info = t(name + "\nID " + id + " • LV." + lv + "\n🪙 " + coin + "  🟡 " + gold, 9.5f, Color.WHITE, true);
        info.setGravity(Gravity.CENTER);
        card.addView(info);
        hostArea.addView(card, new LinearLayout.LayoutParams(-1, -2));
    }

    private void renderSpecialGuest(JSONObject x) {
        specialArea.removeAllViews();
        LinearLayout card = col();
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(8), dp(7), dp(8), dp(8));
        card.setBackground(bg(Color.rgb(21, 20, 73), Color.rgb(255, 68, 212), 22));
        TextView label = t("✨ SPECIAL GUEST SPOTLIGHT", 11, Color.rgb(255, 184, 244), true);
        label.setGravity(Gravity.CENTER);
        card.addView(label);
        if (x == null) {
            TextView empty = t("💫\nHost can place a speaker here", 13, Color.rgb(197, 205, 244), true);
            empty.setGravity(Gravity.CENTER);
            card.addView(empty, new LinearLayout.LayoutParams(-1, dp(98)));
        } else {
            ImageView av = avatar(x.optString("avatar_url", ""), dp(66));
            card.addView(av, new LinearLayout.LayoutParams(dp(66), dp(66)));
            String infoText = x.optString("full_name", "Special Guest") + "\nID " + x.optString("user_id") + " • LV." + x.optInt("level", 0)
                    + "\n🪙 " + x.optLong("coin_balance", 0) + "  🟡 " + x.optLong("gold_balance", 0) + (x.optInt("muted",0)==1 ? "\n🔇 Muted" : "\n🎙 Speaking seat");
            TextView info = t(infoText, 10, Color.WHITE, true);
            info.setGravity(Gravity.CENTER);
            card.addView(info);
            if (host) card.setOnClickListener(v -> clearSpecialGuest());
        }
        specialArea.addView(card, new LinearLayout.LayoutParams(-1, -2));
    }

    private TextView sofaSeat(int seatNo, JSONObject x) {
        boolean occupied = x != null;
        String s;
        if (!occupied) {
            s = "🛋️\nSeat " + seatNo + "\nOpen Sofa";
        } else {
            s = "🎙️  " + x.optString("full_name", "Speaker")
                    + "\nID " + x.optString("user_id") + " • LV." + x.optInt("level", 0)
                    + "\n🪙 " + x.optLong("coin_balance", 0) + " • 🟡 " + x.optLong("gold_balance", 0)
                    + (x.optInt("muted", 0) == 1 ? "\n🔇 Muted" : "\n🛋 Seat " + seatNo);
        }
        TextView v = t(s, occupied ? 9.5f : 11, Color.WHITE, true);
        v.setGravity(Gravity.CENTER);
        int fill = occupied ? Color.rgb(16, 47, 99) : Color.rgb(11, 28, 74);
        int stroke = occupied ? Color.rgb(46, 175, 255) : Color.rgb(119, 85, 187);
        if (x != null && x.optString("user_id").equals(specialGuestId)) stroke = Color.rgb(255, 68, 212);
        v.setBackground(bg(fill, stroke, 18));
        return v;
    }

    private void renderRequests(JSONArray q) {
        requests.removeAllViews();
        if (q == null || q.length() == 0) {
            requests.addView(t("No pending requests", 12, Color.LTGRAY, false));
            return;
        }
        for (int i = 0; i < q.length(); i++) {
            JSONObject x = q.optJSONObject(i); if (x == null) continue;
            LinearLayout rr = row(); rr.setGravity(Gravity.CENTER_VERTICAL);
            TextView nm = t(x.optString("full_name", "User") + "\nID " + x.optString("user_id"), 12, Color.WHITE, true);
            rr.addView(nm, new LinearLayout.LayoutParams(0, dp(48), 1));
            Button ok = small("Accept"); Button no = small("Decline");
            String id = x.optString("user_id");
            ok.setOnClickListener(v -> BackendClient.liveRequestAction(SessionManager.getToken(this), id, true, new ToastCb("Speaker accepted")));
            no.setOnClickListener(v -> BackendClient.liveRequestAction(SessionManager.getToken(this), id, false, new ToastCb("Request declined")));
            rr.addView(ok, new LinearLayout.LayoutParams(dp(76), dp(42)));
            rr.addView(no, new LinearLayout.LayoutParams(dp(78), dp(42)));
            requests.addView(rr);
        }
    }

    private void showSpeakerActions(JSONObject x) {
        final String uid = x.optString("user_id", "");
        final boolean alreadySpecial = uid.equals(specialGuestId);
        String[] actions = alreadySpecial
                ? new String[]{"Remove from Special Guest", "Remove Speaker from Seat"}
                : new String[]{"Make Special Guest", "Remove Speaker from Seat"};
        new AlertDialog.Builder(this)
                .setTitle(x.optString("full_name", "Speaker"))
                .setItems(actions, (d, which) -> {
                    if (which == 0) {
                        BackendClient.liveSpecialGuest(SessionManager.getToken(this), uid, alreadySpecial, new ToastCb(alreadySpecial ? "Special Guest removed" : "Special Guest selected"));
                    } else {
                        BackendClient.liveSpeakerRemove(SessionManager.getToken(this), uid, new ToastCb("Speaker removed"));
                    }
                }).show();
    }

    private void clearSpecialGuest() {
        if (!host || specialGuestId.isEmpty()) return;
        new AlertDialog.Builder(this)
                .setTitle("Special Guest")
                .setMessage("Return this guest to the normal speaker sofa?")
                .setPositiveButton("Remove Spotlight", (d,w) -> BackendClient.liveSpecialGuest(SessionManager.getToken(this), specialGuestId, true, new ToastCb("Spotlight cleared")))
                .setNegativeButton("Cancel", null).show();
    }

    private JSONObject findSeat(JSONArray a, int seatNo) {
        if (a == null) return null;
        for (int i = 0; i < a.length(); i++) { JSONObject x = a.optJSONObject(i); if (x != null && x.optInt("seat_no") == seatNo) return x; }
        return null;
    }
    private JSONObject findUser(JSONArray a, String userId) {
        if (a == null || userId == null || userId.isEmpty()) return null;
        for (int i = 0; i < a.length(); i++) { JSONObject x = a.optJSONObject(i); if (x != null && userId.equals(x.optString("user_id"))) return x; }
        return null;
    }

    private ImageView avatar(String url, int size) {
        ImageView v = new ImageView(this);
        v.setImageResource(android.R.drawable.sym_def_app_icon);
        v.setScaleType(ImageView.ScaleType.CENTER_CROP);
        v.setBackground(bg(Color.rgb(34, 45, 105), Color.rgb(164, 93, 255), size/2));
        if (url != null && !url.trim().isEmpty()) loadImage(v, url);
        return v;
    }
    private void loadImage(ImageView v, String u) {
        new Thread(() -> { try { Bitmap b = BitmapFactory.decodeStream(new URL(u).openStream()); if (b != null) runOnUiThread(() -> v.setImageBitmap(b)); } catch (Exception ignored) {} }).start();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(tick);
        if (host) {
            // Server performs room/seat/request/viewer cleanup when active=false.
            BackendClient.setLivePresence(SessionManager.getToken(this), false, new Silent());
        } else {
            BackendClient.liveLeaveSeat(SessionManager.getToken(this), hostId, new Silent());
            BackendClient.liveViewer(SessionManager.getToken(this), hostId, false, new Silent());
        }
        super.onDestroy();
    }

    class ToastCb implements BackendClient.Callback {
        String ok; ToastCb(String s) { ok = s; }
        @Override public void onSuccess(JSONObject d) { runOnUiThread(() -> { Toast.makeText(AudioLiveRoomActivity.this, ok, Toast.LENGTH_SHORT).show(); refresh(); }); }
        @Override public void onError(String m) { runOnUiThread(() -> Toast.makeText(AudioLiveRoomActivity.this, m, Toast.LENGTH_SHORT).show()); }
    }
    static class Silent implements BackendClient.Callback { @Override public void onSuccess(JSONObject d) {} @Override public void onError(String m) {} }

    private LinearLayout col() { LinearLayout x = new LinearLayout(this); x.setOrientation(LinearLayout.VERTICAL); return x; }
    private LinearLayout row() { LinearLayout x = new LinearLayout(this); x.setOrientation(LinearLayout.HORIZONTAL); x.setGravity(Gravity.CENTER_VERTICAL); return x; }
    private Button btn(String s) { Button b = new Button(this); b.setAllCaps(false); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(14); b.setBackground(bg(Color.rgb(76, 45, 205), Color.rgb(217, 46, 255), 18)); return b; }
    private Button small(String s) { Button b = btn(s); b.setTextSize(10); b.setMinWidth(0); b.setMinimumWidth(0); return b; }
    private TextView t(String s, float z, int c, boolean bold) { TextView v = new TextView(this); v.setText(s); v.setTextSize(z); v.setTextColor(c); if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return v; }
    private GradientDrawable bg(int a, int st, int r) { GradientDrawable g = new GradientDrawable(); g.setColor(a); g.setCornerRadius(dp(r)); g.setStroke(dp(1), st); return g; }
    private int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density + .5f); }
}
