# MY SHOP Developer Handoff — V-282

V-282 is an identity-synchronization repair built from the V-281 Live core without removing approved functionality.

- Preserves the V-281 high-quality Audio Live / 12-seat core and all earlier approved MY SHOP features.
- Fixes the GitHub master workflow source-identity failure by synchronizing every current release marker to V-282.
- `SOURCE_BUILD_ID.txt` = `MY SHOP V-282`.
- `SOURCE_VERSION_NAME.txt` = `2.9.282`.
- Android `versionCode 282`, `versionName 2.9.282`.
- Worker health/build marker = `2.9.282 / V-282`.
- Dashboard approved Go Live 35% / Join Live 65% flow remains preserved.
- Video Live remains OFF / Coming Soon.
- RTC real voice transport remains pending provider credentials/token setup; no secret is embedded in the APK/source.
- Future releases must verify the PACKAGED ZIP itself before delivery: ZIP V-number = SOURCE_BUILD_ID = SOURCE_VERSION_NAME = Android version = Worker build/version = Handoff version.
