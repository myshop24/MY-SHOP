# MY SHOP V-642 / 2.9.642
Continued from delivered V641. Next changed delivery V643. Full source, no signed APK and no production deployment.

## Owner-authorized corrections, ordered
1. Home posts: light grey feed, separate white rounded cards, 10dp separators; composer gallery glyph reduced 10% with original touch target retained.
2. My Collection opens category entries, not purchase history. Room Theme uses existing authenticated theme choices endpoint (Admin free plus active owned), preview then explicit Confirm saves selection. No purchase request display or gift-unbox list in Collection. Admin comment settings remains role gated; normal user only sees assigned/owned comments.
3. Start Audio Live theme picker removed, existing saved room theme resolution retained.
4. Physical Store entrance: diagnosed asset:// sent to HTTP-only CachedImages path when autoplay=false. Decode packaged storefront directly and reserve112dp; existing tap opens Store.
5. Catalog horizontal shelf explicitly bounded192dp, preventing viewport-sized blank gap. Requires device/font-scale acceptance.
6. Avatar cosmetics photo geometry now uses actual FIT_CENTER drawable width/height rather than assuming a square, fixing non-square frame alignment. Comment avatar top aligned, message wraps within preserved ornate design and centered authority animation.
7. Reduce Animation menu removed and legacy preference no longer disables renderers; explicit caller autoplay=false is preserved. PerformanceMode device automatic quality remains.
8. WritingColors is compact Text Color button aligned right. Paint selected style directly onto editor, no duplicate preview copy.

## Verification / limits
Local v640 target source/SQLite/Java parser/callback/lambda checks passed. Regression result recorded separately. Java parsing is NOT Android type checking. No phone/emulator/RTC/payment test, no new APK. Existing Gradle network download limitation remains. Device screenshot acceptance still required for shelf heights, avatar fit during animated frames, theme confirmation across sessions, text style editing and keyboard. Video Live is design-only and excluded. Prior V641 incomplete items (view count, all catalog/live cosmetic parity, full phone acceptance) remain pending; no claim they are completed here.
