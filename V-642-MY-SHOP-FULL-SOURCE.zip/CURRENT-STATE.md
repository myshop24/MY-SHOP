V642 current source. Next delivery V643. Read MY-SHOP-DEVELOPER-HANDOFF.md.
