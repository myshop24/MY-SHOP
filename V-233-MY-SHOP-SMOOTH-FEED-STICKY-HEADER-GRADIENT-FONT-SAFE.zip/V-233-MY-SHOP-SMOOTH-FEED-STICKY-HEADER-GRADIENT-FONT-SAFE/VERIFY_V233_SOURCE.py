from pathlib import Path
import hashlib, re, sys, zipfile
ROOT=Path(__file__).resolve().parent
checks=[]
def ck(name, cond):
    checks.append((name,bool(cond)))
    print(('PASS' if cond else 'FAIL')+' — '+name)
def read(p): return (ROOT/p).read_text(errors='replace')
main=read('app/src/main/java/com/myshop/app/MainActivity.java')
admin=read('app/src/main/java/com/myshop/app/AdminSectionActivity.java')
menu=read('app/src/main/java/com/myshop/app/UserMenuActivity.java')
gradle=read('app/build.gradle')
worker=read('backend/worker/src/index.js')
wrangler=read('backend/worker/wrangler.toml')
ck('SOURCE_BUILD_ID exact V-233', read('SOURCE_BUILD_ID.txt').strip()=='MY SHOP V-233')
ck('Android versionCode/versionName V-233', 'versionCode 233' in gradle and "versionName '2.9.233'" in gradle)
ck('Worker runtime markers V-233', worker.count("version:'2.9.233',build:'V-233'")>=2)
ck('D1 binding preserved', 'binding = "DB"' in wrangler and 'database_name = "my-shop-db"' in wrangler and 'database_id = "15b6acd2-0e82-4bd8-95fb-bee6fc08936c"' in wrangler)
ck('R2 binding preserved', 'binding = "MEDIA"' in wrangler and 'bucket_name = "my-shop-media"' in wrangler)
ck('Feed has silent cache-first refresh', 'FEED_CACHE_PREF' in main and 'renderCachedFeed()' in main and 'putString(FEED_CACHE_KEY,d.toString())' in main)
ck('No visible feed Loading/Retry/error row', 'feedStatus=text(' not in main and 'feedStatus.setText(' not in main)
ck('Header + headline are fixed/sticky', 'sticky.addView(header()' in main and 'sticky.addView(breaking()' in main and 'page.addView(header()' not in main and 'page.addView(breaking()' not in main)
ck('Headline numeric size input exists', 'newsSizeInput=new EditText' in admin and 'syncNewsSizeFromInput()' in admin and 'changeNewsSize(-1.0f)' in admin and 'changeNewsSize(1.0f)' in admin)
ck('Headline size supports 7–24sp source range', 'Math.min(24.0f' in admin and 'Math.min(24,Number(b.breakingNewsTextSize)' in worker and 'Math.min(24.0,c.optDouble("breaking_news_text_size"' in main)
ck('Old MY FEED subtitle removed', 'Share your moments, products, and ideas with our community' not in main)
ck('POWER AD by Touhid beside MY FEED', '⚡ POWER AD by Touhid' in main)
ck('MY FEED + POWER AD gradient text', main.count('applyTextGradient(')>=3 and 'TextView feedTitle=' in main and 'TextView power=' in main)
ck('Readable More menu font', 'text(label,DARK,9.8f,true)' in main)
ck('Readable bottom-nav font', 'text(label,color,9.6f,true)' in main)
ck('Readable profile drawer labels', 'txt(label,14,DARK,active)' in menu and 'txt("Notifications",14,DARK,false)' in menu)
ck('No APK/AAB/ZIP nested inside source', not any(p.suffix.lower() in {'.apk','.aab','.zip'} for p in ROOT.rglob('*') if p.is_file()))
# Protected files must match the locked hashes.
manifest=ROOT/'V-233_PROTECTED_INTEGRITY.sha256'
all_hash=True
for line in manifest.read_text().splitlines():
    if not line.strip(): continue
    expected, rel=line.split(None,1); rel=rel.strip(); p=ROOT/rel
    got=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else ''
    if got!=expected:
        all_hash=False; print('HASH FAIL',rel,expected,got)
ck('Permanent D1/R2 + user identity protected hashes unchanged', all_hash)
failed=[n for n,v in checks if not v]
print(f'\nRESULT: {len(checks)-len(failed)}/{len(checks)} checks PASS')
if failed:
    print('FAILED:', '; '.join(failed)); sys.exit(1)
