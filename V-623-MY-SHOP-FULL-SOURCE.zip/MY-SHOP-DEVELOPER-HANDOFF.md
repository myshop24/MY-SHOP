# MY SHOP V-623 /2.9.623 — full source APK build package

Baseline: exact delivered V-622-MY-SHOP-FULL-SOURCE.zip SHA2564777e52534441305a004d2f5e1062fd6748a0b06b385c6960be0e3360aa0f7c2. Continue V622; no reset or old APK/source substitution. Next changed delivery V624. Package com.myshop.app, SOURCE_BUILD_ID MY SHOP V-623, Android versionCode623/versionName2.9.623, Worker V-623/2.9.623.

## This phase:1/1 Master Commission source implementation completed

Owner-approved details: V623-APPROVED-WORK-BN.md. Main user-control menu now has the exact yellow/red মাইশপ কমিশন কয়েন & ডায়মন্ড button below Special ID/new user and above Back. Master screen title মাইশপ কমিশন যুক্ত করুন. Coin left/Diamond right/Store below. One global green Enable/commission-on or red Disable/commission-free switch. No category switches or scheduled date/time. Rates are integer1–30 percent dropdowns plus Save. Distinct currency transaction/withdrawal rates and Store category rates. Disable makes included fees0 but retains the saved rates and product prices. Re-enable restores them.

Backend persists optional master623 inside the existing commission payload; no destructive schema migration. Active fixed Admin0001/0002/0003 only, optimistic revision, atomic config/audit batch and rollback. Legacy settings remain until the first explicit Master save; no invented rates silently activated during deploy. Review all dropdowns before first save. Old source commission editor replaced by this Master UI; legacy withdrawal rate input hidden and server cannot override active Master through that catalog endpoint. Other withdrawal availability, dates, amounts/conversion/methods remain original.

Gift catalog/Live/Post currency gifts EXCLUDED from Master/switch. A snapshot of the old Gift policy is retained on first Master save, including any pre-existing timed policy; the original gift-only editor can still change giftCatalogPercent separately. All ordinary transfer entry points use the same Coin/Gold transaction rate; purchases/official-source transfer and fixed Admin exemptions unchanged. Star/Level/earned/purchased accounting retained.

Store products remain Diamond-only and individually priced. Rates: Membership, Avatar Frame/Ring, Theme/Wallpaper, Rare ID, Comment Style, Entry Animation, Badge, Other/Bundle. Existing product type aliases map once to these categories. A store product bought as a present uses Store checkout commission, while a currency/catalog gift uses the separate Gift system. Store adds its category fee exactly once; no extra general Diamond-transfer fee. Server-authenticated current quote is fetched before purchase confirmation, including wishlist purchases. Exact total and config revision revalidated before money hold. Confirmation says MY SHOP Commission, not VAT. Fee snapshot/revision retained in purchase requests and approved ledger; a later switch/rate change never rewrites pending held terms. Original Admin approval, ownership, Rare reservation, expiry, rejection refund and retry/dedup paths preserved.

Transfer confirmation now fetches authenticated current terms (including source exemption) and displays base/commission/total/recipient full amount. Changed rate/source before Confirm is rejected without debit. Withdraw always uses the separate Master rate and ADDITIONAL mode when configured; existing withdrawal request terms/history remain immutable. All amounts are integer units with Math.round fee rounding, matching existing economy rules.

## V622 failed build repaired

GitHub failed run38517338706, commit5830f87c197ab0d86124d4b9d5103c2d9d2e9512. Worker V622 deployed/verified successfully BEFORE Android failed. Actual javac errors: non-static levelHandler622 and refreshLevel622 referenced from GiftPanel613.show static context. Corrected exact access to p.levelHandler622.post(p.refreshLevel622), retaining lifecycle polling/dismiss behavior. New compile regression extracts the shipped show method, compiles it, and reproduces both old errors in a negative check. No signing/cache workaround or Secret change.

## Actual verification

- Full release Java compilation PASSED with Gradle8.11.1, actual Android SDK36/resources/dependencies and full Java17 compiler, no build cache, rerun tasks. All242 Java sources/type/resource compilation checked; local Git SHA is local. Firebase values used for this compile-only test were explicit local placeholders, not a real service test or a deliverable APK.
- APK assembly result is recorded at the final packaging checkpoint below.
- tools/v623_verify.sh PASSED: inherited gates, real SQLite behavior, Java context/method fixtures, parser, generated asset hashes/decoded pixels and new Master tests.
- All73 top-level Node .mjs/.cjs suites PASSED, including original gift/registration/read-cache/rare/theme/Live regressions.276 unaffected historical backend functions remain byte-hash locked. Only scoped financial functions and release identity exempt/normalized. The old isolated gift-quote fixture now loads the real Master helper and uses Store commission rather than VAT.
- New actual SQLite API/Store/Transfer tests: owner/active auth, integer1–30 validation, one switch, distinct currency/withdraw/store rates, Gift independence, concurrent revision conflict, failed audit rollback, current quote and stale quote no debit, recipient full amount, mixed purchased-source exemption, insufficient full total, Store hold retry/dedup, pending fee immutability, revenue commission ledger, product-as-present hold/refund, ordinary purchase rejection full refund.
- Generated assets were reproduced from a clean V622 source extraction and all176 generated outputs passed included original byte/pixel gates; no previous APK required for build inputs.100 name-specific sounds and all ten full/previews wallpapers remain intact.
- SourceZIP size/CRC/required files/version normalization/worker syntax checked during final packaging. Source ZIP must stay below25,000,000bytes.

## Pipeline and signing

Existing repository https://github.com/myshop24/MY-SHOP uses a ROOT ZIP-selector workflow, not the workflow embedded inside the ZIP. Upload ONLY V-623-MY-SHOP-FULL-SOURCE.zip at repository root/main, retain existing root my-shop-release.sh and workflow. Exact current script/workflow snapshots from commit5830f87... are in repository-pipeline/ for reference. Root script chooses the highest V-number, normalizes Android/Worker identity, deploys/verifies Worker, directly invokes Gradle, signs one canonical release APK with existing cached key and Secrets. V623 adds current financial tests to Gradle preBuild so they run in this direct pipeline too. Embedded source workflow/ci script retained for extracted-project developers; updated V623 gate.

Original certificate SHA2564c6784cd027679169b60168a3dec744858c56ab681f860880cea435bb2992acd. No signing key/Secret changed, created or included. No V623 repository push, production deploy, GitHub build/run or production DB action performed. The source ZIP does not require an APK inside. Verify actual signed GitHub artifact for the intended commit/run, source/version identity, timestamp/hash and original certificate. A local unsigned/placeholder-config build is NEVER a user release.

## Retained V622 pending work / next checkpoint

See handoffs/MY-SHOP-V622-HANDOFF.md for all seven original tasks. Task4 remains basic procedural object animations, not yet premium/cinematic to the supplied videos. Exact design16/real-mobile layout, phone RTC/audio/Join/comment/gift/admin flows, actual sound listening, billing/payment/push and production D1 acceptance remain pending. Do not claim all original seven tasks finished or Play approval. Original targetSDK36/Billing9.1.0/Cloudflare DB/R2/Durable Object bindings unchanged. No paid plan needed.

Start next work from this complete V623 source. Master Commission and static Java build fix are implemented/tested; continue inherited visual/device work without undoing V622. Next newly changed delivery V624.

## Final packaging checkpoint

Local release Java compilation: PASS. Local assembleRelease: PASS (unsigned test APK, local compile-only Firebase placeholders); package/version checked as com.myshop.app/623/2.9.623. DEX/resources/native packaging passed. This test APK is excluded from delivery and must not be distributed. Signed GitHub V623 APK: NOT BUILT/VERIFIED in this session. Source-only canonical ZIP, no old APK included.
