# V-623 — existing MY-SHOP repository pipeline

Upload ONLY `V-623-MY-SHOP-FULL-SOURCE.zip` to the ROOT of https://github.com/myshop24/MY-SHOP on main. Do not extract/overwrite the existing root workflow or my-shop-release.sh. Keep one ZIP at the highest V-number; retain earlier versions. The current root pipeline selects the highest numbered ZIP, extracts its source, normalizes version identity, deploys/verifies the Worker, runs Gradle and signs one new APK with the existing cached key and unchanged Secrets.

Actions → MY SHOP PERMANENT RELEASE PIPELINE → verify the intended source commit/run. After success download the artifact MY-SHOP-FINAL-V-623; inside is the canonical MY_SHOP_FINAL_RELEASE.apk. GitHub Pages success is unrelated. Verify package com.myshop.app, versionCode623/name2.9.623, timestamp/hash, source/run identity and ORIGINAL certificate SHA2564c6784cd027679169b60168a3dec744858c56ab681f860880cea435bb2992acd. Never substitute an old APK.

Do NOT change signing key/Secrets. Current repository pipeline was checked at commit5830f87c197ab0d86124d4b9d5103c2d9d2e9512. Exact snapshots are in repository-pipeline/ for developer reference, not files to replace in the repository. The source-root .github workflow remains the alternative extracted-project workflow; it is not the workflow your existing ZIP-based repository executes.

The root pipeline deploys the Worker BEFORE Android compilation. V622 Worker deployed successfully even though its Android compile failed. V623 repairs the two instance-field accesses reported by that compile failure. V623 Gradle preBuild runs new Master financial target tests in addition to original identity/resource/asset checks.

This is a FULL SOURCE BUILD PACKAGE; a built APK is not required inside this ZIP. Local compilation/testing and actual signed GitHub release are separate. Read MY-SHOP-DEVELOPER-HANDOFF.md for results and remaining visual/device work. No V623 repository push, production deploy or signing Secret change was made during preparation.
