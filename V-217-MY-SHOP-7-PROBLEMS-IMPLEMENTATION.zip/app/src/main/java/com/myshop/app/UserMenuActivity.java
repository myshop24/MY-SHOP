package com.myshop.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

/**
 * V-165: permanent USER MENU rule.
 * Profile belongs to the main dashboard left side and is never duplicated in this hamburger screen. The hamburger screen contains user features only.
 * Ordinary users never see Admin controls; Admin accounts may use the inline EDIT action for managed features.
 */
public class UserMenuActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(247,248,252), DARK=Color.rgb(24,29,62), BLUE=Color.rgb(46,47,190), PURPLE=Color.rgb(83,32,180), RED=Color.rgb(210,45,55), MUTED=Color.rgb(95,99,115);

    @Override protected void onCreate(Bundle b){super.onCreate(b); build();}

    private void build(){
        LinearLayout root=col();
        root.setBackgroundColor(BG);
        root.setPadding(dp(12),dp(10),dp(12),dp(16));

        LinearLayout title=row();
        TextView close=button("‹",DARK,22); close.setOnClickListener(v->finish()); title.addView(close,lp(dp(40),dp(42)));
        TextView t=txt("MY SHOP",18,DARK,true); t.setGravity(Gravity.CENTER_VERTICAL); title.addView(t,weight(1,dp(42)));
        TextView lang=txt("🌐 "+code(),BLUE,9,true); lang.setGravity(Gravity.CENTER); lang.setBackground(bg(Color.rgb(245,246,255),Color.TRANSPARENT,12)); lang.setOnClickListener(v->LanguageManager.showPicker(this,()->recreate())); title.addView(lang,lp(dp(62),dp(38)));
        root.addView(title,lp(-1,dp(48)));

        TextView label=txt("USER MENU",11,PURPLE,true); label.setPadding(dp(4),dp(4),0,dp(6)); root.addView(label,lp(-1,dp(30)));
        EditText search=new EditText(this); search.setHint("Search"); search.setSingleLine(true); search.setTextSize(13); search.setPadding(dp(12),0,dp(12),0); search.setBackground(bg(Color.WHITE,Color.rgb(225,227,235),12)); root.addView(search,lp(-1,dp(46)));

        ScrollView scroll=new ScrollView(this); scroll.setVerticalScrollBarEnabled(false); scroll.setFillViewport(false);
        LinearLayout list=col();
        add(list,"HOME","Main dashboard",R.drawable.dash_action_feed,()->finish());
        add(list,"MY SHOP","Shop and products",R.drawable.dash_feat_shop,()->open("MY SHOP","my_shop"),"dashboard");
        add(list,"GALLERY","Photo • Audio • Video",R.drawable.dash_feat_gallery,()->startActivity(new Intent(this,GalleryActivity.class)),"gallery");
        add(list,"EXTERNAL MOVIE","External movie links",R.drawable.dash_feat_movie,()->open("EXTERNAL MOVIE","external_movie"),"external_movie");
        add(list,"GO LIVE","Start a live stream",R.drawable.dash_action_go,()->open("GO LIVE","go_live"));
        add(list,"JOIN LIVE","Join a live stream",R.drawable.dash_action_live,()->open("JOIN LIVE","live_now"));
        add(list,"EARN & REWARD","Coins, gifts and rewards",R.drawable.dash_feat_reward,()->open("EARN & REWARD","earn_reward"));
        add(list,"LIVE TV","Live TV channels",R.drawable.dash_feat_tv,()->open("LIVE TV","live_tv"),"live_tv");
        add(list,"LIVE","Watch live streams",R.drawable.dash_action_live,()->open("LIVE","live_now"));
        add(list,"SOCIAL MEDIA","Facebook • YouTube • TikTok • Instagram",R.drawable.feature_social_selected,()->open("SOCIAL MEDIA","social_media"),"social");
        add(list,"CHAT","Chat and messages",R.drawable.menu_chat,()->open("CHAT","chat"));
        add(list,"MUSIC","Music",R.drawable.menu_music,()->open("MUSIC","music"));
        add(list,"BREAKING NEWS","Latest headlines",R.drawable.menu_news,()->open("BREAKING NEWS","breaking_news"),"dashboard");
        add(list,"MORE APPS","Facebook • Page • YouTube • WhatsApp • imo • Instagram • Telegram",R.drawable.dash_feat_apps,()->open("MORE","more_apps"),"more_apps");
        add(list,"SHARE APP","Share MY SHOP",R.drawable.feature_share_selected,()->shareApp());
        add(list,"HELP & SUPPORT","WhatsApp customer support",R.drawable.icon_support,()->open("CUSTOMER SUPPORT","help_support"),"help_support");
        add(list,"JOBS","Jobs and opportunities",R.drawable.menu_jobs,()->open("JOBS","jobs"));
        add(list,"COUPON","Coupons and offers",R.drawable.menu_coupon,()->open("COUPON","coupon"));
        add(list,"BOOKING","Bookings",R.drawable.menu_booking,()->open("BOOKING","booking"));
        add(list,"WALLET","Wallet and coins",R.drawable.menu_wallet,()->open("WALLET","wallet"));
        add(list,"SETTINGS","App settings",R.drawable.menu_settings,()->open("SETTINGS","settings"));
        add(list,"LANGUAGE","বাংলা • English • हिन्दी • العربية",R.drawable.menu_language,()->LanguageManager.showPicker(this,()->recreate()));
        add(list,"LOGOUT","Sign out of this device",R.drawable.menu_logout,()->logout());
        loadDynamicMenu(list);
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence q,int st,int b,int c){String ql=q.toString().trim().toLowerCase(); for(int i=0;i<list.getChildCount();i++){View v=list.getChildAt(i);Object tag=v.getTag();String title=tag==null?"":String.valueOf(tag);v.setVisibility(ql.isEmpty()||title.toLowerCase().contains(ql)?View.VISIBLE:View.GONE);}} public void afterTextChanged(android.text.Editable e){}});
        scroll.addView(list,new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    private void loadDynamicMenu(LinearLayout list){String token=SessionManager.getToken(this);if(token==null||token.isEmpty())return;BackendClient.dashboard(token,new BackendClient.Callback(){public void onSuccess(org.json.JSONObject d){runOnUiThread(()->{org.json.JSONArray a=d.optJSONArray("featureButtons");java.util.HashMap<String,org.json.JSONObject> cfg=new java.util.HashMap<>();if(a!=null)for(int i=0;i<a.length();i++){org.json.JSONObject x=a.optJSONObject(i);if(x!=null)cfg.put(x.optString("key",""),x);}list.removeAllViews();String[] keys={"menu_home","menu_shop","menu_gallery","menu_external","menu_go_live","menu_join_live","menu_earn","menu_live_tv","menu_live","menu_social","menu_chat","menu_music","menu_news","menu_more","menu_share","menu_support","menu_jobs","menu_coupon","menu_booking","menu_wallet","menu_settings","menu_language","menu_logout"};String[] titles={"HOME","MY SHOP","GALLERY","EXTERNAL MOVIE","GO LIVE","JOIN LIVE","EARN & REWARD","LIVE TV","LIVE","SOCIAL MEDIA","CHAT","MUSIC","BREAKING NEWS","MORE APPS","SHARE APP","CUSTOMER SUPPORT","JOBS","COUPON","BOOKING","WALLET","SETTINGS","LANGUAGE","LOGOUT"};String[] desc={"Main dashboard","Shop and products","Photo • Audio • Video","External movie links","Start a live stream","Join a live stream","Coins, gifts and rewards","Live TV channels","Watch live streams","Facebook • YouTube • TikTok • Instagram","Chat and messages","Music","Latest headlines","Facebook • Page • YouTube • WhatsApp • imo • Instagram • Telegram","Share MY SHOP","WhatsApp customer support","Jobs and opportunities","Coupons and offers","Bookings","Wallet and coins","App settings","বাংলা • English • हिन्दी • العربية","Sign out of this device"};int[] icons={R.drawable.dash_action_feed,R.drawable.dash_feat_shop,R.drawable.dash_feat_gallery,R.drawable.dash_feat_movie,R.drawable.dash_action_go,R.drawable.dash_action_live,R.drawable.dash_feat_reward,R.drawable.dash_feat_tv,R.drawable.dash_action_live,R.drawable.feature_social_selected,R.drawable.menu_chat,R.drawable.menu_music,R.drawable.menu_news,R.drawable.dash_feat_apps,R.drawable.feature_share_selected,R.drawable.icon_support,R.drawable.menu_jobs,R.drawable.menu_coupon,R.drawable.menu_booking,R.drawable.menu_wallet,R.drawable.menu_settings,R.drawable.menu_language,R.drawable.menu_logout};for(int i=0;i<keys.length;i++){org.json.JSONObject x=cfg.get(keys[i]);if(x!=null&&x.optInt("active",1)!=1)continue;String tt=x==null?titles[i]:x.optString("title",titles[i]);String uu=x==null?"":x.optString("target_url","");String ii=x==null?"":x.optString("icon_url","");final int idx=i;addConfigured(list,keys[i],tt,desc[i],icons[i],ii,()->{if(!uu.isEmpty()&&FeatureRegistry.isSafeHttpUrl(uu)){try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(uu)));return;}catch(Exception ignored){}}if("menu_home".equals(keys[idx]))finish();else if("menu_gallery".equals(keys[idx]))startActivity(new Intent(UserMenuActivity.this,GalleryActivity.class));else if("menu_support".equals(keys[idx]))open("CUSTOMER SUPPORT","help_support");else if("menu_social".equals(keys[idx]))open("SOCIAL MEDIA","social_media");else if("menu_more".equals(keys[idx]))open("MORE","more_apps");else if("menu_language".equals(keys[idx]))LanguageManager.showPicker(this,()->recreate());else if("menu_logout".equals(keys[idx]))logout();else open(tt,keys[idx].replace("menu_",""));});}if(a!=null)for(int i=0;i<a.length();i++){org.json.JSONObject x=a.optJSONObject(i);if(x==null||x.optInt("active",1)!=1)continue;String key=x.optString("key","");if(!key.startsWith("menu_custom_"))continue;addDynamic(list,x.optString("title","Menu"),x.optString("target_url",""),x.optString("icon_url",""));}});}public void onError(String m){}});}
    private void addConfigured(LinearLayout list,String key,String title,String desc,int icon,String iconUrl,Runnable action){LinearLayout c=col();c.setPadding(dp(8),dp(5),dp(8),dp(5));c.setBackground(bg(Color.WHITE,Color.rgb(224,226,235),14));c.setElevation(dp(2));LinearLayout.LayoutParams cp=lp(-1,dp(66));cp.bottomMargin=dp(7);c.setLayoutParams(cp);LinearLayout r=row();FrameLayout ib=new FrameLayout(this);ib.setBackground(bg(Color.rgb(245,246,252),Color.rgb(230,232,240),12));ImageView iv=new ImageView(this);iv.setImageResource(icon);iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);ib.addView(iv,new FrameLayout.LayoutParams(-1,-1));if(!iconUrl.isEmpty())loadRemoteImage(iv,iconUrl);r.addView(ib,lp(dp(48),dp(48)));LinearLayout b=col();b.setPadding(dp(10),0,dp(4),0);TextView a=txt(title,11.5f,DARK,true);a.setGravity(Gravity.CENTER_VERTICAL);a.setSingleLine(true);b.addView(a,lp(-1,dp(25)));TextView d=txt(desc,8.5f,MUTED,false);d.setGravity(Gravity.CENTER_VERTICAL);d.setSingleLine(true);d.setEllipsize(android.text.TextUtils.TruncateAt.END);b.addView(d,lp(-1,dp(22)));r.addView(b,weight(1,dp(48)));if(SessionManager.isAdmin(this)){TextView ed=txt("EDIT",Color.WHITE,8,true);ed.setGravity(Gravity.CENTER);ed.setBackground(bg(BLUE,BLUE,7));ed.setOnClickListener(v->{Intent i=new Intent(UserMenuActivity.this,AdminSectionActivity.class);i.putExtra("section","menu");i.putExtra("admin_context",true);startActivity(i);});r.addView(ed,lp(dp(52),dp(30)));}TextView go=txt("›",BLUE,20,true);go.setGravity(Gravity.CENTER);r.addView(go,lp(dp(28),dp(48)));c.addView(r,lp(-1,dp(48)));c.setTag(title);c.setOnClickListener(v->action.run());list.addView(c);}
    private void addDynamic(LinearLayout list,String title,String url,String iconUrl){LinearLayout c=col();c.setPadding(dp(8),dp(5),dp(8),dp(5));c.setBackground(bg(Color.WHITE,Color.rgb(224,226,235),14));c.setElevation(dp(2));LinearLayout.LayoutParams cp=lp(-1,dp(66));cp.bottomMargin=dp(7);c.setLayoutParams(cp);LinearLayout r=row();FrameLayout ib=new FrameLayout(this);ib.setBackground(bg(Color.rgb(245,246,252),Color.rgb(230,232,240),12));ImageView iv=new ImageView(this);iv.setImageResource(R.drawable.icon_more);iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);ib.addView(iv,new FrameLayout.LayoutParams(-1,-1));if(!iconUrl.isEmpty())loadRemoteImage(iv,iconUrl);r.addView(ib,lp(dp(48),dp(48)));LinearLayout b=col();b.setPadding(dp(10),0,dp(4),0);TextView a=txt(title,11.5f,DARK,true);a.setGravity(Gravity.CENTER_VERTICAL);a.setSingleLine(true);b.addView(a,lp(-1,dp(25)));TextView d=txt(url.isEmpty()?"MY SHOP menu item":"Open external link",8.5f,MUTED,false);d.setGravity(Gravity.CENTER_VERTICAL);b.addView(d,lp(-1,dp(22)));r.addView(b,weight(1,dp(48)));if(SessionManager.isAdmin(this)){TextView ed=txt("EDIT",Color.WHITE,8,true);ed.setGravity(Gravity.CENTER);ed.setBackground(bg(BLUE,BLUE,7));ed.setOnClickListener(v->{Intent i=new Intent(UserMenuActivity.this,AdminSectionActivity.class);i.putExtra("section","menu");i.putExtra("admin_context",true);startActivity(i);});r.addView(ed,lp(dp(52),dp(30)));}TextView go=txt("›",BLUE,20,true);go.setGravity(Gravity.CENTER);r.addView(go,lp(dp(28),dp(48)));c.addView(r,lp(-1,dp(48)));c.setTag(title);c.setOnClickListener(v->{if(!url.isEmpty())try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url)));}catch(Exception ignored){} });list.addView(c);}

    private void add(LinearLayout list,String title,String desc,int icon,Runnable action){ add(list,title,desc,icon,action,null); }
    private void add(LinearLayout list,String title,String desc,int icon,Runnable action,String adminSection){
        LinearLayout c=col(); c.setPadding(dp(8),dp(5),dp(8),dp(5)); c.setBackground(bg(Color.WHITE,Color.rgb(224,226,235),14)); c.setElevation(dp(2)); if(android.os.Build.VERSION.SDK_INT>=21){android.graphics.drawable.Drawable base=c.getBackground();c.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(Color.argb(42,30,55,120)),base,null));}
        LinearLayout.LayoutParams cp=lp(-1,dp(66)); cp.bottomMargin=dp(7); c.setLayoutParams(cp);
        LinearLayout r=row(); FrameLayout ib=new FrameLayout(this); ib.setBackground(bg(Color.rgb(245,246,252),Color.rgb(230,232,240),12)); ImageView iv=new ImageView(this); iv.setImageResource(icon); iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE); ib.addView(iv,new FrameLayout.LayoutParams(-1,-1)); r.addView(ib,lp(dp(48),dp(48)));
        LinearLayout b=col(); b.setPadding(dp(10),0,dp(4),0); TextView a=txt(title,11.5f,DARK,true); a.setGravity(Gravity.CENTER_VERTICAL); a.setSingleLine(true); b.addView(a,lp(-1,dp(25))); TextView d=txt(desc,8.5f,MUTED,false); d.setGravity(Gravity.CENTER_VERTICAL); d.setSingleLine(true); d.setEllipsize(android.text.TextUtils.TruncateAt.END); b.addView(d,lp(-1,dp(22))); r.addView(b,weight(1,dp(48)));
        if(SessionManager.isAdmin(this)){ TextView ed=txt("EDIT",Color.WHITE,8,true); ed.setGravity(Gravity.CENTER); ed.setBackground(bg(BLUE,BLUE,7)); ed.setOnClickListener(v->{ Intent i=new Intent(UserMenuActivity.this,AdminSectionActivity.class); i.putExtra("section",adminSection==null?"menu":adminSection); i.putExtra("admin_context",true); startActivity(i); }); r.addView(ed,lp(dp(52),dp(30))); }
        TextView go=txt("›",BLUE,20,true); go.setGravity(Gravity.CENTER); r.addView(go,lp(dp(28),dp(48))); c.addView(r,lp(-1,dp(48))); c.setTag(title); c.setOnClickListener(v->action.run()); list.addView(c);
    }

    private void open(String title,String key){ Intent i=new Intent(UserMenuActivity.this,FeatureActivity.class); i.putExtra("title",title); i.putExtra("feature_key",key); i.putExtra("user_menu",true); startActivity(i); }
    private void openCustomerSupport(){
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(org.json.JSONObject d){ org.json.JSONArray a=d.optJSONArray("managedLinks"); String url=""; if(a!=null)for(int i=0;i<a.length();i++){org.json.JSONObject x=a.optJSONObject(i);if(x!=null&&"help_support".equals(x.optString("category",""))){String u=x.optString("url","").trim();String n=normalizeWhatsApp(u);if(!n.isEmpty()){url=n;break;}}} final String target=url; runOnUiThread(()->{if(!target.isEmpty()){try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(target)));}catch(Exception e){Toast.makeText(UserMenuActivity.this,"Unable to open support.",Toast.LENGTH_SHORT).show();}}else Toast.makeText(UserMenuActivity.this,"Customer support is not configured yet.",Toast.LENGTH_SHORT).show();}); }
            public void onError(String m){runOnUiThread(()->Toast.makeText(UserMenuActivity.this,"Customer support unavailable.",Toast.LENGTH_SHORT).show());}
        });
    }
    private String normalizeWhatsApp(String raw){String v=raw==null?"":raw.trim();if(v.isEmpty())return "";if(v.startsWith("http://")||v.startsWith("https://"))return v;String digits=v.replaceAll("[^0-9]","");return digits.length()>=8?"https://wa.me/"+digits:"";}
    private void shareApp(){try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"MY SHOP");i.putExtra(Intent.EXTRA_TEXT,"MY SHOP — https://rapid-bush-62ea.myshopsatkania.workers.dev");startActivity(Intent.createChooser(i,"Share MY SHOP"));}catch(Exception e){Toast.makeText(this,"Share is not available.",Toast.LENGTH_SHORT).show();}}
    private void logout(){String token=SessionManager.getToken(this);SessionManager.clear(this);Intent i=new Intent(this,LoginActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(i);if(token!=null&&!token.isEmpty())BackendClient.logout(token,new BackendClient.Callback(){public void onSuccess(org.json.JSONObject d){}public void onError(String m){}});}
    private void loadRemoteImage(ImageView target,String url){new Thread(()->{try{java.net.HttpURLConnection c=(java.net.HttpURLConnection)new java.net.URL(url).openConnection();c.setConnectTimeout(3000);c.setReadTimeout(5000);try(java.io.InputStream in=c.getInputStream()){android.graphics.Bitmap bm=android.graphics.BitmapFactory.decodeStream(in);if(bm!=null)runOnUiThread(()->target.setImageBitmap(bm));}}catch(Exception ignored){}}).start();}
    private String code(){String l=LanguageManager.get(this);if(LanguageManager.EN.equals(l))return "EN";if(LanguageManager.HI.equals(l))return "HI";if(LanguageManager.AR.equals(l))return "AR";return "বাং";}
    private TextView button(String s,int c,float z){TextView b=new TextView(this);b.setText(s);b.setTextColor(c);b.setTextSize(z);b.setGravity(Gravity.CENTER);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return b;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView txt(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}
    private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}
    private View topWrap(View v,int m){v.setLayoutParams(top(lp(-1,dp(32)),m));return v;}
    private GradientDrawable bg(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
