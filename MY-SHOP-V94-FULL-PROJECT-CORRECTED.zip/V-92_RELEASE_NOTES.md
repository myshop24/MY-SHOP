# MY SHOP V-92

Scope of this version:
- Preserve the V-91 project as the baseline; no unrelated feature redesign.
- Repair the dashboard reference resource so Android resource compilation can process it.
- Align the release workflow to versionCode 92 / versionName 2.9.92 and remove the contradictory V-90 checks.
- Keep LoginActivity as the framework Activity launcher hardening path.
- Keep Login -> Create Account -> User ID -> Dashboard flow intact.
- Keep Email OR Mobile account creation rule and no OTP.
- Expand the registration security-question pool to 6 questions; user still selects 3.
- Keep forgot-password rule: 2 of the 3 submitted answers must match before reset.
- Improve dashboard scaling lower bound for smaller phone screens without changing the dashboard feature layout.

Important:
- The project still contains backend contracts/fallback account storage. A production cloud authentication endpoint must be connected before claiming cross-device permanent IDs are live.
