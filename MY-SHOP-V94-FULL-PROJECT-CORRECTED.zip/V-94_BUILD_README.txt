MY SHOP V-94 FINAL BUILD

This ZIP is the FULL MY SHOP Android project, not only a workflow file.

Fixes included:
1. AccountStore.java: hashAnswer() now handles NoSuchAlgorithmException.
2. myshop_dashboard_reference.png is replaced by the verified
   myshop_dashboard_header.png content.
3. New .github/workflows/my-shop-v94-final.yml builds the project directly.
4. The workflow does NOT require a signing secret for the first test APK.
   If the four MY_SHOP_RELEASE_* secrets exist, it uses the permanent key.
   Otherwise it creates a temporary test key so the APK can still be downloaded.
5. The workflow creates exactly one final APK artifact:
   MY-SHOP-V94-FINAL.apk

IMPORTANT:
- Do NOT delete the existing GitHub repository or old backups.
- Upload/replace the project files from this ZIP in the repository.
- Then run: Actions -> V-94 MY SHOP FINAL APK BUILD -> Run workflow.
- A successful run will show the APK under Artifacts.
- A temporary-key APK is for testing/fresh install; it is not a permanent
  production signing identity. For future updates, add the permanent signing
  secrets before releasing a replacement APK.
