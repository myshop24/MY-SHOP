package com.myshop.app;

import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

/** V-62 Admin entry point. Real production CRUD is routed through the Cloudflare backend. */
public class AdminManagementActivity extends AppCompatActivity {
 @Override protected void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)){finish();return;}build();}
 private void build(){
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,24,24,24);root.setBackgroundColor(0xFFF8F9FC);
  TextView t=new TextView(this);t.setText("ADMIN PANEL");t.setTextSize(24);t.setGravity(Gravity.CENTER);root.addView(t,new LinearLayout.LayoutParams(-1,80));
  TextView status=new TextView(this);status.setGravity(Gravity.CENTER);status.setText(BackendConfig.isConfigured()?"Backend connected — Admin CRUD enabled":"Backend URL not configured yet. Deploy backend/ first, then set BackendConfig.BASE_URL.");root.addView(status,new LinearLayout.LayoutParams(-1,80));
  String[] actions={"Banner Management","Breaking News","Gallery","External Links","Live TV","Social Links","Back"};
  for(String a:actions){Button x=new Button(this);x.setText(a);x.setOnClickListener(v->{if("Back".equals(a))finish();});root.addView(x,new LinearLayout.LayoutParams(-1,58));}
  setContentView(root);
 }
}
