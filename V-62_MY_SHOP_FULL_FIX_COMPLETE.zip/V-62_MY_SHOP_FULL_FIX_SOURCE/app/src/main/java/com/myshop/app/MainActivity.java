package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** MY SHOP V-62: compact, no-vertical-scroll dashboard. */
public class MainActivity extends AppCompatActivity {
    private static final int BG=Color.rgb(248,249,252), TEXT=Color.rgb(25,31,45), BLUE=Color.rgb(29,82,225), PURPLE=Color.rgb(98,36,225), RED=Color.rgb(235,35,55);
    private static final long SLIDE_MS=3500L;
    private final Handler handler=new Handler(); private int bannerIndex=0;
    private final ImageView[] banners=new ImageView[3];
    private final int[] left={R.drawable.banner_top_left_1,R.drawable.banner_top_left_2,R.drawable.banner_top_left_3,R.drawable.banner_top_left_4,R.drawable.banner_top_left_5,R.drawable.banner_top_left_6};
    private final int[] right={R.drawable.banner_top_right_1,R.drawable.banner_top_right_2,R.drawable.banner_top_right_3,R.drawable.banner_top_right_4,R.drawable.banner_top_right_5,R.drawable.banner_top_right_6};
    private final int[] wide={R.drawable.banner_wide_1,R.drawable.banner_wide_2,R.drawable.banner_wide_3,R.drawable.banner_wide_4,R.drawable.banner_wide_5,R.drawable.banner_wide_6};

    @Override protected void onCreate(Bundle b){super.onCreate(b); try{setContentView(build()); startCarousel();}catch(Throwable t){setContentView(safe());}}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams wt(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}

    private View build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        LinearLayout content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(8),dp(4),dp(8),dp(4));

        LinearLayout header=row();
        ImageView avatar=new ImageView(this); avatar.setImageResource(R.drawable.myshop_profile_avatar); avatar.setScaleType(ImageView.ScaleType.CENTER_CROP); avatar.setBackground(round(Color.WHITE,Color.LTGRAY,dp(24))); avatar.setClipToOutline(true); header.addView(avatar,lp(dp(42),dp(42)));
        LinearLayout user=new LinearLayout(this); user.setOrientation(LinearLayout.VERTICAL); user.setGravity(Gravity.CENTER_VERTICAL);
        String id=SessionManager.getUserId(this); String name=getSharedPreferences("myshop_session",MODE_PRIVATE).getString("full_name",""); if(name.trim().isEmpty())name=SessionManager.isAdmin(this)?"Admin":"My Shop User";
        user.addView(text("Hi, "+name, TEXT,13,true)); user.addView(text("ID: "+(id.isEmpty()?"Guest":id),BLUE,11,true)); header.addView(user,wt(1,dp(42)));
        EditText search=new EditText(this); search.setSingleLine(true); search.setHint(LanguageManager.t(this,"search")); search.setTextSize(11); search.setPadding(dp(8),0,dp(5),0); search.setBackground(round(Color.WHITE,Color.LTGRAY,dp(20))); header.addView(search,wt(1.65f,dp(40)));
        Button lang=plain(LanguageManager.t(this,"language"),PURPLE,10); lang.setOnClickListener(v->toggleLanguage()); header.addView(lang,lp(dp(62),dp(40)));
        Button menu=plain("☰",TEXT,20); menu.setOnClickListener(v->{if(SessionManager.isAdmin(this))startActivity(new Intent(this,AdminManagementActivity.class));else startActivity(new Intent(this,AccountActivity.class));}); header.addView(menu,lp(dp(42),dp(40)));
        content.addView(header,lp(-1,dp(44)));

        LinearLayout top=row(); banners[0]=banner(left[0]); banners[1]=banner(right[0]); top.addView(banners[0],wt(1,dp(72))); top.addView(space(dp(5),1),lp(dp(5),1)); top.addView(banners[1],wt(1,dp(72))); content.addView(top,lp(-1,dp(72)));
        TextView dots=text("●  ○  ○  ○  ○  ○",PURPLE,9,true); dots.setGravity(Gravity.CENTER); content.addView(dots,lp(-1,dp(14)));
        banners[2]=banner(wide[0]); content.addView(banners[2],lp(-1,dp(50)));

        TextView breaking=card("🔴  "+LanguageManager.t(this,"breaking")+"  |  বাংলাদেশে আজকের গুরুত্বপূর্ণ সংবাদ",Color.WHITE,TEXT,10); content.addView(breaking,lp(-1,dp(30)));
        TextView liveHead=text("🔴  "+LanguageManager.t(this,"liveNow"),TEXT,12,true); liveHead.setGravity(Gravity.CENTER_VERTICAL); content.addView(liveHead,lp(-1,dp(24)));

        // Six slots in a 3x2 grid: no horizontal or vertical scrolling.
        LinearLayout r1=row(),r2=row(); for(int i=0;i<6;i++){TextView v=emptyLive(i); (i<3?r1:r2).addView(v,wt(1,dp(50))); if(i%3!=2)(i<3?r1:r2).addView(space(dp(4),1),lp(dp(4),1));}
        content.addView(r1,lp(-1,dp(50))); content.addView(space(1,dp(4)),lp(1,dp(4))); content.addView(r2,lp(-1,dp(50)));

        LinearLayout pair=row(); pair.addView(featureImage(R.drawable.feature_my_feed_selected,LanguageManager.t(this,"feed"),"my_feed"),wt(1,dp(48))); pair.addView(space(dp(5),1),lp(dp(5),1)); pair.addView(featureImage(R.drawable.feature_my_shop_selected,LanguageManager.t(this,"shop"),"my_shop"),wt(1,dp(48))); content.addView(pair,lp(-1,dp(50)));

        LinearLayout funcs=row(); funcs.addView(featureImage(R.drawable.feature_gallery_selected,LanguageManager.t(this,"gallery"),"gallery"),wt(1,dp(55))); funcs.addView(featureImage(R.drawable.feature_go_live_selected,"GO LIVE","go_live"),wt(1,dp(55))); funcs.addView(featureImage(R.drawable.feature_social_selected,LanguageManager.t(this,"social"),"social_media"),wt(1,dp(55))); content.addView(funcs,lp(-1,dp(57)));
        root.addView(content,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav=row(); nav.setPadding(dp(2),dp(2),dp(2),dp(2)); nav.setBackground(round(Color.WHITE,Color.LTGRAY,dp(18)));
        Button home=plain("⌂\n"+LanguageManager.t(this,"home"),BLUE,9),store=plain("🛒\n"+LanguageManager.t(this,"store"),TEXT,9),live=plain("◉\nLIVE",TEXT,9),chat=plain("💬\nCHAT",TEXT,9),more=plain("▦\n"+LanguageManager.t(this,"more"),TEXT,9);
        nav.addView(home,wt(1,dp(48)));nav.addView(store,wt(1,dp(48)));nav.addView(live,wt(1,dp(48)));nav.addView(chat,wt(1,dp(48)));nav.addView(more,wt(1,dp(48)));root.addView(nav,lp(-1,dp(52)));
        store.setOnClickListener(v->open("MY SHOP","my_shop"));live.setOnClickListener(v->open("LIVE","live_now"));chat.setOnClickListener(v->open("CHAT","chat"));more.setOnClickListener(v->startActivity(new Intent(this,AccountActivity.class)));
        return root;
    }
    private TextView emptyLive(int i){TextView v=card("No live stream"+"\n#"+(i+1),Color.WHITE,Color.rgb(90,96,110),9);v.setGravity(Gravity.CENTER);return v;}
    private ImageView featureImage(int id,String d,String key){ImageView v=new ImageView(this);v.setImageResource(id);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(round(Color.WHITE,Color.LTGRAY,dp(10)));v.setClipToOutline(true);v.setContentDescription(d);v.setOnClickListener(x->open(d,key));return v;}
    private ImageView banner(int id){ImageView v=new ImageView(this);v.setImageResource(id);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(round(Color.WHITE,Color.LTGRAY,dp(8)));v.setClipToOutline(true);return v;}
    private void toggleLanguage(){String l=LanguageManager.get(this);LanguageManager.set(this,"bn".equals(l)?"en":"bn");recreate();}
    private void open(String t,String k){try{Intent i=new Intent(this,FeatureActivity.class);i.putExtra("title",t);i.putExtra("feature_key",k);startActivity(i);}catch(Throwable e){Toast.makeText(this,t,Toast.LENGTH_SHORT).show();}}
    private void startCarousel(){handler.postDelayed(new Runnable(){public void run(){bannerIndex=(bannerIndex+1)%6;banners[0].setImageResource(left[bannerIndex]);banners[1].setImageResource(right[bannerIndex]);banners[2].setImageResource(wide[bannerIndex]);handler.postDelayed(this,SLIDE_MS);}},SLIDE_MS);}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
    private TextView text(String s,int c,float z,boolean b){TextView v=new TextView(this);v.setText(s);v.setTextColor(c);v.setTextSize(z);if(b)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private TextView card(String s,int bg,int fg,float z){TextView v=text(s,fg,z,true);v.setGravity(Gravity.CENTER);v.setBackground(round(bg,Color.LTGRAY,dp(8)));return v;}
    private Button plain(String s,int c,float z){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setGravity(Gravity.CENTER);b.setTextColor(c);b.setTextSize(z);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setPadding(0,0,0,0);b.setBackground(round(Color.WHITE,Color.LTGRAY,dp(10)));return b;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private View space(int w,int h){return new View(this);}
    private GradientDrawable round(int fill,int stroke,int r){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(r);g.setStroke(dp(1),stroke);return g;}
    private View safe(){LinearLayout l=row();l.setGravity(Gravity.CENTER);l.addView(text("MY SHOP",PURPLE,24,true));return l;}
}
