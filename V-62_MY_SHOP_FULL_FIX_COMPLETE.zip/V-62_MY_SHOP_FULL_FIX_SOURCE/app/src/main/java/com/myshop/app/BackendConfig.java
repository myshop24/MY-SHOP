package com.myshop.app;
/** Set this after deploying backend/ to Cloudflare Workers. Leave empty for local fallback. */
public final class BackendConfig {
    private BackendConfig() {}
    public static final String BASE_URL = "";
    public static boolean isConfigured(){ return BASE_URL != null && !BASE_URL.trim().isEmpty(); }
}
