# MY SHOP V-62 Free Backend

Target: Cloudflare Workers + D1 + R2.

## What this backend provides
- Permanent 4-digit Profile ID generated once in D1.
- Email/mobile uniqueness enforced by database indexes.
- Login returns the same Profile ID on every app update/reinstall when the same account is used.
- Server-side role (`USER`, `ADMIN`, `MODERATOR`).
- Admin content CRUD for banners, breaking news, gallery, external links and live TV.
- R2 is used for uploaded media; D1 stores metadata.

## Deploy
1. Create a Cloudflare Worker.
2. Create a D1 database and an R2 bucket.
3. Bind them in `wrangler.toml`.
4. Run the migration in `migrations/0001_initial.sql`.
5. Set `ADMIN_EMAILS` as a Worker secret/variable containing the admin email(s), comma separated.
6. Deploy the Worker and put the resulting `https://...workers.dev` URL in the Android backend configuration.

Do not put passwords or Cloudflare API tokens in the APK.
