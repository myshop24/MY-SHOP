# MY SHOP DEVELOPER HANDOFF — V-367

Version: V-367
Android: versionCode 367 / versionName 2.9.367
SOURCE_BUILD_ID: MY SHOP V-367

## Completed
1. Removed mismatched LIVE AUDIO strip below pinned comment.
2. Preserved avatar speaking glow/wave as the audio activity indicator.
3. Upgraded Host join-request card with Accept/Reject and user identity.
4. Completed occupied guest seat action menu: Gift, Mute/Unmute, Kick, Main Guest, seat move, Room Admin grant/revoke, remove speaker.
5. Corrected Mute backend behavior so the user remains seated; mute no longer removes the seat.
6. Kept Main Guest host-only; normal speakers can move only through normal guest seats.
7. Added running Host Live Summary via stats/duration controls.
8. Tightened top Host/Level block so the user line starts directly beside it.

## Pending acceptance
- Build APK using the normal GitHub workflow.
- Two-device test: audience Join Request -> Host Accept/Reject; Host Invite -> User Accept; normal seat changes; Main Guest restriction; Gift to seated guest; Mute keeps seat; Unmute restores publish; Kick removes from Live; Room Admin grant/revoke; avatar speaking glow for host/guest; Host live summary values.

## Locked modules
Login/Auth, Profile/Social/Feed, Store/Wallet, Gift economy, Admin modules, D1 schema, fixed MY SHOP IDs, existing RTC transport architecture.

## Known limitation
No claim of real-device RTC audio acceptance until two-device APK test is completed.

## Next checkpoint
Run the acceptance list above and only patch any failing target behavior without redesigning unrelated modules.
