# MY SHOP V-372 — Premium Button Polish

Baseline: V-371.

## Scope
Visual-only premium polish for Live Home and Audio Live Room controls. Existing screen structure, feature positions, navigation, Live roles, seat logic, Gift/Coin logic, backend contracts and click actions are preserved.

## Changes
- Added reusable stateful premium button finish in `PremiumUi`.
- Added pressed/disabled visual states, controlled gradients, thin highlight stroke, elevation and existing smooth press animation.
- Premium-polished Live Home Go Live / Join Live buttons without changing their size or 50/50 layout.
- Premium-polished Live Home center nav accent.
- Premium-polished Live Room Send, Mic, Join/End, Request, Gift, React, Share and compact control buttons.
- Host End remains visually destructive/red; Join remains accent purple/pink.
- No feature relocation or screen redesign.

## Build identity
- SOURCE_BUILD_ID: MY SHOP V-372
- SOURCE_VERSION_NAME: 2.9.372
- Android versionCode: 372
- Android versionName: 2.9.372
- Worker health: V-372 / 2.9.372
