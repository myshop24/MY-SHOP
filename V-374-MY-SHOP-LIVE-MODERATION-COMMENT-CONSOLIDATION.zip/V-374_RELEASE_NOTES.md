# MY SHOP V-374 — Live Moderation + Comment Space Consolidation

## Completed scope
- Added reliable Mute → Unmute behavior for seated speakers.
- Added recovery path for users muted by older Live versions: Host/authorized moderator can clear old mute from the active-user menu even when the target is currently audience.
- Mute is now audio-only: it no longer suppresses ordinary Live comments or call invitations.
- Legacy persisted `MUTED` sanctions are auto-cleared when detected by viewer/state/comment/join flows.
- Live Block now also records the Host's block in the persistent account Block List.
- Profile → Settings & Privacy → Block List now shows avatar, name, MY SHOP ID, and an Unblock button.
- Profile Unblock also clears the matching Live `BLOCKED` sanction so the user is not left stuck.
- Host persistent block is enforced when the blocked user attempts to rejoin that Host's Live.
- Pinned comment banner no longer reserves space when there is no pinned comment.
- Long-press on a Live comment opens pin controls; a visible pinned banner can be long-pressed/unpinned.
- Guest seats were reduced slightly while preserving the same 4+4 seat structure, creating more vertical space for comments.
- Live Room visual layers were normalized to the same dark navy/purple family for a more continuous full-screen theme.
- Existing Live Home Go Live / Join Live controls remain equal-width and premium-styled.

## Preserved
- Guest-seat count/logic and Main Guest behavior.
- Gift, reaction, invite/join, RTC, Live End, ephemeral comments, and existing admin controls.
- Google Play Billing and compliance safeguards.
