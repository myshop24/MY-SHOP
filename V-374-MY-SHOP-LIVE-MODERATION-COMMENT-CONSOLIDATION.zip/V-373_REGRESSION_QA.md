# V-373 Regression QA

- Baseline: V-372 Premium Button Polish.
- Worker JavaScript syntax: PASS (`node --check`).
- Android resource XML parsing: PASS.
- Scope protection: all baseline files outside the intentional V-373 change set remained byte-for-byte unchanged.
- Join Request rule: MUTED is no longer a deny state; BLOCKED/KICKED remain deny states.
- Host/Admin/Moderator invite rule: MUTED is repaired/cleared; BLOCKED/KICKED remain deny states.
- Join acceptance: stale MUTED state cleared before seat assignment.
- Premium button/UI work from V-372: preserved, not redesigned.
- Full Android build: not run in this container; GitHub workflow required.
- Real multi-device Live test: required before calling runtime behavior fully accepted.
