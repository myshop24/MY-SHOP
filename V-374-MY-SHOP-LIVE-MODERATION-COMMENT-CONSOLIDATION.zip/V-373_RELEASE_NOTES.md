# MY SHOP V-373 — Live Mute / Join / Call Eligibility Fix

## Scope
Fix the regression where a user who had previously been muted could no longer send a Join Request or be invited/suggested to the Live call.

## Fixed
1. `MUTED` no longer returns `LIVE_MUTED_LISTEN_ONLY` from the Join Request endpoint.
2. A stale `MUTED` live sanction is cleared when the user sends a fresh Join Request.
3. Host/Room Admin/MY SHOP Admin/Moderator invite path remains available for muted users; only BLOCKED/KICKED are ineligible.
4. Join Request acceptance clears any stale MUTED sanction before speaker-seat assignment.
5. Invite acceptance already clears stale MUTED state and is retained.
6. Block/Kick behavior remains unchanged.
7. No UI/layout/button redesign in this release.

## Identity
- SOURCE_BUILD_ID: MY SHOP V-373
- SOURCE_VERSION_NAME: 2.9.373
- Android versionCode: 373
- Android versionName: 2.9.373
- Worker health: V-373 / 2.9.373
