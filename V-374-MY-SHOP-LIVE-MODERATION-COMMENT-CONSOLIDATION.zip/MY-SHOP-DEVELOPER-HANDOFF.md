# MY SHOP DEVELOPER HANDOFF — V-374

## Phase
Consolidated Live moderation recovery, persistent Block/Unblock, pinned-comment space recovery, and Live Room theme consistency.

## Completed
- Mute → Unmute is reversible from seated-user controls.
- Old/stale MUTED state can be cleared for an audience user from the Live user menu.
- Mute is audio-only; ordinary comments and Host call invitations remain permitted.
- Block is persistent for the Host and appears in Profile → Settings & Privacy → Block List.
- Block List shows avatar, name, MY SHOP ID, and Unblock.
- Unblock clears both persistent account block and Host Live BLOCKED sanction.
- Empty pinned-comment banner is hidden; comment long-press exposes Pin and visible pin can be Unpinned.
- Guest seat visuals reduced slightly to free more comment space without changing the 4+4 structure.
- Live Room dark navy/purple surfaces normalized for a continuous theme.
- Equal-width premium Go Live / Join Live controls preserved.

## Last checkpoint
V-374 prepared from V-373 with scoped changes only to Live moderation/comment UI, Block List UI, backend moderation state, and release metadata/docs.

## Pending
- GitHub Android compile/build.
- Deploy Worker and run two-device real-time QA for mute recovery, comments, invite, block persistence and pin propagation.
- Lock V-374 as golden stable only after runtime PASS.

## Known issues / release truth
This container does not include a Gradle wrapper, so a full Android compile was not executable here. Worker syntax and V-374 source-level regression checks passed. Do not claim real-device acceptance until the deployed Worker + APK are tested.
