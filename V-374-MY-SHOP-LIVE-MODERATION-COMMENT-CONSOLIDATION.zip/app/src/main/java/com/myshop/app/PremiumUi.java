package com.myshop.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.MotionEvent;
import android.view.View;

/** V-370 shared premium visual/micro-interaction foundation.
 * Keep this as the single reusable MY SHOP visual-token source.
 */
public final class PremiumUi {
    private PremiumUi() {}

    public static final int NAVY = Color.rgb(10, 24, 68);
    public static final int BLUE = Color.rgb(49, 111, 245);
    public static final int PURPLE = Color.rgb(111, 63, 232);
    public static final int PINK = Color.rgb(238, 54, 177);
    public static final int CYAN = Color.rgb(71, 213, 255);
    public static final int GOLD = Color.rgb(255, 198, 72);

    // V-370 canonical premium UI tokens. New screens should use these instead of random values.
    public static final int RADIUS_SMALL_DP = 10;
    public static final int RADIUS_CONTROL_DP = 14;
    public static final int RADIUS_CARD_DP = 18;
    public static final int RADIUS_HERO_DP = 24;
    public static final int CONTROL_HEIGHT_DP = 48;
    public static final int PRIMARY_HEIGHT_DP = 52;
    public static final int TOUCH_MIN_DP = 44;
    public static final int SPACE_XS_DP = 4;
    public static final int SPACE_SM_DP = 8;
    public static final int SPACE_MD_DP = 12;
    public static final int SPACE_LG_DP = 16;
    public static final int SPACE_XL_DP = 24;
    public static final long PRESS_IN_MS = 70L;
    public static final long PRESS_OUT_MS = 145L;

    public static GradientDrawable gradient(Context c, int[] colors, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeColor != Color.TRANSPARENT && strokeDp > 0) g.setStroke(dp(c, strokeDp), strokeColor);
        return g;
    }

    public static GradientDrawable solid(Context c, int fill, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeColor != Color.TRANSPARENT && strokeDp > 0) g.setStroke(dp(c, strokeDp), strokeColor);
        return g;
    }

    public static void press(View v) {
        if (v == null) return;
        v.setClickable(true);
        v.setFocusable(true);
        v.setOnTouchListener((view, event) -> {
            int a = event.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(.975f).scaleY(.975f).alpha(.92f).translationY(dp(view.getContext(), 1)).setDuration(PRESS_IN_MS).start();
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).alpha(1f).translationY(0f).setDuration(PRESS_OUT_MS).start();
            }
            return false;
        });
    }


    /** V-372: reusable premium button finish without changing layout or click logic. */
    public static void premiumButton(View v, int[] colors, int radiusDp, int strokeColor, int elevationDp) {
        if (v == null) return;
        int[] pressedColors = new int[colors.length];
        for (int i = 0; i < colors.length; i++) pressedColors[i] = darken(colors[i], 0.90f);
        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, gradient(v.getContext(), pressedColors, radiusDp, Color.argb(165,255,255,255), 1));
        states.addState(new int[]{-android.R.attr.state_enabled}, solid(v.getContext(), Color.rgb(65,72,95), radiusDp, Color.argb(60,255,255,255), 1));
        states.addState(new int[]{}, gradient(v.getContext(), colors, radiusDp, strokeColor, 1));
        v.setBackground(states);
        premiumElevation(v, elevationDp);
        press(v);
    }

    public static void premiumPrimary(View v) {
        premiumButton(v, new int[]{Color.rgb(40,133,255), Color.rgb(83,76,244), Color.rgb(137,55,232)}, RADIUS_CONTROL_DP, Color.argb(150,216,235,255), 5);
    }

    public static void premiumAccent(View v) {
        premiumButton(v, new int[]{Color.rgb(115,52,228), Color.rgb(194,43,221), Color.rgb(244,52,166)}, RADIUS_CONTROL_DP, Color.argb(150,255,214,252), 5);
    }

    public static void premiumDanger(View v) {
        premiumButton(v, new int[]{Color.rgb(232,54,92), Color.rgb(245,57,112), Color.rgb(201,38,137)}, RADIUS_CONTROL_DP, Color.argb(155,255,220,232), 5);
    }

    public static void premiumUtility(View v, int accent) {
        premiumButton(v, new int[]{Color.rgb(15,38,94), Color.rgb(55,41,132)}, RADIUS_CONTROL_DP, accent, 4);
    }

    private static int darken(int color, float factor) {
        int r=Math.max(0,Math.min(255,Math.round(Color.red(color)*factor)));
        int g=Math.max(0,Math.min(255,Math.round(Color.green(color)*factor)));
        int b=Math.max(0,Math.min(255,Math.round(Color.blue(color)*factor)));
        return Color.rgb(r,g,b);
    }

    public static void premiumElevation(View v, int dp) {
        if (v != null) v.setElevation(dp(v.getContext(), dp));
    }

    private static int dp(Context c, int n) {
        return Math.round(n * c.getResources().getDisplayMetrics().density);
    }
}
