# V-374 Regression QA

## Static / source checks
- V-374 identity metadata: PASS.
- Worker JavaScript syntax (`node --check`): PASS.
- V-374 targeted static validator: PASS.
- XML resource parse check: PASS.
- Go Live / Join Live equal-width layout preserved: PASS.
- Existing 8 guest seats remain 4+4; only visual size was reduced slightly: PASS.

## Moderation checks
- Seated user has state-appropriate Mute OR Unmute action: PASS (source verified).
- Legacy audience mute can be cleared without requiring a seat: PASS (source verified).
- Mute does not block ordinary comments: PASS (source verified).
- Mute does not block Host call invitation: PASS (source verified).
- Block remains separate from Mute and persists to Profile Block List: PASS (source verified).
- Profile Unblock clears account block and matching Live sanction: PASS (source verified).

## Comment / UI checks
- Empty pin banner consumes no layout space (`GONE`): PASS.
- Comment long-press pin flow: PASS.
- Unpin removes pinned banner: PASS.
- Smaller seats provide extra comment viewport height: PASS.
- Live background/host/footer overlays use one navy-purple color family: PASS.

## Runtime items requiring device/deployed backend
- Two-account RTC microphone Mute → Unmute audio restoration.
- Previously muted account rejoining from an older deployed build.
- Real Cloudflare D1 persistence for Block → Profile Block List → Unblock.
- Multi-device Pin/Unpin propagation.
- Final Android APK build in GitHub workflow (no Gradle wrapper is included in this source package/container).
