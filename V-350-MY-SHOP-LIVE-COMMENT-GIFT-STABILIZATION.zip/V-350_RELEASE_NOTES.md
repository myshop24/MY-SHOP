# MY SHOP V-350 Stabilization

Locked scope only. No intentional redesign outside the approved Live Room stabilization target.

- Premium soft-grey/translucent 2–9 guest seats (4+4), white chair empty state.
- Join button soft pulse/breathing animation for audience; stops for Host/Speaker/listen-only.
- Expanded flexible comment stage; compact comment rows; auto-scroll to newest.
- Gift activity shown as prominent sender + level + gift image/name/quantity/value entry.
- Gift sound runtime path/fallback retained from V-349 hardening.
- Floating banners moved away from comment list area.
- Existing persistent-login and notification stabilization from V-349 retained.
- Existing Coin/Gold, gift transaction, Admin, Join Request/Host Invite, End Live and backend contracts preserved.

Runtime acceptance still requires installing the Green CI APK and checking the approved reference, gift audio, comment flow, login and notifications on a real device.
