# V-350 Regression QA

## Source/static gates
- [x] Version metadata set to V-350 / 2.9.350 / versionCode 350.
- [x] Seat range remains 2–9, 4+4.
- [x] Empty user seats use chair resource, not MS logo.
- [x] Audience Join animation implemented and state-gated.
- [x] Comment stage remains flexible-height and newest-entry auto-scroll is present.
- [x] Gift sender activity card remains prominent and compact.
- [x] V-349 gift sound hardening retained.
- [x] No intentional Coin/Gold/Admin/backend contract redesign.

## Required Green APK/device acceptance
- [ ] Compare installed Live Room against locked approved reference.
- [ ] Send multiple normal comments and verify sequential visible stack.
- [ ] Send Coin and Gold gifts and verify audible sound + prominent sender entry.
- [ ] Restart app and verify persistent login.
- [ ] Background/close app and verify system notifications.
- [ ] Verify Join request -> Host accept -> Speaker -> Leave flow.
