# MY SHOP Developer Handoff — V-314

## Completed in V-314
- Premium folder-based Admin Control Center redesign.
- Existing Admin login/gate preserved exactly.
- Six organized folders using only features already present in source.
- Search + language selector + collapsible folder navigation.
- Existing Admin module routes preserved.
- Admin Store/Badge/Coin screen reorganized into numbered workflow sections.
- Live Gift Manager reorganized into numbered workflow sections.
- Generic AdminSection and Finance Center receive language access/workflow polish.
- Existing Startup Ad Full Image / 1080×2400 guidance preserved.

## Protected systems
- Do not weaken Admin role checks or local gate.
- Do not rename/remove Cloudflare D1/R2 bindings, worker routes or persistent user IDs.
- Keep Admin CRUD semantics and destructive confirmations.
- Keep Play digital-goods safeguards and Creator Earnings separation.

## QA checkpoint
- V-313 AdminGateActivity SHA-256 equals V-314 AdminGateActivity SHA-256.
- Unique AdminHub routes preserved: PASS.
- Modified Java files: no syntax-like parse errors from javac parsing stage.
- Worker not functionally modified in this Admin redesign.
- Full Android compile: not run locally because source has no executable gradlew/wrapper JAR.

## Google Play compliance gate
- targetSdk / compileSdk 36 retained.
- Paid virtual currency must use compliant Play Billing where required.
- Purchased/spendable Coin/Gold Coin must not be cash-withdrawable.
- Creator cash-out must remain tied to eligible Creator Earnings.
- Production Privacy Policy still needs an explicit real owner/developer/privacy contact before publication if not already supplied externally.
- Play Console Data Safety / Financial Features / Ads / UGC / App Access / account deletion declarations must match runtime behavior.
