package com.myshop.app;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.widget.*;
import org.json.JSONObject;

/** V-297 admin-only manual Coin/Gold/Badge/Membership grant board with Bengali guidance. */
public class AdminWalletActivity extends androidx.appcompat.app.AppCompatActivity {
  private EditText userId,units,days,note; private Spinner type,code;
  @Override protected void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)||!SessionManager.isAdminGateUnlocked()){finish();return;}build();}
  private void build(){
    ScrollView sv=new ScrollView(this); LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(16),dp(18),dp(16),dp(28));r.setBackgroundColor(Color.rgb(246,248,252));
    TextView h=t("এডমিন ওয়ালেট • ব্যাজ/ব্যালেন্স গ্রান্ট",22,true);r.addView(h);
    TextView sub=t("Official Admin Panel থেকে User ID-তে Coin, Gold Coin বা Badge/Membership grant করতে পারবেন। Admin/Official grant-এ MY SHOP Service Fee নেই; Coin/Gold grant-এর Star অনুযায়ী প্রতি 1⭐-এ +2 Level হবে। প্রতিটি Grant backend audit history-তে থাকবে।",12,false);sub.setPadding(0,dp(8),0,dp(14));r.addView(sub);
    r.addView(help("ইউজার আইডি","যে ইউজারকে গ্রান্ট দেবেন তার ৪ সংখ্যার MY SHOP ID লিখুন।"));userId=e("৪ সংখ্যার ইউজার আইডি");userId.setInputType(InputType.TYPE_CLASS_NUMBER);r.addView(userId,lp(-1,dp(52)));
    r.addView(help("গ্রান্টের ধরন","COIN, GOLD অথবা BADGE/MEMBERSHIP নির্বাচন করুন।"));type=new Spinner(this);type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"COIN","GOLD","BADGE"}));r.addView(type,lp(-1,dp(52)));
    r.addView(help("আইটেম / টিয়ার","Coin/Gold অথবা BLUE/VIP/VVIP/ROYAL নির্বাচন করুন।"));code=new Spinner(this);code.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"COIN","GOLD","BLUE","VIP","VVIP","ROYAL"}));r.addView(code,lp(-1,dp(52)));
    r.addView(help("পরিমাণ","Coin/Gold-এর পরিমাণ দিন; Badge হলে ১ দিন।"));units=e("পরিমাণ / ইউনিট (ব্যাজ = ১)");units.setInputType(InputType.TYPE_CLASS_NUMBER);units.setText("1");r.addView(units,lp(-1,dp(52)));
    r.addView(help("মেয়াদ","Badge/Membership কতদিন থাকবে। ০ দিলে Permanent / No Expiry।"));days=e("মেয়াদ (দিন) • ০ = স্থায়ী");days.setInputType(InputType.TYPE_CLASS_NUMBER);days.setText("0");r.addView(days,lp(-1,dp(52)));
    r.addView(help("নোট","Official grant-এর কারণ/রেফারেন্স লিখে রাখুন; Audit-এ কাজে লাগবে।"));note=e("ঐচ্ছিক নোট / Official reference");r.addView(note,lp(-1,dp(64)));
    Button grant=new Button(this);grant.setText("✓ ম্যানুয়াল গ্রান্ট নিশ্চিত করুন");grant.setTextColor(Color.WHITE);grant.setBackgroundColor(Color.rgb(83,32,180));grant.setOnClickListener(v->grant());r.addView(grant,lp(-1,dp(54)));
    Button back=new Button(this);back.setText("ফিরে যান");back.setOnClickListener(v->finish());r.addView(back,lp(-1,dp(50)));sv.addView(r);setContentView(sv);
  }
  private TextView help(String a,String b){TextView x=t(a+" — "+b,10,false);x.setTextColor(Color.rgb(95,103,126));x.setPadding(0,dp(6),0,dp(3));return x;}
  private void grant(){String uid=userId.getText().toString().trim();int u=num(units.getText().toString());int d=num(days.getText().toString());String ty=String.valueOf(type.getSelectedItem());String c=String.valueOf(code.getSelectedItem());if(uid.length()!=4||u<=0){Toast.makeText(this,"সঠিক ৪ সংখ্যার User ID ও পরিমাণ দিন।",Toast.LENGTH_SHORT).show();return;}new AlertDialog.Builder(this).setTitle("এডমিন গ্রান্ট নিশ্চিত করুন").setMessage("User ID: "+uid+"\nধরন: "+ty+"\nআইটেম: "+c+"\nপরিমাণ: "+u+"\nমেয়াদ: "+d+" দিন\n\nএই কাজটি backend audit history-তে থাকবে।").setNegativeButton("বাতিল",null).setPositiveButton("গ্রান্ট দিন",(x,w)->BackendClient.adminWalletGrant(SessionManager.getToken(this),uid,ty,c,u,d,note.getText().toString(),new BackendClient.Callback(){public void onSuccess(JSONObject o){Toast.makeText(AdminWalletActivity.this,"✓ গ্রান্ট সম্পন্ন হয়েছে।",Toast.LENGTH_LONG).show();}public void onError(String m){Toast.makeText(AdminWalletActivity.this,m,Toast.LENGTH_LONG).show();}})).show();}
  private int num(String s){try{return Integer.parseInt(s.trim());}catch(Exception e){return 0;}} private EditText e(String h){EditText x=new EditText(this);x.setHint(h);x.setPadding(dp(10),0,dp(10),0);return x;} private TextView t(String s,int z,boolean b){TextView x=new TextView(this);x.setText(s);x.setTextSize(z);x.setTextColor(Color.rgb(22,28,55));if(b)x.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return x;}private LinearLayout.LayoutParams lp(int w,int h){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.bottomMargin=dp(8);return p;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
