# MY SHOP Developer Handoff — V-313

## Completed
- Coin and Gold Coin separate balances and separate Live Gift catalogs.
- Empty gift catalog auto-seeds functional Coin and Gold Coin gift records; Admin can edit/delete/publish and upload original preview/animation assets.
- Normal user Gift and ID transfer applies configured MY SHOP Service Fee (default 10%); Admin/Official sender exempt.
- 100,000 Coin = 1 Star; 1,000 Gold Coin = 1 Star. Normal receipt adds +1 Level per Star; Official Admin grant adds +2 Levels per Star.
- Star/Level audit ledger and Admin finance exposure added.
- User Coin/Gold wallet removes ADMIN/REWARD action; balance remains primary and Withdraw is compact.
- Withdraw remains Creator Earnings only; spendable Coin/Gold is not cash-withdrawable.
- End Live is first-tap authoritative in UI with idempotent backend automatic retry.
- Existing Startup Advertisement Admin Panel updated/preserved: 1080x2400 recommendation, Full Image default FIT/CONTAIN, Fill Screen option, blur background, image/video, 1–4 sec, publish, Skip.
- Privacy-policy placeholder text removed; production publisher/contact details still require Play Console/public listing owner setup.

## Play Compliance Gate
- Paid digital Coin/Gold purchase remains disabled in this Play release.
- Do not enable paid digital currency without compliant Google Play Billing and provenance rules preventing purchased value from becoming cash-withdrawable directly or indirectly.
- Creator Earnings is the only cash-out source.
- UGC moderation/report/block and account-deletion systems must remain intact.

## Verification
- Worker JavaScript syntax: PASS (`node --check`).
- Targeted V-313 source checks: PASS.
- Full Android compile: NOT RUN locally because the source package has no Gradle wrapper executable; GitHub Actions/Android build environment must compile the release before distribution.

## Known manual setup
- Replace seeded fallback gift visuals by uploading original MY SHOP gift preview/animation assets in Admin Live Gift Manager for a premium visual catalog.
- Confirm real privacy/support contact in Play Console and public listing before production submission.
