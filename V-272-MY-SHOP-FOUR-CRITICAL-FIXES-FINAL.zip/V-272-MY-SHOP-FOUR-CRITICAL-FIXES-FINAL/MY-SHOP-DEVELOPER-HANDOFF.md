# MY SHOP Developer Handoff — V-272

Base: V-271. Target: V-272 / 2.9.272 / versionCode 272.

Critical fixes implemented:
1. Live/New User cards: parent section/row/card heights corrected so the full Add Friend / Requested / Respond action is not clipped.
2. Breaking News Admin: explicit A− / current sp / A+ controls; separate visual Background and Text color pickers + HEX. RTL marquee behavior unchanged.
3. Dashboard theme: Admin-saved BG / Primary Blue / Purple / Pink-Magenta remain server-backed and the Dashboard consumes the latest config via ThemeConfig cache + safe recreate. Key live/dashboard accent gradients/badges use configured palette.
4. User Password / Reset: Account & Security now opens working Change Password and Forgot/Reset flows. Authenticated change verifies current password; both change/reset hash on backend and invalidate sessions. Plaintext password is never returned or exposed.

Verification completed before packaging:
- identity consistency assertions
- four-fix source assertions
- Java delimiter balance on modified source files
- Node.js syntax check on Worker source
- ZIP integrity test

Local APK compilation is not available in this container because the source intentionally has no gradle-wrapper.jar/gradlew. GitHub Actions remains the compile/sign gate.
