# MY SHOP V-639 /2.9.639 — complete source archive recovery

## Scope
Owner requested repair of GitHub run701, which exited9 during unzip, BEFORE Worker deployment or Android Gradle build. Screenshot says end-of-central-directory signature not found. The actual previously delivered V638 Library archive is19,829,173 bytes and fails Python ZIP parsing. Its repaired copy opens but has only1020 entries, with471 V637 entries missing, including Gradle wrapper/build inputs. It is not a complete build source.

## Repair
Reconstruct from the fully verified canonical V637 archive (24,998,619 bytes,1489 entries), preserving every baseline source/runtime asset and build generator input. Carry over only the exact V638 production Java patch: StoryRail632 drafts callback uses StoryRail632.this::reload and StoryRail632.this::drafts636. No app redesign or new economy behavior in this release. V637 UiStrings test-double repairs retained.
VersionCode639/versionName2.9.639, source/build IDs V639 and both Worker health markers updated. Preserve root workflows, permanent signing configuration/Secrets, Cloudflare bindings and data. No deployment performed here.

## Packaging safeguards
Create archive under a temporary name; close and verify all CRCs before atomic rename. Independently run system unzip integrity test and full clean extraction; compare every extracted file to source. Retain Gradle wrapper, scripts, manifests, all original app resources/design generator inputs. Only redundant historical nonbuild verification logs may be excluded per packaging script. No APK included. Before delivery, verify same bytes after saving, and download saved archive for full roundtrip hash/ZIP verification. The archived tests results record actual local checks; full Android build is a separate condition.

## Tests
Exact production draft method compiled using javac with minimal UI/backend doubles, both edit/delete callbacks executed; negative control reproduces both original missing-method errors. Added same regression to preBuild/CI. Existing source gates passed locally; all baseline runtime/design input hashes match V637. Optional unchanged animation regeneration was stopped, not claimed as completed; generated outputs are not added to the ZIP. See verification/V639-build-gates.json and V639-asset-preservation.json.

## Known limits
Local Android assembleRelease may remain blocked at Gradle download; do not claim an APK or complete Android typecheck based on source checks. Existing V636 language/net-profit/office-stock, phone visuals and production D1 acceptance remain as documented in handoffs/MY-SHOP-V636-HANDOFF.md. GitHub's exact selected commit/version/signed APK must still be checked.

## Next
Third phase is V640, per latest owner direction. Home/Profile/menu/Moon redesign, headline divider removal,24h physical Story cleanup, comment bubble design/Try/avatar/reallevel/300Diamond30days/Admin overrides/GiveFriend/customDiamond icon are deferred. Previous scope document retained as historical brief; do not implement in639. Next changed delivery640. Read GITHUB-UPLOAD-V639-BN.md.
