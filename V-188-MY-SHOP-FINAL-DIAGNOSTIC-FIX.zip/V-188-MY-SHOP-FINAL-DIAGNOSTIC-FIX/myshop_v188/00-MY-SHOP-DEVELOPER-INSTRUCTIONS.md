# MY SHOP — Developer Instructions (Permanent Master Rules)

## 0. READ THIS FIRST — NON-NEGOTIABLE
Before opening, editing, replacing, deploying, building, or otherwise working on ANY MY SHOP project file, a developer/AI must read this document first.

This file is the project's permanent handoff/continuation guide. It must remain at the project root with the `00-` prefix so it is encountered before ordinary project files.

**Do not treat MY SHOP as a new project.** Continue from the latest valid sequential V-number and preserve all older versions.

### 0.1 DIRECT FAILURE-FIX RULE — NON-NEGOTIABLE
- If a build/test/deployment failure is shown with an exact error and the affected file/line is identifiable, inspect that exact failure first and fix it directly in the next sequential V-number.
- Do not make the user repeatedly navigate unrelated checks, repeat screenshots, or perform trial-and-error changes when the root compile/runtime error is already visible.
- Preserve the failed version as evidence; never overwrite it.
- After the direct fix, run the relevant validation/build path. If a new error appears, fix that exact new error in the same focused manner.
- Do not claim the fix is successful until the next available validation provides evidence.
- Only ask the user for additional information when the available evidence is genuinely insufficient to identify the failure.

## 1. LIVE VERSION / VERSIONING RULE
- Current development line: **V-186**.
- Previous protected version: **V-185** (V-179 through V-185 remain preserved; V-184 is the failed-build reference and V-185 is the last successful APK-build reference; neither may be overwritten).
- Next release must use the next sequential V-number: V-186, then V-188, etc.
- Never overwrite or delete V-179, V-180, V-181, V-182, or any older protected version.
- Before creating a new release, make a complete backup/copy of the previous release.
- Every new release must contain its own SOURCE_BUILD_ID and release notes.
- The newest V-numbered source is the only source allowed for the next build/release.

## 2. HOW THIS DOCUMENT STAYS CURRENT
Whenever a new requirement, confirmed bug, architectural decision, security rule, deployment rule, or completed feature is learned during development:
1. Add it to this document in the appropriate section.
2. If it is a new historical event/decision, append it to **Section 12 — Running Project Change Log** with the V-number and date.
3. Do not silently remove older rules unless the rule was explicitly superseded; if superseded, record what changed and why.
4. The newest confirmed information has priority over older notes, but protected historical versions must not be rewritten.

## 3. PROJECT PURPOSE
MY SHOP is a mobile-first shopping/live-streaming platform with:
- User registration/login and account management.
- Dashboard, live categories, feed, gallery, banners and managed links.
- Live-streaming related features such as GO LIVE / JOIN LIVE.
- Admin-controlled content, ads, banners and media.
- Cloudflare Worker backend, D1 database and R2 media storage.
- Future monetization including startup advertisements and Google Ads-compatible placement.

## 4. CORE SAFETY / PRESERVATION RULES
- Do not remove or replace a working feature unless the user explicitly asks for it.
- Prefer additive, backward-compatible changes.
- Never overwrite a protected version.
- Before modifying/deploying production-related code, preserve a rollback copy.
- Never claim an APK or live deployment succeeded without actual build/deployment evidence.
- If live Cloudflare credentials/status are unavailable, say so instead of guessing.

## 5. PERMANENT USER / ADMIN IDENTITY RULE — CRITICAL
The Permanent User/Admin ID is immutable and globally unique.

- Never change, delete, recycle, overwrite, or reassign a Permanent User/Admin ID.
- A deleted/deactivated account's Permanent ID must never be reused by another account.
- Identity history must remain available for audit, transactions, moderation and account history.
- Email/mobile/password are credentials and may be reset/updated by authorized Admin without changing the Permanent ID.
- User may change profile photo and normal profile settings, but cannot change Permanent ID.
- Account removal must use a soft status such as ACTIVE / SUSPENDED / DISABLED / DEACTIVATED instead of hard-deleting the identity record.
- Enforce this rule in Android UI, Worker backend and D1 database constraints/logic.
- Passwords must never be stored in plaintext.
- Credential changes should be auditable.

## 6. AUTHENTICATION / GOOGLE LOGIN
Existing login must remain available:
- Email / Mobile / User ID + Password.
- Existing session/token backend flow must remain intact.
- Existing roles: USER / ADMIN / MODERATOR.
- Forgot-password/security-question flow must remain intact.

Google Login is an additional login option, not a replacement.
- Current V-183 state: Google button/UI exists, but real Google OAuth is not live without valid Google Cloud configuration.
- Never grant ADMIN based only on a Gmail address.
- Google identity must be linked to the existing account/Permanent ID and backend role must determine Admin access.
- When implementing real OAuth, prefer current Google-recommended Credential Manager / Google Identity Services.
- Verify Google ID tokens server-side; use Google's stable `sub` identifier for account linkage.

## 7. STARTUP AD
Desired flow:
**App Open → Startup Advertisement → countdown/Skip → Login → Google or normal Login → Dashboard**

Current implementation:
- Startup ad is managed from Admin Dashboard Ads.
- Slot key: `startup_ad`, slot `1`.
- Display duration is configurable (1–60 seconds; current default/fallback is 3 seconds).
- Admin can change photo, save, delete, set target link and display duration.
- If backend is unavailable, app uses bundled fallback startup artwork.
- Future Google Ads integration must respect Google's actual ad format/policy; do not assume an arbitrary forced duration for Google-served ads.

## 8. ADMIN / CONTENT MANAGEMENT
Admin panels must remain Admin-only and must not expose management controls to ordinary users.

Managed areas include, as applicable:
- Dashboard ads/startup ad.
- Banners.
- Gallery/media.
- Dashboard configuration.
- Feature buttons.
- Social links.
- Managed external links.
- Other content-management folders already present in the project.

Known V-182 issue to solve in the next release:
- User reported that **all Admin Add/Save/Link/content features** fail, not only Banner upload.
- Banner error shown: `Upload failed: Banner save failed safely; the previous banner was kept.`
- This strongly suggests a shared backend/D1 write-path, schema, active Worker/database mismatch, or related infrastructure problem rather than one isolated UI feature.
- Do not assume the exact root cause without logs/probes.

## 8.1 SHARED ADMIN WRITE-PATH RULE — PERMANENT
The Admin Banner, Gallery, Advertisement, Dashboard, Social, Feature, External Link and other content folders are not independent infrastructure. They share the Cloudflare D1/R2 write layer.
- If multiple Admin folders fail with similar save/upload errors, treat it as a shared backend/D1/R2 problem first. Do not patch each folder separately as if each were a new bug.
- The first diagnostic path is: active Worker → D1 schema → D1 WRITE probe → R2 WRITE probe → exact endpoint error.
- Schema repair must be additive and explicit. Missing required columns/tables must be repaired automatically; migration errors must never be silently swallowed.
- Before a release is accepted, `/health/deep` must prove both D1 READ+WRITE and R2 READ+WRITE.
- Admin write endpoints must fail with a precise machine-readable error and message when the shared write layer is unavailable.
- If the exact root error is already visible in logs/screenshots, fix that exact layer directly in the next sequential V-number; do not make the user perform unrelated troubleshooting loops.
- R2 uploads must be compensated/deleted if their corresponding D1 record cannot be committed, so failed saves do not leave orphaned media.

## 9. NOTIFICATION SYSTEM — CORE REQUIREMENT
The in-app notification box is a required user-facing feature and must remain functional.
- Users must see MY SHOP broadcast/update notices such as dashboard, banner, gallery, advertisement and other confirmed content updates.
- A post owner must receive an in-app notification when another user likes their post.
- A post owner must receive an in-app notification when another user comments on their post.
- Notification creation must never cause the underlying like/comment/content action to fail.
- Notification schema must be self-healing at runtime and failures must be surfaced in logs/API responses rather than silently swallowed.
- The notification inbox should refresh when opened/resumed and periodically while visible.
- Unread count must remain synchronized with the notification list.
- This is currently an in-app notification inbox; Android push notifications are a separate future feature and must not be assumed to exist.

## 10. BACKEND / CLOUDFLARE
Architecture:
- Cloudflare Worker backend.
- D1 database: `my-shop-db`.
- R2 media bucket: `my-shop-media`.
- Worker name: `rapid-bush-62ea`.
- App/backend URL currently configured in source: `https://rapid-bush-62ea.myshopsatkania.workers.dev`.

Important:
- Live environment cannot be assumed healthy from source code alone.
- Current deep health is mostly read-only; it must be strengthened before relying on it as a write-health guarantee.
- Do not silently swallow schema/migration errors.

## 11. REQUIRED NEXT BACKEND HARDENING
For the next appropriate release, implement and verify:
1. D1 table + required column + index/constraint checks.
2. D1 write → verify → cleanup probe.
3. R2 put → verify/head → delete probe.
4. Auto schema repair with surfaced errors, not silent catches.
5. Safe compensation/rollback if R2 succeeds but D1 fails.
6. Atomic/batched D1 writes where appropriate.
7. Admin System Health diagnostics showing the actual failing layer.
8. GitHub Actions must refuse release/build when required D1/R2 write probes fail.
9. Protect production write probes with appropriate admin/secret authorization.

## 12. BUILD / RELEASE RULES
- Android Java project.
- Expected build environment: Java 17, Android SDK 36, Gradle 8.11.1.
- GitHub Actions is the expected build path when local Gradle/SDK is unavailable.
- Release must use the newest V-numbered source ZIP.
- Workflow must reject older source versions.
- Preserve permanent signing configuration.
- Produce one release APK artifact.
- Verify Worker health and version/build identity after deployment.

## 13. RUNNING PROJECT CHANGE LOG
### V-186 — 2026-09-04
- Permanent shared Admin write-path hardening: content folders now validate the required D1 schema before writes instead of silently accepting incomplete migrations.
- Added D1 write → verify → cleanup health probe and R2 put → head → delete health probe.
- `/health/deep` now reports D1/R2 read and write health; release workflow refuses the APK release unless both write probes pass.
- Admin content/banner/gallery/ad write paths return a precise `D1_WRITE_READY_FAILED` error when the shared D1 layer is not ready.
- Legacy-safe Dashboard Ads write path no longer depends on a UNIQUE constraint for `ON CONFLICT`.
- Gallery upload now deletes the new R2 object if the D1 record cannot be saved.
- Client error display now surfaces exact backend `SERVER_ERROR`/D1 failure details instead of hiding the root cause.
- V-185 remains preserved and is not overwritten.

### V-185 — 2026-09-04
- Directly fixed the exact V-184 GitHub Actions compile failure in `NotificationActivity.java`: `self-reference in initializer` caused by `refreshPoll` referencing itself from its own field initializer.
- Preserved the 15-second notification refresh behavior using an anonymous `Runnable` with `this` inside `run()`.
- Added the permanent Direct Failure-Fix Rule: when an exact failure is visible, fix that exact failure directly in the next sequential version without unnecessary troubleshooting loops.
- V-184 remains preserved as the failed-build reference and is not overwritten.

### V-184 — 2026-09-04
- Added the permanent in-app notification requirement for MY SHOP updates, post likes and post comments.
- Added self-healing notification schema initialization and explicit notification database errors.
- Made like/comment notification creation best-effort so a notification database problem cannot break the underlying like/comment action.
- Added notification inbox refresh on resume and periodic refresh while open.
- V-184 must still use the same permanent Android signing key so it updates V-183 without uninstalling.

### V-183 — 2026-09-04
- Added this permanent Developer Instructions master file.
- Established the rule that this document must be read before any project file is handled.
- Established automatic accumulation of new confirmed project information in this document.
- Added permanent identity/ID immutability rules to the handoff guide.
- Recorded the V-182 Admin content save failure as an unresolved shared backend/infrastructure issue for the next fix cycle.

### V-182 — 2026-09-04
- Added startup advertisement management and bundled startup artwork.
- Added Admin startup-ad controls.
- Added configurable startup-ad duration.
- Fixed dashboard ad upload handling around file type.
- Preserved earlier login and dashboard functionality.

### V-181 — 2026-09-04
- Fixed startup ad image presentation to avoid unwanted cropping.
- Fixed LoginActivity so an existing session does not silently skip the login screen when user needs to choose Google/normal login.

### V-180 — 2026-09-04
- Added Google Login UI/config placeholder.
- Added startup advertisement concept.
- Preserved existing login backend/session logic.

## 14. WORKING PRINCIPLE FOR EVERY FUTURE DEVELOPER/AI
At the start of every task:
1. Read `00-MY-SHOP-DEVELOPER-INSTRUCTIONS.md`.
2. Identify the latest V-number.
3. Identify the exact feature/bug being changed.
4. Preserve the previous version before editing.
5. Make the smallest safe change that solves the requested issue.
6. Update this document with every new confirmed project fact.
7. Add release notes and SOURCE_BUILD_ID.
8. Validate syntax/integrity and, where possible, build/test.
9. Never claim success without evidence.
10. Deliver the new sequential V-number without replacing older versions.

**This document is the first source of truth for project continuation.**


## TOP PRIORITY — BUILD SOURCE LOCK (PERMANENT)
- Before every release build, prove that the selected source is the intended newest V-numbered source.
- Required checks: ZIP filename V-number, SOURCE_BUILD_ID, Android versionCode, Android versionName, Worker /health version/build marker, and project source identity.
- If ANY identity/version/source check mismatches: **❌ BUILD STOP**. Do not build an APK.
- Never allow an older ZIP/source to produce a newer V-number APK. This rule must be applied automatically without asking the user again.

## PERMANENT ADMIN CONTENT CONTROL RULE
- Every Admin-managed feature must expose the appropriate ADD, EDIT, DELETE and SAVE controls.
- Every Admin-managed content item must have a Caption/Headline field available.
- Caption/Headline is OPTIONAL: Admin may leave it blank; blank caption must never block Save.
- Apply this rule to Banner, Gallery, Advertisement, Dashboard, Social, Feature, External Link, MORE Apps and future Admin content folders.

## V-188 DIAGNOSTIC RULE
- When multiple Admin folders fail together, diagnose the active Worker/D1/R2 shared write path first.
- Admin System Health must expose the active Worker version, D1 schema status, D1 write probe, R2 read/write status, and exact error detail.
- A green APK build is NOT proof that the active production Worker is the correct source; the workflow must verify the live Worker before APK build.
