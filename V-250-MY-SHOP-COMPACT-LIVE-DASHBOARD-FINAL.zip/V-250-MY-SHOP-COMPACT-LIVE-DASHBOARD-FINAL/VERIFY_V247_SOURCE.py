from pathlib import Path
import re, sys, subprocess, xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent
checks=[]
def ck(name,ok): checks.append((name,bool(ok)))

gradle=(r/'app/build.gradle').read_text()
worker=(r/'backend/worker/src/index.js').read_text()
account=(r/'app/src/main/java/com/myshop/app/AccountActivity.java').read_text()
public=(r/'app/src/main/java/com/myshop/app/UserProfileActivity.java').read_text()
startup=(r/'app/src/main/java/com/myshop/app/StartupAdActivity.java').read_text()
adminads=(r/'app/src/main/java/com/myshop/app/DashboardAdsAdminActivity.java').read_text()
adminhub=(r/'app/src/main/java/com/myshop/app/AdminHubActivity.java').read_text()
backend=(r/'app/src/main/java/com/myshop/app/BackendClient.java').read_text()

ck('source id',(r/'SOURCE_BUILD_ID.txt').read_text().strip()=='MY SHOP V-247')
ck('source version name',(r/'SOURCE_VERSION_NAME.txt').read_text().strip()=='2.9.247')
ck('android version','versionCode 247' in gradle and "versionName '2.9.247'" in gradle)
ck('worker identity',worker.count("version:'2.9.247',build:'V-247'")>=2)
ck('follow schema/routes',all(x in worker for x in ['myshop_follows','/v1/follow/toggle','/v1/me/social-stats','/v1/friends/remove']))
ck('cover backend/routes',all(x in worker for x in ['cover_url','cover_object_key','/v1/me/cover/upload','/v1/me/cover/delete']))
ck('public profile stats',all(x in public for x in ['Friends','Followers','Following','toggleFollow','removeFriend','coverUrl']))
ck('own profile cover/stats',all(x in account for x in ['changeCoverButton','uploadCover','deleteCover','socialStats']))
ck('startup 1-4 + fail-open',all(x in startup for x in ['Math.max(1,Math.min(4','noConfigWatchdog','mediaWatchdog','openLogin()','mediaReady']))
ck('startup admin controls',all(x in adminads for x in ['ADD','EDIT','SAVE','DELETE','Startup Ad / Banner ON-OFF','Image / Video']))
ck('dedicated startup admin page','startup_ads' in adminhub and 'box_key","startup_ad' in adminhub)
ck('backend ad active upload','String.valueOf(active)' in backend and "form.get('active')" in worker)
ck('premium preserved',(r/'app/src/main/java/com/myshop/app/PremiumTierActivity.java').exists() and all(x in adminhub for x in ['ROYAL • VVIP • VIP MEMBERSHIP','ANIMATED BADGE • USER ID GRANT']))
ck('cover drawable/layout',(r/'app/src/main/res/drawable/profile_cover_placeholder.xml').exists() and 'profileCover' in (r/'app/src/main/res/layout/activity_account.xml').read_text())
ck('durable social migration',(r/'backend/worker/migrations/0003_v247_social_profile.sql').exists())
ck('no destructive auth sql',not re.search(r'DROP\s+TABLE\s+myshop_auth_users_v108|TRUNCATE\s+TABLE\s+myshop_auth_users_v108|DELETE\s+FROM\s+myshop_auth_users_v108',worker,re.I))

bad=[]
for p in [r/'app/src/main/AndroidManifest.xml',*list((r/'app/src/main/res').rglob('*.xml'))]:
    try: ET.parse(p)
    except Exception as e: bad.append((p,str(e)))
ck('android xml parse',not bad)

node=subprocess.run(['node','--check',str(r/'backend/worker/src/index.js')],capture_output=True,text=True)
ck('worker javascript syntax',node.returncode==0)

for name,ok in checks: print(('PASS' if ok else 'FAIL'),name)
if bad:
    for p,e in bad: print('XML_ERROR',p,e)
if node.returncode: print(node.stderr)
if not all(ok for _,ok in checks): sys.exit(1)
print('V-247 SOURCE CHECK PASSED')
