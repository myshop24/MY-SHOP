from pathlib import Path
import re, sys, xml.etree.ElementTree as ET, subprocess
R=Path(__file__).parent
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
app=(R/'app/build.gradle').read_text()
feature=(R/'app/src/main/java/com/myshop/app/FeatureActivity.java').read_text()
backend=(R/'backend/worker/src/index.js').read_text()
ck('source id', (R/'SOURCE_BUILD_ID.txt').read_text().strip()=='MY SHOP V-249')
ck('source version', (R/'SOURCE_VERSION_NAME.txt').read_text().strip()=='2.9.249')
ck('android version', 'versionCode 249' in app and "versionName '2.9.249'" in app)
ck('worker identity', "version:'2.9.249'" in backend and "build:'V-249'" in backend)
ck('method signature six args', 'private void addPlatformButton(LinearLayout root,String platform,String url,String caption,String iconUrl,String imageUrl)' in feature)
ck('success call six args', 'addPlatformButton(content,w,target,caption,iconUrl,imageUrl);' in feature)
ck('fallback call six args', 'addPlatformButton(content,w,"","","","");' in feature)
ck('old broken fallback absent', 'addPlatformButton(content,w,"","","");' not in feature)
# Preserve selected V-248 scope markers
main=(R/'app/src/main/java/com/myshop/app/MainActivity.java').read_text()
admin=(R/'app/src/main/java/com/myshop/app/AdminSectionActivity.java').read_text()
gallery=(R/'app/src/main/java/com/myshop/app/GalleryActivity.java').read_text()
account=(R/'app/src/main/java/com/myshop/app/AccountActivity.java').read_text()
layout=(R/'app/src/main/res/layout/activity_account.xml').read_text()
ck('live 40/60 preserved', 'weight(40,dp(48))' in main and 'weight(60,dp(48))' in main)
ck('external upload preserved', 'external_movie_icon' in admin and 'adminAssetUpload' in admin)
ck('social custom upload preserved', 'social_icon' in admin and 'socialPreview' in admin)
ck('in-app audio preserved', 'AudioPlayerActivity.class' in gallery)
ck('profile social preserved', 'timelineButton' in layout and 'mediaGalleryButton' in layout and 'privacyButton' in layout and 'ProfileSocialActivity.class' in account)
try:
    for f in (R/'app/src/main/res').rglob('*.xml'): ET.parse(f)
    ET.parse(R/'app/src/main/AndroidManifest.xml'); xmlok=True
except Exception as e:
    print('XML ERROR',e); xmlok=False
ck('android xml parse',xmlok)
try:
    r=subprocess.run(['node','--check',str(R/'backend/worker/src/index.js')],capture_output=True,text=True)
    if r.returncode: print(r.stderr)
    jsok=r.returncode==0
except Exception as e:
    print('NODE ERROR',e); jsok=False
ck('worker javascript syntax',jsok)
for n,v in checks: print(('PASS' if v else 'FAIL'),n)
if not all(v for _,v in checks): sys.exit(1)
