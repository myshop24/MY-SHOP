# MY SHOP V-250 — Compact Live Streaming Dashboard

- Replaced the large purple LIVE STREAMING banner-style block with a compact white functional dashboard section.
- LIVE STREAMING title is centered above the controls.
- Go Live width is 35%; Join Live width is 65%.
- Both buttons have smooth pulse animation; Join Live has the stronger visual emphasis.
- Dashboard live row remains 4 dynamic profile slots with See All.
- Backend now returns active live profiles first; if fewer than 4 are live, remaining slots are filled by newest users.
- If nobody is live, newest users are shown first instead of dummy/static live cards.
- Live profile cards show LIVE status; non-live fallback profiles show NEW status and open the user profile.
- Existing Live presence backend and other V-249 features are preserved.
