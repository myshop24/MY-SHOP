# MY SHOP V-249 Build Notes

## Purpose
Compile-only repair of V-248 after GitHub Actions exposed a Java method-arity error.

## Exact error repaired
`FeatureActivity.java` fallback call to `addPlatformButton` supplied 5 parameters, but the method requires 6: `LinearLayout, String, String, String, String, String`.

## Fix
Changed the fallback call to pass an empty `imageUrl` as the sixth argument.

## Version
- Android versionCode: 249
- Android versionName: 2.9.249
- Source build ID: MY SHOP V-249
- Worker identity: V-249 / 2.9.249

All V-248 requested feature work is preserved.
