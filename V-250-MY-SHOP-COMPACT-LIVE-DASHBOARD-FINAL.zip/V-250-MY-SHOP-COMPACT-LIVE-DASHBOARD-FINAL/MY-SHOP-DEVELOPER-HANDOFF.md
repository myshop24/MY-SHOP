# MY SHOP Developer Handoff — V-250

## Base / checkpoint
- Current source: V-250, created from preserved V-249 compile-fix base.
- V-249 remains the rollback checkpoint. Next version is V-251.

## Completed in V-250
1. LIVE STREAMING is now a compact dashboard button section instead of a large advertising-banner style block.
2. Centered LIVE STREAMING heading.
3. Go Live = 35% width, Join Live = 65% width.
4. Smooth animation retained, with Join Live receiving stronger emphasis.
5. Four dashboard profile slots use real backend data.
6. Active live profiles always have priority.
7. When fewer than four users are live, empty positions are filled from newest registered users.
8. When nobody is live, newest users are shown instead of dummy/static live cards.
9. See All remains connected to the live section.
10. Existing V-249 compile fix and V-248 social/profile/media work are preserved.

## Backend behavior
- GET /v1/live/profiles now supports up to 100 results.
- Response profiles include `live: true/false` and live-first/new-user fallback ordering.
- Stale live presence is still automatically expired.

## Validation / acceptance
- Run VERIFY_V249_SOURCE.py plus Java/Worker syntax/build checks.
- Final Android release compile/sign acceptance remains the GitHub Actions release workflow.

## Exact stop point
- V-250 live-dashboard UI/data behavior implemented. Next checkpoint is GitHub Actions release build and device visual verification.
