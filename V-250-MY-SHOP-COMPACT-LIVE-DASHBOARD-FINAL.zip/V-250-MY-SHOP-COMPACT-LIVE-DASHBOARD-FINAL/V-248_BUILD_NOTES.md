# MY SHOP V-248 Build Notes

- Base: V-247 full project (preserved).
- Android: versionCode 248 / versionName 2.9.248.
- Worker target identity: V-248 / 2.9.248.
- Implements the current 9-item scope: Live Streaming 40/60 + real live profiles, custom image uploads for External Movie and Social/More Apps, in-app audio player, icon priority, premium social profile, backend Friends/Followers/Following sync, friend/follow flow hardening, Timeline/Media/Privacy.
- D1 changes are additive only. Permanent User IDs and signing rules unchanged.
- Live deployment still requires GitHub workflow/preflight; source validation/build results are recorded in handoff.
