# MY SHOP V-247 Build Notes

- Full-project source version: V-247
- Android: versionCode 247 / versionName 2.9.247
- Worker health identity: version 2.9.247 / build V-247
- SOURCE_BUILD_ID: `MY SHOP V-247`
- Source base: preserved V-246 full-project ZIP
- Master workflow rule remains unchanged: repository-root `.github/workflows/my-shop-apk.yml` is authoritative and must select the highest valid V-number ZIP.
- No signing key changes.
- D1/R2 changes are additive; permanent user IDs are unchanged.
- GitHub Cloudflare preflight/write-suite and APK build remain required before release acceptance.
