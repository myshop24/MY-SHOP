package com.myshop.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * V-247 Admin-controlled startup advertisement.
 * Image/video + 1-4 sec duration + optional click-through + hard fail-open startup safety.
 * A last-known-good ad is cached so slow networks do not leave the app blocked on launch.
 */
public class StartupAdActivity extends Activity {
    private static final String PREF="startup_ad_cache_v247";
    private final Handler main=new Handler(Looper.getMainLooper());
    private CountDownTimer timer;
    private boolean opened=false,timerStarted=false,cacheUsed=false;
    private Button skip;
    private ImageView imageAd;
    private VideoView videoAd;
    private FrameLayout mediaHost;
    private int seconds=3;
    private Runnable noConfigWatchdog,mediaWatchdog;

    @Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);

        mediaHost=new FrameLayout(this);
        FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER);
        mp.setMargins(dp(8),dp(58),dp(8),dp(58)); root.addView(mediaHost,mp);

        imageAd=new ImageView(this);
        imageAd.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        imageAd.setAdjustViewBounds(true);
        imageAd.setVisibility(View.GONE);
        mediaHost.addView(imageAd,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));

        videoAd=new VideoView(this); videoAd.setVisibility(View.GONE);
        mediaHost.addView(videoAd,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));

        TextView label=new TextView(this); label.setText("ADVERTISEMENT"); label.setTextColor(Color.WHITE); label.setTextSize(11); label.setGravity(Gravity.CENTER); label.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(128),dp(34),Gravity.TOP|Gravity.START); lp.setMargins(dp(12),dp(12),0,0); root.addView(label,lp);

        skip=new Button(this); skip.setAllCaps(false); skip.setText("Skip"); skip.setTextColor(Color.WHITE); skip.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(110),dp(48),Gravity.TOP|Gravity.END); sp.setMargins(0,dp(10),dp(10),0); root.addView(skip,sp); skip.setOnClickListener(v->openLogin());
        skip.setOnTouchListener((v,e)->{if(e.getAction()==android.view.MotionEvent.ACTION_DOWN)v.animate().scaleX(.97f).scaleY(.97f).alpha(.88f).setDuration(60).start();else if(e.getAction()==android.view.MotionEvent.ACTION_UP||e.getAction()==android.view.MotionEvent.ACTION_CANCEL)v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(100).start();return false;});

        TextView hint=new TextView(this); hint.setText("MY SHOP • Advertisement"); hint.setTextColor(Color.WHITE); hint.setTextSize(12); hint.setGravity(Gravity.CENTER); hint.setBackgroundColor(0x66000000);
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(40),Gravity.BOTTOM); hp.setMargins(dp(12),0,dp(12),dp(12)); root.addView(hint,hp);
        setContentView(root);

        cacheUsed=showCachedAdIfAvailable();
        noConfigWatchdog=()->{ if(!timerStarted) openLogin(); };
        if(!cacheUsed) main.postDelayed(noConfigWatchdog,1600L);
        loadRemoteAd();
    }

    private boolean showCachedAdIfAvailable(){
        try{
            SharedPreferences p=getSharedPreferences(PREF,MODE_PRIVATE);
            if(!p.getBoolean("active",false))return false;
            String media=p.getString("media",""); String type=p.getString("type","image"); String target=p.getString("target",""); int duration=Math.max(1,Math.min(4,p.getInt("duration",3)));
            if(media==null||media.trim().isEmpty())return false;
            renderMedia(media,type,target,duration); return true;
        }catch(Exception ignored){return false;}
    }

    private void saveCache(JSONObject found){
        try{
            if(found==null){getSharedPreferences(PREF,MODE_PRIVATE).edit().clear().apply();return;}
            getSharedPreferences(PREF,MODE_PRIVATE).edit()
                    .putBoolean("active",found.optInt("active",1)==1)
                    .putString("media",found.optString("image_url","").trim())
                    .putString("type",found.optString("media_type","image").trim().toLowerCase())
                    .putString("target",found.optString("target_url","").trim())
                    .putInt("duration",Math.max(1,Math.min(4,found.optInt("duration_sec",3))))
                    .putString("updated",found.optString("updated_at","").trim()).apply();
        }catch(Exception ignored){}
    }

    private void loadRemoteAd(){
        if(!BackendClient.configured()){if(!cacheUsed)openLogin();return;}
        BackendClient.dashboard(null,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                runOnUiThread(()->{
                    try{
                        JSONArray ads=d.optJSONArray("dashboardAds"); JSONObject found=null;
                        if(ads!=null) for(int i=0;i<ads.length();i++){
                            JSONObject x=ads.optJSONObject(i);
                            if(x!=null&&"startup_ad".equalsIgnoreCase(x.optString("box_key",""))&&x.optInt("active",1)==1){found=x;break;}
                        }
                        saveCache(found);
                        if(opened)return;
                        if(found==null){ openLogin(); return; }
                        if(!cacheUsed){
                            main.removeCallbacks(noConfigWatchdog);
                            seconds=Math.max(1,Math.min(4,found.optInt("duration_sec",3)));
                            String media=found.optString("image_url","").trim(); String updated=found.optString("updated_at","").trim();
                            if(!media.isEmpty()&&!updated.isEmpty()&&!media.contains("?"))media=media+"?v="+Uri.encode(updated);
                            String type=found.optString("media_type","").trim().toLowerCase(); if(type.isEmpty())type=isVideoUrl(media)?"video":"image";
                            String target=found.optString("target_url","").trim();
                            if(media.isEmpty()){openLogin();return;}
                            renderMedia(media,type,target,seconds);
                        }
                    }catch(Exception ignored){if(!cacheUsed)openLogin();}
                });
            }
            public void onError(String m){runOnUiThread(()->{if(!cacheUsed)openLogin();});}
        });
    }

    private void renderMedia(String media,String type,String target,int duration){
        mediaHost.setOnClickListener(null);
        if(target!=null&&!target.trim().isEmpty())mediaHost.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception ignored){}});
        timerStarted=false;
        if(mediaWatchdog!=null)main.removeCallbacks(mediaWatchdog);
        mediaWatchdog=()->{if(!opened&&!timerStarted)openLogin();};
        main.postDelayed(mediaWatchdog,1200L);
        if("video".equalsIgnoreCase(type)||isVideoUrl(media))showVideo(media,duration); else loadImage(media,duration);
    }

    private void mediaReady(int duration){
        if(opened||timerStarted)return;
        if(mediaWatchdog!=null)main.removeCallbacks(mediaWatchdog);
        startTimer(duration);
    }

    private boolean isVideoUrl(String u){String x=u==null?"":u.toLowerCase();return x.contains(".mp4")||x.contains(".webm")||x.contains(".m3u8")||x.contains("video");}

    private void showVideo(String u,int duration){
        try{
            imageAd.setVisibility(View.GONE); videoAd.setVisibility(View.VISIBLE);
            videoAd.setVideoURI(Uri.parse(u));
            videoAd.setOnPreparedListener(mp->{if(opened)return;mp.setLooping(true);videoAd.start();mediaReady(duration);});
            videoAd.setOnErrorListener((mp,what,extra)->{videoAd.setVisibility(View.GONE);if(!opened&&!timerStarted)openLogin();return true;});
        }catch(Exception e){videoAd.setVisibility(View.GONE);if(!opened&&!timerStarted)openLogin();}
    }

    private void loadImage(String u,int duration){
        imageAd.setVisibility(View.VISIBLE); videoAd.setVisibility(View.GONE);
        new Thread(()->{HttpURLConnection c=null;boolean ok=false;try{c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(700);c.setReadTimeout(1000);c.setUseCaches(true);try(InputStream in=c.getInputStream()){android.graphics.Bitmap b=android.graphics.BitmapFactory.decodeStream(in);if(b!=null){ok=true;runOnUiThread(()->{if(opened)return;imageAd.setImageBitmap(b);imageAd.setAlpha(0f);imageAd.animate().alpha(1f).setDuration(120).start();mediaReady(duration);});}}}catch(Exception ignored){}finally{if(c!=null)c.disconnect();if(!ok)runOnUiThread(()->{if(!opened&&!timerStarted)openLogin();});}}).start();
    }

    private void startTimer(int sec){
        seconds=Math.max(1,Math.min(4,sec)); timerStarted=true; main.removeCallbacks(noConfigWatchdog); if(mediaWatchdog!=null)main.removeCallbacks(mediaWatchdog);
        if(timer!=null)timer.cancel();
        timer=new CountDownTimer(seconds*1000L,250){public void onTick(long ms){int left=(int)Math.ceil(ms/1000.0);skip.setText("Skip "+Math.max(1,left));}public void onFinish(){openLogin();}}.start();
    }

    private void openLogin(){if(opened)return;opened=true;main.removeCallbacks(noConfigWatchdog);if(mediaWatchdog!=null)main.removeCallbacks(mediaWatchdog);if(timer!=null)timer.cancel();try{videoAd.stopPlayback();}catch(Exception ignored){}startActivity(new Intent(this,LoginActivity.class));finish();}
    @Override protected void onDestroy(){main.removeCallbacksAndMessages(null);if(timer!=null)timer.cancel();try{videoAd.stopPlayback();}catch(Exception ignored){}super.onDestroy();}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
