from pathlib import Path
import re, sys, xml.etree.ElementTree as ET, subprocess
R=Path(__file__).parent
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
app=(R/'app/build.gradle').read_text()
main=(R/'app/src/main/java/com/myshop/app/MainActivity.java').read_text()
admin=(R/'app/src/main/java/com/myshop/app/AdminSectionActivity.java').read_text()
feature=(R/'app/src/main/java/com/myshop/app/FeatureActivity.java').read_text()
gallery=(R/'app/src/main/java/com/myshop/app/GalleryActivity.java').read_text()
backend=(R/'backend/worker/src/index.js').read_text()
account=(R/'app/src/main/java/com/myshop/app/AccountActivity.java').read_text()
layout=(R/'app/src/main/res/layout/activity_account.xml').read_text()
ck('source id', (R/'SOURCE_BUILD_ID.txt').read_text().strip()=='MY SHOP V-248')
ck('source version', (R/'SOURCE_VERSION_NAME.txt').read_text().strip()=='2.9.248')
ck('android version', 'versionCode 248' in app and "versionName '2.9.248'" in app)
ck('worker identity', "version:'2.9.248'" in backend and "build:'V-248'" in backend)
ck('live 40/60', 'weight(40,dp(48))' in main and 'weight(60,dp(48))' in main)
ck('live backend profiles', '/v1/live/profiles' in backend and 'myshop_live_presence' in backend and 'liveProfiles' in main)
ck('join pulse', 'joinPulse' in main and 'setDuration(1150)' in main)
ck('external upload preview', 'external_movie_icon' in admin and 'extPreview' in admin and 'adminAssetUpload' in admin)
ck('social custom upload', 'social_icon' in admin and 'socialImage' in admin and 'socialPreview' in admin)
ck('social icon priority', 'if(imageUrl!=null&&!imageUrl.trim().isEmpty())' in feature and 'else if(iconUrl!=null&&!iconUrl.trim().isEmpty())' in feature and 'platformIconRes(platform)' in feature)
ck('in-app audio', 'AudioPlayerActivity.class' in gallery and (R/'app/src/main/java/com/myshop/app/AudioPlayerActivity.java').exists())
ck('profile social', 'timelineButton' in layout and 'mediaGalleryButton' in layout and 'privacyButton' in layout and 'ProfileSocialActivity.class' in account)
ck('profile privacy backend', '/v1/me/privacy' in backend and 'myshop_profile_privacy' in backend and '/v1/users/posts' in backend)
ck('friend stats', 'socialStatsFor(env,user.user_id)' in backend and 'peerStats:await socialStatsFor(env,sender)' in backend)
ck('social schema fields', "icon_url TEXT NOT NULL DEFAULT ''" in backend and "image_url TEXT NOT NULL DEFAULT ''" in backend)
ck('migration', (R/'backend/worker/migrations/0004_v248_social_live_privacy.sql').exists())
ck('handoff', (R/'MY-SHOP-DEVELOPER-HANDOFF.md').exists())
try:
    for f in (R/'app/src/main/res').rglob('*.xml'): ET.parse(f)
    ET.parse(R/'app/src/main/AndroidManifest.xml'); xmlok=True
except Exception as e: print('XML ERROR',e); xmlok=False
ck('android xml parse',xmlok)
try:
    r=subprocess.run(['node','--check',str(R/'backend/worker/src/index.js')],capture_output=True,text=True)
    jsok=r.returncode==0
except Exception: jsok=False
ck('worker javascript syntax',jsok)
for n,v in checks: print(('PASS' if v else 'FAIL'),n)
if not all(v for _,v in checks): sys.exit(1)
