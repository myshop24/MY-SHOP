# MY SHOP V-23 — GitHub upload

1. Extract this ZIP.
2. Upload the **contents** of the extracted folder to the root of the `MY-SHOP` GitHub repository.
3. Keep only this workflow: `.github/workflows/android-apk.yml`.
4. Do not keep older V-19/V-20/V-22 workflow files in `.github/workflows`, otherwise the wrong build can run.
5. Run **MY SHOP V-23 APK Build** from GitHub Actions.
6. Download the single artifact APK: `V-23-MY-SHOP.apk`.

The workflow will fail rather than upload an APK if package/version verification fails.
