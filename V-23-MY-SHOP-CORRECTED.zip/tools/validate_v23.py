from pathlib import Path
import json, re, sys
ROOT=Path(__file__).resolve().parents[1]
errors=[]
required=[ROOT/'app/build.gradle',ROOT/'app/src/main/AndroidManifest.xml',ROOT/'app/src/main/assets/feature_config.json',ROOT/'app/src/main/assets/admin_identifiers.json',ROOT/'.github/workflows/android-apk.yml']
for p in required:
    if not p.exists(): errors.append(f'Missing: {p}')
for p in ROOT.rglob('*.json'):
    if '.git' in p.parts or 'build' in p.parts: continue
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'Invalid JSON {p}: {e}')
bs=(ROOT/'app/build.gradle').read_text()
if 'versionCode 23' not in bs or "versionName '2.12.0'" not in bs: errors.append('Version is not 23/2.12.0')
manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text()
if 'android.intent.action.MAIN' not in manifest or '.LoginActivity' not in manifest: errors.append('LoginActivity is not the launcher')
java='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in ROOT.rglob('*.java'))
for bad in ['admin_password','adminPassword','password = "','password="']:
    if bad in java: errors.append(f'Potential password leak in Java: {bad}')
for required_id in ['loginId','loginPassword','createAccountButton','loginButton','fullName','email','mobile','password','confirmPassword','createButton','dashboardReference']:
    if required_id not in '\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in (ROOT/'app/src/main').rglob('*.xml')) and required_id not in java:
        errors.append(f'Missing functional control: {required_id}')
if errors:
    print('V-23 validation FAILED'); print('\n'.join(errors)); sys.exit(1)
print('V-23 validation OK')
