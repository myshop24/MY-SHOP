# MY SHOP V-23 — Corrected Build Package

## Corrections after V-20/V-23 installation test
- Removed `applicationIdSuffix '.debug'`; V-23 now uses the same package ID `com.myshop.app` as V-20.
- Changed version code to `23` and version name to `2.12.0`.
- Corrected the embedded app version from `2.2.0` to `2.12.0`.
- Removed competing/stale GitHub Actions workflows; only the V-23 workflow remains, preventing the wrong workflow from producing the APK.
- Build verification now checks the final APK itself with `aapt2` for package name, versionCode and versionName before upload.
- The GitHub artifact contains exactly one APK file: `V-23-MY-SHOP.apk`.

## Important signing note
V-20 was a debug APK. Android updates require the new APK to be signed with the same signing key as the installed APK. The source package/signing identity can be checked, but the private signing key from an already-installed V-20 APK cannot be reconstructed from source. Therefore this correction guarantees the package/version side; a direct update from an older APK is only guaranteed when the same signing key is used.
