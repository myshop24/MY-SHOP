# MY SHOP V-23 — Corrected Master Build

This is the corrected GitHub-ready MY SHOP V-23 source.

## Build identity
- Application ID: `com.myshop.app`
- Version code: `23`
- Version name: `2.12.0`
- APK artifact: `V-23-MY-SHOP.apk`

## Important
Upload the **contents of this ZIP to the root of the `MY-SHOP` GitHub repository**. Do not upload an outer ZIP as the repository source.

There is exactly one GitHub Actions workflow: `.github/workflows/android-apk.yml`.

The workflow verifies package name and version from the actual generated APK before uploading it. The artifact contains exactly one APK.

## Update/signing
Android requires an update APK to use the same signing key as the installed APK. This source uses the same package ID as V-20, but the private key used to sign an already-installed V-20 APK is not present in this source. Therefore a direct update from an old differently-signed APK cannot be guaranteed until the same signing key is configured.
