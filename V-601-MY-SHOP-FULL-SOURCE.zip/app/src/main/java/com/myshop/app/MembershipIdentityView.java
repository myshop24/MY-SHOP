package com.myshop.app;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.*;
import java.io.InputStream;
import java.util.concurrent.*;

/** One video-derived identity renderer shared by catalog, profile and Live. */
public final class MembershipIdentityView extends FrameLayout {
    private final ImageView photo;
    private final String tier,avatarSource;
    private String frameSource="";
    private final FrameAnimation reference;private ImageView customFrame;private boolean custom;
    private float cx=.50f, cy=.48f, radius=.265f;
    private long expiresAt;private Runnable expiryAction;
    private final Runnable expiryTick=new Runnable(){public void run(){
        if(expiresAt<=0)return;long remaining=expiresAt-System.currentTimeMillis();
        if(remaining<=0){expiresAt=0;if(expiryAction!=null)expiryAction.run();}
        else postDelayed(this,Math.min(remaining,86400000L));
    }};
    public MembershipIdentityView(Context context,String code,String avatarUrl){
        super(context);avatarSource=avatarUrl==null?"":avatarUrl;tier="TOP1".equals(code)?"TOP1":MembershipUi.tier(code);
        setClipChildren(false);setClipToPadding(false);
        switch(tier){case "ROYAL":cy=.49f;radius=.275f;break;case "VVIP":radius=.245f;break;case "VIP":cy=.535f;radius=.205f;break;case "TOP1":cy=.47f;radius=.23f;break;}
        photo=new ImageView(context);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        photo.setImageResource(R.drawable.myshop_profile_avatar);
        GradientDrawable circle=new GradientDrawable();circle.setShape(GradientDrawable.OVAL);circle.setColor(0xFF15253E);
        photo.setBackground(circle);photo.setClipToOutline(true);addView(photo,new LayoutParams(1,1));
        if(avatarUrl!=null&&!avatarUrl.trim().isEmpty())CachedImages.load(photo,avatarUrl);
        reference=new FrameAnimation(context,tier);addView(reference,new LayoutParams(-1,-1));
        setContentDescription(tier+" animated frame with profile photo");
    }
    public boolean matches(String code,String url,String asset){return tier.equals(MembershipUi.tier(code))&&avatarSource.equals(url==null?"":url)&&frameSource.equals(asset==null?"":asset.trim());}
    public void setExpiry(String value,Runnable action){
        removeCallbacks(expiryTick);expiresAt=0;expiryAction=action;
        try{String date=value==null?"":value.trim().replace('T',' ');if(date.length()>=19){
            java.text.SimpleDateFormat format=new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",java.util.Locale.US);
            format.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));expiresAt=format.parse(date.substring(0,19)).getTime();
        }}catch(Exception ignored){}
        if(expiresAt>0)post(expiryTick);
    }
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();removeCallbacks(expiryTick);if(expiresAt>0)post(expiryTick);}
    @Override protected void onDetachedFromWindow(){removeCallbacks(expiryTick);super.onDetachedFromWindow();}
    public void setPortraitBitmap(Bitmap bitmap){if(bitmap!=null)photo.setImageBitmap(bitmap);}
    public void setDemo(){setContentDescription(tier+" membership preview with your photo");}
    /** Preserve Admin custom PNG/GIF/WebP overrides; blank URL selects the owner video template. */
    public void setFrameAsset(String url){
        frameSource=url==null?"":url.trim();
        if("TOP1".equals(tier)||url==null||url.trim().isEmpty())return;
        String lower=url.toLowerCase(java.util.Locale.US).split("\\?",2)[0];
        if(lower.endsWith(".mp4")||lower.endsWith(".webm")||lower.endsWith(".3gp"))return;
        if(customFrame==null){customFrame=new ImageView(getContext()){
            @Override protected void onDraw(Canvas canvas){
                if(!custom&&getDrawable()!=null){custom=true;reference.setVisibility(GONE);layoutPortrait(MembershipIdentityView.this.getWidth(),MembershipIdentityView.this.getHeight());}
                super.onDraw(canvas);
            }
        };customFrame.setScaleType(ImageView.ScaleType.FIT_CENTER);addView(customFrame,new LayoutParams(-1,-1));}
        AnimatedAssetLoader.load(customFrame,url.trim(),true);layoutPortrait(getWidth(),getHeight());
    }
    @Override protected void onSizeChanged(int w,int h,int ow,int oh){
        super.onSizeChanged(w,h,ow,oh);layoutPortrait(w,h);
    }
    private void layoutPortrait(int w,int h){
        if(custom){float x=168,y=139,r=88;switch(tier){case "KING":x=166;y=139;r=83;break;case "QUEEN":x=165;y=141;r=84;break;case "ROYAL":x=168;y=136;r=85;break;case "VVIP":y=141;break;}
            float scale=Math.min(w/320f,h/275f);LayoutParams p=new LayoutParams(Math.round(r*2*scale)+2,Math.round(r*2*scale)+2);
            p.leftMargin=Math.round((w-320*scale)/2+(x-r)*scale)-1;p.topMargin=Math.round((h-275*scale)/2+(y-r)*scale)-1;photo.setLayoutParams(p);return;}
        float s=Math.min(w,h),left=(w-s)/2,top=(h-s)/2;
        LayoutParams p=new LayoutParams(Math.round(radius*2*s)+2,Math.round(radius*2*s)+2);
        p.leftMargin=Math.round(left+(cx-radius)*s)-1;p.topMargin=Math.round(top+(cy-radius)*s)-1;photo.setLayoutParams(p);
    }
    private static final class FrameAnimation extends View {
        private static final ConcurrentHashMap<String,Movie> CACHE=new ConcurrentHashMap<>();
        private static final ExecutorService IO=Executors.newSingleThreadExecutor();
        private Movie movie;private final String key;private final boolean reduce;
        FrameAnimation(Context c,String tier){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);key=tier.toLowerCase(java.util.Locale.US);reduce=PerformanceMode.reduceAnimations(c);
            movie=CACHE.get(key);if(movie==null)IO.execute(()->{Movie ready=CACHE.get(key);if(ready!=null){post(()->{movie=ready;invalidate();});return;}try(InputStream in=c.getApplicationContext().getAssets().open("membership_v600/"+key+".gif")){
                Movie decoded=Movie.decodeStream(in);if(decoded!=null){CACHE.put(key,decoded);post(()->{movie=decoded;invalidate();});}
            }catch(Exception|OutOfMemoryError ignored){}});
        }
        @Override protected void onDraw(Canvas c){super.onDraw(c);if(movie==null)return;
            float scale=Math.min(getWidth()/(float)movie.width(),getHeight()/(float)movie.height());int save=c.save();
            c.translate((getWidth()-movie.width()*scale)/2,(getHeight()-movie.height()*scale)/2);c.scale(scale,scale);
            boolean animate=!reduce&&isShown()&&(android.os.Build.VERSION.SDK_INT<26||android.animation.ValueAnimator.areAnimatorsEnabled());
            movie.setTime(animate?(int)(android.os.SystemClock.uptimeMillis()%Math.max(1,movie.duration())):0);movie.draw(c,0,0);c.restoreToCount(save);
            if(animate)postInvalidateDelayed(83);
        }
        @Override public void onVisibilityAggregated(boolean visible){super.onVisibilityAggregated(visible);if(visible)invalidate();}
        @Override protected void onAttachedToWindow(){super.onAttachedToWindow();invalidate();}
    }
}
