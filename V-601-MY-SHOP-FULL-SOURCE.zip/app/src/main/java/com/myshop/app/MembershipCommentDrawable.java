package com.myshop.app;

import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;

/** Shared ornamental comment border; animation stays on the border, never the text/photo. */
final class MembershipCommentDrawable extends Drawable {
    private final GradientDrawable base;private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;private final int accent;private final boolean animate;
    private final Runnable tick=this::invalidateSelf;
    MembershipCommentDrawable(GradientDrawable base,float density,int accent,boolean animate){
        this.base=base;this.density=density;this.accent=accent;this.animate=animate;
    }
    @Override protected void onBoundsChange(Rect bounds){base.setBounds(bounds);}
    @Override public void draw(Canvas canvas){
        base.draw(canvas);Rect b=getBounds();float inset=4*density, radius=5*density;
        paint.setColor(accent);paint.setAlpha(105);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(.65f*density);
        canvas.drawRoundRect(b.left+inset,b.top+inset,b.right-inset,b.bottom-inset,radius,radius,paint);
        paint.setStyle(Paint.Style.FILL);
        for(int side=0;side<2;side++){
            float x=side==0?b.left+6*density:b.right-6*density,y=b.top+6*density;
            paint.setAlpha(225);gem(canvas,x,y,2.3f*density);
            paint.setAlpha(160);gem(canvas,x+(side==0?7:-7)*density,y,1.2f*density);
        }
        if(animate&&(android.os.Build.VERSION.SDK_INT<26||android.animation.ValueAnimator.areAnimatorsEnabled())){
            float phase=(android.os.SystemClock.uptimeMillis()%4200)/4200f;
            float x=b.left+inset+(b.width()-2*inset)*phase;paint.setColor(Color.WHITE);paint.setAlpha(185);
            gem(canvas,x,b.top+2*density,1.7f*density);
            unscheduleSelf(tick);scheduleSelf(tick,android.os.SystemClock.uptimeMillis()+120);
        }
    }
    private void gem(Canvas c,float x,float y,float r){Path p=new Path();p.moveTo(x,y-r*2);p.lineTo(x+r*.5f,y-r*.5f);p.lineTo(x+r*2,y);p.lineTo(x+r*.5f,y+r*.5f);p.lineTo(x,y+r*2);p.lineTo(x-r*.5f,y+r*.5f);p.lineTo(x-r*2,y);p.lineTo(x-r*.5f,y-r*.5f);p.close();c.drawPath(p,paint);}
    @Override public void setAlpha(int alpha){base.setAlpha(alpha);invalidateSelf();}
    @Override public void setColorFilter(ColorFilter filter){base.setColorFilter(filter);paint.setColorFilter(filter);invalidateSelf();}
    @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
