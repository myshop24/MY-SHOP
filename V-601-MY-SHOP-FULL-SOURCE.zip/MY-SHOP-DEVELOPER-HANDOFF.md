# Current checkpoint: MY SHOP V-601 / 2.9.601

Read handoffs/MY-SHOP-V601-HANDOFF.md and BUILD-ASSETS-BN.md first. Complete compact
source is below25,000,000 bytes; generated runtime assets rebuild from included inputs,
matching V600 byte-for-byte. Five unused old frames removed; still-referenced legacy
assets retained. Local/fresh-extract regressions passed. Android compile/signing and
real-device Live/UI remain blocked/pending. No V601 APK/deployment. Next delivery V602.
Older sections below are historical.

# Current checkpoint: MY SHOP V-600 / 2.9.600

Read handoffs/MY-SHOP-V600-HANDOFF.md and V600-APPROVED-WORK-BN.md first.
Membership video frames/comments, General active-member filtering and lifetime Host
Top1 order are implemented in source. Local source/backend regressions passed.
Android compile/signed APK are blocked locally; real-device Live/UI/notification QA
is pending. Matching V600 Worker is required; nothing was deployed. No V600 APK is
included. Next newly created delivery is V601. Older sections below are historical.

# Current checkpoint: MY SHOP V-599 / 2.9.599

Read handoffs/MY-SHOP-V599-HANDOFF.md first. Agent route and operational Live permissions corrected. Local tests passed; Android build/device QA pending. Matching Worker update required; not deployed here.

# Current checkpoint: MY SHOP V-598 / 2.9.598

Packaging/build-entry correction only. Application behavior preserved from V597. Read handoffs/MY-SHOP-V598-HANDOFF.md first.

# Current checkpoint: MY SHOP V-597 / 2.9.597

Read handoffs/MY-SHOP-V597-HANDOFF.md first. Local source checks passed; signed APK/Android type/device QA remain pending. Latest owner instructions take priority.

# বর্তমান checkpoint: MY SHOP V-596 / 2.9.596

প্রথমে handoffs/MY-SHOP-V596-HANDOFF.md পড়ুন। V-596-এর ৯টি scoped source পরিবর্তন ও local regression যাচাই হয়েছে। APK/Android type/device/production পরীক্ষা এখনো হয়নি। Older checkpoint নিচে ইতিহাস হিসেবে আছে; নতুন নির্দেশনা অগ্রাধিকার পাবে।

# MY SHOP V-595 — owner-authorized tasks 1–9

Baseline: uploaded V-594 full source, 24,999,761 bytes; SHA-256 411b821692001b6ab32c6f1c545c130400bc32fd9b5303dad61c6bb9e979667c.
Identity: SOURCE_BUILD_ID MY SHOP V-595; versionCode 595; versionName 2.9.595. Worker health and Android identity match. This is a full source continuation, not a patch. Prior V594 handoff retained in handoffs/MY-SHOP-V594-HANDOFF.md.

## 1. D1 reads
Normal safety snapshot 1s → 15s; degraded fallback bounded to 5s. Realtime dirty signals still refresh immediately, comments/gifts remain on original Durable Object path. Healthy Gift event recovery 1.2s → 30s; degraded recovery 5s. Participant state sends only on change or 15s safety retry, no concurrent state sends; backend skips unchanged seat writes. Avatar completion updates its bound ImageViews without issuing another full room API request. Live list refresh 1s → 15s with in-flight deduplication. Unused Live directory discovery/people/ranking loads removed from lifecycle; their independently-used handlers remain. Viewer-count maintenance and seven public aggregates coalesce per DB + host + session for at most 5s; Gift/DIRTY invalidates in the local Worker isolate. Private state/auth/wallet/permissions are never shared through this cache. Redundant meta query reused; global request expiry write removed from room snapshots while room/session expiry remains.
This materially reduces polling requests, but does NOT prove a production rows-read reduction or capacity for 50 rooms/1000 users. Cache is isolate-local and bounded. Remaining common room data is still queried per snapshot; profile subqueries and historical aggregates need production profiling and future summary-table/index work. Measure D1 meta rows_read/rows_written and endpoint latency before/after; full production load test remains required.

## 2–4. Scoped cleanup
Remove only the nominated More popup links; keep Page, Website, My Level, Top Up, Earn Rewards, Share App and authorized Admin in a 3-column layout. Main Home shortcut row and General under headline remain. General hamburger retains Agent/My Links/What's New/Safety & Privacy; Invite now Share with share action. Shared backend records, other routes and existing items are retained.

## 5. Live directory
Live Menu contains only Agent/Support/Share App. Top row has Membership/Games, Earn removed. Tabs LIVE NOW/Following/New; Explore removed. Shared Home/Live header dimensions and bottom icon dimensions/color/spacing agree; Go Live label retains directory action. Both existing ad and Upcoming Live banners remain. Live Room seat/audio/comment UI was not redesigned.

## 6. Premium
Tabs All/Membership/Ride Entry/Wallpaper/My Items only. Avatar Frame/Comment Box/Ring Badge/Theme Effect/Combo Special tabs removed; owned items, membership bundle preview/equipping and independent functional entry routes remain. The owner's video showed category labels, not proof of every category's runtime implementation, so shared ownership/entitlements were not deleted.

## 7. Diamond
Gold Coin display labels rebranded Diamond in Android and backend user-facing messages/default headings; Live gem uses cyan/blue/purple faceted drawable. Internal GOLD API/DB/product keys, prices, balances, signing/package identity and ledger remain unchanged. No 1:1 ledger rewrite is required. Admin/custom remote titles are user-managed and can still contain legacy text; review actual remote configuration after deployment. Ordinary Coin remains separate.

## 8. Commission Management
Owner-only Admin catalog route and real persisted /v1/admin/commission-management API. Centered Coin/Diamond global controls; enable/disable and rate. Four lower entries per row: Gift, Transfer, Withdraw, Ledger. Currency-specific per-feature rates; global timed Free up to 720h; precedence Free > enabled central rate > feature-specific/default. Automatic expiry is evaluated on server time; earlier config remains intact. Atomic revision guard and active-owner recheck with audit. Gift and Transfer retain established purchased/official origin exemptions; no unauthorized charge added to top-up or premium purchases. Central management covers existing Gift/Transfer/Withdrawal commissions; broader new commission types/agency shares are NOT introduced in this release. Existing underlying finance settings remain compatible with older APKs. New APK finance commission button routes here. Withdrawal catalog quote uses the same effective rate. Saved historical request snapshots are unchanged.

## 9. Withdrawal
Cause: old Pending reservations reduced eligible-earnings availability but did not debit the spendable wallet. New requests atomically debit amount plus ADDITIONAL commission from the matching spendable wallet, retaining original earned-reservation model. Hold records distinguish HELD/SETTLED/RELEASED. Paid settles the physical hold without another wallet debit and retains original final earned debit. Reject refunds physical hold exactly once. Request-key/ledger transaction rollback and purchased-source exclusion tested. Wallet screens reload after returning from withdrawal; confirmation screen shows authoritative wallet balance.
Defaults and catalogs without an explicit feeMode now use ADDITIONAL; explicitly saved INCLUDED catalogs remain deliberate compatible settings. Prior requests/terms are not silently repriced. Existing pre-V595 pending requests have no new physical-hold marker; preserve their legacy settlement behavior and do not run a blanket debit/backfill. Reconcile legacy pending balances manually before accepting high-volume financial production. No external bank/payment was sent by these changes.

## Verification / release limits
V590 retained fixture/regression suite and V595 focused tests run locally. V593/V594 appearance tests retained; 206 Java files passed javac syntax and callback Context audits (not Android type compilation). Public cache coalescing/isolation/failure retry; commission API persistence/active owner/revision/audit rollback/Free expiry; withdrawal immediate debit/concurrent retry/no double Paid/exact refund/rollback/purchased protection pass.
Full Android compile, lint, Robolectric runtime, signed APK, phone/RTC/audio/gift/invite/End/reconnect tests and production D1 load test NOT performed here. Build-only script stops because ANDROID_HOME is unavailable; original signing secrets also belong to the user's GitHub setup. No APK is included or relabeled. No production Worker deploy, DB migration, Play upload or external publish performed.
Use existing GitHub signing/Firebase settings. CI runs tools/v595_verify.sh before clean Android test/assembleRelease/lintRelease, preserves certificate check and one canonical APK. APK from a green run still requires exact commit/SOURCE_BUILD_ID/artifact/certificate verification.
Deploy matching Worker with APK through owner's deployment process; backend changes do not appear from APK build alone. Runtime schema creation is additive. Comments stay ephemeral; D1/R2 bindings unchanged.

## Next checkpoint
Complete actual Android CI, then device acceptance for the 9 changes and all locked Live controls. Inspect custom remote labels for Diamond wording. Profile residual room queries before claiming any scaling guarantee. Resolve additional commission folder/agency requirements separately, never infer them from old diagrams.
