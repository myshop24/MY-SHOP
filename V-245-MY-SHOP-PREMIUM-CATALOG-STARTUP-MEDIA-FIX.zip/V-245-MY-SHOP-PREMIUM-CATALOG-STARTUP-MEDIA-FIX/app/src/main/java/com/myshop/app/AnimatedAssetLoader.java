package com.myshop.app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.widget.ImageView;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** V-245 lightweight animated WebP/GIF loader. No heavy animation is bundled in the APK. */
public final class AnimatedAssetLoader {
  private static final ExecutorService IO=Executors.newCachedThreadPool();
  private AnimatedAssetLoader(){}
  public static void load(ImageView view,String url){
    if(view==null||url==null||url.trim().isEmpty())return; final String key=url.trim(); view.setTag(key);
    IO.execute(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(key).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(12000);c.setUseCaches(true);try(InputStream in=c.getInputStream()){
      if(Build.VERSION.SDK_INT>=28){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n,total=0;while((n=in.read(b))>0&&total<9*1024*1024){out.write(b,0,n);total+=n;}Drawable d=ImageDecoder.decodeDrawable(ImageDecoder.createSource(ByteBuffer.wrap(out.toByteArray())));view.post(()->{if(key.equals(view.getTag())){view.setImageDrawable(d);if(d instanceof AnimatedImageDrawable)((AnimatedImageDrawable)d).start();}});}
      else{Bitmap bm=BitmapFactory.decodeStream(in);if(bm!=null)view.post(()->{if(key.equals(view.getTag()))view.setImageBitmap(bm);});}
    }}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}});
  }
}
