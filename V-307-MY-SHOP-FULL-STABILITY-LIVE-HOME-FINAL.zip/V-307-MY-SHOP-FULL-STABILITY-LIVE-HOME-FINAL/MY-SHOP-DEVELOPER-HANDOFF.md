# MY SHOP Developer Handoff — V-307

## Version
V-307 / Android 2.9.307

## Base
Built from the latest V-306 Profile/Host/Locker compile-fix final. All V-306 protected behavior is carried forward.

## Completed in V-307
- Main Dashboard structure preserved; Live section changed only to one `ENTER LIVE HOME` entry.
- Added dedicated `LiveHomeActivity` with real backend Live Now discovery, Go Live, Join Live, real Following filter, Popular/New filters, auto refresh, short cache-first rendering, and real new-user fallback.
- Join Live screen uses real active rooms with proper cached/empty/error states.
- Added server-confirmed `/v1/live/end`; local-only close fallback removed.
- Viewer presence is recounted server-side and Peak is updated from active viewers.
- Live room displays viewer/Peak clearly and fetches enriched summary after confirmed close.
- Store/Coin opaque background, compact category chips, cache-first catalog and retry state.
- Profile content/media cache-first; media viewer Save/Download.
- Inbox compact refresh + Search + New Message; timestamps converted to relative time across Inbox/Chat/Profile/Feed/comments.
- Quick Links allow two-line labels; bottom nav compacted slightly without changing destinations.
- Public profile email privacy retained and checked.

## Preserved / do not regress
- Approved Main Dashboard architecture and visual identity.
- Host separate above + exactly 12 User/Guest seats.
- Join Request, Host Invite, mic control, moderation, audience, gifts, Live goals, themes, creator tools, PK/schedule systems already present.
- Live comments remain ephemeral; normal Feed/Profile comments remain persistent as designed.
- V-306 Admin Locker persistence, Share Profile, Quick Tools, Profile media behavior.
- D1/R2 bindings, schema/storage identifiers, permanent user identity rules, signing/PK and GitHub release workflow.
- Friend/Follow relationship backend and notification systems.

## Validation checkpoint
- `python3 tools/validate_v307.py .` -> PASS.
- `node --check backend/worker/src/index.js` -> PASS.
- AndroidManifest XML parse -> PASS.
- Existing static Java parser/syntax scan -> PASS for changed sources.
- Protected 12-seat and temporary-comment checks -> PASS.

## Required release QA
A full local Gradle assemble was not possible in the current offline environment because this source has no `gradlew` launcher and no local Gradle/Android SDK. Use the included GitHub Actions workflow, which provisions Gradle 8.11.1 and runs `gradle clean :app:assembleRelease`.

After APK build/deploy, run multi-device production QA for: Live viewer/Peak concurrency, Join Request -> Host Accept -> seat, Host Invite -> user Accept -> seat, Agora mic/reconnect, media R2 render/save, startup/admin transition, Friend/Follow counters, Notifications, and enriched Live Summary.

## Last checkpoint
V-307 source guards complete; package ready for release-workflow compile/signing checkpoint.
