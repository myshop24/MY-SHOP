package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;

/** V-296 premium category-first MY SHOP Store. */
public class StoreActivity extends androidx.appcompat.app.AppCompatActivity {
  private LinearLayout list, categories; private TextView status, title; private JSONArray catalog; private double feePercent=10.0;
  private String selected = "ALL";
  private static final String[][] CATS = {
      {"ALL","ALL"},{"COIN","COIN"},{"GOLD","GOLD"},{"BADGE","BADGE"},
      {"FRAME","FRAME"},{"THEME","THEME"},{"GIFT","GIFTS"},{"OWNED","MY ITEMS"}
  };

  @Override protected void onCreate(Bundle b){super.onCreate(b);getWindow().setBackgroundDrawable(new ColorDrawable(Color.rgb(7,9,22)));selected=getIntent().getStringExtra("category");if(selected==null||selected.trim().isEmpty())selected="ALL";selected=selected.toUpperCase();build();loadCached();load();}

  private void build(){ScrollView sv=new ScrollView(this);LinearLayout r=col();r.setPadding(dp(14),dp(16),dp(14),dp(36));r.setBackgroundColor(Color.rgb(7,9,22));
    LinearLayout h=row();TextView back=t("‹",30,Color.WHITE,true);back.setGravity(Gravity.CENTER);back.setOnClickListener(v->finish());h.addView(back,lp(dp(44),dp(44)));LinearLayout hb=col();title=t("MY SHOP STORE",21,Color.WHITE,true);hb.addView(title);hb.addView(t("Buy only what you need • clear categories • secure checkout",10,Color.rgb(184,191,224),false));h.addView(hb,wt(1));r.addView(h);

    TextView guide=t("Choose a folder below. Each folder only shows its own items.",11,Color.rgb(226,229,255),false);guide.setPadding(dp(12),dp(10),dp(12),dp(10));guide.setBackground(round(Color.rgb(24,27,56),16));r.addView(guide,top(lp(-1,-2),12));

    HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);categories=row();categories.setPadding(0,dp(10),0,dp(4));hs.addView(categories);r.addView(hs,lp(-1,-2));renderCategories();

    status=t("Loading Admin Catalog…",11,Color.rgb(184,191,224),false);status.setGravity(Gravity.CENTER_VERTICAL);status.setOnClickListener(v->load());r.addView(status,top(lp(-1,dp(34)),8));list=col();r.addView(list);sv.setBackgroundColor(Color.rgb(7,9,22));sv.addView(r);setContentView(sv);
  }

  private void renderCategories(){categories.removeAllViews();for(String[] c:CATS){TextView chip=t(c[1],9.5f,Color.WHITE,true);chip.setGravity(Gravity.CENTER);boolean on=selected.equals(c[0]);chip.setPadding(dp(10),0,dp(10),0);chip.setBackground(round(on?Color.rgb(112,54,234):Color.rgb(29,32,65),18));chip.setOnClickListener(v->{if("OWNED".equals(c[0])){startActivity(new Intent(this,MyItemsActivity.class));return;}selected=c[0];renderCategories();render(catalog);});int w="OWNED".equals(c[0])?dp(82):dp(64);LinearLayout.LayoutParams p=lp(w,dp(36));p.rightMargin=dp(6);categories.addView(chip,p);}}

  private void loadCached(){try{String raw=getSharedPreferences("myshop_store_cache",MODE_PRIVATE).getString("catalog","");if(raw.isEmpty())return;JSONObject o=new JSONObject(raw);catalog=o.optJSONArray("catalog");feePercent=o.optDouble("platformFeePercent",10.0);if(catalog!=null){render(catalog);status.setText("Saved catalog shown • updating…");}}catch(Exception ignored){}}

  private void load(){if(catalog==null)status.setText("Loading Admin Catalog…");else status.setText("Updating catalog…");BackendClient.storeCatalog(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject o){catalog=o.optJSONArray("catalog");feePercent=o.optDouble("platformFeePercent",10.0);getSharedPreferences("myshop_store_cache",MODE_PRIVATE).edit().putString("catalog",o.toString()).apply();runOnUiThread(()->render(catalog));}public void onError(String m){runOnUiThread(()->status.setText(catalog==null?(m+" • Tap to retry"):("Saved catalog shown • Tap to retry")));}});}

  private void render(JSONArray a){list.removeAllViews();int shown=0;if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&matches(x,selected)){list.addView(card(x),top(lp(-1,-2),10));shown++;}}
    String label=categoryLabel(selected);title.setText("ALL".equals(selected)?"MY SHOP STORE":label);
    status.setText(shown==0?"No published items in “"+label+"” yet.":shown+" item"+(shown==1?"":"s")+" • price and entitlement verified by backend");
  }

  private boolean matches(JSONObject x,String cat){if("ALL".equals(cat))return true;String type=x.optString("item_type","").toUpperCase();String code=x.optString("code","").toUpperCase();
    if("COIN".equals(cat))return type.equals("COIN")||code.contains("COIN_PACK")||code.equals("COIN");
    if("GOLD".equals(cat))return type.equals("GOLD")||type.equals("GOLD_COIN")||code.contains("GOLD");
    if("BADGE".equals(cat))return type.contains("BADGE")||type.contains("MEMBERSHIP")||code.equals("VIP")||code.equals("VVIP")||code.equals("ROYAL");
    if("FRAME".equals(cat))return type.equals("FRAME")||type.equals("AVATAR_FRAME")||code.contains("FRAME");
    if("THEME".equals(cat))return type.equals("THEME")||type.equals("LIVE_THEME")||type.equals("WALLPAPER")||code.contains("THEME")||code.contains("WALLPAPER");
    if("GIFT".equals(cat))return type.equals("GIFT")||type.equals("LIVE_GIFT")||code.contains("GIFT");return true;}

  private String categoryLabel(String c){if("GOLD".equals(c))return "GOLD COIN";if("BADGE".equals(c))return "BADGE / MEMBER";if("FRAME".equals(c))return "AVATAR FRAME";if("THEME".equals(c))return "LIVE THEME";if("GIFT".equals(c))return "LIVE GIFTS";for(String[] x:CATS)if(x[0].equals(c))return x[1];return c;}

  private View card(JSONObject x){LinearLayout c=col();c.setPadding(dp(12),dp(12),dp(12),dp(12));c.setBackground(round(Color.rgb(17,20,42),20));
    String type=x.optString("item_type","").toUpperCase();String code=x.optString("code","");
    c.setOnClickListener(v->{if("ROYAL".equalsIgnoreCase(code)||"VVIP".equalsIgnoreCase(code)||"VIP".equalsIgnoreCase(code)){Intent q=new Intent(this,PremiumTierActivity.class);q.putExtra("code",code);startActivity(q);}});
    LinearLayout top=row();ImageView p=new ImageView(this);p.setScaleType(ImageView.ScaleType.CENTER_INSIDE);p.setBackground(round(Color.rgb(29,31,61),18));String au=x.optString("animation_url","");String pu=x.optString("preview_url","");AnimatedAssetLoader.load(p,!au.isEmpty()?au:pu);top.addView(p,lp(dp(84),dp(84)));LinearLayout tx=col();tx.setPadding(dp(12),0,0,0);tx.addView(t(x.optString("title",code.isEmpty()?"Premium Item":code),17,Color.WHITE,true));tx.addView(t(typeLabel(type),10,Color.rgb(207,180,255),true));String ben=x.optString("benefits","");if(!ben.isEmpty())tx.addView(t(ben,10,Color.rgb(184,191,224),false));if(isLiveOnly(type))tx.addView(t("LIVE STREAMING ONLY",10,Color.rgb(98,220,255),true));top.addView(tx,wt(1));c.addView(top);
    int money=x.optInt("price_minor",0),coin=x.optInt("coin_price",0),days=x.optInt("duration_days",0),units=x.optInt("units",1);int moneyFee=(int)Math.round(money*feePercent/100.0),coinFee=(int)Math.round(coin*feePercent/100.0);String prices=(money>0?"৳"+(money/100.0)+" + VAT ৳"+(moneyFee/100.0)+" = ৳"+((money+moneyFee)/100.0):"")+(money>0&&coin>0?"  OR  ":"")+(coin>0?coin+" + "+coinFee+" VAT = "+(coin+coinFee)+" Coins":"");String meta=(prices.isEmpty()?"Admin-set price":prices)+(days>0?"  •  "+days+" days":"  •  No expiry")+(units>1?"  •  "+units+" units":"");TextView info=t(meta,12,Color.rgb(255,215,103),true);info.setPadding(0,dp(10),0,dp(6));c.addView(info);
    LinearLayout actions=row();if(money>0){TextView buy=btn("BUY / REQUEST",Color.rgb(117,50,230));buy.setOnClickListener(v->moneyPay(x));actions.addView(buy,wt(1));}if(coin>0){TextView buyc=btn("BUY WITH COIN",Color.rgb(31,136,111));buyc.setOnClickListener(v->coinPay(x));LinearLayout.LayoutParams q=wt(1);q.leftMargin=dp(8);actions.addView(buyc,q);}if(money==0&&coin==0){TextView view=btn("VIEW",Color.rgb(53,85,180));actions.addView(view,wt(1));}c.addView(actions,lp(-1,dp(48)));return c;}

  private boolean isLiveOnly(String t){return t.equals("FRAME")||t.equals("AVATAR_FRAME")||t.equals("THEME")||t.equals("LIVE_THEME")||t.equals("WALLPAPER")||t.equals("GIFT")||t.equals("LIVE_GIFT");}
  private String typeLabel(String t){if(t.contains("FRAME"))return "Avatar Frame";if(t.contains("THEME")||t.contains("WALLPAPER"))return "Live Theme / Wallpaper";if(t.contains("BADGE")||t.contains("MEMBERSHIP"))return "Badge / Membership";if(t.contains("GOLD"))return "Gold Coin";if(t.equals("COIN"))return "Coin";if(t.contains("GIFT"))return "Live Gift";return t.isEmpty()?"Store Item":t;}

  private void moneyPay(JSONObject x){String[] labs={"bKash","Nagad","Bangla QR"},keys={"bkash","nagad","bangla_qr"};new AlertDialog.Builder(this).setTitle(x.optString("title")).setItems(labs,(d,w)->{EditText ref=new EditText(this);ref.setHint("Transaction ID / Reference");new AlertDialog.Builder(this).setTitle(labs[w]+" Payment").setMessage("Final price is read from Admin Catalog. App cannot change the amount.").setView(ref).setPositiveButton("SUBMIT",(q,z)->BackendClient.storePurchase(SessionManager.getToken(this),x.optLong("id"),"MONEY",keys[w],ref.getText().toString(),cb("Purchase request submitted for Admin verification."))).setNegativeButton("Cancel",null).show();}).show();}
  private void coinPay(JSONObject x){new AlertDialog.Builder(this).setTitle("Confirm Coin Purchase").setMessage(x.optString("title")+"\nBase: "+x.optInt("coin_price")+" Coins\nVAT/Service Charge: "+feePercent+"%\nTotal is verified by backend before debit.").setPositiveButton("BUY",(d,w)->BackendClient.storePurchase(SessionManager.getToken(this),x.optLong("id"),"COIN","","",cb("Purchase completed and entitlement activated."))).setNegativeButton("Cancel",null).show();}
  private BackendClient.Callback cb(String ok){return new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{Toast.makeText(StoreActivity.this,ok,Toast.LENGTH_LONG).show();load();});}public void onError(String m){runOnUiThread(()->Toast.makeText(StoreActivity.this,m,Toast.LENGTH_LONG).show());}};}

  private TextView btn(String s,int c){TextView v=t(s,10,Color.WHITE,true);v.setGravity(Gravity.CENTER);v.setBackground(round(c,14));return v;} private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}private TextView t(String s,float z,int c,boolean b){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(b)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}private GradientDrawable round(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams wt(float w){return new LinearLayout.LayoutParams(0,-2,w);}private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
