# V-113 PBKDF2 Cloudflare Workers Fix

- Fixed registration failure: `Pbkdf2 failed: iteration counts above 100000`.
- New password hashes use exactly 100000 PBKDF2-HMAC-SHA256 iterations.
- Password verification rejects malformed/unsupported hashes above 100000 instead of crashing the Worker.
- No D1 tables are dropped or altered; V-112 migration remains intact.
- Android versionCode: 113
- Android versionName: 2.9.113
