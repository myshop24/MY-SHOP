# MY SHOP V-112 — Register SERVER_ERROR Fix

- Uses a fresh `myshop_auth_*_v112` namespace so malformed/partial older auth tables cannot block registration.
- Migrates compatible rows from V-108/V-107 auth tables and the original `users` table without deleting source data.
- Preserves existing 4-digit permanent User IDs during migration.
- Removes the incorrect legacy lookup of `users.id`; the original schema uses `users.user_id`.
- The Android client now shows the backend error message instead of hiding it behind only `SERVER_ERROR`.
- No dashboard or unrelated feature changes.
