# MY SHOP V632 / 2.9.632

Base: delivered V631 source ZIP SHA256 12e1219e8d8f8480343b46d342d9b956165e08ee74509e3df8cfb5958ca5658d. Owner explicitly authorized the combined 17-item scope on 2026-10-16. No remote push/deploy/build trigger was performed. Original package, signing inputs, existing repository ZIP pipeline and financial histories remain intact.

## Current source changes by owner numbering

1. Main/Home, Live list, Physical Store and Reels now draw the same SharedPageNav controls, no active underline. SharedPageHeader applies Home header styling to all callers; language remains explicit/readable. Store interior retained.
2. Dark Home announcement, compound engagement icons/text and nav label contrast corrected; approved white top chrome retained. Numerical preset contrast is not proof of Android widget rendering.
3. Compact aqua Start Audio Live panel: title, top-right close, thumbnail upload, name, My Theme selector and GO LIVE. Separate theme preview/Apply. Thumbnail uploads to R2 and is used in Live Discover, without modifying account avatar. Default/current owned choice is preserved if host starts without opening selector.
4. Free themes use existing Admin theme publisher, add-free action, per-item enable/disable/order/name/media and default controls. Admin list includes disabled; host selector includes only enabled zero-price free themes and valid own themes. This enables Admin to upload six or any chosen count; six new production images have NOT been auto-published without Admin selection.
5. Current room state reads current authoritative preference instead of immutable start snapshot. My Items Apply and office theme grant update preference; free disable/expiry falls back. Historical start snapshot remains history. No per-viewer private ownership leakage.
6. Join dirty notification follows completed JOIN/entry/viewer-count writes. Fresh revisits show entry again; heartbeat does not duplicate. Client queues another refresh if dirty signal arrives during a current room refresh.
7. Occupied-seat edge animation adds metallic orbit, gem highlights and voice bars; photograph, existing premium artwork and muted state retained. This is native layered animation, not a new cinematic wing/crown video asset. Reference-quality visual/device acceptance remains open.
8. Existing Music opens system document picker for local songs, multiple selection, selectable queue, move-up ordering, previous/play/pause/stop/next, repeat and volume. Files are copied off the UI thread into app cache for Agora mixing; generation cancels stale loads and active cache file is removed on replacement/stop/destruction. Completion advances queue. Admin-approved music helper retained in source. Host controls phone music. No screen-share feature.
9. Gift Sound appears beside Music for Host; existing session-authorized mute and 0–100 controls retained, independent of music/microphone/animations.
10. Premium comment padding/top-aligned avatar and multiline body fitting strengthened for all premium skins, including membership/Top1. Real narrow-device and very-long text visual acceptance remains required.
11. Highlight settings save no longer validates effective managed commission as if it were the fixed legacy setting; unrelated raw rates remain unchanged. Existing atomic fee/share ledger and idempotent receipt behavior tested with a new configured fee/share and failed delivery rollback.
12. Feed name → level → plain Follow/Unfollow text; uses server relation state, self hidden, requests gated, failed request keeps prior state. Name truncates to leave room.
13. Home Stories/Reels rail above grouped My Feed. Story upload uses existing post media infrastructure with STORY status, 24-hour public visibility and existing blocking/quota rules. Reels reuse existing video posts/profile gallery, no duplicate upload. Core new user labels translated BN/EN/HI/AR. Uploaded content/names are not machine-translated.
14. Reels uses full available playback area with aspect fit and shared bottom navigation; equal 28dp engagement art/count layout, swipe, profile menu and actual share-chooser counter. Feed engagement icons/counts enlarged together. Media decoding is bounded/concurrent thumbnails limited.
15. Actual Home preview editor: hold/drag Stories/composer/banner groups, including relative block order and semantic after-N-post anchors. Show/hide, private preview and explicit Confirm publish. Both banner groups independent; hidden groups collapse. Enable from Banner Admin opens preview, publishes section state atomically with layout after confirm. Admin preview may load disabled banner creatives; ordinary dashboard remains filtered. Home's upcoming invitation stays with second banner group, existing schedule controls retained.
16. My Feed heading + composer + Photo/Video/Post move as one group; heading-only hide collapses, color wheel editor. Dark background uses readable fallback if selected heading color has insufficient contrast. Admin accesses editor from long-press My Feed/menu or Banner Admin enable.
17. Admin dashboard replaces the long activity list with a compact event-count card; tap opens scrollable activity sheet. Logs/data are retained.

## Validation boundaries

See verification/V632-RESULTS.md and current logs. Actual Worker functions run against SQLite with authentication/RTC/R2 network doubles. Shipped Home placement method is compiled/executed against a View-tree double. Java syntax and callback Context audit are not Android symbol compilation. Exact V631 compiler regression retained.

Local full Android compile was attempted but stopped before compilation because Gradle8.11.1 could not download (Network is unreachable). No locally built APK, signing verification, APK size, Android screenshot/device, microphone permission, real Agora audio, Cloudflare D1, live push or two-phone acceptance has been claimed. A GitHub Android build and device acceptance are required. Do not describe all visual references as pixel-exact or all 17 items as device-verified.

Additional legacy tests/v542/worker-behavior.spec.cjs stops at an inherited assertion expecting adminStoreRevoke to throw; the current handler returns a structured error. This is not a new highlight failure. Current scoped highlight debit/share/retry/rollback has independent V632 real-SQLite coverage; do not weaken the old assertion to conceal it.

## Build and deploy

Upload V-632-MY-SHOP-FULL-SOURCE.zip unchanged to myshop24/MY-SHOP repository root/main, keeping the already installed MY SHOP PERMANENT RELEASE PIPELINE. Do not extract/replace root workflow or signing keys. Existing pipeline selects newest ZIP, deploys matching Worker, verifies health632 then builds/signs APK. On success obtain MY-SHOP-FINAL-V-632 / MY_SHOP_FINAL_RELEASE.apk. Pages deployment is separate.

Source includes build-only optional workflow and historical root pipeline snapshots; they do not replace the user's actual installed permanent workflow. JDK17, Node22+, Gradle8.11.1, Android SDK/build-tools36, original signing/Firebase secrets and pinned asset-generation dependencies remain required. Build setup restores generated runtime assets from their included sources; do not package regenerated duplicates or change expected hashes to pass.

Additive schema: free_key column on myshop_live_theme_preferences629, singleton myshop_home_layout632, myshop_live_thumbnails632. Thumbnail media participates in account deletion queue and row cleanup; existing posts deletion already covers STORY rows. No financial tables reset/migration. Keep existing D1/R2 bindings.

Build asset portability: the original membership/avatar converters sometimes produced a first-pass GIF hash mismatch while their paired WebP matched. Re-running only the affected original source tier produced the original expected GIF hash. Preparation now retries only affected tiers, up to three attempts, with the SAME hash/pixel gates; no expected manifest hashes were relaxed or updated. No retained runtime asset bytes changed.

## Required acceptance next

Build exact version632, verify original certificate/package/provenance and APK size. On real phones check small-screen Home and Start panel against reference, drag preview/cancel/confirm and both banner lines, dark/light contrasts, six uploaded free themes + purchased expiry + office grant, live theme Apply on Host/Guest/new joiner, immediate joined notice/count/reconnect, local phone playlist and microphone simultaneously heard by remote listener, gift volume0 and mic/music unaffected, long comments in actual premium frame, feed follow/reload, story expiry/block/report/delete, Reels gestures/share and own profile gallery. Next new delivered change is V633.
