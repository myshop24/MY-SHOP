package com.myshop.app;
import android.graphics.*;import android.graphics.drawable.Drawable;
/** Four approved side controls; central AnimatedLiveIconView is deliberately independent. */
final class NavIcon629 extends Drawable {
 static int labelColor632(android.content.Context c,String key,int normal){if(!Appearance.dark(c))return normal;return "home".equals(key)?0xff8bc7ff:"store".equals(key)?0xffffd277:"support".equals(key)?0xff71efdc:"more".equals(key)?0xffd4a3ff:0xffff8cc0;}
 private final String key;private final Paint p=new Paint(3);NavIcon629(String k){key=k;}
 private void fill(int hi,int lo){p.setStyle(Paint.Style.FILL);p.setShader(new LinearGradient(0,1,26,30,hi,lo,Shader.TileMode.CLAMP));}
 private void line(Canvas c,float x,float y,float xx,float yy,int color,float width){p.setShader(null);p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(width);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(x,y,xx,yy,p);p.setStyle(Paint.Style.FILL);}
 @Override public void draw(Canvas c){int save=c.save();Rect b=getBounds();c.translate(b.left,b.top);c.scale(b.width()/32f,b.height()/32f);p.setShader(null);p.setColor(0x160d2850);c.drawOval(4,28,29,31,p);
 if("home".equals(key)){Path h=new Path();h.moveTo(3,14);h.lineTo(16,3);h.lineTo(29,14);h.lineTo(26,14);h.lineTo(26,28);h.lineTo(19,28);h.lineTo(19,20);h.lineTo(13,20);h.lineTo(13,28);h.lineTo(6,28);h.lineTo(6,14);h.close();fill(0xff36c3ff,0xff0649de);c.drawPath(h,p);line(c,4,14,16,4,0xff8be3ff,1.3f);line(c,16,4,28,14,0xff0640c4,1.4f);}
 else if("store".equals(key)){line(c,2,5,7,5,0xff1465d9,3);Path cart=new Path();cart.moveTo(7,8);cart.lineTo(29,8);cart.lineTo(26,23);cart.lineTo(10,23);cart.close();fill(0xffffdf58,0xffec8504);c.drawPath(cart,p);line(c,9,10,27,10,0xffffef99,1.5f);for(int x=12;x<27;x+=6)line(c,x,12,x-1,20,0xffffe184,1.4f);line(c,10,16,26,16,0xffffe184,1.3f);p.setShader(null);p.setColor(0xff1454ba);c.drawCircle(12,27,3,p);c.drawCircle(24,27,3,p);p.setColor(0xff69c8ff);c.drawCircle(11.3f,26.3f,1,p);c.drawCircle(23.3f,26.3f,1,p);}
 else if("support".equals(key)){p.setShader(null);p.setColor(0xff079a9e);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);c.drawArc(5,3,27,28,180,180,false,p);p.setStyle(Paint.Style.FILL);fill(0xff58f3dc,0xff008d94);c.drawRoundRect(3,14,10,25,3,3,p);c.drawRoundRect(23,14,30,25,3,3,p);line(c,26,25,23,29,0xff007e89,2);line(c,23,29,17,29,0xff007e89,2);p.setShader(null);p.setColor(0xff43d9d0);c.drawRoundRect(14,27,20,31,2,2,p);}
 else {for(int y=0;y<2;y++)for(int x=0;x<2;x++){float l=3+x*15,t=3+y*15;fill(0xffb46aff,0xff6515dc);c.drawRoundRect(l,t,l+12,t+12,3,3,p);line(c,l+3,t+2,l+9,t+2,0xffd7a4ff,1);}}
 p.setShader(null);c.restoreToCount(save);}
 @Override public void setAlpha(int a){p.setAlpha(a);}@Override public void setColorFilter(ColorFilter f){p.setColorFilter(f);}@Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
