package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.app.AlertDialog;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** V-72 login: approved MY SHOP reference, email/mobile/4-digit ID, no OTP. */
public class LoginActivity extends AppCompatActivity {
    private EditText loginId, loginPassword;
    private TextView welcome, forgot, create;
    private CheckBox remember;
    private Button language;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        String existingId = SessionManager.getUserId(this);
        if (SessionManager.isLoggedIn(this) && !existingId.isEmpty() && AccountStore.exists(this, existingId)) {
            startActivity(new Intent(this, MainActivity.class)); finish(); return;
        }
        bindViews();
        applyLanguage();
    }

    private void bindViews() {
        loginId = findViewById(R.id.loginId);
        loginPassword = findViewById(R.id.loginPassword);
        remember = findViewById(R.id.rememberMe);
        welcome = findViewById(R.id.welcomeText);
        forgot = findViewById(R.id.forgotButton);
        create = findViewById(R.id.createAccountButton);
        language = findViewById(R.id.languageButton);
        Button login = findViewById(R.id.loginButton);
        ImageButton toggle = findViewById(R.id.passwordToggle);

        language.setOnClickListener(v -> LanguageManager.showPicker(this, this::applyLanguage));
        create.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
        forgot.setOnClickListener(v -> showPasswordResetBox());
        login.setOnClickListener(v -> login());
        toggle.setOnClickListener(v -> {
            int pos = loginPassword.getSelectionStart();
            boolean hidden = (loginPassword.getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) != 0;
            loginPassword.setInputType(InputType.TYPE_CLASS_TEXT | (hidden ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            loginPassword.setSelection(Math.max(0, pos));
        });
    }

    private void applyLanguage() {
        if (welcome == null) return;
        welcome.setText(LanguageManager.t(this, "welcome"));
        forgot.setText(LanguageManager.t(this, "forgot"));
        create.setText("＋  " + LanguageManager.t(this, "register"));
        remember.setText(LanguageManager.t(this, "remember"));
        language.setText("🌐  " + languageLabel());
        ((Button)findViewById(R.id.loginButton)).setText(LanguageManager.t(this, "login"));
        ((TextView)findViewById(R.id.orText)).setText(LanguageManager.t(this, "or"));
        loginId.setHint("Login / Email / Mobile / ID");
        loginPassword.setHint("Password");
    }

    private String languageLabel() {
        String l = LanguageManager.get(this);
        if (LanguageManager.EN.equals(l)) return "English";
        if (LanguageManager.HI.equals(l)) return "हिन्दी";
        if (LanguageManager.AR.equals(l)) return "العربية";
        return "বাংলা";
    }

    private void showPasswordResetBox() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(18),dp(8),dp(18),dp(8));
        TextView info = new TextView(this); info.setText(LanguageManager.t(this, "security") + "\n" + LanguageManager.t(this, "securityHint")); info.setTextColor(Color.DKGRAY); info.setTextSize(14); box.addView(info);
        EditText identifier = field("Email / Mobile / User ID"); box.addView(identifier);
        EditText a1 = field("Security Answer 1"), a2 = field("Security Answer 2"), a3 = field("Security Answer 3"); box.addView(a1); box.addView(a2); box.addView(a3);
        EditText np = field("New Password"), cp = field("Confirm New Password"); np.setInputType(129); cp.setInputType(129); box.addView(np); box.addView(cp);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(LanguageManager.t(this,"forgot")).setView(box).setNegativeButton("Cancel",null).setPositiveButton("RESET PASSWORD",null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String id = identifier.getText().toString().trim(); String pass = np.getText().toString();
            if (id.isEmpty() || pass.length()<6 || !pass.equals(cp.getText().toString())) { Toast.makeText(this,"Identifier and matching 6+ character password are required.",Toast.LENGTH_SHORT).show(); return; }
            boolean ok = AccountStore.resetPasswordWithTwoOfThree(this,id,new String[]{a1.getText().toString(),a2.getText().toString(),a3.getText().toString()},pass);
            if(ok){Toast.makeText(this,"Password reset successful.",Toast.LENGTH_LONG).show();dialog.dismiss();} else Toast.makeText(this,"At least 2 of the 3 answers must be correct.",Toast.LENGTH_LONG).show();
        }));
        dialog.show();
    }

    private EditText field(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true); e.setPadding(dp(10),0,dp(10),0); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52)); p.topMargin=dp(6); e.setLayoutParams(p); return e; }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    private void login() {
        String identifier = loginId.getText().toString().trim(), pass = loginPassword.getText().toString();
        if(identifier.isEmpty()||pass.isEmpty()){Toast.makeText(this,"Login ID and Password are required.",Toast.LENGTH_SHORT).show();return;}
        try {
            AccountStore.Account account = AccountStore.authenticate(this, identifier, pass);
            if(account==null){Toast.makeText(this,"Login failed. Check your Login ID and Password.",Toast.LENGTH_LONG).show();return;}
            Role role = AdminIdentifiers.isAdminIdentifier(identifier) ? Role.ADMIN : Role.USER;
            SessionManager.setSession(this, role, account.userId); SessionManager.saveProfile(this, account.name, account.email, account.mobile);
            Intent i=new Intent(this,MainActivity.class); i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP); startActivity(i); finish();
        } catch(Throwable t){Toast.makeText(this,"Login failed safely. Your account data was not changed.",Toast.LENGTH_LONG).show();}
    }
}
