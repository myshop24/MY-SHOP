# MY SHOP V-158 — REQUESTED UI / ADMIN FIXES

1. Left hamburger opens the normal User Menu for everyone, including Admin. Admin tools are not exposed there.
2. Admin account actions are opened contextually from the relevant dashboard folder/button/banner area.
3. Social Links admin screen has explicit SAVE/DELETE controls; saved links are shown to users with platform/domain-based icons and open the configured URL when tapped.
4. Customer Support opens the configured WhatsApp support link directly; the phone number is never displayed in the app UI.
5. Share App uses the Android share chooser so the app can be shared to compatible installed social/messaging apps.
6. Feed Like/Comment controls are reduced and use visible dark text on white buttons.
7. User profile includes a visible “Share App” button and keeps the permanent User ID unchanged.
8. Existing notification/feed backend routes are preserved; deployment must use this exact V-158 Worker source before the APK build.

DATA SAFETY
- No D1 reset/drop/truncate.
- No user/account/ID deletion or regeneration.
- Existing D1 database and R2 binding are preserved.
- Profile avatar replacement remains upload-new → update-D1 → delete-old, so the old avatar is retained if the new update fails.
- No OTP/verification-code flow is introduced.
