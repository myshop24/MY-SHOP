package com.myshop.app;

import android.content.Context;
import io.agora.rtc2.ChannelMediaOptions;
import io.agora.rtc2.Constants;
import io.agora.rtc2.IRtcEngineEventHandler;
import io.agora.rtc2.RtcEngine;
import io.agora.rtc2.RtcEngineConfig;

/** V-343 audio-only RTC transport with persistent diagnostics. Backend remains room/seat/role authority. */
public final class AgoraRtcManager {
    public interface Listener {
        void onJoined();
        void onRemoteUserJoined(int uid);
        void onRemoteAudioState(int uid,int state,int reason);
        void onLocalAudioState(int state,int error);
        void onConnectionState(int state,int reason);
        void onError(String message);
        void onTokenWillExpire();
        void onAudioLevel(boolean speaking);
        void onActiveSpeaker(int uid,int volume);
    }
    private RtcEngine engine; private boolean joined=false; private Boolean lastPublishAudio=null,lastMicEnabled=null; private final Listener listener;
    public AgoraRtcManager(Listener listener){this.listener=listener;}
    public void init(Context context) throws Exception {
        if(engine!=null)return;
        RtcEngineConfig c=new RtcEngineConfig(); c.mContext=context.getApplicationContext(); c.mAppId=BuildConfig.AGORA_APP_ID;
        c.mEventHandler=new IRtcEngineEventHandler(){
            @Override public void onJoinChannelSuccess(String ch,int uid,int elapsed){joined=true;if(listener!=null)listener.onJoined();}
            @Override public void onConnectionStateChanged(int state,int reason){if(listener!=null)listener.onConnectionState(state,reason);}
            @Override public void onLocalAudioStateChanged(int state,int error){if(listener!=null)listener.onLocalAudioState(state,error);}
            @Override public void onError(int err){if(listener!=null)listener.onError("Agora RTC error "+err);}
            @Override public void onUserJoined(int uid,int elapsed){if(listener!=null)listener.onRemoteUserJoined(uid);}
            @Override public void onRemoteAudioStateChanged(int uid,int state,int reason,int elapsed){if(listener!=null)listener.onRemoteAudioState(uid,state,reason);}
            @Override public void onTokenPrivilegeWillExpire(String token){if(listener!=null)listener.onTokenWillExpire();}
            @Override public void onRequestToken(){if(listener!=null)listener.onTokenWillExpire();}
            @Override public void onAudioVolumeIndication(AudioVolumeInfo[] speakers,int totalVolume){if(listener==null||speakers==null)return;boolean speaking=false;int loudUid=-1,loudVolume=0;for(AudioVolumeInfo i:speakers){if(i==null)continue;if(i.uid==0&&i.volume>=12)speaking=true;if(i.volume>=12&&i.volume>loudVolume){loudUid=i.uid;loudVolume=i.volume;}}listener.onAudioLevel(speaking);listener.onActiveSpeaker(loudUid,loudVolume);}
        };
        engine=RtcEngine.create(c);
        engine.setChannelProfile(Constants.CHANNEL_PROFILE_LIVE_BROADCASTING);
        engine.enableAudio();
        // V-346 speech-first live audio tuning: prioritize intelligibility for voice chat.
        try{engine.setAudioProfile(Constants.AUDIO_PROFILE_SPEECH_STANDARD);engine.setAudioScenario(Constants.AUDIO_SCENARIO_CHATROOM);}catch(Exception ignored){}
        engine.enableLocalAudio(true);
        engine.setEnableSpeakerphone(true);
        engine.setDefaultAudioRoutetoSpeakerphone(true);
        engine.muteAllRemoteAudioStreams(false);
        try{engine.adjustPlaybackSignalVolume(140);}catch(Exception ignored){}
        engine.adjustRecordingSignalVolume(115);
        engine.enableAudioVolumeIndication(250,3,true);
    }
    public int join(String token,String channelName,int uid,boolean publishAudio){
        if(engine==null)return -10001;
        if(token==null||token.isEmpty()||channelName==null||channelName.isEmpty()||uid<=0)return -10002;
        if(joined){renewToken(token);setPublishAudio(publishAudio);return 0;}
        engine.setClientRole(publishAudio?Constants.CLIENT_ROLE_BROADCASTER:Constants.CLIENT_ROLE_AUDIENCE);
        engine.enableLocalAudio(publishAudio);
        ChannelMediaOptions o=new ChannelMediaOptions();
        o.autoSubscribeAudio=true;
        o.publishMicrophoneTrack=publishAudio;
        int rc=engine.joinChannel(token,channelName,uid,o);
        // V-353: do not pre-mark publish/mic state as applied before Agora confirms the join.
        // The Live room may immediately call setPublishAudio/setMicEnabled after join; those
        // calls must reach the engine once instead of being skipped by the V-352 idempotency cache.
        if(rc==0){lastPublishAudio=null;lastMicEnabled=null;}
        if(rc!=0&&listener!=null)listener.onError("Agora join return "+rc);
        return rc;
    }
    // V-352: role/media updates are idempotent. Re-rendering the Live room must not
    // repeatedly reconfigure the active Agora microphone path and introduce audio jitter.
    public void setPublishAudio(boolean publish){
        if(engine==null)return;
        // V-353 audio recovery: playback/subscription/route must never be skipped.
        // Only the expensive role/media-options mutation is deduplicated.
        try{engine.muteAllRemoteAudioStreams(false);}catch(Exception ignored){}
        try{engine.setEnableSpeakerphone(true);}catch(Exception ignored){}
        if(lastPublishAudio!=null&&lastPublishAudio==publish)return;
        engine.setClientRole(publish?Constants.CLIENT_ROLE_BROADCASTER:Constants.CLIENT_ROLE_AUDIENCE);
        engine.enableLocalAudio(publish);
        ChannelMediaOptions o=new ChannelMediaOptions();o.autoSubscribeAudio=true;o.publishMicrophoneTrack=publish;
        engine.updateChannelMediaOptions(o);lastPublishAudio=publish;
        if(!publish)lastMicEnabled=false;
    }
    public void setMicEnabled(boolean enabled){
        if(engine==null)return;
        if(lastMicEnabled!=null&&lastMicEnabled==enabled)return;
        engine.enableLocalAudio(enabled);engine.muteLocalAudioStream(!enabled);lastMicEnabled=enabled;
    }
    public void renewToken(String token){if(engine!=null&&token!=null&&!token.isEmpty())engine.renewToken(token);}
    public void leave(){if(engine!=null&&joined)engine.leaveChannel();joined=false;lastPublishAudio=null;lastMicEnabled=null;}
    public void destroy(){leave();if(engine!=null){RtcEngine.destroy();engine=null;}}
}
