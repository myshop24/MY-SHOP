package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Shared Login entry point for USER / MODERATOR / ADMIN.
 * Production authentication and role resolution must be supplied by the backend.
 */
public class LoginActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (SessionManager.isLoggedIn(this)) {
            openMain();
            return;
        }

        setContentView(R.layout.activity_login);
        findViewById(R.id.createAccountButton).setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));
        findViewById(R.id.loginButton).setOnClickListener(v -> login());
        findViewById(R.id.forgotButton).setOnClickListener(v ->
                Toast.makeText(this, "Password reset will be connected to the secure backend.", Toast.LENGTH_LONG).show());
    }

    private void login() {
        EditText id = findViewById(R.id.loginId);
        EditText password = findViewById(R.id.loginPassword);
        String identifier = id.getText().toString().trim();
        String pass = password.getText().toString();

        if (identifier.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Email/Mobile and Password are required.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Safe offline shell: never embeds admin credentials in the APK.
        // Backend authentication must replace this USER fallback and return role + userId.
        SessionManager.setSession(this, Role.USER, SessionManager.getUserId(this));
        openMain();
    }

    private void openMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
