package com.myshop.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * V-300 app-local Admin Locker.
 * No Cloudflare/D1/R2 setup is required. This is only an extra local UI gate;
 * real admin authority still comes from backend ADMIN role/identity.
 * Password and recovery answer are PBKDF2 hashes with random salts; plaintext is never stored.
 */
public class AdminGateActivity extends AppCompatActivity {
    private static final String PREF="myshop_admin_locker_v300";
    private static final String K_PASS_SALT="pass_salt", K_PASS_HASH="pass_hash";
    private static final String K_QUESTION="question", K_ANSWER_SALT="answer_salt", K_ANSWER_HASH="answer_hash";
    private static final int ITER=120000, KEY_BITS=256;
    private final int NAVY=Color.rgb(15,25,62), PURPLE=Color.rgb(99,48,211), BLUE=Color.rgb(39,94,228), MUTED=Color.rgb(101,112,143), WHITE=Color.WHITE;
    private final String[] questions={
            "আপনার পছন্দের ব্যক্তির নাম কী?",
            "আপনার জন্মস্থানের জেলা কী?",
            "আপনার পছন্দের রং কী?",
            "আপনার পছন্দের শিক্ষকের নাম কী?",
            "নিজের Security Question লিখুন"
    };

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        if(!SessionManager.isAdmin(this)){finish();return;}
        if(SessionManager.isAdminGateUnlocked()){openHub();return;}
        if(configured())showUnlock(savedQuestion()); else showSetup();
    }

    private boolean configured(){return !prefs().getString(K_PASS_HASH,"").isEmpty();}
    private String savedQuestion(){return prefs().getString(K_QUESTION,"");}

    private void showSetup(){
        LinearLayout card=card();
        card.addView(header("🛡","অ্যাডমিন লকার তৈরি করুন","শুধু এই ফোনে সেট হবে • Cloud/D1 লাগবে না"));
        card.addView(help("অ্যাডমিন পাসওয়ার্ড","কমপক্ষে ৬ অক্ষরের Password দিন। Password plaintext হিসেবে রাখা হবে না।"));
        EditText pass=passwordField("অ্যাডমিন পাসওয়ার্ড"); card.addView(passwordRow(pass));
        card.addView(help("নিরাপত্তা প্রশ্ন","Password ভুলে গেলে এই ফোনে recovery-এর জন্য ব্যবহার হবে।"));
        Spinner spinner=new Spinner(this); spinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,questions)); spinner.setBackground(round(WHITE,Color.rgb(216,222,240),14)); card.addView(spinner,lp(-1,dp(52)));
        EditText custom=textField("নিজের Security Question লিখুন"); custom.setVisibility(View.GONE); card.addView(custom,lp(-1,dp(52)));
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){custom.setVisibility(pos==questions.length-1?View.VISIBLE:View.GONE);}
            public void onNothingSelected(android.widget.AdapterView<?> p){}
        });
        card.addView(help("নিরাপত্তা উত্তর","ছোট কিন্তু মনে রাখা সহজ উত্তর দিন। এটিও plaintext হিসেবে রাখা হবে না।"));
        EditText answer=textField("নিরাপত্তা উত্তর"); card.addView(answer,lp(-1,dp(52)));
        TextView create=primary("🔐  CREATE ADMIN LOCKER");
        create.setOnClickListener(v->{
            hideKeyboard(); String ps=pass.getText().toString(); int qi=spinner.getSelectedItemPosition();
            String qs=qi==questions.length-1?custom.getText().toString().trim():questions[Math.max(0,qi)];
            String as=answer.getText().toString().trim();
            if(ps.length()<6){pass.setError("কমপক্ষে ৬ অক্ষর দিন");return;}
            if(qs.isEmpty()){custom.setError("Security Question দিন");return;}
            if(as.length()<2){answer.setError("Security Answer দিন");return;}
            try{
                byte[] psalt=randomSalt(), asalt=randomSalt();
                prefs().edit()
                        .putString(K_PASS_SALT,b64(psalt)).putString(K_PASS_HASH,b64(hash(ps,psalt)))
                        .putString(K_QUESTION,qs)
                        .putString(K_ANSWER_SALT,b64(asalt)).putString(K_ANSWER_HASH,b64(hash(normalize(as),asalt)))
                        .apply();
                Toast.makeText(this,"Admin Locker এই ফোনে তৈরি হয়েছে",Toast.LENGTH_SHORT).show();
                showUnlock(qs);
            }catch(Exception e){Toast.makeText(this,"Locker তৈরি করা যায়নি",Toast.LENGTH_LONG).show();}
        });
        card.addView(create,top(lp(-1,dp(54)),dp(14)));
        setContentView(screen(card));
    }

    private void showUnlock(String question){
        LinearLayout card=card();
        card.addView(header("🔐","MY SHOP অ্যাডমিন গেট","Local Admin Locker • Cloud setup প্রয়োজন নেই"));
        TextView chip=label("Backend Admin Role + Local Password",10,WHITE,true); chip.setGravity(Gravity.CENTER); chip.setBackground(round(PURPLE,PURPLE,16)); card.addView(chip,lp(-1,dp(34)));
        card.addView(help("অ্যাডমিন পাসওয়ার্ড","এই ফোনে সেট করা Admin Password লিখুন।"));
        EditText pass=passwordField("অ্যাডমিন পাসওয়ার্ড"); card.addView(passwordRow(pass));
        TextView unlock=primary("🔓  UNLOCK ADMIN PANEL");
        unlock.setOnClickListener(v->{
            hideKeyboard();
            if(verify(pass.getText().toString(),K_PASS_SALT,K_PASS_HASH)){SessionManager.setAdminGateUnlocked(true);openHub();}
            else pass.setError("Password সঠিক নয়");
        });
        card.addView(unlock,top(lp(-1,dp(54)),dp(12)));
        TextView forgot=label("Password ভুলে গেছেন?",11,PURPLE,true);forgot.setGravity(Gravity.CENTER);forgot.setBackground(round(Color.rgb(248,246,255),Color.rgb(214,204,241),14));forgot.setOnClickListener(v->showRecovery(question));card.addView(forgot,top(lp(-1,dp(48)),dp(8)));
        setContentView(screen(card));
    }

    private void showRecovery(String question){
        LinearLayout b=dialogBox();b.addView(help("নিরাপত্তা প্রশ্ন",question.isEmpty()?"আপনার Security Question-এর উত্তর দিন।":question));
        EditText ans=textField("নিরাপত্তা উত্তর"),np=passwordField("নতুন Admin Password");b.addView(ans,lp(-1,dp(50)));b.addView(np,top(lp(-1,dp(50)),dp(8)));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("অ্যাডমিন লকার পুনরুদ্ধার").setView(b).setNegativeButton("বাতিল",null).setPositiveButton("পাসওয়ার্ড রিসেট",null).create();
        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            if(np.getText().length()<6){np.setError("কমপক্ষে ৬ অক্ষর");return;}
            if(!verify(normalize(ans.getText().toString()),K_ANSWER_SALT,K_ANSWER_HASH)){ans.setError("উত্তর সঠিক নয়");return;}
            try{byte[] salt=randomSalt();prefs().edit().putString(K_PASS_SALT,b64(salt)).putString(K_PASS_HASH,b64(hash(np.getText().toString(),salt))).apply();dlg.dismiss();Toast.makeText(this,"Password reset হয়েছে",Toast.LENGTH_SHORT).show();showUnlock(question);}catch(Exception e){Toast.makeText(this,"Password reset করা যায়নি",Toast.LENGTH_LONG).show();}
        }));dlg.show();
    }

    private boolean verify(String value,String saltKey,String hashKey){
        try{byte[] salt=Base64.decode(prefs().getString(saltKey,""),Base64.NO_WRAP);byte[] want=Base64.decode(prefs().getString(hashKey,""),Base64.NO_WRAP);byte[] got=hash(value,salt);if(want.length!=got.length)return false;int diff=0;for(int i=0;i<want.length;i++)diff|=(want[i]^got[i]);return diff==0;}catch(Exception e){return false;}
    }
    private byte[] hash(String value,byte[] salt)throws Exception{PBEKeySpec spec=new PBEKeySpec(value.toCharArray(),salt,ITER,KEY_BITS);try{return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();}finally{spec.clearPassword();}}
    private byte[] randomSalt(){byte[] b=new byte[16];new SecureRandom().nextBytes(b);return b;}
    private String b64(byte[] b){return Base64.encodeToString(b,Base64.NO_WRAP);}
    private String normalize(String s){return s==null?"":s.trim().toLowerCase(java.util.Locale.ROOT);}
    private SharedPreferences prefs(){return getSharedPreferences(PREF,MODE_PRIVATE);}

    private LinearLayout passwordRow(EditText pass){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setBackground(round(WHITE,Color.rgb(211,219,239),14));pass.setBackgroundColor(Color.TRANSPARENT);row.addView(pass,new LinearLayout.LayoutParams(0,dp(52),1));TextView eye=label("👁",18,NAVY,true);eye.setGravity(Gravity.CENTER);eye.setOnClickListener(v->{int pos=Math.max(0,pass.getSelectionStart());boolean hidden=(pass.getInputType()&InputType.TYPE_TEXT_VARIATION_PASSWORD)!=0;pass.setInputType(InputType.TYPE_CLASS_TEXT|(hidden?InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD:InputType.TYPE_TEXT_VARIATION_PASSWORD));pass.setSelection(Math.min(pos,pass.length()));eye.setText(hidden?"🙈":"👁");});row.addView(eye,new LinearLayout.LayoutParams(dp(52),dp(52)));return row;}
    private View screen(LinearLayout card){FrameLayout outer=new FrameLayout(this);GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(242,246,255),Color.rgb(250,247,255),Color.rgb(246,250,255)});outer.setBackground(bg);ScrollView sv=new ScrollView(this);sv.setClipToPadding(false);sv.setPadding(dp(14),dp(24),dp(14),dp(24));sv.addView(card,new ScrollView.LayoutParams(-1,-2));outer.addView(sv,new FrameLayout.LayoutParams(-1,-1));return outer;}
    private LinearLayout card(){LinearLayout c=dialogBox();c.setPadding(dp(18),dp(18),dp(18),dp(18));c.setBackground(round(Color.WHITE,Color.rgb(219,224,239),24));return c;}
    private LinearLayout dialogBox(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout header(String icon,String title,String sub){LinearLayout b=dialogBox();TextView i=label(icon,26,BLUE,true);i.setGravity(Gravity.CENTER);b.addView(i,lp(-1,dp(48)));TextView t=label(title,19,NAVY,true);t.setGravity(Gravity.CENTER);b.addView(t,lp(-1,dp(38)));TextView s=label(sub,10.5f,MUTED,false);s.setGravity(Gravity.CENTER);b.addView(s,lp(-1,dp(34)));return b;}
    private TextView help(String title,String text){TextView v=label(title+"\n"+text,10.5f,MUTED,false);v.setPadding(dp(10),dp(9),dp(10),dp(9));v.setBackground(round(Color.rgb(248,249,253),Color.rgb(228,231,240),12));LinearLayout.LayoutParams p=lp(-1,-2);p.topMargin=dp(8);p.bottomMargin=dp(5);v.setLayoutParams(p);return v;}
    private EditText textField(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextSize(12);e.setPadding(dp(12),0,dp(12),0);e.setBackground(round(WHITE,Color.rgb(211,219,239),14));return e;}
    private EditText passwordField(String hint){EditText e=textField(hint);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);return e;}
    private TextView primary(String s){TextView v=label(s,13,WHITE,true);v.setGravity(Gravity.CENTER);v.setBackground(gradient(new int[]{BLUE,PURPLE},16));return v;}
    private TextView label(String s,float z,int c,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private GradientDrawable gradient(int[] colors,int r){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(r));return g;}
    private GradientDrawable round(int fill,int stroke,int r){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(r));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int t){p.topMargin=t;return p;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private void hideKeyboard(){View v=getCurrentFocus();if(v!=null)((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(),0);}
    private void openHub(){runOnUiThread(()->{Intent i=new Intent(this,AdminHubActivity.class);i.putExtra("gate_passed",true);startActivity(i);finish();});}
}
