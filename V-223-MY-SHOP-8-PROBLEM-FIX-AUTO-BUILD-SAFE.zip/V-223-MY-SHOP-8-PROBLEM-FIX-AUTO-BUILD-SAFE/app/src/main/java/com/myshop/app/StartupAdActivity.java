package com.myshop.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** V-223: Admin-controlled startup advertisement with image/video + configurable duration. */
public class StartupAdActivity extends Activity {
    private CountDownTimer timer;
    private boolean opened=false;
    private Button skip;
    private ImageView imageAd;
    private VideoView videoAd;
    private FrameLayout mediaHost;
    private int seconds=3;

    @Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);

        mediaHost=new FrameLayout(this);
        FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER);
        mp.setMargins(dp(8),dp(58),dp(8),dp(58)); root.addView(mediaHost,mp);

        imageAd=new ImageView(this);
        imageAd.setImageResource(R.drawable.startup_ad_myshop_live);
        imageAd.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        imageAd.setAdjustViewBounds(true);
        mediaHost.addView(imageAd,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));

        videoAd=new VideoView(this); videoAd.setVisibility(View.GONE);
        mediaHost.addView(videoAd,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));

        TextView label=new TextView(this); label.setText("ADVERTISEMENT"); label.setTextColor(Color.WHITE); label.setTextSize(11); label.setGravity(Gravity.CENTER); label.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(128),dp(34),Gravity.TOP|Gravity.START); lp.setMargins(dp(12),dp(12),0,0); root.addView(label,lp);

        skip=new Button(this); skip.setAllCaps(false); skip.setTextColor(Color.WHITE); skip.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(110),dp(48),Gravity.TOP|Gravity.END); sp.setMargins(0,dp(10),dp(10),0); root.addView(skip,sp); skip.setOnClickListener(v->openLogin());

        TextView hint=new TextView(this); hint.setText("MY SHOP • Advertisement"); hint.setTextColor(Color.WHITE); hint.setTextSize(12); hint.setGravity(Gravity.CENTER); hint.setBackgroundColor(0x66000000);
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(40),Gravity.BOTTOM); hp.setMargins(dp(12),0,dp(12),dp(12)); root.addView(hint,hp);
        setContentView(root);
        loadRemoteAd();
    }

    private void loadRemoteAd(){
        if(!BackendClient.configured()){startTimer(3);return;}
        BackendClient.dashboard(null,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                runOnUiThread(()->{
                    try{
                        JSONArray ads=d.optJSONArray("dashboardAds"); JSONObject found=null;
                        if(ads!=null) for(int i=0;i<ads.length();i++){
                            JSONObject x=ads.optJSONObject(i);
                            if(x!=null&&"startup_ad".equalsIgnoreCase(x.optString("box_key",""))&&x.optInt("active",1)==1){found=x;break;}
                        }
                        if(found!=null){
                            seconds=Math.max(1,Math.min(60,found.optInt("duration_sec",3)));
                            String media=found.optString("image_url","").trim();
                            String type=found.optString("media_type","").trim().toLowerCase();
                            String target=found.optString("target_url","").trim();
                            if(type.isEmpty()) type=isVideoUrl(media)?"video":"image";
                            // Backward-compatible V-223 mode: with the older Worker, Admin may save a direct MP4/WebM URL in Target URL.
                            // The app treats that as startup video media until the Worker video-upload endpoint is deployed.
                            if(!"video".equals(type) && isVideoUrl(target)){media=target;type="video";target="";}
                            if("video".equals(type) && !media.isEmpty()) showVideo(media); else if(!media.isEmpty()) loadImage(media);
                            final String clickTarget=target;
                            if(!clickTarget.isEmpty()) mediaHost.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(clickTarget)));}catch(Exception ignored){}});
                        } else seconds=3;
                    }catch(Exception ignored){seconds=3;}
                    startTimer(seconds);
                });
            }
            public void onError(String m){runOnUiThread(()->startTimer(3));}
        });
    }

    private boolean isVideoUrl(String u){String x=u==null?"":u.toLowerCase();return x.contains(".mp4")||x.contains(".webm")||x.contains(".m3u8")||x.contains("video");}

    private void showVideo(String u){
        try{
            imageAd.setVisibility(View.GONE); videoAd.setVisibility(View.VISIBLE);
            videoAd.setVideoURI(Uri.parse(u));
            videoAd.setOnPreparedListener(mp->{mp.setLooping(true);videoAd.start();});
            videoAd.setOnErrorListener((mp,what,extra)->{videoAd.setVisibility(View.GONE);imageAd.setVisibility(View.VISIBLE);return true;});
        }catch(Exception e){videoAd.setVisibility(View.GONE);imageAd.setVisibility(View.VISIBLE);}
    }

    private void loadImage(String u){
        imageAd.setVisibility(View.VISIBLE); videoAd.setVisibility(View.GONE);
        new Thread(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setUseCaches(false);c.setRequestProperty("Cache-Control","no-cache");try(InputStream in=c.getInputStream()){android.graphics.Bitmap b=android.graphics.BitmapFactory.decodeStream(in);if(b!=null)runOnUiThread(()->imageAd.setImageBitmap(b));}}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}}).start();
    }

    private void startTimer(int sec){seconds=Math.max(1,sec);if(timer!=null)timer.cancel();timer=new CountDownTimer(seconds*1000L,1000){public void onTick(long ms){int left=(int)Math.ceil(ms/1000.0);skip.setText("Skip "+Math.max(1,left));}public void onFinish(){openLogin();}}.start();}
    private void openLogin(){if(opened)return;opened=true;if(timer!=null)timer.cancel();try{videoAd.stopPlayback();}catch(Exception ignored){}startActivity(new Intent(this,LoginActivity.class));finish();}
    @Override protected void onDestroy(){if(timer!=null)timer.cancel();try{videoAd.stopPlayback();}catch(Exception ignored){}super.onDestroy();}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
