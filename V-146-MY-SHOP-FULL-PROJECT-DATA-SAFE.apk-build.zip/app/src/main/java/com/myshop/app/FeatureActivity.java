package com.myshop.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;
import org.json.JSONArray;
import org.json.JSONObject;
import androidx.appcompat.app.AppCompatActivity;

public class FeatureActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String title = getIntent().getStringExtra("title");
        if (title == null || title.trim().isEmpty()) title = "MY SHOP";

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 42, 28, 28);
        root.setBackgroundColor(getColor(R.color.myshop_bg));

        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextSize(27);
        heading.setTextColor(getColor(R.color.myshop_dark));
        heading.setGravity(Gravity.CENTER);
        root.addView(heading, new LinearLayout.LayoutParams(-1, 100));

        TextView status = new TextView(this);
        status.setText("MY SHOP module frame\n\nThis feature is ready for backend-driven content. Where supported, Admin changes can be delivered without rebuilding the APK.");
        status.setTextSize(17);
        status.setTextColor(getColor(R.color.text_muted));
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, 0, 1));

        String featureKey=getIntent().getStringExtra("feature_key");
        if ("social_media".equals(featureKey)) {
            status.setText("Loading Social Media…");
            BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->renderSocial(root,status,d.optJSONArray("socialLinks")));}
                public void onError(String m){runOnUiThread(()->status.setText("Social links unavailable: "+m));}
            });
        }

        String url = getIntent().getStringExtra("url");
        if (FeatureRegistry.isSafeHttpUrl(url)) {
            Button open = new Button(this);
            open.setText("Open Link");
            open.setOnClickListener(v -> openUrl(url));
            root.addView(open, new LinearLayout.LayoutParams(-1, 58));
        }

        Button back = new Button(this);
        back.setText("Back");
        back.setOnClickListener(v -> finish());
        root.addView(back, new LinearLayout.LayoutParams(-1, 58));
        setContentView(root);
    }

    private void renderSocial(LinearLayout root,TextView status,JSONArray a){
        status.setText("");
        int count=0;
        if(a!=null) for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String platform=x.optString("platform","").trim();String url=x.optString("url","").trim();if(platform.isEmpty()||!FeatureRegistry.isSafeHttpUrl(url))continue;Button b=new Button(this);b.setText(socialIcon(platform)+"  "+platform);b.setTextSize(14);b.setTextColor(Color.rgb(24,29,62));b.setAllCaps(false);b.setOnClickListener(v->openUrl(url));root.addView(b,new LinearLayout.LayoutParams(-1,60));count++;}
        if(count==0) status.setText("No social links have been saved by Admin yet.");
    }
    private String socialIcon(String p){String s=p.toLowerCase();if(s.contains("facebook"))return "ⓕ";if(s.contains("youtube"))return "▶";if(s.contains("tiktok"))return "♪";if(s.contains("instagram"))return "◎";if(s.contains("whatsapp"))return "◉";if(s.contains("telegram"))return "✈";return "●";}

    private void openUrl(String value) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(value.trim())));
        } catch (Exception e) {
            Toast.makeText(this, "Unable to open link.", Toast.LENGTH_SHORT).show();
        }
    }
}
