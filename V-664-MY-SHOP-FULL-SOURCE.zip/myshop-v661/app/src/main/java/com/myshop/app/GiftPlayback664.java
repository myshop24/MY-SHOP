package com.myshop.app;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;

/** Play each existing native gift's authored timeline once at main-stage duration. */
final class GiftPlayback664 {
 static void start(Drawable art,int duration){
  if(art instanceof GiftArt620)((GiftArt620)art).playOnce(duration);
  else if(art instanceof GiftArt619)((GiftArt619)art).playOnce(duration);
  else if(art instanceof FlowerGift653)((FlowerGift653)art).playOnce(duration);
  else if(art instanceof Animatable)((Animatable)art).start();
 }
}
