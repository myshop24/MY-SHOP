package com.myshop.app;
import android.widget.ImageView;
import android.widget.VideoView;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.AnimatedImageDrawable;
import android.os.Build;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
/** Gift-only readiness gate. Existing avatar/catalog loaders remain unchanged. */
final class GiftMedia661 {
 private static final java.util.concurrent.ThreadPoolExecutor IO=new java.util.concurrent.ThreadPoolExecutor(2,2,30,java.util.concurrent.TimeUnit.SECONDS,new java.util.concurrent.ArrayBlockingQueue<Runnable>(8),new java.util.concurrent.ThreadPoolExecutor.AbortPolicy());
 static void image(ImageView art,String url,Runnable ready){
  final Object ticket=new Object();art.setTag(ticket);final boolean[] done={false};
  final Runnable fallback=()->{if(!done[0]&&art.getTag()==ticket){done[0]=true;art.post(ready);}};
  art.postDelayed(fallback,1800);
  if(url==null||url.isEmpty()){fallback.run();return;}
  if(!url.startsWith("https://")&&!url.startsWith("asset://")){try{AnimatedAssetLoader.load(art,url);art.setTag(ticket);}catch(RuntimeException|OutOfMemoryError ignored){}fallback.run();return;}
  try{IO.execute(()->{HttpURLConnection c=null;try{
   if(url.startsWith("https://")){c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(5000);c.setReadTimeout(5000);}
   byte[] data;try(InputStream in=c==null?art.getContext().getAssets().open(url.substring(8)):c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n,total=0;while((n=in.read(buf))!=-1){total+=n;if(total>9*1024*1024)throw new java.io.IOException("Gift exceeds limit");out.write(buf,0,n);}data=out.toByteArray();}
   final Drawable drawable;if(Build.VERSION.SDK_INT>=28){drawable=ImageDecoder.decodeDrawable(ImageDecoder.createSource(ByteBuffer.wrap(data)),(d,info,src)->{int edge=Math.max(info.getSize().getWidth(),info.getSize().getHeight());if(edge>720){float f=720f/edge;d.setTargetSize(Math.max(1,Math.round(info.getSize().getWidth()*f)),Math.max(1,Math.round(info.getSize().getHeight()*f)));}});}else{Bitmap bitmap=BitmapFactory.decodeByteArray(data,0,data.length);if(bitmap==null)throw new java.io.IOException("Invalid gift image");drawable=new android.graphics.drawable.BitmapDrawable(art.getResources(),bitmap);}
   art.post(()->{if(done[0]||art.getTag()!=ticket)return;try{art.setImageDrawable(drawable);if(Build.VERSION.SDK_INT>=28&&drawable instanceof AnimatedImageDrawable)((AnimatedImageDrawable)drawable).start();}catch(RuntimeException|OutOfMemoryError ignored){}fallback.run();});
  }catch(Exception|OutOfMemoryError error){art.post(fallback);}finally{if(c!=null)c.disconnect();}});}catch(java.util.concurrent.RejectedExecutionException full){fallback.run();}
 }
 static void video(VideoView film,ImageView poster,String url,Runnable ready){
  final boolean[] done={false};final Object ticket=new Object();film.setTag(ticket);
  final Runnable fallback=()->{if(done[0]||film.getTag()!=ticket)return;done[0]=true;film.setTag(null);try{film.stopPlayback();}catch(RuntimeException ignored){}film.setVisibility(android.view.View.GONE);poster.setVisibility(android.view.View.VISIBLE);ready.run();};
  film.setVisibility(android.view.View.VISIBLE);film.setAlpha(0f);poster.postDelayed(fallback,1800);
  film.setOnPreparedListener(player->{if(done[0]||film.getTag()!=ticket)return;try{player.setVolume(0,0);film.setAlpha(1f);film.setVisibility(android.view.View.VISIBLE);film.start();poster.setVisibility(android.view.View.INVISIBLE);done[0]=true;ready.run();}catch(RuntimeException error){fallback.run();}});
  film.setOnErrorListener((p,w,e)->{if(!done[0])fallback.run();else{try{film.stopPlayback();}catch(RuntimeException ignored){}film.setVisibility(android.view.View.GONE);poster.setVisibility(android.view.View.VISIBLE);}return true;});
  try{film.setVideoURI(android.net.Uri.parse(url));}catch(RuntimeException error){fallback.run();}
 }
}
