package com.myshop.app;

import android.os.Handler;
import android.os.Looper;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

/** Small dependency-free HTTP client for the Cloudflare Worker backend. */
public final class BackendClient {
    private static final ExecutorService IO = Executors.newCachedThreadPool();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private BackendClient() {}

    public interface Callback { void onSuccess(JSONObject data); void onError(String message); }

    private static String baseUrl() { return BuildConfig.MYSHOP_BACKEND_URL == null ? "" : BuildConfig.MYSHOP_BACKEND_URL.trim().replaceAll("/$", ""); }
    public static boolean configured() { return !baseUrl().isEmpty() && !baseUrl().contains("YOUR-WORKER"); }

    public static void login(String identifier, String password, Callback cb) {
        try { JSONObject b=new JSONObject().put("identifier",identifier).put("password",password); post("/v1/auth/login",b,null,cb); }
        catch(Exception e){ cb.onError("Invalid login request"); }
    }

    public static void register(String name,String email,String mobile,String password,String question,String answer,Callback cb) {
        try {
            JSONObject b=new JSONObject().put("name",name).put("email",email).put("mobile",mobile).put("password",password).put("securityQuestion",question).put("securityAnswer",answer);
            post("/v1/auth/register",b,null,cb);
        } catch(Exception e){ cb.onError("Invalid registration request"); }
    }

    public static void resetPassword(String identifier,String answer,String newPassword,Callback cb) {
        try { JSONObject b=new JSONObject().put("identifier",identifier).put("answer",answer).put("newPassword",newPassword); post("/v1/auth/password/reset",b,null,cb); }
        catch(Exception e){ cb.onError("Invalid reset request"); }
    }

    public static void me(String token,Callback cb) { get("/v1/me",token,cb); }
    public static void securityQuestions(String identifier,Callback cb) {
        try { get("/v1/auth/password/questions?identifier=" + java.net.URLEncoder.encode(identifier,"UTF-8"), null, cb); }
        catch(Exception e){ cb.onError("Invalid identifier"); }
    }
    public static void dashboard(String token,Callback cb) { get("/v1/dashboard/config",token,cb); }
    public static void logout(String token,Callback cb) { post("/v1/auth/logout",new JSONObject(),token,cb); }
    public static void adminPermissions(String token, Callback cb) { get("/v1/admin/permissions", token, cb); }
    public static void adminDashboardPut(String token, String breakingNews, String myShopUrl, String liveTvUrl, String externalMovieUrl, String chatUrl, Callback cb) {
        try {
            JSONObject b = new JSONObject().put("breakingNews", breakingNews).put("myShopUrl", myShopUrl).put("liveTvUrl", liveTvUrl).put("externalMovieUrl", externalMovieUrl).put("chatUrl", chatUrl);
            request("PUT", "/v1/admin/dashboard/config", b, token, cb);
        } catch(Exception e) { cb.onError("Invalid admin settings"); }
    }
    public static void adminAction(String token, String userId, String action, Callback cb) {
        try {
            JSONObject b = new JSONObject().put("userId", userId).put("action", action);
            post("/v1/admin/actions", b, token, cb);
        } catch(Exception e) { cb.onError("Invalid admin action"); }
    }
    public static void adminContentPut(String token, JSONObject payload, Callback cb) { request("PUT", "/v1/admin/content", payload, token, cb); }
    public static void adminMediaList(String token, Callback cb) { get("/v1/admin/media", token, cb); }
    public static void adminBannerDelete(String token, String folder, int slot, Callback cb) { try { post("/v1/admin/banner/delete", new JSONObject().put("folder",folder).put("slot",slot), token, cb); } catch(Exception e) { cb.onError("Invalid banner slot"); } }
    public static void adminBannerUpdate(String token, String folder, int slot, String caption, Callback cb) { try { request("PUT", "/v1/admin/banner/update", new JSONObject().put("folder",folder).put("slot",slot).put("caption",caption), token, cb); } catch(Exception e) { cb.onError("Invalid banner update"); } }
    public static void adminBannerUpload(String token, java.io.InputStream input, String fileName, String mime, String folder, int slot, String caption, Callback cb) {
        uploadMultipart(token,"/v1/admin/banner/upload",input,fileName,mime,new String[][]{{"folder",folder},{"slot",String.valueOf(slot)},{"caption",caption}},cb);
    }
    public static void adminMediaDelete(String token, long id, Callback cb) { try { post("/v1/admin/media/delete", new JSONObject().put("id", id), token, cb); } catch(Exception e) { cb.onError("Invalid media id"); } }
    public static void adminMediaUpdate(String token, long id, String title, String caption, Callback cb) { try { request("PUT", "/v1/admin/media/update", new JSONObject().put("id",id).put("title",title).put("caption",caption), token, cb); } catch(Exception e) { cb.onError("Invalid media update"); } }

    public static void adminMediaUpload(String token, java.io.InputStream input, long length, String fileName, String mime, String folder, String title, String caption, int displayOrder, Callback cb) {
        IO.execute(() -> {
            HttpURLConnection c=null; String boundary="----MYSHOP"+System.currentTimeMillis();
            try {
                c=(HttpURLConnection)new URL(baseUrl()+"/v1/admin/media/upload").openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setDoOutput(true); c.setRequestProperty("Accept","application/json"); c.setRequestProperty("Authorization","Bearer "+token); c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
                try(OutputStream os=c.getOutputStream()) {
                    writePart(os,boundary,"folder",folder,null,null); writePart(os,boundary,"title",title,null,null); writePart(os,boundary,"caption",caption,null,null); writePart(os,boundary,"displayOrder",String.valueOf(displayOrder),null,null);
                    String safe=fileName==null?"media":fileName.replace("\"","_");
                    os.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\"file\"; filename=\""+safe+"\"\r\nContent-Type: "+(mime==null?"application/octet-stream":mime)+"\r\n\r\n").getBytes(StandardCharsets.UTF_8));
                    byte[] buf=new byte[8192]; int n; while((n=input.read(buf))!=-1) os.write(buf,0,n); os.write("\r\n".getBytes(StandardCharsets.UTF_8)); os.write(("--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8));
                } finally { try { input.close(); } catch(Exception ignored){} }
                int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream(); StringBuilder outText=new StringBuilder(); if(in!=null){try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)outText.append(line);}}
                JSONObject out=outText.length()>0?new JSONObject(outText.toString()):new JSONObject(); MAIN.post(() -> {if(code>=200&&code<300)cb.onSuccess(out);else cb.onError(errorText(out,code));});
            } catch(Exception e){ MAIN.post(() -> cb.onError("Media upload failed: "+e.getMessage())); } finally {if(c!=null)c.disconnect();}
        });
    }
    private static void uploadMultipart(String token,String path,java.io.InputStream input,String fileName,String mime,String[][] fields,Callback cb){
        IO.execute(() -> { HttpURLConnection c=null; String boundary="----MYSHOP"+System.currentTimeMillis(); try {
            c=(HttpURLConnection)new URL(baseUrl()+path).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setDoOutput(true); c.setRequestProperty("Accept","application/json"); c.setRequestProperty("Authorization","Bearer "+token); c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
            try(OutputStream os=c.getOutputStream()){ if(fields!=null)for(String[] f:fields)writePart(os,boundary,f[0],f[1],null,null); String safe=fileName==null?"media":fileName.replace("\"","_"); os.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\"file\"; filename=\""+safe+"\"\r\nContent-Type: "+(mime==null?"application/octet-stream":mime)+"\r\n\r\n").getBytes(StandardCharsets.UTF_8)); byte[] buf=new byte[8192];int n;while((n=input.read(buf))!=-1)os.write(buf,0,n);os.write("\r\n".getBytes(StandardCharsets.UTF_8));os.write(("--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8)); } finally {try{input.close();}catch(Exception ignored){}}
            int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();StringBuilder st=new StringBuilder();if(in!=null){try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)st.append(line);}} JSONObject out=st.length()>0?new JSONObject(st.toString()):new JSONObject();MAIN.post(()->{if(code>=200&&code<300)cb.onSuccess(out);else cb.onError(errorText(out,code));});
        }catch(Exception e){MAIN.post(()->cb.onError("Upload failed: "+e.getMessage()));}finally{if(c!=null)c.disconnect();}});
    }

    private static void writePart(OutputStream os,String boundary,String name,String value,String ignored1,String ignored2) throws Exception { String v=value==null?"":value; os.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\""+name+"\"\r\n\r\n"+v+"\r\n").getBytes(StandardCharsets.UTF_8)); }

    private static void get(String path,String token,Callback cb) { request("GET",path,null,token,cb); }
    private static void post(String path,JSONObject body,String token,Callback cb) { request("POST",path,body,token,cb); }

    private static void request(String method,String path,JSONObject body,String token,Callback cb) {
        if(!configured()){ cb.onError("Backend URL is not configured yet."); return; }
        IO.execute(() -> {
            HttpURLConnection c=null;
            try {
                c=(HttpURLConnection)new URL(baseUrl()+path).openConnection(); c.setRequestMethod(method); c.setConnectTimeout(12000); c.setReadTimeout(15000); c.setRequestProperty("Accept","application/json");
                if(token!=null&&!token.isEmpty()) c.setRequestProperty("Authorization","Bearer "+token);
                if(body!=null){ c.setRequestProperty("Content-Type","application/json; charset=utf-8"); c.setDoOutput(true); try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));} }
                int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream(); StringBuilder s=new StringBuilder();
                if(in!=null){try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)s.append(line);}}
                JSONObject out=s.length()>0?new JSONObject(s.toString()):new JSONObject();
                MAIN.post(() -> { if(code>=200&&code<300) cb.onSuccess(out); else cb.onError(errorText(out,code)); });
            } catch(Exception e){ MAIN.post(() -> cb.onError("Backend connection failed. Check internet/Worker URL.")); }
            finally { if(c!=null)c.disconnect(); }
        });
    }
    private static String errorText(JSONObject o,int code){ String e=o.optString("error",""); if("ACCOUNT_EXISTS".equals(e))return "এই Email/Mobile দিয়ে Account আগে থেকেই আছে।"; if("INVALID_CREDENTIALS".equals(e))return "Login ID অথবা Password ভুল।"; if("ANSWER_NOT_MATCHED".equals(e))return "সিকিউরিটি উত্তর সঠিক নয়।"; if("NO_ID_AVAILABLE".equals(e))return "নতুন User ID পাওয়া যাচ্ছে না।"; if("R2_NOT_CONFIGURED".equals(e))return "R2 storage is not configured on the Worker."; if("MEDIA_TOO_LARGE".equals(e))return "Media file is too large (max 50 MB)."; if("MEDIA_TYPE_MISMATCH".equals(e))return "Selected file type does not match the selected Gallery folder."; return e.isEmpty()?"Server error ("+code+")":e; }
}
