package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Admin R2 banner manager: 6 hero slots + 3 promo slots. */
public class BannerAdminActivity extends AppCompatActivity {
    private LinearLayout root; private String folder="hero"; private int slot=1; private final Map<String,String> current=new HashMap<>();
    @Override protected void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)){finish();return;}build();load();}
    private void build(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(16,16,16,24);root.setBackgroundColor(Color.rgb(247,248,252));TextView h=t("MY SHOP • BANNER MANAGER",22,Color.rgb(83,32,180),true);h.setGravity(Gravity.CENTER);root.addView(h,lp(-1,54));TextView n=t("R2 upload • Hero 1-6 / Promo 1-3 • Admin only",12,Color.DKGRAY,false);n.setGravity(Gravity.CENTER);root.addView(n,lp(-1,30));ScrollView s=new ScrollView(this);LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.addView(section("HERO BANNERS • 6"));for(int i=1;i<=6;i++)slotRow(content,"hero",i,"Hero "+i);content.addView(section("PROMO BANNERS • 3"));for(int i=1;i<=3;i++)slotRow(content,"promo",i,"Promo "+i);s.addView(content);root.addView(s,lp(-1,0,1));Button back=btn("BACK");back.setOnClickListener(v->finish());root.addView(back,lp(-1,50));setContentView(root);}
    private void slotRow(LinearLayout c,String f,int sl,String label){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);TextView name=t(label,14,Color.BLACK,true);r.addView(name,wt(1));Button up=btn("UPLOAD");up.setOnClickListener(v->{folder=f;slot=sl;pick();});Button del=btn("DELETE");del.setOnClickListener(v->{folder=f;slot=sl;confirmDelete();});r.addView(up,lp(100,48));r.addView(del,lp(100,48));c.addView(r,lp(-1,58));}
    private void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,800);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r!=800||c!=RESULT_OK||d==null||d.getData()==null)return;Uri u=d.getData();showCaption(u);}
    private void showCaption(Uri u){EditText e=new EditText(this);e.setHint("Banner caption");new AlertDialog.Builder(this).setTitle("Upload "+folder+" slot "+slot).setView(e).setPositiveButton("UPLOAD",(d,w)->upload(u,e.getText().toString())).setNegativeButton("CANCEL",null).show();}
    private void upload(Uri u,String caption){try{InputStream in=getContentResolver().openInputStream(u);String mime=getContentResolver().getType(u);String name="banner.jpg";BackendClient.adminBannerUpload(SessionManager.getToken(this),in,name,mime,folder,slot,caption,new BackendClient.Callback(){public void onSuccess(org.json.JSONObject d){runOnUiThread(()->Toast.makeText(BannerAdminActivity.this,"Banner saved.",Toast.LENGTH_SHORT).show());}public void onError(String m){runOnUiThread(()->Toast.makeText(BannerAdminActivity.this,m,Toast.LENGTH_SHORT).show());}});}catch(Exception e){Toast.makeText(this,"Cannot open image.",Toast.LENGTH_SHORT).show();}}
    private void confirmDelete(){new AlertDialog.Builder(this).setTitle("Delete banner?").setMessage("The slot and its R2 object will be removed.").setPositiveButton("DELETE",(d,w)->BackendClient.adminBannerDelete(SessionManager.getToken(this),folder,slot,new BackendClient.Callback(){public void onSuccess(org.json.JSONObject x){runOnUiThread(()->Toast.makeText(BannerAdminActivity.this,"Deleted.",Toast.LENGTH_SHORT).show());}public void onError(String m){runOnUiThread(()->Toast.makeText(BannerAdminActivity.this,m,Toast.LENGTH_SHORT).show());}})).setNegativeButton("CANCEL",null).show();}
    private TextView section(String s){TextView t=t(s,16,Color.rgb(83,32,180),true);t.setPadding(0,12,0,6);return t;}private TextView t(String s,float z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return t;}private Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams lp(int w,int h,float wt){return new LinearLayout.LayoutParams(w,h,wt);}private LinearLayout.LayoutParams wt(float w){return new LinearLayout.LayoutParams(0,48,w);}private void load(){BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(org.json.JSONObject d){}public void onError(String m){}});}
}
