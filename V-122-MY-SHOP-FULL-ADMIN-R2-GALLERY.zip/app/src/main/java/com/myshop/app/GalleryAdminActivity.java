package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.ArrayList;

/** Admin-only R2 gallery manager. Three folders: PHOTO, AUDIO, VIDEO. */
public class GalleryAdminActivity extends AppCompatActivity {
    private LinearLayout list; private String folder="photo"; private final ArrayList<JSONObject> rows=new ArrayList<>();
    private final int PURPLE=Color.rgb(83,32,180), BG=Color.rgb(247,248,252);
    @Override protected void onCreate(Bundle b){super.onCreate(b); if(!SessionManager.isAdmin(this)){finish();return;} build(); load();}
    private void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(16,16,16,24);root.setBackgroundColor(BG);
        TextView h=txt("MY SHOP • GALLERY MANAGER",22,PURPLE,true);h.setGravity(Gravity.CENTER);root.addView(h,lp(-1,54));
        TextView n=txt("R2 storage • Admin only • Photo / Audio / Video",12,Color.DKGRAY,false);n.setGravity(Gravity.CENTER);root.addView(n,lp(-1,30));
        LinearLayout tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.HORIZONTAL);String[] fs={"photo","audio","video"};String[] ls={"PHOTO","AUDIO","VIDEO"};for(int i=0;i<3;i++){Button bt=button(ls[i]);final String f=fs[i];bt.setOnClickListener(v->{folder=f;load();});tabs.addView(bt,weight(1));}root.addView(tabs,lp(-1,52));
        Button add=button("＋ ADD / UPLOAD MEDIA");add.setOnClickListener(v->pick());root.addView(add,lp(-1,54));
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(list);root.addView(sv,lp(-1,0,1));
        Button back=button("BACK");back.setOnClickListener(v->finish());root.addView(back,lp(-1,50));setContentView(root);
    }
    private void load(){BackendClient.adminMediaList(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{rows.clear();try{JSONArray a=d.optJSONArray("media");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&folder.equalsIgnoreCase(x.optString("folder","")))rows.add(x);}render();}catch(Exception e){toast("Gallery read error");}});}public void onError(String m){runOnUiThread(()->toast("Gallery load: "+m));}});}
    private void render(){list.removeAllViews();if(rows.isEmpty()){TextView e=txt("No media in this folder yet. Tap ADD / UPLOAD MEDIA.",14,Color.DKGRAY,false);e.setPadding(10,30,10,30);list.addView(e);return;}for(JSONObject x:rows){LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(12,8,12,8);card.setBackgroundColor(Color.WHITE);TextView t=txt(x.optString("title","Untitled"),16,Color.BLACK,true);card.addView(t);TextView c=txt(x.optString("caption",""),12,Color.DKGRAY,false);card.addView(c);TextView u=txt(x.optString("media_url",""),10,Color.GRAY,false);card.addView(u);Button del=button("DELETE");long id=x.optLong("id",0);del.setOnClickListener(v->confirmDelete(id));card.addView(del,lp(-1,44));list.addView(card,lp(-1,dp(132)));} }
    private void pick(){String mime=folder.equals("photo")?"image/*":folder.equals("audio")?"audio/*":"video/*";Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType(mime);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,700);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r!=700||c!=RESULT_OK||d==null||d.getData()==null)return;Uri uri=d.getData();showMeta(uri);}
    private void showMeta(Uri uri){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(20,4,20,4);EditText title=field("Title");EditText caption=field("Caption");box.addView(title);box.addView(caption);new AlertDialog.Builder(this).setTitle("Upload to "+folder.toUpperCase()).setView(box).setPositiveButton("UPLOAD",(x,w)->upload(uri,title.getText().toString(),caption.getText().toString())).setNegativeButton("CANCEL",null).show();}
    private void upload(Uri uri,String title,String caption){try{InputStream in=getContentResolver().openInputStream(uri);String mime=getContentResolver().getType(uri);String name=fileName(uri);BackendClient.adminMediaUpload(SessionManager.getToken(this),in,-1,name,mime,folder,title,caption,rows.size()+1,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{toast("Uploaded successfully.");load();});}public void onError(String m){runOnUiThread(()->toast(m));}});}catch(Exception e){toast("Cannot open selected file.");}}
    private void confirmDelete(long id){new AlertDialog.Builder(this).setTitle("Delete media?").setMessage("This removes the gallery record and the R2 object.").setPositiveButton("DELETE",(d,w)->BackendClient.adminMediaDelete(SessionManager.getToken(this),id,new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->{toast("Deleted.");load();});}public void onError(String m){runOnUiThread(()->toast("Delete failed: "+m));}})).setNegativeButton("CANCEL",null).show();}
    private String fileName(Uri u){Cursor c=getContentResolver().query(u,null,null,null,null);if(c!=null)try{int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(c.moveToFirst()&&i>=0)return c.getString(i);}finally{c.close();}return "media";}
    private EditText field(String h){EditText e=new EditText(this);e.setHint(h);e.setSingleLine(true);return e;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
    private TextView txt(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return t;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams lp(int w,int h,float wt){return new LinearLayout.LayoutParams(w,h,wt);}private LinearLayout.LayoutParams weight(float w){return new LinearLayout.LayoutParams(0,52,w);}private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
