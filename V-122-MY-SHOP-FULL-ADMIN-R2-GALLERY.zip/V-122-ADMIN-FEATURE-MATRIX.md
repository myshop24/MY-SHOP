# V-122 Admin feature matrix

| Area | Admin action |
|---|---|
| Breaking News | edit / save |
| Hero banners 1-6 | URL edit + R2 upload + delete |
| Promo banners 1-3 | URL edit + R2 upload + delete |
| Dashboard features | rename / URL / icon URL / show-hide / save |
| Social links | add / edit / delete / enable-disable |
| Gallery | PHOTO / AUDIO / VIDEO folders; upload / caption / delete |
| Live TV | managed links |
| External Movie | managed links |
| More Apps | managed links |
| Payment Methods | managed links |
| Moderators | add / remove |
| Languages | বাংলা / English / हिन्दी / العربية |

No admin action in V-122 drops, clears, or recreates the user/auth tables.
