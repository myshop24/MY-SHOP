# MY SHOP V-61 — CLEAN SINGLE SOURCE PACKAGE

This ZIP contains ONE Android project only.

Upload/extract the contents of this ZIP into the GitHub repository root.
Do NOT upload this ZIP as an APK and do NOT upload any APK from an older release.

Expected GitHub Actions output:
- MY_SHOP_V61_RELEASE.apk (exactly one APK)
- versionCode 61
- versionName 2.9.61

Older V-59/V-60 backups must remain untouched.
