package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

/** V-61: Admin-only local CRUD shell. Production shared CRUD still requires the configured backend. */
public class AdminManagementActivity extends AppCompatActivity {
    private boolean moderatorOnly;
    private LinearLayout listBox;
    private String activeType = "banners";
    private static final int PICK_MEDIA = 7001;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        moderatorOnly=getIntent().getBooleanExtra("moderator_only",false);
        if (moderatorOnly ? !SessionManager.isModerator(this) : !SessionManager.isAdmin(this)) { finish(); return; }
        buildUi();
    }

    private void buildUi() {
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(10,10,10,8); root.setBackgroundColor(0xFFF8F9FC);
        TextView title=new TextView(this); title.setText(moderatorOnly?"Moderator Controls":"Admin Panel — Upload / Edit / Delete"); title.setTextSize(20); title.setTextColor(0xFF6224E1); title.setTypeface(null,1); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,56));
        if(moderatorOnly){ addAction(root,"Ban User ID",()->toast("Ban action requires backend authorization.")); addAction(root,"Kick User",()->toast("Kick action requires backend authorization.")); addAction(root,"Close Live",()->toast("Close Live requires backend authorization.")); }
        else {
            LinearLayout tabs=new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL);
            String[] names={"Banners","Breaking News","Gallery","Social","Live TV"}; String[] types={"banners","breaking_news","gallery","social_links","live_tv"};
            for(int i=0;i<names.length;i++){ final String t=types[i]; Button b=new Button(this); b.setText(names[i]); b.setAllCaps(false); b.setTextSize(11); b.setOnClickListener(v->{activeType=t; refreshList();}); tabs.addView(b,new LinearLayout.LayoutParams(0,52,1)); }
            root.addView(tabs);
            LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
            Button add=new Button(this); add.setText("＋ Add / Upload"); add.setAllCaps(false); add.setOnClickListener(v->addItem());
            Button refresh=new Button(this); refresh.setText("Refresh"); refresh.setOnClickListener(v->refreshList());
            actions.addView(add,new LinearLayout.LayoutParams(0,52,1)); actions.addView(refresh,new LinearLayout.LayoutParams(0,52,1)); root.addView(actions);
            ScrollView scroll=new ScrollView(this); listBox=new LinearLayout(this); listBox.setOrientation(LinearLayout.VERTICAL); scroll.addView(listBox); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
            Button back=new Button(this); back.setText("Back"); back.setOnClickListener(v->finish()); root.addView(back,new LinearLayout.LayoutParams(-1,50)); refreshList();
        }
        setContentView(root);
    }

    private void addAction(LinearLayout root,String label,final Runnable r){ Button b=new Button(this); b.setText(label); b.setAllCaps(false); b.setOnClickListener(v->r.run()); root.addView(b,new LinearLayout.LayoutParams(-1,58)); }

    private void addItem(){
        if(!SessionManager.isAdmin(this)){toast("Admin permission required.");return;}
        if("gallery".equals(activeType) || "banners".equals(activeType)){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivityForResult(i,PICK_MEDIA); return; }
        final EditText input=new EditText(this); input.setHint("Enter content");
        new AlertDialog.Builder(this).setTitle("Add "+activeType).setView(input).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String s=input.getText().toString().trim();if(s.isEmpty())return;if(!BackendConfig.isConfigured()){toast("Cloudflare backend is not configured.");return;}try{org.json.JSONObject b=new org.json.JSONObject();b.put("type",activeType);b.put("title",s);b.put("value",s);BackendClient.postJson("/api/admin/content",b,SessionManager.getBackendToken(this),(r,e)->runOnUiThread(()->{toast(e==null?"Saved to backend":"Save failed: "+e.getMessage());refreshList();}));}catch(Exception e){toast("Request failed");}}).show();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==PICK_MEDIA&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){ Uri uri=data.getData(); if(!BackendConfig.isConfigured()){toast("Cloudflare backend is not configured.");return;} BackendClient.upload(this,uri,SessionManager.getBackendToken(this),(r,e)->runOnUiThread(()->{if(e!=null){toast("Upload failed: "+e.getMessage());return;}try{org.json.JSONObject b=new org.json.JSONObject();b.put("type",activeType);b.put("title",uri.getLastPathSegment()==null?"Media":uri.getLastPathSegment());b.put("value",r.getString("key"));BackendClient.postJson("/api/admin/content",b,SessionManager.getBackendToken(this),(r2,e2)->runOnUiThread(()->{toast(e2==null?"Uploaded to backend":"Metadata save failed");refreshList();}));}catch(Exception ex){toast("Upload response invalid");}})); }}

    private void editItem(AdminContentStore.Item item){ EditText input=new EditText(this);input.setSingleLine(true);input.setText(item.title);new AlertDialog.Builder(this).setTitle("Edit "+activeType).setView(input).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{if(!BackendConfig.isConfigured()){toast("Cloudflare backend is not configured.");return;}try{org.json.JSONObject b=new org.json.JSONObject();b.put("title",input.getText().toString().trim());b.put("value",item.value);BackendClient.putJson("/api/admin/content/"+item.id,b,SessionManager.getBackendToken(this),(r,e)->runOnUiThread(()->{toast(e==null?"Updated":"Update failed");refreshList();}));}catch(Exception e){toast("Request failed");}}).show(); }

    private void refreshList(){ if(listBox==null)return; if(!BackendConfig.isConfigured()){listBox.removeAllViews();TextView e=new TextView(this);e.setText("Cloudflare backend is not configured. Deploy Worker and set BackendConfig.BASE_URL.");e.setPadding(12,24,12,24);listBox.addView(e);return;} BackendClient.get("/api/admin/content?type="+activeType,SessionManager.getBackendToken(this),(r,e)->runOnUiThread(()->{listBox.removeAllViews();if(e!=null){toast("Load failed: "+e.getMessage());return;}try{org.json.JSONArray a=r.getJSONArray("items");for(int i=0;i<a.length();i++){org.json.JSONObject o=a.getJSONObject(i);AdminContentStore.Item item=new AdminContentStore.Item(o.getString("id"),activeType,o.optString("title"),o.optString("value"));LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView t=new TextView(this);t.setText(item.title);t.setTextSize(13);t.setPadding(8,4,8,4);Button edit=new Button(this);edit.setText("Edit");edit.setOnClickListener(v->editItem(item));Button del=new Button(this);del.setText("Delete");del.setOnClickListener(v->{BackendClient.delete("/api/admin/content/"+item.id,SessionManager.getBackendToken(this),(rr,ee)->runOnUiThread(()->{toast(ee==null?"Deleted":"Delete failed");refreshList();}));});row.addView(t,new LinearLayout.LayoutParams(0,58,1));row.addView(edit,new LinearLayout.LayoutParams(80,52));row.addView(del,new LinearLayout.LayoutParams(86,52));listBox.addView(row,new LinearLayout.LayoutParams(-1,58));}if(a.length()==0){TextView empty=new TextView(this);empty.setText("No backend items yet.");empty.setPadding(12,24,12,24);listBox.addView(empty);}}catch(Exception ex){toast("Invalid backend response");}})); }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
