package com.myshop.app;

import android.content.Context;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Small dependency-free HTTP client for the Cloudflare Worker API. */
public final class BackendClient {
    public interface Callback { void done(JSONObject data, Exception error); }
    private static final ExecutorService IO = Executors.newCachedThreadPool();
    private BackendClient(){}
    public static void postJson(String path, JSONObject body, String token, Callback cb){ request("POST",path,body,token,cb); }
    public static void putJson(String path, JSONObject body, String token, Callback cb){ request("PUT",path,body,token,cb); }
    public static void get(String path, String token, Callback cb){ request("GET",path,null,token,cb); }
    public static void delete(String path, String token, Callback cb){ request("DELETE",path,null,token,cb); }
    private static void request(String method,String path,JSONObject body,String token,Callback cb){
        if(!BackendConfig.isConfigured()){ cb.done(null,new IllegalStateException("Backend URL is not configured.")); return; }
        IO.execute(()->{
            HttpURLConnection c=null;
            try{
                URL u=new URL(BackendConfig.BASE_URL.replaceAll("/$","")+path); c=(HttpURLConnection)u.openConnection(); c.setRequestMethod(method); c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setRequestProperty("Accept","application/json");
                if(token!=null&&!token.isEmpty()) c.setRequestProperty("Authorization","Bearer "+token);
                if(body!=null){c.setRequestProperty("Content-Type","application/json; charset=utf-8");c.setDoOutput(true);try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}}
                int code=c.getResponseCode(); InputStream in=code>=400?c.getErrorStream():c.getInputStream(); String s=read(in); JSONObject r=s.isEmpty()?new JSONObject():new JSONObject(s); if(code>=400)throw new IOException(r.optString("error","HTTP "+code)); cb.done(r,null);
            }catch(Exception e){cb.done(null,e);}finally{if(c!=null)c.disconnect();}
        });
    }
    private static String read(InputStream in)throws IOException{if(in==null)return "";StringBuilder s=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String x;while((x=r.readLine())!=null)s.append(x);}return s.toString();}

    public static void upload(Context ctx, Uri uri, String token, Callback cb){
        if(!BackendConfig.isConfigured()){cb.done(null,new IllegalStateException("Backend URL is not configured."));return;}
        IO.execute(()->{HttpURLConnection c=null;try{
            String boundary="----MYSHOP"+System.currentTimeMillis();URL u=new URL(BackendConfig.BASE_URL.replaceAll("/$","")+"/api/media");c=(HttpURLConnection)u.openConnection();c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(15000);c.setReadTimeout(30000);c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
            String name=uri.getLastPathSegment()==null?"media.bin":uri.getLastPathSegment();String mime=ctx.getContentResolver().getType(uri);if(mime==null)mime="application/octet-stream";
            try(OutputStream out=c.getOutputStream();InputStream in=ctx.getContentResolver().openInputStream(uri)){PrintWriter w=new PrintWriter(new OutputStreamWriter(out,StandardCharsets.UTF_8),true);w.append("--").append(boundary).append("\r\n");w.append("Content-Disposition: form-data; name=\"file\"; filename=\"").append(name.replace("\"","_" )).append("\"\r\n");w.append("Content-Type: ").append(mime).append("\r\n\r\n").flush();byte[] buf=new byte[8192];int n;while(in!=null&&(n=in.read(buf))>0)out.write(buf,0,n);out.write(("\r\n--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8));out.flush();}
            int code=c.getResponseCode();String s=read(code>=400?c.getErrorStream():c.getInputStream());JSONObject r=s.isEmpty()?new JSONObject():new JSONObject(s);if(code>=400)throw new IOException(r.optString("error","HTTP "+code));cb.done(r,null);
        }catch(Exception e){cb.done(null,e);}finally{if(c!=null)c.disconnect();}});
    }
}
