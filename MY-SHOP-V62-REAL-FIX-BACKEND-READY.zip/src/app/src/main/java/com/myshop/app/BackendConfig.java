package com.myshop.app;

/** Set this to the deployed MY SHOP Cloudflare Worker URL before the release build. */
public final class BackendConfig {
    public static final String BASE_URL = ""; // e.g. https://my-shop-v62-api.<account>.workers.dev
    private BackendConfig() {}
    public static boolean isConfigured(){ return BASE_URL != null && !BASE_URL.trim().isEmpty(); }
}
