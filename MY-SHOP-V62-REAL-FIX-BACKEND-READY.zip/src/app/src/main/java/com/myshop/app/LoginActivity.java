package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.app.AlertDialog;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** V-54: MY SHOP + LIVE login; backend role check is authoritative. */
public class LoginActivity extends AppCompatActivity {
    private static final String BRAND = "MY SHOP";
    private EditText loginId;
    private EditText loginPassword;
    private TextView emailTab, mobileTab, loginPrefix, languageBn, languageEn, languageHi, languageAr;
    private boolean mobileMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // V-47: preserve the existing account/session across normal app updates.
        // This only works when Android performs an in-place update with the same signing key.
        String existingId = SessionManager.getUserId(this);
        if (SessionManager.isLoggedIn(this) && !existingId.isEmpty() && (BackendConfig.isConfigured() ? !SessionManager.getBackendToken(this).isEmpty() : AccountStore.exists(this, existingId))) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        loginId = findViewById(R.id.loginId);
        loginPassword = findViewById(R.id.loginPassword);
        Button login = findViewById(R.id.loginButton);
        TextView create = findViewById(R.id.createAccountButton);
        TextView forgot = findViewById(R.id.forgotButton);
        ImageButton toggle = findViewById(R.id.passwordToggle);
        emailTab = findViewById(R.id.emailTab);
        mobileTab = findViewById(R.id.mobileTab);
        loginPrefix = findViewById(R.id.loginPrefix);
        languageBn = findViewById(R.id.languageBn);
        languageEn = findViewById(R.id.languageEn);
        languageHi = findViewById(R.id.languageHi);
        languageAr = findViewById(R.id.languageAr);
        languageBn.setOnClickListener(v -> { LanguageManager.set(this, LanguageManager.BN); applyLanguage(); });
        languageEn.setOnClickListener(v -> { LanguageManager.set(this, LanguageManager.EN); applyLanguage(); });
        languageHi.setOnClickListener(v -> { LanguageManager.set(this, LanguageManager.HI); applyLanguage(); });
        languageAr.setOnClickListener(v -> { LanguageManager.set(this, LanguageManager.AR); applyLanguage(); });
        emailTab.setOnClickListener(v -> setLoginMode(false));
        mobileTab.setOnClickListener(v -> setLoginMode(true));
        setLoginMode(false);
        applyLanguage();

        create.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
        login.setOnClickListener(v -> login());
        forgot.setOnClickListener(v -> showForgotPassword());
        toggle.setOnClickListener(v -> {
            int pos = loginPassword.getSelectionStart();
            boolean hidden = (loginPassword.getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) != 0;
            loginPassword.setInputType(InputType.TYPE_CLASS_TEXT | (hidden ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            loginPassword.setSelection(Math.max(0, pos));
        });
    }


    private void applyLanguage() {
        String l=LanguageManager.get(this);
        boolean bn=LanguageManager.BN.equals(l), hi=LanguageManager.HI.equals(l), ar=LanguageManager.AR.equals(l);
        emailTab.setText(bn ? "✉  ইমেইল লগইন" : hi ? "✉  ईमेल लॉगिन" : ar ? "✉  تسجيل البريد" : "✉  Email Login");
        mobileTab.setText(bn ? "▣  মোবাইল লগইন" : hi ? "▣  मोबाइल लॉगिन" : ar ? "▣  تسجيل الهاتف" : "▣  Mobile Login");
        loginPassword.setHint(bn ? "আপনার পাসওয়ার্ড লিখুন" : hi ? "पासवर्ड दर्ज करें" : ar ? "أدخل كلمة المرور" : "Enter your password");
        loginId.setHint(bn ? (mobileMode ? "1XXXXXXXXX" : "আপনার ইমেইল লিখুন") : hi ? (mobileMode ? "1XXXXXXXXX" : "अपना ईमेल दर्ज करें") : ar ? (mobileMode ? "1XXXXXXXXX" : "أدخل بريدك الإلكتروني") : (mobileMode ? "1XXXXXXXXX" : "Enter your email"));
        ((Button)findViewById(R.id.loginButton)).setText(bn ? "লগইন  →" : hi ? "लॉगिन  →" : ar ? "تسجيل الدخول  →" : "LOGIN  →");
        ((TextView)findViewById(R.id.createAccountButton)).setText(bn ? "＋  অ্যাকাউন্ট খুলুন" : hi ? "＋  खाता बनाएँ" : ar ? "＋  إنشاء حساب" : "＋  CREATE ACCOUNT");
        ((TextView)findViewById(R.id.forgotButton)).setText(bn ? "পাসওয়ার্ড ভুলে গেছেন?" : hi ? "पासवर्ड भूल गए?" : ar ? "هل نسيت كلمة المرور؟" : "Forgot Password?");
        int active=0xFF6224E1,inactive=0xFFE8EAF0,dark=0xFF30384A;
        languageBn.setBackgroundColor(bn?active:inactive); languageBn.setTextColor(bn?0xFFFFFFFF:dark);
        languageEn.setBackgroundColor(!bn&&!hi&&!ar?active:inactive); languageEn.setTextColor(!bn&&!hi&&!ar?0xFFFFFFFF:dark);
        languageHi.setBackgroundColor(hi?active:inactive); languageHi.setTextColor(hi?0xFFFFFFFF:dark);
        languageAr.setBackgroundColor(ar?active:inactive); languageAr.setTextColor(ar?0xFFFFFFFF:dark);
    }

    private void setLoginMode(boolean mobile) {
        mobileMode = mobile;
        if (mobile) {
            loginId.setHint("1XXXXXXXXX");
            loginId.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
            loginPrefix.setText("+880  ▾");
            loginPrefix.setVisibility(TextView.VISIBLE);
            mobileTab.setTextColor(android.graphics.Color.WHITE);
            mobileTab.setBackgroundResource(com.myshop.app.R.drawable.bg_mobile_active);
            emailTab.setTextColor(android.graphics.Color.DKGRAY);
            emailTab.setBackgroundResource(com.myshop.app.R.drawable.bg_email_inactive);
        } else {
            loginId.setHint("enter@example.com");
            loginId.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
            loginPrefix.setText("");
            loginPrefix.setVisibility(TextView.GONE);
            emailTab.setTextColor(android.graphics.Color.WHITE);
            emailTab.setBackgroundResource(com.myshop.app.R.drawable.bg_email_tab);
            mobileTab.setTextColor(android.graphics.Color.DKGRAY);
            mobileTab.setBackgroundResource(com.myshop.app.R.drawable.bg_mobile_tab);
        }
    }


    private void showForgotPassword() {
        final EditText identifierInput = new EditText(this);
        identifierInput.setSingleLine(true);
        identifierInput.setHint("Email / Mobile / User ID");
        new AlertDialog.Builder(this)
                .setTitle("Forgot Password?")
                .setMessage("OTP নেই। আপনার ৩টি Security Question দিয়ে Password reset করুন।")
                .setView(identifierInput)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Continue", (d, which) -> verifySecurity(identifierInput.getText().toString().trim()))
                .show();
    }

    private void verifySecurity(String identifier) {
        if (identifier.isEmpty()) { Toast.makeText(this, "Identifier দিন।", Toast.LENGTH_SHORT).show(); return; }
        if (BackendConfig.isConfigured()) {
            org.json.JSONObject b=new org.json.JSONObject(); try{b.put("identifier",identifier);}catch(Exception ignored){}
            BackendClient.postJson("/api/forgot/questions",b,"",(data,error)->runOnUiThread(()->{ if(error!=null){Toast.makeText(this,"Account not found.",Toast.LENGTH_LONG).show();return;} try{org.json.JSONArray a=data.getJSONArray("questions"); showRemoteReset(identifier,new String[]{a.optString(0),a.optString(1),a.optString(2)});}catch(Exception e){Toast.makeText(this,"Questions unavailable.",Toast.LENGTH_LONG).show();} }));
            return;
        }
        String[] q = AccountStore.getSecurityQuestions(this, identifier);
        if (q.length != 3 || q[0].isEmpty() || q[1].isEmpty() || q[2].isEmpty()) {
            Toast.makeText(this, "এই Account-এর Security Questions পাওয়া যায়নি।", Toast.LENGTH_LONG).show();
            return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int)(16 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, 0, pad, 0);
        EditText a1 = answerField(q[0]); box.addView(a1);
        EditText a2 = answerField(q[1]); box.addView(a2);
        EditText a3 = answerField(q[2]); box.addView(a3);
        EditText np = answerField("নতুন Password (কমপক্ষে ৬ অক্ষর)"); np.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD); box.addView(np);
        new AlertDialog.Builder(this)
                .setTitle("Security Verification")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("RESET PASSWORD", (d, which) -> {
                    boolean ok = AccountStore.resetPasswordWithSecurity(this, identifier, a1.getText().toString(), a2.getText().toString(), a3.getText().toString(), np.getText().toString());
                    Toast.makeText(this, ok ? "Password reset successful." : "Security answers or new password are incorrect.", Toast.LENGTH_LONG).show();
                })
                .show();
    }

    private void showRemoteReset(String identifier,String[] q){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); int pad=(int)(16*getResources().getDisplayMetrics().density); box.setPadding(pad,0,pad,0);
        EditText a1=answerField(q[0]),a2=answerField(q[1]),a3=answerField(q[2]),np=answerField("New Password (6+ characters)"); np.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD); box.addView(a1);box.addView(a2);box.addView(a3);box.addView(np);
        new AlertDialog.Builder(this).setTitle("Security Verification").setMessage("Any 2 of the 3 answers must be correct.").setView(box).setNegativeButton("Cancel",null).setPositiveButton("RESET PASSWORD",(d,w)->{try{org.json.JSONObject b=new org.json.JSONObject();b.put("identifier",identifier);b.put("a1",a1.getText().toString());b.put("a2",a2.getText().toString());b.put("a3",a3.getText().toString());b.put("newPassword",np.getText().toString());BackendClient.postJson("/api/forgot/reset",b,"",(data,error)->runOnUiThread(()->Toast.makeText(this,error==null?"Password reset successful.":"At least 2 correct answers are required.",Toast.LENGTH_LONG).show()));}catch(Exception e){Toast.makeText(this,"Reset request failed.",Toast.LENGTH_LONG).show();}}).show();
    }

    private EditText answerField(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextSize(15);
        return e;
    }

    private void login() {
        String identifier = loginId.getText().toString().trim();
        String pass = loginPassword.getText().toString();
        if (identifier.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Email/Mobile and Password are required.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            if (BackendConfig.isConfigured()) {
                org.json.JSONObject body=new org.json.JSONObject(); body.put("identifier",identifier); body.put("password",pass);
                BackendClient.postJson("/api/login",body,"",(data,error)->runOnUiThread(()->{
                    if(error!=null){Toast.makeText(this,"Login failed: "+error.getMessage(),Toast.LENGTH_LONG).show();return;}
                    try{org.json.JSONObject a=data.getJSONObject("user"); String id=a.getString("profile_id"); Role role=Role.valueOf(a.optString("role","USER")); SessionManager.setBackendToken(this,data.getString("token")); SessionManager.setSession(this,role,id); SessionManager.saveProfile(this,a.optString("name",""),a.optString("email",""),a.optString("mobile","")); startActivity(new Intent(this,MainActivity.class)); finish();}catch(Exception e){Toast.makeText(this,"Invalid backend response.",Toast.LENGTH_LONG).show();}
                }));
                return;
            }
            AccountStore.Account account = AccountStore.authenticate(this, identifier, pass);
            if (account == null && mobileMode && !identifier.startsWith("+880")) {
                account = AccountStore.authenticate(this, "+880" + identifier, pass);
            }
            if (account == null) {
                Toast.makeText(this, "Login failed. Check your Email/Mobile and Password.", Toast.LENGTH_LONG).show();
                return;
            }
            Role role = AdminIdentifiers.isAdminIdentifier(identifier) || AdminIdentifiers.isAdminAccount(account.email, account.mobile) ? Role.ADMIN : Role.USER;
            SessionManager.setSession(this, role, account.userId);
            SessionManager.saveProfile(this, account.name, account.email, account.mobile);
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        } catch (Throwable t) {
            Toast.makeText(this, "Login failed safely. Your account data was not changed.", Toast.LENGTH_LONG).show();
        }
    }
}
