# MY SHOP V-61 — Dashboard + Admin + Language Correction

This package is based on the locked V-59/V-60 source baseline. Older versions are not overwritten.

## Corrections in V-61
- Existing local User/Profile IDs are preserved; duplicate registration for an existing email/mobile is blocked and the existing ID is shown.
- Bengali/English switch added to Login and Dashboard.
- Dashboard primary hierarchy is compacted to avoid vertical scrolling; LIVE NOW uses a 3x2 compact grid.
- Admin role matching is more robust for configured admin email/mobile forms.
- Admin Add/Upload, Edit and Delete actions are available to the Admin-only management screen.
- Only one active GitHub Actions workflow is included and it targets one release APK.

## Important backend boundary
The project contracts require the production backend to be the source of truth for permanent IDs, authentication/roles and shared Admin content. This package does not invent a server URL or fake a backend. Therefore cross-device Admin changes and ID recovery after uninstall/reinstall still require the real backend service.

## Build target
Version code: 61
Version name: 2.9.61
Expected artifact: MY_SHOP_V61_RELEASE.apk
