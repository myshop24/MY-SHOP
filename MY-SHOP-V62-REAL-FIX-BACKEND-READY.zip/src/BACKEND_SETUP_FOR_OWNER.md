# MY SHOP V-62 — Cloudflare setup (owner only)

Never send your Cloudflare password, API token or bootstrap secret in chat.

1. Open Cloudflare Dashboard.
2. Workers & Pages -> Create application -> Worker. Name it `my-shop-v62-api`.
3. D1 -> Create database -> `my-shop-db`. Copy the database ID.
4. R2 -> Create bucket -> `my-shop-media`.
5. Open `backend/wrangler.toml` and replace `REPLACE_WITH_YOUR_D1_DATABASE_ID` with your D1 database ID.
6. In `backend/`, run `npm install` and then `npx wrangler d1 execute my-shop-db --remote --file=schema.sql`.
7. Set the Worker secret `ADMIN_BOOTSTRAP_SECRET` using Cloudflare/Wrangler. Keep it private.
8. Run `npx wrangler deploy`.
9. Copy the deployed Worker URL into `app/src/main/java/com/myshop/app/BackendConfig.java` as `BASE_URL`.
10. Build V-62. Production registration/login/admin/profile data then uses Worker + D1/R2.

The first admin is created once with `/api/admin/bootstrap` using the secret header. Change/remove the bootstrap secret after the first successful admin creation.
