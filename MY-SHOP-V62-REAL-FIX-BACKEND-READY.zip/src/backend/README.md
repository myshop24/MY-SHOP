# MY SHOP V-62 Backend

Cloudflare Worker + D1 + R2 backend for permanent accounts, profile IDs, language, password recovery, admin CRUD and media.

## Deploy
1. Create a D1 database named `my-shop-db`.
2. Create an R2 bucket named `my-shop-media`.
3. Put the D1 database ID in `wrangler.toml`.
4. Run `npx wrangler d1 execute my-shop-db --remote --file=schema.sql`.
5. Set a secret: `npx wrangler secret put ADMIN_BOOTSTRAP_SECRET`.
6. Deploy: `npx wrangler deploy`.
7. Bootstrap the first admin using POST `/api/admin/bootstrap` with header `x-bootstrap-secret` once. Do not share the secret in chat.
8. Put the deployed Worker URL into Android `BackendConfig.java`.

The server, not SharedPreferences, is the source of truth for Profile ID, role and account data. Password recovery accepts any 2 of the 3 registered security answers.
