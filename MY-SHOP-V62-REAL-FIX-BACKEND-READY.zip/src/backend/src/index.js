const json = (data, status=200, extra={}) => new Response(JSON.stringify(data), {status, headers:{'content-type':'application/json; charset=utf-8', ...extra}});
const cors = {'access-control-allow-origin':'*','access-control-allow-methods':'GET,POST,PUT,DELETE,OPTIONS','access-control-allow-headers':'content-type,authorization'};
const out = (d,s=200)=>json(d,s,cors);
const now=()=>new Date().toISOString();
const token=()=>crypto.randomUUID().replaceAll('-','')+crypto.randomUUID().replaceAll('-','');
const hex=buf=>Array.from(new Uint8Array(buf)).map(x=>x.toString(16).padStart(2,'0')).join('');
const bytes=hexstr=>new Uint8Array(hexstr.match(/.{2}/g).map(x=>parseInt(x,16)));
async function sha256(s){return hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));}
async function derive(password,salt){const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:bytes(salt),iterations:120000,hash:'SHA-256'},key,256);return hex(bits);}
async function makeHash(p){const salt=crypto.randomUUID().replaceAll('-','');return `pbkdf2$${salt}$${await derive(p,salt)}`;}
async function checkHash(p,h){if(!h.startsWith('pbkdf2$'))return false;const [,salt,stored]=h.split('$');return stored===await derive(p,salt);}
function normEmail(v){return String(v||'').trim().toLowerCase();}
function normMobile(v){return String(v||'').replace(/[^0-9+]/g,'');}
function four(v){return /^\d{4}$/.test(String(v||''));}
async function body(req){try{return await req.json()}catch{return {}}}
async function auth(req,env){const h=req.headers.get('authorization')||'';if(!h.startsWith('Bearer '))return null;const raw=h.slice(7);const th=await sha256(raw);const row=await env.DB.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?').bind(th,now()).first();return row||null;}
async function newSession(env,userId){const raw=token();const th=await sha256(raw);await env.DB.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,datetime(\'now\',\'+30 days\'))').bind(th,userId).run();return raw;}
async function nextProfileId(env){for(let i=1024;i<=9999;i++){const id=String(i).padStart(4,'0');const r=await env.DB.prepare('SELECT 1 FROM users WHERE profile_id=?').bind(id).first();if(!r)return id;}throw new Error('No profile IDs available');}
async function requireAdmin(req,env){const u=await auth(req,env);return u&&u.role==='ADMIN'?u:null;}
export default {async fetch(req,env){
  if(req.method==='OPTIONS')return new Response(null,{status:204,headers:cors});
  const url=new URL(req.url), p=url.pathname;
  try{
    if(p==='/api/health')return out({ok:true,service:'MY SHOP V-62',time:now()});
    if(p==='/api/register'&&req.method==='POST'){
      const b=await body(req), email=normEmail(b.email), mobile=normMobile(b.mobile); if(!b.name||(!email&&!mobile)||!b.password||String(b.password).length<6)return out({error:'invalid_input'},400);
      if(email&&await env.DB.prepare('SELECT 1 FROM users WHERE email=?').bind(email).first())return out({error:'email_exists'},409);
      if(mobile&&await env.DB.prepare('SELECT 1 FROM users WHERE mobile=?').bind(mobile).first())return out({error:'mobile_exists'},409);
      const pid=await nextProfileId(env), ph=await makeHash(b.password), qs=b.questions||{};
      await env.DB.prepare(`INSERT INTO users(profile_id,name,email,mobile,password_hash,security_q1,security_a1,security_q2,security_a2,security_q3,security_a3,language) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).bind(pid,b.name,email||null,mobile||null,ph,qs.q1||'',await makeHash(String(qs.a1||'')),qs.q2||'',await makeHash(String(qs.a2||'')),qs.q3||'',await makeHash(String(qs.a3||'')),b.language||'bn').run();
      const u=await env.DB.prepare('SELECT id,profile_id,name,email,mobile,role,language,profile_photo_key,bio FROM users WHERE profile_id=?').bind(pid).first();
      return out({ok:true,user:u,token:await newSession(env,u.id)},201);
    }
    if(p==='/api/login'&&req.method==='POST'){
      const b=await body(req), v=String(b.identifier||'').trim();let u=null;
      if(four(v))u=await env.DB.prepare('SELECT * FROM users WHERE profile_id=?').bind(v).first();
      else if(v.includes('@'))u=await env.DB.prepare('SELECT * FROM users WHERE email=?').bind(normEmail(v)).first();
      else u=await env.DB.prepare('SELECT * FROM users WHERE mobile=?').bind(normMobile(v)).first();
      if(!u||!(await checkHash(String(b.password||''),u.password_hash)))return out({error:'invalid_credentials'},401);
      return out({ok:true,user:{id:u.id,profile_id:u.profile_id,name:u.name,email:u.email,mobile:u.mobile,role:u.role,language:u.language,profile_photo_key:u.profile_photo_key,bio:u.bio},token:await newSession(env,u.id)});
    }
    if(p==='/api/profile'&&req.method==='GET'){const u=await auth(req,env);if(!u)return out({error:'unauthorized'},401);return out({ok:true,user:{id:u.id,profile_id:u.profile_id,name:u.name,email:u.email,mobile:u.mobile,role:u.role,language:u.language,profile_photo_key:u.profile_photo_key,bio:u.bio}});}
    if(p==='/api/profile/photo'&&req.method==='PUT'){const u=await auth(req,env);if(!u)return out({error:'unauthorized'},401);const b=await body(req);if(!b.key)return out({error:'invalid'},400);await env.DB.prepare('UPDATE users SET profile_photo_key=?,updated_at=? WHERE id=?').bind(b.key,now(),u.id).run();return out({ok:true,profile_photo_key:b.key});}
    if(p==='/api/profile'&&req.method==='PUT'){const u=await auth(req,env);if(!u)return out({error:'unauthorized'},401);const b=await body(req);await env.DB.prepare('UPDATE users SET name=COALESCE(?,name),language=COALESCE(?,language),bio=COALESCE(?,bio),updated_at=? WHERE id=?').bind(b.name??null,b.language??null,b.bio??null,now(),u.id).run();return out({ok:true});}
    if(p==='/api/forgot/questions'&&req.method==='POST'){const b=await body(req),v=String(b.identifier||'').trim();let u;if(four(v))u=await env.DB.prepare('SELECT * FROM users WHERE profile_id=?').bind(v).first();else if(v.includes('@'))u=await env.DB.prepare('SELECT * FROM users WHERE email=?').bind(normEmail(v)).first();else u=await env.DB.prepare('SELECT * FROM users WHERE mobile=?').bind(normMobile(v)).first();if(!u)return out({error:'not_found'},404);return out({ok:true,questions:[u.security_q1,u.security_q2,u.security_q3]});}
    if(p==='/api/forgot/reset'&&req.method==='POST'){const b=await body(req),v=String(b.identifier||'').trim();let u;if(four(v))u=await env.DB.prepare('SELECT * FROM users WHERE profile_id=?').bind(v).first();else if(v.includes('@'))u=await env.DB.prepare('SELECT * FROM users WHERE email=?').bind(normEmail(v)).first();else u=await env.DB.prepare('SELECT * FROM users WHERE mobile=?').bind(normMobile(v)).first();if(!u||!b.newPassword||String(b.newPassword).length<6)return out({error:'invalid'},400);const answers=[['a1',u.security_a1],['a2',u.security_a2],['a3',u.security_a3]];let correct=0;for(const [k,h] of answers)if(b[k]&&await checkHash(String(b[k]),h))correct++;if(correct<2)return out({error:'two_answers_required'},403);await env.DB.prepare('UPDATE users SET password_hash=?,updated_at=? WHERE id=?').bind(await makeHash(b.newPassword),now(),u.id).run();return out({ok:true});}
    if(p==='/api/admin/content'&&req.method==='GET'){if(!await requireAdmin(req,env))return out({error:'forbidden'},403);const type=url.searchParams.get('type')||'banners';const r=await env.DB.prepare('SELECT id,type,title,value,enabled FROM content WHERE type=? ORDER BY created_at DESC').bind(type).all();return out({ok:true,items:r.results||[]});}
    if(p==='/api/admin/content'&&req.method==='POST'){if(!await requireAdmin(req,env))return out({error:'forbidden'},403);const b=await body(req),id=crypto.randomUUID();await env.DB.prepare('INSERT INTO content(id,type,title,value,enabled) VALUES(?,?,?,?,1)').bind(id,b.type,b.title||'',b.value||'').run();return out({ok:true,id},201);}
    if(p.startsWith('/api/admin/content/')&&(req.method==='PUT'||req.method==='DELETE')){if(!await requireAdmin(req,env))return out({error:'forbidden'},403);const id=p.split('/').pop();if(req.method==='DELETE'){await env.DB.prepare('DELETE FROM content WHERE id=?').bind(id).run();return out({ok:true});}const b=await body(req);await env.DB.prepare('UPDATE content SET title=?,value=?,updated_at=? WHERE id=?').bind(b.title||'',b.value||'',now(),id).run();return out({ok:true});}
    if(p==='/api/admin/bootstrap'&&req.method==='POST'){const secret=req.headers.get('x-bootstrap-secret')||'';if(!env.ADMIN_BOOTSTRAP_SECRET||secret!==env.ADMIN_BOOTSTRAP_SECRET)return out({error:'forbidden'},403);const b=await body(req);if(!b.email||!b.password)return out({error:'invalid'},400);const existing=await env.DB.prepare('SELECT id FROM users WHERE email=?').bind(normEmail(b.email)).first();if(existing)return out({error:'already_exists'},409);const pid=await nextProfileId(env);await env.DB.prepare(`INSERT INTO users(profile_id,name,email,password_hash,role,security_q1,security_a1,security_q2,security_a2,security_q3,security_a3) VALUES(?,?,?,?,?,?,?,?,?,?,?)`).bind(pid,b.name||'MY SHOP Admin',normEmail(b.email),await makeHash(b.password),'ADMIN','Admin recovery question 1',await makeHash('admin'), 'Admin recovery question 2',await makeHash('admin'), 'Admin recovery question 3',await makeHash('admin')).run();return out({ok:true,profile_id:pid},201);}
    if(p.startsWith('/api/media')&&req.method==='POST'){const u=await requireAdmin(req,env);if(!u)return out({error:'forbidden'},403);if(!env.MEDIA)return out({error:'r2_not_bound'},500);const form=await req.formData(),file=form.get('file');if(!(file instanceof File))return out({error:'file_required'},400);const key=`${u.profile_id}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,'_')}`;await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:file.type||'application/octet-stream'}});return out({ok:true,key},201);}
    return out({error:'not_found'},404);
  }catch(e){return out({error:'server_error',message:String(e?.message||e)},500)}
}};
