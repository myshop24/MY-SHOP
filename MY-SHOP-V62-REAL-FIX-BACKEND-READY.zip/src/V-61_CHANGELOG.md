# MY SHOP V-61 CHANGELOG

- Preserved V-59 baseline and V-60 source; no overwrite.
- Locked four-digit user/profile IDs: existing local account IDs are never regenerated.
- Prevented duplicate local account creation for an existing email/mobile and display the existing permanent ID.
- Added Bengali/English language switch to Login and Dashboard.
- Reworked Dashboard to fit the primary approved hierarchy without vertical ScrollView; LIVE NOW uses a compact 3x2 grid.
- Improved Admin login role matching for configured admin email/mobile forms.
- Added Admin Edit action alongside Add/Upload/Delete.
- Kept Admin CRUD permission-gated.
- V-61 is not claimed as production backend CRUD: shared cross-device Admin changes and permanent IDs across uninstall/reinstall require the real backend service defined by the project contracts.
