# MY SHOP V-62 — REAL FIX MILESTONE

This package is built from the clean V-61 source and is intentionally NOT a cosmetic patch.

## Locked requirements addressed
- Exactly one final APK: `MY_SHOP_FINAL_RELEASE.apk`; workflow fails for 0 or >1 APKs and uploads only that APK.
- Dashboard remains the approved structure and is fitted to the available phone viewport without adding a vertical ScrollView to the dashboard.
- Breaking News display uses 17sp.
- Login supports Bangla, English, Hindi and Arabic; Dashboard language selector supports all four and Arabic switches layout direction to RTL.
- Forgot Password accepts any 2 correct answers out of the 3 registered security answers (local fallback and backend implementation).
- Permanent user ID is backend-first when Cloudflare Worker URL is configured. D1 owns the unique 4-digit profile ID.
- User profile photo can be uploaded to R2 and its key is persisted in D1.
- Admin CRUD is backend-first when Worker is configured; no SharedPreferences-only admin source is used in that mode.

## Important
The Cloudflare account itself cannot be deployed from this package. Deploy `backend/` to your Cloudflare account, set `BackendConfig.BASE_URL` to the Worker URL, then build the release. Until that URL is configured, the legacy local fallback remains available for development only; it must not be treated as the production source of truth.

## Release gate
Do not call this a final production release until:
1. Worker/D1/R2 are deployed.
2. `BackendConfig.BASE_URL` is configured.
3. Register -> permanent ID -> logout -> login -> update/reinstall test passes.
4. Profile photo persists.
5. Admin CRUD works from a second app session/device.
6. Four languages work in Login and Dashboard.
7. Dashboard is verified on the target phone without vertical scrolling.
8. GitHub Actions produces exactly one APK.
9. Regression tests pass.
