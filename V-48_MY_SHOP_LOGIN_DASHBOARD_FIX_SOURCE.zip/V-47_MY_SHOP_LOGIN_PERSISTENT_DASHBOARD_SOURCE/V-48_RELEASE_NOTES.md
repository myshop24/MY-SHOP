# MY SHOP V-48 — Login + Dashboard Fix

Version Code: 48
Version Name: 2.9.48
Application ID: com.myshop.app (unchanged)

Changes:
- Login screen rebuilt to match the supplied MY SHOP login reference style.
- Create Account screen rebuilt to match the supplied reference.
- Dashboard now uses the supplied dashboard-reference artwork instead of the incorrect V-47 programmatic layout.
- Transparent functional hit areas are placed over the reference artwork for Home, Live, Store, Gallery, External Movie, Live TV, Social Media, Earn & Reward, Share, More Apps, Chat and Profile.
- Existing AccountStore/SessionManager/UserIdManager logic retained.
- V-47 is not overwritten.
- APK is not claimed final until GitHub Actions builds and validates it.

Account persistence note:
An Android update preserves local account data only when the new APK is accepted as an in-place update signed with the same signing key. If a different signing key is used, Android normally cannot update the existing installation; uninstalling/reinstalling also clears local app data. For permanent production accounts, backend storage is required.
