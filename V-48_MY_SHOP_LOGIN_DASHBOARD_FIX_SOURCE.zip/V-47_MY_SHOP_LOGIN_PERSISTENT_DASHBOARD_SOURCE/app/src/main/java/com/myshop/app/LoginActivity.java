package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText loginId, loginPassword;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        String existingId = SessionManager.getUserId(this);
        if (SessionManager.isLoggedIn(this) && !existingId.isEmpty() && AccountStore.exists(this, existingId)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        loginId=findViewById(R.id.loginId);
        loginPassword=findViewById(R.id.loginPassword);
        Button login=findViewById(R.id.loginButton);
        Button create=findViewById(R.id.createAccountButton);
        TextView forgot=findViewById(R.id.forgotButton);

        create.setOnClickListener(v->startActivity(new Intent(this,RegisterActivity.class)));
        login.setOnClickListener(v->login());
        forgot.setOnClickListener(v->Toast.makeText(this,
            "Password reset will be connected to the secure backend.",Toast.LENGTH_LONG).show());
    }

    private void login(){
        String identifier=loginId.getText().toString().trim();
        String pass=loginPassword.getText().toString();
        if(identifier.isEmpty()||pass.isEmpty()){
            Toast.makeText(this,"Email/Mobile and Password are required.",Toast.LENGTH_SHORT).show();
            return;
        }
        try{
            AccountStore.Account account=AccountStore.authenticate(this,identifier,pass);
            if(account==null){
                Toast.makeText(this,"Login failed. Check your Email/Mobile and Password.",Toast.LENGTH_LONG).show();
                return;
            }
            SessionManager.setSession(this,Role.USER,account.userId);
            SessionManager.saveProfile(this,account.name,account.email,account.mobile);
            Intent intent=new Intent(this,MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent); finish();
        }catch(Throwable t){
            Toast.makeText(this,"Login failed safely. Your account data was not changed.",Toast.LENGTH_LONG).show();
        }
    }
}
