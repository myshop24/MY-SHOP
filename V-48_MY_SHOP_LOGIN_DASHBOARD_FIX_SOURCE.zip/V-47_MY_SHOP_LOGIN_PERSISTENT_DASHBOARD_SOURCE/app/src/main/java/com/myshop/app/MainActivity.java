package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static final int IMAGE_W = 1022;
    private static final int IMAGE_H = 1536;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildReferenceDashboard());
    }

    private View buildReferenceDashboard() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(247,248,252));

        int width = getResources().getDisplayMetrics().widthPixels;
        int height = Math.round(width * (IMAGE_H / (float) IMAGE_W));

        FrameLayout board = new FrameLayout(this);
        board.setLayoutParams(new ScrollView.LayoutParams(width, height));

        ImageView image = new ImageView(this);
        image.setImageResource(R.drawable.myshop_dashboard_reference);
        image.setScaleType(ImageView.ScaleType.FIT_XY);
        image.setContentDescription("MY SHOP Dashboard");
        board.addView(image, new FrameLayout.LayoutParams(width, height));

        // Transparent hit areas preserve the exact supplied dashboard artwork while
        // keeping the requested features clickable.
        hotspot(board,width,height,.01f,.005f,.09f,.055f,v->feature("Menu","menu"));
        hotspot(board,width,height,.11f,.005f,.80f,.055f,v->feature("Search","search"));
        hotspot(board,width,height,.83f,.005f,.91f,.055f,v->feature("Notifications","notifications"));
        hotspot(board,width,height,.92f,.005f,.99f,.055f,v->feature("More","more"));
        hotspot(board,width,height,.02f,.06f,.99f,.21f,v->feature("Banner","advertisement"));
        hotspot(board,width,height,.02f,.235f,.99f,.335f,v->feature("MY SHOP","my_shop"));
        hotspot(board,width,height,.02f,.345f,.99f,.445f,v->feature("Offers","offers"));
        hotspot(board,width,height,.02f,.455f,.99f,.505f,v->feature("Breaking News","breaking_news"));
        hotspot(board,width,height,.02f,.515f,.245f,.675f,v->feature("Live","live_now"));
        hotspot(board,width,height,.255f,.515f,.495f,.675f,v->feature("Live","live_now"));
        hotspot(board,width,height,.505f,.515f,.745f,.675f,v->feature("Live","live_now"));
        hotspot(board,width,height,.755f,.515f,.99f,.675f,v->feature("Live","live_now"));
        hotspot(board,width,height,.02f,.675f,.32f,.76f,v->feature("LIVE","live_now"));
        hotspot(board,width,height,.32f,.675f,.68f,.76f,v->feature("GO LIVE","go_live"));
        hotspot(board,width,height,.68f,.675f,.99f,.76f,v->feature("My Feed","my_feed"));
        hotspot(board,width,height,.02f,.765f,.25f,.845f,v->feature("MY SHOP","my_shop"));
        hotspot(board,width,height,.25f,.765f,.50f,.845f,v->feature("GALLERY","gallery"));
        hotspot(board,width,height,.50f,.765f,.75f,.845f,v->feature("EXTERNAL MOVIE","external_movie"));
        hotspot(board,width,height,.75f,.765f,.99f,.845f,v->feature("LIVE TV","live_tv"));
        hotspot(board,width,height,.02f,.845f,.25f,.925f,v->feature("SOCIAL MEDIA","social_media"));
        hotspot(board,width,height,.25f,.845f,.50f,.925f,v->feature("EARN & REWARD","earn_reward"));
        hotspot(board,width,height,.50f,.845f,.75f,.925f,v->feature("SHARE","share"));
        hotspot(board,width,height,.75f,.845f,.99f,.925f,v->feature("MORE APPS","more_apps"));
        hotspot(board,width,height,.00f,.945f,.20f,.999f,v->scroll.smoothScrollTo(0,0));
        hotspot(board,width,height,.20f,.945f,.40f,.999f,v->feature("LIVE","live_now"));
        hotspot(board,width,height,.40f,.945f,.60f,.999f,v->feature("MY SHOP","my_shop"));
        hotspot(board,width,height,.60f,.945f,.80f,.999f,v->feature("CHAT","chat"));
        hotspot(board,width,height,.80f,.945f,1f,.999f,v->startActivity(new Intent(this,AccountActivity.class)));

        scroll.addView(board);
        return scroll;
    }

    private void hotspot(FrameLayout board,int w,int h,float l,float t,float r,float b,View.OnClickListener listener){
        Button hit=new Button(this);
        hit.setBackgroundColor(Color.TRANSPARENT);
        hit.setText("");
        hit.setAlpha(0.02f);
        hit.setOnClickListener(listener);
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(
            Math.max(1,Math.round((r-l)*w)),Math.max(1,Math.round((b-t)*h)));
        p.leftMargin=Math.round(l*w); p.topMargin=Math.round(t*h);
        board.addView(hit,p);
    }

    private void feature(String title,String key){
        try{
            Intent i=new Intent(this,FeatureActivity.class);
            i.putExtra("title",title); i.putExtra("feature_key",key);
            startActivity(i);
        }catch(Throwable t){
            Toast.makeText(this,title,Toast.LENGTH_SHORT).show();
        }
    }
}
