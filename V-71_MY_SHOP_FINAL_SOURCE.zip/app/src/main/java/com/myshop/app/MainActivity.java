package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** V-71 corrected dashboard: uses the supplied final dashboard reference assets and keeps every tile clickable. */
public class MainActivity extends AppCompatActivity {
    private static final int BG = Color.rgb(248,249,252), TEXT = Color.rgb(28,35,52), BLUE = Color.rgb(27,99,220);
    private static final int PURPLE = Color.rgb(92,35,214), RED = Color.rgb(236,34,55);
    private static final long SLIDE_MS = 3500L;
    private final Handler handler = new Handler();
    private int bannerIndex = 0;
    private ImageView ad1, ad2, ad3, wide;
    private final int[] ads1 = {R.drawable.dash_ad1,R.drawable.dash_ad2,R.drawable.dash_ad3,R.drawable.dash_ad4,R.drawable.dash_ad5,R.drawable.dash_ad1};
    private final int[] ads2 = {R.drawable.dash_ad2,R.drawable.dash_ad3,R.drawable.dash_ad4,R.drawable.dash_ad5,R.drawable.dash_ad1,R.drawable.dash_ad2};
    private final int[] ads3 = {R.drawable.dash_ad3,R.drawable.dash_ad4,R.drawable.dash_ad5,R.drawable.dash_ad1,R.drawable.dash_ad2,R.drawable.dash_ad3};
    private final int[] wides = {R.drawable.dash_wide,R.drawable.dash_wide,R.drawable.dash_wide,R.drawable.dash_wide,R.drawable.dash_wide,R.drawable.dash_wide};
    private TextView breaking, liveTitle;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        try { setContentView(buildDashboard()); startCarousel(); }
        catch (Throwable t) { setContentView(buildSafeHome()); }
    }

    private int dp(int v){ return Math.round(v * getResources().getDisplayMetrics().density); }
    private LinearLayout.LayoutParams lp(int w,int h){ return new LinearLayout.LayoutParams(w,h); }
    private LinearLayout.LayoutParams weight(float w,int h){ return new LinearLayout.LayoutParams(0,h,w); }

    private View buildDashboard(){
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setVerticalScrollBarEnabled(false);
        LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(10),dp(7),dp(10),dp(8));

        LinearLayout header = row();
        Button menu = iconButton("☰", TEXT, 25); header.addView(menu,lp(dp(52),dp(54))); menu.setOnClickListener(v->startActivity(new Intent(this,AccountActivity.class)));
        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.myshop_icon); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); header.addView(logo,lp(dp(54),dp(54)));
        EditText search = new EditText(this); search.setSingleLine(true); search.setTextSize(13); search.setHint(LanguageManager.t(this,"search")); search.setPadding(dp(12),0,dp(12),0); search.setBackground(round(Color.WHITE,Color.rgb(225,228,235),dp(22))); header.addView(search,weight(1,dp(50)));
        Button bell = iconButton("🔔", RED, 18); header.addView(bell,lp(dp(50),dp(50)));
        Button more = iconButton("⋮", TEXT, 24); header.addView(more,lp(dp(50),dp(50))); more.setOnClickListener(v->startActivity(new Intent(this,AccountActivity.class)));
        content.addView(header,lp(-1,dp(60)));

        LinearLayout topAds = row();
        ad1 = image(R.drawable.dash_ad1); ad2 = image(R.drawable.dash_ad2);
        topAds.addView(ad1,weight(1,dp(118))); topAds.addView(space(dp(7),1),lp(dp(7),1)); topAds.addView(ad2,weight(1,dp(118)));
        LinearLayout.LayoutParams ta=lp(-1,dp(118)); ta.topMargin=dp(6); content.addView(topAds,ta);
        TextView dots = text("●   ○   ○   ○   ○",PURPLE,13,true); dots.setGravity(Gravity.CENTER); content.addView(dots,lp(-1,dp(24)));

        wide = image(R.drawable.dash_wide); content.addView(wide,lp(-1,dp(150)));
        LinearLayout midAds=row(); ad3=image(R.drawable.dash_ad3); ImageView ad4=image(R.drawable.dash_ad4); ImageView ad5=image(R.drawable.dash_ad5);
        midAds.addView(ad3,weight(1,dp(90))); midAds.addView(space(dp(6),1),lp(dp(6),1)); midAds.addView(ad4,weight(1,dp(90))); midAds.addView(space(dp(6),1),lp(dp(6),1)); midAds.addView(ad5,weight(1,dp(90)));
        content.addView(midAds,lp(-1,dp(90)));

        breaking = card("🔴  "+LanguageManager.t(this,"breaking")+"   |   "+breakingText(),Color.WHITE,TEXT,13); LinearLayout.LayoutParams br=lp(-1,dp(50)); br.topMargin=dp(7); content.addView(breaking,br);
        LinearLayout lh=row(); liveTitle=text("🔴  "+LanguageManager.t(this,"liveNow"),TEXT,15,true); lh.addView(liveTitle,weight(1,dp(42))); TextView all=text(LanguageManager.t(this,"seeAll")+"  ›",BLUE,13,true); all.setGravity(Gravity.CENTER); lh.addView(all,lp(dp(78),dp(42))); content.addView(lh,lp(-1,dp(44)));

        HorizontalScrollView hsv=new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false); LinearLayout liveRow=row();
        int[] liveImages={R.drawable.dash_live1,R.drawable.dash_live2,R.drawable.dash_live3,R.drawable.dash_live4};
        String[] liveNames={"Cute Girl Live","Music Live","Gaming Live","Talk & Fun"};
        for(int i=0;i<4;i++){ ImageView live=image(liveImages[i]); live.setOnClickListener(v->openFeature("LIVE", "live_now")); liveRow.addView(live,lp(dp(154),dp(150))); if(i<3) liveRow.addView(space(dp(7),1),lp(dp(7),1)); }
        hsv.addView(liveRow); content.addView(hsv,lp(-1,dp(156)));

        LinearLayout action=row(); ImageView liveAction=image(R.drawable.dash_action_live); liveAction.setOnClickListener(v->openFeature("LIVE","live_now")); action.addView(liveAction,weight(1,dp(82)));
        ImageView go=image(R.drawable.dash_action_go); go.setOnClickListener(v->openFeature("GO LIVE","go_live")); action.addView(go,lp(dp(150),dp(96)));
        ImageView feed=image(R.drawable.dash_action_feed); feed.setOnClickListener(v->openFeature("MY FEED","my_feed")); action.addView(feed,weight(1,dp(82))); content.addView(action,lp(-1,dp(102)));

        addFeatureRow(content,R.drawable.dash_feat_shop,"shop","my_shop",R.drawable.dash_feat_gallery,"gallery","gallery",R.drawable.dash_feat_movie,"movie","external_movie",R.drawable.dash_feat_tv,"tv","live_tv");
        addFeatureRow(content,R.drawable.dash_feat_social,"social","social_media",R.drawable.dash_feat_reward,"reward","earn_reward",R.drawable.dash_feat_share,"share","share",R.drawable.dash_feat_apps,"apps","more_apps");

        scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=row(); nav.setBackground(round(Color.WHITE,Color.rgb(225,228,235),dp(18)));
        Button home=navButton("⌂\n"+LanguageManager.t(this,"home"),PURPLE); Button live=navButton("◉\n"+LanguageManager.t(this,"live"),TEXT); Button store=navButton("🛒\n"+LanguageManager.t(this,"store"),PURPLE); Button chat=navButton("💬\n"+LanguageManager.t(this,"chat"),TEXT); Button moreNav=navButton("▦\n"+LanguageManager.t(this,"more"),TEXT);
        nav.addView(home,weight(1,dp(64))); nav.addView(live,weight(1,dp(64))); nav.addView(store,weight(1,dp(64))); nav.addView(chat,weight(1,dp(64))); nav.addView(moreNav,weight(1,dp(64))); root.addView(nav,lp(-1,dp(70)));
        live.setOnClickListener(v->openFeature("LIVE","live_now")); store.setOnClickListener(v->openFeature("MY SHOP","my_shop")); chat.setOnClickListener(v->openFeature("CHAT","chat")); moreNav.setOnClickListener(v->startActivity(new Intent(this,AccountActivity.class)));
        return root;
    }

    private void addFeatureRow(LinearLayout parent,int r1,String d1,String k1,int r2,String d2,String k2,int r3,String d3,String k3,int r4,String d4,String k4){
        LinearLayout r=row(); r.addView(tile(r1,d1,k1),weight(1,dp(82))); r.addView(space(dp(5),1),lp(dp(5),1)); r.addView(tile(r2,d2,k2),weight(1,dp(82))); r.addView(space(dp(5),1),lp(dp(5),1)); r.addView(tile(r3,d3,k3),weight(1,dp(82))); r.addView(space(dp(5),1),lp(dp(5),1)); r.addView(tile(r4,d4,k4),weight(1,dp(82))); parent.addView(r,lp(-1,dp(87)));
    }
    private ImageView tile(int res,String desc,String key){ ImageView v=image(res); v.setContentDescription(desc); v.setOnClickListener(x->openFeature(desc,key)); return v; }
    private ImageView image(int res){ ImageView v=new ImageView(this); v.setImageResource(res); v.setScaleType(ImageView.ScaleType.CENTER_CROP); v.setBackground(round(Color.WHITE,Color.rgb(225,228,235),dp(12))); v.setClipToOutline(true); return v; }
    private Button navButton(String label,int color){ return plainButton(label,color,12); }
    private Button iconButton(String label,int color,float size){ return plainButton(label,color,size); }
    private Button plainButton(String label,int color,float size){ Button b=new Button(this); b.setText(label); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setTextColor(color); b.setTextSize(size); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setBackground(round(Color.WHITE,Color.rgb(224,227,235),dp(12))); return b; }
    private TextView card(String label,int bg,int fg,float size){ TextView v=text(label,fg,size,true); v.setGravity(Gravity.CENTER_VERTICAL); v.setPadding(dp(8),dp(5),dp(8),dp(5)); v.setBackground(round(bg,Color.rgb(225,228,235),dp(14))); return v; }
    private TextView text(String s,int c,float size,boolean bold){ TextView v=new TextView(this); v.setText(s); v.setTextColor(c); v.setTextSize(size); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private View space(int w,int h){ return new View(this); }
    private GradientDrawable round(int fill,int stroke,int radius){ GradientDrawable g=new GradientDrawable(); g.setColor(fill); g.setCornerRadius(radius); g.setStroke(dp(1),stroke); return g; }
    private String breakingText(){ return LanguageManager.BN.equals(LanguageManager.get(this)) ? "বাংলাদেশে আজ স্বর্ণের দাম আবার কমলো" : "Welcome to MY SHOP"; }

    private void startCarousel(){ handler.postDelayed(new Runnable(){ public void run(){ bannerIndex=(bannerIndex+1)%6; ad1.setImageResource(ads1[bannerIndex]); ad2.setImageResource(ads2[bannerIndex]); ad3.setImageResource(ads3[bannerIndex]); wide.setImageResource(wides[bannerIndex]); handler.postDelayed(this,SLIDE_MS); }},SLIDE_MS); }
    @Override protected void onDestroy(){ handler.removeCallbacksAndMessages(null); super.onDestroy(); }
    private void openFeature(String t,String k){ try{Intent i=new Intent(this,FeatureActivity.class); i.putExtra("title",t); i.putExtra("feature_key",k); startActivity(i);}catch(Throwable x){Toast.makeText(this,t+" is ready.",Toast.LENGTH_SHORT).show();} }
    private View buildSafeHome(){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setGravity(Gravity.CENTER); r.setBackgroundColor(BG); TextView t=text("MY SHOP\nHome Dashboard",PURPLE,26,true); t.setGravity(Gravity.CENTER); r.addView(t,lp(-1,-2)); Button retry=plainButton("OPEN DASHBOARD",BLUE,15); retry.setOnClickListener(v->recreate()); r.addView(retry,lp(-1,dp(64))); return r; }
}
