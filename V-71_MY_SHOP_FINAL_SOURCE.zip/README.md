# MY SHOP V-71

This is the corrected V-71 source package based on the latest approved MY SHOP login/create-account and dashboard references.

## V-71 corrections
- One release APK only: `MY_SHOP_V71_FINAL_RELEASE.apk`
- Version bumped to `2.9.71` / versionCode `71`
- Latest MY SHOP MS shopping-bag icon applied
- Login screen rebuilt to the latest blue MS reference
- Create Account rebuilt to the latest blue MS reference
- Email OR Mobile is sufficient; no OTP/verification code
- Permanent sequential 4-digit local IDs start at `0100`
- One Security Question box containing 3 questions + answers; password reset requires any 2 of 3 answers
- One language button; clicking it shows only বাংলা / English / हिन्दी / العربية
- Selected language persists into the dashboard
- Dashboard rebuilt to the latest approved layout: wide banner, 3 ad cards, breaking news, live cards, Live/Go Live/My Feed, 4x2 feature grid, bottom navigation
- Six banner slots are retained per banner folder and auto-rotate
- Old APK outputs are deleted before every build
- GitHub Actions fails if more than one release APK is produced

## Build
GitHub Actions workflow: `.github/workflows/my-shop-v71.yml`

Upload exactly one source ZIP to the repository root:
`MY_SHOP_V71_FINAL_SOURCE.zip`

Then run **Actions → MY SHOP V-71 APK → Run workflow**.
