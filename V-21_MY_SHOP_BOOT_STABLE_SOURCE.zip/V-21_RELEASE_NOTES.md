# V-21 MY SHOP RELEASE NOTES

Purpose: isolate and eliminate launcher-time AppCompat/runtime failures before restoring further changes.

Android identity:
- applicationId: com.myshop.app.v21test
- versionCode: 21
- versionName: 3.0.0

Important: this is still a debug APK. GitHub-hosted debug builds can have different debug signing keys between runs. If Android reports an This build uses a unique test package so it can be installed side-by-side with older MY SHOP builds., uninstall the older MY SHOP package once before installing this test build.
