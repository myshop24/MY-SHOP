# V-21 MY SHOP CHANGELOG

- V-21 is a boot-stability branch based on V-20.
- Launcher MainActivity no longer depends on AppCompatActivity/AppCompat AlertDialog.
- Launcher activity uses a platform Material Light theme to isolate AppCompat startup failures.
- Startup callbacks are cancelled in onDestroy.
- Existing MY SHOP screens and features are preserved.
- V-20 source is preserved separately and is not overwritten.
- Uses a unique test applicationId `com.myshop.app.v21test` so installation/update signature conflicts cannot hide the runtime result.
