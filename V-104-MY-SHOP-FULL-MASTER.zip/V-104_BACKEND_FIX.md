MY SHOP V-104 — BACKEND CONNECTION FIX

- Version code: 104
- Version name: 2.9.104
- Configured Android backend URL:
  https://rapid-bush-62ea.myshopsatkania.workers.dev
- Registration/login/password reset now point to the production Worker URL.
- GitHub Actions no longer overwrites MYSHOP_BACKEND_URL with an empty value.
- Permanent 4-digit user ID logic and existing Worker API are preserved.
- This build does not modify or delete the existing V-103 backup.
