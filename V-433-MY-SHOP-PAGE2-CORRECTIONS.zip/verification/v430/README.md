# V-430 verification evidence

Run from project root:

```sh
node --check backend/worker/src/index.js
node tests/v430/backend.spec.cjs
python3 tools/v430/validate_source.py
java tools/v430/JavaSyntaxCheck.java app/src/main/java
mkdir -p /tmp/myshop-v430-tests
javac -d /tmp/myshop-v430-tests app/src/main/java/com/myshop/app/SlotOrder.java app/src/main/java/com/myshop/app/Home2Metrics.java tests/v430/SlotAndLayoutTest.java
java -cp /tmp/myshop-v430-tests SlotAndLayoutTest
bash -n my-shop-release.sh
```

The Worker test uses Node 22.16+ with `node:sqlite`. JVM tests require a JDK. This does not install an Android SDK, compile an APK, contact production D1, or test audible playback.
