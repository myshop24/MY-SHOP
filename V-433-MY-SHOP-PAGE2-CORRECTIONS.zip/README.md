# MY SHOP V-430 — correction source

Start with **START-HERE-V430.md** and **MY-SHOP-DEVELOPER-HANDOFF.md**.

This package contains the corrected Android project AND its matching Cloudflare Worker.
Do not deploy just the Android changes while leaving the old Worker running.
The included existing ZIP-selection GitHub build workflow/release script is unchanged.

Local tests and evidence are in `tests/v430/`, `tools/v430/`, and `verification/v430/`.
Older V-numbered release notes are historical records, NOT the status of V-430.
No signed APK or Android runtime PASS is claimed by this source package.
