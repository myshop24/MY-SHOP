package com.myshop.app;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.os.Handler;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * V-390 Live Streaming Home (Page 2).
 * Approved structure: premium banner -> Go Live / Join Live -> Live Categories ->
 * Today's Live Challenge -> People You May Like -> Weekly Live Stars.
 * Active rooms stay inside JOIN LIVE; no duplicate Top Live block on this page.
 * Shared navigation identity: Home | Store | Video | My Feed | More.
 */
public class LiveHomeActivity extends AppCompatActivity {
    private static final String BANNER_CACHE_PREFS="myshop_live_home_banner_cache";
    private static final String BANNER_CACHE_KEY="active_banners_v430";
    private static final long BANNER_FIRST_TICK_MS=900L;
    private static final long BANNER_INTERVAL_MS=4500L;
    private final int BG=Color.rgb(255,249,252), SURFACE=Color.rgb(255,255,255), SURFACE_2=Color.rgb(246,240,255);
    private final int WHITE=Color.WHITE, MUTED=Color.rgb(91,101,137), BLUE=Color.rgb(45,114,246), CYAN=Color.rgb(41,203,255), PINK=Color.rgb(240,43,183), PURPLE=Color.rgb(123,63,242), GOLD=Color.rgb(255,202,72);
    private final Handler handler=new Handler();
    private final ArrayList<JSONObject> bannerData=new ArrayList<>();
    private final ArrayList<JSONObject> peopleData=new ArrayList<>();
    private final ArrayList<JSONObject> starData=new ArrayList<>();
    private ViewFlipper bannerFlipper;
    private TextView bannerDots,bannerCounter;
    private LinearLayout peopleRow,starsRow,categoryTrack,liveNowRow,promoTrack;
    private Home2Metrics metrics;
    private final ArrayList<JSONObject>[] promoItems=new ArrayList[]{new ArrayList<>(),new ArrayList<>(),new ArrayList<>(),new ArrayList<>()};
    private final String[] promoNames={"Hot Deals","Discount Zone","New Arrivals","Special Offer"};
    private final int[] promoOrder={1,2,3,4};
    private final boolean[] promoEnabled={true,true,true,true};
    private final String[] live2Keys={"live2_music","live2_chat","live2_talent","live2_friendship","live2_gaming","live2_shopping","live2_pk","live2_more","live2_custom_09","live2_custom_10","live2_custom_11","live2_custom_12","live2_custom_13","live2_custom_14","live2_custom_15","live2_custom_16"};
    private final String[] live2Icons={"🎵","💬","🎤","🤝","🎮","🛍","⚔","✦","✦","✦","✦","✦","✦","✦","✦","✦"};
    private final String[] live2Labels={"Music","Chat & Talk","Talent","Friendship","Gaming","Shopping","PK Battle","More","Custom 9","Custom 10","Custom 11","Custom 12","Custom 13","Custom 14","Custom 15","Custom 16"};
    private final String[] live2IconUrls=new String[16];
    private final String[] live2Targets={"LIVE_NOW","TALK_ROOM","TRENDING","FRIENDS","LIVE_NOW","SHOP_LIVE","TRENDING","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW"};
    private final int[] live2Order={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
    private final boolean[] live2Active={true,true,true,true,true,true,true,true,false,false,false,false,false,false,false,false};
    private TextView peopleState,starsState,notificationBadge,messageBadge;
    private int bannerIndex=0;
    private int unreadNotificationCount=0,unreadMessageCount=0;
    private float bannerDownX=0f;
    private boolean bannerLoadInFlight=false;
    private boolean firstLiveResume=true;
    private boolean liveHomeVisible=false;
    private boolean liveHomeDestroyed=false;
    private final ExecutorService imageIo=Executors.newFixedThreadPool(2);

    // V-366: bannerTick is the single recurring scheduler. It advances once, then posts
    // exactly one next tick. render/resume/swipe may reset that one timer, but no code path
    // can multiply callbacks. This also keeps rotation alive after network refreshes.
    private final Runnable bannerTick=new Runnable(){@Override public void run(){
        if(!liveHomeVisible||liveHomeDestroyed)return;
        try{if(bannerData.size()>1)showBannerInternal((bannerIndex+1)%bannerData.size(),true);}catch(Throwable ignored){}
        scheduleBanner(false);
    }};

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(build());
        renderBanners();
        restoreBannerCache();
        loadBanners();
        loadPage2IconConfig();
        loadPeople();
        loadWeeklyStars();
        loadHeaderCounts();
    }

    private View build(){
        metrics=new Home2Metrics(getResources().getConfiguration().screenWidthDp);
        LinearLayout page=col();page.setBackground(new Home2BackgroundDrawable());
        page.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(0,Math.max(0,i.getSystemWindowInsetTop()),0,Math.max(0,i.getSystemWindowInsetBottom()));return i;});
        View header=homeStyleHeader();LinearLayout.LayoutParams hp=lp(-1,dp(58));hp.setMargins(dp(4),dp(8),dp(4),0);page.addView(header,hp);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);
        LinearLayout body=col();body.setPadding(dp(12),dp(5),dp(12),dp(5));body.setBackground(new Home2BackgroundDrawable());
        FrameLayout hero=new FrameLayout(this);hero.setBackground(gradient(new int[]{0xFFFF85C9,0xFFC1EDFF},14));hero.setClipToOutline(true);
        bannerFlipper=new ViewFlipper(this);hero.addView(bannerFlipper,new FrameLayout.LayoutParams(-1,-1));
        bannerDots=t("",8,WHITE,true);bannerDots.setGravity(Gravity.CENTER);FrameLayout.LayoutParams dots=new FrameLayout.LayoutParams(-1,dp(16),Gravity.BOTTOM);hero.addView(bannerDots,dots);
        bannerCounter=t("0/0",8,WHITE,true);bannerCounter.setGravity(Gravity.CENTER);bannerCounter.setBackground(round(0xB032124A,Color.TRANSPARENT,9));FrameLayout.LayoutParams count=new FrameLayout.LayoutParams(dp(35),dp(20),Gravity.RIGHT|Gravity.BOTTOM);count.rightMargin=dp(5);count.bottomMargin=dp(4);hero.addView(bannerCounter,count);
        hero.setContentDescription("Advertising banners: swipe left or right; Admin hold to manage");
        hero.setOnTouchListener(new HorizontalBannerTouch(hero,new HorizontalBannerTouch.Actions(){public void touching(boolean active){if(active)handler.removeCallbacks(bannerTick);else scheduleBanner(false);}public void swipe(boolean next){if(bannerData.size()>1)showBanner((bannerIndex+(next?1:-1)+bannerData.size())%bannerData.size(),next);}public void tap(){openCurrentBannerTarget();}public void hold(){if(SessionManager.isAdmin(LiveHomeActivity.this))openBannerAdmin("live_home","Main Advertising Banners");}}));
        body.addView(hero,lp(-1,dp(metrics.bannerHeightDp))); // V433: full available content width; no fixed 4.3:1 renderer
        LinearLayout actions=row();TextView go=action("🎙  GO LIVE\nStart Your Live",new int[]{0xFFFFA92B,0xFFFF21B5});go.setOnClickListener(v->{Intent i=new Intent(this,AudioLiveRoomActivity.class);i.putExtra("hostMode",true);startActivity(i);});TextView join=action("👥  JOIN LIVE\nExplore Live Rooms",new int[]{0xFF19CCFF,0xFF8224FF});join.setOnClickListener(v->openList());LinearLayout.LayoutParams g=wt(1,dp(44));g.rightMargin=dp(5);actions.addView(go,g);actions.addView(join,wt(1,dp(44)));body.addView(actions,top(lp(-1,dp(44)),5));
        promoTrack=row();body.addView(horizontal(promoTrack,70),top(lp(-1,dp(70)),5));renderPromos();
        body.addView(compactHeader("Live Now",this::openList),top(lp(-1,dp(22)),3));liveNowRow=row();body.addView(horizontal(liveNowRow,52),lp(-1,dp(52)));renderLiveNow();
        body.addView(compactHeader("Live Categories",()->openExplore("CATEGORIES")),top(lp(-1,dp(22)),3));categoryTrack=row();body.addView(horizontal(categoryTrack,48),lp(-1,dp(48)));renderLiveCategories();
        LinearLayout features=row();features.addView(discoveryCard("🏆","Today’s Challenge","Join Now",new int[]{0xFFFF9D48,0xFFBC38F3},()->openExplore("CHALLENGES")),rowWidth(3,4,0,48));features.addView(discoveryCard("📅","Upcoming Events","View Schedule",new int[]{0xFF23D3D7,0xFF357DF5},()->openExplore("EVENTS")),rowWidth(3,4,1,48));features.addView(discoveryCard("👑","Live Spotlight","Watch Now",new int[]{0xFF9F31F7,0xFFFF40B0},()->openLiveCategory("TRENDING")),rowWidth(3,4,2,48));body.addView(horizontal(features,48),top(lp(-1,dp(48)),5));
        body.addView(compactHeader("People You May Like",()->startActivity(new Intent(this,NewPeopleActivity.class))),top(lp(-1,dp(22)),3));peopleRow=row();body.addView(horizontal(peopleRow,76),lp(-1,dp(76)));renderPeople();
        body.addView(compactHeader("Weekly Live Stars",()->openLiveCategory("TRENDING")),top(lp(-1,dp(22)),3));starsRow=row();body.addView(horizontal(starsRow,58),lp(-1,dp(58)));renderStars();
        scroll.addView(body,new ScrollView.LayoutParams(-1,-2));page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));page.addView(bottomNav(),lp(-1,dp(70)));page.post(page::requestApplyInsets);return page;
    }
    private HorizontalScrollView horizontal(LinearLayout track,int height){HorizontalScrollView h=new HorizontalScrollView(this);h.setHorizontalScrollBarEnabled(false);h.setOverScrollMode(View.OVER_SCROLL_NEVER);h.addView(track,new HorizontalScrollView.LayoutParams(-2,dp(height)));return h;}
    private LinearLayout.LayoutParams rowWidth(int visible,int gap,int position,int height){int width=Math.max(1,(getResources().getDisplayMetrics().widthPixels-dp(24)-dp(gap)*(visible-1))/visible);LinearLayout.LayoutParams p=lp(width,dp(height));p.rightMargin=position==visible-1?0:dp(gap);return p;}
    private View compactHeader(String label,Runnable action){LinearLayout h=row();TextView title=t(label,12,0xFF101A48,true);title.setSingleLine(true);h.addView(title,wt(1,dp(22)));TextView all=t("See All ›",9,0xFF204CC5,true);all.setGravity(Gravity.CENTER);all.setOnClickListener(v->action.run());h.addView(all,lp(dp(60),dp(22)));return h;}
    private View discoveryCard(String icon,String name,String action,int[] colors,Runnable run){LinearLayout card=col();card.setPadding(dp(4),dp(3),dp(4),dp(3));card.setBackground(gradient(colors,10));TextView title=t(icon+" "+name,8.5f,WHITE,true);title.setMaxLines(2);card.addView(title,lp(-1,dp(26)));TextView cta=t(action+" ›",8.3f,WHITE,true);cta.setGravity(Gravity.CENTER);card.addView(cta,lp(-1,dp(15)));card.setOnClickListener(v->run.run());return card;}
    private void renderPromos(){if(promoTrack==null)return;promoTrack.removeAllViews();ArrayList<Integer> order=new ArrayList<>();for(int i=0;i<4;i++)if(promoEnabled[i])order.add(i);Collections.sort(order,(a,b)->Integer.compare(promoOrder[a],promoOrder[b]));int[][] colors={{0xFFFFD673,0xFFFFF6C8},{0xFF9CF3AA,0xFFE8FFE8},{0xFF80D7FF,0xFFEEF8FF},{0xFFF197ED,0xFFFFE7FF}};int[] icons={R.drawable.home2_hot,R.drawable.home2_discount,R.drawable.home2_new,R.drawable.home2_special};int pos=0;for(int index:order){final int n=index;LinearLayout card=col();card.setPadding(dp(4),dp(3),dp(4),dp(2));card.setBackground(gradient(colors[n],11));TextView name=t(promoNames[n],9,0xFF17234B,true);name.setSingleLine(true);name.setEllipsize(android.text.TextUtils.TruncateAt.END);card.addView(name,lp(-1,dp(15)));ImageView preview=new ImageView(this);preview.setScaleType(ImageView.ScaleType.FIT_CENTER);preview.setImageResource(icons[n]);if(!promoItems[n].isEmpty())loadImage(preview,promoItems[n].get(0).optString("image_url",""),280);card.addView(preview,lp(-1,dp(32)));TextView count=t(promoItems[n].size()+" items · View All ›",8,0xFF17234B,true);count.setGravity(Gravity.CENTER);card.addView(count,lp(-1,dp(16)));card.setOnClickListener(v->showPromoFolder(n));if(SessionManager.isAdmin(this))card.setOnLongClickListener(v->{managePromo(n);return true;});promoTrack.addView(card,rowWidth(4,4,pos++,70));}}
    private void applyPromos(JSONObject data){for(ArrayList<JSONObject> a:promoItems)a.clear();JSONArray b=data.optJSONArray("banners");if(b!=null)for(int k=0;k<b.length();k++){JSONObject x=b.optJSONObject(k);if(x==null||x.optInt("active",1)!=1)continue;for(int n=0;n<4;n++)if(("live2_promo_"+(n+1)).equals(x.optString("folder"))&&x.optInt("slot",0)>=1&&x.optInt("slot",0)<=6)promoItems[n].add(x);}for(ArrayList<JSONObject> a:promoItems)Collections.sort(a,(x,y)->Integer.compare(x.optInt("slot"),y.optInt("slot")));JSONArray f=data.optJSONArray("featureButtons");if(f!=null)for(int k=0;k<f.length();k++){JSONObject x=f.optJSONObject(k);if(x==null)continue;for(int n=0;n<4;n++)if(("live2_promo_folder_"+(n+1)).equals(x.optString("key"))){promoNames[n]=x.optString("title",promoNames[n]);promoOrder[n]=x.optInt("display_order",n+1);promoEnabled[n]=x.optInt("active",1)==1;}}renderPromos();}
    private void showPromoFolder(int index){if(promoItems[index].isEmpty()){if(SessionManager.isAdmin(this))managePromo(index);else Toast.makeText(this,"এই ফোল্ডারে এখন কোনো published offer নেই।",Toast.LENGTH_SHORT).show();return;}LinearLayout content=col();content.setPadding(dp(8),dp(8),dp(8),dp(8));LinearLayout track=row();for(JSONObject x:promoItems[index]){LinearLayout card=col();ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_CENTER);loadImage(image,x.optString("image_url",""),900);card.addView(image,lp(-1,dp(150)));TextView caption=t(x.optString("caption","Product offer"),13,0xFF17234B,true);caption.setMaxLines(2);card.addView(caption,lp(-1,dp(36)));TextView open=t("OPEN PRODUCT ›",12,BLUE,true);open.setGravity(Gravity.CENTER);card.addView(open,lp(-1,dp(44)));card.setOnClickListener(v->openTarget(x.optString("target_url","")));LinearLayout.LayoutParams q=lp(Math.max(dp(210),getResources().getDisplayMetrics().widthPixels-dp(90)),dp(236));q.rightMargin=dp(8);track.addView(card,q);}content.addView(horizontal(track,236));new android.app.AlertDialog.Builder(this).setTitle(promoNames[index]+" · "+promoItems[index].size()+" / 6").setView(content).setNegativeButton("CLOSE",null).show();}
    private void openTarget(String target){if(FeatureRegistry.isSafeHttpUrl(target)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception e){Toast.makeText(this,"Product link could not open",Toast.LENGTH_SHORT).show();}}else Toast.makeText(this,"Admin has not added a product link yet",Toast.LENGTH_SHORT).show();}
    private void openBannerAdmin(String folder,String title){startActivity(new Intent(this,LiveHomeAdminActivity.class).putExtra("folder",folder).putExtra("folderTitle",title).putExtra("admin_context",true));}
    private void managePromo(int n){new android.app.AlertDialog.Builder(this).setTitle(promoNames[n]+" • Admin").setItems(new String[]{"ADD / EDIT UP TO 6 PRODUCT BANNERS","FOLDER NAME / POSITION / VISIBILITY"},(d,w)->{if(w==0)openBannerAdmin("live2_promo_"+(n+1),promoNames[n]);else editPromoFolder(n);}).setNegativeButton("CLOSE",null).show();}
    private void editPromoFolder(int n){LinearLayout form=col();form.setPadding(dp(16),0,dp(16),0);EditText name=new EditText(this);name.setText(promoNames[n]);name.setHint("Folder name");form.addView(name);EditText order=new EditText(this);order.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);order.setText(String.valueOf(promoOrder[n]));order.setHint("Position 1–4");form.addView(order);CheckBox enabled=new CheckBox(this);enabled.setText("Published");enabled.setChecked(promoEnabled[n]);form.addView(enabled);new android.app.AlertDialog.Builder(this).setTitle("Folder Settings").setView(form).setPositiveButton("SAVE",(d,w)->{try{String title=name.getText().toString().trim();int slot=Integer.parseInt(order.getText().toString().trim());if(title.isEmpty()||slot<1||slot>4)throw new IllegalArgumentException();ArrayList<Integer> ids=new ArrayList<>();for(int i=0;i<4;i++)ids.add(i);Collections.sort(ids,(a,b)->Integer.compare(promoOrder[a],promoOrder[b]));ids.remove(Integer.valueOf(n));ids.add(slot-1,n);JSONArray all=new JSONArray();for(int i=0;i<ids.size();i++){int id=ids.get(i);all.put(new JSONObject().put("key","live2_promo_folder_"+(id+1)).put("title",id==n?title:promoNames[id]).put("active",id==n?enabled.isChecked():promoEnabled[id]).put("displayOrder",i+1));}BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("featureButtons",all),new BackendClient.Callback(){public void onSuccess(JSONObject x){loadPage2IconConfig();}public void onError(String m){Toast.makeText(LiveHomeActivity.this,m,Toast.LENGTH_LONG).show();}});}catch(Exception e){Toast.makeText(this,"Name and position 1–4 required",Toast.LENGTH_SHORT).show();}}).setNegativeButton("CANCEL",null).show();}
    private void renderLiveNow(){if(liveNowRow==null)return;liveNowRow.removeAllViews();if(starData.isEmpty()){TextView empty=t("Upcoming Live · Schedule or tap GO LIVE to start",10,MUTED,false);empty.setGravity(Gravity.CENTER);empty.setOnClickListener(v->openList());liveNowRow.addView(empty,lp(dp(metrics.widthDp),dp(52)));return;}int i=0;for(JSONObject x:starData){if(i>=12)break;LinearLayout card=col();card.setGravity(Gravity.CENTER);ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setBackground(round(Color.WHITE,Color.TRANSPARENT,9));av.setClipToOutline(true);loadImage(av,x.optString("avatarUrl",""),180);card.addView(av,lp(-1,dp(37)));TextView viewers=t("🔴 "+compact(x.optLong("viewerCount",0)),8,0xFF132347,true);viewers.setGravity(Gravity.CENTER);card.addView(viewers,lp(-1,dp(14)));card.setOnClickListener(v->joinRoom(x));liveNowRow.addView(card,rowWidth(6,4,i%6,52));i++;}}


    private View homeStyleHeader(){
        FrameLayout shell=new FrameLayout(this);shell.setClipToPadding(false);shell.setClipChildren(false);GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.rgb(8,33,103),Color.rgb(13,65,181),Color.rgb(20,73,215)});bg.setCornerRadius(dp(18));shell.setBackground(bg);shell.setElevation(dp(4));
        LinearLayout h=row();h.setGravity(Gravity.CENTER_VERTICAL);h.setPadding(dp(5),dp(2),dp(5),dp(1));ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setBackground(round(Color.WHITE,Color.WHITE,24));av.setClipToOutline(true);av.setElevation(dp(2));String avatarUrl=SessionManager.getAvatarUrl(this);if(avatarUrl!=null&&!avatarUrl.isEmpty())loadImage(av,avatarUrl,240);av.setOnClickListener(v->startActivity(new Intent(this,UserMenuActivity.class)));h.addView(av,lp(dp(44),dp(44)));
        LinearLayout brand=col();brand.setGravity(Gravity.CENTER_VERTICAL);brand.setPadding(dp(7),0,0,0);TextView name=t("MY SHOP",17.5f,WHITE,true);SpannableString bs=new SpannableString("MY SHOP");bs.setSpan(new ForegroundColorSpan(Color.rgb(255,202,45)),0,2,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);bs.setSpan(new ForegroundColorSpan(Color.rgb(245,251,255)),3,7,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);name.setText(bs);name.setSingleLine(true);name.setLetterSpacing(.025f);name.setShadowLayer(dp(2),0,dp(1),Color.rgb(0,115,255));brand.addView(name,lp(-1,dp(27)));TextView tag=t("Shop • Social • Live • Earn",7.0f,Color.rgb(234,241,255),true);tag.setSingleLine(true);brand.addView(tag,lp(-1,dp(14)));h.addView(brand,wt(1,dp(45)));
        TextView lang=t("🌐 "+languageCode()+"⌄",8.0f,WHITE,true);lang.setGravity(Gravity.CENTER);lang.setBackground(round(Color.argb(42,255,255,255),Color.TRANSPARENT,11));lang.setOnClickListener(v->LanguageManager.showPicker(this,()->recreate()));h.addView(lang,lp(dp(52),dp(42)));
        FrameLayout bellBox=headerAction(R.drawable.notification_bell,"Notifications");notificationBadge=t("",7.2f,WHITE,true);notificationBadge.setGravity(Gravity.CENTER);notificationBadge.setBackground(round(Color.rgb(238,35,52),Color.TRANSPARENT,9));bellBox.addView(notificationBadge,new FrameLayout.LayoutParams(dp(18),dp(18),Gravity.TOP|Gravity.END));bellBox.setOnClickListener(v->startActivity(new Intent(this,NotificationActivity.class)));h.addView(bellBox,lp(dp(39),dp(44)));updateNotificationBadge();
        FrameLayout chatBox=headerMessageAction();messageBadge=t("",7.2f,WHITE,true);messageBadge.setGravity(Gravity.CENTER);messageBadge.setBackground(round(Color.rgb(238,35,52),Color.TRANSPARENT,9));chatBox.addView(messageBadge,new FrameLayout.LayoutParams(dp(18),dp(18),Gravity.TOP|Gravity.END));chatBox.setOnClickListener(v->startActivity(new Intent(this,InboxActivity.class)));h.addView(chatBox,lp(dp(39),dp(44)));updateMessageBadge();
        FrameLayout search=headerAction(android.R.drawable.ic_menu_search,"Search");search.setOnClickListener(v->startActivity(new Intent(this,SearchActivity.class)));h.addView(search,lp(dp(39),dp(44)));shell.addView(h,new FrameLayout.LayoutParams(-1,-1));return shell;
    }
    private FrameLayout headerAction(int iconRes,String description){FrameLayout box=new FrameLayout(this);ImageView icon=new ImageView(this);icon.setImageResource(iconRes);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setPadding(dp(6),dp(6),dp(6),dp(6));icon.setImageTintList(ColorStateList.valueOf(WHITE));icon.setContentDescription(description);box.addView(icon,new FrameLayout.LayoutParams(-1,-1));PremiumUi.press(box);return box;}
    private FrameLayout headerMessageAction(){FrameLayout box=new FrameLayout(this);ImageView icon=new ImageView(this);icon.setImageResource(R.drawable.ui_message_hd);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setPadding(dp(3),dp(3),dp(3),dp(3));icon.clearColorFilter();icon.setContentDescription("Messages");box.addView(icon,new FrameLayout.LayoutParams(-1,-1));PremiumUi.press(box);return box;}

    private void loadHeaderCounts(){String token=SessionManager.getToken(this);if(token==null||token.isEmpty()){unreadNotificationCount=0;unreadMessageCount=0;updateNotificationBadge();updateMessageBadge();return;}BackendClient.notifications(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){unreadNotificationCount=Math.max(0,d.optInt("unreadCount",0));runOnUiThread(()->updateNotificationBadge());}public void onError(String m){}});BackendClient.messageUnread(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){unreadMessageCount=Math.max(0,d.optInt("unreadCount",0));runOnUiThread(()->updateMessageBadge());}public void onError(String m){}});}
    private void updateNotificationBadge(){if(notificationBadge==null)return;if(unreadNotificationCount<=0)notificationBadge.setVisibility(View.GONE);else{notificationBadge.setVisibility(View.VISIBLE);notificationBadge.setText(unreadNotificationCount>99?"99+":String.valueOf(unreadNotificationCount));}}
    private void updateMessageBadge(){if(messageBadge==null)return;if(unreadMessageCount<=0)messageBadge.setVisibility(View.GONE);else{messageBadge.setVisibility(View.VISIBLE);messageBadge.setText(unreadMessageCount>99?"99+":String.valueOf(unreadMessageCount));}}
    private String languageCode(){String l=LanguageManager.get(this);if(LanguageManager.EN.equals(l))return "EN";if(LanguageManager.HI.equals(l))return "HI";if(LanguageManager.AR.equals(l))return "AR";return "বাং";}

    private void startGlow(View v,long delay){
        v.postDelayed(()->{if(liveHomeDestroyed)return;ObjectAnimator a=ObjectAnimator.ofFloat(v,"alpha",.91f,1f,.91f);a.setDuration(1650);a.setRepeatCount(ValueAnimator.INFINITE);a.start();},delay);
    }

    private void renderLiveCategories(){if(categoryTrack==null)return;categoryTrack.removeAllViews();ArrayList<Integer> ids=new ArrayList<>();for(int i=0;i<live2Keys.length;i++)if(live2Active[i])ids.add(i);Collections.sort(ids,(a,b)->Integer.compare(live2Order[a],live2Order[b]));int[] art={R.drawable.home2_music,R.drawable.home2_chat,R.drawable.home2_talent,R.drawable.home2_friend,R.drawable.home2_game,R.drawable.home2_shop,R.drawable.home2_trophy,R.drawable.home2_more};int pos=0;for(int idx:ids){final int n=idx;LinearLayout card=col();card.setGravity(Gravity.CENTER);card.setBackground(round(Color.WHITE,Color.TRANSPARENT,10));ImageView icon=new ImageView(this);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setImageResource(art[n%art.length]);if(live2IconUrls[n]!=null&&!live2IconUrls[n].isEmpty())loadImage(icon,live2IconUrls[n],160);card.addView(icon,lp(-1,dp(31)));TextView label=t(live2Labels[n],7.5f,0xFF17234B,true);label.setGravity(Gravity.CENTER);label.setMaxLines(2);card.addView(label,lp(-1,dp(16)));card.setOnClickListener(v->{String target=live2Targets[n];if(FeatureRegistry.isSafeHttpUrl(target))openTarget(target);else openLiveCategory(target);});if(SessionManager.isAdmin(this))card.setOnLongClickListener(v->{startActivity(new Intent(this,PageIconAdminActivity.class).putExtra("page","live2").putExtra("admin_context",true));return true;});categoryTrack.addView(card,rowWidth(8,3,pos%8,48));pos++;}}


    private void loadPage2IconConfig(){BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){if(liveHomeDestroyed)return;runOnUiThread(()->{applyPage2IconConfig(d.optJSONArray("featureButtons"));applyPromos(d);});}public void onError(String m){}});}
    private void applyPage2IconConfig(JSONArray a){if(a!=null)for(int x=0;x<a.length();x++){JSONObject f=a.optJSONObject(x);if(f==null)continue;String key=f.optString("key","");for(int i=0;i<live2Keys.length;i++)if(live2Keys[i].equals(key)){String label=f.optString("title","").trim();if(!label.isEmpty())live2Labels[i]=label;live2IconUrls[i]=f.optString("icon_url","").trim();String savedTarget=f.optString("target_url","").trim();if(!savedTarget.isEmpty())live2Targets[i]=savedTarget;live2Order[i]=Math.max(1,f.optInt("display_order",i+1));live2Active[i]=f.optInt("active",1)==1;}}renderLiveCategories();}
    private View categoryCard(String icon,String label,int accent,String iconUrl){
        LinearLayout c=col();c.setGravity(Gravity.CENTER);c.setPadding(dp(6),dp(7),dp(6),dp(6));c.setBackground(gradient(new int[]{Color.argb(210,16,31,79),Color.argb(220,31,25,91)},15));c.setElevation(dp(3));
        FrameLayout iconBox=new FrameLayout(this);TextView ic=t(icon,23,WHITE,true);ic.setGravity(Gravity.CENTER);ic.setShadowLayer(dp(5),0,0,accent);iconBox.addView(ic,new FrameLayout.LayoutParams(-1,-1));if(iconUrl!=null&&!iconUrl.trim().isEmpty()){ImageView custom=new ImageView(this);custom.setScaleType(ImageView.ScaleType.CENTER_INSIDE);custom.setPadding(dp(3),dp(3),dp(3),dp(3));iconBox.addView(custom,new FrameLayout.LayoutParams(-1,-1));loadImage(custom,iconUrl.trim(),180);}c.addView(iconBox,lp(-1,dp(46)));TextView nm=t(label,8.7f,WHITE,true);nm.setGravity(Gravity.CENTER);nm.setMaxLines(2);c.addView(nm,lp(-1,dp(33)));PremiumUi.press(c);return c;
    }

    private View challengeCard(String icon,String title,String tag,int index){
        int[][] gradients={{Color.rgb(40,74,157),Color.rgb(108,57,190)},{Color.rgb(37,103,139),Color.rgb(52,55,154)},{Color.rgb(112,47,149),Color.rgb(183,54,129)},{Color.rgb(26,84,125),Color.rgb(93,48,150)}};
        LinearLayout c=col();c.setPadding(dp(10),dp(7),dp(10),dp(7));c.setBackground(gradient(gradients[index%gradients.length],16));c.setElevation(dp(3));TextView ic=t(icon+"  "+tag,9.3f,Color.rgb(232,235,255),true);c.addView(ic,lp(-1,dp(25)));TextView tx=t(title,10.3f,WHITE,true);tx.setMaxLines(2);c.addView(tx,lp(-1,dp(46)));PremiumUi.press(c);c.setOnClickListener(v->{Intent i=new Intent(this,AudioLiveRoomActivity.class);i.putExtra("hostMode",true);i.putExtra("challengeTitle",title);startActivity(i);});return c;
    }

    private void renderPeople(){if(peopleRow==null)return;peopleRow.removeAllViews();if(peopleData.isEmpty()){TextView empty=t("Discover MY SHOP people ›",10,MUTED,true);empty.setGravity(Gravity.CENTER);empty.setOnClickListener(v->startActivity(new Intent(this,NewPeopleActivity.class)));peopleRow.addView(empty,lp(dp(metrics.widthDp),dp(76)));return;}for(int i=0;i<Math.min(12,peopleData.size());i++){JSONObject p=peopleData.get(i);LinearLayout card=col();card.setPadding(dp(3),dp(3),dp(3),dp(2));card.setGravity(Gravity.CENTER);card.setBackground(round(Color.WHITE,Color.TRANSPARENT,10));ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setBackground(round(Color.WHITE,Color.TRANSPARENT,30));av.setClipToOutline(true);loadImage(av,p.optString("avatarUrl",""),160);card.addView(av,lp(dp(29),dp(29)));TextView name=t(shortName(p.optString("name","User")),8.2f,0xFF17234B,true);name.setGravity(Gravity.CENTER);name.setSingleLine(true);card.addView(name,lp(-1,dp(13)));TextView id=t("ID "+p.optString("userId",""),7.4f,MUTED,false);id.setGravity(Gravity.CENTER);card.addView(id,lp(-1,dp(12)));String state=p.optString("state","NONE");TextView add=t("FRIEND".equals(state)?"✓ Friends":"REQUESTED".equals(state)?"Requested":"+ Add Friend",7.2f,WHITE,true);add.setGravity(Gravity.CENTER);add.setBackground(gradient(new int[]{0xFF7364FF,0xFFB842F0},8));add.setOnClickListener(v->{if(!"NONE".equals(p.optString("state","NONE")))return;v.setEnabled(false);BackendClient.sendFriendRequest(SessionManager.getToken(this),p.optString("userId",""),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{try{p.put("state","REQUESTED");}catch(Exception ignored){}add.setText("Requested");});}public void onError(String m){runOnUiThread(()->{v.setEnabled(true);Toast.makeText(LiveHomeActivity.this,m,Toast.LENGTH_SHORT).show();});}});});card.addView(add,lp(-1,dp(18)));card.setOnClickListener(v->startActivity(new Intent(this,UserProfileActivity.class).putExtra("userId",p.optString("userId",""))));peopleRow.addView(card,rowWidth(5,4,i%5,76));}}


    private void loadPeople(){
        BackendClient.newPeople(SessionManager.getToken(this),20,0,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{peopleData.clear();JSONArray a=d.optJSONArray("people");if(a!=null)for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p!=null&&!SessionManager.getUserId(LiveHomeActivity.this).equals(p.optString("userId","")))peopleData.add(p);}renderPeople();});}public void onError(String m){runOnUiThread(()->renderPeople());}});
    }

    private void loadWeeklyStars(){
        BackendClient.liveDiscover(SessionManager.getToken(this),"TRENDING",12,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{starData.clear();JSONArray a=d.optJSONArray("rooms");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)starData.add(x);}renderStars();renderLiveNow();});}public void onError(String m){runOnUiThread(()->{renderStars();renderLiveNow();});}});
    }

    private void renderStars(){if(starsRow==null)return;starsRow.removeAllViews();String[] roles={"👑 Top Host","♥ Most Loved","★ Rising Star"};int[][] colors={{0xFFFFBC34,0xFFFFE48A},{0xFFFF4AA5,0xFFFFAFE3},{0xFF297EFF,0xFF7BCDFF}};for(int i=0;i<3;i++){JSONObject x=i<starData.size()?starData.get(i):null;LinearLayout c=col();c.setPadding(dp(5),dp(3),dp(5),dp(3));c.setBackground(gradient(colors[i],11));TextView role=t(roles[i],8.5f,WHITE,true);role.setSingleLine(true);c.addView(role,lp(-1,dp(17)));TextView name=t(x==null?"No current entry":shortName(x.optString("name","Creator")),9,WHITE,true);name.setSingleLine(true);c.addView(name,lp(-1,dp(17)));TextView stat=t(x==null?"View community ›":"ID "+x.optString("userId","")+" · View Live ›",7.4f,WHITE,false);stat.setSingleLine(true);c.addView(stat,lp(-1,dp(16)));c.setOnClickListener(v->{if(x==null)openLiveCategory("TRENDING");else joinRoom(x);});starsRow.addView(c,rowWidth(3,4,i,58));}}


    private void openExplore(String type){Intent i=new Intent(this,LiveHomeExploreActivity.class);i.putExtra("section",type);startActivity(i);}
    private void openLiveCategory(String category){Intent i=new Intent(this,LiveListActivity.class);i.putExtra("category",category);startActivity(i);}

    private View bottomNav(){
        LinearLayout nav=row();nav.setPadding(dp(4),dp(2),dp(4),dp(1));nav.setBackgroundColor(Color.WHITE);nav.setElevation(dp(7));addNav(nav,navItem(R.drawable.nav_home,"Home",false,Color.rgb(20,112,247),v->{Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);finish();}));addNav(nav,navItem(R.drawable.nav_store,"Store",false,Color.rgb(255,154,25),v->startActivity(new Intent(this,StoreActivity.class))));addNav(nav,navItem(R.drawable.nav_video,"Video",false,Color.rgb(255,23,89),v->startActivity(new Intent(this,ShortVideoActivity.class))));addNav(nav,navItem(R.drawable.nav_feed,"My Feed",false,Color.rgb(7,185,100),v->{Intent i=new Intent(this,MainActivity.class);i.putExtra("openMyFeed",true);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);finish();}));addNav(nav,navItem(R.drawable.nav_more,"More",false,Color.rgb(126,37,238),v->startActivity(new Intent(this,UserMenuActivity.class))));return nav;
    }
    private void addNav(LinearLayout parent,View child){parent.addView(child,new LinearLayout.LayoutParams(0,dp(61),1));}
    private View navItem(int iconRes,String label,boolean active,int color,View.OnClickListener listener){LinearLayout item=col();item.setGravity(Gravity.CENTER);item.setPadding(dp(3),dp(3),dp(3),0);ImageView icon=new ImageView(this);icon.setImageResource(iconRes);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setImageTintList(ColorStateList.valueOf(color));item.addView(icon,lp(-1,dp(31)));TextView name=t(label,8.5f,active?color:Color.rgb(103,112,139),true);name.setGravity(Gravity.CENTER);name.setSingleLine(true);item.addView(name,lp(-1,dp(18)));View line=new View(this);line.setBackgroundColor(active?color:Color.TRANSPARENT);item.addView(line,lp(dp(34),dp(3)));PremiumUi.press(item);item.setOnClickListener(listener);return item;}

    private LinearLayout sectionHeader(String title,String subtitle,Runnable all){LinearLayout h=row();LinearLayout copy=col();copy.addView(t(title,15.5f,WHITE,true),lp(-1,dp(26)));copy.addView(t(subtitle,8.4f,MUTED,false),lp(-1,dp(18)));h.addView(copy,wt(1,dp(46)));if(all!=null){TextView see=t("See All  ›",10,CYAN,true);see.setGravity(Gravity.CENTER);see.setBackground(round(Color.argb(70,29,100,170),Color.argb(160,55,202,255),14));PremiumUi.press(see);see.setOnClickListener(v->all.run());h.addView(see,lp(dp(88),dp(38)));}return h;}
    private TextView action(String s,int[] colors){TextView v=t(s,10.5f,WHITE,true);v.setGravity(Gravity.CENTER);v.setLines(2);v.setPadding(dp(8),0,dp(8),0);v.setLetterSpacing(.012f);PremiumUi.premiumButton(v,colors,20,Color.argb(165,255,255,255),7);return v;}

    private void loadBanners(){if(bannerLoadInFlight)return;bannerLoadInFlight=true;BackendClient.liveHomeBanners(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){ArrayList<JSONObject> active=parseBannerPayload(d,false);runOnUiThread(()->{if(liveHomeDestroyed)return;bannerLoadInFlight=false;bannerData.clear();bannerData.addAll(active);cacheCurrentBanners();renderBanners(true);});}public void onError(String m){runOnUiThread(()->{bannerLoadInFlight=false;if(!liveHomeDestroyed)renderBanners(false);});}});}


    private ArrayList<JSONObject> parseBannerPayload(JSONObject d,boolean mixedFolders){
        ArrayList<JSONObject> tmp=new ArrayList<>();JSONArray a=d==null?null:d.optJSONArray("banners");
        if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;if(mixedFolders&&!"live_home".equalsIgnoreCase(x.optString("folder","")))continue;int sl=x.optInt("slot",0);String url=x.optString("image_url","").trim();if(sl>=1&&sl<=6&&!url.isEmpty()&&x.optInt("active",1)==1){boolean duplicate=false;for(JSONObject q:tmp)if(q.optInt("slot")==sl)duplicate=true;if(!duplicate)tmp.add(x);}}
        Collections.sort(tmp,Comparator.comparingInt(x->x.optInt("slot",99)));return tmp;
    }
    private void restoreBannerCache(){
        try{String raw=getSharedPreferences(BANNER_CACHE_PREFS,MODE_PRIVATE).getString(BANNER_CACHE_KEY,"");if(raw==null||raw.trim().isEmpty())return;JSONArray a=new JSONArray(raw);ArrayList<JSONObject> cached=new ArrayList<>();for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;int sl=x.optInt("slot",0);String url=x.optString("image_url","").trim();if(sl>=1&&sl<=6&&!url.isEmpty())cached.add(x);}Collections.sort(cached,Comparator.comparingInt(x->x.optInt("slot",99)));if(!cached.isEmpty()){bannerData.clear();bannerData.addAll(cached);renderBanners(true);}}catch(Exception ignored){}
    }
    private void cacheCurrentBanners(){
        try{JSONArray a=new JSONArray();for(JSONObject x:bannerData){if(x!=null&&!x.optBoolean("fallback",false)&&!x.optString("image_url","").trim().isEmpty())a.put(new JSONObject(x.toString()));}getSharedPreferences(BANNER_CACHE_PREFS,MODE_PRIVATE).edit().putString(BANNER_CACHE_KEY,a.toString()).apply();}catch(Exception ignored){}
    }
    private void renderBanners(){renderBanners(false);}
    private void renderBanners(boolean quickStart){
        // Keep only two reusable banner frames alive. Older builds created one decoded
        // bitmap per configured slot; six large banners could remain in the heap together.
        handler.removeCallbacks(bannerTick);
        bannerFlipper.removeAllViews();bannerIndex=0;
        if(bannerData.isEmpty()){
            TextView empty=t(SessionManager.isAdmin(this)?"ADVERTISEMENT · Hold to add up to 6 banners":"MY SHOP · Advertising",12,0xFF692894,true);empty.setGravity(Gravity.CENTER);bannerFlipper.addView(empty,new FrameLayout.LayoutParams(-1,-1));bannerCounter.setText("0/6");bannerDots.setText("");return;
        }
        for(int i=0;i<2;i++){ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.FIT_CENTER);im.setBackgroundColor(0xFFF3E6FC);bannerFlipper.addView(im,new FrameLayout.LayoutParams(-1,-1));}
        bannerFlipper.setDisplayedChild(0);
        bindBannerFrame((ImageView)bannerFlipper.getChildAt(0),0);
        updateBannerIndicators();scheduleBanner(quickStart);
    }
    private void bindBannerFrame(ImageView target,int dataIndex){
        if(target==null)return;target.setTag(null);target.setImageDrawable(null);target.setBackgroundColor(0xFFF3E6FC);
        if(dataIndex<0||dataIndex>=bannerData.size())return;
        String url=bannerData.get(dataIndex).optString("image_url","").trim();
        if(!url.isEmpty())loadImage(target,url,1280);
    }
    private void showBanner(int next,boolean forward){showBannerInternal(next,forward);scheduleBanner(false);}
    private void showBannerInternal(int next,boolean forward){
        if(bannerData.size()<=1){bannerIndex=0;updateBannerIndicators();return;}
        next=(next+bannerData.size())%bannerData.size();if(next==bannerIndex)return;
        final int oldChild=bannerFlipper.getDisplayedChild();
        final int newChild=oldChild==0?1:0;
        ImageView incoming=(ImageView)bannerFlipper.getChildAt(newChild);
        bindBannerFrame(incoming,next);
        Animation in=new TranslateAnimation(Animation.RELATIVE_TO_SELF,forward?1f:-1f,Animation.RELATIVE_TO_SELF,0f,Animation.RELATIVE_TO_SELF,0f,Animation.RELATIVE_TO_SELF,0f);in.setDuration(320);
        Animation out=new TranslateAnimation(Animation.RELATIVE_TO_SELF,0f,Animation.RELATIVE_TO_SELF,forward?-1f:1f,Animation.RELATIVE_TO_SELF,0f,Animation.RELATIVE_TO_SELF,0f);out.setDuration(320);
        bannerFlipper.setInAnimation(in);bannerFlipper.setOutAnimation(out);bannerFlipper.setDisplayedChild(newChild);
        bannerIndex=next;updateBannerIndicators();
        handler.postDelayed(()->{
            if(liveHomeDestroyed)return;
            try{ImageView old=(ImageView)bannerFlipper.getChildAt(oldChild);if(old!=null&&bannerFlipper.getDisplayedChild()!=oldChild){old.setTag(null);old.setImageResource(R.drawable.startup_ad_myshop_live);}}catch(Exception ignored){}
        },380);
    }
    private void updateBannerIndicators(){int n=bannerData.size();StringBuilder d=new StringBuilder();for(int i=0;i<n;i++){d.append(i==bannerIndex?"●":"○");if(i<n-1)d.append("   ");}bannerDots.setText(d.toString());bannerCounter.setText((bannerIndex+1)+"/"+n);}
    private void scheduleBanner(boolean quickStart){handler.removeCallbacks(bannerTick);if(liveHomeVisible&&!liveHomeDestroyed&&bannerData.size()>1)handler.postDelayed(bannerTick,quickStart?BANNER_FIRST_TICK_MS:BANNER_INTERVAL_MS);}
    private void openCurrentBannerTarget(){if(bannerData.isEmpty()){if(SessionManager.isAdmin(this))openBannerAdmin("live_home","Main Advertising Banners");return;}String target=bannerData.get(Math.min(bannerIndex,bannerData.size()-1)).optString("target_url",bannerData.get(Math.min(bannerIndex,bannerData.size()-1)).optString("targetUrl","")).trim();if(FeatureRegistry.isSafeHttpUrl(target)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception ignored){}}}

    private void openList(){Intent i=new Intent(this,LiveListActivity.class);i.putExtra("category","LIVE_NOW");startActivity(i);}
    private void joinRoom(JSONObject x){String uid=x.optString("userId","");if(uid.isEmpty())return;Intent i=new Intent(this,AudioLiveRoomActivity.class);i.putExtra("hostMode",false);i.putExtra("hostId",uid);i.putExtra("hostName",x.optString("name","MY SHOP User"));startActivity(i);}

    @Override protected void onResume(){super.onResume();liveHomeVisible=true;if(firstLiveResume)firstLiveResume=false;else{loadBanners();loadPage2IconConfig();loadPeople();loadWeeklyStars();}loadHeaderCounts();scheduleBanner(true);}
    @Override protected void onPause(){liveHomeVisible=false;handler.removeCallbacks(bannerTick);super.onPause();}
    @Override protected void onDestroy(){liveHomeDestroyed=true;liveHomeVisible=false;handler.removeCallbacksAndMessages(null);imageIo.shutdownNow();super.onDestroy();}

    /**
     * Crash guard for remote Live Home artwork. V-355 could decode up to six large R2
     * banners at full resolution at once. A single 4K/8K image can expand to tens of MB
     * in memory; concurrent full-size decodes could terminate the app with OOM.
     * Decode bounds first, sample to the actual UI need, use RGB_565, cap concurrency,
     * and treat OOM as a failed image rather than a process crash.
     */
    private void loadImage(ImageView target,String rawUrl,int maxPx){
        if(rawUrl==null||rawUrl.trim().isEmpty())return;
        final String url=rawUrl.trim();
        target.setTag(url);
        if(liveHomeDestroyed||imageIo.isShutdown()||imageIo.isTerminated())return;
        try{imageIo.execute(()->{
            Bitmap bitmap=null;
            try{
                BitmapFactory.Options bounds=new BitmapFactory.Options();
                bounds.inJustDecodeBounds=true;
                decodeRemote(url,bounds);
                if(bounds.outWidth<=0||bounds.outHeight<=0)return;

                int sample=1;
                int largest=Math.max(bounds.outWidth,bounds.outHeight);
                while(largest/sample>Math.max(160,maxPx))sample*=2;

                BitmapFactory.Options opts=new BitmapFactory.Options();
                opts.inSampleSize=Math.max(1,sample);
                opts.inPreferredConfig=Bitmap.Config.RGB_565;
                opts.inDither=true;
                bitmap=decodeRemote(url,opts);
            }catch(OutOfMemoryError oom){
                bitmap=null;
                System.gc();
            }catch(Exception ignored){
                bitmap=null;
            }
            final Bitmap safe=bitmap;
            if(safe!=null&&!liveHomeDestroyed&&!isFinishing()&&!isDestroyed())runOnUiThread(()->{
                if(!liveHomeDestroyed&&!isFinishing()&&!isDestroyed()&&url.equals(target.getTag()))target.setImageBitmap(safe);
            });
        });}catch(java.util.concurrent.RejectedExecutionException ignored){}
    }

    private Bitmap decodeRemote(String url,BitmapFactory.Options opts) throws Exception{
        HttpURLConnection c=null;
        try{
            c=(HttpURLConnection)new URL(url).openConnection();
            c.setConnectTimeout(5000);
            c.setReadTimeout(7000);
            c.setInstanceFollowRedirects(true);
            c.setUseCaches(true);
            c.setRequestProperty("User-Agent","MY-SHOP/2.9.398");
            int code=c.getResponseCode();
            if(code<200||code>=300)throw new java.io.IOException("HTTP "+code);
            try(InputStream in=c.getInputStream()){return BitmapFactory.decodeStream(in,null,opts);}
        }finally{if(c!=null)c.disconnect();}
    }
    private String shortName(String n){if(n==null||n.trim().isEmpty())return "User";n=n.trim();return n.length()>12?n.substring(0,12):n;}
    private String compact(long n){if(n>=1000000)return String.format(java.util.Locale.US,"%.1fM",n/1000000f);if(n>=1000)return String.format(java.util.Locale.US,"%.1fK",n/1000f);return String.valueOf(n);}
    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private TextView t(String s,float z,int c,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    private GradientDrawable gradient(int[] colors,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(radius));return g;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams wt(float w,int h){return new LinearLayout.LayoutParams(0,h,w);} private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;} private int dp(float x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
}
