package com.myshop.app;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import android.animation.ValueAnimator;

/** A real profile photo inside an ornament. Only the light layer animates. */
public final class MembershipIdentityView extends FrameLayout {
    private final ImageView photo,ornament;
    private final Sparkles sparkles;
    private final String tier;
    private float cx=168,cy=139,radius=88;
    public MembershipIdentityView(Context context,String code,String avatarUrl){
        super(context);tier=MembershipUi.tier(code);setClipChildren(false);setClipToPadding(false);
        switch(tier){case "KING":cx=166;cy=139;radius=83;break;case "QUEEN":cx=165;cy=141;radius=84;break;case "ROYAL":cx=168;cy=136;radius=85;break;case "VVIP":cx=168;cy=141;radius=88;break;}
        photo=new ImageView(context);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);photo.setImageResource(R.drawable.myshop_profile_avatar);
        GradientDrawable circle=new GradientDrawable();circle.setShape(GradientDrawable.OVAL);circle.setColor(0xFF15253E);photo.setBackground(circle);photo.setClipToOutline(true);addView(photo,new LayoutParams(1,1));
        if(avatarUrl!=null&&!avatarUrl.trim().isEmpty())AnimatedAssetLoader.load(photo,avatarUrl,false);
        ornament=new ImageView(context);ornament.setImageResource(MembershipUi.ornament(tier));ornament.setScaleType(ImageView.ScaleType.FIT_CENTER);addView(ornament,new LayoutParams(-1,-1));
        sparkles=new Sparkles(context,MembershipUi.accent(tier));addView(sparkles,new LayoutParams(-1,-1));
        setContentDescription(tier+" membership frame with your profile photo");setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
    }
    /** Custom PNG/WebP/GIF keeps the documented 320x275 transparent portrait window. */
    public void setFrameAsset(String url){
        if(url==null||url.trim().isEmpty())return;
        String lower=url.toLowerCase(java.util.Locale.US).split("\\?",2)[0];
        if(lower.endsWith(".mp4")||lower.endsWith(".webm")||lower.endsWith(".3gp"))return;
        AnimatedAssetLoader.load(ornament,url.trim(),true);
    }
    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){super.onSizeChanged(w,h,oldw,oldh);float s=Math.min(w/320f,h/275f),left=(w-320*s)/2,top=(h-275*s)/2;
        LayoutParams p=new LayoutParams(Math.round(radius*2*s)+2,Math.round(radius*2*s)+2);p.leftMargin=Math.round(left+(cx-radius)*s)-1;p.topMargin=Math.round(top+(cy-radius)*s)-1;photo.setLayoutParams(p);
        sparkles.cx=left+cx*s;sparkles.cy=top+cy*s;sparkles.radius=radius*s;}
    private static final class Sparkles extends View {
        final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);final int color;float phase,cx,cy,radius;ValueAnimator light;
        Sparkles(Context c,int color){super(c);this.color=color;setClickable(false);}
        @Override protected void onAttachedToWindow(){super.onAttachedToWindow();if(android.os.Build.VERSION.SDK_INT<26||ValueAnimator.areAnimatorsEnabled()){light=ValueAnimator.ofFloat(0f,1f);light.setDuration(4200);light.setRepeatCount(ValueAnimator.INFINITE);light.addUpdateListener(a->{phase=(float)a.getAnimatedValue();invalidate();});light.start();}}
        @Override protected void onDetachedFromWindow(){if(light!=null){light.cancel();light=null;}super.onDetachedFromWindow();}
        @Override protected void onDraw(Canvas c){super.onDraw(c);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(1f,getWidth()/210f));p.setColor(color);p.setAlpha(225);c.drawCircle(cx,cy,radius,p);p.setStyle(Paint.Style.FILL);for(int i=0;i<7;i++){double a=(phase+i/7f)*Math.PI*2;float x=cx+(float)Math.cos(a)*(radius+getWidth()*.05f),y=cy+(float)Math.sin(a)*(radius+getHeight()*.06f);p.setColor(i%2==0?Color.WHITE:color);p.setAlpha(100+(int)(140*Math.abs(Math.sin(a))));float d=Math.max(1.0f,getWidth()/130f);c.drawCircle(x,y,d,p);c.drawRect(x-d*2.3f,y-d/3,x+d*2.3f,y+d/3,p);c.drawRect(x-d/3,y-d*2.3f,x+d/3,y+d*2.3f,p);}}
    }
}
