package com.myshop.app;

import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.text.TextUtils;
import android.provider.MediaStore;
import android.media.MediaScannerConnection;
import android.media.MediaMetadataRetriever;
import android.text.style.ForegroundColorSpan;
import android.text.Spanned;
import android.text.SpannableString;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.content.res.ColorStateList;
import android.util.LruCache;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

/** MY SHOP V-398: reference-parity home polish, animated live signal, compact 3D quick links and hide-on-scroll bottom navigation. */
public class MainActivity extends androidx.appcompat.app.AppCompatActivity {
    private static final int REQUEST_NOTIFICATIONS_V323=9322;
    private int BG=Color.rgb(248,249,253), BLUE=Color.rgb(46,47,190), PURPLE=Color.rgb(91,38,214), PINK=Color.rgb(235,36,168);
    private final int NAVY=Color.rgb(18,32,75), DARK=Color.rgb(35,38,52), RED=Color.rgb(238,35,52), GREEN=Color.rgb(24,169,98), MUTED=Color.rgb(105,111,130);
    private final Handler handler=new Handler();
    private final java.util.concurrent.ExecutorService imagePool=Executors.newFixedThreadPool(2);
    private final LruCache<String,Bitmap> imageCache=new LruCache<String,Bitmap>(4*1024*1024){
        @Override protected int sizeOf(String key,Bitmap value){return value.getByteCount();}
    };
    private long lastFeedLoadAt=0L;
    // V-364 recovery: avoid duplicating the entire dashboard network/image boot on the
    // first onResume immediately after onCreate, and serialize Live/New People refresh.
    private boolean firstDashboardResume=true;
    private boolean liveProfilesLoading=false;
    // V-365: lifecycle gate for dashboard callbacks/timers. Prevent stale callbacks from
    // touching views or submitting image work after Activity recreation/destruction.
    private boolean dashboardVisible=false;
    private boolean dashboardDestroyed=false;
    private final Runnable notificationPoll = new Runnable() {
        @Override public void run() {
            loadNotificationCount(); loadMessageCount();
            handler.postDelayed(this,12000);
        }
    };
    private final Runnable profilePresencePoll = new Runnable() {
        @Override public void run() {
            loadRealLiveProfiles();
            handler.postDelayed(this,5000);
        }
    };
    private final Runnable heroCarouselTick=new Runnable(){@Override public void run(){
        if(!dashboardVisible||dashboardDestroyed)return;
        try{showHeroSlide(nextHeroSlide(slide));}catch(Throwable ignored){}
        scheduleHeroCarousel(3500L);
    }};
    private final Runnable promoCarouselTick=new Runnable(){@Override public void run(){
        if(!dashboardVisible||dashboardDestroyed)return;
        try{promoSlide=(promoSlide+1)%6;applyPromoSlide();}catch(Throwable ignored){}
        schedulePromoCarousel();
    }};
    private final Runnable liveAdCarouselTick=new Runnable(){@Override public void run(){
        if(!dashboardVisible||dashboardDestroyed)return;
        try{if(!liveAds.isEmpty()){liveAdIndex=(liveAdIndex+1)%liveAds.size();renderPowerAds();}}catch(Throwable ignored){}
        scheduleLiveAdCarousel();
    }};
    private int slide=0;
    private int promoSlide=0;
    private ImageView hero;
    private float heroDownX=0f,heroDownY=0f,promoDownX=0f,promoDownY=0f;
    private ImageView[] promoViews=new ImageView[2];
    private String[] remoteHeroUrls=new String[6];
    private String[] remoteHeroTargets=new String[6];
    private String[] remotePromoUrls=new String[6];
    private String[] remotePromoTargets=new String[6];
    private TextView dots,newsText,notificationBadge,messageBadge,feedStatus,postLimit;
    private LinearLayout breakingBox;
    private ImageView headerAvatar,composerAvatar;
    private LinearLayout feedList;
    private LinearLayout newPeopleRow; private View newPeopleSection; private HorizontalScrollView newPeopleScroll; private final ArrayList<JSONObject> newPeopleData=new ArrayList<>(); private int newPeopleStep=0;
    private ScrollView scroll;
    private ValueAnimator chromeMarginAnimator;
    private View feedAnchor;
    private LinearLayout liveAdBox;
    private TextView powerAdTitle, powerAdByline; private LinearLayout dynamicFolderBox; private LinearLayout realLiveProfilesRow;
    private long feedBefore=0;
    private boolean feedLoading=false,feedHasMore=true;
    private static final int PICK_POST=9421;
    private Uri pendingPostUri;
    private String pendingPostMime="image/jpeg";
    private int unreadNotificationCount=0, unreadMessageCount=0;
    private boolean sessionValidationRouted=false;
    private final java.util.HashSet<Long> renderedPostIds=new java.util.HashSet<>();
    private final ArrayList<VideoView> inlineVideos=new ArrayList<>();
    private VideoView activeInlineVideo=null;
    private final java.util.HashMap<Long,View> postViews=new java.util.HashMap<>();
    private long pendingFocusPostId=0;
    private float newsTextSizeSp=13.0f;
    private ImageView liveAdImage; private TextView liveAdCaption; private View liveAdStripView; private final ArrayList<JSONObject> liveAds=new ArrayList<>(); private int liveAdIndex=0;
    private final int[] heroImgs={R.drawable.banner_wide_1,R.drawable.banner_wide_2,R.drawable.banner_wide_3,R.drawable.banner_wide_4,R.drawable.banner_wide_5,R.drawable.banner_wide_6};
    private final int[] left={R.drawable.banner_top_left_1,R.drawable.banner_top_left_2,R.drawable.banner_top_left_3,R.drawable.banner_top_left_4,R.drawable.banner_top_left_5,R.drawable.banner_top_left_6};
    private final int[] right={R.drawable.banner_top_right_1,R.drawable.banner_top_right_2,R.drawable.banner_top_right_3,R.drawable.banner_top_right_4,R.drawable.banner_top_right_5,R.drawable.banner_top_right_6};
    private final int[] live={R.drawable.dash_live1,R.drawable.dash_live2,R.drawable.dash_live3,R.drawable.dash_live4};
    // V-395 Home Page 1 quick links: compact 3D-quality icons, real actions, admin order/enable controls.
    private final String[] mainKeys={"home1_page","home1_website","home1_level","home1_membership","home1_rewards","home1_gallery","home1_external","home1_help","home1_topup","home1_share","home1_my_invite","home1_general","home1_live_tv","home1_follow_us","home1_custom_15","home1_custom_16","home1_custom_17","home1_custom_18","home1_custom_19","home1_custom_20"};
    private final String[] mainTitles={"Page","Website","My Level","Membership","Earn Rewards","Gallery +","External Media","Help Center","Top Up","Share App","My Invite","General","Live TV","Follow Us","New Link 15","New Link 16","New Link 17","New Link 18","New Link 19","New Link 20"};
    private final int[] mainIcons={R.drawable.ql_page_3d,R.drawable.ql_website_3d,R.drawable.ql_level_3d,R.drawable.ql_membership_3d,R.drawable.ql_rewards_3d,R.drawable.ql_gallery_3d,R.drawable.ql_external_3d,R.drawable.ql_help_3d,R.drawable.ql_topup_3d,R.drawable.ql_share_3d,R.drawable.ql_rewards_3d,R.drawable.ql_page_3d,R.drawable.ql_external_3d,R.drawable.ql_website_3d,R.drawable.ql_share_3d,R.drawable.ql_share_3d,R.drawable.ql_share_3d,R.drawable.ql_share_3d,R.drawable.ql_share_3d,R.drawable.ql_share_3d};
    private final FrameLayout[] mainCards=new FrameLayout[20];
    private final TextView[] mainLabels=new TextView[20];
    private final ImageView[] mainIconViews=new ImageView[20];
    private final String[] mainRemoteUrls=new String[20];
    private final String[] mainRemoteIconUrls=new String[20];
    private final int[] mainDisplayOrder={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
    private final boolean[] mainActive={true,true,true,true,true,true,true,true,true,true,true,true,true,true,false,false,false,false,false,false};
    private final int[] mainIconSize={44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44};
    private LinearLayout quickTrack;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        if(!SessionManager.hasUsableSession(this)){
            Intent i=new Intent(this,LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);finish();return;
        }
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},REQUEST_NOTIFICATIONS_V323);
        }
        PushRegistration.sync(this);
        loadCachedTheme();
        pendingFocusPostId=getIntent().getLongExtra("focusPostId",0);
        setContentView(build());
        validateStoredSession();
        loadCurrentProfile(); loadRemote(); loadNotificationCount(); loadMessageCount(); loadNewPeople(); loadFeed(true);
        startCarousel(); startPromoCarousel(); startLiveAdCarousel();
        if(getIntent().getBooleanExtra("openMyFeed",false)) handler.postDelayed(this::openMyFeed,220L);
    }

    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        if(intent!=null&&intent.getBooleanExtra("openMyFeed",false)) handler.postDelayed(this::openMyFeed,120L);
    }


    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==REQUEST_NOTIFICATIONS_V323) PushRegistration.sync(this);
    }

    private void loadCachedTheme(){BG=ThemeConfig.bg(this);BLUE=ThemeConfig.blue(this);PURPLE=ThemeConfig.purple(this);PINK=ThemeConfig.pink(this);}

    private void validateStoredSession(){
        final String token=SessionManager.getToken(this);
        if(token==null||token.isEmpty()){routeToLoginForExpiredSession();return;}
        BackendClient.me(token,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                JSONObject u=d.optJSONObject("user");if(u==null)return;
                try{
                    Role role=Role.valueOf(u.optString("role",SessionManager.getRole(MainActivity.this).name()));
                    String uid=u.optString("userId",SessionManager.getUserId(MainActivity.this));
                    SessionManager.setRemoteSession(MainActivity.this,token,role,uid);
                    SessionManager.saveProfile(MainActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""),u.optString("avatarUrl",""),u.optString("coverUrl",""),u.optString("bio",""));
                    PushRegistration.sync(MainActivity.this);
                }catch(Throwable ignored){}
            }
            public void onError(String m){
                if("UNAUTHORIZED".equalsIgnoreCase(String.valueOf(m).trim())) runOnUiThread(()->routeToLoginForExpiredSession());
                // Network/server errors do not destroy a known session. Cached login stays active.
            }
        });
    }
    private void routeToLoginForExpiredSession(){
        if(sessionValidationRouted)return;sessionValidationRouted=true;
        SessionManager.clear(this);
        Intent i=new Intent(this,LoginActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(i);finish();
    }


    private View build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(BG);
        final LinearLayout fixed=col(); fixed.setPadding(dp(4),dp(8),dp(4),0); fixed.setBackgroundColor(BG);
        fixed.addView(header(),lp(-1,dp(58)));
        fixed.addView(breaking(),top(lp(-1,dp(42)),5));

        scroll=new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);

        LinearLayout page=col();
        page.setPadding(dp(4),dp(4),dp(4),dp(92));
        page.setBackgroundColor(BG);
        page.setOnApplyWindowInsetsListener((v,insets)->{
            int bottomInset=Math.max(0,insets.getSystemWindowInsetBottom());
            v.setPadding(dp(4),dp(4),dp(4),dp(76)+bottomInset);
            return insets;
        });

        // V-395 reference order. The headline stays locked; the lower dashboard naturally
        // scrolls away for a larger feed and returns when the user scrolls upward.
        feedAnchor=feedComposerSection();
        page.addView(feedAnchor,top(lp(-1,-2),5));

        hero=pic(heroImgs[0]);
        hero.setBackground(round(Color.WHITE,Color.rgb(225,228,240),16));
        hero.setClipToOutline(true); hero.setScaleType(ImageView.ScaleType.CENTER_CROP); hero.setAdjustViewBounds(false);
        hero.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){heroDownX=e.getX();heroDownY=e.getY();v.getParent().requestDisallowInterceptTouchEvent(true);return true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE){float dx=e.getX()-heroDownX,dy=e.getY()-heroDownY;if(Math.abs(dy)>Math.abs(dx)&&Math.abs(dy)>dp(8)){v.getParent().requestDisallowInterceptTouchEvent(false);return false;}return true;}
            if(e.getAction()==MotionEvent.ACTION_UP){v.getParent().requestDisallowInterceptTouchEvent(false);float dx=e.getX()-heroDownX;if(Math.abs(dx)>dp(42)){showHeroSlide(dx<0?nextHeroSlide(slide):previousHeroSlide(slide));scheduleHeroCarousel();}else openHeroTarget();return true;}
            if(e.getAction()==MotionEvent.ACTION_CANCEL)v.getParent().requestDisallowInterceptTouchEvent(false);return true;
        });
        if(SessionManager.isAdmin(this))hero.setOnLongClickListener(v->{startActivity(new Intent(this,BannerAdminActivity.class).putExtra("admin_context",true));return true;});
        page.addView(hero,top(lp(-1,dp(148)),6));
        hero.post(()->{ViewGroup.LayoutParams p=hero.getLayoutParams();if(p!=null&&hero.getWidth()>0){p.height=Math.max(dp(132),Math.round(hero.getWidth()/2.63f));hero.setLayoutParams(p);}});

        dots=text("●   ○   ○   ○   ○   ○",BLUE,9,true); dots.setGravity(Gravity.CENTER); page.addView(dots,lp(-1,dp(17)));
        page.addView(shortcutSection(),top(lp(-1,-2),4));
        page.addView(doublePromos(),top(lp(-1,dp(74)),5));

        feedStatus=text(LanguageManager.t(this,"loadingFeed"),MUTED,8.8f,false); feedStatus.setGravity(Gravity.CENTER); page.addView(feedStatus,top(lp(-1,dp(32)),7));
        feedList=col(); page.addView(feedList,lp(-1,-2));
        scroll.addView(page,new ScrollView.LayoutParams(-1,-2));

        final View bottomNav=bottom();
        final View portalBar=liveStreamingSection();
        final boolean[] chromeHidden={false};
        final int fixedHeight=110;
        final int[] topInset={0};
        scroll.setOnScrollChangeListener((v,sx,sy,osx,osy)->{
            View child=scroll.getChildAt(0); if(child!=null && sy+scroll.getHeight()>=child.getHeight()-dp(420)) loadFeed(false); updateInlineVideoPlayback();
            int dy=sy-osy;if(Math.abs(dy)>dp(2)){if(dy>0 && sy>dp(40) && !chromeHidden[0]){chromeHidden[0]=true;portalBar.animate().translationY(-dp(76)).alpha(0f).setDuration(190).start();bottomNav.animate().translationY(dp(82)).alpha(0f).setDuration(190).start();animateScrollTopMargin(topInset[0]+dp(fixedHeight),190);}else if(dy<0 && chromeHidden[0]){chromeHidden[0]=false;portalBar.animate().translationY(0f).alpha(1f).setDuration(190).start();bottomNav.animate().translationY(0f).alpha(1f).setDuration(190).start();animateScrollTopMargin(topInset[0]+dp(fixedHeight+72),190);}}
            if(sy<=dp(8)&&chromeHidden[0]){chromeHidden[0]=false;portalBar.animate().translationY(0f).alpha(1f).setDuration(160).start();bottomNav.animate().translationY(0f).alpha(1f).setDuration(160).start();animateScrollTopMargin(topInset[0]+dp(fixedHeight+72),160);}
        });

        FrameLayout.LayoutParams scrollLp=new FrameLayout.LayoutParams(-1,-1); scrollLp.topMargin=dp(fixedHeight+72); root.addView(scroll,scrollLp);
        root.addView(fixed,new FrameLayout.LayoutParams(-1,dp(fixedHeight),Gravity.TOP));
        FrameLayout.LayoutParams portalLp=new FrameLayout.LayoutParams(-1,dp(68),Gravity.TOP); portalLp.topMargin=dp(fixedHeight+2);portalLp.leftMargin=dp(4);portalLp.rightMargin=dp(4);root.addView(portalBar,portalLp);
        final FrameLayout.LayoutParams navLp=new FrameLayout.LayoutParams(-1,dp(64),Gravity.BOTTOM); root.addView(bottomNav,navLp);

        root.setOnApplyWindowInsetsListener((v,insets)->{
            int ti=Math.max(0,insets.getSystemWindowInsetTop()); int bi=Math.max(0,insets.getSystemWindowInsetBottom());topInset[0]=ti;
            fixed.setPadding(dp(4),ti+dp(8),dp(4),0);
            FrameLayout.LayoutParams fp=(FrameLayout.LayoutParams)fixed.getLayoutParams();fp.height=ti+dp(fixedHeight);fixed.setLayoutParams(fp);
            FrameLayout.LayoutParams sp=(FrameLayout.LayoutParams)scroll.getLayoutParams();sp.topMargin=ti+dp(fixedHeight+(chromeHidden[0]?0:72));sp.bottomMargin=Math.max(0,bi-dp(6));scroll.setLayoutParams(sp);
            FrameLayout.LayoutParams pp=(FrameLayout.LayoutParams)portalBar.getLayoutParams();pp.topMargin=ti+dp(fixedHeight+2);portalBar.setLayoutParams(pp);
            navLp.bottomMargin=Math.max(0,bi-dp(6)); bottomNav.setLayoutParams(navLp); return insets;
        });
        root.post(root::requestApplyInsets); return root;
    }

    private void animateScrollTopMargin(int target,int duration){if(scroll==null)return;android.view.ViewGroup.LayoutParams raw=scroll.getLayoutParams();if(!(raw instanceof FrameLayout.LayoutParams))return;FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)raw;int start=lp.topMargin;if(start==target)return;if(chromeMarginAnimator!=null)chromeMarginAnimator.cancel();chromeMarginAnimator=ValueAnimator.ofInt(start,target);chromeMarginAnimator.setDuration(duration);chromeMarginAnimator.addUpdateListener(a->{FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)scroll.getLayoutParams();p.topMargin=(Integer)a.getAnimatedValue();scroll.setLayoutParams(p);});chromeMarginAnimator.start();}

    private View header(){
        FrameLayout shell=new FrameLayout(this); shell.setClipToPadding(false); shell.setClipChildren(false);
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.rgb(8,33,103),Color.rgb(13,65,181),Color.rgb(20,73,215)});bg.setCornerRadius(dp(18));shell.setBackground(bg);shell.setElevation(dp(4));
        LinearLayout h=row();h.setGravity(Gravity.CENTER_VERTICAL);h.setPadding(dp(5),dp(2),dp(5),dp(1));
        ImageView av=new ImageView(this);headerAvatar=av;av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setBackground(round(Color.WHITE,Color.WHITE,24));av.setClipToOutline(true);av.setElevation(dp(2));av.setContentDescription("Profile menu");String avatarUrl=SessionManager.getAvatarUrl(this);if(avatarUrl!=null&&!avatarUrl.isEmpty())loadRemoteImage(av,avatarUrl);av.setOnClickListener(v->startActivity(new Intent(this,UserMenuActivity.class)));h.addView(av,lp(dp(44),dp(44)));
        LinearLayout brand=col();brand.setGravity(Gravity.CENTER_VERTICAL);brand.setPadding(dp(7),0,0,0);TextView name=text("MY SHOP",Color.WHITE,17.5f,true);SpannableString brandSpan=new SpannableString("MY SHOP");brandSpan.setSpan(new ForegroundColorSpan(Color.rgb(255,202,45)),0,2,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);brandSpan.setSpan(new ForegroundColorSpan(Color.rgb(245,251,255)),3,7,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);name.setText(brandSpan);name.setSingleLine(true);name.setLetterSpacing(.025f);name.setShadowLayer(dp(2),0,dp(1),Color.rgb(0,115,255));brand.addView(name,lp(-1,dp(27)));TextView tag=text("Shop • Social • Live • Earn",Color.rgb(234,241,255),7.0f,true);tag.setSingleLine(true);brand.addView(tag,lp(-1,dp(14)));h.addView(brand,weight(1,dp(45)));
        TextView lang=text("🌐 "+languageCode()+"⌄",Color.WHITE,8.0f,true);lang.setGravity(Gravity.CENTER);lang.setSingleLine(true);lang.setBackground(round(Color.argb(42,255,255,255),Color.TRANSPARENT,11));lang.setOnClickListener(v->LanguageManager.showPicker(this,()->recreate()));h.addView(lang,lp(dp(52),dp(42)));
        FrameLayout bellBox=headerAction(R.drawable.notification_bell,"Notifications");notificationBadge=text("",Color.WHITE,7.2f,true);notificationBadge.setGravity(Gravity.CENTER);notificationBadge.setBackground(round(RED,Color.TRANSPARENT,9));FrameLayout.LayoutParams nb=new FrameLayout.LayoutParams(dp(18),dp(18),Gravity.TOP|Gravity.END);bellBox.addView(notificationBadge,nb);bellBox.setOnClickListener(v->startActivity(new Intent(this,NotificationActivity.class)));h.addView(bellBox,lp(dp(39),dp(44)));updateNotificationBadge();
        FrameLayout chatBox=headerMessageAction();messageBadge=text("",Color.WHITE,7.2f,true);messageBadge.setGravity(Gravity.CENTER);messageBadge.setBackground(round(RED,Color.TRANSPARENT,9));FrameLayout.LayoutParams mb=new FrameLayout.LayoutParams(dp(18),dp(18),Gravity.TOP|Gravity.END);chatBox.addView(messageBadge,mb);chatBox.setOnClickListener(v->startActivity(new Intent(this,InboxActivity.class)));h.addView(chatBox,lp(dp(39),dp(44)));updateMessageBadge();
        FrameLayout search=headerAction(android.R.drawable.ic_menu_search,"Search");search.setOnClickListener(v->startActivity(new Intent(this,SearchActivity.class)));h.addView(search,lp(dp(39),dp(44)));
        shell.addView(h,new FrameLayout.LayoutParams(-1,-1));
        if(SessionManager.isAdmin(this))shell.setOnLongClickListener(v->{Intent i=new Intent(this,AdminSectionActivity.class);i.putExtra("section","dashboard");i.putExtra("admin_context",true);startActivity(i);return true;});return shell;
    }
    private FrameLayout headerAction(int iconRes,String description){FrameLayout box=new FrameLayout(this);ImageView icon=new ImageView(this);icon.setImageResource(iconRes);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setPadding(dp(6),dp(6),dp(6),dp(6));icon.setImageTintList(ColorStateList.valueOf(Color.WHITE));icon.setContentDescription(description);box.addView(icon,new FrameLayout.LayoutParams(-1,-1));applyRipple(box);return box;}
    private FrameLayout headerMessageAction(){FrameLayout box=new FrameLayout(this);ImageView icon=new ImageView(this);icon.setImageResource(R.drawable.ui_message_hd);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setPadding(dp(3),dp(3),dp(3),dp(3));icon.clearColorFilter();icon.setContentDescription("Messages");box.addView(icon,new FrameLayout.LayoutParams(-1,-1));applyRipple(box);return box;}

    private View threeLineMenu(){
        LinearLayout box=col(); box.setGravity(Gravity.CENTER); box.setPadding(dp(5),dp(6),dp(5),dp(6)); box.setBackground(round(Color.TRANSPARENT,Color.TRANSPARENT,12));
        int[] colors={Color.rgb(31,64,180),Color.rgb(245,141,0),Color.rgb(27,163,105)};
        for(int i=0;i<colors.length;i++){ View line=new View(this); line.setBackground(round(colors[i],Color.TRANSPARENT,3)); LinearLayout.LayoutParams q=lp(dp(30),dp(5)); if(i>0)q.topMargin=dp(4); box.addView(line,q); }
        return box;
    }


    private View breaking(){
        LinearLayout b=row(); breakingBox=b;
        b.setPadding(dp(5),dp(1),dp(5),dp(1));
        b.setBackground(round(Color.rgb(255,239,247),Color.rgb(255,214,232),11));

        TextView megaphone=text("📣",Color.rgb(235,35,53),26,true);
        megaphone.setGravity(Gravity.CENTER);
        megaphone.setContentDescription("Breaking news");
        b.setClipChildren(true);b.setClipToPadding(true);b.addView(megaphone,lp(dp(44),dp(40)));

        ObjectAnimator sx=ObjectAnimator.ofFloat(megaphone,"scaleX",.96f,1.10f,.96f);
        ObjectAnimator sy=ObjectAnimator.ofFloat(megaphone,"scaleY",.96f,1.10f,.96f);
        ObjectAnimator al=ObjectAnimator.ofFloat(megaphone,"alpha",1f,.48f,1f);
        sx.setRepeatCount(ValueAnimator.INFINITE); sy.setRepeatCount(ValueAnimator.INFINITE); al.setRepeatCount(ValueAnimator.INFINITE);
        sx.setDuration(1250); sy.setDuration(1250); al.setDuration(1250);
        AnimatorSet glow=new AnimatorSet(); glow.playTogether(sx,sy,al); glow.start();

        newsTextSizeSp=Math.max(newsTextSizeSp,13.0f);
        newsText=text("আপনার উন্নয়ন ও নতুন ফিচার যুক্ত করার খবর এখানে দেখাবে",Color.rgb(65,70,98),newsTextSizeSp,true);
        newsText.setGravity(Gravity.CENTER_VERTICAL);
        newsText.setSingleLine(true);
        newsText.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        newsText.setMarqueeRepeatLimit(-1);
        newsText.setSelected(true);
        newsText.setHorizontallyScrolling(true);
        newsText.setPadding(dp(5),0,dp(5),0);
        b.addView(newsText,weight(1,dp(40)));

        b.setOnClickListener(v->{if(SessionManager.isAdmin(this)){Intent i=new Intent(this,AdminSectionActivity.class);i.putExtra("section","dashboard");i.putExtra("admin_context",true);startActivity(i);}});
        applyRipple(b);
        return b;
    }

    private View doublePromos(){
        LinearLayout r=row();ImageView a=pic(left[0]),b=pic(right[0]);promoViews[0]=a;promoViews[1]=b;a.setScaleType(ImageView.ScaleType.CENTER_CROP);b.setScaleType(ImageView.ScaleType.CENTER_CROP);
        View.OnTouchListener promoTouch=(v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){promoDownX=e.getX();promoDownY=e.getY();v.getParent().requestDisallowInterceptTouchEvent(true);return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){float dx=e.getX()-promoDownX,dy=e.getY()-promoDownY;if(Math.abs(dy)>Math.abs(dx)&&Math.abs(dy)>dp(8)){v.getParent().requestDisallowInterceptTouchEvent(false);return false;}return true;}if(e.getAction()==MotionEvent.ACTION_UP){v.getParent().requestDisallowInterceptTouchEvent(false);float dx=e.getX()-promoDownX;if(Math.abs(dx)>dp(36)){promoSlide=(promoSlide+(dx<0?1:5))%6;applyPromoSlide();schedulePromoCarousel();}else{if(SessionManager.isAdmin(this))startActivity(new Intent(this,BannerAdminActivity.class).putExtra("admin_context",true));else openPromoTarget(v==a?0:1);}return true;}if(e.getAction()==MotionEvent.ACTION_CANCEL)v.getParent().requestDisallowInterceptTouchEvent(false);return true;};a.setOnTouchListener(promoTouch);b.setOnTouchListener(promoTouch);
        r.addView(a,weight(1,dp(74)));r.addView(space(),lp(dp(6),1));r.addView(b,weight(1,dp(74)));return r;
    }

    private View sectionTitle(String title,boolean all){
        LinearLayout h=row(); h.addView(text(title,DARK,13,true),weight(1,dp(28))); if(all){TextView a=text("View All",BLUE,9.5f,true);a.setGravity(Gravity.CENTER);a.setOnClickListener(v->openFeature("LIVE","live_now"));h.addView(a,lp(dp(58),dp(28)));} return h;
    }

    private View liveRow(){
        realLiveProfilesRow=row(); realLiveProfilesRow.setGravity(Gravity.CENTER_VERTICAL); realLiveProfilesRow.setPadding(dp(1),0,dp(1),0);
        loadRealLiveProfiles();
        return realLiveProfilesRow;
    }

    private void loadRealLiveProfiles(){
        if(realLiveProfilesRow==null||liveProfilesLoading)return;
        liveProfilesLoading=true;
        BackendClient.liveProfiles(SessionManager.getToken(this),4,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){if(dashboardDestroyed)return;runOnUiThread(()->{if(dashboardDestroyed)return;liveProfilesLoading=false;renderRealLiveProfiles(d.optJSONArray("profiles"));});}
            public void onError(String m){if(dashboardDestroyed)return;runOnUiThread(()->{if(dashboardDestroyed)return;liveProfilesLoading=false;renderRealLiveProfiles(null);});}
        });
    }
    private void renderRealLiveProfiles(JSONArray a){
        if(realLiveProfilesRow==null)return; realLiveProfilesRow.removeAllViews();
        int shown=0;
        if(a!=null)for(int i=0;i<a.length()&&shown<4;i++){
            JSONObject x=a.optJSONObject(i);if(x==null)continue;
            final String uid=x.optString("userId","");
            final String nm=x.optString("name",x.optBoolean("live",false)?"Live":"New User");
            String av=x.optString("avatarUrl","");
            int viewers=x.optInt("viewerCount",0);
            boolean isLive=x.optBoolean("live",true);
            final String relation=x.optString("state","NONE");
            LinearLayout wrap=col();wrap.setGravity(Gravity.CENTER_HORIZONTAL);wrap.setPadding(dp(4),dp(3),dp(4),dp(3));wrap.setBackground(round(Color.WHITE,Color.rgb(226,229,240),14));
            FrameLayout card=new FrameLayout(this);card.setBackground(round(Color.WHITE,isLive?Color.rgb(255,55,186):Color.rgb(210,216,238),26));
            ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setImageResource(R.drawable.myshop_profile_avatar);im.setClipToOutline(true);if(!av.isEmpty())loadRemoteImage(im,av);card.addView(im,new FrameLayout.LayoutParams(dp(66),dp(66),Gravity.CENTER));
            if(x.optBoolean("online",false)){View dot=new View(this);dot.setBackground(round(GREEN,Color.WHITE,20));FrameLayout.LayoutParams dpv=new FrameLayout.LayoutParams(dp(7),dp(7),Gravity.BOTTOM|Gravity.RIGHT);dpv.rightMargin=dp(5);dpv.bottomMargin=dp(9);card.addView(dot,dpv);}
            if(isLive){ObjectAnimator px=ObjectAnimator.ofFloat(card,"scaleX",1f,1.035f,1f);ObjectAnimator py=ObjectAnimator.ofFloat(card,"scaleY",1f,1.035f,1f);px.setRepeatCount(ValueAnimator.INFINITE);py.setRepeatCount(ValueAnimator.INFINITE);px.setDuration(1250);py.setDuration(1250);AnimatorSet pulse=new AnimatorSet();pulse.playTogether(px,py);pulse.start();}
            wrap.addView(card,lp(dp(78),dp(78)));
            TextView nameView=text(nm,NAVY,10.2f,true);nameView.setGravity(Gravity.CENTER);nameView.setSingleLine(true);nameView.setEllipsize(TextUtils.TruncateAt.END);if(Build.VERSION.SDK_INT>=26)nameView.setAutoSizeTextTypeUniformWithConfiguration(8,11,1,android.util.TypedValue.COMPLEX_UNIT_SP);wrap.addView(nameView,lp(-1,dp(18)));
            LinearLayout meta=row();meta.setGravity(Gravity.CENTER);TextView idv=text("🆔 "+uid,MUTED,8.6f,true);idv.setSingleLine(true);TextView lv=text("LV."+Math.max(0,x.optInt("level",0)),NAVY,8.6f,true);lv.setSingleLine(true);meta.addView(idv,lp(-2,dp(18)));meta.addView(space(),lp(dp(6),1));meta.addView(lv,lp(-2,dp(18)));wrap.addView(meta,lp(-1,dp(19)));
            if(isLive){TextView vc=text(viewers>0?"◉ "+compactCount(viewers):"",MUTED,8.2f,true);vc.setGravity(Gravity.CENTER);wrap.addView(vc,lp(dp(78),dp(12)));}
            else{
                TextView add=fixedFriendAction(relation);
                if("FRIEND".equals(relation)){add.setEnabled(false);add.setAlpha(.78f);}else if("REQUESTED".equals(relation)){add.setAlpha(.86f);add.setOnClickListener(v->cancelFriendRequest(uid,add));}else if("INCOMING".equals(relation)){add.setOnClickListener(v->startActivity(new Intent(this,FriendRequestsActivity.class)));}else{add.setOnClickListener(v->{try{JSONObject person=new JSONObject().put("userId",uid).put("state",relation);sendFriendRequest(person,add);}catch(Exception ignored){}});}LinearLayout.LayoutParams abp=lp(-1,dp(30));abp.setMargins(dp(3),0,dp(3),0);wrap.addView(add,abp);
            }
            wrap.setOnClickListener(v->{if(isLive){openFeature(nm,"live_now");}else{Intent q=new Intent(MainActivity.this,UserProfileActivity.class);q.putExtra("userId",uid);startActivity(q);}});
            realLiveProfilesRow.addView(wrap,weight(1,isLive?dp(132):dp(148)));shown++;
        }
        if(shown==0){ renderDynamicFoldersFallbackForLive(); }
    }
    private String compactCount(int n){if(n>=1000000)return String.format(java.util.Locale.US,"%.1fM",n/1000000f);if(n>=1000)return String.format(java.util.Locale.US,"%.1fK",n/1000f);return String.valueOf(n);}
    private void renderDynamicFoldersFallbackForLive(){
        if(realLiveProfilesRow==null)return;
        int shown=0;
        for(int i=0;i<newPeopleData.size()&&shown<4;i++){
            JSONObject p=newPeopleData.get(i);if(p==null)continue;
            final String uid=p.optString("userId","");final String relation=p.optString("state","NONE");String nm=p.optString("name","New User"),av=p.optString("avatarUrl","");
            LinearLayout wrap=col();wrap.setGravity(Gravity.CENTER_HORIZONTAL);wrap.setPadding(dp(4),dp(3),dp(4),dp(3));wrap.setBackground(round(Color.WHITE,Color.rgb(226,229,240),14));
            FrameLayout card=new FrameLayout(this);card.setBackground(round(Color.WHITE,Color.rgb(210,216,238),26));
            ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setImageResource(R.drawable.myshop_profile_avatar);im.setClipToOutline(true);if(!av.isEmpty())loadRemoteImage(im,av);card.addView(im,new FrameLayout.LayoutParams(dp(66),dp(66),Gravity.CENTER));if(p.optBoolean("online",false)){View dot2=new View(this);dot2.setBackground(round(GREEN,Color.WHITE,20));FrameLayout.LayoutParams d2=new FrameLayout.LayoutParams(dp(7),dp(7),Gravity.BOTTOM|Gravity.RIGHT);d2.rightMargin=dp(5);d2.bottomMargin=dp(9);card.addView(dot2,d2);}wrap.addView(card,lp(dp(78),dp(78)));
            TextView t=text(nm,NAVY,10.2f,true);t.setGravity(Gravity.CENTER);t.setSingleLine(true);t.setEllipsize(TextUtils.TruncateAt.END);if(Build.VERSION.SDK_INT>=26)t.setAutoSizeTextTypeUniformWithConfiguration(8,11,1,android.util.TypedValue.COMPLEX_UNIT_SP);wrap.addView(t,lp(-1,dp(18)));
            LinearLayout meta=row();meta.setGravity(Gravity.CENTER);TextView idv=text("🆔 "+uid,MUTED,8.6f,true);idv.setSingleLine(true);TextView lv=text("LV."+Math.max(0,p.optInt("level",0)),NAVY,8.6f,true);lv.setSingleLine(true);meta.addView(idv,lp(-2,dp(18)));meta.addView(space(),lp(dp(6),1));meta.addView(lv,lp(-2,dp(18)));wrap.addView(meta,lp(-1,dp(19)));
            TextView add=fixedFriendAction(relation);
            if("FRIEND".equals(relation)){add.setEnabled(false);add.setAlpha(.78f);}else if("REQUESTED".equals(relation)){add.setAlpha(.86f);add.setOnClickListener(v->cancelFriendRequest(uid,add));}else if("INCOMING".equals(relation)){add.setOnClickListener(v->startActivity(new Intent(this,FriendRequestsActivity.class)));}else add.setOnClickListener(v->sendFriendRequest(p,add));LinearLayout.LayoutParams abp=lp(-1,dp(30));abp.setMargins(dp(3),dp(1),dp(3),0);wrap.addView(add,abp);
            wrap.setOnClickListener(v->{Intent q=new Intent(MainActivity.this,UserProfileActivity.class);q.putExtra("userId",uid);startActivity(q);});realLiveProfilesRow.addView(wrap,weight(1,dp(148)));shown++;
        }
        for(;shown<4;shown++){LinearLayout wrap=col();wrap.setGravity(Gravity.CENTER_HORIZONTAL);wrap.setPadding(dp(3),dp(2),dp(3),dp(2));wrap.setBackground(round(Color.WHITE,Color.rgb(232,234,242),12));View circle=new View(this);circle.setBackground(round(Color.rgb(238,240,246),Color.rgb(226,229,238),28));wrap.addView(circle,lp(dp(58),dp(58)));View line1=new View(this);line1.setBackground(round(Color.rgb(238,240,246),Color.TRANSPARENT,6));LinearLayout.LayoutParams l1=lp(dp(58),dp(10));l1.topMargin=dp(6);wrap.addView(line1,l1);View line2=new View(this);line2.setBackground(round(Color.rgb(242,243,248),Color.TRANSPARENT,6));LinearLayout.LayoutParams l2=lp(dp(70),dp(20));l2.topMargin=dp(7);wrap.addView(line2,l2);ObjectAnimator a=ObjectAnimator.ofFloat(wrap,"alpha",.55f,1f,.55f);a.setDuration(1100);a.setRepeatCount(ValueAnimator.INFINITE);a.start();realLiveProfilesRow.addView(wrap,weight(1,dp(156)));}
    }

    /** V-230: dynamic dashboard content remains INSIDE the existing small circular/live row.
     * No second placeholder row is created. Each slot has its own Admin editor. */
    private void renderDynamicFolders(JSONArray a){
        if(dynamicFolderBox==null)return;
        dynamicFolderBox.removeAllViews();
        JSONObject[] slots=new JSONObject[6];
        if(a!=null){
            for(int i=0;i<a.length();i++){
                JSONObject x=a.optJSONObject(i); if(x==null)continue;
                String cat=x.optString("category","").trim().toLowerCase();
                if(cat.startsWith("dashboard_slot_")){
                    try{int n=Integer.parseInt(cat.substring("dashboard_slot_".length()));if(n>=1&&n<=6&&slots[n-1]==null)slots[n-1]=x;}catch(Exception ignored){}
                }
            }
        }
        String[] defaults={"Shopping Live","Gadget Live","Fashion Live","Gaming Live","Beauty Live","AD"};
        String[] viewers={"1.2K","956","743","2.1K","1.8K",""};
        for(int i=0;i<6;i++){
            JSONObject cfg=slots[i];
            boolean slotActive=cfg==null || cfg.optInt("active",1)==1;
            boolean adminMode=SessionManager.isAdmin(this);
            if(!slotActive && !adminMode) continue; // hidden for normal users; Admin can still tap to restore
            LinearLayout wrap=col(); wrap.setGravity(Gravity.CENTER_HORIZONTAL); wrap.setPadding(dp(2),0,dp(2),0); wrap.setAlpha(slotActive?1f:0.48f);
            String title=cfg==null?defaults[i]:cfg.optString("title",defaults[i]).trim(); if(title.isEmpty())title=defaults[i]; if(!slotActive&&adminMode)title=title+" • HIDDEN";
            String caption=cfg==null?"":cfg.optString("caption","").trim();
            String url=cfg==null?"":cfg.optString("url","").trim();
            String image=cfg==null?"":cfg.optString("image_url","").trim();
            String iconUrl=cfg==null?"":cfg.optString("icon_url","").trim();
            FrameLayout card=new FrameLayout(this); card.setBackground(round(Color.WHITE,Color.rgb(255,72,182),40));
            ImageView im=new ImageView(this); im.setScaleType(ImageView.ScaleType.CENTER_CROP); im.setBackground(round(Color.WHITE,Color.TRANSPARENT,40)); im.setClipToOutline(true);
            if(i==5) im.setTag("live_folder_ad");
            if(!image.isEmpty())loadRemoteImage(im,image); else if(!iconUrl.isEmpty())loadRemoteImage(im,iconUrl); else im.setImageResource(i==5?R.drawable.banner_top_left_3:live[i%live.length]);
            card.addView(im,new FrameLayout.LayoutParams(dp(52),dp(52),Gravity.CENTER));
            TextView badge=text("● LIVE",Color.WHITE,6.3f,true); badge.setGravity(Gravity.CENTER); badge.setBackground(round(RED,Color.TRANSPARENT,8)); FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(50),dp(16),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL); card.addView(badge,bp);
            wrap.addView(card,lp(dp(56),dp(58)));
            final int slot=i+1; final String target=url; final String slotTitle=title;
            wrap.setOnClickListener(v->{
                if(SessionManager.isAdmin(this)){openFeatureCardAdmin("dashboard_slot_"+slot,"DASHBOARD SLOT "+slot);return;}
                if(FeatureRegistry.isSafeHttpUrl(target)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception ignored){}}
                else if(slot<=5)openFeature(slotTitle,"live_now");
            });
            dynamicFolderBox.addView(wrap,weight(1,dp(64)));
        }
    }

    private View liveStreamingSection(){
        LinearLayout row=row();row.setGravity(Gravity.CENTER_VERTICAL);row.setClipChildren(false);row.setClipToPadding(false);
        View store=homePortal(false,"PREMIUM SHOP","Membership • Frames • Rings • Live Themes • Entry",new int[]{Color.rgb(255,164,45),Color.rgb(190,52,218),Color.rgb(62,97,244)});store.setOnClickListener(v->startActivity(new Intent(this,StoreActivity.class)));
        View live=homePortal(true,"LIVE STREAMING","Go Live • Join Live • Enjoy",new int[]{Color.rgb(4,126,255),Color.rgb(25,60,220),Color.rgb(131,36,236)});live.setOnClickListener(v->startActivity(new Intent(this,LiveHomeActivity.class)));
        LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(0,dp(62),42f);a.rightMargin=dp(8);row.addView(store,a);row.addView(live,new LinearLayout.LayoutParams(0,dp(62),58f));
        if(SessionManager.isAdmin(this))row.setOnLongClickListener(v->{Intent i=new Intent(this,AdminHubActivity.class);i.putExtra("admin_context",true);startActivity(i);return true;});return row;
    }
    private View homePortal(boolean isLive,String title,String subtitle,int[] colors){
        FrameLayout shell=new FrameLayout(this);shell.setClipChildren(false);shell.setClipToPadding(false);GradientDrawable bg=gradient(colors[0],colors[colors.length-1],17);shell.setBackground(bg);shell.setElevation(dp(4));
        LinearLayout line=row();line.setGravity(Gravity.CENTER_VERTICAL);line.setPadding(dp(8),0,dp(6),0);
        View icon;
        if(isLive){BroadcastSignalView sig=new BroadcastSignalView(this);sig.setContentDescription("Live broadcast signal");icon=sig;}else{ImageView bag=new ImageView(this);bag.setImageResource(R.drawable.nav_store);bag.setImageTintList(ColorStateList.valueOf(Color.WHITE));bag.setScaleType(ImageView.ScaleType.CENTER_INSIDE);bag.setPadding(dp(4),dp(4),dp(4),dp(4));icon=bag;}
        line.addView(icon,lp(dp(44),dp(44)));
        LinearLayout copy=col();copy.setGravity(Gravity.CENTER_VERTICAL);TextView t=text(title,Color.WHITE,isLive?11.0f:11.5f,true);t.setSingleLine(true);if(isLive){SpannableString sp=new SpannableString(title);sp.setSpan(new ForegroundColorSpan(Color.WHITE),0,4,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);sp.setSpan(new ForegroundColorSpan(Color.rgb(25,226,255)),5,title.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);t.setText(sp);}copy.addView(t,lp(-1,dp(24)));TextView sub=text(subtitle,Color.rgb(244,247,255),7.8f,false);sub.setSingleLine(true);copy.addView(sub,lp(-1,dp(17)));line.addView(copy,weight(1,dp(44)));
        shell.addView(line,new FrameLayout.LayoutParams(-1,-1));
        if(isLive){ObjectAnimator glow=ObjectAnimator.ofFloat(shell,"alpha",0.93f,1f,0.93f);glow.setDuration(1800);glow.setRepeatCount(ValueAnimator.INFINITE);glow.setRepeatMode(ValueAnimator.RESTART);glow.start();}
        applyRipple(shell);return shell;
    }
    private static class BroadcastSignalView extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private final RectF r=new RectF();private float phase=0f;private ValueAnimator animator;
        BroadcastSignalView(Context c){super(c);p.setStrokeCap(Paint.Cap.ROUND);animator=ValueAnimator.ofFloat(0f,1f);animator.setDuration(1250);animator.setRepeatCount(ValueAnimator.INFINITE);animator.addUpdateListener(a->{phase=(float)a.getAnimatedValue();invalidate();});animator.start();}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f,min=Math.min(w,h);float beat=.72f+.28f*(float)Math.sin(phase*Math.PI*2f);p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(255,26,48));p.setAlpha(255);c.drawCircle(cx,cy,min*(.10f+.025f*beat),p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(3.2f,min*.072f));for(int i=0;i<3;i++){float rr=min*(.20f+i*.125f+.035f*beat);float pulse=(phase+i*.22f)%1f;int a=(int)(130+125*(1f-Math.abs(.5f-pulse)*2f));p.setColor(i==2?Color.rgb(255,82,96):Color.rgb(255,28,48));p.setAlpha(a);r.set(cx-rr,cy-rr,cx+rr,cy+rr);c.drawArc(r,-64,128,false,p);c.drawArc(r,116,128,false,p);}p.setStyle(Paint.Style.FILL);for(int i=0;i<6;i++){double ang=(phase*360+i*60)*Math.PI/180.0;float rr=min*(.39f+.05f*((i%2)==0?beat:1f-beat));p.setColor(Color.rgb(255,70,84));p.setAlpha(120+(i%3)*35);c.drawCircle(cx+(float)Math.cos(ang)*rr,cy+(float)Math.sin(ang)*rr,Math.max(1.5f,min*.025f),p);} }
        @Override protected void onDetachedFromWindow(){if(animator!=null)animator.cancel();super.onDetachedFromWindow();}
    }

    private View liveProfilesSection(){
        LinearLayout box=col();
        box.setPadding(dp(6),dp(4),dp(6),dp(4));
        box.setBackground(round(Color.WHITE,Color.rgb(229,231,240),16));
        LinearLayout profileHead=row(); profileHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView newTitle=text("●  New Users",NAVY,9.4f,true); newTitle.setTextColor(GREEN); newTitle.setGravity(Gravity.CENTER_VERTICAL); profileHead.addView(newTitle,lp(dp(86),dp(24)));
        TextView status=text("•  Live users first  •  New users when offline",MUTED,7.9f,true); status.setGravity(Gravity.CENTER_VERTICAL); status.setSingleLine(true); status.setEllipsize(TextUtils.TruncateAt.END); profileHead.addView(status,weight(1,dp(24)));
        TextView see=text("See All  →",BLUE,9.2f,true); see.setGravity(Gravity.CENTER); see.setSingleLine(true); see.setOnClickListener(v->showAllNewPeople()); profileHead.addView(see,lp(dp(68),dp(24))); box.addView(profileHead,lp(-1,dp(24)));
        box.addView(liveRow(),lp(-1,dp(158)));
        box.setElevation(dp(1));
        if(SessionManager.isAdmin(this)) box.setOnLongClickListener(v->{Intent a=new Intent(this,AdminSectionActivity.class);a.putExtra("section","dynamic_content");a.putExtra("admin_context",true);startActivity(a);return true;});
        return box;
    }

    private View newPeopleSection(){
        LinearLayout box=col(); box.setPadding(dp(6),dp(4),dp(6),dp(4)); box.setBackground(round(Color.WHITE,Color.rgb(229,231,240),14));
        LinearLayout head=row(); TextView title=text("New People",NAVY,10.5f,true); head.addView(title,weight(1,dp(24))); TextView see=text("See All  →",BLUE,8.5f,true); see.setGravity(Gravity.CENTER); see.setOnClickListener(v->showAllNewPeople()); head.addView(see,lp(dp(76),dp(24))); box.addView(head,lp(-1,dp(24)));
        newPeopleScroll=new HorizontalScrollView(this); newPeopleScroll.setHorizontalScrollBarEnabled(false); newPeopleScroll.setFillViewport(false); newPeopleRow=row(); newPeopleScroll.addView(newPeopleRow,new HorizontalScrollView.LayoutParams(-2,dp(90))); box.addView(newPeopleScroll,lp(-1,dp(90))); return box;
    }

    private void loadNewPeople(){
        String token=SessionManager.getToken(this);if(token==null||token.isEmpty())return;
        renderCachedNewPeople();
        BackendClient.newPeople(token,20,0,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                getSharedPreferences("myshop_people",MODE_PRIVATE).edit().putString("latest",d.toString()).apply();
                applyNewPeoplePayload(d);
            }
            public void onError(String m){ }
        });
    }
    private boolean renderCachedNewPeople(){try{String raw=getSharedPreferences("myshop_people",MODE_PRIVATE).getString("latest","");if(raw.isEmpty())return false;JSONObject cached=new JSONObject(raw);JSONArray people=cached.optJSONArray("people");if(people!=null)for(int i=0;i<people.length();i++){JSONObject p=people.optJSONObject(i);if(p!=null)p.put("online",false);}applyNewPeoplePayload(cached);return true;}catch(Exception e){return false;}}
    private void applyNewPeoplePayload(JSONObject d){JSONArray a=d.optJSONArray("people");newPeopleData.clear();if(a!=null)for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p!=null&&!SessionManager.getUserId(this).equals(p.optString("userId","")))newPeopleData.add(p);}if(!dashboardDestroyed)runOnUiThread(()->{if(dashboardDestroyed)return;renderNewPeople();/* Standalone block is removed in V-256, but the Live section still needs fresh New User fallback data. */if(realLiveProfilesRow!=null)loadRealLiveProfiles();});}
    private void renderNewPeople(){
        if(newPeopleSection==null||newPeopleRow==null)return;newPeopleRow.removeAllViews();
        if(newPeopleData.isEmpty()){newPeopleSection.setVisibility(View.GONE);return;}
        newPeopleSection.setVisibility(View.VISIBLE);int visible=Math.min(5,newPeopleData.size());int cardWidth=Math.max(dp(66),(getResources().getDisplayMetrics().widthPixels-dp(18))/5);
        for(int i=0;i<visible;i++)newPeopleRow.addView(newPersonCard(newPeopleData.get(i)),lp(cardWidth,dp(88)));
    }
    private View newPersonCard(JSONObject p){
        LinearLayout c=col();c.setGravity(Gravity.CENTER_HORIZONTAL);c.setPadding(dp(2),0,dp(2),0);c.setOnClickListener(v->{Intent q=new Intent(this,UserProfileActivity.class);q.putExtra("userId",p.optString("userId",""));startActivity(q);});
        ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setBackground(round(Color.rgb(239,241,248),Color.rgb(223,226,237),24));av.setClipToOutline(true);String url=p.optString("avatarUrl","");if(!url.isEmpty())loadRemoteImage(av,url);c.addView(av,lp(dp(42),dp(42)));
        TextView name=text(p.optString("name","New Member"),DARK,7.2f,true);name.setGravity(Gravity.CENTER);name.setSingleLine(true);name.setEllipsize(TextUtils.TruncateAt.END);c.addView(name,lp(-1,dp(18)));
        String state=p.optString("state","NONE");TextView add=fixedFriendAction(state);
        if("FRIEND".equals(state)){add.setEnabled(false);add.setAlpha(.78f);}else if("REQUESTED".equals(state)){add.setEnabled(false);add.setAlpha(.72f);}else if("INCOMING".equals(state)){add.setOnClickListener(v->startActivity(new Intent(this,FriendRequestsActivity.class)));}else add.setOnClickListener(v->sendFriendRequest(p,add));
        LinearLayout.LayoutParams abp=lp(-1,dp(24));abp.setMargins(dp(4),0,dp(4),0);c.addView(add,abp);return c;
    }
    /** Fixed/locked action button shell used by every dashboard user card.
     * Keeps icon/text on one line and prevents Add Friend/Respond/Requested/Friends overflow. */
    private TextView fixedFriendAction(String state){
        String label="FRIEND".equals(state)?"✓ Friends":"INCOMING".equals(state)?"Respond":"REQUESTED".equals(state)?"Requested":"＋ Add Friend";
        TextView b=text(label,Color.WHITE,7.8f,true); b.setGravity(Gravity.CENTER); b.setSingleLine(true); b.setMaxLines(1);
        b.setIncludeFontPadding(false); b.setPadding(dp(3),0,dp(3),0); b.setMinWidth(0); b.setMinimumWidth(0);
        int fill="REQUESTED".equals(state)?MUTED:"FRIEND".equals(state)?Color.rgb(28,148,104):BLUE;
        b.setBackground(round(fill,Color.TRANSPARENT,9)); applyRipple(b); return b;
    }

    private void sendFriendRequest(JSONObject person,TextView button){String id=person.optString("userId","");String token=SessionManager.getToken(this);if(token==null||token.isEmpty()||id.isEmpty())return;button.setEnabled(false);BackendClient.sendFriendRequest(token,id,new BackendClient.Callback(){public void onSuccess(JSONObject d){try{person.put("state","REQUESTED");}catch(Exception ignored){}button.setText("Requested");button.setAlpha(.7f);}public void onError(String m){button.setEnabled(true);if(m!=null&&m.toLowerCase().contains("pending")){button.setText("Requested");button.setAlpha(.7f);}else toast(m);}});}
    private void cancelFriendRequest(String userId,TextView button){String token=SessionManager.getToken(this);if(token==null||token.isEmpty()||userId==null||userId.isEmpty())return;button.setEnabled(false);button.setText("Cancelling…");BackendClient.cancelFriendRequest(token,userId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{button.setEnabled(true);button.setAlpha(1f);button.setText("＋ Add Friend");button.setOnClickListener(v->{try{JSONObject person=new JSONObject().put("userId",userId).put("state","NONE");sendFriendRequest(person,button);}catch(Exception ignored){}});});}public void onError(String m){runOnUiThread(()->{button.setEnabled(true);button.setText("Requested");toast(m);});}});}
    private void showAllNewPeople(){startActivity(new Intent(this,NewPeopleActivity.class));}

    private View liveActions(){ return liveStreamingSection(); }

    private View liveAdStrip(){
        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); hs.setFillViewport(false);
        liveAdStripView=hs; liveAdBox=row(); liveAdBox.setPadding(dp(4),dp(4),dp(4),dp(4)); liveAdBox.setBackground(round(Color.WHITE,Color.rgb(232,233,238),16));
        renderPowerAds();
        hs.addView(liveAdBox,new HorizontalScrollView.LayoutParams(-2,dp(92))); return hs;
    }

    private void renderPowerAds(){
        if(liveAdBox!=null){ liveAdBox.removeAllViews(); liveAdBox.setVisibility(View.GONE); }
        if(liveAds.isEmpty()) return;
        int n=Math.min(6,liveAds.size()); JSONObject a=liveAds.get(liveAdIndex%n);
        final ImageView target=findLiveFolderAd(); if(target==null)return;
        String u=a.optString("image_url",""); if(!u.isEmpty())loadRemoteImage(target,u);
        target.setOnClickListener(v->{if(SessionManager.isAdmin(this)){startActivity(new Intent(this,DashboardAdsAdminActivity.class).putExtra("admin_context",true).putExtra("box_key","live_now"));return;}String t=a.optString("target_url","");if(FeatureRegistry.isSafeHttpUrl(t)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(t)));}catch(Exception ignored){}}});
    }
    private ImageView findLiveFolderAd(){ if(scroll==null)return null; return findImageByTag(scroll,"live_folder_ad"); }
    private ImageView findImageByTag(View v,String tag){ if(v instanceof ViewGroup){ ViewGroup g=(ViewGroup)v; for(int i=0;i<g.getChildCount();i++){View c=g.getChildAt(i);if(tag.equals(c.getTag())&&c instanceof ImageView)return (ImageView)c; ImageView r=findImageByTag(c,tag);if(r!=null)return r;}} return null; }

    private View mainFeatureGrid(){
        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);hs.setFillViewport(false);quickTrack=row();quickTrack.setGravity(Gravity.TOP);renderQuickLinks();hs.addView(quickTrack,new HorizontalScrollView.LayoutParams(-2,dp(94)));return hs;
    }
    private void renderQuickLinks(){
        if(quickTrack==null)return;quickTrack.removeAllViews();ArrayList<Integer> ids=new ArrayList<>();for(int i=0;i<mainKeys.length;i++)if(mainActive[i])ids.add(i);java.util.Collections.sort(ids,(a,b)->Integer.compare(mainDisplayOrder[a],mainDisplayOrder[b]));
        int width=Math.max(dp(55),(getResources().getDisplayMetrics().widthPixels-dp(40)-dp(4)*4)/5);
        for(int idx:ids){LinearLayout.LayoutParams p=lp(width,dp(92));p.rightMargin=dp(4);quickTrack.addView(mainFeatureCard(idx),p);}
    }

    private View mainFeatureCard(final int idx){
        int[] tile={Color.rgb(226,246,255),Color.rgb(247,229,255),Color.rgb(224,246,255),Color.rgb(250,232,255),Color.rgb(230,255,235),Color.rgb(255,234,229),Color.rgb(226,240,255),Color.rgb(240,231,255),Color.rgb(222,251,248),Color.rgb(231,255,235)};
        FrameLayout card=new FrameLayout(this);mainCards[idx]=card;card.setBackground(round(tile[idx%tile.length],Color.TRANSPARENT,11));card.setElevation(dp(2));card.setAlpha(mainActive[idx]?1f:.45f);
        LinearLayout c=col();c.setGravity(Gravity.CENTER);c.setPadding(dp(3),dp(4),dp(3),dp(2));ImageView iv=new ImageView(this);mainIconViews[idx]=iv;iv.setImageResource(mainIcons[idx]);iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);iv.setElevation(dp(3));if(mainRemoteIconUrls[idx]!=null&&!mainRemoteIconUrls[idx].trim().isEmpty())loadRemoteImage(iv,mainRemoteIconUrls[idx].trim());int isz=Math.max(28,Math.min(56,mainIconSize[idx]));c.addView(iv,lp(dp(isz),dp(isz)));TextView t=text(mainTitles[idx],Color.rgb(28,48,134),7.6f,true);mainLabels[idx]=t;t.setGravity(Gravity.CENTER);t.setMaxLines(2);t.setEllipsize(TextUtils.TruncateAt.END);c.addView(t,lp(-1,dp(27)));card.addView(c,new FrameLayout.LayoutParams(-1,-1));applyRipple(card);card.setOnClickListener(v->openHomeShortcut(idx));card.setOnLongClickListener(v->{if(!SessionManager.isAdmin(this))return false;Intent manage=new Intent(this,PageIconAdminActivity.class);manage.putExtra("page","home1");startActivity(manage);return true;});return card;
    }
    private View shortcutSection(){
        LinearLayout box=col();box.setPadding(dp(7),dp(5),dp(7),dp(7));box.setBackground(round(Color.WHITE,Color.rgb(229,231,240),14));box.setElevation(dp(1));LinearLayout h=row();TextView title=text("🔗  Quick Links",NAVY,12.0f,true);h.addView(title,weight(1,dp(26)));TextView see=text("See All  →",BLUE,10.0f,true);see.setGravity(Gravity.CENTER);see.setOnClickListener(v->showQuickLinksAll());h.addView(see,lp(dp(76),dp(24)));box.addView(h,lp(-1,dp(26)));box.addView(mainFeatureGrid(),top(lp(-1,dp(94)),3));if(SessionManager.isAdmin(this))box.setOnLongClickListener(v->{startActivity(new Intent(this,PageIconAdminActivity.class).putExtra("page","home1").putExtra("admin_context",true));return true;});return box;
    }
    private void showQuickLinksAll(){showMoreQuickActions();}
    private void openHomeShortcut(int idx){
        if(idx<0||idx>=mainKeys.length||(!mainActive[idx]&&!SessionManager.isAdmin(this)))return;String remote=mainRemoteUrls[idx]==null?"":mainRemoteUrls[idx].trim();if(FeatureRegistry.isSafeHttpUrl(remote)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(remote)));return;}catch(Exception ignored){}}
        switch(idx){case 0:openQuickWeb("Page","facebook_page");break;case 1:openQuickWeb("Website","myshop_website");break;case 2:startActivity(new Intent(this,AccountActivity.class));break;case 3:{Intent i=new Intent(this,StoreActivity.class);i.putExtra("category","MEMBER");startActivity(i);break;}case 4:openQuickFeature("EARN & REWARD","earn_reward");break;case 5:startActivity(new Intent(this,MediaHubActivity.class));break;case 6:openQuickFeature("EXTERNAL MEDIA","external_movie");break;case 7:openQuickFeature("HELP CENTER","help_support");break;case 8:startActivity(new Intent(this,CoinWalletActivity.class));break;case 9:shareAppFromDashboard();break;case 10:if(SessionManager.isAdmin(this))startActivity(new Intent(this,AdminStoreActivity.class).putExtra("admin_context",true));else startActivity(new Intent(this,MyInviteActivity.class));break;case 11:if(SessionManager.isAdmin(this))startActivity(new Intent(this,AdminManagementActivity.class).putExtra("admin_context",true));else startActivity(new Intent(this,GeneralUsersActivity.class));break;case 12:if(SessionManager.isAdmin(this))startActivity(new Intent(this,LiveTvAdminActivity.class).putExtra("admin_context",true));else startActivity(new Intent(this,LiveTvActivity.class));break;case 13:if(SessionManager.isAdmin(this))startActivity(new Intent(this,AdminSectionActivity.class).putExtra("section","social").putExtra("admin_context",true));else startActivity(new Intent(this,FollowUsActivity.class));break;default:openQuickFeature(mainTitles[idx],mainKeys[idx]);break;}
    }
    private void openQuickWeb(String title,String key){String u=featureRemoteUrl(key);if(!FeatureRegistry.isSafeHttpUrl(u)){u=FeatureRegistry.getUrl(this,key);}if(!FeatureRegistry.isSafeHttpUrl(u)){toast(title+" link is not configured yet.");return;}try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){toast("Could not open "+title);}}
    private void openQuickFeature(String title,String key){Intent i=new Intent(this,FeatureActivity.class);i.putExtra("title",title);i.putExtra("feature_key",key);String u=featureRemoteUrl(key);if(FeatureRegistry.isSafeHttpUrl(u))i.putExtra("url",u);startActivity(i);}

    private View feedComposerSection(){
        LinearLayout box=col(); box.setPadding(dp(8),dp(6),dp(8),dp(6)); box.setBackground(round(Color.WHITE,Color.rgb(226,229,238),14)); box.setElevation(dp(1));
        LinearLayout title=row(); ImageView feedIcon=new ImageView(this); feedIcon.setImageResource(R.drawable.dash_action_feed); feedIcon.setScaleType(ImageView.ScaleType.FIT_CENTER); feedIcon.setAdjustViewBounds(true); feedIcon.setBackground(round(Color.rgb(235,242,255),Color.TRANSPARENT,18)); title.addView(feedIcon,lp(dp(76),dp(34)));
        View.OnClickListener feedFolderTap=v->{if(SessionManager.isAdmin(this))openAdminFolder("MY FEED","my_feed");}; feedIcon.setOnClickListener(feedFolderTap);
        TextView power=text(powerAdText(),PURPLE,8.5f,true);applyPowerAdColors(power);power.setGravity(Gravity.CENTER_VERTICAL);power.setOnClickListener(feedFolderTap);title.addView(power,weight(1,dp(34)));
        TextView see=text("See All  →",BLUE,8,true); see.setGravity(Gravity.CENTER); see.setOnClickListener(v->{if(SessionManager.isAdmin(this)){openAdminFolder("MY FEED","my_feed");return;}if(scroll!=null)scroll.smoothScrollTo(0,0);}); title.addView(see,lp(dp(72),dp(30))); box.addView(title,lp(-1,dp(35)));

        LinearLayout compose=row(); ImageView av=new ImageView(this); composerAvatar=av; av.setImageResource(R.drawable.myshop_profile_avatar); av.setScaleType(ImageView.ScaleType.CENTER_CROP); av.setBackground(round(Color.rgb(238,240,248),Color.TRANSPARENT,20)); av.setClipToOutline(true); String avatarUrl=SessionManager.getAvatarUrl(this); if(avatarUrl!=null&&!avatarUrl.isEmpty())loadRemoteImage(av,avatarUrl); compose.addView(av,lp(dp(42),dp(42)));
        TextView hint=text("What's on your mind?",MUTED,11.2f,false); hint.setGravity(Gravity.CENTER_VERTICAL); hint.setPadding(dp(12),0,dp(8),0); hint.setBackground(round(Color.rgb(244,246,250),Color.rgb(231,233,240),15)); hint.setOnClickListener(v->showTextPostDialog()); compose.addView(hint,weight(1,dp(42))); box.addView(compose,top(lp(-1,dp(42)),4));

        LinearLayout acts=row(); TextView photo=miniFeedAction("▣  Photo",GREEN); TextView video=miniFeedAction("●  Video",RED); TextView post=miniFeedAction("➤  Post",PURPLE); photo.setOnClickListener(v->pickPost("image")); video.setOnClickListener(v->pickPost("video")); post.setOnClickListener(v->showTextPostDialog()); acts.addView(photo,weight(1,dp(28))); acts.addView(video,weight(1,dp(28))); acts.addView(post,weight(1,dp(28))); box.addView(acts,top(lp(-1,dp(28)),3));
        postLimit=text("",MUTED,7,false); postLimit.setVisibility(View.GONE); if(SessionManager.isAdmin(this))box.setOnLongClickListener(v->{openAdminFolder("MY FEED","my_feed");return true;}); return box;
    }

    private TextView miniFeedAction(String label,int color){TextView t=text(label,color,9.4f,true);t.setGravity(Gravity.CENTER);t.setSingleLine(true);return t;}

    private View feedSection(){ return feedComposerSection(); }

    private void showFeedFilter(){
        new AlertDialog.Builder(this).setTitle(LanguageManager.t(this,"filter"))
                .setItems(new String[]{LanguageManager.t(this,"textPost"),LanguageManager.t(this,"galleryAction")},(d,w)->{if(w==0)showTextPostDialog();else pickPost("image");}).show();
    }

    private boolean renderCachedFeed(){
        try{String raw=getSharedPreferences("myshop_feed_cache",MODE_PRIVATE).getString("first_page","");if(raw.isEmpty())return false;JSONObject d=new JSONObject(raw);JSONArray a=d.optJSONArray("posts");if(a==null||a.length()==0)return false;feedList.removeAllViews();renderedPostIds.clear();postViews.clear();inlineVideos.clear();activeInlineVideo=null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)renderPost(x);}feedBefore=d.optLong("nextBefore",0);feedHasMore=d.optBoolean("hasMore",feedBefore>0);if(feedStatus!=null)feedStatus.setText("Updating Feed…");return true;}catch(Exception e){return false;}
    }
    private void loadFeed(boolean reset){
        lastFeedLoadAt=System.currentTimeMillis();
        if(feedLoading || (!feedHasMore && !reset)) return; String token=SessionManager.getToken(this); if(token==null||token.isEmpty()){if(feedStatus!=null)feedStatus.setText(LanguageManager.t(this,"loginFeed"));return;}
        feedLoading=true; boolean hadCache=false;
        if(reset){feedBefore=0;feedHasMore=true;hadCache=renderCachedFeed();if(!hadCache){if(feedList!=null){feedList.removeAllViews();renderedPostIds.clear();postViews.clear();showFeedSkeleton();}if(feedStatus!=null)feedStatus.setText("Loading latest posts…");}}
        final boolean cachedVisible=hadCache; final long before=reset?0:feedBefore;
        BackendClient.feedList(token,5,before,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{
            if(reset){pauseInlineVideos();feedList.removeAllViews();renderedPostIds.clear();postViews.clear();inlineVideos.clear();activeInlineVideo=null;getSharedPreferences("myshop_feed_cache",MODE_PRIVATE).edit().putString("first_page",d.toString()).apply();}
            JSONArray a=d.optJSONArray("posts");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)renderPost(x);}
            feedBefore=d.optLong("nextBefore",0);feedHasMore=feedBefore>0&&d.optBoolean("hasMore",false);int today=d.optInt("postsToday",0);boolean can=d.optBoolean("canPost",false);if(postLimit!=null)postLimit.setText(can?"Post today: "+today+"/1":"আজকের পোস্ট সম্পন্ন");if(feedStatus!=null)feedStatus.setText(feedHasMore?"Scroll down for more posts":LanguageManager.t(MainActivity.this,"feedEnd"));feedLoading=false;loadFocusedPostIfNeeded();
        });}public void onError(String m){runOnUiThread(()->{if(feedStatus!=null)feedStatus.setText(cachedVisible?"Saved posts shown • tap/scroll to retry":LanguageManager.t(MainActivity.this,"feedUnavailable")+m);feedLoading=false;});}});
    }
    private void showFeedSkeleton(){if(feedList==null)return;for(int i=0;i<2;i++){LinearLayout sk=col();sk.setPadding(dp(10),dp(10),dp(10),dp(10));sk.setBackground(round(Color.WHITE,Color.rgb(233,235,241),14));TextView a=text("",MUTED,1,false);a.setBackground(round(Color.rgb(236,238,244),Color.TRANSPARENT,12));sk.addView(a,lp(-1,dp(42)));TextView b=text("",MUTED,1,false);b.setBackground(round(Color.rgb(241,242,246),Color.TRANSPARENT,10));sk.addView(b,top(lp(-1,dp(110)),7));feedList.addView(sk,lp(-1,-2));feedList.addView(space(),lp(1,dp(8)));}}
    private void loadFocusedPostIfNeeded(){final long id=pendingFocusPostId;if(id<=0)return;View found=postViews.get(id);if(found!=null){scrollToPost(id);pendingFocusPostId=0;return;}BackendClient.feedPost(SessionManager.getToken(this),id,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONObject post=d.optJSONObject("post");if(post!=null)renderPostAtTop(post);scrollToPost(id);pendingFocusPostId=0;});}public void onError(String m){pendingFocusPostId=0;}});}
    private void scrollToPost(long id){View v=postViews.get(id);if(v==null||scroll==null)return;scroll.postDelayed(()->scroll.smoothScrollTo(0,Math.max(0,feedList.getTop()+v.getTop()-dp(12))),120);}

    private void renderPostAtTop(JSONObject x){ if(feedList==null||x==null)return; LinearLayout old=feedList; LinearLayout temp=old; renderPost(x); if(temp.getChildCount()>=2){ View card=temp.getChildAt(temp.getChildCount()-2); View gap=temp.getChildAt(temp.getChildCount()-1); temp.removeViewAt(temp.getChildCount()-1); temp.removeViewAt(temp.getChildCount()-1); temp.addView(card,0); temp.addView(gap,1);} }

    private void renderPost(JSONObject x){
        long id=x.optLong("id",0);if(id>0&&renderedPostIds.contains(id))return;if(id>0)renderedPostIds.add(id);String uid=x.optString("userId","");String name=x.optString("name","MY SHOP User");String avatar=x.optString("avatarUrl","");String cap=x.optString("caption","");String url=x.optString("mediaUrl","");String type=x.optString("mediaType","image"); final int likeCount=x.optInt("likeCount",0);
        LinearLayout card=col();card.setPadding(dp(12),dp(11),dp(12),dp(11));card.setBackground(round(Color.WHITE,Color.rgb(228,230,238),16));card.setElevation(dp(2));
        LinearLayout head=row();head.setOnClickListener(v->{Intent q=new Intent(this,UserProfileActivity.class);q.putExtra("userId",uid);startActivity(q);});ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setBackground(round(Color.rgb(238,240,248),Color.TRANSPARENT,20));av.setClipToOutline(true);if(!avatar.isEmpty())loadRemoteImage(av,avatar);head.addView(av,lp(dp(50),dp(50)));LinearLayout who=col();who.setPadding(dp(11),dp(2),dp(5),0);TextView nm=text(name+"   LV."+Math.max(0,x.optInt("level",0)),Color.rgb(25,30,55),15.5f,true);nm.setSingleLine(true);nm.setEllipsize(TextUtils.TruncateAt.END);who.addView(nm,lp(-1,dp(27)));who.addView(text("ID "+uid+" • "+UiTime.relative(x.optString("createdAt","")),MUTED,9.2f,false),lp(-1,dp(20)));head.addView(who,weight(1,dp(50)));card.addView(head,lp(-1,dp(52)));
        if(!cap.isEmpty()){TextView c=text(cap,Color.rgb(31,35,49),18.0f,false);c.setPadding(dp(2),dp(10),dp(2),dp(11));c.setLineSpacing(dp(4),1.04f);c.setMaxLines(12);c.setEllipsize(TextUtils.TruncateAt.END);card.addView(c,lp(-1,-2));}
        if(!url.isEmpty()){
            if("video".equalsIgnoreCase(type)){
                FrameLayout media=new FrameLayout(this); media.setBackground(round(Color.BLACK,Color.rgb(226,228,236),12)); media.setClipToOutline(true);
                ImageView thumb=new ImageView(this); thumb.setScaleType(ImageView.ScaleType.CENTER_CROP); thumb.setBackgroundColor(Color.BLACK); media.addView(thumb,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER)); loadVideoThumbnail(thumb,url);
                VideoView vv=new VideoView(this); vv.setBackgroundColor(Color.TRANSPARENT); vv.setVideoURI(Uri.parse(url)); vv.setTag(url);
                FrameLayout.LayoutParams vp=new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER); media.addView(vv,vp);
                TextView play=text("▶",Color.WHITE,22f,true); play.setGravity(Gravity.CENTER); play.setBackground(round(Color.argb(150,30,30,35),Color.TRANSPARENT,28)); FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(56),dp(56),Gravity.CENTER); media.addView(play,pp);
                TextView expand=text("⛶",Color.WHITE,15f,true); expand.setGravity(Gravity.CENTER); expand.setBackground(round(Color.argb(145,20,20,25),Color.TRANSPARENT,10)); FrameLayout.LayoutParams ep=new FrameLayout.LayoutParams(dp(40),dp(36),Gravity.TOP|Gravity.END); ep.setMargins(0,dp(8),dp(8),0); media.addView(expand,ep);
                final boolean[] prepared={false}; final android.media.MediaPlayer[] player={null};
                vv.setOnPreparedListener(mp->{try{prepared[0]=true;player[0]=mp;mp.setVolume(0f,0f);mp.setLooping(false);vv.seekTo(10);play.setVisibility(View.VISIBLE);}catch(Exception ignored){}});
                vv.setOnErrorListener((mp,what,extra)->{play.setText("↻");play.setVisibility(View.VISIBLE);return true;});
                View.OnClickListener toggle=v->{try{if(vv.isPlaying()){vv.pause();play.setText("▶");play.setVisibility(View.VISIBLE);}else{pauseInlineVideosExcept(vv);if(!prepared[0])vv.setVideoURI(Uri.parse(url));if(player[0]!=null)player[0].setVolume(1f,1f);vv.start();activeInlineVideo=vv;play.setText("▶");play.setVisibility(View.GONE);}}catch(Exception e){play.setText("↻");play.setVisibility(View.VISIBLE);}};
                vv.setOnClickListener(toggle); play.setOnClickListener(toggle); vv.setOnCompletionListener(mp->{play.setText("▶");play.setVisibility(View.VISIBLE);});
                expand.setOnClickListener(v->openFeedVideo(url));
                inlineVideos.add(vv); card.addView(media,top(lp(-1,dp(285)),6));
            }else{
                ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setBackground(round(Color.rgb(242,243,248),Color.TRANSPARENT,10));applyRipple(im);im.setOnClickListener(v->openFeedImage(url));card.addView(im,top(lp(-1,dp(300)),6));loadRemoteImage(im,url);
            }
        }
        LinearLayout actions=row(); actions.setPadding(0,0,0,0); final boolean initiallyLiked=x.optBoolean("liked",false); final int commentCount=x.optInt("commentCount",0);
        TextView like=text((initiallyLiked?"♥  Liked":"♡  Like")+"  "+likeCount,Color.rgb(45,48,70),10.8f,true); like.setGravity(Gravity.CENTER); like.setMinHeight(dp(40)); like.setPadding(dp(5),0,dp(5),0); like.setBackground(round(Color.WHITE,Color.rgb(220,223,232),10)); like.setElevation(dp(1)); applyRipple(like);
        TextView comment=text("▢  Comment  "+commentCount,Color.rgb(45,48,70),10.8f,true); comment.setGravity(Gravity.CENTER); comment.setMinHeight(dp(40)); comment.setPadding(dp(5),0,dp(5),0); comment.setBackground(round(Color.WHITE,Color.rgb(220,223,232),10)); comment.setElevation(dp(1)); applyRipple(comment);
        LinearLayout.LayoutParams ap1=weight(1,dp(40)); ap1.setMargins(0,0,dp(5),0); LinearLayout.LayoutParams ap2=weight(1,dp(40)); ap2.setMargins(0,0,dp(5),0); actions.addView(like,ap1); actions.addView(comment,ap2); TextView share=text("↗  Share",Color.rgb(45,48,70),10.8f,true); share.setGravity(Gravity.CENTER); share.setBackground(round(Color.WHITE,Color.rgb(220,223,232),10)); applyRipple(share); share.setOnClickListener(v->shareFeedPost(name,cap,url)); actions.addView(share,weight(1,dp(40))); final long postId=id; final String ownerUid=uid; like.setOnClickListener(v->BackendClient.feedLike(SessionManager.getToken(this),postId,new BackendClient.Callback(){public void onSuccess(JSONObject d){like.setText((d.optBoolean("liked",false)?"♥  Liked":"♡  Like")+"  "+d.optInt("likeCount",0)); loadNotificationCount();}public void onError(String m){toast("Like failed: "+m);}})); comment.setOnClickListener(v->showCommentDialog(postId,comment));
        if(!SessionManager.getUserId(this).equals(uid)){TextView flag=action("⚑",Color.rgb(148,48,70));flag.setOnClickListener(v->SafetyActions.show(this,ownerUid,"POST",String.valueOf(postId)));actions.addView(flag,lp(dp(42),dp(34)));}if(SessionManager.getUserId(this).equals(uid)||SessionManager.isAdmin(this)||SessionManager.isModerator(this)){TextView del=action("🗑",RED);del.setOnClickListener(v->deletePost(id));actions.addView(del,lp(dp(44),dp(34)));}
        card.addView(actions,top(lp(-1,dp(42)),8));if(id>0)postViews.put(id,card);feedList.addView(card,lp(-1,-2));feedList.addView(space(),lp(1,dp(9)));
    }

    private void pauseInlineVideos(){for(VideoView v:inlineVideos){try{if(v!=null&&v.isPlaying())v.pause();}catch(Exception ignored){}}activeInlineVideo=null;}
    private void pauseInlineVideosExcept(VideoView keep){for(VideoView v:inlineVideos){if(v==keep)continue;try{if(v!=null&&v.isPlaying())v.pause();}catch(Exception ignored){}}}
    private void updateInlineVideoPlayback(){
        if(inlineVideos.isEmpty()||scroll==null)return;
        android.graphics.Rect viewport=new android.graphics.Rect(); scroll.getGlobalVisibleRect(viewport);
        VideoView best=null; int bestArea=0;
        for(VideoView v:inlineVideos){if(v==null||!v.isShown())continue; android.graphics.Rect r=new android.graphics.Rect(); if(!v.getGlobalVisibleRect(r))continue; int area=Math.max(0,r.width())*Math.max(0,r.height()); if(area>bestArea){bestArea=area;best=v;}}
        int threshold=Math.max(1,scroll.getWidth()*dp(110));
        if(best!=null&&bestArea>threshold){ if(activeInlineVideo!=best){pauseInlineVideosExcept(best); try{best.start();activeInlineVideo=best;}catch(Exception ignored){}} }
        else if(activeInlineVideo!=null){try{activeInlineVideo.pause();}catch(Exception ignored){}activeInlineVideo=null;}
    }

    private void shareFeedPost(String name,String caption,String mediaUrl){try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");StringBuilder b=new StringBuilder();if(name!=null&&!name.isEmpty())b.append(name).append(" on MY SHOP\n");if(caption!=null&&!caption.isEmpty())b.append(caption).append("\n");if(mediaUrl!=null&&!mediaUrl.isEmpty())b.append(mediaUrl);i.putExtra(Intent.EXTRA_TEXT,b.toString().trim());startActivity(Intent.createChooser(i,"Share post"));}catch(Exception e){toast("Share is not available.");}}

    private void showCommentDialog(long postId, final TextView commentButton){
        LinearLayout wrap=col(); wrap.setPadding(dp(10),dp(4),dp(10),dp(4));
        TextView loading=text("Loading comments…",MUTED,9.5f,false); wrap.addView(loading,lp(-1,dp(28)));
        ScrollView sv=new ScrollView(this); sv.setVerticalScrollBarEnabled(false); LinearLayout comments=col(); sv.addView(comments,new ScrollView.LayoutParams(-1,-2)); wrap.addView(sv,lp(-1,dp(270)));
        EditText input=new EditText(this); input.setHint("Write a comment…"); input.setTextSize(11); input.setMinLines(2); input.setMaxLines(4); input.setBackground(round(Color.rgb(246,247,251),Color.rgb(222,225,234),12)); wrap.addView(input,top(lp(-1,dp(64)),6));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Comments").setView(wrap).setNegativeButton(LanguageManager.t(this,"cancel"),null).setPositiveButton("POST",null).create();
        dlg.setOnShowListener(x->{
            loadCommentsInto(postId,comments,loading);
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String text=input.getText().toString().trim();if(text.isEmpty())return;dlg.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);BackendClient.feedComment(SessionManager.getToken(this),postId,text,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{input.setText("");commentButton.setText("▢  Comment  "+d.optInt("commentCount",0));dlg.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);loadCommentsInto(postId,comments,loading);loadNotificationCount();});}public void onError(String m){runOnUiThread(()->{dlg.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);toast("Comment failed: "+m);});}});});
        });
        dlg.show();
    }
    private void loadCommentsInto(long postId,LinearLayout list,TextView status){status.setText("Loading comments…");BackendClient.feedComments(SessionManager.getToken(this),postId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{list.removeAllViews();JSONArray a=d.optJSONArray("comments");if(a==null||a.length()==0){status.setText("No comments yet");return;}status.setText(a.length()+" comment"+(a.length()==1?"":"s"));for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;LinearLayout row=row();row.setPadding(dp(4),dp(5),dp(4),dp(5));ImageView av=new ImageView(MainActivity.this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setClipToOutline(true);av.setBackground(round(Color.rgb(238,240,248),Color.TRANSPARENT,18));String au=c.optString("avatarUrl","");if(!au.isEmpty())loadRemoteImage(av,au);row.addView(av,lp(dp(36),dp(36)));LinearLayout body=col();body.setPadding(dp(8),0,0,0);body.addView(text(c.optString("name","MY SHOP User"),DARK,9.5f,true),lp(-1,dp(19)));body.addView(text(c.optString("comment",""),Color.rgb(45,48,64),10.5f,false),lp(-1,-2));body.addView(text(UiTime.relative(c.optString("createdAt","")),MUTED,7.5f,false),lp(-1,dp(17)));row.addView(body,weight(1,-2));String commentUid=c.optString("userId","");if(!commentUid.isEmpty()&&!commentUid.equals(SessionManager.getUserId(MainActivity.this))){TextView flag=action("⚑",Color.rgb(148,48,70));flag.setOnClickListener(v->SafetyActions.show(MainActivity.this,commentUid,"COMMENT",String.valueOf(c.optLong("id",0))));row.addView(flag,lp(dp(38),dp(32)));}list.addView(row,lp(-1,-2));}});}public void onError(String m){runOnUiThread(()->status.setText("Comments unavailable: "+m));}});}

    private void loadVideoThumbnail(ImageView view,String url){imagePool.execute(()->{MediaMetadataRetriever r=new MediaMetadataRetriever();try{r.setDataSource(url,new java.util.HashMap<String,String>());Bitmap b=r.getFrameAtTime(0,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);if(b!=null)runOnUiThread(()->view.setImageBitmap(b));}catch(Exception ignored){}finally{try{r.release();}catch(Exception ignored){}}});}

    private void openFeedVideo(String url){LinearLayout box=col();box.setPadding(dp(8),dp(8),dp(8),dp(8));box.setBackgroundColor(Color.BLACK);VideoView v=new VideoView(this);box.addView(v,lp(-1,dp(520)));LinearLayout actions=row();TextView close=action("CLOSE",Color.rgb(70,73,86));TextView down=action("DOWNLOAD VIDEO",BLUE);actions.addView(close,weight(1,dp(46)));actions.addView(space(),lp(dp(8),1));actions.addView(down,weight(1,dp(46)));box.addView(actions,top(lp(-1,dp(46)),8));AlertDialog dlg=new AlertDialog.Builder(this).setView(box).create();close.setOnClickListener(q->{try{v.stopPlayback();}catch(Exception ignored){}dlg.dismiss();});down.setOnClickListener(q->downloadVideo(url));dlg.setOnDismissListener(q->{try{v.stopPlayback();}catch(Exception ignored){}});dlg.show();if(dlg.getWindow()!=null){dlg.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);dlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.BLACK));}v.setVideoURI(Uri.parse(url));v.setOnPreparedListener(mp->{mp.setLooping(false);v.start();});}

    private void downloadVideo(String url){try{DownloadManager dm=(DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE);DownloadManager.Request r=new DownloadManager.Request(Uri.parse(url));r.setTitle("MY SHOP Video");r.setDescription("Downloading video");r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);r.setMimeType("video/mp4");r.setDestinationInExternalPublicDir(Environment.DIRECTORY_MOVIES,"MY SHOP/MY_SHOP_"+System.currentTimeMillis()+".mp4");dm.enqueue(r);toast("✓ Video download started");}catch(Exception e){toast("Video download failed. Please try again.");}}

    private void openFeedImage(String url){
        final AlertDialog[] holder=new AlertDialog[1]; LinearLayout box=col();box.setPadding(dp(8),dp(8),dp(8),dp(8));box.setBackgroundColor(Color.BLACK);
        ImageView full=new ImageView(this);full.setScaleType(ImageView.ScaleType.FIT_CENTER);full.setBackgroundColor(Color.BLACK);box.addView(full,lp(-1,dp(520)));loadRemoteImage(full,url);
        LinearLayout actions=row();TextView close=action("CLOSE",Color.rgb(70,73,86));TextView save=action("SAVE PHOTO",BLUE);actions.addView(close,weight(1,dp(46)));actions.addView(space(),lp(dp(8),1));actions.addView(save,weight(1,dp(46)));box.addView(actions,top(lp(-1,dp(46)),8));
        AlertDialog dlg=new AlertDialog.Builder(this).setView(box).create();holder[0]=dlg;close.setOnClickListener(v->dlg.dismiss());save.setOnClickListener(v->{save.setEnabled(false);save.setText("SAVING…");saveImageToGallery(url,ok->runOnUiThread(()->{save.setEnabled(true);save.setText("SAVE PHOTO");toast(ok?"✓ Photo saved to gallery":"Save failed. Please try again.");}));});dlg.show();
        if(dlg.getWindow()!=null){dlg.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);dlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.BLACK));}
    }
    private interface SaveResult{void done(boolean ok);}
    private void saveImageToGallery(String url,SaveResult result){imagePool.execute(()->{boolean ok=false;try{Bitmap bm=imageCache.get(url);if(bm==null){HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(12000);c.setRequestProperty("User-Agent","MY-SHOP/2.9.241");try(InputStream in=c.getInputStream()){bm=BitmapFactory.decodeStream(in);}c.disconnect();}if(bm==null)throw new Exception("decode failed");String name="MY_SHOP_"+System.currentTimeMillis()+".jpg";if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/MY SHOP");v.put(MediaStore.Images.Media.IS_PENDING,1);Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(u==null)throw new Exception("insert failed");try(OutputStream out=getContentResolver().openOutputStream(u)){if(out==null||!bm.compress(Bitmap.CompressFormat.JPEG,95,out))throw new Exception("write failed");}v.clear();v.put(MediaStore.Images.Media.IS_PENDING,0);getContentResolver().update(u,v,null,null);ok=true;}else{File dir=new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES),"MY SHOP");if(!dir.exists())dir.mkdirs();File f=new File(dir,name);try(OutputStream out=new FileOutputStream(f)){if(!bm.compress(Bitmap.CompressFormat.JPEG,95,out))throw new Exception("write failed");}MediaScannerConnection.scanFile(MainActivity.this,new String[]{f.getAbsolutePath()},new String[]{"image/jpeg"},null);ok=true;}}catch(Exception ignored){}result.done(ok);});}

    private void deletePost(long id){new AlertDialog.Builder(this).setTitle("Delete this post?").setMessage("The post will be removed. User account and Permanent ID will not be affected.").setNegativeButton(LanguageManager.t(this,"cancel"),null).setPositiveButton("DELETE",(d,w)->{BackendClient.Callback cb=new BackendClient.Callback(){public void onSuccess(JSONObject x){toast("✓ Post removed");loadFeed(true);}public void onError(String m){toast("Delete failed: "+m);}};if(SessionManager.isAdmin(this)||SessionManager.isModerator(this))BackendClient.moderatorFeedDelete(SessionManager.getToken(this),id,"Removed from Feed",cb);else BackendClient.feedDelete(SessionManager.getToken(this),id,cb);}).show();}

    private void pickPost(String type){
        if(SessionManager.getToken(this)==null||SessionManager.getToken(this).isEmpty()){startActivity(new Intent(this,AccountActivity.class));return;}
        Intent i=new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);
        i.setType("video".equals(type)?"video/*":"image/*");
        pendingPostMime="video".equals(type)?"video/mp4":"image/jpeg";
        startActivityForResult(i,PICK_POST);
    }

    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r!=PICK_POST||c!=RESULT_OK||data==null||data.getData()==null)return;pendingPostUri=data.getData();showPostCaptionDialog();}
    private void showPostCaptionDialog(){EditText cap=new EditText(this);cap.setHint(LanguageManager.t(this,"caption"));cap.setMinLines(3);new AlertDialog.Builder(this).setTitle(LanguageManager.t(this,"createPost")).setMessage("User: 1 photo/video + caption per day. Public videos automatically appear in Videos.").setView(cap).setNegativeButton(LanguageManager.t(this,"cancel"),null).setPositiveButton(LanguageManager.t(this,"post"),(d,w)->uploadPost(cap.getText().toString().trim())).show();}
    private void showTextPostDialog(){
        final EditText cap=new EditText(this);
        cap.setHint(LanguageManager.t(this,"writePost"));
        cap.setMinLines(4);
        cap.setGravity(Gravity.TOP|Gravity.START);
        cap.setPadding(dp(10),dp(8),dp(10),dp(8));
        new AlertDialog.Builder(this)
                .setTitle(LanguageManager.t(this,"textPost"))
                .setMessage("Write a text-only post. No photo is required.")
                .setView(cap)
                .setNegativeButton(LanguageManager.t(this,"cancel"),null)
                .setPositiveButton(LanguageManager.t(this,"post"),(d,w)->uploadTextPost(cap.getText().toString().trim()))
                .show();
    }

    private void uploadTextPost(String caption){
        if(caption.isEmpty()){toast("Please write something first.");return;}
        String token=SessionManager.getToken(this);
        if(token==null||token.isEmpty()){startActivity(new Intent(this,AccountActivity.class));return;}
        BackendClient.feedText(token,caption,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{toast("✓ Post published");JSONObject post=d.optJSONObject("post");if(post!=null&&feedList!=null){renderPostAtTop(post);}else{loadFeed(true);}});}
            public void onError(String m){runOnUiThread(()->toast("Post failed: "+m));}
        });
    }
    private void uploadPost(String caption){
        if(pendingPostUri==null){toast("Please select a photo first.");return;}
        try{
            InputStream in=getContentResolver().openInputStream(pendingPostUri);
            if(in==null){toast("Selected media could not be opened. Please choose it again.");return;}
            String mime=getContentResolver().getType(pendingPostUri);
            if(mime==null||mime.trim().isEmpty())mime=pendingPostMime;
            String name=queryName(pendingPostUri);
            String mediaType=mime.toLowerCase().startsWith("video/")?"video":"image";
            BackendClient.feedUpload(SessionManager.getToken(this),in,name,mime,mediaType,caption,new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->{toast("✓ Post published");pendingPostUri=null;JSONObject post=d.optJSONObject("post");if(post!=null&&feedList!=null)renderPostAtTop(post);else loadFeed(true);});}
                public void onError(String m){runOnUiThread(()->toast("Post failed: "+m));}
            });
        }catch(Exception e){toast("Could not open selected media. Please choose the file again.");}
    }
    private String queryName(Uri u){try(android.database.Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}catch(Exception ignored){}return "myshop-post";}

    private View bottom(){
        LinearLayout n=row();n.setPadding(dp(4),dp(2),dp(4),dp(1));n.setBackgroundColor(Color.WHITE);n.setElevation(dp(7));
        addNav(n,navItem(R.drawable.nav_home,LanguageManager.t(this,"home"),true,"home",Color.rgb(20,112,247)));addNav(n,navItem(R.drawable.nav_store,LanguageManager.t(this,"store"),false,"store",Color.rgb(255,154,25)));addNav(n,navItem(R.drawable.nav_video,"Video",false,"video",Color.rgb(255,23,89)));addNav(n,navItem(R.drawable.nav_feed,"My Feed",false,"feed",Color.rgb(7,185,100)));addNav(n,navItem(R.drawable.nav_more,LanguageManager.t(this,"more"),false,"more",Color.rgb(126,37,238)));return n;
    }
    private void addNav(LinearLayout parent,View child){parent.addView(child,new LinearLayout.LayoutParams(0,dp(61),1));}
    private View navItem(int iconRes,String label,boolean active,String key,int color){
        LinearLayout item=col();item.setGravity(Gravity.CENTER);item.setPadding(dp(3),dp(3),dp(3),0);ImageView icon=new ImageView(this);icon.setImageResource(iconRes);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setImageTintList(ColorStateList.valueOf(color));item.addView(icon,lp(-1,dp(31)));TextView name=text(label,active?color:Color.rgb(103,112,139),8.5f,true);name.setGravity(Gravity.CENTER);name.setSingleLine(true);item.addView(name,lp(-1,dp(18)));View line=new View(this);line.setBackgroundColor(active?color:Color.TRANSPARENT);item.addView(line,lp(dp(34),dp(3)));applyRipple(item);if(SessionManager.isAdmin(this))item.setOnLongClickListener(v->{Intent a=new Intent(this,AdminSectionActivity.class);a.putExtra("section","menu");a.putExtra("admin_context",true);startActivity(a);return true;});item.setOnClickListener(v->{if("home".equals(key)){if(scroll!=null)scroll.smoothScrollTo(0,0);return;}if("video".equals(key))startActivity(new Intent(this,ShortVideoActivity.class));else if("store".equals(key))startActivity(new Intent(this,StoreActivity.class));else if("feed".equals(key))openMyFeed();else if("more".equals(key))showMoreQuickActions();});return item;
    }

    private void openMyFeed(){
        if(scroll==null)return;
        final View target=feedAnchor!=null?feedAnchor:feedList;
        if(target==null){scroll.smoothScrollTo(0,Math.max(0,scroll.getChildAt(0)==null?0:scroll.getChildAt(0).getHeight()/2));return;}
        scroll.post(()->{int y=Math.max(0,target.getTop()-dp(10));scroll.smoothScrollTo(0,y);if(feedStatus!=null&&System.currentTimeMillis()-lastFeedLoadAt>8000)loadFeed(true);});
    }

    private void showMoreQuickActions(){
        final PopupWindow[] holder=new PopupWindow[1];
        LinearLayout sheet=col();sheet.setPadding(dp(12),dp(9),dp(12),dp(12));sheet.setBackground(round(Color.WHITE,Color.rgb(226,229,238),22));
        LinearLayout head=row();head.addView(text("Quick Links • See All",Color.rgb(22,34,86),15,true),weight(1,dp(34)));TextView close=text("✕",MUTED,15,true);close.setGravity(Gravity.CENTER);head.addView(close,lp(dp(38),dp(34)));sheet.addView(head,lp(-1,dp(36)));
        sheet.addView(text("All Home Page 1 shortcuts",MUTED,8,false),lp(-1,dp(22)));
        ArrayList<Integer> ids=new ArrayList<>();for(int i=0;i<mainKeys.length;i++)if(mainActive[i])ids.add(i);java.util.Collections.sort(ids,(a,b)->Integer.compare(mainDisplayOrder[a],mainDisplayOrder[b]));
        if(ids.isEmpty()){TextView empty=text("No Quick Links are published yet.",MUTED,9.0f,false);empty.setGravity(Gravity.CENTER);sheet.addView(empty,lp(-1,dp(64)));}
        int cols=5,index=0;while(index<ids.size()){LinearLayout r=row();for(int c=0;c<cols;c++){if(index<ids.size()){final int idx=ids.get(index++);LinearLayout cell=quickCell(mainIcons[idx],mainTitles[idx]);ImageView custom=(ImageView)cell.getChildAt(0);int qsz=Math.max(28,Math.min(56,mainIconSize[idx]));custom.setLayoutParams(lp(dp(qsz),dp(qsz)));if(mainRemoteIconUrls[idx]!=null&&!mainRemoteIconUrls[idx].trim().isEmpty()){loadRemoteImage(custom,mainRemoteIconUrls[idx].trim());}cell.setOnClickListener(v->{if(holder[0]!=null)holder[0].dismiss();openHomeShortcut(idx);});cell.setOnLongClickListener(v->{if(!SessionManager.isAdmin(this))return false;if(holder[0]!=null)holder[0].dismiss();startActivity(new Intent(this,PageIconAdminActivity.class).putExtra("page","home1"));return true;});r.addView(cell,weight(1,dp(92)));}else r.addView(space(),weight(1,dp(92)));}sheet.addView(r,top(lp(-1,dp(92)),4));}
        PopupWindow pop=new PopupWindow(sheet,ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT,true);holder[0]=pop;pop.setBackgroundDrawable(round(Color.WHITE,Color.TRANSPARENT,22));pop.setOutsideTouchable(true);pop.setElevation(dp(12));close.setOnClickListener(v->pop.dismiss());pop.showAtLocation(getWindow().getDecorView(),Gravity.BOTTOM,0,dp(70));sheet.setTranslationY(dp(24));sheet.setAlpha(0f);sheet.animate().translationY(0f).alpha(1f).setDuration(180).start();
    }
    private LinearLayout quickCell(int iconRes,String label){
        LinearLayout c=col();c.setGravity(Gravity.CENTER);c.setPadding(dp(2),dp(4),dp(2),dp(3));ImageView i=new ImageView(this);i.setImageResource(iconRes);i.setScaleType(ImageView.ScaleType.CENTER_INSIDE);i.setElevation(dp(3));c.addView(i,lp(dp(40),dp(40)));TextView t=text(label,DARK,8.1f,true);t.setGravity(Gravity.CENTER);t.setMaxLines(2);c.addView(t,lp(-1,dp(30)));c.setBackground(round(Color.rgb(250,252,255),Color.TRANSPARENT,12));applyRipple(c);return c;
    }
    private void runQuickAction(String label){
        if("Page".equals(label))openHomeShortcut(0);else if("Website".equals(label))openHomeShortcut(1);else if("My Level".equals(label))openHomeShortcut(2);else if("Membership".equals(label))openHomeShortcut(3);else if("Earn Rewards".equals(label))openHomeShortcut(4);else if("Gallery +".equals(label))openHomeShortcut(5);else if("External Media".equals(label))openHomeShortcut(6);else if("Help Center".equals(label))openHomeShortcut(7);else if("Top Up".equals(label))openHomeShortcut(8);else if("Share App".equals(label))openHomeShortcut(9);
    }
    private void openShortcutByKey(String title,String key){if(SessionManager.isAdmin(this)){openAdminFolder(title,key);return;}String u=featureRemoteUrl(key);if(!FeatureRegistry.isSafeHttpUrl(u)){toast(title+" link is not configured yet.");return;}try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){toast("Could not open "+title);}}
    private void openGalleryExternalAdmin(){String[] items={"Gallery Photo/Audio/Video","External Links"};new AlertDialog.Builder(this).setTitle("GALLERY + EXTERNAL ADMIN").setItems(items,(d,w)->{if(w==0)startActivity(new Intent(this,GalleryAdminActivity.class).putExtra("admin_context",true));else startActivity(new Intent(this,AdminSectionActivity.class).putExtra("section","external_movie").putExtra("admin_context",true));}).show();}
    private void openDirectFeature(String title,String key){try{if("chat".equals(key)){startActivity(new Intent(this,InboxActivity.class));return;}if(SessionManager.isAdmin(this)){openAdminFolder(title,key);return;}Intent i=new Intent(MainActivity.this,FeatureActivity.class);i.putExtra("title",title);i.putExtra("feature_key",key);String u=featureRemoteUrl(key);if(FeatureRegistry.isSafeHttpUrl(u))i.putExtra("url",u);startActivity(i);}catch(Throwable t){toast(title+" is ready.");}}
    private void openAdminFolder(String title,String key){Intent i=new Intent(this,AdminFolderActivity.class);i.putExtra("title",title);i.putExtra("feature_key",key);i.putExtra("admin_context",true);startActivity(i);}
    private void shareAppFromDashboard(){try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"MY SHOP");i.putExtra(Intent.EXTRA_TEXT,"MY SHOP — https://rapid-bush-62ea.myshopsatkania.workers.dev");startActivity(Intent.createChooser(i,"Share MY SHOP"));}catch(Exception e){toast("Share is not available.");}}

    private void openSupport(){ if(SessionManager.isAdmin(this)){openAdminFolder("CUSTOMER SUPPORT","help_support");return;} Intent i=new Intent(MainActivity.this,FeatureActivity.class); i.putExtra("title","CUSTOMER SUPPORT"); i.putExtra("feature_key","help_support"); startActivity(i); }
    private String powerAdText(){ String l=LanguageManager.get(this); if(LanguageManager.BN.equals(l))return "⚡  পাওয়ার অ্যাড বাই তৌহিদ"; if(LanguageManager.HI.equals(l))return "⚡  पावर ऐड द्वारा तौहिद"; if(LanguageManager.AR.equals(l))return "⚡  إعلان قوي بواسطة توحيد"; return "⚡  POWER AD by Touhid"; }
    private void applyPowerAdColors(TextView v){ String s=v.getText().toString(); SpannableString sp=new SpannableString(s); if(s.length()>0)sp.setSpan(new ForegroundColorSpan(Color.rgb(245,145,0)),0,1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); int mid=Math.min(s.length(),Math.max(1,s.length()/2)); sp.setSpan(new ForegroundColorSpan(Color.rgb(91,38,214)),1,mid,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); if(mid<s.length())sp.setSpan(new ForegroundColorSpan(Color.rgb(235,45,100)),mid,s.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); v.setText(sp); }

    private void loadCurrentProfile(){String token=SessionManager.getToken(this);if(token==null||token.isEmpty())return;BackendClient.me(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){JSONObject u=d.optJSONObject("user");if(u!=null){String avatar=u.optString("avatarUrl","").trim();SessionManager.saveProfile(MainActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""),avatar,u.optString("bio",""));runOnUiThread(()->{if(!avatar.isEmpty()){if(headerAvatar!=null)loadRemoteImage(headerAvatar,avatar);if(composerAvatar!=null)loadRemoteImage(composerAvatar,avatar);}});}}public void onError(String m){}});}
    private int safeColor(String hex,int fallback){try{String x=hex==null?"":hex.trim();return x.matches("#[0-9A-Fa-f]{6}")?Color.parseColor(x):fallback;}catch(Exception e){return fallback;}}

    private void loadRemote(){BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){if(dashboardDestroyed)return;runOnUiThread(()->{if(dashboardDestroyed)return;applyRemote(d);if(newsText!=null&&newsText.getTextSize()/getResources().getDisplayMetrics().scaledDensity<10.0f)newsText.setTextSize(10.0f);restartNewsMarquee();scheduleHeroCarousel(900L);});}public void onError(String m){}});}
    private void applyRemote(JSONObject d){try{JSONObject c=d.optJSONObject("config");if(c!=null){String n=c.optString("breaking_news","").trim();if(!n.isEmpty()&&newsText!=null)newsText.setText(n);newsTextSizeSp=(float)Math.max(10.0,Math.min(24.0,c.optDouble("breaking_news_text_size",13.0)));if(newsText!=null){newsText.setTextSize(newsTextSizeSp);int fg=safeColor(c.optString("breaking_news_text_color","#414662"),Color.rgb(65,70,98));newsText.setTextColor(fg);if(breakingBox!=null){int bg=safeColor(c.optString("breaking_news_bg_color","#FFEFF7"),Color.rgb(255,239,247));int stroke=Color.argb(70,Color.red(fg),Color.green(fg),Color.blue(fg));breakingBox.setBackground(round(bg,stroke,11));}}saveRemoteUrl("my_shop",c.optString("my_shop_url",""));saveRemoteUrl("live_tv",c.optString("live_tv_url",""));saveRemoteUrl("external_movie",c.optString("external_movie_url",""));saveRemoteUrl("chat",c.optString("chat_url",""));if(powerAdTitle!=null){powerAdTitle.setText(c.optString("power_ad_title","POWER AD").trim().isEmpty()?"POWER AD":c.optString("power_ad_title","POWER AD").trim());powerAdByline.setText(c.optString("power_ad_byline","by Touhid").trim().isEmpty()?"by Touhid":c.optString("power_ad_byline","by Touhid").trim());}ThemeConfig.cacheFromConfig(this,c);}for(int z=0;z<remoteHeroUrls.length;z++){remoteHeroUrls[z]="";remoteHeroTargets[z]="";}for(int z=0;z<remotePromoUrls.length;z++){remotePromoUrls[z]="";remotePromoTargets[z]="";}JSONArray banners=d.optJSONArray("banners");if(banners!=null){for(int i=0;i<banners.length();i++){JSONObject o=banners.optJSONObject(i);if(o==null)continue;String folder=o.optString("folder","");int slot=o.optInt("slot",0);String url=o.optString("image_url","").trim();String target=o.optString("target_url","").trim();String updated=o.optString("updated_at","").trim();if(!updated.isEmpty()&&!url.contains("?"))url=url+"?v="+Uri.encode(updated);if(url.isEmpty())continue;if("hero".equalsIgnoreCase(folder)&&slot>=1&&slot<=6){remoteHeroUrls[slot-1]=url;remoteHeroTargets[slot-1]=target;}else if("promo".equalsIgnoreCase(folder)&&slot>=1&&slot<=6){remotePromoUrls[slot-1]=url;remotePromoTargets[slot-1]=target;}}}showFirstRemoteHeroIfAvailable();applyPromoSlide();JSONArray managedLinks=d.optJSONArray("managedLinks");renderDynamicFolders(managedLinks);applyManagedFeatureCards(managedLinks);JSONArray ads=d.optJSONArray("dashboardAds");liveAds.clear();if(ads!=null){for(int i=0;i<ads.length();i++){JSONObject o=ads.optJSONObject(i);if(o!=null&&"live_now".equalsIgnoreCase(o.optString("box_key","")))liveAds.add(o);}}if(liveAdStripView!=null)liveAdStripView.setVisibility(View.VISIBLE); renderPowerAds();JSONArray features=d.optJSONArray("featureButtons");if(features!=null){for(int i=0;i<features.length();i++){JSONObject f=features.optJSONObject(i);if(f==null)continue;String key=f.optString("key","");for(int j=0;j<mainKeys.length;j++)if(mainKeys[j].equals(key)){mainRemoteUrls[j]=f.optString("target_url","");mainRemoteIconUrls[j]=f.optString("icon_url","");mainDisplayOrder[j]=Math.max(1,f.optInt("display_order",j+1));mainIconSize[j]=Math.max(28,Math.min(56,f.optInt("icon_size",38)));mainActive[j]=f.optInt("active",j<14?1:0)==1;String label=f.optString("title","").trim();if(!label.isEmpty())mainTitles[j]=label;}}if(quickTrack!=null)renderQuickLinks();}}catch(Exception ignored){}}
    private void saveRemoteUrl(String key,String url){if(url!=null&&!url.trim().isEmpty())getSharedPreferences("myshop_remote_config",MODE_PRIVATE).edit().putString("url_"+key,url.trim()).apply();}
    private void openFeatureCardAdmin(String category,String title){Intent a=new Intent(this,AdminSectionActivity.class);a.putExtra("section","feature_card");a.putExtra("managed_category",category);a.putExtra("managed_title",title);a.putExtra("admin_context",true);startActivity(a);}
    private void applyManagedFeatureCards(JSONArray links){
        android.content.SharedPreferences sp=getSharedPreferences("myshop_remote_config",MODE_PRIVATE); android.content.SharedPreferences.Editor ed=sp.edit();
        for(int j=0;j<mainKeys.length;j++){if(mainCards[j]!=null){mainCards[j].setVisibility(View.VISIBLE);mainCards[j].setAlpha(1f);}if(mainLabels[j]!=null)mainLabels[j].setText(mainTitles[j]);if(mainIconViews[j]!=null)mainIconViews[j].setImageResource(mainIcons[j]);ed.remove("managed_url_"+mainKeys[j]);ed.remove("managed_title_"+mainKeys[j]);}
        String[] clearKeys={"go_live","live_now","live_tv","external_movie","my_feed","social_media","earn_reward","more_apps","gallery","my_shop"}; for(String k:clearKeys)ed.remove("managed_url_"+k);
        if(links!=null)for(int i=0;i<links.length();i++){JSONObject x=links.optJSONObject(i);if(x==null)continue;String cat=x.optString("category","").trim();if(!cat.startsWith("feature_"))continue;String key=cat.substring(8);int active=x.optInt("active",1);String title=x.optString("title","").trim();String url=x.optString("url","").trim();String image=x.optString("image_url","").trim();String icon=x.optString("icon_url","").trim();ed.putInt("managed_active_"+key,active);ed.putString("managed_url_"+key,url);ed.putString("managed_title_"+key,title);for(int j=0;j<mainKeys.length;j++)if(mainKeys[j].equals(key)){boolean adminMode=SessionManager.isAdmin(this);if(mainCards[j]!=null){mainCards[j].setVisibility(active==1||adminMode?View.VISIBLE:View.GONE);mainCards[j].setAlpha(active==1?1f:0.48f);}if(mainLabels[j]!=null){if(active==1&&!title.isEmpty())mainLabels[j].setText(title);else if(active!=1&&adminMode)mainLabels[j].setText((title.isEmpty()?mainTitles[j]:title)+" • HIDDEN");}if(mainIconViews[j]!=null&&(active==1||adminMode)){mainIconViews[j].setImageResource(mainIcons[j]);if(!image.isEmpty()){mainIconViews[j].clearColorFilter();loadRemoteImage(mainIconViews[j],image);}else if(!icon.isEmpty()){mainIconViews[j].clearColorFilter();loadRemoteImage(mainIconViews[j],icon);}else mainIconViews[j].clearColorFilter();}}}
        ed.apply();
    }
    private String featureRemoteUrl(String key){String managed=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("managed_url_"+key,"").trim();if(!managed.isEmpty())return managed;for(int i=0;i<mainKeys.length;i++)if(mainKeys[i].equals(key))return mainRemoteUrls[i]==null?"":mainRemoteUrls[i].trim();return getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("url_"+key,"");}
    private void openFeature(String title,String key){try{
        if("chat".equals(key)){openDirectFeature(title,key);return;}
        if(SessionManager.isAdmin(this)){openAdminFolder(title,key);return;}
        if("gallery".equals(key)){startActivity(new Intent(this,GalleryActivity.class));return;}
        Intent i=new Intent(MainActivity.this,FeatureActivity.class);String managedTitle=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("managed_title_"+key,"").trim();i.putExtra("title",managedTitle.isEmpty()?title:managedTitle);i.putExtra("feature_key",key);String url=featureRemoteUrl(key);if("my_shop".equals(key)&&url.isEmpty())url=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("url_my_shop",url);if("external_movie".equals(key)&&url.isEmpty())url=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("url_external_movie",url);if(FeatureRegistry.isSafeHttpUrl(url))i.putExtra("url",url);else{String fallback=FeatureRegistry.getUrl(this,key);if(FeatureRegistry.isSafeHttpUrl(fallback))i.putExtra("url",fallback);}startActivity(i);}catch(Throwable t){toast(title+" is ready.");}}
    private void applyLiveAd(int index){if(liveAdImage==null||liveAds.isEmpty())return;JSONObject a=liveAds.get(index%liveAds.size());String u=a.optString("image_url","");String cap=a.optString("caption","");if(!u.isEmpty())loadRemoteImage(liveAdImage,u);liveAdCaption.setText(cap.isEmpty()?"Advertisement":cap);liveAdImage.setOnClickListener(v->{String target=a.optString("target_url","");if(FeatureRegistry.isSafeHttpUrl(target)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception ignored){}}});}
    private void startLiveAdCarousel(){scheduleLiveAdCarousel();}
    private void scheduleLiveAdCarousel(){handler.removeCallbacks(liveAdCarouselTick);if(dashboardVisible&&!dashboardDestroyed)handler.postDelayed(liveAdCarouselTick,5000);}
    private void openPromoTarget(int visibleIndex){int idx=(promoSlide+visibleIndex)%6;String t=remotePromoTargets[idx];if(FeatureRegistry.isSafeHttpUrl(t)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(t)));}catch(Exception ignored){}}}

    private void applyPromoSlide(){if(promoViews==null||promoViews.length<2)return;int idx=promoSlide%6;for(int i=0;i<2;i++){final int slotIndex=i;final int slideIndex=(idx+i)%6;final String u=remotePromoUrls[slideIndex];final ImageView v=promoViews[i];if(v==null)continue;v.animate().alpha(0.35f).setDuration(180).withEndAction(()->{if(u!=null&&!u.isEmpty())loadRemoteImage(v,u);else v.setImageResource(slotIndex==0?left[slideIndex%left.length]:right[slideIndex%right.length]);v.animate().alpha(1f).setDuration(260).start();}).start();}}
    private void startPromoCarousel(){schedulePromoCarousel();}
    private void schedulePromoCarousel(){handler.removeCallbacks(promoCarouselTick);if(dashboardVisible&&!dashboardDestroyed)handler.postDelayed(promoCarouselTick,4000);}

    private int previousHeroSlide(int current){boolean any=false;for(String u:remoteHeroUrls)if(u!=null&&!u.isEmpty()){any=true;break;}if(any){for(int step=1;step<=6;step++){int idx=(current-step+6*2)%6;if(remoteHeroUrls[idx]!=null&&!remoteHeroUrls[idx].isEmpty())return idx;}}return (current+5)%6;}
    private void openHeroTarget(){if(SessionManager.isAdmin(this)){startActivity(new Intent(this,BannerAdminActivity.class).putExtra("admin_context",true));return;}String t=(slide>=0&&slide<remoteHeroTargets.length)?remoteHeroTargets[slide]:"";if(FeatureRegistry.isSafeHttpUrl(t)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(t)));}catch(Exception ignored){}}}
    private int nextHeroSlide(int current){
        boolean any=false; for(String u:remoteHeroUrls) if(u!=null&&!u.isEmpty()){any=true;break;}
        if(any){for(int step=1;step<=6;step++){int idx=(current+step)%6;if(remoteHeroUrls[idx]!=null&&!remoteHeroUrls[idx].isEmpty())return idx;}}
        return (current+1)%6;
    }
    private void showHeroSlide(int idx){
        slide=Math.max(0,Math.min(5,idx)); String u=remoteHeroUrls[slide];
        if(u!=null&&!u.isEmpty())loadRemoteImage(hero,u);else hero.setImageResource(heroImgs[slide]);
        StringBuilder b=new StringBuilder();for(int i=0;i<6;i++){b.append(i==slide?"●":"○");if(i<5)b.append("   ");}if(dots!=null)dots.setText(b.toString());
    }
    private void showFirstRemoteHeroIfAvailable(){
        for(int i=0;i<remoteHeroUrls.length;i++){if(remoteHeroUrls[i]!=null&&!remoteHeroUrls[i].isEmpty()){showHeroSlide(i);return;}}
        showHeroSlide(slide);
    }
    private void startCarousel(){scheduleHeroCarousel(900L);}
    private void scheduleHeroCarousel(){scheduleHeroCarousel(3500L);}
    private void scheduleHeroCarousel(long delayMs){handler.removeCallbacks(heroCarouselTick);if(dashboardVisible&&!dashboardDestroyed)handler.postDelayed(heroCarouselTick,Math.max(500L,delayMs));}
    private void loadNotificationCount(){String token=SessionManager.getToken(this);if(token==null||token.isEmpty()){unreadNotificationCount=0;updateNotificationBadge();return;}BackendClient.notifications(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){unreadNotificationCount=Math.max(0,d.optInt("unreadCount",0));getSharedPreferences("myshop_notifications",MODE_PRIVATE).edit().putString("last_payload",d.toString()).apply();runOnUiThread(()->updateNotificationBadge());}public void onError(String m){}});}
    private void updateNotificationBadge(){if(notificationBadge==null)return;if(unreadNotificationCount<=0)notificationBadge.setVisibility(View.GONE);else{notificationBadge.setVisibility(View.VISIBLE);notificationBadge.setText(unreadNotificationCount>99?"99+":String.valueOf(unreadNotificationCount));}}
    private void loadMessageCount(){String token=SessionManager.getToken(this);if(token==null||token.isEmpty()){unreadMessageCount=0;updateMessageBadge();return;}BackendClient.messageUnread(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){unreadMessageCount=Math.max(0,d.optInt("unreadCount",0));runOnUiThread(()->updateMessageBadge());}public void onError(String m){}});}
    private void updateMessageBadge(){if(messageBadge==null)return;if(unreadMessageCount<=0)messageBadge.setVisibility(View.GONE);else{messageBadge.setVisibility(View.VISIBLE);messageBadge.setText(unreadMessageCount>99?"99+":String.valueOf(unreadMessageCount));}}
    private String languageCode(){String l=LanguageManager.get(this);if(LanguageManager.EN.equals(l))return "EN";if(LanguageManager.HI.equals(l))return "HI";if(LanguageManager.AR.equals(l))return "AR";return "বাং";}
    @Override protected void onResume(){
        super.onResume();
        dashboardVisible=true;
        // onCreate already performs the first dashboard load. Running the same API/image
        // burst again from the first onResume doubled memory/network pressure at startup.
        if(firstDashboardResume){
            firstDashboardResume=false;
        }else{
            loadCurrentProfile();loadRemote();loadNotificationCount();loadMessageCount();loadNewPeople();
            if(feedList!=null&&!feedLoading&&(System.currentTimeMillis()-lastFeedLoadAt>30000))loadFeed(true);
        }
        handler.removeCallbacks(notificationPoll);handler.postDelayed(notificationPoll,12000);
        handler.removeCallbacks(profilePresencePoll);handler.postDelayed(profilePresencePoll,5000);
        scheduleHeroCarousel(900L);schedulePromoCarousel();scheduleLiveAdCarousel();restartNewsMarquee();
    }
    @Override protected void onPause(){dashboardVisible=false;handler.removeCallbacks(notificationPoll);handler.removeCallbacks(profilePresencePoll);handler.removeCallbacks(heroCarouselTick);handler.removeCallbacks(promoCarouselTick);handler.removeCallbacks(liveAdCarouselTick);pauseInlineVideos();super.onPause();}
    @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(hasFocus&&dashboardVisible)restartNewsMarquee();}
    private void restartNewsMarquee(){
        if(newsText==null||dashboardDestroyed)return;
        newsText.setSingleLine(true);newsText.setEllipsize(TextUtils.TruncateAt.MARQUEE);newsText.setMarqueeRepeatLimit(-1);newsText.setHorizontallyScrolling(true);
        newsText.setSelected(false);newsText.postDelayed(()->{if(newsText!=null&&!dashboardDestroyed&&dashboardVisible)newsText.setSelected(true);},80);
    }
    private void loadRemoteImage(ImageView target,String url){
        if(target==null||url==null||url.trim().isEmpty())return;
        final String key=url.trim();
        Bitmap cached=imageCache.get(key);
        if(cached!=null&&!cached.isRecycled()){target.setImageBitmap(cached);return;}
        target.setTag(key);
        // Dashboard can show many remote images at once. Decode to a bounded size
        // instead of expanding every R2 photo/banner at full camera resolution.
        if(dashboardDestroyed||imagePool.isShutdown()||imagePool.isTerminated())return;
        try{imagePool.execute(()->{
            Bitmap bm=null;
            try{
                BitmapFactory.Options bounds=new BitmapFactory.Options();
                bounds.inJustDecodeBounds=true;
                decodeRemoteBitmap(key,bounds);
                if(bounds.outWidth<=0||bounds.outHeight<=0)return;
                int maxPx=1280,sample=1,largest=Math.max(bounds.outWidth,bounds.outHeight);
                while(largest/sample>maxPx)sample*=2;
                BitmapFactory.Options opts=new BitmapFactory.Options();
                opts.inSampleSize=Math.max(1,sample);
                opts.inPreferredConfig=Bitmap.Config.RGB_565;
                opts.inDither=true;
                bm=decodeRemoteBitmap(key,opts);
            }catch(OutOfMemoryError oom){
                bm=null;
                System.gc();
            }catch(Exception ignored){
                bm=null;
            }
            final Bitmap safe=bm;
            if(safe!=null&&!dashboardDestroyed&&!isFinishing()&&!isDestroyed()){
                imageCache.put(key,safe);
                runOnUiThread(()->{
                    if(!dashboardDestroyed&&!isFinishing()&&!isDestroyed()&&key.equals(target.getTag()))target.setImageBitmap(safe);
                });
            }
        });}catch(java.util.concurrent.RejectedExecutionException ignored){}
    }
    private Bitmap decodeRemoteBitmap(String url,BitmapFactory.Options opts) throws Exception{
        HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(6000);c.setReadTimeout(8000);c.setInstanceFollowRedirects(true);c.setUseCaches(true);int code=c.getResponseCode();if(code<200||code>=300)throw new java.io.IOException("HTTP "+code);try(InputStream in=c.getInputStream()){return BitmapFactory.decodeStream(in,null,opts);}}finally{if(c!=null)c.disconnect();}
    }
    private void applyRipple(View v){
        if(android.os.Build.VERSION.SDK_INT>=21){
            android.graphics.drawable.Drawable base=v.getBackground();
            if(base==null)return;
            v.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.argb(42,30,55,120)),base,null));
        }
    }
    private TextView action(String s,int c){TextView t=text(s,Color.WHITE,10.5f,true);t.setGravity(Gravity.CENTER);t.setMinHeight(dp(44));t.setPadding(dp(10),0,dp(10),0);t.setBackground(gradient(c,Color.rgb(Math.max(0,Color.red(c)-18),Math.max(0,Color.green(c)-18),Math.max(0,Color.blue(c)-18)),12));t.setElevation(dp(2));applyRipple(t);return t;}
    private ImageView pic(int r){ImageView v=new ImageView(this);v.setImageResource(r);v.setScaleType(ImageView.ScaleType.FIT_XY);return v;}
    private Button icon(String s,int c,float z){Button b=new Button(this);b.setText(s);b.setTextColor(c);b.setTextSize(Math.max(z,11f));b.setGravity(Gravity.CENTER);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setPadding(0,0,0,0);b.setBackgroundColor(Color.TRANSPARENT);return b;}
    private TextView text(String s,int c,float z,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);} private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;} private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;} private View space(){return new View(this);} private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);} private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;} private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);} private GradientDrawable round(int fill,int stroke,int rad){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(rad));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;} private GradientDrawable gradient(int a,int b,int rad){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});g.setCornerRadius(dp(rad));return g;} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onDestroy(){dashboardDestroyed=true;dashboardVisible=false;handler.removeCallbacksAndMessages(null);pauseInlineVideos();imagePool.shutdownNow();imageCache.evictAll();super.onDestroy();}
    private void showPremiumLiveLauncher(){
        final android.app.Dialog d=new android.app.Dialog(this);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(18),dp(18),dp(18));box.setBackground(round(Color.rgb(12,20,62),Color.rgb(157,67,255),24));
        TextView title=text("✨  CHOOSE LIVE TYPE",Color.WHITE,17,true);title.setGravity(Gravity.CENTER);box.addView(title,lp(-1,dp(42)));
        TextView sub=text("Start your MY SHOP live room",Color.rgb(185,199,245),10,false);sub.setGravity(Gravity.CENTER);box.addView(sub,lp(-1,dp(28)));
        TextView audio=text("🎙️  AUDIO LIVE\nStart Audio Room",Color.WHITE,15,true);audio.setGravity(Gravity.CENTER);audio.setBackground(gradient(Color.rgb(88,45,220),Color.rgb(216,39,190),22));audio.setOnClickListener(v->{d.dismiss();Intent i=new Intent(this,AudioLiveRoomActivity.class);i.putExtra("hostMode",true);startActivity(i);});LinearLayout.LayoutParams ap=lp(-1,dp(78));ap.topMargin=dp(10);box.addView(audio,ap);
        TextView video=text("📹  VIDEO LIVE\nCOMING SOON",Color.rgb(220,226,255),14,true);video.setGravity(Gravity.CENTER);video.setBackground(round(Color.rgb(20,31,78),Color.rgb(78,118,220),22));video.setOnClickListener(v->Toast.makeText(this,"Video Live — Coming Soon",Toast.LENGTH_SHORT).show());LinearLayout.LayoutParams vp=lp(-1,dp(70));vp.topMargin=dp(10);box.addView(video,vp);
        TextView cancel=text("Cancel",Color.rgb(190,200,235),11,true);cancel.setGravity(Gravity.CENTER);cancel.setOnClickListener(v->d.dismiss());box.addView(cancel,lp(-1,dp(42)));
        d.setContentView(box);android.view.Window w=d.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.68f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.88f),-2);}d.setOnShowListener(x->{android.view.Window ww=d.getWindow();if(ww!=null)ww.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.88f),-2);});d.show();
    }

}
