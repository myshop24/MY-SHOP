package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

/** V-395 compact Home search: exact MY SHOP ID lookup without changing existing backend contracts. */
public class SearchActivity extends androidx.appcompat.app.AppCompatActivity {
    private EditText query;
    @Override protected void onCreate(Bundle b){super.onCreate(b);build();}
    private void build(){
        LinearLayout root=col();root.setPadding(dp(14),dp(14),dp(14),dp(22));root.setBackgroundColor(Color.rgb(246,248,253));
        LinearLayout head=row();TextView back=t("‹",30,Color.rgb(26,37,76),true);back.setGravity(Gravity.CENTER);back.setOnClickListener(v->finish());head.addView(back,lp(dp(42),dp(46)));TextView title=t("Search MY SHOP",18,Color.rgb(22,32,73),true);title.setGravity(Gravity.CENTER_VERTICAL);head.addView(title,new LinearLayout.LayoutParams(0,dp(46),1));root.addView(head,lp(-1,dp(50)));
        LinearLayout card=col();card.setPadding(dp(13),dp(14),dp(13),dp(14));card.setBackground(round(Color.WHITE,Color.rgb(224,228,240),18));card.setElevation(dp(3));TextView info=t("Find a user by MY SHOP ID",11,Color.rgb(92,101,126),false);card.addView(info,lp(-1,dp(28)));
        query=new EditText(this);query.setHint("Enter 4-digit MY SHOP ID");query.setSingleLine(true);query.setTextSize(14);query.setInputType(InputType.TYPE_CLASS_NUMBER);query.setPadding(dp(12),0,dp(12),0);query.setBackground(round(Color.rgb(245,248,255),Color.rgb(208,217,239),13));card.addView(query,lp(-1,dp(50)));
        TextView go=t("Search  →",12,Color.WHITE,true);go.setGravity(Gravity.CENTER);go.setBackground(round(Color.rgb(25,108,245),Color.TRANSPARENT,13));go.setElevation(dp(3));go.setOnClickListener(v->open());card.addView(go,top(lp(-1,dp(46)),10));root.addView(card,top(lp(-1,-2),8));setContentView(root);
    }
    private void open(){String id=query.getText().toString().trim();if(!id.matches("\\d{4}")){Toast.makeText(this,"Enter a valid 4-digit MY SHOP ID",Toast.LENGTH_SHORT).show();return;}Intent i=new Intent(this,UserProfileActivity.class);i.putExtra("userId",id);startActivity(i);}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private TextView t(String s,float z,int c,boolean b){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(b)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}private GradientDrawable round(int fill,int stroke,int r){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(r));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int t){p.topMargin=dp(t);return p;}private int dp(float x){return Math.round(x*getResources().getDisplayMetrics().density);}
}
