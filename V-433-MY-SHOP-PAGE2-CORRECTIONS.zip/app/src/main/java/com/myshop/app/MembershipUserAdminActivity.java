package com.myshop.app;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.*;
import java.util.ArrayList;

/** Exact ID -> verified profile -> select published membership -> confirm grant/remove. */
public final class MembershipUserAdminActivity extends AppCompatActivity {
    private EditText id,days;private TextView user,status;private ImageView photo;private Spinner choice;
    private Button search,grant,remove;private final ArrayList<JSONObject> products=new ArrayList<>();private String verifiedId="";private boolean busy;
    @Override protected void onCreate(Bundle state){super.onCreate(state);if(!SessionManager.isAdmin(this)){finish();return;}
        ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(12),dp(16),dp(22));root.setBackgroundColor(Color.WHITE);
        root.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(dp(16),Math.max(dp(12),i.getSystemWindowInsetTop()),dp(16),Math.max(dp(22),i.getSystemWindowInsetBottom()));return i;});
        Button back=button("‹ MEMBERSHIP USER CONTROL");back.setOnClickListener(v->finish());root.addView(back);
        id=new EditText(this);id.setHint("Exact 4-digit MY SHOP User ID");id.setInputType(InputType.TYPE_CLASS_NUMBER);id.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(4)});root.addView(id);
        search=button("SEARCH / VERIFY ID");search.setOnClickListener(v->search());root.addView(search);
        photo=new ImageView(this);photo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);root.addView(photo,new LinearLayout.LayoutParams(-1,dp(92)));
        user=label("No user selected",16);root.addView(user);status=label("Loading published memberships…",12);root.addView(status);
        choice=new Spinner(this);root.addView(choice,new LinearLayout.LayoutParams(-1,dp(48)));
        days=new EditText(this);days.setHint("Duration in days (1–3650)");days.setInputType(InputType.TYPE_CLASS_NUMBER);days.setText("30");root.addView(days);
        grant=button("GRANT / CHANGE MEMBERSHIP");grant.setEnabled(false);grant.setOnClickListener(v->confirmGrant());root.addView(grant);
        remove=button("REMOVE MEMBERSHIP + COMMENT BOX");remove.setEnabled(false);remove.setOnClickListener(v->confirmRemove());root.addView(remove);
        root.addView(label("The photo/name above is the verified recipient. Grants are not sales. Removing a membership also disables its frame and matching comment box.",12));sc.addView(root);setContentView(sc);root.post(root::requestApplyInsets);
        id.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){verifiedId="";updateButtons();}public void afterTextChanged(android.text.Editable e){}});
        BackendClient.adminStoreCatalog(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{products.clear();ArrayList<String> names=new ArrayList<>();JSONArray a=d.optJSONArray("catalog");if(a!=null)for(int n=0;n<a.length();n++){JSONObject x=a.optJSONObject(n);if(x!=null&&!MembershipUi.tier(x.optString("code")).isEmpty()&&x.optInt("enabled",0)==1){products.add(x);names.add(x.optString("title")+" • "+x.optInt("duration_days",30)+" days");}}choice.setAdapter(new ArrayAdapter<String>(MembershipUserAdminActivity.this,android.R.layout.simple_spinner_dropdown_item,names));status.setText(products.isEmpty()?"No published memberships. Publish in Membership Admin first.":"Select a membership after verifying the recipient.");choice.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int position,long itemId){if(position<products.size())days.setText(String.valueOf(products.get(position).optInt("duration_days",30)));}public void onNothingSelected(android.widget.AdapterView<?> p){}});updateButtons();});}public void onError(String message){showError(message);}});
    }
    private void search(){String requested=id.getText().toString().trim();if(!requested.matches("[0-9]{4}")){showError("Enter a valid 4-digit ID.");return;}setBusy(true);verifiedId="";user.setText("Verifying ID "+requested+"…");BackendClient.userProfile(SessionManager.getToken(this),requested,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{setBusy(false);if(!requested.equals(id.getText().toString().trim()))return;JSONObject p=d.optJSONObject("profile");if(p==null){showError("Profile verification failed; nothing activated.");return;}verifiedId=requested;user.setText(p.optString("name","MY SHOP User")+"\nID "+requested);photo.setImageResource(R.drawable.myshop_profile_avatar);String url=p.optString("avatarUrl","");if(!url.isEmpty())AnimatedAssetLoader.load(photo,url,false);status.setText("Verified. Choose membership and confirm.");updateButtons();});}public void onError(String m){runOnUiThread(()->{setBusy(false);showError(m);});}});}
    private void confirmGrant(){if(busy||verifiedId.isEmpty()||choice.getSelectedItemPosition()<0||products.isEmpty())return;final int duration;try{duration=Integer.parseInt(days.getText().toString().trim());if(duration<1||duration>3650)throw new IllegalArgumentException();}catch(Exception e){showError("Duration must be 1–3650 days.");return;}JSONObject item=products.get(choice.getSelectedItemPosition());String target=verifiedId;new AlertDialog.Builder(this).setTitle("Confirm membership activation").setMessage(user.getText()+"\n"+item.optString("title")+"\n"+duration+" days\nAny current membership will be replaced.").setPositiveButton("ACTIVATE",(d,w)->{setBusy(true);BackendClient.adminMembershipGrant(SessionManager.getToken(this),target,item.optLong("id"),duration,result("Membership and comment box activated."));}).setNegativeButton("CANCEL",null).show();}
    private void confirmRemove(){if(busy||verifiedId.isEmpty())return;String target=verifiedId;new AlertDialog.Builder(this).setTitle("Remove this user’s membership?").setMessage(user.getText()+"\nThe frame and matching comment box will be disabled together.").setPositiveButton("REMOVE",(d,w)->{setBusy(true);BackendClient.adminMembershipRevoke(SessionManager.getToken(this),target,"Removed in Membership User Control",result("Membership and matching comment box removed."));}).setNegativeButton("CANCEL",null).show();}
    private BackendClient.Callback result(String message){return new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{setBusy(false);status.setText(message);Toast.makeText(MembershipUserAdminActivity.this,message,Toast.LENGTH_LONG).show();});}public void onError(String m){runOnUiThread(()->{setBusy(false);showError(m);});}};}
    private void setBusy(boolean value){busy=value;search.setEnabled(!busy);id.setEnabled(!busy);updateButtons();}
    private void updateButtons(){if(grant!=null)grant.setEnabled(!busy&&!verifiedId.isEmpty()&&!products.isEmpty());if(remove!=null)remove.setEnabled(!busy&&!verifiedId.isEmpty());}
    private void showError(String m){runOnUiThread(()->{status.setText(m);Toast.makeText(this,m,Toast.LENGTH_LONG).show();});}
    private TextView label(String value,int size){TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(0xFF252B49);v.setPadding(0,dp(8),0,dp(8));return v;}
    private Button button(String title){Button b=new Button(this);b.setText(title);b.setTextSize(12);b.setAllCaps(false);return b;}
    private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
}
