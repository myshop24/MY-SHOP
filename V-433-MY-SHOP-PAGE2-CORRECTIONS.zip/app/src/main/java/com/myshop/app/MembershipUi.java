package com.myshop.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.Locale;

/** Shared identity contract for Shop, Admin, Profile and Live. */
public final class MembershipUi {
    private MembershipUi(){}
    public static String tier(String raw){String c=raw==null?"":raw.trim().toUpperCase(Locale.US);if(c.startsWith("MS430_"))c=c.substring(6);return isTier(c)?c:"";}
    public static boolean isTier(String c){return "KING".equals(c)||"QUEEN".equals(c)||"ROYAL".equals(c)||"VVIP".equals(c)||"VIP".equals(c);}
    public static int accent(String c){switch(tier(c)){case "KING":return 0xFFFFBD42;case "QUEEN":return 0xFFFF52B7;case "ROYAL":return 0xFFAD73FF;case "VVIP":return 0xFF47D7FF;default:return 0xFF45DF98;}}
    public static int ornament(String c){switch(tier(c)){case "KING":return R.drawable.member430_king;case "QUEEN":return R.drawable.member430_queen;case "ROYAL":return R.drawable.member430_royal;case "VVIP":return R.drawable.member430_vvip;default:return R.drawable.member430_vip;}}
    public static View comment(Context c,String tier,String name,String url){
        int ac=accent(tier);LinearLayout row=new LinearLayout(c);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(c,3),dp(c,3),dp(c,3),dp(c,3));
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0xFF121B39,Color.rgb(Color.red(ac)/3,Color.green(ac)/3,Color.blue(ac)/3)});bg.setCornerRadius(dp(c,10));bg.setStroke(dp(c,1),ac);row.setBackground(bg);
        row.addView(new MembershipIdentityView(c,tier,url),new LinearLayout.LayoutParams(dp(c,35),dp(c,35)));
        LinearLayout text=new LinearLayout(c);text.setOrientation(LinearLayout.VERTICAL);TextView n=new TextView(c);n.setText((name==null||name.isEmpty()?"Your name":name)+" • "+tier);n.setTextColor(ac);n.setTextSize(8.5f);n.setTypeface(null,Typeface.BOLD);n.setSingleLine(true);text.addView(n);TextView body=new TextView(c);body.setText("Your matching comment box ✦");body.setTextColor(Color.WHITE);body.setTextSize(8);body.setMaxLines(2);text.addView(body);row.addView(text,new LinearLayout.LayoutParams(0,-2,1));return row;
    }
    /** Preserve the original avatar, click listeners and container. Removal is reversible. */
    public static void attach(ImageView avatar,String code,String url){attach(avatar,code,url,"");}
    public static void attach(ImageView avatar,String code,String url,String frameUrl){
        if(avatar==null||!(avatar.getParent() instanceof FrameLayout))return;FrameLayout parent=(FrameLayout)avatar.getParent();String tag="membership430:"+System.identityHashCode(avatar);View old=parent.findViewWithTag(tag);if(old!=null)parent.removeView(old);
        String tier=tier(code);if(tier.isEmpty()){avatar.setAlpha(1f);return;}MembershipIdentityView view=new MembershipIdentityView(avatar.getContext(),tier,url);view.setFrameAsset(frameUrl);view.setTag(tag);view.setClickable(false);view.setFocusable(false);parent.addView(view,parent.indexOfChild(avatar)+1,new FrameLayout.LayoutParams((FrameLayout.LayoutParams)avatar.getLayoutParams()));avatar.setAlpha(0f);
    }
    private static int dp(Context c,int v){return Math.round(v*c.getResources().getDisplayMetrics().density);}
}
