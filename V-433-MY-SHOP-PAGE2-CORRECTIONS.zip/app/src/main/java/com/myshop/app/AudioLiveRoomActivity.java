package com.myshop.app;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.media.MediaPlayer;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Build;
import android.app.PictureInPictureParams;
import android.util.Rational;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.HorizontalScrollView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.TimeZone;

/**
 * MY SHOP V-350 Premium Audio Live Room with light right-action spacing and bottom safe-area protection.
 * V-305 visual host separation: Host is rendered in the dedicated top Host area; the approved 8 default guest seats are preserved in two rows of four; extra occupied seats appear dynamically.
 * The bundled Guitar Blue wallpaper is the safe default while Admin themes
 * can override it remotely without changing the Dashboard.
 */
public class AudioLiveRoomActivity extends AppCompatActivity {
    private final java.util.HashSet<String> shownPremiumEntrances=new java.util.HashSet<>();
    private final Handler handler = new Handler();
    private boolean host;
    private boolean hostStarted;
    private volatile boolean endLiveInProgress = false;
    private volatile boolean roomEnded = false;
    private boolean localMicOn = true;
    private boolean roomAdmin = false;
    private boolean canSuggestCall = false;
    private boolean canPinComments = false;
    private boolean listenOnly = false;
    private String hostId;
    private String specialGuestId = "";
    private String myRole = "AUDIENCE";
    private long startedAtMs = 0L;
    private String activeSessionId = "";
    private long serverElapsedSec = 0L;
    private long serverElapsedSyncMs = 0L;
    private boolean endedSummaryShown = false;
    private boolean commentSending = false;
    private float liveCommentFontSize=15.2f; private JSONObject globalCommentStyle=new JSONObject(); private final java.util.HashMap<String,JSONObject> commentPresets=new java.util.HashMap<>(); private final java.util.HashMap<String,JSONObject> commentAssignments=new java.util.HashMap<>();
    private final Map<String,String> pendingComments = new LinkedHashMap<>();
    private final Set<String> shownMilestones = new HashSet<>();
    private long lastEntryEventId = 0L;
    private long lastGiftEventId = 0L;
    private final Set<Long> renderedGiftEventIds = new HashSet<>();
    private final Set<Long> renderedCommentIds = new HashSet<>();
    private final Set<Long> renderedRoomEventIds = new HashSet<>();
    private final Set<Long> renderedHighlightCommentIds = new HashSet<>();
    private int shareCount = 0;
    private long reactCount = 0L;
    private long voteCount = 0L;
    private ImageView wallpaper;
    private LinearLayout hostArea, audienceRow, specialArea, seats, requests, commentsList;
    private ScrollView commentScroll;
    private TextView viewers, status, syncState, durationView, roomTitle, roomTopic, pinnedView, shareView, reactView, premiumStrip, welcomeView, productView, pkView, topStatsView;
    private Button sendButton;
    private String currentLiveName = "Host";
    private final Set<Integer> lockedSeats = new HashSet<>();
    private JSONArray currentViewerProfiles = new JSONArray();
    private JSONArray currentTopSupporters = new JSONArray();
    private JSONObject currentHostStats = new JSONObject();
    private HorizontalScrollView audienceScroll;
    private TextView onlineCountView, topGiftView, topCoinView, topGoldView, topStarView;
    private JSONArray currentSeats = new JSONArray();
    private int currentSeatNo = 0;
    private final Map<String,Bitmap> avatarCache = new LinkedHashMap<>();
    private JSONArray currentRequests = new JSONArray();
    private int currentViewerCount = 0;
    private int currentPeakViewers = 0;
    private int currentTotalListeners = 0;
    private String lastInviteNotice = "";
    private String lastRequestNotice = "";
    private boolean inviteDialogOpen = false;
    private boolean requestDialogOpen = false;
    private String lastCommentsSignature = "";
    private int highlightPrice = 1000;
    private boolean highlightSelected = false;
    private long lastHighlightId = 0L;
    private TextView micButton, speakerActionButton;
    private float joinFontSize=18.0f;
    private int joinTextColor=Color.WHITE;
    private ObjectAnimator joinPulseAlpha, joinPulseX, joinPulseY;
    private LinearLayout requestNoticeBar;
    private JSONObject cachedGiftCatalog;
    private long cachedGiftCatalogAt = 0L;
    private volatile boolean giftCatalogFetchInFlight = false;
    private AlertDialog giftLoadingDialog;
    private AlertDialog giftStoreDialog;
    private String giftReceiverId="",giftReceiverName="";
    private volatile boolean giftPollInFlight = false;
    private volatile boolean refreshInFlight = false;
    private volatile boolean realtimeInFlight = false;
    private int realtimeFailures = 0;
    private int realtimeRevision = 0;
    private long lastRealtimeCommentId = 0L;
    private long lastRealtimeHighlightId = 0L;
    private long lastRealtimeFallbackMs = 0L;
    private long lastGiftRecoveryPollMs = 0L;
    private String myRequestStatus = "NONE";
    private int pendingRequestCount = 0;
    private int myLevel = 0;
    private volatile boolean localSpeaking = false;
    private volatile boolean voiceMonitorRunning = false;
    private android.media.AudioRecord voiceRecorder;
    private Thread voiceThread;
    private long lastVoiceAboveMs = 0L;
    private boolean micPermissionAsked = false;
    private AgoraRtcManager rtcManager;
    private volatile String rtcDiagnosticStatus="RTC waiting";
    private volatile int activeRtcSpeakerUid=-1;
    private volatile long activeRtcSpeakerAt=0L;
    private boolean rtcJoinRequested=false;
    private boolean rtcJoined=false;
    private long lastRtcAudioUiAt=0L;
    private String rtcRole="";

    // V-352: expensive full D1 room snapshots are no longer polled sub-second.
    // Realtime comments/gifts/control-dirty signals use the Durable Object hub.
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (roomEnded || endLiveInProgress) return;
            if (hostStarted || !host) refresh();
            // V-392 safety snapshot: realtime remains primary, but a short full-state fallback
            // prevents seats/requests/gifts from staying stale if a hub signal is missed.
            if (!roomEnded && !endLiveInProgress) handler.postDelayed(this, 1800L);
        }
    };

    private final Runnable presenceTick = new Runnable() {
        @Override public void run() {
            if (roomEnded || endLiveInProgress) return;
            if (hostStarted || !host) {
                if (host) BackendClient.setLivePresence(token(), true, new Silent());
                else BackendClient.liveViewer(token(), hostId, true, new Silent());
            }
            if (!roomEnded && !endLiveInProgress) handler.postDelayed(this, 6500L);
        }
    };

    private final Runnable participantTick = new Runnable() {
        @Override public void run() {
            if (roomEnded || endLiveInProgress) return;
            if (hostStarted || !host) {
                if (host || "SPEAKER".equals(myRole)) {
                    BackendClient.liveParticipantState(token(), hostId, localMicOn, localSpeaking, networkQuality(), new Silent());
                }
            }
            if (!roomEnded && !endLiveInProgress) handler.postDelayed(this, 1500L);
        }
    };

    private final Runnable durationTick = new Runnable() {
        @Override public void run() {
            if (durationView != null && !activeSessionId.isEmpty()) {
                long sec = Math.max(0, serverElapsedSec + (System.currentTimeMillis() - serverElapsedSyncMs) / 1000L);
                durationView.setText(hhmmss(sec));
            }
            handler.postDelayed(this, 1000);
        }
    };

    private final Runnable realtimeTick = new Runnable() {
        @Override public void run() {
            if (roomEnded || endLiveInProgress) return;
            if (!activeSessionId.isEmpty() && !realtimeInFlight) {
                realtimeInFlight = true;
                final String expectedSession = activeSessionId;
                final int knownRevision = realtimeRevision;
                BackendClient.liveRealtime(token(), hostId, expectedSession, lastRealtimeCommentId, lastRealtimeHighlightId, lastGiftEventId, knownRevision, new BackendClient.Callback(){
                    public void onSuccess(JSONObject d){runOnUiThread(()->{
                        realtimeInFlight=false;
                        if(roomEnded||!expectedSession.equals(activeSessionId))return;
                        realtimeFailures=0;
                        String sid=d.optString("sessionId","");
                        if(!sid.isEmpty()&&!sid.equals(activeSessionId))return;
                        JSONArray cs=d.optJSONArray("comments"),hs=d.optJSONArray("highlights"),gs=d.optJSONArray("gifts");
                        if(cs!=null){for(int i=0;i<cs.length();i++){JSONObject c=cs.optJSONObject(i);if(c!=null)lastRealtimeCommentId=Math.max(lastRealtimeCommentId,c.optLong("id",0));}}
                        if(hs!=null){for(int i=0;i<hs.length();i++){JSONObject h=hs.optJSONObject(i);if(h!=null)lastRealtimeHighlightId=Math.max(lastRealtimeHighlightId,h.optLong("id",0));}}
                        renderComments(cs,null,hs);
                        renderGiftEvents(gs);
                        int revision=Math.max(0,d.optInt("revision",knownRevision));
                        boolean stateDirty=d.optBoolean("changed",false)&&revision>realtimeRevision;
                        realtimeRevision=revision;
                        if(stateDirty && System.currentTimeMillis()-lastRealtimeFallbackMs>250L){
                            lastRealtimeFallbackMs=System.currentTimeMillis();
                            refresh();
                        }
                    });}
                    public void onError(String m){runOnUiThread(()->{
                        realtimeInFlight=false;
                        realtimeFailures++;
                        long now=System.currentTimeMillis();
                        // V-392: recover on the first realtime miss. A room-state refresh renews the
                        // hub ticket and the gift poll recovers any event delivered while realtime was down.
                        if(realtimeFailures>=1 && now-lastRealtimeFallbackMs>2500L){
                            lastRealtimeFallbackMs=now;
                            refresh();
                            if(!giftPollInFlight){
                                giftPollInFlight=true;
                                BackendClient.liveGiftEvents(token(),hostId,lastGiftEventId,new BackendClient.Callback(){
                                    public void onSuccess(JSONObject x){runOnUiThread(()->{giftPollInFlight=false;renderGiftEvents(x.optJSONArray("events"));});}
                                    public void onError(String e){giftPollInFlight=false;}
                                });
                            }
                        }
                    });}
                });
            }
            long now=System.currentTimeMillis();
            // V-394: realtime hub is primary, but every participant also performs a tiny
            // event-id based recovery poll. This removes the sender-only gift failure mode
            // when a realtime signal is missed without duplicating effects.
            if(!activeSessionId.isEmpty() && !giftPollInFlight && now-lastGiftRecoveryPollMs>=1200L){
                lastGiftRecoveryPollMs=now;giftPollInFlight=true;
                BackendClient.liveGiftEvents(token(),hostId,lastGiftEventId,new BackendClient.Callback(){
                    public void onSuccess(JSONObject x){runOnUiThread(()->{giftPollInFlight=false;renderGiftEvents(x.optJSONArray("events"));});}
                    public void onError(String e){giftPollInFlight=false;}
                });
            }
            if (now-cachedGiftCatalogAt>60000L) prefetchGiftCatalog();
            handler.postDelayed(this, 300L);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        // V-353: Live voice and gift effects share the audible media output path.
        setVolumeControlStream(android.media.AudioManager.STREAM_MUSIC);
        host = getIntent().getBooleanExtra("hostMode", false);
        hostId = host ? SessionManager.getUserId(this) : getIntent().getStringExtra("hostId");
        if (hostId == null || hostId.trim().isEmpty()) hostId = SessionManager.getUserId(this);
        build();
        loadLiveUiSettings();
        rtcManager=new AgoraRtcManager(new AgoraRtcManager.Listener(){
            public void onJoined(){rtcJoined=true;rtcDiagnosticStatus="RTC connected";runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);updateLiveStatusLine();});}
            public void onRemoteUserJoined(int uid){rtcDiagnosticStatus="RTC peer "+uid+" connected";runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);updateLiveStatusLine();});}
            public void onRemoteAudioState(int uid,int state,int reason){rtcDiagnosticStatus="RTC remote audio uid="+uid+" state="+state+" reason="+reason;runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);updateLiveStatusLine();});}
            public void onLocalAudioState(int state,int error){rtcDiagnosticStatus="RTC local audio state="+state+" error="+error;runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);updateLiveStatusLine();});}
            public void onConnectionState(int state,int reason){if(state==3)rtcJoined=true;else if(state==5)rtcJoined=false;rtcDiagnosticStatus="RTC connection state="+state+" reason="+reason;runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);updateLiveStatusLine();});}
            public void onError(String m){rtcDiagnosticStatus=m;runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);updateLiveStatusLine();});}
            public void onTokenWillExpire(){rtcDiagnosticStatus="RTC token renewing";runOnUiThread(()->requestRtcToken(true));}
            public void onAudioLevel(boolean speaking){if(localSpeaking!=speaking){localSpeaking=speaking;runOnUiThread(()->{updateLiveStatusLine();refreshSpeakingAvatars();});}}
            public void onActiveSpeaker(int uid,int volume){int previous=activeRtcSpeakerUid;activeRtcSpeakerUid=uid;activeRtcSpeakerAt=System.currentTimeMillis();if(uid!=previous){lastRtcAudioUiAt=System.currentTimeMillis();runOnUiThread(()->{updateLiveStatusLine();refreshSpeakingAvatars();});}}
        });
        try{rtcManager.init(this);}catch(Exception e){Toast.makeText(this,"RTC init failed",Toast.LENGTH_LONG).show();}
        loadCommentUi();
        renderLocalSkeleton();
        handler.post(durationTick);
        handler.post(realtimeTick);
        handler.post(presenceTick);
        handler.post(participantTick);
        prefetchGiftCatalog();
        if (host) showHostSetup();
        else {
            BackendClient.liveViewer(token(), hostId, true, new Silent());
            requestRtcToken(false);
            handler.post(tick);
        }
    }

    private void showHostSetup() {
        final android.app.Dialog d=new android.app.Dialog(this);
        LinearLayout box=col();box.setPadding(dp(20),dp(18),dp(20),dp(18));box.setBackground(bg(Color.rgb(10,18,58),Color.rgb(170,69,255),24));
        TextView hd=t("🎙  START AUDIO LIVE",18,Color.WHITE,true);hd.setGravity(Gravity.CENTER);box.addView(hd,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView sub=t("Create your MY SHOP audio room",10.5f,Color.rgb(188,202,244),false);sub.setGravity(Gravity.CENTER);box.addView(sub,new LinearLayout.LayoutParams(-1,dp(30)));
        EditText title=new EditText(this);title.setHint("Live Name");title.setText(SessionManager.getFullName(this).isEmpty()?"My Live":SessionManager.getFullName(this));title.setTextColor(Color.WHITE);title.setHintTextColor(Color.rgb(155,166,205));title.setSingleLine(true);title.setPadding(dp(14),0,dp(14),0);title.setBackground(bg(Color.rgb(17,31,79),Color.rgb(94,110,225),16));LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(50));tp.topMargin=dp(10);box.addView(title,tp);
        EditText topic=new EditText(this);topic.setHint("Caption");String challengeTitle=getIntent().getStringExtra("challengeTitle");topic.setText(challengeTitle==null?"":challengeTitle);topic.setTextColor(Color.WHITE);topic.setHintTextColor(Color.rgb(155,166,205));topic.setSingleLine(true);topic.setPadding(dp(14),0,dp(14),0);topic.setBackground(bg(Color.rgb(17,31,79),Color.rgb(94,110,225),16));LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,dp(50));op.topMargin=dp(10);box.addView(topic,op);
        LinearLayout actions=row();Button cancel=small("Cancel");cancel.setBackground(bg(Color.rgb(27,38,83),Color.rgb(96,111,185),18));Button go=btn("GO LIVE");go.setBackground(bg(Color.rgb(126,43,218),Color.rgb(255,71,192),18));cancel.setOnClickListener(v->{d.dismiss();finish();});go.setOnClickListener(v->{String t=title.getText().toString().trim(),p=topic.getText().toString().trim();if(t.isEmpty())t=SessionManager.getFullName(AudioLiveRoomActivity.this);if(t==null||t.trim().isEmpty())t="My Live";d.dismiss();startHostLive(t,p);});LinearLayout.LayoutParams c=new LinearLayout.LayoutParams(0,dp(46),.38f);c.rightMargin=dp(8);actions.addView(cancel,c);actions.addView(go,new LinearLayout.LayoutParams(0,dp(46),.62f));LinearLayout.LayoutParams ax=new LinearLayout.LayoutParams(-1,dp(46));ax.topMargin=dp(16);box.addView(actions,ax);
        d.setContentView(box);d.setCancelable(false);d.setOnShowListener(x->{android.view.Window w=d.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.72f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.88f),-2);}});d.show();
    }

    private void startHostLive(String title, String topic) {
        // V-394: the value the host just entered is authoritative immediately. Never render
        // a cached SessionManager/profile name while the start request is in flight.
        currentLiveName=(title==null||title.trim().isEmpty())?"My Live":title.trim();
        if(roomTitle!=null)roomTitle.setText("🎙 "+currentLiveName);
        // Atomic Live start: create the session with the selected Live Name/Caption
        // in one backend operation, so nobody can discover the room under an old cached name.
        BackendClient.setLivePresence(token(), true, title, topic, new BackendClient.Callback() {
            @Override public void onSuccess(JSONObject data) {
                hostStarted = true;
                currentLiveName=data.optString("title",title);
                runOnUiThread(() -> { syncState.setText("● LIVE • Room connected"); requestRtcToken(false); refresh(); handler.post(tick); });
            }
            @Override public void onError(String m) { runOnUiThread(() -> { syncState.setText("Could not start live"); Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show(); showHostSetup(); }); }
        });
    }

    private void build() {
        FrameLayout page = new FrameLayout(this);
        wallpaper = new ImageView(this);
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        wallpaper.setImageResource(R.drawable.live_room_default_wallpaper);
        page.addView(wallpaper, new FrameLayout.LayoutParams(-1,-1));

        // V-320 premium depth layer: visual polish only; guest-seat structure/logic remains untouched.
        View ambience=new View(this);
        ambience.setBackground(gradient(new int[]{Color.argb(178,7,15,54),Color.argb(148,28,18,76),Color.argb(178,7,15,54)},Color.TRANSPARENT,0));
        page.addView(ambience,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout root = col(); root.setPadding(dp(10), dp(4), dp(10), dp(10));
        root.setBackgroundColor(Color.TRANSPARENT);
        page.addView(root, new FrameLayout.LayoutParams(-1,-1));

        // V-292: preserve V-291 bottom safe-area and add only light spacing to right-side actions.
        // clearly above Android gesture/navigation controls on every device.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int navBottom = insets == null ? 0 : insets.getSystemWindowInsetBottom();
            root.setPadding(dp(10), dp(4), dp(10), Math.max(dp(8), navBottom + dp(6)));
            return insets;
        });
        root.post(root::requestApplyInsets);

        roomTitle = t("", 1, Color.TRANSPARENT, false);
        viewers = t("", 1, Color.TRANSPARENT, false); viewers.setVisibility(View.GONE);
        LinearLayout meta = row();
        status = t((host?"Host":"🎧 Audience")+" • ID "+SessionManager.getUserId(this),11,Color.rgb(226,199,255),true);
        meta.addView(status,new LinearLayout.LayoutParams(0,dp(28),1));
        shareView=t("↗ 0",11,Color.rgb(226,199,255),true); shareView.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); meta.addView(shareView,new LinearLayout.LayoutParams(dp(70),dp(28)));
        meta.setVisibility(View.GONE); root.addView(meta,new LinearLayout.LayoutParams(1,1));
        syncState=t("",1,Color.TRANSPARENT,false); syncState.setVisibility(View.GONE); root.addView(syncState,new LinearLayout.LayoutParams(1,1));

        hostArea=col(); hostArea.setPadding(dp(7),dp(4),dp(7),dp(2)); hostArea.setBackgroundColor(Color.TRANSPARENT);
        audienceRow=row(); audienceRow.setGravity(Gravity.CENTER_VERTICAL);
        audienceScroll=new HorizontalScrollView(this); audienceScroll.setHorizontalScrollBarEnabled(false); audienceScroll.setFillViewport(false); audienceScroll.addView(audienceRow,new HorizontalScrollView.LayoutParams(-2,dp(76)));
        root.addView(hostArea,new LinearLayout.LayoutParams(-1,dp(128)));
        roomTopic = t("",1,Color.TRANSPARENT,false); roomTopic.setVisibility(View.GONE); root.addView(roomTopic,new LinearLayout.LayoutParams(1,1));
        specialArea=col(); specialArea.setGravity(Gravity.CENTER_HORIZONTAL); LinearLayout.LayoutParams sgp=new LinearLayout.LayoutParams(-1,-2); sgp.topMargin=dp(2); root.addView(specialArea,sgp);

        seats=col(); seats.setPadding(dp(2),dp(2),dp(2),dp(2)); seats.setBackgroundColor(Color.TRANSPARENT); root.addView(seats,new LinearLayout.LayoutParams(-1,-2));

        if(host){
            requestNoticeBar=row();
            requestNoticeBar.setGravity(Gravity.CENTER_VERTICAL);
            requestNoticeBar.setPadding(dp(8),dp(3),dp(6),dp(3));
            requestNoticeBar.setVisibility(View.GONE);
            requestNoticeBar.setBackground(gradient(new int[]{Color.argb(235,28,46,112),Color.argb(235,91,42,151)},Color.rgb(84,214,255),14));
            LinearLayout.LayoutParams rnp=new LinearLayout.LayoutParams(-1,dp(62)); rnp.topMargin=dp(2); rnp.bottomMargin=dp(2); root.addView(requestNoticeBar,rnp);
            requests=col(); requests.setVisibility(View.GONE); root.addView(requests,new LinearLayout.LayoutParams(1,1)); requests.addView(t("No pending requests",11,Color.LTGRAY,false));
        }

        pinnedView=t("",13.2f,Color.rgb(255,230,158),true); pinnedView.setOnLongClickListener(v->{if(canPinComments&&pinnedView.getVisibility()==View.VISIBLE){unpinComment();return true;}return false;}); pinnedView.setPadding(dp(10),dp(6),dp(10),dp(6)); pinnedView.setBackground(gradient(new int[]{Color.argb(192,32,27,91),Color.argb(192,47,23,103)},Color.rgb(255,199,80),14)); pinnedView.setVisibility(View.GONE);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2); pp.topMargin=dp(2); root.addView(pinnedView,pp);

        // V-367: no separate LIVE AUDIO strip below pinned comments. Speaking state is shown on avatars instead.
        premiumStrip=t("",1,Color.TRANSPARENT,false); premiumStrip.setVisibility(View.GONE); root.addView(premiumStrip,new LinearLayout.LayoutParams(1,1));
        welcomeView=t("",9.4f,Color.rgb(255,231,166),true);welcomeView.setPadding(dp(8),0,dp(8),0);welcomeView.setGravity(Gravity.CENTER_VERTICAL);welcomeView.setVisibility(View.GONE);root.addView(welcomeView,new LinearLayout.LayoutParams(-1,dp(21)));
        productView=t("",9.5f,Color.WHITE,true);productView.setPadding(dp(8),0,dp(8),0);productView.setGravity(Gravity.CENTER_VERTICAL);productView.setBackground(bg(Color.argb(170,26,97,79),Color.rgb(80,234,165),11));productView.setVisibility(View.GONE);productView.setOnClickListener(v->startActivity(new Intent(this,StoreActivity.class)));root.addView(productView,new LinearLayout.LayoutParams(-1,dp(22)));
        pkView=t("",9.6f,Color.WHITE,true);pkView.setPadding(dp(8),0,dp(8),0);pkView.setGravity(Gravity.CENTER_VERTICAL);pkView.setBackground(gradient(new int[]{Color.argb(190,151,31,76),Color.argb(190,67,41,185)},Color.rgb(255,92,159),11));pkView.setVisibility(View.GONE);root.addView(pkView,new LinearLayout.LayoutParams(-1,dp(22)));

        TextView chatTitle=t("",1,Color.TRANSPARENT,false); chatTitle.setVisibility(View.GONE); root.addView(chatTitle,new LinearLayout.LayoutParams(1,1));
        // V-387: comments have a dedicated safe zone BELOW the seat grid. Never overlay seats.
        FrameLayout commentStage=new FrameLayout(this); commentStage.setBackground(bg(Color.argb(42,7,17,54),Color.argb(74,81,104,190),16)); commentStage.setMinimumHeight(dp(120));
        commentScroll=new ScrollView(this); commentScroll.setVerticalScrollBarEnabled(false); commentScroll.setFillViewport(false); commentsList=col(); commentsList.setPadding(dp(5),dp(4),dp(5),dp(4)); commentsList.setBackgroundColor(Color.TRANSPARENT); commentScroll.setBackgroundColor(Color.TRANSPARENT); commentScroll.addView(commentsList);
        FrameLayout.LayoutParams csp=new FrameLayout.LayoutParams(-1,-1); csp.rightMargin=dp(48); commentStage.addView(commentScroll,csp);
        LinearLayout floating=col(); floating.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView request=t("✋",18,Color.WHITE,true); request.setGravity(Gravity.CENTER); request.setClickable(true); request.setFocusable(true); request.setElevation(dp(6)); PremiumUi.premiumButton(request,new int[]{Color.rgb(16,55,130),Color.rgb(55,64,179)},21,Color.rgb(78,220,255),6); request.setOnClickListener(v->{if(host)showJoinRequestsDialog();else requestJoinToCall();}); floating.addView(request,new LinearLayout.LayoutParams(dp(42),dp(42))); request.bringToFront();
        TextView gift=t("🎁",19,Color.WHITE,true); gift.setGravity(Gravity.CENTER); gift.setClickable(true); gift.setFocusable(true); gift.setElevation(dp(6)); PremiumUi.premiumButton(gift,new int[]{Color.rgb(93,42,145),Color.rgb(173,51,177)},21,Color.rgb(255,202,78),6); gift.setOnClickListener(v->showGiftPanel()); LinearLayout.LayoutParams gfp=new LinearLayout.LayoutParams(dp(42),dp(42)); gfp.topMargin=dp(8); floating.addView(gift,gfp); gift.bringToFront();
        reactView=t("❤️",16,Color.WHITE,true); reactView.setGravity(Gravity.CENTER); PremiumUi.premiumButton(reactView,new int[]{Color.rgb(109,24,124),Color.rgb(195,40,137)},21,Color.rgb(255,94,197),6); reactView.setOnClickListener(v->{BackendClient.liveReact(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{reactCount=d.optLong("reactCount",0);reactView.setText("❤️\n"+compact(reactCount));renderHost(findSeat(currentSeats,1));if(d.optInt("rewardCoin",0)>0&&host)Toast.makeText(AudioLiveRoomActivity.this,"Love React reward +"+d.optInt("rewardCoin")+" Coin",Toast.LENGTH_LONG).show();showReaction();});}public void onError(String e){runOnUiThread(()->showReaction());}});}); LinearLayout.LayoutParams frp=new LinearLayout.LayoutParams(dp(42),dp(42)); frp.topMargin=dp(8); floating.addView(reactView,frp);
        TextView vote=t("Vote",10.8f,Color.WHITE,true); vote.setGravity(Gravity.CENTER); vote.setBackground(softGradient(new int[]{Color.rgb(40,92,180),Color.rgb(97,57,184)},20)); vote.setOnClickListener(v->BackendClient.liveVote(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{voteCount=d.optLong("voteCount",voteCount);renderHost(findSeat(currentSeats,1));Toast.makeText(AudioLiveRoomActivity.this,"Vote added",Toast.LENGTH_SHORT).show();});}public void onError(String e){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_SHORT).show());}})); LinearLayout.LayoutParams vfp=new LinearLayout.LayoutParams(dp(42),dp(42));vfp.topMargin=dp(8);floating.addView(vote,vfp);
        TextView share=t("↗",18,Color.WHITE,true); share.setGravity(Gravity.CENTER); PremiumUi.premiumButton(share,new int[]{Color.rgb(16,61,126),Color.rgb(42,94,166)},21,Color.rgb(57,216,255),6); share.setOnClickListener(v->shareRoom()); LinearLayout.LayoutParams sfp=new LinearLayout.LayoutParams(dp(42),dp(42)); sfp.topMargin=dp(8); floating.addView(share,sfp);
        FrameLayout.LayoutParams fap=new FrameLayout.LayoutParams(dp(42),dp(242),Gravity.RIGHT|Gravity.BOTTOM); fap.rightMargin=dp(1); fap.bottomMargin=dp(6); commentStage.addView(floating,fap);
        LinearLayout.LayoutParams commentSafeLp=new LinearLayout.LayoutParams(-1,0,1);commentSafeLp.topMargin=dp(4);commentSafeLp.bottomMargin=dp(2);root.addView(commentStage,commentSafeLp);

        LinearLayout sendRow=row(); sendRow.setGravity(Gravity.CENTER_VERTICAL); sendRow.setPadding(dp(4),dp(3),dp(4),dp(3)); sendRow.setBackground(PremiumUi.gradient(this,new int[]{Color.argb(148,10,20,62),Color.argb(148,34,22,88)},20,Color.argb(82,118,93,210),1));PremiumUi.premiumElevation(sendRow,2);
        FrameLayout commentBox=new FrameLayout(this);
        EditText commentInput=new EditText(this); commentInput.setHint("Write a comment…"); commentInput.setTextColor(Color.WHITE); commentInput.setHintTextColor(Color.rgb(155,165,195)); commentInput.setSingleLine(true); commentInput.setTextSize(12.8f); commentInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_SHORT_MESSAGE); commentInput.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEND); commentInput.setFocusableInTouchMode(true); commentInput.setClickable(true); commentInput.setBackground(bg(Color.argb(184,9,19,51),Color.TRANSPARENT,17)); commentInput.setPadding(dp(10),0,dp(38),0); commentBox.addView(commentInput,new FrameLayout.LayoutParams(-1,-1));
        TextView highlight=t("✨",15,Color.rgb(255,219,96),true); highlight.setGravity(Gravity.CENTER); FrameLayout.LayoutParams hlp=new FrameLayout.LayoutParams(dp(36),-1,Gravity.RIGHT); commentBox.addView(highlight,hlp);
        highlight.setOnClickListener(v->{highlightSelected=!highlightSelected;highlight.setBackground(highlightSelected?bg(Color.argb(170,112,48,170),Color.rgb(255,216,89),15):null);Toast.makeText(this,highlightSelected?"Highlight ON • "+highlightPrice+" Coin":"Highlight OFF",Toast.LENGTH_SHORT).show();});
        BackendClient.liveHighlightConfig(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{highlightPrice=d.optInt("coinPrice",1000);if(d.optBoolean("free",false))highlightPrice=0;});}public void onError(String e){}});
        sendButton=small("➤"); sendButton.setAllCaps(false); sendButton.setTextSize(19.0f); sendButton.setContentDescription("Send comment"); PremiumUi.premiumPrimary(sendButton); sendButton.setClickable(true); sendButton.setFocusable(true); sendButton.setOnClickListener(v->sendLiveComment(commentInput,highlight)); commentInput.setOnEditorActionListener((v,actionId,event)->{boolean enter=event!=null&&event.getAction()==android.view.KeyEvent.ACTION_UP&&event.getKeyCode()==android.view.KeyEvent.KEYCODE_ENTER;if(actionId==android.view.inputmethod.EditorInfo.IME_ACTION_SEND||enter){sendLiveComment(commentInput,highlight);return true;}return false;});
        micButton=t("🎙",17,Color.WHITE,true); micButton.setGravity(Gravity.CENTER); micButton.setContentDescription("Microphone"); PremiumUi.premiumUtility(micButton,Color.rgb(67,225,255)); micButton.setOnClickListener(v->toggleMic()); updateLocalMicUi();
        FrameLayout liveMessageButton=new FrameLayout(this); liveMessageButton.setContentDescription("Messages"); liveMessageButton.setClickable(true); liveMessageButton.setFocusable(true); ImageView liveMessageIcon=new ImageView(this); liveMessageIcon.setImageResource(R.drawable.ui_message_hd); liveMessageIcon.setScaleType(ImageView.ScaleType.CENTER_INSIDE); liveMessageIcon.setPadding(dp(2),dp(2),dp(2),dp(2)); liveMessageButton.addView(liveMessageIcon,new FrameLayout.LayoutParams(-1,-1)); liveMessageButton.setOnClickListener(v->openLiveInbox()); PremiumUi.press(liveMessageButton);
        speakerActionButton=t(host?"END":"JOIN",host?13.6f:Math.min(joinFontSize,15.0f),host?Color.WHITE:joinTextColor,true); speakerActionButton.setGravity(Gravity.CENTER); speakerActionButton.setSingleLine(true); if(host){speakerActionButton.setBackground(gradient(new int[]{Color.rgb(255,58,86),Color.rgb(222,38,121)},Color.rgb(255,150,188),17));}else{speakerActionButton.setBackground(gradient(new int[]{Color.rgb(17,196,255),Color.rgb(63,82,237),Color.rgb(200,31,236)},Color.rgb(103,235,255),17));} speakerActionButton.setOnClickListener(v->{if(host){endHostLive();return;}if("SPEAKER".equals(myRole)){confirmLeaveSeat();return;}if(listenOnly){showFloatingBanner("🔇 Listen-only mode");return;}requestJoinToCall();});
        LinearLayout.LayoutParams cip=new LinearLayout.LayoutParams(0,dp(38),1); cip.rightMargin=dp(4); sendRow.addView(commentBox,cip);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(44),dp(38)); sp.rightMargin=dp(4); sendRow.addView(sendButton,sp);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(dp(44),dp(38)); mp.rightMargin=dp(4); sendRow.addView(micButton,mp);
        LinearLayout.LayoutParams msgp=new LinearLayout.LayoutParams(dp(42),dp(38)); msgp.rightMargin=dp(4); sendRow.addView(liveMessageButton,msgp);
        speakerActionButton.setElevation(dp(6));
        sendRow.addView(speakerActionButton,new LinearLayout.LayoutParams(dp(84),dp(38)));
        updateJoinButtonAnimation();
        LinearLayout.LayoutParams srp=new LinearLayout.LayoutParams(-1,dp(52)); srp.topMargin=dp(4); srp.bottomMargin=dp(2); root.addView(sendRow,srp);
        // commentStage is intentionally part of the vertical root layout, so comments/gift text
        // cannot climb over the host/guest seats even on smaller screens.
        setContentView(page);
    }

    private void addControls(LinearLayout root){
        LinearLayout bottom=row(); bottom.setGravity(Gravity.CENTER_VERTICAL);
        String[] labels=host?new String[]{"🎙","➕","🪑","📌","↗","⚙"}:new String[]{"✋","➕","💬","📩","↗","⚙"};
        for(int i=0;i<labels.length;i++){final int idx=i;TextView v=t(labels[i],16,Color.WHITE,true);v.setGravity(Gravity.CENTER);PremiumUi.premiumButton(v,new int[]{Color.rgb(17,42,103),Color.rgb(65,46,143)},18,Color.argb(150,106,207,255),4);v.setOnClickListener(x->handleCompactControl(idx));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(40),1);lp.setMargins(dp(2),0,dp(2),0);bottom.addView(v,lp);}
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(42)); bp.topMargin=dp(3); root.addView(bottom,bp);
    }

    private void handleCompactControl(int i){
        if(host){if(i==0)toggleMic();else if(i==1)showAudienceList();else if(i==2)Toast.makeText(this,"Tap a sofa to lock/unlock or manage speaker",Toast.LENGTH_SHORT).show();else if(i==3)editPinned();else if(i==4)shareRoom();else if(i==5)showHostRoomMenu();}
        else{if(i==0)BackendClient.liveSpeakRequest(token(),hostId,new ToastCb("Request sent"));else if(i==1)BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));else if(i==2)Toast.makeText(this,"Live chat is above",Toast.LENGTH_SHORT).show();else if(i==3)Toast.makeText(this,"Open Inbox",Toast.LENGTH_SHORT).show();else if(i==4)shareRoom();else showLiveCommunityMenu();}
    }

    private void showHostRoomMenu(){String[] a={"Live Summary","Theme","Live Name / Caption","Pinned announcement","Welcome / Rules","Live Goal","Pin Shop Item","Top Supporters / Fan Club","Creator Center","Schedule Live","PK / Battle","End Live"};new AlertDialog.Builder(this).setTitle("Host Room Controls").setItems(a,(d,w)->{if(w==0)showRunningLiveSummary();else if(w==1)chooseTheme();else if(w==2)editRoomInfo();else if(w==3)editPinned();else if(w==4)editWelcome();else if(w==5)editGoal();else if(w==6)choosePinnedProduct();else if(w==7)showFanClub();else if(w==8)openCreatorCenter(hostId);else if(w==9)showScheduleDialog();else if(w==10)showPkDialog();else confirmEndLive();}).show();}

    private void handleControl(int i){
        if(host){
            if(i==0) toggleMic(); else if(i==2) Toast.makeText(this,"Tap any sofa to lock/unlock or manage speaker",Toast.LENGTH_SHORT).show();
            else if(i==3) editPinned(); else if(i==4) chooseTheme(); else if(i==5) shareRoom(); else if(i==6) showReaction(); else if(i==7) editRoomInfo();
            else Toast.makeText(this,"Host control ready",Toast.LENGTH_SHORT).show();
        } else {
            if(i==0) toggleMic(); else if(i==1) BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));
            else if(i==3) showReaction(); else if(i==5) shareRoom(); else Toast.makeText(this,"Live control",Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleMic(){
        localMicOn=!localMicOn;
        if(!localMicOn)localSpeaking=false;
        updateLocalMicUi();
        updateVoiceMonitor();
        if(rtcManager!=null)rtcManager.setMicEnabled(localMicOn&&(host||"SPEAKER".equals(myRole))&&!listenOnly);
        BackendClient.liveParticipantState(token(),hostId,localMicOn,localSpeaking,networkQuality(),true,new ToastCb(localMicOn?"Mic on":"Mic muted"));
    }

    private void updateLocalMicUi(){
        if(micButton==null)return;
        if(localMicOn){
            micButton.setText("🎙");
            micButton.setTextColor(Color.WHITE);
            micButton.setBackground(gradient(new int[]{Color.rgb(22,68,187),Color.rgb(67,42,214)},Color.rgb(42,232,255),18));
        }else{
            micButton.setText("🎙✕");
            micButton.setTextColor(Color.rgb(255,92,92));
            micButton.setBackground(gradient(new int[]{Color.rgb(92,24,48),Color.rgb(132,28,55)},Color.rgb(255,76,92),18));
        }
    }

    private String rtcAudioIndicator(){
        boolean publish=(host||"SPEAKER".equals(myRole))&&!listenOnly;
        long age=System.currentTimeMillis()-activeRtcSpeakerAt;
        if(activeRtcSpeakerUid>0&&age>=0&&age<1800L)return "🔊 Voice receiving";
        if(publish&&localSpeaking)return "🎤 Mic sending";
        if(rtcJoined)return publish?(localMicOn?"🎤 Mic connected":"🎤 Mic muted"):"🔊 Listening";
        return "Audio connecting";
    }
    private void updateLiveStatusLine(){
        String roleText=host?"HOST":(roomAdmin?"ADMIN":myRole);
        if(status!=null)status.setText((host?"Host":(roomAdmin?"🛡 Admin":"🎧 "+myRole))+" • ID "+SessionManager.getUserId(this)+(listenOnly?" • Listen only":"")+" • "+rtcAudioIndicator());
        // V-367: audio state is represented by avatar speaking glow/mic badge, not a separate comment-area strip.
    }

    private void updateVoiceMonitor(){
        boolean publish=(host||"SPEAKER".equals(myRole))&&!listenOnly;
        stopVoiceMonitor(false); // Agora owns microphone capture; never open a competing AudioRecord.
        if(rtcManager!=null){rtcManager.setPublishAudio(publish);rtcManager.setMicEnabled(publish&&localMicOn);}
        if(!publish)localSpeaking=false;
    }

    private void startVoiceMonitor(){ updateVoiceMonitor(); }
    private void stopVoiceMonitor(boolean publish){
        voiceMonitorRunning=false;localSpeaking=false;
        try{if(voiceRecorder!=null){voiceRecorder.stop();voiceRecorder.release();}}catch(Exception ignored){}
        voiceRecorder=null;voiceThread=null;
    }

    private boolean ensureRtcMicPermission(){
        boolean publish=(host||"SPEAKER".equals(myRole))&&!listenOnly;
        if(!publish)return true;
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},9021);
            if(syncState!=null)syncState.setText("● LIVE • Allow microphone to connect audio");
            return false;
        }
        return true;
    }

    private void requestRtcToken(boolean renew){
        if(roomEnded||endLiveInProgress||hostId==null||hostId.isEmpty()||rtcManager==null)return;
        if(!ensureRtcMicPermission())return;
        if(rtcJoinRequested&&!renew)return;
        rtcJoinRequested=true;
        BackendClient.agoraRtcToken(token(),hostId,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                rtcJoinRequested=false;String t=d.optString("token","");String ch=d.optString("channel","");int uid=d.optInt("uid",0);String role=d.optString("role","AUDIENCE");
                String serverLiveName=d.optString("liveName","").trim();if(!serverLiveName.isEmpty()){currentLiveName=serverLiveName;if(roomTitle!=null)roomTitle.setText("🎙 "+currentLiveName);}
                boolean publish="PUBLISHER".equals(role)&&!listenOnly;rtcRole=role;
                if(renew){rtcManager.renewToken(t);rtcManager.setPublishAudio(publish);rtcDiagnosticStatus="RTC token renewed • role="+role;}else{int rc=rtcManager.join(t,ch,uid,publish);rtcDiagnosticStatus=(rc==0?"RTC joining ch="+ch+" uid="+uid+" role="+role:"RTC join failed rc="+rc);}
                // V-392: a user promoted from audience to speaker must switch transport role
                // immediately; token renewal alone is not enough to start microphone publishing.
                rtcManager.setPublishAudio(publish);rtcManager.setMicEnabled(publish&&localMicOn);rtcManager.recoverPlayback();updateLiveStatusLine();
            });}
            public void onError(String m){rtcJoinRequested=false;runOnUiThread(()->{rtcJoined=false;rtcDiagnosticStatus="RTC token unavailable: "+m;if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);updateLiveStatusLine();});}
        });
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==9021 && grantResults.length>0 && grantResults[0]==android.content.pm.PackageManager.PERMISSION_GRANTED){updateVoiceMonitor();requestRtcToken(false);}
        else if(requestCode==9021){Toast.makeText(this,"Microphone permission is required to speak in Live",Toast.LENGTH_LONG).show();}
    }

    private void loadLiveUiSettings(){BackendClient.liveUiSettings(token(),new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{joinFontSize=(float)Math.max(14,Math.min(26,o.optDouble("joinFontSize",18)));try{joinTextColor=Color.parseColor(o.optString("joinTextColor","#FFFFFF"));}catch(Exception e){joinTextColor=Color.WHITE;}if(speakerActionButton!=null&&!host){speakerActionButton.setTextSize(joinFontSize);speakerActionButton.setTextColor(joinTextColor);}});}public void onError(String m){}});}

    private void loadCommentUi(){BackendClient.liveCommentUi(token(),new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{globalCommentStyle=o.optJSONObject("globalStyle");if(globalCommentStyle==null)globalCommentStyle=new JSONObject();liveCommentFontSize=(float)Math.max(12,Math.min(28,globalCommentStyle.optInt("fontSize",15)));commentPresets.clear();JSONArray p=o.optJSONArray("presets");if(p!=null)for(int i=0;i<p.length();i++){JSONObject x=p.optJSONObject(i);if(x!=null&&!x.optString("presetKey","").isEmpty())commentPresets.put(x.optString("presetKey"),x);}commentAssignments.clear();JSONArray a=o.optJSONArray("assignments");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&x.optBoolean("enabled",true)&&!x.optString("userId","").isEmpty())commentAssignments.put(x.optString("userId"),x);}});}public void onError(String m){}});}
    private JSONObject commentStyleFor(String userId){JSONObject a=commentAssignments.get(userId);if(a!=null){if(a.optBoolean("isCustom",false)){JSONObject c=a.optJSONObject("customStyle");if(c!=null)return c;}String key=a.optString("presetKey","");JSONObject p=commentPresets.get(key);if(p!=null)return p;}return globalCommentStyle==null?new JSONObject():globalCommentStyle;}
    private int commentColor(JSONObject s,String k,int fallback){try{return Color.parseColor(s.optString(k,""));}catch(Exception e){return fallback;}}
    private android.graphics.drawable.Drawable commentStyleDrawable(JSONObject s){int fill=Color.rgb(7,14,38),stroke=Color.TRANSPARENT;int op=Math.max(30,Math.min(100,s.optInt("opacity",92)));fill=Color.argb((int)(255*(op/100f)),Color.red(fill),Color.green(fill),Color.blue(fill));int radius=Math.max(10,Math.min(30,s.optInt("cornerRadius",18))),width=0;android.graphics.drawable.GradientDrawable inner=new android.graphics.drawable.GradientDrawable();inner.setColor(fill);inner.setCornerRadius(dp(radius));if(width>0)inner.setStroke(dp(width),stroke);if(!s.optBoolean("borderGlow",false))return inner;int gc=commentColor(s,"borderGlowColor",Color.rgb(168,85,247)),gi=Math.max(0,Math.min(100,s.optInt("borderGlowIntensity",55)));gc=Color.argb(Math.max(30,(int)(255*(gi/100f))),Color.red(gc),Color.green(gc),Color.blue(gc));android.graphics.drawable.GradientDrawable outer=new android.graphics.drawable.GradientDrawable();outer.setColor(Color.TRANSPARENT);outer.setCornerRadius(dp(radius+3));outer.setStroke(dp(Math.max(2,width+2)),gc);android.graphics.drawable.LayerDrawable layers=new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{outer,inner});layers.setLayerInset(1,dp(3),dp(3),dp(3),dp(3));return layers;}
    private void applyCommentStyle(TextView row,String userId){JSONObject s=commentStyleFor(userId);row.setTextSize((float)Math.max(12,Math.min(28,s.optInt("fontSize",15))));row.setTextColor(commentColor(s,"textColor",Color.WHITE));row.setTypeface(Typeface.DEFAULT,"BOLD".equalsIgnoreCase(s.optString("fontWeight","NORMAL"))?Typeface.BOLD:Typeface.NORMAL);row.setBackground(commentStyleDrawable(s));row.setElevation(dp(s.optBoolean("backgroundGlow",false)?5:1));boolean any=s.optBoolean("animation",false)||s.optBoolean("boxAnimation",false)||s.optBoolean("borderAnimation",false)||s.optBoolean("textAnimation",false)||s.optBoolean("nameAnimation",false)||s.optBoolean("levelAnimation",false);if(any){long d=Math.max(220,1200-(Math.max(10,Math.min(100,s.optInt("animationSpeed",55)))*8L));String type=s.optBoolean("boxAnimation",false)?s.optString("boxAnimationType",s.optString("animationType","FADE")):s.optString("animationType","FADE");android.view.animation.Animation a;if("POP".equalsIgnoreCase(type)){a=new android.view.animation.ScaleAnimation(.92f,1f,.92f,1f,android.view.animation.Animation.RELATIVE_TO_SELF,.5f,android.view.animation.Animation.RELATIVE_TO_SELF,.5f);}else{a=new android.view.animation.AlphaAnimation(.62f,1f);}a.setDuration(d);a.setRepeatMode(android.view.animation.Animation.REVERSE);a.setRepeatCount(1);row.startAnimation(a);if(s.optBoolean("borderAnimation",false))row.animate().translationZ(dp(4)).setDuration(d/2).withEndAction(()->row.animate().translationZ(0).setDuration(d/2).start()).start();}}

    private void pinCommentText(String text){if(!canPinComments)return;AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle("📌 Comment options").setMessage(text).setPositiveButton("PIN",(d,w)->BackendClient.livePinnedMessage(token(),hostId,text,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,"Comment pinned",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}})).setNegativeButton("Cancel",null);if(pinnedView!=null&&pinnedView.getVisibility()==View.VISIBLE)b.setNeutralButton("UNPIN",(d,w)->unpinComment());b.show();}
    private void unpinComment(){if(!canPinComments)return;BackendClient.livePinnedMessage(token(),hostId,"",new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{pinnedView.setText("");pinnedView.setVisibility(View.GONE);Toast.makeText(AudioLiveRoomActivity.this,"Comment unpinned",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}});}

    private void editPinned(){EditText e=new EditText(this);e.setHint("Pinned announcement");new AlertDialog.Builder(this).setTitle("Pinned message").setView(e).setPositiveButton("Save",(d,w)->BackendClient.liveRoomConfig(token(),null,null,e.getText().toString().trim(),null,new ToastCb("Pinned message updated"))).setNegativeButton("Cancel",null).show();}
    private void editRoomInfo(){LinearLayout b=col();EditText t1=new EditText(this);t1.setHint("Live Name");t1.setText(currentLiveName);EditText t2=new EditText(this);t2.setHint("Caption");t2.setText(roomTopic.getText());b.addView(t1);b.addView(t2);TextView note=t("Live Name যেকোনো সময় পরিবর্তন করা যাবে • ID পরিবর্তন হবে না।",10,Color.DKGRAY,false);b.addView(note);new AlertDialog.Builder(this).setTitle("Live Name & Caption").setView(b).setPositiveButton("Save",(d,w)->BackendClient.liveRoomConfig(token(),t1.getText().toString(),t2.getText().toString(),null,null,new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,"Live info updated",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String e){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_LONG).show());}})).setNegativeButton("Cancel",null).show();}
    private void editCaptionOnly(){final EditText e=new EditText(this);e.setHint("Caption");e.setSingleLine(true);e.setText(roomTopic.getText());new AlertDialog.Builder(this).setTitle("Edit Caption").setView(e).setPositiveButton("Save",(d,w)->BackendClient.liveRoomConfig(token(),null,e.getText().toString(),null,null,new ToastCb("Caption updated"))).setNegativeButton("Cancel",null).show();}

    private void chooseTheme(){BackendClient.liveThemes(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("themes");if(a==null||a.length()==0){Toast.makeText(AudioLiveRoomActivity.this,"No enabled themes",Toast.LENGTH_SHORT).show();return;}String[] names=new String[a.length()];String[] keys=new String[a.length()];for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);names[i]=x==null?"Theme":x.optString("name","Theme");keys[i]=x==null?"GUITAR_BLUE":x.optString("theme_key","GUITAR_BLUE");}new AlertDialog.Builder(AudioLiveRoomActivity.this).setTitle("Live Theme").setItems(names,(q,which)->BackendClient.liveRoomConfig(token(),null,null,null,keys[which],new ToastCb("Theme changed"))).show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}

    private void shareRoom(){BackendClient.liveShare(token(),hostId,new Silent()); Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,"Join my MY SHOP Audio Live • Host ID "+hostId);startActivity(Intent.createChooser(send,"Share Live"));}

    private void openLiveInbox(){
        Intent i=new Intent(this,InboxActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);startActivity(i);
    }

    private void showReaction(){
        // V-390: reactions are visual overlays only. Never insert a heart into commentsList.
        ViewGroup content=findViewById(android.R.id.content);if(content==null)return;
        final TextView r=t("❤️",30,Color.WHITE,true);r.setGravity(Gravity.CENTER);r.setAlpha(.18f);r.setScaleX(.72f);r.setScaleY(.72f);
        FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(dp(54),dp(54),Gravity.RIGHT|Gravity.BOTTOM);rp.rightMargin=dp(62);rp.bottomMargin=dp(128);content.addView(r,rp);
        r.animate().alpha(1f).scaleX(1.12f).scaleY(1.12f).translationY(-dp(38)).setDuration(280).withEndAction(()->
            r.animate().alpha(0f).scaleX(.92f).scaleY(.92f).translationY(-dp(96)).setDuration(700).withEndAction(()->{try{content.removeView(r);}catch(Exception ignored){}}).start()
        ).start();
    }

    private void showUserModeration(JSONObject u){
        String uid=u.optString("user_id",u.optString("userId",""));if(uid.isEmpty()||uid.equals(hostId))return;
        final boolean canInvite=canSuggestCall||host||roomAdmin||SessionManager.isAdmin(this)||SessionManager.isModerator(this);
        final boolean canKick=host||SessionManager.isAdmin(this)||SessionManager.isModerator(this);
        final boolean canBlock=host||SessionManager.isAdmin(this);
        final boolean canRoomAdmin=host;
        java.util.ArrayList<String> actions=new java.util.ArrayList<>();
        if(canInvite)actions.add("📞 Call / Invite to Seat");
        actions.add("🎁 Send Gift");
        actions.add("Open Profile");
        JSONObject seat=findUser(currentSeats,uid);boolean currentlyMuted=u.optInt("muted",0)==1||(seat!=null&&seat.optInt("muted",0)==1);
        if(canInvite){if(currentlyMuted)actions.add("🎙 Unmute");else if(seat!=null)actions.add("🔇 Mute");}
        if(canKick)actions.add("Kick from Live");
        if(canBlock)actions.add("Block from this Live");
        if(canRoomAdmin){actions.add("Add as Room Admin");actions.add("Remove Room Admin");}
        actions.add("⚑ Report / Block Account");
        String name=u.optString("full_name","User");
        String info="ID "+uid+"  •  🏅LV."+u.optInt("level",0)+"\n🪙 Coin  "+compact(u.optLong("coin_balance",0))+"   •   🟡 Gold  "+compact(u.optLong("gold_balance",0));
        new AlertDialog.Builder(this).setTitle(name).setMessage(info).setItems(actions.toArray(new String[0]),(d,w)->{
            String a=actions.get(w);
            if(a.equals("Open Profile")){openUserProfile(u);return;}
            if(a.startsWith("🎁")){giftReceiverId=uid;giftReceiverName=name;showGiftPanel();return;}
            if(a.startsWith("📞")){inviteToCall(u);return;}
            if(a.startsWith("🎙")){BackendClient.liveModeration(token(),hostId,uid,"UNMUTE",new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,"Mute cleared • speaking restored",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}});return;}
            if(a.startsWith("🔇")){BackendClient.liveModeration(token(),hostId,uid,"MUTE",new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,"Audio muted • comments and call invites stay available",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}});return;}
            if(a.equals("Kick from Live")){BackendClient.liveModeration(token(),hostId,uid,"KICK",new ToastCb("User kicked out"));return;}
            if(a.equals("Block from this Live")){BackendClient.liveModeration(token(),hostId,uid,"BLOCK",new ToastCb("User blocked from Live"));return;}
            if(a.equals("Add as Room Admin")){BackendClient.liveModeration(token(),hostId,uid,"ADD_ROOM_ADMIN",new ToastCb("Room Admin added"));return;}
            if(a.equals("Remove Room Admin")){BackendClient.liveModeration(token(),hostId,uid,"REMOVE_ROOM_ADMIN",new ToastCb("Room Admin removed"));return;}
            SafetyActions.show(this,uid,"LIVE_USER",hostId);
        }).setNegativeButton("Close",null).show();
    }

    private void prefetchGiftCatalog(){
        if(giftCatalogFetchInFlight)return;giftCatalogFetchInFlight=true;
        BackendClient.liveGifts(token(),new BackendClient.Callback(){public void onSuccess(JSONObject o){cachedGiftCatalog=o;cachedGiftCatalogAt=System.currentTimeMillis();giftCatalogFetchInFlight=false;}public void onError(String m){giftCatalogFetchInFlight=false;}});
    }

    private void showGiftPanel(){
        if(giftReceiverId.isEmpty()||giftReceiverId.equals(SessionManager.getUserId(this))){giftReceiverId="";giftReceiverName="";if(!hostId.equals(SessionManager.getUserId(this))){giftReceiverId=hostId;giftReceiverName="Host";}else{for(int si=2;si<=11;si++){JSONObject su=findSeat(currentSeats,si);if(su!=null&&!su.optString("user_id","").equals(SessionManager.getUserId(this))){giftReceiverId=su.optString("user_id","");giftReceiverName=su.optString("full_name","User");break;}}}if(giftReceiverId.isEmpty()){Toast.makeText(this,"No eligible gift recipient",Toast.LENGTH_SHORT).show();return;}}
        long age=System.currentTimeMillis()-cachedGiftCatalogAt;
        if(cachedGiftCatalog!=null&&age<10000L){openGiftChart(cachedGiftCatalog);prefetchGiftCatalog();return;}
        if(giftLoadingDialog!=null&&giftLoadingDialog.isShowing())return;
        LinearLayout loading=col();loading.setPadding(dp(18),dp(14),dp(18),dp(14));loading.setBackground(bg(Color.rgb(13,14,38),Color.rgb(112,71,225),20));
        TextView title=t("🎁  LIVE GIFT STORE",16,Color.WHITE,true);loading.addView(title,new LinearLayout.LayoutParams(-1,dp(34)));
        TextView msg=t("Syncing current Admin prices & gift settings…",11.5f,Color.rgb(205,207,239),false);loading.addView(msg,new LinearLayout.LayoutParams(-1,dp(38)));
        giftLoadingDialog=new AlertDialog.Builder(this).setView(loading).setNegativeButton("Close",null).create();giftLoadingDialog.show();
        BackendClient.liveGifts(token(),new BackendClient.Callback(){
            public void onSuccess(JSONObject o){runOnUiThread(()->{cachedGiftCatalog=o;cachedGiftCatalogAt=System.currentTimeMillis();if(giftLoadingDialog!=null&&giftLoadingDialog.isShowing())giftLoadingDialog.dismiss();giftLoadingDialog=null;if(!isFinishing())openGiftChart(o);});}
            public void onError(String m){runOnUiThread(()->{if(giftLoadingDialog!=null&&giftLoadingDialog.isShowing())giftLoadingDialog.dismiss();giftLoadingDialog=null;Toast.makeText(AudioLiveRoomActivity.this,"Could not sync current gift prices. "+m,Toast.LENGTH_LONG).show();});}
        });
    }
    private void openGiftChart(JSONObject o){
        if(giftStoreDialog!=null&&giftStoreDialog.isShowing())giftStoreDialog.dismiss();
        final JSONArray gifts=o.optJSONArray("gifts")==null?new JSONArray():o.optJSONArray("gifts");
        LinearLayout box=col();box.setPadding(dp(10),dp(8),dp(10),dp(10));box.setBackground(gradient(new int[]{Color.rgb(10,12,34),Color.rgb(31,20,71),Color.rgb(16,18,52)},Color.rgb(121,78,236),22));
        LinearLayout giftHead=row();giftHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=t("🎁  SEND A GIFT",17,Color.WHITE,true);title.setGravity(Gravity.CENTER);giftHead.addView(title,new LinearLayout.LayoutParams(0,dp(40),1));
        TextView closeGift=t("✕",17,Color.rgb(235,229,255),true);closeGift.setGravity(Gravity.CENTER);closeGift.setBackground(bg(Color.argb(120,79,57,145),Color.argb(180,150,119,240),17));giftHead.addView(closeGift,new LinearLayout.LayoutParams(dp(38),dp(38)));
        box.addView(giftHead,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView sub=t("Tap a gift once → press Send",10,Color.rgb(207,207,239),false);sub.setGravity(Gravity.CENTER);box.addView(sub,new LinearLayout.LayoutParams(-1,dp(21)));
        TextView balance=t("🪙 Coin  "+o.optLong("coinBalance",0)+"      👑 Gold Coin  "+o.optLong("goldBalance",0),12,Color.WHITE,true);balance.setGravity(Gravity.CENTER);balance.setBackground(bg(Color.argb(130,58,44,130),Color.argb(190,135,92,235),14));box.addView(balance,new LinearLayout.LayoutParams(-1,dp(42)));
        final TextView receiver=t("🎯 Sending to: "+(giftReceiverName.isEmpty()?giftReceiverId:giftReceiverName)+" • ID "+giftReceiverId,10.5f,Color.WHITE,true);receiver.setGravity(Gravity.CENTER);receiver.setPadding(dp(6),0,dp(6),0);receiver.setBackground(bg(Color.argb(150,15,65,83),Color.argb(200,70,220,255),12));receiver.setOnClickListener(v->{java.util.ArrayList<JSONObject> choices=new java.util.ArrayList<>();JSONObject hu=findSeat(currentSeats,1);if(hu!=null&&!hostId.equals(SessionManager.getUserId(this)))choices.add(hu);for(int si=2;si<=11;si++){JSONObject su=findSeat(currentSeats,si);if(su!=null&&!su.optString("user_id","").equals(SessionManager.getUserId(this)))choices.add(su);}if(choices.isEmpty()){Toast.makeText(this,"No eligible gift recipient",Toast.LENGTH_SHORT).show();return;}String[] labels=new String[choices.size()];for(int k=0;k<choices.size();k++){JSONObject cu=choices.get(k);labels[k]=cu.optString("full_name","User")+" • ID "+cu.optString("user_id","");}new AlertDialog.Builder(this).setTitle("Send Gift To").setItems(labels,(dd,which)->{JSONObject cu=choices.get(which);giftReceiverId=cu.optString("user_id",hostId);giftReceiverName=cu.optString("full_name","User");receiver.setText("🎯 Sending to: "+giftReceiverName+" • ID "+giftReceiverId);}).setNegativeButton("Cancel",null).show();});box.addView(receiver,new LinearLayout.LayoutParams(-1,dp(40)));

        LinearLayout tabs=row();Button coin=small("🪙 Gift Coin"),gold=small("👑 Gold Coin");coin.setBackground(bg(Color.rgb(93,53,202),Color.rgb(176,101,255),16));gold.setBackground(bg(Color.rgb(135,89,30),Color.rgb(245,179,60),16));tabs.addView(coin,new LinearLayout.LayoutParams(0,dp(44),1));tabs.addView(gold,new LinearLayout.LayoutParams(0,dp(44),1));box.addView(tabs);

        HorizontalScrollView sc=new HorizontalScrollView(this);sc.setHorizontalScrollBarEnabled(false);sc.setFillViewport(false);final GridLayout grid=new GridLayout(this);grid.setRowCount(2);grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);grid.setPadding(dp(3),dp(7),dp(3),dp(7));sc.addView(grid,new HorizontalScrollView.LayoutParams(-2,-1));box.addView(sc,new LinearLayout.LayoutParams(-1,dp(226)));
        TextView swipeHint=t("←  Swipe left / right for more gifts  →",9.3f,Color.rgb(191,194,231),false);swipeHint.setGravity(Gravity.CENTER);box.addView(swipeHint,new LinearLayout.LayoutParams(-1,dp(24)));
        final Map<ImageView,JSONObject> catalogAnimConfigs=new LinkedHashMap<>();
        final Map<ImageView,TextView> catalogSparkles=new LinkedHashMap<>();

        LinearLayout selectedBar=row();selectedBar.setPadding(dp(10),dp(6),dp(10),dp(6));selectedBar.setBackground(bg(Color.argb(200,30,27,78),Color.rgb(109,79,210),16));
        final TextView selectedText=t("Select a gift",11.5f,Color.WHITE,true);selectedText.setGravity(Gravity.CENTER_VERTICAL);selectedBar.addView(selectedText,new LinearLayout.LayoutParams(0,dp(52),1));
        final Button sendButton=small("SEND");sendButton.setEnabled(false);sendButton.setAlpha(.48f);sendButton.setTextSize(12);sendButton.setBackground(gradient(new int[]{Color.rgb(238,63,153),Color.rgb(116,75,239)},Color.rgb(255,180,225),18));selectedBar.addView(sendButton,new LinearLayout.LayoutParams(dp(104),dp(48)));box.addView(selectedBar,new LinearLayout.LayoutParams(-1,dp(60)));

        final String[] currency={"COIN"};final JSONObject[] chosen={null};final View[] chosenTile={null};
        final Runnable[] renderHolder=new Runnable[1];
        renderHolder[0]=()->{
            for(ImageView oldArt:catalogAnimConfigs.keySet())CatalogGiftAnimator.stop(oldArt,catalogSparkles.get(oldArt));
            catalogAnimConfigs.clear();catalogSparkles.clear();grid.removeAllViews();chosen[0]=null;chosenTile[0]=null;sendButton.setEnabled(false);sendButton.setAlpha(.48f);sendButton.setText("SEND");selectedText.setText("Select a gift");
            boolean isCoin="COIN".equals(currency[0]);coin.setAlpha(isCoin?1f:.55f);gold.setAlpha(isCoin ? .55f : 1f);
            int count=0;
            for(int i=0;i<gifts.length();i++){
                final JSONObject g=gifts.optJSONObject(i);if(g==null||!currency[0].equals(g.optString("currency")))continue;count++;
                final LinearLayout tile=col();tile.setGravity(Gravity.CENTER);tile.setPadding(dp(5),dp(5),dp(5),dp(5));tile.setBackground(giftTileBg(false,"GOLD".equals(currency[0])));tile.setElevation(dp(1));
                FrameLayout iconBox=new FrameLayout(this);iconBox.setClipChildren(false);tile.setClipChildren(false);ImageView icon=new ImageView(this);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                String catalogAsset=g.optString("catalog_animation_url","").trim();String preview=g.optString("preview_url","").trim();if(preview.isEmpty())preview=g.optString("animation_url","").trim();
                if(!catalogAsset.isEmpty())AnimatedAssetLoader.load(icon,catalogAsset,false);else if(!preview.isEmpty())loadImage(icon,preview);else icon.setImageResource(builtInGiftArt(g.optString("name","Gift")));
                int previewDp=CatalogGiftAnimator.iconDp(g);FrameLayout.LayoutParams iconLp=new FrameLayout.LayoutParams(dp(previewDp),dp(previewDp),Gravity.CENTER);iconBox.addView(icon,iconLp);
                TextView sparkle=t("✦   ✧",12,Color.rgb(255,226,118),true);sparkle.setGravity(Gravity.CENTER);sparkle.setAlpha(.12f);iconBox.addView(sparkle,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));tile.addView(iconBox,new LinearLayout.LayoutParams(-1,dp(54)));
                catalogAnimConfigs.put(icon,g);catalogSparkles.put(icon,sparkle);
                TextView nm=t(g.optString("name","Gift"),9.6f,Color.WHITE,true);nm.setGravity(Gravity.CENTER);nm.setMaxLines(1);tile.addView(nm,new LinearLayout.LayoutParams(-1,dp(22)));
                TextView pr=t(("GOLD".equals(currency[0])?"👑 ":"🪙 ")+g.optInt("price",1),10.0f,Color.rgb(255,219,91),true);pr.setGravity(Gravity.CENTER);tile.addView(pr,new LinearLayout.LayoutParams(-1,dp(21)));
                tile.setOnClickListener(v->{
                    if(chosenTile[0]!=null)chosenTile[0].setBackground(giftTileBg(false,"GOLD".equals(currency[0])));
                    chosen[0]=g;chosenTile[0]=tile;tile.setBackground(giftTileBg(true,"GOLD".equals(currency[0])));tile.animate().scaleX(1.045f).scaleY(1.045f).setDuration(100).withEndAction(()->tile.animate().scaleX(1f).scaleY(1f).setDuration(100).start()).start();
                    selectedText.setText("✓ "+g.optString("name","Gift")+"  •  "+("GOLD".equals(currency[0])?"👑 ":"🪙 ")+g.optInt("price",1));sendButton.setEnabled(true);sendButton.setAlpha(1f);sendButton.setText("SEND");
                });
                int slot=count-1;GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=dp(94);gp.height=dp(102);gp.rowSpec=GridLayout.spec(slot%2);gp.columnSpec=GridLayout.spec(slot/2);gp.setMargins(dp(3),dp(3),dp(3),dp(3));grid.addView(tile,gp);
            }
            if(count==0){TextView empty=t("No published gifts in this catalog.",11,Color.rgb(200,202,229),false);empty.setGravity(Gravity.CENTER);grid.addView(empty,new GridLayout.LayoutParams(GridLayout.spec(0),GridLayout.spec(0,3)));}
            sc.post(()->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles));
            sc.postDelayed(()->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles),650L);
        };
        sc.setOnScrollChangeListener((v,sx,sy,ox,oy)->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles));
        coin.setOnClickListener(v->{currency[0]="COIN";renderHolder[0].run();});gold.setOnClickListener(v->{currency[0]="GOLD";renderHolder[0].run();});
        sendButton.setOnClickListener(v->{
            final JSONObject gift=chosen[0];if(gift==null)return;sendButton.setEnabled(false);sendButton.setText("SENDING…");
            final long giftId=gift.optLong("id");final String nonce="gift-"+SessionManager.getUserId(this)+"-"+UUID.randomUUID();
            final String receiverId=giftReceiverId; final JSONObject localGift=gift; if(giftStoreDialog!=null&&giftStoreDialog.isShowing())giftStoreDialog.dismiss(); giftStoreDialog=null; showGiftEffect(localGift,new JSONObject()); BackendClient.liveGiftSend(token(),hostId,receiverId,giftId,nonce,new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->{
                    long sentEventId=d.optLong("eventId",0);JSONObject serverGift=d.optJSONObject("gift");final JSONObject effectGift=serverGift==null?gift:serverGift;
                    JSONObject localGiftEvent=new JSONObject();try{
                        localGiftEvent.put("id",sentEventId).put("sender_id",SessionManager.getUserId(AudioLiveRoomActivity.this)).put("sender_name",d.optString("senderName",SessionManager.getFullName(AudioLiveRoomActivity.this))).put("sender_avatar",d.optString("senderAvatar",SessionManager.getAvatarUrl(AudioLiveRoomActivity.this))).put("sender_level",d.optInt("senderLevel",myLevel)).put("receiver_id",d.optString("receiverId",hostId)).put("receiver_name",currentLiveName).put("name",effectGift.optString("name","Gift")).put("currency",effectGift.optString("currency","COIN")).put("price",effectGift.optInt("price",d.optInt("grossAmount",1))).put("combo",Math.max(1,d.optInt("combo",1))).put("preview_url",effectGift.optString("preview_url","")).put("animation_url",effectGift.optString("animation_url",""));
                    }catch(Exception ignored){}
                    renderGiftActivityComment(localGiftEvent);
                    if(sentEventId>0){renderedGiftEventIds.add(sentEventId);lastGiftEventId=Math.max(lastGiftEventId,sentEventId);}
                    if(giftStoreDialog!=null&&giftStoreDialog.isShowing())giftStoreDialog.dismiss();giftStoreDialog=null;cachedGiftCatalog=null;cachedGiftCatalogAt=0L;
                    prefetchGiftCatalog();
                });}
                public void onError(String m){runOnUiThread(()->{sendButton.setEnabled(true);sendButton.setAlpha(1f);sendButton.setText("SEND");Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show();});}
            });
        });
        renderHolder[0].run();
        giftStoreDialog=new AlertDialog.Builder(this).setView(box).create();
        closeGift.setOnClickListener(v->{if(giftStoreDialog!=null&&giftStoreDialog.isShowing())giftStoreDialog.dismiss();});
        giftStoreDialog.setOnDismissListener(d->{for(ImageView art:catalogAnimConfigs.keySet())CatalogGiftAnimator.stop(art,catalogSparkles.get(art));catalogAnimConfigs.clear();catalogSparkles.clear();giftStoreDialog=null;});
        giftStoreDialog.setOnShowListener(d->{android.view.Window w=giftStoreDialog.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.72f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.94f),-2);}});
        giftStoreDialog.show();
        sc.postDelayed(()->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles),150L);
        sc.postDelayed(()->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles),1300L);
        sc.postDelayed(()->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles),3200L);
    }

    private void updateCatalogPreviewAnimations(View sc,Map<ImageView,JSONObject> configs,Map<ImageView,TextView> sparkles){
        if(sc==null||configs==null)return;Rect scrollRect=new Rect();boolean scrollVisible=sc.getGlobalVisibleRect(scrollRect);
        for(Map.Entry<ImageView,JSONObject> e:configs.entrySet()){
            ImageView art=e.getKey();if(art==null)continue;Rect artRect=new Rect();boolean visible=scrollVisible&&art.getGlobalVisibleRect(artRect)&&Rect.intersects(scrollRect,artRect);
            if(visible)CatalogGiftAnimator.start(art,sparkles.get(art),e.getValue());else CatalogGiftAnimator.stop(art,sparkles.get(art));
        }
    }

    private android.graphics.drawable.GradientDrawable giftTileBg(boolean selected,boolean gold){
        int[] colors=gold?new int[]{Color.rgb(58,39,76),Color.rgb(95,59,45)}:new int[]{Color.rgb(31,29,78),Color.rgb(63,38,110)};
        int stroke=selected?(gold?Color.rgb(255,213,89):Color.rgb(255,102,214)):(gold?Color.rgb(181,132,65):Color.rgb(101,83,191));
        return gradient(colors,stroke,16);
    }

    private void renderLocalSkeleton(){renderHost(null);renderAudience(null,0);renderSpecialGuest(null);renderSeats(null);}

    private void refresh(){if(roomEnded||endLiveInProgress||refreshInFlight)return;refreshInFlight=true;BackendClient.liveRoomState(token(),hostId,new BackendClient.Callback(){@Override public void onSuccess(JSONObject d){runOnUiThread(()->{refreshInFlight=false;if(roomEnded||endLiveInProgress)return;syncState.setText("● LIVE • "+rtcDiagnosticStatus+" • "+networkQuality());render(d);});}@Override public void onError(String m){runOnUiThread(()->{refreshInFlight=false;if(roomEnded)return;if(endLiveInProgress){syncState.setText("Ending live…");return;}if(!host && m!=null && m.contains("LIVE_NOT_ACTIVE")){handler.removeCallbacks(tick);handler.removeCallbacks(realtimeTick);handler.removeCallbacks(presenceTick);handler.removeCallbacks(participantTick);showAudienceEndSummary();return;}syncState.setText("● LIVE • Weak network • Reconnecting…");if(seats.getChildCount()==0)renderLocalSkeleton();});}});}

    private void render(JSONObject d){
        int vc=d.optInt("viewerCount",0),peak=d.optInt("peakViewers",0); currentViewerCount=vc; currentPeakViewers=peak; currentTotalListeners=d.optInt("totalListeners",0); viewers.setText("");
        String previousRtcRole=myRole; myRole=d.optString("myRole",host?"HOST":"AUDIENCE"); if(!myRole.equals(previousRtcRole))requestRtcToken(false); myLevel=Math.max(0,d.optInt("myLevel",myLevel)); roomAdmin=d.optBoolean("myRoomAdmin",false); canSuggestCall=d.optBoolean("canSuggestCall",host||roomAdmin||SessionManager.isAdmin(this)||SessionManager.isModerator(this)); canPinComments=d.optBoolean("canPinComments",host||roomAdmin)||SessionManager.isAdmin(this)||SessionManager.isModerator(this); String sanction=d.optString("mySanction","NONE"); listenOnly="MUTED".equals(sanction); if("BLOCKED".equals(sanction)||"KICKED".equals(sanction)){Toast.makeText(this,"You were removed from this live",Toast.LENGTH_SHORT).show();finish();return;} updateVoiceMonitor(); updateLiveStatusLine(); updateLocalMicUi();
        specialGuestId=d.optString("specialGuestId",""); shareCount=d.optInt("shareCount",0); shareView.setText("↗ "+shareCount);
        currentLiveName=d.optString("title","Host"); roomTitle.setText("🎙 "+currentLiveName); String cap=d.optString("topic","").trim(); roomTopic.setText(cap.isEmpty()?"Add caption":cap); reactCount=d.optLong("reactCount",0); voteCount=d.optLong("voteCount",0); if(reactView!=null)reactView.setText("❤️\n"+compact(reactCount));
        String pin=d.optString("pinnedMessage","").trim(); if(pin.isEmpty()){pinnedView.setText("");pinnedView.setVisibility(View.GONE);}else{pinnedView.setText("📌  "+pin+"    • long-press to unpin");pinnedView.setVisibility(View.VISIBLE);}
        String sid=d.optString("sessionId","");long elapsed=Math.max(0,d.optLong("elapsedSeconds",0));long parsed=parseServerTime(d.optString("startedAt",""));
        if(!sid.equals(activeSessionId)){activeSessionId=sid;serverElapsedSec=elapsed;serverElapsedSyncMs=System.currentTimeMillis();startedAtMs=parsed;pendingComments.clear();shownMilestones.clear();lastEntryEventId=0L;lastGiftEventId=0L;lastRealtimeCommentId=0L;lastRealtimeHighlightId=0L;realtimeRevision=0;realtimeFailures=0;renderedGiftEventIds.clear();renderedCommentIds.clear();renderedRoomEventIds.clear();renderedHighlightCommentIds.clear();shownPremiumEntrances.clear();commentsList.removeAllViews();giftPollInFlight=false;}else{serverElapsedSec=elapsed;serverElapsedSyncMs=System.currentTimeMillis();if(parsed>0)startedAtMs=parsed;}
        renderPremiumState(d);
        lockedSeats.clear();JSONArray locks=d.optJSONArray("lockedSeats");if(locks!=null)for(int i=0;i<locks.length();i++)lockedSeats.add(locks.optInt(i));
        currentHostStats=d.optJSONObject("hostStats"); if(currentHostStats==null)currentHostStats=new JSONObject(); currentTopSupporters=d.optJSONArray("topSupporters"); if(currentTopSupporters==null)currentTopSupporters=new JSONArray();
        JSONArray a=d.optJSONArray("seats"); currentSeats=a==null?new JSONArray():a; currentSeatNo=0; JSONObject meSeat=findUser(currentSeats,SessionManager.getUserId(this)); if(meSeat!=null){currentSeatNo=meSeat.optInt("seat_no",0);if(!host&&"SPEAKER".equals(myRole)){boolean serverMicOn=meSeat.optInt("mic_on",1)==1&&meSeat.optInt("muted",0)!=1;if(localMicOn!=serverMicOn){localMicOn=serverMicOn;if(!localMicOn)localSpeaking=false;if(rtcManager!=null)rtcManager.setMicEnabled(localMicOn&&!listenOnly);updateLocalMicUi();}}} updateSpeakerControls(); renderHost(findSeat(a,1));renderAudience(d.optJSONArray("viewerProfiles"),vc);renderSpecialGuest(findUser(a,specialGuestId));renderSeats(a);
        currentRequests=d.optJSONArray("requests")==null?new JSONArray():d.optJSONArray("requests");
        pendingRequestCount=Math.max(0,d.optInt("requestCount",currentRequests.length()));
        myRequestStatus=d.optString("myRequestStatus","NONE");
        if(host&&requests!=null){renderRequests(currentRequests);notifyHostOfNewRequest(currentRequests);}
        updateSpeakerControls();
        JSONArray highlights=d.optJSONArray("highlightComments");JSONArray giftEvents=d.optJSONArray("giftEvents");renderComments(d.optJSONArray("comments"),d.optJSONArray("events"),highlights);renderGiftActivityEventsOnly(giftEvents);renderHighlightComments(highlights);renderGiftEffectsOnly(giftEvents);
        if(!host)showIncomingInvite(d.optJSONObject("incomingInvite"));
        JSONObject theme=d.optJSONObject("theme"); if(theme!=null){String mode=theme.optString("fit_mode","CENTER_CROP");if("FIT".equalsIgnoreCase(mode))wallpaper.setScaleType(ImageView.ScaleType.FIT_CENTER);else if("FILL".equalsIgnoreCase(mode))wallpaper.setScaleType(ImageView.ScaleType.FIT_XY);else wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);String bg=theme.optString("background_url",""),themeKey=theme.optString("theme_key","");if(!bg.trim().isEmpty())loadImage(wallpaper,bg);else if(themeKey.toUpperCase(Locale.US).startsWith("WALLPAPER_"))wallpaper.setImageDrawable(new PremiumWallpaperDrawable(themeKey+"|"+theme.optString("name","MY SHOP")));else wallpaper.setImageResource(R.drawable.live_room_default_wallpaper);}
    }

    private void renderHost(JSONObject x){
        hostArea.removeAllViews();
        LinearLayout top=row(); top.setGravity(Gravity.CENTER_VERTICAL);
        JSONObject hostDisplay=x;
        if(hostDisplay==null&&host){hostDisplay=new JSONObject();try{hostDisplay.put("user_id",SessionManager.getUserId(this));hostDisplay.put("full_name",SessionManager.getFullName(this));hostDisplay.put("avatar_url",SessionManager.getAvatarUrl(this));hostDisplay.put("mic_on",localMicOn?1:0);}catch(Exception ignored){}}
        boolean speaking=hostDisplay!=null&&hostDisplay.optInt("speaking",0)==1;speaking=speaking||isRtcSpeaking(hostDisplay,true);
        FrameLayout av=avatarWithMicState(hostDisplay,dp(58),speaking);top.addView(av,new LinearLayout.LayoutParams(dp(58),dp(58)));
        String id=hostDisplay==null?hostId:hostDisplay.optString("user_id",hostId);
        String liveName=currentLiveName==null||currentLiveName.trim().isEmpty()?(hostDisplay==null?"Host":hostDisplay.optString("full_name","Host")):currentLiveName;
        String hostName=hostDisplay==null?currentLiveName:hostDisplay.optString("full_name",currentLiveName);
        if(hostName==null||hostName.trim().isEmpty())hostName=SessionManager.getFullName(this);
        if(hostName==null||hostName.trim().isEmpty())hostName="MY SHOP User";
        LinearLayout hostIdentity=col();hostIdentity.setPadding(dp(7),0,dp(3),0);
        TextView hostNameView=t(hostName,11.8f,Color.WHITE,true);hostNameView.setSingleLine(true);hostNameView.setEllipsize(android.text.TextUtils.TruncateAt.END);hostIdentity.addView(hostNameView,new LinearLayout.LayoutParams(-1,dp(27)));
        LinearLayout idLine=row();idLine.setGravity(Gravity.CENTER_VERTICAL);TextView idView=t("ID "+id,10.8f,Color.rgb(231,235,255),true);idLine.addView(idView,new LinearLayout.LayoutParams(-2,dp(27)));
        if(!SessionManager.getUserId(this).equals(id)){TextView followPlus=t("+",14.8f,Color.WHITE,true);followPlus.setGravity(Gravity.CENTER);followPlus.setContentDescription("Follow host");followPlus.setBackground(gradient(new int[]{Color.rgb(124,44,244),Color.rgb(39,132,255),Color.rgb(18,214,228)},Color.rgb(149,236,255),12));followPlus.setElevation(dp(4));followPlus.setOnClickListener(v->{followPlus.setEnabled(false);BackendClient.toggleFollow(token(),id,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{followPlus.setText("✓");followPlus.setEnabled(true);Toast.makeText(AudioLiveRoomActivity.this,"Follow updated",Toast.LENGTH_SHORT).show();});}public void onError(String m){runOnUiThread(()->{followPlus.setEnabled(true);Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show();});}});});LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(dp(28),dp(24));fp.leftMargin=dp(6);idLine.addView(followPlus,fp);}
        hostIdentity.addView(idLine,new LinearLayout.LayoutParams(-1,dp(29)));
        View.OnClickListener hostSummaryClick=v->showRunningLiveSummary();av.setClickable(true);av.setFocusable(true);av.setOnClickListener(hostSummaryClick);PremiumUi.press(av);hostIdentity.setClickable(true);hostIdentity.setFocusable(true);hostIdentity.setOnClickListener(hostSummaryClick);PremiumUi.press(hostIdentity);
        top.addView(hostIdentity,new LinearLayout.LayoutParams(dp(130),dp(60)));
        if(audienceScroll.getParent()!=null)((android.view.ViewGroup)audienceScroll.getParent()).removeView(audienceScroll);top.addView(audienceScroll,new LinearLayout.LayoutParams(0,dp(60),1));
        onlineCountView=t("✕",22f,Color.WHITE,true);onlineCountView.setGravity(Gravity.CENTER);onlineCountView.setBackgroundColor(Color.TRANSPARENT);onlineCountView.setOnClickListener(v->{if(host)endHostLive();else confirmLeaveLive();});top.addView(onlineCountView,new LinearLayout.LayoutParams(dp(36),dp(36)));
        hostArea.addView(top,new LinearLayout.LayoutParams(-1,dp(68)));
        long coin=currentHostStats.optLong("coinBalance",x==null?0:x.optLong("coin_balance",0)),gold=currentHostStats.optLong("goldBalance",x==null?0:x.optLong("gold_balance",0));
        LinearLayout stats=row();stats.setGravity(Gravity.CENTER_VERTICAL);stats.setPadding(0,0,0,0);
        String[] sv={"👁 "+compact(currentViewerCount+1),"🪙 "+compact(coin),"🟡 "+compact(gold),"Vote "+compact(voteCount),"❤️ "+compact(reactCount)};
        for(String value:sv){TextView item=t(value,12.3f,Color.WHITE,true);item.setGravity(Gravity.CENTER);item.setSingleLine(true);item.setBackgroundColor(Color.TRANSPARENT);stats.addView(item,new LinearLayout.LayoutParams(0,dp(34),1));}
        hostArea.addView(stats,new LinearLayout.LayoutParams(-1,dp(36)));
    }

    private LinearLayout.LayoutParams statLp(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(45),1);p.setMargins(dp(1),0,dp(1),0);return p;}
    private TextView statPill(String label,String value,int accent){TextView v=t(label+"\n"+value,10.8f,Color.WHITE,true);v.setGravity(Gravity.CENTER);v.setBackgroundColor(Color.TRANSPARENT);return v;}

    private void renderAudience(JSONArray a,int total){
        currentViewerProfiles=a==null?new JSONArray():a; currentViewerCount=total; audienceRow.removeAllViews(); audienceRow.setPadding(dp(2),0,dp(2),0);
        for(int i=0;i<currentViewerProfiles.length();i++){
            JSONObject u=currentViewerProfiles.optJSONObject(i); if(u==null)continue;
            String viewerTier=u.optString("tier","STANDARD");
            FrameLayout av=circleAvatar(u.optString("avatar_url",""),dp(46),false,viewerTier,MembershipUi.isTier(viewerTier)?u.optString("membership_frame_url",""):u.optString("frame_url",""));
            String premiumUid=u.optString("user_id",u.optString("userId",""));if(!"STANDARD".equalsIgnoreCase(viewerTier)&&!premiumUid.isEmpty()&&shownPremiumEntrances.add(premiumUid))showFloatingBanner("✨ "+viewerTier+" • "+shortName(u.optString("full_name","User"))+" joined");
            av.setClickable(true);av.setFocusable(true);PremiumUi.press(av);
            final String viewerUid=u.optString("user_id",u.optString("userId",""));
            final boolean audienceCallAllowed=!viewerUid.isEmpty()&&!viewerUid.equals(hostId)&&(host||roomAdmin||canSuggestCall||SessionManager.isAdmin(this)||SessionManager.isModerator(this));
            av.setOnClickListener(v->{if(audienceCallAllowed)showViewerCallCard(u);else showMiniProfile(u);});
            if(audienceCallAllowed){TextView callBadge=t("☎",8.5f,Color.WHITE,true);callBadge.setGravity(Gravity.CENTER);callBadge.setBackground(gradient(new int[]{Color.rgb(24,178,255),Color.rgb(111,45,244)},Color.rgb(178,244,255),10));callBadge.setElevation(dp(6));callBadge.setContentDescription("Invite viewer to call");callBadge.setOnClickListener(v->inviteToCall(u));FrameLayout.LayoutParams cbp=new FrameLayout.LayoutParams(dp(20),dp(20),Gravity.RIGHT|Gravity.BOTTOM);cbp.rightMargin=-dp(1);cbp.bottomMargin=-dp(1);av.addView(callBadge,cbp);}
            LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(50),dp(50));ap.rightMargin=dp(4);audienceRow.addView(av,ap);
        }
        if(currentViewerProfiles.length()==0){TextView empty=t("",1,Color.TRANSPARENT,false);audienceRow.addView(empty,new LinearLayout.LayoutParams(dp(4),dp(50)));}
    }

    private void showGiftSummary(){
        LinearLayout wrap=col();wrap.setPadding(dp(8),dp(4),dp(8),dp(6));
        TextView note=t("Current Live session • Top 20 supporters",10,Color.rgb(183,196,232),false);note.setGravity(Gravity.CENTER);wrap.addView(note,new LinearLayout.LayoutParams(-1,dp(32)));
        ScrollView scroll=new ScrollView(this);LinearLayout rows=col();scroll.addView(rows,new ScrollView.LayoutParams(-1,-2));
        int n=currentTopSupporters==null?0:Math.min(20,currentTopSupporters.length());
        if(n==0){TextView empty=t("No gifts in this Live yet",12,Color.rgb(190,200,225),true);empty.setGravity(Gravity.CENTER);rows.addView(empty,new LinearLayout.LayoutParams(-1,dp(100)));}
        for(int i=0;i<n;i++){
            JSONObject x=currentTopSupporters.optJSONObject(i);if(x==null)continue;final int rank=i+1;final String uid=x.optString("sender_id","");
            LinearLayout r=row();r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(7),dp(6),dp(7),dp(6));r.setBackground(bg(rank<=3?Color.argb(235,55,38,84):Color.argb(225,15,29,72),rank==1?Color.rgb(255,208,72):rank==2?Color.rgb(199,211,231):rank==3?Color.rgb(222,151,91):Color.rgb(68,91,160),13));
            TextView rr=t(rank==1?"🥇":rank==2?"🥈":rank==3?"🥉":"#"+rank,11,rank<=3?Color.rgb(255,224,145):Color.WHITE,true);rr.setGravity(Gravity.CENTER);r.addView(rr,new LinearLayout.LayoutParams(dp(42),dp(46)));
            FrameLayout av=circleAvatar(x.optString("avatar_url",""),dp(42),false);r.addView(av,new LinearLayout.LayoutParams(dp(42),dp(42)));
            LinearLayout meta=col();meta.setPadding(dp(8),0,dp(3),0);TextView nm=t(x.optString("full_name","Supporter")+"  •  ID "+uid,10,Color.WHITE,true);nm.setSingleLine(true);meta.addView(nm,new LinearLayout.LayoutParams(-1,dp(22)));long gifts=x.optLong("gift_count",0),coins=x.optLong("coin_value",0),gold=x.optLong("gold_value",0);TextView vals=t("🎁 "+gifts+"   •   🪙 "+compact(coins)+" Coin   •   🟡 "+compact(gold)+" Gold",8.6f,Color.rgb(219,226,255),false);vals.setSingleLine(true);meta.addView(vals,new LinearLayout.LayoutParams(-1,dp(21)));r.addView(meta,new LinearLayout.LayoutParams(0,dp(46),1));
            if(!uid.isEmpty()){r.setOnClickListener(v->{Intent q=new Intent(this,UserProfileActivity.class);q.putExtra("userId",uid);startActivity(q);});PremiumUi.press(r);}LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(58));rp.bottomMargin=dp(5);rows.addView(r,rp);
        }
        wrap.addView(scroll,new LinearLayout.LayoutParams(-1,dp(430)));
        new AlertDialog.Builder(this).setTitle("🎁 Live Gift Summary • Top 20").setView(wrap).setNeutralButton("Host Profile",(d,w)->{Intent q=new Intent(this,UserProfileActivity.class);q.putExtra("userId",hostId);startActivity(q);}).setPositiveButton("Close",null).show();
    }

    private void showRunningLiveSummary(){
        long elapsed=!activeSessionId.isEmpty()?Math.max(0,serverElapsedSec+(System.currentTimeMillis()-serverElapsedSyncMs)/1000L):0;
        long coin=0,gold=0,count=0;if(currentTopSupporters!=null)for(int i=0;i<currentTopSupporters.length();i++){JSONObject g=currentTopSupporters.optJSONObject(i);if(g!=null){coin+=g.optLong("coin_value",0);gold+=g.optLong("gold_value",0);count+=g.optLong("gift_count",0);}}
        JSONObject x=new JSONObject();try{x.put("duration_seconds",elapsed).put("peak_viewers",currentPeakViewers).put("total_listeners",currentTotalListeners).put("react_count",reactCount).put("totalCoinGift",coin).put("totalGoldGift",gold).put("giftCount",count).put("topSupporters",currentTopSupporters);}catch(Exception ignored){}
        showPremiumSummaryDialog(x,false);
    }

    private String compact(long n){if(n>=1000000)return (n%1000000==0?(n/1000000)+"M":String.format(Locale.US,"%.1fM",n/1000000f));if(n>=1000)return (n%1000==0?(n/1000)+"K":String.format(Locale.US,"%.1fK",n/1000f));return String.valueOf(n);}

    private String shortName(String n){ if(n==null||n.trim().isEmpty())return "User"; n=n.trim(); int sp=n.indexOf(' '); if(sp>0)n=n.substring(0,sp); return n.length()>7?n.substring(0,7):n; }

    private void showViewerCallCard(JSONObject u){
        if(u==null)return;
        String uid=u.optString("user_id",u.optString("userId",""));if(uid.isEmpty()||uid.equals(hostId)){showMiniProfile(u);return;}
        String name=u.optString("full_name",u.optString("name","User"));
        LinearLayout box=col();box.setPadding(dp(16),dp(14),dp(16),dp(14));box.setBackground(gradient(new int[]{Color.rgb(12,27,73),Color.rgb(48,30,108)},Color.rgb(94,222,255),22));
        LinearLayout top=row();top.setGravity(Gravity.CENTER_VERTICAL);FrameLayout av=circleAvatar(u.optString("avatar_url",""),dp(52),false,u.optString("tier","STANDARD"));top.addView(av,new LinearLayout.LayoutParams(dp(52),dp(52)));
        LinearLayout meta=col();meta.setPadding(dp(10),0,0,0);TextView nm=t(name,12.4f,Color.WHITE,true);nm.setSingleLine(true);meta.addView(nm,new LinearLayout.LayoutParams(-1,dp(27)));TextView sub=t("ID "+uid+"  •  LV."+u.optInt("level",0)+"  •  Viewer",9.2f,Color.rgb(203,229,255),false);sub.setSingleLine(true);meta.addView(sub,new LinearLayout.LayoutParams(-1,dp(23)));top.addView(meta,new LinearLayout.LayoutParams(0,dp(52),1));box.addView(top,new LinearLayout.LayoutParams(-1,dp(56)));
        TextView hint=t("Invite this viewer to join the live speaker seat.",9.4f,Color.rgb(211,220,246),false);hint.setGravity(Gravity.CENTER);box.addView(hint,new LinearLayout.LayoutParams(-1,dp(34)));
        LinearLayout actions=row();Button call=small("☎  INVITE TO CALL");call.setTextSize(9.4f);call.setTextColor(Color.WHITE);call.setBackground(gradient(new int[]{Color.rgb(17,172,255),Color.rgb(111,47,244)},Color.rgb(175,244,255),18));call.setElevation(dp(6));Button profile=small("PROFILE");profile.setTextSize(9.0f);profile.setTextColor(Color.WHITE);profile.setBackground(gradient(new int[]{Color.rgb(50,66,116),Color.rgb(82,52,139)},Color.rgb(145,164,230),18));profile.setElevation(dp(4));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(46),1.35f);cp.rightMargin=dp(8);actions.addView(call,cp);actions.addView(profile,new LinearLayout.LayoutParams(0,dp(46),.65f));box.addView(actions,new LinearLayout.LayoutParams(-1,dp(50)));
        final AlertDialog dlg=new AlertDialog.Builder(this).setView(box).create();call.setOnClickListener(v->{dlg.dismiss();inviteToCall(u);});profile.setOnClickListener(v->{dlg.dismiss();openUserProfile(u);});dlg.setOnShowListener(d->{android.view.Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.65f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);}});dlg.show();
    }

    private void showAudienceList(){
        int n=currentViewerProfiles==null?0:currentViewerProfiles.length();
        if(n==0){Toast.makeText(this,"No active users right now",Toast.LENGTH_SHORT).show();return;}
        String[] items=new String[n]; for(int i=0;i<n;i++){JSONObject u=currentViewerProfiles.optJSONObject(i); items[i]=u==null?"User":u.optString("full_name","User")+"  •  ID "+u.optString("user_id",u.optString("userId",""))+"  •  🏅LV."+u.optInt("level",0);}
        new AlertDialog.Builder(this).setTitle("Active Users • "+currentViewerCount).setItems(items,(d,w)->{JSONObject u=currentViewerProfiles.optJSONObject(w);if(u==null)return;if(canSuggestCall||host||roomAdmin||SessionManager.isAdmin(this)||SessionManager.isModerator(this))showUserModeration(u);else showMiniProfile(u);}).setNegativeButton("Close",null).show();
    }

    private void inviteToCall(JSONObject u){
        if(u==null)return;
        boolean allowed=canSuggestCall||host||roomAdmin||SessionManager.isAdmin(this)||SessionManager.isModerator(this);
        if(!allowed){Toast.makeText(this,"You do not have Call Suggest permission",Toast.LENGTH_SHORT).show();return;}
        String uid=u.optString("user_id",u.optString("userId","")).trim();if(uid.isEmpty()||uid.equals(hostId))return;
        BackendClient.liveInvite(token(),hostId,uid,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{String nm=u.optString("full_name","User");showFloatingBanner("📞 Call sent • waiting for "+shortName(nm));Toast.makeText(AudioLiveRoomActivity.this,"Call invitation sent to "+nm,Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->{showFloatingBanner("⚠ Call failed • "+String.valueOf(m));Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show();});}});
    }

    private void showIncomingInvite(JSONObject inv){
        if(inv==null||host||inviteDialogOpen)return;
        String key=inv.optString("host_id",hostId)+"|"+inv.optString("session_id","")+"|"+inv.optString("created_at","");
        if(key.equals(lastInviteNotice))return;
        lastInviteNotice=key;inviteDialogOpen=true;
        String hostName=inv.optString("host_name","Host");
        LinearLayout box=col();box.setPadding(dp(18),dp(16),dp(18),dp(16));box.setBackground(gradient(new int[]{Color.rgb(13,24,69),Color.rgb(47,28,102)},Color.rgb(104,211,255),22));
        TextView title=t("📞  LIVE CALL INVITATION",16.5f,Color.WHITE,true);title.setGravity(Gravity.CENTER);box.addView(title,new LinearLayout.LayoutParams(-1,dp(38)));
        TextView msg=t(hostName+" আপনাকে Live Call-এ speaker হিসেবে আমন্ত্রণ জানিয়েছে।",11.2f,Color.rgb(218,228,255),false);msg.setGravity(Gravity.CENTER);msg.setPadding(dp(8),dp(4),dp(8),dp(8));box.addView(msg,new LinearLayout.LayoutParams(-1,dp(58)));
        LinearLayout actions=row();actions.setGravity(Gravity.CENTER);
        Button accept=small("✓  ACCEPT");accept.setTextSize(10.2f);accept.setTextColor(Color.WHITE);accept.setBackground(gradient(new int[]{Color.rgb(12,139,102),Color.rgb(30,211,145)},Color.rgb(151,255,218),18));accept.setElevation(dp(5));
        Button reject=small("✕  REJECT");reject.setTextSize(10.2f);reject.setTextColor(Color.WHITE);reject.setBackground(gradient(new int[]{Color.rgb(133,29,74),Color.rgb(225,54,100)},Color.rgb(255,145,177),18));reject.setElevation(dp(5));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(48),1);ap.rightMargin=dp(8);actions.addView(accept,ap);actions.addView(reject,new LinearLayout.LayoutParams(0,dp(48),1));box.addView(actions,new LinearLayout.LayoutParams(-1,dp(52)));
        final AlertDialog dlg=new AlertDialog.Builder(this).setView(box).create();
        accept.setOnClickListener(v->{accept.setEnabled(false);reject.setEnabled(false);handleInviteAction(true,dlg);});
        reject.setOnClickListener(v->{accept.setEnabled(false);reject.setEnabled(false);handleInviteAction(false,dlg);});
        dlg.setOnCancelListener(d->inviteDialogOpen=false);dlg.setOnDismissListener(d->inviteDialogOpen=false);dlg.setOnShowListener(d->{android.view.Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.72f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);}});dlg.show();
    }

    private void handleInviteAction(boolean accept,AlertDialog dlg){
        performInviteAction(accept,dlg,false);
    }

    private void performInviteAction(boolean accept,AlertDialog dlg,boolean retried){
        BackendClient.liveInviteAction(token(),hostId,accept,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                if(dlg!=null&&dlg.isShowing())dlg.dismiss();inviteDialogOpen=false;
                if(accept){
                    myRole="SPEAKER";currentSeatNo=d.optInt("seatNo",currentSeatNo);localMicOn=true;
                    requestRtcToken(true);updateSpeakerControls();updateLocalMicUi();
                    showFloatingBanner("✓ Call accepted • joining speaker seat");
                    Toast.makeText(AudioLiveRoomActivity.this,"Call accepted • joining speaker seat",Toast.LENGTH_SHORT).show();
                    refresh();handler.postDelayed(()->refresh(),350L);handler.postDelayed(()->refresh(),950L);handler.postDelayed(()->refresh(),1700L);
                }else{Toast.makeText(AudioLiveRoomActivity.this,"Invitation rejected",Toast.LENGTH_SHORT).show();refresh();}
            });}
            public void onError(String m){runOnUiThread(()->{
                String err=String.valueOf(m);
                // The audience heartbeat may be a few seconds late on weak networks. Re-assert
                // viewer presence once, then retry the same pending invite instead of forcing the user to tap again.
                if(accept&&!retried&&(err.contains("NOT_IN_LIVE")||err.contains("INVITE_NOT_PENDING")||err.contains("LIVE_SESSION_NOT_READY"))){
                    BackendClient.liveViewer(token(),hostId,true,new BackendClient.Callback(){
                        public void onSuccess(JSONObject x){performInviteAction(true,dlg,true);}
                        public void onError(String e){inviteDialogOpen=false;if(dlg!=null&&dlg.isShowing())dlg.dismiss();Toast.makeText(AudioLiveRoomActivity.this,err,Toast.LENGTH_LONG).show();refresh();}
                    });
                    return;
                }
                inviteDialogOpen=false;if(dlg!=null&&dlg.isShowing())dlg.dismiss();Toast.makeText(AudioLiveRoomActivity.this,err,Toast.LENGTH_LONG).show();refresh();
            });}
        });
    }

    private void notifyHostOfNewRequest(JSONArray q){
        if(!host||requestNoticeBar==null)return;
        if(q==null||q.length()==0){requestNoticeBar.setVisibility(View.GONE);requestNoticeBar.removeAllViews();return;}
        JSONObject x=q.optJSONObject(0);if(x==null)return;
        String uid=x.optString("user_id","");String nm=x.optString("full_name","User");String key=uid+"|"+x.optString("created_at","");
        requestNoticeBar.removeAllViews();
        requestNoticeBar.setPadding(dp(8),dp(5),dp(7),dp(5));
        requestNoticeBar.setBackground(gradient(new int[]{Color.argb(248,18,27,72),Color.argb(248,70,39,139),Color.argb(248,27,86,164)},Color.rgb(99,225,255),18));
        requestNoticeBar.setElevation(dp(5));
        FrameLayout av=circleAvatar(x.optString("avatar_url",""),dp(42),false,x.optString("tier","STANDARD"));
        TextView live=t("CALL",6.8f,Color.WHITE,true);live.setGravity(Gravity.CENTER);live.setBackground(bg(Color.rgb(238,57,108),Color.rgb(255,128,169),8));FrameLayout.LayoutParams lb=new FrameLayout.LayoutParams(dp(29),dp(15),Gravity.RIGHT|Gravity.BOTTOM);lb.rightMargin=-dp(2);lb.bottomMargin=-dp(1);av.addView(live,lb);
        LinearLayout.LayoutParams avp=new LinearLayout.LayoutParams(dp(42),dp(42));avp.rightMargin=dp(8);requestNoticeBar.addView(av,avp);
        LinearLayout meta=col();
        TextView who=t("✋ JOIN REQUEST  •  "+shortName(nm)+(q.length()>1?"  +"+(q.length()-1):""),10.6f,Color.WHITE,true);who.setSingleLine(true);who.setEllipsize(android.text.TextUtils.TruncateAt.END);meta.addView(who,new LinearLayout.LayoutParams(-1,dp(21)));
        TextView sub=t("ID "+uid+"  •  LV."+x.optInt("level",0)+"  •  wants a speaker seat",8.5f,Color.rgb(205,232,255),false);sub.setSingleLine(true);meta.addView(sub,new LinearLayout.LayoutParams(-1,dp(18)));
        requestNoticeBar.addView(meta,new LinearLayout.LayoutParams(0,dp(42),1));
        Button ok=small("✓ ACCEPT");ok.setTextSize(7.9f);ok.setTextColor(Color.WHITE);ok.setBackground(gradient(new int[]{Color.rgb(10,137,102),Color.rgb(30,213,146)},Color.rgb(146,255,216),15));ok.setElevation(dp(4));
        Button no=small("✕ REJECT");no.setTextSize(7.9f);no.setTextColor(Color.WHITE);no.setBackground(gradient(new int[]{Color.rgb(128,28,70),Color.rgb(221,49,96)},Color.rgb(255,137,171),15));no.setElevation(dp(4));
        ok.setOnClickListener(v->handleJoinRequestAction(uid,true,ok,no));no.setOnClickListener(v->handleJoinRequestAction(uid,false,ok,no));
        LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(dp(68),dp(38));op.rightMargin=dp(5);requestNoticeBar.addView(ok,op);requestNoticeBar.addView(no,new LinearLayout.LayoutParams(dp(68),dp(38)));
        requestNoticeBar.setVisibility(View.VISIBLE);
        if(!key.equals(lastRequestNotice)){lastRequestNotice=key;requestNoticeBar.setAlpha(.25f);requestNoticeBar.setScaleX(.98f);requestNoticeBar.setScaleY(.98f);requestNoticeBar.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(190).start();}
    }

    private void handleJoinRequestAction(String uid,boolean accept,Button yes,Button no){
        if(yes!=null)yes.setEnabled(false);if(no!=null)no.setEnabled(false);
        BackendClient.liveRequestAction(token(),uid,accept,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,accept?"Speaker accepted • call connected":"Request rejected",Toast.LENGTH_SHORT).show();refresh();handler.postDelayed(()->refresh(),350L);});}
            public void onError(String m){runOnUiThread(()->{if(yes!=null)yes.setEnabled(true);if(no!=null)no.setEnabled(true);Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show();refresh();});}
        });
    }

    private void showJoinRequestsDialog(){
        if(!host)return;if(currentRequests==null||currentRequests.length()==0){Toast.makeText(this,"No pending join requests",Toast.LENGTH_SHORT).show();return;}
        int n=currentRequests.length();String[] items=new String[n];for(int i=0;i<n;i++){JSONObject x=currentRequests.optJSONObject(i);items[i]=x==null?"User":x.optString("full_name","User")+" • ID "+x.optString("user_id","");}
        new AlertDialog.Builder(this).setTitle("Join Requests • "+n).setItems(items,(d,w)->{JSONObject x=currentRequests.optJSONObject(w);if(x==null)return;String uid=x.optString("user_id","");new AlertDialog.Builder(this).setTitle(items[w]).setItems(new String[]{"Accept to Call","Decline"},(dd,which)->BackendClient.liveRequestAction(token(),uid,which==0,new BackendClient.Callback(){public void onSuccess(JSONObject z){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,which==0?"Speaker accepted • call connected":"Request rejected",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String e){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_LONG).show());}})).show();}).setNegativeButton("Close",null).show();
    }

    private void renderSpecialGuest(JSONObject x){
        specialArea.removeAllViews();
        FrameLayout stage=new FrameLayout(this);
        long elapsed=!activeSessionId.isEmpty()?Math.max(0,serverElapsedSec+(System.currentTimeMillis()-serverElapsedSyncMs)/1000L):0;
        durationView=t(hhmmss(elapsed),11.6f,Color.WHITE,true); durationView.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); durationView.setBackgroundColor(Color.TRANSPARENT); if(host){durationView.setClickable(true);PremiumUi.press(durationView);durationView.setOnClickListener(v->showRunningLiveSummary());}
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(dp(88),dp(28),Gravity.LEFT|Gravity.TOP); tp.leftMargin=dp(3); tp.topMargin=dp(5); stage.addView(durationView,tp);

        boolean speaking=x!=null&&x.optInt("speaking",0)==1;speaking=speaking||isRtcSpeaking(x,false);
        FrameLayout guestFrame=new FrameLayout(this); GoldenGuestHalo halo=new GoldenGuestHalo(this); guestFrame.addView(halo,new FrameLayout.LayoutParams(-1,-1));
        if(x==null){
            ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.live_main_guest_logo);logo.setScaleType(ImageView.ScaleType.CENTER_CROP);logo.setClipToOutline(true);logo.setBackground(bg(Color.rgb(10,20,66),Color.rgb(255,193,58),44));
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(92),dp(92),Gravity.CENTER);guestFrame.addView(logo,lp);
        }else{
            FrameLayout av=avatarWithMicState(x,dp(92),speaking); FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(dp(92),dp(92),Gravity.CENTER); guestFrame.addView(av,ap);
        }
        
        ObjectAnimator pulseX=ObjectAnimator.ofFloat(halo,"scaleX",1f,1.045f,1f); pulseX.setDuration(1650); pulseX.setRepeatCount(ValueAnimator.INFINITE); pulseX.start();
        ObjectAnimator pulseY=ObjectAnimator.ofFloat(halo,"scaleY",1f,1.045f,1f); pulseY.setDuration(1650); pulseY.setRepeatCount(ValueAnimator.INFINITE); pulseY.start();
        ObjectAnimator glow=ObjectAnimator.ofFloat(halo,"alpha",.78f,1f,.78f); glow.setDuration(1400); glow.setRepeatCount(ValueAnimator.INFINITE); glow.start();
        FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(dp(142),dp(122),Gravity.CENTER); stage.addView(guestFrame,gp);
        specialArea.addView(stage,new LinearLayout.LayoutParams(-1,dp(124)));
        if(x!=null){guestFrame.setClickable(true);guestFrame.setFocusable(true);PremiumUi.press(guestFrame);guestFrame.setOnClickListener(v->{String uid=x.optString("user_id","");if(SessionManager.getUserId(this).equals(uid)&&"SPEAKER".equals(myRole))showSelfSpeakerMenu();else showSeatedUserActions(x);});}else guestFrame.setOnClickListener(null);
    }

    private void renderSeats(JSONArray a){
        seats.removeAllViews();
        // V-427 locked behavior: exactly 8 empty guest seats by default (4 + 4).
        // Extra seats 9/10... are rendered only after a real accepted speaker occupies them.
        int seatNo=2;
        for(int rr=0;rr<2;rr++){
            LinearLayout r=row();r.setGravity(Gravity.CENTER);
            for(int c=0;c<4;c++,seatNo++) addSeatToRow(r,a,seatNo,true);
            seats.addView(r,new LinearLayout.LayoutParams(-1,dp(62)));
        }
        LinearLayout extra=null;
        for(int n=10;n<=11;n++){
            JSONObject found=findSeat(a,n);
            if(found==null||hostId.equals(found.optString("user_id","")))continue;
            if(!specialGuestId.isEmpty()&&specialGuestId.equals(found.optString("user_id","")))continue;
            if(extra==null){extra=row();extra.setGravity(Gravity.CENTER);}
            addSeatToRow(extra,a,n,false);
        }
        if(extra!=null)seats.addView(extra,new LinearLayout.LayoutParams(-1,dp(62)));
    }

    private void addSeatToRow(LinearLayout r,JSONArray a,int n,boolean allowEmpty){
        JSONObject found=findSeat(a,n);
        if(found!=null&&hostId.equals(found.optString("user_id","")))found=null;
        boolean specialReserved=found!=null&&!specialGuestId.isEmpty()&&specialGuestId.equals(found.optString("user_id",""));
        if(specialReserved)found=null;
        if(found==null&&!allowEmpty)return;
        boolean locked=(n>1&&lockedSeats.contains(n))||specialReserved;
        LinearLayout tile=seatTile(n,found,locked); final int seatNo=n; final JSONObject clicked=found;
        tile.setOnClickListener(v->{
            if(clicked!=null){
                String clickedId=clicked.optString("user_id","");
                if(SessionManager.getUserId(this).equals(clickedId)&&"SPEAKER".equals(myRole)){showSelfSpeakerMenu();return;}
                showSeatedUserActions(clicked);return;
            }
            if(host){toggleSeatLock(seatNo,locked);return;}
            if("SPEAKER".equals(myRole)&&!locked){moveMySeat(seatNo);}
        });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(58),1);lp.setMargins(dp(4),dp(2),dp(4),dp(2));r.addView(tile,lp);
    }

    private LinearLayout seatTile(int seatNo,JSONObject x,boolean locked){
        LinearLayout v=col(); v.setGravity(Gravity.CENTER); v.setPadding(dp(1),dp(1),dp(1),dp(1)); v.setBackgroundColor(Color.TRANSPARENT);
        boolean occupied=x!=null,speaking=occupied&&x.optInt("speaking",0)==1;speaking=speaking||isRtcSpeaking(x,false);
        if(occupied){
            FrameLayout av=avatarWithMicState(x,dp(48),speaking); v.addView(av,new LinearLayout.LayoutParams(dp(48),dp(48)));
        }else{
            FrameLayout stage=new FrameLayout(this); stage.addView(sofaIcon(locked),new FrameLayout.LayoutParams(dp(50),dp(50),Gravity.CENTER)); v.addView(stage,new LinearLayout.LayoutParams(dp(52),dp(52)));
        }
        return v;
    }

    private View sofaIcon(boolean locked){
        FrameLayout f=new FrameLayout(this);f.setPadding(dp(2),dp(2),dp(2),dp(2));f.setElevation(dp(1));
        GradientDrawable seatBg=new GradientDrawable();
        seatBg.setShape(GradientDrawable.OVAL);
        seatBg.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        seatBg.setGradientCenter(.40f,.34f);
        seatBg.setGradientRadius(dp(58));
        seatBg.setColors(locked
                ?new int[]{Color.argb(210,70,67,73),Color.argb(185,43,42,53),Color.argb(155,24,26,39)}
                :new int[]{Color.argb(225,59,43,31),Color.argb(205,28,27,47),Color.argb(176,9,18,48)});
        seatBg.setStroke(dp(2.6f),locked?Color.argb(190,210,165,65):Color.rgb(255,200,67));
        f.setBackground(seatBg);f.setElevation(dp(3));
        ImageView chair=new ImageView(this);chair.setImageResource(R.drawable.live_guest_chair);chair.setScaleType(ImageView.ScaleType.CENTER_INSIDE);chair.setAlpha(.97f);
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(36),dp(36),Gravity.CENTER);f.addView(chair,cp);
        if(locked){TextView mark=t("🔒",8,Color.WHITE,true);mark.setGravity(Gravity.CENTER);mark.setBackground(bg(Color.argb(170,20,20,24),Color.argb(190,220,220,230),18));FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(20),dp(20),Gravity.RIGHT|Gravity.BOTTOM);f.addView(mark,mp);}
        return f;
    }

    private void toggleSeatLock(int seatNo,boolean locked){BackendClient.liveSeatLock(token(),seatNo,!locked,new ToastCb(!locked?"Seat locked":"Seat unlocked"));}


    private void renderHighlightComments(JSONArray arr){
        if(arr==null||arr.length()==0)return; JSONObject c=arr.optJSONObject(arr.length()-1); if(c==null)return; long hid=c.optLong("id",0); if(hid<=lastHighlightId)return; lastHighlightId=hid; final TextView banner=t("✨ "+c.optString("full_name","User")+": "+c.optString("message",""),11,Color.WHITE,true); banner.setPadding(dp(14),0,dp(14),0); banner.setGravity(Gravity.CENTER_VERTICAL); banner.setBackground(gradient(new int[]{Color.argb(235,76,34,145),Color.argb(235,184,54,156)},Color.rgb(255,209,92),18)); addContentView(banner,new android.view.ViewGroup.LayoutParams(dp(310),dp(42))); banner.setX(getResources().getDisplayMetrics().widthPixels); banner.setY(getResources().getDisplayMetrics().heightPixels*0.46f); banner.animate().translationX(-getResources().getDisplayMetrics().widthPixels-dp(340)).setDuration(6500).withEndAction(()->((android.view.ViewGroup)banner.getParent()).removeView(banner)).start();
    }

    private void renderRequests(JSONArray q){
        requests.removeAllViews();
        if(q==null||q.length()==0){requests.addView(t("No pending requests",11,Color.LTGRAY,false));return;}
        for(int i=0;i<q.length();i++){
            JSONObject x=q.optJSONObject(i);if(x==null)continue;
            LinearLayout rr=row();rr.setGravity(Gravity.CENTER_VERTICAL);
            String tier=x.optString("tier","STANDARD");long fan=x.optLong("fan_points",0);
            String badge="STANDARD".equals(tier)?"":(" • "+tier);
            TextView nm=t(x.optString("full_name","User")+badge+" • ID "+x.optString("user_id")+(fan>0?" • ⭐"+fan:""),10.5f,Color.WHITE,true);
            rr.addView(nm,new LinearLayout.LayoutParams(0,dp(36),1));
            Button ok=small("Accept"),no=small("Decline");String id=x.optString("user_id");
            ok.setOnClickListener(v->handleJoinRequestAction(id,true,ok,no));
            no.setOnClickListener(v->handleJoinRequestAction(id,false,ok,no));
            rr.addView(ok,new LinearLayout.LayoutParams(dp(72),dp(38)));rr.addView(no,new LinearLayout.LayoutParams(dp(74),dp(38)));requests.addView(rr);
        }
    }

    private void compactCommentRow(TextView row){if(row==null)return;row.setMaxLines(Integer.MAX_VALUE);row.setEllipsize(null);row.setMinHeight(0);row.setGravity(Gravity.CENTER_VERTICAL);}

    private int membershipAccent(String tier){
        if("KING".equalsIgnoreCase(tier))return Color.rgb(255,182,46);
        if("QUEEN".equalsIgnoreCase(tier))return Color.rgb(255,78,180);
        if("ROYAL".equalsIgnoreCase(tier))return Color.rgb(166,91,255);
        if("VVIP".equalsIgnoreCase(tier))return Color.rgb(52,205,255);
        if("VIP".equalsIgnoreCase(tier))return Color.rgb(83,224,126);
        return Color.rgb(153,132,255);
    }
    private String membershipIcon(String tier){if("KING".equalsIgnoreCase(tier))return "🦁";if("QUEEN".equalsIgnoreCase(tier))return "♛";if("ROYAL".equalsIgnoreCase(tier))return "✦";if("VVIP".equalsIgnoreCase(tier))return "◆";if("VIP".equalsIgnoreCase(tier))return "❖";return "";}
    private FrameLayout liveCommentAvatar(String url,String gender,String tier,int size){
        if(MembershipUi.isTier(tier)){FrameLayout frame=new FrameLayout(this);frame.addView(new MembershipIdentityView(this,tier,url),new FrameLayout.LayoutParams(size,size));return frame;}
        int stroke="STANDARD".equalsIgnoreCase(tier)?("FEMALE".equalsIgnoreCase(gender)?Color.rgb(255,83,190):"MALE".equalsIgnoreCase(gender)?Color.rgb(57,210,118):Color.rgb(153,132,255)):membershipAccent(tier);
        FrameLayout frame=new FrameLayout(this);frame.setBackground(bg(Color.argb(210,13,20,48),stroke,size/2));
        ImageView v=new ImageView(this);v.setImageResource(android.R.drawable.sym_def_app_icon);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setClipToOutline(true);v.setBackground(bg(Color.rgb(31,40,84),stroke,size/2));
        FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,-1);ip.setMargins(dp(2),dp(2),dp(2),dp(2));frame.addView(v,ip);if(url!=null&&!url.trim().isEmpty())loadImage(v,url);
        if(!"STANDARD".equalsIgnoreCase(tier)){TextView dot=t("",1,Color.TRANSPARENT,false);dot.setBackground(bg(Color.TRANSPARENT,stroke,size/2));FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(-1,-1);rp.setMargins(dp(1),dp(1),dp(1),dp(1));frame.addView(dot,rp);ObjectAnimator pulse=ObjectAnimator.ofFloat(dot,"alpha",.25f,1f,.25f);pulse.setDuration(1500);pulse.setRepeatCount(ValueAnimator.INFINITE);pulse.start();dot.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View v){}public void onViewDetachedFromWindow(View v){pulse.cancel();}});}
        return frame;
    }

    private LinearLayout buildUniversalCommentRow(JSONObject c,String name,String message,String gender){
        String tier=c==null?"STANDARD":c.optString("tier","STANDARD").toUpperCase();int accent=membershipAccent(tier);boolean premium=!"STANDARD".equals(tier);
        LinearLayout row=row();row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(5),dp(4),dp(6),dp(4));
        int bgc=premium?Color.argb(232,9,12,30):Color.argb(205,7,12,31);row.setBackground(bg(bgc,premium?accent:Color.TRANSPARENT,13));
        String avatar=c==null?"":c.optString("avatar_url",c.optString("sender_avatar",""));FrameLayout av=liveCommentAvatar(avatar,gender,tier,dp(40));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(40),dp(40));ap.leftMargin=-dp(2);row.addView(av,ap);
        LinearLayout textBox=col();textBox.setPadding(dp(8),0,dp(5),0);String displayName=(name==null||name.trim().isEmpty()?"User":name.trim());int level=c==null?0:c.optInt("level",0);
        TextView top=t(displayName+(level>0?"   LV."+level:""),Math.max(12.5f,liveCommentFontSize-.8f),premium?accent:Color.WHITE,true);top.setSingleLine(true);textBox.addView(top,new LinearLayout.LayoutParams(-1,-2));
        TextView body=t(message==null?"":message,Math.max(13.0f,liveCommentFontSize),Color.WHITE,false);body.setLineSpacing(0,1.02f);compactCommentRow(body);textBox.addView(body,new LinearLayout.LayoutParams(-1,-2));row.addView(textBox,new LinearLayout.LayoutParams(0,-2,1));
        String customComment=c==null?"":c.optString("comment_style_url","");if(!customComment.isEmpty()){ImageView styleMark=new ImageView(this);styleMark.setScaleType(ImageView.ScaleType.CENTER_INSIDE);styleMark.setContentDescription("Applied premium comment style");AnimatedAssetLoader.load(styleMark,customComment,true);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(30),dp(36));sp.rightMargin=dp(4);row.addView(styleMark,sp);}
        if(premium){View divider=new View(this);divider.setBackgroundColor(Color.argb(150,Color.red(accent),Color.green(accent),Color.blue(accent)));LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(dp(1),dp(31));dl.rightMargin=dp(6);row.addView(divider,dl);LinearLayout badge=col();badge.setGravity(Gravity.CENTER);TextView ic=t(membershipIcon(tier),16,accent,true);ic.setGravity(Gravity.CENTER);badge.addView(ic,new LinearLayout.LayoutParams(dp(48),dp(22)));TextView nm=t(tier,7.8f,accent,true);nm.setGravity(Gravity.CENTER);badge.addView(nm,new LinearLayout.LayoutParams(dp(48),dp(15)));row.addView(badge,new LinearLayout.LayoutParams(dp(50),dp(40)));}
        if(c!=null){final JSONObject profile=c;row.setClickable(true);row.setFocusable(true);PremiumUi.press(row);row.setOnClickListener(v->openUserProfile(profile));}return row;
    }

    private void renderComments(JSONArray comments,JSONArray events,JSONArray highlights){
        if(commentsList==null)return;
        final int before=commentsList.getChildCount();
        if(events!=null){int start=Math.max(0,events.length()-8);for(int i=start;i<events.length();i++){JSONObject e=events.optJSONObject(i);if(e==null)continue;String eventType=e.optString("event_type","");if("GIFT".equalsIgnoreCase(eventType)||"REACT".equalsIgnoreCase(eventType)||"REACTION".equalsIgnoreCase(eventType)||"LOVE_REACT".equalsIgnoreCase(eventType))continue;long id=e.optLong("id",0);if(id>0&&!renderedRoomEventIds.add(id))continue;if("SPEAKER_JOIN".equalsIgnoreCase(eventType))showFloatingBanner("🎙 "+e.optString("full_name","User")+" joined the call");TextView n=t("• "+e.optString("full_name","Someone")+" "+e.optString("message",""),11.0f,Color.rgb(205,222,255),true);n.setPadding(dp(7),dp(3),dp(7),dp(3));n.setBackground(bg(Color.argb(118,13,30,70),Color.TRANSPARENT,10));LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,-2);ep.bottomMargin=dp(3);commentsList.addView(n,ep);}}
        if(highlights!=null){for(int i=0;i<highlights.length();i++){JSONObject h=highlights.optJSONObject(i);if(h==null)continue;long id=h.optLong("id",0);if(id>0&&!renderedHighlightCommentIds.add(id))continue;LinearLayout hi=buildUniversalCommentRow(h,"✨ "+h.optString("full_name","User"),h.optString("message",""),h.optString("gender","UNSPECIFIED"));hi.setBackground(softGradient(new int[]{Color.argb(220,76,34,145),Color.argb(220,184,54,156)},13));LinearLayout.LayoutParams hlp=new LinearLayout.LayoutParams(-1,-2);hlp.bottomMargin=dp(3);commentsList.addView(hi,hlp);}}
        if(comments!=null){for(int i=0;i<comments.length();i++){
            JSONObject c=comments.optJSONObject(i);if(c==null)continue;long id=c.optLong("id",0);if(id>0&&!renderedCommentIds.add(id))continue;
            String nonce=c.optString("client_nonce","");if(!nonce.isEmpty()){pendingComments.remove(nonce);removePendingCommentView(nonce);}
            String name=c.optString("full_name","User"),message=c.optString("message",""),gender=c.optString("gender","UNSPECIFIED");
            LinearLayout row=buildUniversalCommentRow(c,name,message,gender);if(canPinComments){final String pinText=name+" : "+message;row.setOnLongClickListener(v->{pinCommentText(pinText);return true;});}
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(3);commentsList.addView(row,rp);
        }}
        // Keep the approved comment area clean when there are no comments; do not insert placeholder text.
        trimCommentRows();
        if(commentScroll!=null&&commentsList.getChildCount()>before)commentScroll.post(()->commentScroll.fullScroll(View.FOCUS_DOWN));
    }
    private void removePendingCommentView(String nonce){if(commentsList==null)return;String tag="pending:"+nonce;for(int i=commentsList.getChildCount()-1;i>=0;i--){View v=commentsList.getChildAt(i);if(tag.equals(String.valueOf(v.getTag())))commentsList.removeViewAt(i);}}
    private void trimCommentRows(){if(commentsList==null)return;for(int i=commentsList.getChildCount()-1;i>=0;i--){View v=commentsList.getChildAt(i);if("comments-empty".equals(String.valueOf(v.getTag()))&&commentsList.getChildCount()>1)commentsList.removeViewAt(i);}while(commentsList.getChildCount()>100)commentsList.removeViewAt(0);}




    private void sendLiveComment(EditText input,TextView highlight){
        final String m=input.getText().toString().trim();if(m.isEmpty()||commentSending)return;
        commentSending=true;if(sendButton!=null){sendButton.setEnabled(false);sendButton.setText("Sending…");}
        final boolean hi=highlightSelected;final String nonce="c-"+SessionManager.getUserId(this)+"-"+UUID.randomUUID().toString();
        input.setText("");highlightSelected=false;highlight.setBackground(null);
        if(!hi){pendingComments.put(nonce,m);renderPendingOnly(nonce,m);}
        BackendClient.Callback cb=new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                commentSending=false;if(sendButton!=null){sendButton.setEnabled(true);sendButton.setText("Send");}
                JSONObject ack=d.optJSONObject("comment");
                if(!hi && ack!=null) renderAcknowledgedComment(ack,nonce);
                else if(!roomEnded&&!endLiveInProgress) refresh();
            });}
            public void onError(String e){runOnUiThread(()->{
                pendingComments.remove(nonce);removePendingCommentView(nonce);commentSending=false;
                if(sendButton!=null){sendButton.setEnabled(true);sendButton.setText("Send");}
                Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_SHORT).show();
                if(!roomEnded&&!endLiveInProgress)refresh();
            });}
        };
        if(hi)BackendClient.liveHighlightComment(token(),hostId,m,cb);else BackendClient.liveComment(token(),hostId,m,nonce,cb);
    }
    private void renderAcknowledgedComment(JSONObject c,String nonce){
        if(commentsList==null||c==null)return;
        long id=c.optLong("id",0);if(id>0&&!renderedCommentIds.add(id)){pendingComments.remove(nonce);removePendingCommentView(nonce);return;}
        pendingComments.remove(nonce);removePendingCommentView(nonce);
        String name=c.optString("full_name",SessionManager.getFullName(this)),message=c.optString("message",""),gender=c.optString("gender","UNSPECIFIED");
        LinearLayout row=buildUniversalCommentRow(c,name,message,gender);if(canPinComments){final String pinText=name+" : "+message;row.setOnLongClickListener(v->{pinCommentText(pinText);return true;});}
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(3);commentsList.addView(row,rp);trimCommentRows();if(commentScroll!=null)commentScroll.post(()->commentScroll.smoothScrollTo(0,commentsList.getBottom()));
    }

    private String currentUserGender(){
        String me=SessionManager.getUserId(this);
        JSONObject x=findUser(currentSeats,me);if(x!=null&&!x.optString("gender","").isEmpty())return x.optString("gender","UNSPECIFIED");
        x=findUser(currentViewerProfiles,me);if(x!=null&&!x.optString("gender","").isEmpty())return x.optString("gender","UNSPECIFIED");
        return "UNSPECIFIED";
    }
    private void renderPendingOnly(String nonce,String message){
        if(commentsList==null)return;JSONObject self=new JSONObject();String selfGender=currentUserGender();try{self.put("user_id",SessionManager.getUserId(this));self.put("full_name",SessionManager.getFullName(this));self.put("avatar_url",SessionManager.getAvatarUrl(this));self.put("gender",selfGender);}catch(Exception ignored){}
        LinearLayout pr=buildUniversalCommentRow(self,SessionManager.getFullName(this),message,selfGender);pr.setTag("pending:"+nonce);pr.setAlpha(.84f);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(3);commentsList.addView(pr,rp);if(commentScroll!=null)commentScroll.post(()->commentScroll.smoothScrollTo(0,commentsList.getBottom()));
    }
    private void renderEntryEffects(JSONArray a){
        if(a==null||a.length()==0)return;
        JSONObject x=a.optJSONObject(a.length()-1);if(x==null)return;
        long id=x.optLong("id",0);if(id<=lastEntryEventId)return;lastEntryEventId=id;
        String tier=x.optString("tier","STANDARD"),asset=x.optString("animation_url",""),mime=x.optString("animation_mime",""),code=x.optString("item_code","");
        if(!asset.isEmpty()||!code.isEmpty()){
            final LinearLayout stage=col();stage.setGravity(Gravity.CENTER);stage.setPadding(dp(4),dp(2),dp(4),dp(2));stage.setBackgroundColor(Color.TRANSPARENT);
            final VideoView[] video={null};
            String assetPath=asset.toLowerCase(Locale.US).split("\\?",2)[0];final boolean videoAsset=!asset.isEmpty()&&(mime.toLowerCase(Locale.US).startsWith("video/")||assetPath.endsWith(".mp4")||assetPath.endsWith(".webm")||assetPath.endsWith(".3gp"));
            if(videoAsset){
                VideoView vv=new VideoView(this);video[0]=vv;vv.setVideoURI(android.net.Uri.parse(asset));vv.setOnPreparedListener(mp->{mp.setLooping(false);float vol=x.optString("sound_url","").trim().isEmpty()?Math.max(0,Math.min(100,x.optInt("sound_volume",90)))/100f:0f;mp.setVolume(vol,vol);vv.start();String sound=x.optString("sound_url","");if(!sound.isEmpty())playEntrySound(sound,x.optInt("sound_volume",90),x.optInt("sound_duration_ms",3000));});stage.addView(vv,new LinearLayout.LayoutParams(dp(300),dp(158)));
            }else if(!asset.isEmpty()){
                ImageView art=new ImageView(this);art.setScaleType(ImageView.ScaleType.CENTER_INSIDE);AnimatedAssetLoader.load(art,asset,true);stage.addView(art,new LinearLayout.LayoutParams(dp(300),dp(158)));
            }else{
                TextView art=t(entryAnimationIcon(code),88,Color.WHITE,true);art.setGravity(Gravity.CENTER);art.setShadowLayer(dp(14),0,0,membershipAccent(tier));stage.addView(art,new LinearLayout.LayoutParams(dp(300),dp(158)));
            }
            TextView who=t(x.optString("full_name","Member")+(code.isEmpty()?"":" • "+code.replace("ENTRY_","").replace('_',' ')),11.5f,Color.WHITE,true);who.setGravity(Gravity.CENTER);who.setBackground(gradient(new int[]{Color.argb(225,12,16,43),Color.argb(225,55,30,102)},membershipAccent(tier),14));stage.addView(who,new LinearLayout.LayoutParams(dp(270),dp(34)));
            addContentView(stage,new ViewGroup.LayoutParams(dp(320),dp(210)));float width=getResources().getDisplayMetrics().widthPixels;stage.setX(-dp(330));stage.setY(dp(145));stage.setScaleX(.82f);stage.setScaleY(.82f);stage.setAlpha(.02f);
            int speed=Math.max(1,Math.min(100,x.optInt("animation_speed",55)));long travel=Math.max(1200,2500-(speed*10L));int total=Math.max(1200,Math.min(15000,x.optInt("effect_duration_ms",3500)));
            stage.animate().x(width+dp(15)).alpha(1f).scaleX(1f).scaleY(1f).setDuration(travel).setInterpolator(new android.view.animation.LinearInterpolator()).withEndAction(()->handler.postDelayed(()->stage.animate().alpha(0f).setDuration(220).withEndAction(()->{try{if(video[0]!=null)video[0].stopPlayback();}catch(Exception ignored){}if(stage.getParent()!=null)((ViewGroup)stage.getParent()).removeView(stage);}).start(),Math.max(0,total-(int)travel))).start();
            String sound=x.optString("sound_url","");if(!videoAsset&&!sound.isEmpty())playEntrySound(sound,x.optInt("sound_volume",90),x.optInt("sound_duration_ms",3000));return;
        }
        if(!"STANDARD".equals(tier))showFloatingBanner(membershipIcon(tier)+" "+tier+" ENTRY • "+x.optString("full_name","Member"));
    }
    private String entryAnimationIcon(String code){String c=String.valueOf(code).toUpperCase(Locale.US);if(c.contains("BICYCLE"))return "🚲";if(c.contains("MOTORCYCLE")||c.contains("BIKE"))return "🏍";if(c.contains("CAR")||c.contains("LIMO"))return "🏎";if(c.contains("HORSE"))return "🐎";if(c.contains("HELICOPTER"))return "🚁";if(c.contains("JET"))return "✈";if(c.contains("ROCKET")||c.contains("SPACESHIP"))return "🚀";if(c.contains("BOAT"))return "🚤";if(c.contains("UFO"))return "🛸";if(c.contains("LION"))return "🦁";if(c.contains("DRAGON"))return "🐉";if(c.contains("PHOENIX"))return "🔥";if(c.contains("UNICORN"))return "🦄";if(c.contains("BALLOON"))return "🎈";if(c.contains("EAGLE"))return "🦅";if(c.contains("TIGER"))return "🐯";if(c.contains("CLOUD"))return "☁";if(c.contains("PORTAL"))return "🌀";return "✨";}
    private final ManagedSoundPlayer entrySound430=new ManagedSoundPlayer();
    private void playEntrySound(String url,int volume,int durationMs){entrySound430.play(url,volume,durationMs,message->android.util.Log.w("MYSHOP_ENTRY_SOUND",message));}

    private void renderMilestones(JSONArray a){if(a==null)return;for(int i=0;i<a.length();i++){String k=a.optString(i,"");if(!k.isEmpty()&&shownMilestones.add(k))showFloatingBanner("🏆 "+k.replace('_',' '));}}
    private void showFloatingBanner(String text){final TextView b=t(text,12,Color.WHITE,true);b.setGravity(Gravity.CENTER);b.setBackground(gradient(new int[]{Color.argb(235,102,43,178),Color.argb(235,219,64,143)},Color.rgb(255,223,101),18));addContentView(b,new android.view.ViewGroup.LayoutParams(dp(300),dp(42)));b.setX((getResources().getDisplayMetrics().widthPixels-dp(300))/2f);b.setY(dp(110));b.setAlpha(0f);b.animate().alpha(1f).translationY(dp(10)).setDuration(220).withEndAction(()->handler.postDelayed(()->b.animate().alpha(0f).setDuration(350).withEndAction(()->{if(b.getParent()!=null)((android.view.ViewGroup)b.getParent()).removeView(b);}).start(),1800)).start();}
    private void renderGiftActivityComment(JSONObject e){
        if(commentsList==null||e==null)return;
        LinearLayout giftRow=row();giftRow.setGravity(Gravity.CENTER_VERTICAL);giftRow.setPadding(dp(7),dp(4),dp(8),dp(4));giftRow.setBackground(gradient(new int[]{Color.argb(218,31,73,153),Color.argb(218,83,35,145)},Color.rgb(68,207,255),13));
        FrameLayout av=circleAvatar(e.optString("sender_avatar",""),dp(40),false);giftRow.addView(av,new LinearLayout.LayoutParams(dp(40),dp(40)));
        ImageView giftThumb=new ImageView(this);giftThumb.setScaleType(ImageView.ScaleType.CENTER_INSIDE);String giftAsset=e.optString("preview_url","");if(giftAsset.isEmpty())giftAsset=e.optString("animation_url","");if(!giftAsset.isEmpty())AnimatedAssetLoader.load(giftThumb,giftAsset);else giftThumb.setImageResource(builtInGiftArt(e.optString("name","Gift")));LinearLayout.LayoutParams gtp=new LinearLayout.LayoutParams(dp(48),dp(48));gtp.leftMargin=dp(6);giftRow.addView(giftThumb,gtp);
        String sender=e.optString("sender_name","Supporter"),gift=e.optString("name","Gift"),receiver=e.optString("receiver_name",currentLiveName);int price=e.optInt("price",0),level=e.optInt("sender_level",e.optInt("level",0)),qty=Math.max(1,e.optInt("combo",e.optInt("quantity",1)));String currency="GOLD".equalsIgnoreCase(e.optString("currency","COIN"))?"Gold":"Coin";
        LinearLayout body=col();body.setPadding(dp(6),0,0,0);
        TextView who=t(sender+"  ⭐ LV."+level,13.6f,Color.rgb(255,231,111),true);who.setMaxLines(1);body.addView(who,new LinearLayout.LayoutParams(-1,-2));
        TextView what=t("🎁 sent "+gift+" ×"+qty+"  •  "+price+" "+currency,14.2f,Color.WHITE,true);what.setMaxLines(1);what.setEllipsize(android.text.TextUtils.TruncateAt.END);body.addView(what,new LinearLayout.LayoutParams(-1,-2));
        TextView to=t("to "+receiver,9.8f,Color.rgb(205,225,255),false);to.setMaxLines(1);body.addView(to,new LinearLayout.LayoutParams(-1,-2));
        giftRow.addView(body,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(4);commentsList.addView(giftRow,rp);trimCommentRows();if(commentScroll!=null)commentScroll.post(()->commentScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void renderGiftActivityEventsOnly(JSONArray arr){
        if(arr==null||arr.length()==0)return;
        for(int i=0;i<arr.length();i++){
            JSONObject e=arr.optJSONObject(i);if(e==null)continue;long id=e.optLong("id",0);if(id>0&&!renderedGiftEventIds.add(id))continue;
            renderGiftActivityComment(e);
        }
    }

    private void renderGiftEffectsOnly(JSONArray arr){
        if(arr==null||arr.length()==0)return;
        for(int i=0;i<arr.length();i++){
            JSONObject e=arr.optJSONObject(i);if(e==null)continue;long id=e.optLong("id",0);if(id<=lastGiftEventId)continue;
            lastGiftEventId=id;
            JSONObject g=new JSONObject();try{g.put("name",e.optString("name","Gift")).put("currency",e.optString("currency","COIN")).put("price",e.optInt("price",1)).put("preview_url",e.optString("preview_url","")).put("animation_url",e.optString("animation_url","")).put("animation_mime",e.optString("animation_mime","")).put("animation_enabled",e.optInt("animation_enabled",1)).put("sound_url",e.optString("sound_url","")).put("sound_enabled",e.optInt("sound_enabled",1)).put("sound_volume",e.optInt("sound_volume",92)).put("effect_duration_ms",e.optInt("effect_duration_ms",4200)).put("sound_duration_ms",e.optInt("sound_duration_ms",3800)).put("sound_trim_start_pct",e.optInt("sound_trim_start_pct",0)).put("sound_trim_end_pct",e.optInt("sound_trim_end_pct",100)).put("vat_percent",e.optInt("vat_percent",10)).put("board_position",e.optString("board_position","CENTER")).put("animation_scale",e.optInt("animation_scale",82)).put("size_mode",e.optString("size_mode","MEDIUM"));}catch(Exception ignored){}
            JSONObject r=new JSONObject();try{r.put("eventId",id).put("receiverId",e.optString("receiver_id",hostId)).put("combo",Math.max(1,e.optInt("combo",1))).put("senderName",e.optString("sender_name","Supporter"));}catch(Exception ignored){}
            showGiftEffect(g,r);
        }
    }

    private void renderGiftEvents(JSONArray arr){renderGiftActivityEventsOnly(arr);renderGiftEffectsOnly(arr);}


    private int builtInGiftArt(String name){
        int v381=GiftBuiltIns.art(name);if(v381!=0)return v381;
        String n=String.valueOf(name).toLowerCase(Locale.US);
        if(n.contains("neon prism"))return R.drawable.gift_v375_neon_prism;
        if(n.contains("panda cheer"))return R.drawable.gift_v375_panda_cheer;
        if(n.contains("love balloons"))return R.drawable.gift_v375_love_balloons;
        if(n.contains("celebration burst"))return R.drawable.gift_v375_celebration_burst;
        if(n.contains("sweet surprise"))return R.drawable.gift_v375_sweet_surprise;
        if(n.contains("lucky clover"))return R.drawable.gift_v375_lucky_clover;
        if(n.contains("butterfly glow"))return R.drawable.gift_v375_butterfly_glow;
        if(n.contains("music pulse"))return R.drawable.gift_v375_music_pulse;
        if(n.contains("sakura dream"))return R.drawable.gift_v375_sakura_dream;
        if(n.contains("turbo bike"))return R.drawable.gift_v375_turbo_bike;
        if(n.contains("royal scepter"))return R.drawable.gift_v375_royal_scepter;
        if(n.contains("aurora orb"))return R.drawable.gift_v375_aurora_orb;
        if(n.contains("celestial wings"))return R.drawable.gift_v375_celestial_wings;
        if(n.contains("time portal"))return R.drawable.gift_v375_time_portal;
        if(n.contains("ocean voyager"))return R.drawable.gift_v375_ocean_voyager;
        if(n.contains("fire phoenix"))return R.drawable.gift_v375_fire_phoenix;
        if(n.contains("rainbow unicorn"))return R.drawable.gift_v375_rainbow_unicorn;
        if(n.contains("moon romance"))return R.drawable.gift_v375_moon_romance;
        if(n.contains("starship"))return R.drawable.gift_v375_starship;
        if(n.contains("golden dragon"))return R.drawable.gift_v375_golden_dragon;
        if(n.contains("rose"))return R.drawable.gift_rose;
        if(n.contains("heart"))return R.drawable.gift_heart;
        if(n.contains("teddy"))return R.drawable.gift_teddy;
        if(n.contains("chocolate"))return R.drawable.gift_chocolate;
        if(n.equals("star")||n.contains("super star"))return R.drawable.gift_star;
        if(n.contains("diamond"))return R.drawable.gift_diamond;
        if(n.contains("crown"))return R.drawable.gift_crown;
        if(n.contains("car"))return R.drawable.gift_car;
        if(n.contains("jet"))return R.drawable.gift_jet;
        if(n.contains("castle"))return R.drawable.gift_castle;
        return R.drawable.gift_star;
    }
    private int builtInGiftSound(String name){
        int v381=GiftBuiltIns.sound(name);if(v381!=0)return v381;
        String n=String.valueOf(name).toLowerCase(Locale.US);
        if(n.contains("neon prism"))return R.raw.gift_v375_neon_prism_sound;
        if(n.contains("panda cheer"))return R.raw.gift_v375_panda_cheer_sound;
        if(n.contains("love balloons"))return R.raw.gift_v375_love_balloons_sound;
        if(n.contains("celebration burst"))return R.raw.gift_v375_celebration_burst_sound;
        if(n.contains("sweet surprise"))return R.raw.gift_v375_sweet_surprise_sound;
        if(n.contains("lucky clover"))return R.raw.gift_v375_lucky_clover_sound;
        if(n.contains("butterfly glow"))return R.raw.gift_v375_butterfly_glow_sound;
        if(n.contains("music pulse"))return R.raw.gift_v375_music_pulse_sound;
        if(n.contains("sakura dream"))return R.raw.gift_v375_sakura_dream_sound;
        if(n.contains("turbo bike"))return R.raw.gift_v375_turbo_bike_sound;
        if(n.contains("royal scepter"))return R.raw.gift_v375_royal_scepter_sound;
        if(n.contains("aurora orb"))return R.raw.gift_v375_aurora_orb_sound;
        if(n.contains("celestial wings"))return R.raw.gift_v375_celestial_wings_sound;
        if(n.contains("time portal"))return R.raw.gift_v375_time_portal_sound;
        if(n.contains("ocean voyager"))return R.raw.gift_v375_ocean_voyager_sound;
        if(n.contains("fire phoenix"))return R.raw.gift_v375_fire_phoenix_sound;
        if(n.contains("rainbow unicorn"))return R.raw.gift_v375_rainbow_unicorn_sound;
        if(n.contains("moon romance"))return R.raw.gift_v375_moon_romance_sound;
        if(n.contains("starship"))return R.raw.gift_v375_starship_sound;
        if(n.contains("golden dragon"))return R.raw.gift_v375_golden_dragon_sound;
        if(n.contains("rose"))return R.raw.gift_rose_sound;
        if(n.contains("heart"))return R.raw.gift_heart_sound;
        if(n.contains("teddy"))return R.raw.gift_teddy_sound;
        if(n.contains("chocolate"))return R.raw.gift_chocolate_sound;
        if(n.equals("star")||n.contains("super star"))return R.raw.gift_star_sound;
        if(n.contains("diamond"))return R.raw.gift_diamond_sound;
        if(n.contains("crown"))return R.raw.gift_crown_sound;
        if(n.contains("car"))return R.raw.gift_car_sound;
        if(n.contains("jet"))return R.raw.gift_jet_sound;
        if(n.contains("castle"))return R.raw.gift_castle_sound;
        return 0;
    }
    // V-380: Love Balloons + Celebration Burst live-board effects use transparent
    // premium artwork instead of the old square/card PNG. Admin-uploaded custom
    // animation/preview URLs still take priority, so existing Gift Manager controls
    // and backend behavior remain unchanged.
    private Bitmap v380PremiumGiftBitmap(String name){
        String n=String.valueOf(name).toLowerCase(Locale.US);
        if(!n.contains("love balloons")&&!n.contains("celebration burst"))return null;
        final int size=512;
        Bitmap bmp=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(bmp);
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStrokeCap(Paint.Cap.ROUND);

        if(n.contains("love balloons")){
            // Three clean heart balloons on a transparent canvas — visually aligned
            // with the simple Rose/Heart live effects, without any rectangular panel.
            v380DrawHeart(c,p,258,218,150,Color.rgb(255,39,112));
            v380DrawHeart(c,p,154,154,92,Color.rgb(255,92,158));
            v380DrawHeart(c,p,358,142,105,Color.rgb(255,52,124));
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(7f);p.setColor(Color.argb(220,255,205,226));
            c.drawLine(258,290,255,430,p);c.drawLine(154,198,232,430,p);c.drawLine(358,193,278,430,p);
            p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);
            c.drawCircle(214,180,10,p);c.drawCircle(331,114,8,p);c.drawCircle(129,126,7,p);
            p.setStrokeWidth(5f);p.setStyle(Paint.Style.STROKE);p.setColor(Color.argb(235,255,226,239));
            c.drawLine(102,226,132,226,p);c.drawLine(117,211,117,241,p);
            c.drawLine(390,237,420,237,p);c.drawLine(405,222,405,252,p);
            return bmp;
        }

        // Celebration Burst: transparent fireworks/sparkles. No dark square image.
        int[][] bursts={{256,242,Color.rgb(255,177,52)},{174,202,Color.rgb(224,66,255)},{342,188,Color.rgb(66,176,255)}};
        for(int[] b:bursts){
            float cx=b[0],cy=b[1];int color=b[2];
            for(int i=0;i<18;i++){
                double a=(Math.PI*2*i)/18.0;float inner=34f+(i%3)*7f,outer=108f+(i%4)*12f;
                float x1=cx+(float)Math.cos(a)*inner,y1=cy+(float)Math.sin(a)*inner;
                float x2=cx+(float)Math.cos(a)*outer,y2=cy+(float)Math.sin(a)*outer;
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(i%3==0?8f:5f);p.setColor(color);c.drawLine(x1,y1,x2,y2,p);
                p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);c.drawCircle(x2,y2,i%3==0?7f:4.5f,p);
            }
            p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);c.drawCircle(cx,cy,14f,p);
        }
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(6f);p.setColor(Color.rgb(255,111,67));
        c.drawLine(252,270,226,430,p);c.drawLine(262,270,291,430,p);
        p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(255,232,109));
        c.drawCircle(96,124,8,p);c.drawCircle(420,122,9,p);c.drawCircle(104,348,7,p);c.drawCircle(407,342,7,p);
        return bmp;
    }
    private void v380DrawHeart(Canvas c,Paint p,float cx,float cy,float size,int color){
        float s=size/100f;Path h=new Path();h.moveTo(cx,cy+38*s);
        h.cubicTo(cx-72*s,cy-7*s,cx-61*s,cy-78*s,cx-18*s,cy-75*s);
        h.cubicTo(cx-2*s,cy-74*s,cx+12*s,cy-63*s,cx,cy-48*s);
        h.cubicTo(cx+19*s,cy-70*s,cx+61*s,cy-76*s,cx+72*s,cy-40*s);
        h.cubicTo(cx+87*s,cy+7*s,cx+35*s,cy+48*s,cx,cy+78*s);h.close();
        p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawPath(h,p);
        p.setColor(Color.argb(150,255,255,255));c.drawCircle(cx-24*s,cy-31*s,10*s,p);
    }
    private void setGiftArt(ImageView art,JSONObject gift){
        String asset=gift.optString("animation_url","");if(asset.isEmpty())asset=gift.optString("preview_url","");
        if(!asset.isEmpty()){AnimatedAssetLoader.load(art,asset);return;}
        Bitmap premium=v380PremiumGiftBitmap(gift.optString("name","Gift"));
        if(premium!=null){art.setImageBitmap(premium);return;}
        art.setImageResource(builtInGiftArt(gift.optString("name","Gift")));
    }
    private int giftInt(JSONObject gift,String snake,String camel,int def){
        if(gift==null)return def;Object v=gift.opt(snake);if(v==null||v==JSONObject.NULL)v=gift.opt(camel);if(v==null||v==JSONObject.NULL)return def;
        if(v instanceof Number)return ((Number)v).intValue();if(v instanceof Boolean)return ((Boolean)v)?1:0;try{return Integer.parseInt(String.valueOf(v).trim());}catch(Exception ignored){return def;}
    }
    private String giftString(JSONObject gift,String snake,String camel){if(gift==null)return "";String v=gift.optString(snake,"").trim();if(v.isEmpty())v=gift.optString(camel,"").trim();return v;}
    private void playBuiltInGiftSound(int resId,float volume,int maxDuration){
        if(resId==0||volume<=0f)return;
        try{
            final android.media.MediaPlayer fb=new android.media.MediaPlayer();
            // V-353: gift audio uses the normal media stream. SONIFICATION + transient focus
            // could be inaudible on some devices and could also duck/interrupt Agora voice.
            android.media.AudioAttributes aa=new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build();fb.setAudioAttributes(aa);
            android.content.res.AssetFileDescriptor afd=getResources().openRawResourceFd(resId);if(afd==null){fb.release();return;}fb.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());afd.close();fb.prepare();fb.setVolume(volume,volume);
            final int targetDuration=Math.max(1500,Math.min(maxDuration,7000));if(fb.getDuration()>0&&fb.getDuration()<1200&&targetDuration>fb.getDuration()+150)fb.setLooping(true);
            final android.media.audiofx.LoudnessEnhancer[] boost={null};try{boost[0]=new android.media.audiofx.LoudnessEnhancer(fb.getAudioSessionId());boost[0].setTargetGain(500);boost[0].setEnabled(true);}catch(Throwable ignored){}
            final boolean[] done={false};final Runnable release=()->{if(done[0])return;done[0]=true;try{if(fb.isPlaying())fb.stop();}catch(Exception ignored){}try{if(boost[0]!=null){boost[0].setEnabled(false);boost[0].release();}}catch(Exception ignored){}try{fb.release();}catch(Exception ignored){}};
            fb.setOnCompletionListener(x->release.run());fb.setOnErrorListener((x,w,e)->{release.run();return true;});fb.start();handler.postDelayed(release,targetDuration);
        }catch(Exception ignored){}
    }
    private void playGiftSound(JSONObject gift){
        if(giftInt(gift,"sound_enabled","soundEnabled",1)!=1)return;
        final float volume=Math.max(0f,Math.min(1f,giftInt(gift,"sound_volume","soundVolume",92)/100f));if(volume<=0f)return;
        final int configuredDuration=Math.max(600,giftInt(gift,"sound_duration_ms","soundDurationMs",3800));final int maxDuration=Math.max(1200,Math.min(18000,Math.round(configuredDuration*1.45f)));
        final String url=giftString(gift,"sound_url","soundUrl");final String giftName=gift.optString("name","Gift");final int fallbackRes=builtInGiftSound(giftName);final boolean[] fallbackUsed={false};
        final Runnable playFallback=()->{if(fallbackUsed[0])return;fallbackUsed[0]=true;playBuiltInGiftSound(fallbackRes,volume,maxDuration);};
        if(url.isEmpty()){playFallback.run();return;}
        try{
            final android.media.MediaPlayer mp=new android.media.MediaPlayer();android.media.AudioAttributes aa=new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build();mp.setAudioAttributes(aa);mp.setDataSource(url);
            final boolean[] released={false},prepared={false};final android.media.audiofx.LoudnessEnhancer[] boost={null};
            final Runnable release=()->{if(released[0])return;released[0]=true;try{if(mp.isPlaying())mp.stop();}catch(Exception ignored){}try{if(boost[0]!=null){boost[0].setEnabled(false);boost[0].release();}}catch(Exception ignored){}try{mp.reset();}catch(Exception ignored){}try{mp.release();}catch(Exception ignored){}};
            final Runnable watchdog=()->{if(!prepared[0]&&!released[0]){release.run();playFallback.run();}};handler.postDelayed(watchdog,1200L);
            mp.setOnPreparedListener(x->{prepared[0]=true;handler.removeCallbacks(watchdog);if(released[0])return;try{x.setVolume(volume,volume);try{boost[0]=new android.media.audiofx.LoudnessEnhancer(x.getAudioSessionId());boost[0].setTargetGain(400);boost[0].setEnabled(true);}catch(Throwable ignored){}int total=Math.max(1,x.getDuration());int startPct=Math.max(0,Math.min(99,giftInt(gift,"sound_trim_start_pct","soundTrimStartPct",0)));int endPct=Math.max(startPct+1,Math.min(100,giftInt(gift,"sound_trim_end_pct","soundTrimEndPct",100)));int startMs=(int)((long)total*startPct/100L);int endMs=(int)((long)total*endPct/100L);int segmentMs=Math.max(100,endMs-startMs);int playMs=segmentMs<1400?Math.min(maxDuration,Math.max(1800,segmentMs*4)):Math.min(maxDuration,segmentMs);if(startMs>0)x.seekTo(startMs);if(segmentMs<1400&&playMs>segmentMs+150)x.setLooping(true);x.start();handler.postDelayed(release,playMs);}catch(Exception ex){release.run();playFallback.run();}});
            mp.setOnCompletionListener(x->release.run());mp.setOnErrorListener((x,w,e)->{handler.removeCallbacks(watchdog);release.run();playFallback.run();return true;});mp.prepareAsync();
        }catch(Exception ex){playFallback.run();}
    }

    private int giftScale(JSONObject gift){
        if(gift.has("animation_scale"))return Math.max(0,Math.min(100,gift.optInt("animation_scale",70)));
        String m=gift.optString("size_mode","MEDIUM").toUpperCase(Locale.US);if("SMALL".equals(m))return 15;if("LARGE".equals(m))return 75;if("FULL_SCREEN".equals(m))return 100;return 48;
    }
    private String giftModeForScale(int scale){if(scale<=20)return "SMALL";if(scale<=58)return "MEDIUM";if(scale<=84)return "LARGE";return "FULL_SCREEN";}
    private int giftArtPx(int scale){
        int w=getResources().getDisplayMetrics().widthPixels,h=getResources().getDisplayMetrics().heightPixels,base=Math.min(w,h);
        float pct=.46f+(1.00f*(Math.max(0,Math.min(100,scale))/100f));
        return Math.max(dp(156),Math.min((int)(base*1.34f),(int)(base*pct)));
    }
    private String giftParticleSymbol(String name){
        String n=String.valueOf(name).toLowerCase(Locale.US);
        if(n.contains("rose")||n.contains("flower"))return "✿";
        if(n.contains("heart")||n.contains("love"))return "♥";
        if(n.contains("diamond")||n.contains("ring"))return "◆";
        if(n.contains("crown")||n.contains("throne")||n.contains("palace"))return "✦";
        if(n.contains("fire")||n.contains("party"))return "✹";
        if(n.contains("butterfly")||n.contains("wing")||n.contains("phoenix"))return "✧";
        if(n.contains("moon")||n.contains("galaxy")||n.contains("star"))return "★";
        return "✦";
    }
    private void addGiftParticles(FrameLayout overlay,String name,int count){
        String symbol=giftParticleSymbol(name);String n=String.valueOf(name).toLowerCase(Locale.US);
        int w=getResources().getDisplayMetrics().widthPixels,h=getResources().getDisplayMetrics().heightPixels;
        for(int i=0;i<count;i++){
            final TextView p=t(symbol,12+(i%5)*3,(i%3==0&&n.contains("gold"))?Color.rgb(255,205,72):Color.WHITE,true);p.setGravity(Gravity.CENTER);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(34),dp(34));overlay.addView(p,lp);
            float x=(w*.05f)+((i*83)%(Math.max(1,(int)(w*.90f))));float y=h*(.76f+(i%5)*.028f);p.setX(x);p.setY(y);p.setAlpha(0f);p.setScaleX(.2f);p.setScaleY(.2f);
            long delay=(i%9)*55L;float rise=h*(.30f+(i%7)*.055f);float drift=((i%2==0)?1:-1)*dp(18+(i%6)*10);
            p.animate().alpha(.98f).scaleX(1f+(i%3)*.08f).scaleY(1f+(i%3)*.08f).translationY(-rise).translationX(drift).rotationBy((i%2==0?1:-1)*(70+(i%6)*24)).setStartDelay(delay).setDuration(1450+(i%5)*210L).withEndAction(()->p.animate().alpha(0f).setDuration(340).start()).start();
        }
    }
    private void addGiftBurstRings(FrameLayout overlay,boolean gold){
        int[] strokes=gold?new int[]{Color.rgb(255,205,70),Color.rgb(255,116,194),Color.rgb(104,169,255)}:new int[]{Color.rgb(255,106,202),Color.rgb(130,112,255),Color.rgb(79,208,255)};
        for(int i=0;i<3;i++){
            View ring=new View(this);android.graphics.drawable.GradientDrawable gd=new android.graphics.drawable.GradientDrawable();gd.setShape(android.graphics.drawable.GradientDrawable.OVAL);gd.setColor(Color.TRANSPARENT);gd.setStroke(dp(i==0?3:2),Color.argb(210,Color.red(strokes[i]),Color.green(strokes[i]),Color.blue(strokes[i])));ring.setBackground(gd);int side=dp(150+i*38);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(side,side,Gravity.CENTER);overlay.addView(ring,lp);ring.setScaleX(.25f);ring.setScaleY(.25f);ring.setAlpha(.88f);ring.animate().scaleX(2.15f+i*.25f).scaleY(2.15f+i*.25f).alpha(0f).setStartDelay(i*120L).setDuration(1050+i*180L).start();
        }
    }
    private void animateGiftArt(ImageView art,String name,String sizeMode){
        String n=String.valueOf(name).toLowerCase(Locale.US);int sw=getResources().getDisplayMetrics().widthPixels,sh=getResources().getDisplayMetrics().heightPixels;
        art.setAlpha(0f);art.setScaleX(.38f);art.setScaleY(.38f);art.setTranslationX(0f);art.setTranslationY(0f);art.setRotation(0f);
        if(n.contains("car")||n.contains("bike")){
            art.setTranslationX(-sw*.78f);art.setTranslationY(dp(70));art.setAlpha(1f);art.setScaleX(.78f);art.setScaleY(.78f);art.animate().translationX(0f).translationY(0f).scaleX(1.12f).scaleY(1.12f).setDuration(1500).withEndAction(()->art.animate().translationX(sw*.48f).scaleX(.98f).scaleY(.98f).setDuration(1450).start()).start();return;
        }
        if(n.contains("jet")){
            art.setTranslationX(-sw*.72f);art.setTranslationY(sh*.24f);art.setRotation(-15f);art.setAlpha(1f);art.setScaleX(.72f);art.setScaleY(.72f);art.animate().translationX(0f).translationY(-dp(25)).rotation(2f).scaleX(1.18f).scaleY(1.18f).setDuration(1700).withEndAction(()->art.animate().translationX(sw*.58f).translationY(-sh*.22f).rotation(10f).setDuration(1650).start()).start();return;
        }
        if(n.contains("yacht")){
            art.setTranslationX(sw*.60f);art.setTranslationY(dp(55));art.setAlpha(1f);art.setScaleX(.76f);art.setScaleY(.76f);art.animate().translationX(0f).translationY(0f).scaleX(1.12f).scaleY(1.12f).setDuration(1800).withEndAction(()->art.animate().translationX(-dp(28)).translationY(-dp(12)).setDuration(1100).start()).start();return;
        }
        if(n.contains("dragon")||n.contains("phoenix")||n.contains("peacock")||n.contains("butterfly")||n.contains("wing")){
            art.setTranslationY(dp(180));art.setRotation(-8f);art.animate().alpha(1f).translationY(-dp(30)).rotation(5f).scaleX(1.16f).scaleY(1.16f).setDuration(1550).withEndAction(()->art.animate().translationY(-dp(48)).rotation(-2f).scaleX(1.03f).scaleY(1.03f).setDuration(1350).start()).start();return;
        }
        if(n.contains("fireworks")||n.contains("firecracker")||n.contains("party popper")||n.contains("diamond rain")){
            art.setScaleX(.18f);art.setScaleY(.18f);art.animate().alpha(1f).scaleX(1.28f).scaleY(1.28f).setDuration(720).withEndAction(()->art.animate().scaleX(.96f).scaleY(.96f).setDuration(280).withEndAction(()->art.animate().scaleX(1.08f).scaleY(1.08f).setDuration(800).start()).start()).start();return;
        }
        if(n.contains("rose")||n.contains("flower")||n.contains("balloon")){
            art.setTranslationY(dp(165));art.setRotation(-8f);art.animate().alpha(1f).translationY(-dp(28)).rotation(5f).scaleX(1.15f).scaleY(1.15f).setDuration(1350).withEndAction(()->art.animate().translationY(-dp(42)).rotation(-3f).scaleX(1.02f).scaleY(1.02f).setDuration(1300).start()).start();return;
        }
        if(n.contains("heart")||n.contains("teddy")||n.contains("cake")||n.contains("ice cream")||n.contains("chocolate")){
            art.animate().alpha(1f).scaleX(1.20f).scaleY(1.20f).setDuration(620).withEndAction(()->art.animate().scaleX(.98f).scaleY(.98f).setDuration(320).withEndAction(()->art.animate().scaleX(1.08f).scaleY(1.08f).translationY(-dp(24)).setDuration(900).start()).start()).start();return;
        }
        if(n.contains("crown")||n.contains("throne")||n.contains("palace")||n.contains("treasure")||n.contains("lion")||n.contains("elephant")||n.contains("perfume")||n.contains("coffee")){
            art.setTranslationY(dp(100));art.animate().alpha(1f).translationY(-dp(18)).scaleX(1.18f).scaleY(1.18f).setDuration(1450).withEndAction(()->art.animate().scaleX(1.04f).scaleY(1.04f).translationY(-dp(34)).setDuration(1250).start()).start();return;
        }
        if(n.contains("galaxy")||n.contains("rainbow")||n.contains("moon")||n.contains("magic wand")||n.contains("star")||n.contains("ring")){
            art.setRotation(-10f);art.animate().alpha(1f).rotation(7f).scaleX(1.18f).scaleY(1.18f).setDuration(1250).withEndAction(()->art.animate().rotation(-3f).scaleX(1.04f).scaleY(1.04f).setDuration(1350).start()).start();return;
        }
        art.animate().alpha(1f).scaleX(1.14f).scaleY(1.14f).translationY(-dp(22)).setDuration(1450).withEndAction(()->art.animate().scaleX(1.03f).scaleY(1.03f).setDuration(1000).start()).start();
    }
    private void showGiftEffect(JSONObject gift,JSONObject result){
        cachedGiftCatalog=null;cachedGiftCatalogAt=0L;
        final int combo=Math.max(1,result.optInt("combo",1));final String name=gift.optString("name","Gift");final int scale=giftScale(gift);final String sizeMode=giftModeForScale(scale);final int price=gift.optInt("price",0);final boolean goldGift="GOLD".equalsIgnoreCase(gift.optString("currency","COIN"));final String receiver=result.optString("receiverId",hostId);final String streak=combo>1?"  ×"+combo+" COMBO":"";
        playGiftSound(gift);
        if(giftInt(gift,"animation_enabled","animationEnabled",1)!=1){prefetchGiftCatalog();return;}
        final boolean cinematic=goldGift||scale>=62||price>=1000;
        final FrameLayout overlay=new FrameLayout(this);overlay.setClickable(false);overlay.setBackgroundColor(Color.argb(goldGift?170:(cinematic?105:32),5,7,25));addContentView(overlay,new android.view.ViewGroup.LayoutParams(-1,-1));
        addGiftBurstRings(overlay,goldGift);addGiftParticles(overlay,name,goldGift?58:(cinematic?38:24));
        final ImageView art=new ImageView(this);art.setScaleType(ImageView.ScaleType.CENTER_INSIDE);setGiftArt(art,gift);int artPx=giftArtPx(scale);String boardPos=gift.optString("board_position","CENTER").toUpperCase(Locale.US);int giftGravity="TOP".equals(boardPos)?(Gravity.TOP|Gravity.CENTER_HORIZONTAL):"BOTTOM".equals(boardPos)?(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL):Gravity.CENTER;if("FULL_SCREEN".equals(boardPos))artPx=Math.max(artPx,Math.min(getResources().getDisplayMetrics().widthPixels,getResources().getDisplayMetrics().heightPixels));FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(artPx,artPx,giftGravity);if("TOP".equals(boardPos))ap.topMargin=dp(115);else if("BOTTOM".equals(boardPos))ap.bottomMargin=dp(115);overlay.addView(art,ap);
        TextView glow=t("✦     ✧     ✦",cinematic?34:24,Color.rgb(255,230,125),true);glow.setGravity(Gravity.CENTER);glow.setAlpha(.25f);FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(-1,dp(70),Gravity.CENTER);overlay.addView(glow,gp);ObjectAnimator pulse=ObjectAnimator.ofFloat(glow,"alpha",.18f,.9f,.18f);pulse.setDuration(780);pulse.setRepeatCount(3);pulse.start();
        animateGiftArt(art,name,sizeMode);
        String sender=result.optString("senderName",SessionManager.getFullName(this));if(sender==null||sender.trim().isEmpty())sender="Supporter";String currency=gift.optString("currency","COIN");
        LinearLayout giftMeta=col();giftMeta.setGravity(Gravity.CENTER);giftMeta.setPadding(dp(10),dp(4),dp(10),dp(5));giftMeta.setBackground(bg(Color.argb(175,10,13,37),Color.argb(220,255,201,78),14));
        TextView who=t(sender+"  •  "+name+(streak.isEmpty()?"":streak),9.2f,Color.WHITE,true);who.setGravity(Gravity.CENTER);giftMeta.addView(who,new LinearLayout.LayoutParams(-2,dp(21)));
        TextView val=t(("GOLD".equals(currency)?"👑 ":"🪙 ")+price+("GOLD".equals(currency)?" Gold Coin":" Coin"),8.8f,Color.rgb(255,210,71),true);val.setGravity(Gravity.CENTER);giftMeta.addView(val,new LinearLayout.LayoutParams(-2,dp(20)));
        FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(-2,dp(47),Gravity.CENTER);mp.topMargin=Math.min(dp(245),Math.max(dp(115),artPx/2+dp(30)));overlay.addView(giftMeta,mp);
        long configuredStay=Math.max(500,gift.optInt("effect_duration_ms",scale>=90?4200:cinematic?3600:3000));long stay=Math.max(3200,Math.min(18000,Math.round(configuredStay*1.45f)));handler.postDelayed(()->overlay.animate().alpha(0f).setDuration(420).withEndAction(()->{if(overlay.getParent()!=null)((android.view.ViewGroup)overlay.getParent()).removeView(overlay);}).start(),stay);
        prefetchGiftCatalog();
    }

    private void openUserProfile(JSONObject u){if(u==null)return;String uid=u.optString("user_id",u.optString("userId",""));if(uid.isEmpty())return;Intent i=new Intent(this,UserProfileActivity.class);i.putExtra("userId",uid);startActivity(i);}

    private void showMiniProfile(JSONObject u){
        String uid=u.optString("user_id",u.optString("userId",""));if(uid.isEmpty())return;
        String tier=u.optString("tier","STANDARD"),name=u.optString("full_name",u.optString("name","User"));
        boolean canInvite=!uid.equals(hostId)&&(canSuggestCall||host||roomAdmin||SessionManager.isAdmin(this)||SessionManager.isModerator(this));
        java.util.ArrayList<String> actions=new java.util.ArrayList<>();
        actions.add(uid.equals(hostId)?"Open Creator Profile":"Open Profile");
        if(canInvite)actions.add("📞 Call / Invite to Seat");
        actions.add(uid.equals(hostId)?"Follow Host":"Follow");actions.add("Message");
        if(uid.equals(hostId))actions.add("Fan Club");actions.add("⚑ Report / Block");
        String info="ID "+uid+"  •  🏅LV."+u.optInt("level",0)+"\n🪙 Coin  "+compact(u.optLong("coin_balance",0))+"   •   🟡 Gold  "+compact(u.optLong("gold_balance",0));
        int fp=u.optInt("fan_points",u.optInt("fanPoints",0));if(fp>0)info+="\n⭐ Fan Points "+fp;
        final String finalInfo=info;
        new AlertDialog.Builder(this).setTitle(name+" • "+tier).setMessage(finalInfo).setItems(actions.toArray(new String[0]),(d,w)->{
            String a=actions.get(w);
            if(a.startsWith("Open")){if(uid.equals(hostId))openCreatorCenter(uid);else{Intent i=new Intent(this,UserProfileActivity.class);i.putExtra("userId",uid);startActivity(i);}return;}
            if(a.startsWith("📞")){inviteToCall(u);return;}
            if(a.startsWith("Follow")){BackendClient.toggleFollow(token(),uid,new ToastCb("Follow updated"));return;}
            if(a.equals("Message")){Intent i=new Intent(this,ChatActivity.class);i.putExtra("userId",uid);i.putExtra("name",name);startActivity(i);return;}
            if(a.equals("Fan Club")){showFanClub();return;}
            SafetyActions.show(this,uid,"LIVE_USER",hostId);
        }).setNegativeButton("Close",null).show();
    }

    private void showLiveCommunityMenu(){new AlertDialog.Builder(this).setTitle("Live Community").setItems(new String[]{"Host Creator Profile","Fan Club / Supporters","Scheduled Lives","Follow Host"},(d,w)->{if(w==0)openCreatorCenter(hostId);else if(w==1)showFanClub();else if(w==2)showSchedules(hostId);else BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));}).show();}
    private void openCreatorCenter(String uid){Intent i=new Intent(this,CreatorCenterActivity.class);i.putExtra("userId",uid);startActivity(i);}
    private void showFanClub(){BackendClient.liveFanClub(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("members");StringBuilder z=new StringBuilder("Members: ").append(d.optInt("memberCount",0)).append("\nYour points: ").append(d.optLong("points",0)).append("\n\n");if(a!=null)for(int i=0;i<Math.min(8,a.length());i++){JSONObject x=a.optJSONObject(i);if(x!=null)z.append(i+1).append(". ").append(x.optString("full_name","User")).append(" • ").append(x.optLong("points",0)).append(" pts\n");}AlertDialog.Builder b=new AlertDialog.Builder(AudioLiveRoomActivity.this).setTitle("⭐ Fan Club").setMessage(z.toString()).setNegativeButton("Close",null);if(!host)b.setPositiveButton(d.optBoolean("joined",false)?"Leave Fan Club":"Join Fan Club",(q,w)->BackendClient.liveFanClubToggle(token(),hostId,new ToastCb("Fan Club updated")));b.show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}
    private void editWelcome(){EditText e=new EditText(this);e.setHint("Welcome message / room rules");new AlertDialog.Builder(this).setTitle("Room Welcome").setView(e).setPositiveButton("Save",(d,w)->BackendClient.livePremiumConfig(token(),e.getText().toString().trim(),null,-1,-1,new ToastCb("Welcome updated"))).setNegativeButton("Cancel",null).show();}
    private void editGoal(){String[] types={"COIN","SUPPORTERS","MINUTES","VIEWERS","NONE"};new AlertDialog.Builder(this).setTitle("Live Goal Type").setItems(types,(d,w)->{String type=types[w];if("NONE".equals(type)){BackendClient.livePremiumConfig(token(),null,"NONE",0,-1,new ToastCb("Goal cleared"));return;}EditText e=new EditText(this);e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);e.setHint("Target");new AlertDialog.Builder(this).setTitle(type+" target").setView(e).setPositiveButton("Save",(q,x)->{long target=0;try{target=Long.parseLong(e.getText().toString().trim());}catch(Exception ignored){}BackendClient.livePremiumConfig(token(),null,type,target,-1,new ToastCb("Live Goal updated"));}).setNegativeButton("Cancel",null).show();}).show();}
    private void choosePinnedProduct(){BackendClient.storeCatalog(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray raw=d.optJSONArray("products");if(raw==null)raw=d.optJSONArray("catalog");final JSONArray a=raw;if(a==null||a.length()==0){Toast.makeText(AudioLiveRoomActivity.this,"No enabled Shop items",Toast.LENGTH_SHORT).show();return;}String[] names=new String[a.length()+1];long[] ids=new long[a.length()+1];names[0]="Clear pinned product";ids[0]=0;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);names[i+1]=x==null?"Item":x.optString("title","Item")+" • "+x.optLong("coin_price",x.optLong("coinPrice",0))+" Coin";ids[i+1]=x==null?0:x.optLong("id",0);}new AlertDialog.Builder(AudioLiveRoomActivity.this).setTitle("🛍 Live Shop • Pin Item").setItems(names,(q,w)->BackendClient.livePremiumConfig(token(),null,null,-1,ids[w],new ToastCb(w==0?"Product pin cleared":"Product pinned"))).show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}
    private void showSchedules(String uid){BackendClient.liveSchedules(token(),uid,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("schedules");if(a==null||a.length()==0){Toast.makeText(AudioLiveRoomActivity.this,"No scheduled live",Toast.LENGTH_SHORT).show();return;}String[] x=new String[a.length()];for(int i=0;i<a.length();i++){JSONObject z=a.optJSONObject(i);x[i]=(z==null?"Scheduled Live":z.optString("title","Scheduled Live")+" • "+z.optString("scheduled_at",""));}new AlertDialog.Builder(AudioLiveRoomActivity.this).setTitle("🔔 Scheduled Lives").setItems(x,(q,w)->{JSONObject z=a.optJSONObject(w);if(z!=null&&!host)BackendClient.liveScheduleReminder(token(),z.optLong("id"),new ToastCb("Reminder updated"));}).setNegativeButton("Close",null).show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}
    private void showScheduleDialog(){LinearLayout box=col();EditText title=new EditText(this);title.setHint("Live title");EditText topic=new EditText(this);topic.setHint("Topic");EditText at=new EditText(this);at.setHint("YYYY-MM-DD HH:MM:SS");box.addView(title);box.addView(topic);box.addView(at);new AlertDialog.Builder(this).setTitle("🔔 Schedule Live").setView(box).setPositiveButton("Save",(d,w)->BackendClient.liveScheduleSave(token(),0,title.getText().toString().trim(),topic.getText().toString().trim(),at.getText().toString().trim(),new ToastCb("Live scheduled"))).setNeutralButton("View Schedules",(d,w)->showSchedules(hostId)).setNegativeButton("Cancel",null).show();}
    private void showPkDialog(){EditText e=new EditText(this);e.setHint("Other LIVE Host ID");e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);new AlertDialog.Builder(this).setTitle("⚔ Friendly PK / Battle").setMessage("Both hosts must already be live. V-304 foundation scores completed gifts during the PK.").setView(e).setPositiveButton("Invite",(d,w)->BackendClient.livePkStart(token(),e.getText().toString().trim(),new ToastCb("PK invitation sent"))).setNegativeButton("Cancel",null).show();}
    private void showIncomingPk(long id){new AlertDialog.Builder(this).setTitle("⚔ PK Invitation").setMessage("Another live host invited this room to a friendly PK.").setPositiveButton("Accept",(d,w)->BackendClient.livePkAction(token(),id,"ACCEPT",new ToastCb("PK started"))).setNegativeButton("Decline",(d,w)->BackendClient.livePkAction(token(),id,"DECLINE",new ToastCb("PK declined"))).show();}
    private void showAudienceEndSummary(){if(endedSummaryShown)return;endedSummaryShown=true;showAudienceEndSummaryAttempt(1);}
    private void showAudienceEndSummaryAttempt(final int attempt){
        BackendClient.liveSummary(token(),hostId,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{JSONObject x=d.optJSONObject("summary");if(x!=null){showSummary(x);return;}if(attempt<5){handler.postDelayed(()->showAudienceEndSummaryAttempt(attempt+1),450L+attempt*250L);return;}showLocalAudienceEndSummary();});}
            public void onError(String m){runOnUiThread(()->{if(attempt<5){handler.postDelayed(()->showAudienceEndSummaryAttempt(attempt+1),450L+attempt*250L);return;}showLocalAudienceEndSummary();});}
        });
    }
    private void showLocalAudienceEndSummary(){JSONObject x=new JSONObject();try{long duration=Math.max(0,serverElapsedSec+(System.currentTimeMillis()-serverElapsedSyncMs)/1000L);x.put("duration_seconds",duration).put("peak_viewers",Math.max(currentPeakViewers,currentViewerCount)).put("total_listeners",Math.max(currentTotalListeners,currentViewerCount)).put("react_count",Math.max(0,reactCount)).put("topSupporters",currentTopSupporters==null?new JSONArray():currentTopSupporters);}catch(Exception ignored){}showPremiumSummaryDialog(x,true);}


    private void updateSpeakerControls(){
        if(speakerActionButton!=null){
            String label;
            if(host)label="END";
            else if("SPEAKER".equals(myRole))label="LEAVE";
            else if("PENDING".equalsIgnoreCase(myRequestStatus))label="REQUESTED ✓";
            else label=pendingRequestCount>0?("JOIN • "+pendingRequestCount):"JOIN";
            speakerActionButton.setText(label);
            speakerActionButton.setTextSize(host?13.6f:(label.startsWith("REQUESTED")?10.4f:Math.min(joinFontSize,14.6f)));
            if(!host)speakerActionButton.setTextColor(joinTextColor);
            speakerActionButton.setEnabled(host||"SPEAKER".equals(myRole)||!"PENDING".equalsIgnoreCase(myRequestStatus));
        }
        if(micButton!=null){boolean canTalk=host||"SPEAKER".equals(myRole);micButton.setAlpha(canTalk?1f:.42f);micButton.setEnabled(canTalk&&!listenOnly);}
        updateJoinButtonAnimation();
    }
    private void updateJoinButtonAnimation(){
        if(speakerActionButton==null)return;
        boolean animate=!host&&!"SPEAKER".equals(myRole)&&!listenOnly;
        if(!animate){
            if(joinPulseAlpha!=null){joinPulseAlpha.cancel();joinPulseAlpha=null;}
            if(joinPulseX!=null){joinPulseX.cancel();joinPulseX=null;}
            if(joinPulseY!=null){joinPulseY.cancel();joinPulseY=null;}
            speakerActionButton.setAlpha(1f);speakerActionButton.setScaleX(1f);speakerActionButton.setScaleY(1f);return;
        }
        if(joinPulseAlpha!=null)return;
        joinPulseAlpha=ObjectAnimator.ofFloat(speakerActionButton,"alpha",.86f,1f);joinPulseAlpha.setDuration(1250);joinPulseAlpha.setRepeatCount(ValueAnimator.INFINITE);joinPulseAlpha.setRepeatMode(ValueAnimator.REVERSE);
        joinPulseX=ObjectAnimator.ofFloat(speakerActionButton,"scaleX",1f,1.055f);joinPulseX.setDuration(1250);joinPulseX.setRepeatCount(ValueAnimator.INFINITE);joinPulseX.setRepeatMode(ValueAnimator.REVERSE);
        joinPulseY=ObjectAnimator.ofFloat(speakerActionButton,"scaleY",1f,1.055f);joinPulseY.setDuration(1250);joinPulseY.setRepeatCount(ValueAnimator.INFINITE);joinPulseY.setRepeatMode(ValueAnimator.REVERSE);
        joinPulseAlpha.start();joinPulseX.start();joinPulseY.start();
    }
    private void requestJoinToCall(){
        if(roomEnded||endLiveInProgress||"PENDING".equalsIgnoreCase(myRequestStatus))return;
        // V-394 optimistic UI: the user immediately sees the request state while the
        // backend publishes the same state to the host/all participants.
        myRequestStatus="PENDING";pendingRequestCount=Math.max(1,pendingRequestCount+1);updateSpeakerControls();
        BackendClient.liveSpeakRequest(token(),hostId,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{myRequestStatus=d.optString("status","PENDING");showFloatingBanner("✋ Join request sent • waiting for Host");updateSpeakerControls();refresh();});}
            public void onError(String m){runOnUiThread(()->{myRequestStatus="NONE";pendingRequestCount=Math.max(0,pendingRequestCount-1);updateSpeakerControls();showFloatingBanner("⚠ "+(m==null||m.trim().isEmpty()?"Join request failed":m));});}
        });
    }
    private void confirmLeaveSeat(){
        new AlertDialog.Builder(this).setTitle("Leave call?").setMessage("You will leave the speaker seat but stay in the Live as audience.").setPositiveButton("Leave Call",(d,w)->BackendClient.liveLeaveSeat(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->{myRole="AUDIENCE";currentSeatNo=0;localMicOn=true;if(rtcManager!=null){rtcManager.setPublishAudio(false);rtcManager.setMicEnabled(false);}requestRtcToken(false);updateSpeakerControls();Toast.makeText(AudioLiveRoomActivity.this,"Left the call • still watching Live",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}})).setNegativeButton("Stay",null).show();
    }
    private void moveMySeat(int seatNo){
        if(!"SPEAKER".equals(myRole)||seatNo<2||seatNo>11||seatNo==currentSeatNo)return;
        BackendClient.liveSelfSeatAssign(token(),hostId,seatNo,new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->{currentSeatNo=seatNo;Toast.makeText(AudioLiveRoomActivity.this,"Moved to seat "+seatNo,Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});
    }
    private void showSelfSeatChooser(){
        java.util.ArrayList<Integer> nums=new java.util.ArrayList<>();java.util.ArrayList<String> labels=new java.util.ArrayList<>();
        for(int seatNo=2;seatNo<=11;seatNo++){if(seatNo==currentSeatNo||lockedSeats.contains(seatNo))continue;JSONObject x=findSeat(currentSeats,seatNo);if(x!=null)continue;nums.add(seatNo);labels.add("Guest Seat "+seatNo);}
        if(nums.isEmpty()){Toast.makeText(this,"No free seat available",Toast.LENGTH_SHORT).show();return;}
        new AlertDialog.Builder(this).setTitle("Change Seat").setItems(labels.toArray(new String[0]),(d,w)->moveMySeat(nums.get(w))).setNegativeButton("Cancel",null).show();
    }
    private void showSelfSpeakerMenu(){
        String mic=localMicOn?"Mute microphone":"Unmute microphone";
        new AlertDialog.Builder(this).setTitle("My Call Controls").setItems(new String[]{"Change seat",mic,"Leave Seat / Leave Call"},(d,w)->{if(w==0)showSelfSeatChooser();else if(w==1)toggleMic();else confirmLeaveSeat();}).setNegativeButton("Close",null).show();
    }

    private boolean canModerateSeat(){return host||roomAdmin||SessionManager.isAdmin(this)||SessionManager.isModerator(this);}

    private void showSeatedUserActions(JSONObject x){
        final String uid=x.optString("user_id","");if(uid.isEmpty())return;
        final String title=x.optString("full_name","User")+" • ID "+uid;
        final boolean moderator=canModerateSeat();
        if(!moderator){
            new AlertDialog.Builder(this).setTitle(title).setItems(new String[]{"🎁 Send Gift","Open Profile"},(d,w)->{
                if(w==0){giftReceiverId=uid;giftReceiverName=x.optString("full_name","User");showGiftPanel();}
                else openUserProfile(x);
            }).setNegativeButton("Close",null).show();return;
        }
        showSpeakerActions(x);
    }

    private void refreshSpeakingAvatars(){
        if(isFinishing()||roomEnded)return;
        try{renderHost(findSeat(currentSeats,1));renderSeats(currentSeats);}catch(Throwable ignored){}
    }

    private void showSpeakerActions(JSONObject x){
        final String uid=x.optString("user_id","");if(uid.isEmpty())return;
        final boolean special=uid.equals(specialGuestId);
        final String title=x.optString("full_name","Speaker")+" • ID "+uid;
        java.util.ArrayList<String> actions=new java.util.ArrayList<>();
        actions.add("🎁 Send Gift"); actions.add("Open Profile");
        if(host){actions.add(special?"Remove Center Guest":"Make Center Guest");actions.add("Move to Guest Seat");}
        final boolean currentlyMuted=x.optInt("muted",0)==1||x.optInt("mic_on",1)==0;
        actions.add(currentlyMuted?"Unmute microphone":"Mute microphone");
        if(host||SessionManager.isAdmin(this)||SessionManager.isModerator(this))actions.add("Kick out of Live");
        if(host||SessionManager.isAdmin(this))actions.add("Block from Live");
        if(host){actions.add("Make Room Admin");actions.add("Revoke Room Admin");actions.add("Remove from Speaker Seat");}
        new AlertDialog.Builder(this).setTitle(title).setItems(actions.toArray(new String[0]),(d,which)->{
            String action=actions.get(which);
            if(action.startsWith("🎁")){if(uid.equals(SessionManager.getUserId(this))){Toast.makeText(this,"You cannot gift yourself",Toast.LENGTH_SHORT).show();return;}giftReceiverId=uid;giftReceiverName=x.optString("full_name","User");showGiftPanel();return;}
            if(action.equals("Open Profile")){openUserProfile(x);return;}
            if(action.equals("Make Center Guest")){BackendClient.liveSpecialGuest(token(),uid,false,new ToastCb("Center Guest selected"));return;}
            if(action.equals("Remove Center Guest")){BackendClient.liveSpecialGuest(token(),uid,true,new ToastCb("Center Guest removed"));return;}
            if(action.equals("Move to Guest Seat")){showSeatChooser(uid);return;}
            if(action.equals("Mute microphone")){BackendClient.liveModeration(token(),hostId,uid,"MUTE",new ToastCb("Guest muted"));return;}
            if(action.equals("Unmute microphone")){BackendClient.liveModeration(token(),hostId,uid,"UNMUTE",new ToastCb("Guest unmuted"));return;}
            if(action.equals("Kick out of Live")){new AlertDialog.Builder(this).setTitle("Kick this user?").setMessage("The user will be removed from this Live.").setPositiveButton("Kick",(dd,ww)->BackendClient.liveModeration(token(),hostId,uid,"KICK",new ToastCb("User kicked out"))).setNegativeButton("Cancel",null).show();return;}
            if(action.equals("Block from Live")){new AlertDialog.Builder(this).setTitle("Block from this Live?").setMessage("This user will be removed and cannot rejoin until unblocked.").setPositiveButton("Block",(dd,ww)->BackendClient.liveModeration(token(),hostId,uid,"BLOCK",new ToastCb("User blocked from Live"))).setNegativeButton("Cancel",null).show();return;}
            if(action.equals("Make Room Admin")){BackendClient.liveModeration(token(),hostId,uid,"ADD_ROOM_ADMIN",new ToastCb("Room Admin added"));return;}
            if(action.equals("Revoke Room Admin")){BackendClient.liveModeration(token(),hostId,uid,"REMOVE_ROOM_ADMIN",new ToastCb("Room Admin removed"));return;}
            if(action.equals("Remove from Speaker Seat")){BackendClient.liveSpeakerRemove(token(),uid,new ToastCb("Speaker removed from seat"));}
        }).setNegativeButton("Close",null).show();
    }

    private void showSeatChooser(String uid){String[] items=new String[10];for(int i=0;i<10;i++)items[i]="Guest Seat "+(i+2)+(lockedSeats.contains(i+2)?" • Locked":"");new AlertDialog.Builder(this).setTitle("Move Speaker to Guest Seat").setItems(items,(d,w)->BackendClient.liveSeatAssign(token(),uid,w+2,new ToastCb("Guest seat updated"))).setNegativeButton("Cancel",null).show();}
    private void clearSpecialGuest(){if(!host||specialGuestId.isEmpty())return;new AlertDialog.Builder(this).setTitle("Special Guest").setMessage("Return this guest to a normal speaker seat?").setPositiveButton("Remove Spotlight",(d,w)->BackendClient.liveSpecialGuest(token(),specialGuestId,true,new ToastCb("Spotlight cleared"))).setNegativeButton("Cancel",null).show();}

    private void confirmLeaveLive(){new AlertDialog.Builder(this).setTitle("Leave Live?").setMessage("Leave this live room?").setPositiveButton("Leave",(d,w)->finish()).setNegativeButton("Stay",null).show();}
    private void confirmEndLive(){
        if(endLiveInProgress||roomEnded)return;
        new AlertDialog.Builder(this).setTitle("End Live?").setMessage("This will end the room for everyone.")
                .setPositiveButton("End Live",(d,w)->endHostLive()).setNegativeButton("Cancel",null).show();
    }
    private void endHostLive(){
        if(endLiveInProgress||roomEnded)return;
        endLiveInProgress=true;hostStarted=false;
        if(speakerActionButton!=null){speakerActionButton.setEnabled(false);speakerActionButton.setText("ENDING…");speakerActionButton.setAlpha(.72f);}
        if(onlineCountView!=null){onlineCountView.setEnabled(false);onlineCountView.setAlpha(.45f);}
        handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);handler.removeCallbacks(realtimeTick);handler.removeCallbacks(presenceTick);handler.removeCallbacks(participantTick);
        stopVoiceMonitor(false);
        if(rtcManager!=null)rtcManager.leave();
        syncState.setText("Ending live…");
        if(premiumStrip!=null)premiumStrip.setText("Ending live…");
        // One tap is authoritative, but keep this Activity alive until the server confirms close
        // so the Host End Summary can always be rendered before leaving the room.
        endHostLiveAttempt(1);
    }
    private void endHostLiveAttempt(final int attempt){
        if(roomEnded)return;
        BackendClient.endLive(token(),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                if(roomEnded)return;
                if(!d.optBoolean("closed",false)){
                    handler.postDelayed(()->endHostLiveAttempt(attempt+1),Math.min(3000L,500L+attempt*350L));
                    return;
                }
                roomEnded=true;endLiveInProgress=false;hostStarted=false;
                handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);handler.removeCallbacks(realtimeTick);handler.removeCallbacks(presenceTick);handler.removeCallbacks(participantTick);pendingComments.clear();
                final JSONObject closeSummary=d.optJSONObject("summary");
                // V-392: /live/end already returns the authoritative history row. Show it
                // immediately instead of waiting on a second network request that can hide/delay summary.
                if(closeSummary!=null){showSummary(closeSummary);return;}
                BackendClient.liveSummary(token(),hostId,new BackendClient.Callback(){
                    public void onSuccess(JSONObject ss){runOnUiThread(()->{JSONObject x=ss.optJSONObject("summary");if(x!=null)showSummary(x);else showLocalHostEndSummary();});}
                    public void onError(String m){runOnUiThread(()->showLocalHostEndSummary());}
                });
            });}
            public void onError(String m){
                if(roomEnded)return;
                // One tap is enough: keep retrying automatically. Do not return the room to LIVE/Reconnecting.
                handler.postDelayed(()->endHostLiveAttempt(attempt+1),Math.min(4000L,650L+attempt*450L));
            }
        });
    }
    private void endLiveFailed(String message){
        // V-311 compatibility method: never re-activate an End request.
        if(roomEnded)return;endLiveInProgress=true;hostStarted=false;syncState.setText("Ending live…");
        handler.postDelayed(()->endHostLiveAttempt(1),1200L);
    }
    private void showLocalHostEndSummary(){
        // V-394 guaranteed host summary fallback. The authoritative server summary is preferred,
        // but the Host never loses the end screen because a second network read failed.
        JSONObject x=new JSONObject();
        try{
            long duration=Math.max(0,serverElapsedSec+(System.currentTimeMillis()-serverElapsedSyncMs)/1000L);
            x.put("duration_seconds",duration).put("peak_viewers",Math.max(currentPeakViewers,currentViewerCount))
             .put("total_listeners",Math.max(currentTotalListeners,currentViewerCount)).put("react_count",Math.max(0,reactCount));
        }catch(Exception ignored){}
        showSummary(x);
    }

    private void showClosedWithoutSummary(String message){
        roomEnded=true;endLiveInProgress=false;syncState.setText("Live ended • server confirmed");hostStarted=false;
        handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);handler.removeCallbacks(realtimeTick);handler.removeCallbacks(presenceTick);handler.removeCallbacks(participantTick);pendingComments.clear();
        new AlertDialog.Builder(this).setTitle("Live ended").setMessage(message).setPositiveButton("DONE",(d,w)->finish()).setCancelable(false).show();
    }

    private void showSummary(JSONObject x){
        if(x==null){showClosedWithoutSummary("The room is closed.");return;}
        endedSummaryShown=true;
        JSONArray top=x.optJSONArray("topSupporters");if(top!=null)currentTopSupporters=top;
        showPremiumSummaryDialog(x,true);
    }

    private TextView summaryCard(String icon,String label,String value,int accent){
        TextView v=t(icon+"\n"+value+"\n"+label,11.2f,Color.WHITE,true);v.setGravity(Gravity.CENTER);v.setPadding(dp(4),dp(7),dp(4),dp(7));v.setBackground(gradient(new int[]{Color.argb(238,18,34,83),Color.argb(238,60,35,111)},accent,16));v.setElevation(dp(3));return v;
    }

    private void showPremiumSummaryDialog(JSONObject x,boolean ended){
        long duration=Math.max(0,x.optLong("duration_seconds",x.optLong("elapsedSeconds",0)));
        long peak=Math.max(0,x.optLong("peak_viewers",x.optLong("peakViewers",currentPeakViewers)));
        long listeners=Math.max(0,x.optLong("total_listeners",x.optLong("totalListeners",currentTotalListeners)));
        long reactions=Math.max(0,x.optLong("react_count",x.optLong("reactCount",reactCount)));
        long coin=x.optLong("totalCoinGift",0),gold=x.optLong("totalGoldGift",0),giftCount=x.optLong("giftCount",currentHostStats==null?0:currentHostStats.optLong("totalGift",0));
        LinearLayout box=col();box.setPadding(dp(10),dp(10),dp(10),dp(10));box.setBackground(gradient(new int[]{Color.rgb(8,18,55),Color.rgb(45,24,91)},Color.rgb(121,96,255),24));
        TextView title=t(ended?"✨ LIVE SUMMARY":"⚡ LIVE SUMMARY",20,Color.WHITE,true);title.setGravity(Gravity.CENTER);box.addView(title,new LinearLayout.LayoutParams(-1,dp(44)));
        String summaryHostName=currentLiveName;JSONObject hs=findSeat(currentSeats,1);if(hs!=null){String actual=hs.optString("full_name","");if(!actual.trim().isEmpty())summaryHostName=actual;}if(summaryHostName==null||summaryHostName.trim().isEmpty())summaryHostName="MY SHOP User";
        final String summaryHostNameFinal=summaryHostName;
        TextView sub=t(summaryHostNameFinal+"  •  ID "+hostId+"  •  "+(ended?"Ended":"Running"),10,Color.rgb(203,216,255),true);sub.setGravity(Gravity.CENTER);sub.setOnClickListener(v->{JSONObject hp=hs;if(hp==null){hp=new JSONObject();try{hp.put("user_id",hostId).put("full_name",summaryHostNameFinal);}catch(Exception ignored){}}showMiniProfile(hp);});box.addView(sub,new LinearLayout.LayoutParams(-1,dp(28)));
        LinearLayout row1=row();String[][] cards={{"⏱","Duration",hhmmss(duration)},{"📈","Peak",String.valueOf(peak)},{"🎧","Listeners",String.valueOf(listeners)}};int[] ac={Color.rgb(92,205,255),Color.rgb(184,104,255),Color.rgb(255,118,185)};for(int i=0;i<3;i++){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(92),1);lp.setMargins(dp(3),dp(3),dp(3),dp(3));row1.addView(summaryCard(cards[i][0],cards[i][1],cards[i][2],ac[i]),lp);}box.addView(row1);
        LinearLayout row2=row();String[][] more={{"🎁","Gifts",compact(giftCount)},{"🪙","Coin",compact(coin)},{"🟡","Gold",compact(gold)},{"❤️","Reacts",compact(reactions)}};for(int i=0;i<4;i++){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(86),1);lp.setMargins(dp(2),dp(3),dp(2),dp(3));row2.addView(summaryCard(more[i][0],more[i][1],more[i][2],Color.rgb(255,203,76)),lp);}box.addView(row2);
        TextView top=t("🏆 TOP GIFTERS • 1–20",14.5f,Color.rgb(255,225,135),true);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(8),0,0,0);box.addView(top,new LinearLayout.LayoutParams(-1,dp(38)));
        ScrollView sc=new ScrollView(this);LinearLayout rows=col();sc.addView(rows,new ScrollView.LayoutParams(-1,-2));JSONArray arr=x.optJSONArray("topSupporters");if(arr==null)arr=currentTopSupporters;int n=arr==null?0:Math.min(20,arr.length());if(n==0){TextView empty=t("No gifts in this Live yet",11,Color.rgb(194,205,238),true);empty.setGravity(Gravity.CENTER);rows.addView(empty,new LinearLayout.LayoutParams(-1,dp(72)));}for(int i=0;i<n;i++){JSONObject g=arr.optJSONObject(i);if(g==null)continue;int rank=i+1;LinearLayout rr=row();rr.setGravity(Gravity.CENTER_VERTICAL);rr.setPadding(dp(7),dp(4),dp(7),dp(4));rr.setBackground(bg(rank<=3?Color.argb(235,59,36,92):Color.argb(220,12,28,72),rank==1?Color.rgb(255,210,74):rank==2?Color.rgb(203,215,236):rank==3?Color.rgb(222,153,92):Color.rgb(73,102,178),14));TextView rk=t(rank==1?"👑 #1":rank==2?"🥈 #2":rank==3?"🥉 #3":"#"+rank,10.5f,Color.WHITE,true);rk.setGravity(Gravity.CENTER);rr.addView(rk,new LinearLayout.LayoutParams(dp(52),dp(48)));FrameLayout av=circleAvatar(g.optString("avatar_url",""),dp(40),false);rr.addView(av,new LinearLayout.LayoutParams(dp(40),dp(40)));LinearLayout meta=col();meta.setPadding(dp(7),0,0,0);TextView nm=t(g.optString("full_name","Supporter")+" • ID "+g.optString("sender_id","")+" • LV."+g.optInt("level",0),9.6f,Color.WHITE,true);nm.setSingleLine(true);meta.addView(nm,new LinearLayout.LayoutParams(-1,dp(22)));long gc=g.optLong("coin_value",g.optLong("total",0)),gg=g.optLong("gold_value",0);TextView vl=t("🪙 "+compact(gc)+" Coin   •   🟡 "+compact(gg)+" Gold   •   🎁 "+g.optLong("gift_count",0),8.8f,Color.rgb(221,229,255),false);vl.setSingleLine(true);meta.addView(vl,new LinearLayout.LayoutParams(-1,dp(20)));rr.addView(meta,new LinearLayout.LayoutParams(0,dp(46),1));final JSONObject supporter=g;rr.setClickable(true);rr.setFocusable(true);rr.setOnClickListener(v->showMiniProfile(supporter));PremiumUi.press(rr);rows.addView(rr,new LinearLayout.LayoutParams(-1,dp(56)));}
        box.addView(sc,new LinearLayout.LayoutParams(-1,Math.min(dp(360),dp(74)+n*dp(56))));
        AlertDialog dlg=new AlertDialog.Builder(this).setView(box).setPositiveButton(ended?"DONE":"CLOSE",(d,w)->{if(ended)finish();}).setNeutralButton("MY RECEIPT",(d,w)->showMyGiftReceipt()).setNegativeButton("SHARE",(d,w)->shareSummaryText(x)).setCancelable(!ended).create();dlg.setOnShowListener(d->{android.view.Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.95f),-2);}});dlg.show();
    }

    private void showMyGiftReceipt(){
        String me=SessionManager.getUserId(this);long coin=0,gold=0,count=0;if(currentTopSupporters!=null)for(int i=0;i<currentTopSupporters.length();i++){JSONObject g=currentTopSupporters.optJSONObject(i);if(g!=null&&me.equals(g.optString("sender_id",""))){coin=g.optLong("coin_value",0);gold=g.optLong("gold_value",0);count=g.optLong("gift_count",0);break;}}
        new AlertDialog.Builder(this).setTitle("🎁 My Live Gift Receipt").setMessage("MY SHOP ID "+me+"\n\n🪙 Coin gifted  "+compact(coin)+"\n🟡 Gold Coin gifted  "+compact(gold)+"\n🎁 Gifts sent  "+count).setPositiveButton("Close",null).show();
    }

    private void shareSummaryText(JSONObject x){
        Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,"MY SHOP Live Summary • Host "+hostId+" • Duration "+hhmmss(x.optLong("duration_seconds",0))+" • Peak "+x.optLong("peak_viewers",0)+" • Listeners "+x.optLong("total_listeners",0)+" • Top Gifters 1–20");startActivity(Intent.createChooser(send,"Share Live Summary"));
    }

    private void renderPremiumState(JSONObject d){
        if(d==null||premiumStrip==null)return;
        String tier=d.optString("myTier",d.optString("membershipTier","")).trim();
        String role=d.optString("myRole",host?"HOST":"AUDIENCE");
        String net=networkQuality();
        StringBuilder line=new StringBuilder("⚡ LIVE AUDIO • ").append(role).append(" • ").append(net).append(" • ").append(rtcAudioIndicator());
        if(!tier.isEmpty()&&!"FREE".equalsIgnoreCase(tier))line.append(" • ").append(tier);
        premiumStrip.setText(line.toString());premiumStrip.setVisibility(View.VISIBLE);
    }

    private JSONObject findSeat(JSONArray a,int seatNo){if(a==null)return null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&x.optInt("seat_no")==seatNo)return x;}return null;}
    private JSONObject findUser(JSONArray a,String userId){if(a==null||userId==null||userId.isEmpty())return null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&userId.equals(x.optString("user_id")))return x;}return null;}

    private boolean isRtcSpeaking(JSONObject x,boolean hostAvatar){
        if(System.currentTimeMillis()-activeRtcSpeakerAt>900L)return false;
        if(activeRtcSpeakerUid<0)return false;
        if(activeRtcSpeakerUid==0)return (hostAvatar&&host)||(!hostAvatar&&x!=null&&SessionManager.getUserId(this).equals(x.optString("user_id","")));
        String uid=x==null?(hostAvatar?hostId:""):x.optString("user_id",hostAvatar?hostId:"");
        try{return Integer.parseInt(uid)==activeRtcSpeakerUid;}catch(Exception ignored){return false;}
    }

    private FrameLayout avatarWithMicState(JSONObject x,int size,boolean speaking){
        FrameLayout wrap=new FrameLayout(this);
        String url=x==null?"":x.optString("avatar_url","");
        String tier=x==null?"STANDARD":x.optString("tier","STANDARD");
        FrameLayout av=circleAvatar(url,size,speaking,tier,x==null?"":MembershipUi.isTier(tier)?x.optString("membership_frame_url",""):x.optString("frame_url",""));wrap.addView(av,new FrameLayout.LayoutParams(-1,-1));
        boolean muted=x!=null&&(x.optInt("mic_on",1)==0||x.optInt("muted",0)==1);
        if(muted){TextView m=t("🎙✕",Math.max(6.8f,size/7.0f),Color.rgb(255,82,94),true);m.setGravity(Gravity.CENTER);m.setBackground(bg(Color.argb(225,45,10,24),Color.rgb(255,70,84),9));FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(24),dp(16),Gravity.RIGHT|Gravity.BOTTOM);mp.rightMargin=-dp(2);mp.bottomMargin=-dp(1);wrap.addView(m,mp);}
        else if(speaking){TextView m=t("🎙",Math.max(7.2f,size/7.0f),Color.WHITE,true);m.setGravity(Gravity.CENTER);m.setBackground(bg(Color.rgb(38,194,104),Color.rgb(255,230,118),10));FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(22),dp(18),Gravity.RIGHT|Gravity.BOTTOM);mp.rightMargin=-dp(2);mp.bottomMargin=-dp(1);wrap.addView(m,mp);}
        if(x!=null&&isTopGifter(x.optString("user_id",""))){TextView crown=t("👑",Math.max(8f,size/6.4f),Color.WHITE,true);crown.setGravity(Gravity.CENTER);crown.setBackground(bg(Color.argb(220,91,58,10),Color.rgb(255,214,75),10));FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(23),dp(18),Gravity.LEFT|Gravity.TOP);cp.leftMargin=-dp(2);cp.topMargin=-dp(2);wrap.addView(crown,cp);}
        return wrap;
    }

    private boolean isTopGifter(String uid){
        if(uid==null||uid.isEmpty()||currentTopSupporters==null||currentTopSupporters.length()==0)return false;
        JSONObject top=currentTopSupporters.optJSONObject(0);return top!=null&&uid.equals(top.optString("sender_id",""));
    }

    private FrameLayout circleAvatar(String url,int size,boolean speaking){return circleAvatar(url,size,speaking,"STANDARD","");}
    private FrameLayout circleAvatar(String url,int size,boolean speaking,String tier){return circleAvatar(url,size,speaking,tier,"");}
    private FrameLayout circleAvatar(String url,int size,boolean speaking,String tier,String frameUrl){
        FrameLayout frame=new FrameLayout(this);frame.setClipChildren(false);frame.setClipToPadding(false);int premiumStroke="KING".equalsIgnoreCase(tier)?Color.rgb(255,182,46):"QUEEN".equalsIgnoreCase(tier)?Color.rgb(255,78,180):"ROYAL".equalsIgnoreCase(tier)?Color.rgb(166,91,255):"VVIP".equalsIgnoreCase(tier)?Color.rgb(52,205,255):"VIP".equalsIgnoreCase(tier)?Color.rgb(83,224,126):Color.rgb(153,132,255);
        int stroke=speaking?Color.rgb(255,214,84):premiumStroke;frame.setBackground(bg(Color.argb(210,25,33,82),stroke,size/2));
        ImageView v=new ImageView(this);v.setImageResource(android.R.drawable.sym_def_app_icon);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(bg(Color.rgb(34,45,105),stroke,size/2));v.setClipToOutline(true);
        boolean premiumTier=tier!=null&&!tier.trim().isEmpty()&&!"STANDARD".equalsIgnoreCase(tier)&&!"FREE".equalsIgnoreCase(tier);
        int pad=dp(premiumTier?5:3);FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,-1);ip.setMargins(pad,pad,pad,pad);frame.addView(v,ip);
        if(url!=null&&!url.trim().isEmpty())loadImage(v,url);
        if(frameUrl!=null&&!frameUrl.trim().isEmpty()&&!premiumTier){ImageView premiumFrame=new ImageView(this);premiumFrame.setScaleType(ImageView.ScaleType.FIT_CENTER);premiumFrame.setAdjustViewBounds(false);premiumFrame.setContentDescription("Equipped Live premium profile frame");FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(-1,-1);fp.setMargins(dp(1),dp(1),dp(1),dp(1));frame.addView(premiumFrame,fp);AnimatedAssetLoader.load(premiumFrame,frameUrl,true);}if(premiumTier&&!MembershipUi.isTier(tier)){TextView aura=t(liveMembershipCrest(tier),Math.max(15f,size/3.0f),Color.WHITE,true);aura.setGravity(Gravity.CENTER);aura.setTextColor(premiumStroke);aura.setShadowLayer(dp(8),0,0,premiumStroke);aura.setBackground(bg(Color.TRANSPARENT,premiumStroke,size/2));FrameLayout.LayoutParams af=new FrameLayout.LayoutParams(-1,-1);af.setMargins(dp(1),dp(1),dp(1),dp(1));frame.addView(aura,af);ObjectAnimator pulse=ObjectAnimator.ofFloat(aura,"alpha",.38f,1f,.38f);pulse.setDuration(1250);pulse.setRepeatCount(ValueAnimator.INFINITE);pulse.start();aura.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View x){}public void onViewDetachedFromWindow(View x){pulse.cancel();}});}
        if(premiumTier&&!MembershipUi.isTier(tier)){TextView crest=t(liveMembershipCrest(tier)+" "+tier.toUpperCase(Locale.US),Math.max(6.6f,size/8.2f),Color.WHITE,true);crest.setGravity(Gravity.CENTER);crest.setShadowLayer(dp(4),0,0,premiumStroke);crest.setBackground(bg(Color.argb(232,19,18,47),premiumStroke,10));FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(Math.max(34,size/1.45f)),dp(Math.max(16,size/4)),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);cp.bottomMargin=-dp(3);frame.addView(crest,cp);}
        if(MembershipUi.isTier(tier)){v.setAlpha(0f);MembershipIdentityView memberView=new MembershipIdentityView(this,tier,url);memberView.setFrameAsset(frameUrl);frame.addView(memberView,new FrameLayout.LayoutParams(-1,-1));}
        // Speaking effect animates only the ring/glow. The profile photo itself stays perfectly still.
        if(speaking){TextView ring=t("",1,Color.TRANSPARENT,false);ring.setBackground(bg(Color.TRANSPARENT,Color.rgb(255,221,102),size/2));FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(-1,-1);rp.setMargins(dp(1),dp(1),dp(1),dp(1));frame.addView(ring,rp);ObjectAnimator glow=ObjectAnimator.ofFloat(ring,"alpha",.22f,1f,.22f);glow.setDuration(520);ObjectAnimator gx=ObjectAnimator.ofFloat(ring,"scaleX",1.02f,1.34f,1.02f);gx.setDuration(620);gx.setRepeatCount(ValueAnimator.INFINITE);gx.start();ObjectAnimator gy=ObjectAnimator.ofFloat(ring,"scaleY",1.02f,1.34f,1.02f);gy.setDuration(620);gy.setRepeatCount(ValueAnimator.INFINITE);gy.start();glow.setRepeatCount(ValueAnimator.INFINITE);glow.start();ring.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View x){}public void onViewDetachedFromWindow(View x){glow.cancel();gx.cancel();gy.cancel();}});}
        return frame;
    }
    private String liveMembershipCrest(String tier){String x=tier==null?"":tier.trim().toUpperCase(Locale.US);if("KING".equals(x))return "♛";if("QUEEN".equals(x))return "♕";if("ROYAL".equals(x))return "✦";if("VVIP".equals(x))return "◆";if("VIP".equals(x))return "❖";return "★";}

    private void loadImage(ImageView v,String u){Bitmap cached=avatarCache.get(u);if(cached!=null){v.setImageBitmap(cached);return;}new Thread(()->{try{Bitmap b=BitmapFactory.decodeStream(new URL(u).openStream());if(b!=null){synchronized(avatarCache){avatarCache.put(u,b);while(avatarCache.size()>80){String k=avatarCache.keySet().iterator().next();avatarCache.remove(k);}}runOnUiThread(()->v.setImageBitmap(b));}}catch(Exception ignored){}}).start();}

    private String networkQuality(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);NetworkInfo n=cm==null?null:cm.getActiveNetworkInfo();if(n==null||!n.isConnected())return "OFFLINE";return n.getType()==ConnectivityManager.TYPE_WIFI?"GOOD":"FAIR";}catch(Exception e){return "GOOD";}}
    private String signal(String q){q=q==null?"GOOD":q.toUpperCase();if("WEAK".equals(q)||"OFFLINE".equals(q))return "▂";if("FAIR".equals(q))return "▂▄";return "▂▄▆";}
    private long parseServerTime(String s){if(s==null||s.trim().isEmpty())return 0;String[] patterns={"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd'T'HH:mm:ss.SSS'Z'","yyyy-MM-dd'T'HH:mm:ss'Z'"};for(String p:patterns){try{SimpleDateFormat f=new SimpleDateFormat(p,Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));Date d=f.parse(s);if(d!=null)return d.getTime();}catch(Exception ignored){}}return 0;}
    private String summaryTime(String s){if(s==null||s.trim().isEmpty())return "—";String x=s.trim();return x.length()>=19?x.substring(11,19):x;}
    private String hhmm(long sec){long h=sec/3600,m=(sec%3600)/60;return String.format(Locale.US,"%02d:%02d",h,m);}
    private String hhmmss(long sec){long h=sec/3600,m=(sec%3600)/60,s=sec%60;return String.format(Locale.US,"%02d:%02d:%02d",h,m,s);}
    private String token(){return SessionManager.getToken(this);}

    @Override public void onBackPressed(){
        if(!roomEnded && !endLiveInProgress && Build.VERSION.SDK_INT>=26){
            try{PictureInPictureParams params=new PictureInPictureParams.Builder().setAspectRatio(new Rational(9,16)).build();enterPictureInPictureMode(params);return;}catch(Exception ignored){}
        }
        moveTaskToBack(true);
    }
    @Override protected void onDestroy(){entrySound430.stop();handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);handler.removeCallbacks(realtimeTick);handler.removeCallbacks(presenceTick);handler.removeCallbacks(participantTick);if(joinPulseAlpha!=null)joinPulseAlpha.cancel();if(joinPulseX!=null)joinPulseX.cancel();if(joinPulseY!=null)joinPulseY.cancel();joinPulseAlpha=null;joinPulseX=null;joinPulseY=null;activeSessionId="";serverElapsedSec=0;serverElapsedSyncMs=0;pendingComments.clear();stopVoiceMonitor(false);if(rtcManager!=null){rtcManager.destroy();rtcManager=null;}if(giftLoadingDialog!=null&&giftLoadingDialog.isShowing())giftLoadingDialog.dismiss();if(giftStoreDialog!=null&&giftStoreDialog.isShowing())giftStoreDialog.dismiss();if(isFinishing()&&!roomEnded&&!host){BackendClient.liveLeaveSeat(token(),hostId,new Silent());BackendClient.liveViewer(token(),hostId,false,new Silent());}super.onDestroy();}


    private class GoldenGuestHalo extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF oval=new RectF();
        GoldenGuestHalo(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f;float r=Math.min(w,h)*.36f;
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2.2f));p.setColor(Color.rgb(255,194,47));p.setShadowLayer(dp(8),0,0,Color.rgb(255,139,22));c.drawCircle(cx,cy,r,p);p.clearShadowLayer();
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(255,190,42));
            for(int side=-1;side<=1;side+=2){for(int i=0;i<7;i++){float y=cy-r*.72f+i*r*.24f;float x=cx+side*(r+dp(5)+i*dp(.7f));c.save();c.rotate(side*(-32+i*5),x,y);oval.set(x-dp(5),y-dp(2.3f),x+dp(5),y+dp(2.3f));c.drawOval(oval,p);c.restore();}}
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));p.setColor(Color.rgb(255,221,97));oval.set(cx-r-dp(10),cy+r*.66f,cx+r+dp(10),cy+r+dp(12));c.drawArc(oval,188,164,false,p);
            // V-384: no crown on the center guest/guest profile; keep only the premium golden halo.
        }
    }

    class ToastCb implements BackendClient.Callback{String ok;ToastCb(String s){ok=s;}public void onSuccess(JSONObject d){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,ok,Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}}
    static class Silent implements BackendClient.Callback{public void onSuccess(JSONObject d){}public void onError(String m){}}

    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private Button btn(String s){Button b=new Button(this);b.setAllCaps(false);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);PremiumUi.premiumAccent(b);return b;}
    private Button small(String s){Button b=btn(s);b.setTextSize(9.5f);b.setMinWidth(0);b.setMinimumWidth(0);return b;}
    private TextView t(String s,float z,int c,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private GradientDrawable bg(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private GradientDrawable gradient(int[] colors,int stroke,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private GradientDrawable softGradient(int[] colors,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(radius));return g;}
    private int dp(float x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
}
