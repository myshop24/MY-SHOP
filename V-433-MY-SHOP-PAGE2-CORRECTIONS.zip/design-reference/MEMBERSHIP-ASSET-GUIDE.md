# Membership ornament template

Use transparent PNG / animated WebP / GIF, canvas 320×275 (or an exact multiple). Do not bake any person's face into the image. Keep the circular avatar window transparent.

| Tier | Window centre x,y | Radius |
|---|---:|---:|
| KING | 166,139 | 83 |
| QUEEN | 165,141 | 84 |
| ROYAL | 168,136 | 85 |
| VVIP | 168,141 | 88 |
| VIP | 168,139 | 88 |

The app puts the signed-in / selected user's actual photo behind that window. Its independent sparkle layer is lifecycle-bound. Animated image playback depends on platform decoding; the native light layer remains the built-in motion. No full-card bouncing is used. For updated remote assets publish a NEW URL/object version, not a stale cached URL.

The included Home Page 2 WebP is a reduced-size 512×768 copy of the approved 1024×1536 DESIGN reference (original conversation upload: 126807.jpg). It is not a screenshot of V-430 running on Android. Use the original upload for full-resolution pixel comparison.
