# MY SHOP — V-430 developer handoff

## Identity / scope
MY SHOP V-430, versionCode 430, versionName 2.9.430. Corrected source, NOT a verified APK.
Baseline is the uploaded V-429 package, whose internal app/Worker identities were still 428/427. These are now aligned at 430. Only the latest 25 correction scope is addressed; the earlier 251-item idea list is not claimed implemented.

## Completed source work
- `PageIconAdminActivity` is now a real four-column long-press drag grid. Moving inserts the selected stable key and shifts intervening items. Published items are grouped first so visible slot numbers match Home/See All; hidden tiles remain editable below. Unsaved edits remain local until Save Order, and failed publishing retains the draft. Feature-button writes use an atomic D1 batch with order validation.
- Home 1 Quick Links is a horizontal row; Home/See All use the same persisted `display_order`. Membership navigation points to the real MEMBER catalog. Existing Home 1 shell/feed/nav are not replaced.
- `LiveHomeActivity` uses a compact bright background, constrained banner height, four equal-width promo folders, horizontal live/category/people rows, three adjacent challenge/event/spotlight cards and three compact star cards. Original top-header/bottom-navigation method text remains byte-identical. The star section retains its existing discovery-data source; this release does not invent a new weekly ranking calculation.
- Main ads load 0–6 actual published slots, support manual horizontal gestures + auto rotation, pause auto scheduling during touch, retain ordering and replace obsolete cached state even when the server list becomes empty. No default deleted ad is re-seeded.
- Four product-ad folders `live2_promo_1`…`live2_promo_4` each have independent six-slot Add/Replace/Edit/Disable/Delete/link controls. Folder names/positions/visibility are persisted separately. New banners require real Admin assets; reference mock product promotions are not fake production listings.
- Page 2 category See All reads the same saved labels/order/active state/custom entries as the dashboard, including added icons. The Events entry opens managed event announcements instead of a category fallback.
- One-time, transactional V-430 membership install uses NEW `MS430_*` catalog identities. A schema marker prevents re-insertion of subsequently deleted items. Old catalog removals are respected. The five default packages retain editable 5,000 Gold / 30-day initial pricing.
- `MembershipIdentityView` composites the actual user avatar into a face-free ornament. Only the light layer animates; the whole membership card is not scaled up/down. KING / QUEEN / ROYAL / VVIP / VIP have distinct native ornament assets and matching comment presets.
- Admin-edited compatible transparent PNG/WebP/GIF ornaments flow from catalog to preview/Profile/Live seats/viewers. Legacy standalone video frames are intentionally not used as profile cut-outs; they cannot safely preserve the centre photo in this image compositor. Use the documented transparent image template. Other Ride/Entry videos remain supported.
- Exact ID search shows the verified recipient name/photo before grant/change/remove. Server roles are checked. Grant atomically replaces the old membership and matching comment assignment; remove disables both. Expiry is enforced by the existing Live-comment configuration read. Editing a V-430 row preserves its persistent catalog code.
- Normal and gifted Premium purchases wait for explicit Admin approval, including rows with the legacy auto-approve flag. Tested normal purchase hold/duplicate request/approval/rejection paths. Admin grants remain distinct from sales.
- Rider previews and Live entries no longer force embedded video sound to zero when no external track is configured. Separate audio uses a managed single-player lifecycle, configured volume/duration, stale-callback guards, error reporting, and video-prepared synchronization. Muted volume stays muted. A silent source clip still needs an Admin-supplied soundtrack; this release does not fabricate audio or change RTC capture settings.

## Real evidence available
`verification/v430/backend-tests.txt`: 31 tests against shipped Worker functions and real in-memory SQLite transactions. Auth identities, R2 and notifications are explicit test doubles; no real account/balance/production DB was touched.
`slot-layout-tests.txt`: 4,900 actual `SlotOrder.move` cases + invalid-index guards, and 40 `Home2Metrics` width cases.
`java-syntax.txt`: 99 Java files parsed with the JDK compiler parser, NOT Android type checking.
`source-guards.txt`: 96 XML files parse; resource references resolve; manifest/identity/route guards pass.
`source-preservation.json`: baseline hashes, unchanged files, preserved RTC manager/CI/Worker bindings/header/nav source.

## Pending release gates (NOT run)
1. Full clean Android compile and dependency resolution; signed APK creation with the user's existing signing key.
2. Measured Android screenshots versus `design-reference/HOME-PAGE-2-APPROVED-REFERENCE.webp`. The source is a native approximation of the compact approved design; pixel-identical runtime rendering has NOT been certified.
3. Physical gestures: icon move 1→last/last→1/middle, save/error/cancel, Home + See All + another device + restart. Verify scroll and long-press do not conflict.
4. Six real main ads and all four × six product ads: touch, auto rotation, tap links, disable/delete/reload. Test actual R2 uploads.
5. Five actual memberships: no old portrait inside frame; actual profile photo; real Live comments; approval/hold/refund/direct grant/change/remove/expiry; user role cannot access Admin controls.
6. Two-device Rider audio with actual sound-containing video/external audio, 0/50/100 volume, duration, close/reopen, unavailable file. Confirm host and guest speech remains clear.
7. Full regression: host/seat state, realtime comments (ephemeral), gifts, invite/join, mute/unmute, Back/minimize, end/exit, Store, Page 1, login, admin, wallet ledgers.
8. Verify production Worker health, source/build ID, commit SHA, timestamp and APK hash from the exact clean run. Source comparisons and local tests are not production certification.

## Last checkpoint / next tasks
Source fixes and local tests complete. Deploy matching Worker with existing bindings, build APK with the existing CI pipeline, then execute pending device gates. Do not label the package as all 251 features finished or publish an APK as fully verified from these source tests alone.

## Known limitations / guardrails
- Existing CI invokes installed Gradle 8.11.1; absence of `gradlew` is NOT itself a blocker. Complete local Android SDK/Gradle/dependency/signing toolchain was not available for this handoff.
- The compact Home 2 body budget is about 0.60–0.62k dp; smaller viewports / large accessibility fonts may legitimately scroll. Touch targets, text visibility and safe areas must win over blindly shrinking all screens.
- Five built-in membership identities are supported in this correction. New arbitrary tier template engines are not introduced. Admin can edit the display title of an existing identity; broader new tier designs need paired frame/comment templates.
- Native comment preview uses the tier's base palette; final Admin-customized comment style should be confirmed in the Live room. This is not a live Android preview renderer.
- No licensed sound packs, production ad artwork or real product inventory are invented.
- End-to-end transaction concurrency, network outages and production limits are not established by sequential SQLite tests.
- Keep exactly one highest-version source ZIP in the ZIP-selection build workflow. No new signing key, D1 reset, data wipe, default-item resurrection or unrelated module rewrite.


## V-433 correction scope
- Home Page 2 main advertising banner display: full available content width; old fixed 1200×280 / 4.3:1 display recommendation removed from Page 2 Admin.
- Live Now old blank wording replaced with persistent Upcoming Live / Go Live fallback state.
- Promotional folders remain functional product folders; each supports up to six Store-product promotions through existing Page 2 Admin/backend path.
- Quick Links final layout requirement: 5 icons per row × 2 rows visible, overflow horizontal; Admin long-press drag/drop + Save Order remains authoritative.
- Membership identity rule: catalog must use neutral demo identity; user photo is only for user Preview/owned active identity, and selected-user photo for Admin Grant preview.
- Page 2 compact premium 3D icon/glow visual rule is locked; do not replace with large emoji cards.
- GO LIVE/JOIN LIVE: icon/light/glow may animate; entire button must not jump.
- Preserve all unrelated working modules.
