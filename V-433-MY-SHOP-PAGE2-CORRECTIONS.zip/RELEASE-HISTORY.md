## V-396 — One-APK Root Pipeline Packaging Fix
- User-facing GitHub artifact contains only `MY_SHOP_FINAL_RELEASE.apk`; verification metadata stays internal.
- V-395 Home/Page2/Admin implementation preserved; protected Live/Wallet files unchanged.

## V-395 — Home Page 1 + Page 2 Admin/Visual Reference Implementation
- See V-395_RELEASE_NOTES.md and MY-SHOP-DEVELOPER-HANDOFF.md.

# V-392 — Live Realtime / Audio / Gift Reliability Fix
- Cross-client seat/join state recovery hardened and fallback sync accelerated.
- Agora publisher/playback role recovery fixed, including invite-accept audience→speaker promotion.
- Join action visibility improved; successful speaker joins are announced to every refreshed client.
- Host End Summary displays immediately from authoritative `/live/end` response.
- Gift realtime revision + D1 recovery added to prevent sender-only effects.
- Live Name/Caption made atomic at session start and preferred in live discovery display.
- Identity advanced to 392 / 2.9.392.

# V-391 — Compile Hotfix
- Full source carried forward from V-390.
- Fixed missing `android.view.ViewGroup` import in `AudioLiveRoomActivity.java`.
- Advanced release identity to 391 / 2.9.391.
- No functional redesign.

# MY SHOP RELEASE HISTORY — RECOVERY INDEX

- V-327: Premium Gift Admin Catalog baseline; source used for V-328.
- V-328: Premium Experience + Stability Foundation. Shared PremiumUi, Live Hub/Room polish, gap-free live-comment acknowledgement, Feature/Chat/Inbox polish, existing FCM notification presentation refinement, Master State recovery system added.

Rule: Never delete this file. Append each future V-number with scope, base version, key modified modules, regression status and rollback source.

## V-330
Coin & Gold Coin Catalog admin completion pass: navigation disambiguation, full Gift Studio lock/preservation, separate COIN/GOLD finance summary, version 2.9.330. Runtime acceptance pending CI/device.

## V-352
Base V-351. Live stabilization pass: D1 full-room polling reduced from sub-second to 12-second reconciliation; temporary Live comments/highlights and gift delivery use a per-room Durable Object realtime hub; join/invite/seat/moderation mutations trigger lightweight dirty signals; additive D1 read indexes added; repeated Agora publish/mic reconfiguration suppressed. Approved V-350/V-351 Live UI and unrelated working modules locked. Runtime Cloud + two-device acceptance pending.
## V-353
Base V-352. Audio-only recovery pass: restored Agora live voice playback/publish application after V-352 idempotency regression; remote audio/speaker route kept active; gift sounds switched to MEDIA/MUSIC playback and no longer steal transient audio focus from RTC. V-352 D1/realtime/comment work and unrelated modules locked. Runtime two-device acceptance pending.


## V-390
Base V-389. Screen-match correction pass: Quick Links clipping/overlay protection; transparent parent strip behind the approved five-color bottom navigation on Home + Live Home; Love React removed from comment rendering; Host End Summary premature-finish bug removed; Inbox accessible from active Live; Live Streaming Home top header aligned to Main Home profile/language/notification/message structure; GitHub final install artifact staged as one APK only. Host top-viewer Call/Invite and production Worker URL/retry behavior preserved. Static source checks PASS; CI/device/production runtime acceptance pending.

## V-405 — Premium Catalog Products + Admin Approval
- User/Admin catalog product cards now visibly populated.
- Approved KING/QUEEN/ROYAL/VVIP/VIP membership previews bundled with matching comment-box visual.
- 50 wallpapers + 30 entry animations visible; Admin controls final assets/prices/duration.
- Admin purchase request approval added; Coin/Gold deduct only after approval.
- Wallpaper drag/drop order persistence added.
- Live-only premium application preserved; My Feed unchanged.

V-406: Live premium profile-fit + visible catalog lock. Premium effects remain Live-only; My Feed untouched.

## V-412 — Premium Gold Safety + Grid Catalog
- Gold Coin-only Premium purchase enforcement.
- Compact visual grid catalog.
- Safe Hold → Approve/Reject flow and Premium Revenue ledger.
- Stuck/Held Gold Admin review.
- White + Red Premium Admin shell and double-confirm Admin Grant.
- Static V-412 guard 37/37 PASS; runtime verification pending.

- V-421: Dedicated Entry / Ride Animation light user GRID + separate Admin route, animation/video + sound controls, Live join Ride playback; regression-scoped.
