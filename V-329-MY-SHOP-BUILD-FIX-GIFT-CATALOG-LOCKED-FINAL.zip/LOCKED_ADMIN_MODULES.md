# MY SHOP — LOCKED ADMIN MODULES (V-329)

## Gift Coin & Gold Coin Catalog — PROTECTED / DO NOT REGRESS
The following approved capabilities must survive every future unrelated version unchanged unless the owner explicitly requests a change:
- Separate Gift Coin and Gold Coin catalog modes.
- Up to 50 gifts per catalog, all visible/manageable.
- Tap gift card to edit.
- Long-press + drag/reorder/position handling.
- Gift name, currency price, category, active/published state.
- Image/preview asset add/replace.
- Live animation asset add/replace.
- Catalog animation asset add/replace + preview/test.
- Sound add/replace from device file/gallery.
- Sound preview/test before save.
- Sound trim/crop start/end selection with waveform guide.
- Sound volume and sound duration controls.
- Gift effect duration and animation board coverage/scale.
- Board position: center/top/bottom/full-screen.
- Per-gift VAT and global VAT apply-all.
- Live-board preview.
- Save/Publish/Delete flows and historical transaction-safe soft delete.

## Regression rule
Unrelated work must not rewrite, simplify, delete, rename, or replace this module. Before release, compare protected files against the previous stable source and investigate any unexpected change.
