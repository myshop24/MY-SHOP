# MY SHOP RELEASE HISTORY — RECOVERY INDEX

- V-327: Premium Gift Admin Catalog baseline; source used for V-328.
- V-328: Premium Experience + Stability Foundation. Shared PremiumUi, Live Hub/Room polish, gap-free live-comment acknowledgement, Feature/Chat/Inbox polish, existing FCM notification presentation refinement, Master State recovery system added.

Rule: Never delete this file. Append each future V-number with scope, base version, key modified modules, regression status and rollback source.
