# MY SHOP V-597 build checkpoint

Source: 2.9.597 / versionCode 597 / com.myshop.app.
Local source/regression checks are recorded in handoffs/MY-SHOP-V597-HANDOFF.md.
No Android SDK or original signing secrets are configured in this environment. No APK was built or substituted.
Upload the extracted complete source to GitHub. Actions → MY SHOP Android APK → Run workflow.
The existing original-signing/Firebase secrets must remain configured. A successful build uploads MY-SHOP-V-597-APK containing MY_SHOP_FINAL_RELEASE.apk.
CI checks the package, version, original signer certificate, APK alignment, unit tests and lint. No production deployment performed.
