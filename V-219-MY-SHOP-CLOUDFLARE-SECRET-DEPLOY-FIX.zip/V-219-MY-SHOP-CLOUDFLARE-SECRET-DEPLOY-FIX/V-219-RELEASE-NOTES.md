# MY SHOP V-219

## Exact fix for GitHub run #290
- Root cause: `wrangler secret put MYSHOP_HEALTH_PROBE_KEY` attempted to create/deploy a secret version while the latest Worker version was not deployed, and Wrangler stopped with `Secret edit failed`.
- Replaced only that failing secret-update mechanism with Cloudflare's supported `wrangler versions upload --secrets-file` flow so the code and required health-probe secret are uploaded into the same Worker version.
- Kept the exact tagged version deployment at 100% traffic.
- Kept the V-218 Java fix unchanged.
- Bumped source/build/Worker markers to V-219.
- No V-211/V-217/V-218 files are overwritten by this package.
