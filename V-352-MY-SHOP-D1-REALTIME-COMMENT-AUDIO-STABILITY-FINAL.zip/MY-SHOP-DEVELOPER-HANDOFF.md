# MY SHOP — DEVELOPER HANDOFF

## Current Release: V-352
- versionCode: 352
- versionName: 2.9.352
- Base: V-351
- Completed in source: D1 Live polling reduction, Durable Object realtime comments/highlights/gifts, realtime state-dirty signals, additive Live read indexes, and idempotent Agora publish/mic updates.
- Locked: approved V-350/V-351 Live UI, seats 2–9, Gift/Coin/Gold/Admin/Join-Invite/End-Live and unrelated modules.
- Pending: Worker deploy + Durable Object migration, D1 migration 0017, GitHub CI compile, Cloudflare usage observation, and two-device comment/audio/regression acceptance.
- Last checkpoint: static source validation and protected-file diff pass.
- Next tasks: deploy Worker/migration -> CI build -> install on two devices -> 20–30 minute Live D1/comment/audio QA -> final Play compliance audit.
- Known constraint: local environment has no Gradle wrapper/system Gradle, so Android compile/runtime is not claimed PASS here.

---


# MY SHOP DEVELOPER HANDOFF — V-349 STABILIZATION

Current version: V-349
Base: V-348 correct source branch (`v348_work`), not the older compact branch that produced the wrong Live runtime.
SOURCE_BUILD_ID: MY SHOP V-349
Android: versionCode 349 / versionName 2.9.349
Worker: version 2.9.349 / build V-349
Golden Live reference: `APPROVED-V349-LIVE-ROOM-FINAL-REFERENCE.png`
Locked scope: `V-349_LOCKED_STABILIZATION_SCOPE.md`

Completed in source: final 8-seat Live layout lock, Main Guest logo/crown, chair empty seats, red borderless Exit, Gift sound hardening, prominent sender Gift comments, Keystore-backed persistent login, system-push client/server diagnostics, obsolete seat asset cleanup, audio-only Agora SDK size stabilization.

Regression lock: do not redesign the approved Live UI or change Coin/Gold economy, Gift Admin/catalog/balance/ledger rules, D1/R2 contracts, Join Request/Host Invite, End Live, comments, PiP, Profile, Dashboard, Admin, Store or navigation unless explicitly requested.

Acceptance status: SOURCE/STATIC PASS; RUNTIME PENDING. A Green build is not Final. The CI-built APK must pass `V-349_REGRESSION_QA.md`. Real FCM push also requires the Firebase GitHub build values and Worker `FCM_SERVICE_ACCOUNT_JSON`; secrets are not included in source.

Last checkpoint: V-349 static validator passed all locked source checks; Worker syntax and Android resource integrity checks passed. Full Android compile/device acceptance is not available in this local environment.

Next: GitHub CI -> install APK -> compare Live screenshot to golden reference -> two-device Gift/audio/login/push/regression QA -> only then production acceptance.

---
# MY SHOP DEVELOPER HANDOFF — V-348

Current version: V-348
Base: V-347
Completed: Final locked Live Room seat/main-guest/exit visual implementation and Gift Sound playback hardening.
Pending acceptance: GitHub CI release build + real-device test of uploaded custom gift sound and RTC coexistence.
Golden UI reference: APPROVED-V348-LIVE-ROOM-FINAL-REFERENCE.png
Regression rule: do not redesign or move the approved Live Room UI while fixing functionality.

# MY SHOP Developer Handoff — V-347

Current version: V-347
SOURCE_BUILD_ID: MY SHOP V-347
Android: versionCode 347 / versionName 2.9.347
Worker health identity: version 2.9.347 / build V-347

Completed: V-346 AAPT resource failure fixed by replacing the mislabeled JPEG-as-PNG empty-seat asset with the user-approved MY SHOP MS image re-encoded as a true PNG. Empty Guest seats use the MS artwork, occupied Guest seats keep real profile photos, and Host rendering has a real-profile fallback. Existing V-346 Live mini/PiP, gift, audio, pin, Exit, Join/Leave, frameless seat and full-screen low-light theme behavior is preserved.

Regression lock: preserve all unrelated working modules/files, RTC token flow, existing seat allocation/count, Join Request/Host Invite, Coin/Gold Coin economy, Gift catalog/ledger/Admin controls, D1/R2 schema/bindings, ephemeral Live comments, Profile, Dashboard, Store, Admin and navigation behavior.

Pending acceptance: run the established GitHub Android CI compile/sign and complete two-device real Live tests before production release.

Last checkpoint: source/static validation passed and the V-346 AAPT root cause was confirmed (`live_empty_seat_myshop.png` contained JPEG/JFIF bytes). V-347 replacement is a valid 1536×1536 RGBA PNG.

Next tasks: GitHub CI build -> signed APK verification -> two-device Live QA -> final Google Play release audit.

Known issues: no known source-level V-347 blocker after the PNG correction; runtime/device acceptance remains required.
