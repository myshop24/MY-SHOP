# MY SHOP DEVELOPER HANDOFF — V-310

## Completed
- Play-safe Coin + Gold Coin architecture introduced.
- Paid Coin/Gold Coin purchase buttons disabled for this Play release.
- Admin Grant remains available for Coin/Gold Coin rewards.
- Admin-granted/reward Coin is spendable-only, not directly cash-withdrawable.
- Live Gift receiver value is credited to separate Creator Earnings.
- Cash Out endpoint reads only Creator Earnings.
- MY SHOP Service Fee is configurable by Admin; default 10%.
- Reference conversion: 100,000 earning units = Tk 600.
- Example: 100,000 gross, 10% Service Fee => 90,000 net => Tk 540.
- bKash/Nagad cash-out request remains MY SHOP-managed and Pending for payout review.
- D1/R2 bindings preserved.

## QA
- Worker JavaScript syntax: PASS.
- Targeted wallet separation checks: PASS.
- Android Java compile: NOT EXECUTED locally because this source package has no Gradle wrapper executable; CI/GitHub build remains required before release.
- Google Play Console declarations and real-device/AAB testing remain manual release gates.

## Critical invariant
Never change withdrawal back to normal Coin/Gold wallet balance. Only Creator Earnings is eligible for Cash Out.
