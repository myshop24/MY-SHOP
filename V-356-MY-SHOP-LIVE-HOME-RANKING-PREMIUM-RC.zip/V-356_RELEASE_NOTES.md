# MY SHOP V-356 Release Notes

- Version identity: V-356
- Android versionCode: 356
- Android versionName: 2.9.356
- Content/functionality: same implementation scope prepared from the V-355 RC working tree; version identity advanced to V-356 per owner request.
- Regression rule: preserve protected Live Voice, Gift Sound engine, Coin/Gold transaction logic, Gift animation, and 8 guest seats (2-9).
- Device/runtime verification is still required before production release.
