# MY SHOP Developer Handoff — V-356

**V#:** V-356 (`versionCode 356`, `versionName 2.9.356`)

**Phase:** Live Streaming Home redesign + Live user-line ranking + Gift Summary + universal comment/profile polish.

**Completed:** Implemented the latest confirmed scope on the V-354 baseline: Gender contrast fix; Photo + Name : Comment; enlarged/serialized horizontal host user line; Top 20 Gift Summary; Top Gifter/Membership/Coin/Level priority ordering; simplified Live Streaming Home with 6-banner carousel, one Top Live row and four future folders; dedicated six-slot Admin banner manager; bottom nav Home/Store/Video/My Feed/Profile; dashboard default palette aligned to Live Home.

**Pending:** Build with the project CI/Android toolchain, deploy Worker + migration `0019_v355_live_home_palette.sql`, then perform real-device runtime/regression testing.

**Last checkpoint:** V-354 source baseline; V-353/V-354 Voice + Gift Sound path is protected and was not modified by V-356.

**Next tasks:** 1) Android compile/CI, 2) Worker deploy, 3) D1 migration, 4) test six banner slots + carousel, 5) test top-live sorting, 6) test user-line ranking/profile taps, 7) test Gift Summary, 8) verify Voice/Gift Sound/Coin/Gold regressions, 9) run Play pre-launch/runtime checks.

**Known issues / gates:** Full Android compile could not be executed in this environment because the source snapshot lacks the runnable Gradle wrapper/JAR and no Android SDK/system Gradle is available. Runtime behavior is therefore not claimed until device/CI verification.

**Locked modules:** Agora voice recovery, Gift Sound engine/assets, Gift animation, Coin/Gold accounting/ledger, 8 guest seats (2–9), Live ephemeral-comment storage behavior, D1/Durable Object realtime architecture.
