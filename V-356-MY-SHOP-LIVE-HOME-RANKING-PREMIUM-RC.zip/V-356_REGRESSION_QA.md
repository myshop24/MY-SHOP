# V-356 Regression QA

- [PASS] Source versionCode = 356
- [PASS] Source versionName = 2.9.356
- [PASS] SOURCE_BUILD_ID = MY SHOP V-356
- [PASS] SOURCE_VERSION_NAME = 2.9.356
- [PASS] No intentional functional scope expansion from V-355 RC
- [REQUIRED] Android compile/install and real-device runtime QA
