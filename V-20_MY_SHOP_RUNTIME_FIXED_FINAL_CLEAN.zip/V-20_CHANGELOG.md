# V-20 MY SHOP CHANGELOG

- Promoted the successful V-19 runtime-fixed source to V-20.
- Changed Android versionCode from 19 to 20.
- Changed Android versionName from 2.8.0 to 2.9.0.
- Removed the `.debug` applicationId suffix so the APK uses the real package ID `com.myshop.app`.
- Preserved the V-19 runtime hardening and SearchBox fix.
- Updated the GitHub Actions workflow to validate and publish V-20.
- V-19 source remains preserved as a separate backup and is not overwritten.
- Runtime fix: changed `Theme.MyShop` to an AppCompat theme because all activities extend `AppCompatActivity`; the previous platform Material theme could crash the app during startup.
