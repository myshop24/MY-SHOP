from pathlib import Path
import re
root=Path(__file__).resolve().parent
assert (root/'SOURCE_BUILD_ID.txt').read_text().strip()=='MY SHOP V-206'
g=(root/'app/build.gradle').read_text()
assert re.search(r'\bversionCode\s+205\b',g)
assert re.search(r"versionName\s+['\"]2\.9\.205['\"]",g)
js=(root/'backend/worker/src/index.js').read_text()
assert "worker:{version:'2.9.206',build:'V-206'}" in js
assert 'async function insertBannerCompat' in js
assert 'names.has(\'section\')' in js and 'names.has(\'position\')' in js and 'names.has(\'is_active\')' in js
assert 'await insertBannerCompat(env,{folder:bannerFolder' in js
assert 'await insertBannerCompat(env,{folder,slot,imageUrl,caption,active})' in js
assert 'await insertBannerCompat(env,{folder,slot,imageUrl:url,caption,active:1})' in js
for bad in ('DROP TABLE','TRUNCATE TABLE','DELETE FROM myshop_auth_users_v108'):
    assert bad not in js
print('V-206 SOURCE VERIFICATION PASSED')
