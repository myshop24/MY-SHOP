# MY SHOP DEVELOPER HANDOFF — V-372

## Completed
- Live Home + Audio Live Room premium button polish only.
- Shared PremiumUi button states/elevation/press finish.
- Build identity V-372 / 2.9.372 / versionCode 372.

## Locked / preserved
- Current layouts and feature positions.
- Live seat/role/moderation/invite/gift/comment logic.
- Coin/Gold Coin economy and backend schema.

## Phase
Premium UI rollout — Batch 1 (buttons only).

## Last checkpoint
V-371 was the GitHub auto-build compatibility baseline.

## Next tasks
Real-device visual acceptance. If approved, reuse the same component styling on Dashboard/Profile/Wallet/Admin in later batches.

## Known issues
No new runtime claim until APK/device testing.

--- Previous handoff retained below ---
# MY SHOP DEVELOPER HANDOFF

Version: V-371
Version name: 2.9.371
Phase: Permanent stabilization + premium UI foundation
Base: V-369

## Completed
- Centralized Android release identity on SOURCE_BUILD_ID.txt + SOURCE_VERSION_NAME.txt.
- Added build-time source/app/backend identity guard.
- Added installed APK identity + runtime backend MATCH/MISMATCH to About.
- Added Git SHA visibility for GitHub builds.
- Added shared PremiumUi spacing/radius/control/touch/motion tokens.
- Added permanent Stabilization + Premium UI Master Plan.
- Preserved V-369 feature behavior; V-371 is a foundation release, not a broad feature rewrite.

## Pending runtime QA
- Build V-371 in GitHub and confirm About shows the actual Git SHA.
- Deploy V-371 Worker and confirm About -> Backend check: MATCH.
- Repeat V-369 two-device Live acceptance tests before declaring Live participant fixes accepted.

## Locked / do not regress
- Authentication/session/user ID.
- Coin/Gold/Star/Level and ledgers.
- Gifts/catalog/admin pricing.
- Agora RTC architecture.
- Ephemeral Live comments.
- End Live first-tap behavior.
- Banner carousel and Live Home approved structure.
- Profile/social and Admin CRUD behavior.
- Google Play compliance safeguards.

## Next phase
Apply Premium UI visually in small batches, beginning with Live Room, using the approved reference and V-371 shared tokens. Do not combine visual polish with unrelated business-logic rewrites.

## Known limitation
A source ZIP cannot prove a GitHub APK was built/deployed; the proof is the installed About identity (Git SHA) plus backend MATCH after deployment.


## V-371 GitHub Auto-Build Compatibility Fix
- Baseline: V-370 Stabilization + Premium Foundation.
- Fixed permanent GitHub workflow rejection caused by dynamic `versionCode myshopVersionCode`.
- Android `defaultConfig` now exposes literal `versionCode 371` and `versionName "2.9.371"` so the existing permanent workflow safety parser can verify the source before build.
- Preserved SOURCE_BUILD_ID/SOURCE_VERSION_NAME as identity inputs for runtime BuildConfig/backend matching and strengthened Gradle verification so literal Android identity must match those files.
- No Live feature/UI/business-logic changes in this release.

