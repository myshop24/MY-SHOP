# MY SHOP V-205

Permanent root fix for legacy D1 `banners` schemas that retain required `section`, `position`, or `is_active` columns.

- Adds `insertBannerCompat()` and uses it for health diagnostics, admin content writes, and banner uploads.
- Existing production rows are not deleted, reset, or migrated destructively.
- The health gate now proves the same backward-compatible banner write path used by the app.
- Version identity: V-205 / Android 2.9.205.
