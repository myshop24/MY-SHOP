# MY SHOP V-143

## Locked final dashboard UI
- MY SHOP header/logo corrected so the MS bag icon and two-line MY / SHOP wordmark stay together.
- Breaking bar label is compact red `BREAKING`; headline text is 17sp and scrolls for readability.
- Hero and two compact promo banners remain.
- GO LIVE and JOIN LIVE are side-by-side before the live cards.
- LIVE row shows five live cards plus View All.
- Feature buttons are a single compact modern row: MY SHOP, GALLERY, EXTERNAL MOVIE, EARN & REWARD, MORE.
- Sponsored Ads stays directly below the feature row.
- MY FEED stays below ads; composer uses GALLERY to select a photo and POST to publish with caption.

## Data safety
- V-142 preserved as rollback backup.
- No user/auth/D1 data reset, delete, truncate, or ID regeneration.
- Existing R2/D1 bindings and Worker URL preserved.
- Existing profile/gallery/feed restrictions preserved.

## Release
- Target: `2.9.143`, build `143`.
- Final artifact: exactly one APK named `MY_SHOP_FINAL_RELEASE.apk`.
