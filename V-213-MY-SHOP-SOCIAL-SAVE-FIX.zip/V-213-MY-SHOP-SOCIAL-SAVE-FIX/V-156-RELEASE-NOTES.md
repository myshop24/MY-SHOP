# MY SHOP V-156 FINAL

- Permanent-data-safe continuation of V-155.
- VersionCode 156 / versionName 2.9.156.
- Fixes requested from the latest video/screens: admin feature editing from dashboard/menu, user-only gallery clean view, social save/delete UI retained, Customer Support and Share App in More, profile Share, Facebook-style Like/Comment action row without Share, larger feed text, faster post insertion, notification badge refresh.
- No D1 reset/drop/truncate, no user deletion, no ID regeneration.
- Profile avatar replacement remains atomic: new upload + D1 update succeeds before old R2 object deletion.
- No OTP / verification-code flow.
