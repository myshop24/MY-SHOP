# MY SHOP V-197 — FULL SCHEMA + CONTENT-WRITE FIX

- Restored the correct social_links INSERT path in admin content handling.
- Removed an accidental health-probe code injection from admin social-link handling.
- Hardened content-write health probes with explicit timestamp columns for legacy D1 schemas.
- Hardened managed-link writes with explicit updated_at.
- Kept all repairs additive; no tables or existing data are deleted.
