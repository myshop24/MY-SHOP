# MY SHOP V-171

Final fixes for the three reported V-170 problems:

1. MORE always renders all seven social buttons (Facebook, Page, YouTube, WhatsApp, imo, Instagram, Telegram), plus Customer Support and Share App. Only a button with a configured safe URL is clickable.
2. Notifications stay visible while the inbox is open. Read state is recorded when leaving the inbox or using Mark seen, preventing the list from disappearing immediately.
3. Cloudflare Worker content writes are backward-compatible with older D1 schemas and do not depend on legacy UNIQUE constraints for banner/social writes.

Data safety: no auth/user tables are dropped or reset; existing D1/R2 bindings and backend URL remain unchanged.
