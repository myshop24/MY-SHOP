# MY SHOP V-47 RELEASE NOTES

- Version Code: 47
- Version Name: 2.9.47
- Application ID: com.myshop.app

## Fixed in V-47
- Uses the supplied MY SHOP Login Reference artwork and login layout.
- Uses the supplied MY SHOP Dashboard Reference header artwork and the dashboard feature structure.
- Restores an existing local session on startup when the installed app data is preserved.
- Existing 4-digit User ID is never regenerated during a normal in-place app update.
- Previous V-46 source is preserved; V-47 is a separate package.

## Critical update rule
Android preserves SharedPreferences only when the APK is updated in place. The applicationId must remain com.myshop.app and the APK must be signed with the same signing key as the installed version. A new GitHub Actions runner creates a new debug signing key, so debug APKs from different runs cannot be relied upon for in-place updates.

Production account/User ID persistence must ultimately use the backend as the source of truth.
