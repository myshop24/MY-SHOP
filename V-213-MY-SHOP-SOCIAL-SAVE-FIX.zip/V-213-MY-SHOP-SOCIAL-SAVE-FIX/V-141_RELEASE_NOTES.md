# MY SHOP V-141

## Targeted build fix
- Fixed the single Java compile error reported by GitHub Actions in `GalleryActivity.java:123`.
- The `txt()` method signature is `txt(String, int color, float size, boolean bold)`.
- `action()` was incorrectly calling it as `txt(String, float size, int color, boolean bold)`.
- Corrected only that argument order.

## Safety
- V-140 is preserved as an exact backup.
- No D1 reset/drop/truncate.
- No user/auth data deletion or ID regeneration.
- No unrelated feature changes are intended.

## Build identity
- Source: V-141
- Version name: 2.9.141
- The workflow is pinned to the exact V-141 archive name.
- Release build must contain exactly one APK.
