# MY SHOP V-150 — TWO TARGETED UI FIXES

- Preserves V-149-FIXED baseline and backend/data safety.
- BREAKING News ticker font reduced from 18sp bold to 16sp regular/medium for a longer visible headline without making it too small.
- MY FEED title is larger, dark/bold and color-mixed (MY dark + FEED purple).
- Added a small stylish `POWER AD · by Touhid` label beside MY FEED; label follows the selected app language.
- Removed the duplicate Gallery button from the bottom-left of the MY FEED composer. The right-side POST button remains. Gallery/Text choices remain available from the Filter control.
- No backend schema/data/ID changes.
- No unrelated dashboard buttons/features changed.
