# V-182 — MY SHOP Startup Live Ad Admin System

- Added the supplied MY SHOP Live Streaming startup advertisement as the bundled default.
- Added admin-controlled `startup_ad` slot 1.
- Admin can replace/upload, edit caption/link, set display seconds (1–60), save, and delete.
- Startup ad fetches the active admin setting from the dashboard endpoint; if unavailable, bundled default remains.
- Existing V-179/V-180/V-181 source is preserved as backup; V-182 is the next sequential version only.
