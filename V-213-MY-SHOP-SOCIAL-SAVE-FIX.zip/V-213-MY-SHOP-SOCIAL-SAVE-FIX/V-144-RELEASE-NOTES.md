# MY SHOP V-144 — LOCKED DASHBOARD UI

- Preserves V-143 as the exact backup baseline.
- No D1/R2 reset, drop, truncate, ID regeneration, or destructive migration.
- Locks the user-approved dashboard layout.
- Breaking ticker: compact red BREAKING badge, no View All, headline text 17px.
- Modern compact five-button row: MY SHOP, GALLERY, EXTERNAL MOVIE, EARN & REWARD, MORE.
- Sponsored Ads remains below the feature row and is visually filled even when no live stream is active.
- Existing feed, gallery, live, profile, coin, banner, and backend functionality is preserved.
- Release version: 2.9.144 / versionCode 144.
