# MY SHOP V-134 — ADMIN SERVER + PROFILE + USER MENU FIX

## Fixed
- Repaired additive D1 content-schema compatibility for existing `dashboard_config`, `banners`, `gallery_media`, `banner_media`, and `managed_links` tables. Missing columns are added without deleting/resetting user/auth data.
- Admin content endpoints now re-check/repair content schema before read/write operations.
- Banner Manager keeps all 6 Hero + 3 Promo slots visible even when no banner exists. Each slot has CHANGE PHOTO, EDIT, SAVE, DELETE, and a caption field. New uploads now ask for a caption before upload.
- Removed the whole-card click behavior that could interfere with the action buttons.
- Fixed Banner picker permission syntax.
- User More menu row heights were increased so titles/descriptions no longer overlap or clip on high-density phones.
- User menu now clearly shows PROFILE • USER/ADMIN and includes LOGOUT.
- Admin Hub now shows PROFILE • ADMIN and LOGOUT instead of exposing the permanent Admin ID in the header.
- Account/User logout now invalidates the backend session as well as clearing the local session.
- Client now surfaces the Worker `SERVER_ERROR` message when the server supplies one.
- Android version bumped to `2.9.134` / versionCode `134`.

## Safety
- No user/auth table is dropped, cleared, or reset. Permanent IDs are preserved.
- Admin authorization remains backend-enforced. Normal users do not receive Admin controls.

## Build
- This archive contains project source/config/backend only; no duplicate APK or SHA file is bundled.
- Production Worker is not claimed as live-verified from this environment.
