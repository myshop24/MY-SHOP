# MY SHOP V-52 — FINAL CONSOLIDATED SOURCE

VersionCode: 52
VersionName: 2.9.52

## Locked UI
- MY SHOP dashboard remains the locked base design.
- Header, banners, Breaking News, LIVE NOW, MY FEED, MY SHOP and lower feature arrangement are preserved.
- Bottom navigation remains Home / Store / Live / Chat / More.

## Banner correction
- Six slots exist in each of the three banner folders.
- Each slot now carries its correct 1/6 through 6/6 position marker.
- Left, right and full-width folders rotate independently through six slots.

## LIVE NOW correction
- Six positions are retained.
- Active live count controls how many Live cards are shown.
- Remaining positions are explicit ADVERTISEMENT cards.
- With zero live streams, all six positions are advertisements.

## Login/account foundation
- Email OR Mobile is sufficient for account creation.
- No OTP/verification-code flow is used.
- Four-digit user ID allocation remains in the account foundation.
- Admin identifier role hook recognizes the three approved identifiers after successful authentication; passwords remain outside the APK.

## Version/backup rule
- V-51 remains untouched as the previous source backup.
- V-52 is a separate source package.
