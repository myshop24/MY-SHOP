# V-113 — Single Security Question Authentication Fix

- Registration now asks for exactly ONE security question and one answer.
- Forgot Password first asks for Email/Mobile/Permanent ID, then fetches and displays the saved security question.
- Only the correct answer unlocks the new-password fields.
- Permanent 4-digit User ID remains unchanged after password reset.
- Existing auth table and existing user records are preserved; q2/q3 columns remain for backward compatibility and are not deleted.
- Existing users can use their existing q1 answer for reset.
- Password hashing remains PBKDF2-SHA256 with 100,000 iterations on the backend.
- No database reset, DROP, DELETE-all, or ID renumbering was added.

## Release verification required
This archive changes source code only. The production Cloudflare Worker must be deployed from the same release before testing the APK. Do not submit to Play Store until registration, login, forgot-password, dashboard, update-install, and database/ID preservation tests all pass.
