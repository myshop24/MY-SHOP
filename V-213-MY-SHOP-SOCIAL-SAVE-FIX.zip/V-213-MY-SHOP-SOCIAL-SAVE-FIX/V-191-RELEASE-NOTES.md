# MY SHOP V-191 — PERMANENT CLOUD / D1 / R2 FIX

## Goal
Fix the shared Admin content save/upload failures permanently and prevent a green APK build from hiding an unhealthy production backend.

## Confirmed V-190 problem
V-190 APK build succeeded, but the GitHub Actions run shown during testing did not execute the Cloudflare/D1/R2 preflight steps. The production D1 screenshots also showed a legacy `banners` schema using `section`/`position`, while the current Worker expects `folder`/`slot`. This mismatch is a direct cause candidate for Banner save failures.

## V-191 changes
- Additive, explicit D1 schema repair with exact errors; no silent schema-repair catches.
- Automatically repair legacy `banners` by adding `folder`/`slot` and mapping existing `section`/`position` values without deleting old columns or user data.
- Automatically add missing `dashboard_ads.duration_sec` and `social_links.caption`.
- Add persistent `myshop_schema_meta` schema-version marker and a versioned D1 migration.
- D1 schema repair retries after a transient failure instead of caching a rejected initialization promise.
- `/health/deep` remains a real D1 read/write + R2 read/write gate.
- `/health/content-write-suite` independently tests R2 and temporary writes across dashboard, banner, banner media, gallery, social, feature, managed links, ads, notifications and notification reads.
- GitHub Actions must run the Cloudflare gate before Gradle; if the gate fails, APK build stops.
- Cloudflare health evidence is saved as an artifact for every release run.
- Source ZIP now carries the same mandatory release workflow so future project copies cannot silently drop the cloud gate.
- Permanent Developer Instructions updated with the V-190 workflow mismatch and legacy-D1 schema issue.

## Preservation
- V-190 and all earlier versions remain untouched.
- Same Android package name and permanent signing key.
- Permanent User/Admin IDs are never changed, deleted, recycled or reassigned.
- No auth identity table is touched by health probes.
