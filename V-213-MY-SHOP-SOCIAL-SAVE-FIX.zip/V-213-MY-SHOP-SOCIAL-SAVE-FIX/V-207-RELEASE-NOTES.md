# MY SHOP V-207 — FINAL WORKFLOW FIX

- Removed Google Drive / external-backup workflow logic.
- Active workflow now has no Google Drive backup dependency.
- Build triggers only for a root V-*.zip source upload or workflow change.
- Highest V-number source selection is strict and stops on duplicate highest versions.
- SOURCE_BUILD_ID, Android versionCode/versionName, and Worker version are locked to the selected V-number.
- Preserved the existing permanent signing-key continuity instead of generating/replacing a key.
- Preserved Cloudflare D1/R2 preflight and live verification before APK build.
- Preserved the one-final-APK rule: MY_SHOP_FINAL_RELEASE.apk.
