# MY SHOP V-106 — FINAL DASHBOARD LOCK

- Version code: 106
- Version name: 2.9.106
- Base: V-105 full master
- Dashboard now follows the user-approved reference layout:
  - Profile/greeting/ID + search + notification + menu
  - Two top banner cards
  - Six-slide banner carousel with dots
  - One wide promotional banner
  - Breaking News row
  - LIVE NOW horizontal cards
  - My Feed + My Shop action cards
  - Gallery / Live TV / Earn & Reward on left
  - External / Social / Share on right
  - Center GO LIVE button
  - Fixed HOME / STORE / LIVE / CHAT / MORE bottom navigation
- Existing backend URL and account/auth files are preserved from V-105.
- No user database is dropped or reset by this package.
