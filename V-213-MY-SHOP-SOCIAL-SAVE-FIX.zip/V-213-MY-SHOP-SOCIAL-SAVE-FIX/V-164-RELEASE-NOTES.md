# MY SHOP V-164

## Final instruction lock
- Profile remains only on the left/profile area; the 3-line User Menu never contains Profile.
- Main Dashboard **MORE** now opens exactly three user actions: Social Media, Customer Support, Share App.
- Social Media loads Admin-saved links.
- Customer Support opens the Admin-saved WhatsApp link; the phone number is not displayed.
- Share App uses Android's installed-app share chooser.
- Admin access remains contextual: feature/folder click opens the relevant Admin panel; the hamburger remains a User Menu.

## Backend safety
- Avatar upload explicitly ensures the additive auth schema before reading/updating the user.
- Multipart parse errors and R2 verification failures now return clear diagnostics.
- After a new avatar is written to R2, the object is verified before D1 is updated. If D1 update fails, the new R2 object is deleted and the previous avatar reference remains unchanged.
- Deep health now checks the permanent auth table and required avatar columns in addition to D1/R2.
- No DROP/TRUNCATE or auth-user destructive migration was introduced.

## Build
- versionCode: 164
- versionName: 2.9.164
- package: com.myshop.app
