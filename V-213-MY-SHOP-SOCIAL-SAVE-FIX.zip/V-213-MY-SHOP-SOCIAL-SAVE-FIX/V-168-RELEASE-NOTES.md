# MY SHOP V-168

- Final dashboard instruction pass based on the approved dashboard/menu references.
- Hamburger menu upgraded with Search and the requested user feature list, including Social Media, Share App and Help & Support.
- More opens Customer Support + Share App for users; admins remain isolated in Admin Hub.
- Customer Support accepts either WhatsApp URL or phone number and opens WhatsApp without displaying the number in the user UI.
- Notification badge/inbox remains unread-count based and marks notifications read after opening. Like/comment notifications remain user-specific; admin content/ad changes broadcast MY SHOP update notifications.
- Breaking-news strip now uses only the rotating 🌎 icon; the previous red globe box is removed. News font is intentionally unchanged.
- Power Ad remains multilingual and mixed-color.
- Dashboard ad folders retain six slots per box and live ads rotate in the live area.
- D1/R2 workflow keeps the existing Worker URL, deploys the same verified Worker source, checks /health and /health/deep before APK build, and refuses a missing permanent signing key.
- Version incremented to V-168 / 2.9.168.
