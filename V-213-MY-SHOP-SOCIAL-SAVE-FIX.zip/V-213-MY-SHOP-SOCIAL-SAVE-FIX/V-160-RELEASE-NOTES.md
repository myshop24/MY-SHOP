# MY SHOP V-160

Targeted backend/deployment reliability fix.
- Correct Worker /health version marker to V-160.
- Deploy and verify the exact Worker source before APK build.
- Verify ACTIVE production Worker version plus D1/R2 health before building.
- Refuse to generate a replacement signing key; use the existing stable key only.
- Preserve D1/R2/user IDs/user accounts; no destructive migration.
- One final APK + checksum artifact.
