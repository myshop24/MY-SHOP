# V-98 Master Rules

- The canonical workflow is `.github/workflows/my-shop-apk.yml`.
- This exact workflow is included in every complete backup.
- Android version is `versionCode 98`, `versionName 2.9.98`.
- Build output must contain one APK and one complete master backup.
- Existing user IDs/data must not be intentionally deleted by an app update.
- Permanent cross-device identity still requires a server-authoritative backend; local SharedPreferences is not sufficient for uninstall/device migration.
- Future versions must increment both VERSION_CODE and versionName together and regenerate the complete backup.
