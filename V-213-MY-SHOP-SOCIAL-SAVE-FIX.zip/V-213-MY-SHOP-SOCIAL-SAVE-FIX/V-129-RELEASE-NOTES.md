# V-129 MY SHOP — ADMIN FOLDER / DETAIL BOARD FIX

## Exact problems identified from the V-128 test video
1. The AdminHub was visually too dense: tiny descriptions and a long mixed control area made the panel look cluttered.
2. The old AdminManagementActivity rendered Dashboard, banners, features, social, gallery and other resources in one long page. This is the main reason the admin panel felt like a "jumbled" page.
3. The test video also showed `Load failed: SERVER_ERROR` while the admin config page was opening. The dashboard Worker response was too fragile because a failure in one optional content query could turn the whole endpoint into HTTP 500.
4. The V-128 GitHub workflow was still internally labeled/source-checked as V-127 in places, creating a version/source mismatch risk.

## V-129 changes
- Admin hamburger continues to route only Admin accounts to the Admin Folder List.
- Normal users continue to receive UserMenuActivity; no Admin controls are added there.
- New focused AdminSectionActivity: one folder at a time, with a clear detail board and Save/Delete controls.
- AdminHub is now a clean, colorful folder list with 10 clearly separated sections.
- Banner folder remains dedicated to BannerAdminActivity: 6 Hero + 3 Promo slots, phone Gallery upload, Caption, Save, Delete.
- Gallery folder remains dedicated to GalleryAdminActivity: Photo / Audio / Video, phone Gallery upload, Caption, Edit, Save, Delete.
- Managed-link saves are targeted; editing one category/item no longer clears other managed categories/items.
- Worker dashboard endpoint now tolerates an unavailable optional content table instead of failing the complete dashboard response.
- Version is 2.9.129 / versionCode 129 / targetSdk 36.
- Auth, user records, sessions, permanent IDs and D1 user data are not reset or deleted by these changes.

## Verification
- Worker JavaScript syntax check: PASS.
- Manifest includes AdminSectionActivity: PASS.
- Workflow stale V-127 references: NONE.
- Full Android release build must be verified by GitHub Actions before the APK is treated as stable.
