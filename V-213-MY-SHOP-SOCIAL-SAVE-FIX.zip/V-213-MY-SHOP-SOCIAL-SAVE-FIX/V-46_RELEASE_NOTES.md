# MY SHOP V-46 — LOGIN + DASHBOARD DESIGN FIX

This milestone starts from the last known buildable V-45 source and changes only the Login/Home presentation layer.

## Fixed first
- Login screen rebuilt to match the approved MY SHOP Login Reference: MS logo/header, Login field, Password field with visibility toggle, Remember me, Forgot Password, blue gradient LOGIN button, OR separator, Create Account.
- Home Dashboard rebuilt around the approved dashboard reference: top visual header, Live Now cards, Live/Go Live/My Feed actions, MY SHOP/Gallery/External Movie/Live TV, Social Media/Earn & Reward/Share/More Apps, and a large five-item bottom navigation.
- Existing authentication/account/session classes are retained.
- ApplicationId remains `com.myshop.app`.
- Version increments to `versionCode 46`, `versionName 2.9.46`.
- No previous V-45 archive is overwritten.

## Verification policy
Build is not considered final until GitHub Actions confirms compilation, exactly one APK, package `com.myshop.app`, version 46/2.9.46, APK integrity, and artifact upload.
