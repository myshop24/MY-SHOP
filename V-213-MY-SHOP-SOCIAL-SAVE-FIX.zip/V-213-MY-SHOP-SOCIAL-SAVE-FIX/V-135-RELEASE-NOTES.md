# MY SHOP V-135

## Direct build-error fix
- Fixed `AdminHubActivity.java` compile error: added `import org.json.JSONObject;`.
- This resolves the reported `cannot find symbol: class JSONObject` error in `:app:compileReleaseJavaWithJavac`.

## Build identity
- versionCode: 135
- versionName: 2.9.135
- GitHub Actions workflow updated to use the V-135 full-project ZIP.
- Workflow verifies `AdminHubActivity` routing and builds exactly one APK artifact.

## Data safety
- No database reset/drop/delete operation was added.
- Existing user/auth data is preserved by this change.
