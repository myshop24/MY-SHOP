# V-120 MY SHOP — STABILITY + ADMIN + UI FIX

- Version: 2.9.120 / versionCode 120
- Preserves existing D1 data and permanent User IDs.
- Fixes Breaking News: removes the unwanted View All and gives the headline the full remaining width.
- Adds a visible language selector in the dashboard header: বাংলা / English / हिन्दी / العربية.
- Hamburger/admin flow re-checks the backend role before opening Admin Management, reducing stale-session failures.
- Moves bottom navigation slightly upward with safe margin for easier tapping.
- Keeps approved final lower dashboard structure: MY FEED + MY SHOP emphasized, remaining feature cards in a premium white/tinted style.
- Keeps remote feature/banner/social/gallery controls and server-side admin authorization.
- GitHub workflow builds exactly one V-120 APK and can deploy the Worker when CLOUDFLARE_API_TOKEN is configured.
