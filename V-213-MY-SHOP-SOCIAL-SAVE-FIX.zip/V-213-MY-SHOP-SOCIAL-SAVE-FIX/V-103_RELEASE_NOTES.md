# MY SHOP V-103

## Fix
The registration screen previously changed only the language button while the security-question Spinner and several registration texts remained hard-coded English.

## V-103 solution
- All six security questions are translated for বাংলা / English / हिन्दी / العربية.
- Changing language refreshes the registration screen immediately.
- Security-question values sent to the backend are stable IDs (`q1`..`q6`), so language changes do not change the meaning of an account's saved questions.
- Password reset translates both new `q1`..`q6` values and old English question text.
- Permanent user ID allocation and existing account data are untouched.

## Version
- versionCode: 103
- versionName: 2.9.103
