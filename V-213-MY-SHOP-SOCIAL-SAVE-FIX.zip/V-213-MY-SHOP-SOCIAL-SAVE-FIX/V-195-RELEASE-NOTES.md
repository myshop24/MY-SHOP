# MY SHOP V-195 — Runtime + Exact Worker Deployment Fix

- Keeps the V-194 `schemaInitByEnv` runtime fix.
- Explicitly uploads and promotes the exact Cloudflare Worker version tag.
- Makes production probes diagnostic and tolerant of short propagation windows.
- Preserves all prior V-number backups.
