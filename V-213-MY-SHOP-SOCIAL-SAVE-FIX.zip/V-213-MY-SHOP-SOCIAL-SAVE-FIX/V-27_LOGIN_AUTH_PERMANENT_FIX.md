# MY SHOP V-28 — Permanent Login Authentication Hardening

## Confirmed problem
The V-28 client is a local prototype and its login lookup depended on an email/mobile index key. If that index was missing after an older-version migration, login could report failure even when the account record and password were still present. The client also did not accept the permanent 4-digit User ID as a login identifier.

## V-28 fixes
- Login accepts the permanent 4-digit User ID, Email, or Mobile Number.
- Email/mobile index is automatically repaired from the authoritative local account record when missing.
- Legacy direct account records are migrated into the V2 record layout on first login.
- Account creation uses commit() so the account record/index is synchronously persisted before reporting success.
- Password verification remains PBKDF2 with legacy SHA-256 upgrade support.
- User ID remains attached to the account and is never regenerated during login.
- VersionCode 27 / VersionName 2.14.2 in source; CI must use this source as the only build input.

## Important limitation
This APK still has no production authentication backend. Local account data survives an in-place APK update with the same package/signature, but uninstalling/clearing app data can remove local records. True cross-device/permanent recovery of User ID, password, profile, photos and coins requires a server-side database/authentication service.

## Admin security
Do not embed admin passwords in the APK. Admin role must remain backend-authoritative.
