# MY SHOP V-173 — MASTER FIX

এই source package-এ V-173-এর জন্য একসাথে master-fix pass করা হয়েছে।

## Included
- MORE screen: Facebook-style smooth rounded cards, consistent icon/text/arrow alignment, ripple feedback, elevation, spacing and scroll-safe layout.
- User menu: consistent raised/ripple button cards, improved icon containers, spacing and touch area.
- Admin action buttons: consistent rounded/ripple treatment.
- Social admin loader: all 7 MORE social slots are loaded (Facebook, Page, YouTube, WhatsApp, imo, Instagram, Telegram).
- Notification inbox: no longer auto-marks everything read merely by leaving the screen; user can use Mark seen.
- Notification badge polling: refresh interval reduced to 5 seconds while Home is resumed.
- Existing D1/R2/auth code was preserved; no destructive migration was introduced in this pass.
- Version: 173 / 2.9.173.

## Important
This is a source ZIP, not a verified APK. Android SDK/Gradle build environment is not available locally in this workspace, so APK compilation must be performed by the project GitHub Actions workflow.
