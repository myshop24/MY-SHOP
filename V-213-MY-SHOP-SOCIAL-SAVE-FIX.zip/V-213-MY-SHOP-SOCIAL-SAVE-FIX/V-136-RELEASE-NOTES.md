# MY SHOP V-136

- Version: 2.9.136 / versionCode 136
- Keeps V-135 features and user/auth data intact.
- Added production deep health check for D1 schema + R2 binding.
- Added automatic post-deploy verification of Worker and dashboard API.
- Worker deployment no longer silently skips when Cloudflare secrets are missing.
- Added stable R2_WRITE_FAILED error reporting.
- Gallery user view: photo tap opens the photo; audio/video keep type-specific players.
- Gallery Admin: PHOTO/AUDIO/VIDEO tabs are type-specific; picker, preview/play, caption, save, edit title, and delete remain available.
- No auth/user tables are dropped, reset, or deleted.
