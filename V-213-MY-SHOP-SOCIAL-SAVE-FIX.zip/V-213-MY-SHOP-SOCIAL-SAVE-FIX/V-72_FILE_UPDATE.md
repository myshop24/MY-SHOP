# V-72 file update summary

- `.github/workflows/my-shop-v72.yml` — new clean V-72 one-APK build workflow; removes nested-ZIP expectation.
- `app/build.gradle` — version 71 → 72 / 2.9.72.
- `tools/validate_v72.py` — V-72 source validation.
- `README.md` — V-72 build/use notes and scope clarification.
- `V-72_RELEASE_NOTES.md` — detailed V-72 milestone notes.
- `app/src/main/java/com/myshop/app/LoginActivity.java` — V-72 source label only; behavior carried forward.
- `app/src/main/java/com/myshop/app/MainActivity.java` — V-72 source label only; dashboard implementation carried forward.
- All other application source/resources/assets — carried forward unchanged from V-71 full source to protect existing working features.
