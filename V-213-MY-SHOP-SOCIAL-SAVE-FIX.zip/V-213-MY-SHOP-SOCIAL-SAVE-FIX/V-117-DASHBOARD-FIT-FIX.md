# V-117 Dashboard Fit + Breaking News Fix

- Compact dashboard vertical spacing so the main dashboard fits much more comfortably on a standard phone without requiring immediate vertical scrolling.
- Reduced header, hero, promo, LIVE NOW, action and feature-card heights.
- Changed feature grid to a compact 4-column x 2-row layout.
- Breaking News red label reduced to a compact pill.
- Removed the misleading/space-consuming View All/arrow area from inside the Breaking News ticker.
- Headline receives the main available width and remains single-line marquee text.
- LIVE NOW keeps its own "সব দেখুন" control separately.
- Existing authentication, permanent IDs, database and admin backend are not reset or removed.
- Version: 2.9.117 / versionCode 117.
