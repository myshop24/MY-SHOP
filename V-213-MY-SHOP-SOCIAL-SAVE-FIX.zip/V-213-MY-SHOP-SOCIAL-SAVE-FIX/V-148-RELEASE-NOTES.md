# V-148 MY SHOP

- Base: V-147.
- Preserved the current MY SHOP dashboard layout; no unrelated buttons/sections removed.
- BREAKING: smaller red badge, no speaker emoji, slightly smaller dark-blue headline.
- Header MY SHOP branding kept compact.
- Language picker remains বাংলা / English / हिन्दी / العربية and dashboard strings use the selected language where wired.
- MY FEED heading uses a subtle dark mixed-color bold treatment.
- Filter opens Text Post/Status or Gallery. Gallery opens the phone image picker.
- Photo posts support caption or no caption; POST is a small blue control on white.
- Removed the POWER AD by Touhid branding card and made the advertisement strip use the same-size ad cards.
- Existing D1/R2 bindings, user data and permanent IDs are preserved; no destructive reset/drop/truncate operations added.
- Version: 2.9.148 / versionCode 148.
