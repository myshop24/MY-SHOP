# MY SHOP V-72 — Full Source Package Update

## What was fixed in V-72
1. **Full source package**: V-72 is a complete Android project source ZIP, not a small patch/code-copy package.
2. **Build pipeline correction**: the V-72 workflow builds the checked-out project directly instead of expecting a second nested source ZIP.
3. **Gradle**: GitHub Actions uses Gradle 8.11.1 with Java 17 and Android SDK 35.
4. **One-APK guard**: the workflow fails if it finds anything other than exactly one release APK.
5. **APK identity check**: package `com.myshop.app`, versionCode `72`, versionName `2.9.72` are verified before the artifact is uploaded.
6. **Final artifact naming**: `V-72 MY SHOP FINAL RELEASE.apk` plus SHA-256 checksum.
7. **Existing V-71 features are carried forward**: the source base is the latest V-71 full source package; no old backup ZIP is overwritten.
8. **Security-question reset remains present**: three questions/answers with a 2-of-3 reset rule.
9. **Four-digit local profile ID allocation remains present**: sequential IDs beginning at 0100 in the current client-side fallback.
10. **Four-language UI remains present**: বাংলা, English, हिन्दी, العربية.

## Important scope note
V-72 is a **build/source-package milestone**. The current source still documents the backend as the production source of truth; the local account store is a fallback/prototype. A real Cloudflare Worker + D1 + R2 backend must be connected before claiming cross-device/permanent cloud identity guarantees.
