# MY SHOP V-51 — FINAL CORRECTED BANNER + LOGIN/DASHBOARD PACKAGE

VersionCode: 51
VersionName: 2.9.51

## Locked decisions
- Keep the approved dashboard upper area unchanged in structure.
- Keep the selected My Feed + My Shop pair.
- Keep centered Go Live control below My Feed/My Shop.
- Bottom navigation is Home / Store / Live / Chat / More.
- Live area keeps six positions and shows controlled placeholders/ads when no live stream is active.

## Banner correction
- Removed the previous active banner artwork from the V-51 source.
- Added exactly six top-left banner slots.
- Added exactly six top-right banner slots.
- Added exactly six full-width banner slots.
- All 18 active banner files are the newly selected dashboard artwork; no legacy banner file is referenced by MainActivity.
- Auto-rotation remains enabled at 3.5 seconds per slot.

## Login correction
- MY SHOP + LIVE branding retained.
- Email / Mobile login tabs added.
- No OTP requirement.
- Password show/hide retained.
- Forgot Password and Create Account retained.
- Mobile login accepts local number and retries with +880 for compatibility.

## Verification performed before packaging
- VersionCode/versionName checked.
- Six + six + six active banner resources checked.
- MainActivity banner arrays checked to reference only the new 18 slots.
- Login resource IDs checked against LoginActivity.
- ZIP integrity test required before delivery.
