# V-128 MY SHOP — IN-APP NOTIFICATION COUNT

- Adds authenticated in-app notification inbox.
- Header bell now shows unread count (up to 99+).
- Opening Notifications loads the latest 50 and marks current notifications as seen.
- Backend uses additive D1 tables: notifications + notification_reads. Existing auth/user tables are untouched.
- Admin dashboard/content/banner/gallery changes create broadcast notifications for users.
- No database reset, ID reset, password reset, or destructive migration.
- Android versionCode 128 / versionName 2.9.128 / targetSdk 36.
