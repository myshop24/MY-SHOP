# MY SHOP V-186 — Permanent Content/D1/R2 Write Fix

- Sequential next version after V-185.
- Preserves V-179 through V-185.
- Keeps the permanent Android signing key and update/replace rule.
- Hardens the shared Admin content write path.
- Adds D1 schema verification and D1 write probe.
- Adds R2 write verification probe.
- `/health/deep` now requires both read and write health.
- GitHub Actions refuses release if D1/R2 write health is not healthy.
- Improves exact backend error visibility.
- Does not delete or modify Permanent User/Admin IDs.
