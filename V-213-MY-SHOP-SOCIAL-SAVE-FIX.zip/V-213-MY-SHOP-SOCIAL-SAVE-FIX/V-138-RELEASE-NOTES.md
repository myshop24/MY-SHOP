# MY SHOP V-138 — DATA SAFE PROFILE + COIN FOUNDATION

Baseline: V-137.

## Safety first
- Existing D1 user/auth rows are preserved. No DROP, DELETE, reset, or ID regeneration migration was added.
- Permanent 4-digit User ID remains read-only in the profile UI.
- Profile changes update only the authenticated user's editable fields; user_id is never changed.
- New profile/avatar columns are additive via ensureColumn().
- New coin tables are additive and start at zero for existing users without changing their accounts.
- Existing R2 media is preserved. Banner replacement now uploads/commits the new object before deleting the old object.

## Profile
- Premium profile foundation with avatar, name, permanent ID, contact, bio, edit flow, history/gallery placeholders, security/support controls.
- Real backend profile update endpoint: PUT /v1/me/profile.
- Real R2 avatar upload endpoint: POST /v1/me/avatar/upload.

## Coins
- Server-authoritative wallet and transaction tables.
- Coin balance endpoint: GET /v1/coins.
- Purchase request endpoint supports bKash, Nagad, and Bangla QR Code as PENDING requests; no client-side crediting.
- Coins are credited only by future server-side approval logic, not by the APK.

## Build
- Version code: 138
- Version name: 2.9.138
- Workflow source archive must be V-138-MY-SHOP-FULL-PROJECT-PROFILE-COINS-DATA-SAFE.zip
- Final APK name: MY_SHOP_FINAL_RELEASE.apk
- Worker deploy and deep D1/R2 health verification remain required.
