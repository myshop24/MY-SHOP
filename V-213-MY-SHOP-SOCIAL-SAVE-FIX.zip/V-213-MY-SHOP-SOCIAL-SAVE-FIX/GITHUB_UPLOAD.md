# V-80 GitHub upload

Upload these two files to the repository root:
1. `V-80_MY_SHOP_FULL_PROJECT_SOURCE.zip`
2. `.github/workflows/my-shop-v80.yml` (from this project backup)

The V-80 workflow produces exactly one signed APK and verifies:
- package: `com.myshop.app`
- versionCode: `80`
- versionName: `2.9.80`
- launcher: `com.myshop.app.LoginActivity`

Keep V-77, V-78 and V-79 backups unchanged.
