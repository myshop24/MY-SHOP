# MY SHOP V-48 — Dashboard Layout Fix

- Version Code: 48
- Version Name: 2.9.48
- Application ID: com.myshop.app (unchanged)

## Primary fix
- Rebuilt the dashboard sizing around Android dp units instead of raw pixel heights.
- The previous V-47 MainActivity used values such as 330, 150, 102 and 84 directly as pixels. On modern high-density phones this compressed the dashboard and produced a large blank area.
- The supplied dashboard header artwork is now displayed with `adjustViewBounds` and its natural aspect ratio instead of being forced into a 330px-high box.
- Live cards, feature cards and the bottom navigation now use density-aware sizes.
- Bottom navigation remains fixed while the dashboard content scrolls.

## Preservation
- V-47 source remains untouched in the original backup.
- applicationId remains `com.myshop.app`.
- Version is incremented to V-48 / 2.9.48.
- Login/account/session code was not changed in this dashboard-only fix.

## Important
A successful GitHub Actions build proves compilation/artifact creation only. The final APK still needs installation and runtime verification on the target phone.
