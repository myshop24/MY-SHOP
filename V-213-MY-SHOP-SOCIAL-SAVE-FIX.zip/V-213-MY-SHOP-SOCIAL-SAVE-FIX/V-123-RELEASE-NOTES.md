# MY SHOP V-123 — ADMIN + UI POLISH RELEASE

## Purpose
V-123 is a full-project release built from V-122. It keeps the existing backend, authentication, permanent IDs and D1 data model intact and adds a cleaner admin/content-management experience.

## Dashboard
- Keeps the approved 4x2 lower feature layout.
- Removes the overly circular/rounded visual treatment from lower feature buttons.
- MY FEED and MY SHOP use polished colored rectangular cards.
- Other feature cards use clean white rectangular cards with subtle borders/elevation.
- Bottom Home / Live / Store / Chat / More bar is raised slightly for easier mobile tapping.
- Store button remains the centered highlighted item.
- Language picker remains Bengali / English / Hindi / Arabic.

## Admin
- Rebuilt Admin Management UI with consistent rectangular fields and action buttons.
- Clear SAVE / DELETE / ADD/UPLOAD actions are visible.
- Dashboard headline and URL controls.
- Hero 6 + Promo 3 banner controls.
- Feature rename / URL / icon URL / show-hide controls.
- Social links add/edit/delete through the remote content contract.
- Gallery quick controls plus dedicated R2 Gallery Manager.
- Live TV / External Movie / More Apps / Payment Methods managed links.
- Moderator add/remove.
- Admin authorization remains server-authoritative.

## R2 Banner Manager
- Hero 1–6 and Promo 1–3.
- Upload image to R2.
- Save banner caption.
- Delete banner and its R2 object.

## R2 Gallery Manager
- Three folders: PHOTO, AUDIO, VIDEO.
- Upload media to R2.
- Save caption.
- Edit title.
- Delete media and its R2 object.

## Backend
- Added admin banner caption update endpoint.
- Added admin gallery media metadata update endpoint.
- No destructive auth/user migration.
- No user ID reset.

## Release identity
- versionCode: 123
- versionName: 2.9.123
- compileSdk: 36
- targetSdk: 36
- applicationId: com.myshop.app
- Production Worker URL remains the existing MY SHOP Worker.

## Verification
The GitHub workflow is V-123-specific and verifies source identity, backend JavaScript syntax, Android SDK 36 build identity, and exactly one APK output.
