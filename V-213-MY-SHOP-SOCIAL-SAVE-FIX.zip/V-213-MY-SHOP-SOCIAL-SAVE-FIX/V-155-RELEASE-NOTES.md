# MY SHOP V-155 — FINAL VERSION-LOCKED BUILD

- Permanent-data-safe continuation from V-154.
- **Permanent build fix:** versionCode is 155 and versionName is 2.9.155.
- The GitHub workflow derives the APK version directly from `app/build.gradle` and verifies that it matches `SOURCE_BUILD_ID.txt` (`V-155`).
- The workflow refuses to build an old/wrong version and builds exactly one APK.
- Same package `com.myshop.app` and permanent signing key requirement, so this is an update build rather than a separate app.
- No D1/R2 reset, drop, truncate, ID regeneration, or user/account deletion.
- Keeps V-154 functional changes: compact Facebook-style Like/Comment actions with Share removed, user Gallery clean view, Social Save/Delete controls, notification creation for likes/comments, and permanent profile/avatar safety.
