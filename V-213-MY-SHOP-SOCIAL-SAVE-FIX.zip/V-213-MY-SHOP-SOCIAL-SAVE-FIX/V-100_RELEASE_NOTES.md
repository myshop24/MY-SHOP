# MY SHOP V-100 — FINAL DASHBOARD START

- Main dashboard redesigned to closely follow the approved mobile reference.
- Order: header → main hero banner → six-dot carousel → 3 ad cards → breaking news → live-now cards → Live/Go Live/My Feed → 8 feature tiles → bottom navigation.
- Existing feature keys/actions are preserved.
- Six-position automatic ad carousel retained.
- Permanent account/login/backend classes are preserved from V-99.
- Android version: 100
- Version name: 2.9.100
- Exact build workflow is included at `.github/workflows/my-shop-apk.yml` and uses the same V-100 version values.
