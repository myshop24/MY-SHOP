# V-76 file update summary

- `app/src/main/java/com/myshop/app/MainActivity.java` — corrected dashboard full-screen behavior and removed vertical scrolling.
- `app/build.gradle` — versionCode 76; versionName 2.9.76.
- `.github/workflows/my-shop-v76.yml` — one-APK production build workflow using Gradle 8.11.1 provisioned by GitHub Actions; no missing-wrapper dependency.
- `tools/validate_v76.py` — validates V-76 version and dashboard-fit changes.
- `SOURCE_BUILD_ID.txt` — V-76 source marker.
- Existing login/register resources, dashboard assets, design references, backend contracts and prior working source are carried forward without deletion.
