# MY SHOP V-114 — Stable Build Pipeline Fix

This release does **not** change the authentication design beyond the already-approved single security question flow. It fixes the release/build path that was still pointing at the old V-109 source and old version checks.

## Permanent release rules
- Build only from the exact V-114 source archive or the checked-out V-114 project.
- Never search for or extract a V-109/V-110/V-111 archive during a V-114 build.
- Verify versionCode 114 and versionName 2.9.114 before compiling.
- Verify compileSdk/targetSdk 36.
- Verify the registration layout contains one security-question selector and one security-answer field.
- Verify the production backend URL.
- Build exactly one release APK.
- Fail the workflow if source/version/UI checks do not match.

## Important signing note
The included workflow creates a temporary test signing key only so a test APK can be installed. **This test APK is not the Play Store release signing key.** Before the first Play Store release, configure a permanent protected upload/release keystore in GitHub Secrets and create a separate signed AAB release workflow. Never commit the keystore or passwords to the repository.

## Database safety
No database reset, DROP, user-ID renumbering, or destructive migration is part of V-114. Existing permanent IDs and existing auth data must remain intact.
