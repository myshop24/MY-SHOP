# MY SHOP V-43 — Login/Open + Compile Hardening

## Baseline
- V-28 source preserved as the baseline; V-28 is not overwritten.
- applicationId remains `com.myshop.app`.

## Critical fixes
- Version changed to `43` / `2.9.43`.
- LoginActivity explicitly imports `android.widget.Button` so any Button usage cannot fail with `cannot find symbol: class Button`.
- LoginActivity now has a programmatic fallback login screen if the XML login layout fails to inflate.
- Login fallback uses the same authentication path; it does not bypass authentication.
- MainActivity searchBox listener remains attached to the typed `EditText` field.
- Resource-ID audit found no Java `R.id` references missing from the project resources.
- Admin credentials remain absent from Java source; role authority remains backend-owned.

## Build gate
- `clean` must pass.
- duplicate-class check must pass.
- Java compilation must pass.
- `assembleDebug` must pass.
- exactly one final APK must be found.
- APK package must be `com.myshop.app`.
- APK version must be code `43`, name `2.9.43`.
- APK ZIP integrity must pass.

## Runtime gate
Build success alone is not final success. The APK must be installed and tested for: launch -> Login screen -> Create Account screen -> login attempt -> Dashboard transition without crash/blank screen.
