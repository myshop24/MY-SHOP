# MY SHOP V-198 — Full Content-Write Compatibility Fix

## Root cause fixed
Production legacy `banners` and `banner_media` schemas use `slot BETWEEN 1 AND 6`. The V-197 health probe incorrectly used `slot=999`, causing a D1 CHECK constraint failure and HTTP 503.

## Fix
- Health probe uses `slot=1` for `banners` and `banner_media`.
- Cleanup uses the same valid slot.
- Dashboard ad probe also uses slot 1.
- Content-write workflow preserves the HTTP response body when a probe fails, so any future server-side error is visible in the log.
- No D1 table/row deletion or destructive migration was added.

## Verification performed
- Source build ID: V-198
- Worker marker: V-198 / 2.9.198
- Android version: 198 / 2.9.198
- Node syntax check: required before release
- Workflow YAML parse: required before release
- Content-write probe values audited against bundled migration constraints.
