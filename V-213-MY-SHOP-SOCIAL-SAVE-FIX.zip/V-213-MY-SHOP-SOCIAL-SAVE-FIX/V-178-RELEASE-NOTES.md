# MY SHOP V-178 Release Notes

This build is a consolidated correction pass based on the reported V-175/V-176/V-177 UI results.

### Root cause fixed
The app was using `RippleDrawable` as a **foreground** on several TextViews/cards. That foreground could draw over the existing content, producing the reported blank white/green/blue buttons and blank menu/MORE cards. V-178 moves ripple feedback into the background layer so text and icons remain visible.

### Feed
- Like and Comment are compact buttons.
- Like count remains visible.
- Comment count is now supplied by the Worker and updates after a successful comment.

### Backend
- `/v1/feed` now returns `commentCount`.
- `/v1/feed/comment` returns the updated comment count.
- Existing notification and D1/R2 safeguards remain.

No user/auth data reset or destructive migration was introduced.
