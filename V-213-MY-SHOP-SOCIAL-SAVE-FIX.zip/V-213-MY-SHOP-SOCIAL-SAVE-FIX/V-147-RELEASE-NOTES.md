# MY SHOP V-147 — VIDEO FIX RELEASE

## Targeted fixes from 77226.mp4
- Production API routes used by Feed, Gallery, Notifications, Profile and Admin content are deployed by the release workflow from the exact V-147 source.
- Gallery is viewable by all logged-in users; only Admin sees upload/edit/delete controls.
- Feed supports text-only posts through `/v1/feed/text`.
- Social links are saved from Admin and displayed with a URL-derived site favicon when available.
- Breaking ticker is taller and uses 18sp marquee text for longer headlines.
- Profile avatar upload tolerates missing MIME metadata by safely guessing common image types from the filename.
- D1 database `my-shop-db` and R2 bucket `my-shop-media` remain the same; no destructive migration/reset/drop/truncate is included.
- Release APK uses the permanent signing-key secrets so V-147 can update/replace the installed V-146 package without uninstalling, provided the same permanent key is configured.
- Workflow builds exactly one APK and deploys the same V-147 Worker source; it never selects an older V ZIP.
