from pathlib import Path
from PIL import Image
import json,re,zipfile
root=Path(__file__).resolve().parents[1]
build=(root/'app/build.gradle').read_text()
assert "versionCode 55" in build
assert "versionName '2.9.55'" in build
assert "applicationId 'com.myshop.app'" in build
main=(root/'app/src/main/java/com/myshop/app/MainActivity.java').read_text()
login=(root/'app/src/main/java/com/myshop/app/LoginActivity.java').read_text()
reg=(root/'app/src/main/java/com/myshop/app/RegisterActivity.java').read_text()
uid=(root/'app/src/main/java/com/myshop/app/UserIdManager.java').read_text()
admin=(root/'app/src/main/java/com/myshop/app/AdminIdentifiers.java').read_text()
inv=json.loads((root/'app/src/main/assets/final_feature_inventory.json').read_text())
assert 'MAX_BANNERS_PER_FOLDER = 6' in main
for p in ['banner_top_left','banner_top_right','banner_wide']:
    files=sorted((root/'app/src/main/res/drawable').glob(p+'_*.png'))
    assert len(files)==6,(p,len(files))
    for f in files: assert Image.open(f).width>0 and Image.open(f).height>0
for required in ['myshop_icon.png','myshop_login_header.png','myshop_dashboard_reference.png','feature_my_feed_selected.png','feature_my_shop_selected.png','feature_go_live_selected.png']:
    assert (root/'app/src/main/res/drawable'/required).exists(),required
assert 'ADVERTISEMENT' in main
for key in ['MY FEED','MY SHOP','GO LIVE','GALLERY','LIVE TV','SOCIAL','EXTERNAL','EARN & REWARD','SHARE']:
    assert key in main,key
assert 'Email অথবা Mobile' in reg
assert 'No OTP required' in (root/'app/src/main/res/layout/activity_login.xml').read_text()
assert 'FIRST_ID = 100' in uid and '%04d' in uid
for ident in ['myshopsatkania@gmail.com','touhidsatkania@gmail.com','01860626700']:
    assert ident in admin
for feat in ['login_register','profile_management','four_digit_user_id','three_admin_accounts','admin_auto_role_detection','six_moderators','six_banner_auto_slider','breaking_news','live_now','go_live_foundation','my_feed','my_shop_external_url','gallery_photo_audio_video','external_movie','live_tv','social_media','chat','earn_reward','share','payment_methods','remote_configuration']:
    assert feat in inv['features'],feat
# Prevent accidental old version claims in the main runtime/build metadata.
assert '2.9.54' not in build
print('V-55 source validation PASSED')
