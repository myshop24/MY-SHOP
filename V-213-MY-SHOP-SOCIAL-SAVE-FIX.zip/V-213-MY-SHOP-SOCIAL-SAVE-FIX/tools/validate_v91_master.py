from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[1]
APP = ROOT/'app'/'build.gradle'
MANIFEST = ROOT/'app'/'src'/'main'/'AndroidManifest.xml'
LOGIN = ROOT/'app'/'src'/'main'/'java'/'com'/'myshop'/'app'/'LoginActivity.java'
ACCOUNT = list(ROOT.rglob('AccountStore.java'))
assert APP.is_file()
assert MANIFEST.is_file()
assert LOGIN.is_file()
assert len(ACCOUNT)==1, f'expected 1 AccountStore.java, found {len(ACCOUNT)}'
s=APP.read_text()
assert re.search(r"applicationId\s+'com\.myshop\.app'",s)
assert re.search(r'versionCode\s+90\b',s)
assert re.search(r"versionName\s+'2\.9\.90'",s)
m=MANIFEST.read_text()
for x in ['android:name=".LoginActivity"','android:name="android.intent.action.MAIN"','android:name="android.intent.category.LAUNCHER"','android:exported="true"']:
    assert x in m, x
l=LOGIN.read_text()
assert 'public class LoginActivity extends android.app.Activity' in l
assert 'androidx.appcompat.app.AppCompatActivity' not in l
wf=list((ROOT/'.github'/'workflows').glob('*.yml'))
assert len(wf)==1, f'expected exactly 1 active workflow, found {len(wf)}'
w=wf[0].read_text()
for x in ['V-91','V-91_MY_SHOP_FULL_PROJECT_SOURCE.zip','versionCode 91','2.9.91','V-91 MY SHOP FINAL RELEASE.apk','V-91-MY-SHOP-FINAL-RELEASE']:
    assert x in w, x
assert 'V-80' not in w
print('V-91 MASTER VALIDATION PASSED')
print('package=com.myshop.app')
print('versionCode=90')
print('versionName=2.9.91')
print('launcher=com.myshop.app.LoginActivity')
