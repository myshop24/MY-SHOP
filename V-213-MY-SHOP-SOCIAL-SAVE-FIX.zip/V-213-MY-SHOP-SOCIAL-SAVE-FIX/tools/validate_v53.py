from pathlib import Path
import re, zipfile
root=Path(__file__).resolve().parents[1]
build=(root/'app/build.gradle').read_text()
assert re.search(r'versionCode\s+52',build)
assert "versionName '2.9.53'" in build
main=(root/'app/src/main/java/com/myshop/app/MainActivity.java').read_text()
assert 'MAX_BANNERS_PER_FOLDER = 6' in main
for p in ['banner_top_left','banner_top_right','banner_wide']:
    assert len(list((root/'app/src/main/res/drawable').glob(p+'_*.png')))==6
assert 'ADVERTISEMENT' in main
assert 'MY FEED' in main and 'MY SHOP' in main and 'GO LIVE' in main
print('V-53 source validation PASSED')
