from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
gradle = (root/'app/build.gradle').read_text()
assert re.search(r'versionCode\s+92\b', gradle)
assert "versionName '2.9.92'" in gradle
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
assert 'android:name=".LoginActivity"' in manifest
assert 'android:name="android.intent.action.MAIN"' in manifest
assert 'android:name="android.intent.category.LAUNCHER"' in manifest
img=root/'app/src/main/res/drawable/myshop_dashboard_reference.png'
assert img.read_bytes()[:8] == b'\x89PNG\r\n\x1a\n'
register=(root/'app/src/main/java/com/myshop/app/RegisterActivity.java').read_text()
assert 'What is your favorite teacher name?' in register
login=(root/'app/src/main/java/com/myshop/app/LoginActivity.java').read_text()
assert 'resetPasswordWithTwoOfThree' in login
assert 'getSecurityQuestions' in login
print('V-92 static validation: PASS')
