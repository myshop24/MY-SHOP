# MY SHOP V-172

Build-failure correction for V-171.

1. Added the missing `android.widget.ScrollView` import in `FeatureActivity.java`; this fixes the `cannot find symbol: class ScrollView` compile errors shown by GitHub Actions.
2. Incremented app version to `versionCode 172` / `versionName 2.9.172` so the corrected source is a new build and never reuses V-171.
3. Preserved all V-171 feature, backend, D1/R2, authentication, and data-safety changes.

Data safety: no auth/user tables are dropped or reset; existing D1/R2 bindings and backend URL remain unchanged.
