# MY SHOP V-176 Release Notes

Final correction package for the eight reported V-175 runtime/UI issues.

- Bottom navigation/Home alignment
- Like/Comment/count styling
- User MORE routing
- Hamburger/User Menu visibility
- External Movie 6-slot CRUD
- Notification inbox visibility
- Media upload picker compatibility
- Existing D1/R2/auth data preserved; no destructive auth-table SQL
