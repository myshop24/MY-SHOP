# V-181 — MY SHOP Advertisement + Login Flow Fix

## Fixes
- Fixed startup advertisement cropping: wide banner now uses CENTER_INSIDE so the full artwork remains visible on portrait phones.
- Removed silent automatic login redirect from LoginActivity.
- User must explicitly press LOGIN or Continue with Google before entering Dashboard.
- Existing login/session storage is preserved; V-180 remains unchanged.

## Version
- versionCode: 181
- versionName: 2.9.180
