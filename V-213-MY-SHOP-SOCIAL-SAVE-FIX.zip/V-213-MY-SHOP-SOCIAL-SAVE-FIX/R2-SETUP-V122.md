# MY SHOP V-122 R2 setup

V-122 adds a Cloudflare R2 binding named `MEDIA` and expects the bucket:

`my-shop-media`

Create that bucket in the same Cloudflare account used by the `my-shop-api` Worker. The Wrangler file already contains:

```toml
[[r2_buckets]]
binding = "MEDIA"
bucket_name = "my-shop-media"
```

The Worker serves stored media through `/v1/media/<object-key>`, so the bucket itself does not need to be publicly exposed.

GitHub Actions still needs the existing Cloudflare deployment secrets for automatic Worker deployment. The Android release/update signing key must remain permanent for seamless in-place updates.
