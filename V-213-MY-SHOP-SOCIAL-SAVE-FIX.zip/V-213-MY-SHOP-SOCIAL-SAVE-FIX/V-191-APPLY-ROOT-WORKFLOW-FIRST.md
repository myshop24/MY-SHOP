# V-191 — FIRST STEP BEFORE RUNNING APK BUILD

The repository-root GitHub Actions workflow is the workflow that actually runs.
A `.github/workflows/my-shop-apk.yml` file stored only inside a ZIP does not automatically replace the repository's existing workflow.

Before running V-191:
1. Replace the repository-root `.github/workflows/my-shop-apk.yml` with the V-191 workflow included in this release.
2. Confirm the workflow name is `MY SHOP V-191 PERMANENT CLOUD D1 R2 FIX RELEASE`.
3. Confirm the job contains the Cloudflare checks before Gradle:
   - `/health`
   - `/health/deep`
   - `/v1/dashboard/config`
   - `/health/content-write-suite`
4. Only then run the V-191 workflow.

If the Cloudflare gate fails, do not bypass it and do not build the APK. The failure output is the evidence needed to fix the real backend/infrastructure layer.
