# MY SHOP V-174 — MASTER FINAL CHECKLIST

1. Notification error: endpoint/schema guard, retry/error feedback, mark-seen refresh.
2. 3-line menu: three-color lines + matching semantic icons for menu items.
3. External Save: dedicated External Movie Save button; server config save/reload.
4. MORE: Facebook, Page, YouTube, WhatsApp, imo, Instagram, Telegram; Admin-controlled links; WhatsApp/imo number or URL; Customer Support WhatsApp number/URL; Share App.
5. Profile picture: sync `/v1/me` into local session so dashboard header and MY FEED composer use the same current avatar.
6. Ads/links/notifications: Worker/D1/R2 path checked in source; notification/dashboard routes initialize schema before query.
7. Buttons: crisp, responsive, ripple, elevation, rounded styling; bottom nav uses vector icons instead of glyphs.
8. Performance: shared image executor + LRU bitmap cache; reduced feed reload frequency; notification polling 15s.
9. Header: moved slightly down; smaller logo/text; mixed-color MY SHOP; balanced spacing.
10. Dashboard layout: extra bottom safe space; bottom nav no longer covers feed; responsive content spacing.
11. Bottom nav: Home/Store/Live/Support/More vector icons, crisp active/inactive states.
12. Feature decisions: Search remains; Like/Comment remain; MY FEED post Share remains intentionally absent; MORE Share remains.
13. Store cart/wishlist/order tracking remain future phase.
14. Keep app lightweight/free-tier friendly; no unnecessary new heavy features.
15. Final quality: responsive sizes, weak network, loading/error/retry, D1 save→reload, backend response, notifications, profile, links, buttons, navigation, performance, data safety, Play Store readiness.

DATA SAFETY: no auth/user table deletion or reset added by V-174.
VERSION: V-174 / app 2.9.174.
BACKEND: rapid-bush-62ea / my-shop-db / MEDIA.
