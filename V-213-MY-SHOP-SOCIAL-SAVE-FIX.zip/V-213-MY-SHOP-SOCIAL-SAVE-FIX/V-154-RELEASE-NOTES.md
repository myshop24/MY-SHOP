# MY SHOP V-154

- Permanent-data-safe continuation from V-153.
- No D1/R2 reset, drop, truncate, ID regeneration, or user/account deletion.
- Feed actions redesigned to compact white Facebook-style Like/Comment buttons; Share removed.
- Added real Like toggle and Comment endpoints; likes/comments create user-targeted notifications.
- Gallery user view: no admin instruction/footer text; PHOTO/AUDIO/VIDEO tabs all viewable, management remains Admin-only.
- Social link Save/Delete controls retained.
- Same package/applicationId and higher versionCode for update install.
