# MY SHOP V-54

- VersionCode: 54
- VersionName: 2.9.54
- Fixed GitHub Actions version mismatch.
- Selected MY SHOP login design asset is used at runtime.
- Selected dashboard banner assets are used at runtime.
- Six slots per top-left, top-right and wide banner folder.
- User ID allocation starts at 0100 and increments 0101, 0102... for local fallback.
- Dashboard header now displays the actual signed-in User ID instead of hard-coded 1024.
- Previous V-53 source remains preserved and is not overwritten.
