# MY SHOP V-153 — FINAL BUILD PIPELINE FIX

- V-152 source preserved as the baseline; no D1/R2 reset, drop, truncate, ID regeneration, or destructive migration.
- App version bumped to **2.9.153 / versionCode 153** so the update cannot reuse the previous build number.
- Backend health build marker bumped to **V-153**.
- Cloudflare Worker remains **rapid-bush-62ea** with the existing D1 database and R2 binding.
- GitHub Actions no longer extracts an older V-numbered ZIP to build the APK. It builds the checked-out V-153 source directly.
- Workflow verifies package `com.myshop.app`, versionName `2.9.153`, versionCode `153`, permanent signing key, and exactly one final APK.
- Worker is deployed and health/deep-health/dashboard checks must pass before APK build is accepted.
- Final artifact: `MY_SHOP_FINAL_RELEASE.apk` only.
