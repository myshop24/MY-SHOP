# Gradle Wrapper status

The source archive inherited from V-72 did not contain `gradlew`, `gradlew.bat`, or `gradle/wrapper/gradle-wrapper.jar`.

The V-73 GitHub Actions workflow does not require those files because it installs Gradle 8.11.1 with `gradle/actions/setup-gradle@v4` and invokes `gradle` directly.

Do not treat the wrapper as complete until the three launcher artifacts are present.
