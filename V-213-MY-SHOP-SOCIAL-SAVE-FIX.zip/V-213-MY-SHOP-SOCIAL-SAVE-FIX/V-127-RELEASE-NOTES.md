# V-127 MY SHOP — User Menu Compile Fix

## Exact failure fixed
GitHub Actions V-126 failed in `UserMenuActivity.java` at the GALLERY and ACCOUNT menu rows with Java parser errors (`)` expected).

## Fix
Replaced the two inline `new Intent(...)` lambda expressions with explicit `Intent` local variables and a block lambda. This removes the parser ambiguity while preserving the same user-visible behavior.

## Safety
- No D1 schema changes.
- No user/auth data changes.
- Permanent IDs unchanged.
- Admin-only access logic unchanged.
- Admin panel remains hidden from normal users.
- Version: 2.9.127 / versionCode 127.
- Backend URL unchanged.
