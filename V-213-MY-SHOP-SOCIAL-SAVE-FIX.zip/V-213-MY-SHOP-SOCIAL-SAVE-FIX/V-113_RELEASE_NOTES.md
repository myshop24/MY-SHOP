# MY SHOP V-113 Release Notes

Purpose: simplify authentication recovery and reduce registration friction.

Main change: one security question + one answer. Forgot Password shows that saved question after the user enters Email, Mobile, or permanent User ID. A correct answer permits setting a new password.

Safety: existing database tables are retained; permanent User IDs are not changed; existing records are not cleared.

Important: V-113 is not a Play Store release candidate until the matching backend is deployed and live functional tests pass.
