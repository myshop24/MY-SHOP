# IMPORTANT — Repository Root Workflow

The `.github/workflows/my-shop-apk.yml` inside this full project is the V-137 build + Worker deployment workflow.

GitHub Actions only executes workflow files that exist under the repository root `.github/workflows/` directory. Uploading this ZIP as a single file does not automatically install its nested workflow.

Before treating V-137 as a server release, the repository-root workflow must be the V-137 workflow and its `deploy-worker` job must finish successfully. Required secrets: `CLOUDFLARE_API_TOKEN` and `CLOUDFLARE_ACCOUNT_ID`.
