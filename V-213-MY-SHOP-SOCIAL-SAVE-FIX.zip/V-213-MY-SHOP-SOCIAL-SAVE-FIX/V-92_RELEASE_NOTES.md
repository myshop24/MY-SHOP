# V-92 MY SHOP — Phase 1

Scope of this version is intentionally limited to the first stable flow:

1. App icon / launcher
2. Login board
3. Create Account
4. Permanent four-digit User ID flow (local fallback until backend allocator is wired)
5. Forgot Password using 3 saved security questions; 2 of 3 correct answers reset password
6. Login/Create Account -> Main Dashboard opening
7. Preserve the existing dashboard design and feature tiles without changing later feature modules.

Changes:
- Version bumped to 2.9.92 / versionCode 92.
- Fixed `myshop_dashboard_reference.png` content type: it was a JPEG stored with a PNG filename and could fail AAPT resource compilation.
- Create Account now offers six security questions; exactly three unique questions are selected.
- Forgot Password now first resolves the account and displays the user's three saved questions before collecting answers.
- Password reset keeps the Permanent User ID unchanged.
- Existing V-91 source remains the baseline backup and is not overwritten.

Important:
- This ZIP preserves the existing project architecture. The source currently contains a local account store and explicitly documents that production authentication/ID allocation belongs to the backend. A backend adapter/atomic allocator should be wired in a later controlled phase rather than inventing credentials or endpoints here.
