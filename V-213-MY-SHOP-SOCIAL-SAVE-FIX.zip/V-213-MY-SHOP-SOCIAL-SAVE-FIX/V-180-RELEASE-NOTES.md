# V-180 — MY SHOP Startup Ad + Google Login UI

## Base
- Built from V-179-MY-SHOP-FINAL-MASTER-FIX.
- V-179 remains untouched and is the rollback backup.

## Implemented
1. Added a 3-second startup advertisement screen using the existing MY SHOP banner asset.
2. Added Skip countdown and automatic transition to the existing Login screen.
3. Added Continue with Google button to the existing Login screen without removing Email / Mobile / User ID + Password login.
4. Added `GOOGLE_WEB_CLIENT_ID` BuildConfig placeholder for the Google Cloud OAuth credential.
5. Kept existing backend/session/login logic unchanged.

## Not yet live
- Real Google OAuth token verification and account linking require a real Google Cloud OAuth Client ID and backend verification endpoint.
- No existing V-179 login data or role logic was replaced.

## Version
- Android versionCode: 180
- Android versionName: 2.9.180
