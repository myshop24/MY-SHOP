# V-114 Release Notes

## Purpose
Fix the build pipeline that was still using the old V-109 workflow/source selection, which could produce an APK showing the old three-security-question registration UI even when the V-113 source had already been changed to one question.

## Authentication UI
- One security question only.
- One security answer only.
- Forgot Password fetches the saved question for the account.
- Correct answer permits a new password.
- Permanent User ID remains unchanged.

## Backend
- Existing auth namespace remains `myshop_auth_users_v108`.
- Existing data is preserved.
- PBKDF2 remains at the Cloudflare-compatible 100,000 iteration setting.

## Build
- versionCode: 114
- versionName: 2.9.114
- compileSdk: 36
- targetSdk: 36
- Production Worker URL remains `https://rapid-bush-62ea.myshopsatkania.workers.dev`.
- GitHub workflow now builds from exact V-114 source and refuses old V-109 source/version checks.

## Verification
The workflow verifies source version, backend URL, single-question registration layout, APK package/version, APK signature validity, and exactly one final test APK artifact.
