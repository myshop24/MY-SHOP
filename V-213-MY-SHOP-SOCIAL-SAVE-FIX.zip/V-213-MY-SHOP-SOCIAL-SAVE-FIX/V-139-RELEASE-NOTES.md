# MY SHOP V-140 — DATA SAFE + REAL USER GALLERY + PROFILE + DASHBOARD ADS

## Baseline
- Protected baseline: V-138.
- V-138 backup is delivered separately as `V-138-BACKUP-BEFORE-V139.zip`.
- No production D1 reset, DROP, TRUNCATE, user-ID regeneration, or destructive migration was added.

## User Gallery
- Gallery now has independent PHOTO / AUDIO / VIDEO folders.
- Users can select one or multiple files from the phone using the Android document picker.
- There is no item-count cap in the app/backend; each individual file remains subject to a 50 MB Worker/R2 limit and the actual R2 account quota.
- Each upload stores the media object in R2 and its metadata/owner in D1.
- Each user's own media supports caption/title edit and delete.
- Ownership is enforced by `owner_user_id`; existing rows remain nullable/untouched.
- Existing Admin Gallery controls remain separate.

## Profile
- Premium dark/purple profile presentation.
- Permanent User ID is read-only.
- Real profile update endpoint and real avatar upload endpoint use the same existing Worker/D1/R2.
- Added Coin Balance, Buy Coins, Coin History, Gift History, My Live, My Gallery and security/support areas.
- Payment request methods: bKash, Nagad, Bangla QR.
- Coin credit is not granted by the APK; server-side approval is required.

## Dashboard advertisements
- New additive `dashboard_ads` table.
- Every configured dashboard box can have up to 6 advertisement slots.
- Admin can upload/change/edit/delete each slot.
- LIVE NOW has a rotating advertisement strip that can coexist with the live cards; if no ads exist, the strip stays hidden.
- The same generic six-slot API is available for other dashboard boxes without changing their existing data.

## Banner safety
- Banner replacement uploads the new R2 object first, then updates D1, and only then removes the old object.
- If R2 or D1 update fails, the previous banner remains intact.

## D1/R2 automatic behavior
- APK keeps the stable Worker URL `https://rapid-bush-62ea.myshopsatkania.workers.dev`.
- The Worker remains bound to the existing D1 database `my-shop-db` and R2 bucket `my-shop-media`.
- Installing a new APK does not perform D1 setup; D1/R2 are server-side resources owned by the Worker deployment.
- Worker deep health must report database/schema/R2 as OK before the release is considered verified.

## Build integrity
- Version code: 139.
- Version name: 2.9.139.
- Workflow selects the exact V-139 source archive.
- Build fails if more than one release APK exists.
- Final APK filename: `MY_SHOP_FINAL_RELEASE.apk`.
