# R2 — MY SHOP-এর জন্য কেন দরকার

Cloudflare D1 এবং R2-এর কাজ আলাদা:

- **D1** = user/account/configuration/metadata/transaction database.
- **R2** = আসল file storage — Photo, Audio, Video, Avatar, Banner, Advertisement image ইত্যাদি।

## সুবিধা
1. বড় media file D1-এর ভিতরে রাখার দরকার হয় না।
2. Photo/Audio/Video/Avatar/Banner আলাদা object হিসেবে রাখা যায়।
3. Worker R2 থেকে file stream করে Android app-এ দিতে পারে।
4. D1-এর user/account data ছোট ও manageable থাকে।
5. একই R2 object-কে D1 metadata-এর সঙ্গে owner/user ID দিয়ে যুক্ত করা যায়।
6. পুরোনো media update করার সময় নতুন object আগে লিখে পরে পুরোনো object delete করলে safer replacement করা যায়।

## অসুবিধা / সীমাবদ্ধতা
1. R2 একটি আলাদা storage service; storage এবং operation usage অনুযায়ী খরচ/limits থাকতে পারে।
2. Worker/R2 binding ভুল হলে media upload/read ব্যর্থ হতে পারে।
3. R2 object-এর জন্য access route ঠিক রাখতে হয়; MY SHOP-এ Worker `/v1/media/...` route দিয়ে private bucket access দিচ্ছে।
4. APK-তে R2 credential রাখা যাবে না। Credential/binding শুধু Cloudflare Worker-এ থাকবে।

## MY SHOP-এ R2 কেন প্রয়োজন
আপনার পরিকল্পনায় Photo, Audio, Video, Profile Photo, Banner এবং Dashboard Advertisement আছে। এগুলো D1-এর জন্য উপযুক্ত data নয়; D1 metadata রাখবে এবং R2 actual bytes রাখবে।

**সবচেয়ে গুরুত্বপূর্ণ:** নতুন APK install/update করলে R2 বা D1 নতুন করে তৈরি হবে না। APK একই stable Worker URL ব্যবহার করবে, আর Worker একই existing D1/R2 binding ব্যবহার করবে।
