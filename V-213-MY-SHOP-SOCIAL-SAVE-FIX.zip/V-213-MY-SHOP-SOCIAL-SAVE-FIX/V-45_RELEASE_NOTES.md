# MY SHOP V-45 — SearchBox / Build Validator Fix

- V-44 preserved as a separate backup.
- Version Code: 45
- Version Name: 2.9.45
- Application ID: com.myshop.app
- LoginActivity remains the launcher; MainActivity is opened only after login/registration.
- MainActivity search box is now a typed field (`EditText searchBox`) with its listener attached to that field.
- The V-45 workflow no longer requires a nonexistent `findViewById(R.id.searchBox)` binding for a programmatically built dashboard.
- The unsafe direct listener expression is explicitly rejected.
- Build must produce exactly one APK and verify package/version/integrity.
