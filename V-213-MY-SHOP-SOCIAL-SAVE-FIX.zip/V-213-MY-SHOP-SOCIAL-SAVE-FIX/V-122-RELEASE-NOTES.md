# MY SHOP V-122 — FULL ADMIN CONTENT + R2 MEDIA + GALLERY MANAGER

Based on V-121 full project archive. This is a complete restoreable project archive.

## Main goals
- Keep the approved MY SHOP dashboard layout from V-121.
- Keep permanent User IDs and existing D1/auth data untouched.
- Make the Admin console genuinely usable for add/edit/delete/save/hide controls.
- Add R2-backed media upload/delete for banners and gallery media.
- Add Gallery management with three folders: PHOTO, AUDIO, VIDEO.
- Store title/caption/type/order/active state for gallery media.
- Keep four-language picker: বাংলা / English / हिन्दी / العربية.
- Keep hamburger → server-authorized Admin Control for fixed admin IDs 0001/0002/0003.

## R2
Worker expects an R2 bucket named `my-shop-media` through binding `MEDIA`.
Media is served through the Worker `/v1/media/<object-key>` route, so the R2 bucket does not need to be publicly exposed.

## Safety
- No DROP, DELETE, RESET, or recreation of auth/user tables.
- Existing permanent IDs remain unchanged.
- Content/media tables are additive-only.
- Existing URL-based content continues to work.

## Build
- versionCode: 122
- versionName: 2.9.122
- compileSdk: 36
- targetSdk: 36
- package: com.myshop.app
