# MY SHOP V-142

## Main changes
- Facebook-style MY FEED is embedded below the main dashboard content and loads posts progressively while scrolling.
- Ordinary User: maximum 1 post per server day, image + caption.
- User video upload button remains visible but locked.
- Admin: video post upload is available.
- Post media is stored in R2; metadata/ownership/moderation state stays in D1.
- User can delete their own post. Admin or assigned Moderator can remove inappropriate posts.
- Removing a post does not delete the account, permanent User ID, or unrelated data.
- Dashboard keeps the approved layout: headline at top, hero advertisement, two compact promo advertisements, LIVE NOW, GO LIVE/JOIN LIVE, then MY SHOP/GALLERY/EXTERNAL MOVIE/EARN & REWARD/MORE.
- Audio/Video Gallery buttons remain visible for Users but their upload action is locked; Admin can upload them.
- Profile avatar remains one replaceable R2 object; maximum avatar size reduced to 5 MB.
- All D1 changes are additive-only. No user/auth table is dropped, reset, or truncated.

## Safety / deployment
- V-141 is preserved as the rollback backup.
- Worker deployment is mandatory in the V-142 workflow and is verified with `/health`, `/health/deep`, and `/v1/dashboard/config`.
- Release target: `2.9.142`, build `142`.
- Final artifact policy: exactly one APK named `MY_SHOP_FINAL_RELEASE.apk`.
