# V-139 Data Safety Manifest

Protected baseline: V-138-BACKUP-BEFORE-V139.zip

Rules enforced in V-138:
1. Never reset or recreate production D1.
2. Never delete or regenerate permanent User IDs during an update.
3. Only additive schema changes are permitted.
4. New APK must point to the same Worker URL and existing D1/R2 bindings.
5. Release is not considered verified until Worker deep health reports database, schema, and R2 as OK.
6. Exactly one APK must exist in the final release directory.

7. User Gallery ownership is added as a nullable column; existing gallery rows are not rewritten or deleted.
8. User Gallery uploads have no item-count cap; each file remains subject to the per-file R2/Worker limit and account quota.
9. Dashboard ads use a new additive six-slot-per-box table; existing hero/promo banners are untouched.
10. APK always uses the same stable Worker URL; the Worker remains the only component bound to D1/R2, so installing a new APK does not require re-binding D1.
