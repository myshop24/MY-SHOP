# MY SHOP V-70

## This correction
- File/version naming is now explicitly V-70 / 2.9.70.
- Create Account keeps Email and Mobile optional as long as one is supplied.
- No OTP/verification-code flow is added.
- Permanent four-digit sequential IDs remain 0100, 0101, 0102... and are not tied to the app version.
- Registration now has one **Security Questions** box containing 3 separate question/answer pairs.
- Forgot Password opens one reset box containing the identifier, all 3 security answers, and the new password fields.
- Password reset succeeds only when any 2 of the 3 answers match.
- Security answers are stored as hashes, not plain text.
- The build pipeline cleans APK output and fails unless exactly one release APK exists.

## Important
This V-70 source is based on the latest MY SHOP source available in the project backup library (V-55). It does not overwrite older backups.
