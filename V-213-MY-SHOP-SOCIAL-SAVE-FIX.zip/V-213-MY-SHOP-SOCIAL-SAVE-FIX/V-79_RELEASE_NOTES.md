# MY SHOP V-79 — FULL PROJECT BACKUP / LAUNCH-HARDENED SOURCE

V-79 is based on the verified V-77 full source. The approved Login/Register/Dashboard assets and feature structure are preserved.

### V-79 changes
- versionCode: 79
- versionName: 2.9.79
- Launcher (`LoginActivity`) now has a recovery UI if the reference login layout fails to inflate.
- Recovery login still authenticates through the same local `AccountStore` and opens the same `MainActivity`.
- Reference-only dashboard image remains in the full source backup but is excluded from the release build inputs by the V-79 workflow.
- Release workflow requires exactly one Android project and exactly one final APK.
- Release verification checks package name, versionCode, versionName, and launcher activity before upload.

### Backup rule
This ZIP is the full source project for Google Drive backup. Do not delete V-77/V-78 backups.
