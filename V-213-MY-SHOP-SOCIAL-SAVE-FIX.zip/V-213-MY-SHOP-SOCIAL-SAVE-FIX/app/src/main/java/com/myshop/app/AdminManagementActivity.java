package com.myshop.app;

import android.os.Bundle;

/** V-130: legacy entry point redirects to the secure colorful Admin Hub. */
public class AdminManagementActivity extends androidx.appcompat.app.AppCompatActivity {
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        String uid=SessionManager.getUserId(this);
        if(AdminIdentifiers.isAdminIdentifier(uid)){
            SessionManager.setRemoteSession(this,SessionManager.getToken(this),Role.ADMIN,AdminIdentifiers.adminIdFor(uid));
        }
        if(!SessionManager.isAdmin(this)){ finish(); return; }
        startActivity(new android.content.Intent(this,AdminHubActivity.class));
        finish();
    }
}
