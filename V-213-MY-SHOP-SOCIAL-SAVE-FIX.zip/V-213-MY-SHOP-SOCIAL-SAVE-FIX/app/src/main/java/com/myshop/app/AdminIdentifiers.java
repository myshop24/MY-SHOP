package com.myshop.app;

/**
 * Client-side identity labels only. Production authorization MUST be server-side.
 * The three supplied admin identities are mapped to fixed public admin IDs.
 */
public final class AdminIdentifiers {
    private AdminIdentifiers() {}

    public static boolean isAdminIdentifier(String value) {
        return adminIdFor(value) != null;
    }

    public static String adminIdFor(String value) {
        if (value == null) return null;
        String v = value.trim().toLowerCase(java.util.Locale.US);
        if (v.equals("myshopsatkania@gmail.com")) return "0001";
        if (v.equals("touhidsatkania@gmail.com")) return "0002";
        if (v.equals("01860626700")) return "0003";
        if (v.equals("0001") || v.equals("0002") || v.equals("0003")) return v;
        return null;
    }
}
