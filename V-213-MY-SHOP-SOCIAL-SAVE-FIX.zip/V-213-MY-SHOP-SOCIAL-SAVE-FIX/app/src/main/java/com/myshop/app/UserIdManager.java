package com.myshop.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Map;

/**
 * Local fallback allocator for development/offline registration.
 * Production MUST allocate the immutable four-digit ID atomically on the backend.
 * New local IDs are sequential from 0100 and existing IDs are never rewritten.
 */
public final class UserIdManager {
    private static final String PREFS = "myshop_users";
    private static final String KEY_NEXT = "next_serial_id";
    private static final int FIRST_ID = 100;
    private static final int LAST_ID = 9999;

    private UserIdManager() {}

    public static synchronized String peekNextLocalId(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int candidate = p.getInt(KEY_NEXT, FIRST_ID);

        // Repair the pointer against authoritative local account records so an app
        // update cannot accidentally reuse an already assigned ID.
        Map<String, ?> all = context.getSharedPreferences("myshop_accounts_v2", Context.MODE_PRIVATE).getAll();
        int max = FIRST_ID - 1;
        for (Map.Entry<String, ?> e : all.entrySet()) {
            String key = e.getKey();
            if (!key.startsWith("acct_uid_") || !key.endsWith("_user_id")) continue;
            String value = String.valueOf(e.getValue());
            if (value.matches("\\d{4}")) {
                try { max = Math.max(max, Integer.parseInt(value)); } catch (NumberFormatException ignored) {}
            }
        }
        candidate = Math.max(candidate, max + 1);
        if (candidate < FIRST_ID) candidate = FIRST_ID;
        if (candidate > LAST_ID) throw new IllegalStateException("No free four-digit User ID available.");
        return String.format("%04d", candidate);
    }

    public static synchronized void commitLocalAllocation(Context context, String allocatedId) {
        if (allocatedId == null || !allocatedId.matches("\\d{4}")) return;
        int value = Integer.parseInt(allocatedId);
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putInt(KEY_NEXT, Math.min(LAST_ID + 1, value + 1)).apply();
    }

    /** Backward-compatible name retained for older callers; allocation is sequential, not random. */
    public static synchronized String allocateLocalId(Context context) {
        String id = peekNextLocalId(context);
        commitLocalAllocation(context, id);
        return id;
    }
}
