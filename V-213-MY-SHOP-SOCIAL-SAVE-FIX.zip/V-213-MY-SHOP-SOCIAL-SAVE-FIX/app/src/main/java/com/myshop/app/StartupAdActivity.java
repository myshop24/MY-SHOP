package com.myshop.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** V-182: Admin-controlled startup advertisement. Default is the MY SHOP Live banner. */
public class StartupAdActivity extends Activity {
    private CountDownTimer timer;
    private boolean opened=false;
    private Button skip;
    private ImageView ad;
    private int seconds=3;

    @Override protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);
        ad=new ImageView(this); ad.setImageResource(R.drawable.startup_ad_myshop_live); ad.setScaleType(ImageView.ScaleType.CENTER_INSIDE); ad.setAdjustViewBounds(true);
        FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER); ap.setMargins(dp(8),dp(58),dp(8),dp(58)); root.addView(ad,ap);
        TextView label=new TextView(this); label.setText("ADVERTISEMENT"); label.setTextColor(Color.WHITE); label.setTextSize(11); label.setGravity(Gravity.CENTER); label.setBackgroundColor(0x99000000); FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(128),dp(34),Gravity.TOP|Gravity.START); lp.setMargins(dp(12),dp(12),0,0); root.addView(label,lp);
        skip=new Button(this); skip.setAllCaps(false); skip.setTextColor(Color.WHITE); skip.setBackgroundColor(0x99000000); FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(110),dp(48),Gravity.TOP|Gravity.END); sp.setMargins(0,dp(10),dp(10),0); root.addView(skip,sp); skip.setOnClickListener(v->openLogin());
        TextView hint=new TextView(this); hint.setText("MY SHOP • Live Shopping & Live Streaming"); hint.setTextColor(Color.WHITE); hint.setTextSize(12); hint.setGravity(Gravity.CENTER); hint.setBackgroundColor(0x66000000); FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-1,dp(40),Gravity.BOTTOM); hp.setMargins(dp(12),0,dp(12),dp(12)); root.addView(hint,hp);
        setContentView(root); loadRemoteAd();
    }

    private void loadRemoteAd(){
        if(!BackendClient.configured()){startTimer(3);return;}
        BackendClient.dashboard(null,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                runOnUiThread(()->{
                    try{
                        JSONArray ads=d.optJSONArray("dashboardAds"); JSONObject found=null;
                        if(ads!=null) for(int i=0;i<ads.length();i++){JSONObject x=ads.optJSONObject(i); if(x!=null&&"startup_ad".equalsIgnoreCase(x.optString("box_key",""))&&x.optInt("slot",0)==1&&x.optInt("active",1)==1){found=x;break;}}
                        if(found!=null){seconds=Math.max(1,Math.min(60,found.optInt("duration_sec",3)));String u=found.optString("image_url","").trim();String target=found.optString("target_url","").trim();if(!u.isEmpty())loadImage(u);if(!target.isEmpty())ad.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(target)));}catch(Exception ignored){}});} else seconds=3;
                    }catch(Exception ignored){seconds=3;}
                    startTimer(seconds);
                });
            }
            public void onError(String m){runOnUiThread(()->startTimer(3));}
        });
    }
    private void loadImage(String u){new Thread(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setDoInput(true);try(InputStream in=c.getInputStream()){android.graphics.Bitmap b=android.graphics.BitmapFactory.decodeStream(in);if(b!=null)runOnUiThread(()->ad.setImageBitmap(b));}}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}}).start();}
    private void startTimer(int sec){seconds=Math.max(1,sec);if(timer!=null)timer.cancel();timer=new CountDownTimer(seconds*1000L,1000){int left=seconds;public void onTick(long ms){skip.setText("Skip "+left);left--;}public void onFinish(){openLogin();}}.start();}
    private void openLogin(){if(opened)return;opened=true;if(timer!=null)timer.cancel();startActivity(new Intent(this,LoginActivity.class));finish();}
    @Override protected void onDestroy(){if(timer!=null)timer.cancel();super.onDestroy();}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
