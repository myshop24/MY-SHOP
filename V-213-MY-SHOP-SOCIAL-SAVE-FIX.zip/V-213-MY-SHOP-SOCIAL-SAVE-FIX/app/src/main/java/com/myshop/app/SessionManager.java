package com.myshop.app;

import android.content.Context;
import android.content.SharedPreferences;

/** Local session shell. Production authentication/roles must be supplied by the backend. */
public final class SessionManager {
    private static final String PREF = "myshop_session";
    private static final String ROLE = "role";
    private static final String USER_ID = "user_id";
    private static final String TOKEN = "token";

    private SessionManager() {}

    public static void setSession(Context c, Role role, String userId) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString(ROLE, role.name())
                .putString(USER_ID, userId == null ? "" : userId)
                .putBoolean("logged_in", role != Role.GUEST)
                .apply();
    }


    public static void setRemoteSession(Context c, String token, Role role, String userId) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString(TOKEN, token == null ? "" : token)
                .putString(ROLE, role.name())
                .putString(USER_ID, userId == null ? "" : userId)
                .putBoolean("logged_in", role != Role.GUEST).apply();
    }

    public static String getToken(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(TOKEN, "");
    }

    public static Role getRole(Context c) {
        String value = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getString(ROLE, Role.GUEST.name());
        try { return Role.valueOf(value); } catch (Exception ignored) { return Role.GUEST; }
    }

    public static String getUserId(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(USER_ID, "");
    }

    public static boolean isLoggedIn(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("logged_in", false); }

    public static boolean isAdmin(Context c) { return getRole(c) == Role.ADMIN; }
    public static boolean isModerator(Context c) { return getRole(c) == Role.MODERATOR; }

    public static void saveProfile(Context c, String name, String email, String mobile) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("full_name", name == null ? "" : name)
                .putString("email", email == null ? "" : email)
                .putString("mobile", mobile == null ? "" : mobile)
                .apply();
    }


    public static void saveProfile(Context c, String name, String email, String mobile, String avatarUrl, String bio) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("full_name", name == null ? "" : name)
                .putString("email", email == null ? "" : email)
                .putString("mobile", mobile == null ? "" : mobile)
                .putString("avatar_url", avatarUrl == null ? "" : avatarUrl)
                .putString("bio", bio == null ? "" : bio)
                .apply();
    }

    public static String getAvatarUrl(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("avatar_url", ""); }
    public static String getBio(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("bio", ""); }

    public static void clear(Context c) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply();
    }
}
