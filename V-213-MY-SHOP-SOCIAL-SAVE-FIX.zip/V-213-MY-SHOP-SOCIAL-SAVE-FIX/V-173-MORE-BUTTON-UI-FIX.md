# MY SHOP V-173 — MORE BUTTON UI FIX

- Reworked the User MORE screen into consistent rounded card buttons.
- Added spacing, elevation, ripple feedback, icon area, title/subtitle, and right-arrow affordance.
- Prevented overlap/cut-off by using responsive vertical cards inside a ScrollView.
- Unconfigured links remain visible but disabled; configured HTTP(S) links remain clickable.
- Preserved the existing backend-driven social link flow and data.
- Version: 2.9.173 / versionCode 173.
