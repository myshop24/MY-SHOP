# MY SHOP V-192 Release Notes

## Purpose
V-192 is the next sequential Full Project release after V-191.

## Fix
- Fixed the V-191 GitHub Actions preflight failure caused by the Java context-safety guard rejecting valid `new Intent(this, FeatureActivity.class)` calls.
- Current navigation now uses explicit Activity contexts (`MainActivity.this` / `UserMenuActivity.this`).
- The guard remains enabled to prevent callback-context regressions in future builds.

## Cloud / D1 / R2
- V-191 Cloudflare/D1/R2 verification architecture is preserved.
- Mandatory active Worker verification and content write-suite remain before Gradle.
- Durable non-destructive schema metadata migration added as `0002_v192_release_metadata.sql`.

## Release safety
- Permanent User/Admin identity rules preserved.
- Same package/application identity and permanent signing-key update model preserved.
- versionCode = 192
- versionName = 2.9.192
- SOURCE_BUILD_ID = MY SHOP V-192
- Older V-numbered releases remain untouched.

## Delivery rule
This release is delivered as a Full Project ZIP so it can be archived directly in Google Drive and reused as the source of future releases.
