# MY SHOP V-91 — CLEAN OPEN + DASHBOARD BASELINE

V-91 is the next controlled build baseline derived from the previously assembled MY SHOP source baseline.

### V-91 identity
- versionCode: 91
- versionName: 2.9.91
- package: com.myshop.app
- launcher: com.myshop.app.LoginActivity
- exactly one release APK is required
- permanent release signing secrets are required; no temporary signing key is generated

### Scope of this baseline
- Preserve the existing Login/Register/Dashboard structure.
- Prioritize reliable application startup.
- Keep the approved dashboard assets available as UI references.
- Prepare the project for the next step: full mobile-screen dashboard fitting and feature-by-feature verification.

### Important
This is a source/build baseline, not a claim that every backend or dashboard feature has been runtime-verified. GitHub Actions must pass the build and emulator launch smoke test before an APK is treated as testable.
