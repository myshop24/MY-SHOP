# MY SHOP V-76 — FULL-SCREEN DASHBOARD RELEASE CANDIDATE

V-76 is derived from V-73 and targets the reported mobile dashboard fit problem.

### Dashboard correction
- Full-screen immersive presentation enabled for MainActivity.
- Dashboard no longer uses a vertical ScrollView.
- The complete dashboard is laid out as one design surface and uniformly scaled to the available phone screen.
- Existing approved dashboard artwork, feature tiles, login/register flow, and click targets are preserved.

### Version
- versionName: `2.9.76`
- source versionCode: `76`

### Safety
- V-73 remains a separate backup.
- No production backend endpoint was guessed or invented.
