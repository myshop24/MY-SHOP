# MY SHOP V-145 — FIXED HEADER + USER GALLERY LOCK + POWER AD

- Preserves V-144 as the exact backup baseline.
- No D1/R2 reset, drop, truncate, ID regeneration, or destructive migration.
- Header and BREAKING News area are fixed; only the content below BREAKING scrolls.
- BREAKING badge is smaller and the headline gets more horizontal space; no View All.
- Normal Users cannot open the Gallery; Gallery is Admin Only.
- POWER AD / by Touhid appears in the left branding block of the ad strip, matching the approved reference.
- Admin dashboard settings include editable POWER AD title and byline with safe defaults.
- Existing remote ads remain supported; local fallback remains available when no remote ads exist.
- Release version: 2.9.145 / versionCode 145.
