# MY SHOP V-112 — PBKDF2 SERVER ERROR FIX

- Version code: 112
- Version name: 2.9.112
- Base: V-111 full project
- Root cause fixed: Cloudflare Worker Web Crypto rejected PBKDF2 iteration count 120000 with `Pbkdf2 failed: iteration counts above 100000`.
- New password hashes use PBKDF2-HMAC-SHA256 with exactly 100000 iterations.
- Existing database tables and user records are not dropped, cleared, renamed, or overwritten.
- Existing auth namespace `myshop_auth_users_v108` is preserved.
- Security-answer hashing remains SHA-256.
- Android source and backend URL are preserved except for the release version increment.
- V-111 archive remains unchanged as the rollback source.
