# V-125 MY SHOP — FINAL ADMIN / USER MENU POLISH

## Purpose
V-125 is the next full-project release based on V-124. It preserves the existing backend, D1 tables, permanent User IDs and R2 media architecture.

## Final UI changes
- Normal users now get a dedicated User Menu from the 3-line button.
- Admin users get a separate Admin Panel hub; admin controls are not shown in the normal user menu.
- Admin Hub separates Banner, Gallery, Dashboard/Features, Social/Other Links, and Moderator/Settings areas.
- Bottom navigation is raised slightly for easier touch access on mobile screens.
- Language button has a larger touch target and keeps বাংলা / English / हिन्दी / العربية picker behavior.

## Admin content controls carried forward
- Hero banners: 6 slots.
- Promo banners: 3 slots.
- Phone gallery upload to R2, caption save/edit/delete.
- Gallery folders: Photo / Audio / Video.
- Feature titles, icon URLs, target URLs, active state.
- Social links and other managed links.
- Breaking News and dashboard URLs.
- Moderator add/remove.

## Safety
- No auth-user reset.
- No permanent User ID reset.
- No destructive D1 migration.
- R2 media is stored through the Worker when the MEDIA binding is configured.

## Build
- versionCode: 125
- versionName: 2.9.125
- compileSdk: 36
- targetSdk: 36
- package: com.myshop.app
