# MY SHOP V-107

## Fix 1 — exactly one APK
- Uses only the V-107 source ZIP.
- Builds `assembleRelease`, not debug.
- Signs one final APK.
- Deletes intermediate APKs before artifact upload.
- Final guard requires exactly one `.apk` in `release/`.
- Artifact contains exactly one APK plus its SHA-256 file.

## Fix 2 — SERVER_ERROR / D1 schema mismatch
- Existing legacy `users` table is NOT dropped, renamed, cleared, or overwritten.
- New auth tables: `myshop_auth_users`, `myshop_auth_sessions`, `myshop_moderators`.
- Registration now uses the dedicated auth table.
- Permanent IDs: 0100, 0101, 0102...; admin IDs 0001/0002/0003 remain reserved.
- Admin identifiers are mapped to the three locked accounts.
- Forgot-password security answers use the 2-of-3 rule.
- Existing legacy data remains untouched.
