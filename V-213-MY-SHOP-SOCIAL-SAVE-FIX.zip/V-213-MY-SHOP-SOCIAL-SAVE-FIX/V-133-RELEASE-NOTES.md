# MY SHOP V-133 — ADMIN SERVER ERROR + BANNER PICKER + USER MENU FIX

## Main fixes
- **Admin Server Error hardening:** Worker schema initialization is now additive and fault-tolerant. A single pre-existing table/index problem no longer aborts every Admin request with `SERVER_ERROR`.
- **Dashboard config remains public and self-healing:** `GET /v1/dashboard/config` ensures its own row and safely returns empty content arrays when optional content tables are unavailable.
- **Admin Banner Manager:** each Hero/Promo slot now has a clear **CHANGE PHOTO / PHONE GALLERY**, **EDIT**, **SAVE**, and **DELETE** flow. Tapping the slot/card also opens the phone photo picker.
- **Banner edit flow:** Edit opens a caption/headline editor; Save persists it to D1.
- **Gallery Manager:** Photo/Audio/Video upload continues to use the Android phone picker and has clearer edit/save/delete controls.
- **User Menu layout:** increased row heights and text containers to prevent title/description clipping and overlap on high-density phones.
- **Admin-only security preserved:** normal users still do not receive Admin controls; backend Admin authorization remains enforced.
- **User/auth data preserved:** no auth tables, permanent IDs, or existing user records are reset/deleted.
- **Release version:** Android `versionCode 133`, `versionName 2.9.133`.
- **Build workflow:** updated to build exactly one V-133 APK and deploy the matching Worker when Cloudflare secrets are configured.

## Verification performed locally
- Java source structure checked.
- Worker JavaScript checked with `node --check`.
- Archive will contain source/config/backend only; no duplicate APK or `.sha256` files are bundled inside the project archive.
- Production Worker cannot be truthfully marked live-verified from this environment; the GitHub deploy job is included to publish the exact matching Worker.
