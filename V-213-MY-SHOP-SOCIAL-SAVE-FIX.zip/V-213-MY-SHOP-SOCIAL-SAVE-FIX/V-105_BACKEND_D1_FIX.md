# MY SHOP V-105 — Backend D1 Configuration

- Android versionCode: 105
- Android versionName: 2.9.105
- Production Worker URL: https://rapid-bush-62ea.myshopsatkania.workers.dev
- Worker: rapid-bush-62ea
- D1 database: my-shop-db
- D1 database_id: 15b6acd2-0e82-4bd8-95fb-bee6fc08936c

The D1 ID is now configured in backend/worker/wrangler.toml.
