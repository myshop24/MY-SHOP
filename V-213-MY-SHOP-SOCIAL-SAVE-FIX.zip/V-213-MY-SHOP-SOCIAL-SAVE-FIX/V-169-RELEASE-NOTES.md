# V-169 FINAL FEATURE FIX

This build is based on the tested V-168 source and fixes the items reported during the user/admin test.

- Hamburger menu now renders the full requested user feature list instead of only Search.
- Header MY SHOP logo/text footprint reduced.
- Breaking News arrow removed; only rotating 🌎 remains beside the scrolling news.
- Admin taps route directly to the relevant manager; dashboard/live ad manager can open the exact box instead of the global box list.
- More screen now renders configured Facebook, Page, YouTube, WhatsApp, imo, Instagram and Telegram buttons, plus Customer Support and Share App.
- Admin More folder provides link fields for those seven buttons and a separate WhatsApp Customer Support field.
- WhatsApp support accepts a link or number and the number is not displayed in the user UI.
- Feed like counts are returned by the backend and displayed compactly beside Like; the count updates immediately after a like/unlike.
- Like/comment actions refresh the notification badge immediately.
- Existing D1/R2 content-management and notification contracts are preserved.
