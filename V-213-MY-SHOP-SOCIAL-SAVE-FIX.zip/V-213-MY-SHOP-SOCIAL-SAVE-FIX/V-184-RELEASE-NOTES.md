# V-184 Release Notes

## Purpose
Fix the MY SHOP in-app notification box and carry forward all permanent Developer Instructions from V-183.

## Changes
- Notification schema self-heals before notification reads/writes.
- Like notifications are created for the post owner.
- Comment notifications are created for the post owner.
- Broadcast MY SHOP update notifications continue for supported Admin content changes.
- Notification DB failures are logged and returned explicitly where the notification endpoint itself is affected.
- Like/comment actions no longer fail merely because notification creation fails.
- Notification inbox refreshes on resume and every 15 seconds while visible.
- Added manual Refresh control.
- Preserved permanent User/Admin ID rules, existing authentication, startup ad, Admin controls, Cloudflare architecture and previous version protections.
- V-184 uses versionCode 184 / versionName 2.9.184.

## Validation
- Worker syntax checked with Node.js `node --check`.
- GitHub Actions remains the authoritative Android build path.
- Permanent signing key guard remains enabled; V-184 must update V-183 without uninstalling.
