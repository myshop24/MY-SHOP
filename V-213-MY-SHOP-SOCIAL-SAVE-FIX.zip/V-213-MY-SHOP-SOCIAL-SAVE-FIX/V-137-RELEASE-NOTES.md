# MY SHOP V-137

Verified release package based on the V-136 source, with truthful V-137 version identity.

## Backend / R2
- Worker route verification for dashboard, gallery and media objects.
- D1 binding: DB -> my-shop-db.
- R2 binding: MEDIA -> my-shop-media.
- Production deep health check requires database, schema and R2 to report ok.
- Existing user/auth data is never reset or deleted.

## Gallery
- Separate PHOTO / AUDIO / VIDEO folder requests.
- Folder-specific picker and upload metadata.
- Caption, save/edit and delete.
- R2 object and D1 record are created together on upload.

## Release gate
The repository-root GitHub workflow must run the `deploy-worker` job after the APK build. A green APK job alone does NOT prove that the production Worker was updated.
