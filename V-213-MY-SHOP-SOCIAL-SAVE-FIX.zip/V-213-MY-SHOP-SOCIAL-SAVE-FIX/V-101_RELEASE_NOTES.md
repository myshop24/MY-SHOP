# MY SHOP V-101 — DASHBOARD LAYOUT FIX

- Fixed the V-100 dashboard scaling approach that could shrink the whole page to fit the phone.
- Main content is now genuinely scrollable while bottom navigation stays fixed.
- Header includes Language picker for বাংলা / English / हिन्दी / العربية.
- Main hero uses six carousel slots with automatic rotation every 3500 ms.
- Promo banners and live cards remain in the approved visual order.
- Eight feature tiles keep the approved names and existing feature keys.
- Existing login/auth/backend/permanent-ID implementation is preserved.
- Version Code: 101
- Version Name: 2.9.101
- V-100 remains preserved as the previous master baseline.
