# V-183 Release Notes

- Added `00-MY-SHOP-DEVELOPER-INSTRUCTIONS.md` as the permanent first-read developer handoff.
- Added a running change-log mechanism so newly confirmed project information is appended to the same master instructions.
- Added permanent User/Admin ID immutability and identity-preservation rules.
- Recorded the V-182 shared Admin Add/Save/Link failure as the next backend-hardening target.
- Preserved V-182 source; this release is a new sequential version.
