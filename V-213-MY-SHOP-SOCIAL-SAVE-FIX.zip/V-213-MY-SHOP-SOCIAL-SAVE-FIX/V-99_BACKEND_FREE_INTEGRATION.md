# V-99 Backend Free Integration

- Cloudflare Worker + D1 only; no paid database/hosting.
- Android registration/login/password reset now use the Worker API when MYSHOP_BACKEND_URL is configured.
- Permanent four-digit IDs are allocated server-side starting at 0100.
- Local SharedPreferences are no longer the authentication authority.
- Session token is stored locally only as a credential cache; the server remains authoritative.
- Dashboard backend endpoints are included; full admin content editing and media storage are next integration steps.
- Do not publish a final APK until the Worker URL is configured and `/health`, register, login, reset and reinstall tests pass.
