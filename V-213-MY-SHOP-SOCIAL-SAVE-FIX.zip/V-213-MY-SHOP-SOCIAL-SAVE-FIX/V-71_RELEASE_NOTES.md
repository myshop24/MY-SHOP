# MY SHOP V-71 — corrected final source

- One release APK policy remains enforced by GitHub Actions.
- Version: `2.9.71` / versionCode `71`.
- Dashboard visual assets are cropped from the supplied final dashboard reference so the old feature icons are not used.
- The supplied login/create-account references remain the auth visual baseline.
- Language picker contains only বাংলা / English / हिन्दी / العربية.
- Existing permanent 4-digit ID and 2-of-3 security-answer reset logic are preserved.
- Old backups are not overwritten.
