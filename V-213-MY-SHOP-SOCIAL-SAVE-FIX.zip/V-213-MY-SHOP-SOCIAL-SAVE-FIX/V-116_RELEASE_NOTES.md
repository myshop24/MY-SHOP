# V-116 MY SHOP — DASHBOARD + ADMIN FUNCTIONAL FIX

- Dashboard UI rebuilt closer to the approved MY SHOP reference: branded header, hero carousel, promo row, breaking news, LIVE NOW, action row, feature grid and fixed bottom navigation.
- Admin menu now opens the real Admin Management screen for ADMIN sessions instead of the normal account screen.
- Admin Management now loads/saves dashboard configuration through the Cloudflare Worker and supports add/remove moderator actions.
- Dashboard loads the backend breaking-news value when available.
- Existing User IDs, authentication tables and database data are preserved; no reset/drop/delete migration added.
- Existing mapped admin identifiers are promoted to ADMIN role server-side at successful login if their matching account exists.
- Version 2.9.116 / versionCode 116.
- This release is a test/stabilization build until the matching Worker is deployed and the admin actions are verified against production.
