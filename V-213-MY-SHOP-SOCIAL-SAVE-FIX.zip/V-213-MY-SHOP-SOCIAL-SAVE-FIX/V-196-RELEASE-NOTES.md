# MY SHOP V-197 — Full D1 Schema Column Audit

## Confirmed root cause fixed
Production D1 reached the Worker correctly, but `/health/deep` returned `d1Write=error` because the legacy `social_links` table could be missing the required `active` column.

## What was audited
The Worker `REQUIRED_CONTENT_COLUMNS` contract was compared against the additive repair path table-by-table and column-by-column. Repair coverage was added for every non-primary required content column, including legacy-safe defaults for notification/post relationship fields.

## Preservation
- No table is dropped.
- No existing rows are deleted.
- Repairs use additive `ALTER TABLE ... ADD COLUMN` only when a column is absent.
- Existing V-193/V-194/V-195 backups remain untouched.

## Build identity
- Source: `MY SHOP V-197`
- Android: `versionCode 197`, `versionName 2.9.197`
- Worker: `2.9.197`, `V-197`
- Workflow minimum source: V-197
