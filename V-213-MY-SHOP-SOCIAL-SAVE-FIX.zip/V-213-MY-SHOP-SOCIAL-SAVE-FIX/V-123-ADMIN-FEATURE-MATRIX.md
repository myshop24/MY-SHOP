# V-123 ADMIN FEATURE MATRIX

| Resource | Add/Upload | Edit/Save | Delete/Hide | Storage |
|---|---|---|---|---|
| Breaking News | — | YES | Clear | D1 |
| Hero Banners 1-6 | YES | Caption | YES | R2 + D1 |
| Promo Banners 1-3 | YES | Caption | YES | R2 + D1 |
| Dashboard Features | — | Title/URL/Icon/Show | Hide | D1 |
| Social Links | ADD slot | Save URL | Delete | D1 |
| Gallery Photo | YES | Title/Caption | YES | R2 + D1 |
| Gallery Audio | YES | Title/Caption | YES | R2 + D1 |
| Gallery Video | YES | Title/Caption | YES | R2 + D1 |
| Live TV links | ADD slot | Save | Delete | D1 |
| External Movie links | ADD slot | Save | Delete | D1 |
| More Apps links | ADD slot | Save | Delete | D1 |
| Payment Methods | ADD slot | Save | Delete | D1 |
| Moderators | ADD | — | REMOVE | D1 |

Auth tables and permanent IDs are not modified by content-management operations.
