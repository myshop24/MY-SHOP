# MY SHOP Free Backend

This backend uses only Cloudflare Workers Free + Cloudflare D1 Free. No paid database or hosting is required for the prototype/early production stage.

## Components
- Worker: `backend/worker/src/index.js`
- D1 schema: `backend/migrations/001_initial.sql`
- Database name: `my-shop-db`

## Deploy
1. In Cloudflare D1, open `my-shop-db` and copy its Database ID.
2. Put that ID in `backend/worker/wrangler.toml`.
3. Run the migration against `my-shop-db` using Wrangler or paste `backend/migrations/001_initial.sql` into the D1 SQL console.
4. Deploy `backend/worker` as `my-shop-api`.
5. Test `GET https://YOUR-WORKER-URL/health` and expect `{ "ok": true }`.
6. Put the Worker URL into the Android build as `MYSHOP_BACKEND_URL`.

## Important
The free tier has daily usage limits. It is free, but not unlimited. Cloudflare currently documents Workers Free at 100,000 requests/day and D1 Free at 5 million rows read/day, 100,000 rows written/day, with 5 GB total D1 storage. If a daily limit is exceeded, D1 requests pause until the next reset. Do not promise unlimited free usage.
