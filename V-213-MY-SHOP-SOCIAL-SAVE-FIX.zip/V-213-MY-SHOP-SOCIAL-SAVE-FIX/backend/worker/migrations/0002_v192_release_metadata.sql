-- MY SHOP V-192 release metadata.
-- Non-destructive. Does not alter or delete User/Admin identity data.
INSERT OR REPLACE INTO myshop_schema_meta(key,value,updated_at)
VALUES('release_version','V-192',CURRENT_TIMESTAMP);
