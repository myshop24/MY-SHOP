-- MY SHOP V-192 baseline schema metadata.
-- Safe on existing production databases; no user/admin identity data is modified.
CREATE TABLE IF NOT EXISTS myshop_schema_meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
