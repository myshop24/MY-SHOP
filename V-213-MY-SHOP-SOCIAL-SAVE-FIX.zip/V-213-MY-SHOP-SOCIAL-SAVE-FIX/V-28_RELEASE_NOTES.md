# MY SHOP V-28 — Sequential ID & Account Safety Build

## Preserved
- Existing MY SHOP dashboard/features and previous V-28 source structure.
- Shared Login for user/admin/moderator; no separate Admin login page.
- No OTP/email verification.
- Backend remains the production authority for authentication, roles, coins and data.

## Fixed in V-28 source
- New local fallback User IDs are sequential from **0100** instead of random.
- Existing four-digit User IDs are never rewritten during an app update.
- Duplicate Email/Mobile registration is checked before consuming the next serial ID.
- Existing account authentication/index-repair behavior is preserved.
- Version changed to `28` / `2.15.0`; applicationId remains `com.myshop.app`.

## Important production rule
The Android local allocator is only a fallback. Production registration must use the backend atomic serial allocator and immutable User ID.

## Verification status
Static source audit completed for the changes above. An actual APK build must be run by GitHub Actions because this environment does not contain the Android Gradle build toolchain.
