# MY SHOP V-166 — Final UI + Safety Update

Based on V-165 source.

## Included
- Hamburger menu now includes the requested user feature set, including More Apps, Share App, Help & Support, Settings, Language and Logout.
- Customer Support accepts either a WhatsApp URL or a phone-number value; phone numbers are not rendered in the UI and are converted to a WhatsApp `wa.me` destination.
- More includes Social Media, Customer Support and Share App.
- Notification badge continues to use the D1 notification/read model; opening/marking seen clears the unread state. Likes/comments already create user notifications, and admin content changes broadcast MY SHOP update notifications.
- Dashboard advertisement folder remains six slots per box; live-now ads rotate one at a time from the selected folder.
- Breaking News now uses a continuously rotating 🌎 marker and a smaller dense red news ticker.
- Power Ad by Touhid is multilingual and color-mixed for Bangla, English, Hindi and Arabic.
- Header search box removed and MY SHOP logo/title reduced in size.
- Bottom navigation is now Home → Store → Live → Support → More, with five distinct colors, Live centered, and the dock lifted above the Android system navigation area.
- Existing Cloudflare Worker URL, D1 database binding and R2 MEDIA binding are preserved; no new local D1/R2 setup is introduced.
- Workflow keeps the source-version lock, Worker health/deep-health checks, one-APK rule, package/version verification, permanent signing-key protection and data-safety guards.

## Version
- App versionCode: `166`
- App versionName: `2.9.166`
- Source marker: `MY SHOP V-166`
