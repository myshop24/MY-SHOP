#!/usr/bin/env python3
import re, pathlib
js=pathlib.Path('backend/worker/src/index.js').read_text(encoding='utf-8')
m=re.search(r"p===['\"]\/health['\"].*?version:(['\"])([^'\"]+)\1,build:(['\"])(V-\d+)\3",js)
assert m, 'actual /health endpoint marker missing'
assert m.group(2)=='2.9.203' and m.group(4)=='V-203', f'actual /health marker mismatch: {m.group(2)} / {m.group(4)}'
print('WORKER /health VERSION GUARD PASSED')
