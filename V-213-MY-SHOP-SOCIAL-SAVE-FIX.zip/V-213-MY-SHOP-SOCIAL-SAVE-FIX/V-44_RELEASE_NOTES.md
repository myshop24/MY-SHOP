# MY SHOP V-44 — OPEN + DASHBOARD FIRST FIX

Priority fixes:
- Keep V-43 untouched as the previous build.
- Version Code 44 / Version Name 2.9.44.
- Replace the fragile MainActivity XML startup chain with a self-contained Home Dashboard.
- MainActivity has a final safe fallback so startup cannot intentionally leave a blank/black Activity.
- Dashboard follows the supplied dashboard reference structure: top menu/search/notification, banners, breaking news, live cards, live actions, feature grid, and bottom navigation.
- Successful registration now opens the dashboard and finishes RegisterActivity.
- LoginActivity remains the single launcher/login entry point.
- No admin secrets are embedded in the APK.
- Build must still verify exactly one APK, package com.myshop.app, version 44/2.9.44, and APK integrity.

Runtime test gate:
1. Install APK.
2. Tap app icon and verify Login Dashboard opens.
3. Create account with email OR mobile.
4. Verify registration returns directly to Home Dashboard, not black screen.
5. Verify dashboard remains visible after reopening the app.
6. Verify login with the created account returns to the same Home Dashboard.
