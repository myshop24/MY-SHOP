# MY SHOP V-149 — Targeted Build Fix

- Based directly on V-148. No feature redesign.
- Fixed the V-148 Java compile error in `MainActivity.loadFeed()`: callbacks were passing the anonymous `Callback` object (`this`) to `LanguageManager.t(...)` instead of the Activity context.
- Corrected both `feedEnd` and `feedUnavailable` calls to use `MainActivity.this`.
- Version: 2.9.149 / versionCode 149.
- Existing D1/R2 bindings, permanent IDs, user data, and production data are preserved; no destructive migration/reset/drop/truncate.
- Build workflow selects ONLY the exact V-149 source ZIP and refuses older ZIP fallback.
