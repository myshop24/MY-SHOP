# MY SHOP V-121 — ADMIN / MENU / LANGUAGE / UI STABILITY FIX

Based on V-120 full project archive. No auth/user/database reset or destructive migration.

## Fixed
- Admin Management crash: social-link fields were accidentally attached to two parents; switched to `makeField()` before adding them into their row.
- Hamburger menu: fixed-admin IDs 0001/0002/0003 now route directly to Admin Control and the server also re-promotes those fixed IDs to ADMIN for old sessions.
- Language control: clearer 🌐 language button with বাংলা / English / हिन्दी / العربية picker and activity refresh.
- Feature card logos: use the built-in high-quality dashboard drawable icons instead of text glyph placeholders; remote icon URLs can still override them later.
- Bottom navigation: moved upward and increased touch area while preserving the approved Home / Live / Store / Chat / More layout.

## Safety
- Existing D1/auth tables are preserved.
- Permanent IDs remain unchanged.
- No DROP/DELETE/RESET migration was added.
- This archive must be treated as a full restoreable project, not an APK-only package.
