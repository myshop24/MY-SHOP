# V-136 Gallery + R2 Hardening

- Gallery API now accepts a folder filter (`photo`, `audio`, `video`) so each tab requests only its own folder.
- Android client requests the selected folder explicitly.
- Multipart media uploads use chunked streaming to avoid buffering unknown-length files.
- Worker deploy job is required before release verification; production `/health/deep` checks D1 schema and R2 `MEDIA`.
- Existing user/auth data is never reset or deleted.
- No content-table destructive migration is included.
