# MY SHOP V-95 — Master Requirement Status

## Implemented in this V-95 source package
- MY SHOP icon/login/dashboard reference assets are retained.
- Four-language selector: বাংলা, English, हिन्दी, العربية.
- Email OR mobile registration; neither is required when the other is supplied.
- No OTP / verification-code flow.
- Six owner-specified security questions are available; account stores three selected questions and recovery uses 2-of-3 matching.
- Four-digit local ID allocation starts at 0100 and existing local IDs are not rewritten by the allocator.
- Three admin identifiers are mapped to 0001/0002/0003 as identity labels.
- Admin/Moderator UI is role-gated in the Android client.
- Dashboard has six-position banner arrays and automatic carousel timing.
- Dashboard reference PNG is repaired at source level by using the verified header PNG.
- Backend contract files define six-banner sections, admin content actions, four languages, payment methods, social links, TV, gallery and feed contracts.
- Moderator contract is limited to five moderators and only ban/kick/close-live permissions.

## Requires a real backend before production
- Server-authoritative permanent user IDs across devices/reinstalls.
- Server authentication, password reset, admin role detection and session tokens.
- Real admin add/edit/delete operations for banners/news/gallery/links.
- Real My Feed storage, posts, likes, shares and moderation.
- Real coin ledger, Buy Coin and Cash Out transactions.
- Real bKash/Nagad/QR payment processing.
- Real live streaming, kick/ban/close-live enforcement.

The Android source must not claim these backend capabilities are production-ready until a backend is connected and tested.
