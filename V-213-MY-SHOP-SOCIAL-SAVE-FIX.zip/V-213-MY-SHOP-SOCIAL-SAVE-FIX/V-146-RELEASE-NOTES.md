# MY SHOP V-146 — SAFE FIX RELEASE

- V-145 remains the unchanged backup baseline.
- No D1/R2 reset, drop, truncate, ID regeneration, or destructive migration.
- BREAKING headline area now gives the message more visible horizontal/vertical space.
- Gallery is visible to normal Users for viewing; Admin-only upload/edit/delete controls remain locked to Admin.
- POWER AD / by Touhid now uses a polished branded card treatment instead of plain text.
- MY FEED now supports text-only captions/posts as well as photo + caption.
- Social Media Admin save remains server-backed; saved platform names are shown with automatic platform-style icons and open the saved URL.
- Hardened image uploads so missing phone MIME metadata falls back safely instead of producing avoidable server errors.
- Added text-post API without changing existing post tables or IDs.
- APK uses the same applicationId `com.myshop.app` and versionCode 146 so a correctly signed V-146 APK can update V-145 without uninstalling.
- Release workflow builds from the exact V-146 source and keeps exactly one signed APK artifact.
