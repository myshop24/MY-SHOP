# MY SHOP V-152 — R2 + Worker Permanent Deploy Fix

- Based only on V-151; no feature reset.
- Cloudflare R2 subscription is now active and bucket `my-shop-media` exists.
- Worker `wrangler.toml` now targets the existing production Worker `rapid-bush-62ea`.
- D1 binding remains `my-shop-db` with the existing database ID.
- R2 binding remains `MEDIA` → `my-shop-media`.
- GitHub workflow uses the exact V-152 ZIP; it refuses ambiguous V-152 sources.
- Worker deploy and `/health`, `/health/deep`, `/v1/dashboard/config` checks happen before APK build.
- APK is versionCode 152 / versionName 2.9.152 and exactly one final APK is uploaded.
- No OTP / verification-code flow added.
- Existing permanent user IDs/data are untouched.
- One-avatar replacement safety from V-151 is preserved: upload new avatar → update D1 → delete old R2 object only after success; if update fails, old avatar remains.
