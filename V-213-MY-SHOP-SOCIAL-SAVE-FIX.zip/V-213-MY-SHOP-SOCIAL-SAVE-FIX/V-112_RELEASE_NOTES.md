# MY SHOP V-112 RELEASE NOTES

## Critical server fix
- Fixed registration failure: `Server error: Pbkdf2 failed: iteration counts above 100000`.
- Cloudflare Worker PBKDF2 iterations changed from 120000 to the supported maximum of 100000.
- Password format remains `pbkdf2_sha256$<iterations>$<salt>$<digest>`.

## Data safety
- No D1 tables are dropped or reset.
- Existing legacy `users` data is untouched.
- Existing dedicated auth tables and permanent User IDs are preserved.

## Android
- VersionCode: 112
- VersionName: 2.9.112
- Backend Worker URL remains unchanged.

## Verification
- Source archive includes the complete V-111 project plus this V-112 fix.
- V-111 is retained separately as rollback.
