# V-130 MY SHOP — COLORFUL ADMIN HUB + SERVER ERROR HARDENING

- Replaced the legacy all-in-one Admin Management entry with the secure Admin Hub.
- Admin menu is colorful, clean, and each menu item opens its own focused dashboard.
- Normal-user menu remains free of Admin controls; Admin activities still require an Admin session, and backend Admin endpoints remain server-authorized.
- Fixed the raw-pixel Android layout sizing that caused text/fields/buttons to overlap or appear clipped on high-density phones.
- Dashboard, Banner, Gallery and Admin Section screens now use proper dp dimensions for smooth readable spacing.
- Banner manager keeps 6 Hero + 3 Promo slots, with phone file picker, caption, save and delete.
- Gallery manager keeps Photo / Audio / Video upload, caption, edit, save and delete.
- Hardened GET /v1/dashboard/config so auth/content schema initialization cannot block a public config read with SERVER_ERROR. The Worker now additively ensures dashboard_config exists before reading it.
- No user/auth table is dropped, reset, or cleared. Permanent User IDs are preserved.
- Android versionCode 130 / versionName 2.9.130.
