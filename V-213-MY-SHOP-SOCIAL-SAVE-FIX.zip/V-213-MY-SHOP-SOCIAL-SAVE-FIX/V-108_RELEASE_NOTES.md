# MY SHOP V-108 — SERVER + ONE-APK HARDENING

- Version 2.9.108 / versionCode 108.
- Fresh auth namespace `myshop_auth_users_v108` prevents a malformed/partial V-107 auth table from causing SERVER_ERROR.
- Compatible V-107 auth rows are copied forward with INSERT OR IGNORE; old tables and legacy users are never dropped or modified.
- Permanent IDs remain 0100, 0101, 0102… and fixed admin IDs 0001/0002/0003.
- Moderator endpoint now reads the same dedicated moderator table used by admin actions.
- APK workflow is manual-dispatch only to prevent old push-triggered workflows from producing duplicate APKs.
- Release build uses `assembleRelease`, signs one APK, removes intermediates, and requires exactly one final APK.
