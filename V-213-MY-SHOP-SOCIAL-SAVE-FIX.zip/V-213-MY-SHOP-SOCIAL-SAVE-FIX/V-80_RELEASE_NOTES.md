# MY SHOP V-80 — LAUNCH + VERSION HARDENED SOURCE

V-80 is based on the verified V-79 full source.

### V-80 changes
- versionCode: 80
- versionName: 2.9.80
- Launcher LoginActivity no longer depends on AppCompatActivity for process startup. It uses the Android framework Activity class to reduce launcher-time theme/dependency failures.
- Existing recovery login remains in place.
- Existing approved Login/Register/Dashboard structure is preserved.
- Package remains com.myshop.app.

### Backup
This ZIP is the complete V-80 project source for Google Drive backup. Keep V-77, V-78 and V-79 backups unchanged.
