# MY SHOP V-77 — FULL-SCREEN DASHBOARD HARDENED RELEASE

V-77 is derived from the V-76 full source backup. Approved Login/Register/Dashboard assets and feature structure are preserved.

### Dashboard correction
- Hardened immersive fullscreen for modern Android.
- Re-applies fullscreen when the activity regains focus.
- Uses a fixed 480dp design surface and scales the complete dashboard into the available viewport.
- Centers the complete dashboard without a vertical ScrollView.
- Preserves the approved header, banners, Breaking News, LIVE NOW, action row, My Feed/My Shop/features, and bottom navigation.

### Version
- versionName: `2.9.77`
- source versionCode: `77`

### Safety
- V-76 remains unchanged as the immediate backup.
- Cloudflare Worker + D1 production backend configuration is not guessed or replaced.
