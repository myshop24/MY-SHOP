# V-185 MY SHOP — Notification Compile Fix

## Based on
- V-184 source is preserved unchanged as the failed build reference.
- V-185 is the next sequential development version and contains the direct compile fix.

## Exact failure fixed
GitHub Actions V-184 failed during `:app:compileReleaseJavaWithJavac` in `NotificationActivity.java` because `refreshPoll` referenced itself from its own field initializer:

`self-reference in initializer`

The periodic notification refresh runnable now uses an anonymous `Runnable` and `this` inside `run()`, removing the illegal self-reference while preserving the 15-second refresh behavior.

## Permanent rules preserved
- V-183 and all earlier versions remain protected.
- V-184 remains preserved and is not overwritten.
- V-185 must use the same permanent Android signing key and update V-184/V-183 without uninstalling the previous app.
- Developer Instructions must be read before touching project files.
- Any newly confirmed requirement or failure must be added to the Developer Instructions.
- A visible exact build failure must be fixed directly in the next sequential version instead of making the user repeatedly navigate unrelated checks.
