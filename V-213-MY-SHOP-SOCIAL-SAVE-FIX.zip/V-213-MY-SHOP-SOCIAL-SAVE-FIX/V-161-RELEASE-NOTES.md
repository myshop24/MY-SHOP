# MY SHOP V-161 — Instruction + Speed Fix

## Locked user navigation
- Left side remains the Profile area.
- Hamburger/three-line menu opens ONLY the User Menu.
- Profile is NOT repeated inside the hamburger menu.
- User Menu contains the requested user features, including Social Media, Share App and Help & Support.
- User Menu has no direct AdminSectionActivity reference.

## Locked admin navigation
- Admin panels are opened contextually from the corresponding dashboard/button/banner/feature.
- AdminSectionActivity requires both an ADMIN session and `admin_context=true`.
- Normal users never receive admin controls from the UI or backend authorization.

## Speed fix
- Removed repeated content-schema initialization from every authenticated request path.
- Added per-Worker-isolate cached schema initialization so D1 schema repair/default setup happens once per isolate instead of on every Feed/Coins/Notification request.
- Feed endpoint no longer runs an additional content-schema initialization after the request-level initialization.
- This is additive/data-safe; no DROP/TRUNCATE/reset/user-ID regeneration.

## Build/deployment safety
- Android versionCode 161 / versionName 2.9.161.
- Worker health marker V-161 / 2.9.161.
- Same package `com.myshop.app` and permanent signing-key requirement.
- Worker deployment and active `/health`, `/health/deep`, `/v1/dashboard/config` verification happen BEFORE APK compilation.
- Exactly one APK is permitted.
- Existing D1 database ID and R2 bucket binding remain unchanged.
