# V-126 MY SHOP — Exact Build Failure Fix

## Root cause fixed
The V-125 build failed only in `UserMenuActivity.java` because two `root.addView(item(...))` calls were missing one closing `)` each:
- GALLERY menu item
- ACCOUNT menu item

This caused `')' expected` errors during `compileReleaseJavaWithJavac`.

## V-126 changes
- Fixed both exact syntax errors; no functional/admin/backend data reset.
- Kept the normal-user menu separate from the admin hub.
- Kept admin controls hidden from normal users.
- Bumped Android `versionCode` to 126 and `versionName` to 2.9.126.
- Updated the included GitHub Actions workflow to build/verify V-126.
- Kept compileSdk/targetSdk at 36.
- Kept the production Worker URL unchanged.
- Preserved the complete project source, backend, configs, workflows, and historical notes.

## Data safety
No D1/auth/user table is dropped or reset by this fix. Permanent User IDs remain unchanged.
