# V-120 Worker deployment

The APK alone cannot update the Cloudflare Worker. The V-120 workflow includes an optional Worker deployment step.

GitHub repository secrets required for automatic deployment:
- `CLOUDFLARE_API_TOKEN`
- `CLOUDFLARE_ACCOUNT_ID`

The Worker name and D1 binding remain unchanged:
- Worker: `my-shop-api`
- D1: `my-shop-db`
- Binding: `DB`

No database reset/drop/migration-destructive command is used by the V-120 deployment step.
