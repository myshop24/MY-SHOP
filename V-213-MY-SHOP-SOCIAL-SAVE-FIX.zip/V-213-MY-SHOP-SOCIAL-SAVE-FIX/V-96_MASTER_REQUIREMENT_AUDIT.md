# V-96 MY SHOP — MASTER REQUIREMENT AUDIT

## Verified in this client project
- App icon, login, register and dashboard reference assets are retained.
- Four-language selector is present: English, বাংলা, हिन्दी, العربية.
- Registration accepts email OR mobile; OTP/verification-code flow is not used.
- Six owner-specified security questions are present; three can be selected and recovery checks 2 of 3.
- Local four-digit IDs start at 0100 and the local allocator does not rewrite an existing ID.
- Admin identifiers 0001/0002/0003 are mapped to the three supplied admin identifiers.
- Role-gated Admin/Moderator activity exists in the Android client.
- Dashboard has six-position banner arrays and timed rotation.
- Dashboard reference PNG is validated/repaired from the verified header image during build.
- The project contains feature/config contracts for banners, breaking news, social, TV, gallery, feed, languages and payments.

## Production blockers that cannot honestly be marked complete in an offline Android-only ZIP
- Permanent user identity across reinstall/device requires a server/database authority.
- Real admin CRUD for banners/news/gallery/links requires persistent backend APIs/storage.
- Real My Feed photo/share/like storage requires backend data services.
- Real coin ledger, Buy Coin, Cash Out and bKash/Nagad/QR processing require payment/backend integration.
- Real live streaming, kick/ban/close-live enforcement requires a live backend.

**Rule:** V-96 must not claim these backend capabilities are production-ready until the backend is connected and tested.
