# V-115 MY SHOP — Stable Build Fix

- Fixed RegisterActivity compile error: `setupSpinners()` → `setupSpinner()` to match the actual method.
- Keeps the single Security Question + single Security Answer registration design.
- Version: 2.9.115 / versionCode 115.
- Target/compile SDK 36.
- Existing user data and permanent IDs are not reset or deleted.
- Build workflow now installs Android SDK 36 and validates the release APK.
- V-114 is preserved unchanged for rollback.
