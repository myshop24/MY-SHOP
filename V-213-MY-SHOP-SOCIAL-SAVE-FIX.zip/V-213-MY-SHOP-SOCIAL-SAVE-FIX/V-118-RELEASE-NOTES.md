# V-118 — MY SHOP PRO DASHBOARD + ADMIN CONTENT CONTROL

## Purpose
This release is a focused UI/content-management stabilization release. Authentication, permanent User IDs, existing database records, and legacy tables are not reset or deleted.

## Dashboard changes
- Compact responsive header and sections.
- Breaking News label reduced to a compact marker so the headline gets most of the width.
- Breaking News `View All` removed from the ticker; only the headline and arrow remain.
- Banner cards no longer draw artificial borders/strokes.
- Banner and feature images use full-frame fitting instead of aggressive center-cropping.
- Feature grid remains 4×2 but uses smaller cards so more functionality fits on normal phone screens.
- Bottom navigation reduced in height.
- Dashboard keeps a scroll fallback for smaller screens rather than hiding content.

## Admin content
Admin-only remote content controls now include:
- Breaking News
- MY SHOP / Live TV / External Movie / Chat URLs
- 6 hero banner image URLs
- 6 social platform + URL slots
- 3 gallery media URL slots
- Moderator add/remove

Changes are stored server-side and are intended to update dashboard content without requiring an APK rebuild after the backend is deployed.

## Safety
- No database reset.
- No User ID renumbering.
- No deletion of legacy users.
- Authentication/PBKDF2 logic is unchanged from V-117.
- V-117 remains the rollback archive.
