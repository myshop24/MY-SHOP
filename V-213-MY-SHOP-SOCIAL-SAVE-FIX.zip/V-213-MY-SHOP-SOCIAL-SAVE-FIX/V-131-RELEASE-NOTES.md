# MY SHOP V-131 — SERVER + UI + APK RELEASE FIX

## Targeted fixes
- Fixes the Android user menu text/layout blur caused by non-dp pixel heights.
- Fixes Admin Hub folder card clipping/overlap so each item has enough vertical space.
- Fixes remaining density-sensitive sizing in GalleryActivity.
- Keeps Admin-only controls hidden from normal users.
- Keeps Cloudflare D1 binding `my-shop-db` unchanged.
- Keeps Cloudflare R2 binding `my-shop-media` unchanged.
- Keeps the V-130 public `/v1/dashboard/config` hardening: config reads do not depend on unrelated auth/content schema initialization.
- Updates GitHub Actions to build/deploy V-131 instead of the stale V-129 source.
- Final GitHub artifact contains exactly one APK file (the SHA-256 file is no longer bundled into the downloadable APK artifact).

## Important backend finding
The V-130 project already contains the correct D1 and R2 bindings. The GitHub workflow was still extracting and deploying the old V-129 archive. That can leave the live Worker on the older dashboard-config implementation and explains why the APK can show `Server config unavailable: SERVER_ERROR` even though the V-130 source was fixed.

R2 is not required for a normal `/v1/dashboard/config` read. R2 is used for media/banner uploads and `/v1/media/...` retrieval. If R2 were missing, the upload path returns `R2_NOT_CONFIGURED`; it is not the root requirement for dashboard config loading.

No auth/user tables are reset or deleted by this release.
