# V-119 MY SHOP — FINAL DASHBOARD + ADMIN CONTROL

## Purpose
V-119 applies the user's approved final dashboard layout to the lower feature area while preserving the existing authentication, D1 data, permanent User IDs, and Cloudflare Worker architecture.

## Final dashboard layout
- Header/hero/promo area retained from V-118.
- Breaking News remains full-width with compact marker, headline area, and View All.
- Live Now remains above the final feature section.
- Final feature section is exactly 4 columns x 2 rows:
  1. MY FEED | LIVE | GO LIVE | LIVE TV
  2. MY SHOP | EXTERNAL MOVIE | GALLERY | SOCIAL MEDIA
- Fixed bottom navigation remains: Home | Live | Store | Chat | More.
- No duplicate MORE/MY FEED and no extra third feature row.
- Feature cards use compact premium styling with accent cards for MY FEED and MY SHOP.

## Admin controls
Admin-only remote management now covers:
- Breaking News and dashboard URLs.
- 6 hero banners.
- 3 promo banners.
- 6 social links.
- 3 gallery media links.
- All 8 final dashboard feature cards: rename, show/hide, target URL, optional remote icon URL.
- Moderator add/remove.

## Backend safety
- Added additive `feature_buttons` table with `CREATE TABLE IF NOT EXISTS`.
- Existing auth tables, legacy `users` table, D1 records, and permanent IDs are not dropped/reset.
- Fixed the V-118 route issue by defining the previously referenced `/v1/admin/content` handler.
- Content updates are admin-authorized by the server.

## Build
- versionCode: 119
- versionName: 2.9.119
- compileSdk: 36
- targetSdk: 36
- applicationId: com.myshop.app
- Production Worker URL preserved: https://rapid-bush-62ea.myshopsatkania.workers.dev
- GitHub Actions workflow: `.github/workflows/my-shop-v119-pro-release.yml`
- Workflow is configured to build exactly one test APK artifact from V-119 source.

## Verification performed in this environment
- ZIP source unpacked successfully.
- Cloudflare Worker JavaScript syntax check: PASS (`node --check`).
- Project Python validation scripts: PASS.
- V-119 version/SDK/backend URL checks: PASS.
- Final 8 feature keys and removal of the old extra feature row: PASS.
- Admin feature content handler + route: PASS.
- Workflow V-119 consistency checks: PASS.

## Important release note
This archive is source-verified/static-verified in the current environment. A GitHub Actions V-119 build must still complete successfully before the archive/APK is treated as the stable external drive save candidate.

## Data rule
Never drop/reset `myshop_auth_users_v108`, `myshop_auth_sessions_v108`, `myshop_moderators_v108`, the legacy `users` table, or permanent User IDs.
