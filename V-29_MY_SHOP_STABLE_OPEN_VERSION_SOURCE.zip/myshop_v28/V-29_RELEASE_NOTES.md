# MY SHOP V-29 — Stable Open & Version Build

## Baseline
- Built from V-28 source without overwriting the V-28 archive.

## Critical fixes
- VersionCode changed to 29.
- VersionName changed to 2.16.0.
- applicationId remains com.myshop.app.
- Launcher remains LoginActivity.
- Login startup now has a programmatic fallback screen if login XML inflation fails, preventing a blank/crash-like startup state.
- Existing session/account, sequential 4-digit ID, and searchBox fixes are preserved.

## Release rule
- Do not call this APK final until GitHub Actions builds exactly one APK, verifies package/version metadata, and the APK is installed/opened on a real device.
