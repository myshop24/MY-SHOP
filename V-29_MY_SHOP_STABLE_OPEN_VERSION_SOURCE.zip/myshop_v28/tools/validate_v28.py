from pathlib import Path
import json, re, sys
ROOT = Path(__file__).resolve().parents[1]
errors=[]
b=ROOT/'app/build.gradle'
bs=b.read_text(encoding='utf-8')
if 'versionCode 28' not in bs or "versionName '2.15.0'" not in bs: errors.append('Version is not 28/2.15.0')
if "applicationId 'com.myshop.app'" not in bs: errors.append('applicationId mismatch')
uid=(ROOT/'app/src/main/java/com/myshop/app/UserIdManager.java').read_text(encoding='utf-8')
if 'RANDOM' in uid or 'Random' in uid: errors.append('Random ID allocation remains')
if 'FIRST_ID = 100' not in uid: errors.append('Sequential start 0100 missing')
acct=(ROOT/'app/src/main/java/com/myshop/app/AccountStore.java').read_text(encoding='utf-8')
if 'canCreate' not in acct: errors.append('Duplicate account preflight missing')
reg=(ROOT/'app/src/main/java/com/myshop/app/RegisterActivity.java').read_text(encoding='utf-8')
if 'peekNextLocalId' not in reg or 'commitLocalAllocation' not in reg: errors.append('Registration serial allocation flow missing')
for p in ROOT.rglob('*.java'):
    txt=p.read_text(encoding='utf-8',errors='ignore')
    for bad in ['myshopsatkania@gmail.com','touhidsatkania@gmail.com','Touhidsatkania@gmail.com','01860626700']:
        if bad in txt: errors.append(f'Admin identifier embedded in Java: {bad}')
manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
if 'android:name=".LoginActivity" android:exported="true"' not in manifest: errors.append('LoginActivity launcher missing')
if errors:
 print('VALIDATION FAILED'); print('\n'.join(errors)); sys.exit(1)
print('V-28 static validation OK')
