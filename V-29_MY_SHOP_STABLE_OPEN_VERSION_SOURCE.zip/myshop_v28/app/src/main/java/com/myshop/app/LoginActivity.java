package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** Shared Login entry point for USER / MODERATOR / ADMIN. */
public class LoginActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            if (SessionManager.isLoggedIn(this) && !SessionManager.getUserId(this).isEmpty()) {
                // Only restore a session that has a coherent local profile. Otherwise require a fresh login.
                String uid = SessionManager.getUserId(this);
                String profile = getSharedPreferences("myshop_session", MODE_PRIVATE).getString("full_name", "");
                if (!profile.trim().isEmpty()) { openMain(); return; }
                SessionManager.clear(this);
            }
            setContentView(R.layout.activity_login);
            findViewById(R.id.createAccountButton).setOnClickListener(v ->
                    startActivity(new Intent(this, RegisterActivity.class)));
            findViewById(R.id.loginButton).setOnClickListener(v -> login());
            findViewById(R.id.forgotButton).setOnClickListener(v ->
                    Toast.makeText(this, "Password reset will be connected to the secure backend.", Toast.LENGTH_LONG).show());
        } catch (Throwable t) {
            // Never leave the launcher blank if XML inflation or optional startup code fails.
            showLoginFallback();
        }
    }

    private void showLoginFallback() {
        android.widget.LinearLayout root = new android.widget.LinearLayout(this);
        root.setOrientation(android.widget.LinearLayout.VERTICAL);
        root.setGravity(android.view.Gravity.CENTER);
        root.setPadding(32, 48, 32, 32);
        root.setBackgroundColor(android.graphics.Color.WHITE);

        android.widget.TextView title = new android.widget.TextView(this);
        title.setText("MY SHOP");
        title.setTextSize(30);
        title.setTextColor(android.graphics.Color.rgb(18, 87, 232));
        title.setGravity(android.view.Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);

        android.widget.TextView message = new android.widget.TextView(this);
        message.setText("Login Dashboard");
        message.setTextSize(20);
        message.setGravity(android.view.Gravity.CENTER);
        message.setPadding(0, 24, 0, 24);

        EditText id = new EditText(this);
        id.setHint("Email / Mobile / User ID");
        id.setSingleLine(true);
        root.addView(title, new android.widget.LinearLayout.LayoutParams(-1, -2));
        root.addView(message, new android.widget.LinearLayout.LayoutParams(-1, -2));
        root.addView(id, new android.widget.LinearLayout.LayoutParams(-1, -2));

        EditText password = new EditText(this);
        password.setHint("Password");
        password.setSingleLine(true);
        password.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        root.addView(password, new android.widget.LinearLayout.LayoutParams(-1, -2));

        Button login = new Button(this);
        login.setText("LOGIN");
        login.setOnClickListener(v -> {
            String identifier = id.getText().toString().trim();
            String pass = password.getText().toString();
            if (identifier.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Email/Mobile/User ID and Password are required.", Toast.LENGTH_SHORT).show();
                return;
            }
            AccountStore.Account account = AccountStore.authenticate(this, identifier, pass);
            if (account == null) {
                Toast.makeText(this, "Login failed. Check your credentials.", Toast.LENGTH_LONG).show();
                return;
            }
            SessionManager.setSession(this, Role.USER, account.userId);
            SessionManager.saveProfile(this, account.name, account.email, account.mobile);
            openMain();
        });
        root.addView(login, new android.widget.LinearLayout.LayoutParams(-1, -2));

        Button create = new Button(this);
        create.setText("CREATE NEW ACCOUNT");
        create.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
        root.addView(create, new android.widget.LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private void login() {
        try {
            EditText id = findViewById(R.id.loginId);
            EditText password = findViewById(R.id.loginPassword);
            String identifier = id == null ? "" : id.getText().toString().trim();
            String pass = password == null ? "" : password.getText().toString();

            if (identifier.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Email/Mobile and Password are required.", Toast.LENGTH_SHORT).show();
                return;
            }

            AccountStore.Account account = AccountStore.authenticate(this, identifier, pass);
            if (account == null) {
                Toast.makeText(this, "Login failed. Check your Email/Mobile and Password.", Toast.LENGTH_LONG).show();
                return;
            }

            // Role resolution remains server-owned. This local prototype never grants Admin by UI matching.
            SessionManager.setSession(this, Role.USER, account.userId);
            SessionManager.saveProfile(this, account.name, account.email, account.mobile);
            openMain();
        } catch (Throwable t) {
            Toast.makeText(this, "Login failed safely. Your account data was not changed.", Toast.LENGTH_LONG).show();
        }
    }

    private void openMain() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }
}
