# MY SHOP Developer Handoff — V-365

## Phase
Critical runtime recovery / regression-safe stabilization.

## Completed
- Fixed Live Home auto-banner scheduler multiplication. V-364's banner tick could schedule itself and also be scheduled again by `showBanner()`, allowing callback count to grow over time. V-365 has one scheduling owner and one next tick.
- Added lifecycle gates to Dashboard and Live Home async callbacks so stale responses cannot mutate destroyed UI.
- Added safe rejection handling around Dashboard/Live Home image executors after Activity teardown.
- Converted Dashboard hero/promo/live-ad anonymous recurring callbacks into named lifecycle-bound tasks; pause removes them, resume restarts one copy.
- Restored Breaking News marquee after remote headline refresh, activity resume, and window-focus return.
- Removed immediate remote-theme `recreate()` during Dashboard startup to eliminate a destroy/recreate callback race; cached theme is retained for the next normal Activity creation.
- Version identity aligned to V-365 / 2.9.365.

## Locked / unchanged
Login/auth, Create Account/Gender, Audio Live Room and Agora RTC behavior, Gift/Coin/Gold Coin economy, Profile/Social/Feed, Store/Wallet, Admin feature modules, core user IDs, D1 schema/data model, and unrelated backend contracts.

## Last checkpoint
Static source validation completed: Worker syntax, Android XML parse, Java delimiter/brace checks, targeted diff whitelist, version identity, and no Java syntax-pattern errors from javac parsing pass.

## Pending / device acceptance
The retained source package has no runnable Gradle wrapper JAR/Android SDK in this container, so a signed Android compile and real-device runtime cannot be claimed here. Build through the existing GitHub Android workflow, then test:
1. Cold-start app at least 5 times.
2. Keep Dashboard open 10+ minutes; it must not close to launcher.
3. Verify Breaking News scrolls continuously and resumes after background/foreground.
4. Verify Dashboard banners continue rotating with no duplicated/accelerating timer.
5. Open Live Streaming Home with 2–6 active banners; verify 1→2→3→… wrap-around every ~4.5s for 10+ minutes.
6. Background/foreground both screens repeatedly; no crash and no frozen/duplicated scroll timers.

## Known limitation
Exact original device stack trace was not available, so V-365 hardens the concrete lifecycle/timer/executor faults found in source and observed behavior. Device acceptance remains the final runtime gate.
