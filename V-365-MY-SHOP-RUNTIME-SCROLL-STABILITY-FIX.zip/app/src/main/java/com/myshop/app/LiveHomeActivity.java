package com.myshop.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * V-355 Live Streaming Home.
 * Latest approved structure: 6-banner carousel -> Go Live / Join Live -> one Top Live row -> 4 future folders.
 * Bottom navigation: Home | Store | Video | My Feed | Profile.
 */
public class LiveHomeActivity extends AppCompatActivity {
    private final int BG=Color.rgb(5,14,45), SURFACE=Color.rgb(12,25,70), SURFACE_2=Color.rgb(22,27,83);
    private final int WHITE=Color.WHITE, MUTED=Color.rgb(183,196,232), BLUE=Color.rgb(45,114,246), CYAN=Color.rgb(41,203,255), PINK=Color.rgb(240,43,183), PURPLE=Color.rgb(123,63,242), GOLD=Color.rgb(255,202,72);
    private final Handler handler=new Handler();
    private final ArrayList<JSONObject> bannerData=new ArrayList<>();
    private final ArrayList<JSONObject> liveData=new ArrayList<>();
    private ViewFlipper bannerFlipper;
    private TextView bannerDots,bannerCounter,topLiveState;
    private LinearLayout topLiveRow;
    private int bannerIndex=0;
    private float bannerDownX=0f;
    private boolean liveLoadInFlight=false;
    private boolean bannerLoadInFlight=false;
    private boolean firstLiveResume=true;
    private boolean liveHomeVisible=false;
    private boolean liveHomeDestroyed=false;
    private final ExecutorService imageIo=Executors.newFixedThreadPool(2);

    private final Runnable refreshTick=new Runnable(){@Override public void run(){if(!liveHomeVisible||liveHomeDestroyed)return;loadTopLive();handler.postDelayed(this,7000);}};
    // V-365: one owner schedules the banner tick. showBanner() reschedules once, so the
    // tick itself must NOT also post another copy (V-364 could multiply 1->2->4 callbacks).
    private final Runnable bannerTick=new Runnable(){@Override public void run(){if(!liveHomeVisible||liveHomeDestroyed)return;if(bannerData.size()>1)showBanner((bannerIndex+1)%bannerData.size(),true);else scheduleBanner();}};

    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(build());loadBanners();loadTopLive();}

    private View build(){
        LinearLayout page=col();page.setBackgroundColor(BG);
        page.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(0,Math.max(0,i.getSystemWindowInsetTop()),0,Math.max(0,i.getSystemWindowInsetBottom()));return i;});

        LinearLayout top=row();top.setPadding(dp(12),0,dp(12),0);top.setGravity(Gravity.CENTER_VERTICAL);top.setBackground(gradient(new int[]{Color.rgb(7,20,65),Color.rgb(26,20,91)},0));
        TextView back=t("‹",34,WHITE,true);back.setGravity(Gravity.CENTER);PremiumUi.press(back);back.setOnClickListener(v->finish());top.addView(back,lp(dp(46),dp(58)));
        TextView title=t("LIVE STREAMING",22,WHITE,true);title.setGravity(Gravity.CENTER_VERTICAL);top.addView(title,wt(1,dp(58)));
        LinearLayout brand=col();brand.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);TextView b1=t("MY SHOP",14,Color.rgb(170,111,255),true);b1.setGravity(Gravity.RIGHT);TextView b2=t("Shop • Social • Live",7.4f,MUTED,false);b2.setGravity(Gravity.RIGHT);brand.addView(b1);brand.addView(b2);top.addView(brand,lp(dp(104),dp(48)));page.addView(top,lp(-1,dp(58)));

        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setVerticalScrollBarEnabled(false);sv.setBackgroundColor(BG);
        LinearLayout body=col();body.setPadding(dp(12),dp(10),dp(12),dp(20));body.setBackgroundColor(BG);

        FrameLayout hero=new FrameLayout(this);hero.setBackground(gradient(new int[]{Color.rgb(26,42,128),Color.rgb(91,36,176),Color.rgb(235,37,171)},22));hero.setClipToOutline(true);PremiumUi.premiumElevation(hero,6);
        bannerFlipper=new ViewFlipper(this);bannerFlipper.setMeasureAllChildren(false);hero.addView(bannerFlipper,new FrameLayout.LayoutParams(-1,-1));
        View heroShade=new View(this);heroShade.setBackground(gradient(new int[]{Color.argb(20,0,0,0),Color.argb(8,0,0,0),Color.argb(38,2,5,22)},22));hero.addView(heroShade,new FrameLayout.LayoutParams(-1,-1));
        bannerDots=t("●  ○  ○  ○  ○  ○",8.2f,WHITE,true);bannerDots.setGravity(Gravity.CENTER);bannerDots.setShadowLayer(dp(3),0,0,Color.BLACK);FrameLayout.LayoutParams dp1=new FrameLayout.LayoutParams(dp(170),dp(25),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);dp1.bottomMargin=dp(4);hero.addView(bannerDots,dp1);
        bannerCounter=t("1/6",8.5f,WHITE,true);bannerCounter.setGravity(Gravity.CENTER);bannerCounter.setBackground(round(Color.argb(150,0,0,0),Color.argb(80,255,255,255),10));FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(42),dp(24),Gravity.BOTTOM|Gravity.RIGHT);cp.rightMargin=dp(8);cp.bottomMargin=dp(5);hero.addView(bannerCounter,cp);
        hero.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){bannerDownX=e.getX();return true;}if(e.getAction()==MotionEvent.ACTION_UP){float dx=e.getX()-bannerDownX;if(Math.abs(dx)>dp(42)){if(dx<0)showBanner((bannerIndex+1)%Math.max(1,bannerData.size()),true);else showBanner((bannerIndex-1+Math.max(1,bannerData.size()))%Math.max(1,bannerData.size()),false);}else openCurrentBannerTarget();return true;}return true;});
        if(SessionManager.isAdmin(this))hero.setOnLongClickListener(v->{startActivity(new Intent(this,LiveHomeAdminActivity.class));return true;});
        body.addView(hero,lp(-1,dp(168)));

        LinearLayout actions=row();actions.setPadding(0,dp(10),0,0);
        TextView go=action("▣  Go Live\nShare Your Story",new int[]{Color.rgb(44,153,255),Color.rgb(57,83,240),Color.rgb(113,55,238)});go.setOnClickListener(v->{Intent i=new Intent(this,AudioLiveRoomActivity.class);i.putExtra("hostMode",true);startActivity(i);});
        TextView join=action("👥  Join Live\nSee All Active Lives  ›",new int[]{Color.rgb(241,45,184),Color.rgb(132,55,240),Color.rgb(50,117,246)});join.setOnClickListener(v->openList());
        LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(0,dp(78),1);gp.rightMargin=dp(8);actions.addView(go,gp);actions.addView(join,new LinearLayout.LayoutParams(0,dp(78),1));body.addView(actions,lp(-1,dp(88)));

        body.addView(sectionHeader("🔥  Top Live","Highest viewers first",this::openList),top(lp(-1,dp(48)),8));
        topLiveState=t("Loading live rooms…",9.5f,MUTED,false);body.addView(topLiveState,lp(-1,dp(22)));
        HorizontalScrollView liveScroll=new HorizontalScrollView(this);liveScroll.setHorizontalScrollBarEnabled(false);liveScroll.setFillViewport(false);topLiveRow=row();topLiveRow.setGravity(Gravity.CENTER_VERTICAL);liveScroll.addView(topLiveRow,new HorizontalScrollView.LayoutParams(-2,dp(158)));body.addView(liveScroll,lp(-1,dp(158)));

        body.addView(sectionHeader("▣  Future Folders","Reserved for your next decision",null),top(lp(-1,dp(48)),10));
        LinearLayout folders=row();folders.setGravity(Gravity.CENTER);for(int i=1;i<=4;i++){LinearLayout c=futureFolder(i);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(112),1);if(i>1)p.leftMargin=dp(6);folders.addView(c,p);}body.addView(folders,lp(-1,dp(112)));

        TextView adminHint=t("Admin: long-press the banner to manage Live Streaming Home Page",8.2f,Color.rgb(142,157,204),false);adminHint.setGravity(Gravity.CENTER);adminHint.setVisibility(SessionManager.isAdmin(this)?View.VISIBLE:View.GONE);body.addView(adminHint,top(lp(-1,dp(28)),8));

        sv.addView(body);page.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        page.addView(bottomNav(),lp(-1,dp(70)));page.post(page::requestApplyInsets);return page;
    }

    private LinearLayout futureFolder(int no){LinearLayout c=col();c.setGravity(Gravity.CENTER);c.setPadding(dp(4),dp(8),dp(4),dp(8));c.setBackground(gradient(new int[]{Color.rgb(15,31,78),Color.rgb(24,30,87)},16));TextView icon=t("▱",28,Color.rgb(113,142,221),false);icon.setGravity(Gravity.CENTER);c.addView(icon,lp(-1,dp(42)));TextView n=t("Folder "+no,10.5f,WHITE,true);n.setGravity(Gravity.CENTER);c.addView(n,lp(-1,dp(26)));TextView s=t("Coming Soon",7.8f,MUTED,false);s.setGravity(Gravity.CENTER);c.addView(s,lp(-1,dp(20)));return c;}

    private View bottomNav(){
        LinearLayout nav=row();nav.setPadding(dp(6),dp(5),dp(6),dp(5));nav.setBackground(gradient(new int[]{Color.rgb(6,18,58),Color.rgb(10,13,47)},0));
        nav.addView(navItem("⌂\nHome",false,v->{Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);finish();}),wt(1,dp(60)));
        nav.addView(navItem("▢\nStore",false,v->startActivity(new Intent(this,StoreActivity.class))),wt(1,dp(60)));
        nav.addView(navItem("▶\nVideo",true,v->startActivity(new Intent(this,ShortVideoActivity.class))),wt(1,dp(60)));
        nav.addView(navItem("▤\nMy Feed",false,v->{Intent i=new Intent(this,FeatureActivity.class);i.putExtra("title","MY FEED");i.putExtra("feature_key","my_feed");startActivity(i);}),wt(1,dp(60)));
        nav.addView(navItem("○\nProfile",false,v->{Intent i=new Intent(this,UserProfileActivity.class);i.putExtra("userId",SessionManager.getUserId(this));startActivity(i);}),wt(1,dp(60)));
        return nav;
    }
    private TextView navItem(String s,boolean centerAccent,View.OnClickListener l){TextView v=t(s,9.2f,WHITE,true);v.setGravity(Gravity.CENTER);v.setLines(2);v.setPadding(dp(2),dp(2),dp(2),dp(2));if(centerAccent){v.setBackground(gradient(new int[]{Color.rgb(90,52,235),Color.rgb(207,42,233)},16));PremiumUi.premiumElevation(v,6);}else v.setBackground(round(Color.TRANSPARENT,Color.TRANSPARENT,14));PremiumUi.press(v);v.setOnClickListener(l);return v;}

    private LinearLayout sectionHeader(String title,String subtitle,Runnable all){LinearLayout h=row();LinearLayout copy=col();copy.addView(t(title,15.5f,WHITE,true),lp(-1,dp(26)));copy.addView(t(subtitle,8.4f,MUTED,false),lp(-1,dp(18)));h.addView(copy,wt(1,dp(46)));if(all!=null){TextView see=t("See All  ›",10,CYAN,true);see.setGravity(Gravity.CENTER);PremiumUi.press(see);see.setOnClickListener(v->all.run());h.addView(see,lp(dp(88),dp(42)));}return h;}
    private TextView action(String s,int[] colors){TextView v=t(s,12.5f,WHITE,true);v.setGravity(Gravity.CENTER);v.setLines(2);v.setPadding(dp(8),0,dp(8),0);v.setBackground(PremiumUi.gradient(this,colors,20,Color.argb(120,255,255,255),1));PremiumUi.premiumElevation(v,6);PremiumUi.press(v);return v;}

    private void loadBanners(){
        if(bannerLoadInFlight)return;bannerLoadInFlight=true;
        // Prefer the lightweight carousel endpoint, but keep the older Dashboard payload
        // as a compatibility fallback. This prevents a temporary Worker deployment lag
        // from collapsing a configured 2–6 banner carousel into a permanent 1/1 view.
        BackendClient.liveHomeBanners(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                if(liveHomeDestroyed)return;
                ArrayList<JSONObject> primary=parseBannerPayload(d,false);
                if(primary.size()>1){runOnUiThread(()->{if(liveHomeDestroyed)return;bannerLoadInFlight=false;bannerData.clear();bannerData.addAll(primary);renderBanners();});}
                else loadBannersFromDashboard(primary);
            }
            public void onError(String m){if(!liveHomeDestroyed)loadBannersFromDashboard(new ArrayList<>());}
        });
    }
    private ArrayList<JSONObject> parseBannerPayload(JSONObject d,boolean mixedFolders){
        ArrayList<JSONObject> tmp=new ArrayList<>();JSONArray a=d==null?null:d.optJSONArray("banners");
        if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;if(mixedFolders&&!"live_home".equalsIgnoreCase(x.optString("folder","")))continue;int sl=x.optInt("slot",0);String url=x.optString("image_url","").trim();if(sl>=1&&sl<=6&&!url.isEmpty())tmp.add(x);}
        Collections.sort(tmp,Comparator.comparingInt(x->x.optInt("slot",99)));return tmp;
    }
    private void loadBannersFromDashboard(ArrayList<JSONObject> primary){
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){if(liveHomeDestroyed)return;ArrayList<JSONObject> fallback=parseBannerPayload(d,true);ArrayList<JSONObject> chosen=fallback.size()>primary.size()?fallback:primary;runOnUiThread(()->{if(liveHomeDestroyed)return;bannerLoadInFlight=false;bannerData.clear();bannerData.addAll(chosen);renderBanners();});}
            public void onError(String m){if(liveHomeDestroyed)return;runOnUiThread(()->{if(liveHomeDestroyed)return;bannerLoadInFlight=false;bannerData.clear();bannerData.addAll(primary);renderBanners();});}
        });
    }
    private void renderBanners(){
        // Keep only two reusable banner frames alive. Older builds created one decoded
        // bitmap per configured slot; six large banners could remain in the heap together.
        handler.removeCallbacks(bannerTick);
        bannerFlipper.removeAllViews();bannerIndex=0;
        if(bannerData.isEmpty()){
            JSONObject x=new JSONObject();try{x.put("slot",1).put("fallback",true);}catch(Exception ignored){}bannerData.add(x);
        }
        for(int i=0;i<2;i++){ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setImageResource(R.drawable.startup_ad_myshop_live);bannerFlipper.addView(im,new FrameLayout.LayoutParams(-1,-1));}
        bannerFlipper.setDisplayedChild(0);
        bindBannerFrame((ImageView)bannerFlipper.getChildAt(0),0);
        updateBannerIndicators();scheduleBanner();
    }
    private void bindBannerFrame(ImageView target,int dataIndex){
        if(target==null)return;target.setTag(null);target.setImageResource(R.drawable.startup_ad_myshop_live);
        if(dataIndex<0||dataIndex>=bannerData.size())return;
        String url=bannerData.get(dataIndex).optString("image_url","").trim();
        if(!url.isEmpty())loadImage(target,url,1280);
    }
    private void showBanner(int next,boolean forward){
        if(bannerData.size()<=1){bannerIndex=0;updateBannerIndicators();scheduleBanner();return;}
        next=(next+bannerData.size())%bannerData.size();if(next==bannerIndex)return;
        final int oldChild=bannerFlipper.getDisplayedChild();
        final int newChild=oldChild==0?1:0;
        ImageView incoming=(ImageView)bannerFlipper.getChildAt(newChild);
        bindBannerFrame(incoming,next);
        Animation in=new TranslateAnimation(Animation.RELATIVE_TO_SELF,forward?1f:-1f,Animation.RELATIVE_TO_SELF,0f,Animation.RELATIVE_TO_SELF,0f,Animation.RELATIVE_TO_SELF,0f);in.setDuration(320);
        Animation out=new TranslateAnimation(Animation.RELATIVE_TO_SELF,0f,Animation.RELATIVE_TO_SELF,forward?-1f:1f,Animation.RELATIVE_TO_SELF,0f,Animation.RELATIVE_TO_SELF,0f);out.setDuration(320);
        bannerFlipper.setInAnimation(in);bannerFlipper.setOutAnimation(out);bannerFlipper.setDisplayedChild(newChild);
        bannerIndex=next;updateBannerIndicators();scheduleBanner();
        handler.postDelayed(()->{
            try{ImageView old=(ImageView)bannerFlipper.getChildAt(oldChild);if(old!=null&&bannerFlipper.getDisplayedChild()!=oldChild){old.setTag(null);old.setImageResource(R.drawable.startup_ad_myshop_live);}}catch(Exception ignored){}
        },380);
    }
    private void updateBannerIndicators(){int n=bannerData.size();StringBuilder d=new StringBuilder();for(int i=0;i<n;i++){d.append(i==bannerIndex?"●":"○");if(i<n-1)d.append("   ");}bannerDots.setText(d.toString());bannerCounter.setText((bannerIndex+1)+"/"+n);}
    private void scheduleBanner(){handler.removeCallbacks(bannerTick);if(liveHomeVisible&&!liveHomeDestroyed)handler.postDelayed(bannerTick,4500);}
    private void openCurrentBannerTarget(){if(bannerData.isEmpty())return;String target=bannerData.get(Math.min(bannerIndex,bannerData.size()-1)).optString("target_url",bannerData.get(Math.min(bannerIndex,bannerData.size()-1)).optString("targetUrl","")).trim();if(FeatureRegistry.isSafeHttpUrl(target)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception ignored){}}}

    private void loadTopLive(){if(liveLoadInFlight||liveHomeDestroyed)return;liveLoadInFlight=true;BackendClient.liveDiscover(SessionManager.getToken(this),"LIVE_NOW",30,new BackendClient.Callback(){public void onSuccess(JSONObject d){liveLoadInFlight=false;if(liveHomeDestroyed)return;runOnUiThread(()->{if(!liveHomeDestroyed)renderTopLive(d.optJSONArray("rooms"));});}public void onError(String m){liveLoadInFlight=false;if(liveHomeDestroyed)return;runOnUiThread(()->{if(!liveHomeDestroyed&&topLiveState!=null)topLiveState.setText("Live list unavailable • tap See All to retry");});}});}
    private void renderTopLive(JSONArray a){liveData.clear();if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)liveData.add(x);}Collections.sort(liveData,(x,y)->Integer.compare(y.optInt("viewerCount",0),x.optInt("viewerCount",0)));topLiveRow.removeAllViews();int n=liveData.size();topLiveState.setText(n==0?"No one is live right now":n+" active live • swipe for more");if(n==0){TextView e=t("Start the first Live with Go Live",10,MUTED,false);e.setGravity(Gravity.CENTER);topLiveRow.addView(e,new LinearLayout.LayoutParams(dp(280),dp(120)));return;}int available=Math.max(dp(320),getResources().getDisplayMetrics().widthPixels-dp(24));int cardW=Math.max(dp(78),(available-dp(18))/4);for(int i=0;i<n;i++){LinearLayout c=topLiveCard(liveData.get(i),i+1);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(cardW,dp(150));p.rightMargin=dp(6);topLiveRow.addView(c,p);}}
    private LinearLayout topLiveCard(JSONObject x,int rank){LinearLayout c=col();c.setPadding(dp(4),dp(4),dp(4),dp(5));c.setBackground(gradient(new int[]{Color.rgb(18,30,82),Color.rgb(31,26,92)},15));FrameLayout media=new FrameLayout(this);ImageView img=new ImageView(this);img.setImageResource(R.drawable.myshop_profile_avatar);img.setScaleType(ImageView.ScaleType.CENTER_CROP);img.setClipToOutline(true);String url=x.optString("avatarUrl","");if(!url.isEmpty())loadImage(img,url,320);media.addView(img,new FrameLayout.LayoutParams(-1,-1));TextView live=t("● LIVE",6.8f,WHITE,true);live.setGravity(Gravity.CENTER);live.setBackground(round(PINK,PINK,7));FrameLayout.LayoutParams lp1=new FrameLayout.LayoutParams(dp(43),dp(18),Gravity.LEFT|Gravity.TOP);lp1.leftMargin=dp(3);lp1.topMargin=dp(3);media.addView(live,lp1);TextView v=t("◉ "+compact(x.optInt("viewerCount",0)),6.7f,WHITE,true);v.setGravity(Gravity.CENTER);v.setBackground(round(Color.argb(170,0,0,0),Color.TRANSPARENT,8));FrameLayout.LayoutParams vp=new FrameLayout.LayoutParams(dp(50),dp(18),Gravity.RIGHT|Gravity.TOP);vp.rightMargin=dp(3);vp.topMargin=dp(3);media.addView(v,vp);TextView rk=t("#"+rank,7,GOLD,true);rk.setGravity(Gravity.CENTER);rk.setBackground(round(Color.argb(205,85,42,8),GOLD,8));FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(dp(28),dp(18),Gravity.LEFT|Gravity.BOTTOM);rp.leftMargin=dp(3);rp.bottomMargin=dp(3);media.addView(rk,rp);c.addView(media,lp(-1,dp(98)));TextView nm=t(shortName(x.optString("name","MY SHOP User")),8.4f,WHITE,true);nm.setGravity(Gravity.CENTER);nm.setSingleLine(true);c.addView(nm,lp(-1,dp(22)));TextView vc=t(compact(x.optInt("viewerCount",0))+" viewers",7.3f,MUTED,false);vc.setGravity(Gravity.CENTER);c.addView(vc,lp(-1,dp(20)));PremiumUi.press(c);c.setOnClickListener(vw->joinRoom(x));return c;}

    private void openList(){Intent i=new Intent(this,LiveListActivity.class);i.putExtra("category","LIVE_NOW");startActivity(i);}
    private void joinRoom(JSONObject x){String uid=x.optString("userId","");if(uid.isEmpty())return;Intent i=new Intent(this,AudioLiveRoomActivity.class);i.putExtra("hostMode",false);i.putExtra("hostId",uid);i.putExtra("hostName",x.optString("name","MY SHOP User"));startActivity(i);}

    @Override protected void onResume(){super.onResume();liveHomeVisible=true;if(firstLiveResume)firstLiveResume=false;else loadBanners();handler.removeCallbacks(refreshTick);handler.postDelayed(refreshTick,7000);scheduleBanner();}
    @Override protected void onPause(){liveHomeVisible=false;handler.removeCallbacks(refreshTick);handler.removeCallbacks(bannerTick);super.onPause();}
    @Override protected void onDestroy(){liveHomeDestroyed=true;liveHomeVisible=false;handler.removeCallbacksAndMessages(null);imageIo.shutdownNow();super.onDestroy();}

    /**
     * Crash guard for remote Live Home artwork. V-355 could decode up to six large R2
     * banners at full resolution at once. A single 4K/8K image can expand to tens of MB
     * in memory; concurrent full-size decodes could terminate the app with OOM.
     * Decode bounds first, sample to the actual UI need, use RGB_565, cap concurrency,
     * and treat OOM as a failed image rather than a process crash.
     */
    private void loadImage(ImageView target,String rawUrl,int maxPx){
        if(rawUrl==null||rawUrl.trim().isEmpty())return;
        final String url=rawUrl.trim();
        target.setTag(url);
        if(liveHomeDestroyed||imageIo.isShutdown()||imageIo.isTerminated())return;
        try{imageIo.execute(()->{
            Bitmap bitmap=null;
            try{
                BitmapFactory.Options bounds=new BitmapFactory.Options();
                bounds.inJustDecodeBounds=true;
                decodeRemote(url,bounds);
                if(bounds.outWidth<=0||bounds.outHeight<=0)return;

                int sample=1;
                int largest=Math.max(bounds.outWidth,bounds.outHeight);
                while(largest/sample>Math.max(160,maxPx))sample*=2;

                BitmapFactory.Options opts=new BitmapFactory.Options();
                opts.inSampleSize=Math.max(1,sample);
                opts.inPreferredConfig=Bitmap.Config.RGB_565;
                opts.inDither=true;
                bitmap=decodeRemote(url,opts);
            }catch(OutOfMemoryError oom){
                bitmap=null;
                System.gc();
            }catch(Exception ignored){
                bitmap=null;
            }
            final Bitmap safe=bitmap;
            if(safe!=null&&!liveHomeDestroyed&&!isFinishing()&&!isDestroyed())runOnUiThread(()->{
                if(!liveHomeDestroyed&&!isFinishing()&&!isDestroyed()&&url.equals(target.getTag()))target.setImageBitmap(safe);
            });
        });}catch(java.util.concurrent.RejectedExecutionException ignored){}
    }

    private Bitmap decodeRemote(String url,BitmapFactory.Options opts) throws Exception{
        HttpURLConnection c=null;
        try{
            c=(HttpURLConnection)new URL(url).openConnection();
            c.setConnectTimeout(5000);
            c.setReadTimeout(7000);
            c.setInstanceFollowRedirects(true);
            c.setUseCaches(true);
            c.setRequestProperty("User-Agent","MY-SHOP/2.9.365");
            int code=c.getResponseCode();
            if(code<200||code>=300)throw new java.io.IOException("HTTP "+code);
            try(InputStream in=c.getInputStream()){return BitmapFactory.decodeStream(in,null,opts);}
        }finally{if(c!=null)c.disconnect();}
    }
    private String shortName(String n){if(n==null||n.trim().isEmpty())return "User";n=n.trim();return n.length()>12?n.substring(0,12):n;}
    private String compact(long n){if(n>=1000000)return String.format(java.util.Locale.US,"%.1fM",n/1000000f);if(n>=1000)return String.format(java.util.Locale.US,"%.1fK",n/1000f);return String.valueOf(n);}
    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private TextView t(String s,float z,int c,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    private GradientDrawable gradient(int[] colors,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(radius));return g;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams wt(float w,int h){return new LinearLayout.LayoutParams(0,h,w);} private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;} private int dp(float x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
}
