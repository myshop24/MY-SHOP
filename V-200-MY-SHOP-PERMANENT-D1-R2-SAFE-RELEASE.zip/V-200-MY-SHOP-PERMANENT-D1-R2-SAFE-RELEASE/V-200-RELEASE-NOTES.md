# MY SHOP V-200 — Permanent D1/R2 Safe Release

- Promoted the source/build identity to V-200 / Android 2.9.200.
- Locked the release workflow to exactly V-200 so an older source cannot be selected for this release.
- Fixed content-write diagnostics so an orphaned/legacy `banner_media` row cannot cause a false UNIQUE(folder,slot) failure.
- Kept live content-write diagnostics non-blocking; APK release is gated by Worker health/deep-health, while diagnostics are retained for troubleshooting.
- Expanded final safety checks to reject destructive SQL targeting authentication/session/moderator/coin tables.
- Kept D1 migrations additive and aligned with current Cloudflare Wrangler configuration.
- No user/admin identity rows, permanent IDs, coin balances, transactions, or account records are deleted or reset by the V-200 changes.
