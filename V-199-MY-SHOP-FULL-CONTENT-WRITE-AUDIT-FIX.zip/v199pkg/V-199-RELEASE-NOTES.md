# MY SHOP V-199 — Full Content-Write Compatibility + Safe Probe Fix

## Confirmed V-198 follow-up issues fixed
- `dashboard_ads` content-write probe still used `slot=999`; production/application rules accept slots 1-6. V-199 uses slot 1.
- Gallery/feature/managed-link probes used unnecessary `display_order=999`; V-199 uses safe display order 1.
- Gallery-item cleanup previously matched generic title/media values and could remove an unrelated row. V-199 records exact inserted IDs and deletes only those IDs.
- Notification-read probe now uses an existing account ID when available, avoiding legacy foreign-key/check incompatibility without changing identity data.
- Banner probe now selects an actually free valid hero/promo slot before inserting, so it never collides with a real banner. If all normal slots are occupied, it uses a temporary folder while keeping a valid slot value.
- Every temporary write records the exact inserted row/key and cleanup targets only that probe row.
- The content-write suite still blocks APK compilation unless every required write family passes.

## Static/runtime validation performed before packaging
- Worker JavaScript `node --check`: PASS
- GitHub Actions YAML parse: PASS
- Python heredoc safety: PASS
- Bundled SQLite simulation of content-write SQL: PASS
- Legacy banner/banner-media/dashboard-ad slot CHECK simulation (1-6): PASS
- Version identity: V-199 / Android 2.9.199 / Worker V-199
- No destructive D1 migration added
- Previous V-number backups preserved
