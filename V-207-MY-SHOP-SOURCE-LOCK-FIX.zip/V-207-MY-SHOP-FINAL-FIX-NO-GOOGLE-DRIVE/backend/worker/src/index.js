const json = (data, status = 200, extra = {}) => new Response(JSON.stringify(data), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", ...extra }
});

const cors = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET,POST,PUT,DELETE,OPTIONS",
  "access-control-allow-headers": "Content-Type, Authorization, X-MYSHOP-HEALTH-KEY"
};

function normalizeEmail(v) { return String(v || '').trim().toLowerCase(); }
function normalizeMobile(v) { return String(v || '').trim().replace(/[\s()-]/g, ''); }
function normalizeAnswer(v) { return String(v || '').trim().toLowerCase(); }
function isFourDigit(v) { return /^\d{4}$/.test(String(v || '')); }

function bytesToHex(bytes) { return [...new Uint8Array(bytes)].map(b => b.toString(16).padStart(2,'0')).join(''); }
function hexToBytes(hex) { const out = new Uint8Array(hex.length / 2); for (let i=0;i<out.length;i++) out[i]=parseInt(hex.slice(i*2,i*2+2),16); return out; }

async function sha256(text) {
  return bytesToHex(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)));
}

const PBKDF2_ITERATIONS = 100000;

async function pbkdf2(password, saltHex, iterations = PBKDF2_ITERATIONS) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({name:'PBKDF2', salt:hexToBytes(saltHex), iterations, hash:'SHA-256'}, key, 256);
  return bytesToHex(bits);
}

function randomHex(bytes = 16) {
  const a = new Uint8Array(bytes); crypto.getRandomValues(a); return bytesToHex(a);
}

function guessContentType(file) {
  const raw=String(file?.type||'').toLowerCase().trim();
  if(raw) return raw;
  const name=String(file?.name||'').toLowerCase();
  const ext=name.includes('.')?name.split('.').pop():'';
  const map={jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webp:'image/webp',gif:'image/gif',bmp:'image/bmp',heic:'image/heic',heif:'image/heif',mp3:'audio/mpeg',wav:'audio/wav',m4a:'audio/mp4',aac:'audio/aac',ogg:'audio/ogg',mp4:'video/mp4',webm:'video/webm',mov:'video/quicktime',mkv:'video/x-matroska'};
  return map[ext]||'application/octet-stream';
}

async function hashPassword(password) {
  const salt = randomHex(16);
  const iterations = PBKDF2_ITERATIONS;
  const digest = await pbkdf2(password, salt, iterations);
  return `pbkdf2_sha256$${iterations}$${salt}$${digest}`;
}

async function verifyPassword(password, stored) {
  const p = String(stored || '').split('$');
  if (p.length !== 4 || p[0] !== 'pbkdf2_sha256') return false;
  const digest = await pbkdf2(password, p[2], Number(p[1]));
  return digest === p[3];
}

async function ensureAuthSchema(env) {
  // Additive-only and fault-tolerant. Existing user/auth data is never dropped or cleared.
  const statements = [
    `CREATE TABLE IF NOT EXISTS myshop_auth_users_v108 (user_id TEXT PRIMARY KEY CHECK(length(user_id)=4),full_name TEXT NOT NULL,email TEXT UNIQUE,mobile TEXT UNIQUE,password_hash TEXT NOT NULL,security_q1 TEXT NOT NULL,security_a1_hash TEXT NOT NULL,security_q2 TEXT NOT NULL,security_a2_hash TEXT NOT NULL,security_q3 TEXT NOT NULL,security_a3_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'USER' CHECK(role IN ('USER','ADMIN','MODERATOR')),active INTEGER NOT NULL DEFAULT 1,avatar_url TEXT NOT NULL DEFAULT '',avatar_object_key TEXT NOT NULL DEFAULT '',bio TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_myshop_auth_email ON myshop_auth_users_v108(email) WHERE email IS NOT NULL AND email <> ''`,
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_myshop_auth_mobile ON myshop_auth_users_v108(mobile) WHERE mobile IS NOT NULL AND mobile <> ''`,
    `CREATE TABLE IF NOT EXISTS myshop_auth_sessions_v108 (token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id) ON DELETE CASCADE,expires_at INTEGER NOT NULL,created_at INTEGER NOT NULL)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_auth_sessions_v108_user ON myshop_auth_sessions_v108(user_id)`,
    `CREATE TABLE IF NOT EXISTS myshop_moderators_v108 (user_id TEXT PRIMARY KEY REFERENCES myshop_auth_users_v108(user_id) ON DELETE CASCADE,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`
  ];
  for (const sql of statements) { try { await env.DB.prepare(sql).run(); } catch (_) {} }
  // Additive migration for databases created by an older MY SHOP release.
  // Never drop/recreate the auth table: existing IDs, users and sessions stay intact.
  try {
    const cols = (await env.DB.prepare(`PRAGMA table_info(myshop_auth_users_v108)`).all()).results || [];
    const names = new Set(cols.map(x => String(x.name || '')));
    if (!names.has('avatar_url')) await env.DB.prepare(`ALTER TABLE myshop_auth_users_v108 ADD COLUMN avatar_url TEXT NOT NULL DEFAULT ''`).run();
    if (!names.has('avatar_object_key')) await env.DB.prepare(`ALTER TABLE myshop_auth_users_v108 ADD COLUMN avatar_object_key TEXT NOT NULL DEFAULT ''`).run();
    if (!names.has('bio')) await env.DB.prepare(`ALTER TABLE myshop_auth_users_v108 ADD COLUMN bio TEXT NOT NULL DEFAULT ''`).run();
  } catch (_) {}
  try { await migratePreviousAuthIfPresent(env); } catch (_) {}
}

async function migratePreviousAuthIfPresent(env) {
  // V-107 may have created the old auth table before a deployment failed.
  // Copy compatible rows forward; never delete or modify the old table.
  try {
    await env.DB.prepare(`INSERT OR IGNORE INTO myshop_auth_users_v108
      (user_id,full_name,email,mobile,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role,active,created_at,updated_at)
      SELECT user_id,full_name,email,mobile,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role,active,created_at,updated_at
      FROM myshop_auth_users`).run();
  } catch (_) {
    // Old table may not exist or may have an incompatible schema. Leave it untouched.
  }
}

async function createSession(env, userId) {
  const raw = `${crypto.randomUUID()}-${randomHex(16)}`;
  const hash = await sha256(raw);
  const days = Math.max(1, Number(env.SESSION_DAYS || 30));
  const expires = Date.now() + days * 86400000;
  await env.DB.prepare('INSERT INTO myshop_auth_sessions_v108(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)')
    .bind(hash, userId, expires, Date.now()).run();
  return raw;
}

async function getUser(request, env) {
  const auth = request.headers.get('authorization') || '';
  if (!auth.toLowerCase().startsWith('bearer ')) return null;
  const raw = auth.slice(7).trim();
  if (!raw) return null;
  const hash = await sha256(raw);
  const row = await env.DB.prepare(`SELECT u.* FROM myshop_auth_sessions_v108 s JOIN myshop_auth_users_v108 u ON u.user_id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.active=1`).bind(hash, Date.now()).first();
  return row || null;
}

function publicUser(u) {
  return { userId:u.user_id, name:u.full_name, email:u.email || '', mobile:u.mobile || '', role:u.role, avatarUrl:u.avatar_url || '', bio:u.bio || '' };
}

async function body(request) {
  try { return await request.json(); } catch { return {}; }
}

async function findAuthUser(env, identifier) {
  const id = String(identifier || '').trim();
  let user = null;
  if (isFourDigit(id)) user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(id).first();
  if (!user && id.includes('@')) user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE email=? AND active=1').bind(normalizeEmail(id)).first();
  if (!user) user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE mobile=? AND active=1').bind(normalizeMobile(id)).first();
  return user;
}

async function register(request, env) {
  const b = await body(request);
  const name = String(b.name || '').trim();
  const email = normalizeEmail(b.email);
  const mobile = normalizeMobile(b.mobile);
  const password = String(b.password || '');
  const securityQuestion = String(b.securityQuestion || (Array.isArray(b.securityQuestions) ? b.securityQuestions[0] : '') || '').trim();
  const securityAnswer = String(b.securityAnswer || (Array.isArray(b.securityAnswers) ? b.securityAnswers[0] : '') || '').trim();
  if (!name || (!email && !mobile) || password.length < 6 || !securityQuestion || !securityAnswer) return json({error:'INVALID_INPUT'},400,cors);
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({error:'INVALID_EMAIL'},400,cors);

  const duplicate = await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE (?<>'' AND email=?) OR (?<>'' AND mobile=?) LIMIT 1`)
    .bind(email,email,mobile,mobile).first();
  if (duplicate) return json({error:'ACCOUNT_EXISTS'},409,cors);

  // Keep legacy users untouched, but block duplicate identifiers that already exist there.
  try {
    const legacy = await env.DB.prepare(`SELECT id FROM users WHERE (?<>'' AND lower(email)=?) OR (?<>'' AND mobile=?) LIMIT 1`)
      .bind(email,email,mobile,mobile).first();
    if (legacy) return json({error:'ACCOUNT_EXISTS'},409,cors);
  } catch (_) { /* legacy table may not exist on a fresh database */ }

  const adminMap = {
    'myshopsatkania@gmail.com': '0001',
    'touhidsatkania@gmail.com': '0002',
    '01860626700': '0003'
  };
  const adminId = adminMap[email] || adminMap[mobile] || '';
  const role = adminId ? 'ADMIN' : 'USER';
  let userId = adminId;
  if (!userId) {
    const next = await env.DB.prepare(`SELECT COALESCE(MAX(CAST(user_id AS INTEGER))+1,100) AS n FROM myshop_auth_users_v108 WHERE CAST(user_id AS INTEGER) >= 100`).first();
    const n = Number(next?.n || 100);
    if (n > 9999) return json({error:'NO_ID_AVAILABLE'},409,cors);
    userId = String(n).padStart(4,'0');
  } else {
    const occupied = await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=?').bind(userId).first();
    if (occupied) return json({error:'ACCOUNT_EXISTS'},409,cors);
  }

  const ph = await hashPassword(password);
  const answerHash = await sha256(normalizeAnswer(securityAnswer));
  // Keep the existing 3-question columns for backward compatibility. New accounts use only q1/a1.
  await env.DB.prepare(`INSERT INTO myshop_auth_users_v108(user_id,full_name,email,mobile,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).bind(userId,name,email||null,mobile||null,ph,securityQuestion,answerHash,'','', '','',role).run();

  const user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=?').bind(userId).first();
  const token = await createSession(env, userId);
  return json({ok:true,user:publicUser(user),token},201,cors);
}

async function login(request, env) {
  const b = await body(request);
  const id = String(b.identifier || '').trim();
  const password = String(b.password || '');
  if (!id || !password) return json({error:'INVALID_INPUT'},400,cors);
  const user = await findAuthUser(env,id);
  if (!user || !(await verifyPassword(password,user.password_hash))) return json({error:'INVALID_CREDENTIALS'},401,cors);
  const adminMap = {'myshopsatkania@gmail.com':'0001','touhidsatkania@gmail.com':'0002','01860626700':'0003'};
  const mappedAdminId = adminMap[normalizeEmail(id)] || adminMap[normalizeMobile(id)] || (isFourDigit(id) && ['0001','0002','0003'].includes(id) ? id : '');
  if (mappedAdminId && user.user_id === mappedAdminId && user.role !== 'ADMIN') {
    await env.DB.prepare("UPDATE myshop_auth_users_v108 SET role='ADMIN', updated_at=CURRENT_TIMESTAMP WHERE user_id=?").bind(mappedAdminId).run();
    user.role = 'ADMIN';
  }
  const token = await createSession(env,user.user_id);
  return json({ok:true,user:publicUser(user),token},200,cors);
}

async function me(request, env) {
  const user = await getUser(request,env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  return json({ok:true,user:publicUser(user)},200,cors);
}

async function logout(request, env) {
  const auth = request.headers.get('authorization') || '';
  if (auth.toLowerCase().startsWith('bearer ')) await env.DB.prepare('DELETE FROM myshop_auth_sessions_v108 WHERE token_hash=?').bind(await sha256(auth.slice(7).trim())).run();
  return json({ok:true},200,cors);
}

async function securityQuestions(request, env) {
  const id = String(new URL(request.url).searchParams.get('identifier') || '').trim();
  const user = await findAuthUser(env,id);
  if (!user) return json({error:'NOT_FOUND'},404,cors);
  return json({ok:true,question:user.security_q1},200,cors);
}

async function resetPassword(request, env) {
  const b = await body(request);
  const id = String(b.identifier || '').trim();
  const answer = String(b.answer || (Array.isArray(b.answers) ? b.answers[0] : '') || '').trim();
  const newPassword = String(b.newPassword || '');
  if (!id || !answer || newPassword.length < 6) return json({error:'INVALID_INPUT'},400,cors);
  const user = await findAuthUser(env,id);
  if (!user) return json({error:'NOT_FOUND'},404,cors);
  const answerHash = await sha256(normalizeAnswer(answer));
  if (!user.security_a1_hash || user.security_a1_hash !== answerHash) return json({error:'ANSWER_NOT_MATCHED'},403,cors);
  const ph = await hashPassword(newPassword);
  await env.DB.prepare('UPDATE myshop_auth_users_v108 SET password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(ph,user.user_id).run();
  await env.DB.prepare('DELETE FROM myshop_auth_sessions_v108 WHERE user_id=?').bind(user.user_id).run();
  return json({ok:true,userId:user.user_id},200,cors);
}


async function ensureContentSchema(env) {
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  // Additive, backward-compatible schema bootstrap. Never silently swallow a D1 schema error.
  const statements = [
    `CREATE TABLE IF NOT EXISTS gallery_items (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL DEFAULT '',media_url TEXT NOT NULL DEFAULT '',media_type TEXT NOT NULL DEFAULT 'image',active INTEGER NOT NULL DEFAULT 1,display_order INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_gallery_active_order ON gallery_items(active,display_order)`,
    `CREATE TABLE IF NOT EXISTS feature_buttons (key TEXT PRIMARY KEY,title TEXT NOT NULL DEFAULT '',icon_url TEXT NOT NULL DEFAULT '',target_url TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,display_order INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_feature_buttons_active_order ON feature_buttons(active,display_order)`,
    `CREATE TABLE IF NOT EXISTS gallery_media (id INTEGER PRIMARY KEY AUTOINCREMENT,folder TEXT NOT NULL,title TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',media_url TEXT NOT NULL DEFAULT '',object_key TEXT NOT NULL DEFAULT '',media_type TEXT NOT NULL DEFAULT 'image',active INTEGER NOT NULL DEFAULT 1,display_order INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_gallery_media_folder_order ON gallery_media(folder,active,display_order,id)`,
    `CREATE TABLE IF NOT EXISTS dashboard_ads (id INTEGER PRIMARY KEY AUTOINCREMENT,box_key TEXT NOT NULL,slot INTEGER NOT NULL,image_url TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',target_url TEXT NOT NULL DEFAULT '',object_key TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,duration_sec INTEGER NOT NULL DEFAULT 3,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(box_key,slot))`,
    `CREATE INDEX IF NOT EXISTS idx_dashboard_ads_box ON dashboard_ads(box_key,active,slot,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_posts (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id),caption TEXT NOT NULL DEFAULT '',media_url TEXT NOT NULL DEFAULT '',object_key TEXT NOT NULL DEFAULT '',media_type TEXT NOT NULL DEFAULT 'image',status TEXT NOT NULL DEFAULT 'ACTIVE',moderated_by TEXT NOT NULL DEFAULT '',moderated_at TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_posts_feed ON myshop_posts(status,created_at DESC,id DESC)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_posts_user_day ON myshop_posts(user_id,created_at DESC,id DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_post_likes (post_id INTEGER NOT NULL,user_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(post_id,user_id))`,
    `CREATE TABLE IF NOT EXISTS myshop_post_comments (id INTEGER PRIMARY KEY AUTOINCREMENT,post_id INTEGER NOT NULL,user_id TEXT NOT NULL,comment TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS managed_links (id INTEGER PRIMARY KEY AUTOINCREMENT,category TEXT NOT NULL,title TEXT NOT NULL DEFAULT '',url TEXT NOT NULL DEFAULT '',icon_url TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,display_order INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_managed_links_category_order ON managed_links(category,active,display_order,id)`,
    `CREATE TABLE IF NOT EXISTS banner_media (id INTEGER PRIMARY KEY AUTOINCREMENT,folder TEXT NOT NULL,slot INTEGER NOT NULL,object_key TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(folder,slot))`,
    `CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL DEFAULT 'MY SHOP',message TEXT NOT NULL DEFAULT '',audience TEXT NOT NULL DEFAULT 'ALL',user_id TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at DESC,id DESC)`,
    `CREATE INDEX IF NOT EXISTS idx_notifications_audience_user ON notifications(audience,user_id,created_at DESC)`,
    `CREATE TABLE IF NOT EXISTS notification_reads (notification_id INTEGER NOT NULL,user_id TEXT NOT NULL,read_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(notification_id,user_id))`,
    `CREATE INDEX IF NOT EXISTS idx_notification_reads_user ON notification_reads(user_id,read_at DESC)`,
    `CREATE TABLE IF NOT EXISTS dashboard_config (id INTEGER PRIMARY KEY CHECK(id=1),breaking_news TEXT NOT NULL DEFAULT '',my_shop_url TEXT NOT NULL DEFAULT '',live_tv_url TEXT NOT NULL DEFAULT '',external_movie_url TEXT NOT NULL DEFAULT '',chat_url TEXT NOT NULL DEFAULT '',power_ad_title TEXT NOT NULL DEFAULT 'POWER AD',power_ad_byline TEXT NOT NULL DEFAULT 'by Touhid',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS banners (id INTEGER PRIMARY KEY AUTOINCREMENT,folder TEXT NOT NULL DEFAULT '',slot INTEGER NOT NULL DEFAULT 0,image_url TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(folder,slot))`,
    `CREATE TABLE IF NOT EXISTS social_links (id INTEGER PRIMARY KEY AUTOINCREMENT,platform TEXT NOT NULL UNIQUE,url TEXT NOT NULL DEFAULT '',icon_key TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1)`,
    `CREATE TABLE IF NOT EXISTS myshop_coin_wallets (user_id TEXT PRIMARY KEY REFERENCES myshop_auth_users_v108(user_id),balance INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_coin_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id),kind TEXT NOT NULL,amount INTEGER NOT NULL,reference TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'COMPLETED',metadata TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_coin_transactions_user ON myshop_coin_transactions(user_id,created_at,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_coin_purchase_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id),package_coins INTEGER NOT NULL,amount_minor INTEGER NOT NULL,payment_method TEXT NOT NULL,reference TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_coin_purchase_user ON myshop_coin_purchase_requests(user_id,created_at,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_gift_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT,sender_user_id TEXT NOT NULL,receiver_user_id TEXT NOT NULL,coins INTEGER NOT NULL,gift_code TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_schema_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`
  ];
  for (const sql of statements) await env.DB.prepare(sql).run();
  await env.DB.prepare(`INSERT OR IGNORE INTO dashboard_config(id) VALUES(1)`).run();
  await repairContentSchema(env);
  await env.DB.prepare(`INSERT INTO myshop_schema_meta(key,value,updated_at) VALUES('content_schema','191',CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=CURRENT_TIMESTAMP`).run();
}

const schemaInitByEnv = new WeakMap();

async function ensureSchemasOnce(env){
  let p=schemaInitByEnv.get(env);
  if(!p){
    p=(async()=>{
      await ensureAuthSchema(env);
      await ensureContentSchema(env);
    })().catch(e=>{ schemaInitByEnv.delete(env); throw e; });
    schemaInitByEnv.set(env,p);
  }
  return p;
}

async function ensureNotificationSchema(env){
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL DEFAULT 'MY SHOP',message TEXT NOT NULL DEFAULT '',audience TEXT NOT NULL DEFAULT 'ALL',user_id TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at DESC,id DESC)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_notifications_audience_user ON notifications(audience,user_id,created_at DESC)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS notification_reads (notification_id INTEGER NOT NULL,user_id TEXT NOT NULL,read_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(notification_id,user_id))`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_notification_reads_user ON notification_reads(user_id,read_at DESC)`).run();
}

async function createUserNotification(env,userId,title,message){
  const uid=String(userId||'').trim();
  if(!uid) return false;
  const t=String(title||'MY SHOP'), m=String(message||'');
  for(let attempt=1;attempt<=2;attempt++){
    try {
      await ensureNotificationSchema(env);
      const r=await env.DB.prepare(`INSERT INTO notifications(title,message,audience,user_id,created_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)`).bind(t,m,'USER',uid).run();
      const id=r.meta?.last_row_id;
      if(id){ const v=await env.DB.prepare('SELECT id FROM notifications WHERE id=? AND user_id=?').bind(id,uid).first(); if(v?.id) return true; }
      const v=await env.DB.prepare("SELECT id FROM notifications WHERE title=? AND message=? AND audience='USER' AND user_id=? ORDER BY id DESC LIMIT 1").bind(t,m,uid).first();
      if(v?.id) return true;
    } catch (e) {
      console.error('NOTIFICATION_DB_WRITE_FAILED',JSON.stringify({attempt,message:String(e?.message||e)}));
    }
  }
  return false;
}

async function createBroadcastNotification(env,title,message){
  const t=String(title||'MY SHOP'), m=String(message||'');
  for(let attempt=1;attempt<=2;attempt++){
    try {
      await ensureNotificationSchema(env);
      const r=await env.DB.prepare(`INSERT INTO notifications(title,message,audience,user_id,created_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)`).bind(t,m,'ALL','').run();
      const id=r.meta?.last_row_id;
      if(id){ const v=await env.DB.prepare("SELECT id FROM notifications WHERE id=? AND audience='ALL'").bind(id).first(); if(v?.id) return true; }
    } catch (e) {
      console.error('NOTIFICATION_DB_WRITE_FAILED',JSON.stringify({attempt,message:String(e?.message||e)}));
    }
  }
  return false;
}

async function notificationsList(request,env){
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  try { await ensureNotificationSchema(env); } catch (e) { return json({error:'NOTIFICATION_SCHEMA_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
  try { const any=await env.DB.prepare(`SELECT id FROM notifications WHERE audience='ALL' OR user_id=? ORDER BY id DESC LIMIT 1`).bind(user.user_id).first(); if(!any?.id){ const made=await createBroadcastNotification(env,'MY SHOP Notifications','আপনার নতুন আপডেটগুলো এখানে দেখা যাবে।'); if(!made) return json({error:'NOTIFICATION_DB_WRITE_FAILED',message:'Notification table is readable but broadcast notification insert failed.'},503,cors); } } catch (e) { return json({error:'NOTIFICATION_DB_WRITE_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const rows=await env.DB.prepare(`SELECT n.id,n.title,n.message,n.created_at,CASE WHEN r.notification_id IS NULL THEN 0 ELSE 1 END AS is_read FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? WHERE (n.audience='ALL' OR (n.audience='USER' AND n.user_id=?)) ORDER BY n.id DESC LIMIT 50`).bind(user.user_id,user.user_id).all();
  const unread=await env.DB.prepare(`SELECT COUNT(*) AS c FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? WHERE (n.audience='ALL' OR (n.audience='USER' AND n.user_id=?)) AND r.notification_id IS NULL`).bind(user.user_id,user.user_id).first();
  return json({ok:true,unreadCount:Number(unread?.c||0),notifications:(rows.results||[]).map(x=>({id:x.id,title:x.title,message:x.message,createdAt:x.created_at,isRead:Number(x.is_read||0)}))},200,cors);
}

async function notificationsReadAll(request,env){
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  try { await ensureNotificationSchema(env); await env.DB.prepare(`INSERT OR IGNORE INTO notification_reads(notification_id,user_id,read_at) SELECT n.id,?,CURRENT_TIMESTAMP FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? WHERE (n.audience='ALL' OR (n.audience='USER' AND n.user_id=?)) AND r.notification_id IS NULL`).bind(user.user_id,user.user_id,user.user_id).run(); return json({ok:true,unreadCount:0},200,cors); }
  catch(e){ return json({error:'NOTIFICATION_DB_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
}



const REQUIRED_CONTENT_COLUMNS = {
  dashboard_config:['id','breaking_news','my_shop_url','live_tv_url','external_movie_url','chat_url','power_ad_title','power_ad_byline','updated_at'],
  banners:['id','folder','slot','image_url','caption','active','updated_at'],
  banner_media:['id','folder','slot','object_key','updated_at'],
  gallery_media:['id','folder','title','caption','media_url','object_key','media_type','active','display_order','updated_at'],
  gallery_items:['id','title','media_url','media_type','active','display_order','updated_at'],
  feature_buttons:['key','title','icon_url','target_url','active','display_order','updated_at'],
  social_links:['id','platform','url','icon_key','caption','active'],
  managed_links:['id','category','title','url','icon_url','active','display_order','updated_at'],
  dashboard_ads:['id','box_key','slot','image_url','caption','target_url','object_key','active','duration_sec','updated_at'],
  notifications:['id','title','message','audience','user_id','created_at'],
  notification_reads:['notification_id','user_id','read_at'],
  myshop_posts:['id','user_id','caption','media_url','object_key','media_type','status','moderated_by','moderated_at','created_at','updated_at'],
  myshop_post_likes:['post_id','user_id','created_at'],
  myshop_post_comments:['id','post_id','user_id','comment','created_at']
};

async function assertContentSchema(env){
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  const missing=[];
  for(const [table,cols] of Object.entries(REQUIRED_CONTENT_COLUMNS)){
    let rows=[];
    try{ rows=(await env.DB.prepare(`PRAGMA table_info(${table})`).all()).results||[]; }
    catch(e){ throw new Error(`D1_SCHEMA_READ_FAILED:${table}:${String(e?.message||e).slice(0,160)}`); }
    if(!rows.length){ missing.push(`${table}:(table missing)`); continue; }
    const names=new Set(rows.map(r=>String(r.name||'')));
    for(const col of cols) if(!names.has(col)) missing.push(`${table}.${col}`);
  }
  if(missing.length) throw new Error('D1_SCHEMA_INCOMPLETE:'+missing.slice(0,20).join(','));
  const cfg=await env.DB.prepare('SELECT id FROM dashboard_config WHERE id=1').first();
  if(!cfg) throw new Error('D1_SCHEMA_INCOMPLETE:dashboard_config.id=1 row missing');
  return true;
}

async function d1WriteProbe(env){
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_health_probe (probe_id TEXT PRIMARY KEY,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  const id=crypto.randomUUID();
  await env.DB.prepare('INSERT INTO myshop_health_probe(probe_id) VALUES(?)').bind(id).run();
  const row=await env.DB.prepare('SELECT probe_id FROM myshop_health_probe WHERE probe_id=?').bind(id).first();
  if(!row?.probe_id) throw new Error('D1_WRITE_VERIFY_FAILED');
  await env.DB.prepare('DELETE FROM myshop_health_probe WHERE probe_id=?').bind(id).run();
  return true;
}

async function r2WriteProbe(env){
  if(!env?.MEDIA) throw new Error('R2_NOT_CONFIGURED');
  const key=`_health/myshop-${crypto.randomUUID()}.txt`;
  const data=new TextEncoder().encode('MY SHOP R2 health probe');
  try{
    await env.MEDIA.put(key,data,{httpMetadata:{contentType:'text/plain',cacheControl:'no-store'}});
    const head=await env.MEDIA.head(key);
    if(!head) throw new Error('R2_WRITE_VERIFY_FAILED');
  } finally {
    try{ await env.MEDIA.delete(key); }catch(_){}
  }
  return true;
}

async function assertWriteReady(env){
  await ensureSchemasOnce(env);
  await assertContentSchema(env);
  return true;
}

async function ensureColumn(env, table, column, definition) {
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  const info = await env.DB.prepare(`PRAGMA table_info(${table})`).all();
  const rows=info.results||[];
  if(!rows.length) throw new Error(`D1_SCHEMA_TABLE_MISSING:${table}`);
  const found = rows.some(r => String(r.name || '') === column);
  if(!found){
    try { await env.DB.prepare(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`).run(); }
    catch(e){ throw new Error(`D1_SCHEMA_REPAIR_FAILED:${table}.${column}:${String(e?.message||e).slice(0,180)}`); }
  }
}

async function repairContentSchema(env) {
  // Existing production databases may use older column names. Repair is additive only.
  await ensureColumn(env,'myshop_auth_users_v108','avatar_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'myshop_auth_users_v108','avatar_object_key',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'myshop_auth_users_v108','bio',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'myshop_auth_users_v108','updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`);

  for (const [c,d] of [
    ['breaking_news',`TEXT NOT NULL DEFAULT ''`],['my_shop_url',`TEXT NOT NULL DEFAULT ''`],['live_tv_url',`TEXT NOT NULL DEFAULT ''`],
    ['external_movie_url',`TEXT NOT NULL DEFAULT ''`],['chat_url',`TEXT NOT NULL DEFAULT ''`],['power_ad_title',`TEXT NOT NULL DEFAULT 'POWER AD'`],
    ['power_ad_byline',`TEXT NOT NULL DEFAULT 'by Touhid'`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
  ]) await ensureColumn(env,'dashboard_config',c,d);

  // V-192 permanent legacy-banner repair: older D1 used section/position/is_active.
  await ensureColumn(env,'banners','folder',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'banners','slot',`INTEGER NOT NULL DEFAULT 0`);
  await ensureColumn(env,'banners','image_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'banners','caption',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'banners','active',`INTEGER NOT NULL DEFAULT 1`);
  await ensureColumn(env,'banners','updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`);
  const bannerCols=(await env.DB.prepare('PRAGMA table_info(banners)').all()).results||[];
  const bn=new Set(bannerCols.map(r=>String(r.name||'')));
  if(bn.has('section')) await env.DB.prepare(`UPDATE banners SET folder=CASE WHEN lower(trim(COALESCE(section,''))) IN ('hero','promo') THEN lower(trim(section)) ELSE CASE WHEN lower(trim(COALESCE(folder,''))) IN ('hero','promo') THEN lower(trim(folder)) ELSE 'hero' END END WHERE trim(COALESCE(folder,''))=''`).run();
  if(bn.has('position')) await env.DB.prepare(`UPDATE banners SET slot=CASE WHEN CAST(COALESCE(position,0) AS INTEGER)>0 THEN CAST(position AS INTEGER) ELSE CASE WHEN slot>0 THEN slot ELSE 1 END END WHERE COALESCE(slot,0)<=0`).run();
  await env.DB.prepare(`UPDATE banners SET folder='hero' WHERE trim(COALESCE(folder,''))=''`).run();
  await env.DB.prepare(`UPDATE banners SET slot=1 WHERE COALESCE(slot,0)<=0`).run();

  for (const [c,d] of [['caption',`TEXT NOT NULL DEFAULT ''`],['object_key',`TEXT NOT NULL DEFAULT ''`],['media_url',`TEXT NOT NULL DEFAULT ''`],['media_type',`TEXT NOT NULL DEFAULT 'image'`],['active',`INTEGER NOT NULL DEFAULT 1`],['display_order',`INTEGER NOT NULL DEFAULT 1`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`],['owner_user_id',`TEXT`]]) await ensureColumn(env,'gallery_media',c,d);
  await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_gallery_media_owner ON gallery_media(owner_user_id,folder,active,updated_at)').run();

  await ensureColumn(env,'dashboard_ads','duration_sec',`INTEGER NOT NULL DEFAULT 3`);
  await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_dashboard_ads_box ON dashboard_ads(box_key,active,slot,id)').run();
  await ensureColumn(env,'banner_media','object_key',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'banner_media','updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`);
  for (const [c,d] of [['icon_url',`TEXT NOT NULL DEFAULT ''`],['active',`INTEGER NOT NULL DEFAULT 1`],['display_order',`INTEGER NOT NULL DEFAULT 1`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]]) await ensureColumn(env,'managed_links',c,d);
  await ensureColumn(env,'social_links','icon_key',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'social_links','caption',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'social_links','active',`INTEGER NOT NULL DEFAULT 1`);

  // Full required-column repair audit (additive only). Existing rows are preserved.
  // Primary-key columns are intentionally not ALTERed; their tables are created above when absent.
  const requiredRepairs = {
    gallery_media:[
      ['folder',`TEXT NOT NULL DEFAULT ''`],['title',`TEXT NOT NULL DEFAULT ''`]
    ],
    gallery_items:[
      ['title',`TEXT NOT NULL DEFAULT ''`],['media_url',`TEXT NOT NULL DEFAULT ''`],['media_type',`TEXT NOT NULL DEFAULT 'image'`],
      ['active',`INTEGER NOT NULL DEFAULT 1`],['display_order',`INTEGER NOT NULL DEFAULT 1`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    feature_buttons:[
      ['title',`TEXT NOT NULL DEFAULT ''`],['icon_url',`TEXT NOT NULL DEFAULT ''`],['target_url',`TEXT NOT NULL DEFAULT ''`],
      ['active',`INTEGER NOT NULL DEFAULT 1`],['display_order',`INTEGER NOT NULL DEFAULT 1`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    banner_media:[
      ['folder',`TEXT NOT NULL DEFAULT ''`],['slot',`INTEGER NOT NULL DEFAULT 0`]
    ],
    notifications:[
      ['title',`TEXT NOT NULL DEFAULT 'MY SHOP'`],['message',`TEXT NOT NULL DEFAULT ''`],['audience',`TEXT NOT NULL DEFAULT 'ALL'`],
      ['user_id',`TEXT NOT NULL DEFAULT ''`],['created_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    notification_reads:[
      ['notification_id',`INTEGER`],['user_id',`TEXT`],['read_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    myshop_posts:[
      ['user_id',`TEXT NOT NULL DEFAULT ''`],['caption',`TEXT NOT NULL DEFAULT ''`],['media_url',`TEXT NOT NULL DEFAULT ''`],
      ['object_key',`TEXT NOT NULL DEFAULT ''`],['media_type',`TEXT NOT NULL DEFAULT 'image'`],['status',`TEXT NOT NULL DEFAULT 'ACTIVE'`],
      ['moderated_by',`TEXT NOT NULL DEFAULT ''`],['moderated_at',`TEXT`],['created_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`],
      ['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    myshop_post_likes:[
      ['post_id',`INTEGER`],['user_id',`TEXT`],['created_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    myshop_post_comments:[
      ['post_id',`INTEGER`],['user_id',`TEXT`],['comment',`TEXT NOT NULL DEFAULT ''`],['created_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    managed_links:[
      ['category',`TEXT NOT NULL DEFAULT ''`],['title',`TEXT NOT NULL DEFAULT ''`],['url',`TEXT NOT NULL DEFAULT ''`]
    ],
    dashboard_ads:[
      ['box_key',`TEXT NOT NULL DEFAULT ''`],['slot',`INTEGER NOT NULL DEFAULT 0`],['image_url',`TEXT NOT NULL DEFAULT ''`],
      ['caption',`TEXT NOT NULL DEFAULT ''`],['target_url',`TEXT NOT NULL DEFAULT ''`],['object_key',`TEXT NOT NULL DEFAULT ''`],
      ['active',`INTEGER NOT NULL DEFAULT 1`],['duration_sec',`INTEGER NOT NULL DEFAULT 3`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ]
  };
  for (const [table, columns] of Object.entries(requiredRepairs)) {
    for (const [column, definition] of columns) await ensureColumn(env,table,column,definition);
  }
}

async function ensureDashboardConfigSchema(env) {
  await ensureContentSchema(env);
}

async function deepHealth(env) {
  const result={ok:true,service:'my-shop-api',database:'unknown',d1Write:'unknown',r2:'unknown',r2Write:'unknown',schema:'unknown',time:new Date().toISOString()};
  try {
    await env.DB.prepare('SELECT 1').first();
    result.database='ok';
    await ensureSchemasOnce(env);
    await assertContentSchema(env);
    result.schema='ok';
    await d1WriteProbe(env);
    result.d1Write='ok';
  } catch (e) {
    result.ok=false;
    result.database=result.database==='ok'?'ok':'error';
    result.schema=result.schema==='ok'?'ok':'error';
    result.d1Write='error';
    result.databaseMessage=String(e?.message||e).slice(0,220);
  }
  try {
    if (!env.MEDIA) throw new Error('R2 binding MEDIA is missing');
    await env.MEDIA.list({limit:1});
    result.r2='ok';
    await r2WriteProbe(env);
    result.r2Write='ok';
  } catch (e) {
    result.ok=false;
    result.r2=result.r2==='ok'?'ok':'error';
    result.r2Write='error';
    result.r2Message=String(e?.message||e).slice(0,220);
  }
  return result;
}

async function insertBannerCompat(env,{folder,slot,imageUrl,caption,active=1}) {
  const cols=(await env.DB.prepare('PRAGMA table_info(banners)').all()).results||[];
  const names=new Set(cols.map(r=>String(r.name||'')));
  const fields=['folder','slot','image_url','caption','active'];
  const values=[folder,slot,imageUrl,caption,active];
  if(names.has('section')) { fields.push('section'); values.push(folder); }
  if(names.has('position')) { fields.push('position'); values.push(slot); }
  if(names.has('is_active')) { fields.push('is_active'); values.push(active); }
  fields.push('updated_at');
  const placeholders=[...values.map(()=>'?'),'CURRENT_TIMESTAMP'];
  await env.DB.prepare(`INSERT INTO banners(${fields.join(',')}) VALUES(${placeholders.join(',')})`).bind(...values).run();
}

async function contentWriteSuite(request,env){
  const expected=String(env.MYSHOP_HEALTH_PROBE_KEY||'').trim();
  const supplied=String(request.headers.get('X-MYSHOP-HEALTH-KEY')||'').trim();
  if(!expected || !supplied || supplied!==expected) return json({error:'HEALTH_PROBE_FORBIDDEN'},403,cors);
  const marker=`__health_${crypto.randomUUID().replace(/-/g,'')}`;
  const checks={};
  const created={
    bannerId:null,bannerMediaId:null,galleryItemId:null,galleryMediaId:null,
    socialId:null,featureKey:null,managedLinkId:null,adId:null,notificationId:null,
    notificationReadUserId:null
  };
  let bannerFolder=''; let bannerSlot=0;
  try{
    await ensureSchemasOnce(env);
    await assertContentSchema(env);
    checks.schema='ok';

    await r2WriteProbe(env);
    checks.r2='ok';

    // Banners are constrained in production to hero 1-6 / promo 1-3.
    // Select a free valid slot first; never overwrite a real banner.
    for(const [folder,maxSlot] of [['hero',6],['promo',3]]){
      if(bannerSlot) break;
      for(let slot=1;slot<=maxSlot;slot++){
        const row=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=? LIMIT 1').bind(folder,slot).first();
        if(!row?.id){ bannerFolder=folder; bannerSlot=slot; break; }
      }
    }
    // If all normal slots are occupied, use a temporary folder. Current/legacy
    // schema constrains slot, not folder; this avoids touching existing banners.
    if(!bannerSlot){ bannerFolder=marker; bannerSlot=1; }

    await insertBannerCompat(env,{folder:bannerFolder,slot:bannerSlot,imageUrl:'health://probe',caption:'',active:1});
    const br=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=? ORDER BY id DESC LIMIT 1').bind(bannerFolder,bannerSlot).first();
    created.bannerId=Number(br?.id||0)||null;
    const b=br;
    if(!b?.id) throw new Error('BANNER_WRITE_VERIFY_FAILED');
    created.bannerId=Number(b.id); checks.banners='ok';

    // banner_media has a legacy UNIQUE(folder,slot). Never collide with an orphaned row.
    let mediaFolder=bannerFolder, mediaSlot=bannerSlot;
    for(let i=0;i<20;i++){
      const existing=await env.DB.prepare('SELECT id FROM banner_media WHERE folder=? AND slot=? LIMIT 1').bind(mediaFolder,mediaSlot).first();
      if(!existing?.id) break;
      mediaSlot++;
      if(mediaSlot>6){ mediaFolder=`${marker}_media`; mediaSlot=1; }
    }
    const bmr=await env.DB.prepare('INSERT INTO banner_media(folder,slot,object_key,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP)').bind(mediaFolder,mediaSlot,marker).run();
    created.bannerMediaId=Number(bmr?.meta?.last_row_id||0)||null;
    const bm=await env.DB.prepare('SELECT id FROM banner_media WHERE object_key=?').bind(marker).first();
    if(!bm?.id) throw new Error('BANNER_MEDIA_WRITE_VERIFY_FAILED');
    created.bannerMediaId=Number(bm.id); checks.banner_media='ok';

    const giTitle=`Health Probe ${marker}`;
    const gir=await env.DB.prepare('INSERT INTO gallery_items(title,media_url,media_type,active,display_order,updated_at) VALUES(?,?,?,?,1,CURRENT_TIMESTAMP)').bind(giTitle,'health://probe','image',1).run();
    created.galleryItemId=Number(gir?.meta?.last_row_id||0)||null;
    const gi=await env.DB.prepare('SELECT id FROM gallery_items WHERE id=?').bind(created.galleryItemId).first();
    if(!gi?.id) throw new Error('GALLERY_ITEM_WRITE_VERIFY_FAILED');
    checks.gallery_items='ok';

    const gm=await env.DB.prepare('INSERT INTO gallery_media(folder,title,caption,media_url,object_key,media_type,active,display_order,updated_at) VALUES(?,?,?,?,?,?,1,1,CURRENT_TIMESTAMP)').bind(marker,'Health Probe','', 'health://probe', marker, 'image').run();
    created.galleryMediaId=Number(gm?.meta?.last_row_id||0)||null;
    const gmv=await env.DB.prepare('SELECT id FROM gallery_media WHERE id=?').bind(created.galleryMediaId).first();
    if(!gmv?.id) throw new Error('GALLERY_MEDIA_WRITE_VERIFY_FAILED');
    checks.gallery_media='ok';

    const sl=await env.DB.prepare('INSERT INTO social_links(platform,url,icon_key,caption,active) VALUES(?,?,?,?,1)').bind(marker,'https://example.invalid',marker,'').run();
    created.socialId=Number(sl?.meta?.last_row_id||0)||null;
    const slv=await env.DB.prepare('SELECT id FROM social_links WHERE id=?').bind(created.socialId).first();
    if(!slv?.id) throw new Error('SOCIAL_WRITE_VERIFY_FAILED');
    checks.social_links='ok';

    await env.DB.prepare('INSERT INTO feature_buttons(key,title,icon_url,target_url,active,display_order,updated_at) VALUES(?,?,?,?,1,1,CURRENT_TIMESTAMP)').bind(marker,'Health Probe','','').run();
    const fb=await env.DB.prepare('SELECT key FROM feature_buttons WHERE key=?').bind(marker).first();
    if(!fb?.key) throw new Error('FEATURE_WRITE_VERIFY_FAILED');
    created.featureKey=marker; checks.feature_buttons='ok';

    const ml=await env.DB.prepare('INSERT INTO managed_links(category,title,url,icon_url,active,display_order,updated_at) VALUES(?,?,?,?,1,1,CURRENT_TIMESTAMP)').bind(marker,'Health Probe','','').run();
    created.managedLinkId=Number(ml?.meta?.last_row_id||0)||null;
    const mlv=await env.DB.prepare('SELECT id FROM managed_links WHERE id=?').bind(created.managedLinkId).first();
    if(!mlv?.id) throw new Error('MANAGED_LINK_WRITE_VERIFY_FAILED');
    checks.managed_links='ok';

    // Dashboard ads are constrained by the application to slots 1-6.
    const da=await env.DB.prepare('INSERT INTO dashboard_ads(box_key,slot,image_url,caption,target_url,object_key,active,duration_sec,updated_at) VALUES(?,?,?,?,?,?,1,3,CURRENT_TIMESTAMP)').bind(marker,1,'health://probe','','',marker).run();
    created.adId=Number(da?.meta?.last_row_id||0)||null;
    const dav=await env.DB.prepare('SELECT id FROM dashboard_ads WHERE id=?').bind(created.adId).first();
    if(!dav?.id) throw new Error('DASHBOARD_AD_WRITE_VERIFY_FAILED');
    checks.dashboard_ads='ok';

    const no=await env.DB.prepare('INSERT INTO notifications(title,message,audience,user_id,created_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)').bind('MY SHOP Health Probe',marker,'ALL','').run();
    created.notificationId=Number(no?.meta?.last_row_id||0)||null;
    const nov=await env.DB.prepare('SELECT id FROM notifications WHERE id=?').bind(created.notificationId).first();
    if(!nov?.id) throw new Error('NOTIFICATION_WRITE_VERIFY_FAILED');
    checks.notifications='ok';

    // Prove a dashboard write without changing user-visible values.
    const cfg=await env.DB.prepare('SELECT id FROM dashboard_config WHERE id=1').first();
    if(!cfg?.id) throw new Error('DASHBOARD_CONFIG_READ_VERIFY_FAILED');
    await env.DB.prepare('UPDATE dashboard_config SET updated_at=updated_at WHERE id=1').run();
    const cfg2=await env.DB.prepare('SELECT id FROM dashboard_config WHERE id=1').first();
    if(!cfg2?.id) throw new Error('DASHBOARD_CONFIG_WRITE_VERIFY_FAILED');
    checks.dashboard_config='ok';

    // If the legacy table has a foreign-key/check constraint on user_id, use a real
    // existing account rather than inventing an identity value. No identity row is changed.
    const userRow=await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 ORDER BY user_id LIMIT 1').first();
    const readUserId=String(userRow?.user_id||'0100');
    await env.DB.prepare('INSERT INTO notification_reads(notification_id,user_id,read_at) VALUES(?,?,CURRENT_TIMESTAMP)').bind(created.notificationId,readUserId).run();
    created.notificationReadUserId=readUserId;
    const nr=await env.DB.prepare('SELECT notification_id FROM notification_reads WHERE notification_id=? AND user_id=?').bind(created.notificationId,readUserId).first();
    if(!nr?.notification_id) throw new Error('NOTIFICATION_READ_WRITE_VERIFY_FAILED');
    checks.notification_reads='ok';

    return json({ok:true,checks},200,cors);
  } catch(e){
    return json({ok:false,checks,error:'CONTENT_WRITE_SUITE_FAILED',message:String(e?.message||e).slice(0,240)},503,cors);
  } finally {
    const cleanup=[
      created.notificationReadUserId && created.notificationId
        ? ['DELETE FROM notification_reads WHERE notification_id=? AND user_id=?',[created.notificationId,created.notificationReadUserId]] : null,
      created.notificationId ? ['DELETE FROM notifications WHERE id=?',[created.notificationId]] : null,
      created.adId ? ['DELETE FROM dashboard_ads WHERE id=?',[created.adId]] : null,
      created.managedLinkId ? ['DELETE FROM managed_links WHERE id=?',[created.managedLinkId]] : null,
      created.featureKey ? ['DELETE FROM feature_buttons WHERE key=?',[created.featureKey]] : null,
      created.socialId ? ['DELETE FROM social_links WHERE id=?',[created.socialId]] : null,
      created.galleryMediaId ? ['DELETE FROM gallery_media WHERE id=?',[created.galleryMediaId]] : null,
      created.galleryItemId ? ['DELETE FROM gallery_items WHERE id=?',[created.galleryItemId]] : null,
      created.bannerMediaId ? ['DELETE FROM banner_media WHERE id=?',[created.bannerMediaId]] : null,
      created.bannerId ? ['DELETE FROM banners WHERE id=?',[created.bannerId]] : null
    ].filter(Boolean);
    for(const [sql,args] of cleanup){ try{await env.DB.prepare(sql).bind(...args).run();}catch(_){} }
  }
}

async function adminSystemHealth(request,env){
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const h=await deepHealth(env);
  const counts={};
  const tables=['banners','banner_media','gallery_media','dashboard_ads','social_links','feature_buttons','managed_links','notifications','notification_reads'];
  for(const t of tables){
    try { const r=await env.DB.prepare(`SELECT COUNT(*) AS c FROM ${t}`).first(); counts[t]=Number(r?.c||0); }
    catch(e){ counts[t]={error:String(e?.message||e).slice(0,180)}; }
  }
  let schemaMeta={}; try { schemaMeta=(await env.DB.prepare("SELECT key,value,updated_at FROM myshop_schema_meta WHERE key='content_schema'").first())||{}; } catch(e) { schemaMeta={error:String(e?.message||e).slice(0,180)}; }
  return json({ok:h.ok,worker:{version:'2.9.207',build:'V-207'},health:h,schemaMeta,counts,time:new Date().toISOString()},h.ok?200:503,cors);
}

async function dashboardConfig(request, env) {
  let config={}; let banners=[]; let socialLinks=[]; let gallery=[]; let featureButtons=[]; let managedLinks=[]; let media=[];
  try { config=(await env.DB.prepare('SELECT * FROM dashboard_config WHERE id=1').first())||{}; } catch (_) {}
  try { banners=(await env.DB.prepare('SELECT id,folder,slot,image_url,caption,active FROM banners WHERE active=1 ORDER BY folder,slot').all()).results||[]; } catch (_) {}
  try { socialLinks=(await env.DB.prepare('SELECT platform,url,active,icon_key,caption FROM social_links WHERE active=1 ORDER BY platform').all()).results||[]; } catch (_) {}
  try { gallery=(await env.DB.prepare('SELECT id,title,media_url,media_type,active,display_order FROM gallery_items WHERE active=1 ORDER BY display_order,id').all()).results||[]; } catch (_) {}
  try { featureButtons=(await env.DB.prepare('SELECT key,title,icon_url,target_url,active,display_order FROM feature_buttons ORDER BY display_order,key').all()).results||[]; } catch (_) {}
  try { managedLinks=(await env.DB.prepare('SELECT id,category,title,url,icon_url,active,display_order FROM managed_links ORDER BY category,display_order,id').all()).results||[]; } catch (_) {}
  try { media=(await env.DB.prepare('SELECT id,folder,title,caption,media_url,object_key,media_type,active,display_order FROM gallery_media WHERE active=1 ORDER BY folder,display_order,id').all()).results||[]; } catch (_) {}
  let dashboardAds=[];
  try { dashboardAds=(await env.DB.prepare('SELECT id,box_key,slot,image_url,caption,target_url,active,duration_sec FROM dashboard_ads WHERE active=1 ORDER BY box_key,slot').all()).results||[]; } catch (_) {}
  return json({ok:true,config,banners,socialLinks,gallery,featureButtons,managedLinks,media,dashboardAds},200,cors);
}

async function adminOnly(request, env) {
  const user = await getUser(request,env);
  if (!user) return {error:json({error:'ADMIN_REQUIRED'},403,cors)};
  const fixedAdmin = ['0001','0002','0003'].includes(String(user.user_id));
  if (fixedAdmin && user.role !== 'ADMIN') {
    await env.DB.prepare("UPDATE myshop_auth_users_v108 SET role='ADMIN', updated_at=CURRENT_TIMESTAMP WHERE user_id=?").bind(user.user_id).run();
    user.role = 'ADMIN';
  }
  if (user.role !== 'ADMIN') return {error:json({error:'ADMIN_REQUIRED'},403,cors)};
  return {user};
}

async function adminDashboardPut(request, env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const b = await body(request);
  await env.DB.prepare(`UPDATE dashboard_config SET breaking_news=?,my_shop_url=?,live_tv_url=?,external_movie_url=?,chat_url=?,power_ad_title=?,power_ad_byline=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`)
    .bind(String(b.breakingNews||''),String(b.myShopUrl||''),String(b.liveTvUrl||''),String(b.externalMovieUrl||''),String(b.chatUrl||''),String(b.powerAdTitle||'POWER AD').trim().slice(0,60)||'POWER AD',String(b.powerAdByline||'by Touhid').trim().slice(0,60)||'by Touhid').run();
  await createBroadcastNotification(env,'MY SHOP আপডেট','ড্যাশবোর্ডের কনটেন্ট আপডেট করা হয়েছে।');
  return json({ok:true},200,cors);
}

async function adminContentPut(request, env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const b = await body(request);

  const banners = Array.isArray(b.banners) ? b.banners : [];
  for (const x of banners) {
    const folder=String(x.folder||'').trim().toLowerCase(); const slot=Number(x.slot||0);
    if (!['hero','promo'].includes(folder) || !Number.isInteger(slot) || slot<1 || slot>(folder==='hero'?6:3)) continue;
    const imageUrl=String(x.imageUrl||x.image_url||'').trim(); const caption=String(x.caption||'').trim(); const active=x.active===false?0:1;
    if(!imageUrl){ await env.DB.prepare('DELETE FROM banners WHERE folder=? AND slot=?').bind(folder,slot).run(); continue; }
    const existingBanner=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=? LIMIT 1').bind(folder,slot).first();
    if(existingBanner?.id){ await env.DB.prepare('UPDATE banners SET image_url=?,caption=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(imageUrl,caption,active,existingBanner.id).run(); }
    else { await insertBannerCompat(env,{folder,slot,imageUrl,caption,active}); }
  }

  const social = Array.isArray(b.socialLinks) ? b.socialLinks : [];
  for (const x of social) {
    const platform=String(x.platform||'').trim(); if(!platform) continue;
    const url=String(x.url||'').trim(); const active=x.active===false?0:(url?1:0); const iconKey=String(x.iconKey||x.icon_key||platform).trim().toLowerCase().slice(0,40); const caption=String(x.caption||'').trim().slice(0,160);
    if(!url){ await env.DB.prepare('DELETE FROM social_links WHERE platform=?').bind(platform).run(); continue; }
    const existingSocial=await env.DB.prepare('SELECT id FROM social_links WHERE platform=? LIMIT 1').bind(platform).first();
    if(existingSocial?.id){
      await env.DB.prepare('UPDATE social_links SET url=?,icon_key=?,caption=?,active=? WHERE id=?').bind(url,iconKey,caption,active,existingSocial.id).run();
    } else {
      await env.DB.prepare('INSERT INTO social_links(platform,url,icon_key,caption,active) VALUES(?,?,?,?,?)').bind(platform,url,iconKey,caption,active).run();
    }
  }

  const gallery = Array.isArray(b.gallery) ? b.gallery : [];
  for (const x of gallery) {
    const title=String(x.title||'').trim(); const mediaUrl=String(x.mediaUrl||x.media_url||'').trim(); if(!mediaUrl) continue;
    const mediaType=String(x.mediaType||x.media_type||'image').trim()||'image'; const active=x.active===false?0:1; const order=Math.max(1,Number(x.displayOrder||1));
    const existing=await env.DB.prepare('SELECT id FROM gallery_items WHERE display_order=? LIMIT 1').bind(order).first();
    if(existing) await env.DB.prepare('UPDATE gallery_items SET title=?,media_url=?,media_type=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(title,mediaUrl,mediaType,active,existing.id).run();
    else await env.DB.prepare('INSERT INTO gallery_items(title,media_url,media_type,active,display_order) VALUES(?,?,?,?,?)').bind(title,mediaUrl,mediaType,active,order).run();
  }

  const features = Array.isArray(b.featureButtons) ? b.featureButtons : [];
  for (const x of features) {
    const key=String(x.key||'').trim(); if(!key) continue;
    const title=String(x.title||'').trim(); const iconUrl=String(x.iconUrl||x.icon_url||'').trim(); const targetUrl=String(x.targetUrl||x.target_url||'').trim(); const active=x.active===false?0:1; const order=Math.max(1,Number(x.displayOrder||1));
    const existingFeature=await env.DB.prepare('SELECT key FROM feature_buttons WHERE key=? LIMIT 1').bind(key).first();
    if(existingFeature?.key){
      await env.DB.prepare('UPDATE feature_buttons SET title=?,icon_url=?,target_url=?,active=?,display_order=?,updated_at=CURRENT_TIMESTAMP WHERE key=?').bind(title,iconUrl,targetUrl,active,order,key).run();
    } else {
      await env.DB.prepare('INSERT INTO feature_buttons(key,title,icon_url,target_url,active,display_order,updated_at) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)').bind(key,title,iconUrl,targetUrl,active,order).run();
    }
  }

  // Explicit deletes for content records. User/auth tables are never touched.
  for (const x of (Array.isArray(b.deleteBanners)?b.deleteBanners:[])) {
    const folder=String(x.folder||'').trim().toLowerCase(); const slot=Number(x.slot||0);
    if(['hero','promo'].includes(folder) && Number.isInteger(slot)) await env.DB.prepare('DELETE FROM banners WHERE folder=? AND slot=?').bind(folder,slot).run();
  }
  for (const platform of (Array.isArray(b.deleteSocialPlatforms)?b.deleteSocialPlatforms:[])) {
    await env.DB.prepare('DELETE FROM social_links WHERE platform=?').bind(String(platform||'').trim()).run();
  }
  for (const key of (Array.isArray(b.deleteFeatureKeys)?b.deleteFeatureKeys:[])) {
    await env.DB.prepare('UPDATE feature_buttons SET active=0,updated_at=CURRENT_TIMESTAMP WHERE key=?').bind(String(key||'').trim()).run();
  }
  const links = Array.isArray(b.managedLinks) ? b.managedLinks : [];
  for (const x of links) {
    const id=Number(x.id||0); const category=String(x.category||'').trim().toLowerCase(); const title=String(x.title||'').trim(); const url=String(x.url||'').trim(); const iconUrl=String(x.iconUrl||x.icon_url||'').trim(); const active=x.active===false?0:1; const order=Math.max(1,Number(x.displayOrder||1));
    if(!category) continue;
    if(id>0) await env.DB.prepare('UPDATE managed_links SET category=?,title=?,url=?,icon_url=?,active=?,display_order=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(category,title,url,iconUrl,active,order,id).run();
    else await env.DB.prepare('INSERT INTO managed_links(category,title,url,icon_url,active,display_order,updated_at) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)').bind(category,title,url,iconUrl,active,order).run();
  }
  for (const id of (Array.isArray(b.deleteManagedLinkIds)?b.deleteManagedLinkIds:[])) await env.DB.prepare('DELETE FROM managed_links WHERE id=?').bind(Number(id)).run();

  await createBroadcastNotification(env,'MY SHOP আপডেট','ব্যানার, সোশ্যাল বা ফিচার কনটেন্টে নতুন পরিবর্তন এসেছে।');
  return json({ok:true},200,cors);
}

async function adminBannerUpload(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  if(!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(); const folder=String(form.get('folder')||'').trim().toLowerCase(); const slot=Number(form.get('slot')||0); const file=form.get('file'); const caption=String(form.get('caption')||'').trim();
  if(!['hero','promo'].includes(folder) || !Number.isInteger(slot) || slot<1 || slot>(folder==='hero'?6:3) || !(file instanceof File)) return json({error:'INVALID_BANNER'},400,cors);
  const bannerType=guessContentType(file);
  if(!bannerType.startsWith('image/')) return json({error:'BANNER_MUST_BE_IMAGE'},400,cors);
  if(file.size>15*1024*1024) return json({error:'BANNER_TOO_LARGE'},413,cors);
  const old=await env.DB.prepare('SELECT id,object_key FROM banner_media WHERE folder=? AND slot=? LIMIT 1').bind(folder,slot).first();
  // Safety: never delete the currently working banner until the new object and D1 rows are committed.
  const oldKey=old?.object_key||'';
  const ext=(String(file.name||'jpg').split('.').pop()||'jpg').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'jpg';
  const key=`banners/${folder}/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  try {
    await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:String(file.type||'image/jpeg'),cacheControl:'public, max-age=31536000'}});
  } catch (e) {
    return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);
  }
  const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  try {
    // Backward-compatible write path: some existing D1 databases may have been created
    // before the UNIQUE(folder,slot) constraint existed. Do not depend on ON CONFLICT.
    const existingBanner=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=? LIMIT 1').bind(folder,slot).first();
    if(existingBanner?.id){
      await env.DB.prepare('UPDATE banners SET image_url=?,caption=?,active=1,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(url,caption,existingBanner.id).run();
    } else {
      await insertBannerCompat(env,{folder,slot,imageUrl:url,caption,active:1});
    }
    const existingMedia=await env.DB.prepare('SELECT id FROM banner_media WHERE folder=? AND slot=? LIMIT 1').bind(folder,slot).first();
    if(existingMedia?.id){
      await env.DB.prepare('UPDATE banner_media SET object_key=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(key,existingMedia.id).run();
    } else {
      await env.DB.prepare('INSERT INTO banner_media(folder,slot,object_key,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP)').bind(folder,slot,key).run();
    }
  } catch(e) {
    try { await env.MEDIA.delete(key); } catch(_) {}
    return json({error:'BANNER_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors);
  }
  if(oldKey && oldKey!==key){ try { await env.MEDIA.delete(oldKey); } catch(_) {} }
  await createBroadcastNotification(env,'নতুন ব্যানার','MY SHOP-এ নতুন ব্যানার আপডেট হয়েছে।');
  return json({ok:true,folder,slot,image_url:url,caption},201,cors);
}

async function adminBannerUpdate(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const b=await body(request); const folder=String(b.folder||'').trim().toLowerCase(); const slot=Number(b.slot||0); const caption=String(b.caption||'').trim();
  if(!['hero','promo'].includes(folder)||!Number.isInteger(slot)||slot<1||slot>(folder==='hero'?6:3)) return json({error:'INVALID_BANNER'},400,cors);
  const row=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=?').bind(folder,slot).first();
  if(!row) return json({error:'BANNER_NOT_FOUND'},404,cors);
  await env.DB.prepare('UPDATE banners SET caption=?,updated_at=CURRENT_TIMESTAMP WHERE folder=? AND slot=?').bind(caption,folder,slot).run();
  await createBroadcastNotification(env,'ব্যানার আপডেট','একটি ব্যানারের ক্যাপশন আপডেট হয়েছে।');
  return json({ok:true,folder,slot,caption},200,cors);
}

async function adminBannerDelete(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error; const b=await body(request); const folder=String(b.folder||'').trim().toLowerCase(); const slot=Number(b.slot||0); if(!['hero','promo'].includes(folder)||!Number.isInteger(slot)) return json({error:'INVALID_BANNER'},400,cors);
  const old=await env.DB.prepare('SELECT object_key FROM banner_media WHERE folder=? AND slot=?').bind(folder,slot).first(); if(old?.object_key&&env.MEDIA) await env.MEDIA.delete(old.object_key);
  await env.DB.prepare('DELETE FROM banner_media WHERE folder=? AND slot=?').bind(folder,slot).run(); await env.DB.prepare('DELETE FROM banners WHERE folder=? AND slot=?').bind(folder,slot).run(); await createBroadcastNotification(env,'ব্যানার আপডেট','একটি ব্যানার সরানো হয়েছে।'); return json({ok:true},200,cors);
}

async function adminMediaList(request,env) {
  try { await ensureSchemasOnce(env); } catch (_) {}
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const folder=safeMediaFolder(new URL(request.url).searchParams.get('folder')||'');
  const sql=folder
    ? 'SELECT id,folder,title,caption,media_url,object_key,media_type,active,display_order FROM gallery_media WHERE folder=? ORDER BY display_order,id'
    : 'SELECT id,folder,title,caption,media_url,object_key,media_type,active,display_order FROM gallery_media ORDER BY folder,display_order,id';
  const rows=folder ? await env.DB.prepare(sql).bind(folder).all() : await env.DB.prepare(sql).all();
  return json({ok:true,folder:folder||'all',media:rows.results||[]},200,cors);
}

function safeMediaFolder(v){ const f=String(v||'').trim().toLowerCase(); return ['photo','audio','video'].includes(f)?f:''; }
function safeKeyPart(v){ return String(v||'').replace(/[^a-zA-Z0-9._-]/g,'_').slice(0,120); }

async function adminMediaUpload(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  if(!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(); const file=form.get('file'); const folder=safeMediaFolder(form.get('folder'));
  if(!(file instanceof File) || !folder) return json({error:'INVALID_MEDIA'},400,cors);
  const contentType=guessContentType(file);
  const allowed=folder==='photo'?contentType.startsWith('image/'):folder==='audio'?contentType.startsWith('audio/'):contentType.startsWith('video/');
  if(!allowed) return json({error:'MEDIA_TYPE_MISMATCH'},400,cors);
  if(file.size>50*1024*1024) return json({error:'MEDIA_TOO_LARGE'},413,cors);
  const title=String(form.get('title')||'').trim(); const caption=String(form.get('caption')||'').trim(); const order=Math.max(1,Number(form.get('displayOrder')||1));
  const ext=(String(file.name||'bin').split('.').pop()||'bin').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'bin';
  const key=`gallery/${folder}/${Date.now()}-${crypto.randomUUID().slice(0,8)}-${safeKeyPart(file.name||'media')}.${ext}`;
  try {
    await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType,cacheControl:'public, max-age=31536000'}});
  } catch (e) {
    return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);
  }
  const mediaUrl=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  let r;
  try { r=await env.DB.prepare('INSERT INTO gallery_media(folder,title,caption,media_url,object_key,media_type,active,display_order) VALUES(?,?,?,?,?,?,1,?)').bind(folder,title,caption,mediaUrl,key,contentType,order).run(); }
  catch(e){ try{await env.MEDIA.delete(key);}catch(_){} return json({error:'GALLERY_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,220)},500,cors); }
  await createBroadcastNotification(env,'গ্যালারি আপডেট','গ্যালারিতে নতুন মিডিয়া যোগ হয়েছে।');
  return json({ok:true,id:r.meta?.last_row_id||null,folder,title,caption,media_url:mediaUrl,object_key:key,media_type:contentType,display_order:order},201,cors);
}

async function adminMediaUpdate(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const b=await body(request); const id=Number(b.id||0); const title=String(b.title||'').trim(); const caption=String(b.caption||'').trim();
  if(!id) return json({error:'INVALID_MEDIA_ID'},400,cors);
  const row=await env.DB.prepare('SELECT id FROM gallery_media WHERE id=?').bind(id).first();
  if(!row) return json({error:'MEDIA_NOT_FOUND'},404,cors);
  await env.DB.prepare('UPDATE gallery_media SET title=?,caption=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(title,caption,id).run();
  await createBroadcastNotification(env,'গ্যালারি আপডেট','গ্যালারির একটি আইটেম সম্পাদনা করা হয়েছে।');
  return json({ok:true,id,title,caption},200,cors);
}

async function adminMediaDelete(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const b=await body(request); const id=Number(b.id||0); if(!id) return json({error:'INVALID_MEDIA_ID'},400,cors);
  const row=await env.DB.prepare('SELECT object_key FROM gallery_media WHERE id=?').bind(id).first(); if(!row) return json({error:'MEDIA_NOT_FOUND'},404,cors);
  if(env.MEDIA && row.object_key) await env.MEDIA.delete(row.object_key);
  await env.DB.prepare('DELETE FROM gallery_media WHERE id=?').bind(id).run();
  await createBroadcastNotification(env,'গ্যালারি আপডেট','গ্যালারি থেকে একটি মিডিয়া সরানো হয়েছে।');
  return json({ok:true},200,cors);
}



async function userGalleryList(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  const folder=safeMediaFolder(new URL(request.url).searchParams.get('folder')||'');
  if (!folder) return json({error:'INVALID_GALLERY_FOLDER'},400,cors);
  const rows=(await env.DB.prepare(`SELECT id,folder,title,caption,media_url,object_key,media_type,active,display_order,owner_user_id,updated_at FROM gallery_media WHERE active=1 AND folder=? AND (owner_user_id IS NULL OR owner_user_id=?) ORDER BY id DESC`).bind(folder,user.user_id).all()).results||[];
  return json({ok:true,folder,media:rows},200,cors);
}

async function userGalleryUpload(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!isAdminUser(user)) return json({error:'GALLERY_ADMIN_ONLY'},403,cors);
  if (!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(); const file=form.get('file'); const folder=safeMediaFolder(form.get('folder'));
  if (!(file instanceof File) || !folder) return json({error:'INVALID_MEDIA'},400,cors);
  const contentType=guessContentType(file);
  const allowed=folder==='photo'?contentType.startsWith('image/'):folder==='audio'?contentType.startsWith('audio/'):contentType.startsWith('video/');
  if(!allowed) return json({error:'MEDIA_TYPE_MISMATCH'},400,cors);
  // No item-count cap. Each individual object is limited to 50 MB; R2/account quota still applies.
  if(Number(file.size||0)>50*1024*1024) return json({error:'MEDIA_TOO_LARGE'},413,cors);
  const title=String(form.get('title')||'').trim().slice(0,160);
  const caption=String(form.get('caption')||'').trim().slice(0,1000);
  const ext=(String(file.name||'media').split('.').pop()||'bin').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'bin';
  const key=`gallery/users/${user.user_id}/${folder}/${Date.now()}-${crypto.randomUUID().slice(0,8)}-${safeKeyPart(file.name||'media')}.${ext}`;
  try { await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType,cacheControl:'public, max-age=31536000'}}); }
  catch(e){ return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
  const mediaUrl=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  try {
    const r=await env.DB.prepare(`INSERT INTO gallery_media(folder,title,caption,media_url,object_key,media_type,active,display_order,owner_user_id) VALUES(?,?,?,?,?,?,1,?,?)`).bind(folder,title,caption,mediaUrl,key,contentType,1,user.user_id).run();
    await createBroadcastNotification(env,'গ্যালারি আপডেট','একটি নতুন ইউজার গ্যালারি মিডিয়া যোগ হয়েছে।');
    return json({ok:true,id:r.meta?.last_row_id||null,folder,title,caption,media_url:mediaUrl,object_key:key,media_type:contentType,owner_user_id:user.user_id},201,cors);
  } catch(e){ try{await env.MEDIA.delete(key);}catch(_){} return json({error:'GALLERY_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors); }
}

async function userGalleryUpdate(request, env) {
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!isAdminUser(user)) return json({error:'GALLERY_ADMIN_ONLY'},403,cors);
  const b=await body(request); const id=Number(b.id||0); const title=String(b.title||'').trim().slice(0,160); const caption=String(b.caption||'').trim().slice(0,1000);
  if(!id) return json({error:'INVALID_MEDIA_ID'},400,cors);
  const row=await env.DB.prepare('SELECT id FROM gallery_media WHERE id=? AND owner_user_id=?').bind(id,user.user_id).first();
  if(!row) return json({error:'MEDIA_NOT_FOUND'},404,cors);
  await env.DB.prepare('UPDATE gallery_media SET title=?,caption=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND owner_user_id=?').bind(title,caption,id,user.user_id).run();
  return json({ok:true,id,title,caption},200,cors);
}

async function userGalleryDelete(request, env) {
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!isAdminUser(user)) return json({error:'GALLERY_ADMIN_ONLY'},403,cors);
  const b=await body(request); const id=Number(b.id||0); if(!id) return json({error:'INVALID_MEDIA_ID'},400,cors);
  const row=await env.DB.prepare('SELECT object_key FROM gallery_media WHERE id=? AND owner_user_id=?').bind(id,user.user_id).first();
  if(!row) return json({error:'MEDIA_NOT_FOUND'},404,cors);
  if(env.MEDIA && row.object_key) { try{await env.MEDIA.delete(row.object_key);}catch(_){} }
  await env.DB.prepare('DELETE FROM gallery_media WHERE id=? AND owner_user_id=?').bind(id,user.user_id).run();
  return json({ok:true},200,cors);
}


function isAdminUser(user) { return !!user && String(user.role || '').toUpperCase() === 'ADMIN'; }
function isModeratorUser(user) { return !!user && ['MODERATOR','ADMIN'].includes(String(user.role || '').toUpperCase()); }

async function feedList(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  const url = new URL(request.url);
  const limit = Math.min(10, Math.max(1, Number(url.searchParams.get('limit') || 5)));
  const before = Math.max(0, Number(url.searchParams.get('before') || 0));
  const sql = before > 0
    ? `SELECT p.id,p.user_id,p.caption,p.media_url,p.object_key,p.media_type,p.created_at,u.full_name,u.avatar_url,
          (SELECT COUNT(*) FROM myshop_post_likes l WHERE l.post_id=p.id) AS like_count,
          (SELECT COUNT(*) FROM myshop_post_comments c WHERE c.post_id=p.id) AS comment_count,
          EXISTS(SELECT 1 FROM myshop_post_likes ml WHERE ml.post_id=p.id AND ml.user_id=?) AS liked
       FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id
       WHERE p.status='ACTIVE' AND p.id<? ORDER BY p.id DESC LIMIT ?`
    : `SELECT p.id,p.user_id,p.caption,p.media_url,p.object_key,p.media_type,p.created_at,u.full_name,u.avatar_url,
          (SELECT COUNT(*) FROM myshop_post_likes l WHERE l.post_id=p.id) AS like_count,
          (SELECT COUNT(*) FROM myshop_post_comments c WHERE c.post_id=p.id) AS comment_count,
          EXISTS(SELECT 1 FROM myshop_post_likes ml WHERE ml.post_id=p.id AND ml.user_id=?) AS liked
       FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id
       WHERE p.status='ACTIVE' ORDER BY p.id DESC LIMIT ?`;
  const rows = before > 0
    ? (await env.DB.prepare(sql).bind(user.user_id,before,limit).all()).results || []
    : (await env.DB.prepare(sql).bind(user.user_id,limit).all()).results || [];
  const today = await env.DB.prepare(`SELECT COUNT(*) AS c FROM myshop_posts WHERE user_id=? AND date(created_at)=date('now')`).bind(user.user_id).first();
  const canPost = isAdminUser(user) || Number(today?.c || 0) < 1;
  return json({ok:true,posts:rows.map(x=>({id:x.id,userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',caption:x.caption||'',mediaUrl:x.media_url||'',mediaType:x.media_type||'image',createdAt:x.created_at||'',likeCount:Number(x.like_count||0),commentCount:Number(x.comment_count||0),liked:Boolean(x.liked)})),nextBefore:rows.length?Number(rows[rows.length-1].id):null,hasMore:rows.length===limit,canPost,role:user.role,postsToday:Number(today?.c||0)},200,cors);
}

async function feedUpload(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  try { await ensureSchemasOnce(env); } catch (_) {}
  if (!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const isAdmin = isAdminUser(user);
  const form = await request.formData();
  const file = form.get('file');
  if (!(file instanceof File)) return json({error:'FILE_REQUIRED'},400,cors);
  const contentType = guessContentType(file);
  if (!contentType || contentType === 'application/octet-stream') { return json({error:'POST_MEDIA_TYPE_MISMATCH',message:'The selected file type could not be identified as an image.'},400,cors); }
  const requestedType = String(form.get('mediaType') || '').trim().toLowerCase();
  const mediaType = requestedType || (contentType.startsWith('video/') ? 'video' : 'image');
  const allowed = mediaType === 'image' ? contentType.startsWith('image/') : mediaType === 'video' ? contentType.startsWith('video/') : false;
  if (!allowed) return json({error:'POST_MEDIA_TYPE_MISMATCH'},400,cors);
  if (!isAdmin && mediaType !== 'image') return json({error:'USER_VIDEO_LOCKED'},403,cors);
  const maxBytes = isAdmin ? 50*1024*1024 : 5*1024*1024;
  if (Number(file.size||0) > maxBytes) return json({error:isAdmin?'POST_MEDIA_TOO_LARGE':'USER_POST_TOO_LARGE'},413,cors);
  const caption = String(form.get('caption') || '').trim().slice(0,1000);
  if (!isAdmin && !caption) return json({error:'POST_CAPTION_REQUIRED'},400,cors);
  if (!isAdmin) {
    const today = await env.DB.prepare(`SELECT COUNT(*) AS c FROM myshop_posts WHERE user_id=? AND date(created_at)=date('now')`).bind(user.user_id).first();
    if (Number(today?.c||0) >= 1) return json({error:'DAILY_POST_LIMIT',message:'সাধারণ User প্রতিদিন সর্বোচ্চ ১টি পোস্ট করতে পারবে।'},429,cors);
  }
  const ext=(String(file.name||'media').split('.').pop()||'bin').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'bin';
  const key=`posts/${user.user_id}/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  try { await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType,cacheControl:'public, max-age=86400'}}); }
  catch(e) { return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
  const mediaUrl=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  try {
    const r=await env.DB.prepare(`INSERT INTO myshop_posts(user_id,caption,media_url,object_key,media_type,status) VALUES(?,?,?,?,?,'ACTIVE')`).bind(user.user_id,caption,mediaUrl,key,mediaType).run();
    await createBroadcastNotification(env,'MY SHOP Feed','নতুন একটি পোস্ট Feed-এ যোগ হয়েছে।');
    return json({ok:true,id:r.meta?.last_row_id||null,post:{id:r.meta?.last_row_id||null,userId:user.user_id,name:user.full_name||'',avatarUrl:user.avatar_url||'',caption,mediaUrl,mediaType}},201,cors);
  } catch(e) { try { await env.MEDIA.delete(key); } catch (_) {} return json({error:'POST_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors); }
}

async function feedText(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  try { await ensureSchemasOnce(env); } catch (_) {}
  const b=await body(request); const caption=String(b.caption||'').trim().slice(0,1000);
  if(!caption) return json({error:'POST_CAPTION_REQUIRED'},400,cors);
  const isAdmin=isAdminUser(user);
  if(!isAdmin){
    const today=await env.DB.prepare(`SELECT COUNT(*) AS c FROM myshop_posts WHERE user_id=? AND date(created_at)=date('now')`).bind(user.user_id).first();
    if(Number(today?.c||0)>=1)return json({error:'DAILY_POST_LIMIT',message:'সাধারণ User প্রতিদিন সর্বোচ্চ ১টি পোস্ট করতে পারবে।'},429,cors);
  }
  try{
    const r=await env.DB.prepare(`INSERT INTO myshop_posts(user_id,caption,media_url,object_key,media_type,status) VALUES(?,?,'','','text','ACTIVE')`).bind(user.user_id,caption).run();
    await createBroadcastNotification(env,'MY SHOP Feed','নতুন একটি text post Feed-এ যোগ হয়েছে।');
    return json({ok:true,id:r.meta?.last_row_id||null,post:{id:r.meta?.last_row_id||null,userId:user.user_id,name:user.full_name||'',avatarUrl:user.avatar_url||'',caption,mediaUrl:'',mediaType:'text'}},201,cors);
  }catch(e){return json({error:'POST_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors);}
}

async function feedLike(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request); const id=Number(b.postId||0); if(!Number.isInteger(id)||id<=0)return json({error:'INVALID_POST_ID'},400,cors);
  const post=await env.DB.prepare(`SELECT id,user_id FROM myshop_posts WHERE id=? AND status='ACTIVE'`).bind(id).first(); if(!post)return json({error:'POST_NOT_FOUND'},404,cors);
  const exists=await env.DB.prepare('SELECT post_id FROM myshop_post_likes WHERE post_id=? AND user_id=?').bind(id,user.user_id).first();
  if(exists){await env.DB.prepare('DELETE FROM myshop_post_likes WHERE post_id=? AND user_id=?').bind(id,user.user_id).run(); const c=await env.DB.prepare('SELECT COUNT(*) AS c FROM myshop_post_likes WHERE post_id=?').bind(id).first(); return json({ok:true,liked:false,likeCount:Number(c?.c||0)},200,cors);}
  await env.DB.prepare('INSERT OR IGNORE INTO myshop_post_likes(post_id,user_id) VALUES(?,?)').bind(id,user.user_id).run();
  if(post.user_id!==user.user_id) await createUserNotification(env,post.user_id,'MY SHOP','User ID '+user.user_id+' liked your post.');
  const c=await env.DB.prepare('SELECT COUNT(*) AS c FROM myshop_post_likes WHERE post_id=?').bind(id).first(); return json({ok:true,liked:true,likeCount:Number(c?.c||0)},200,cors);
}

async function feedComment(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors); const b=await body(request); const id=Number(b.postId||0); const comment=String(b.comment||'').trim().slice(0,1000);
  if(!Number.isInteger(id)||id<=0||!comment)return json({error:'INVALID_COMMENT'},400,cors); const post=await env.DB.prepare(`SELECT id,user_id FROM myshop_posts WHERE id=? AND status='ACTIVE'`).bind(id).first(); if(!post)return json({error:'POST_NOT_FOUND'},404,cors);
  await env.DB.prepare('INSERT INTO myshop_post_comments(post_id,user_id,comment) VALUES(?,?,?)').bind(id,user.user_id,comment).run(); if(post.user_id!==user.user_id) await createUserNotification(env,post.user_id,'MY SHOP','User ID '+user.user_id+' commented on your post.'); const c=await env.DB.prepare('SELECT COUNT(*) AS c FROM myshop_post_comments WHERE post_id=?').bind(id).first(); return json({ok:true,commentCount:Number(c?.c||0)},201,cors);
}

async function feedDeleteOwn(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request); const id=Number(b.id||0); if(!id)return json({error:'INVALID_POST_ID'},400,cors);
  const row=await env.DB.prepare(`SELECT object_key FROM myshop_posts WHERE id=? AND user_id=? AND status='ACTIVE'`).bind(id,user.user_id).first();
  if(!row)return json({error:'POST_NOT_FOUND'},404,cors);
  if(env.MEDIA&&row.object_key){try{await env.MEDIA.delete(row.object_key);}catch(_){} }
  await env.DB.prepare(`UPDATE myshop_posts SET status='REMOVED',moderated_by=?,moderated_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?`).bind(user.user_id,id,user.user_id).run();
  return json({ok:true},200,cors);
}

async function adminFeedList(request,env) {
  const auth=await adminOnly(request,env); if(auth.error)return auth.error;
  try{await ensureSchemasOnce(env);}catch(_){ }
  const rows=(await env.DB.prepare(`SELECT p.id,p.user_id,p.caption,p.media_url,p.media_type,p.status,p.created_at,p.moderated_by,p.moderated_at,u.full_name,u.avatar_url FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id ORDER BY p.id DESC LIMIT 100`).all()).results||[];
  return json({ok:true,posts:rows},200,cors);
}

async function moderatorFeedDelete(request,env) {
  const user=await getUser(request,env);
  if(!user || !isModeratorUser(user)) return json({error:'MODERATOR_REQUIRED'},403,cors);
  try{await ensureSchemasOnce(env);}catch(_){ }
  const b=await body(request); const id=Number(b.id||0); const reason=String(b.reason||'').trim().slice(0,300);
  if(!id)return json({error:'INVALID_POST_ID'},400,cors);
  const row=await env.DB.prepare(`SELECT object_key,status FROM myshop_posts WHERE id=?`).bind(id).first();
  if(!row)return json({error:'POST_NOT_FOUND'},404,cors);
  if(env.MEDIA&&row.object_key){try{await env.MEDIA.delete(row.object_key);}catch(_){} }
  await env.DB.prepare(`UPDATE myshop_posts SET status='REMOVED',moderated_by=?,moderated_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(user.user_id,id).run();
  return json({ok:true,removedBy:user.user_id,reason},200,cors);
}

async function adminAdsList(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error;
  const box=String(new URL(request.url).searchParams.get('box_key')||'').trim().toLowerCase();
  const rows=box?await env.DB.prepare('SELECT id,box_key,slot,image_url,caption,target_url,object_key,active,duration_sec,updated_at FROM dashboard_ads WHERE box_key=? ORDER BY slot').bind(box).all():await env.DB.prepare('SELECT id,box_key,slot,image_url,caption,target_url,object_key,active,duration_sec,updated_at FROM dashboard_ads ORDER BY box_key,slot').all();
  return json({ok:true,ads:rows.results||[]},200,cors);
}

async function adminAdUpload(request,env){
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error)return auth.error;
  if(!env.MEDIA)return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(); const file=form.get('file'); const box=String(form.get('boxKey')||'').trim().toLowerCase().replace(/[^a-z0-9_-]/g,'_').slice(0,60); const slot=Number(form.get('slot')||0); const caption=String(form.get('caption')||'').trim().slice(0,300); const target=String(form.get('targetUrl')||'').trim().slice(0,500); const duration=Math.max(1,Math.min(60,Number(form.get('durationSec')||3)));
  if(!(file instanceof File)||!box||!Number.isInteger(slot)||slot<1||slot>6)return json({error:'INVALID_AD'},400,cors);
  if(!String(file.type||'').startsWith('image/'))return json({error:'AD_MUST_BE_IMAGE'},400,cors);
  if(file.size>15*1024*1024)return json({error:'AD_TOO_LARGE'},413,cors);
  const old=await env.DB.prepare('SELECT object_key FROM dashboard_ads WHERE box_key=? AND slot=?').bind(box,slot).first(); const oldKey=old?.object_key||'';
  const ext=(String(file.name||'jpg').split('.').pop()||'jpg').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'jpg'; const key=`dashboard-ads/${box}/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  try{await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:String(file.type||'image/jpeg'),cacheControl:'public, max-age=31536000'}});}catch(e){return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);}
  const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  try{
    const existing=await env.DB.prepare('SELECT id FROM dashboard_ads WHERE box_key=? AND slot=? LIMIT 1').bind(box,slot).first();
    if(existing?.id){
      await env.DB.prepare('UPDATE dashboard_ads SET image_url=?,caption=?,target_url=?,object_key=?,active=1,duration_sec=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(url,caption,target,key,duration,existing.id).run();
    } else {
      await env.DB.prepare('INSERT INTO dashboard_ads(box_key,slot,image_url,caption,target_url,object_key,active,duration_sec,updated_at) VALUES(?,?,?,?,?,?,1,?,CURRENT_TIMESTAMP)').bind(box,slot,url,caption,target,key,duration).run();
    }
  }catch(e){try{await env.MEDIA.delete(key);}catch(_){}return json({error:'AD_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,220)},500,cors);}
  if(oldKey&&oldKey!==key){try{await env.MEDIA.delete(oldKey);}catch(_){} }
  await createBroadcastNotification(env,'বিজ্ঞাপন আপডেট','ড্যাশবোর্ডের বিজ্ঞাপন আপডেট হয়েছে।');
  return json({ok:true,box_key:box,slot,image_url:url,caption,target_url:target},201,cors);
}

async function adminAdUpdate(request,env){
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; const b=await body(request); const id=Number(b.id||0); if(!id)return json({error:'INVALID_AD_ID'},400,cors);
  const row=await env.DB.prepare('SELECT id FROM dashboard_ads WHERE id=?').bind(id).first(); if(!row)return json({error:'AD_NOT_FOUND'},404,cors);
  const duration=Math.max(1,Math.min(60,Number(b.durationSec||3)));
  await env.DB.prepare('UPDATE dashboard_ads SET caption=?,target_url=?,active=?,duration_sec=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(String(b.caption||'').trim().slice(0,300),String(b.targetUrl||'').trim().slice(0,500),b.active===false?0:1,duration,id).run(); await createBroadcastNotification(env,'বিজ্ঞাপন আপডেট','ড্যাশবোর্ডের বিজ্ঞাপন আপডেট হয়েছে।'); return json({ok:true},200,cors);
}

async function adminAdDelete(request,env){
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; const b=await body(request); const id=Number(b.id||0); if(!id)return json({error:'INVALID_AD_ID'},400,cors); const row=await env.DB.prepare('SELECT object_key FROM dashboard_ads WHERE id=?').bind(id).first(); if(!row)return json({error:'AD_NOT_FOUND'},404,cors); if(env.MEDIA&&row.object_key){try{await env.MEDIA.delete(row.object_key);}catch(_){} } await env.DB.prepare('DELETE FROM dashboard_ads WHERE id=?').bind(id).run(); await createBroadcastNotification(env,'বিজ্ঞাপন সরানো হয়েছে','ড্যাশবোর্ডের একটি বিজ্ঞাপন সরানো হয়েছে।'); return json({ok:true},200,cors);
}

async function profileUpdate(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  const b = await body(request);
  const name = String(b.name ?? user.full_name).trim();
  const email = normalizeEmail(b.email ?? user.email ?? '');
  const mobile = normalizeMobile(b.mobile ?? user.mobile ?? '');
  const bio = String(b.bio ?? user.bio ?? '').trim().slice(0,500);
  if (!name || (!email && !mobile)) return json({error:'INVALID_PROFILE'},400,cors);
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({error:'INVALID_EMAIL'},400,cors);
  const duplicate = await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE user_id<>? AND ((?<>'' AND email=?) OR (?<>'' AND mobile=?)) LIMIT 1`).bind(user.user_id,email,email,mobile,mobile).first();
  if (duplicate) return json({error:'ACCOUNT_EXISTS'},409,cors);
  await env.DB.prepare(`UPDATE myshop_auth_users_v108 SET full_name=?,email=?,mobile=?,bio=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(name,email||null,mobile||null,bio,user.user_id).run();
  const fresh=await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(user.user_id).first();
  return json({ok:true,user:publicUser(fresh)},200,cors);
}

async function profileAvatarUpload(request, env) {
  try { await ensureAuthSchema(env); } catch (_) {}
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  let form;
  try { form = await request.formData(); } catch (e) { return json({error:'AVATAR_MULTIPART_INVALID',message:String(e?.message||e).slice(0,180)},400,cors); }
  const file = form.get('file');
  if (!file || typeof file.arrayBuffer !== 'function') return json({error:'FILE_REQUIRED'},400,cors);
  const rawType=String(file.type||'').toLowerCase();
  const fileName=String(file.name||'').toLowerCase();
  const extName=fileName.includes('.')?fileName.split('.').pop():'';
  const guessedType=extName==='png'?'image/png':extName==='webp'?'image/webp':extName==='gif'?'image/gif':(extName==='jpg'||extName==='jpeg')?'image/jpeg':'';
  const type=rawType.startsWith('image/')?rawType:(guessedType||'');
  if (!type.startsWith('image/')) return json({error:'AVATAR_TYPE_MISMATCH'},400,cors);
  if (Number(file.size||0)>5*1024*1024) return json({error:'AVATAR_TOO_LARGE'},413,cors);
  const ext=(extName||type.split('/')[1]||'jpg').replace(/[^a-z0-9]/g,'').slice(0,8)||'jpg';
  const key=`profiles/${user.user_id}/avatar-${Date.now()}-${randomHex(8)}.${ext}`;
  try { await env.MEDIA.put(key,await file.arrayBuffer(),{httpMetadata:{contentType:type,cacheControl:'public, max-age=3600'}}); }
  catch(e){ return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
  try {
    const saved=await env.MEDIA.head(key);
    if(!saved) throw new Error('R2 object verification failed');
  } catch(e) {
    try { await env.MEDIA.delete(key); } catch(_) {}
    return json({error:'R2_VERIFY_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);
  }
  const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  const oldKey=user.avatar_object_key||'';
  try {
    await env.DB.prepare('UPDATE myshop_auth_users_v108 SET avatar_url=?,avatar_object_key=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(url,key,user.user_id).run();
  } catch(e) {
    try { await env.MEDIA.delete(key); } catch(_) {}
    return json({error:'PROFILE_UPDATE_FAILED'},500,cors);
  }
  if(oldKey && oldKey!==key){ try { await env.MEDIA.delete(oldKey); } catch(_) {} }
  const fresh=await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(user.user_id).first();
  return json({ok:true,user:publicUser(fresh)},200,cors);
}

async function coinBalance(request, env) {
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  await env.DB.prepare('INSERT OR IGNORE INTO myshop_coin_wallets(user_id,balance) VALUES(?,0)').bind(user.user_id).run();
  const wallet=await env.DB.prepare('SELECT user_id,balance,updated_at FROM myshop_coin_wallets WHERE user_id=?').bind(user.user_id).first();
  const tx=(await env.DB.prepare('SELECT id,kind,amount,reference,status,metadata,created_at FROM myshop_coin_transactions WHERE user_id=? ORDER BY id DESC LIMIT 50').bind(user.user_id).all()).results||[];
  return json({ok:true,balance:Number(wallet?.balance||0),transactions:tx},200,cors);
}

async function giftHistory(request,env){
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const rows=(await env.DB.prepare(`SELECT id,sender_user_id,receiver_user_id,coins,gift_code,created_at FROM myshop_gift_transactions WHERE sender_user_id=? OR receiver_user_id=? ORDER BY id DESC LIMIT 100`).bind(user.user_id,user.user_id).all()).results||[];
  return json({ok:true,gifts:rows},200,cors);
}

async function coinPurchaseRequest(request, env) {
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request); const coins=Number(b.coins||0); const amountMinor=Number(b.amountMinor||0); const method=String(b.paymentMethod||'').trim().toLowerCase(); const reference=String(b.reference||'').trim().slice(0,120);
  if(!Number.isInteger(coins)||coins<=0||coins>100000000||!Number.isInteger(amountMinor)||amountMinor<=0||!['bkash','nagad','bangla_qr'].includes(method)) return json({error:'INVALID_PURCHASE_REQUEST'},400,cors);
  const r=await env.DB.prepare('INSERT INTO myshop_coin_purchase_requests(user_id,package_coins,amount_minor,payment_method,reference,status) VALUES(?,?,?,?,?,\'PENDING\')').bind(user.user_id,coins,amountMinor,method,reference).run();
  return json({ok:true,requestId:r.meta?.last_row_id||null,status:'PENDING',message:'Payment request received. Coin credit requires server-side approval.'},201,cors);
}

async function mediaGet(request,env,key) {
  if(!env.MEDIA) return new Response('R2 not configured',{status:503,headers:cors});
  const object=await env.MEDIA.get(key); if(!object) return new Response('Not found',{status:404,headers:cors});
  const headers=new Headers(cors); object.writeHttpMetadata(headers); headers.set('etag',object.httpEtag);
  return new Response(object.body,{headers});
}

async function adminPermissions(request,env) {
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const user = auth.user;
  const mods = await env.DB.prepare('SELECT user_id,active FROM myshop_moderators_v108 ORDER BY user_id LIMIT 5').all();
  return json({ok:true,role:user.role,admin:true,moderators:mods.results||[]},200,cors);
}

async function adminAction(request,env) {
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const b = await body(request);
  const uid = String(b.userId||'').trim();
  const action = String(b.action||'').toLowerCase();
  if (!isFourDigit(uid)) return json({error:'INVALID_USER_ID'},400,cors);
  if (action==='add_moderator') {
    const target = await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(uid).first();
    if (!target) return json({error:'USER_NOT_FOUND'},404,cors);
    const count = await env.DB.prepare('SELECT COUNT(*) AS c FROM myshop_moderators_v108 WHERE active=1').first();
    if (Number(count?.c||0)>=5) return json({error:'MODERATOR_LIMIT'},409,cors);
    await env.DB.prepare('INSERT INTO myshop_moderators_v108(user_id) VALUES(?) ON CONFLICT(user_id) DO UPDATE SET active=1').bind(uid).run();
    await env.DB.prepare("UPDATE myshop_auth_users_v108 SET role='MODERATOR' WHERE user_id=? AND user_id NOT IN ('0001','0002','0003')").bind(uid).run();
  } else if (action==='remove_moderator') {
    await env.DB.prepare('UPDATE myshop_moderators_v108 SET active=0 WHERE user_id=?').bind(uid).run();
    await env.DB.prepare("UPDATE myshop_auth_users_v108 SET role=CASE WHEN role='MODERATOR' THEN 'USER' ELSE role END WHERE user_id=?").bind(uid).run();
  } else return json({error:'UNSUPPORTED_ACTION'},400,cors);
  return json({ok:true},200,cors);
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null,{status:204,headers:cors});
    const url = new URL(request.url); const p=url.pathname;
    try {
      if (request.method==='GET' && p==='/health') return json({ok:true,service:'my-shop-api',version:'2.9.207',build:'V-207',database:'my-shop-db',r2:'MEDIA',time:new Date().toISOString()},200,cors);
      if (request.method==='GET' && p==='/health/deep') {
        try { await ensureAuthSchema(env); } catch (_) {}
        try { await ensureSchemasOnce(env); } catch (_) {}
        const h=await deepHealth(env);
        return json(h,h.ok?200:503,cors);
      }
      // Dashboard config is public read data. Do not let an unrelated auth/content schema
      // initialization failure turn a simple config read into SERVER_ERROR.
      if (request.method==='GET' && p==='/v1/dashboard/config') {
        try { await ensureSchemasOnce(env); } catch (_) {}
        return await dashboardConfig(request,env);
      }
      await ensureSchemasOnce(env);
      if (request.method==='POST' && p==='/v1/auth/register') return await register(request,env);
      if (request.method==='POST' && p==='/v1/auth/login') return await login(request,env);
      if (request.method==='POST' && p==='/v1/auth/logout') return await logout(request,env);
      if (request.method==='GET' && p==='/v1/auth/password/questions') return await securityQuestions(request,env);
      if (request.method==='POST' && p==='/v1/auth/password/reset') return await resetPassword(request,env);
      if (request.method==='GET' && p==='/v1/me') return await me(request,env);
      if (request.method==='PUT' && p==='/v1/me/profile') return await profileUpdate(request,env);
      if (request.method==='POST' && p==='/v1/me/avatar/upload') return await profileAvatarUpload(request,env);
      if (request.method==='GET' && p==='/v1/gallery') return await userGalleryList(request,env);
      if (request.method==='POST' && p==='/v1/gallery/upload') return await userGalleryUpload(request,env);
      if (request.method==='PUT' && p==='/v1/gallery/update') return await userGalleryUpdate(request,env);
      if (request.method==='POST' && p==='/v1/gallery/delete') return await userGalleryDelete(request,env);
      if (request.method==='GET' && p==='/v1/feed') return await feedList(request,env);
      if (request.method==='POST' && p==='/v1/feed/upload') return await feedUpload(request,env);
       if (request.method==='POST' && p==='/v1/feed/text') return await feedText(request,env);
      if (request.method==='POST' && p==='/v1/feed/delete') return await feedDeleteOwn(request,env);
      if (request.method==='POST' && p==='/v1/feed/like') return await feedLike(request,env);
      if (request.method==='POST' && p==='/v1/feed/comment') return await feedComment(request,env);
      if (request.method==='GET' && p==='/v1/admin/feed') return await adminFeedList(request,env);
      if (request.method==='POST' && p==='/v1/admin/feed/delete') return await moderatorFeedDelete(request,env);
      if (request.method==='GET' && p==='/v1/coins') return await coinBalance(request,env);
      if (request.method==='GET' && p==='/v1/gifts/history') return await giftHistory(request,env);
      if (request.method==='POST' && p==='/v1/coins/purchase-request') return await coinPurchaseRequest(request,env);
      if (request.method==='GET' && p==='/v1/notifications') { try { await ensureSchemasOnce(env); } catch (_) {} return await notificationsList(request,env); }
      if (request.method==='POST' && p==='/v1/notifications/read-all') { try { await ensureSchemasOnce(env); } catch (_) {} return await notificationsReadAll(request,env); }
      if (request.method==='GET' && p==='/health/content-write-suite') return await contentWriteSuite(request,env);
      if (request.method==='GET' && p==='/v1/admin/system/health') return await adminSystemHealth(request,env);
      if (request.method==='GET' && p==='/v1/admin/permissions') return await adminPermissions(request,env);
      if (request.method==='PUT' && p==='/v1/admin/dashboard/config') return await adminDashboardPut(request,env);
      if (request.method==='PUT' && p==='/v1/admin/content') return await adminContentPut(request,env);
      if (request.method==='GET' && p==='/v1/admin/media') return await adminMediaList(request,env);
      if (request.method==='POST' && p==='/v1/admin/media/upload') return await adminMediaUpload(request,env);
      if (request.method==='GET' && p==='/v1/admin/ads') return await adminAdsList(request,env);
      if (request.method==='POST' && p==='/v1/admin/ad/upload') return await adminAdUpload(request,env);
      if (request.method==='PUT' && p==='/v1/admin/ad/update') return await adminAdUpdate(request,env);
      if (request.method==='POST' && p==='/v1/admin/ad/delete') return await adminAdDelete(request,env);
      if (request.method==='POST' && p==='/v1/admin/banner/upload') return await adminBannerUpload(request,env);
      if (request.method==='POST' && p==='/v1/admin/banner/delete') return await adminBannerDelete(request,env);
      if (request.method==='PUT' && p==='/v1/admin/banner/update') return await adminBannerUpdate(request,env);
      if (request.method==='PUT' && p==='/v1/admin/media/update') return await adminMediaUpdate(request,env);
      if (request.method==='POST' && p==='/v1/admin/media/delete') return await adminMediaDelete(request,env);
      if (request.method==='GET' && p.startsWith('/v1/media/')) return await mediaGet(request,env,decodeURIComponent(p.slice('/v1/media/'.length)));
      if (request.method==='POST' && p==='/v1/admin/actions') return await adminAction(request,env);
      return json({error:'NOT_FOUND'},404,cors);
    } catch (e) {
      return json({error:'SERVER_ERROR',message:String(e?.message||e)},500,cors);
    }
  }
};
