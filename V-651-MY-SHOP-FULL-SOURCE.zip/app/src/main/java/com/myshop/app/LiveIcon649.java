package com.myshop.app;
import android.graphics.*;import android.graphics.drawable.Drawable;
/** V650 approved freestanding satin controls. Square viewport, no enclosing badge/rim. */
final class LiveIcon649 extends Drawable {
 private final String kind;private final Paint p=new Paint(3);private int alpha=255;private ColorFilter filter;
 LiveIcon649(String value){kind=value.toLowerCase(java.util.Locale.ROOT);}
 public void draw(Canvas c){Rect b=getBounds();float size=Math.min(b.width(),b.height());int save=c.save();c.translate(b.left+(b.width()-size)/2f,b.top+(b.height()-size)/2f);c.scale(size/32f,size/32f);p.setAlpha(alpha);p.setColorFilter(filter);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
 if(kind.contains("love")){material(0xffffc3d5,0xffed356e,0xffa10f46);path(c,"M16 27 C-5 14 9 0 16 10 C23 0 37 14 16 27 Z");}
 else if(kind.contains("more")){material(0xfffff4d6,0xffe9c890,0xffb78b52);for(int y:new int[]{9,23})for(int x:new int[]{9,23})c.drawCircle(x,y,4.5f,p);}
 else if(kind.contains("mic")){material(0xffb8ffff,0xff13cbd3,0xff08758c);c.drawRoundRect(12,3,20,21,4,4,p);silver();stroke(2);c.drawArc(8,10,24,25,0,180,false,p);line(c,16,25,16,29);line(c,11,29,21,29);}
 else if(kind.contains("pk")){material(0xffffedb2,0xffffbc4f,0xffc56c17);p.setTypeface(Typeface.create("sans-serif-black",Typeface.BOLD_ITALIC));p.setTextSize(20);p.setTextAlign(Paint.Align.CENTER);c.drawText("PK",16,23,p);}
 else if(kind.contains("camera")||kind.contains("beauty")){purple();c.drawRoundRect(3,9,27,27,3,3,p);c.drawRoundRect(8,5,17,11,2,2,p);silver();c.drawCircle(15,18,7,p);purple();c.drawCircle(15,18,5,p);silver();c.drawCircle(13.5f,16.5f,1.6f,p);path(c,"M27 1 L28 4 L31 5 L28 6 L27 9 L26 6 L23 5 L26 4 Z");}
 else if(kind.contains("game")){purple();path(c,"M8 8 Q4 8 3 14 L1 25 Q1 31 7 26 L11 22 H21 L25 26 Q31 31 31 25 L29 14 Q28 8 24 8 Z");silver();stroke(2.3f);line(c,7,15,13,15);line(c,10,12,10,18);p.setStyle(Paint.Style.FILL);c.drawCircle(23,13,1.6f,p);c.drawCircle(26,17,1.6f,p);}
 else if(kind.contains("gift")){purple();c.drawRoundRect(5,13,27,29,2,2,p);c.drawRoundRect(3,9,29,15,2,2,p);gold();c.drawRect(14,9,18,29,p);stroke(2.5f);c.drawOval(7,2,16,10,p);c.drawOval(16,2,25,10,p);if(kind.contains("sound")){stroke(1.5f);c.drawArc(25,4,32,17,-60,120,false,p);}}
 else if(kind.contains("message")){teal();c.drawRoundRect(3,5,29,24,5,5,p);path(c,"M8 20 L7 29 L17 22 Z");silver();for(int x:new int[]{10,16,22})c.drawCircle(x,14,1.6f,p);}
 else if(kind.contains("share")){material(0xffc5f7ff,0xff44b9f6,0xff2261bc);stroke(3);line(c,5,21,5,26);line(c,5,26,27,26);line(c,27,26,27,21);line(c,16,21,16,5);line(c,16,5,10,11);line(c,16,5,22,11);}
 else if(kind.contains("music")){purple();stroke(4);line(c,12,23,12,7);line(c,12,7,26,4);line(c,26,4,26,21);p.setStyle(Paint.Style.FILL);c.drawOval(4,20,14,28,p);c.drawOval(18,18,28,26,p);}
 else if(kind.contains("audio")){teal();path(c,"M3 12 H10 L18 5 V27 L10 20 H3 Z");stroke(2);c.drawArc(19,8,29,24,-60,120,false,p);c.drawArc(20,3,34,29,-55,110,false,p);}
 else if(kind.contains("settings")){silver();for(int i=0;i<8;i++){c.save();c.rotate(i*45,16,16);c.drawRoundRect(13,2,19,11,1,1,p);c.restore();}c.drawCircle(16,16,10,p);p.setShader(null);p.setColor(0xff20224c);c.drawCircle(16,16,5,p);}
 else if(kind.contains("favourite")){gold();Path star=new Path();for(int i=0;i<10;i++){double t=-Math.PI/2+i*Math.PI/5;float r=i%2==0?14:6;float x=16+(float)Math.cos(t)*r,y=16+(float)Math.sin(t)*r;if(i==0)star.moveTo(x,y);else star.lineTo(x,y);}star.close();c.drawPath(star,p);}
 else if(kind.contains("vote")){purple();c.drawRoundRect(7,11,26,28,2,2,p);silver();path(c,"M11 3 H25 L20 11 H6 Z");stroke(2);line(c,11,20,15,24);line(c,15,24,22,16);}
 else if(kind.contains("layout")){purple();for(int y:new int[]{4,18})for(int x:new int[]{4,18})c.drawRoundRect(x,y,x+10,y+10,3,3,p);}
 else if(kind.contains("seat")){teal();c.drawRoundRect(7,4,22,19,3,3,p);c.drawRoundRect(3,16,26,25,3,3,p);stroke(3);line(c,7,24,7,29);line(c,23,24,23,29);gold();c.drawRoundRect(23,15,31,24,1,1,p);stroke(2);c.drawArc(24,9,31,19,180,180,false,p);}
 c.restoreToCount(save);}
 private void material(int a,int b,int d){p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);p.setShader(new LinearGradient(5,2,24,30,new int[]{a,b,d},new float[]{0,.5f,1},Shader.TileMode.CLAMP));}
 private void purple(){material(0xffeddbff,0xffae66ed,0xff5129a1);}private void teal(){material(0xffbdffff,0xff24ced4,0xff087d96);}private void silver(){material(0xffffffff,0xffd0d0ef,0xff8c83be);}private void gold(){material(0xfffff6d8,0xffffce6a,0xffb98532);}private void stroke(float width){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(width);}private void line(Canvas c,float x,float y,float a,float b){c.drawLine(x,y,a,b,p);}private void path(Canvas c,String data){c.drawPath(androidx.core.graphics.PathParser.createPathFromPathData(data),p);}
 public void setAlpha(int a){alpha=a;invalidateSelf();}public void setColorFilter(ColorFilter f){filter=f;invalidateSelf();}public int getOpacity(){return PixelFormat.TRANSLUCENT;}public int getIntrinsicWidth(){return 64;}public int getIntrinsicHeight(){return 64;}
}
