# MY SHOP V-651 — source implementation checkpoint

Status: source changes implemented; Android compilation, Robolectric UI tests, signed APK, GitHub run and real-device/production RTC acceptance NOT verified. Do not describe this checkpoint as a fixed/accepted live release.

## Approved scope / last checkpoint
Continue the actual V650 full source (Library filename V-650-MY-SHOP-FULL-SOURCE.zip). The later MY-SHOP-FINAL-V-650(2).zip contains only a 446,078,049-byte APK, not source. Its DEX contains MY SHOP V-650, but original signing/commit provenance was not established here. New identity V651 / 2.9.651. No production deployment, key replacement or external repository write performed.
Owner authorized work after discussion on2026-10-20. Follow pictures + final chat + Developer Rules. Comment vertical height/flow is locked to V650, Rocket highlight behavior unchanged, other controls/financial rules unchanged. Explicit follow-up: two large videos + six further working positions means eight total participants. Four/six means TOTAL including Host. Normal video area HEIGHT reduced20%; width is retained to fit side by side; full-screen is not reduced.

## Implemented source changes (not device acceptance)
1. RTC remote-video availability retained if SDK event arrives before panel creation, then hydrated into the panel. Remote TextureView remains visible underneath the opaque loading cover to bootstrap decoding; explicit camera-off still hides it. Frozen/starting state does not erase the previous decoded state. Unchanged audio profile, gain, routing, mute authority and financial logic.
2. An accepted but unconfirmed SDK join may be retried after15s. Token requests have a15s stale-callback guard. Token refresh always passes through channel identity check, so a new room session cannot renew an old channel silently.
3. Comment composer Send is disabled while sending and restored on failure; keyboard Send action reaches the same guarded handler. Existing highlight API/nonce/selection retained. First-touch behavior still needs a physical keyboard/device test.
4. Solo Host normal video uses full-screen automatically. Full-screen PK polling no longer overwrites MATCH_PARENT height with the compact height. Camera-off solo Host reveals selected room theme, with no frozen frame/profile cover; audio/comment/gift state is not ended.
5. New default selectable Video8: two large videos and one horizontal row of six working positions. Existing2/4/7 options retained,6 enabled (schema already supports6); legacy5 accepted by server. Four uses existing large Host +3 vertical guests; six uses existing Host-left grid. Focus/restore remains host-authoritative. Three full-screen gold empty-chair positions visible; additional positions reachable by vertical scroll.
6. Full-screen-only horizontal comment hide/show uses INVISIBLE to retain existing measured bounds and vertical flow. Normal layouts keep original scrolling. Height/seat-to-composer anchoring logic untouched.
7. Coin/Gold header opens independent all-time Top20 from existing gift-summary endpoint; currency filter applied BEFORE LIMIT20. Combined100:1 ranking and lifetime ledgers unchanged. First three cards styled distinctly. Only successful gifts, host isolation, previous sessions retained.
8. Existing PK layout/score/sounds retained. Supporter query now selects top THREE for EACH side, rather than letting one side consume the global six rows. Other icons untouched.

## Validation / truthful limits
- New SQLite lifetime/currency/100:1/auth and per-PK-side ranking tests pass.
- Broad114 Node test-file gate and targeted lifecycle/invite/reward/account-deletion tests run; final results in verification/V651-RESULTS.json.
- Java parser/callback Context audit and compiled gift-send test are distinct from Android type checking.
- Four new Robolectric tests cover8 positions, remote surface/bootstrap + explicit off, full-screen theme, horizontal gesture preserving height. Added to CI by normal test discovery; not run locally because Gradle8.11.1 distribution download fails Network is unreachable. No Android SDK build or new APK claimed.
- Exact file preservation compares804 original unchanged production files; scoped changes are separately pinned by V651 source manifest. Generated runtime media must pass original manifests, never remove a required sound/animation to shrink a bundle.
- TargetSDK36 remains unchanged. Reviewed official Android target SDK and camera/mic while-in-use guidance; no Play acceptance claim. Phone tests must include permission denial, microphone/camera foreground/background/PiP, route/headset, reconnect, muted users, Host/Guest/Audience on separate networks. No account/privacy/billing release audit performed in this scope.

## Build / setup
Keep original package com.myshop.app and original signing certificate. Use included .github/workflows/my-shop-apk.yml + tools/ci-apk-build.sh. Read BUILD-ASSETS-BN.md and GITHUB-UPLOAD-V651-BN.md. Generate media using bash tools/prepare-build-assets.sh, then bash tools/v651_target_verify.sh. Android gate: bash gradlew clean :app:testDebugUnitTest :app:assembleRelease :app:lintRelease -PmyshopOfflineTests -PrequirePush --no-daemon --no-build-cache --rerun-tasks.
Use existing GitHub Secrets MYSHOP_KEYSTORE_BASE64 (or existing encrypted-key restoration), MYSHOP_KEYSTORE_PASSWORD, MYSHOP_KEY_ALIAS, MYSHOP_KEY_PASSWORD and original Firebase config/secrets. Never place values in source or logs. Worker requires its existing AGORA_APP_ID/AGORA_APP_CERTIFICATE secrets and existing D1/R2 bindings. Apply existing migrations through0063 in order if not already applied. V651 requires matching client/Worker for currency-filter UI; there is no new schema migration and no automatic deployment.

## Remaining acceptance / next actions
1. Run exact V651 CI from a clean checkout with original secrets. Verify intended commit SHA, SOURCE_BUILD_ID, package/version, original cert and exact run artifact hash/timestamp; inspect source/DEX gates. Only one signed MY_SHOP_FINAL_RELEASE.apk for users.
2. Perform Host + Guest + Audience device tests: actual remote video/audio in both directions, join delay, same/new session reconnect, camera-off/on, solo/pair/4/6/8, focus/restore, PK, comment Send with keyboard/failure, swipe, gift animation/sound, moderation, minimize/end and old modules. Do not call remote-video/audio bugs resolved before this.
3. Visually compare devices with supplied images.20% sizing was implemented as height reduction while retaining full horizontal width; adjust only if owner clarifies a different dimension.
4. Measure signed APK size. Existing V650 input APK is446MB; this source package excludes reproducible outputs but retains source generators. Do not promise25MB APK or delete needed features. Native multi-ABI SDK/media dominate the inherited APK.
5. Continue from this checkpoint, do not restart V650. A later changed delivery must useV652; do not overwrite delivered651.
