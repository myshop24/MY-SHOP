# V610 / 2.9.610 — canonical GitHub source delivery

Continued from V609, with identical approved features. Owner requested the next delivery number V610 because V609 was already delivered. Android versionCode 610, versionName 2.9.610, SOURCE_BUILD_ID MY SHOP V-610 and Worker health identity V-610 all match. Cosmetic catalog codes AV609_, asset paths and migration marker remain unchanged intentionally to prevent duplicate products or lost ownership.

Use exactly V-610-MY-SHOP-FULL-SOURCE.zip in the existing repository root. This name matches the permanent release selector. Successful APK release workflow produces the new signed APK; GitHub Pages is a separate workflow and does not build APKs. No actual GitHub run, full Android build or phone animation acceptance is claimed here.

All V609 completed features, preservation details, passed local tests and outstanding phone acceptance are recorded in handoffs/MY-SHOP-V609-HANDOFF.md and remain applicable. No unrelated features changed. D1 optimization remains excluded. Next new delivery V611; continue from V610.
