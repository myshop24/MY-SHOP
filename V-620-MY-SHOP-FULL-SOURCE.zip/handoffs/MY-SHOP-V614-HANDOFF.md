# V614 / 2.9.614 — GitHub compiler failure correction

Canonical source: V-614-MY-SHOP-FULL-SOURCE.zip. Next delivery V615.
Continued directly from delivered V613. Parent SHA256: 9749bbe79b9417cc1ef387510cb48c01359179d9c2d7ae1c7b5ab3ad05e2b43b.

## Failure and correction
Owner GitHub run #677 (commit shown65349df) failed :app:compileReleaseJavaWithJavac at AudioLiveRoomActivity.java:806: cannot find symbol class Dialog, private Dialog giftDialog613. Added missing android.app.Dialog import. No Live layout, RTC, gift transaction or other behavior changed for this fix. The Node20/setup-java/ubuntu warnings in the summary are separate warnings, not the shown compiler error; workflow dependencies were not changed speculatively.

## Prevention and verification
- tests/v614-dialog-compile.spec.py compiles the exact shipped field/import against an Android Dialog type stub; reproduces original missing-import cannot-find-symbol error and rejects it. This is a targeted Java type test, not full Android compilation.
- tools/v583_package_check.py now checks unqualified Dialog field/return/type references as well as constructor imports; this catches the precise omitted import syntax parsing missed.
- tools/v614_verify.sh passed the inherited target chain and new compiler test; tools/v575_verify.sh passed existing regression checks. Actual logs are verification/v614-target.log and v614-regression.log.
- Preservation test normalizes V614 health version/build metadata only, leaving existing locked-function assertions unchanged.
- SOURCE_BUILD_ID, versionCode614, versionName2.9.614 and Worker health match. CI now runs V614 target checks before signed Android build, original certificate/package/version/provenance verification and upload artifact.
- Local full Gradle assembleRelease attempted; Gradle8.11.1 download failed Network is unreachable. No V614 APK built and no new GitHub run performed here. This ZIP contains source/build workflow, NO APK. GitHub Android build success is required before downloading MY_SHOP_FINAL_RELEASE.apk from Artifacts. Original signing/Firebase secrets required, unchanged.

## Continuation and known incomplete features
All V613 source changes and pending work remain recorded in handoffs/MY-SHOP-V613-HANDOFF.md. True1003D media/sound, comprehensive localization, Admin-only missing animation reproduction, Mini Card unsaved edit across page switches, reference pixel fidelity and phone/RTC/payment/push acceptance remain pending; this import correction does not claim those features complete. No production Worker/D1 deployment or public APK replacement performed. Preserve original signing key, auth IDs, wallet/ledger, bindings and previous archives. Continue from V614 and issue V615 for the next new delivery.
