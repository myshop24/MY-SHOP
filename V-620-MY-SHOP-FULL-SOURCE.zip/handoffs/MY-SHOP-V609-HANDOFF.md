# V609 / 2.9.609 — Store and animation continuation

Continued from the delivered V608 source; no restart. Next new delivery V610. Owner-authorized remaining Store/animation/comment work implemented in source. D1 read optimization (previous item 3) is explicitly excluded.

## Source changes completed
- Home Membership shortcut becomes matching blue Store; Live Store and Games use icon above label. Store opens all products, with Popular/Membership/Avatar Frame/Rider/Theme tabs and New → Membership → Avatar Frame → Rider → Theme shelves. Three complete tiles per viewport row, remaining tiles horizontally swipeable.
- White Store design, current portrait previews, demo/details, dynamic Admin prices/days, existing Buy Request and quoted friend-gift paths; full-screen image/video Theme preview and existing 20 rider demos. Original Membership ranks, privilege rules, prices, artwork, and comment styles remain separate from decorative frames.
- Three normal decorative frames with light matching comment skins and one luxury violet frame with elaborate comment skin. Frame visuals derive from supplied videos; luxury input is the clean first 1.5 seconds to exclude hand-drawn red marks. Blank selected comment plates carry dynamic text/avatar/crest. New products seed as disabled drafts: Admin must set a positive diamond price and publish; no invented prices or automatic grants.
- Real inline Store ad carousel below categories near My Items/Admin; right-to-left auto movement and horizontal manual swipe. Store Admin folder links catalog activities and separate ads. Existing 20 templates, direct first/second colour wheels, mixed colours, gallery image/link, seconds, expiry, revision/restore and permissions retained. Other page advertisements stay separate.
- Shared Membership frame renderer decodes at actual view size, keeps per-view animation state, infinite repeats and lifecycle rearming; software GIF clock fallback. Own-account and other-account rendering share the same path. Explicit user Reduce Animation preference stays respected. This is a source correction, not a reproduced/verified phone fix.
- Live comment skin sets background before padding, keeps name/LV/Top1 inside the skin, bounds body font size and uses internal scrolling if needed. Existing 200-codepoint handling and visit isolation retained. Cosmetics do not displace Membership or Top1 identity.

## Preservation
Original package/signing settings and GitHub workflow/secrets contract retained. No production deployment, real charge, gift or admin publication performed here. Existing financial quote/hold/ownership/equip/expiry paths retained. Original six Membership animation inputs/outputs are unchanged. Source size was reduced by resizing only the old static app icon and seven legacy avatar JPGs to 768px while retaining aspect/design; they are not byte-identical. See verification/v609-static-sizing.json. New generated animation outputs are reconstructed from included source inputs by prepare_build_assets.py and verified against manifests; blank comment skins are included directly.

## Verification actually completed
- tools/v609_verify.sh passed: inherited owner edit restrictions, post gift SQL/rollback, 20 rides, live entry/reentry isolation, tier/Coin ordering, Top1 helpers, missing-key Java compile regression; new SQLite cosmetic seed rollback/retry, equipment/expiry without membership privileges, Store ad auth/mixed colours/revision/expiry/Home isolation; gift quote matching/stale rejection; four moving WebP/GIF outputs, alpha holes, geometry and selected blank skins; compiled cosmetic helper checks.
- tools/v575_verify.sh passed: broad backend regression suite, parsing of 221 Java sources, resource/import/package and known compiler-failure contracts. These checks do not type-check the entire Android app.
- Full Android compile attempt could not download Gradle 8.11.1 (Network is unreachable); local SDK/signing build is not verified. No APK included or claimed. Owner's existing GitHub pipeline must build the new signed APK and publish MY_SHOP_FINAL_RELEASE.apk after success. Verify intended source identity V609/2.9.609/609 and original certificate; never reuse an old APK.

## Device acceptance still required
After successful GitHub build, compare own ID and another ID for frame animation across profile/Live/seats/comments/catalog, app focus/reentry, and accessibility preference. Check 200-character comments on small screens, three-card shelves, Theme video demo, swipe/auto ads and matching Admin colours. Real RTC/audio/payment/push and latency are not tested here. D1 quota optimization remains excluded, not silently completed.

## Resume instructions
Continue from this V609 source and this handoff, not V607/V608. Finish only actual device/build failures reported next; preserve unrelated modules. Next source delivery V610. Historical handoffs remain included for audit.
