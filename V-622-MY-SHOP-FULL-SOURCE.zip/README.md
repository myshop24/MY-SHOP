# MY SHOP V-622 full source checkpoint

This complete Android/Worker source continues V621. Six approved task groups have local source checks; gift cinematic quality remains incomplete. Read MY-SHOP-DEVELOPER-HANDOFF.md and DEVELOPER-POLICY-BN.md first.

No APK is included. Upload/extract the full project (including .github) to the repository root, retain original GitHub signing/Firebase Secrets, then run Actions → MY SHOP Android APK. After a verified successful exactV622 build, download the ONE MY_SHOP_FINAL_RELEASE.apk artifact. See GITHUB_UPLOAD.md and SIGNING-SETUP.md. Do not reuse an older APK.

Local media: python3 tools/prepare_build_assets.py (requirements in tools/requirements-build-assets.txt, ffmpeg and DejaVu fonts required). Local target/regression: bash tools/v622_verify.sh. Full build: bash gradlew --no-daemon assembleRelease with Android SDK36, network and original signing setup. The source includes generators and inputs for omitted build-generated media.

Package com.myshop.app; SOURCE_BUILD_ID MY SHOP V-622; versionName2.9.622. Next changed delivery V623. No production deployment authorized/performed.
