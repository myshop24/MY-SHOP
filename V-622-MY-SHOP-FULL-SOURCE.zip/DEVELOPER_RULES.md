Current V622 /2.9.622: read MY-SHOP-DEVELOPER-HANDOFF.md. Six task groups source-tested; Task4 premium cinematic quality incomplete. Android/signedAPK/production/device acceptance pending. Next new deliveryV623. Latest owner rules supersede historical notes.

Current V620 /2.9.620: read handoffs/MY-SHOP-V620-HANDOFF.md. Latest three-item source scope implemented,20additive gifts; local tests pass. ProductionD1, fullAndroid/signedAPK/device acceptance pending. Next changeddeliveryV621.

# MY SHOP — Canonical Developer Rules

The merged, deduplicated policy is DEVELOPER-POLICY-BN.md (2026-10-09). Read that file before implementation/build/delivery. Read MY-SHOP-DEVELOPER-INSTRUCTIONS.md for retained distinct feature instructions, AGENTS.md for Live approval scope, and MY-SHOP-DEVELOPER-HANDOFF.md for actual continuation state. This file is an entry point rather than a duplicate policy. Latest owner instructions override historical notes.

Owner addition 2026-10-11: Read section 7 “GitHub আপলোড ও APK ডাউনলোড” in DEVELOPER-POLICY-BN.md. Every future source ZIP must include the working signed-APK GitHub workflow, downloadable canonical APK artifact after successful build, setup/download instructions, and explicit disclosure when APK has not been built.

## Owner delivery rule — V597 continuation
Provide the complete versioned source ZIP for GitHub upload. Preserve the original package/signing identity and working Android APK workflow. A successful GitHub build must upload its verified signed APK as an Actions artifact. If local SDK/signing credentials are unavailable, explicitly state that no APK was built; never substitute an older APK or claim build success. Retain all prior releases.
