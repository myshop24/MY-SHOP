# V-622 upload and APK download

This is the full SOURCE ZIP. It contains no APK; local Android compilation was blocked by Gradle download/network. Task4 gift cinematic quality is incomplete; read the handoff before release.

1. Extract V-622-MY-SHOP-FULL-SOURCE.zip and upload all files to repository root, including .github. Do not upload a second nested project folder.
2. Keep the ORIGINAL signing key and existing GitHub Secrets listed in SIGNING-SETUP.md. Do not put credentials in source or generate a replacement signing key.
3. Actions → MY SHOP Android APK → Run workflow. If your existing repository root pipeline chooses versioned ZIPs, this file uses its V-number naming contract; retain that root pipeline.
4. Only after the actual Android release build and provenance checks succeed, open that run's Artifacts and download the canonical MY_SHOP_FINAL_RELEASE.apk.
5. Verify V622/2.9.622, source/commit/build identity, package and original signing certificate. A green non-Android workflow is insufficient.

New Themes are Admin drafts: set price/duration and publish. Source ZIP under25,000,000bytes is a separate size measure from the eventual APK. Full device/RTC/audio/payment/push QA and gift visual acceptance remain pending.
