package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * V-314 premium Admin Control Center.
 * Login/gate/backend routes are intentionally preserved; this class only reorganizes the admin UX.
 */
public class AdminHubActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG = Color.rgb(246, 248, 254);
    private final int NAVY = Color.rgb(20, 32, 73);
    private final int MUTED = Color.rgb(100, 108, 130);
    private final int BLUE = Color.rgb(44, 106, 238);
    private final int PURPLE = Color.rgb(116, 55, 225);
    private final int PINK = Color.rgb(232, 49, 168);
    private final int CYAN = Color.rgb(32, 174, 222);
    private final int GREEN = Color.rgb(29, 159, 101);
    private final int ORANGE = Color.rgb(236, 138, 30);
    private final int RED = Color.rgb(220, 63, 79);
    private final int WHITE = Color.WHITE;

    private LinearLayout moduleHost;
    private FrameLayout shell;
    private LinearLayout sideMenuPanel;
    private EditText searchBox;
    private final List<Module> modules = new ArrayList<>();
    private final Map<String, Category> categories = new LinkedHashMap<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        String uid = SessionManager.getUserId(this);
        if (AdminIdentifiers.isAdminIdentifier(uid)) {
            SessionManager.setRemoteSession(this, SessionManager.getToken(this), Role.ADMIN, AdminIdentifiers.adminIdFor(uid));
        }
        if (!SessionManager.isAdmin(this)) { finish(); return; }
        if (!getIntent().getBooleanExtra("gate_passed", false) && !SessionManager.isAdminGateUnlocked()) {
            startActivity(new Intent(this, AdminGateActivity.class));
            finish(); return;
        }
        seedModules();
        build();
    }

    private boolean bn() { return LanguageManager.BN.equals(LanguageManager.get(this)); }
    private String tr(String bangla, String english) { return bn() ? bangla : english; }
    private String langLabel() {
        String l = LanguageManager.get(this);
        if (LanguageManager.BN.equals(l)) return "🌐 বাংলা";
        if (LanguageManager.HI.equals(l)) return "🌐 हिन्दी";
        if (LanguageManager.AR.equals(l)) return "🌐 العربية";
        return "🌐 English";
    }

    private void seedModules() {
        categories.clear(); modules.clear();
        addCategory("finance", "💳", tr("অর্থ ও হিসাব", "Finance & Accounting"), tr("লেনদেন, পেমেন্ট, Coin/Gold Coin", "Transactions, payment, Coin/Gold Coin"), BLUE);
        addCategory("live", "📡", tr("লাইভ স্ট্রিমিং", "Live Streaming"), tr("লাইভ গিফট ও থিম নিয়ন্ত্রণ", "Live gifts and themes"), PINK);
        addCategory("membership", "👑", tr("মেম্বারশিপ ও ব্যাজ", "Membership & Badges"), tr("ROYAL/VVIP/VIP, ব্যাজ ও গ্রান্ট", "ROYAL/VVIP/VIP, badges and grants"), PURPLE);
        addCategory("content", "🖼", tr("ড্যাশবোর্ড ও কনটেন্ট", "Dashboard & Content"), tr("ব্যানার, মিডিয়া, লিংক, বিজ্ঞাপন", "Banners, media, links and ads"), CYAN);
        addCategory("community", "🛡", tr("কমিউনিটি ও নিরাপত্তা", "Community & Safety"), tr("মডারেশন, সাপোর্ট ও রিপোর্ট", "Moderation, support and reports"), GREEN);
        addCategory("system", "⚙", tr("সিস্টেম", "System"), tr("সিস্টেম স্বাস্থ্য ও টেকনিক্যাল পরীক্ষা", "Health and technical checks"), ORANGE);

        add("finance","💰",tr("লেনদেন • আয়/ব্যয়", "Transactions & Earnings"),tr("আজকের হিসাব, মোট, User ID খোঁজ ও audit", "Daily totals, user lookup and audit"),"finance_center",BLUE);
        add("finance","💳",tr("পেমেন্ট পদ্ধতি", "Payment Methods"),tr("নাম, লিংক/মান, চালু/বন্ধ", "Name, link/value and visibility"),"payment_methods",PURPLE);
        add("finance","➕",tr("ইউজারকে Coin / Gold দিন", "Give Coin / Gold to User"),tr("User ID যাচাই করে Official grant দিন", "Verify User ID and send an Official grant"),"admin_wallet",GREEN);

        add("finance","🎁",tr("কয়েন ও গোল্ড কয়েন ক্যাটালগ", "Coin & Gold Coin Catalog"),tr("পূর্ণ Gift Studio • Grid, Edit, Drag, Sound Trim, Animation, Box, VAT, Publish", "Full Gift Studio • Grid, Edit, Drag, Sound Trim, Animation, Box, VAT, Publish"),"live_gifts",PINK);
        add("live","💬",tr("লাইভ কমেন্ট ও ব্যানার", "Live Comments & Banners"),tr("ফন্ট সাইজ, ১০ ব্যানার, User ID assignment", "Font size, 10 banners, User ID assignment"),"live_comments",PINK);
        add("live","🎨",tr("অডিও লাইভ থিম", "Audio Live Themes"),tr("ব্যাকগ্রাউন্ড, accent, publish", "Background, accent and publish"),"live_themes",PURPLE);

        add("membership","🏅",tr("এনিমেটেড ব্যাজ • ID গ্রান্ট", "Animated Badges • ID Grant"),tr("Asset, মূল্য, মেয়াদ, publish ও user grant", "Asset, price, duration, publish and user grant"),"wallet_badge",PURPLE);
        add("membership","👑",tr("ROYAL • VVIP • VIP", "ROYAL • VVIP • VIP"),tr("মেম্বারশিপ মূল্য, মেয়াদ ও সুবিধা", "Membership price, duration and benefits"),"wallet_badge",ORANGE);

        add("content","🏞",tr("ব্যানার ম্যানেজমেন্ট", "Banner Management"),tr("সর্বোচ্চ ৬টি, upload/edit/save/delete", "Up to 6, upload/edit/save/delete"),"banner",BLUE);
        add("content","🖼",tr("গ্যালারি ম্যানেজমেন্ট", "Gallery Management"),tr("ছবি, অডিও, ভিডিও ও caption", "Images, audio, video and captions"),"gallery",CYAN);
        add("content","📢",tr("ড্যাশবোর্ড বিজ্ঞাপন", "Dashboard Ads"),tr("ছবি/ভিডিও, লিংক, ১–৬ বিজ্ঞাপন", "Image/video, links, 1–6 ads"),"ads",PINK);
        add("content","📰",tr("ড্যাশবোর্ড • ব্রেকিং নিউজ", "Dashboard • Breaking News"),tr("শিরোনাম, URL, text style ও save", "Headline, URLs, text style and save"),"dashboard",BLUE);
        add("content","✨",tr("ফিচার ম্যানেজমেন্ট", "Feature Management"),tr("নাম, icon, link, show/hide", "Name, icon, link and visibility"),"features",PURPLE);
        add("content","🔳",tr("ড্যাশবোর্ড ছোট ফিচার স্লট", "Dashboard Feature Slots"),tr("Slot 1–6, ছবি, caption, link", "Slots 1–6, image, caption and link"),"dynamic_content",CYAN);
        add("content","🌐",tr("সোশ্যাল লিংক", "Social Links"),tr("Facebook, YouTube, TikTok, WhatsApp ইত্যাদি", "Facebook, YouTube, TikTok, WhatsApp and more"),"social",BLUE);
        add("content","📺",tr("লাইভ টিভি", "Live TV"),tr("চ্যানেল, link, icon, show/hide", "Channels, links, icons and visibility"),"live_tv",RED);
        add("content","🎬",tr("এক্সটার্নাল মুভি", "External Movie"),tr("নাম, link, custom icon/image", "Name, link and custom icon/image"),"external_movie",PURPLE);
        add("content","📱",tr("আরও অ্যাপ", "More Apps"),tr("App name, link, icon, show/hide", "App name, link, icon and visibility"),"more_apps",GREEN);
        add("content","🚀",tr("অ্যাপ ওপেন বিজ্ঞাপন", "Startup Advertisement"),tr("Full Image/Fill Screen, image/video, 1–4 sec", "Full Image/Fill Screen, image/video, 1–4 sec"),"startup_ads",ORANGE);

        add("community","🧑‍💼",tr("মডারেটর / এডমিন", "Moderator / Admin"),tr("Moderator ID যোগ/সরান ও admin safety", "Add/remove moderator IDs and admin safety"),"moderators",PURPLE);
        add("community","📝",tr("MY FEED মডারেশন", "MY FEED Moderation"),tr("রিপোর্টেড/কুরুচিপূর্ণ পোস্ট review", "Review reported or abusive posts"),"feed_moderation",RED);
        add("community","💬",tr("কাস্টমার সাপোর্ট", "Customer Support"),tr("WhatsApp, imo, Facebook, website", "WhatsApp, imo, Facebook and website"),"help_support",GREEN);
        add("community","🛡",tr("Safety Reports • Account Deletion", "Safety Reports • Account Deletion"),tr("Report review, resolve/dismiss, deletion verification", "Report review, resolve/dismiss, deletion verification"),"safety_reports",RED);

        add("system","🩺",tr("সিস্টেম স্বাস্থ্য / পরীক্ষা", "System Health / Test"),tr("Worker, D1, R2 ও API পরীক্ষা", "Worker, D1, R2 and API checks"),"system_health",ORANGE);
    }

    private void addCategory(String key, String icon, String title, String desc, int color) {
        categories.put(key, new Category(key, icon, title, desc, color));
    }
    private void add(String category, String icon, String title, String desc, String mode, int color) {
        modules.add(new Module(category, icon, title, desc, mode, color));
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setClipToPadding(false);

        LinearLayout root = col();
        root.setBackgroundColor(BG);
        root.setPadding(dp(12), dp(10), dp(12), dp(28));

        root.addView(topBar(), lp(-1, dp(54)));
        root.addView(heroCard(), top(lp(-1, dp(148)), dp(8)));
        root.addView(quickStatus(), top(lp(-1, dp(70)), dp(10)));

        TextView heading = txt(tr("আপনার অ্যাপ পরিচালনা করুন", "Manage Your App"), 17, NAVY, true);
        heading.setPadding(dp(4), dp(18), dp(4), dp(4));
        root.addView(heading, lp(-1, dp(48)));

        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setTextSize(12.5f);
        searchBox.setHint(tr("🔎  ফিচার বা সেটিং খুঁজুন…", "🔎  Search a feature or setting…"));
        searchBox.setPadding(dp(15), 0, dp(15), 0);
        searchBox.setBackground(round(WHITE, Color.rgb(218,224,240), 17));
        root.addView(searchBox, lp(-1, dp(50)));

        moduleHost = col();
        root.addView(moduleHost, top(lp(-1, -2), dp(10)));
        renderModules("");

        TextView safe = txt(tr("🔐 Login, Admin Gate, D1/R2 binding ও existing backend route অপরিবর্তিত রাখা হয়েছে।", "🔐 Login, Admin Gate, D1/R2 bindings and existing backend routes are preserved."), 10.5f, MUTED, false);
        safe.setGravity(Gravity.CENTER);
        safe.setPadding(dp(12), dp(14), dp(12), dp(14));
        root.addView(safe, top(lp(-1, -2), dp(10)));

        searchBox.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int before, int count) { renderModules(s == null ? "" : s.toString()); }
            public void afterTextChanged(Editable e) {}
        });

        sv.addView(root);
        shell=new FrameLayout(this);
        shell.setBackgroundColor(BG);
        shell.addView(sv,new FrameLayout.LayoutParams(-1,-1));
        sideMenuPanel=buildSideMenu();
        FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(232),-1,Gravity.START);
        shell.addView(sideMenuPanel,sp);
        sideMenuPanel.bringToFront();
        setContentView(shell);
    }

    private View topBar() {
        LinearLayout row = row(); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = txt("☰", 24, NAVY, true); back.setGravity(Gravity.CENTER); back.setOnClickListener(v -> toggleSideMenu()); row.addView(back, lp(dp(42), dp(48)));
        LinearLayout brand = col();
        TextView logo = txt("MY SHOP", 20, BLUE, true); logo.setLetterSpacing(.02f); brand.addView(logo, lp(-1, dp(26)));
        brand.addView(txt(tr("ADMIN CONTROL CENTER", "ADMIN CONTROL CENTER"), 9.5f, MUTED, true), lp(-1, dp(18)));
        row.addView(brand, weight(1));
        TextView lang = chip(langLabel(), BLUE, WHITE); lang.setOnClickListener(v -> LanguageManager.showPicker(this, this::recreate)); row.addView(lang, lp(dp(96), dp(38)));
        TextView more = chip("⋮", NAVY, WHITE); more.setTextSize(22); more.setOnClickListener(v -> showAdminMenu(more)); row.addView(more, left(lp(dp(42),dp(38)),dp(6)));
        return row;
    }

    private View heroCard() {
        LinearLayout hero = col(); hero.setPadding(dp(18), dp(16), dp(18), dp(14));
        hero.setBackground(gradient(new int[]{Color.rgb(38,83,216), Color.rgb(91,61,226), Color.rgb(219,55,180)}, 22));
        TextView crown = txt("👑  "+tr("স্বাগতম, Admin!", "Welcome, Admin!"), 21, WHITE, true); hero.addView(crown, lp(-1, dp(38)));
        TextView sub = txt(tr("MY SHOP-কে এক জায়গা থেকে সহজে পরিচালনা করুন", "Manage MY SHOP easily from one organized place"), 11.5f, Color.rgb(240,242,255), false); hero.addView(sub, lp(-1, dp(30)));
        TextView note = txt(tr("ফোল্ডার খুলুন → প্রয়োজনীয় অংশ বাছুন → পরিবর্তন করুন → Preview → Save/Publish", "Open a folder → choose a module → edit → Preview → Save/Publish"), 10.5f, WHITE, true);
        note.setPadding(dp(11),dp(7),dp(11),dp(7)); note.setBackground(round(Color.argb(38,255,255,255), Color.argb(75,255,255,255), 13)); hero.addView(note, top(lp(-1,-2),dp(6)));
        return hero;
    }

    private View quickStatus() {
        LinearLayout row = row(); row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(statusTile("🔐",tr("Admin", "Admin"),tr("Verified", "Verified"),BLUE),weight(1));
        row.addView(statusTile("🗂",String.valueOf(categories.size()),tr("Folders", "Folders"),PURPLE),left(weight(1),dp(7)));
        row.addView(statusTile("🧩",String.valueOf(modules.size()),tr("Tools", "Tools"),PINK),left(weight(1),dp(7)));
        return row;
    }

    private View statusTile(String icon, String big, String small, int color) {
        LinearLayout c = col(); c.setGravity(Gravity.CENTER); c.setPadding(dp(6),dp(7),dp(6),dp(5)); c.setBackground(round(WHITE,Color.rgb(224,228,241),16));
        TextView t = txt(icon+"  "+big,13,color,true); t.setGravity(Gravity.CENTER); c.addView(t,lp(-1,dp(27)));
        TextView s = txt(small,9.5f,MUTED,false); s.setGravity(Gravity.CENTER); c.addView(s,lp(-1,dp(22)));
        return c;
    }

    private void renderModules(String query) {
        if (moduleHost == null) return;
        moduleHost.removeAllViews();
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        int found = 0;
        for (Category cat : categories.values()) {
            List<Module> group = new ArrayList<>();
            for (Module m : modules) {
                if (!cat.key.equals(m.category)) continue;
                if (q.isEmpty() || (m.title+" "+m.desc+" "+cat.title).toLowerCase(Locale.ROOT).contains(q)) group.add(m);
            }
            if (group.isEmpty()) continue;
            found += group.size();
            moduleHost.addView(categoryFolder(cat, group, !q.isEmpty()), top(lp(-1,-2),dp(8)));
        }
        if (found == 0) {
            LinearLayout empty = card(); empty.setGravity(Gravity.CENTER); empty.setPadding(dp(12),dp(22),dp(12),dp(22));
            TextView t = txt(tr("কিছু পাওয়া যায়নি\nঅন্য শব্দ দিয়ে খুঁজুন", "Nothing found\nTry another search"),12,MUTED,true); t.setGravity(Gravity.CENTER); empty.addView(t,lp(-1,-2));
            moduleHost.addView(empty,lp(-1,-2));
        }
    }

    private View categoryFolder(Category cat, List<Module> group, boolean openInitially) {
        LinearLayout outer = card(); outer.setPadding(0,0,0,0); outer.setClipToPadding(false);
        LinearLayout header = row(); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(12),dp(11),dp(10),dp(11));
        TextView icon = txt(cat.icon,23,WHITE,true); icon.setGravity(Gravity.CENTER); icon.setBackground(gradient(new int[]{cat.color, brighten(cat.color)},16)); header.addView(icon,lp(dp(50),dp(50)));
        LinearLayout copy = col(); copy.setPadding(dp(12),0,dp(5),0); copy.addView(txt(cat.title,14,NAVY,true),lp(-1,dp(26))); TextView d=txt(cat.desc,9.7f,MUTED,false); d.setMaxLines(2); copy.addView(d,lp(-1,dp(32))); header.addView(copy,weight(1));
        TextView count = txt(group.size()+"  ›",11,cat.color,true); count.setGravity(Gravity.CENTER); count.setBackground(round(light(cat.color),Color.TRANSPARENT,12)); header.addView(count,lp(dp(58),dp(36)));
        outer.addView(header,lp(-1,dp(72)));

        LinearLayout body = col(); body.setPadding(dp(8),0,dp(8),dp(8));
        for (Module m : group) body.addView(moduleCard(m), top(lp(-1,-2),dp(7)));
        body.setVisibility(openInitially ? View.VISIBLE : View.GONE);
        outer.addView(body,lp(-1,-2));
        header.setOnClickListener(v -> {
            boolean show = body.getVisibility() != View.VISIBLE;
            body.setVisibility(show ? View.VISIBLE : View.GONE);
            count.setText(group.size() + (show ? "  ⌄" : "  ›"));
            press(header);
        });
        count.setText(group.size() + (openInitially ? "  ⌄" : "  ›"));
        return outer;
    }

    private View moduleCard(Module m) {
        LinearLayout row = row(); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(10),dp(9),dp(9),dp(9)); row.setBackground(round(Color.rgb(251,252,255),Color.rgb(230,233,244),15));
        TextView icon = txt(m.icon,21,m.color,true); icon.setGravity(Gravity.CENTER); icon.setBackground(round(light(m.color),Color.TRANSPARENT,13)); row.addView(icon,lp(dp(46),dp(46)));
        LinearLayout copy=col(); copy.setPadding(dp(10),0,dp(4),0); TextView title=txt(m.title,12.5f,NAVY,true); title.setMaxLines(1); copy.addView(title,lp(-1,dp(24))); TextView desc=txt(m.desc,9.3f,MUTED,false); desc.setMaxLines(2); copy.addView(desc,lp(-1,dp(31))); row.addView(copy,weight(1));
        TextView open=txt(tr("খুলুন  ›","Open  ›"),10,m.color,true); open.setGravity(Gravity.CENTER); open.setBackground(round(light(m.color),Color.TRANSPARENT,12)); row.addView(open,lp(dp(70),dp(38)));
        row.setOnClickListener(v -> open(m.mode));
        row.setOnTouchListener((v,e)->{ if(e.getAction()==MotionEvent.ACTION_DOWN) v.animate().scaleX(.987f).scaleY(.987f).alpha(.92f).setDuration(55).start(); else if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL) v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(95).start(); return false; });
        return row;
    }

    private void toggleSideMenu(){if(sideMenuPanel==null)return;boolean show=sideMenuPanel.getVisibility()!=View.VISIBLE;sideMenuPanel.setVisibility(show?View.VISIBLE:View.GONE);if(show)sideMenuPanel.bringToFront();}

    private LinearLayout buildSideMenu(){
        LinearLayout wrap=col();wrap.setPadding(0,0,0,dp(10));wrap.setBackground(gradient(new int[]{Color.rgb(12,28,72),Color.rgb(18,31,82)},0));wrap.setElevation(dp(16));
        LinearLayout head=col();head.setPadding(dp(16),dp(18),dp(12),dp(14));head.addView(txt("👑  MY SHOP",17,Color.WHITE,true),lp(-1,dp(30)));head.addView(txt("Admin Panel",10,Color.rgb(80,220,245),true),lp(-1,dp(22)));wrap.addView(head,lp(-1,dp(78)));
        ScrollView scroll=new ScrollView(this);LinearLayout list=col();list.setPadding(dp(8),dp(4),dp(8),dp(12));
        addSide(list,"⌂","Dashboard",()->{},true);
        addSide(list,"👥","Users & Members",()->open("users"),false);
        addSide(list,"▣","Content Management",()->open("dashboard"),false);
        addSide(list,"👑","Coin & Gold Coin",()->open("live_gifts"),true);
        addSide(list,"🎁","Gift Coin Catalog",()->openGiftCurrency("COIN"),true);
        addSide(list,"♛","Gold Coin Catalog",()->openGiftCurrency("GOLD"),false);
        addSide(list,"🪙","Coin Management",()->open("finance_center"),false);
        addSide(list,"●","Gold Coin Management",()->open("finance_center"),false);
        addSide(list,"➕","Give Coin to User",()->open("admin_wallet"),false);
        addSide(list,"✦","Give Gold Coin to User",()->open("admin_wallet"),false);
        addSide(list,"⇄","Coin Transactions",()->open("finance_center"),false);
        addSide(list,"◉","Gold Coin Transactions",()->open("finance_center"),false);
        addSide(list,"🎁","Gift History",()->open("finance_center"),false);
        addSide(list,"💰","Earnings & Revenue",()->open("finance_center"),false);
        addSide(list,"％","VAT & Commission",()->open("live_gifts"),false);
        addSide(list,"▤","Reports & Analytics",()->open("finance_center"),false);
        addSide(list,"📡","Live Streaming",()->open("live_themes"),false);
        addSide(list,"🛒","Orders & Store",()->open("wallet_badge"),false);
        addSide(list,"🖼","Media & Gallery",()->open("gallery"),false);
        addSide(list,"📢","Advertisements",()->open("ads"),false);
        addSide(list,"★","Dynamic Badges",()->open("wallet_badge"),false);
        addSide(list,"⚙","Settings",()->open("system_health"),false);
        addSide(list,"▤","Logs",()->open("system_health"),false);
        addSide(list,"⏻","Logout",this::logout,false);
        scroll.addView(list);wrap.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));return wrap;
    }
    private void addSide(LinearLayout host,String icon,String label,Runnable action,boolean accent){TextView v=txt(icon+"   "+label,10.6f,Color.WHITE,accent);v.setGravity(Gravity.CENTER_VERTICAL);v.setPadding(dp(10),0,dp(8),0);v.setBackground(accent?gradient(new int[]{Color.rgb(64,77,230),Color.rgb(63,175,232)},10):round(Color.TRANSPARENT,Color.TRANSPARENT,10));v.setOnClickListener(x->{press(v);toggleSideMenu();action.run();});host.addView(v,top(lp(-1,dp(42)),dp(3)));}
    private void openGiftCurrency(String currency){Intent i=new Intent(this,LiveGiftAdminActivity.class);i.putExtra("currency",currency);startActivity(i);}

    private void showAdminMenu(View anchor) {
        PopupMenu p = new PopupMenu(this, anchor);
        p.getMenu().add(tr("আমার প্রোফাইল", "My Profile"));
        p.getMenu().add(tr("সিস্টেম স্বাস্থ্য", "System Health"));
        p.getMenu().add(tr("লগআউট", "Logout"));
        p.setOnMenuItemClickListener(item -> {
            String s = item.getTitle().toString();
            if (s.equals(tr("আমার প্রোফাইল","My Profile"))) startActivity(new Intent(this,AccountActivity.class));
            else if (s.equals(tr("সিস্টেম স্বাস্থ্য","System Health"))) startActivity(new Intent(this,AdminSystemHealthActivity.class));
            else logout();
            return true;
        });
        p.show();
    }

    private void open(String mode) {
        if ("finance_center".equals(mode)) { startActivity(new Intent(this,AdminFinanceActivity.class)); return; }
        if ("banner".equals(mode)) { startActivity(new Intent(this,BannerAdminActivity.class)); return; }
        if ("gallery".equals(mode)) { startActivity(new Intent(this,GalleryAdminActivity.class)); return; }
        if ("ads".equals(mode)) { startActivity(new Intent(this,DashboardAdsAdminActivity.class)); return; }
        if ("startup_ads".equals(mode)) {
            Intent i = new Intent(this,DashboardAdsAdminActivity.class);
            i.putExtra("box_key","startup_ad");
            i.putExtra("box_title",tr("অ্যাপ ওপেন ছবি / ভিডিও বিজ্ঞাপন","Startup Image / Video Advertisement"));
            startActivity(i); return;
        }
        if ("feed_moderation".equals(mode)) { startActivity(new Intent(this,FeedModerationActivity.class)); return; }
        if ("system_health".equals(mode)) { startActivity(new Intent(this,AdminSystemHealthActivity.class)); return; }
        if ("coin_gold_catalog".equals(mode)) { startActivity(new Intent(this,CoinGoldCatalogActivity.class)); return; }
        if ("wallet_badge".equals(mode)) { startActivity(new Intent(this,AdminStoreActivity.class)); return; }
        if ("admin_wallet".equals(mode)) { startActivity(new Intent(this,AdminWalletActivity.class)); return; }
        if ("live_themes".equals(mode)) { startActivity(new Intent(this,LiveThemeAdminActivity.class)); return; }
        if ("live_comments".equals(mode)) { startActivity(new Intent(this,LiveCommentAdminActivity.class)); return; }
        if ("live_gifts".equals(mode)) { startActivity(new Intent(this,LiveGiftAdminActivity.class)); return; }
        if ("safety_reports".equals(mode)) { startActivity(new Intent(this,AdminSafetyActivity.class)); return; }
        Intent i = new Intent(this,AdminSectionActivity.class);
        i.putExtra("section", mode); i.putExtra("admin_context", true); startActivity(i);
    }

    private void logout() {
        String token = SessionManager.getToken(this);
        SessionManager.clear(this);
        Intent i = new Intent(this, LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        if (token != null && !token.isEmpty()) BackendClient.logout(token,new BackendClient.Callback(){ public void onSuccess(JSONObject d){} public void onError(String m){} });
    }

    private void press(View v){ v.animate().scaleX(.99f).scaleY(.99f).setDuration(45).withEndAction(()->v.animate().scaleX(1f).scaleY(1f).setDuration(80).start()).start(); }
    private int brighten(int c){ return Color.rgb(Math.min(255,Color.red(c)+35),Math.min(255,Color.green(c)+35),Math.min(255,Color.blue(c)+35)); }
    private int light(int c){ return Color.rgb((Color.red(c)+255*4)/5,(Color.green(c)+255*4)/5,(Color.blue(c)+255*4)/5); }

    private TextView chip(String s,int color,int text){ TextView t=txt(s,10,text,true); t.setGravity(Gravity.CENTER); t.setBackground(round(WHITE,Color.rgb(217,223,239),14)); return t; }
    private LinearLayout card(){ LinearLayout c=col(); c.setPadding(dp(10),dp(10),dp(10),dp(10)); c.setBackground(round(WHITE,Color.rgb(223,227,241),18)); c.setElevation(dp(2)); return c; }
    private LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private LinearLayout col(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private TextView txt(String s,float z,int c,boolean bold){ TextView v=new TextView(this); v.setText(s); v.setTextSize(z); v.setTextColor(c); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private GradientDrawable gradient(int[] colors,int r){ GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors); g.setCornerRadius(dp(r)); return g; }
    private GradientDrawable round(int fill,int stroke,int r){ GradientDrawable g=new GradientDrawable(); g.setColor(fill); g.setCornerRadius(dp(r)); if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke); return g; }
    private LinearLayout.LayoutParams lp(int w,int h){ return new LinearLayout.LayoutParams(w,h); }
    private LinearLayout.LayoutParams weight(float w){ return new LinearLayout.LayoutParams(0,-1,w); }
    private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int t){ p.topMargin=t; return p; }
    private LinearLayout.LayoutParams left(LinearLayout.LayoutParams p,int l){ p.leftMargin=l; return p; }
    private int dp(int n){ return Math.round(n*getResources().getDisplayMetrics().density); }

    private static final class Category {
        final String key,icon,title,desc; final int color;
        Category(String k,String i,String t,String d,int c){key=k;icon=i;title=t;desc=d;color=c;}
    }
    private static final class Module {
        final String category,icon,title,desc,mode; final int color;
        Module(String c,String i,String t,String d,String m,int x){category=c;icon=i;title=t;desc=d;mode=m;color=x;}
    }
}
