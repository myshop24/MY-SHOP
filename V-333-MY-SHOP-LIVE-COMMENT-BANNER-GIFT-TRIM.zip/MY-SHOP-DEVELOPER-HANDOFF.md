# MY SHOP Developer Handoff — V-333
Base: V-332 (known GitHub GREEN).
Completed source scope: Live comment cleanup, host pin-any-comment UI, larger/admin-controlled comment font, 10 User-ID comment banners, interactive Gift Sound trim waveform controls.
Backend: deploy `backend/worker/src/index.js` for comment UI/banner D1 tables and endpoints.
Pending verification: GitHub release compile, Worker deployment, two-account banner assignment test, host pin/unpin test, real-device Gift Sound select/trim/test/save/reopen.
Do not redesign Home Dashboard or alter Host separate + 12 seats (6+6).
