# MY SHOP Developer Handoff — V-334

Base: V-333
Build identity: MY SHOP V-334
versionCode: 334
versionName: 2.9.334

Completed in this version:
- Fixed CI-blocking duplicate `<activity>` registration for LiveCommentAdminActivity in AndroidManifest.xml.
- Preserved all V-333 Live Room, pinned comment, Live Comment Admin/Banner, and Gift Sound trim changes.

Pending verification:
- GitHub release build: NEEDS CI TEST.
- Real-device Live Comment/Banner/Pinned Comment/Gift Sound QA: NEEDS DEVICE TEST.

Regression rule:
- Do not redesign the locked Home Dashboard.
- Preserve Host separate + 12 seats (6+6).
- Preserve Coin/Gold flows and existing backend contracts.
