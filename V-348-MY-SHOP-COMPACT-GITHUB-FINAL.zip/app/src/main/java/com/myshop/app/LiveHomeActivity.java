package com.myshop.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;

/** V-328 premium Live Streaming Hub. Real backend data; Home Dashboard remains untouched. */
public class LiveHomeActivity extends AppCompatActivity {
    private final int NAVY=Color.rgb(10,24,68), MUTED=Color.rgb(91,102,137), BLUE=Color.rgb(44,111,244), PINK=Color.rgb(239,49,181), PURPLE=Color.rgb(120,63,235);
    private final Handler handler=new Handler();
    private LinearLayout activeRow,trendingRow,newRow;
    private TextView activeState,trendingState,newState;
    private final Runnable refreshTick=()->loadAll(false);

    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(build());loadAll(true);}

    private View build(){
        LinearLayout page=col();page.setBackgroundColor(Color.rgb(246,248,255));
        page.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(0,Math.max(0,i.getSystemWindowInsetTop()),0,Math.max(0,i.getSystemWindowInsetBottom()));return i;});

        LinearLayout top=row();top.setPadding(dp(14),0,dp(14),0);top.setGravity(Gravity.CENTER_VERTICAL);top.setBackground(PremiumUi.solid(this,Color.WHITE,0,Color.rgb(236,239,249),1));PremiumUi.premiumElevation(top,2);
        TextView back=t("‹",34,NAVY,true);back.setGravity(Gravity.CENTER);PremiumUi.press(back);back.setOnClickListener(v->finish());top.addView(back,lp(dp(48),dp(58)));
        TextView title=t("LIVE STREAMING",22,NAVY,true);title.setGravity(Gravity.CENTER);top.addView(title,wt(1,dp(58)));
        LinearLayout brand=col();brand.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);TextView b1=t("MY SHOP",13,Color.rgb(67,54,215),true);b1.setGravity(Gravity.RIGHT);TextView b2=t("Shop • Social • Live",7.5f,MUTED,false);b2.setGravity(Gravity.RIGHT);brand.addView(b1);brand.addView(b2);top.addView(brand,lp(dp(96),dp(48)));page.addView(top,lp(-1,dp(58)));

        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setVerticalScrollBarEnabled(false);
        LinearLayout body=col();body.setPadding(dp(14),dp(8),dp(14),dp(18));

        FrameLayout hero=new FrameLayout(this);hero.setBackground(PremiumUi.gradient(this,new int[]{Color.rgb(35,79,230),Color.rgb(112,54,225),Color.rgb(232,53,176)},22,Color.argb(120,255,255,255),1));hero.setClipToOutline(true);PremiumUi.premiumElevation(hero,5);
        ImageView heroImg=new ImageView(this);heroImg.setImageResource(R.drawable.startup_ad_myshop_live);heroImg.setScaleType(ImageView.ScaleType.CENTER_CROP);heroImg.setAlpha(.72f);hero.addView(heroImg,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this);shade.setBackground(grad(new int[]{Color.argb(225,11,31,105),Color.argb(90,108,29,161),Color.argb(10,245,57,177)},20));hero.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout heroText=col();heroText.setPadding(dp(16),dp(16),dp(16),dp(12));heroText.addView(t("MY SHOP",18,Color.WHITE,true));heroText.addView(t("LIVE\nSTREAMING",27,Color.WHITE,true));heroText.addView(t("Real People • Real Stories\nShop • Social • Live • Connect",10.5f,Color.rgb(238,243,255),false));FrameLayout.LayoutParams htp=new FrameLayout.LayoutParams(dp(220),-1,Gravity.LEFT);hero.addView(heroText,htp);
        TextView liveBadge=t("◉  LIVE",15,Color.WHITE,true);liveBadge.setGravity(Gravity.CENTER);liveBadge.setBackground(round(Color.argb(220,231,32,164),Color.rgb(255,126,224),16));FrameLayout.LayoutParams lbp=new FrameLayout.LayoutParams(dp(120),dp(44),Gravity.RIGHT|Gravity.BOTTOM);lbp.rightMargin=dp(14);lbp.bottomMargin=dp(14);hero.addView(liveBadge,lbp);
        body.addView(hero,lp(-1,dp(158)));

        LinearLayout actions=row();actions.setPadding(0,dp(10),0,0);
        TextView go=action("▣  Go Live\nShare Your World",new int[]{Color.rgb(50,160,251),Color.rgb(63,92,236)});go.setOnClickListener(v->{Intent i=new Intent(this,AudioLiveRoomActivity.class);i.putExtra("hostMode",true);startActivity(i);});
        TextView join=action("👥  Join Live\nDiscover Amazing Creators  ›",new int[]{Color.rgb(244,55,182),Color.rgb(127,58,239),Color.rgb(49,121,247)});join.setOnClickListener(v->openList("LIVE_NOW"));
        LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(0,dp(70),.35f);gp.rightMargin=dp(8);actions.addView(go,gp);actions.addView(join,new LinearLayout.LayoutParams(0,dp(70),.65f));body.addView(actions,lp(-1,dp(80)));

        body.addView(sectionHeader("●  Active Live",PINK,()->openList("LIVE_NOW")),top(lp(-1,dp(42)),8));
        activeState=t("Loading active live…",10,MUTED,false);body.addView(activeState,lp(-1,dp(22)));
        HorizontalScrollView ah=new HorizontalScrollView(this);ah.setHorizontalScrollBarEnabled(false);activeRow=row();activeRow.setPadding(0,0,dp(4),0);ah.addView(activeRow);body.addView(ah,lp(-1,dp(126)));

        body.addView(sectionHeader("🔥  Trending Rooms",PINK,()->openList("TRENDING")),top(lp(-1,dp(42)),8));
        trendingState=t("Loading trending rooms…",10,MUTED,false);body.addView(trendingState,lp(-1,dp(22)));
        HorizontalScrollView th=new HorizontalScrollView(this);th.setHorizontalScrollBarEnabled(false);trendingRow=row();trendingRow.setPadding(0,0,dp(4),0);th.addView(trendingRow);body.addView(th,lp(-1,dp(224)));

        body.addView(sectionHeader("★  New Users",Color.rgb(244,181,47),this::openNewPeople),top(lp(-1,dp(42)),8));
        newState=t("Loading new users…",10,MUTED,false);body.addView(newState,lp(-1,dp(22)));
        HorizontalScrollView nh=new HorizontalScrollView(this);nh.setHorizontalScrollBarEnabled(false);newRow=row();newRow.setPadding(0,0,dp(4),0);nh.addView(newRow);body.addView(nh,lp(-1,dp(136)));

        LinearLayout footer=row();footer.setPadding(dp(14),dp(10),dp(12),dp(10));footer.setBackground(grad(new int[]{Color.rgb(238,244,255),Color.rgb(247,236,255)},16));footer.addView(t("◇",26,PURPLE,true),lp(dp(42),dp(42)));LinearLayout ft=col();ft.addView(t("Be a Part of MY SHOP Live",12,NAVY,true));ft.addView(t("Shop Together • Support Creators • Real Connections",8.8f,MUTED,false));footer.addView(ft,wt(1,dp(42)));TextView better=t("Better Together  ›",9,Color.WHITE,true);better.setGravity(Gravity.CENTER);better.setBackground(grad(new int[]{Color.rgb(237,47,181),Color.rgb(105,73,239)},15));footer.addView(better,lp(dp(112),dp(36)));body.addView(footer,top(lp(-1,dp(64)),14));

        sv.addView(body);page.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        page.addView(bottomNav(),lp(-1,dp(66)));page.post(page::requestApplyInsets);return page;
    }

    private View bottomNav(){LinearLayout nav=row();nav.setPadding(dp(8),dp(5),dp(8),dp(5));nav.setBackgroundColor(Color.WHITE);nav.addView(navItem("⌂\nHome",false,v->finish()),wt(1,dp(56)));nav.addView(navItem("▢\nShop",false,v->startActivity(new Intent(this,StoreActivity.class))),wt(1,dp(56)));nav.addView(navItem("▣\nLive",true,v->{}),wt(1,dp(56)));nav.addView(navItem("▤\nFeed",false,v->{Intent i=new Intent(this,FeatureActivity.class);i.putExtra("title","MY FEED");i.putExtra("feature_key","my_feed");startActivity(i);}),wt(1,dp(56)));nav.addView(navItem("○\nProfile",false,v->{Intent i=new Intent(this,UserProfileActivity.class);i.putExtra("userId",SessionManager.getUserId(this));startActivity(i);}),wt(1,dp(56)));return nav;}
    private TextView navItem(String s,boolean on,View.OnClickListener l){TextView v=t(s,9,on?PURPLE:MUTED,on);v.setGravity(Gravity.CENTER);PremiumUi.press(v);v.setOnClickListener(l);if(on)v.setBackground(PremiumUi.gradient(this,new int[]{Color.rgb(247,239,255),Color.rgb(235,242,255)},18,Color.rgb(215,198,255),1));return v;}

    private void loadAll(boolean first){loadLive("LIVE_NOW",true);loadLive("TRENDING",false);loadNewUsers();}
    private void loadLive(String category,boolean active){BackendClient.liveDiscover(SessionManager.getToken(this),category,12,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->renderLive(d.optJSONArray("rooms"),active));}public void onError(String m){runOnUiThread(()->{if(active)activeState.setText("Live list unavailable • tap See All to retry");else trendingState.setText("Trending list unavailable • tap See All to retry");});}});}
    private void renderLive(JSONArray a,boolean active){LinearLayout row=active?activeRow:trendingRow;TextView state=active?activeState:trendingState;row.removeAllViews();int n=a==null?0:a.length();state.setText(n==0?(active?"No one is live right now":"No trending rooms right now"):(active?n+" active live now":n+" trending live rooms"));for(int i=0;i<n;i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;row.addView(active?activeCard(x):trendingCard(x));}}
    private View activeCard(JSONObject x){LinearLayout c=col();c.setGravity(Gravity.CENTER_HORIZONTAL);c.setPadding(dp(3),dp(4),dp(3),dp(4));ImageView av=avatar(dp(72));String u=x.optString("avatarUrl","");if(!u.isEmpty())loadImage(av,u);FrameLayout ring=new FrameLayout(this);ring.setBackground(round(Color.WHITE,PINK,42));FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(dp(68),dp(68),Gravity.CENTER);ap.setMargins(dp(3),dp(3),dp(3),dp(3));ring.addView(av,ap);TextView badge=t("LIVE",8,Color.WHITE,true);badge.setGravity(Gravity.CENTER);badge.setBackground(round(PINK,PINK,8));FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(44),dp(18),Gravity.CENTER_HORIZONTAL|Gravity.BOTTOM);bp.bottomMargin=-dp(1);ring.addView(badge,bp);c.addView(ring,lp(dp(78),dp(78)));TextView nm=t(shortName(x.optString("name","MY SHOP User")),10,NAVY,true);nm.setGravity(Gravity.CENTER);c.addView(nm,lp(dp(86),dp(22)));TextView vc=t(compact(x.optInt("viewerCount",0))+" watching",8.5f,MUTED,false);vc.setGravity(Gravity.CENTER);c.addView(vc,lp(dp(86),dp(18)));PremiumUi.press(c);c.setOnClickListener(v->joinRoom(x));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(96),dp(118));p.rightMargin=dp(8);c.setLayoutParams(p);return c;}
    private View trendingCard(JSONObject x){LinearLayout c=col();c.setPadding(dp(8),dp(8),dp(8),dp(8));c.setBackground(PremiumUi.solid(this,Color.WHITE,18,Color.rgb(225,229,244),1));PremiumUi.premiumElevation(c,4);FrameLayout media=new FrameLayout(this);ImageView img=avatar(dp(132));img.setScaleType(ImageView.ScaleType.CENTER_CROP);String u=x.optString("avatarUrl","");if(!u.isEmpty())loadImage(img,u);media.addView(img,new FrameLayout.LayoutParams(-1,-1));TextView live=t("▶ LIVE",8,Color.WHITE,true);live.setGravity(Gravity.CENTER);live.setBackground(round(PINK,PINK,8));FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(55),dp(20),Gravity.LEFT|Gravity.TOP);lp.leftMargin=dp(7);lp.topMargin=dp(7);media.addView(live,lp);TextView viewers=t("◉ "+compact(x.optInt("viewerCount",0)),8,Color.WHITE,true);viewers.setGravity(Gravity.CENTER);viewers.setBackground(round(Color.argb(170,20,20,35),Color.TRANSPARENT,8));FrameLayout.LayoutParams vp=new FrameLayout.LayoutParams(dp(58),dp(20),Gravity.RIGHT|Gravity.TOP);vp.rightMargin=dp(7);vp.topMargin=dp(7);media.addView(viewers,vp);c.addView(media,lp(-1,dp(112)));c.addView(t(x.optString("title","Audio Live"),11,NAVY,true),lp(-1,dp(24)));TextView sub=t(x.optString("name","MY SHOP Creator"),9,MUTED,false);c.addView(sub,lp(-1,dp(20)));LinearLayout bottom=row();ImageView mini=avatar(dp(24));if(!u.isEmpty())loadImage(mini,u);bottom.addView(mini,lp(dp(24),dp(24)));TextView host=t("  "+shortName(x.optString("name","Creator")),8.8f,NAVY,true);bottom.addView(host,wt(1,dp(28)));TextView join=t("Join",9,Color.WHITE,true);join.setGravity(Gravity.CENTER);join.setBackground(grad(new int[]{PINK,PURPLE},14));bottom.addView(join,lp(dp(62),dp(30)));c.addView(bottom,lp(-1,dp(32)));PremiumUi.press(c);c.setOnClickListener(v->joinRoom(x));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(172),dp(208));p.rightMargin=dp(9);c.setLayoutParams(p);return c;}
    private void loadNewUsers(){BackendClient.newPeople(SessionManager.getToken(this),12,0,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->renderNew(d.optJSONArray("people")));}public void onError(String m){runOnUiThread(()->newState.setText("New users unavailable right now"));}});}
    private void renderNew(JSONArray a){newRow.removeAllViews();int n=a==null?0:a.length();newState.setText(n==0?"No new users right now":n+" new users");for(int i=0;i<n;i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String uid=x.optString("userId","");if(uid.equals(SessionManager.getUserId(this)))continue;LinearLayout c=col();c.setGravity(Gravity.CENTER_HORIZONTAL);c.setPadding(dp(8),dp(8),dp(8),dp(8));c.setBackground(PremiumUi.solid(this,Color.WHITE,17,Color.rgb(227,231,246),1));PremiumUi.premiumElevation(c,3);ImageView av=avatar(dp(54));String u=x.optString("avatarUrl","");if(!u.isEmpty())loadImage(av,u);c.addView(av,lp(dp(54),dp(54)));TextView nm=t(shortName(x.optString("name","New User")),9,NAVY,true);nm.setGravity(Gravity.CENTER);c.addView(nm,lp(dp(100),dp(22)));TextView lv=t("New Creator • LV."+x.optInt("level",0),7.7f,MUTED,false);lv.setGravity(Gravity.CENTER);c.addView(lv,lp(dp(100),dp(18)));TextView follow=t("View Profile",8.5f,Color.WHITE,true);follow.setGravity(Gravity.CENTER);follow.setBackground(grad(new int[]{BLUE,PURPLE},12));c.addView(follow,lp(dp(100),dp(30)));PremiumUi.press(c);c.setOnClickListener(v->{Intent q=new Intent(this,UserProfileActivity.class);q.putExtra("userId",uid);startActivity(q);});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(116),dp(126));p.rightMargin=dp(8);c.setLayoutParams(p);newRow.addView(c);}}

    private LinearLayout sectionHeader(String title,int accent,Runnable all){LinearLayout h=row();TextView x=t(title,15,NAVY,true);h.addView(x,wt(1,dp(40)));TextView see=t("See All  ›",10,BLUE,true);see.setGravity(Gravity.CENTER);PremiumUi.press(see);see.setOnClickListener(v->all.run());h.addView(see,lp(dp(86),dp(40)));return h;}
    private TextView action(String s,int[] colors){TextView v=t(s,12.3f,Color.WHITE,true);v.setGravity(Gravity.CENTER);v.setLines(2);v.setPadding(dp(8),0,dp(8),0);v.setBackground(PremiumUi.gradient(this,colors,20,Color.argb(105,255,255,255),1));PremiumUi.premiumElevation(v,5);PremiumUi.press(v);return v;}
    private ImageView avatar(int size){ImageView v=new ImageView(this);v.setImageResource(R.drawable.myshop_profile_avatar);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(round(Color.rgb(234,239,255),Color.rgb(210,217,241),size/2));v.setClipToOutline(true);return v;}
    private void joinRoom(JSONObject x){String uid=x.optString("userId","");if(uid.isEmpty())return;Intent i=new Intent(this,AudioLiveRoomActivity.class);i.putExtra("hostMode",false);i.putExtra("hostId",uid);i.putExtra("hostName",x.optString("name","MY SHOP User"));startActivity(i);}
    private void openList(String category){Intent i=new Intent(this,LiveListActivity.class);i.putExtra("category",category);startActivity(i);}
    private void openNewPeople(){Intent i=new Intent(this,LiveListActivity.class);i.putExtra("category","NEW_HOST");startActivity(i);}
    @Override protected void onResume(){super.onResume();handler.removeCallbacks(refreshTick);handler.postDelayed(refreshTick,7000);}
    @Override protected void onPause(){handler.removeCallbacks(refreshTick);super.onPause();}
    @Override protected void onDestroy(){handler.removeCallbacks(refreshTick);super.onDestroy();}
    private void loadImage(ImageView v,String u){new Thread(()->{try{Bitmap b=BitmapFactory.decodeStream(new URL(u).openStream());if(b!=null)runOnUiThread(()->v.setImageBitmap(b));}catch(Exception ignored){}}).start();}
    private String shortName(String n){if(n==null||n.trim().isEmpty())return "User";n=n.trim();return n.length()>13?n.substring(0,13):n;}
    private String compact(long n){if(n>=1000000)return String.format(java.util.Locale.US,"%.1fM",n/1000000f);if(n>=1000)return String.format(java.util.Locale.US,"%.1fK",n/1000f);return String.valueOf(n);}
    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private TextView t(String s,float z,int c,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    private GradientDrawable grad(int[] colors,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(radius));return g;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams wt(float w,int h){return new LinearLayout.LayoutParams(0,h,w);} private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;} private int dp(float x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
}
