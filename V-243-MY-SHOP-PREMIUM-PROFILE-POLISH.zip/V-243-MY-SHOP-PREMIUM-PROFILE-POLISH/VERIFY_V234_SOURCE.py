from pathlib import Path
root=Path(__file__).resolve().parent
def read(p): return (root/p).read_text(encoding='utf-8')
main=read('app/src/main/java/com/myshop/app/MainActivity.java')
gradle=read('app/build.gradle')
worker=read('backend/worker/src/index.js')
workflow=read('.github/workflows/my-shop-apk.yml')
tests={
 'source id':read('SOURCE_BUILD_ID.txt').strip()=='MY SHOP V-234',
 'source version':read('SOURCE_VERSION_NAME.txt').strip()=='2.9.234',
 'android version':'versionCode 234' in gradle and "versionName '2.9.234'" in gradle,
 'worker identity':worker.count("version:'2.9.234',build:'V-234'")>=2,
 'notification':'release_notice_v234' in worker,
 'workflow':'AUTO-BUILD V-234' in workflow,
 'fixed header/live':all(x in main for x in ['fixed.addView(header()','fixed.addView(breaking()','fixed.addView(liveStreamingSection()']),
 'live controls':all(x in main for x in ['Go Live','Live Now','Join Live','See All  →']),
 'responsive live row':'new JSONObject[6]' in main and 'weight(1,dp(58))' in main,
 'title animation':'ObjectAnimator.ofFloat(title,"scaleX"' in main,
 'headline readable':'Math.max(newsTextSizeSp,12.5f)' in main,
 'single feed label':'names.addView(text("MY FEED"' not in main,
 'requirements':(root/'FINAL_DASHBOARD_REQUIREMENTS_V234.md').is_file(),
 'java delimiters':main.count('{')==main.count('}')
}
for n,v in tests.items(): print(('PASS ' if v else 'FAIL ')+n)
failed=[n for n,v in tests.items() if not v]
print(f"RESULT: {len(tests)-len(failed)}/{len(tests)}")
raise SystemExit(bool(failed))
