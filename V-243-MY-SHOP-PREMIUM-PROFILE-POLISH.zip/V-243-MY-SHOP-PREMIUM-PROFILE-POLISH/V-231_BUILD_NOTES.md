# V-231 MY SHOP — Latest 7 Fix Final Safe

Base: V-230-MY-SHOP-REFERENCE-DASHBOARD-ADMIN-FOLDER-SAFE

## Implemented latest 7 instructions
1. Header safe-area/touch fix: Profile, Language, Notification and Chat are positioned below the system status area with comfortable touch targets while preserving the approved design.
2. Breaking headline redesign: removed the literal “Breaking News”, 🔥 and “Shop Now”; kept animated 📣 + headline only. Admin tapping the headline opens the editor directly with Edit/Save, Delete and A-/A+ size controls.
3. MY FEED unlocked: dashboard content and feed now use one natural full-page ScrollView so upper sections scroll away and feed posts can use the full screen.
4. More + Profile drawer clarity: shortcut icons/touch cells and drawer icons/text/rows enlarged for clearer viewing and tapping.
5. Bottom navigation: Home / Store / Live / Support / More each use a distinct vibrant approved-palette color.
6. Notifications: post-owner Like/Comment notifications remain server-backed; system/content update notices remain in the same inbox; a one-time V-231 release update notice is added; opening the inbox marks unread notifications seen so the badge clears.
7. Chat icon: the user-provided Messenger icon is bundled and used in the top-right Chat button at a slightly larger balanced size.

## Safety / backend preservation
- Cloudflare D1/R2 binding file `backend/worker/wrangler.toml` is unchanged.
- Existing D1 migration files are unchanged.
- Permanent User ID/session/account-store source files are unchanged.
- Breaking-news text size is implemented with an additive D1 column only (`breaking_news_text_size`); no user table is removed/reset.
- User core identity records are not hard-deleted by these changes.
- Approved dashboard color defaults remain unchanged; Admin-only color settings continue to work.

## Version
- versionCode: 231
- versionName: 2.9.231
- source build: V-231

## Build environment note
This package is source-verified in this environment. Full Android APK compilation requires Android SDK 36 and is intended to run in the existing GitHub Actions release workflow.
