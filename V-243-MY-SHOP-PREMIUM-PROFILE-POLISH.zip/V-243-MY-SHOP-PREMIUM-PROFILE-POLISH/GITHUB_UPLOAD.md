# V-230 GitHub upload

Normal permanent flow:
1. Upload `V-230-MY-SHOP-REFERENCE-DASHBOARD-ADMIN-FOLDER-SAFE.zip` to the repository root.
2. The repository-root `.github/workflows/my-shop-apk.yml` selects the highest V-number source ZIP.
3. Build/sign V-230 with the existing permanent signing key.
4. Download the artifact; it must contain only `MY_SHOP_FINAL_RELEASE.apk`.
5. Install and test functions separately from build status.

Required function checks: exact approved Dashboard palette/layout direction, profile drawer, Language/Notification/Chat header, six-slot hero, Live Streaming, My Feed, MORE-only shortcut grid, per-folder Admin controls, six ads per folder, ordinary-user Admin invisibility, permanent User ID, and Cloudflare D1/R2 content/media.
