package com.myshop.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** V-238 Facebook-style New People: newest eligible users, relationship state, See All pagination. */
public class NewPeopleActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(248,249,253), BLUE=Color.rgb(46,47,190), PURPLE=Color.rgb(91,38,214), DARK=Color.rgb(30,35,56), MUTED=Color.rgb(105,111,130), GREEN=Color.rgb(24,169,98);
    private LinearLayout list;
    private TextView status, loadMore;
    private final ArrayList<JSONObject> people=new ArrayList<>();
    private int offset=0;
    private boolean loading=false,hasMore=true;
    private final ExecutorService images=Executors.newFixedThreadPool(3);

    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(build());load(true);}

    private View build(){
        LinearLayout root=col();root.setBackgroundColor(BG);root.setPadding(dp(10),dp(8),dp(10),dp(14));
        root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(dp(10),Math.max(dp(8),insets.getSystemWindowInsetTop()+dp(4)),dp(10),dp(14));return insets;});
        LinearLayout head=row();Button back=new Button(this);back.setText("‹");back.setTextSize(28);back.setTextColor(DARK);back.setBackgroundColor(Color.TRANSPARENT);back.setOnClickListener(v->finish());head.addView(back,lp(dp(48),dp(48)));
        LinearLayout titles=col();titles.addView(txt("New People",DARK,18,true),lp(-1,dp(26)));titles.addView(txt("Latest MY SHOP users • Add Friend or Message",MUTED,9,false),lp(-1,dp(20)));head.addView(titles,weight(1,dp(48)));
        TextView requests=chip("Requests",PURPLE);requests.setOnClickListener(v->startActivity(new Intent(this,FriendRequestsActivity.class)));head.addView(requests,lp(dp(78),dp(36)));root.addView(head,lp(-1,dp(52)));
        status=txt("Loading people…",MUTED,10,false);status.setGravity(Gravity.CENTER_VERTICAL);root.addView(status,lp(-1,dp(30)));
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setVerticalScrollBarEnabled(false);list=col();sv.addView(list,new ScrollView.LayoutParams(-1,-2));root.addView(sv,weight(1,0));
        loadMore=chip("Load more",BLUE);loadMore.setGravity(Gravity.CENTER);loadMore.setOnClickListener(v->load(false));root.addView(loadMore,lp(-1,dp(44)));root.post(root::requestApplyInsets);return root;
    }

    private void load(boolean reset){
        if(loading||(!hasMore&&!reset))return;String token=SessionManager.getToken(this);if(token==null||token.isEmpty()){status.setText("Please login first");return;}loading=true;
        if(reset){offset=0;hasMore=true;people.clear();list.removeAllViews();renderCached();}
        status.setText(people.isEmpty()?"Loading people…":"Updating…");loadMore.setEnabled(false);
        final int requestOffset=offset;
        BackendClient.newPeople(token,50,requestOffset,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                JSONArray a=d.optJSONArray("people");if(reset){people.clear();list.removeAllViews();getSharedPreferences("myshop_people",MODE_PRIVATE).edit().putString("all_first",d.toString()).apply();}
                if(a!=null)for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p!=null&&!SessionManager.getUserId(NewPeopleActivity.this).equals(p.optString("userId",""))&&!contains(p.optString("userId","")))people.add(p);}
                offset=d.optInt("nextOffset",requestOffset+(a==null?0:a.length()));hasMore=d.optBoolean("hasMore",false);render();loading=false;status.setText(people.isEmpty()?"No new people right now":people.size()+" people");loadMore.setEnabled(hasMore);loadMore.setVisibility(hasMore?View.VISIBLE:View.GONE);
            });}
            public void onError(String m){runOnUiThread(()->{loading=false;status.setText(people.isEmpty()?"Unable to load people":"Saved people shown • retry when online");loadMore.setEnabled(true);});}
        });
    }

    private void renderCached(){try{String raw=getSharedPreferences("myshop_people",MODE_PRIVATE).getString("all_first","");if(raw.isEmpty())return;JSONObject d=new JSONObject(raw);JSONArray a=d.optJSONArray("people");if(a!=null)for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p!=null&&!SessionManager.getUserId(this).equals(p.optString("userId","")))people.add(p);}render();}catch(Exception ignored){}}
    private boolean contains(String id){for(JSONObject p:people)if(id.equals(p.optString("userId","")))return true;return false;}

    private void render(){list.removeAllViews();for(JSONObject p:people){list.addView(personCard(p),margin(lp(-1,dp(82)),0,0,0,dp(7)));}}
    private View personCard(JSONObject p){
        LinearLayout c=row();c.setPadding(dp(8),dp(7),dp(8),dp(7));c.setBackground(round(Color.WHITE,Color.rgb(228,230,238),14));c.setElevation(dp(1));c.setOnClickListener(v->{Intent q=new Intent(this,UserProfileActivity.class);q.putExtra("userId",p.optString("userId",""));startActivity(q);});
        ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setClipToOutline(true);av.setBackground(round(Color.rgb(240,242,248),Color.TRANSPARENT,28));String au=p.optString("avatarUrl","");if(!au.isEmpty())loadImage(av,au);c.addView(av,lp(dp(54),dp(54)));
        LinearLayout info=col();info.setPadding(dp(9),0,dp(6),0);TextView n=txt(p.optString("name","New Member"),DARK,11.5f,true);n.setSingleLine(true);n.setEllipsize(TextUtils.TruncateAt.END);info.addView(n,lp(-1,dp(28)));info.addView(txt("ID "+p.optString("userId","")+" • New user",MUTED,8.5f,false),lp(-1,dp(22)));c.addView(info,weight(1,dp(58)));
        LinearLayout actions=col();TextView msg=chip("Message",PURPLE);msg.setOnClickListener(v->{Intent q=new Intent(this,ChatActivity.class);q.putExtra("userId",p.optString("userId",""));q.putExtra("name",p.optString("name","MY SHOP User"));startActivity(q);});actions.addView(msg,lp(dp(82),dp(30)));
        String state=p.optString("state","NONE");TextView add=chip("REQUESTED".equals(state)?"Requested":"INCOMING".equals(state)?"Respond":"Add Friend","REQUESTED".equals(state)?MUTED:BLUE);if("REQUESTED".equals(state)){add.setEnabled(false);add.setAlpha(.7f);}else if("INCOMING".equals(state)){add.setOnClickListener(v->startActivity(new Intent(this,FriendRequestsActivity.class)));}else add.setOnClickListener(v->request(p,add));actions.addView(add,margin(lp(dp(82),dp(30)),0,dp(4),0,0));c.addView(actions,lp(dp(84),dp(64)));return c;
    }
    private void request(JSONObject p,TextView b){String id=p.optString("userId","");if(id.isEmpty())return;b.setEnabled(false);BackendClient.sendFriendRequest(SessionManager.getToken(this),id,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{try{p.put("state","REQUESTED");}catch(Exception ignored){}b.setText("Requested");b.setBackground(round(MUTED,MUTED,12));b.setAlpha(.7f);});}public void onError(String m){runOnUiThread(()->{if(m!=null&&m.toLowerCase().contains("pending")){b.setText("Requested");b.setAlpha(.7f);}else{b.setEnabled(true);Toast.makeText(NewPeopleActivity.this,m,Toast.LENGTH_SHORT).show();}});}});}

    private void loadImage(ImageView v,String url){images.execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(6000);c.setReadTimeout(8000);try(InputStream in=c.getInputStream()){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null)runOnUiThread(()->v.setImageBitmap(b));}c.disconnect();}catch(Exception ignored){}});}
    @Override protected void onDestroy(){images.shutdownNow();super.onDestroy();}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private TextView txt(String s,int c,float z,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}private TextView chip(String s,int c){TextView t=txt(s,Color.WHITE,9,true);t.setGravity(Gravity.CENTER);t.setBackground(round(c,c,12));return t;}private GradientDrawable round(int f,int st,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(st!=Color.TRANSPARENT)g.setStroke(dp(1),st);return g;}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}private LinearLayout.LayoutParams margin(LinearLayout.LayoutParams p,int l,int t,int r,int b){p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
