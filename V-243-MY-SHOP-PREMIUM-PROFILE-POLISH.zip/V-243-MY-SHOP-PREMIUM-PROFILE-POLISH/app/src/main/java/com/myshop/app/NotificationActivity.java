package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** V-239 cached social notification inbox with per-item read state and destination routing. */
public class NotificationActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(248,249,253), BLUE=Color.rgb(46,47,190), NAVY=Color.rgb(18,32,75), DARK=Color.rgb(35,38,52), MUTED=Color.rgb(105,110,125), PURPLE=Color.rgb(91,38,214);
    private LinearLayout list; private TextView status; private final Handler handler=new Handler(); private boolean hasContent=false; private final ExecutorService images=Executors.newFixedThreadPool(3);
    private final Runnable refreshPoll=new Runnable(){@Override public void run(){load(false);handler.postDelayed(this,12000);}};
    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(build());load(true);}

    private View build(){
        LinearLayout root=col();root.setBackgroundColor(BG);root.setPadding(dp(10),dp(8),dp(10),dp(14));
        root.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(dp(10),Math.max(dp(8),i.getSystemWindowInsetTop()+dp(4)),dp(10),dp(14));return i;});
        LinearLayout head=row();Button back=button("‹",NAVY,28,true);back.setOnClickListener(v->finish());head.addView(back,lp(dp(42),dp(46)));
        TextView title=txt("Notifications",NAVY,17,true);title.setGravity(Gravity.CENTER_VERTICAL);head.addView(title,weight(1,dp(46)));
        TextView requests=chip("Requests",PURPLE);requests.setOnClickListener(v->startActivity(new Intent(this,FriendRequestsActivity.class)));head.addView(requests,lp(dp(76),dp(34)));
        TextView mark=chip("Mark seen",BLUE);mark.setOnClickListener(v->markRead());head.addView(mark,margin(lp(dp(82),dp(34)),dp(5),0,0,0));root.addView(head,lp(-1,dp(50)));
        status=txt("Loading latest…",MUTED,9.5f,false);status.setGravity(Gravity.CENTER_VERTICAL);status.setPadding(dp(4),0,0,0);status.setOnClickListener(v->load(false));root.addView(status,lp(-1,dp(28)));
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setVerticalScrollBarEnabled(false);list=col();sv.addView(list,new ScrollView.LayoutParams(-1,-2));root.addView(sv,new LinearLayout.LayoutParams(-1,0,1f));root.post(root::requestApplyInsets);return root;
    }

    private void load(boolean first){
        String token=SessionManager.getToken(this);if(token==null||token.isEmpty()){empty("Login to see notifications");return;}
        if(first)renderCached(); if(hasContent)status.setText("Updating in background…"); else status.setText("Loading latest…");
        BackendClient.notifications(token,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){getSharedPreferences("myshop_notifications",MODE_PRIVATE).edit().putString("last_payload",d.toString()).apply();runOnUiThread(()->{JSONArray a=d.optJSONArray("notifications");if(a!=null&&a.length()>0)render(a);else empty("No notifications yet");status.setText(d.optInt("unreadCount",0)>0?d.optInt("unreadCount",0)+" unread":"All caught up");});}
            public void onError(String m){runOnUiThread(()->status.setText(hasContent?"Saved notifications shown • tap to retry":"Unable to sync • tap to retry"));}
        });
    }
    private boolean renderCached(){try{String raw=getSharedPreferences("myshop_notifications",MODE_PRIVATE).getString("last_payload","");if(raw.isEmpty())return false;JSONArray a=new JSONObject(raw).optJSONArray("notifications");if(a==null||a.length()==0)return false;render(a);status.setText("Saved notifications • updating…");return true;}catch(Exception e){return false;}}

    private void render(JSONArray a){
        list.removeAllViews(); hasContent=a!=null&&a.length()>0; if(!hasContent){empty("No notifications yet");return;}
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i); if(o==null)continue; boolean unread=o.optInt("isRead",0)==0;
            LinearLayout card=row(); card.setGravity(Gravity.TOP); card.setPadding(dp(10),dp(10),dp(9),dp(10)); card.setBackground(round(unread?Color.rgb(232,242,255):Color.WHITE,Color.rgb(230,233,240),12));
            ImageView av=new ImageView(this); av.setImageResource(R.drawable.myshop_profile_avatar); av.setScaleType(ImageView.ScaleType.CENTER_CROP); av.setClipToOutline(true); av.setBackground(round(Color.rgb(238,241,248),Color.TRANSPARENT,29)); card.addView(av,lp(dp(58),dp(58)));
            String actor=o.optString("actorAvatarUrl",""); if(!actor.isEmpty())loadImage(av,actor);
            LinearLayout info=col(); info.setPadding(dp(10),0,dp(5),0);
            TextView title=txt(o.optString("title","MY SHOP"),DARK,12.8f,true); title.setMaxLines(2); info.addView(title,lp(-1,-2));
            TextView msg=txt(o.optString("message",""),Color.rgb(48,53,70),11.5f,false); msg.setMaxLines(4); msg.setPadding(0,dp(2),0,dp(3)); info.addView(msg,lp(-1,-2));
            LinearLayout meta=row(); TextView tm=txt(o.optString("createdAt",""),unread?BLUE:MUTED,9f,unread); meta.addView(tm,weight(1,dp(21))); if(unread){TextView dot=txt("●",BLUE,10,true);dot.setGravity(Gravity.CENTER);meta.addView(dot,lp(dp(20),dp(21)));} info.addView(meta,lp(-1,dp(22)));
            card.addView(info,new LinearLayout.LayoutParams(0,-2,1f));
            String thumb=o.optString("thumbnailUrl",""); if(!thumb.isEmpty()){ImageView th=new ImageView(this);th.setScaleType(ImageView.ScaleType.CENTER_CROP);th.setClipToOutline(true);th.setBackground(round(Color.rgb(239,241,247),Color.TRANSPARENT,9));loadImage(th,thumb);card.addView(th,lp(dp(54),dp(54)));}
            card.setOnClickListener(v->openNotification(o)); list.addView(card,lp(-1,-2)); if(i<a.length()-1)list.addView(new Space(this),lp(1,dp(4)));
        }
    }
    private void loadImage(ImageView v,String url){images.execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(5000);c.setReadTimeout(7000);try(InputStream in=c.getInputStream()){android.graphics.Bitmap bm=android.graphics.BitmapFactory.decodeStream(in);if(bm!=null)runOnUiThread(()->v.setImageBitmap(bm));}c.disconnect();}catch(Exception ignored){}});}

    private void openNotification(JSONObject o){
        String token=SessionManager.getToken(this);long id=o.optLong("id",0);if(id>0)BackendClient.markNotificationRead(token,id,new BackendClient.Callback(){public void onSuccess(JSONObject d){}public void onError(String m){}});
        String type=o.optString("type","").toUpperCase(),actor=o.optString("actorUserId",""),target=o.optString("targetId","");Intent i;
        if("MESSAGE".equals(type)&&!actor.isEmpty()){i=new Intent(this,ChatActivity.class);i.putExtra("userId",actor);i.putExtra("name","MY SHOP User");}
        else if(type.startsWith("FRIEND")){i=new Intent(this,FriendRequestsActivity.class);}
        else if("LIKE".equals(type)||"COMMENT".equals(type)){i=new Intent(this,MainActivity.class);try{i.putExtra("focusPostId",Long.parseLong(target));}catch(Exception ignored){}}
        else{i=new Intent(this,MainActivity.class);}startActivity(i);load(false);
    }
    private void markRead(){String token=SessionManager.getToken(this);if(token==null||token.isEmpty())return;BackendClient.markNotificationsRead(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{status.setText("All seen");load(false);});}public void onError(String m){runOnUiThread(()->status.setText("Could not mark seen • tap to retry"));}});}
    private void empty(String s){list.removeAllViews();hasContent=false;TextView t=txt(s,MUTED,11,false);t.setGravity(Gravity.CENTER);list.addView(t,lp(-1,dp(130)));}
    @Override protected void onResume(){super.onResume();load(false);handler.removeCallbacks(refreshPoll);handler.postDelayed(refreshPoll,12000);}@Override protected void onPause(){super.onPause();handler.removeCallbacks(refreshPoll);}@Override protected void onDestroy(){images.shutdownNow();super.onDestroy();}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private TextView txt(String s,int c,float z,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}private Button button(String s,int c,float z,boolean b){Button v=new Button(this);v.setText(s);v.setTextColor(c);v.setTextSize(z);if(b)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setBackgroundColor(Color.TRANSPARENT);return v;}private TextView chip(String s,int c){TextView t=txt(s,Color.WHITE,9,true);t.setGravity(Gravity.CENTER);t.setBackground(round(c,c,12));return t;}private GradientDrawable round(int fill,int stroke,int r){GradientDrawable g=new GradientDrawable();g.setColor(fill);if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);g.setCornerRadius(dp(r));return g;}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}private LinearLayout.LayoutParams margin(LinearLayout.LayoutParams p,int l,int t,int r,int b){p.setMargins(l,t,r,b);return p;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
