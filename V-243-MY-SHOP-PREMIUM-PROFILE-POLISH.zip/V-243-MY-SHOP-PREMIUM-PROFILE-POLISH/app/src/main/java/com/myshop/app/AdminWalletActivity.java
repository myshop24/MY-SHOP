package com.myshop.app;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;
import org.json.JSONObject;

/** V-242 admin-only manual Coin/Gold/Badge/Membership grant board. */
public class AdminWalletActivity extends androidx.appcompat.app.AppCompatActivity {
  private EditText userId,units,days,note; private Spinner type,code;
  @Override protected void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)){finish();return;}build();}
  private void build(){
    ScrollView sv=new ScrollView(this); LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(16),dp(18),dp(16),dp(28));r.setBackgroundColor(Color.rgb(246,248,252));
    TextView h=t("Admin Wallet • Badge Grant",22,true);r.addView(h); TextView sub=t("ব্যক্তিগতভাবে টাকা নিলে Payment Method ছাড়াই User ID-তে Coin, Gold Coin বা Badge/Membership দিতে পারবেন। প্রতিটি Grant backend audit history-তে থাকবে।",12,false);sub.setPadding(0,dp(8),0,dp(14));r.addView(sub);
    userId=e("4-digit User ID");userId.setInputType(InputType.TYPE_CLASS_NUMBER);r.addView(userId,lp(-1,dp(52)));
    type=new Spinner(this);type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"COIN","GOLD","BADGE"}));r.addView(type,lp(-1,dp(52)));
    code=new Spinner(this);code.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"COIN","GOLD","BLUE","VIP","VVIP","ROYAL"}));r.addView(code,lp(-1,dp(52)));
    units=e("Amount / Units (badge = 1)");units.setInputType(InputType.TYPE_CLASS_NUMBER);units.setText("1");r.addView(units,lp(-1,dp(52)));
    days=e("Membership duration in days (0 = no expiry)");days.setInputType(InputType.TYPE_CLASS_NUMBER);days.setText("0");r.addView(days,lp(-1,dp(52)));
    note=e("Optional note / personal payment reference");r.addView(note,lp(-1,dp(64)));
    Button grant=new Button(this);grant.setText("CONFIRM MANUAL GRANT");grant.setTextColor(Color.WHITE);grant.setBackgroundColor(Color.rgb(83,32,180));grant.setOnClickListener(v->grant());r.addView(grant,lp(-1,dp(54)));
    Button back=new Button(this);back.setText("Back");back.setOnClickListener(v->finish());r.addView(back,lp(-1,dp(50)));sv.addView(r);setContentView(sv);
  }
  private void grant(){String uid=userId.getText().toString().trim();int u=num(units.getText().toString());int d=num(days.getText().toString());String ty=String.valueOf(type.getSelectedItem());String c=String.valueOf(code.getSelectedItem());if(uid.length()!=4||u<=0){Toast.makeText(this,"Valid User ID and amount required.",Toast.LENGTH_SHORT).show();return;}new AlertDialog.Builder(this).setTitle("Confirm Admin Grant").setMessage("User ID: "+uid+"\nType: "+ty+"\nItem: "+c+"\nUnits: "+u+"\nDays: "+d+"\n\nThis action is audited on the backend.").setNegativeButton("Cancel",null).setPositiveButton("Grant",(x,w)->BackendClient.adminWalletGrant(SessionManager.getToken(this),uid,ty,c,u,d,note.getText().toString(),new BackendClient.Callback(){public void onSuccess(JSONObject o){Toast.makeText(AdminWalletActivity.this,"Grant completed.",Toast.LENGTH_LONG).show();}public void onError(String m){Toast.makeText(AdminWalletActivity.this,m,Toast.LENGTH_LONG).show();}})).show();}
  private int num(String s){try{return Integer.parseInt(s.trim());}catch(Exception e){return 0;}} private EditText e(String h){EditText x=new EditText(this);x.setHint(h);x.setPadding(dp(10),0,dp(10),0);return x;} private TextView t(String s,int z,boolean b){TextView x=new TextView(this);x.setText(s);x.setTextSize(z);x.setTextColor(Color.rgb(22,28,55));if(b)x.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return x;}private LinearLayout.LayoutParams lp(int w,int h){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.bottomMargin=dp(8);return p;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
