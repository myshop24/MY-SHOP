package com.myshop.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** V-238 lightweight public profile with Message + friend state. */
public class UserProfileActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(7,9,20),DARK=Color.WHITE,MUTED=Color.rgb(161,171,201),BLUE=Color.rgb(58,96,230),PURPLE=Color.rgb(126,55,232),GREEN=Color.rgb(20,153,92);
    private String userId="",name="MY SHOP User",avatarUrl=""; private LinearLayout root; private ImageView avatar; private TextView title,bio,state,badge; private Button friend;
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    @Override protected void onCreate(Bundle b){super.onCreate(b);userId=getIntent().getStringExtra("userId");if(userId==null)userId="";setContentView(build());load();}
    private android.view.View build(){root=col();root.setBackgroundColor(BG);root.setPadding(dp(14),dp(10),dp(14),dp(20));root.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(dp(14),Math.max(dp(10),i.getSystemWindowInsetTop()+dp(5)),dp(14),dp(20));return i;});LinearLayout h=row();Button back=btn("‹",Color.TRANSPARENT,DARK);back.setTextSize(28);back.setOnClickListener(v->finish());h.addView(back,lp(dp(48),dp(48)));TextView ht=txt("Profile",DARK,18,true);ht.setGravity(Gravity.CENTER_VERTICAL);h.addView(ht,weight(1,dp(48)));root.addView(h,lp(-1,dp(52)));avatar=new ImageView(this);avatar.setImageResource(R.drawable.myshop_profile_avatar);avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);avatar.setPadding(dp(4),dp(4),dp(4),dp(4));avatar.setBackground(round(Color.rgb(118,67,224),Color.rgb(255,208,98),60));avatar.setClipToOutline(true);LinearLayout ac=row();ac.setGravity(Gravity.CENTER);ac.addView(avatar,lp(dp(112),dp(112)));root.addView(ac,lp(-1,dp(130)));LinearLayout nr=row();nr.setGravity(Gravity.CENTER);title=txt("Loading profile…",DARK,21,true);nr.addView(title,lp(-2,dp(38)));badge=txt("",Color.WHITE,9,true);badge.setGravity(Gravity.CENTER);badge.setVisibility(android.view.View.GONE);nr.addView(badge,margin(lp(-2,dp(26)),8,0,0,0));root.addView(nr,lp(-1,dp(40)));state=txt("MY SHOP ID  •  "+userId,MUTED,10,true);state.setGravity(Gravity.CENTER);root.addView(state,lp(-1,dp(26)));bio=txt("",DARK,11,false);bio.setGravity(Gravity.CENTER);bio.setPadding(dp(14),dp(12),dp(14),dp(12));bio.setBackground(round(Color.rgb(18,23,42),Color.rgb(40,50,82),16));root.addView(bio,margin(lp(-1,-2),0,8,0,0));LinearLayout a=row();Button message=btn("Message",PURPLE,Color.WHITE);message.setOnClickListener(v->openChat());a.addView(message,weight(1,dp(46)));Space sp=new Space(this);a.addView(sp,lp(dp(8),1));friend=btn("Add Friend",BLUE,Color.WHITE);friend.setOnClickListener(v->friendAction());a.addView(friend,weight(1,dp(46)));root.addView(a,margin(lp(-1,dp(46)),0,dp(16),0,0));root.post(root::requestApplyInsets);return root;}
    private void load(){if(userId.isEmpty()){title.setText("User unavailable");return;}BackendClient.userProfile(SessionManager.getToken(this),userId,new BackendClient.Callback(){public void onSuccess(JSONObject d){JSONObject p=d.optJSONObject("profile");if(p==null)return;name=p.optString("name","MY SHOP User");avatarUrl=p.optString("avatarUrl","");runOnUiThread(()->{title.setText(name);String st=p.optString("state","NONE");state.setText("MY SHOP ID  •  "+userId+("FRIEND".equals(st)?"  •  Friend":"REQUESTED".equals(st)?"  •  Requested":"INCOMING".equals(st)?"  •  Sent you a request":""));String bioText=p.optString("bio","").trim(); org.json.JSONArray ba=p.optJSONArray("badges"); String badgeCode=""; if(ba!=null&&ba.length()>0){JSONObject bb=ba.optJSONObject(0); if(bb!=null)badgeCode=bb.optString("badge_code","MEMBER").trim().toUpperCase();} applyBadge(badgeCode); bio.setText(bioText);if("SELF".equals(st)){friend.setVisibility(android.view.View.GONE);}else if("FRIEND".equals(st)){friend.setText("Friends");friend.setEnabled(false);friend.setBackground(round(GREEN,GREEN,13));}else if("REQUESTED".equals(st)){friend.setText("Requested");friend.setEnabled(false);friend.setBackground(round(MUTED,MUTED,13));}else if("INCOMING".equals(st)){friend.setText("Respond");friend.setOnClickListener(v->startActivity(new Intent(UserProfileActivity.this,FriendRequestsActivity.class)));}if(!avatarUrl.isEmpty())loadImage();});}public void onError(String m){runOnUiThread(()->title.setText("Profile unavailable"));}});}
    private void applyBadge(String code){
        if(code==null||code.isEmpty()){badge.setVisibility(android.view.View.GONE);return;}
        int bg=Color.rgb(65,77,116),fg=Color.WHITE; String label=code;
        if("BLUE".equals(code)){bg=Color.rgb(55,120,242);label="BLUE ✓";}
        else if("VIP".equals(code)){bg=Color.rgb(255,190,72);fg=Color.rgb(45,28,0);}
        else if("VVIP".equals(code)){bg=Color.rgb(181,74,238);}
        else if("ROYAL".equals(code)){bg=Color.rgb(215,157,28);fg=Color.rgb(45,28,0);}
        badge.setText(label);badge.setTextColor(fg);badge.setBackground(round(bg,Color.argb(150,255,255,255),13));badge.setPadding(dp(9),0,dp(9),0);badge.setVisibility(android.view.View.VISIBLE);
    }
    private void friendAction(){friend.setEnabled(false);BackendClient.sendFriendRequest(SessionManager.getToken(this),userId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{friend.setText("Requested");friend.setBackground(round(MUTED,MUTED,13));});}public void onError(String m){runOnUiThread(()->{friend.setEnabled(true);Toast.makeText(UserProfileActivity.this,m,Toast.LENGTH_SHORT).show();});}});}
    private void openChat(){if(userId.equals(SessionManager.getUserId(this)))return;Intent q=new Intent(this,ChatActivity.class);q.putExtra("userId",userId);q.putExtra("name",name);q.putExtra("avatarUrl",avatarUrl);startActivity(q);}
    private void loadImage(){final String u=avatarUrl;io.execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(5000);c.setReadTimeout(7000);try(InputStream in=c.getInputStream()){Bitmap bm=BitmapFactory.decodeStream(in);if(bm!=null)runOnUiThread(()->avatar.setImageBitmap(bm));}c.disconnect();}catch(Exception ignored){}});}
    @Override protected void onDestroy(){io.shutdownNow();super.onDestroy();}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private TextView txt(String s,int c,float z,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}private Button btn(String s,int bg,int fg){Button b=new Button(this);b.setText(s);b.setTextColor(fg);b.setTextSize(10);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(bg==Color.TRANSPARENT?null:round(bg,bg,13));return b;}private GradientDrawable round(int f,int st,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(st!=Color.TRANSPARENT)g.setStroke(dp(1),st);return g;}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}private LinearLayout.LayoutParams margin(LinearLayout.LayoutParams p,int l,int t,int r,int b){p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
