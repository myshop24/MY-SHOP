# V-235 MY SHOP — Compact Live + New People

- Android: versionCode 235 / versionName 2.9.235.
- SOURCE_BUILD_ID: MY SHOP V-235.
- Live Streaming height reduced from 168dp to 148dp without reducing its text or live-row height.
- Advertisement slider remains 118dp and fills the available screen width.
- New People appears between advertisements and MY FEED, showing four profiles at once with swipe and one-by-one automatic scrolling.
- Add Friend and See All are connected to authenticated Worker endpoints.
- Suggestions exclude self, accepted friends, pending requests and blocked users, and hide when empty.
