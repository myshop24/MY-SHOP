from pathlib import Path
r=Path(__file__).resolve().parent
main=(r/'app/src/main/java/com/myshop/app/MainActivity.java').read_text()
notif=(r/'app/src/main/java/com/myshop/app/NotificationActivity.java').read_text()
inbox=(r/'app/src/main/java/com/myshop/app/InboxActivity.java').read_text()
chat=(r/'app/src/main/java/com/myshop/app/ChatActivity.java').read_text()
menu=(r/'app/src/main/java/com/myshop/app/UserMenuActivity.java').read_text()
worker=(r/'backend/worker/src/index.js').read_text()
gradle=(r/'app/build.gradle').read_text()
checks={
 'source id':(r/'SOURCE_BUILD_ID.txt').read_text().strip()=='MY SHOP V-239',
 'android version':'versionCode 239' in gradle and "versionName '2.9.239'" in gradle,
 'worker version':worker.count("version:'2.9.239',build:'V-239'")>=2,
 'live premium':'Explore Live Rooms' in main and 'Live Your Moment' in main and 'weight(40' in main and 'weight(60' in main,
 'no duplicate live nav':'R.drawable.nav_live' not in main and 'R.drawable.nav_video' in main,
 'inline timeline video':'VideoView vv' in main and 'PLAY VIDEO' not in main,
 'notification visible':'new LinearLayout.LayoutParams(-1,0,1f)' in notif and 'actorAvatarUrl' in notif,
 'messages visible':'new LinearLayout.LayoutParams(-1,0,1f)' in inbox and 'new LinearLayout.LayoutParams(-1,0,1f)' in chat,
 'more icons enlarged':'dp(68),dp(68)' in main,
 'drawer icons enlarged':'dp(62),dp(62)' in menu,
 'worker notification media':'actorAvatarUrl' in worker and 'thumbnailUrl' in worker and 'LEFT JOIN myshop_posts' in worker,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL'),k)
if not all(checks.values()): raise SystemExit(1)
print('V-239 SOURCE CHECK PASSED')
