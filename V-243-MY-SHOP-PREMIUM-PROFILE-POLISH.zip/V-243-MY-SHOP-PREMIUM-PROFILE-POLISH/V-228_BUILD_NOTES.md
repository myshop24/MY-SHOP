# MY SHOP V-228 — Functional Fix Build Notes

Runtime issues confirmed from V-227 and fixed in source:

1. MORE button routing restored: Admin/user opens the original MORE page with social media, Customer Support and Share App. Admin edit controls stay inside that page.
2. Feature/Support admin panels now show a large, obvious full-width SAVE button.
3. Feature/Support fields are optional: image, icon, caption, link and name may be left blank.
4. Social settings can be saved with a blank URL (inactive) instead of blocking Save.
5. Main feature buttons reset to the correct built-in icon unless a custom image/icon is explicitly configured.
6. Banner R2 upload bug fixed: undefined `mime` variable replaced by the detected `bannerType`.
7. Notification bell, badge and whole bell area open the notification inbox; latest notification payload is cached and used as a fallback if refresh temporarily fails.
8. VersionCode 228 / VersionName 2.9.228 / SOURCE_BUILD_ID V-228.
9. Permanent signing key is untouched.

Build Success is not Function PASS. Runtime verification is required after install.
