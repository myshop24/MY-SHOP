# V-232 MY SHOP — SOURCE_BUILD_ID Exact-Match Build Fix

Base: V-231-MY-SHOP-LATEST-7-FIX-FINAL-SAFE

## Confirmed GitHub Actions failure
The repository master workflow selected V-231 correctly, then stopped at **Extract and verify exact source identity** because the source package contained:

`SOURCE_BUILD_ID.txt = V-231`

while the permanent workflow requires the exact format:

`MY SHOP V-<selected version>`

So V-231 failed before Android/Cloudflare build steps with a SOURCE_BUILD_ID mismatch.

## V-232 fix
- SOURCE_BUILD_ID.txt = `MY SHOP V-232`
- Android versionCode = `232`
- Android versionName = `2.9.232`
- Worker runtime version/build markers = `2.9.232` / `V-232`
- Release notification marker = `release_notice_v232`
- Existing V-231 UI/features are preserved unchanged.
- Repository master workflow YAML is not modified.

## Safety preservation
- Cloudflare D1/R2 bindings unchanged.
- Existing D1 migrations unchanged.
- Permanent User ID/session/account-store files unchanged.
- No destructive schema or user-data operation added.
