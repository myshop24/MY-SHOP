# MY SHOP V-241 BUILD NOTES

Source base: V-240-MY-SHOP-BUILD-COMPILE-FIX

Fixes in V-241:
1. Home Feed video playback: Cloudflare R2 media endpoint now supports HTTP byte-range requests (206 / Content-Range / Accept-Ranges), improving Android progressive video playback and first-frame loading. Home VideoView also has retry/error state and manual tap enables audio.
2. Friend request acceptance: Friend schema migration now safely adds missing legacy columns, Accept is idempotent, update success is verified, and declined rows can be re-requested later.
3. Feed comments: GET /v1/feed/comments added. Tapping Comment now opens the existing comment history and lets the user post a new comment without closing the dialog.
4. Feed photo save: tapping a Home Feed photo opens a full-screen viewer; SAVE PHOTO appears only there and saves to Pictures/MY SHOP on modern Android.
5. Live UI: Go Live reduced to 34% width, Join Live increased to 66%, Join text enlarged, and both buttons now have stronger continuous smooth pulse animations.
6. More menu clarity: replaced blurry wide banner assets with new 256x256 high-resolution icon assets; icons and labels are larger and sharper.
7. Left drawer clarity: same high-resolution icon system applied; menu rows and labels are larger/bolder while preserving navigation behavior.

Version locks:
- Android versionCode: 241
- Android versionName: 2.9.241
- Worker health/build: V-241 / 2.9.241
- SOURCE_BUILD_ID: MY SHOP V-241

Validation performed before packaging:
- `node --check backend/worker/src/index.js` PASS
- Java source brace/string sanity checks PASS
- New icon assets verified as valid PNG files
- V-number/version markers checked
