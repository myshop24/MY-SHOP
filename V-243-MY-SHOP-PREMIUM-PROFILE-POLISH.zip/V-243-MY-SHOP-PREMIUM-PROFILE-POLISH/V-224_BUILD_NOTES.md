# MY SHOP V-224 — FULL FIX / AUTO BUILD SAFE

- SOURCE_BUILD_ID: MY SHOP V-224
- Android versionCode: 224
- Android versionName: 2.9.224
- Worker health marker: V-224 / 2.9.224
- Preserves permanent signing identity; no keystore regeneration.
- Contains Android app + Cloudflare Worker source.
- Includes the full deployment-capable workflow candidate inside `.github/workflows/my-shop-apk.yml`.
- IMPORTANT: repository-root workflow controls GitHub artifact contents and Worker deployment. Source ZIP cannot replace a repository-root workflow by itself.
