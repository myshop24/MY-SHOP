# MY SHOP V-242

Profile remains in the existing Account/Profile location. Added Coin + Gold Coin wallet UI, Blue/VIP/VVIP/Royal membership request UI, bKash/Nagad/Bangla QR purchase request flow, Gold withdrawal request flow, backend-authoritative badge display, and Admin-only manual Coin/Gold/Badge grant with audit history. Existing V-241 Feed/video/friend/comment/photo/live/menu fixes are preserved.

Security: purchase requests are PENDING until backend/admin verification; balances and badges are never trusted from the APK. Admin manual grants require authenticated ADMIN role and are audited.
