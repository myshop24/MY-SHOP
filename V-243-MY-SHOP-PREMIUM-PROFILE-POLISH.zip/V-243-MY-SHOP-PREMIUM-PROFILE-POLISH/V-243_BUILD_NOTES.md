# MY SHOP V-243 — Premium Profile Polish

- Profile stays in the same existing MY SHOP location; navigation and V-241/V-242 functionality are preserved.
- Rebuilt the self-profile visual layer with a dark premium gradient hero, rounded avatar ring, polished identity chip, compact social stats, premium wallet cards, membership card, withdrawal card, quick actions and security cards.
- Removed the misleading always-visible VIP label. Free users show no VIP/VVIP/Royal/Blue badge in the title/name area.
- Active backend-assigned/purchased BLUE, VIP, VVIP or ROYAL badges now render automatically beside the profile name and in the header with tier-specific colors.
- Added membership expiry/source display from backend wallet profile data.
- Fixed wallet badge parsing to support the backend D1 field names `badge_code` and `expires_at`.
- Added a soft badge pulse for active premium tiers and preserved secure backend-authoritative balances/badges.
- Friends count now loads from the existing friends API. Followers/Following remain ready for a future follow API.
- Share Profile now includes the MY SHOP display name and User ID.
- Android versionCode 243 / versionName 2.9.243 / Worker V-243 / SOURCE_BUILD_ID MY SHOP V-243.
