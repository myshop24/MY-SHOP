from pathlib import Path
import xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent
read=lambda p:(r/p).read_text(encoding='utf-8')
g=read('app/build.gradle');w=read('backend/worker/src/index.js');m=read('app/src/main/java/com/myshop/app/MainActivity.java');c=read('app/src/main/java/com/myshop/app/BackendClient.java');mft=read('app/src/main/AndroidManifest.xml');wf=read('.github/workflows/my-shop-apk.yml')
checks={'source id':read('SOURCE_BUILD_ID.txt').strip()=='MY SHOP V-236','version':'versionCode 236' in g and "versionName '2.9.236'" in g,'worker':w.count("version:'2.9.236',build:'V-236'")>=2,'release':'release_notice_v236' in w,'workflow':'AUTO-BUILD V-236' in wf,'friend APIs':all(x in w for x in ['/v1/friends/request','/v1/friends/respond',"p==='/v1/friends'"]),'friend UI':'.FriendRequestsActivity' in mft and '/v1/friends/respond' in c,'video UI':'.ShortVideoActivity' in mft and 'ShortVideoActivity.class' in m,'chat icon':'myshop_chat_icon_v236' in m and (r/'app/src/main/res/drawable/myshop_chat_icon_v236.png').is_file(),'old chat unused':'messenger_chat_icon' not in m,'V235 dashboard kept':'dp(148)' in m and 'dp(118)' in m}
ET.parse(r/'app/src/main/AndroidManifest.xml');ET.parse(r/'app/src/main/res/values/themes.xml')
for k,v in checks.items():print('PASS' if v else 'FAIL',k)
raise SystemExit(0 if all(checks.values()) else 1)
