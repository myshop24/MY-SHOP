# V-236 MY SHOP — Social, Video and Original Chat

- Android: versionCode 236 / versionName 2.9.236.
- Full friend-request lifecycle: send, incoming list, Accept, Decline, Friends list and user notifications.
- Approved original chat icon replaces the Messenger-like icon in the dashboard header.
- Vertical short-video screen: one active video, autoplay/loop, swipe up/down, pause/tap, mute, like, share and save feedback.
- Lightweight global screen transitions and press feedback preserve performance.
- Existing V-235 dashboard order, compact Live box, full-width advertisement and New People rules remain intact.
