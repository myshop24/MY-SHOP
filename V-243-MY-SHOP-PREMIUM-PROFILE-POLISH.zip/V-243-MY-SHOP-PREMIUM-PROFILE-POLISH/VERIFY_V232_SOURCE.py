#!/usr/bin/env python3
from pathlib import Path
import hashlib, re, subprocess, sys

ROOT=Path(__file__).resolve().parent
checks=[]

def ok(name, cond):
    checks.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ")+name)

def read(rel):
    return (ROOT/rel).read_text(encoding="utf-8", errors="replace")

main=read("app/src/main/java/com/myshop/app/MainActivity.java")
admin=read("app/src/main/java/com/myshop/app/AdminSectionActivity.java")
backend=read("app/src/main/java/com/myshop/app/BackendClient.java")
notif=read("app/src/main/java/com/myshop/app/NotificationActivity.java")
menu=read("app/src/main/java/com/myshop/app/UserMenuActivity.java")
worker=read("backend/worker/src/index.js")
gradle=read("app/build.gradle")

ok("version V-232", "versionCode 232" in gradle and "versionName '2.9.232'" in gradle)
ok("exact SOURCE_BUILD_ID", read("SOURCE_BUILD_ID.txt").strip()=="MY SHOP V-232")
ok("source version name", read("SOURCE_VERSION_NAME.txt").strip()=="2.9.232")
ok("Worker V-232 runtime markers", worker.count("version:'2.9.232',build:'V-232'")>=2)
ok("header safe-area inset", "getSystemWindowInsetTop()" in main and "topInset+dp(8)" in main)
ok("header tap targets enlarged", 'lp(dp(45),dp(45))' in main and 'lp(dp(44),dp(48))' in main)
ok("Messenger chat asset bundled", (ROOT/"app/src/main/res/drawable/messenger_chat_icon.png").exists() and "R.drawable.messenger_chat_icon" in main)
ok("clean animated headline strip", 'text("📣"' in main and 'ObjectAnimator.ofFloat(megaphone' in main and 'Shop Now' not in main and 'Breaking News:' not in main and 'text("🔥"' not in main)
ok("headline admin opens direct editor", 'new Intent(this,AdminSectionActivity.class)' in main and 'i.putExtra("section","dashboard")' in main)
ok("headline edit/delete/save/size controls", "EDIT / SAVE" in admin and "DELETE" in admin and "changeNewsSize(-0.5f)" in admin and "changeNewsSize(0.5f)" in admin)
ok("headline text size server-backed", "breakingNewsTextSize" in backend and "breaking_news_text_size" in worker and "ensureColumn(env,'dashboard_config'" in worker)
ok("MY FEED natural full-page scrolling", "one natural full-page scroll" in main and "page.addView(feedComposerSection()" in main and "page.addView(feedList" in main and "locked.post" not in main)
ok("More shortcuts enlarged", "dp(94)" in main and "lp(dp(54),dp(54))" in main and "8.8f" in main)
ok("Profile drawer enlarged", "lp(dp(48),dp(48))" in menu and "txt(label,13" in menu and "lp(-1,dp(58))" in menu)
ok("bottom nav distinct colors", "Color.rgb(245,139,0)" in main and "Color.rgb(235,36,168)" in main and "Color.rgb(0,154,205)" in main and "Color.rgb(113,38,220)" in main)
ok("Like notification to post owner", "createUserNotification(env,post.user_id,'❤️ New Like'" in worker)
ok("Comment notification to post owner", "createUserNotification(env,post.user_id,'💬 New Comment'" in worker)
ok("system/release update notification", "ensureReleaseNotification(env)" in worker and "release_notice_v232" in worker and "createBroadcastNotification" in worker)
ok("opening inbox marks seen", "markReadSilently()" in notif and "markNotificationsRead" in notif)
ok("badge hides when zero", "unreadNotificationCount<=0" in main and "notificationBadge.setVisibility(View.GONE)" in main)
ok("approved default palette preserved", "Color.rgb(248,249,253)" in main and "Color.rgb(46,47,190)" in main and "Color.rgb(91,38,214)" in main and "Color.rgb(235,36,168)" in main)

manifest=ROOT/"V-232_PROTECTED_INTEGRITY.sha256"
protected_ok=True
for line in manifest.read_text().splitlines():
    if not line.strip(): continue
    expected, rel=line.split("  ",1)
    p=ROOT/rel
    actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else ""
    if actual!=expected:
        protected_ok=False
        print("PROTECTED MISMATCH",rel)
ok("D1/R2 + permanent ID protected files integrity", protected_ok)

wrangler=read("backend/worker/wrangler.toml")
ok("D1 binding still present", "[[d1_databases]]" in wrangler and "binding = \"DB\"" in wrangler)
ok("R2 binding still present", "[[r2_buckets]]" in wrangler and "binding = \"MEDIA\"" in wrangler)

# Basic delimiter balance on changed Java files.
def balanced(s):
    pairs={')':'(',']':'[','}':'{'}
    stack=[]
    in_str=None; esc=False; line_comment=False; block=False
    i=0
    while i<len(s):
        ch=s[i]; nx=s[i+1] if i+1<len(s) else ''
        if line_comment:
            if ch=='\n': line_comment=False
            i+=1; continue
        if block:
            if ch=='*' and nx=='/': block=False; i+=2; continue
            i+=1; continue
        if in_str:
            if esc: esc=False
            elif ch=='\\': esc=True
            elif ch==in_str: in_str=None
            i+=1; continue
        if ch=='/' and nx=='/': line_comment=True; i+=2; continue
        if ch=='/' and nx=='*': block=True; i+=2; continue
        if ch in ('"',"'"): in_str=ch; i+=1; continue
        if ch in '([{': stack.append(ch)
        elif ch in ')]}':
            if not stack or stack.pop()!=pairs[ch]: return False
        i+=1
    return not stack and not in_str and not block
for rel in [
    "app/src/main/java/com/myshop/app/MainActivity.java",
    "app/src/main/java/com/myshop/app/AdminSectionActivity.java",
    "app/src/main/java/com/myshop/app/BackendClient.java",
    "app/src/main/java/com/myshop/app/NotificationActivity.java",
    "app/src/main/java/com/myshop/app/UserMenuActivity.java",
]:
    ok("Java delimiter balance: "+Path(rel).name, balanced(read(rel)))

try:
    r=subprocess.run(["node","--check",str(ROOT/"backend/worker/src/index.js")],capture_output=True,text=True,timeout=15)
    ok("Worker JavaScript syntax", r.returncode==0)
except Exception:
    ok("Worker JavaScript syntax", False)

passed=sum(v for _,v in checks)
print(f"\nRESULT: {passed}/{len(checks)} checks passed")
if passed!=len(checks):
    print("FAILED:")
    for n,v in checks:
        if not v: print("- "+n)
    sys.exit(1)
