from pathlib import Path
import hashlib, re, subprocess, sys, yaml
R=Path(__file__).resolve().parent
checks=[]
def ck(name, cond): checks.append((name,bool(cond)))
def read(rel): return (R/rel).read_text(encoding='utf-8')

main=read('app/src/main/java/com/myshop/app/MainActivity.java')
menu=read('app/src/main/java/com/myshop/app/UserMenuActivity.java')
adminfolder=read('app/src/main/java/com/myshop/app/AdminFolderActivity.java')
adsadmin=read('app/src/main/java/com/myshop/app/DashboardAdsAdminActivity.java')
feature=read('app/src/main/java/com/myshop/app/FeatureActivity.java')
gallery=read('app/src/main/java/com/myshop/app/GalleryActivity.java')
theme=read('app/src/main/java/com/myshop/app/ThemeConfig.java')
worker=read('backend/worker/src/index.js')
manifest=read('app/src/main/AndroidManifest.xml')
workflow=read('.github/workflows/my-shop-apk.yml')

ck('version lock V-230', read('SOURCE_BUILD_ID.txt').strip()=='MY SHOP V-230' and read('SOURCE_VERSION_NAME.txt').strip()=='2.9.230' and 'versionCode 230' in read('app/build.gradle') and "versionName '2.9.230'" in read('app/build.gradle'))
ck('approved reference image bundled byte-for-byte', (R/'design-reference/V-230_USER_APPROVED_REFERENCE.png').exists() and hashlib.sha256((R/'design-reference/V-230_USER_APPROVED_REFERENCE.png').read_bytes()).hexdigest()=='8d90153f82c81b0c42f893a2a69a307b0d0b2a7a35a7c66436047f22abc58d2a')
ck('approved default palette locked', all(x in theme for x in ['#F8F9FD','#2E2FBE','#5B26D6','#EB24A8']) and 'loadCachedTheme()' in main)
ck('profile opens left drawer', 'av.setOnClickListener(v->startActivity(new Intent(this,UserMenuActivity.class)))' in main)
ck('More-only shortcut content', all(x in main for x in ['"My Shop","Gallery","External Media","Earn & Reward","Categories","Orders","Cart","Social Links","Customer Support","Settings","Share App"']) and 'showMoreQuickActions()' in main and 'root.addView(mainFeatureGrid' not in main and 'locked.addView(mainFeatureGrid' not in main)
ck('Admin Panel hidden from ordinary More list', '"Share App","Admin Panel"' in main and 'new String[]{"My Shop","Gallery","External Media","Earn & Reward","Categories","Orders","Cart","Social Links","Customer Support","Settings","Share App"}' in main)
ck('hero six-banner manager routes to established real hero manager', '"dashboard_banner".equals(featureKey)' in adminfolder and 'BannerAdminActivity.class' in adminfolder)
ck('per-folder admin gate', 'SessionManager.isAdmin(this)' in adminfolder and 'getBooleanExtra("admin_context",false)' in adminfolder and all(x in adminfolder for x in ['＋  ADD','✎  EDIT','⌫  DELETE','✓  SAVE','OPEN 6-BANNER MANAGER']))
ck('every folder ad manager max six', 'new JSONObject[6]' in adsadmin and 'for(int i=0;i<6;i++)' in adsadmin and 'slot>6' in worker and 'box_key' in worker)
ck('generic user folder ads rotate max six', 'folderAds.size()<6' in feature and 'folderAdTick' in feature and 'scheduleNextFolderAd' in feature)
ck('gallery user ads rotate max six', '"gallery".equalsIgnoreCase(x.optString("box_key",""))' in gallery and 'folderAds.size()<6' in gallery and 'folderAdTick' in gallery)
ck('My Feed admin folder routing', 'openAdminFolder("MY FEED","my_feed")' in main and 'FeedModerationActivity.class' in adminfolder)
ck('ordinary drawer has conditional Admin Panel', 'if(SessionManager.isAdmin(this))add(list,R.drawable.feature_earn_selected,"Admin Panel"' in menu)
ck('admin color controls server backed', all(x in worker for x in ['dashboard_bg_color','dashboard_blue_color','dashboard_purple_color','dashboard_pink_color','safeDashboardHex']) and 'Dashboard + colors saved' in read('app/src/main/java/com/myshop/app/AdminSectionActivity.java'))
ck('new admin activity in manifest', 'android:name=".AdminFolderActivity"' in manifest)

expected={
 'backend/worker/wrangler.toml':'8a583df35c161577bf6ec37cc216e29461ffffab24b8d7dcfc2dc938702689bc',
 'app/src/main/java/com/myshop/app/UserIdManager.java':'3b1c8b4929298e3c492337eb4438ae95d3915b2e0cbf4855001fa56a560e78cb',
 'app/src/main/java/com/myshop/app/SessionManager.java':'a30aa4d5afa42685194475800d01350510fa3cd795e42260ac5ee488215f0c4b',
}
for rel,h in expected.items():
    got=hashlib.sha256((R/rel).read_bytes()).hexdigest(); ck('protected unchanged: '+rel,got==h)
wr=read('backend/worker/wrangler.toml')
ck('Cloudflare D1/R2 bindings preserved', all(x in wr for x in ['name = "rapid-bush-62ea"','database_name = "my-shop-db"','database_id = "15b6acd2-0e82-4bd8-95fb-bee6fc08936c"','binding = "MEDIA"','bucket_name = "my-shop-media"']))
ck('no destructive auth SQL', not re.search(r'DROP\s+TABLE|TRUNCATE\s+TABLE|DELETE\s+FROM\s+myshop_auth_users_v108',worker,re.I))
ck('theme schema migration additive', 'ALTER TABLE' in worker and 'ensureColumn' in worker and not re.search(r'ALTER\s+TABLE\s+dashboard_config\s+DROP',worker,re.I))

try:
    yaml.safe_load(workflow); ck('workflow YAML parses',True)
except Exception: ck('workflow YAML parses',False)
try:
    r=subprocess.run(['node','--check',str(R/'backend/worker/src/index.js')],capture_output=True,text=True,timeout=30)
    ck('worker JavaScript syntax',r.returncode==0)
except Exception: ck('worker JavaScript syntax',False)

# Lightweight delimiter scan for changed Java sources (ignores strings/comments enough for accidental edit detection).
def balanced_java(text):
    stack=[]; pairs={')':'(',']':'[','}':'{'}; opens=set(pairs.values())
    i=0; state='code'; quote=''
    while i<len(text):
        c=text[i]; n=text[i+1] if i+1<len(text) else ''
        if state=='code':
            if c=='/' and n=='/': state='line'; i+=2; continue
            if c=='/' and n=='*': state='block'; i+=2; continue
            if c in ('"',"'"): state='str'; quote=c; i+=1; continue
            if c in opens: stack.append(c)
            elif c in pairs:
                if not stack or stack[-1]!=pairs[c]: return False
                stack.pop()
        elif state=='line':
            if c=='\n': state='code'
        elif state=='block':
            if c=='*' and n=='/': state='code'; i+=2; continue
        else:
            if c=='\\': i+=2; continue
            if c==quote: state='code'
        i+=1
    return not stack and state not in ('block','str')
for rel in [
'app/src/main/java/com/myshop/app/MainActivity.java','app/src/main/java/com/myshop/app/UserMenuActivity.java','app/src/main/java/com/myshop/app/AdminFolderActivity.java','app/src/main/java/com/myshop/app/DashboardAdsAdminActivity.java','app/src/main/java/com/myshop/app/FeatureActivity.java','app/src/main/java/com/myshop/app/GalleryActivity.java','app/src/main/java/com/myshop/app/ThemeConfig.java','app/src/main/java/com/myshop/app/AdminSectionActivity.java','app/src/main/java/com/myshop/app/BackendClient.java']:
    ck('Java delimiter balance: '+Path(rel).name, balanced_java(read(rel)))

for n,ok in checks: print(('PASS' if ok else 'FAIL'),n)
failed=[n for n,ok in checks if not ok]
print(f'\nRESULT: {len(checks)-len(failed)}/{len(checks)} checks passed')
if failed:
    print('FAILED:',*failed,sep='\n- '); sys.exit(1)
