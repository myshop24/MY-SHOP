# MY SHOP V-226 — FUNCTION SYNC FIX

This version is based on V-225 and targets the proven gap between successful build/backend data and Android frontend behavior.

## Confirmed from live checks before this build
- GitHub build pipeline runs successfully.
- Cloudflare Worker is deployed and active.
- R2 `my-shop-media` contains banner objects.
- D1 `banners` table contains two active hero banner records.
- `/v1/dashboard/config` returns `ok:true`, banner data, featureButtons, managedLinks and media.
- `dashboardAds` was empty at the time of the live check, so startup-ad content itself was not yet present in D1.

## V-226 code fixes
1. Dashboard remote configuration is re-fetched in `MainActivity.onResume()` so Admin save -> Back to Dashboard refreshes without relaunching the app.
2. Hero banner carousel now rotates only through populated remote hero slots when remote banners exist, instead of showing local fallback images between remote slots.
3. After dashboard API returns, the first available remote hero banner is shown immediately.
4. Customer Support page fixed from raw-pixel/fixed-height header/status sizing to dp + WRAP_CONTENT, preventing clipped text.
5. Customer Support has a full readable empty-state card with the correct support icon when no Admin support URL exists.
6. Customer Support bottom Back control is styled and sized to avoid the previous grey-bar/overlay appearance.
7. Startup Ad media URL now uses `updated_at` cache busting so a replaced image/video is fetched fresh after Admin changes.
8. Version advanced to `versionCode 226` / `versionName 2.9.226` / `MY SHOP V-226`.

## Important limitation still external to this ZIP
The repository-root GitHub Actions workflow controls the downloaded artifact contents. The workflow candidate inside this source uploads only `MY_SHOP_FINAL_RELEASE.apk`, but a source ZIP cannot replace an already-installed repository-root workflow by itself. If the live root workflow still uploads `.sha256` and `BUILD_SOURCE_ID.txt`, the artifact will still contain 3 files until that root workflow is updated once.

## Function verification rule
Build success is not treated as feature success. After APK build, verify Admin Save -> D1/API -> Dashboard refresh, Customer Support, and Startup Ad with actual content.
