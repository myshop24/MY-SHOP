# MY SHOP V-237 BUILD NOTES

Base: V-236. Preserves existing V-236 functionality and adds the agreed V-237 scope.

- New People + friend request flow preserved.
- Real 1-to-1 message backend (D1), Inbox, conversation UI, unread count API and message notifications.
- Notification routing for Message/Friend/social update surfaces.
- Existing full-screen vertical public-video viewer preserved and exposed as Videos in More.
- Admin Banner Manager upgraded with current banner reference, Add/Edit/Save/Delete, optional caption and optional click-link URL.
- Banner backend stores target_url and remains backward-compatible through additive schema migration.
- Existing admin managed-link optional fields preserved; Name + URL or partial data can be saved without requiring icon/image/caption.
- Android + Worker version aligned to V-237 / 2.9.237.
