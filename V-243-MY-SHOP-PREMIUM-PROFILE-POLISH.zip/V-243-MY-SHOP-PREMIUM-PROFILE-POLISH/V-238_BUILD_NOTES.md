# MY SHOP V-238 — FACEBOOK-SMOOTH SOCIAL + VIDEO FINAL

Build identity: V-238 / 2.9.238
Base: V-237-MY-SHOP-MESSAGE-VIDEO-ADMIN-BANNER-FINAL

## Locked V-238 scope implemented
1. Smooth cached/background loading for dashboard social surfaces; MY FEED no longer blanks during refresh.
2. MY FEED first-page cache, background refresh, duplicate-post guard and focused-post routing.
3. Admin cards use per-card colorful rounded ADD / EDIT / SAVE / DELETE controls; optional External Movie fields stay optional. Banner slots keep current preview + click link controls.
4. New People dashboard shows latest five eligible users; See All supports the full list, friend state, requests, accepts and social notifications.
5. Full 1-to-1 message inbox/chat with unread badges, history cache, polling, sending/failure state and message notifications.
6. Dedicated bottom Video navigation opens public full-screen vertical video feed with Like / Comment / Share / Save and next-video prefetch. LIVE remains separate.

Android + Worker are version-aligned to V-238.
