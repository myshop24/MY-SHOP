from pathlib import Path

root=Path(__file__).resolve().parent
def read(path): return (root/path).read_text(encoding="utf-8")
checks=[]
def ok(name,value):
    checks.append((name,bool(value)))
    print(("PASS " if value else "FAIL ")+name)

main=read("app/src/main/java/com/myshop/app/MainActivity.java")
gradle=read("app/build.gradle")
worker=read("backend/worker/src/index.js")
workflow=read(".github/workflows/my-shop-apk.yml")
ok("SOURCE_BUILD_ID V-233",read("SOURCE_BUILD_ID.txt").strip()=="MY SHOP V-233")
ok("source version 2.9.233",read("SOURCE_VERSION_NAME.txt").strip()=="2.9.233")
ok("Android version", "versionCode 233" in gradle and "versionName '2.9.233'" in gradle)
ok("Worker identity",worker.count("version:'2.9.233',build:'V-233'")>=2)
ok("release notification","release_notice_v233" in worker)
ok("fixed dashboard surface","fixed.addView(header()" in main and "fixed.addView(breaking()" in main and "fixed.addView(liveStreamingSection()" in main)
ok("advertisement before feed","page.addView(hero" in main and main.index("page.addView(hero")<main.index("page.addView(feedComposerSection"))
ok("professional live controls",all(x in main for x in ['Go Live','Live Now','Join Live','See All  →']))
ok("title-only animation",'ObjectAnimator.ofFloat(title,"scaleX"' in main)
ok("six responsive slots",'new JSONObject[6]' in main and 'weight(1,dp(58))' in main)
ok("duplicate MY FEED removed",'names.addView(text("MY FEED"' not in main)
ok("headline readable",'Math.max(newsTextSizeSp,12.5f)' in main)
ok("workflow V-233","AUTO-BUILD V-233" in workflow)
ok("Java delimiters",main.count("{")==main.count("}"))
failed=[n for n,v in checks if not v]
print(f"RESULT: {len(checks)-len(failed)}/{len(checks)}")
raise SystemExit(1 if failed else 0)
