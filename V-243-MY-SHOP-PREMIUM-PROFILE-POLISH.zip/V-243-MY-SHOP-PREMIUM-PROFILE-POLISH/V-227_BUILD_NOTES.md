# MY SHOP V-227 — FUNCTION ADMIN + EXISTING LIVE ROW FIX

## Version
- SOURCE_BUILD_ID: `MY SHOP V-227`
- Android versionCode: `227`
- Android versionName: `2.9.227`

## Confirmed problems addressed in this source

### 1) Unwanted blank Dynamic Content section
- Removed the separate `LIVE / AD / SOCIAL / CAPTION` placeholder area.
- Dynamic content now renders inside the EXISTING small circular/live-person row only.
- The existing row supports six isolated slots (`dashboard_slot_1` ... `dashboard_slot_6`).
- Admin tapping a slot opens that exact slot's editor.
- Normal users open the configured link/action; default live behavior remains when no custom link exists.

### 2) Customer Support had no Admin CRUD
- Customer Support now exposes Admin edit access from MORE and from the Support page.
- Up to 3 support items can be managed independently.
- Each item supports: Name, Caption, Link/URL, Icon URL, Image URL, Active state.
- Controls: ADD, SAVE / EDIT, DELETE.
- WhatsApp phone numbers, normal web/Facebook links, `tel:` and `mailto:` targets are supported by the Support renderer.

### 3) Per-feature Admin control for the confirmed dashboard scope
- Dashboard main feature cards open their own Admin editor when tapped by Admin.
- Existing circular/live slots open their own Admin editor when tapped by Admin.
- Each generic feature editor supports: Name, Caption, Link, Icon, Image, Active, ADD, SAVE / EDIT, DELETE.
- Saved configuration is stored through the existing `managed_links` backend model and reloads from `/v1/dashboard/config`.

### 4) Image system
- Generic feature and Customer Support editors include `CHOOSE / UPLOAD IMAGE`.
- Upload reuses the already-live `/v1/admin/ad/upload` endpoint and R2 storage.
- Returned image URL is filled into the editor; Admin then presses SAVE / EDIT to attach it to that feature/support item.
- No new Worker API is required for this V-227 scope.

## Safety / build rules
- Permanent signing key is NOT regenerated or replaced.
- Nested workflow uses repository secrets for signing credentials; passwords are not hard-coded in the V-227 workflow candidate.
- Artifact upload candidate contains only `MY_SHOP_FINAL_RELEASE.apk`.

## Verification performed before packaging
- Java source parser scan: no Java syntax/parser errors detected (Android SDK classes are unavailable in this local static scan).
- Worker JavaScript: `node --check` passed.
- Required backend method `adminAdUpload(...)` exists.
- Version markers checked.
- ZIP integrity checked after packaging.

## Function status
- IMPLEMENTED IN SOURCE, but NOT marked end-to-end PASS until the GitHub-built V-227 APK is installed and tested on the real device.
- Build success alone must not be treated as function success.

## Scope note
Existing Social/More/Menu systems retain their established editors. V-227 applies the new exact per-button generic editor to the confirmed dashboard main feature cards, the existing circular/live row, and Customer Support. It does not claim that every screen in the entire app has been migrated to one universal editor yet.
