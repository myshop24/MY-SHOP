# Repository Root Workflow Note — V-227

GitHub executes only workflow files that exist in the repository-root `.github/workflows/` directory. A workflow stored inside this source ZIP is a candidate/reference and does not replace the live root workflow by itself.

The live repository-root workflow has already been manually corrected to upload only `MY_SHOP_FINAL_RELEASE.apk` in the artifact. Keep that permanent root workflow unless a future change is explicitly required.

V-227's confirmed feature/support changes reuse existing live backend endpoints and do not require a new Worker route.
