# MY SHOP V-221

- Permanent Cloudflare auto-promotion fix.
- Preserved the V-219 feature/backend source and changed only release/version markers plus the master GitHub Actions deployment logic.
- Worker upload now captures the exact uploaded version ID, deploys that exact version at 100% traffic, and verifies production before APK build.
- If production remains on an older version, GitHub retries the exact 100% promotion and then fails clearly instead of allowing an APK build.
- Future V-221, V-222, etc. inherit this master workflow automatically when they are based on this source.
