# MY SHOP V-239

Implemented requested UI/runtime fixes without replacing the approved dashboard structure.

1. Premium LIVE STREAMING section: smaller Go Live, larger Join Live, smooth pulse/glow, Live Now/Popular/Following/Nearby/See All controls.
2. Message inbox/chat visibility fixed (vertical weighted ScrollView width bug removed), larger clearer conversation UI.
3. Feed videos now render inline using VideoView instead of purple PLAY VIDEO placeholder; first-frame preparation, tap play/pause, muted preview, visibility-based playback, and fullscreen external open control.
4. More menu tiles enlarged and sharpened with larger high-resolution source assets.
5. Notifications blank-list bug fixed; Facebook-like larger rows with actor avatar, unread highlight, timestamps and optional post thumbnail. Worker notification payload now supplies actor avatar/post media when available.
6. Removed duplicate pink Live bottom-nav tab; Video remains. Dashboard Live section remains the Live entry point.
7. Left drawer menu icons/rows enlarged and clarified while preserving structure/navigation/admin/notification/logout behavior.

Live audio transport (Agora credentials/token service) is intentionally not hard-coded; the existing Go Live/Join Live routes remain ready for the dedicated Live backend integration.
