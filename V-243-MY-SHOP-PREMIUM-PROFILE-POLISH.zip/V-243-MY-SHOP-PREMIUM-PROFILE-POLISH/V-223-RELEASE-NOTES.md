# MY SHOP V-223 — 8 Problem Fix Release

## Locked build identity
- SOURCE_BUILD_ID: MY SHOP V-223
- versionCode: 223
- versionName: 2.9.223
- Permanent repository master YAML remains external/authoritative and must not be replaced by this ZIP.

## Included fixes
1. Final release policy documented: user-facing delivery target is one APK only. Note: GitHub artifact packaging is controlled by the locked repository master workflow, not Android source.
2. Startup Advertisement: Admin-managed image or video media, Add/Replace, Save, Delete, active state, target URL and 1–60 second duration; safe fallback if media fails.
3. Customer Support: corrected full-page layout, support icon support (including remote icon), no blank overlay after load, working support URL/WhatsApp target.
4. 3-Line Menu: existing dynamic Admin Add/Edit/Save/Delete + icon/name/link/show-hide kept and verified; frontend loads remote menu config/custom items.
5. Dashboard Banners: Admin CRUD path preserved, updated_at cache busting preserved, hero/promo auto rotation preserved.
6. Notifications: real notification inbox/unread state preserved; like/comment server notifications verified in worker source.
7. Dashboard Dynamic Folders: Icon + Name + Image/Banner + Caption + Link + Add/Edit/Save/Delete preserved; remote frontend rendering preserved.
8. External Links: Image + Icon + Name + Caption + URL + Save/Edit/Delete preserved and frontend click target preserved.

## V-223 startup media backend
- dashboard_ads now repairs/adds media_type automatically.
- Admin ad upload accepts image/* or video/*; image max 15 MB, video max 60 MB.
- Dashboard API returns media_type + updated_at.
- StartupAdActivity supports VideoView playback with image fallback and configurable timer.

## Safety
- No signing key is generated/replaced.
- Android package remains com.myshop.app.
- Existing auth/user IDs/data tables are not dropped.
- Worker source contains no destructive DROP/TRUNCATE of user tables.
