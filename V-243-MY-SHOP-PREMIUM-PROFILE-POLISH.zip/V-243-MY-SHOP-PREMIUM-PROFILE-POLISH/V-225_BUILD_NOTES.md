# MY SHOP V-225 — VERIFIED FULL FIX / AUTO BUILD SAFE

- SOURCE_BUILD_ID: MY SHOP V-225
- Android versionCode: 225
- Android versionName: 2.9.225
- Worker health marker: V-225 / 2.9.225
- Preserves permanent signing identity; no keystore regeneration.
- Carries forward V-224 app/backend feature fixes.
- Internal workflow candidate uploads ONLY `MY_SHOP_FINAL_RELEASE.apk` in the final user artifact.
- Internal workflow candidate includes Cloudflare Worker deployment/verification.
- IMPORTANT: the repository-root `.github/workflows/my-shop-apk.yml` controls the live GitHub build. Uploading this source ZIP alone cannot replace that repository-root workflow under the current read-only master workflow. Therefore the current root workflow may still package checksum/source-id files until it receives a one-time root-workflow upgrade.
