# MY SHOP Dashboard — Final Approved Requirements (V-234)

1. Order: Header, Breaking News, Live Streaming, advertisement slider, MY FEED, posts, bottom navigation.
2. Header through Live Streaming stays fixed; advertisement, feed and posts scroll; bottom navigation stays fixed.
3. Live panel is medium-height, full safe width, borderless, responsive, clean purple/blue and uses native text.
4. Only LIVE STREAMING uses a slow smooth pulse; no harsh flashing.
5. Go Live is left, small Live Now is centered, Join Live is right; buttons are long, rounded and separated.
6. Six live profile icons fill one row; See All opens remaining live profiles. LIVE and NEW states must never mix.
7. Advertisement slider is below Live Streaming, full safe width, proportional and retains automatic dots/carousel.
8. Breaking News contains only the animated megaphone and readable semibold marquee headline.
9. MY FEED keeps one clear left logo; the duplicate right MY FEED title is removed. POWER AD and See All remain.
10. Header, feed composer/posts/social features, approved colors and bottom navigation otherwise remain unchanged.
