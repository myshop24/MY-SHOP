# MY SHOP V-59 — GitHub Upload Package

Upload the contents of this package to the GitHub repository root.

- This package contains ONE Android source tree.
- It contains ONE GitHub Actions workflow: `.github/workflows/my-shop-apk.yml`.
- No source ZIP is included inside the package.
- The workflow builds the repository source directly.
- Source baseline is V-59 / version 2.9.59.
- Every new GitHub Actions run generates a new APK version.
