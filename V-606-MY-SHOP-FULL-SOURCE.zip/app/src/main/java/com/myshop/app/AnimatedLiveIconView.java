package com.myshop.app;
import android.content.Context;
import android.graphics.*;
import android.view.View;
/** Design29: stationary camera, slow expanding blue/pink light. */
final class AnimatedLiveIconView extends View {
 private final Paint p=new Paint(3);private final boolean reduce;
 AnimatedLiveIconView(Context c){super(c);reduce=c.getSharedPreferences("myshop_accessibility",Context.MODE_PRIVATE).getBoolean("reduce_animation",false);setContentDescription("Live video");}
 @Override protected void onDraw(Canvas c){float s=Math.min(getWidth(),getHeight()),x=getWidth()/2f,y=getHeight()/2f,t=reduce?0:(android.os.SystemClock.uptimeMillis()%3000)/3000f;
 p.setStyle(Paint.Style.FILL);p.setShader(new RadialGradient(x,y,s*.4f,new int[]{0xff02030d,0xff070723,0xff18214a},null,Shader.TileMode.CLAMP));c.drawCircle(x,y,s*.37f,p);
 p.setStyle(Paint.Style.STROKE);p.setShader(new SweepGradient(x,y,new int[]{0xff43dbff,0xff7353ff,0xffff3ab9,0xff43dbff},null));for(int i=0;i<3;i++){float f=(t+i/3f)%1;p.setStrokeWidth(s*.014f);p.setAlpha((int)(120*(1-f)));c.drawCircle(x,y,s*(.37f+.115f*f),p);}p.setAlpha(210+(int)(40*Math.sin(t*6.283)));p.setStrokeWidth(s*.025f);c.drawCircle(x,y,s*.37f,p);
 p.setShader(null);p.setAlpha(255);p.setColor(Color.WHITE);p.setStyle(Paint.Style.FILL);c.drawRoundRect(x-s*.19f,y-s*.135f,x+s*.085f,y+s*.135f,s*.045f,s*.045f,p);Path camera=new Path();camera.moveTo(x+s*.11f,y-s*.08f);camera.lineTo(x+s*.22f,y-s*.13f);camera.lineTo(x+s*.22f,y+s*.13f);camera.lineTo(x+s*.11f,y+s*.08f);camera.close();c.drawPath(camera,p);p.setColor(0xff392074);Path play=new Path();play.moveTo(x-s*.09f,y-s*.055f);play.lineTo(x-s*.09f,y+s*.055f);play.lineTo(x-s*.015f,y);play.close();c.drawPath(play,p);if(!reduce&&isShown())postInvalidateOnAnimation();}
}
