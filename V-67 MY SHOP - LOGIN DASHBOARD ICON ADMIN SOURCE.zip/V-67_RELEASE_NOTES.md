# MY SHOP V-67

## Milestone
Login + Dashboard + MS Icon + Admin hardening.

### Changes
- Preserved Email/Mobile login with no OTP.
- Preserved permanent 4-digit IDs beginning at 0100.
- Password reset now accepts any 2 of the 3 security answers.
- Profile contact/name updates persist against the permanent account record.
- Fixed admin identity role detection on account creation for the three configured identities.
- Admin management remains role-gated and uses the same Main Dashboard.
- Moderator management capped at 5.
- Replaced launcher icon with the supplied MS icon reference.
- Dashboard live cards now use image assets and remain mobile-responsive.
- Version changed to 2.9.67 / versionCode 67.
