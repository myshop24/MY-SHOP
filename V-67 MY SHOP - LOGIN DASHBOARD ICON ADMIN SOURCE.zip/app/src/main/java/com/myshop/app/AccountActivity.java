package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** MY SHOP account screen: local actions are functional; server authority can be attached later. */
public class AccountActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        refreshHeader();

        Switch notifications = findViewById(R.id.notificationSwitch);
        notifications.setChecked(getPreferences(MODE_PRIVATE).getBoolean("notifications", true));
        notifications.setOnCheckedChangeListener((button, checked) ->
                getPreferences(MODE_PRIVATE).edit().putBoolean("notifications", checked).apply());

        findViewById(R.id.profileButton).setOnClickListener(v -> editProfile());
        findViewById(R.id.passwordButton).setOnClickListener(v -> changePassword());
        findViewById(R.id.reportButton).setOnClickListener(v -> saveSimpleItem("report", "Report saved. Admin can review it."));
        findViewById(R.id.blockButton).setOnClickListener(v -> saveSimpleItem("block", "Block request saved locally."));

        Button admin = findViewById(R.id.adminButton);
        if (SessionManager.isAdmin(this)) {
            admin.setVisibility(Button.VISIBLE);
            admin.setOnClickListener(v -> startActivity(new Intent(this, AdminManagementActivity.class)));
        } else {
            admin.setVisibility(Button.GONE);
        }

        findViewById(R.id.logoutButton).setOnClickListener(v -> {
            SessionManager.clear(this);
            Intent intent = new Intent(this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }

    private void refreshHeader() {
        TextView id = findViewById(R.id.accountId);
        TextView role = findViewById(R.id.accountRole);
        String userId = SessionManager.getUserId(this);
        String name = getSharedPreferences("myshop_session", MODE_PRIVATE).getString("full_name", "");
        String email = getSharedPreferences("myshop_session", MODE_PRIVATE).getString("email", "");
        String mobile = getSharedPreferences("myshop_session", MODE_PRIVATE).getString("mobile", "");
        id.setText("Profile ID: " + (userId.isEmpty() ? "Not assigned" : userId)
                + "\nName: " + (name.isEmpty() ? "Not set" : name)
                + "\nEmail/Mobile: " + (!email.isEmpty() ? email : (mobile.isEmpty() ? "Not set" : mobile)));
        role.setText("Role: " + SessionManager.getRole(this).name());
    }

    private void editProfile() {
        LinearLayoutBox box = new LinearLayoutBox();
        new AlertDialog.Builder(this).setTitle("Edit Profile").setView(box.layout)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE", (d, w) -> {
                    String n = box.name.getText().toString().trim();
                    String e = box.email.getText().toString().trim();
                    String m = box.mobile.getText().toString().trim();
                    if (n.isEmpty() || (e.isEmpty() && m.isEmpty())) { Toast.makeText(this, "Name and at least Email or Mobile are required.", Toast.LENGTH_SHORT).show(); return; }
                    String id = SessionManager.getUserId(this);
                    if (!AccountStore.updateProfile(this, id, n, e, m)) { Toast.makeText(this, "Profile update failed or contact is already in use.", Toast.LENGTH_LONG).show(); return; }
                    SessionManager.saveProfile(this, n, e, m);
                    refreshHeader();
                    Toast.makeText(this, "Profile updated. Permanent ID remains " + id + ".", Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void changePassword() {
        LinearPasswordBox box = new LinearPasswordBox();
        new AlertDialog.Builder(this).setTitle("Change Password").setView(box.layout)
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("SAVE", (d, w) -> {
                    String oldPass = box.oldPass.getText().toString();
                    String newPass = box.newPass.getText().toString();
                    if (newPass.length() < 6) { Toast.makeText(this, "New password must be 6+ characters.", Toast.LENGTH_SHORT).show(); return; }
                    String id = SessionManager.getUserId(this);
                    AccountStore.Account a = AccountStore.authenticate(this, id, oldPass);
                    if (a == null || !AccountStore.changePassword(this, id, newPass)) {
                        Toast.makeText(this, "Current password is incorrect.", Toast.LENGTH_LONG).show();
                    } else Toast.makeText(this, "Password changed.", Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void saveSimpleItem(String key, String message) {
        getSharedPreferences("myshop_account_actions", MODE_PRIVATE).edit().putLong(key, System.currentTimeMillis()).apply();
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private final class LinearLayoutBox {
        final LinearLayout layout = new LinearLayout(AccountActivity.this);
        final EditText name = field("Full name");
        final EditText email = field("Email (optional)");
        final EditText mobile = field("Mobile (optional)");
        LinearLayoutBox(){
            layout.setOrientation(LinearLayout.VERTICAL);
            int p=(int)(16*getResources().getDisplayMetrics().density); layout.setPadding(p,0,p,0);
            name.setText(getSharedPreferences("myshop_session",MODE_PRIVATE).getString("full_name",""));
            email.setText(getSharedPreferences("myshop_session",MODE_PRIVATE).getString("email",""));
            mobile.setText(getSharedPreferences("myshop_session",MODE_PRIVATE).getString("mobile",""));
            layout.addView(name); layout.addView(email); layout.addView(mobile);
        }
        private EditText field(String hint){ EditText e=new EditText(AccountActivity.this); e.setHint(hint); e.setSingleLine(true); return e; }
    }

    private final class LinearPasswordBox {
        final android.widget.LinearLayout layout = new android.widget.LinearLayout(AccountActivity.this);
        final EditText oldPass = field("Current password");
        final EditText newPass = field("New password (6+ chars)");
        LinearPasswordBox() { layout.setOrientation(android.widget.LinearLayout.VERTICAL); int p=(int)(16*getResources().getDisplayMetrics().density); layout.setPadding(p,0,p,0); layout.addView(oldPass); layout.addView(newPass); }
        private EditText field(String hint){ EditText e=new EditText(AccountActivity.this); e.setHint(hint); e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); e.setSingleLine(true); return e; }
    }
}
