package com.myshop.app;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

/** V-66: role-gated Admin controls. No separate Admin dashboard; this is management access only. */
public class AdminManagementActivity extends AppCompatActivity {
    private SharedPreferences p;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        if(!SessionManager.isAdmin(this)){ Toast.makeText(this,"Admin access required.",Toast.LENGTH_LONG).show(); finish(); return; }
        p=getSharedPreferences("myshop_admin",MODE_PRIVATE); buildUi();
    }
    private void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,22,18,18); root.setBackgroundColor(getColor(R.color.myshop_bg));
        TextView title=new TextView(this); title.setText("MY SHOP • ADMIN CONTROLS"); title.setTextSize(22); title.setGravity(Gravity.CENTER); title.setTypeface(null,1); root.addView(title,new LinearLayout.LayoutParams(-1,64));
        TextView who=new TextView(this); who.setText("Role: ADMIN\nProfile ID: "+SessionManager.getUserId(this)); who.setTextSize(14); root.addView(who,new LinearLayout.LayoutParams(-1,58));
        add(root,"Banner • Add / Edit / Delete",v->showBannerManager());
        add(root,"Breaking News • Add / Edit / Delete",v->editText("Breaking News",p.getString("breaking_news","বাংলাদেশে আজ স্বর্ণের দাম আবার কমলো ☀️"),"breaking_news"));
        add(root,"Gallery / Media • Add / Edit / Delete",v->showEditable("gallery_media","Gallery / Media items (comma separated)",p.getString("gallery_media","")));
        add(root,"Social Links • Add / Edit / Delete",v->showEditable("social_links","Social links (comma separated)",p.getString("social_links","")));
        add(root,"My Shop • Add / Edit / Delete",v->showEditable("shop_url","MY SHOP URL",p.getString("shop_url","")));
        add(root,"TV / External • Add / Edit / Delete",v->showEditable("tv_external","TV / External links (comma separated)",p.getString("tv_external","")));
        add(root,"Moderator Management",v->showEditable("moderators","Moderator IDs (up to 5, comma separated)",p.getString("moderators","")));
        add(root,"Admin Identity / Permission Check",v->Toast.makeText(this,"Admin verified\nProfile ID: "+SessionManager.getUserId(this),Toast.LENGTH_LONG).show());
        Button back=new Button(this); back.setText("BACK TO SAME MAIN DASHBOARD"); back.setOnClickListener(v->finish()); root.addView(back,new LinearLayout.LayoutParams(-1,58));
        setContentView(root);
    }
    private void add(LinearLayout root,String s,android.view.View.OnClickListener l){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setOnClickListener(l);root.addView(b,new LinearLayout.LayoutParams(-1,56));}
    private void showBannerManager(){
        new AlertDialog.Builder(this).setTitle("Banner Management")
                .setMessage("Each banner group supports up to 6 active banners.\n\nTop Left: 6\nTop Right: 6\nWide: 6")
                .setNegativeButton("CLOSE",null).setPositiveButton("EDIT STATUS",(d,w)->showEditable("banner_status","Banner status",p.getString("banner_status","6 / 6 / 6"))).show();
    }
    private void editText(String title,String initial,String key){ EditText e=new EditText(this); e.setText(initial); e.setSingleLine(false); new AlertDialog.Builder(this).setTitle(title).setView(e).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(d,w)->{p.edit().putString(key,e.getText().toString().trim()).apply();Toast.makeText(this,"Saved.",Toast.LENGTH_SHORT).show();}).show(); }
    private void showEditable(String key,String title,String initial){
        EditText e=new EditText(this); e.setText(initial); e.setSingleLine(false);
        new AlertDialog.Builder(this).setTitle(title).setView(e).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(d,w)->{
            String value=e.getText().toString().trim();
            if ("moderators".equals(key)) {
                String[] parts=value.isEmpty()?new String[0]:value.split(",");
                if (parts.length>5) { Toast.makeText(this,"Maximum 5 moderators allowed.",Toast.LENGTH_LONG).show(); return; }
            }
            p.edit().putString(key,value).apply(); Toast.makeText(this,"Saved.",Toast.LENGTH_SHORT).show();
        }).show();
    }
}
