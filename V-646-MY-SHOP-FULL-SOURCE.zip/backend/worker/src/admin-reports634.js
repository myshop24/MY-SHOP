const sources={
 PRODUCT_ACTIONS:{table:'myshop_product_actions634',owner:'user_id',cursor:'rowid',cols:'rowid id,created_at,user_id,actor_id,action type,item_id,kind,days,reason,request_key reference'},
 WALLET_LOCKS:{table:'myshop_wallet_lock_audit634',owner:'user_id',cursor:'rowid',cols:'rowid id,created_at,user_id,actor_id,action type,currency,amount,before_amount,after_amount,reason,request_key reference'},
 LIVE_HISTORY:{table:'myshop_live_history',owner:'host_id',time:'ended_at',cols:'id,ended_at created_at,host_id user_id,title type,started_at,duration_seconds,peak_viewers,total_listeners'},
 TRANSACTIONS:{table:'myshop_value_ledger',owner:'sender_id',cols:'id,created_at,status,currency,tx_type type,sender_id user_id,receiver_id,gross_amount amount,reference'},
 WITHDRAWALS:{table:'myshop_creator_withdraw_requests',owner:'user_id',cols:'id,created_at,status,currency,user_id,gross_units amount,payment_method,updated_at'},
 COIN_PURCHASES:{table:'myshop_coin_purchase_requests',owner:'user_id',cols:'id,created_at,status,user_id,package_coins amount,payment_method,reference'},
 USER_REPORTS:{table:'myshop_safety_reports',owner:'reporter_id',cols:'id,created_at,status,reporter_id user_id,target_user_id,content_type type,reason'},
 ADMIN_ACTIVITY:{table:'myshop_admin_user_actions',owner:'user_id',cols:'id,created_at,admin_id,user_id,action type,note'}
};
export async function adminReports634(request,env,h){const a=await h.adminOnly(request,env);if(a.error)return a.error;if(!['0001','0002','0003'].includes(a.user.user_id))return h.json({error:'MAIN_ADMIN_ONLY'},403,h.cors);
 const q=new URL(request.url).searchParams,kind=q.get('kind')||'TRANSACTIONS',source=sources[kind],status=q.get('status')||'',start=q.get('start')||'',end=q.get('end')||'',id=q.get('userId')||'',before=Number(q.get('before')||0);
 if(!source||status&&!/^[A-Z_]{1,30}$/.test(status)||id&&!/^\d{4,8}$/.test(id)||!Number.isSafeInteger(before)||before<0||[start,end].some(d=>d&&(!/^\d{4}-\d{2}-\d{2}$/.test(d)||!Number.isFinite(Date.parse(d))||new Date(d).toISOString().slice(0,10)!==d))||start&&end&&start>end)return h.json({error:'INVALID_REPORT_FILTER'},400,h.cors);
 if(!await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").bind(source.table).first())return h.json({error:'REPORT_SOURCE_UNAVAILABLE'},409,h.cors);
 if(status&&['ADMIN_ACTIVITY','LIVE_HISTORY','PRODUCT_ACTIONS','WALLET_LOCKS'].includes(kind))return h.json({error:'STATUS_NOT_APPLICABLE'},400,h.cors);
 const uid=id?await h.resolve(env,id):'',params=[uid,uid,...(kind==='TRANSACTIONS'?[uid,uid]:[]),start,start,end,end,before,before],where=`${kind==='TRANSACTIONS'?"(?='' OR sender_id=? OR receiver_id=? OR host_id=?)":"(?='' OR "+source.owner+"=?)"} AND (?='' OR date(${source.time||'created_at'})>=date(?)) AND (?='' OR date(${source.time||'created_at'})<=date(?)) AND (?=0 OR ${source.cursor||'id'}<?)`;
 const rows=(await env.DB.prepare(`SELECT ${source.cols} FROM ${source.table} WHERE ${where}${status?' AND status=?':''} ORDER BY ${source.cursor||'id'} DESC LIMIT 51`).bind(...params,...(status?[status]:[])).all()).results||[];const more=rows.length>50,list=rows.slice(0,50);
 return h.json({ok:true,kind,rows:list,hasMore:more,nextBefore:more?list.at(-1).id:0,asOf:new Date().toISOString(),timezone:'UTC'},200,{...h.cors,'Cache-Control':'private, no-store'});
}
