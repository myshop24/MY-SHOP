import {writeManagedFeature,featureHistorySchema} from './feature-history.js';
const MAIN_IDS=new Set(['0001','0002','0003']);
const ACTIONS=['view','save_draft'];
const LIVE_ACTIONS=['view','mute','unmute','kick','block','unblock','invite','requests','pin','room_admin','settings','end'];
const validFolder=x=>/^feature_[a-z0-9_]{1,80}$/.test(x);

async function schema(DB){
 await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_folder_grants(user_id TEXT NOT NULL,folder TEXT NOT NULL,action TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 0,revision INTEGER NOT NULL DEFAULT 1,actor_id TEXT NOT NULL,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,folder,action))`).run();
 await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_folder_grant_audit(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,folder TEXT NOT NULL,action TEXT NOT NULL,old_enabled INTEGER NOT NULL,new_enabled INTEGER NOT NULL,actor_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
 await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_feature_drafts(category TEXT PRIMARY KEY,payload TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 1,actor_id TEXT NOT NULL,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
 await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_feature_draft_events(id INTEGER PRIMARY KEY AUTOINCREMENT,category TEXT NOT NULL,actor_id TEXT NOT NULL,old_payload TEXT NOT NULL,new_payload TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
}

export async function adminFolderControls(request,env,h){
 const {json,cors}=h,fail=(error,status)=>json({error},status,cors);
 const me=await h.getUser(request,env);if(!me)return fail('UNAUTHORIZED',401);
 const url=new URL(request.url),path=url.pathname,DB=env.DB;
 const main=MAIN_IDS.has(String(me.user_id)),admin=main||me.role==='ADMIN';
 const target=await DB.prepare('SELECT active,role FROM myshop_auth_users_v108 WHERE user_id=?').bind(me.user_id).first();
 if(!target||Number(target.active)!==1)return fail('UNAUTHORIZED',401);
 await schema(DB);
 if(path==='/v1/me/admin-folders'){
  if(request.method!=='GET')return fail('METHOD_NOT_ALLOWED',405);
  if(me.role!=='MODERATOR'||target.role!=='MODERATOR')return fail('MODERATOR_REQUIRED',403);
  const rows=(await DB.prepare(`SELECT folder,MAX(CASE WHEN action='view' THEN enabled ELSE 0 END) can_view,MAX(CASE WHEN action='save_draft' THEN enabled ELSE 0 END) can_save_draft FROM myshop_folder_grants WHERE user_id=? GROUP BY folder HAVING MAX(CASE WHEN action='view' THEN enabled ELSE 0 END)=1 ORDER BY folder LIMIT 200`).bind(me.user_id).all()).results||[];
  return json({ok:true,folders:rows},200,cors);
 }
 if(path==='/v1/admin/folder-grants'){
  if(!main)return fail('PERMISSION_MANAGEMENT_REQUIRED',403);
  if(!['GET','PUT'].includes(request.method))return fail('METHOD_NOT_ALLOWED',405);
  let b={};if(request.method==='PUT'){try{b=await request.json();}catch(_){return fail('INVALID_JSON',400);}}
  if(!b||typeof b!=='object'||Array.isArray(b))return fail('INVALID_JSON',400);
  const uid=String(b.userId||url.searchParams.get('userId')||''),folder=String(b.folder||url.searchParams.get('folder')||'');
  if(!/^\d{4}$/.test(uid)||!validFolder(folder))return fail('INVALID_GRANT_SCOPE',400);
  if(MAIN_IDS.has(uid))return fail('PROTECTED_ADMIN',403);
  const actions=folder==='feature_live_streaming'?LIVE_ACTIONS:ACTIONS;
  const user=await DB.prepare('SELECT active,role FROM myshop_auth_users_v108 WHERE user_id=?').bind(uid).first();
  if(!user||Number(user.active)!==1||user.role!=='MODERATOR')return fail('ACTIVE_MODERATOR_REQUIRED',409);
  if(request.method==='GET'){
   const grants=(await DB.prepare('SELECT action,enabled,revision FROM myshop_folder_grants WHERE user_id=? AND folder=?').bind(uid,folder).all()).results||[];
   return json({ok:true,userId:uid,folder,actions,grants},200,cors);
  }
  if(!actions.includes(b.action)||typeof b.enabled!=='boolean'||!Number.isSafeInteger(b.expectedRevision)||b.expectedRevision<0)return fail('INVALID_FOLDER_GRANT',400);
  const previous=await DB.prepare('SELECT enabled,revision FROM myshop_folder_grants WHERE user_id=? AND folder=? AND action=?').bind(uid,folder,b.action).first();
  if(Number(previous?.revision||0)!==b.expectedRevision)return fail('GRANT_REVISION_CONFLICT',409);
  if(previous&&Number(previous.enabled)===Number(b.enabled))return json({ok:true,revision:b.expectedRevision,alreadyApplied:true},200,cors);
  const change=previous?DB.prepare('UPDATE myshop_folder_grants SET enabled=?,revision=revision+1,actor_id=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND folder=? AND action=? AND revision=?').bind(Number(b.enabled),me.user_id,uid,folder,b.action,b.expectedRevision):DB.prepare('INSERT OR IGNORE INTO myshop_folder_grants(user_id,folder,action,enabled,actor_id) VALUES(?,?,?,?,?)').bind(uid,folder,b.action,Number(b.enabled),me.user_id);
  const results=await DB.batch([change,DB.prepare('INSERT INTO myshop_folder_grant_audit(user_id,folder,action,old_enabled,new_enabled,actor_id) SELECT ?,?,?,?,?,? WHERE changes()=1').bind(uid,folder,b.action,Number(previous?.enabled||0),Number(b.enabled),me.user_id)]);
  if(!Number(results[0]?.meta?.changes||0))return fail('GRANT_REVISION_CONFLICT',409);
  return json({ok:true,revision:b.expectedRevision+1},200,cors);
 }
 if(path==='/v1/admin/features/publish'){
  if(!main)return fail('OWNER_PUBLISH_PERMISSION_REQUIRED',403);
  if(request.method!=='POST')return fail('METHOD_NOT_ALLOWED',405);
  let b;try{b=await request.json();}catch(_){return fail('INVALID_JSON',400);}
  const category=String(b?.category||'');if(!validFolder(category))return fail('INVALID_FEATURE_CATEGORY',400);
  if(/(?:^|_)(?:live|rtc|audio|gift|gifts|room)(?:_|$)/.test(category)||['feature_go_live','feature_top_gifters'].includes(category))return fail('LIVE_OWNER_APPROVAL_REQUIRED',403);
  if(!Number.isSafeInteger(b.draftRevision)||!Number.isSafeInteger(b.featureRevision))return fail('INVALID_REVISION',400);
  const draft=await DB.prepare('SELECT * FROM myshop_feature_drafts WHERE category=?').bind(category).first();
  if(!draft||Number(draft.revision)!==b.draftRevision)return fail('DRAFT_REVISION_CONFLICT',409);
  await DB.prepare(featureHistorySchema).run();
  const result=await writeManagedFeature(DB,me.user_id,JSON.parse(draft.payload),b.featureRevision,'SAVE',0,b.draftRevision);
  return json(result,result.error?result.statusCode:200,cors);
 }
 if(path!=='/v1/admin/features/draft')return fail('NOT_FOUND',404);
 if(!['GET','PUT'].includes(request.method))return fail('METHOD_NOT_ALLOWED',405);
 const folder=String(url.searchParams.get('category')||'');if(!validFolder(folder))return fail('INVALID_FEATURE_CATEGORY',400);
 if(!admin){
  if(me.role!=='MODERATOR'||target.role!=='MODERATOR')return fail('FOLDER_PERMISSION_REQUIRED',403);
  const grants=(await DB.prepare('SELECT action,enabled FROM myshop_folder_grants WHERE user_id=? AND folder=?').bind(me.user_id,folder).all()).results||[];
  const allowed=x=>grants.some(g=>g.action===x&&Number(g.enabled)===1);
  if(!allowed('view')||request.method==='PUT'&&!allowed('save_draft'))return fail('FOLDER_PERMISSION_REQUIRED',403);
 }
 const old=await DB.prepare('SELECT * FROM myshop_feature_drafts WHERE category=?').bind(folder).first();
 if(request.method==='GET')return json({ok:true,draft:old?JSON.parse(old.payload):null,revision:Number(old?.revision||0)},200,cors);
 let b;try{b=await request.json();}catch(_){return fail('INVALID_JSON',400);}
 if(!b||typeof b!=='object'||Array.isArray(b))return fail('INVALID_JSON',400);
 if(!b.config||typeof b.config!=='object'||Array.isArray(b.config)||b.config.category!==folder||!Number.isSafeInteger(b.expectedRevision)||b.expectedRevision<0)return fail('INVALID_FEATURE_DRAFT',400);
 const payload=JSON.stringify(b.config);if(new TextEncoder().encode(payload).length>16000)return fail('DRAFT_TOO_LARGE',413);
 if(Number(old?.revision||0)!==b.expectedRevision)return fail('DRAFT_REVISION_CONFLICT',409);
 const acl=admin?"EXISTS(SELECT 1 FROM myshop_auth_users_v108 a WHERE a.user_id=? AND a.active=1 AND (a.role='ADMIN' OR a.user_id IN ('0001','0002','0003')))":"EXISTS(SELECT 1 FROM myshop_auth_users_v108 a WHERE a.user_id=? AND a.active=1 AND a.role='MODERATOR') AND EXISTS(SELECT 1 FROM myshop_folder_grants g WHERE g.user_id=? AND g.folder=? AND g.action IN ('view','save_draft') AND g.enabled=1 GROUP BY g.user_id,g.folder HAVING COUNT(DISTINCT g.action)=2)";
 const aclArgs=admin?[me.user_id]:[me.user_id,me.user_id,folder];
 const write=old?DB.prepare('UPDATE myshop_feature_drafts SET payload=?,revision=revision+1,actor_id=?,updated_at=CURRENT_TIMESTAMP WHERE category=? AND revision=? AND '+acl).bind(payload,me.user_id,folder,b.expectedRevision,...aclArgs):DB.prepare('INSERT OR IGNORE INTO myshop_feature_drafts(category,payload,actor_id) SELECT ?,?,? WHERE '+acl).bind(folder,payload,me.user_id,...aclArgs);
 const results=await DB.batch([write,DB.prepare('INSERT INTO myshop_feature_draft_events(category,actor_id,old_payload,new_payload) SELECT ?,?,?,? WHERE changes()=1').bind(folder,me.user_id,old?.payload||'{}',payload)]);
 if(!Number(results[0]?.meta?.changes||0)){const currentAccess=await DB.prepare('SELECT CASE WHEN '+acl+' THEN 1 ELSE 0 END allowed').bind(...aclArgs).first();return fail(Number(currentAccess?.allowed)===1?'DRAFT_REVISION_CONFLICT':'FOLDER_PERMISSION_REQUIRED',Number(currentAccess?.allowed)===1?409:403);}
 return json({ok:true,revision:b.expectedRevision+1},200,cors);
}

// Called only after the existing server-side admin authorization gate.
export async function applyModeratorChange(env,actor,uid,action,note,h){
 const {json,cors}=h,fail=(error,status)=>json({error},status,cors),DB=env.DB;
 if(!/^\d{4}$/.test(uid)||!['add_moderator','remove_moderator'].includes(action))return fail('INVALID_MODERATOR_ACTION',400);
 if(MAIN_IDS.has(uid))return fail('PROTECTED_ADMIN',403);
  const user=await DB.prepare('SELECT active,role FROM myshop_auth_users_v108 WHERE user_id=?').bind(uid).first();if(!user)return fail('USER_NOT_FOUND',404);
 const enabled=action==='add_moderator'?1:0;
 if(enabled&&user.role==='ADMIN')return fail('PROTECTED_ADMIN_ROLE',403);
 if(enabled&&Number(user.active)!==1)return fail('ACTIVE_USER_REQUIRED',409);
 await schema(DB);
 await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_admin_user_actions(id INTEGER PRIMARY KEY AUTOINCREMENT,admin_id TEXT NOT NULL,user_id TEXT NOT NULL,action TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
 const previous=await DB.prepare('SELECT active FROM myshop_moderators_v108 WHERE user_id=?').bind(uid).first();
 if(Number(previous?.active||0)===enabled)return json({ok:true,userId:uid,action,alreadyApplied:true},200,cors);
 const change=enabled?DB.prepare(`INSERT INTO myshop_moderators_v108(user_id,active) SELECT ?,1 WHERE (SELECT COUNT(*) FROM myshop_moderators_v108 WHERE active=1)<5 ON CONFLICT(user_id) DO UPDATE SET active=1 WHERE myshop_moderators_v108.active=0`).bind(uid):DB.prepare('UPDATE myshop_moderators_v108 SET active=0 WHERE user_id=? AND active=1').bind(uid);
 const results=await DB.batch([
  change,
  DB.prepare('INSERT INTO myshop_admin_user_actions(admin_id,user_id,action,note) SELECT ?,?,?,? WHERE changes()=1').bind(actor.user_id,uid,action,String(note||'').slice(0,1000)),
  DB.prepare(enabled?"UPDATE myshop_auth_users_v108 SET role='MODERATOR' WHERE user_id=? AND changes()=1":"UPDATE myshop_auth_users_v108 SET role=CASE WHEN role='MODERATOR' THEN 'USER' ELSE role END WHERE user_id=? AND changes()=1").bind(uid),
  ...(!enabled?[
   DB.prepare('INSERT INTO myshop_folder_grant_audit(user_id,folder,action,old_enabled,new_enabled,actor_id) SELECT user_id,folder,action,1,0,? FROM myshop_folder_grants WHERE user_id=? AND enabled=1').bind(actor.user_id,uid),
   DB.prepare('UPDATE myshop_folder_grants SET enabled=0,revision=revision+1,actor_id=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND enabled=1').bind(actor.user_id,uid)
  ]:[])
 ]);
 if(!Number(results[0]?.meta?.changes||0))return fail('MODERATOR_LIMIT_OR_STATE_CHANGED',409);
 return json({ok:true,userId:uid,action},200,cors);
}
