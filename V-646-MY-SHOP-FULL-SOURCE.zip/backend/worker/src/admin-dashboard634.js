import { readIndexes636 } from './read-indexes636.js';
// One read-only snapshot. Missing sources are explicitly unavailable, never demo zeroes.
export async function adminDashboard634(request,env,h){
 const a=await h.adminOnly(request,env);if(a.error)return a.error;let indexUnavailable640=false;try{await readIndexes636(env.DB);}catch(_){indexUnavailable640=true;}
 const tables=new Set(((await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table'").all()).results||[]).map(r=>r.name));
 const unavailable=indexUnavailable640?["read_indexes"]:[];const one=async(table,sql)=>{if(!tables.has(table)){unavailable.push(table);return null;}try{return await env.DB.prepare(sql).first();}catch(_){unavailable.push(table);return null;}};
 const categories=[];
 for(const [key,table,pending] of [
 ['withdrawals','myshop_creator_withdraw_requests',"'PENDING','PROCESSING'"],
 ['coinPurchases','myshop_coin_purchase_requests',"'PENDING'"],
 ['reports','myshop_safety_reports',"'OPEN','PENDING'"],
 ['store','myshop_store_purchase_requests',"'PENDING'"],
 ['orders','shop_orders',"'PENDING','CONFIRMED','SHIPPED'"],
 ['support','myshop_support_tickets',"'PENDING','OPEN','WAITING_USER'"],
 ['accountDeletion','myshop_account_deletion_requests',"'PENDING','OPEN'"],
 ['legacyWithdrawals','myshop_coin_withdraw_requests',"'PENDING','PROCESSING'"]]){
 const row=await one(table,`SELECT COUNT(*) pending,MIN(created_at) oldest FROM ${table} WHERE status IN (${pending})`);categories.push({key,...(row||{}),available:!!row});
 }
 let unread=null,unreadCounts=[];
 if(tables.has('myshop_request_notices')&&tables.has('myshop_folder_notice_reads')){unreadCounts=(await env.DB.prepare('SELECT n.kind,COUNT(*) unread FROM myshop_request_notices n LEFT JOIN myshop_folder_notice_reads r ON r.event_key=n.event_key AND r.admin_id=? WHERE r.event_key IS NULL GROUP BY n.kind').bind(a.user.user_id).all()).results||[];unread=unreadCounts.reduce((n,r)=>n+Number(r.unread),0);}
 const kindMap={withdrawals:'WITHDRAW',coinPurchases:'COIN_PURCHASE',reports:'REPORT',store:'PREMIUM',orders:'ORDER',support:'SUPPORT',accountDeletion:'ACCOUNT_DELETE'};
 for(const c of categories)c.unread=unread===null?null:Number(unreadCounts.find(r=>r.kind===kindMap[c.key])?.unread||0);
 let adminActivity=[];try{if(tables.has('myshop_admin_user_actions'))adminActivity=(await env.DB.prepare('SELECT id,admin_id,user_id,action,note,created_at FROM myshop_admin_user_actions ORDER BY id DESC LIMIT 3').all()).results||[];}catch(_){unavailable.push('adminActivity');}
 const users=await one('myshop_auth_users_v108',"SELECT COUNT(*) total,SUM(CASE WHEN date(created_at)=date('now') THEN 1 ELSE 0 END) today FROM myshop_auth_users_v108");
 const presence=await one('myshop_app_presence',"SELECT SUM(CASE WHEN active=1 AND datetime(last_seen)>=datetime('now','-30 seconds') THEN 1 ELSE 0 END) online,SUM(CASE WHEN date(last_seen)=date('now') THEN 1 ELSE 0 END) daily,SUM(CASE WHEN datetime(last_seen)>=datetime('now','-7 days') THEN 1 ELSE 0 END) weekly,SUM(CASE WHEN datetime(last_seen)>=datetime('now','-30 days') THEN 1 ELSE 0 END) monthly FROM myshop_app_presence");
 const live=await one('myshop_live_presence',"SELECT COUNT(*) rooms FROM myshop_live_presence WHERE active=1 AND datetime(last_seen)>=datetime('now','-30 seconds')");
 const viewers=tables.has('myshop_live_presence')?await one('myshop_live_viewers',"SELECT COUNT(DISTINCT v.user_id) users FROM myshop_live_viewers v JOIN myshop_live_presence p ON p.user_id=v.host_id WHERE p.active=1 AND datetime(p.last_seen)>=datetime('now','-30 seconds') AND datetime(v.last_seen)>=datetime('now','-30 seconds')"):null;
 let liveRoles=null;try{
 if(tables.has('myshop_live_seats_dynamic')&&tables.has('myshop_live_viewers')&&tables.has('myshop_live_presence'))liveRoles=await env.DB.prepare("SELECT (SELECT COUNT(DISTINCT s.user_id) FROM myshop_live_seats_dynamic s JOIN myshop_live_presence p ON p.user_id=s.host_id WHERE p.active=1 AND datetime(p.last_seen)>=datetime('now','-30 seconds')) guests,(SELECT COUNT(DISTINCT v.user_id) FROM myshop_live_viewers v JOIN myshop_live_presence p ON p.user_id=v.host_id WHERE p.active=1 AND datetime(p.last_seen)>=datetime('now','-30 seconds') AND datetime(v.last_seen)>=datetime('now','-30 seconds') AND v.user_id<>v.host_id AND NOT EXISTS(SELECT 1 FROM myshop_live_seats_dynamic s WHERE s.host_id=v.host_id AND s.user_id=v.user_id)) audience").first();
}catch(_){unavailable.push('liveRoles');}
 let recent=[];try{if(tables.has('myshop_value_ledger'))recent=(await env.DB.prepare("SELECT id,tx_type,currency,sender_id,receiver_id,gross_amount,status,created_at FROM myshop_value_ledger ORDER BY id DESC LIMIT 3").all()).results||[];
}catch(_){unavailable.push('recent');}
 let history=[];try{if(tables.has('myshop_live_history'))history=(await env.DB.prepare('SELECT id,host_id,title,started_at,ended_at,duration_seconds,peak_viewers,total_listeners FROM myshop_live_history ORDER BY id DESC LIMIT 20').all()).results||[];
}catch(_){unavailable.push('history');}
 return h.json({ok:true,asOf:new Date().toISOString(),timezone:'UTC',categories,unread,adminActivity,users,presence,live,viewers,liveRoles,recent,history,unavailable,profit:{status:'UNVERIFIED',reason:'Complete income, expense and liability sources must be reconciled before net profit can be calculated.'},refreshSeconds:60},200,{...h.cors,'Cache-Control':'no-store'});
}
