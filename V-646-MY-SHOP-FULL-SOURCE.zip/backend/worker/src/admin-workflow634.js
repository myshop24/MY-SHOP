export async function adminWorkflow634(request,env,h){
 const a=await h.adminOnly(request,env);if(a.error)return a.error;
 await env.DB.batch([
 env.DB.prepare("CREATE TABLE IF NOT EXISTS myshop_request_work634(event_key TEXT PRIMARY KEY,note TEXT NOT NULL DEFAULT '',assigned_to TEXT NOT NULL DEFAULT '',revision INTEGER NOT NULL DEFAULT 0,updated_by TEXT NOT NULL,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)"),
 env.DB.prepare("CREATE TABLE IF NOT EXISTS myshop_request_work_audit634(id INTEGER PRIMARY KEY AUTOINCREMENT,event_key TEXT NOT NULL,note TEXT NOT NULL,assigned_to TEXT NOT NULL,revision INTEGER NOT NULL,actor_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")]);
 const b=request.method==='GET'?Object.fromEntries(new URL(request.url).searchParams):await request.json().catch(()=>({}));const key=String(b.eventKey||'');if(!/^[A-Z_]+:[0-9A-Za-z_-]{1,100}$/.test(key))return h.json({error:'INVALID_REQUEST'},400,h.cors);
 const table=await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='myshop_request_notices'").first();if(!table||!await env.DB.prepare('SELECT 1 found FROM myshop_request_notices WHERE event_key=?').bind(key).first())return h.json({error:'REQUEST_NOT_FOUND'},404,h.cors);
 if(request.method==='POST'){
 const note=String(b.note||'').trim(),assigned=String(b.assignedTo||''),revision=Number(b.expectedRevision);
 if(note.length>1000||assigned&&!/^\d{4,8}$/.test(assigned)||!Number.isSafeInteger(revision)||revision<0)return h.json({error:'INVALID_NOTE'},400,h.cors);
 if(assigned&&!await env.DB.prepare("SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND role='ADMIN' AND active=1").bind(assigned).first())return h.json({error:'ASSIGNEE_NOT_ADMIN'},400,h.cors);
 await env.DB.prepare("INSERT OR IGNORE INTO myshop_request_work634(event_key,updated_by) VALUES(?,?)").bind(key,a.user.user_id).run();
 const result=await env.DB.batch([env.DB.prepare('UPDATE myshop_request_work634 SET note=?,assigned_to=?,revision=revision+1,updated_by=?,updated_at=CURRENT_TIMESTAMP WHERE event_key=? AND revision=?').bind(note,assigned,a.user.user_id,key,revision),env.DB.prepare('INSERT INTO myshop_request_work_audit634(event_key,note,assigned_to,revision,actor_id) SELECT ?,?,?,?,? WHERE changes()=1').bind(key,note,assigned,revision+1,a.user.user_id)]);
 if(!result[0].meta?.changes)return h.json({error:'NOTE_CHANGED_RELOAD'},409,h.cors);
 }
 const work=await env.DB.prepare('SELECT * FROM myshop_request_work634 WHERE event_key=?').bind(key).first();const history=(await env.DB.prepare('SELECT * FROM myshop_request_work_audit634 WHERE event_key=? ORDER BY id DESC LIMIT 50').bind(key).all()).results||[];
 return h.json({ok:true,work,history},200,{...h.cors,'Cache-Control':'private, no-store'});
}
