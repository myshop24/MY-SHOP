// Opaque revision only: no user, request, wallet or session values enter the DO.
const verified=new Map();
function token(request){return String(request.headers.get('authorization')||'');}
function hub(env){return env.LIVE_ROOM_HUB?.get(env.LIVE_ROOM_HUB.idFromName('admin-dashboard-634'));}
export function rememberAdmin634(request){const now=Date.now();if(verified.size>200)for(const [key,until] of verified)if(until<now)verified.delete(key);verified.set(token(request),now+30000);}
export async function dashboardRevision634(request,env,h){
 if(!token(request))return h.json({error:'UNAUTHORIZED'},401,h.cors);
 if((verified.get(token(request))||0)<Date.now()){const a=await h.adminOnly(request,env);if(a.error)return a.error;rememberAdmin634(request);}
 const stub=hub(env);if(!stub)return h.json({error:'REVISION_UNAVAILABLE',fallbackSeconds:15},503,h.cors);
 const r=await stub.fetch('https://admin-dashboard/directory/revision');return new Response(await r.text(),{status:r.status,headers:{...h.cors,'Content-Type':'application/json','Cache-Control':'no-store'}});
}
export async function signalDashboard634(env){try{const s=hub(env);if(s)await s.fetch('https://admin-dashboard/directory/change',{method:'POST'});}catch(_){/* Snapshot fallback repairs missed events. */}}
