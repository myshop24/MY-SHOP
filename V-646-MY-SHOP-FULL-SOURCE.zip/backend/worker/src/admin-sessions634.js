export async function adminSessions634(request,env,h){
 const a=await h.adminOnly(request,env);if(a.error)return a.error;const me=a.user,auth=String(request.headers.get('authorization')||'');const current=await h.sha256(auth.replace(/^Bearer\s+/i,''));
 if(request.method==='GET'){const rows=(await env.DB.prepare('SELECT token_hash,created_at,expires_at FROM myshop_auth_sessions_v108 WHERE user_id=? AND expires_at>? ORDER BY created_at DESC').bind(me.user_id,Date.now()).all()).results||[];return h.json({ok:true,sessions:rows.map(r=>({id:r.token_hash,createdAt:r.created_at,expiresAt:r.expires_at,current:r.token_hash===current}))},200,{...h.cors,'Cache-Control':'private, no-store'});}
 const b=await request.json().catch(()=>({}));if(typeof b.id!=='string'||!/^[0-9a-f]{64}$/i.test(b.id)||b.confirm!==true)return h.json({error:'INVALID_SESSION'},400,h.cors);
 await env.DB.prepare('DELETE FROM myshop_auth_sessions_v108 WHERE user_id=? AND token_hash=?').bind(me.user_id,b.id).run();return h.json({ok:true,currentEnded:b.id===current},200,h.cors);
}
