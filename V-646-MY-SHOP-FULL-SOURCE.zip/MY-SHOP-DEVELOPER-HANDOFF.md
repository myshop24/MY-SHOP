# MY SHOP V646 / 2.9.646 — Phase 1: animation advertisements

## Authorized scope and actual source
Continued from the saved V-645-MY-SHOP-FULL-SOURCE.zip, not a restart. Owner authorized Phase 1 only on 2026-10-18 after reviewing video 143344.mp4 and page references. Agora, audio/video seats, new Go Live setup and revised 10-second/multiple-claim gift boxes belong to later phases. No production deployment or remote repository mutation is authorized/performed here.

## Implemented
- Existing Admin → Live Management → এনিমেশন বিজ্ঞাপন retained, with Add/Edit, Draft Save, Enable/Disable, explicit Publish, date schedules, priorities, per-page placement and existing shared color wheel for background/start/end/text.
- Shared preview/runtime renderer: mini ads 48dp high; moving strips 30dp instead of old58dp. Dark gradient centre, fine illuminated border, moving light and small sparkles; one foreground queued advertisement at a time. Animation toggle suppresses card motion/shimmer/text marquee and local product playback.
- Membership loads actual selected tier frame from bundled membership_v603, not excluded legacy membership_v600. Avatar frames include a centred sample portrait. Chat ads use the actual selected ChatBubble611 skin; Rider uses the existing ArticulatedRideView for bundled catalog rides, silently without modifying entry/gift sound. No new product, price or entitlement is invented.
- Rare ID has prominent actual ID number and actual Coin/Gold price, no crown. Automatic mode rotates available catalog numbers every2.4seconds; the tap opens the number actually displayed. Selected-only mode remains available. Disabled/deleted, owned/retired/held, reserved, existing-account and pending/processing/completed purchase IDs are excluded by server queries. Empty availability hides the ad. Current catalog updates enter the existing1s public cache and foreground feed.
- Gift announcement has actual sender portrait, sender/receiver names/IDs, gift/amount/currency and artwork. Preview is explicitly labelled Demo and never uses the old position-only title as a real event.
- Optional small gold WIN/Reward banner reads only the existing COMPLETED live reaction rewards. It does not mint coins, invent random winners or create a new gambling/reward mechanic. Only this existing server reward source is currently connected; other future reward engines require explicit integration. Reward history shown to Admin, bounded client dedup persisted across Activity recreation.
- Optional small animated microphone with adjustable position, width and colors through the same card controls; defaults disabled, no sound or microphone activation.
- Preview has a proportional native page/room backdrop, draggable long-press wrapper and replay button. Shared proportional bounds reserve right17% on Live for actions and bottom15% on all pages. This is a demo, not a real room. Precise appearance/touch safety across real phones still requires acceptance.
- Existing pages are live_room/home/live/shop; independent normalized placements and visibility persist on server. Existing draft/publish CAS, auth, audit, gift transaction outbox, expiry, bounded queue, gift event dedup and one-ID-once box rules retained. No financial/box schema migration in this release.
- Chat portrait remains vertically centred from V645. Old retired mini-card classes remain absent; old financial/history data remains intact.

## Preservation
AudioLiveRoomActivity, MainActivity, LiveHomeActivity, PhysicalStoreActivity, ChatComment640, GiftPanel613 and unrelated Store/RTC/ledger code remain byte-identical to V645. Worker index.js changes only release identity. Updated historical preservation test normalizes V646 version metadata only; no behavior exclusion was added. Full regression, exact implementation fingerprints and APK DEX verification are included.

## Build and continuation
Use JDK17, Gradle8.11.1, SDK36 and existing original signing/Firebase setup. Read BUILD-ASSETS-BN.md, SIGNING-SETUP.md and GITHUB-UPLOAD-V646-BN.md. Unit tests MUST use -PmyshopOfflineTests (debug-only localhost override); release URL unchanged. Commands:
- bash tools/v646_target_verify.sh
- bash gradlew clean :app:testDebugUnitTest :app:assembleRelease :app:lintRelease -PmyshopOfflineTests
- backend/worker: npm ci; Wrangler deploy --dry-run only for bundle verification.
Existing backend dependencies unchanged. Existing0059 migration and Store/Live schema must already be initialized; no database reset or new migration. Deploy the same Worker release only after authorized staging acceptance. The feed still uses foreground HTTP polling2s Live/5s other pages, not a newly implemented push socket.

## Verification and limits
Final measured results are in verification/V646-RESULTS.json and verification/V646-final-summary.md. Do not use historical V645 logs as evidence for V646. An intermediate incremental compilation used stale copied classes; final verification must use the clean/recompiled source and DEX checks. The ad-only local artwork decoder handles local static images even when animation is disabled; it limits decoded art to128px without touching the shared loader.
No original signing key is available here; no original-signed APK is delivered. No real-phone, multi-room latency, production D1/Worker or Play submission acceptance is claimed. Keep existing132 source-proven inherited lint errors in the existing V644 baseline; new errors must remain fatal. Runtime media/native RTC assets are retained; APK remains large. No forced deletion to meet an APK size target.

## Next phases (not implemented)
Phase2: reference-style pre-live screen, profile-sourced identity, bottom Audio/Video switch, small seat thumbnails, Audio4/6/8/12/18, in-room More; Video preview only unless separately authorized.
Phase3: server-snapshot boxes appearing for10seconds with1–5 winners per room chosen by Admin, one user once per publication; then separately approved real Agora video/PK. Future VPS migration needs a media server; keep provider connection behind an adapter when implementing Video. Do not claim the current old V645 single-winner10–300s box already follows the new rule.
Next changed delivery V647. Continue from this complete V646 source and saved proof, not V644/V645 or a partial checkpoint.
