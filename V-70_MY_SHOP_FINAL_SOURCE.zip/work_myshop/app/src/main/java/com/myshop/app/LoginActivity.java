package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.app.AlertDialog;
import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** V-54: MY SHOP + LIVE login; backend role check is authoritative. */
public class LoginActivity extends AppCompatActivity {
    private static final String BRAND = "MY SHOP";
    private EditText loginId;
    private EditText loginPassword;
    private TextView emailTab, mobileTab, loginPrefix;
    private boolean mobileMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // V-47: preserve the existing account/session across normal app updates.
        // This only works when Android performs an in-place update with the same signing key.
        String existingId = SessionManager.getUserId(this);
        if (SessionManager.isLoggedIn(this) && !existingId.isEmpty() && AccountStore.exists(this, existingId)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        loginId = findViewById(R.id.loginId);
        loginPassword = findViewById(R.id.loginPassword);
        Button login = findViewById(R.id.loginButton);
        TextView create = findViewById(R.id.createAccountButton);
        TextView forgot = findViewById(R.id.forgotButton);
        ImageButton toggle = findViewById(R.id.passwordToggle);
        emailTab = findViewById(R.id.emailTab);
        mobileTab = findViewById(R.id.mobileTab);
        loginPrefix = findViewById(R.id.loginPrefix);
        emailTab.setOnClickListener(v -> setLoginMode(false));
        mobileTab.setOnClickListener(v -> setLoginMode(true));
        setLoginMode(false);

        create.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
        login.setOnClickListener(v -> login());
        forgot.setOnClickListener(v -> showPasswordResetBox());
        toggle.setOnClickListener(v -> {
            int pos = loginPassword.getSelectionStart();
            boolean hidden = (loginPassword.getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) != 0;
            loginPassword.setInputType(InputType.TYPE_CLASS_TEXT | (hidden ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            loginPassword.setSelection(Math.max(0, pos));
        });
    }

    private void showPasswordResetBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int)(18 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad, pad, pad);

        TextView info = new TextView(this);
        info.setText("Security Question + 2-of-3 Password Reset\n৩টির মধ্যে যেকোনো ২টি উত্তর সঠিক হলে নতুন Password সেট হবে।");
        info.setTextColor(Color.rgb(25,31,45));
        info.setTextSize(14);
        box.addView(info, new LinearLayout.LayoutParams(-1, -2));

        EditText identifier = new EditText(this);
        identifier.setHint("Email / Mobile / User ID");
        box.addView(identifier, new LinearLayout.LayoutParams(-1, dp(56)));

        String[] questions = AccountStore.getSecurityQuestions(this, identifier.getText().toString().trim());
        TextView hint = new TextView(this);
        hint.setText("প্রথমে আপনার Email/Mobile/User ID দিন, তারপর নিচের ৩টি উত্তর দিন।");
        hint.setTextColor(Color.DKGRAY);
        hint.setTextSize(12);
        box.addView(hint, new LinearLayout.LayoutParams(-1, -2));

        EditText a1 = answerField("Security Answer 1");
        EditText a2 = answerField("Security Answer 2");
        EditText a3 = answerField("Security Answer 3");
        box.addView(a1); box.addView(a2); box.addView(a3);

        EditText newPass = answerField("New Password (6+ characters)");
        newPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText confirm = answerField("Confirm New Password");
        confirm.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(newPass); box.addView(confirm);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Forgot Password")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("RESET PASSWORD", null)
                .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String id = identifier.getText().toString().trim();
            if (id.isEmpty()) { Toast.makeText(this, "Email/Mobile/User ID দিন।", Toast.LENGTH_SHORT).show(); return; }
            String np = newPass.getText().toString();
            if (np.length() < 6 || !np.equals(confirm.getText().toString())) { Toast.makeText(this, "New password ঠিকভাবে দিন।", Toast.LENGTH_SHORT).show(); return; }
            boolean ok = AccountStore.resetPasswordWithTwoOfThree(this, id,
                    new String[]{a1.getText().toString(), a2.getText().toString(), a3.getText().toString()}, np);
            if (ok) { Toast.makeText(this, "Password reset সফল হয়েছে। এখন নতুন Password দিয়ে Login করুন।", Toast.LENGTH_LONG).show(); dialog.dismiss(); }
            else Toast.makeText(this, "৩টির মধ্যে অন্তত ২টি Security Answer সঠিক হয়নি।", Toast.LENGTH_LONG).show();
        }));
        dialog.show();
    }

    private EditText answerField(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setPadding(dp(10), 0, dp(10), 0);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54));
        p.topMargin = dp(7);
        e.setLayoutParams(p);
        return e;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void setLoginMode(boolean mobile) {
        mobileMode = mobile;
        if (mobile) {
            loginId.setHint("1XXXXXXXXX");
            loginId.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
            loginPrefix.setText("+880  ▾");
            loginPrefix.setVisibility(TextView.VISIBLE);
            mobileTab.setTextColor(android.graphics.Color.WHITE);
            mobileTab.setBackgroundResource(com.myshop.app.R.drawable.bg_mobile_active);
            emailTab.setTextColor(android.graphics.Color.DKGRAY);
            emailTab.setBackgroundResource(com.myshop.app.R.drawable.bg_email_inactive);
        } else {
            loginId.setHint("enter@example.com");
            loginId.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
            loginPrefix.setText("");
            loginPrefix.setVisibility(TextView.GONE);
            emailTab.setTextColor(android.graphics.Color.WHITE);
            emailTab.setBackgroundResource(com.myshop.app.R.drawable.bg_email_tab);
            mobileTab.setTextColor(android.graphics.Color.DKGRAY);
            mobileTab.setBackgroundResource(com.myshop.app.R.drawable.bg_mobile_tab);
        }
    }

    private void login() {
        String identifier = loginId.getText().toString().trim();
        String pass = loginPassword.getText().toString();
        if (identifier.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Email/Mobile and Password are required.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            AccountStore.Account account = AccountStore.authenticate(this, identifier, pass);
            if (account == null && mobileMode && !identifier.startsWith("+880")) {
                account = AccountStore.authenticate(this, "+880" + identifier, pass);
            }
            if (account == null) {
                Toast.makeText(this, "Login failed. Check your Email/Mobile and Password.", Toast.LENGTH_LONG).show();
                return;
            }
            Role role = AdminIdentifiers.isAdminIdentifier(identifier) ? Role.ADMIN : Role.USER;
            SessionManager.setSession(this, role, account.userId);
            SessionManager.saveProfile(this, account.name, account.email, account.mobile);
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        } catch (Throwable t) {
            Toast.makeText(this, "Login failed safely. Your account data was not changed.", Toast.LENGTH_LONG).show();
        }
    }
}
