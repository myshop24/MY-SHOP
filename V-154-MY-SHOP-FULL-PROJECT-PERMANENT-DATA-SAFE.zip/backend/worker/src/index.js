const json = (data, status = 200, extra = {}) => new Response(JSON.stringify(data), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", ...extra }
});

const cors = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET,POST,PUT,DELETE,OPTIONS",
  "access-control-allow-headers": "Content-Type, Authorization"
};

function normalizeEmail(v) { return String(v || '').trim().toLowerCase(); }
function normalizeMobile(v) { return String(v || '').trim().replace(/[\s()-]/g, ''); }
function normalizeAnswer(v) { return String(v || '').trim().toLowerCase(); }
function isFourDigit(v) { return /^\d{4}$/.test(String(v || '')); }

function bytesToHex(bytes) { return [...new Uint8Array(bytes)].map(b => b.toString(16).padStart(2,'0')).join(''); }
function hexToBytes(hex) { const out = new Uint8Array(hex.length / 2); for (let i=0;i<out.length;i++) out[i]=parseInt(hex.slice(i*2,i*2+2),16); return out; }

async function sha256(text) {
  return bytesToHex(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)));
}

const PBKDF2_ITERATIONS = 100000;

async function pbkdf2(password, saltHex, iterations = PBKDF2_ITERATIONS) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({name:'PBKDF2', salt:hexToBytes(saltHex), iterations, hash:'SHA-256'}, key, 256);
  return bytesToHex(bits);
}

function randomHex(bytes = 16) {
  const a = new Uint8Array(bytes); crypto.getRandomValues(a); return bytesToHex(a);
}

function guessContentType(file) {
  const raw=String(file?.type||'').toLowerCase().trim();
  if(raw) return raw;
  const name=String(file?.name||'').toLowerCase();
  const ext=name.includes('.')?name.split('.').pop():'';
  const map={jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webp:'image/webp',gif:'image/gif',bmp:'image/bmp',heic:'image/heic',heif:'image/heif',mp3:'audio/mpeg',wav:'audio/wav',m4a:'audio/mp4',aac:'audio/aac',ogg:'audio/ogg',mp4:'video/mp4',webm:'video/webm',mov:'video/quicktime',mkv:'video/x-matroska'};
  return map[ext]||'application/octet-stream';
}

async function hashPassword(password) {
  const salt = randomHex(16);
  const iterations = PBKDF2_ITERATIONS;
  const digest = await pbkdf2(password, salt, iterations);
  return `pbkdf2_sha256$${iterations}$${salt}$${digest}`;
}

async function verifyPassword(password, stored) {
  const p = String(stored || '').split('$');
  if (p.length !== 4 || p[0] !== 'pbkdf2_sha256') return false;
  const digest = await pbkdf2(password, p[2], Number(p[1]));
  return digest === p[3];
}

async function ensureAuthSchema(env) {
  // Additive-only and fault-tolerant. Existing user/auth data is never dropped or cleared.
  const statements = [
    `CREATE TABLE IF NOT EXISTS myshop_auth_users_v108 (user_id TEXT PRIMARY KEY CHECK(length(user_id)=4),full_name TEXT NOT NULL,email TEXT UNIQUE,mobile TEXT UNIQUE,password_hash TEXT NOT NULL,security_q1 TEXT NOT NULL,security_a1_hash TEXT NOT NULL,security_q2 TEXT NOT NULL,security_a2_hash TEXT NOT NULL,security_q3 TEXT NOT NULL,security_a3_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'USER' CHECK(role IN ('USER','ADMIN','MODERATOR')),active INTEGER NOT NULL DEFAULT 1,avatar_url TEXT NOT NULL DEFAULT '',avatar_object_key TEXT NOT NULL DEFAULT '',bio TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_myshop_auth_email ON myshop_auth_users_v108(email) WHERE email IS NOT NULL AND email <> ''`,
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_myshop_auth_mobile ON myshop_auth_users_v108(mobile) WHERE mobile IS NOT NULL AND mobile <> ''`,
    `CREATE TABLE IF NOT EXISTS myshop_auth_sessions_v108 (token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id) ON DELETE CASCADE,expires_at INTEGER NOT NULL,created_at INTEGER NOT NULL)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_auth_sessions_v108_user ON myshop_auth_sessions_v108(user_id)`,
    `CREATE TABLE IF NOT EXISTS myshop_moderators_v108 (user_id TEXT PRIMARY KEY REFERENCES myshop_auth_users_v108(user_id) ON DELETE CASCADE,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`
  ];
  for (const sql of statements) { try { await env.DB.prepare(sql).run(); } catch (_) {} }
  try { await migratePreviousAuthIfPresent(env); } catch (_) {}
}

async function migratePreviousAuthIfPresent(env) {
  // V-107 may have created the old auth table before a deployment failed.
  // Copy compatible rows forward; never delete or modify the old table.
  try {
    await env.DB.prepare(`INSERT OR IGNORE INTO myshop_auth_users_v108
      (user_id,full_name,email,mobile,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role,active,created_at,updated_at)
      SELECT user_id,full_name,email,mobile,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role,active,created_at,updated_at
      FROM myshop_auth_users`).run();
  } catch (_) {
    // Old table may not exist or may have an incompatible schema. Leave it untouched.
  }
}

async function createSession(env, userId) {
  const raw = `${crypto.randomUUID()}-${randomHex(16)}`;
  const hash = await sha256(raw);
  const days = Math.max(1, Number(env.SESSION_DAYS || 30));
  const expires = Date.now() + days * 86400000;
  await env.DB.prepare('INSERT INTO myshop_auth_sessions_v108(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)')
    .bind(hash, userId, expires, Date.now()).run();
  return raw;
}

async function getUser(request, env) {
  const auth = request.headers.get('authorization') || '';
  if (!auth.toLowerCase().startsWith('bearer ')) return null;
  const raw = auth.slice(7).trim();
  if (!raw) return null;
  const hash = await sha256(raw);
  const row = await env.DB.prepare(`SELECT u.* FROM myshop_auth_sessions_v108 s JOIN myshop_auth_users_v108 u ON u.user_id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.active=1`).bind(hash, Date.now()).first();
  return row || null;
}

function publicUser(u) {
  return { userId:u.user_id, name:u.full_name, email:u.email || '', mobile:u.mobile || '', role:u.role, avatarUrl:u.avatar_url || '', bio:u.bio || '' };
}

async function body(request) {
  try { return await request.json(); } catch { return {}; }
}

async function findAuthUser(env, identifier) {
  const id = String(identifier || '').trim();
  let user = null;
  if (isFourDigit(id)) user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(id).first();
  if (!user && id.includes('@')) user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE email=? AND active=1').bind(normalizeEmail(id)).first();
  if (!user) user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE mobile=? AND active=1').bind(normalizeMobile(id)).first();
  return user;
}

async function register(request, env) {
  const b = await body(request);
  const name = String(b.name || '').trim();
  const email = normalizeEmail(b.email);
  const mobile = normalizeMobile(b.mobile);
  const password = String(b.password || '');
  const securityQuestion = String(b.securityQuestion || (Array.isArray(b.securityQuestions) ? b.securityQuestions[0] : '') || '').trim();
  const securityAnswer = String(b.securityAnswer || (Array.isArray(b.securityAnswers) ? b.securityAnswers[0] : '') || '').trim();
  if (!name || (!email && !mobile) || password.length < 6 || !securityQuestion || !securityAnswer) return json({error:'INVALID_INPUT'},400,cors);
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({error:'INVALID_EMAIL'},400,cors);

  const duplicate = await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE (?<>'' AND email=?) OR (?<>'' AND mobile=?) LIMIT 1`)
    .bind(email,email,mobile,mobile).first();
  if (duplicate) return json({error:'ACCOUNT_EXISTS'},409,cors);

  // Keep legacy users untouched, but block duplicate identifiers that already exist there.
  try {
    const legacy = await env.DB.prepare(`SELECT id FROM users WHERE (?<>'' AND lower(email)=?) OR (?<>'' AND mobile=?) LIMIT 1`)
      .bind(email,email,mobile,mobile).first();
    if (legacy) return json({error:'ACCOUNT_EXISTS'},409,cors);
  } catch (_) { /* legacy table may not exist on a fresh database */ }

  const adminMap = {
    'myshopsatkania@gmail.com': '0001',
    'touhidsatkania@gmail.com': '0002',
    '01860626700': '0003'
  };
  const adminId = adminMap[email] || adminMap[mobile] || '';
  const role = adminId ? 'ADMIN' : 'USER';
  let userId = adminId;
  if (!userId) {
    const next = await env.DB.prepare(`SELECT COALESCE(MAX(CAST(user_id AS INTEGER))+1,100) AS n FROM myshop_auth_users_v108 WHERE CAST(user_id AS INTEGER) >= 100`).first();
    const n = Number(next?.n || 100);
    if (n > 9999) return json({error:'NO_ID_AVAILABLE'},409,cors);
    userId = String(n).padStart(4,'0');
  } else {
    const occupied = await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=?').bind(userId).first();
    if (occupied) return json({error:'ACCOUNT_EXISTS'},409,cors);
  }

  const ph = await hashPassword(password);
  const answerHash = await sha256(normalizeAnswer(securityAnswer));
  // Keep the existing 3-question columns for backward compatibility. New accounts use only q1/a1.
  await env.DB.prepare(`INSERT INTO myshop_auth_users_v108(user_id,full_name,email,mobile,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).bind(userId,name,email||null,mobile||null,ph,securityQuestion,answerHash,'','', '','',role).run();

  const user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=?').bind(userId).first();
  const token = await createSession(env, userId);
  return json({ok:true,user:publicUser(user),token},201,cors);
}

async function login(request, env) {
  const b = await body(request);
  const id = String(b.identifier || '').trim();
  const password = String(b.password || '');
  if (!id || !password) return json({error:'INVALID_INPUT'},400,cors);
  const user = await findAuthUser(env,id);
  if (!user || !(await verifyPassword(password,user.password_hash))) return json({error:'INVALID_CREDENTIALS'},401,cors);
  const adminMap = {'myshopsatkania@gmail.com':'0001','touhidsatkania@gmail.com':'0002','01860626700':'0003'};
  const mappedAdminId = adminMap[normalizeEmail(id)] || adminMap[normalizeMobile(id)] || (isFourDigit(id) && ['0001','0002','0003'].includes(id) ? id : '');
  if (mappedAdminId && user.user_id === mappedAdminId && user.role !== 'ADMIN') {
    await env.DB.prepare("UPDATE myshop_auth_users_v108 SET role='ADMIN', updated_at=CURRENT_TIMESTAMP WHERE user_id=?").bind(mappedAdminId).run();
    user.role = 'ADMIN';
  }
  const token = await createSession(env,user.user_id);
  return json({ok:true,user:publicUser(user),token},200,cors);
}

async function me(request, env) {
  const user = await getUser(request,env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  return json({ok:true,user:publicUser(user)},200,cors);
}

async function logout(request, env) {
  const auth = request.headers.get('authorization') || '';
  if (auth.toLowerCase().startsWith('bearer ')) await env.DB.prepare('DELETE FROM myshop_auth_sessions_v108 WHERE token_hash=?').bind(await sha256(auth.slice(7).trim())).run();
  return json({ok:true},200,cors);
}

async function securityQuestions(request, env) {
  const id = String(new URL(request.url).searchParams.get('identifier') || '').trim();
  const user = await findAuthUser(env,id);
  if (!user) return json({error:'NOT_FOUND'},404,cors);
  return json({ok:true,question:user.security_q1},200,cors);
}

async function resetPassword(request, env) {
  const b = await body(request);
  const id = String(b.identifier || '').trim();
  const answer = String(b.answer || (Array.isArray(b.answers) ? b.answers[0] : '') || '').trim();
  const newPassword = String(b.newPassword || '');
  if (!id || !answer || newPassword.length < 6) return json({error:'INVALID_INPUT'},400,cors);
  const user = await findAuthUser(env,id);
  if (!user) return json({error:'NOT_FOUND'},404,cors);
  const answerHash = await sha256(normalizeAnswer(answer));
  if (!user.security_a1_hash || user.security_a1_hash !== answerHash) return json({error:'ANSWER_NOT_MATCHED'},403,cors);
  const ph = await hashPassword(newPassword);
  await env.DB.prepare('UPDATE myshop_auth_users_v108 SET password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(ph,user.user_id).run();
  await env.DB.prepare('DELETE FROM myshop_auth_sessions_v108 WHERE user_id=?').bind(user.user_id).run();
  return json({ok:true,userId:user.user_id},200,cors);
}


async function ensureContentSchema(env) {
  // Additive-only content schema. Each statement is isolated so one old/incompatible
  // index cannot turn every Admin request into SERVER_ERROR.
  const statements = [
    `CREATE TABLE IF NOT EXISTS gallery_items (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL DEFAULT '',media_url TEXT NOT NULL DEFAULT '',media_type TEXT NOT NULL DEFAULT 'image',active INTEGER NOT NULL DEFAULT 1,display_order INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_gallery_active_order ON gallery_items(active,display_order)`,
    `CREATE TABLE IF NOT EXISTS feature_buttons (key TEXT PRIMARY KEY,title TEXT NOT NULL DEFAULT '',icon_url TEXT NOT NULL DEFAULT '',target_url TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,display_order INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_feature_buttons_active_order ON feature_buttons(active,display_order)`,
    `CREATE TABLE IF NOT EXISTS gallery_media (id INTEGER PRIMARY KEY AUTOINCREMENT,folder TEXT NOT NULL,title TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',media_url TEXT NOT NULL DEFAULT '',object_key TEXT NOT NULL DEFAULT '',media_type TEXT NOT NULL DEFAULT 'image',active INTEGER NOT NULL DEFAULT 1,display_order INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_gallery_media_folder_order ON gallery_media(folder,active,display_order,id)`,
    `CREATE TABLE IF NOT EXISTS dashboard_ads (id INTEGER PRIMARY KEY AUTOINCREMENT,box_key TEXT NOT NULL,slot INTEGER NOT NULL,image_url TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',target_url TEXT NOT NULL DEFAULT '',object_key TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(box_key,slot))`,
    `CREATE INDEX IF NOT EXISTS idx_dashboard_ads_box ON dashboard_ads(box_key,active,slot,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_posts (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id),caption TEXT NOT NULL DEFAULT '',media_url TEXT NOT NULL DEFAULT '',object_key TEXT NOT NULL DEFAULT '',media_type TEXT NOT NULL DEFAULT 'image',status TEXT NOT NULL DEFAULT 'ACTIVE',moderated_by TEXT NOT NULL DEFAULT '',moderated_at TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_posts_feed ON myshop_posts(status,created_at DESC,id DESC)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_posts_user_day ON myshop_posts(user_id,created_at DESC,id DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_post_likes (post_id INTEGER NOT NULL,user_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(post_id,user_id))`,
    `CREATE TABLE IF NOT EXISTS myshop_post_comments (id INTEGER PRIMARY KEY AUTOINCREMENT,post_id INTEGER NOT NULL,user_id TEXT NOT NULL,comment TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS managed_links (id INTEGER PRIMARY KEY AUTOINCREMENT,category TEXT NOT NULL,title TEXT NOT NULL DEFAULT '',url TEXT NOT NULL DEFAULT '',icon_url TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,display_order INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_managed_links_category_order ON managed_links(category,active,display_order,id)`,
    `CREATE TABLE IF NOT EXISTS banner_media (id INTEGER PRIMARY KEY AUTOINCREMENT,folder TEXT NOT NULL,slot INTEGER NOT NULL,object_key TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(folder,slot))`,
    `CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL DEFAULT 'MY SHOP',message TEXT NOT NULL DEFAULT '',audience TEXT NOT NULL DEFAULT 'ALL',user_id TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at DESC,id DESC)`,
    `CREATE INDEX IF NOT EXISTS idx_notifications_audience_user ON notifications(audience,user_id,created_at DESC)`,
    `CREATE TABLE IF NOT EXISTS notification_reads (notification_id INTEGER NOT NULL,user_id TEXT NOT NULL,read_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(notification_id,user_id))`,
    `CREATE INDEX IF NOT EXISTS idx_notification_reads_user ON notification_reads(user_id,read_at DESC)`,
    `CREATE TABLE IF NOT EXISTS dashboard_config (id INTEGER PRIMARY KEY CHECK(id=1),breaking_news TEXT NOT NULL DEFAULT '',my_shop_url TEXT NOT NULL DEFAULT '',live_tv_url TEXT NOT NULL DEFAULT '',external_movie_url TEXT NOT NULL DEFAULT '',chat_url TEXT NOT NULL DEFAULT '',power_ad_title TEXT NOT NULL DEFAULT 'POWER AD',power_ad_byline TEXT NOT NULL DEFAULT 'by Touhid',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS banners (id INTEGER PRIMARY KEY AUTOINCREMENT,folder TEXT NOT NULL,slot INTEGER NOT NULL,image_url TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(folder,slot))`,
    `CREATE TABLE IF NOT EXISTS social_links (id INTEGER PRIMARY KEY AUTOINCREMENT,platform TEXT NOT NULL UNIQUE,url TEXT NOT NULL DEFAULT '',icon_key TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1)`,
    `CREATE TABLE IF NOT EXISTS myshop_coin_wallets (user_id TEXT PRIMARY KEY REFERENCES myshop_auth_users_v108(user_id),balance INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_coin_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id),kind TEXT NOT NULL,amount INTEGER NOT NULL,reference TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'COMPLETED',metadata TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_coin_transactions_user ON myshop_coin_transactions(user_id,created_at,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_coin_purchase_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id),package_coins INTEGER NOT NULL,amount_minor INTEGER NOT NULL,payment_method TEXT NOT NULL,reference TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_coin_purchase_user ON myshop_coin_purchase_requests(user_id,created_at,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_gift_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT,sender_user_id TEXT NOT NULL,receiver_user_id TEXT NOT NULL,coins INTEGER NOT NULL,gift_code TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`
  ];
  for (const sql of statements) { try { await env.DB.prepare(sql).run(); } catch (_) {} }
  try { await env.DB.prepare(`INSERT OR IGNORE INTO dashboard_config(id) VALUES(1)`).run(); } catch (_) {}
  const defaults=[
    ['my_feed','MY FEED','', '',1,1],['live_now','LIVE','', '',1,2],['go_live','GO LIVE','', '',1,3],['live_tv','LIVE TV','', '',1,4],
    ['my_shop','MY SHOP','', '',1,5],['external_movie','EXTERNAL MOVIE','', '',1,6],['gallery','GALLERY','', '',1,7],['social_media','SOCIAL MEDIA','', '',1,8]
  ];
  for (const d of defaults) { try { await env.DB.prepare(`INSERT OR IGNORE INTO feature_buttons(key,title,icon_url,target_url,active,display_order) VALUES(?,?,?,?,?,?)`).bind(...d).run(); } catch (_) {} }
  try { await repairContentSchema(env); } catch (_) {}
}

async function createBroadcastNotification(env,title,message){
  try {
    await env.DB.prepare(`INSERT INTO notifications(title,message,audience,user_id,created_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)`).bind(String(title||'MY SHOP'),String(message||''),'ALL','').run();
  } catch (_) {}
}

async function notificationsList(request,env){
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  const rows=await env.DB.prepare(`SELECT n.id,n.title,n.message,n.created_at,CASE WHEN r.notification_id IS NULL THEN 0 ELSE 1 END AS is_read FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? WHERE (n.audience='ALL' OR (n.audience='USER' AND n.user_id=?)) ORDER BY n.id DESC LIMIT 50`).bind(user.user_id,user.user_id).all();
  const unread=await env.DB.prepare(`SELECT COUNT(*) AS c FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? WHERE (n.audience='ALL' OR (n.audience='USER' AND n.user_id=?)) AND r.notification_id IS NULL`).bind(user.user_id,user.user_id).first();
  return json({ok:true,unreadCount:Number(unread?.c||0),notifications:(rows.results||[]).map(x=>({id:x.id,title:x.title,message:x.message,createdAt:x.created_at,isRead:Number(x.is_read||0)}))},200,cors);
}

async function notificationsReadAll(request,env){
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  await env.DB.prepare(`INSERT OR IGNORE INTO notification_reads(notification_id,user_id,read_at) SELECT n.id,?,CURRENT_TIMESTAMP FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? WHERE (n.audience='ALL' OR (n.audience='USER' AND n.user_id=?)) AND r.notification_id IS NULL`).bind(user.user_id,user.user_id,user.user_id).run();
  return json({ok:true,unreadCount:0},200,cors);
}


async function ensureColumn(env, table, column, definition) {
  // D1 keeps existing tables when CREATE TABLE IF NOT EXISTS is reused.
  // Repair only missing content columns; never drop/reset user data.
  try {
    const info = await env.DB.prepare(`PRAGMA table_info(${table})`).all();
    const found = (info.results || []).some(r => String(r.name || '') === column);
    if (!found) await env.DB.prepare(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`).run();
  } catch (_) {}
}

async function repairContentSchema(env) {
  await ensureColumn(env,'myshop_auth_users_v108','avatar_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'myshop_auth_users_v108','avatar_object_key',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'myshop_auth_users_v108','bio',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'myshop_auth_users_v108','updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`);
  await ensureColumn(env,'dashboard_config','breaking_news',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'dashboard_config','my_shop_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'dashboard_config','live_tv_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'dashboard_config','external_movie_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'dashboard_config','chat_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'dashboard_config','power_ad_title',`TEXT NOT NULL DEFAULT 'POWER AD'`);
  await ensureColumn(env,'dashboard_config','power_ad_byline',`TEXT NOT NULL DEFAULT 'by Touhid'`);
  await ensureColumn(env,'dashboard_config','updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`);

  await ensureColumn(env,'banners','image_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'banners','caption',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'banners','active',`INTEGER NOT NULL DEFAULT 1`);
  await ensureColumn(env,'banners','updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`);

  await ensureColumn(env,'gallery_media','caption',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'gallery_media','object_key',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'gallery_media','media_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'gallery_media','media_type',`TEXT NOT NULL DEFAULT 'image'`);
  await ensureColumn(env,'gallery_media','active',`INTEGER NOT NULL DEFAULT 1`);
  await ensureColumn(env,'gallery_media','display_order',`INTEGER NOT NULL DEFAULT 1`);
  await ensureColumn(env,'gallery_media','updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`);
  // Ownership is nullable so every existing gallery row remains untouched and visible to Admin.
  await ensureColumn(env,'gallery_media','owner_user_id',`TEXT`);
  try { await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_gallery_media_owner ON gallery_media(owner_user_id,folder,active,updated_at)').run(); } catch (_) {}
  try { await env.DB.prepare(`CREATE TABLE IF NOT EXISTS dashboard_ads (id INTEGER PRIMARY KEY AUTOINCREMENT,box_key TEXT NOT NULL,slot INTEGER NOT NULL,image_url TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',target_url TEXT NOT NULL DEFAULT '',object_key TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(box_key,slot))`).run(); } catch (_) {}
  try { await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_dashboard_ads_box ON dashboard_ads(box_key,active,slot,id)').run(); } catch (_) {}
  try { await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_posts (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id),caption TEXT NOT NULL DEFAULT '',media_url TEXT NOT NULL DEFAULT '',object_key TEXT NOT NULL DEFAULT '',media_type TEXT NOT NULL DEFAULT 'image',status TEXT NOT NULL DEFAULT 'ACTIVE',moderated_by TEXT NOT NULL DEFAULT '',moderated_at TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run(); } catch (_) {}
  try { await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_myshop_posts_feed ON myshop_posts(status,created_at DESC,id DESC)').run(); } catch (_) {}
  try { await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_myshop_posts_user_day ON myshop_posts(user_id,created_at DESC,id DESC)').run(); } catch (_) {}
  try { await env.DB.prepare('CREATE TABLE IF NOT EXISTS myshop_post_likes (post_id INTEGER NOT NULL,user_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(post_id,user_id))').run(); } catch (_) {}
  try { await env.DB.prepare('CREATE TABLE IF NOT EXISTS myshop_post_comments (id INTEGER PRIMARY KEY AUTOINCREMENT,post_id INTEGER NOT NULL,user_id TEXT NOT NULL,comment TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)').run(); } catch (_) {}

  await ensureColumn(env,'banner_media','object_key',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'banner_media','updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`);

  await ensureColumn(env,'managed_links','icon_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'managed_links','active',`INTEGER NOT NULL DEFAULT 1`);
  await ensureColumn(env,'managed_links','display_order',`INTEGER NOT NULL DEFAULT 1`);
  await ensureColumn(env,'managed_links','updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`);
  await ensureColumn(env,'social_links','icon_key',`TEXT NOT NULL DEFAULT ''`);
}

async function ensureDashboardConfigSchema(env) {
  try { await env.DB.prepare(`CREATE TABLE IF NOT EXISTS dashboard_config (id INTEGER PRIMARY KEY CHECK(id=1),breaking_news TEXT NOT NULL DEFAULT '',my_shop_url TEXT NOT NULL DEFAULT '',live_tv_url TEXT NOT NULL DEFAULT '',external_movie_url TEXT NOT NULL DEFAULT '',chat_url TEXT NOT NULL DEFAULT '',power_ad_title TEXT NOT NULL DEFAULT 'POWER AD',power_ad_byline TEXT NOT NULL DEFAULT 'by Touhid',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run(); } catch (_) {}
  try { await env.DB.prepare(`INSERT OR IGNORE INTO dashboard_config(id) VALUES(1)`).run(); } catch (_) {}
  await repairContentSchema(env);
}

async function deepHealth(env) {
  const result={ok:true,service:'my-shop-api',database:'unknown',r2:'unknown',schema:'unknown',time:new Date().toISOString()};
  try {
    await env.DB.prepare('SELECT 1').first();
    result.database='ok';
    const tables=['dashboard_config','banners','gallery_media','banner_media','dashboard_ads','feature_buttons','social_links','managed_links','notifications','notification_reads','myshop_coin_wallets','myshop_coin_transactions','myshop_coin_purchase_requests','myshop_posts','myshop_post_likes','myshop_post_comments'];
    for (const table of tables) {
      await env.DB.prepare(`SELECT 1 FROM ${table} LIMIT 1`).first();
    }
    result.schema='ok';
  } catch (e) {
    result.ok=false; result.database=result.database==='ok'?'ok':'error'; result.schema='error'; result.databaseMessage=String(e?.message||e).slice(0,180);
  }
  try {
    if (!env.MEDIA) throw new Error('R2 binding MEDIA is missing');
    await env.MEDIA.list({limit:1});
    result.r2='ok';
  } catch (e) {
    result.ok=false; result.r2='error'; result.r2Message=String(e?.message||e).slice(0,180);
  }
  return result;
}

async function dashboardConfig(request, env) {
  let config={}; let banners=[]; let socialLinks=[]; let gallery=[]; let featureButtons=[]; let managedLinks=[]; let media=[];
  try { config=(await env.DB.prepare('SELECT * FROM dashboard_config WHERE id=1').first())||{}; } catch (_) {}
  try { banners=(await env.DB.prepare('SELECT id,folder,slot,image_url,caption,active FROM banners WHERE active=1 ORDER BY folder,slot').all()).results||[]; } catch (_) {}
  try { socialLinks=(await env.DB.prepare('SELECT platform,url,active,icon_key FROM social_links WHERE active=1 ORDER BY platform').all()).results||[]; } catch (_) {}
  try { gallery=(await env.DB.prepare('SELECT id,title,media_url,media_type,active,display_order FROM gallery_items WHERE active=1 ORDER BY display_order,id').all()).results||[]; } catch (_) {}
  try { featureButtons=(await env.DB.prepare('SELECT key,title,icon_url,target_url,active,display_order FROM feature_buttons ORDER BY display_order,key').all()).results||[]; } catch (_) {}
  try { managedLinks=(await env.DB.prepare('SELECT id,category,title,url,icon_url,active,display_order FROM managed_links ORDER BY category,display_order,id').all()).results||[]; } catch (_) {}
  try { media=(await env.DB.prepare('SELECT id,folder,title,caption,media_url,object_key,media_type,active,display_order FROM gallery_media WHERE active=1 ORDER BY folder,display_order,id').all()).results||[]; } catch (_) {}
  let dashboardAds=[];
  try { dashboardAds=(await env.DB.prepare('SELECT id,box_key,slot,image_url,caption,target_url,active FROM dashboard_ads WHERE active=1 ORDER BY box_key,slot').all()).results||[]; } catch (_) {}
  return json({ok:true,config,banners,socialLinks,gallery,featureButtons,managedLinks,media,dashboardAds},200,cors);
}

async function adminOnly(request, env) {
  const user = await getUser(request,env);
  if (!user) return {error:json({error:'ADMIN_REQUIRED'},403,cors)};
  const fixedAdmin = ['0001','0002','0003'].includes(String(user.user_id));
  if (fixedAdmin && user.role !== 'ADMIN') {
    await env.DB.prepare("UPDATE myshop_auth_users_v108 SET role='ADMIN', updated_at=CURRENT_TIMESTAMP WHERE user_id=?").bind(user.user_id).run();
    user.role = 'ADMIN';
  }
  if (user.role !== 'ADMIN') return {error:json({error:'ADMIN_REQUIRED'},403,cors)};
  return {user};
}

async function adminDashboardPut(request, env) {
  try { await ensureDashboardConfigSchema(env); } catch (_) {}
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const b = await body(request);
  await env.DB.prepare(`UPDATE dashboard_config SET breaking_news=?,my_shop_url=?,live_tv_url=?,external_movie_url=?,chat_url=?,power_ad_title=?,power_ad_byline=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`)
    .bind(String(b.breakingNews||''),String(b.myShopUrl||''),String(b.liveTvUrl||''),String(b.externalMovieUrl||''),String(b.chatUrl||''),String(b.powerAdTitle||'POWER AD').trim().slice(0,60)||'POWER AD',String(b.powerAdByline||'by Touhid').trim().slice(0,60)||'by Touhid').run();
  await createBroadcastNotification(env,'MY SHOP আপডেট','ড্যাশবোর্ডের কনটেন্ট আপডেট করা হয়েছে।');
  return json({ok:true},200,cors);
}

async function adminContentPut(request, env) {
  try { await ensureContentSchema(env); } catch (_) {}
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const b = await body(request);

  const banners = Array.isArray(b.banners) ? b.banners : [];
  for (const x of banners) {
    const folder=String(x.folder||'').trim().toLowerCase(); const slot=Number(x.slot||0);
    if (!['hero','promo'].includes(folder) || !Number.isInteger(slot) || slot<1 || slot>(folder==='hero'?6:3)) continue;
    const imageUrl=String(x.imageUrl||x.image_url||'').trim(); const caption=String(x.caption||'').trim(); const active=x.active===false?0:1;
    if(!imageUrl){ await env.DB.prepare('DELETE FROM banners WHERE folder=? AND slot=?').bind(folder,slot).run(); continue; }
    await env.DB.prepare(`INSERT INTO banners(folder,slot,image_url,caption,active,updated_at) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(folder,slot) DO UPDATE SET image_url=excluded.image_url,caption=excluded.caption,active=excluded.active,updated_at=CURRENT_TIMESTAMP`).bind(folder,slot,imageUrl,caption,active).run();
  }

  const social = Array.isArray(b.socialLinks) ? b.socialLinks : [];
  for (const x of social) {
    const platform=String(x.platform||'').trim(); if(!platform) continue;
    const url=String(x.url||'').trim(); const active=x.active===false?0:(url?1:0); const iconKey=String(x.iconKey||x.icon_key||platform).trim().toLowerCase().slice(0,40);
    if(!url){ await env.DB.prepare('DELETE FROM social_links WHERE platform=?').bind(platform).run(); continue; }
    await env.DB.prepare(`INSERT INTO social_links(platform,url,icon_key,active) VALUES(?,?,?,?) ON CONFLICT(platform) DO UPDATE SET url=excluded.url,icon_key=excluded.icon_key,active=excluded.active`).bind(platform,url,iconKey,active).run();
  }

  const gallery = Array.isArray(b.gallery) ? b.gallery : [];
  for (const x of gallery) {
    const title=String(x.title||'').trim(); const mediaUrl=String(x.mediaUrl||x.media_url||'').trim(); if(!mediaUrl) continue;
    const mediaType=String(x.mediaType||x.media_type||'image').trim()||'image'; const active=x.active===false?0:1; const order=Math.max(1,Number(x.displayOrder||1));
    const existing=await env.DB.prepare('SELECT id FROM gallery_items WHERE display_order=? LIMIT 1').bind(order).first();
    if(existing) await env.DB.prepare('UPDATE gallery_items SET title=?,media_url=?,media_type=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(title,mediaUrl,mediaType,active,existing.id).run();
    else await env.DB.prepare('INSERT INTO gallery_items(title,media_url,media_type,active,display_order) VALUES(?,?,?,?,?)').bind(title,mediaUrl,mediaType,active,order).run();
  }

  const features = Array.isArray(b.featureButtons) ? b.featureButtons : [];
  for (const x of features) {
    const key=String(x.key||'').trim(); if(!key) continue;
    const title=String(x.title||'').trim(); const iconUrl=String(x.iconUrl||x.icon_url||'').trim(); const targetUrl=String(x.targetUrl||x.target_url||'').trim(); const active=x.active===false?0:1; const order=Math.max(1,Number(x.displayOrder||1));
    await env.DB.prepare(`INSERT INTO feature_buttons(key,title,icon_url,target_url,active,display_order,updated_at) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET title=excluded.title,icon_url=excluded.icon_url,target_url=excluded.target_url,active=excluded.active,display_order=excluded.display_order,updated_at=CURRENT_TIMESTAMP`).bind(key,title,iconUrl,targetUrl,active,order).run();
  }

  // Explicit deletes for content records. User/auth tables are never touched.
  for (const x of (Array.isArray(b.deleteBanners)?b.deleteBanners:[])) {
    const folder=String(x.folder||'').trim().toLowerCase(); const slot=Number(x.slot||0);
    if(['hero','promo'].includes(folder) && Number.isInteger(slot)) await env.DB.prepare('DELETE FROM banners WHERE folder=? AND slot=?').bind(folder,slot).run();
  }
  for (const platform of (Array.isArray(b.deleteSocialPlatforms)?b.deleteSocialPlatforms:[])) {
    await env.DB.prepare('DELETE FROM social_links WHERE platform=?').bind(String(platform||'').trim()).run();
  }
  for (const key of (Array.isArray(b.deleteFeatureKeys)?b.deleteFeatureKeys:[])) {
    await env.DB.prepare('UPDATE feature_buttons SET active=0,updated_at=CURRENT_TIMESTAMP WHERE key=?').bind(String(key||'').trim()).run();
  }
  const links = Array.isArray(b.managedLinks) ? b.managedLinks : [];
  for (const x of links) {
    const id=Number(x.id||0); const category=String(x.category||'').trim().toLowerCase(); const title=String(x.title||'').trim(); const url=String(x.url||'').trim(); const iconUrl=String(x.iconUrl||x.icon_url||'').trim(); const active=x.active===false?0:1; const order=Math.max(1,Number(x.displayOrder||1));
    if(!category) continue;
    if(id>0) await env.DB.prepare('UPDATE managed_links SET category=?,title=?,url=?,icon_url=?,active=?,display_order=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(category,title,url,iconUrl,active,order,id).run();
    else await env.DB.prepare('INSERT INTO managed_links(category,title,url,icon_url,active,display_order) VALUES(?,?,?,?,?,?)').bind(category,title,url,iconUrl,active,order).run();
  }
  for (const id of (Array.isArray(b.deleteManagedLinkIds)?b.deleteManagedLinkIds:[])) await env.DB.prepare('DELETE FROM managed_links WHERE id=?').bind(Number(id)).run();

  await createBroadcastNotification(env,'MY SHOP আপডেট','ব্যানার, সোশ্যাল বা ফিচার কনটেন্টে নতুন পরিবর্তন এসেছে।');
  return json({ok:true},200,cors);
}

async function adminBannerUpload(request,env) {
  try { await ensureContentSchema(env); } catch (_) {}
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  if(!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(); const folder=String(form.get('folder')||'').trim().toLowerCase(); const slot=Number(form.get('slot')||0); const file=form.get('file'); const caption=String(form.get('caption')||'').trim();
  if(!['hero','promo'].includes(folder) || !Number.isInteger(slot) || slot<1 || slot>(folder==='hero'?6:3) || !(file instanceof File)) return json({error:'INVALID_BANNER'},400,cors);
  const bannerType=guessContentType(file);
  if(!bannerType.startsWith('image/')) return json({error:'BANNER_MUST_BE_IMAGE'},400,cors);
  if(file.size>15*1024*1024) return json({error:'BANNER_TOO_LARGE'},413,cors);
  const old=await env.DB.prepare('SELECT object_key FROM banner_media WHERE folder=? AND slot=?').bind(folder,slot).first();
  // Safety: never delete the currently working banner until the new object and D1 rows are committed.
  const oldKey=old?.object_key||'';
  const ext=(String(file.name||'jpg').split('.').pop()||'jpg').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'jpg';
  const key=`banners/${folder}/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  try {
    await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:bannerType,cacheControl:'public, max-age=31536000'}});
  } catch (e) {
    return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);
  }
  const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  try {
    await env.DB.prepare(`INSERT INTO banners(folder,slot,image_url,caption,active,updated_at) VALUES(?,?,?,?,1,CURRENT_TIMESTAMP) ON CONFLICT(folder,slot) DO UPDATE SET image_url=excluded.image_url,caption=excluded.caption,active=1,updated_at=CURRENT_TIMESTAMP`).bind(folder,slot,url,caption).run();
    await env.DB.prepare(`INSERT INTO banner_media(folder,slot,object_key,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(folder,slot) DO UPDATE SET object_key=excluded.object_key,updated_at=CURRENT_TIMESTAMP`).bind(folder,slot,key).run();
  } catch(e) {
    try { await env.MEDIA.delete(key); } catch(_) {}
    return json({error:'BANNER_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors);
  }
  if(oldKey && oldKey!==key){ try { await env.MEDIA.delete(oldKey); } catch(_) {} }
  await createBroadcastNotification(env,'নতুন ব্যানার','MY SHOP-এ নতুন ব্যানার আপডেট হয়েছে।');
  return json({ok:true,folder,slot,image_url:url,caption},201,cors);
}

async function adminBannerUpdate(request,env) {
  try { await ensureContentSchema(env); } catch (_) {}
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const b=await body(request); const folder=String(b.folder||'').trim().toLowerCase(); const slot=Number(b.slot||0); const caption=String(b.caption||'').trim();
  if(!['hero','promo'].includes(folder)||!Number.isInteger(slot)||slot<1||slot>(folder==='hero'?6:3)) return json({error:'INVALID_BANNER'},400,cors);
  const row=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=?').bind(folder,slot).first();
  if(!row) return json({error:'BANNER_NOT_FOUND'},404,cors);
  await env.DB.prepare('UPDATE banners SET caption=?,updated_at=CURRENT_TIMESTAMP WHERE folder=? AND slot=?').bind(caption,folder,slot).run();
  await createBroadcastNotification(env,'ব্যানার আপডেট','একটি ব্যানারের ক্যাপশন আপডেট হয়েছে।');
  return json({ok:true,folder,slot,caption},200,cors);
}

async function adminBannerDelete(request,env) {
  try { await ensureContentSchema(env); } catch (_) {}
  const auth=await adminOnly(request,env); if(auth.error) return auth.error; const b=await body(request); const folder=String(b.folder||'').trim().toLowerCase(); const slot=Number(b.slot||0); if(!['hero','promo'].includes(folder)||!Number.isInteger(slot)) return json({error:'INVALID_BANNER'},400,cors);
  const old=await env.DB.prepare('SELECT object_key FROM banner_media WHERE folder=? AND slot=?').bind(folder,slot).first(); if(old?.object_key&&env.MEDIA) await env.MEDIA.delete(old.object_key);
  await env.DB.prepare('DELETE FROM banner_media WHERE folder=? AND slot=?').bind(folder,slot).run(); await env.DB.prepare('DELETE FROM banners WHERE folder=? AND slot=?').bind(folder,slot).run(); await createBroadcastNotification(env,'ব্যানার আপডেট','একটি ব্যানার সরানো হয়েছে।'); return json({ok:true},200,cors);
}

async function adminMediaList(request,env) {
  try { await ensureContentSchema(env); } catch (_) {}
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const folder=safeMediaFolder(new URL(request.url).searchParams.get('folder')||'');
  const sql=folder
    ? 'SELECT id,folder,title,caption,media_url,object_key,media_type,active,display_order FROM gallery_media WHERE folder=? ORDER BY display_order,id'
    : 'SELECT id,folder,title,caption,media_url,object_key,media_type,active,display_order FROM gallery_media ORDER BY folder,display_order,id';
  const rows=folder ? await env.DB.prepare(sql).bind(folder).all() : await env.DB.prepare(sql).all();
  return json({ok:true,folder:folder||'all',media:rows.results||[]},200,cors);
}

function safeMediaFolder(v){ const f=String(v||'').trim().toLowerCase(); return ['photo','audio','video'].includes(f)?f:''; }
function safeKeyPart(v){ return String(v||'').replace(/[^a-zA-Z0-9._-]/g,'_').slice(0,120); }

async function adminMediaUpload(request,env) {
  try { await ensureContentSchema(env); } catch (_) {}
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  if(!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(); const file=form.get('file'); const folder=safeMediaFolder(form.get('folder'));
  if(!(file instanceof File) || !folder) return json({error:'INVALID_MEDIA'},400,cors);
  const contentType=guessContentType(file);
  const allowed=folder==='photo'?contentType.startsWith('image/'):folder==='audio'?contentType.startsWith('audio/'):contentType.startsWith('video/');
  if(!allowed) return json({error:'MEDIA_TYPE_MISMATCH'},400,cors);
  if(file.size>50*1024*1024) return json({error:'MEDIA_TOO_LARGE'},413,cors);
  const title=String(form.get('title')||'').trim(); const caption=String(form.get('caption')||'').trim(); const order=Math.max(1,Number(form.get('displayOrder')||1));
  const ext=(String(file.name||'bin').split('.').pop()||'bin').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'bin';
  const key=`gallery/${folder}/${Date.now()}-${crypto.randomUUID().slice(0,8)}-${safeKeyPart(file.name||'media')}.${ext}`;
  try {
    await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType,cacheControl:'public, max-age=31536000'}});
  } catch (e) {
    return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);
  }
  const mediaUrl=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  const r=await env.DB.prepare('INSERT INTO gallery_media(folder,title,caption,media_url,object_key,media_type,active,display_order) VALUES(?,?,?,?,?,?,1,?)').bind(folder,title,caption,mediaUrl,key,contentType,order).run();
  await createBroadcastNotification(env,'গ্যালারি আপডেট','গ্যালারিতে নতুন মিডিয়া যোগ হয়েছে।');
  return json({ok:true,id:r.meta?.last_row_id||null,folder,title,caption,media_url:mediaUrl,object_key:key,media_type:contentType,display_order:order},201,cors);
}

async function adminMediaUpdate(request,env) {
  try { await ensureContentSchema(env); } catch (_) {}
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const b=await body(request); const id=Number(b.id||0); const title=String(b.title||'').trim(); const caption=String(b.caption||'').trim();
  if(!id) return json({error:'INVALID_MEDIA_ID'},400,cors);
  const row=await env.DB.prepare('SELECT id FROM gallery_media WHERE id=?').bind(id).first();
  if(!row) return json({error:'MEDIA_NOT_FOUND'},404,cors);
  await env.DB.prepare('UPDATE gallery_media SET title=?,caption=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(title,caption,id).run();
  await createBroadcastNotification(env,'গ্যালারি আপডেট','গ্যালারির একটি আইটেম সম্পাদনা করা হয়েছে।');
  return json({ok:true,id,title,caption},200,cors);
}

async function adminMediaDelete(request,env) {
  try { await ensureContentSchema(env); } catch (_) {}
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const b=await body(request); const id=Number(b.id||0); if(!id) return json({error:'INVALID_MEDIA_ID'},400,cors);
  const row=await env.DB.prepare('SELECT object_key FROM gallery_media WHERE id=?').bind(id).first(); if(!row) return json({error:'MEDIA_NOT_FOUND'},404,cors);
  if(env.MEDIA && row.object_key) await env.MEDIA.delete(row.object_key);
  await env.DB.prepare('DELETE FROM gallery_media WHERE id=?').bind(id).run();
  await createBroadcastNotification(env,'গ্যালারি আপডেট','গ্যালারি থেকে একটি মিডিয়া সরানো হয়েছে।');
  return json({ok:true},200,cors);
}



async function userGalleryList(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  const folder=safeMediaFolder(new URL(request.url).searchParams.get('folder')||'');
  if (!folder) return json({error:'INVALID_GALLERY_FOLDER'},400,cors);
  const rows=(await env.DB.prepare(`SELECT id,folder,title,caption,media_url,object_key,media_type,active,display_order,owner_user_id,updated_at FROM gallery_media WHERE active=1 AND folder=? AND (owner_user_id IS NULL OR owner_user_id=?) ORDER BY id DESC`).bind(folder,user.user_id).all()).results||[];
  return json({ok:true,folder,media:rows},200,cors);
}

async function userGalleryUpload(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!isAdminUser(user)) return json({error:'GALLERY_ADMIN_ONLY'},403,cors);
  if (!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(); const file=form.get('file'); const folder=safeMediaFolder(form.get('folder'));
  if (!(file instanceof File) || !folder) return json({error:'INVALID_MEDIA'},400,cors);
  const contentType=guessContentType(file);
  const allowed=folder==='photo'?contentType.startsWith('image/'):folder==='audio'?contentType.startsWith('audio/'):contentType.startsWith('video/');
  if(!allowed) return json({error:'MEDIA_TYPE_MISMATCH'},400,cors);
  // No item-count cap. Each individual object is limited to 50 MB; R2/account quota still applies.
  if(Number(file.size||0)>50*1024*1024) return json({error:'MEDIA_TOO_LARGE'},413,cors);
  const title=String(form.get('title')||'').trim().slice(0,160);
  const caption=String(form.get('caption')||'').trim().slice(0,1000);
  const ext=(String(file.name||'media').split('.').pop()||'bin').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'bin';
  const key=`gallery/users/${user.user_id}/${folder}/${Date.now()}-${crypto.randomUUID().slice(0,8)}-${safeKeyPart(file.name||'media')}.${ext}`;
  try { await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType,cacheControl:'public, max-age=31536000'}}); }
  catch(e){ return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
  const mediaUrl=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  try {
    const r=await env.DB.prepare(`INSERT INTO gallery_media(folder,title,caption,media_url,object_key,media_type,active,display_order,owner_user_id) VALUES(?,?,?,?,?,?,1,?,?)`).bind(folder,title,caption,mediaUrl,key,contentType,1,user.user_id).run();
    await createBroadcastNotification(env,'গ্যালারি আপডেট','একটি নতুন ইউজার গ্যালারি মিডিয়া যোগ হয়েছে।');
    return json({ok:true,id:r.meta?.last_row_id||null,folder,title,caption,media_url:mediaUrl,object_key:key,media_type:contentType,owner_user_id:user.user_id},201,cors);
  } catch(e){ try{await env.MEDIA.delete(key);}catch(_){} return json({error:'GALLERY_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors); }
}

async function userGalleryUpdate(request, env) {
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!isAdminUser(user)) return json({error:'GALLERY_ADMIN_ONLY'},403,cors);
  const b=await body(request); const id=Number(b.id||0); const title=String(b.title||'').trim().slice(0,160); const caption=String(b.caption||'').trim().slice(0,1000);
  if(!id) return json({error:'INVALID_MEDIA_ID'},400,cors);
  const row=await env.DB.prepare('SELECT id FROM gallery_media WHERE id=? AND owner_user_id=?').bind(id,user.user_id).first();
  if(!row) return json({error:'MEDIA_NOT_FOUND'},404,cors);
  await env.DB.prepare('UPDATE gallery_media SET title=?,caption=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND owner_user_id=?').bind(title,caption,id,user.user_id).run();
  return json({ok:true,id,title,caption},200,cors);
}

async function userGalleryDelete(request, env) {
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!isAdminUser(user)) return json({error:'GALLERY_ADMIN_ONLY'},403,cors);
  const b=await body(request); const id=Number(b.id||0); if(!id) return json({error:'INVALID_MEDIA_ID'},400,cors);
  const row=await env.DB.prepare('SELECT object_key FROM gallery_media WHERE id=? AND owner_user_id=?').bind(id,user.user_id).first();
  if(!row) return json({error:'MEDIA_NOT_FOUND'},404,cors);
  if(env.MEDIA && row.object_key) { try{await env.MEDIA.delete(row.object_key);}catch(_){} }
  await env.DB.prepare('DELETE FROM gallery_media WHERE id=? AND owner_user_id=?').bind(id,user.user_id).run();
  return json({ok:true},200,cors);
}


function isAdminUser(user) { return !!user && String(user.role || '').toUpperCase() === 'ADMIN'; }
function isModeratorUser(user) { return !!user && ['MODERATOR','ADMIN'].includes(String(user.role || '').toUpperCase()); }

async function feedList(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  try { await ensureContentSchema(env); } catch (_) {}
  const url = new URL(request.url);
  const limit = Math.min(10, Math.max(1, Number(url.searchParams.get('limit') || 5)));
  const before = Math.max(0, Number(url.searchParams.get('before') || 0));
  const sql = before > 0
    ? `SELECT p.id,p.user_id,p.caption,p.media_url,p.object_key,p.media_type,p.created_at,u.full_name,u.avatar_url
       FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id
       WHERE p.status='ACTIVE' AND p.id<? ORDER BY p.id DESC LIMIT ?`
    : `SELECT p.id,p.user_id,p.caption,p.media_url,p.object_key,p.media_type,p.created_at,u.full_name,u.avatar_url
       FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id
       WHERE p.status='ACTIVE' ORDER BY p.id DESC LIMIT ?`;
  const rows = before > 0
    ? (await env.DB.prepare(sql).bind(before,limit).all()).results || []
    : (await env.DB.prepare(sql).bind(limit).all()).results || [];
  const today = await env.DB.prepare(`SELECT COUNT(*) AS c FROM myshop_posts WHERE user_id=? AND date(created_at)=date('now')`).bind(user.user_id).first();
  const canPost = isAdminUser(user) || Number(today?.c || 0) < 1;
  return json({ok:true,posts:rows.map(x=>({id:x.id,userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',caption:x.caption||'',mediaUrl:x.media_url||'',mediaType:x.media_type||'image',createdAt:x.created_at||''})),nextBefore:rows.length?Number(rows[rows.length-1].id):null,hasMore:rows.length===limit,canPost,role:user.role,postsToday:Number(today?.c||0)},200,cors);
}

async function feedUpload(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const isAdmin = isAdminUser(user);
  const form = await request.formData();
  const file = form.get('file');
  if (!(file instanceof File)) return json({error:'FILE_REQUIRED'},400,cors);
  const contentType = guessContentType(file);
  const requestedType = String(form.get('mediaType') || '').trim().toLowerCase();
  const mediaType = requestedType || (contentType.startsWith('video/') ? 'video' : 'image');
  const allowed = mediaType === 'image' ? contentType.startsWith('image/') : mediaType === 'video' ? contentType.startsWith('video/') : false;
  if (!allowed) return json({error:'POST_MEDIA_TYPE_MISMATCH'},400,cors);
  if (!isAdmin && mediaType !== 'image') return json({error:'USER_VIDEO_LOCKED'},403,cors);
  const maxBytes = isAdmin ? 50*1024*1024 : 5*1024*1024;
  if (Number(file.size||0) > maxBytes) return json({error:isAdmin?'POST_MEDIA_TOO_LARGE':'USER_POST_TOO_LARGE'},413,cors);
  const caption = String(form.get('caption') || '').trim().slice(0,1000);
  if (!isAdmin && !caption) return json({error:'POST_CAPTION_REQUIRED'},400,cors);
  if (!isAdmin) {
    const today = await env.DB.prepare(`SELECT COUNT(*) AS c FROM myshop_posts WHERE user_id=? AND date(created_at)=date('now')`).bind(user.user_id).first();
    if (Number(today?.c||0) >= 1) return json({error:'DAILY_POST_LIMIT',message:'সাধারণ User প্রতিদিন সর্বোচ্চ ১টি পোস্ট করতে পারবে।'},429,cors);
  }
  const ext=(String(file.name||'media').split('.').pop()||'bin').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'bin';
  const key=`posts/${user.user_id}/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  try { await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType,cacheControl:'public, max-age=86400'}}); }
  catch(e) { return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
  const mediaUrl=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  try {
    const r=await env.DB.prepare(`INSERT INTO myshop_posts(user_id,caption,media_url,object_key,media_type,status) VALUES(?,?,?,?,?,'ACTIVE')`).bind(user.user_id,caption,mediaUrl,key,mediaType).run();
    await createBroadcastNotification(env,'MY SHOP Feed','নতুন একটি পোস্ট Feed-এ যোগ হয়েছে।');
    return json({ok:true,id:r.meta?.last_row_id||null,post:{id:r.meta?.last_row_id||null,userId:user.user_id,name:user.full_name||'',avatarUrl:user.avatar_url||'',caption,mediaUrl,mediaType}},201,cors);
  } catch(e) { try { await env.MEDIA.delete(key); } catch (_) {} return json({error:'POST_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors); }
}

async function feedText(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  try { await ensureContentSchema(env); } catch (_) {}
  const b=await body(request); const caption=String(b.caption||'').trim().slice(0,1000);
  if(!caption) return json({error:'POST_CAPTION_REQUIRED'},400,cors);
  const isAdmin=isAdminUser(user);
  if(!isAdmin){
    const today=await env.DB.prepare(`SELECT COUNT(*) AS c FROM myshop_posts WHERE user_id=? AND date(created_at)=date('now')`).bind(user.user_id).first();
    if(Number(today?.c||0)>=1)return json({error:'DAILY_POST_LIMIT',message:'সাধারণ User প্রতিদিন সর্বোচ্চ ১টি পোস্ট করতে পারবে।'},429,cors);
  }
  try{
    const r=await env.DB.prepare(`INSERT INTO myshop_posts(user_id,caption,media_url,object_key,media_type,status) VALUES(?,?,'','','text','ACTIVE')`).bind(user.user_id,caption).run();
    await createBroadcastNotification(env,'MY SHOP Feed','নতুন একটি text post Feed-এ যোগ হয়েছে।');
    return json({ok:true,id:r.meta?.last_row_id||null,post:{id:r.meta?.last_row_id||null,userId:user.user_id,name:user.full_name||'',avatarUrl:user.avatar_url||'',caption,mediaUrl:'',mediaType:'text'}},201,cors);
  }catch(e){return json({error:'POST_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors);}
}

async function feedLike(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request); const id=Number(b.postId||0); if(!Number.isInteger(id)||id<=0)return json({error:'INVALID_POST_ID'},400,cors);
  const post=await env.DB.prepare(`SELECT id,user_id FROM myshop_posts WHERE id=? AND status='ACTIVE'`).bind(id).first(); if(!post)return json({error:'POST_NOT_FOUND'},404,cors);
  const exists=await env.DB.prepare('SELECT post_id FROM myshop_post_likes WHERE post_id=? AND user_id=?').bind(id,user.user_id).first();
  if(exists){await env.DB.prepare('DELETE FROM myshop_post_likes WHERE post_id=? AND user_id=?').bind(id,user.user_id).run(); return json({ok:true,liked:false},200,cors);}
  await env.DB.prepare('INSERT OR IGNORE INTO myshop_post_likes(post_id,user_id) VALUES(?,?)').bind(id,user.user_id).run();
  if(post.user_id!==user.user_id) await env.DB.prepare(`INSERT INTO notifications(title,message,audience,user_id,created_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)`).bind('MY SHOP','User ID '+user.user_id+' liked your post.','USER',post.user_id).run();
  return json({ok:true,liked:true},200,cors);
}
async function feedComment(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors); const b=await body(request); const id=Number(b.postId||0); const comment=String(b.comment||'').trim().slice(0,1000);
  if(!Number.isInteger(id)||id<=0||!comment)return json({error:'INVALID_COMMENT'},400,cors); const post=await env.DB.prepare(`SELECT id,user_id FROM myshop_posts WHERE id=? AND status='ACTIVE'`).bind(id).first(); if(!post)return json({error:'POST_NOT_FOUND'},404,cors);
  await env.DB.prepare('INSERT INTO myshop_post_comments(post_id,user_id,comment) VALUES(?,?,?)').bind(id,user.user_id,comment).run(); if(post.user_id!==user.user_id) await env.DB.prepare(`INSERT INTO notifications(title,message,audience,user_id,created_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)`).bind('MY SHOP','User ID '+user.user_id+' commented on your post.','USER',post.user_id).run(); return json({ok:true},201,cors);
}

async function feedDeleteOwn(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request); const id=Number(b.id||0); if(!id)return json({error:'INVALID_POST_ID'},400,cors);
  const row=await env.DB.prepare(`SELECT object_key FROM myshop_posts WHERE id=? AND user_id=? AND status='ACTIVE'`).bind(id,user.user_id).first();
  if(!row)return json({error:'POST_NOT_FOUND'},404,cors);
  if(env.MEDIA&&row.object_key){try{await env.MEDIA.delete(row.object_key);}catch(_){} }
  await env.DB.prepare(`UPDATE myshop_posts SET status='REMOVED',moderated_by=?,moderated_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?`).bind(user.user_id,id,user.user_id).run();
  return json({ok:true},200,cors);
}

async function adminFeedList(request,env) {
  const auth=await adminOnly(request,env); if(auth.error)return auth.error;
  try{await ensureContentSchema(env);}catch(_){ }
  const rows=(await env.DB.prepare(`SELECT p.id,p.user_id,p.caption,p.media_url,p.media_type,p.status,p.created_at,p.moderated_by,p.moderated_at,u.full_name,u.avatar_url FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id ORDER BY p.id DESC LIMIT 100`).all()).results||[];
  return json({ok:true,posts:rows},200,cors);
}

async function moderatorFeedDelete(request,env) {
  const user=await getUser(request,env);
  if(!user || !isModeratorUser(user)) return json({error:'MODERATOR_REQUIRED'},403,cors);
  try{await ensureContentSchema(env);}catch(_){ }
  const b=await body(request); const id=Number(b.id||0); const reason=String(b.reason||'').trim().slice(0,300);
  if(!id)return json({error:'INVALID_POST_ID'},400,cors);
  const row=await env.DB.prepare(`SELECT object_key,status FROM myshop_posts WHERE id=?`).bind(id).first();
  if(!row)return json({error:'POST_NOT_FOUND'},404,cors);
  if(env.MEDIA&&row.object_key){try{await env.MEDIA.delete(row.object_key);}catch(_){} }
  await env.DB.prepare(`UPDATE myshop_posts SET status='REMOVED',moderated_by=?,moderated_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(user.user_id,id).run();
  return json({ok:true,removedBy:user.user_id,reason},200,cors);
}

async function adminAdsList(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error;
  const box=String(new URL(request.url).searchParams.get('box_key')||'').trim().toLowerCase();
  const rows=box?await env.DB.prepare('SELECT id,box_key,slot,image_url,caption,target_url,object_key,active,updated_at FROM dashboard_ads WHERE box_key=? ORDER BY slot').bind(box).all():await env.DB.prepare('SELECT id,box_key,slot,image_url,caption,target_url,object_key,active,updated_at FROM dashboard_ads ORDER BY box_key,slot').all();
  return json({ok:true,ads:rows.results||[]},200,cors);
}

async function adminAdUpload(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error;
  if(!env.MEDIA)return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(); const file=form.get('file'); const box=String(form.get('boxKey')||'').trim().toLowerCase().replace(/[^a-z0-9_-]/g,'_').slice(0,60); const slot=Number(form.get('slot')||0); const caption=String(form.get('caption')||'').trim().slice(0,300); const target=String(form.get('targetUrl')||'').trim().slice(0,500);
  if(!(file instanceof File)||!box||!Number.isInteger(slot)||slot<1||slot>6)return json({error:'INVALID_AD'},400,cors);
  if(!String(file.type||'').startsWith('image/'))return json({error:'AD_MUST_BE_IMAGE'},400,cors);
  if(file.size>15*1024*1024)return json({error:'AD_TOO_LARGE'},413,cors);
  const old=await env.DB.prepare('SELECT object_key FROM dashboard_ads WHERE box_key=? AND slot=?').bind(box,slot).first(); const oldKey=old?.object_key||'';
  const ext=(String(file.name||'jpg').split('.').pop()||'jpg').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'jpg'; const key=`dashboard-ads/${box}/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  try{await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:bannerType,cacheControl:'public, max-age=31536000'}});}catch(e){return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);}
  const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  try{await env.DB.prepare(`INSERT INTO dashboard_ads(box_key,slot,image_url,caption,target_url,object_key,active,updated_at) VALUES(?,?,?,?,?,?,1,CURRENT_TIMESTAMP) ON CONFLICT(box_key,slot) DO UPDATE SET image_url=excluded.image_url,caption=excluded.caption,target_url=excluded.target_url,object_key=excluded.object_key,active=1,updated_at=CURRENT_TIMESTAMP`).bind(box,slot,url,caption,target,key).run();}catch(e){try{await env.MEDIA.delete(key);}catch(_){}return json({error:'AD_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors);}
  if(oldKey&&oldKey!==key){try{await env.MEDIA.delete(oldKey);}catch(_){} }
  await createBroadcastNotification(env,'বিজ্ঞাপন আপডেট','ড্যাশবোর্ডের বিজ্ঞাপন আপডেট হয়েছে।');
  return json({ok:true,box_key:box,slot,image_url:url,caption,target_url:target},201,cors);
}

async function adminAdUpdate(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; const b=await body(request); const id=Number(b.id||0); if(!id)return json({error:'INVALID_AD_ID'},400,cors);
  const row=await env.DB.prepare('SELECT id FROM dashboard_ads WHERE id=?').bind(id).first(); if(!row)return json({error:'AD_NOT_FOUND'},404,cors);
  await env.DB.prepare('UPDATE dashboard_ads SET caption=?,target_url=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(String(b.caption||'').trim().slice(0,300),String(b.targetUrl||'').trim().slice(0,500),b.active===false?0:1,id).run(); return json({ok:true},200,cors);
}

async function adminAdDelete(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; const b=await body(request); const id=Number(b.id||0); if(!id)return json({error:'INVALID_AD_ID'},400,cors); const row=await env.DB.prepare('SELECT object_key FROM dashboard_ads WHERE id=?').bind(id).first(); if(!row)return json({error:'AD_NOT_FOUND'},404,cors); if(env.MEDIA&&row.object_key){try{await env.MEDIA.delete(row.object_key);}catch(_){} } await env.DB.prepare('DELETE FROM dashboard_ads WHERE id=?').bind(id).run(); return json({ok:true},200,cors);
}

async function profileUpdate(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  const b = await body(request);
  const name = String(b.name ?? user.full_name).trim();
  const email = normalizeEmail(b.email ?? user.email ?? '');
  const mobile = normalizeMobile(b.mobile ?? user.mobile ?? '');
  const bio = String(b.bio ?? user.bio ?? '').trim().slice(0,500);
  if (!name || (!email && !mobile)) return json({error:'INVALID_PROFILE'},400,cors);
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({error:'INVALID_EMAIL'},400,cors);
  const duplicate = await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE user_id<>? AND ((?<>'' AND email=?) OR (?<>'' AND mobile=?)) LIMIT 1`).bind(user.user_id,email,email,mobile,mobile).first();
  if (duplicate) return json({error:'ACCOUNT_EXISTS'},409,cors);
  await env.DB.prepare(`UPDATE myshop_auth_users_v108 SET full_name=?,email=?,mobile=?,bio=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(name,email||null,mobile||null,bio,user.user_id).run();
  const fresh=await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(user.user_id).first();
  return json({ok:true,user:publicUser(fresh)},200,cors);
}

async function profileAvatarUpload(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form = await request.formData();
  const file = form.get('file');
  if (!file || typeof file.arrayBuffer !== 'function') return json({error:'FILE_REQUIRED'},400,cors);
  const rawType=String(file.type||'').toLowerCase();
  const fileName=String(file.name||'').toLowerCase();
  const extName=fileName.includes('.')?fileName.split('.').pop():'';
  const guessedType=extName==='png'?'image/png':extName==='webp'?'image/webp':extName==='gif'?'image/gif':(extName==='jpg'||extName==='jpeg')?'image/jpeg':'';
  const type=rawType.startsWith('image/')?rawType:(guessedType||'');
  if (!type.startsWith('image/')) return json({error:'AVATAR_TYPE_MISMATCH'},400,cors);
  if (Number(file.size||0)>5*1024*1024) return json({error:'AVATAR_TOO_LARGE'},413,cors);
  const ext=(extName||type.split('/')[1]||'jpg').replace(/[^a-z0-9]/g,'').slice(0,8)||'jpg';
  const key=`profiles/${user.user_id}/avatar-${Date.now()}-${randomHex(8)}.${ext}`;
  try { await env.MEDIA.put(key,await file.arrayBuffer(),{httpMetadata:{contentType:type,cacheControl:'public, max-age=3600'}}); }
  catch(e){ return json({error:'R2_WRITE_FAILED',message:String(e?.message||e)},503,cors); }
  const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  const oldKey=user.avatar_object_key||'';
  try {
    await env.DB.prepare('UPDATE myshop_auth_users_v108 SET avatar_url=?,avatar_object_key=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(url,key,user.user_id).run();
  } catch(e) {
    try { await env.MEDIA.delete(key); } catch(_) {}
    return json({error:'PROFILE_UPDATE_FAILED'},500,cors);
  }
  if(oldKey && oldKey!==key){ try { await env.MEDIA.delete(oldKey); } catch(_) {} }
  const fresh=await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(user.user_id).first();
  return json({ok:true,user:publicUser(fresh)},200,cors);
}

async function coinBalance(request, env) {
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  await env.DB.prepare('INSERT OR IGNORE INTO myshop_coin_wallets(user_id,balance) VALUES(?,0)').bind(user.user_id).run();
  const wallet=await env.DB.prepare('SELECT user_id,balance,updated_at FROM myshop_coin_wallets WHERE user_id=?').bind(user.user_id).first();
  const tx=(await env.DB.prepare('SELECT id,kind,amount,reference,status,metadata,created_at FROM myshop_coin_transactions WHERE user_id=? ORDER BY id DESC LIMIT 50').bind(user.user_id).all()).results||[];
  return json({ok:true,balance:Number(wallet?.balance||0),transactions:tx},200,cors);
}

async function giftHistory(request,env){
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const rows=(await env.DB.prepare(`SELECT id,sender_user_id,receiver_user_id,coins,gift_code,created_at FROM myshop_gift_transactions WHERE sender_user_id=? OR receiver_user_id=? ORDER BY id DESC LIMIT 100`).bind(user.user_id,user.user_id).all()).results||[];
  return json({ok:true,gifts:rows},200,cors);
}

async function coinPurchaseRequest(request, env) {
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request); const coins=Number(b.coins||0); const amountMinor=Number(b.amountMinor||0); const method=String(b.paymentMethod||'').trim().toLowerCase(); const reference=String(b.reference||'').trim().slice(0,120);
  if(!Number.isInteger(coins)||coins<=0||coins>100000000||!Number.isInteger(amountMinor)||amountMinor<=0||!['bkash','nagad','bangla_qr'].includes(method)) return json({error:'INVALID_PURCHASE_REQUEST'},400,cors);
  const r=await env.DB.prepare('INSERT INTO myshop_coin_purchase_requests(user_id,package_coins,amount_minor,payment_method,reference,status) VALUES(?,?,?,?,?,\'PENDING\')').bind(user.user_id,coins,amountMinor,method,reference).run();
  return json({ok:true,requestId:r.meta?.last_row_id||null,status:'PENDING',message:'Payment request received. Coin credit requires server-side approval.'},201,cors);
}

async function mediaGet(request,env,key) {
  if(!env.MEDIA) return new Response('R2 not configured',{status:503,headers:cors});
  const object=await env.MEDIA.get(key); if(!object) return new Response('Not found',{status:404,headers:cors});
  const headers=new Headers(cors); object.writeHttpMetadata(headers); headers.set('etag',object.httpEtag);
  return new Response(object.body,{headers});
}

async function adminPermissions(request,env) {
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const user = auth.user;
  const mods = await env.DB.prepare('SELECT user_id,active FROM myshop_moderators_v108 ORDER BY user_id LIMIT 5').all();
  return json({ok:true,role:user.role,admin:true,moderators:mods.results||[]},200,cors);
}

async function adminAction(request,env) {
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const b = await body(request);
  const uid = String(b.userId||'').trim();
  const action = String(b.action||'').toLowerCase();
  if (!isFourDigit(uid)) return json({error:'INVALID_USER_ID'},400,cors);
  if (action==='add_moderator') {
    const target = await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(uid).first();
    if (!target) return json({error:'USER_NOT_FOUND'},404,cors);
    const count = await env.DB.prepare('SELECT COUNT(*) AS c FROM myshop_moderators_v108 WHERE active=1').first();
    if (Number(count?.c||0)>=5) return json({error:'MODERATOR_LIMIT'},409,cors);
    await env.DB.prepare('INSERT INTO myshop_moderators_v108(user_id) VALUES(?) ON CONFLICT(user_id) DO UPDATE SET active=1').bind(uid).run();
    await env.DB.prepare("UPDATE myshop_auth_users_v108 SET role='MODERATOR' WHERE user_id=? AND user_id NOT IN ('0001','0002','0003')").bind(uid).run();
  } else if (action==='remove_moderator') {
    await env.DB.prepare('UPDATE myshop_moderators_v108 SET active=0 WHERE user_id=?').bind(uid).run();
    await env.DB.prepare("UPDATE myshop_auth_users_v108 SET role=CASE WHEN role='MODERATOR' THEN 'USER' ELSE role END WHERE user_id=?").bind(uid).run();
  } else return json({error:'UNSUPPORTED_ACTION'},400,cors);
  return json({ok:true},200,cors);
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null,{status:204,headers:cors});
    const url = new URL(request.url); const p=url.pathname;
    try {
      if (request.method==='GET' && p==='/health') return json({ok:true,service:'my-shop-api',version:'2.9.154',build:'V-154',database:'my-shop-db',r2:'MEDIA',time:new Date().toISOString()},200,cors);
      if (request.method==='GET' && p==='/health/deep') {
        try { await ensureAuthSchema(env); } catch (_) {}
        try { await ensureContentSchema(env); } catch (_) {}
        const h=await deepHealth(env);
        return json(h,h.ok?200:503,cors);
      }
      // Dashboard config is public read data. Do not let an unrelated auth/content schema
      // initialization failure turn a simple config read into SERVER_ERROR.
      if (request.method==='GET' && p==='/v1/dashboard/config') {
        try { await ensureDashboardConfigSchema(env); } catch (_) {}
        return await dashboardConfig(request,env);
      }
      await ensureAuthSchema(env);
      await ensureContentSchema(env);
      if (request.method==='POST' && p==='/v1/auth/register') return await register(request,env);
      if (request.method==='POST' && p==='/v1/auth/login') return await login(request,env);
      if (request.method==='POST' && p==='/v1/auth/logout') return await logout(request,env);
      if (request.method==='GET' && p==='/v1/auth/password/questions') return await securityQuestions(request,env);
      if (request.method==='POST' && p==='/v1/auth/password/reset') return await resetPassword(request,env);
      if (request.method==='GET' && p==='/v1/me') return await me(request,env);
      if (request.method==='PUT' && p==='/v1/me/profile') return await profileUpdate(request,env);
      if (request.method==='POST' && p==='/v1/me/avatar/upload') return await profileAvatarUpload(request,env);
      if (request.method==='GET' && p==='/v1/gallery') return await userGalleryList(request,env);
      if (request.method==='POST' && p==='/v1/gallery/upload') return await userGalleryUpload(request,env);
      if (request.method==='PUT' && p==='/v1/gallery/update') return await userGalleryUpdate(request,env);
      if (request.method==='POST' && p==='/v1/gallery/delete') return await userGalleryDelete(request,env);
      if (request.method==='GET' && p==='/v1/feed') return await feedList(request,env);
      if (request.method==='POST' && p==='/v1/feed/upload') return await feedUpload(request,env);
       if (request.method==='POST' && p==='/v1/feed/text') return await feedText(request,env);
      if (request.method==='POST' && p==='/v1/feed/delete') return await feedDeleteOwn(request,env);
      if (request.method==='POST' && p==='/v1/feed/like') return await feedLike(request,env);
      if (request.method==='POST' && p==='/v1/feed/comment') return await feedComment(request,env);
      if (request.method==='GET' && p==='/v1/admin/feed') return await adminFeedList(request,env);
      if (request.method==='POST' && p==='/v1/admin/feed/delete') return await moderatorFeedDelete(request,env);
      if (request.method==='GET' && p==='/v1/coins') return await coinBalance(request,env);
      if (request.method==='GET' && p==='/v1/gifts/history') return await giftHistory(request,env);
      if (request.method==='POST' && p==='/v1/coins/purchase-request') return await coinPurchaseRequest(request,env);
      if (request.method==='GET' && p==='/v1/notifications') return await notificationsList(request,env);
      if (request.method==='POST' && p==='/v1/notifications/read-all') return await notificationsReadAll(request,env);
      if (request.method==='GET' && p==='/v1/admin/permissions') return await adminPermissions(request,env);
      if (request.method==='PUT' && p==='/v1/admin/dashboard/config') return await adminDashboardPut(request,env);
      if (request.method==='PUT' && p==='/v1/admin/content') return await adminContentPut(request,env);
      if (request.method==='GET' && p==='/v1/admin/media') return await adminMediaList(request,env);
      if (request.method==='POST' && p==='/v1/admin/media/upload') return await adminMediaUpload(request,env);
      if (request.method==='GET' && p==='/v1/admin/ads') return await adminAdsList(request,env);
      if (request.method==='POST' && p==='/v1/admin/ad/upload') return await adminAdUpload(request,env);
      if (request.method==='PUT' && p==='/v1/admin/ad/update') return await adminAdUpdate(request,env);
      if (request.method==='POST' && p==='/v1/admin/ad/delete') return await adminAdDelete(request,env);
      if (request.method==='POST' && p==='/v1/admin/banner/upload') return await adminBannerUpload(request,env);
      if (request.method==='POST' && p==='/v1/admin/banner/delete') return await adminBannerDelete(request,env);
      if (request.method==='PUT' && p==='/v1/admin/banner/update') return await adminBannerUpdate(request,env);
      if (request.method==='PUT' && p==='/v1/admin/media/update') return await adminMediaUpdate(request,env);
      if (request.method==='POST' && p==='/v1/admin/media/delete') return await adminMediaDelete(request,env);
      if (request.method==='GET' && p.startsWith('/v1/media/')) return await mediaGet(request,env,decodeURIComponent(p.slice('/v1/media/'.length)));
      if (request.method==='POST' && p==='/v1/admin/actions') return await adminAction(request,env);
      return json({error:'NOT_FOUND'},404,cors);
    } catch (e) {
      return json({error:'SERVER_ERROR',message:String(e?.message||e)},500,cors);
    }
  }
};
