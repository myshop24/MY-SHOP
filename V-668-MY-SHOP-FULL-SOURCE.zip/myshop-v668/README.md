# MY SHOP V-668 / 2.9.668
Continue delivered V667. Read V668-HANDOFF.md, DEVELOPER-POLICY-BN.md and V667-TASK-LEDGER-BN.md.
Scope: three full-screen guest seats, run727 music APK verification and slow build setup repair. Other unfinished features remain pending.
This is source, not a signed APK. Android/device acceptance is not claimed.
For build-only GitHub Actions use GITHUB-UPLOAD-V668-BN.md and the included root .github/workflows/my-shop-apk.yml. Merely uploading a ZIP to the previous permanent workflow does not replace its automatic production deploy logic.
Compact media needs the hash-pinned V664 archive; see V666-HANDOFF.md. Current application/backend code is entirely V668; no older code is restored.
