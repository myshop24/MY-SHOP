# MY SHOP V-175 — MASTER FINAL FIX CHECKLIST

1. Header/menu: restore the lower, cleaner header proportions; three-line hamburger uses three clearly separated colors with comfortable spacing; MY SHOP logo/text have breathing room; notification bell uses a crisp vector icon and stable badge alignment.
2. Bottom navigation: restore the original lower anchored position; Home/Store/LIVE/Support/More stay on one row, Home is always visible, no floating/aircraft look, no feed overlap, crisp icons and smooth press feedback.
3. MORE: keep the requested social buttons (Facebook, Page, YouTube, WhatsApp, imo, Instagram, Telegram), Admin-controlled targets, number-or-link handling, Customer Support and Share App.
4. Menu items: semantic local vector icons remain for Chat, Music, News, Help, Jobs, Coupon, Booking, Wallet, Settings, Language and Logout.
5. Upload/post flow: use Android's persistent document picker for images and videos, preserve URI access, show actionable errors, and keep the successful post flow intact.
6. Backend upload reliability: feed upload initializes additive D1 schemas before writing, validates R2, media type, size and caption, deletes orphaned R2 media if D1 save fails, and returns useful error codes.
7. Notification reliability: notification list/read-all routes initialize schemas, inbox has retry/error feedback, mark-seen refreshes, and dashboard badge uses the unread count.
8. Profile: `/v1/me` syncs the current avatar into the header and MY FEED composer.
9. External Save: dedicated External Movie Save + Reload remains in Admin and persists `external_movie_url` safely.
10. Performance: shared image executor + LRU cache, reduced unnecessary feed reloads, graceful weak-network behavior, and no UI-thread media work.
11. Dashboard: safe bottom spacing without artificially lifting the bottom navigation; feed remains readable above the navigation.
12. Feature decisions: Search remains; Like/Comment remain; MY FEED post Share remains intentionally absent; MORE Share remains.
13. Store cart/wishlist/order tracking remain future phase and are not added here.
14. Lightweight/free-tier friendly: no unnecessary heavy storage or new service dependency.
15. Final quality: responsive sizing, loading/error/retry, D1 save→reload, Worker response, notifications, profile, links, navigation, performance, data safety and Play Store readiness.

DATA SAFETY: no auth/user table deletion, reset or destructive migration added by V-175.
VERSION: V-175 / app 2.9.175.
BACKEND: rapid-bush-62ea / my-shop-db / MEDIA.
