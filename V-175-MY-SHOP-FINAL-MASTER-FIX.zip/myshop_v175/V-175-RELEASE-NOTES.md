# MY SHOP V-175 — FINAL MASTER FIX

V-175 is the final consolidated fix package based on the V-174 source and the last user-provided runtime video/screenshots.

Highlights:
- Restored the bottom navigation to the previous lower anchored position.
- Removed the oversized/floating bottom-nav presentation and restored a compact five-button row.
- Kept crisp vector icons and smooth ripple interaction.
- Restored a clearer three-color hamburger with real spacing between lines.
- Rebalanced the MY SHOP logo/text/header spacing.
- Replaced the notification emoji with a crisp vector bell and retained unread badge behavior.
- Switched user image selection to ACTION_OPEN_DOCUMENT for more reliable URI access.
- Added clearer post-upload failure handling.
- Added an additive backend schema guard before feed uploads so D1 content tables are ready before R2/D1 writes.
- Preserved R2 orphan cleanup if post database insertion fails.
- Preserved MORE, Customer Support, Share App, profile sync, External Movie Save and all locked feature decisions.

No auth/user data deletion or reset was added.
