# START HERE — MY SHOP V-322

This is the complete V-322 source base for the next developer/version.

## Current identity
- SOURCE_BUILD_ID: `MY SHOP V-322`
- Android versionCode: `322`
- Android versionName: `2.9.322`
- Worker health/build markers: `2.9.322 / V-322`

## Where the main code is
- Android app: `app/`
- Live Room: `app/src/main/java/com/myshop/app/AudioLiveRoomActivity.java`
- Android API client: `app/src/main/java/com/myshop/app/BackendClient.java`
- Gift Admin: `app/src/main/java/com/myshop/app/LiveGiftAdminActivity.java`
- Message push service: `app/src/main/java/com/myshop/app/MyShopMessagingService.java`
- Push registration: `app/src/main/java/com/myshop/app/PushRegistration.java`
- Cloudflare Worker: `backend/worker/src/index.js`
- Worker bindings: `backend/worker/wrangler.toml`
- Build workflow: `.github/workflows/my-shop-apk.yml`

## Read before changing code
1. `00-MY-SHOP-DEVELOPER-INSTRUCTIONS.md`
2. `V-322_RELEASE_NOTES.md`
3. `V-322_47_INSTRUCTION_QA.md`
4. `V-322_VALIDATION_REPORT.txt`
5. `V-322_PLAY_COMPLIANCE_QA.md`
6. `MY-SHOP-DEVELOPER-HANDOFF.md`

## V-322 external configuration
No secrets are stored in this ZIP. GitHub release build requires Firebase build secrets: `MYSHOP_FIREBASE_API_KEY`, `MYSHOP_FIREBASE_APP_ID`, `MYSHOP_FIREBASE_PROJECT_ID`, `MYSHOP_FIREBASE_SENDER_ID`. Worker push requires `FCM_SERVICE_ACCOUNT_JSON`. Existing Cloudflare/Play secrets remain required by the master workflow.

## Build note
The inherited source does not contain `gradlew`, `gradlew.bat`, or `gradle-wrapper.jar`. The included permanent GitHub workflow installs Gradle 8.11.1 itself and does not depend on a wrapper. See `GRADLE_WRAPPER_STATUS.md`.
