# V-322 Build + Message Push Setup

## GitHub Actions secrets required for V-322 message push
- `MYSHOP_FIREBASE_API_KEY`
- `MYSHOP_FIREBASE_APP_ID`
- `MYSHOP_FIREBASE_PROJECT_ID`
- `MYSHOP_FIREBASE_SENDER_ID`
- `FCM_SERVICE_ACCOUNT_JSON`

The build workflow injects only the four Android Firebase values into BuildConfig. The full FCM service account JSON is sent only as a Worker secret during the verified Worker-version upload. Do not commit secret values to source files.

## Runtime flow
1. Android initializes Firebase only when all build values are present.
2. FCM token is registered to `/v1/push/token` for the logged-in MY SHOP user.
3. A successful `/v1/messages/send` stores the message and user notification.
4. Worker schedules FCM push through `ctx.waitUntil`, so message response does not wait for the push network call.
5. Android shows a high-priority MY SHOP Messages notification using sender name/message preview and updates it with sender avatar when available.
6. Tapping a message notification opens the exact `ChatActivity` conversation.
7. Android notification/lock-screen privacy settings remain user-controlled.
