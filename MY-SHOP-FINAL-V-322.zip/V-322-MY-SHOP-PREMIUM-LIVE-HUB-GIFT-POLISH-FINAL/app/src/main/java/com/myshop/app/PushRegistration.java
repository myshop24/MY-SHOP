package com.myshop.app;

import android.content.Context;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;

/** V-322: safely registers this Android install for real FCM push when Firebase CI config is present. */
public final class PushRegistration {
    private PushRegistration() {}
    public static boolean firebaseConfigured(){return BuildConfig.FIREBASE_APP_ID!=null&&!BuildConfig.FIREBASE_APP_ID.isEmpty()&&BuildConfig.FIREBASE_PROJECT_ID!=null&&!BuildConfig.FIREBASE_PROJECT_ID.isEmpty()&&BuildConfig.FIREBASE_SENDER_ID!=null&&!BuildConfig.FIREBASE_SENDER_ID.isEmpty()&&BuildConfig.FIREBASE_API_KEY!=null&&!BuildConfig.FIREBASE_API_KEY.isEmpty();}
    public static void sync(Context c){
        if(c==null||!firebaseConfigured()||FirebaseApp.getApps(c).isEmpty())return;String auth=SessionManager.getToken(c);if(auth==null||auth.trim().isEmpty())return;
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task->{if(!task.isSuccessful()||task.getResult()==null)return;BackendClient.registerPushToken(auth,task.getResult(),new BackendClient.Callback(){public void onSuccess(org.json.JSONObject d){}public void onError(String m){}});});
    }
}
