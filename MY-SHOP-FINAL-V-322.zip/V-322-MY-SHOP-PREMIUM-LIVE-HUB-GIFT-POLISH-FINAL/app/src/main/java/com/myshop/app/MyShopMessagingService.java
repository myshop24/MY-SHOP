package com.myshop.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;

/** V-322: Messenger/WhatsApp-style system notification and direct Chat deep-link. */
public class MyShopMessagingService extends FirebaseMessagingService {
    private static final java.util.concurrent.ExecutorService AVATAR_POOL=Executors.newSingleThreadExecutor();
    public static final String MESSAGE_CHANNEL="myshop_messages",GENERAL_CHANNEL="myshop_general";
    @Override public void onNewToken(String token){super.onNewToken(token);PushRegistration.sync(this);}
    @Override public void onMessageReceived(RemoteMessage remote){super.onMessageReceived(remote);Map<String,String>d=remote.getData();String type=s(d.get("type")),actor=s(d.get("actorUserId")),title=s(d.get("title")),body=s(d.get("body")),avatar=s(d.get("actorAvatarUrl"));if(title.isEmpty())title="MY SHOP";show(type,actor,title,body,avatar);}
    private void show(String type,String actor,String title,String body,String avatarUrl){
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(nm==null)return;ensureChannels(nm);
        Intent i;if("MESSAGE".equals(type)&&!actor.isEmpty()){i=new Intent(this,ChatActivity.class);i.putExtra("userId",actor);i.putExtra("name",title);}else{i=new Intent(this,MainActivity.class);}i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int request=Math.abs((type+"|"+actor).hashCode());PendingIntent pi=PendingIntent.getActivity(this,request,i,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));String channel="MESSAGE".equals(type)?MESSAGE_CHANNEL:GENERAL_CHANNEL;
        NotificationCompat.Builder b=new NotificationCompat.Builder(this,channel).setSmallIcon(R.drawable.myshop_icon).setContentTitle(title).setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body)).setAutoCancel(true).setContentIntent(pi).setPriority(NotificationCompat.PRIORITY_HIGH).setCategory("MESSAGE".equals(type)?NotificationCompat.CATEGORY_MESSAGE:NotificationCompat.CATEGORY_SOCIAL).setGroup("MESSAGE".equals(type)?"myshop_message_group":"myshop_general_group").setNumber(1).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setOnlyAlertOnce(false);
        int id="MESSAGE".equals(type)&&!actor.isEmpty()?100000+Math.abs(actor.hashCode()%800000):900000+Math.abs((type+body).hashCode()%90000);nm.notify(id,b.build());
        if("MESSAGE".equals(type)&&avatarUrl!=null&&!avatarUrl.trim().isEmpty()){
            AVATAR_POOL.execute(()->{Bitmap avatar=loadAvatar(avatarUrl);if(avatar!=null){b.setLargeIcon(avatar).setOnlyAlertOnce(true);nm.notify(id,b.build());}});
        }
    }
    private Bitmap loadAvatar(String raw){HttpURLConnection c=null;try{URL u=new URL(raw);c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(2500);c.setReadTimeout(2500);c.setInstanceFollowRedirects(true);return BitmapFactory.decodeStream(c.getInputStream());}catch(Exception ignored){return null;}finally{if(c!=null)c.disconnect();}}
    public static void ensureChannels(NotificationManager nm){if(Build.VERSION.SDK_INT<26)return;NotificationChannel m=new NotificationChannel(MESSAGE_CHANNEL,"MY SHOP Messages",NotificationManager.IMPORTANCE_HIGH);m.setDescription("New MY SHOP chat messages");m.enableVibration(true);NotificationChannel g=new NotificationChannel(GENERAL_CHANNEL,"MY SHOP Notifications",NotificationManager.IMPORTANCE_DEFAULT);g.setDescription("MY SHOP updates and live alerts");nm.createNotificationChannel(m);nm.createNotificationChannel(g);}
    private static String s(String x){return x==null?"":x;}
}
