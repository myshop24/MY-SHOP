# MY-SHOP-DEVELOPER-HANDOFF — V-322

## Starting point
This ZIP is the complete V-322 source base. A future V-323 developer should start from this package and should not need V-321.

## Architecture
- Android Java app: `app/`
- Cloudflare Worker/API: `backend/worker/`
- D1/R2 binding names and production URLs are preserved from the incoming source.
- Build identity: `SOURCE_BUILD_ID.txt` + Android versionCode/versionName.

## V-322 focus
47-item Live Room/Gift/Join/Comment polish scope plus Messenger/WhatsApp-style message push notification foundation. See `V-322_RELEASE_NOTES.md`.

## Push configuration
Do not commit Firebase service-account JSON or API secrets. Supply Android Firebase values with build environment variables and set Worker `FCM_SERVICE_ACCOUNT_JSON` as a Cloudflare secret.

## Validation
See `V-322_VALIDATION_REPORT.txt` and `V-322_PLAY_COMPLIANCE_CHECKLIST.md`. Production RTC, D1 migration, FCM delivery, and signed Play release require deployment/device tests outside static source validation.

## Protected behavior
Do not change the 12-seat 6+6 structure, separate Coin/Gold Coin economy/catalogs, purchased-vs-earned protections, or Live transient-comment policy unless explicitly instructed.
