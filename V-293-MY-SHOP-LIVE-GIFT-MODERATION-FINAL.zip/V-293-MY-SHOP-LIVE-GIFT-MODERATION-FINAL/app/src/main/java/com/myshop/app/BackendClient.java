package com.myshop.app;

import android.os.Handler;
import android.os.Looper;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

/** Small dependency-free HTTP client for the Cloudflare Worker backend. */
public final class BackendClient {
    private static final ExecutorService IO = Executors.newCachedThreadPool();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private BackendClient() {}

    public interface Callback { void onSuccess(JSONObject data); void onError(String message); }

    private static String baseUrl() { return BuildConfig.MYSHOP_BACKEND_URL == null ? "" : BuildConfig.MYSHOP_BACKEND_URL.trim().replaceAll("/$", ""); }
    public static boolean configured() { return !baseUrl().isEmpty() && !baseUrl().contains("YOUR-WORKER"); }

    public static void login(String identifier, String password, Callback cb) {
        try { JSONObject b=new JSONObject().put("identifier",identifier).put("password",password); post("/v1/auth/login",b,null,cb); }
        catch(Exception e){ cb.onError("Invalid login request"); }
    }

    public static void register(String name,String email,String mobile,String password,String question,String answer,Callback cb) {
        try {
            JSONObject b=new JSONObject().put("name",name).put("email",email).put("mobile",mobile).put("password",password).put("securityQuestion",question).put("securityAnswer",answer);
            post("/v1/auth/register",b,null,cb);
        } catch(Exception e){ cb.onError("Invalid registration request"); }
    }

    public static void resetPassword(String identifier,String answer,String newPassword,Callback cb) {
        try { JSONObject b=new JSONObject().put("identifier",identifier).put("answer",answer).put("newPassword",newPassword); post("/v1/auth/password/reset",b,null,cb); }
        catch(Exception e){ cb.onError("Invalid reset request"); }
    }

    public static void changePassword(String token,String currentPassword,String newPassword,Callback cb) {
        try { JSONObject b=new JSONObject().put("currentPassword",currentPassword).put("newPassword",newPassword); post("/v1/auth/password/change",b,token,cb); }
        catch(Exception e){ cb.onError("Invalid password change request"); }
    }

    public static void me(String token,Callback cb) { get("/v1/me",token,cb); }
    public static void coinInfo(String token,Callback cb) { get("/v1/coins",token,cb); }
    public static void securityQuestions(String identifier,Callback cb) {
        try { get("/v1/auth/password/questions?identifier=" + java.net.URLEncoder.encode(identifier,"UTF-8"), null, cb); }
        catch(Exception e){ cb.onError("Invalid identifier"); }
    }
    public static void dashboard(String token,Callback cb) { get("/v1/dashboard/config",token,cb); }
    public static void notifications(String token,Callback cb) { get("/v1/notifications",token,cb); }
    public static void newPeople(String token,int limit,int offset,Callback cb) { get("/v1/people/new?limit="+Math.max(1,Math.min(500,limit))+"&offset="+Math.max(0,offset),token,cb); }
    public static void userProfile(String token,String userId,Callback cb){ try{get("/v1/users/profile?userId="+java.net.URLEncoder.encode(userId,"UTF-8"),token,cb);}catch(Exception e){cb.onError("Invalid profile");} }
    public static void sendFriendRequest(String token,String userId,Callback cb) { try { post("/v1/friends/request",new JSONObject().put("userId",userId),token,cb); } catch(Exception e){ cb.onError("Invalid friend request"); } }
    public static void friends(String token,Callback cb){ get("/v1/friends",token,cb); }
    public static void removeFriend(String token,String userId,Callback cb){ try{post("/v1/friends/remove",new JSONObject().put("userId",userId),token,cb);}catch(Exception e){cb.onError("Invalid friend remove request");} }
    public static void cancelFriendRequest(String token,String userId,Callback cb){ try{post("/v1/friends/cancel",new JSONObject().put("userId",userId),token,cb);}catch(Exception e){cb.onError("Invalid friend cancel request");} }
    public static void toggleFollow(String token,String userId,Callback cb){ try{post("/v1/follow/toggle",new JSONObject().put("userId",userId),token,cb);}catch(Exception e){cb.onError("Invalid follow request");} }
    public static void socialStats(String token,Callback cb){ get("/v1/me/social-stats",token,cb); }
    public static void liveProfiles(String token,int limit,Callback cb){ get("/v1/live/profiles?limit="+Math.max(1,Math.min(100,limit)),token,cb); }
    public static void setAppPresence(String token,boolean active,Callback cb){ try{post("/v1/app/presence",new JSONObject().put("active",active),token,cb);}catch(Exception e){cb.onError("App presence failed");} }
    public static void setLivePresence(String token,boolean active,Callback cb){ try{post("/v1/live/presence",new JSONObject().put("active",active),token,cb);}catch(Exception e){cb.onError("Live presence failed");} }
    public static void liveViewer(String token,String hostId,boolean joined,Callback cb){ try{post("/v1/live/viewer",new JSONObject().put("hostId",hostId).put("joined",joined),token,cb);}catch(Exception e){cb.onError("Live viewer update failed");} }
    public static void liveRoomState(String token,String hostId,Callback cb){ get("/v1/live/room?hostId="+hostId,token,cb); }
    public static void liveSpeakRequest(String token,String hostId,Callback cb){ try{post("/v1/live/request",new JSONObject().put("hostId",hostId),token,cb);}catch(Exception e){cb.onError("Speak request failed");} }
    public static void liveRequestAction(String token,String requesterId,boolean accept,Callback cb){ try{post("/v1/live/request/action",new JSONObject().put("requesterId",requesterId).put("action",accept?"ACCEPT":"REJECT"),token,cb);}catch(Exception e){cb.onError("Request action failed");} }
    public static void liveLeaveSeat(String token,String hostId,Callback cb){ try{post("/v1/live/seat/leave",new JSONObject().put("hostId",hostId),token,cb);}catch(Exception e){cb.onError("Leave seat failed");} }
    public static void liveSpecialGuest(String token,String userId,boolean clear,Callback cb){ try{post("/v1/live/special-guest",new JSONObject().put("userId",userId==null?"":userId).put("clear",clear),token,cb);}catch(Exception e){cb.onError("Special guest update failed");} }
    public static void liveSpeakerRemove(String token,String userId,Callback cb){ try{post("/v1/live/speaker/remove",new JSONObject().put("userId",userId),token,cb);}catch(Exception e){cb.onError("Speaker remove failed");} }
    public static void liveRoomConfig(String token,String title,String topic,String pinned,String themeKey,Callback cb){ try{JSONObject j=new JSONObject(); if(title!=null)j.put("title",title); if(topic!=null)j.put("topic",topic); if(pinned!=null)j.put("pinnedMessage",pinned); if(themeKey!=null)j.put("themeKey",themeKey); post("/v1/live/room/config",j,token,cb);}catch(Exception e){cb.onError("Room settings failed");} }
    public static void liveSeatLock(String token,int seatNo,boolean locked,Callback cb){ try{post("/v1/live/seat/lock",new JSONObject().put("seatNo",seatNo).put("locked",locked),token,cb);}catch(Exception e){cb.onError("Seat lock failed");} }
    public static void liveParticipantState(String token,String hostId,boolean micOn,boolean speaking,String networkQuality,Callback cb){ try{post("/v1/live/participant/state",new JSONObject().put("hostId",hostId).put("micOn",micOn).put("speaking",speaking).put("networkQuality",networkQuality),token,cb);}catch(Exception e){cb.onError("Participant state failed");} }
    public static void liveShare(String token,String hostId,Callback cb){ try{post("/v1/live/share",new JSONObject().put("hostId",hostId),token,cb);}catch(Exception e){cb.onError("Share count failed");} }
    public static void liveComment(String token,String hostId,String message,Callback cb){ try{post("/v1/live/comment",new JSONObject().put("hostId",hostId).put("message",message),token,cb);}catch(Exception e){cb.onError("Comment failed");} }
    public static void liveThemes(String token,Callback cb){ get("/v1/live/themes",token,cb); }
    public static void liveSummary(String token,String hostId,Callback cb){ get("/v1/live/summary?hostId="+hostId,token,cb); }
    public static void liveModeration(String token,String hostId,String userId,String action,Callback cb){ try{post("/v1/live/moderation",new JSONObject().put("hostId",hostId).put("userId",userId).put("action",action),token,cb);}catch(Exception e){cb.onError("Moderation failed");} }
    public static void liveGifts(String token,Callback cb){ get("/v1/live/gifts",token,cb); }
    public static void liveGiftSend(String token,String hostId,String receiverId,long giftId,Callback cb){ try{post("/v1/live/gifts/send",new JSONObject().put("hostId",hostId).put("receiverId",receiverId).put("giftId",giftId),token,cb);}catch(Exception e){cb.onError("Gift send failed");} }
    public static void adminLiveGifts(String token,Callback cb){ get("/v1/admin/live/gifts",token,cb); }
    public static void adminLiveGiftSave(String token,JSONObject gift,Callback cb){ post("/v1/admin/live/gifts/save",gift,token,cb); }
    public static void adminLiveGiftDelete(String token,long id,Callback cb){ try{post("/v1/admin/live/gifts/delete",new JSONObject().put("id",id),token,cb);}catch(Exception e){cb.onError("Gift delete failed");} }
    public static void adminLiveGiftAssetUpload(String token,java.io.InputStream input,String fileName,String mime,Callback cb){ uploadMultipart(token,"/v1/admin/live/gifts/asset/upload",input,fileName,mime,null,cb); }
    public static void adminLiveTheme(String token,String action,String key,String name,String backgroundUrl,String accent,boolean enabled,int sortOrder,Callback cb){ try{post("/v1/admin/live/themes",new JSONObject().put("action",action).put("themeKey",key).put("name",name).put("backgroundUrl",backgroundUrl).put("accent",accent).put("enabled",enabled).put("sortOrder",sortOrder),token,cb);}catch(Exception e){cb.onError("Live theme update failed");} }
    public static void userPosts(String token,String userId,String media,Callback cb){ try{get("/v1/users/posts?userId="+java.net.URLEncoder.encode(userId,"UTF-8")+"&media="+java.net.URLEncoder.encode(media==null?"all":media,"UTF-8"),token,cb);}catch(Exception e){cb.onError("Profile posts unavailable");} }
    public static void profilePrivacy(String token,Callback cb){ get("/v1/me/privacy",token,cb); }
    public static void updateProfilePrivacy(String token,String posts,String media,Callback cb){ try{request("PUT","/v1/me/privacy",new JSONObject().put("postsVisibility",posts).put("mediaVisibility",media),token,cb);}catch(Exception e){cb.onError("Invalid privacy setting");} }
    public static void messageInbox(String token,Callback cb){ get("/v1/messages/inbox",token,cb); }
    public static void messageThread(String token,String userId,Callback cb){ try{get("/v1/messages/thread?userId="+java.net.URLEncoder.encode(userId,"UTF-8"),token,cb);}catch(Exception e){cb.onError("Invalid conversation");} }
    public static void messageSend(String token,String userId,String message,Callback cb){ try{post("/v1/messages/send",new JSONObject().put("userId",userId).put("message",message),token,cb);}catch(Exception e){cb.onError("Invalid message");} }
    public static void messageUnread(String token,Callback cb){ get("/v1/messages/unread",token,cb); }
    public static void respondFriendRequest(String token,String userId,String action,Callback cb){ try{post("/v1/friends/respond",new JSONObject().put("userId",userId).put("action",action),token,cb);}catch(Exception e){cb.onError("Invalid response");} }
    public static void adminSystemHealth(String token,Callback cb) { get("/v1/admin/system/health",token,cb); }
    public static void feedList(String token, int limit, long before, Callback cb) {
        try {
            String q="/v1/feed?limit="+Math.max(1,Math.min(10,limit));
            if(before>0) q += "&before="+before;
            get(q,token,cb);
        } catch(Exception e){ cb.onError("Invalid Feed request"); }
    }
    public static void feedPost(String token,long postId,Callback cb) {
        try { get("/v1/feed/post?id="+postId,token,cb); } catch(Exception e){ cb.onError("Invalid post request"); }
    }
    public static void videoList(String token,int limit,long before,Callback cb) {
        try { String q="/v1/videos?limit="+Math.max(1,Math.min(30,limit)); if(before>0)q+="&before="+before; get(q,token,cb); }
        catch(Exception e){ cb.onError("Invalid video request"); }
    }
    public static void feedUpload(String token, java.io.InputStream input, String fileName, String mime, String mediaType, String caption, Callback cb) {
        uploadMultipart(token,"/v1/feed/upload",input,fileName,mime,new String[][]{{"mediaType",mediaType},{"caption",caption}},cb);
    }
    public static void feedLike(String token,long postId,Callback cb){ try { request("POST","/v1/feed/like",new JSONObject().put("postId",postId),token,cb); } catch(Exception e){ cb.onError("Invalid like request"); } }
    public static void feedComment(String token,long postId,String comment,Callback cb){ try { request("POST","/v1/feed/comment",new JSONObject().put("postId",postId).put("comment",comment),token,cb); } catch(Exception e){ cb.onError("Invalid comment request"); } }
    public static void feedComments(String token,long postId,Callback cb){ try { get("/v1/feed/comments?postId="+postId,token,cb); } catch(Exception e){ cb.onError("Invalid comments request"); } }
    public static void feedText(String token, String caption, Callback cb) { try { request("POST","/v1/feed/text",new JSONObject().put("caption",caption==null?"":caption),token,cb); } catch(Exception e){ cb.onError("Invalid text post request"); } }
    public static void feedDelete(String token,long id,Callback cb) {
        try { post("/v1/feed/delete",new JSONObject().put("id",id),token,cb); } catch(Exception e){ cb.onError("Invalid post delete request"); }
    }
    public static void adminFeedList(String token,Callback cb) { get("/v1/admin/feed",token,cb); }
    public static void moderatorFeedDelete(String token,long id,String reason,Callback cb) {
        try { post("/v1/admin/feed/delete",new JSONObject().put("id",id).put("reason",reason==null?"":reason),token,cb); } catch(Exception e){ cb.onError("Invalid moderation request"); }
    }
    public static void markNotificationRead(String token,long id,Callback cb) { try{post("/v1/notifications/read",new JSONObject().put("id",id),token,cb);}catch(Exception e){cb.onError("Invalid notification");} }
    public static void markNotificationsRead(String token,Callback cb) { post("/v1/notifications/read-all", new JSONObject(), token, cb); }
    public static void logout(String token,Callback cb) { post("/v1/auth/logout",new JSONObject(),token,cb); }
    public static void adminPermissions(String token, Callback cb) { get("/v1/admin/permissions", token, cb); }
    public static void updateProfile(String token, String name, String email, String mobile, String bio, Callback cb) {
        try { request("PUT", "/v1/me/profile", new JSONObject().put("name",name).put("email",email).put("mobile",mobile).put("bio",bio), token, cb); }
        catch(Exception e) { cb.onError("Invalid profile data"); }
    }
    public static void uploadAvatar(String token, java.io.InputStream input, String fileName, String mime, Callback cb) {
        uploadMultipart(token,"/v1/me/avatar/upload",input,fileName,mime,null,cb);
    }
    public static void uploadCover(String token, java.io.InputStream input, String fileName, String mime, Callback cb) {
        uploadMultipart(token,"/v1/me/cover/upload",input,fileName,mime,null,cb);
    }
    public static void deleteCover(String token, Callback cb) { post("/v1/me/cover/delete",new JSONObject(),token,cb); }
    public static void coins(String token, Callback cb) { get("/v1/coins",token,cb); }
    public static void giftHistory(String token, Callback cb) { get("/v1/gifts/history",token,cb); }
    public static void requestCoinPurchase(String token, int coins, int amountMinor, String method, String reference, Callback cb) {
        try { request("POST","/v1/coins/purchase-request",new JSONObject().put("coins",coins).put("amountMinor",amountMinor).put("paymentMethod",method).put("reference",reference),token,cb); }
        catch(Exception e) { cb.onError("Invalid coin purchase request"); }
    }
    public static void walletProfile(String token, Callback cb) { get("/v1/wallet/profile",token,cb); }
    public static void storeCatalog(String token, Callback cb) { get("/v1/store/catalog",token,cb); }
    public static void adminStoreCatalog(String token, Callback cb) { get("/v1/admin/store/catalog",token,cb); }
    public static void storePurchase(String token,long productId,String paymentMode,String method,String reference,Callback cb){ try{request("POST","/v1/store/purchase-request",new JSONObject().put("productId",productId).put("paymentMode",paymentMode).put("paymentMethod",method).put("reference",reference),token,cb);}catch(Exception e){cb.onError("Invalid store purchase");} }
    public static void setActiveBadge(String token,long badgeId,Callback cb){ try{request("POST","/v1/badges/active",new JSONObject().put("badgeId",badgeId),token,cb);}catch(Exception e){cb.onError("Invalid badge selection");} }
    public static void adminStoreSave(String token,JSONObject item,Callback cb){ request("POST","/v1/admin/store/catalog/save",item,token,cb); }
    public static void adminStoreToggle(String token,long id,boolean enabled,Callback cb){ try{request("POST","/v1/admin/store/catalog/toggle",new JSONObject().put("id",id).put("enabled",enabled),token,cb);}catch(Exception e){cb.onError("Invalid catalog item");} }
    public static void adminStoreGrant(String token,String userId,long productId,String note,Callback cb){ try{request("POST","/v1/admin/store/grant",new JSONObject().put("userId",userId).put("productId",productId).put("note",note),token,cb);}catch(Exception e){cb.onError("Invalid catalog grant");} }
    public static void adminStoreAssetUpload(String token,java.io.InputStream input,String fileName,String mime,Callback cb){ uploadMultipart(token,"/v1/admin/store/asset/upload",input,fileName,mime,null,cb); }
    public static void adminAssetUpload(String token,java.io.InputStream input,String fileName,String mime,String purpose,Callback cb){ uploadMultipart(token,"/v1/admin/asset/upload",input,fileName,mime,new String[][]{{"purpose",purpose==null?"asset":purpose}},cb); }
    public static void requestWalletPurchase(String token,String itemType,String itemCode,int units,int amountMinor,String method,String reference,String duration,Callback cb){
        try{ request("POST","/v1/wallet/purchase-request",new JSONObject().put("itemType",itemType).put("itemCode",itemCode).put("units",units).put("amountMinor",amountMinor).put("paymentMethod",method).put("reference",reference).put("duration",duration),token,cb); }catch(Exception e){cb.onError("Invalid purchase request");}
    }
    public static void requestGoldWithdrawal(String token,int gold,String method,String account,String note,Callback cb){
        try{ request("POST","/v1/wallet/withdraw-request",new JSONObject().put("gold",gold).put("paymentMethod",method).put("account",account).put("note",note),token,cb); }catch(Exception e){cb.onError("Invalid withdrawal request");}
    }
    public static void adminWalletGrant(String token,String userId,String itemType,String itemCode,int units,int days,String note,Callback cb){
        try{ request("POST","/v1/admin/wallet/grant",new JSONObject().put("userId",userId).put("itemType",itemType).put("itemCode",itemCode).put("units",units).put("days",days).put("note",note),token,cb); }catch(Exception e){cb.onError("Invalid admin grant");}
    }

    public static void adminDashboardPut(String token, String breakingNews, String myShopUrl, String liveTvUrl, String externalMovieUrl, String chatUrl, String powerAdTitle, String powerAdByline, Callback cb) {
        adminDashboardPut(token,breakingNews,myShopUrl,liveTvUrl,externalMovieUrl,chatUrl,powerAdTitle,powerAdByline,null,null,null,null,cb);
    }
    public static void adminDashboardPut(String token, String breakingNews, String myShopUrl, String liveTvUrl, String externalMovieUrl, String chatUrl, String powerAdTitle, String powerAdByline, String dashboardBgColor, String dashboardBlueColor, String dashboardPurpleColor, String dashboardPinkColor, Callback cb) {
        adminDashboardPutInternal(token,breakingNews,myShopUrl,liveTvUrl,externalMovieUrl,chatUrl,powerAdTitle,powerAdByline,dashboardBgColor,dashboardBlueColor,dashboardPurpleColor,dashboardPinkColor,null,null,null,cb);
    }
    public static void adminDashboardPut(String token, String breakingNews, String myShopUrl, String liveTvUrl, String externalMovieUrl, String chatUrl, String powerAdTitle, String powerAdByline, String dashboardBgColor, String dashboardBlueColor, String dashboardPurpleColor, String dashboardPinkColor, float breakingNewsTextSize, Callback cb) {
        adminDashboardPutInternal(token,breakingNews,myShopUrl,liveTvUrl,externalMovieUrl,chatUrl,powerAdTitle,powerAdByline,dashboardBgColor,dashboardBlueColor,dashboardPurpleColor,dashboardPinkColor,breakingNewsTextSize,null,null,cb);
    }
    public static void adminDashboardPut(String token, String breakingNews, String myShopUrl, String liveTvUrl, String externalMovieUrl, String chatUrl, String powerAdTitle, String powerAdByline, String dashboardBgColor, String dashboardBlueColor, String dashboardPurpleColor, String dashboardPinkColor, float breakingNewsTextSize, String breakingNewsBgColor, String breakingNewsTextColor, Callback cb) {
        adminDashboardPutInternal(token,breakingNews,myShopUrl,liveTvUrl,externalMovieUrl,chatUrl,powerAdTitle,powerAdByline,dashboardBgColor,dashboardBlueColor,dashboardPurpleColor,dashboardPinkColor,breakingNewsTextSize,breakingNewsBgColor,breakingNewsTextColor,cb);
    }
    private static void adminDashboardPutInternal(String token, String breakingNews, String myShopUrl, String liveTvUrl, String externalMovieUrl, String chatUrl, String powerAdTitle, String powerAdByline, String dashboardBgColor, String dashboardBlueColor, String dashboardPurpleColor, String dashboardPinkColor, Float breakingNewsTextSize, String breakingNewsBgColor, String breakingNewsTextColor, Callback cb) {
        try {
            JSONObject b = new JSONObject().put("breakingNews", breakingNews).put("myShopUrl", myShopUrl).put("liveTvUrl", liveTvUrl).put("externalMovieUrl", externalMovieUrl).put("chatUrl", chatUrl).put("powerAdTitle", powerAdTitle).put("powerAdByline", powerAdByline);
            if(dashboardBgColor!=null)b.put("dashboardBgColor",dashboardBgColor); if(dashboardBlueColor!=null)b.put("dashboardBlueColor",dashboardBlueColor); if(dashboardPurpleColor!=null)b.put("dashboardPurpleColor",dashboardPurpleColor); if(dashboardPinkColor!=null)b.put("dashboardPinkColor",dashboardPinkColor);
            if(breakingNewsTextSize!=null)b.put("breakingNewsTextSize",breakingNewsTextSize); if(breakingNewsBgColor!=null)b.put("breakingNewsBgColor",breakingNewsBgColor); if(breakingNewsTextColor!=null)b.put("breakingNewsTextColor",breakingNewsTextColor);
            request("PUT", "/v1/admin/dashboard/config", b, token, cb);
        } catch(Exception e) { cb.onError("Invalid admin settings"); }
    }
    public static void adminAction(String token, String userId, String action, Callback cb) {
        try {
            JSONObject b = new JSONObject().put("userId", userId).put("action", action);
            post("/v1/admin/actions", b, token, cb);
        } catch(Exception e) { cb.onError("Invalid admin action"); }
    }
    public static void adminContentPut(String token, JSONObject payload, Callback cb) { request("PUT", "/v1/admin/content", payload, token, cb); }
    public static void adminMediaList(String token, String folder, Callback cb) {
        String f = folder == null ? "" : folder.trim().toLowerCase();
        try { get("/v1/admin/media?folder=" + java.net.URLEncoder.encode(f,"UTF-8"), token, cb); }
        catch(Exception e) { cb.onError("Invalid gallery folder"); }
    }
    public static void adminBannerDelete(String token, String folder, int slot, Callback cb) { try { post("/v1/admin/banner/delete", new JSONObject().put("folder",folder).put("slot",slot), token, cb); } catch(Exception e) { cb.onError("Invalid banner slot"); } }
    public static void adminBannerUpdate(String token, String folder, int slot, String caption, String targetUrl, Callback cb) { try { request("PUT", "/v1/admin/banner/update", new JSONObject().put("folder",folder).put("slot",slot).put("caption",caption).put("targetUrl",targetUrl), token, cb); } catch(Exception e) { cb.onError("Invalid banner update"); } }
    public static void adminBannerUpload(String token, java.io.InputStream input, String fileName, String mime, String folder, int slot, String caption, String targetUrl, Callback cb) {
        uploadMultipart(token,"/v1/admin/banner/upload",input,fileName,mime,new String[][]{{"folder",folder},{"slot",String.valueOf(slot)},{"caption",caption},{"targetUrl",targetUrl}},cb);
    }
    public static void adminMediaDelete(String token, long id, Callback cb) { try { post("/v1/admin/media/delete", new JSONObject().put("id", id), token, cb); } catch(Exception e) { cb.onError("Invalid media id"); } }
    public static void adminMediaUpdate(String token, long id, String title, String caption, Callback cb) { try { request("PUT", "/v1/admin/media/update", new JSONObject().put("id",id).put("title",title).put("caption",caption), token, cb); } catch(Exception e) { cb.onError("Invalid media update"); } }

    // User-owned Gallery: unlimited item count; each file is still subject to server/R2 limits.
    public static void galleryList(String token, String folder, Callback cb) {
        try { get("/v1/gallery?folder=" + java.net.URLEncoder.encode(folder==null?"":folder,"UTF-8"), token, cb); }
        catch(Exception e) { cb.onError("Invalid gallery folder"); }
    }
    public static void galleryUpload(String token, java.io.InputStream input, String fileName, String mime, String folder, String title, String caption, Callback cb) {
        uploadMultipart(token,"/v1/gallery/upload",input,fileName,mime,new String[][]{{"folder",folder},{"title",title},{"caption",caption}},cb);
    }
    public static void galleryUpdate(String token,long id,String title,String caption,Callback cb) {
        try { request("PUT","/v1/gallery/update",new JSONObject().put("id",id).put("title",title).put("caption",caption),token,cb); }
        catch(Exception e){ cb.onError("Invalid Gallery edit request"); }
    }
    public static void galleryDelete(String token,long id,Callback cb) {
        try { post("/v1/gallery/delete",new JSONObject().put("id",id),token,cb); }
        catch(Exception e){ cb.onError("Invalid Gallery delete request"); }
    }
    public static void adminAds(String token,String boxKey,Callback cb) {
        try { get("/v1/admin/ads?box_key="+java.net.URLEncoder.encode(boxKey==null?"":boxKey,"UTF-8"),token,cb); }
        catch(Exception e){ cb.onError("Invalid ad folder"); }
    }
    public static void adminAdUpload(String token,java.io.InputStream input,String fileName,String mime,String boxKey,int slot,String caption,String targetUrl,boolean active,int durationSec,Callback cb) {
        uploadMultipart(token,"/v1/admin/ad/upload",input,fileName,mime,new String[][]{{"boxKey",boxKey},{"slot",String.valueOf(slot)},{"caption",caption},{"targetUrl",targetUrl},{"active",String.valueOf(active)},{"durationSec",String.valueOf(durationSec)}},cb);
    }
    public static void adminAdUpload(String token,java.io.InputStream input,String fileName,String mime,String boxKey,int slot,String caption,String targetUrl,int durationSec,Callback cb) {
        adminAdUpload(token,input,fileName,mime,boxKey,slot,caption,targetUrl,true,durationSec,cb);
    }
    public static void adminAdUpdate(String token,long id,String caption,String targetUrl,boolean active,int durationSec,Callback cb) {
        try { request("PUT","/v1/admin/ad/update",new JSONObject().put("id",id).put("caption",caption).put("targetUrl",targetUrl).put("active",active).put("durationSec",durationSec),token,cb); }
        catch(Exception e){ cb.onError("Invalid ad update request"); }
    }
    public static void adminAdDelete(String token,long id,Callback cb) {
        try { post("/v1/admin/ad/delete",new JSONObject().put("id",id),token,cb); }
        catch(Exception e){ cb.onError("Invalid ad delete request"); }
    }

    public static void adminMediaUpload(String token, java.io.InputStream input, long length, String fileName, String mime, String folder, String title, String caption, int displayOrder, Callback cb) {
        IO.execute(() -> {
            HttpURLConnection c=null; String boundary="----MYSHOP"+System.currentTimeMillis();
            try {
                c=(HttpURLConnection)new URL(baseUrl()+"/v1/admin/media/upload").openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setDoOutput(true); c.setChunkedStreamingMode(8192); c.setRequestProperty("Accept","application/json"); c.setRequestProperty("Authorization","Bearer "+token); c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
                try(OutputStream os=c.getOutputStream()) {
                    writePart(os,boundary,"folder",folder,null,null); writePart(os,boundary,"title",title,null,null); writePart(os,boundary,"caption",caption,null,null); writePart(os,boundary,"displayOrder",String.valueOf(displayOrder),null,null);
                    String safe=fileName==null?"media":fileName.replace("\"","_");
                    os.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\"file\"; filename=\""+safe+"\"\r\nContent-Type: "+(mime==null?"application/octet-stream":mime)+"\r\n\r\n").getBytes(StandardCharsets.UTF_8));
                    byte[] buf=new byte[8192]; int n; while((n=input.read(buf))!=-1) os.write(buf,0,n); os.write("\r\n".getBytes(StandardCharsets.UTF_8)); os.write(("--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8));
                } finally { try { input.close(); } catch(Exception ignored){} }
                int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream(); StringBuilder outText=new StringBuilder(); if(in!=null){try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)outText.append(line);}}
                JSONObject out=outText.length()>0?new JSONObject(outText.toString()):new JSONObject(); MAIN.post(() -> {if(code>=200&&code<300)cb.onSuccess(out);else cb.onError(errorText(out,code));});
            } catch(Exception e){ MAIN.post(() -> cb.onError("Media upload failed: "+e.getMessage())); } finally {if(c!=null)c.disconnect();}
        });
    }
    private static void uploadMultipart(String token,String path,java.io.InputStream input,String fileName,String mime,String[][] fields,Callback cb){
        IO.execute(() -> { HttpURLConnection c=null; String boundary="----MYSHOP"+System.currentTimeMillis(); try {
            c=(HttpURLConnection)new URL(baseUrl()+path).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setDoOutput(true); c.setChunkedStreamingMode(8192); c.setRequestProperty("Accept","application/json"); c.setRequestProperty("Authorization","Bearer "+token); c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
            try(OutputStream os=c.getOutputStream()){ if(fields!=null)for(String[] f:fields)writePart(os,boundary,f[0],f[1],null,null); String safe=fileName==null?"media":fileName.replace("\"","_"); os.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\"file\"; filename=\""+safe+"\"\r\nContent-Type: "+(mime==null?"application/octet-stream":mime)+"\r\n\r\n").getBytes(StandardCharsets.UTF_8)); byte[] buf=new byte[8192];int n;while((n=input.read(buf))!=-1)os.write(buf,0,n);os.write("\r\n".getBytes(StandardCharsets.UTF_8));os.write(("--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8)); } finally {try{input.close();}catch(Exception ignored){}}
            int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();StringBuilder st=new StringBuilder();if(in!=null){try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)st.append(line);}} JSONObject out=st.length()>0?new JSONObject(st.toString()):new JSONObject();MAIN.post(()->{if(code>=200&&code<300)cb.onSuccess(out);else cb.onError(errorText(out,code));});
        }catch(Exception e){MAIN.post(()->cb.onError("Upload failed: "+e.getMessage()));}finally{if(c!=null)c.disconnect();}});
    }

    private static void writePart(OutputStream os,String boundary,String name,String value,String ignored1,String ignored2) throws Exception { String v=value==null?"":value; os.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\""+name+"\"\r\n\r\n"+v+"\r\n").getBytes(StandardCharsets.UTF_8)); }

    private static void get(String path,String token,Callback cb) { request("GET",path,null,token,cb); }
    private static void post(String path,JSONObject body,String token,Callback cb) { request("POST",path,body,token,cb); }

    private static void request(String method,String path,JSONObject body,String token,Callback cb) {
        if(!configured()){ cb.onError("Backend URL is not configured yet."); return; }
        IO.execute(() -> {
            HttpURLConnection c=null;
            try {
                c=(HttpURLConnection)new URL(baseUrl()+path).openConnection(); c.setRequestMethod(method); c.setConnectTimeout(7000); c.setReadTimeout(10000); c.setRequestProperty("Accept","application/json");
                if(token!=null&&!token.isEmpty()) c.setRequestProperty("Authorization","Bearer "+token);
                if(body!=null){ c.setRequestProperty("Content-Type","application/json; charset=utf-8"); c.setDoOutput(true); try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));} }
                int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream(); StringBuilder s=new StringBuilder();
                if(in!=null){try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)s.append(line);}}
                JSONObject out=s.length()>0?new JSONObject(s.toString()):new JSONObject();
                MAIN.post(() -> { if(code>=200&&code<300) cb.onSuccess(out); else cb.onError(errorText(out,code)); });
            } catch(Exception e){ MAIN.post(() -> cb.onError("Backend connection failed. Check internet/Worker URL.")); }
            finally { if(c!=null)c.disconnect(); }
        });
    }
    private static String errorText(JSONObject o,int code){ String e=o.optString("error",""); String detail=o.optString("message",""); if("ACCOUNT_EXISTS".equals(e))return "এই Email/Mobile দিয়ে Account আগে থেকেই আছে।"; if("INVALID_CREDENTIALS".equals(e))return "Login ID অথবা Password ভুল।"; if("ANSWER_NOT_MATCHED".equals(e))return "সিকিউরিটি উত্তর সঠিক নয়।"; if("NO_ID_AVAILABLE".equals(e))return "নতুন User ID পাওয়া যাচ্ছে না।"; if("R2_NOT_CONFIGURED".equals(e))return "R2 storage is not configured on the Worker."; if("AVATAR_TOO_LARGE".equals(e))return "Profile photo is too large (max 5 MB)."; if("AVATAR_TYPE_MISMATCH".equals(e))return "Please select an image for the profile photo."; if("COVER_TOO_LARGE".equals(e))return "Cover photo is too large (max 8 MB)."; if("COVER_TYPE_MISMATCH".equals(e))return "Please select an image for the cover photo."; if("COVER_MULTIPART_INVALID".equals(e))return "Cover photo upload format was rejected by the Worker: "+detail; if("PROFILE_UPDATE_FAILED".equals(e))return "Profile could not be saved safely. Your account was not changed."; if("R2_WRITE_FAILED".equals(e))return "R2 upload failed: "+detail; if("R2_VERIFY_FAILED".equals(e))return "R2 upload verification failed: "+detail; if("AVATAR_MULTIPART_INVALID".equals(e))return "Profile photo upload format was rejected by the Worker: "+detail; if("MEDIA_TOO_LARGE".equals(e))return "Media file is too large (max 50 MB)."; if("MEDIA_TYPE_MISMATCH".equals(e))return "Selected file type does not match the selected Gallery folder."; if("GALLERY_DB_UPDATE_FAILED".equals(e))return "Gallery save failed safely; the selected media was not kept without a database record."; if("MEDIA_NOT_FOUND".equals(e))return "This Gallery item is no longer available."; if("INVALID_GALLERY_FOLDER".equals(e))return "Gallery folder is invalid."; if("AD_DB_UPDATE_FAILED".equals(e))return "Advertisement save failed safely; the old advertisement was kept."; if("AD_TOO_LARGE".equals(e))return "Advertisement image is too large (max 15 MB)."; if("AD_MUST_BE_IMAGE".equals(e)||"AD_MUST_BE_IMAGE_OR_VIDEO".equals(e))return "Please select an image or video for the advertisement."; if("D1_WRITE_READY_FAILED".equals(e))return "MY SHOP database write check failed: "+detail; if("NOTIFICATION_DB_WRITE_FAILED".equals(e))return "Notification database write failed: "+detail; if("NOTIFICATION_SCHEMA_FAILED".equals(e))return "Notification schema failed: "+detail; if("BANNER_DB_UPDATE_FAILED".equals(e))return "Banner save failed: "+detail; if("DAILY_POST_LIMIT".equals(e))return "আজকের ১টি পোস্ট ইতিমধ্যে করা হয়েছে। আগামীকাল আবার পোস্ট করতে পারবেন।";  if("FILE_REQUIRED".equals(e))return "No media file was received. Please choose the photo again."; if("POST_MEDIA_TYPE_MISMATCH".equals(e))return "Selected file type is not allowed for this post."; if("POST_CAPTION_REQUIRED".equals(e))return "Please add a caption before publishing the post."; if("USER_POST_TOO_LARGE".equals(e))return "User post is too large (image max 5 MB, video max 20 MB)."; if("POST_DB_UPDATE_FAILED".equals(e))return "Post save failed safely; the uploaded media was not kept without a database record."; if("POST_NOT_FOUND".equals(e))return "This post is no longer available."; if("MODERATOR_REQUIRED".equals(e))return "Moderator permission is required."; if("SERVER_ERROR".equals(e))return detail.isEmpty()?"Server error ("+code+")":"Server error: "+detail; return e.isEmpty()?"Server error ("+code+")":e; }
}
