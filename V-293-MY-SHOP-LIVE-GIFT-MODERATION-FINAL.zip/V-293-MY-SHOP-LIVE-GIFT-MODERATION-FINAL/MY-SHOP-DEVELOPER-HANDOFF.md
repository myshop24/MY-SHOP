# MY SHOP Developer Handoff — V-293

## Current Version
- Build: V-293
- Android versionName: 2.9.293
- Base: V-292

## Completed in V-293
- Repaired the Live D1 `no such column: title` failure. Root cause: SQLite does not accept the old backslash apostrophe escape in the ALTER statement. V-293 uses `DEFAULT 'Let''s Talk Together'` and adds migration `0010_v293_live_gift_moderation_and_title_fix.sql`.
- Host End/Back fail-safe: a failed server End call no longer traps the Host in the Live Room; local Activity closes and server cleanup can retry.
- Added emoji control inside the Live comment composer; it opens the device keyboard/emoji input.
- Added Live Gift chart foundation with separate Coin Gifts / Gold Coin Gifts tabs and Coin/Gold balances.
- Added server-authoritative Live Gift catalog/send APIs and D1 tables.
- Added Admin Live Gift Manager: max 50 Coin + 50 Gold Coin gifts; Add/Edit/Delete/Save/Publish; price; enabled state; Animation ON/OFF; Sound ON/OFF; sound volume 0–100; Small/Medium/Large/Full Screen size; display order; animation/sound asset upload to R2.
- Added Live moderation foundation: Host Kick, Mute, Unmute, Block, Room Admin add/remove (max 5). Room Admin is mute/unmute only. MY SHOP global MODERATOR can mute/kick. Global ADMIN can moderate. Main Admin User ID 0001 has permanent soft-ban power.
- Muted users remain listen/gift capable but server blocks Live Comment and Join/Speak Request.
- Blocked users cannot join that Live until unblocked.
- Kick removes the user from the current Live; room state signals the client to exit.
- Permanent ban keeps the Permanent User ID record and soft-deactivates the account; no identity deletion/reassignment.
- Existing V-292 approved Live Room layout and right-action spacing preserved.

## Fixed MY SHOP Admin identities
The existing source already has the three fixed Admin identities mapped to User IDs 0001, 0002 and 0003. V-293 preserves them. Permanent-ban authority is intentionally limited to 0001.

## NEXT START HERE
1. Apply D1 migration `0010_v293_live_gift_moderation_and_title_fix.sql` before Worker rollout.
2. Deploy Worker and confirm `/health` reports `2.9.293 / V-293`.
3. Test Live start/end against an older database that previously lacked `myshop_live_room_meta.title`.
4. Test Host Android Back + End Live while forcing backend failure; UI must still exit locally.
5. Test Host Kick/Mute/Block and max-5 Room Admin assignment; Room Admin must only get Mute/Unmute.
6. Test global MODERATOR mute/kick, fixed ADMIN moderation, and User ID 0001 permanent soft-ban.
7. Test Gift Admin: create 50 Coin and 50 Gold gifts, edit/delete, switches, volume, size and R2 upload.
8. Test Gift send with insufficient/sufficient Coin and Gold balances; deductions must occur only on Worker/D1.
9. Production high-animation playback/queue should be expanded next for uploaded GIF/animated WebP/WebM/Lottie assets; V-293 establishes catalog, settings, transaction, upload and Gift Chart plumbing but does not claim final BIGO-class animation renderer yet.
10. Real Agora RTC audio transport remains pending and is not claimed complete in V-293.

## Validation limitation
No Gradle wrapper executable is present in this source root, so an Android APK compile was not run. Do not claim APK compile success for V-293 until CI/Gradle performs it.
