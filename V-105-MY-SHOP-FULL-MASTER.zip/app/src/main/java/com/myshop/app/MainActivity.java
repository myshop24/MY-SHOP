package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * V-101 MAIN DASHBOARD
 * Visual master: approved MY SHOP mobile dashboard reference.
 * V-101 fixes the V-100 scaling problem by using a real scrollable content area
 * with a fixed bottom navigation bar instead of shrinking the whole dashboard.
 */
public class MainActivity extends AppCompatActivity {
    private static final int BG = Color.rgb(249, 250, 253);
    private static final int TEXT = Color.rgb(30, 32, 44);
    private static final int PURPLE = Color.rgb(91, 35, 214);
    private static final int RED = Color.rgb(235, 32, 53);
    private static final long SLIDE_MS = 3500L;

    private final Handler handler = new Handler();
    private int bannerIndex = 0;
    private ImageView hero, ad1, ad2, ad3;
    private TextView dots;

    // Six local reference slots. Admin/remote configuration can replace these later.
    private final int[] heroSlides = {
            R.drawable.dash_wide,
            R.drawable.banner_wide_1,
            R.drawable.banner_wide_2,
            R.drawable.banner_wide_3,
            R.drawable.banner_wide_4,
            R.drawable.banner_wide_5
    };
    private final int[] adSlides = {
            R.drawable.dash_ad1, R.drawable.dash_ad2, R.drawable.dash_ad3,
            R.drawable.dash_ad4, R.drawable.dash_ad5, R.drawable.dash_ad1
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        enableFullscreen();
        setContentView(buildDashboard());
        startCarousel();
    }

    private void enableFullscreen() {
        Window window = getWindow();
        View decor = window.getDecorView();
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
            WindowInsetsController c = window.getInsetsController();
            if (c != null) {
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
            }
        } else {
            decor.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) enableFullscreen();
    }

    private View buildDashboard() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(12), dp(8), dp(12), dp(92));
        page.setBackgroundColor(BG);

        page.addView(buildHeader(), lp(-1, dp(62)));
        page.addView(buildHero(), top(lp(-1, heroHeight()), 8));
        page.addView(buildDots(), lp(-1, dp(28)));
        page.addView(buildPromoRow(), lp(-1, dp(92)));
        page.addView(buildBreakingNews(), top(lp(-1, dp(48)), 8));
        page.addView(buildLiveHeader(), top(lp(-1, dp(38)), 6));
        page.addView(buildLiveRow(), lp(-1, dp(150)));
        page.addView(buildLiveActions(), top(lp(-1, dp(92)), 6));
        addFeatureRow(page,
                R.drawable.dash_feat_shop, "shop", "my_shop",
                R.drawable.dash_feat_gallery, "gallery", "gallery",
                R.drawable.dash_feat_tv, "tv", "live_tv",
                R.drawable.dash_feat_movie, "movie", "external_movie");
        addFeatureRow(page,
                R.drawable.dash_feat_social, "social", "social_media",
                R.drawable.dash_feat_reward, "reward", "earn_reward",
                R.drawable.dash_feat_share, "share", "share",
                R.drawable.dash_feat_apps, "apps", "more_apps");

        scroll.addView(page, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        root.addView(buildBottomNav(), new FrameLayout.LayoutParams(-1, dp(74), Gravity.BOTTOM));
        return root;
    }

    private View buildHeader() {
        LinearLayout header = row();
        header.setPadding(dp(4), 0, dp(4), 0);
        header.setBackground(round(Color.WHITE, Color.rgb(230, 231, 237), dp(20)));

        Button menu = iconButton("☰", TEXT, 25);
        menu.setOnClickListener(v -> startActivity(new Intent(this, AccountActivity.class)));
        header.addView(menu, lp(dp(42), dp(54)));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.myshop_icon);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        header.addView(logo, lp(dp(44), dp(54)));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text("MY SHOP", TEXT, 19, true);
        TextView tagline = text("সবকিছু এক অ্যাপেই ❤️", Color.DKGRAY, 8, false);
        brand.addView(name, lp(-1, dp(27)));
        brand.addView(tagline, lp(-1, dp(17)));
        header.addView(brand, weight(1, dp(54)));

        Button language = iconButton("🌐", TEXT, 17);
        language.setContentDescription("Language");
        language.setOnClickListener(v -> LanguageManager.showPicker(this, this::recreate));
        header.addView(language, lp(dp(40), dp(54)));

        Button search = iconButton("⌕", TEXT, 27);
        search.setOnClickListener(v -> Toast.makeText(this, LanguageManager.t(this, "search"), Toast.LENGTH_SHORT).show());
        header.addView(search, lp(dp(40), dp(54)));

        Button bell = iconButton("♧", TEXT, 24);
        bell.setOnClickListener(v -> Toast.makeText(this, "Notifications", Toast.LENGTH_SHORT).show());
        header.addView(bell, lp(dp(40), dp(54)));

        ImageView avatar = new ImageView(this);
        avatar.setImageResource(R.drawable.myshop_profile_avatar);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatar.setBackground(round(Color.WHITE, Color.LTGRAY, dp(22)));
        avatar.setOnClickListener(v -> startActivity(new Intent(this, AccountActivity.class)));
        header.addView(avatar, lp(dp(42), dp(42)));
        return header;
    }

    private ImageView buildHero() {
        hero = image(heroSlides[0]);
        hero.setScaleType(ImageView.ScaleType.CENTER_CROP);
        hero.setOnClickListener(v -> openFeature("MY SHOP", "my_shop"));
        return hero;
    }

    private TextView buildDots() {
        dots = text("●   ○   ○   ○   ○   ○", PURPLE, 11, true);
        dots.setGravity(Gravity.CENTER);
        return dots;
    }

    private View buildPromoRow() {
        LinearLayout row = row();
        ad1 = image(adSlides[0]);
        ad2 = image(adSlides[1]);
        ad3 = image(adSlides[2]);
        ad1.setOnClickListener(v -> openFeature("MY SHOP", "my_shop"));
        ad2.setOnClickListener(v -> openFeature("MY SHOP", "my_shop"));
        ad3.setOnClickListener(v -> openFeature("MY SHOP", "my_shop"));
        row.addView(ad1, weight(1, dp(92)));
        row.addView(space(), lp(dp(6), 1));
        row.addView(ad2, weight(1, dp(92)));
        row.addView(space(), lp(dp(6), 1));
        row.addView(ad3, weight(1, dp(92)));
        return row;
    }

    private View buildBreakingNews() {
        TextView breaking = card("🔴  " + LanguageManager.t(this, "breaking") +
                "    |    " + breakingText() + "    ☀️    ›", Color.WHITE, TEXT, 11);
        breaking.setSingleLine(true);
        breaking.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
        breaking.setMarqueeRepeatLimit(-1);
        breaking.setSelected(true);
        return breaking;
    }

    private View buildLiveHeader() {
        LinearLayout head = row();
        TextView title = text("🔴  " + LanguageManager.t(this, "liveNow"), TEXT, 14, true);
        head.addView(title, weight(1, dp(38)));
        TextView all = text(LanguageManager.t(this, "seeAll") + "  ›", TEXT, 11, true);
        all.setGravity(Gravity.CENTER);
        all.setOnClickListener(v -> openFeature("LIVE", "live_now"));
        head.addView(all, lp(dp(72), dp(38)));
        return head;
    }

    private View buildLiveRow() {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout liveRow = row();
        int[] liveImages = {R.drawable.dash_live1, R.drawable.dash_live2, R.drawable.dash_live3, R.drawable.dash_live4};
        for (int i = 0; i < liveImages.length; i++) {
            ImageView live = image(liveImages[i]);
            live.setContentDescription("LIVE " + (i + 1));
            live.setOnClickListener(v -> openFeature("LIVE", "live_now"));
            liveRow.addView(live, lp(dp(112), dp(142)));
            if (i < liveImages.length - 1) liveRow.addView(space(), lp(dp(7), 1));
        }
        hsv.addView(liveRow, new HorizontalScrollView.LayoutParams(-2, -1));
        return hsv;
    }

    private View buildLiveActions() {
        LinearLayout actions = row();
        ImageView live = image(R.drawable.dash_action_live);
        live.setOnClickListener(v -> openFeature("LIVE", "live_now"));
        actions.addView(live, weight(1, dp(82)));
        ImageView go = image(R.drawable.dash_action_go);
        go.setOnClickListener(v -> openFeature("GO LIVE", "go_live"));
        actions.addView(go, lp(dp(128), dp(92)));
        ImageView feed = image(R.drawable.dash_action_feed);
        feed.setOnClickListener(v -> openFeature("MY FEED", "my_feed"));
        actions.addView(feed, weight(1, dp(82)));
        return actions;
    }

    private View buildBottomNav() {
        LinearLayout nav = row();
        nav.setPadding(dp(4), 0, dp(4), 0);
        nav.setBackground(round(Color.WHITE, Color.rgb(229, 230, 236), dp(16)));

        Button home = navButton("⌂\n" + LanguageManager.t(this, "home"), PURPLE);
        Button live = navButton("◉\n" + LanguageManager.t(this, "live"), TEXT);
        Button store = navButton("🛒\n" + LanguageManager.t(this, "store"), PURPLE);
        Button chat = navButton("💬\n" + LanguageManager.t(this, "chat"), TEXT);
        Button more = navButton("▦\n" + LanguageManager.t(this, "more"), TEXT);

        nav.addView(home, weight(1, dp(70)));
        nav.addView(live, weight(1, dp(70)));
        nav.addView(store, weight(1, dp(70)));
        nav.addView(chat, weight(1, dp(70)));
        nav.addView(more, weight(1, dp(70)));

        home.setOnClickListener(v -> Toast.makeText(this, LanguageManager.t(this, "home"), Toast.LENGTH_SHORT).show());
        live.setOnClickListener(v -> openFeature("LIVE", "live_now"));
        store.setOnClickListener(v -> openFeature("MY SHOP", "my_shop"));
        chat.setOnClickListener(v -> openFeature("CHAT", "chat"));
        more.setOnClickListener(v -> startActivity(new Intent(this, AccountActivity.class)));
        return nav;
    }

    private void addFeatureRow(LinearLayout parent,
                               int r1, String d1, String k1,
                               int r2, String d2, String k2,
                               int r3, String d3, String k3,
                               int r4, String d4, String k4) {
        LinearLayout r = row();
        r.addView(tile(r1, d1, k1), weight(1, dp(78)));
        r.addView(space(), lp(dp(5), 1));
        r.addView(tile(r2, d2, k2), weight(1, dp(78)));
        r.addView(space(), lp(dp(5), 1));
        r.addView(tile(r3, d3, k3), weight(1, dp(78)));
        r.addView(space(), lp(dp(5), 1));
        r.addView(tile(r4, d4, k4), weight(1, dp(78)));
        parent.addView(r, top(lp(-1, dp(82)), 6));
    }

    private ImageView tile(int res, String description, String key) {
        ImageView v = image(res);
        v.setContentDescription(description);
        v.setOnClickListener(x -> openFeature(description, key));
        return v;
    }

    private ImageView image(int res) {
        ImageView v = new ImageView(this);
        v.setImageResource(res);
        v.setScaleType(ImageView.ScaleType.CENTER_CROP);
        v.setBackground(round(Color.WHITE, Color.rgb(231, 232, 238), dp(12)));
        v.setClipToOutline(true);
        return v;
    }

    private int heroHeight() {
        int width = getResources().getDisplayMetrics().widthPixels;
        float density = getResources().getDisplayMetrics().density;
        int widthDp = Math.max(320, Math.round(width / density) - 24);
        return Math.max(88, Math.min(124, Math.round(widthDp * 238f / 980f)));
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private LinearLayout.LayoutParams weight(float w, int h) {
        return new LinearLayout.LayoutParams(0, h, w);
    }

    private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p, int margin) {
        p.topMargin = dp(margin);
        return p;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private View space() { return new View(this); }

    private Button navButton(String label, int color) {
        return plainButton(label, color, 10);
    }

    private Button iconButton(String label, int color, float size) {
        return plainButton(label, color, size);
    }

    private Button plainButton(String label, int color, float size) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setTextColor(color);
        b.setTextSize(size);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(0, 0, 0, 0);
        b.setBackgroundColor(Color.TRANSPARENT);
        return b;
    }

    private TextView card(String label, int bg, int fg, float size) {
        TextView v = text(label, fg, size, true);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(dp(8), dp(4), dp(8), dp(4));
        v.setBackground(round(bg, Color.rgb(238, 228, 233), dp(13)));
        return v;
    }

    private TextView text(String value, int color, float size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextColor(color);
        v.setTextSize(size);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private GradientDrawable round(int fill, int stroke, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radius);
        if (stroke != Color.TRANSPARENT) g.setStroke(dp(1), stroke);
        return g;
    }

    private String breakingText() {
        if (LanguageManager.BN.equals(LanguageManager.get(this))) {
            return "বাংলাদেশে আজ স্বর্ণের দাম আবার কমলো";
        }
        return "Welcome to MY SHOP";
    }

    private void startCarousel() {
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                bannerIndex = (bannerIndex + 1) % 6;
                hero.setImageResource(heroSlides[bannerIndex]);
                ad1.setImageResource(adSlides[bannerIndex]);
                ad2.setImageResource(adSlides[(bannerIndex + 1) % 6]);
                ad3.setImageResource(adSlides[(bannerIndex + 2) % 6]);
                if (dots != null) {
                    StringBuilder s = new StringBuilder();
                    for (int i = 0; i < 6; i++) {
                        s.append(i == bannerIndex ? "●" : "○");
                        if (i < 5) s.append("  ");
                    }
                    dots.setText(s.toString());
                }
                handler.postDelayed(this, SLIDE_MS);
            }
        }, SLIDE_MS);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private void openFeature(String title, String key) {
        try {
            Intent i = new Intent(this, FeatureActivity.class);
            i.putExtra("title", title);
            i.putExtra("feature_key", key);
            String url = FeatureRegistry.getUrl(this, key);
            if (FeatureRegistry.isSafeHttpUrl(url)) i.putExtra("url", url);
            startActivity(i);
        } catch (Throwable x) {
            Toast.makeText(this, title + " is ready.", Toast.LENGTH_SHORT).show();
        }
    }
}
