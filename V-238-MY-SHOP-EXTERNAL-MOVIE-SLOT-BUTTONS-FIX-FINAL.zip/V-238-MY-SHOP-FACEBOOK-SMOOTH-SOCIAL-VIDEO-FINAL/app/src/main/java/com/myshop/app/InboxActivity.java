package com.myshop.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** V-238 Facebook-style message inbox with cache, unread counts and live refresh. */
public class InboxActivity extends androidx.appcompat.app.AppCompatActivity{
    private final int BG=Color.rgb(246,248,252),DARK=Color.rgb(25,37,80),BLUE=Color.rgb(46,47,190),MUTED=Color.rgb(105,111,130);
    private LinearLayout list;private TextView status;private boolean hasContent=false;private final Handler h=new Handler(Looper.getMainLooper());private final ExecutorService images=Executors.newFixedThreadPool(3);
    private final Runnable poll=new Runnable(){public void run(){load(false);h.postDelayed(this,8000);}};
    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(build());load(true);}
    private View build(){LinearLayout r=col();r.setPadding(dp(10),dp(8),dp(10),dp(10));r.setBackgroundColor(BG);r.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(dp(10),Math.max(dp(8),i.getSystemWindowInsetTop()+dp(4)),dp(10),dp(10));return i;});LinearLayout head=row();Button back=new Button(this);back.setText("‹");back.setTextSize(28);back.setTextColor(DARK);back.setBackgroundColor(Color.TRANSPARENT);back.setOnClickListener(v->finish());head.addView(back,lp(dp(48),dp(48)));TextView t=txt("Messages",DARK,18,true);head.addView(t,weight(1,dp(48)));TextView refresh=chip("Refresh",BLUE);refresh.setOnClickListener(v->load(false));head.addView(refresh,lp(dp(72),dp(34)));r.addView(head);status=txt("Loading conversations…",MUTED,9.5f,false);status.setPadding(dp(4),0,0,0);r.addView(status,lp(-1,dp(28)));ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setVerticalScrollBarEnabled(false);list=col();sv.addView(list);r.addView(sv,weight(1,0));r.post(r::requestApplyInsets);return r;}
    private void load(boolean first){String token=SessionManager.getToken(this);if(token==null||token.isEmpty()){empty("Login to use Messages");return;}if(first)renderCached();status.setText(hasContent?"Updating…":"Loading conversations…");BackendClient.messageInbox(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){getSharedPreferences("myshop_messages",MODE_PRIVATE).edit().putString("inbox",d.toString()).apply();runOnUiThread(()->{render(d.optJSONArray("conversations"));int u=d.optInt("unreadCount",0);status.setText(u>0?u+" unread message(s)":"All messages read");});}public void onError(String m){runOnUiThread(()->status.setText(hasContent?"Saved conversations shown • retry when online":"Messages unavailable • tap Refresh"));}});}
    private void renderCached(){try{String raw=getSharedPreferences("myshop_messages",MODE_PRIVATE).getString("inbox","");if(raw.isEmpty())return;render(new JSONObject(raw).optJSONArray("conversations"));}catch(Exception ignored){}}
    private void render(JSONArray a){list.removeAllViews();hasContent=a!=null&&a.length()>0;if(!hasContent){empty("No conversations yet");return;}for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;list.addView(conversation(x),margin(lp(-1,dp(74)),0,0,0,dp(7)));}}
    private View conversation(JSONObject x){String uid=x.optString("userId"),name=x.optString("name","MY SHOP User"),avatar=x.optString("avatarUrl","");int unread=x.optInt("unread",0);LinearLayout c=row();c.setPadding(dp(8),dp(7),dp(9),dp(7));c.setBackground(round(unread>0?Color.WHITE:Color.rgb(250,251,253),Color.rgb(229,231,238),14));c.setElevation(unread>0?dp(2):dp(1));ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setClipToOutline(true);av.setBackground(round(Color.rgb(240,242,248),Color.TRANSPARENT,25));if(!avatar.isEmpty())loadImage(av,avatar);c.addView(av,lp(dp(50),dp(50)));LinearLayout info=col();info.setPadding(dp(9),0,dp(4),0);LinearLayout line=row();TextView n=txt(name,DARK,11.5f,true);n.setSingleLine(true);n.setEllipsize(TextUtils.TruncateAt.END);line.addView(n,weight(1,dp(24)));if(unread>0){TextView badge=chip(unread>99?"99+":String.valueOf(unread),BLUE);line.addView(badge,lp(dp(34),dp(23)));}info.addView(line,lp(-1,dp(25)));TextView m=txt(x.optString("lastMessage",""),unread>0?DARK:MUTED,9.5f,unread>0);m.setSingleLine(true);m.setEllipsize(TextUtils.TruncateAt.END);info.addView(m,lp(-1,dp(22)));TextView tm=txt(x.optString("lastAt",""),MUTED,7.5f,false);info.addView(tm,lp(-1,dp(16)));c.addView(info,weight(1,dp(58)));c.setOnClickListener(v->{Intent q=new Intent(this,ChatActivity.class);q.putExtra("userId",uid);q.putExtra("name",name);q.putExtra("avatarUrl",avatar);startActivity(q);});return c;}
    private void empty(String s){list.removeAllViews();hasContent=false;TextView t=txt(s,MUTED,11,false);t.setGravity(Gravity.CENTER);list.addView(t,lp(-1,dp(140)));}
    private void loadImage(ImageView v,String url){images.execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(6000);c.setReadTimeout(8000);try(InputStream in=c.getInputStream()){Bitmap bm=BitmapFactory.decodeStream(in);if(bm!=null)runOnUiThread(()->v.setImageBitmap(bm));}c.disconnect();}catch(Exception ignored){}});}
    @Override protected void onResume(){super.onResume();load(false);h.removeCallbacks(poll);h.postDelayed(poll,8000);}@Override protected void onPause(){super.onPause();h.removeCallbacks(poll);}@Override protected void onDestroy(){images.shutdownNow();super.onDestroy();}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private TextView txt(String s,int c,float z,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}private TextView chip(String s,int c){TextView t=txt(s,Color.WHITE,9,true);t.setGravity(Gravity.CENTER);t.setBackground(round(c,c,12));return t;}private GradientDrawable round(int c,int st,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));if(st!=Color.TRANSPARENT)g.setStroke(dp(1),st);return g;}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}private LinearLayout.LayoutParams margin(LinearLayout.LayoutParams p,int l,int t,int r,int b){p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
