# V-238 External Movie Slot Button Fix

- Every External Movie slot (1-6) now renders a fixed, visible four-button row directly below Image URL: ADD, EDIT, SAVE, DELETE.
- Buttons use the approved purple/orange/green/red action colors and each action is bound only to its own slot.
- External Movie loading now respects `display_order`, so saved items stay in their intended slot after reload/delete operations.
- Worker save logic now treats External Movie as fixed slots and updates an existing row for the same slot instead of creating duplicate rows when saving with a new/local ID.
- Other dashboard, social, messaging, video, auth, signing, and approved layout behavior is unchanged.
