# MY SHOP Developer Handoff — V-274

Current base: **V-274** (built from V-273)

Latest completed checkpoint:
- Breaking News font-size control hardened to an explicit visible `− / px / +` UI with live preview and backend save.
- Dashboard user-card online indicator now depends only on real app foreground presence; no static/duplicate dots.
- Presence heartbeat: 30 seconds; stale backend timeout: 90 seconds; Dashboard online-dot refresh: 30 seconds.
- New backend route: `POST /v1/app/presence`.
- New D1 migration: `0006_v274_app_presence.sql`.

Important: deploy the updated Worker/migration together with the APK for real online presence to work.

---

# MY SHOP Developer Handoff

Current version: V-273
Base: V-272-MY-SHOP-FOUR-CRITICAL-FIXES-FINAL

Completed in V-273:
- Profile name/cover overlap fix.
- Breaking News font size +/- admin control polished to 1-unit steps with visible integer size.
- Dashboard people card redesign: no NEW/LIVE overlay badge; plain name line; compact ID + crown level line; no purple level background; reduced gaps.

Preserve all existing backend/social/live/navigation functionality. Do not reintroduce NEW or LIVE overlay badges on people profile images.
