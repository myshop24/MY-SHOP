# MY SHOP Developer Handoff — V-315

Current version: V-315 / 2.9.315
Checkpoint: V-314 build failure repaired; Admin Coin/Gold user grant flow completed and surfaced in Admin Finance.
Preserve: Admin Login/Gate, D1/R2 bindings/schema compatibility, Live, Wallet Play safeguards, Startup Ad Full Image/Fill Screen behavior.
QA gate: GitHub Actions release compile must pass before release.
Known manual release gate: production Privacy Policy owner/privacy contact and Play Console declarations must be verified before Play submission.
