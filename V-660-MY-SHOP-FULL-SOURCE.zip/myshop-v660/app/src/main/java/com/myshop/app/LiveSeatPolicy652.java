package com.myshop.app;
import org.json.*;import java.util.*;
/** Capacity and visible placeholders are separate. Existing seat numbers stay authoritative. */
final class LiveSeatPolicy652 {
 static java.util.List<Integer> videoSlots(int capacity,java.util.List<JSONObject> users){
  TreeSet<Integer> occupied=new TreeSet<>();for(JSONObject u:users){int n=u.optInt("seat_no");if(n>=2&&n<=capacity)occupied.add(n);}
  ArrayList<Integer> slots=new ArrayList<>(occupied);for(int n=2;n<=capacity;n++)if(!occupied.contains(n)){slots.add(n);break;}Collections.sort(slots);return slots;
 }
 static int audioVisible(int layout,JSONArray users){int highest=0;Set<Integer> occupied=new HashSet<>();for(int i=0;users!=null&&i<users.length();i++){JSONObject u=users.optJSONObject(i);if(u!=null){int n=u.optInt("seat_no")-1;if(n>0){highest=Math.max(highest,n);occupied.add(n);}}}if(layout!=18)return Math.max(layout,highest);int visible=Math.max(8,highest);boolean full=true;for(int n=1;n<=visible;n++)if(!occupied.contains(n)){full=false;break;}return Math.min(18,full?visible+1:visible);}
}
