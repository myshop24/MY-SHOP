package com.myshop.app;

import android.content.Context;
import io.agora.rtc2.ChannelMediaOptions;
import io.agora.rtc2.ClientRoleOptions;
import io.agora.rtc2.Constants;
import io.agora.rtc2.IRtcEngineEventHandler;
import io.agora.rtc2.RtcEngine;
import io.agora.rtc2.RtcEngineConfig;

/** V-343 audio-only RTC transport with persistent diagnostics. Backend remains room/seat/role authority. */
public final class AgoraRtcManager implements LiveVideoTransport647 {
    private boolean desiredPublish649,desiredMic649=true;private String channel649="";private boolean videoMode647,publisher647,cameraEnabled647=true;private Boolean appliedVideoPublisher647;
    public interface Listener {
        void onJoined();
        void onRemoteUserJoined(int uid);
        void onRemoteAudioState(int uid,int state,int reason);
        void onLocalAudioState(int state,int error);
        void onConnectionState(int state,int reason);
        void onError(String message);
        void onTokenWillExpire();
        void onAudioLevel(boolean speaking);
        void onActiveSpeaker(int uid,int volume);
        default void onRemoteVideo647(int uid,boolean available){}
        default void onMusicCompleted(){}
        default void onMusicError(int reason){}
        default void onNetworkQuality(int uid,int tx,int rx){}
    }
    private final java.util.concurrent.ConcurrentHashMap<Integer,Long> speakingUntil=new java.util.concurrent.ConcurrentHashMap<>();private boolean remoteEnabled=true,focusAllowed=true;private int audioRoute=-1;private android.media.AudioDeviceCallback deviceCallback;private android.media.AudioManager audioManager;private final android.media.AudioManager.OnAudioFocusChangeListener focusListener=change->{focusAllowed=change==android.media.AudioManager.AUDIOFOCUS_GAIN||change==android.media.AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK;if(this.engine!=null)try{this.engine.muteLocalAudioStream(!focusAllowed||!Boolean.TRUE.equals(this.lastMicEnabled));syncBridge648();}catch(Exception ignored){}};
    private RtcEngine engine; private volatile boolean joined=false,joining=false; private Boolean lastPublishAudio=null,lastMicEnabled=null; private final Listener listener;
    // Preserve decoder state even when callbacks precede the room's first state response.
    private final java.util.concurrent.ConcurrentHashMap<Integer,Boolean> remoteVideo651=new java.util.concurrent.ConcurrentHashMap<>();
    private long lastRepair660;
    public void repairSubscriptions660(){if(engine==null||!joined)return;long now=android.os.SystemClock.elapsedRealtime();if(now-lastRepair660<2000)return;lastRepair660=now;ChannelMediaOptions o=new ChannelMediaOptions();o.autoSubscribeAudio=true;o.autoSubscribeVideo=videoMode647;int rc=engine.updateChannelMediaOptions(o);if(rc!=0)android.util.Log.w("MYSHOP_RTC","Receive subscription recovery rc="+rc);recoverPlayback();}
    private long joinStarted651;
    public java.util.Map<Integer,Boolean> remoteVideo651(){return new java.util.HashMap<>(remoteVideo651);}
    public boolean isJoined651(){return joined;}
    public boolean joinTimedOut651(){return joining&&!joined&&android.os.SystemClock.elapsedRealtime()-joinStarted651>=15000;}
    private void remoteVideo651(int uid,boolean available){remoteVideo651.put(uid,available);if(listener!=null)listener.onRemoteVideo647(uid,available);}
    public AgoraRtcManager(Listener listener){this.listener=listener;}
    public void init(Context context) throws Exception {
        if(engine!=null)return;
        RtcEngineConfig c=new RtcEngineConfig(); c.mContext=context.getApplicationContext(); c.mAppId=BuildConfig.AGORA_APP_ID;
        c.mEventHandler=new IRtcEngineEventHandler(){
            @Override public void onJoinChannelSuccess(String ch,int uid,int elapsed){joining=false;joined=true;lastPublishAudio=null;lastMicEnabled=null;appliedVideoPublisher647=null;setPublishAudio(desiredPublish649);setMicEnabled(desiredPublish649&&desiredMic649);videoMode647(videoMode647,publisher647);recoverPlayback();if(listener!=null)listener.onJoined();}
            @Override public void onConnectionStateChanged(int state,int reason){if(state==5){stopBridge648();appliedVideoPublisher647=null;joining=false;joined=false;lastPublishAudio=null;lastMicEnabled=null;if(engine!=null)try{engine.leaveChannel();}catch(Exception ignored){}}if(state==3)recoverPlayback();if(listener!=null)listener.onConnectionState(state,reason);}
            @Override public void onLocalAudioStateChanged(int state,int error){if(listener!=null)listener.onLocalAudioState(state,error);}
            @Override public void onAudioMixingStateChanged(int state,int reason){if(state==Constants.AUDIO_MIXING_STATE_STOPPED&&reason==Constants.AUDIO_MIXING_REASON_ALL_LOOPS_COMPLETED&&listener!=null)listener.onMusicCompleted();if(state==Constants.AUDIO_MIXING_STATE_FAILED&&listener!=null)listener.onMusicError(reason);}
            @Override public void onError(int err){joining=false;if(listener!=null)listener.onError("Agora RTC error "+err);}
            @Override public void onRejoinChannelSuccess(String ch,int uid,int elapsed){onJoinChannelSuccess(ch,uid,elapsed);}
            @Override public void onFirstRemoteVideoFrame(int uid,int width,int height,int elapsed){remoteVideo651(uid,true);}
            @Override public void onUserOffline(int uid,int reason){remoteVideo651(uid,false);}
            @Override public void onRemoteVideoStateChanged(int uid,int state,int reason,int elapsed){if(state==2)remoteVideo651(uid,true);else if(state==0||state==4)remoteVideo651(uid,false);}
            @Override public void onUserJoined(int uid,int elapsed){recoverPlayback();if(listener!=null)listener.onRemoteUserJoined(uid);}
            @Override public void onRemoteAudioStateChanged(int uid,int state,int reason,int elapsed){if(state==0||state==4)recoverPlayback();if(listener!=null)listener.onRemoteAudioState(uid,state,reason);}
            @Override public void onTokenPrivilegeWillExpire(String token){if(listener!=null)listener.onTokenWillExpire();}
            @Override public void onRequestToken(){if(listener!=null)listener.onTokenWillExpire();}
            @Override public void onNetworkQuality(int uid,int tx,int rx){if(listener!=null)listener.onNetworkQuality(uid,tx,rx);}
            @Override public void onAudioVolumeIndication(AudioVolumeInfo[] speakers,int totalVolume){if(listener==null||speakers==null)return;boolean speaking=false;int loudUid=-1,loudVolume=0;for(AudioVolumeInfo i:speakers){if(i==null)continue;if(i.volume>=12)speakingUntil.put(i.uid,System.currentTimeMillis()+650);if(i.uid==0&&i.volume>=12)speaking=true;if(i.volume>=12&&i.volume>loudVolume){loudUid=i.uid;loudVolume=i.volume;}}listener.onAudioLevel(speaking);listener.onActiveSpeaker(loudUid,loudVolume);}
        };
        engine=RtcEngine.create(c);audioManager=(android.media.AudioManager)context.getSystemService(Context.AUDIO_SERVICE);if(audioManager!=null)audioManager.requestAudioFocus(focusListener,android.media.AudioManager.STREAM_VOICE_CALL,android.media.AudioManager.AUDIOFOCUS_GAIN);
        engine.setChannelProfile(Constants.CHANNEL_PROFILE_LIVE_BROADCASTING);
        engine.enableAudio();
        // V-346 speech-first live audio tuning: prioritize intelligibility for voice chat.
        try{engine.setAudioProfile(Constants.AUDIO_PROFILE_SPEECH_STANDARD);engine.setAudioScenario(Constants.AUDIO_SCENARIO_CHATROOM);}catch(Exception ignored){}
        engine.enableLocalAudio(false);
        // External headsets keep SDK/system priority; speaker is the fallback only.
        engine.setDefaultAudioRoutetoSpeakerphone(true);
        engine.muteAllRemoteAudioStreams(!remoteEnabled);
        try{engine.adjustPlaybackSignalVolume(remoteEnabled?100:0);}catch(Exception ignored){}
        try{engine.adjustRecordingSignalVolume(100);}catch(Exception ignored){}
        engine.enableAudioVolumeIndication(200,3,true);
        if(audioManager!=null){deviceCallback=new android.media.AudioDeviceCallback(){@Override public void onAudioDevicesAdded(android.media.AudioDeviceInfo[] devices){applyRoute(audioRoute);}@Override public void onAudioDevicesRemoved(android.media.AudioDeviceInfo[] devices){if(!applyRoute(audioRoute)){audioRoute=-1;applyRoute(-1);}}};audioManager.registerAudioDeviceCallback(deviceCallback,new android.os.Handler(android.os.Looper.getMainLooper()));}
        applyRoute(-1);
    }
    public int join(String token,String channelName,int uid,boolean publishAudio){
        if(engine==null)return -10001;
        if(token==null||token.isEmpty()||channelName==null||channelName.isEmpty()||uid<=0)return -10002;
        desiredPublish649=publishAudio;if((joined||joining)&&!channelName.equals(channel649))leave();if(joined){renewToken(token);setPublishAudio(publishAudio);return 0;}
        if(joining){if(!joinTimedOut651())return 0;leave();}
        channel649=channelName;joining=true;joinStarted651=android.os.SystemClock.elapsedRealtime();
        ClientRoleOptions roleOptions=new ClientRoleOptions();roleOptions.audienceLatencyLevel=Constants.AUDIENCE_LATENCY_LEVEL_ULTRA_LOW_LATENCY;
        engine.setClientRole(publishAudio?Constants.CLIENT_ROLE_BROADCASTER:Constants.CLIENT_ROLE_AUDIENCE,roleOptions);
        // V-392: keep the local audio module warm even for audience. Only mute publishing.
        // This makes audience→speaker promotion immediate and avoids tearing down audio state.
        engine.enableLocalAudio(publishAudio);
        engine.muteLocalAudioStream(!publishAudio||!desiredMic649||!focusAllowed);
        recoverPlayback();
        ChannelMediaOptions o=new ChannelMediaOptions();
        o.autoSubscribeAudio=true;o.autoSubscribeVideo=videoMode647;o.publishCameraTrack=videoMode647&&publisher647&&cameraEnabled647;
        o.publishMicrophoneTrack=publishAudio;o.clientRoleType=publishAudio?Constants.CLIENT_ROLE_BROADCASTER:Constants.CLIENT_ROLE_AUDIENCE;o.channelProfile=Constants.CHANNEL_PROFILE_LIVE_BROADCASTING;
        int rc=engine.joinChannel(token,channelName,uid,o);
        // V-353: do not pre-mark publish/mic state as applied before Agora confirms the join.
        // The Live room may immediately call setPublishAudio/setMicEnabled after join; those
        // calls must reach the engine once instead of being skipped by the V-352 idempotency cache.
        if(rc==0){lastPublishAudio=null;lastMicEnabled=null;}
        if(rc!=0)joining=false;
        if(rc!=0&&listener!=null)listener.onError("Agora join return "+rc);
        return rc;
    }
    // V-352: role/media updates are idempotent. Re-rendering the Live room must not
    // repeatedly reconfigure the active Agora microphone path and introduce audio jitter.
    public void setPublishAudio(boolean publish){
        desiredPublish649=publish;if(engine==null||!joined)return;
        // V-353 audio recovery: playback/subscription/route must never be skipped.
        // Only the expensive role/media-options mutation is deduplicated.
        if(lastPublishAudio!=null&&lastPublishAudio==publish){
            // V-394: do not overwrite the explicit microphone mute state on routine room refresh.
            // Publishing role and microphone enabled state are separate authorities.
            return;
        }
        recoverPlayback();
        ClientRoleOptions roleOptions=new ClientRoleOptions();roleOptions.audienceLatencyLevel=Constants.AUDIENCE_LATENCY_LEVEL_ULTRA_LOW_LATENCY;
        engine.setClientRole(publish?Constants.CLIENT_ROLE_BROADCASTER:Constants.CLIENT_ROLE_AUDIENCE,roleOptions);
        engine.enableLocalAudio(publish);
        engine.muteLocalAudioStream(!publish||!desiredMic649||!focusAllowed);
        ChannelMediaOptions o=new ChannelMediaOptions();o.autoSubscribeAudio=true;o.autoSubscribeVideo=videoMode647;o.publishCameraTrack=videoMode647&&publisher647&&cameraEnabled647;o.publishMicrophoneTrack=publish;o.clientRoleType=publish?Constants.CLIENT_ROLE_BROADCASTER:Constants.CLIENT_ROLE_AUDIENCE;o.channelProfile=Constants.CHANNEL_PROFILE_LIVE_BROADCASTING;
        int applied=engine.updateChannelMediaOptions(o);if(applied==0)lastPublishAudio=publish;else lastPublishAudio=null;syncBridge648();
        if(!publish)lastMicEnabled=false;
    }
    public void setRemoteAudioEnabled(boolean enabled){
        remoteEnabled=enabled;
        if(engine==null)return;
        try{engine.muteAllRemoteAudioStreams(!enabled);}catch(Exception ignored){}
        try{engine.adjustPlaybackSignalVolume(enabled?100:0);}catch(Exception ignored){}
    }
    public void setMicEnabled(boolean enabled){
        desiredMic649=enabled;if(engine==null||!joined)return;
        if(lastMicEnabled!=null&&lastMicEnabled==enabled){engine.muteLocalAudioStream(!enabled||!focusAllowed);syncBridge648();return;}
        engine.enableLocalAudio(desiredPublish649);engine.muteLocalAudioStream(!enabled||!desiredPublish649||!focusAllowed);lastMicEnabled=enabled;syncBridge648();
    }
    /** V-392: restore remote subscription/output route without rejoining the channel. */
    public void recoverPlayback(){
        if(engine==null)return;
        try{engine.enableAudio();}catch(Exception ignored){}
        try{engine.muteAllRemoteAudioStreams(!remoteEnabled);}catch(Exception ignored){}
        // Playback recovery must not force speaker or undo a headset selection.
        try{engine.adjustPlaybackSignalVolume(remoteEnabled?100:0);}catch(Exception ignored){}
    }
    public boolean isSpeaking(int uid){return speakingUntil.getOrDefault(uid,0L)>System.currentTimeMillis();}
    public void setUserVolume(int uid,int volume){if(engine!=null)try{engine.adjustUserPlaybackSignalVolume(uid,Math.max(0,Math.min(100,volume)));}catch(Exception ignored){}}
    public boolean selectRoute(int route){if(route < -1 || route > 3)return false;if(!applyRoute(route))return false;audioRoute=route;return true;}
    private boolean matches(int route,int type){return route==0&&type==android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER || route==1&&type==android.media.AudioDeviceInfo.TYPE_BUILTIN_EARPIECE || route==2&&(type==android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO||type==android.media.AudioDeviceInfo.TYPE_BLE_HEADSET) || route==3&&(type==android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET||type==android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES||type==android.media.AudioDeviceInfo.TYPE_USB_HEADSET);}
    private boolean applyRoute(int route){
        if(engine==null)return false;
        try{
            if(android.os.Build.VERSION.SDK_INT>=31&&audioManager!=null){
                java.util.List<android.media.AudioDeviceInfo> devices=audioManager.getAvailableCommunicationDevices();
                android.media.AudioDeviceInfo selected=null;
                if(route==-1){for(int preferred:new int[]{3,2,0}){for(android.media.AudioDeviceInfo d:devices)if(matches(preferred,d.getType())){selected=d;break;}if(selected!=null)break;}}
                else for(android.media.AudioDeviceInfo d:devices)if(matches(route,d.getType())){selected=d;break;}
                if(selected==null)return false;
                if(!audioManager.setCommunicationDevice(selected))return false;
                if(selected.getType()==android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER||selected.getType()==android.media.AudioDeviceInfo.TYPE_BUILTIN_EARPIECE)engine.setEnableSpeakerphone(selected.getType()==android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER);
                return true;
            }
            if(route==2){if(audioManager==null||!audioManager.isBluetoothScoAvailableOffCall())return false;audioManager.startBluetoothSco();audioManager.setBluetoothScoOn(true);return true;}
            if(route==3){if(audioManager==null||!audioManager.isWiredHeadsetOn())return false;return true;}
            if(route==-1){if(audioManager!=null&&audioManager.isWiredHeadsetOn())return true;engine.setDefaultAudioRoutetoSpeakerphone(true);return true;}
            if(audioManager!=null){audioManager.stopBluetoothSco();audioManager.setBluetoothScoOn(false);}return engine.setEnableSpeakerphone(route==0)==0;
        }catch(SecurityException denied){return false;}catch(Exception unavailable){return false;}
    }
    private io.agora.rtc2.RtcConnection bridge648;private String bridgeKey648="";
    public int bridge648(String token,String channel,int uid){if(engine==null||!joined||!publisher647)return -1;io.agora.rtc2.RtcEngineEx ex=(io.agora.rtc2.RtcEngineEx)engine;String key=channel+"|"+uid;if(bridge648!=null&&key.equals(bridgeKey648)){ChannelMediaOptions options=bridgeOptions648();options.token=token;return ex.updateChannelMediaOptionsEx(options,bridge648);}stopBridge648();io.agora.rtc2.RtcConnection connection=new io.agora.rtc2.RtcConnection(channel,uid);int rc=ex.joinChannelEx(token,connection,bridgeOptions648(),new IRtcEngineEventHandler(){@Override public void onError(int err){if(listener!=null)listener.onError("PK connection error "+err);}});if(rc==0){bridge648=connection;bridgeKey648=key;}return rc;}
    private ChannelMediaOptions bridgeOptions648(){ChannelMediaOptions o=new ChannelMediaOptions();o.clientRoleType=Constants.CLIENT_ROLE_BROADCASTER;o.channelProfile=Constants.CHANNEL_PROFILE_LIVE_BROADCASTING;o.autoSubscribeAudio=false;o.autoSubscribeVideo=false;o.publishCameraTrack=videoMode647&&publisher647&&cameraEnabled647;o.publishMicrophoneTrack=publisher647&&focusAllowed&&Boolean.TRUE.equals(lastMicEnabled);return o;}
    private void syncBridge648(){if(engine!=null&&bridge648!=null)((io.agora.rtc2.RtcEngineEx)engine).updateChannelMediaOptionsEx(bridgeOptions648(),bridge648);}
    public void stopBridge648(){if(engine!=null&&bridge648!=null)((io.agora.rtc2.RtcEngineEx)engine).leaveChannelEx(bridge648);bridge648=null;bridgeKey648="";}
    public void videoMode647(boolean enabled,boolean publisher){if(engine==null)return;publisher647=publisher;if(videoMode647!=enabled){appliedVideoPublisher647=null;videoMode647=enabled;if(enabled){engine.enableVideo();engine.setRemoteSubscribeFallbackOption(Constants.STREAM_FALLBACK_OPTION_VIDEO_STREAM_LOW);engine.setVideoEncoderConfiguration(new io.agora.rtc2.video.VideoEncoderConfiguration(io.agora.rtc2.video.VideoEncoderConfiguration.VD_640x360,io.agora.rtc2.video.VideoEncoderConfiguration.FRAME_RATE.FRAME_RATE_FPS_15,600,io.agora.rtc2.video.VideoEncoderConfiguration.ORIENTATION_MODE.ORIENTATION_MODE_ADAPTIVE));}else{engine.stopPreview();engine.disableVideo();}}if(enabled){boolean desired=publisher&&cameraEnabled647;if(joined&&appliedVideoPublisher647!=null&&appliedVideoPublisher647==desired)return;engine.enableLocalVideo(desired);ChannelMediaOptions o=new ChannelMediaOptions();o.autoSubscribeVideo=true;o.publishCameraTrack=desired;int rc=engine.updateChannelMediaOptions(o);if(rc==0&&joined)appliedVideoPublisher647=desired;if(desired)engine.startPreview();else engine.stopPreview();}}
    public int camera647(boolean enabled){if(engine==null||!publisher647||!videoMode647)return -1;if(cameraEnabled647==enabled&&appliedVideoPublisher647!=null&&appliedVideoPublisher647==enabled)return 0;cameraEnabled647=enabled;engine.enableLocalVideo(enabled);ChannelMediaOptions o=new ChannelMediaOptions();o.publishCameraTrack=enabled;int result=engine.updateChannelMediaOptions(o);if(result==0)appliedVideoPublisher647=enabled;else appliedVideoPublisher647=null;if(enabled)engine.startPreview();else engine.stopPreview();syncBridge648();return result;}
    public int switchCamera647(){return engine==null||!publisher647?-1:engine.switchCamera();}
    public int beauty647(boolean enabled,float value){if(engine==null||!publisher647)return -1;float amount=Math.max(0,Math.min(1,value));io.agora.rtc2.video.BeautyOptions options=new io.agora.rtc2.video.BeautyOptions();options.smoothnessLevel=amount;options.lighteningLevel=amount*.5f;return engine.setBeautyEffectOptions(enabled,options);}
    public void attachVideo647(android.view.View target,int uid,boolean local){if(engine==null||!videoMode647)return;io.agora.rtc2.video.VideoCanvas canvas=new io.agora.rtc2.video.VideoCanvas(target,io.agora.rtc2.Constants.RENDER_MODE_HIDDEN,local?0:uid);int rc=local?engine.setupLocalVideo(canvas):engine.setupRemoteVideo(canvas);if(rc!=0)android.util.Log.w("MYSHOP_RTC","Video bind uid="+uid+" local="+local+" rc="+rc);}
    public void desiredCamera652(boolean on){if(cameraEnabled647!=on){cameraEnabled647=on;appliedVideoPublisher647=null;}}
    public void prepareCamera649(boolean on){cameraEnabled647=on;appliedVideoPublisher647=null;}
    public void recoverFocus649(){if(audioManager!=null&&audioManager.requestAudioFocus(focusListener,android.media.AudioManager.STREAM_VOICE_CALL,android.media.AudioManager.AUDIOFOCUS_GAIN)==android.media.AudioManager.AUDIOFOCUS_REQUEST_GRANTED){focusAllowed=true;setMicEnabled(desiredPublish649&&desiredMic649);}recoverPlayback();}
    public boolean cameraEnabled649(){return cameraEnabled647;}
    public void renewToken(String token){if(engine!=null&&token!=null&&!token.isEmpty())engine.renewToken(token);}
    /** Publishes the selected Admin-library track with the microphone to every listener. */
    public int startMusic(String url){
        if(engine==null||url==null||url.trim().isEmpty())return -10003;
        try{return engine.startAudioMixing(url.trim(),false,1);}catch(Exception e){return -10004;}
    }
    public void pauseMusic(){if(engine!=null)try{engine.pauseAudioMixing();}catch(Exception ignored){}}
    public void resumeMusic(){if(engine!=null)try{engine.resumeAudioMixing();}catch(Exception ignored){}}
    public void stopMusic(){if(engine!=null)try{engine.stopAudioMixing();}catch(Exception ignored){}}
    public void setMusicVolume(int volume){if(engine!=null)try{engine.adjustAudioMixingVolume(Math.max(0,Math.min(100,volume)));}catch(Exception ignored){}}
    public void leave(){stopBridge648();if(engine!=null)engine.leaveChannel();joining=false;joined=false;lastPublishAudio=null;lastMicEnabled=null;remoteVideo651.clear();}
    public void destroy(){stopBridge648();if(audioManager!=null){if(deviceCallback!=null)audioManager.unregisterAudioDeviceCallback(deviceCallback);audioManager.abandonAudioFocus(focusListener);if(android.os.Build.VERSION.SDK_INT>=31)try{audioManager.clearCommunicationDevice();}catch(Exception ignored){}}speakingUntil.clear();leave();if(engine!=null){RtcEngine.destroy();engine=null;}}
}
