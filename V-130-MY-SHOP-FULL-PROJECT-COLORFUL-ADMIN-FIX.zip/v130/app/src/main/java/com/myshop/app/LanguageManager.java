package com.myshop.app;

import android.app.AlertDialog;
import android.content.Context;
import java.util.HashMap;
import java.util.Map;

public final class LanguageManager {
    public static final String BN="bn", EN="en", HI="hi", AR="ar";
    private static final String PREFS="myshop_settings", KEY_LANGUAGE="language";
    private static final String[] CODES={BN,EN,HI,AR};
    private static final String[] LABELS={"বাংলা","English","हिन्दी","العربية"};
    private static final Map<String,Map<String,String>> TEXT=new HashMap<>();

    static {
        Map<String,String> en=new HashMap<>();
        en.put("search","Search for products, live, users, posts..."); en.put("breaking","BREAKING NEWS"); en.put("liveNow","LIVE NOW"); en.put("seeAll","See all");
        en.put("live","LIVE"); en.put("goLive","GO LIVE"); en.put("feed","MY FEED"); en.put("shop","MY SHOP"); en.put("gallery","GALLERY"); en.put("movie","EXTERNAL MOVIE"); en.put("tv","LIVE TV");
        en.put("social","SOCIAL MEDIA"); en.put("reward","EARN & REWARD"); en.put("share","SHARE"); en.put("apps","MORE APPS"); en.put("chat","Chat"); en.put("home","Home"); en.put("store","Store"); en.put("more","More");
        en.put("language","Language"); en.put("login","LOGIN"); en.put("register","CREATE ACCOUNT"); en.put("forgot","Forgot Password?"); en.put("welcome","Welcome Back!"); en.put("remember","Remember me"); en.put("or","OR");
        en.put("fullName","Full Name"); en.put("email","Email Address (optional)"); en.put("mobile","Mobile Number (optional)"); en.put("password","Create Password"); en.put("confirm","Confirm Password");
        en.put("security","Security Question + Password Reset"); en.put("securityHint","Set one security question and answer. This question will appear in Forgot Password; the correct answer lets you set a new password."); en.put("terms","I agree to the Terms & Conditions and Privacy Policy"); en.put("noOtp","No OTP / verification code required");
        en.put("createSubtitle","Join with us and start your journey"); en.put("answer1","Security Answer"); en.put("alreadyLogin","Already have an account? Login"); en.put("selectQuestion","Select a security question");
        en.put("q1","What is the name of your favorite person?"); en.put("q2","Which district is your birthplace?"); en.put("q3","What is your favorite color?"); en.put("q4","What is your favorite teacher's name?"); en.put("q5","What is your birth year?"); en.put("q6","What is your favorite sport?");
        TEXT.put(EN,en);

        Map<String,String> bn=new HashMap<>();
        bn.put("search","পণ্য, লাইভ, ইউজার, পোস্ট খুঁজুন..."); bn.put("breaking","ব্রেকিং নিউজ"); bn.put("liveNow","লাইভ এখন চলছে"); bn.put("seeAll","সব দেখুন"); bn.put("live","লাইভ"); bn.put("goLive","লাইভ যান"); bn.put("feed","MY FEED"); bn.put("shop","MY SHOP"); bn.put("gallery","গ্যালারি"); bn.put("movie","এক্সটার্নাল মুভি"); bn.put("tv","লাইভ টিভি");
        bn.put("social","সোশ্যাল মিডিয়া"); bn.put("reward","আয় ও পুরস্কার"); bn.put("share","শেয়ার"); bn.put("apps","আরও অ্যাপস"); bn.put("chat","চ্যাট"); bn.put("home","হোম"); bn.put("store","স্টোর"); bn.put("more","আরও"); bn.put("language","ভাষা"); bn.put("login","লগইন"); bn.put("register","অ্যাকাউন্ট খুলুন"); bn.put("forgot","পাসওয়ার্ড ভুলে গেছেন?"); bn.put("welcome","স্বাগতম আবার!"); bn.put("remember","আমাকে মনে রাখুন"); bn.put("or","অথবা");
        bn.put("fullName","পূর্ণ নাম"); bn.put("email","ইমেইল (ঐচ্ছিক)"); bn.put("mobile","মোবাইল নম্বর (ঐচ্ছিক)"); bn.put("password","পাসওয়ার্ড তৈরি করুন"); bn.put("confirm","পাসওয়ার্ড নিশ্চিত করুন"); bn.put("security","সিকিউরিটি প্রশ্ন + পাসওয়ার্ড রিসেট"); bn.put("securityHint","একটি সিকিউরিটি প্রশ্ন ও উত্তর সেট করুন। Forgot Password-এ এই প্রশ্নটি দেখাবে; সঠিক উত্তর দিলে নতুন পাসওয়ার্ড সেট করতে পারবেন।"); bn.put("terms","আমি Terms & Conditions এবং Privacy Policy মেনে নিচ্ছি"); bn.put("noOtp","কোনো OTP / ভেরিফিকেশন কোড লাগবে না");
        bn.put("createSubtitle","আমাদের সাথে যোগ দিন এবং আপনার যাত্রা শুরু করুন"); bn.put("answer1","সিকিউরিটি উত্তর"); bn.put("alreadyLogin","আগেই অ্যাকাউন্ট আছে? লগইন করুন"); bn.put("selectQuestion","সিকিউরিটি প্রশ্ন নির্বাচন করুন");
        bn.put("q1","আপনার প্রিয় মানুষের নাম কি?"); bn.put("q2","আপনার জন্মস্থান কোন জেলা?"); bn.put("q3","আপনার প্রিয় রঙ কি?"); bn.put("q4","আপনার প্রিয় শিক্ষকের নাম কি?"); bn.put("q5","আপনার জন্ম সাল কত?"); bn.put("q6","আপনার প্রিয় খেলা কি?");
        TEXT.put(BN,bn);

        Map<String,String> hi=new HashMap<>();
        hi.put("search","प्रोडक्ट, लाइव, यूज़र, पोस्ट खोजें..."); hi.put("breaking","ब्रेकिंग न्यूज़"); hi.put("liveNow","अभी लाइव"); hi.put("seeAll","सब देखें"); hi.put("live","लाइव"); hi.put("goLive","लाइव जाएँ"); hi.put("feed","MY FEED"); hi.put("shop","MY SHOP"); hi.put("gallery","गैलरी"); hi.put("movie","एक्सटर्नल मूवी"); hi.put("tv","लाइव टीवी"); hi.put("social","सोशल मीडिया"); hi.put("reward","कमाएँ और रिवॉर्ड"); hi.put("share","शेयर"); hi.put("apps","और ऐप्स"); hi.put("chat","चैट"); hi.put("home","होम"); hi.put("store","स्टोर"); hi.put("more","और"); hi.put("language","भाषा"); hi.put("login","लॉगिन"); hi.put("register","अकाउंट बनाएँ"); hi.put("forgot","पासवर्ड भूल गए?"); hi.put("welcome","वापसी पर स्वागत है!"); hi.put("remember","मुझे याद रखें"); hi.put("or","या"); hi.put("fullName","पूरा नाम"); hi.put("email","ईमेल (वैकल्पिक)"); hi.put("mobile","मोबाइल नंबर (वैकल्पिक)"); hi.put("password","पासवर्ड बनाएँ"); hi.put("confirm","पासवर्ड की पुष्टि करें"); hi.put("security","सिक्योरिटी प्रश्न + पासवर्ड रीसेट"); hi.put("securityHint","एक सिक्योरिटी प्रश्न और उत्तर सेट करें। Forgot Password में यही प्रश्न दिखेगा; सही उत्तर पर नया पासवर्ड सेट कर सकते हैं।"); hi.put("terms","मैं Terms & Conditions और Privacy Policy से सहमत हूँ"); hi.put("noOtp","OTP / verification code की जरूरत नहीं"); hi.put("createSubtitle","हमसे जुड़ें और अपनी यात्रा शुरू करें"); hi.put("answer1","सिक्योरिटी उत्तर"); hi.put("alreadyLogin","पहले से अकाउंट है? लॉगिन करें"); hi.put("selectQuestion","सिक्योरिटी प्रश्न चुनें");
        hi.put("q1","आपके पसंदीदा व्यक्ति का नाम क्या है?"); hi.put("q2","आपका जन्मस्थान किस जिले में है?"); hi.put("q3","आपका पसंदीदा रंग क्या है?"); hi.put("q4","आपके पसंदीदा शिक्षक का नाम क्या है?"); hi.put("q5","आपका जन्म वर्ष क्या है?"); hi.put("q6","आपका पसंदीदा खेल क्या है?"); TEXT.put(HI,hi);

        Map<String,String> ar=new HashMap<>();
        ar.put("search","ابحث عن المنتجات والبث والمستخدمين والمنشورات..."); ar.put("breaking","أخبار عاجلة"); ar.put("liveNow","مباشر الآن"); ar.put("seeAll","عرض الكل"); ar.put("live","مباشر"); ar.put("goLive","ابدأ البث"); ar.put("feed","MY FEED"); ar.put("shop","MY SHOP"); ar.put("gallery","المعرض"); ar.put("movie","فيلم خارجي"); ar.put("tv","تلفزيون مباشر"); ar.put("social","التواصل الاجتماعي"); ar.put("reward","اربح ومكافآت"); ar.put("share","مشاركة"); ar.put("apps","المزيد من التطبيقات"); ar.put("chat","دردشة"); ar.put("home","الرئيسية"); ar.put("store","المتجر"); ar.put("more","المزيد"); ar.put("language","اللغة"); ar.put("login","تسجيل الدخول"); ar.put("register","إنشاء حساب"); ar.put("forgot","هل نسيت كلمة المرور؟"); ar.put("welcome","مرحباً بعودتك!"); ar.put("remember","تذكرني"); ar.put("or","أو"); ar.put("fullName","الاسم الكامل"); ar.put("email","البريد الإلكتروني (اختياري)"); ar.put("mobile","رقم الهاتف (اختياري)"); ar.put("password","إنشاء كلمة المرور"); ar.put("confirm","تأكيد كلمة المرور"); ar.put("security","سؤال الأمان + إعادة تعيين كلمة المرور"); ar.put("securityHint","اختر سؤال أمان وإجابة واحدة. سيظهر السؤال عند نسيان كلمة المرور، والإجابة الصحيحة تسمح بتعيين كلمة مرور جديدة."); ar.put("terms","أوافق على الشروط وسياسة الخصوصية"); ar.put("noOtp","لا حاجة إلى رمز OTP / التحقق"); ar.put("createSubtitle","انضم إلينا وابدأ رحلتك"); ar.put("answer1","إجابة الأمان"); ar.put("alreadyLogin","لديك حساب بالفعل؟ تسجيل الدخول"); ar.put("selectQuestion","اختر سؤال الأمان");
        ar.put("q1","ما اسم الشخص المفضل لديك؟"); ar.put("q2","في أي منطقة تقع مسقط رأسك؟"); ar.put("q3","ما لونك المفضل؟"); ar.put("q4","ما اسم معلمك المفضل؟"); ar.put("q5","ما سنة ميلادك؟"); ar.put("q6","ما رياضتك المفضلة؟"); TEXT.put(AR,ar);
    }

    private LanguageManager() {}
    public static String get(Context c){ return c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(KEY_LANGUAGE,BN); }
    public static void set(Context c,String l){ c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(KEY_LANGUAGE,l).apply(); }
    public static String t(Context c,String key){ Map<String,String> m=TEXT.get(get(c)); if(m==null)m=TEXT.get(BN); String v=m.get(key); return v==null?key:v; }
    public static String[] securityQuestionOptions(Context c){ return new String[]{t(c,"selectQuestion"),t(c,"q1"),t(c,"q2"),t(c,"q3"),t(c,"q4"),t(c,"q5"),t(c,"q6")}; }
    public static String securityQuestionKey(int position){ return position>=1 && position<=6 ? "q"+position : ""; }
    public static String securityQuestionText(Context c,String stored){
        if(stored==null)return "";
        for(int i=1;i<=6;i++) if(stored.equals("q"+i)) return t(c,"q"+i);
        String[] old={"What is the name of your favorite person?","Which district is your birthplace?","What is your favorite color?","What is your favorite teacher's name?","What is your birth year?","What is your favorite sport?"};
        for(int i=0;i<old.length;i++) if(stored.equals(old[i])) return t(c,"q"+(i+1));
        return stored;
    }
    public static void showPicker(Context c,Runnable onChanged){ new AlertDialog.Builder(c).setTitle("🌐  "+t(c,"language")).setItems(LABELS,(d,w)->{set(c,CODES[w]);if(onChanged!=null)onChanged.run();}).show(); }
}
