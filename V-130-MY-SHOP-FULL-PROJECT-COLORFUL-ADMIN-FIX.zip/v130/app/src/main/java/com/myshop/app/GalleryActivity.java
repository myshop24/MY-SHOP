package com.myshop.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;

/** User gallery: three folders PHOTO / AUDIO / VIDEO. Admin controls content remotely. */
public class GalleryActivity extends AppCompatActivity {
    private LinearLayout list; private String folder="photo";
    @Override protected void onCreate(Bundle b){super.onCreate(b);build();load();}
    private void build(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(14,14,14,20);r.setBackgroundColor(Color.rgb(248,249,253));TextView h=t("GALLERY",23,Color.rgb(50,25,150),true);h.setGravity(Gravity.CENTER);r.addView(h,lp(-1,52));LinearLayout tabs=new LinearLayout(this);String[] fs={"photo","audio","video"};String[] ls={"PHOTO","AUDIO","VIDEO"};for(int i=0;i<3;i++){Button b=btn(ls[i]);String f=fs[i];b.setOnClickListener(v->{folder=f;load();});tabs.addView(b,wt(1));}r.addView(tabs,lp(-1,52));list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);ScrollView s=new ScrollView(this);s.addView(list);r.addView(s,lp(-1,0,1));Button back=btn("BACK");back.setOnClickListener(v->finish());r.addView(back,lp(-1,50));setContentView(r);}
    private void load(){BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->render(d.optJSONArray("media")));}public void onError(String m){runOnUiThread(()->Toast.makeText(GalleryActivity.this,"Gallery unavailable",Toast.LENGTH_SHORT).show());}});}
    private void render(JSONArray a){list.removeAllViews();int count=0;try{if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null||!folder.equalsIgnoreCase(x.optString("folder",""))||x.optInt("active",1)!=1)continue;count++;card(x);}}catch(Exception ignored){}if(count==0){TextView e=t("No media available in this folder.",14,Color.DKGRAY,false);e.setPadding(12,30,12,30);list.addView(e);}}
    private void card(JSONObject x){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(10,8,10,8);c.setBackgroundColor(Color.WHITE);TextView title=t(x.optString("title","Untitled"),16,Color.BLACK,true);c.addView(title);TextView cap=t(x.optString("caption",""),12,Color.DKGRAY,false);c.addView(cap);String url=x.optString("media_url","");if(folder.equals("photo")){ImageView iv=new ImageView(this);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);c.addView(iv,lp(-1,180));loadImage(iv,url);}else{Button play=btn(folder.equals("audio")?"▶ PLAY AUDIO":"▶ PLAY VIDEO");play.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}catch(Exception e){Toast.makeText(this,"No player found",Toast.LENGTH_SHORT).show();}});c.addView(play,lp(-1,52));}list.addView(c,lp(-1,folder.equals("photo")?260:130));}
    private void loadImage(ImageView v,String u){Executors.newSingleThreadExecutor().execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(10000);try(InputStream in=c.getInputStream()){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null)runOnUiThread(()->v.setImageBitmap(b));}}catch(Exception ignored){}});}
    private Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}private TextView t(String s,float z,int c,boolean bo){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bo)t.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return t;}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams lp(int w,int h,float wt){return new LinearLayout.LayoutParams(w,h,wt);}private LinearLayout.LayoutParams wt(float w){return new LinearLayout.LayoutParams(0,52,w);}
}
