# MY SHOP Developer Handoff — V-326

## Scope locked for this version
Only the Admin **Gift Coin & Gold Coin Catalog** usability correction was changed. The separate future mobile Live/Message notification request is NOT included in this version.

## Completed
- Gift Coin and Gold Coin remain separate tabs/catalogs.
- Catalog list changed from tall stacked cards to a compact 4-column live-store-style grid.
- Every existing gift remains visible in the selected catalog; tapping a compact gift card opens the full editor.
- Long-press + drag is enabled on gift cards. Dropping on another occupied slot swaps the two slots and saves the whole selected catalog order server-side.
- New protected backend endpoint: `/v1/admin/live/gifts/reorder`; validates currency, IDs, duplicates, 50-item maximum, then persists contiguous sort order.
- Sound Add now opens the Android audio picker and keeps the selected audio LOCAL first; it is no longer immediately uploaded as a URL.
- Selected audio shows file name and duration when available.
- Start/End trim sliders show actual time labels for locally selected audio and the selected segment can be previewed before upload.
- Preview/Test plays the local selected audio segment directly from the phone, respecting trim, volume and sound duration.
- Sound is uploaded to R2 only when **SAVE / PUBLISH** is pressed; after successful upload the gift record is saved.
- Sound Remove is explicit and only takes effect after Save.
- Existing remote/saved sound can still be previewed; existing live playback already respects trim Start/End, volume and duration.
- Gift editor still preserves price, per-gift VAT, global VAT, animation/effect duration, animation size/board coverage, board position, catalog animation, enable/publish, image/animation assets and Add New Gift.

## Regression safety
- Existing gift-send animation logic was not replaced.
- Existing Coin/Gold gift data schema was not dropped or recreated.
- Reorder is an additive endpoint; no destructive DB migration was added.
- Live/Message push-notification work is intentionally deferred to a later focused version.

## Validation status
- Worker JavaScript syntax: PASS (`node --check`).
- Modified Java files parser-level syntax scan: PASS (no parser syntax errors detected; Android SDK symbols unavailable in this container).
- Version identity: V-326 / 2.9.326 / versionCode 326.
- Real Android compile/signing: requires normal GitHub Actions/Android SDK environment.
- Real-device verification still required for Android document picker, local audio preview, R2 save upload, drag/drop gesture and multi-device Live Store order refresh.

## V-327 checkpoint
- Base: V-326-MY-SHOP-GIFT-CATALOG-DRAG-SOUND-FINAL.zip
- Scope locked to Gift Coin / Gold Coin Admin Catalog UI/UX.
- Added editor Box selector with reorder normalization, trim waveform guide, Live Board Preview, Save Draft, Publish and Delete controls.
- Preserved existing backend schema/API and unrelated app modules.
- Next gate: compile/static validation and device acceptance of Admin catalog editing + regression smoke test.
