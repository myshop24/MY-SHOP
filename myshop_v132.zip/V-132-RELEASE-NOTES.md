# MY SHOP V-132

Targeted fix only:
- Banner slot is now directly tappable to open the phone document/gallery picker.
- Banner cards explicitly show CHANGE IMAGE, EDIT, SAVE, DELETE.
- Caption field is larger and easier to edit.
- Existing D1 and R2 bindings are preserved.
- Dashboard config self-healing remains additive and does not reset user/auth data.
- Version code 132 / version name 2.9.132.

Important: production Worker code must be deployed for the server-config fix to take effect. The code cannot auto-deploy merely because an APK is installed.
