package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import androidx.appcompat.app.AppCompatActivity;
import java.io.InputStream;
import org.json.JSONArray;
import org.json.JSONObject;

/** V-124 R2 banner manager — upload, caption save, delete for all 9 banner slots. */
public class BannerAdminActivity extends AppCompatActivity {
    private LinearLayout list; private final EditText[] heroCaption=new EditText[6],promoCaption=new EditText[3];
    private final boolean[] heroExists=new boolean[6],promoExists=new boolean[3];
    private final int PURPLE=Color.rgb(83,32,180),GREEN=Color.rgb(17,139,88),RED=Color.rgb(210,45,55),BLUE=Color.rgb(31,73,210),BG=Color.rgb(246,248,252);
    private String folder; private int slot;
    @Override protected void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)){finish();return;}build();load();}
    private void build(){
        LinearLayout root=col();root.setPadding(dp(12),dp(12),dp(12),dp(18));root.setBackgroundColor(BG);
        TextView h=txt("MY SHOP  •  BANNER MANAGER",22,Color.rgb(20,28,60),true);h.setGravity(Gravity.CENTER);root.addView(h,lp(-1,dp(48)));
        TextView n=txt("R2 storage  •  6 Hero + 3 Promo  •  Admin only",11,Color.DKGRAY,false);n.setGravity(Gravity.CENTER);root.addView(n,lp(-1,dp(28)));
        list=col();ScrollView sv=new ScrollView(this);sv.addView(list);root.addView(sv,lp(-1,0,1));
        TextView back=action("BACK",Color.rgb(20,28,60),()->finish());root.addView(back,lp(-1,dp(44)));setContentView(root);
    }
    private void load(){BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{render(d.optJSONArray("banners"));});}public void onError(String m){runOnUiThread(()->toast("Load failed: "+m));}});}
    private void render(JSONArray a){list.removeAllViews();for(int i=0;i<6;i++){heroExists[i]=false;heroCaption[i]=null;}for(int i=0;i<3;i++){promoExists[i]=false;promoCaption[i]=null;}
        JSONObject[] dataH=new JSONObject[6],dataP=new JSONObject[3];if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;int sl=x.optInt("slot",0);if("hero".equalsIgnoreCase(x.optString("folder",""))&&sl>=1&&sl<=6)dataH[sl-1]=x;if("promo".equalsIgnoreCase(x.optString("folder",""))&&sl>=1&&sl<=3)dataP[sl-1]=x;}
        list.addView(section("HERO BANNERS  •  6"));for(int i=0;i<6;i++)slotCard("hero",i+1,"Hero Banner "+(i+1),dataH[i]);
        list.addView(section("PROMO BANNERS  •  3"));for(int i=0;i<3;i++)slotCard("promo",i+1,"Promo Banner "+(i+1),dataP[i]);
    }
    private void slotCard(String f,int sl,String label,JSONObject x){
        boolean exists=x!=null; if("hero".equals(f))heroExists[sl-1]=exists;else promoExists[sl-1]=exists;
        LinearLayout card=col();card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(bg(Color.WHITE,Color.rgb(224,226,235),10));
        card.setClickable(true); card.setOnClickListener(v->{folder=f;slot=sl;pick();});
        TextView name=txt(label+(exists?"  •  SAVED":"  •  EMPTY"),15,Color.rgb(20,28,60),true);card.addView(name,lp(-1,dp(30)));
        TextView tap=txt(exists?"Tap this banner to change the image • Edit caption below":"Tap this banner to choose an image from your phone",11,Color.rgb(83,32,180),false);card.addView(tap,lp(-1,dp(28)));
        EditText cap=field("Caption / headline");cap.setText(exists?x.optString("caption",""):"");card.addView(cap,lp(-1,dp(48)));if("hero".equals(f))heroCaption[sl-1]=cap;else promoCaption[sl-1]=cap;
        LinearLayout actions=row();
        actions.addView(action("CHANGE IMAGE",PURPLE,()->{folder=f;slot=sl;pick();}),wt(1));
        actions.addView(gap(),lp(dp(5),1));
        actions.addView(action("EDIT",BLUE,()->{cap.requestFocus();cap.setSelection(cap.length());}),wt(1));
        actions.addView(gap(),lp(dp(5),1));
        actions.addView(action("SAVE",GREEN,()->saveCaption(f,sl,cap.getText().toString().trim())),wt(1));
        actions.addView(gap(),lp(dp(5),1));
        actions.addView(action("DELETE",RED,()->confirmDelete(f,sl)),wt(1));
        card.addView(actions,lp(-1,dp(44)));
        TextView hint=txt(exists?x.optString("image_url",""):"No image uploaded yet",9,Color.GRAY,false);hint.setMaxLines(1);card.addView(hint,lp(-1,dp(22)));
        list.addView(card,lp(-1,-2));Space sp=new Space(this);list.addView(sp,lp(1,dp(8)));
    }
    private void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,800);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r!=800||c!=RESULT_OK||d==null||d.getData()==null)return;upload(d.getData());}
    private void upload(Uri u){try{InputStream in=getContentResolver().openInputStream(u);String mime=getContentResolver().getType(u);BackendClient.adminBannerUpload(SessionManager.getToken(this),in,"banner.jpg",mime,folder,slot,"",new BackendClient.Callback(){public void onSuccess(JSONObject d){toast("✓ Banner uploaded to R2");load();}public void onError(String m){toast("Upload failed: "+m);}});}catch(Exception e){toast("Cannot open selected image.");}}
    private void saveCaption(String f,int sl,String cap){BackendClient.adminBannerUpdate(SessionManager.getToken(this),f,sl,cap,new BackendClient.Callback(){public void onSuccess(JSONObject d){toast("✓ Caption saved");load();}public void onError(String m){toast("Save failed: "+m);}});}
    private void confirmDelete(String f,int sl){new AlertDialog.Builder(this).setTitle("Delete banner?").setMessage("This removes the slot and its R2 object.").setPositiveButton("DELETE",(d,w)->BackendClient.adminBannerDelete(SessionManager.getToken(this),f,sl,new BackendClient.Callback(){public void onSuccess(JSONObject x){toast("✓ Deleted");load();}public void onError(String m){toast("Delete failed: "+m);}})).setNegativeButton("CANCEL",null).show();}
    private TextView section(String s){TextView t=txt(s,14,PURPLE,true);t.setPadding(dp(3),dp(10),0,dp(6));return t;}
    private TextView action(String s,int c,Runnable r){TextView t=txt(s,11,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setBackground(bg(c,c,7));t.setOnClickListener(v->r.run());return t;}
    private EditText field(String h){EditText e=new EditText(this);e.setHint(h);e.setSingleLine(true);e.setTextSize(12);e.setPadding(dp(10),0,dp(10),0);e.setBackground(bg(Color.WHITE,Color.rgb(215,218,228),7));return e;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private View gap(){return new View(this);}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams lp(int w,int h,float wt){return new LinearLayout.LayoutParams(w,h,wt);}private LinearLayout.LayoutParams wt(float w){return new LinearLayout.LayoutParams(0,dp(42),w);}private GradientDrawable bg(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;}private TextView txt(String s,float z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
}
