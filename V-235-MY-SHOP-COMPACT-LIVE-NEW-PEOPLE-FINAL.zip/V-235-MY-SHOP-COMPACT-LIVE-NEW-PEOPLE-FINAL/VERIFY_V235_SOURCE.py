from pathlib import Path
root=Path(__file__).resolve().parent
read=lambda p:(root/p).read_text(encoding='utf-8')
main=read('app/src/main/java/com/myshop/app/MainActivity.java')
client=read('app/src/main/java/com/myshop/app/BackendClient.java')
worker=read('backend/worker/src/index.js')
gradle=read('app/build.gradle')
workflow=read('.github/workflows/my-shop-apk.yml')
checks={
 'source id':read('SOURCE_BUILD_ID.txt').strip()=='MY SHOP V-235',
 'source version':read('SOURCE_VERSION_NAME.txt').strip()=='2.9.235',
 'android version':'versionCode 235' in gradle and "versionName '2.9.235'" in gradle,
 'worker identity':worker.count("version:'2.9.235',build:'V-235'")>=2,
 'notification':'release_notice_v235' in worker,
 'workflow':'AUTO-BUILD V-235' in workflow,
 'compact live':'dp(148)' in main and 'dp(258)' in main,
 'ad unchanged':'page.addView(hero,top(lp(-1,dp(118)),6))' in main,
 'four visible':'widthPixels-dp(12))/4' in main,
 'people client':'/v1/people/new' in client and '/v1/friends/request' in client,
 'people backend':'myshop_friend_requests' in worker and 'myshop_user_blocks' in worker,
}
bad=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(('PASS' if v else 'FAIL'),k)
raise SystemExit(1 if bad else 0)
