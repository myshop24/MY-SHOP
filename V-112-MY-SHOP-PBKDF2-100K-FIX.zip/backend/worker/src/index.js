const json = (data, status = 200, extra = {}) => new Response(JSON.stringify(data), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", ...extra }
});

const cors = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET,POST,PUT,DELETE,OPTIONS",
  "access-control-allow-headers": "Content-Type, Authorization"
};

function normalizeEmail(v) { return String(v || '').trim().toLowerCase(); }
function normalizeMobile(v) { return String(v || '').trim().replace(/[\s()-]/g, ''); }
function normalizeAnswer(v) { return String(v || '').trim().toLowerCase(); }
function isFourDigit(v) { return /^\d{4}$/.test(String(v || '')); }

function bytesToHex(bytes) { return [...new Uint8Array(bytes)].map(b => b.toString(16).padStart(2,'0')).join(''); }
function hexToBytes(hex) { const out = new Uint8Array(hex.length / 2); for (let i=0;i<out.length;i++) out[i]=parseInt(hex.slice(i*2,i*2+2),16); return out; }

async function sha256(text) {
  return bytesToHex(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)));
}

const PBKDF2_ITERATIONS = 100000;

async function pbkdf2(password, saltHex, iterations = PBKDF2_ITERATIONS) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({name:'PBKDF2', salt:hexToBytes(saltHex), iterations, hash:'SHA-256'}, key, 256);
  return bytesToHex(bits);
}

function randomHex(bytes = 16) {
  const a = new Uint8Array(bytes); crypto.getRandomValues(a); return bytesToHex(a);
}

async function hashPassword(password) {
  const salt = randomHex(16);
  const iterations = PBKDF2_ITERATIONS;
  const digest = await pbkdf2(password, salt, iterations);
  return `pbkdf2_sha256$${iterations}$${salt}$${digest}`;
}

async function verifyPassword(password, stored) {
  const p = String(stored || '').split('$');
  if (p.length !== 4 || p[0] !== 'pbkdf2_sha256') return false;
  const digest = await pbkdf2(password, p[2], Number(p[1]));
  return digest === p[3];
}

async function ensureAuthSchema(env) {
  // IMPORTANT: the existing legacy `users` table is never dropped, renamed, or cleared.
  // Auth data lives in dedicated tables so older user/profile data remains untouched.
  await env.DB.batch([
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_auth_users_v108 (
      user_id TEXT PRIMARY KEY CHECK(length(user_id)=4),
      full_name TEXT NOT NULL,
      email TEXT UNIQUE,
      mobile TEXT UNIQUE,
      password_hash TEXT NOT NULL,
      security_q1 TEXT NOT NULL, security_a1_hash TEXT NOT NULL,
      security_q2 TEXT NOT NULL, security_a2_hash TEXT NOT NULL,
      security_q3 TEXT NOT NULL, security_a3_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'USER' CHECK(role IN ('USER','ADMIN','MODERATOR')),
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )`),
    env.DB.prepare(`CREATE UNIQUE INDEX IF NOT EXISTS idx_myshop_auth_email ON myshop_auth_users_v108(email) WHERE email IS NOT NULL AND email <> ''`),
    env.DB.prepare(`CREATE UNIQUE INDEX IF NOT EXISTS idx_myshop_auth_mobile ON myshop_auth_users_v108(mobile) WHERE mobile IS NOT NULL AND mobile <> ''`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_auth_sessions_v108 (
      token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id) ON DELETE CASCADE,
      expires_at INTEGER NOT NULL, created_at INTEGER NOT NULL
    )`),
    env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_myshop_auth_sessions_v108_user ON myshop_auth_sessions_v108(user_id)`),
    env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_moderators_v108 (
      user_id TEXT PRIMARY KEY REFERENCES myshop_auth_users_v108(user_id) ON DELETE CASCADE,
      active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )`)
  ]);
  await migratePreviousAuthIfPresent(env);
}

async function migratePreviousAuthIfPresent(env) {
  // V-107 may have created the old auth table before a deployment failed.
  // Copy compatible rows forward; never delete or modify the old table.
  try {
    await env.DB.prepare(`INSERT OR IGNORE INTO myshop_auth_users_v108
      (user_id,full_name,email,mobile,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role,active,created_at,updated_at)
      SELECT user_id,full_name,email,mobile,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role,active,created_at,updated_at
      FROM myshop_auth_users`).run();
  } catch (_) {
    // Old table may not exist or may have an incompatible schema. Leave it untouched.
  }
}

async function createSession(env, userId) {
  const raw = `${crypto.randomUUID()}-${randomHex(16)}`;
  const hash = await sha256(raw);
  const days = Math.max(1, Number(env.SESSION_DAYS || 30));
  const expires = Date.now() + days * 86400000;
  await env.DB.prepare('INSERT INTO myshop_auth_sessions_v108(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)')
    .bind(hash, userId, expires, Date.now()).run();
  return raw;
}

async function getUser(request, env) {
  const auth = request.headers.get('authorization') || '';
  if (!auth.toLowerCase().startsWith('bearer ')) return null;
  const raw = auth.slice(7).trim();
  if (!raw) return null;
  const hash = await sha256(raw);
  const row = await env.DB.prepare(`SELECT u.* FROM myshop_auth_sessions_v108 s JOIN myshop_auth_users_v108 u ON u.user_id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.active=1`).bind(hash, Date.now()).first();
  return row || null;
}

function publicUser(u) {
  return { userId:u.user_id, name:u.full_name, email:u.email || '', mobile:u.mobile || '', role:u.role };
}

async function body(request) {
  try { return await request.json(); } catch { return {}; }
}

async function findAuthUser(env, identifier) {
  const id = String(identifier || '').trim();
  let user = null;
  if (isFourDigit(id)) user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(id).first();
  if (!user && id.includes('@')) user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE email=? AND active=1').bind(normalizeEmail(id)).first();
  if (!user) user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE mobile=? AND active=1').bind(normalizeMobile(id)).first();
  return user;
}

async function register(request, env) {
  const b = await body(request);
  const name = String(b.name || '').trim();
  const email = normalizeEmail(b.email);
  const mobile = normalizeMobile(b.mobile);
  const password = String(b.password || '');
  const qs = Array.isArray(b.securityQuestions) ? b.securityQuestions : [];
  const ans = Array.isArray(b.securityAnswers) ? b.securityAnswers : [];
  if (!name || (!email && !mobile) || password.length < 6 || qs.length !== 3 || ans.length !== 3) return json({error:'INVALID_INPUT'},400,cors);
  if (new Set(qs.map(String)).size !== 3 || ans.some(x => !String(x || '').trim())) return json({error:'INVALID_SECURITY_QUESTIONS'},400,cors);
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({error:'INVALID_EMAIL'},400,cors);

  const duplicate = await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE (?<>'' AND email=?) OR (?<>'' AND mobile=?) LIMIT 1`)
    .bind(email,email,mobile,mobile).first();
  if (duplicate) return json({error:'ACCOUNT_EXISTS'},409,cors);

  // Keep legacy users untouched, but block duplicate identifiers that already exist there.
  try {
    const legacy = await env.DB.prepare(`SELECT id FROM users WHERE (?<>'' AND lower(email)=?) OR (?<>'' AND mobile=?) LIMIT 1`)
      .bind(email,email,mobile,mobile).first();
    if (legacy) return json({error:'ACCOUNT_EXISTS'},409,cors);
  } catch (_) { /* legacy table may not exist on a fresh database */ }

  const adminMap = {
    'myshopsatkania@gmail.com': '0001',
    'touhidsatkania@gmail.com': '0002',
    '01860626700': '0003'
  };
  const adminId = adminMap[email] || adminMap[mobile] || '';
  const role = adminId ? 'ADMIN' : 'USER';
  let userId = adminId;
  if (!userId) {
    const next = await env.DB.prepare(`SELECT COALESCE(MAX(CAST(user_id AS INTEGER))+1,100) AS n FROM myshop_auth_users_v108 WHERE CAST(user_id AS INTEGER) >= 100`).first();
    const n = Number(next?.n || 100);
    if (n > 9999) return json({error:'NO_ID_AVAILABLE'},409,cors);
    userId = String(n).padStart(4,'0');
  } else {
    const occupied = await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=?').bind(userId).first();
    if (occupied) return json({error:'ACCOUNT_EXISTS'},409,cors);
  }

  const ph = await hashPassword(password);
  const ah = await Promise.all(ans.map(a => sha256(normalizeAnswer(a))));
  await env.DB.prepare(`INSERT INTO myshop_auth_users_v108(user_id,full_name,email,mobile,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).bind(userId,name,email||null,mobile||null,ph,String(qs[0]),ah[0],String(qs[1]),ah[1],String(qs[2]),ah[2],role).run();

  const user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=?').bind(userId).first();
  const token = await createSession(env, userId);
  return json({ok:true,user:publicUser(user),token},201,cors);
}

async function login(request, env) {
  const b = await body(request);
  const id = String(b.identifier || '').trim();
  const password = String(b.password || '');
  if (!id || !password) return json({error:'INVALID_INPUT'},400,cors);
  const user = await findAuthUser(env,id);
  if (!user || !(await verifyPassword(password,user.password_hash))) return json({error:'INVALID_CREDENTIALS'},401,cors);
  const token = await createSession(env,user.user_id);
  return json({ok:true,user:publicUser(user),token},200,cors);
}

async function me(request, env) {
  const user = await getUser(request,env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  return json({ok:true,user:publicUser(user)},200,cors);
}

async function logout(request, env) {
  const auth = request.headers.get('authorization') || '';
  if (auth.toLowerCase().startsWith('bearer ')) await env.DB.prepare('DELETE FROM myshop_auth_sessions_v108 WHERE token_hash=?').bind(await sha256(auth.slice(7).trim())).run();
  return json({ok:true},200,cors);
}

async function securityQuestions(request, env) {
  const id = String(new URL(request.url).searchParams.get('identifier') || '').trim();
  const user = await findAuthUser(env,id);
  if (!user) return json({error:'NOT_FOUND'},404,cors);
  return json({ok:true,questions:[user.security_q1,user.security_q2,user.security_q3]},200,cors);
}

async function resetPassword(request, env) {
  const b = await body(request);
  const id = String(b.identifier || '').trim();
  const answers = Array.isArray(b.answers) ? b.answers : [];
  const newPassword = String(b.newPassword || '');
  if (!id || answers.length !== 3 || newPassword.length < 6) return json({error:'INVALID_INPUT'},400,cors);
  const user = await findAuthUser(env,id);
  if (!user) return json({error:'NOT_FOUND'},404,cors);
  const hashes = await Promise.all(answers.map(a => sha256(normalizeAnswer(a))));
  const matches = [user.security_a1_hash,user.security_a2_hash,user.security_a3_hash].reduce((n,h,i)=>n+(h && h===hashes[i]?1:0),0);
  if (matches < 2) return json({error:'ANSWERS_NOT_MATCHED'},403,cors);
  const ph = await hashPassword(newPassword);
  await env.DB.prepare('UPDATE myshop_auth_users_v108 SET password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(ph,user.user_id).run();
  await env.DB.prepare('DELETE FROM myshop_auth_sessions_v108 WHERE user_id=?').bind(user.user_id).run();
  return json({ok:true,userId:user.user_id},200,cors);
}

async function dashboardConfig(request, env) {
  const config = await env.DB.prepare('SELECT * FROM dashboard_config WHERE id=1').first();
  const banners = await env.DB.prepare('SELECT id,folder,slot,image_url,caption,active FROM banners WHERE active=1 ORDER BY folder,slot').all();
  const social = await env.DB.prepare('SELECT platform,url,active FROM social_links WHERE active=1 ORDER BY platform').all();
  return json({ok:true,config:config||{},banners:banners.results||[],socialLinks:social.results||[]},200,cors);
}

async function adminOnly(request, env) {
  const user = await getUser(request,env);
  if (!user || user.role !== 'ADMIN') return {error:json({error:'ADMIN_REQUIRED'},403,cors)};
  return {user};
}

async function adminDashboardPut(request, env) {
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const b = await body(request);
  await env.DB.prepare(`UPDATE dashboard_config SET breaking_news=?,my_shop_url=?,live_tv_url=?,external_movie_url=?,chat_url=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`)
    .bind(String(b.breakingNews||''),String(b.myShopUrl||''),String(b.liveTvUrl||''),String(b.externalMovieUrl||''),String(b.chatUrl||'')).run();
  return json({ok:true},200,cors);
}

async function adminPermissions(request,env) {
  const user = await getUser(request,env); if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  const mods = await env.DB.prepare('SELECT user_id,active FROM myshop_moderators_v108 ORDER BY user_id LIMIT 5').all();
  return json({ok:true,role:user.role,admin:user.role==='ADMIN',moderators:mods.results||[]},200,cors);
}

async function adminAction(request,env) {
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const b = await body(request);
  const uid = String(b.userId||'').trim();
  const action = String(b.action||'').toLowerCase();
  if (!isFourDigit(uid)) return json({error:'INVALID_USER_ID'},400,cors);
  if (action==='add_moderator') {
    const target = await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(uid).first();
    if (!target) return json({error:'USER_NOT_FOUND'},404,cors);
    const count = await env.DB.prepare('SELECT COUNT(*) AS c FROM myshop_moderators_v108 WHERE active=1').first();
    if (Number(count?.c||0)>=5) return json({error:'MODERATOR_LIMIT'},409,cors);
    await env.DB.prepare('INSERT INTO myshop_moderators_v108(user_id) VALUES(?) ON CONFLICT(user_id) DO UPDATE SET active=1').bind(uid).run();
    await env.DB.prepare("UPDATE myshop_auth_users_v108 SET role='MODERATOR' WHERE user_id=? AND user_id NOT IN ('0001','0002','0003')").bind(uid).run();
  } else if (action==='remove_moderator') {
    await env.DB.prepare('UPDATE myshop_moderators_v108 SET active=0 WHERE user_id=?').bind(uid).run();
    await env.DB.prepare("UPDATE myshop_auth_users_v108 SET role=CASE WHEN role='MODERATOR' THEN 'USER' ELSE role END WHERE user_id=?").bind(uid).run();
  } else return json({error:'UNSUPPORTED_ACTION'},400,cors);
  return json({ok:true},200,cors);
}

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null,{status:204,headers:cors});
    const url = new URL(request.url); const p=url.pathname;
    try {
      if (request.method==='GET' && p==='/health') return json({ok:true,service:'my-shop-api',database:'my-shop-db',time:new Date().toISOString()},200,cors);
      await ensureAuthSchema(env);
      if (request.method==='POST' && p==='/v1/auth/register') return await register(request,env);
      if (request.method==='POST' && p==='/v1/auth/login') return await login(request,env);
      if (request.method==='POST' && p==='/v1/auth/logout') return await logout(request,env);
      if (request.method==='GET' && p==='/v1/auth/password/questions') return await securityQuestions(request,env);
      if (request.method==='POST' && p==='/v1/auth/password/reset') return await resetPassword(request,env);
      if (request.method==='GET' && p==='/v1/me') return await me(request,env);
      if (request.method==='GET' && p==='/v1/dashboard/config') return await dashboardConfig(request,env);
      if (request.method==='GET' && p==='/v1/admin/permissions') return await adminPermissions(request,env);
      if (request.method==='PUT' && p==='/v1/admin/dashboard/config') return await adminDashboardPut(request,env);
      if (request.method==='POST' && p==='/v1/admin/actions') return await adminAction(request,env);
      return json({error:'NOT_FOUND'},404,cors);
    } catch (e) {
      return json({error:'SERVER_ERROR',message:String(e?.message||e)},500,cors);
    }
  }
};
