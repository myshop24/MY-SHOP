# MY SHOP V-132 — BANNER + SERVER FIX

- Android versionCode: 132
- Android versionName: 2.9.132
- Banner manager: 6 Hero + 3 Promo slots.
- Banner CHANGE IMAGE opens the phone image picker, with Android 13+ photo picker and fallback.
- EDIT opens a real caption editor; SAVE persists the caption; DELETE removes the banner and R2 object.
- Worker content schema is additive-only and self-heals dashboard_config, banners, social_links and other admin tables.
- D1 binding remains `my-shop-db`; R2 binding remains `my-shop-media`.
- No user/auth tables are dropped, cleared, or reset.
- GitHub Actions final artifact contains exactly one APK.
