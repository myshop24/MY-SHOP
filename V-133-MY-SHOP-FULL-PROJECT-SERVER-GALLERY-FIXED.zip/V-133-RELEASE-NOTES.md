# MY SHOP V-133 — SERVER ERROR + PHONE GALLERY FIX

## Fixes
- Keeps all V-132 Admin Hub/UI/security fixes.
- Banner Manager now opens the normal Android document/gallery chooser first when a banner slot or CHANGE IMAGE is tapped.
- Gallery Manager now uses the same reliable phone chooser flow for Photo/Audio/Video.
- Banner cards retain explicit CHANGE IMAGE, EDIT, SAVE and DELETE controls after the server data loads.
- Public `/v1/dashboard/config` remains self-healing and cannot fail just because unrelated auth/content tables are missing.
- Adds a dedicated GitHub Actions Worker deployment workflow that deploys the Worker from the newest V source ZIP and then checks `/health` and `/v1/dashboard/config`.
- No auth/user table is reset, deleted, or recreated destructively.

## Important
The screenshots showed `SERVER_ERROR` / `NOT_FOUND` while the APK was trying to load Admin content. The V-132 Worker source already contains the public config hardening; the remaining production problem was that the GitHub build workflow did not actually deploy that Worker. V-133 includes a dedicated server deployment workflow so the APK and Worker are released together.
