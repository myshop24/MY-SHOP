# MY SHOP Developer Handoff — V-361

**V#:** V-361 (`versionCode 361`, `versionName 2.9.361`)

**Phase:** Targeted V-355 crash correction using V-354 as the known-good baseline.

**Root-cause finding:** The V-354→V-355 diff introduced the Live Home six-banner carousel. V-355 loaded every remote banner with `BitmapFactory.decodeStream(new URL(...).openStream())` at full source resolution and started a separate unbounded thread per image. The backend accepts banner uploads up to 15 MB. Android bitmap memory is based on decoded pixel dimensions, not compressed file size, so several large banner decodes can exhaust the app heap. `OutOfMemoryError` is not caught by `catch(Exception)`, allowing the process to terminate.

**Fix completed:** Kept the V-355 Live Home design/features and replaced only its remote image path with a bounded 3-thread executor, connection/read timeouts, bounds-first sampled decode, `RGB_565`, separate banner/avatar decode limits, lifecycle guards, target-tag guard, and explicit `OutOfMemoryError` containment. The executor is shut down in `onDestroy`. No YML/workflow change.

**Regression lock:** V-354 protected modules remain unchanged except required V-355 feature files and V-361 identity. Agora voice, Gift Sound, Gift animation, Coin/Gold accounting/ledger, live comments/session behavior, login/profile/feed/dashboard navigation and existing backend contracts are not redesigned by this correction.

**Build selection:** Existing GitHub workflow selects the highest `V-*.zip`; V-361 is intentionally numbered above the existing V-360 test package so this corrected source is selected without editing the YML.

**Verification performed:** file-by-file V-354↔V-355 diff; isolated the V-355 Live Home image-loading regression; source patch review; version/build identity checks; ZIP integrity check. Real-device runtime remains the final acceptance gate because this environment does not contain the project Android CI signing/toolchain.

**Next checkpoint:** Build V-361 with the unchanged GitHub workflow and test: app open → Dashboard idle → Live Streaming Home idle for at least several carousel rotations → scroll Top Live → background/foreground → return Home.
