# MY SHOP V-365 — Google Play Compliance QA

- PASS (static): no new Android permissions added.
- PASS (scope): no billing, digital currency, payout, account deletion, privacy, UGC/moderation, ads policy, or authentication contract changes.
- PASS (identity): Android versionCode/versionName advanced to 365 / 2.9.365.
- PASS (data safety scope): no new data collection/storage behavior introduced by this patch.
- NEEDS BUILD/DEVICE QA: signed APK/AAB and real-device runtime must still be produced/tested by the existing GitHub Android build environment.
- NEEDS FINAL PLAY AUDIT: mandatory before Play submission, as with every MY SHOP release.
