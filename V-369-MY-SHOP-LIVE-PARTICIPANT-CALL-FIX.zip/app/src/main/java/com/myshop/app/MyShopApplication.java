package com.myshop.app;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

/**
 * V-274 real MY SHOP in-app presence.
 * A user is considered online only while the app process has a visible Activity.
 * Foreground heartbeat prevents stale "online" dots; background transition clears it immediately when possible.
 */
public class MyShopApplication extends Application implements Application.ActivityLifecycleCallbacks {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private int startedActivities=0;
    private boolean foreground=false;
    private boolean presenceInFlight=false;
    private boolean queuedPresence=false;
    private boolean queuedActive=false;
    private final Runnable heartbeat=new Runnable(){
        @Override public void run(){
            if(!foreground)return;
            publish(true);
            // Keep server-side online TTL fresh without hammering the Worker every 30 seconds.
            // 60s remains inside the 90s presence window and removes the exact 30s regression trigger.
            handler.postDelayed(this,60000L);
        }
    };

    @Override public void onCreate(){
        super.onCreate();
        registerActivityLifecycleCallbacks(this);
        try{
            android.app.NotificationManager nm=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(nm!=null)MyShopMessagingService.ensureChannels(nm);
            if(PushRegistration.firebaseConfigured()&&com.google.firebase.FirebaseApp.getApps(this).isEmpty()){
                com.google.firebase.FirebaseOptions o=new com.google.firebase.FirebaseOptions.Builder().setApiKey(BuildConfig.FIREBASE_API_KEY).setApplicationId(BuildConfig.FIREBASE_APP_ID).setProjectId(BuildConfig.FIREBASE_PROJECT_ID).setGcmSenderId(BuildConfig.FIREBASE_SENDER_ID).build();com.google.firebase.FirebaseApp.initializeApp(this,o);
            }
            PushRegistration.sync(this);
        }catch(Exception ignored){}
    }

    private void publish(boolean active){
        String token=SessionManager.getToken(this);
        if(token==null||token.trim().isEmpty())return;
        // Never stack presence requests during Activity transitions or a slow network.
        // Queue only the newest state; this avoids request bursts and lifecycle races.
        if(presenceInFlight){queuedPresence=true;queuedActive=active;return;}
        presenceInFlight=true;
        BackendClient.setAppPresence(token,active,new BackendClient.Callback(){
            private void done(){
                presenceInFlight=false;
                if(queuedPresence){boolean next=queuedActive;queuedPresence=false;publish(next);}
            }
            public void onSuccess(org.json.JSONObject data){done();}
            public void onError(String message){done();}
        });
    }

    @Override public void onActivityStarted(Activity activity){
        startedActivities++;
        if(startedActivities==1){
            foreground=true;
            handler.removeCallbacks(heartbeat);
            publish(true);
            handler.postDelayed(heartbeat,60000L);
        }
    }

    @Override public void onActivityStopped(Activity activity){
        startedActivities=Math.max(0,startedActivities-1);
        if(startedActivities==0 && !activity.isChangingConfigurations()){
            foreground=false;
            handler.removeCallbacks(heartbeat);
            publish(false);
        }
    }

    @Override public void onActivityCreated(Activity activity, Bundle state){}
    @Override public void onActivityResumed(Activity activity){}
    @Override public void onActivityPaused(Activity activity){}
    @Override public void onActivitySaveInstanceState(Activity activity, Bundle outState){}
    @Override public void onActivityDestroyed(Activity activity){}
}
