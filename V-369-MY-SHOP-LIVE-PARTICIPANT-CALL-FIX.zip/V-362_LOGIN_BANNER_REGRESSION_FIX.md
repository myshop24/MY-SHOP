# MY SHOP V-362 — Login + Banner Regression Fix

## Fixed
1. Login/session endpoints are isolated from unrelated Live/Gift/content schema bootstrap. A schema problem in another module can no longer block `/v1/auth/login` or `/v1/me` before auth is checked.
2. Dashboard promo banner carousel now actually starts. The existing `startPromoCarousel()` implementation was present but never invoked from `MainActivity.onCreate()`.
3. Existing hero banner carousel, Live Home carousel, Live/Gift/Profile/Admin behavior are preserved.
4. Worker health/build identity updated to V-362 / 2.9.362.

## Regression scope
Changed functional files only:
- `app/src/main/java/com/myshop/app/MainActivity.java`
- `backend/worker/src/index.js`
- `app/src/main/java/com/myshop/app/LiveHomeActivity.java` (versioned User-Agent only)
- version metadata / handoff notes

No database tables are dropped, renamed, deleted, or reassigned. Existing user IDs and balances are untouched.
