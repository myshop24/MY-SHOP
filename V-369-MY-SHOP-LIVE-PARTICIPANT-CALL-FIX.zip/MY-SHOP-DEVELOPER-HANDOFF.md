# MY SHOP DEVELOPER HANDOFF

Version: V-369
Version name: 2.9.369
Phase: Live participant state / role invite / premium request-card stabilization
Base: V-368

## Completed
- Seat mute no longer removes/hides participant identity.
- Temporary MUTE/KICK state reset across Live sessions; BLOCK remains persistent.
- Unmute restores seat mic state; self mic-on clears legacy temporary mute state.
- Call Suggest supports Host, Room Admin, MY SHOP Admin, Moderator for the active Host Live.
- Audience avatar/profile action card now shows Coin + Gold Coin and Live actions.
- Voluntary Leave Seat / Leave Call preserved and clearly exposed.
- Join Request Accept/Reject card premium-polished.
- Version identity moved to V-369 / 2.9.369.

## Pending runtime QA
- Two-device Host <-> Guest mute/unmute.
- Guest Leave Call then re-request/re-invite.
- Room Admin/Admin/Moderator Call Suggest on real account roles.
- Fresh Live after previous mute/kick must show user normally.
- Permanent Block must still prevent rejoin.
- Coin/Gold balances on top-user action card.
- Join Request card visual acceptance on target device.

## Locked / do not regress
- Gift/Coin/Gold ledgers and pricing.
- Agora RTC architecture.
- Ephemeral Live comments.
- End Live first-tap behavior.
- Existing banner carousel fixes and Go Live / Join Live premium design from V-368.
