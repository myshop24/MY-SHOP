# MY SHOP V-366 — Google Play Compliance QA

- PASS (static): no new Android permissions added.
- PASS (scope): no billing, Coin/Gold Coin economy, payout, account deletion, privacy-policy, UGC/moderation, authentication, or ad-policy contract changes.
- PASS (microphone): existing RECORD_AUDIO permission remains limited to Audio Live speaking; audience listen mode does not require microphone permission.
- PASS (identity): Android versionCode/versionName advanced to 366 / 2.9.366.
- PASS (data safety): banner cache is local UI cache of public banner configuration; no new personal-data collection/storage behavior was introduced.
- NEEDS BUILD/DEVICE QA: signed APK/AAB and real-device runtime still must be produced/tested by the existing Android build environment.
- NEEDS FINAL PLAY AUDIT: mandatory before Play submission.
