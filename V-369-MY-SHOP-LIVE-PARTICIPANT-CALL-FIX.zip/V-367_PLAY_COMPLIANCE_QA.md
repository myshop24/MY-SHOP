# MY SHOP V-367 — Google Play Compliance QA

- [PASS] No new sensitive Android permission added.
- [PASS] Microphone use remains limited to Audio Live speaking flow.
- [PASS] No billing / Coin / Gold Coin purchase logic changed.
- [PASS] Purchased-vs-earned balance rules untouched.
- [PASS] No account deletion, privacy, Data Safety, auth, or user-ID behavior changed.
- [PASS] No D1 schema migration or destructive user SQL added.
- [PASS] Live moderation actions remain server-authorized.
- [NEEDS DEVICE QA] Verify microphone permission prompt and two-device live audio behavior in built APK.
- [NEEDS RELEASE QA] Run final Play Console/Data Safety/target SDK/signing checks before production upload.
