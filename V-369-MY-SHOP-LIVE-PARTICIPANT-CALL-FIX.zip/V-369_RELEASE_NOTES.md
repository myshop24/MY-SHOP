# MY SHOP V-369 Release Notes

## Targeted fixes
1. Muting a seated guest no longer hides/removes that user, their ID, viewer identity, or call eligibility.
2. Temporary MUTE/KICK state is cleared when a Live ends and when a fresh Live begins; permanent BLOCK remains persistent.
3. Unmute restores the guest seat microphone state; a seated guest may also turn their own microphone back on through participant-state sync.
4. Host, Room Admin, MY SHOP Admin, and Moderator can send Call Suggest / Invite to an active audience user from that host's Live, subject to role permissions and permanent block/kick safety.
5. Top audience avatar tap opens a Live user action/profile card instead of bypassing Live actions; Coin and Gold Coin balances are shown there.
6. Guest/Speaker retains voluntary Leave Seat / Leave Call and returns to Audience without ending the room.
7. Join Request card upgraded to a premium avatar + ID + Level + prominent Accept/Reject presentation.
8. Viewer serial remains contiguous over the visible active list; muted guests are not removed from the list, preventing mute-triggered serial collapse.

## Regression lock
- Gift/Coin/Gold transaction logic unchanged.
- Live comment persistence rule unchanged (ephemeral only).
- Agora remains RTC transport.
- Existing End Live, Join Request, Invite acceptance, Gift catalog, profile, and dashboard modules preserved except for the scoped fixes above.
- Permanent Live Block continues across sessions; only temporary MUTE/KICK are cleared.

## Runtime acceptance required
Real-device verification is still required for multi-role call suggestion, mute/unmute, seat leave/rejoin, and two-device RTC behavior.
