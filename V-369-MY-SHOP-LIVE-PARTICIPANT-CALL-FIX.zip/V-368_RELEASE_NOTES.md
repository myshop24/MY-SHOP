# MY SHOP V-368 Release Notes

Base: V-367-MY-SHOP-LIVE-GUEST-CONTROL-FIX

## Completed
- Occupied guest-seat tap no longer bypasses seat actions via the avatar.
- Any eligible viewer can send a gift directly to a seated user.
- Host/authorized moderation exposes role-appropriate Mute/Unmute, Kick, Block, Room Admin and seat controls.
- Speaker tapping their own occupied seat opens My Call Controls, including Leave Call.
- Leave Call keeps the user in the Live as Audience and disables local publish/mic.
- Agora active-speaker changes immediately refresh seat/host speaking UI. Speaking users get a glow ring and visible microphone badge.
- Host header is compacted so the User Line begins directly after the host/level block instead of starting from the middle.
- Live Home banner source accepts legacy R2 banner_media object keys when image_url is missing and avoids collapsing a known multi-banner cache to 1/1 on partial responses.
- Existing single-owner carousel timer remains 0.9s first advance then 4.5s continuous wrap-around.
- Go Live and Join Live redesigned 50/50: Go Live orange/pink, Join Live blue/purple, equal size and emphasis.

## Regression lock
- Existing Coin/Gold Coin gift accounting, Agora RTC transport, comments, Join Request/Host Invite, End Live, profile/social, admin modules and unrelated dashboard modules were not redesigned.
- Existing pin-comment/status-area fix remains unchanged.

## Runtime acceptance still required
- Android/GitHub build and two-device Live test are required before claiming device-level PASS.
