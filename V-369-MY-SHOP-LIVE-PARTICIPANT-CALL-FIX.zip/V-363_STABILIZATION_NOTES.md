# MY SHOP Developer Handoff — V-363

## Release type
Emergency stabilization / regression repair.

## Completed
- 30-second stability path hardened: app-presence heartbeat moved from 30s to 60s, requests serialized, duplicate resume publish removed, and Worker presence route isolated from the full Live/Gift/content schema bootstrap.
- Dashboard remote images now use bounded sampled RGB_565 decoding with OutOfMemory containment instead of full-resolution decoding.
- Live Home six-slot banners now use a dedicated lightweight API and auto-rotate every 4.5 seconds whenever 2+ active banners are configured.
- Main Dashboard promo carousel startup fix from V-362 is preserved.
- Login/auth isolation from V-362 is preserved.
- Create Account Gender selector restored (Male / Female / Prefer not to say) and registration stores the selected gender in D1.
- No new media assets were added; this stabilization should not materially increase package weight.

## Locked / preserved
Live Room seat layout, gifts, comments, RTC/Agora, Coin/Gold Coin, Profile/Social, Store/Wallet, Notifications, Admin modules and existing user IDs were not redesigned or deleted.

## Validation gate
Static source validation, XML parse, Worker JavaScript syntax, changed-file audit, auth/gender route checks, banner route/timer checks and destructive-SQL scan must pass before ZIP delivery. APK/device runtime still requires the normal GitHub Android build/install test; source validation alone is not represented as a real-device PASS.

## Next device test
Keep app open 5+ minutes, login, create a test account with Gender, verify Dashboard banners, verify 2–6 Live Home banners rotate, enter/exit Live, test comments/gifts/profile, and confirm no crash/forced close.
