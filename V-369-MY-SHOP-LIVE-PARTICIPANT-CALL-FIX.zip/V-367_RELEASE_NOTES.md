# MY SHOP V-367 — Live Guest Control & Speaking UI

## Scope completed
- Removed the separate LIVE AUDIO status strip below pinned comments to restore comment space.
- Speaking state remains visible on the speaker/host avatar ring and mic badge.
- Host Join Request card upgraded with avatar, name, ID, level, Accept and Reject controls.
- Host can invite audience users using the existing real-time invite flow.
- Occupied guest seat menu now includes Profile, Gift, Main Guest select/remove, normal seat move, Mute, Unmute, Kick, Room Admin grant/revoke, and remove-from-seat.
- Normal speakers can move only among free normal guest seats (2–9); Main Guest remains host-controlled only.
- Fixed moderation semantics: Mute keeps the guest seated and disables speaking; Kick/Remove are separate actions.
- Host can open an in-live summary from the stats/duration area showing duration, current users, peak viewers, total listeners, reactions, gifts, Coin and Gold.
- Top audience/user line begins immediately after a narrower Host + Level block.

## Locked / preserved
- Existing 12-seat/approved guest-seat visual structure and RTC/Agora architecture.
- Gift/Coin/Gold Coin transaction logic and catalogs.
- Live comments/highlight/pinned comment behavior.
- Profile, Feed, Store, Wallet, Login, Admin, D1 schema and core IDs.

## Validation limits
- Worker JavaScript syntax checked locally.
- Android source/static structure checked locally.
- Full Android Gradle build and real-device multi-user RTC acceptance still require the normal GitHub/device build path.
