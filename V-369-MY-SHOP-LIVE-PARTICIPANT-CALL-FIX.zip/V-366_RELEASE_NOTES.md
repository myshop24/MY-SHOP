# MY SHOP V-366 — Immediate Banner Rotation + Live Audio Verification

## Scope
Targeted regression-safe follow-up from V-365. No unrelated feature redesign.

## Fixed / improved
- Live Home banner carousel now restores the last known active 2–6 banner set from local cache before network refresh when available.
- Live Home first auto-advance starts quickly (~0.9s after the screen is active) instead of waiting a full carousel interval after data becomes available.
- Live Home banner rotation now has one recurring scheduler owner: one tick advances once and posts exactly one next tick, so network refresh, resume, and manual swipe cannot multiply or lose the timer.
- Live Home network refresh updates the cache and restarts the single timer without freezing an already working carousel.
- Main Dashboard hero carousel also gets a quick first advance after resume/remote configuration, then returns to the normal 3.5s steady interval.
- Live Audio now exposes a compact visible status strip in the existing Live Room UI so RTC transport can be verified on-device without Logcat:
  - `🎤 Mic connected` / `🎤 Mic sending` for host or seated speaker.
  - `🔊 Listening` for audience connected to RTC.
  - `🔊 Voice receiving` when real remote voice energy is detected.
  - `Audio connecting` while RTC is not yet joined.
- Existing Agora room/token/publish/subscribe contracts are preserved; this release adds visibility/verification rather than replacing the RTC architecture.

## Preserved / locked
Login/auth, Create Account/Gender, Gift/Coin/Gold Coin, Profile/Social/Feed, Store/Wallet, Admin modules, user IDs, D1 schema/data model, seat/role backend contracts, gift effects, comments, join request/invite logic, and other existing Live features.

## Version
- versionCode: 366
- versionName: 2.9.366
- SOURCE_BUILD_ID: MY SHOP V-366
