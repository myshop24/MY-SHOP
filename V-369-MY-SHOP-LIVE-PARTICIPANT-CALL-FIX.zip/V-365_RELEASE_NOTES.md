# MY SHOP V-365 — Runtime Stability + Scroll Recovery

## Scope
Targeted recovery only. No feature redesign.

## Fixed
- Dashboard crash guard: stale async image/UI callbacks can no longer submit work after Activity shutdown/recreation.
- Dashboard image executor now safely ignores rejected post-destroy work instead of allowing a process-ending runtime exception.
- Dashboard hero banner, promo banner, and live-ad timers are now named/idempotent lifecycle tasks; they stop on pause and restart once on resume.
- Breaking News headline marquee is explicitly restored after remote text updates and when window focus/resume returns.
- Live Home banner timer duplication fixed: one auto-rotation tick now schedules exactly one next tick instead of multiplying callbacks.
- Live Home banner/image/network callbacks are lifecycle guarded after pause/destroy.
- Immediate Dashboard self-recreate after remote theme cache change was removed to avoid startup callback races; cached theme applies on the next normal Dashboard creation.

## Preserved / locked
Login/auth, Create Account/Gender, Audio Live Room/Agora, Gift/Coin/Gold Coin, Profile/Social/Feed, Store/Wallet, Admin modules, user IDs, D1 schema/data model, and existing backend feature contracts.

## Version
- versionCode: 365
- versionName: 2.9.365
- SOURCE_BUILD_ID: MY SHOP V-365
