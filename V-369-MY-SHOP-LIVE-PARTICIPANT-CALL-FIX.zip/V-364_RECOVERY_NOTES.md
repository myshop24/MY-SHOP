# MY SHOP V-364 — App Stability + Banner Recovery

Scope is intentionally limited to two regressions only:
1. App opens then closes / unstable startup.
2. Live Home banners do not auto-scroll one after another.

No feature redesign is included.
