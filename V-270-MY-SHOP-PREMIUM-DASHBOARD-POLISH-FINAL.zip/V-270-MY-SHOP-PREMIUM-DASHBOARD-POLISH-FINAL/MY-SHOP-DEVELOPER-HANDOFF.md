# MY SHOP DEVELOPER HANDOFF

Current source: **V-270** (`versionCode 270`, `versionName 2.9.270`).

## Checkpoint
V-270 is the corrected successor to V-269. It fixes the permanent GitHub Actions source identity gate by using the exact `SOURCE_BUILD_ID.txt = MY SHOP V-270`, and synchronizes Android and Worker identity to V-270.

## Preserved approved scope
- Premium Dashboard proportions and clean responsive alignment.
- Breaking News intentionally scrolls right-to-left; Admin font size and visual text/background color controls remain.
- LIVE STREAMING Go Live / Join Live design and locked top flow remain.
- Dynamic Live-first → newest-user fallback remains.
- Approved circular profile + NEW/LIVE badge + green dot + Name/Level/ID + full-width friend action card style remains.
- MY Feed, Quick Links, banners, notifications/messages and existing backend/social functionality remain protected.

## Next build
Upload this V-270 ZIP to the repository and run the permanent GitHub Actions workflow. Do not modify the master workflow or signing secrets for this identity correction.
