PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  user_id TEXT PRIMARY KEY CHECK(length(user_id)=4),
  full_name TEXT NOT NULL,
  email TEXT UNIQUE,
  mobile TEXT UNIQUE,
  password_hash TEXT NOT NULL,
  security_q1 TEXT NOT NULL,
  security_a1_hash TEXT NOT NULL,
  security_q2 TEXT NOT NULL,
  security_a2_hash TEXT NOT NULL,
  security_q3 TEXT NOT NULL,
  security_a3_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'USER' CHECK(role IN ('USER','ADMIN','MODERATOR')),
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email) WHERE email IS NOT NULL AND email <> '';
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_mobile ON users(mobile) WHERE mobile IS NOT NULL AND mobile <> '';
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);

CREATE TABLE IF NOT EXISTS moderators (
  user_id TEXT PRIMARY KEY REFERENCES users(user_id) ON DELETE CASCADE,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS dashboard_config (
  id INTEGER PRIMARY KEY CHECK(id=1),
  breaking_news TEXT NOT NULL DEFAULT '',
  my_shop_url TEXT NOT NULL DEFAULT '',
  live_tv_url TEXT NOT NULL DEFAULT '',
  external_movie_url TEXT NOT NULL DEFAULT '',
  chat_url TEXT NOT NULL DEFAULT '',
  breaking_news_text_size REAL NOT NULL DEFAULT 13.0,
  breaking_news_bg_color TEXT NOT NULL DEFAULT '#FFEFF7',
  breaking_news_text_color TEXT NOT NULL DEFAULT '#414662',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
INSERT OR IGNORE INTO dashboard_config(id) VALUES(1);

CREATE TABLE IF NOT EXISTS banners (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  folder TEXT NOT NULL,
  slot INTEGER NOT NULL CHECK(slot BETWEEN 1 AND 6),
  image_url TEXT NOT NULL,
  caption TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(folder, slot)
);

CREATE TABLE IF NOT EXISTS social_links (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  platform TEXT NOT NULL UNIQUE,
  url TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS payment_methods (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  method TEXT NOT NULL UNIQUE,
  value TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS admin_identifiers (
  identifier TEXT PRIMARY KEY,
  user_id TEXT UNIQUE NOT NULL,
  email_or_mobile TEXT NOT NULL UNIQUE
);
INSERT OR IGNORE INTO admin_identifiers(identifier,user_id,email_or_mobile) VALUES
 ('0001','0001','myshopsatkania@gmail.com'),
 ('0002','0002','touhidsatkania@gmail.com'),
 ('0003','0003','01860626700');
