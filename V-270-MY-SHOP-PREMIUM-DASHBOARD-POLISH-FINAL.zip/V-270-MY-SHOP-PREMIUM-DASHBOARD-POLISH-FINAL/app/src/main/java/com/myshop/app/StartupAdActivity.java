package com.myshop.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * V-258 runtime recovery launcher.
 *
 * Goals:
 * 1) Never let the startup animation/ad path end the task on an exception.
 * 2) Preserve Admin-controlled image/video startup ads and their existing duration.
 * 3) Keep a branded startup animation without a blank/white gap.
 * 4) If LoginActivity itself fails before drawing, keep this launcher alive and show
 *    a built-in recovery login instead of returning to the phone home screen.
 */
public class StartupAdActivity extends Activity {
    private static final String PREF = "startup_ad_cache_v247";
    private static final String GUARD_PREF = "startup_runtime_guard_v258";
    private static final String KEY_LOGIN_READY = "login_ui_ready";

    private final Handler main = new Handler(Looper.getMainLooper());
    private CountDownTimer timer;
    private boolean opened = false;
    private boolean timerStarted = false;
    private boolean cacheUsed = false;
    private boolean handoffStarted = false;
    private boolean recoveryVisible = false;

    private Button skip;
    private ImageView imageAd;
    private VideoView videoAd;
    private FrameLayout root;
    private FrameLayout mediaHost;
    private FrameLayout adLayer;
    private FrameLayout openingLayer;
    private Runnable noConfigWatchdog;
    private Runnable mediaWatchdog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSharedPreferences(GUARD_PREF, MODE_PRIVATE).edit().putBoolean(KEY_LOGIN_READY, false).apply();
        try {
            buildStartupUi();
            main.postDelayed(() -> {
                try {
                    beginAdFlow();
                } catch (Throwable fatal) {
                    safeOpenLogin();
                }
            }, 450L);
        } catch (Throwable startupFailure) {
            showRecoveryLogin();
        }
    }

    private void buildStartupUi() {
        root = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(4, 12, 34), Color.rgb(7, 24, 70), Color.rgb(19, 8, 44)});
        root.setBackground(bg);

        adLayer = new FrameLayout(this);
        adLayer.setVisibility(View.GONE);
        root.addView(adLayer, new FrameLayout.LayoutParams(-1, -1));

        mediaHost = new FrameLayout(this);
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER);
        adLayer.addView(mediaHost, mp);

        imageAd = new ImageView(this);
        imageAd.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageAd.setVisibility(View.GONE);
        mediaHost.addView(imageAd, new FrameLayout.LayoutParams(-1, -1));

        videoAd = new VideoView(this);
        videoAd.setVisibility(View.GONE);
        mediaHost.addView(videoAd, new FrameLayout.LayoutParams(-1, -1));

        TextView label = new TextView(this);
        label.setText("ADVERTISEMENT");
        label.setTextColor(Color.WHITE);
        label.setTextSize(10);
        label.setGravity(Gravity.CENTER);
        label.setBackgroundColor(0x88000000);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(122), dp(34), Gravity.TOP | Gravity.START);
        lp.setMargins(dp(12), dp(12), 0, 0);
        adLayer.addView(label, lp);

        skip = new Button(this);
        skip.setAllCaps(false);
        skip.setText("Skip");
        skip.setTextColor(Color.WHITE);
        skip.setTextSize(11);
        skip.setBackground(round(0x99000000, 22));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(dp(105), dp(44), Gravity.TOP | Gravity.END);
        sp.setMargins(0, dp(10), dp(10), 0);
        adLayer.addView(skip, sp);
        skip.setOnClickListener(v -> safeOpenLogin());

        openingLayer = new FrameLayout(this);
        root.addView(openingLayer, new FrameLayout.LayoutParams(-1, -1));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.myshop_icon);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        FrameLayout.LayoutParams logop = new FrameLayout.LayoutParams(dp(166), dp(166), Gravity.CENTER);
        logop.bottomMargin = dp(74);
        openingLayer.addView(logo, logop);

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.HORIZONTAL);
        brand.setGravity(Gravity.CENTER);
        TextView myBrand = new TextView(this);
        myBrand.setText("MY");
        myBrand.setTextColor(Color.rgb(36, 118, 255));
        myBrand.setTextSize(30);
        myBrand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView shopBrand = new TextView(this);
        shopBrand.setText(" SHOP");
        shopBrand.setTextColor(Color.rgb(255, 139, 0));
        shopBrand.setTextSize(30);
        shopBrand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.addView(myBrand);
        brand.addView(shopBrand);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, dp(50), Gravity.CENTER);
        bp.topMargin = dp(112);
        openingLayer.addView(brand, bp);

        TextView tag = new TextView(this);
        tag.setText("Shop • Social • Live • Earn\n●   ●   ●");
        tag.setTextColor(Color.rgb(214, 224, 255));
        tag.setTextSize(12);
        tag.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1, dp(70), Gravity.CENTER);
        tp.topMargin = dp(166);
        openingLayer.addView(tag, tp);

        // Premium local-only opening animation. Remote ad loading starts behind this layer,
        // so the user never sees a blank/white bridge while media is prepared.
        logo.setScaleX(.82f);
        logo.setScaleY(.82f);
        logo.setAlpha(.18f);
        logo.animate().scaleX(1.10f).scaleY(1.10f).alpha(1f).setDuration(760)
                .withEndAction(() -> {
                    try {
                        logo.animate().scaleX(1f).scaleY(1f).alpha(.98f).setDuration(420).start();
                    } catch (Throwable ignored) { }
                }).start();
        brand.setAlpha(0f);
        brand.setTranslationY(dp(16));
        brand.animate().alpha(1f).translationY(0f).setStartDelay(220).setDuration(650).start();
        tag.setAlpha(0f);
        tag.setTranslationY(dp(8));
        tag.animate().alpha(1f).translationY(0f).setStartDelay(500).setDuration(620).start();

        setContentView(root);
    }

    private void beginAdFlow() {
        if (opened || recoveryVisible) return;
        try {
            // Keep the branded opening layer visible while image/video is loading.
            // The ad layer is revealed only from mediaReady(), after drawable/video preparation succeeds.
            if (adLayer != null) {
                adLayer.setAlpha(0f);
                adLayer.setVisibility(View.VISIBLE);
            }

            cacheUsed = showCachedAdIfAvailable();
            noConfigWatchdog = () -> {
                try {
                    if (!timerStarted && !opened) safeOpenLogin();
                } catch (Throwable ignored) {
                    showRecoveryLogin();
                }
            };
            if (!cacheUsed) main.postDelayed(noConfigWatchdog, 1800L);

            try {
                loadRemoteAd();
            } catch (Throwable remoteStartFailure) {
                if (!cacheUsed) safeOpenLogin();
            }
        } catch (Throwable fatal) {
            safeOpenLogin();
        }
    }

    private boolean showCachedAdIfAvailable() {
        try {
            SharedPreferences p = getSharedPreferences(PREF, MODE_PRIVATE);
            if (!p.getBoolean("active", false)) return false;
            String media = p.getString("media", "");
            String type = p.getString("type", "image");
            String target = p.getString("target", "");
            int duration = Math.max(1, Math.min(4, p.getInt("duration", 3)));
            if (media == null || media.trim().isEmpty()) return false;
            renderMedia(media, type, target, duration);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private void saveCache(JSONObject found) {
        try {
            if (found == null) {
                getSharedPreferences(PREF, MODE_PRIVATE).edit().clear().apply();
                return;
            }
            getSharedPreferences(PREF, MODE_PRIVATE).edit()
                    .putBoolean("active", found.optInt("active", 1) == 1)
                    .putString("media", found.optString("image_url", "").trim())
                    .putString("type", found.optString("media_type", "image").trim().toLowerCase())
                    .putString("target", found.optString("target_url", "").trim())
                    .putInt("duration", Math.max(1, Math.min(4, found.optInt("duration_sec", 3))))
                    .putString("updated", found.optString("updated_at", "").trim())
                    .apply();
        } catch (Throwable ignored) { }
    }

    private void loadRemoteAd() {
        if (!BackendClient.configured()) {
            if (!cacheUsed) safeOpenLogin();
            return;
        }
        BackendClient.dashboard(null, new BackendClient.Callback() {
            public void onSuccess(JSONObject d) {
                runOnUiThread(() -> {
                    try {
                        JSONArray ads = d == null ? null : d.optJSONArray("dashboardAds");
                        JSONObject found = null;
                        if (ads != null) {
                            for (int i = 0; i < ads.length(); i++) {
                                JSONObject x = ads.optJSONObject(i);
                                if (x != null && "startup_ad".equalsIgnoreCase(x.optString("box_key", ""))
                                        && x.optInt("active", 1) == 1) {
                                    found = x;
                                    break;
                                }
                            }
                        }
                        saveCache(found);
                        if (opened || recoveryVisible) return;
                        if (found == null) {
                            if (!cacheUsed) safeOpenLogin();
                            return;
                        }
                        if (!cacheUsed) {
                            if (noConfigWatchdog != null) main.removeCallbacks(noConfigWatchdog);
                            int sec = Math.max(1, Math.min(4, found.optInt("duration_sec", 3)));
                            String media = found.optString("image_url", "").trim();
                            String updated = found.optString("updated_at", "").trim();
                            if (!media.isEmpty() && !updated.isEmpty() && !media.contains("?")) {
                                media = media + "?v=" + Uri.encode(updated);
                            }
                            String type = found.optString("media_type", "").trim().toLowerCase();
                            if (type.isEmpty()) type = isVideoUrl(media) ? "video" : "image";
                            String target = found.optString("target_url", "").trim();
                            if (media.isEmpty()) {
                                safeOpenLogin();
                                return;
                            }
                            renderMedia(media, type, target, sec);
                        }
                    } catch (Throwable ignored) {
                        if (!cacheUsed) safeOpenLogin();
                    }
                });
            }

            public void onError(String m) {
                runOnUiThread(() -> {
                    try {
                        if (!cacheUsed) safeOpenLogin();
                    } catch (Throwable ignored) {
                        showRecoveryLogin();
                    }
                });
            }
        });
    }

    private void renderMedia(String media, String type, String target, int duration) {
        try {
            if (mediaHost == null) {
                safeOpenLogin();
                return;
            }
            mediaHost.setOnClickListener(null);
            if (target != null && !target.trim().isEmpty()) {
                mediaHost.setOnClickListener(v -> {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(target)));
                    } catch (Throwable ignored) { }
                });
            }
            timerStarted = false;
            if (mediaWatchdog != null) main.removeCallbacks(mediaWatchdog);
            mediaWatchdog = () -> {
                try {
                    if (!opened && !timerStarted) safeOpenLogin();
                } catch (Throwable ignored) {
                    showRecoveryLogin();
                }
            };
            main.postDelayed(mediaWatchdog, 5500L);

            if ("video".equalsIgnoreCase(type) || isVideoUrl(media)) showVideo(media, duration);
            else loadImage(media, duration);
        } catch (Throwable t) {
            safeOpenLogin();
        }
    }

    private void mediaReady(int duration) {
        try {
            if (opened || timerStarted || recoveryVisible) return;
            if (mediaWatchdog != null) main.removeCallbacks(mediaWatchdog);
            // Cross-fade only after media is actually ready. This removes the white/blank gap.
            if (adLayer != null) {
                adLayer.setVisibility(View.VISIBLE);
                adLayer.animate().cancel();
                adLayer.setAlpha(0f);
                adLayer.animate().alpha(1f).setDuration(240).start();
            }
            if (openingLayer != null && openingLayer.getVisibility() == View.VISIBLE) {
                openingLayer.animate().cancel();
                openingLayer.animate().alpha(0f).setDuration(260).withEndAction(() -> {
                    try { if (openingLayer != null) openingLayer.setVisibility(View.GONE); } catch (Throwable ignored) { }
                }).start();
                main.postDelayed(() -> startTimer(duration), 180L);
            } else {
                startTimer(duration);
            }
        } catch (Throwable ignored) {
            safeOpenLogin();
        }
    }

    private boolean isVideoUrl(String u) {
        String x = u == null ? "" : u.toLowerCase();
        return x.contains(".mp4") || x.contains(".webm") || x.contains(".m3u8") || x.contains("video");
    }

    private void showVideo(String u, int duration) {
        try {
            if (imageAd != null) imageAd.setVisibility(View.GONE);
            if (videoAd == null) {
                safeOpenLogin();
                return;
            }
            videoAd.setVisibility(View.VISIBLE);
            videoAd.setVideoURI(Uri.parse(u));
            videoAd.setOnPreparedListener(mp -> {
                try {
                    if (opened || recoveryVisible) return;
                    mp.setLooping(true);
                    videoAd.start();
                    mediaReady(duration);
                } catch (Throwable t) {
                    safeOpenLogin();
                }
            });
            videoAd.setOnErrorListener((mp, what, extra) -> {
                try {
                    videoAd.setVisibility(View.GONE);
                    if (!opened && !timerStarted) safeOpenLogin();
                } catch (Throwable ignored) {
                    showRecoveryLogin();
                }
                return true;
            });
        } catch (Throwable e) {
            if (!opened && !timerStarted) safeOpenLogin();
        }
    }

    private void loadImage(String u, int duration) {
        try {
            if (imageAd == null || videoAd == null) {
                safeOpenLogin();
                return;
            }
            imageAd.setVisibility(View.VISIBLE);
            videoAd.setVisibility(View.GONE);
            new Thread(() -> {
                HttpURLConnection c = null;
                boolean ok = false;
                try {
                    c = (HttpURLConnection) new URL(u).openConnection();
                    c.setConnectTimeout(3500);
                    c.setReadTimeout(5500);
                    c.setUseCaches(true);
                    try (InputStream in = c.getInputStream()) {
                        final android.graphics.Bitmap b = android.graphics.BitmapFactory.decodeStream(in);
                        if (b != null) {
                            ok = true;
                            runOnUiThread(() -> {
                                try {
                                    if (opened || recoveryVisible || imageAd == null) return;
                                    imageAd.setImageBitmap(b);
                                    imageAd.setAlpha(0f);
                                    imageAd.animate().alpha(1f).setDuration(150).start();
                                    mediaReady(duration);
                                } catch (Throwable t) {
                                    safeOpenLogin();
                                }
                            });
                        }
                    }
                } catch (Throwable ignored) {
                } finally {
                    if (c != null) c.disconnect();
                    if (!ok) {
                        runOnUiThread(() -> {
                            if (!opened && !timerStarted) safeOpenLogin();
                        });
                    }
                }
            }, "myshop-startup-image").start();
        } catch (Throwable t) {
            safeOpenLogin();
        }
    }

    private void startTimer(int sec) {
        try {
            int seconds = Math.max(1, Math.min(6, sec));
            timerStarted = true;
            if (noConfigWatchdog != null) main.removeCallbacks(noConfigWatchdog);
            if (mediaWatchdog != null) main.removeCallbacks(mediaWatchdog);
            if (timer != null) timer.cancel();
            timer = new CountDownTimer(seconds * 1000L, 250) {
                public void onTick(long ms) {
                    try {
                        int left = (int) Math.ceil(ms / 1000.0);
                        if (skip != null) skip.setText("Skip  " + Math.max(1, left));
                    } catch (Throwable ignored) { }
                }

                public void onFinish() {
                    safeOpenLogin();
                }
            }.start();
        } catch (Throwable t) {
            safeOpenLogin();
        }
    }

    /**
     * Do NOT finish this launcher immediately. If LoginActivity crashes before it draws,
     * Android will resume this Activity and onResume() will present the built-in recovery UI.
     */
    private void safeOpenLogin() {
        if (opened || recoveryVisible) return;
        opened = true;
        handoffStarted = true;
        cancelStartupWork();
        getSharedPreferences(GUARD_PREF, MODE_PRIVATE).edit().putBoolean(KEY_LOGIN_READY, false).apply();
        try {
            if (videoAd != null) videoAd.stopPlayback();
        } catch (Throwable ignored) { }
        try {
            Intent i = new Intent(this, LoginActivity.class);
            startActivity(i);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            // Intentionally keep this Activity in the back stack as a crash recovery guard.
        } catch (Throwable launchFailure) {
            opened = false;
            handoffStarted = false;
            showRecoveryLogin();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // If LoginActivity was launched and then the launcher becomes visible again,
        // distinguish normal Back from a LoginActivity startup crash.
        if (handoffStarted && !recoveryVisible) {
            main.postDelayed(() -> {
                try {
                    if (!handoffStarted || recoveryVisible || isFinishing()) return;
                    boolean loginWasReady = getSharedPreferences(GUARD_PREF, MODE_PRIVATE)
                            .getBoolean(KEY_LOGIN_READY, false);
                    if (loginWasReady) {
                        // User returned/backed out from a successfully drawn Login screen.
                        finish();
                    } else {
                        // LoginActivity did not reach its ready marker: keep the app open.
                        opened = false;
                        handoffStarted = false;
                        showRecoveryLogin();
                    }
                } catch (Throwable t) {
                    opened = false;
                    handoffStarted = false;
                    showRecoveryLogin();
                }
            }, 220L);
        }
    }

    private void showRecoveryLogin() {
        if (recoveryVisible || isFinishing()) return;
        recoveryVisible = true;
        opened = false;
        handoffStarted = false;
        cancelStartupWork();
        try {
            if (videoAd != null) videoAd.stopPlayback();
        } catch (Throwable ignored) { }

        try {
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER_HORIZONTAL);
            box.setPadding(dp(24), dp(42), dp(24), dp(24));
            GradientDrawable bg = new GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    new int[]{Color.rgb(4, 12, 34), Color.rgb(7, 24, 70), Color.rgb(19, 8, 44)});
            box.setBackground(bg);

            ImageView logo = new ImageView(this);
            logo.setImageResource(R.drawable.myshop_icon);
            logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            box.addView(logo, new LinearLayout.LayoutParams(dp(86), dp(86)));

            TextView title = new TextView(this);
            title.setText("MY SHOP");
            title.setTextColor(Color.rgb(28, 42, 100));
            title.setTextSize(28);
            title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            title.setGravity(Gravity.CENTER);
            box.addView(title, new LinearLayout.LayoutParams(-1, dp(58)));

            TextView note = new TextView(this);
            note.setText("Safe startup mode");
            note.setTextColor(Color.rgb(98, 84, 165));
            note.setTextSize(12);
            note.setGravity(Gravity.CENTER);
            box.addView(note, new LinearLayout.LayoutParams(-1, dp(34)));

            EditText id = new EditText(this);
            id.setHint("Email / Mobile / User ID");
            id.setSingleLine(true);
            box.addView(id, new LinearLayout.LayoutParams(-1, dp(58)));

            EditText pass = new EditText(this);
            pass.setHint("Password");
            pass.setSingleLine(true);
            pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(58));
            pp.topMargin = dp(10);
            box.addView(pass, pp);

            Button login = new Button(this);
            login.setText("LOGIN");
            login.setAllCaps(false);
            login.setTextColor(Color.WHITE);
            login.setTextSize(16);
            login.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            login.setBackground(round(Color.rgb(42, 67, 210), 14));
            LinearLayout.LayoutParams lpp = new LinearLayout.LayoutParams(-1, dp(58));
            lpp.topMargin = dp(16);
            box.addView(login, lpp);

            Button create = new Button(this);
            create.setText("＋  CREATE ACCOUNT");
            create.setAllCaps(false);
            create.setTextColor(Color.rgb(37, 91, 195));
            create.setTextSize(14);
            create.setBackgroundColor(Color.TRANSPARENT);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, dp(54));
            cp.topMargin = dp(8);
            box.addView(create, cp);

            login.setOnClickListener(v -> recoveryLogin(id, pass, login));
            create.setOnClickListener(v -> {
                try {
                    startActivity(new Intent(this, RegisterActivity.class));
                } catch (Throwable t) {
                    Toast.makeText(this, "Create Account could not open.", Toast.LENGTH_LONG).show();
                }
            });

            setContentView(box);
        } catch (Throwable impossible) {
            // Last-resort minimal view. This path intentionally uses no custom drawable/resource.
            TextView emergency = new TextView(this);
            emergency.setText("MY SHOP\nStartup recovery mode\nPlease reopen the app.");
            emergency.setTextColor(Color.BLACK);
            emergency.setTextSize(20);
            emergency.setGravity(Gravity.CENTER);
            emergency.setBackgroundColor(Color.WHITE);
            setContentView(emergency);
        }
    }

    private void recoveryLogin(EditText id, EditText pass, Button login) {
        String identifier = id.getText().toString().trim();
        String password = pass.getText().toString();
        if (identifier.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Login ID and Password are required.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!BackendClient.configured()) {
            Toast.makeText(this, "Backend URL is not configured.", Toast.LENGTH_LONG).show();
            return;
        }
        login.setEnabled(false);
        login.setText("Signing in…");
        try {
            BackendClient.login(identifier, password, new BackendClient.Callback() {
                public void onSuccess(JSONObject data) {
                    runOnUiThread(() -> {
                        try {
                            JSONObject u = data.getJSONObject("user");
                            Role role = Role.valueOf(u.optString("role", "USER"));
                            String uid = u.optString("userId", "");
                            SessionManager.setRemoteSession(StartupAdActivity.this,
                                    data.optString("token", ""), role, uid);
                            SessionManager.saveProfile(StartupAdActivity.this,
                                    u.optString("name", ""), u.optString("email", ""), u.optString("mobile", ""));
                            Intent i = new Intent(StartupAdActivity.this, MainActivity.class);
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(i);
                            finish();
                        } catch (Throwable e) {
                            login.setEnabled(true);
                            login.setText("LOGIN");
                            Toast.makeText(StartupAdActivity.this, "Login response invalid.", Toast.LENGTH_LONG).show();
                        }
                    });
                }

                public void onError(String message) {
                    runOnUiThread(() -> {
                        login.setEnabled(true);
                        login.setText("LOGIN");
                        Toast.makeText(StartupAdActivity.this, message, Toast.LENGTH_LONG).show();
                    });
                }
            });
        } catch (Throwable t) {
            login.setEnabled(true);
            login.setText("LOGIN");
            Toast.makeText(this, "Login failed safely. Please try again.", Toast.LENGTH_LONG).show();
        }
    }

    private void cancelStartupWork() {
        try {
            if (noConfigWatchdog != null) main.removeCallbacks(noConfigWatchdog);
            if (mediaWatchdog != null) main.removeCallbacks(mediaWatchdog);
            if (timer != null) timer.cancel();
        } catch (Throwable ignored) { }
    }

    @Override
    protected void onDestroy() {
        main.removeCallbacksAndMessages(null);
        cancelStartupWork();
        try {
            if (videoAd != null) videoAd.stopPlayback();
        } catch (Throwable ignored) { }
        super.onDestroy();
    }

    private GradientDrawable round(int fill, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(r));
        return g;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
