package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

/**
 * V-230 per-folder Admin entry panel.
 * Ordinary users can never open this Activity: it requires an ADMIN session and admin_context=true.
 * Every managed folder has separate ADD / EDIT / DELETE / SAVE entry controls and its own 6-slot ad manager.
 */
public class AdminFolderActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(248,249,253), NAVY=Color.rgb(18,32,75), BLUE=Color.rgb(46,47,190),
            PURPLE=Color.rgb(91,38,214), PINK=Color.rgb(235,36,168), GREEN=Color.rgb(24,169,98),
            RED=Color.rgb(238,35,52), MUTED=Color.rgb(105,111,130);
    private String featureKey="dashboard", displayTitle="DASHBOARD";

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        if(!SessionManager.isAdmin(this) || !getIntent().getBooleanExtra("admin_context",false)){ finish(); return; }
        String k=getIntent().getStringExtra("feature_key"); if(k!=null&&!k.trim().isEmpty())featureKey=safeKey(k);
        String t=getIntent().getStringExtra("title"); if(t!=null&&!t.trim().isEmpty())displayTitle=t.trim();
        build();
    }

    private void build(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setVerticalScrollBarEnabled(false);
        LinearLayout root=col(); root.setPadding(dp(12),dp(10),dp(12),dp(20)); root.setBackgroundColor(BG);

        LinearLayout head=row();
        TextView back=label("‹",NAVY,30,true); back.setGravity(Gravity.CENTER); back.setOnClickListener(v->finish()); head.addView(back,lp(dp(44),dp(46)));
        LinearLayout hb=col(); hb.setPadding(dp(4),0,0,0); hb.addView(label(displayTitle,NAVY,19,true),lp(-1,dp(25))); hb.addView(label("ADMIN PANEL  •  "+featureKey,MUTED,8.5f,true),lp(-1,dp(17))); head.addView(hb,wt(1,dp(46)));
        root.addView(head,lp(-1,dp(50)));

        LinearLayout banner=col(); banner.setPadding(dp(13),dp(10),dp(13),dp(10)); banner.setBackground(gradient(Color.rgb(41,57,197),Color.rgb(151,31,220),18)); banner.setElevation(dp(3));
        banner.addView(label("6 ADVERTISEMENT BANNERS",Color.WHITE,15,true),lp(-1,dp(25)));
        banner.addView(label("এই ফোল্ডারের জন্য সর্বোচ্চ ৬টি banner • একটার পর একটা auto-scroll",Color.rgb(244,239,255),8.8f,false),lp(-1,dp(22)));
        TextView manage=action("▦  OPEN 6-BANNER MANAGER",Color.rgb(255,42,149)); manage.setOnClickListener(v->openAds()); banner.addView(manage,top(lp(-1,dp(44)),7));
        root.addView(banner,top(lp(-1,-2),5));

        TextView h=label("CONTENT CONTROLS",NAVY,12,true); h.setPadding(dp(2),dp(16),0,dp(7)); root.addView(h,lp(-1,dp(48)));
        LinearLayout grid=col();
        LinearLayout r1=row();
        TextView add=action("＋  ADD",PURPLE); add.setOnClickListener(v->openContent("add")); r1.addView(add,wt(1,dp(48))); r1.addView(space(),lp(dp(7),1));
        TextView edit=action("✎  EDIT",BLUE); edit.setOnClickListener(v->openContent("edit")); r1.addView(edit,wt(1,dp(48))); grid.addView(r1,lp(-1,dp(48)));
        LinearLayout r2=row();
        TextView del=action("⌫  DELETE",RED); del.setOnClickListener(v->openContent("delete")); r2.addView(del,wt(1,dp(48))); r2.addView(space(),lp(dp(7),1));
        TextView save=action("✓  SAVE",GREEN); save.setOnClickListener(v->openContent("save")); r2.addView(save,wt(1,dp(48))); grid.addView(r2,top(lp(-1,dp(48)),7));
        root.addView(grid,lp(-1,-2));

        LinearLayout note=col(); note.setPadding(dp(12),dp(10),dp(12),dp(10)); note.setBackground(round(Color.WHITE,Color.rgb(229,232,243),14));
        note.addView(label("Admin only",PINK,11,true),lp(-1,dp(22)));
        note.addView(label("সাধারণ User এই Add / Edit / Delete / Save বা Admin activity-এর কোনো অংশ দেখবে না।",MUTED,9,false),lp(-1,-2));
        root.addView(note,top(lp(-1,-2),14));

        TextView close=action("←  BACK",NAVY); close.setOnClickListener(v->finish()); root.addView(close,top(lp(-1,dp(46)),14));
        scroll.addView(root,new ScrollView.LayoutParams(-1,-2)); setContentView(scroll);
    }

    private void openAds(){
        // The Dashboard hero already has its established six-slot banner storage/API; route to that real manager.
        if("dashboard_banner".equals(featureKey) || "hero".equals(featureKey)){
            Intent i=new Intent(this,BannerAdminActivity.class); i.putExtra("admin_context",true); startActivity(i); return;
        }
        Intent i=new Intent(this,DashboardAdsAdminActivity.class); i.putExtra("box_key",featureKey); i.putExtra("box_title",displayTitle); i.putExtra("admin_context",true); startActivity(i);
    }

    private void openContent(String action){
        if("gallery".equals(featureKey)){
            Intent i=new Intent(this,GalleryAdminActivity.class); i.putExtra("admin_context",true); i.putExtra("requested_action",action); startActivity(i); return;
        }
        if("my_feed".equals(featureKey) || "feed".equals(featureKey) || "feed_moderation".equals(featureKey)){
            Intent i=new Intent(this,FeedModerationActivity.class); i.putExtra("admin_context",true); i.putExtra("requested_action",action); startActivity(i); return;
        }
        if("dashboard_banner".equals(featureKey) || "hero".equals(featureKey)){
            Intent i=new Intent(this,BannerAdminActivity.class); i.putExtra("admin_context",true); i.putExtra("requested_action",action); startActivity(i); return;
        }
        if("admin_panel".equals(featureKey)){
            startActivity(new Intent(this,AdminHubActivity.class)); return;
        }
        String section=sectionFor(featureKey);
        Intent i=new Intent(this,AdminSectionActivity.class); i.putExtra("section",section); i.putExtra("admin_context",true); i.putExtra("requested_action",action);
        if(needsFeatureCard(section)){
            i.putExtra("managed_category","feature_"+featureKey); i.putExtra("managed_title",displayTitle);
        }
        startActivity(i);
    }

    private String sectionFor(String key){
        if("dashboard".equals(key)||"breaking_news".equals(key))return "dashboard";
        if("social_media".equals(key)||"social_links".equals(key))return "social";
        if("external_movie".equals(key)||"external_media".equals(key))return "external_movie";
        if("help_support".equals(key))return "help_support";
        if("more_apps".equals(key))return "more_apps";
        if("menu".equals(key)||"user_menu".equals(key))return "menu";
        if("moderators".equals(key))return "moderators";
        return "feature_card";
    }
    private boolean needsFeatureCard(String section){return "feature_card".equals(section);}
    private String safeKey(String s){String x=s.toLowerCase(java.util.Locale.US).replaceAll("[^a-z0-9_-]","_");return x.length()>60?x.substring(0,60):x;}

    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private View space(){return new View(this);}
    private TextView label(String s,int color,float size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private TextView action(String s,int color){TextView t=label(s,Color.WHITE,11,true);t.setGravity(Gravity.CENTER);t.setBackground(round(color,color,13));t.setElevation(dp(2));applyRipple(t);return t;}
    private void applyRipple(View v){if(android.os.Build.VERSION.SDK_INT>=21){android.graphics.drawable.Drawable base=v.getBackground();if(base!=null)v.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(Color.argb(45,255,255,255)),base,null));}}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    private GradientDrawable gradient(int a,int b,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{a,b});g.setCornerRadius(dp(radius));return g;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams wt(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}
    private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}
    private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
