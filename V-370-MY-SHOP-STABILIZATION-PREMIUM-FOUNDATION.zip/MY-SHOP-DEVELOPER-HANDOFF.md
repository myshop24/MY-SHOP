# MY SHOP DEVELOPER HANDOFF

Version: V-370
Version name: 2.9.370
Phase: Permanent stabilization + premium UI foundation
Base: V-369

## Completed
- Centralized Android release identity on SOURCE_BUILD_ID.txt + SOURCE_VERSION_NAME.txt.
- Added build-time source/app/backend identity guard.
- Added installed APK identity + runtime backend MATCH/MISMATCH to About.
- Added Git SHA visibility for GitHub builds.
- Added shared PremiumUi spacing/radius/control/touch/motion tokens.
- Added permanent Stabilization + Premium UI Master Plan.
- Preserved V-369 feature behavior; V-370 is a foundation release, not a broad feature rewrite.

## Pending runtime QA
- Build V-370 in GitHub and confirm About shows the actual Git SHA.
- Deploy V-370 Worker and confirm About -> Backend check: MATCH.
- Repeat V-369 two-device Live acceptance tests before declaring Live participant fixes accepted.

## Locked / do not regress
- Authentication/session/user ID.
- Coin/Gold/Star/Level and ledgers.
- Gifts/catalog/admin pricing.
- Agora RTC architecture.
- Ephemeral Live comments.
- End Live first-tap behavior.
- Banner carousel and Live Home approved structure.
- Profile/social and Admin CRUD behavior.
- Google Play compliance safeguards.

## Next phase
Apply Premium UI visually in small batches, beginning with Live Room, using the approved reference and V-370 shared tokens. Do not combine visual polish with unrelated business-logic rewrites.

## Known limitation
A source ZIP cannot prove a GitHub APK was built/deployed; the proof is the installed About identity (Git SHA) plus backend MATCH after deployment.
