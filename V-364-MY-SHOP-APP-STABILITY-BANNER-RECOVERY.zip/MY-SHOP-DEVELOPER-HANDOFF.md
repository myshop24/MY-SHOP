# MY SHOP Developer Handoff — V-364

## Release type
Targeted recovery stabilization. Only the two user-reported problems are in scope: app closing/crashing and Live Home banner auto-rotation.

## Completed
- Startup ad remote images now use bounds-first sampled RGB_565 decode with OOM containment instead of full-resolution allocation.
- Dashboard first-resume duplicate API/image boot is removed; the first onResume no longer repeats the complete onCreate load.
- Live profile refresh is serialized and its first polling tick is delayed to avoid overlapping startup requests.
- Live Home banner carousel now keeps only two reusable image frames in memory instead of one decoded bitmap per configured slot.
- Live Home banner loading prefers the dedicated endpoint and falls back to the existing Dashboard banner payload if the Worker endpoint is missing/stale, preventing false 1/1 states after deployment lag.
- Returning from the Live Home Admin banner screen reloads banner slots without requiring an app restart.
- Auto-rotation remains 4.5 seconds whenever 2–6 active banner images are available.

## Locked / preserved
Login, Create Account/Gender, Live Room, RTC/Agora, Gift, Coin/Gold Coin, Profile/Social, Store/Wallet, Feed, Admin modules, user IDs, D1 schema and existing backend contracts were not redesigned or removed.

## Validation gate
Static Java structural checks, Android XML parse, Worker JavaScript syntax, version identity, targeted changed-file audit, banner timer/API contract and destructive-SQL scan must pass before ZIP delivery.

## Runtime status
Full APK/device runtime cannot be claimed from this environment because the retained project does not include a runnable Gradle wrapper/JAR or Android SDK. GitHub build + device test remains required: cold start, keep app open 10+ minutes, open/return Live Home, and confirm 2–6 active banners rotate repeatedly.
