# V-74 Update Report

## Baseline
V-74 is based on the latest MY SHOP full source package available in this workspace.

## Build-system corrections
- Removed ZIP-inside-repository build dependency from the V-74 workflow.
- GitHub Actions now builds the Android project directly from repository root.
- Workflow is stored at `.github/workflows/my-shop-v74.yml` so it can appear in GitHub Actions after commit.
- Java 17 and Android SDK 35 are configured.
- Gradle 8.11.1 is installed by GitHub Actions.
- Exactly one release APK is required; the job fails if zero or more than one is found.
- APK package/version metadata is verified.
- A SHA-256 checksum is generated for the final APK.
- Final artifact is named `V-74 MY SHOP FINAL RELEASE.apk`.

## App version
- applicationId: `com.myshop.app`
- versionCode: `74`
- versionName: `2.9.74`

## Preserved source
The existing `app/src`, resources, assets, backend contract files, design references, and prior release documentation are preserved rather than replaced with a newly invented app.

## Important wrapper note
`gradlew` and `gradlew.bat` are included as launcher files, and `gradle/wrapper/gradle-wrapper.properties` is included. A valid `gradle-wrapper.jar` could not be obtained in this offline build environment, so the V-74 GitHub Actions workflow intentionally uses `gradle/actions/setup-gradle@v4` and the installed `gradle` command instead of invoking the wrapper. This is deliberate and is not claimed to be a complete offline Gradle Wrapper distribution.

## Upload rule
Upload/extract the CONTENTS of this source package to the repository root. Do not upload the ZIP as the only repository file. The workflow must end up at:

`.github/workflows/my-shop-v74.yml`

Then open GitHub Actions and select `MY SHOP V-74 ONE APK`.
