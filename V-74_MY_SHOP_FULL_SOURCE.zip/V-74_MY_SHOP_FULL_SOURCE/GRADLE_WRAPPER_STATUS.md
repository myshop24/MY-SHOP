# Gradle Wrapper Status — V-74

Included:
- `gradlew`
- `gradlew.bat`
- `gradle/wrapper/gradle-wrapper.properties`

Not included:
- `gradle/wrapper/gradle-wrapper.jar`

Reason: the current working environment has no Gradle distribution/cache and no network access to obtain the official wrapper JAR. The GitHub Actions workflow does not depend on the wrapper; it installs Gradle 8.11.1 using `gradle/actions/setup-gradle@v4` and invokes `gradle` directly.
