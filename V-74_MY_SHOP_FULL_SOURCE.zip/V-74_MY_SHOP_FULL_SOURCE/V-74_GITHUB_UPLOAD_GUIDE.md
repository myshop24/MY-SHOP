# V-74 GitHub Upload Guide

Do NOT upload only the ZIP file into the repository.

Extract this package and upload its CONTENTS to the repository root so the tree contains:

.github/workflows/my-shop-v74.yml
app/
gradle/
gradlew
gradlew.bat
settings.gradle
build.gradle
gradle.properties

After committing to `main`, open Actions and choose:
`MY SHOP V-74 ONE APK`

The workflow can also be started manually with `Run workflow` because `workflow_dispatch` is enabled.
