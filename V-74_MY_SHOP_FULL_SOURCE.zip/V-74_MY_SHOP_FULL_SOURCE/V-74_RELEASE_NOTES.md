# MY SHOP V-74 — Full Source Package

V-74 is a corrected build-source milestone derived from V-73.

### Fixed in this milestone
- V-73 workflow referenced missing `tools/validate_v72.py`; V-74 uses `tools/validate_v74.py`.
- V-73 workflow checked `versionCode='72'` while the source was V-73; V-74 checks versionCode 74 and versionName 2.9.74.
- V-74 keeps the one-release-APK guard and SHA-256 output.
- V-74 adds `gradlew` and `gradlew.bat` bootstrap launchers.

### Carried forward
- Full `app/src` tree
- Full Android resources/assets
- backend contracts/config
- design references
- root/app Gradle files
- GitHub Actions workflow
- V-73 working source

### Wrapper note
The official Gradle `gradle-wrapper.jar` binary is not present in the V-73 source and cannot honestly be fabricated. V-74 therefore keeps the Gradle 8.11.1 properties and uses GitHub Actions Gradle setup for CI.
