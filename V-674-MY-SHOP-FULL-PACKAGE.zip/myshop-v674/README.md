# MY SHOP V-673

Guardian Admin preview correction, retaining V672 gift-size fix and all earlier features. Admin grid/editor now shares the new MS halo renderer with Store/Live. Direct Guardian Controls button added to the Guardian product Admin page.

Read GITHUB-UPLOAD-V673-BN.md and MY-SHOP-DEVELOPER-HANDOFF.md. One complete source project archive; no signed APK bundled. Existing original GitHub signing required. No phone/RTC acceptance claimed.
