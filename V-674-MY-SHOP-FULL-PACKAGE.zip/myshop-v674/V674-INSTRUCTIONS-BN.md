# V-674 MY SHOP — কাজ ও ব্যবহার

৫: Live গিফট কমেন্টে পুরো প্রেরক/প্রাপক, গিফটের নাম, প্রতি প্রাপকের সংখ্যা, প্রতি প্রাপকের Coin/Gold Coin ও মোট গিফট মূল্য দেখাবে। কমিশন এই মূল্য নয়; Send-এর আসল হিসাব অপরিবর্তিত।
৮: Admin Panel → Startup Advertisement থেকে ছবি/ভিডিও চালু করে Save করুন। অ্যাপ নতুন করে খুললে দেখা যাবে। Skip ও লোড-ব্যর্থতার fallback বহাল।
৯: Messages → Official Message-এ সিন করা বার্তা থাকবে, নতুন বার্তা ওপরে লাল হাইলাইট হবে। Admin → অফিসিয়াল মেসেজ → Sent messages • Remove থেকে সবার জন্য সরাতে পারবেন।
২১: Animated wallpaper ডিফল্ট চালু; Live → More → Animated wallpaper on this device দিয়ে নিজের পছন্দ বদলানো যায়। ভিডিও সাইলেন্ট লুপে চলে। MP4 H.264 ব্যবহার করুন।
২২: Admin → Audio / Video Live Themes → Audio/Video → Wallpaper/Animated → ছয় কার্ডের একটি → নাম/ছবি বা ভিডিও/প্রিভিউ → চালু → সংরক্ষণ ও প্রকাশ। আরও সেটিংস ও Join settings আলাদা খুলবে। চার বিভাগে ৬ করে মোট২৪ ফ্রি স্লট; পুরোনো Default/থিম বহাল। কার্ড বদলাতে নতুন নেটওয়ার্ক রিড নয়; Save-এর পরে refresh। D1 দৈনিক quota ইতোমধ্যে শেষ হলে পরের quota window প্রয়োজন; UI সেটিং তা বাড়ায় না।
২৩: Admin → Comment Design → সাধারণ ইউজার। ২০ সাদাকালো বা২০ রঙিন কার্ড বাছুন। ব্যাকগ্রাউন্ড ও লেখার রঙের চাকা আলাদা। র‌্যান্ডম চাইলে চালু করে কার্ড লং-প্রেসে pool-এ যোগ/বাদ দিন অথবা২০টি বাছুন। প্রকাশ করলে সাধারণ/নতুন ইউজারের পরের কমেন্টে কার্যকর (সর্বোচ্চ১০সেকেন্ড config cache)। কেনা/ব্যক্তিগত/মেম্বারশিপ/অথরিটি ডিজাইন অক্ষত। নির্দিষ্ট ইউজারের পুরোনো editor-এ লেখার আলাদা রং যুক্ত।

একটিমাত্র ZIP অপরিবর্তিত অবস্থায় আগের GitHub repository-তে আপলোড করুন। পুরোনো root pipeline ও original signing Secrets রাখুন। নতুন সফল build-এর Artifacts থেকে MY_SHOP_FINAL_RELEASE.apk নামাবেন। এই২৫MB-এর নিচের source ZIP-এ APK নেই। নতুন signing key বা ওয়েবসাইট build লাগবে না।

ফোনে Live/Agora ও original-signed APK acceptance আলাদা; পরীক্ষার রিপোর্ট verification/V674-RESULTS.json-এ।

অডিও পরীক্ষা: role/capture/mute/options SDK কল সফল হলেই প্রয়োগকৃত অবস্থা সেভ হবে। ব্যর্থ হলে পরের refresh-এ আবার চেষ্টা করবে। reconnect ও local-audio failure-এ cached state পরিষ্কার হয়। নিজের Mute/Focus ও audience microphone privacy অপরিবর্তিত। কোডভিত্তিক2–18 জনের পরীক্ষা পাস; বাস্তব ফোনে delivery পরীক্ষা বাকি।

ফোনে অডিও যাচাই: Host ও Guest-এর ফোনে একই নতুন APK আপডেট করুন। Host → Guest/Audience এবং Guest → Host/অন্য Guest শোনা, নিজের Mute/Unmute, seat-এ ওঠা/নামা, নেটওয়ার্ক reconnect ও minimize থেকে ফিরে আসা পরীক্ষা করুন। নিজের Mute/Room audio OFF কোড নিজে থেকে ON করবে না। বাস্তব ফোনের এই পরীক্ষা এখানে করা হয়নি।

তালিকা লোড ব্যর্থ হলে Theme Admin-এ Retry চাপুন; তালিকা না পাওয়া পর্যন্ত নতুন আপলোড/প্রকাশ বন্ধ থাকবে, যাতে পুরোনো ভালো সেটিংয়ের ওপর ফাঁকা তথ্য লেখা না হয়।
