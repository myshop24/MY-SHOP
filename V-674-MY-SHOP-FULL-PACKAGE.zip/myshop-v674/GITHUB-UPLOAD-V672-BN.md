# V-672 — একটিই ZIP আপলোড

**V-672-MY-SHOP-FULL-PACKAGE.zip** না খুলে আগেরMY-SHOP repository root-এ Upload files→Commit করুন। Successful Android build→Artifacts থেকে নতুন APK নিন। নতুনversionCode672/versionName2.9.672 এবং আগের signing certificate মিলবে। ZIP-এ APK নেই; কোনো পুরোনো APK নতুন নামে দেওয়া হয়নি। আগের original signing Secrets/cache অপরিবর্তিত রাখবেন।

এই সংস্করণে শুধু গিফট আইকনের density scaling ঠিক হয়েছে।48dp জায়গা থাকলেও CENTER_INSIDE সেটিং40physical-pixel মূল ছবিটিকে বড় হতে দিচ্ছিল না। FIT_CENTER সেটিং এখন নির্ধারিত জায়গা ভরে আঁকবে। ঢাকনা/ফুল animation ও Send একই আছে। V671-এর Guardian/Admin-onlyRemove,Wallpaper এবংfullscreen fixes অক্ষত।

মূলpermanent workflow আগের মতোWorker deploy-ও করে; ZIP upload করলে rootworkflow নিজে বদলায় না। এই কাজ থেকে কোনোremote deploy হয়নি। Sourcemedia hash-verified baseline restore ও includedgenerators ব্যবহার করে; build-এ internet লাগবে। ফোনে screenshot/Live পরীক্ষা হয়নি। Developerhandoff ও verification/V672-RESULTS.json-এ প্রকৃত ফল আছে।
