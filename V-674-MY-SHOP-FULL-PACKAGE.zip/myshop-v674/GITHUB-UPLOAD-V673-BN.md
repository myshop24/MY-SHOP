# V-673 — একটি ZIP আপলোড

**V-673-MY-SHOP-FULL-PACKAGE.zip** না খুলে আগের MY-SHOP repository root-এ Upload files→Commit করুন। সফল Android build→Artifacts থেকে versionCode673/versionName2.9.673-এর নতুন APK নিন। ZIP-এ APK নেই; মূল signing Secrets/cache অপরিবর্তিত রাখবেন।

সংশোধন: GUARDIAN Admin-এর grid ও editor preview এখন Store/Live-এর একই নতুন MS/animated halo দেখাবে। পুরোনো frame asset দেখানোর renderer mismatch ঠিক হয়েছে। এইপৃষ্ঠার ওপরে **Guardian Controls • Background / Remove / Restore** বাটনে চাপলে নতুন নিয়ন্ত্রণপ্যানেল খুলবে। এডমিনথেকেপ্রিভিউসেটিংবদলানোরপ্রয়োজননেই।

আগের সবফিচার,গিফটআইকনসাইজেরV672ফিক্স,মূলদাম,কেনাআইডি,মেয়াদওহিস্ট্রিঅক্ষত। পুরোনো30/90daysপ্ল্যানইচ্ছাকৃতভাবেমুছিনি।

মূল permanent workflow Worker deploy-ও করে; ZIP upload-এ root workflow নিজে বদলায় না। এই কাজ থেকে remote deploy হয়নি। Build included generators এবং hash-verified baseline restore ব্যবহার করে; internet/dependencies প্রয়োজন। ফোনে বাস্তব screenshot/Live পরীক্ষা হয়নি। প্রকৃত ফল verification/V673-RESULTS.json-এ।
