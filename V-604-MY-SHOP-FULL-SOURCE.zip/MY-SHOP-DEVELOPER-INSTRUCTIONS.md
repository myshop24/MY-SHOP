Current V604 /2.9.604: read handoffs/MY-SHOP-V604-HANDOFF.md. Canonical source<=25,000,000 bytes. Next deliveryV605. No APK; inherited partial work recorded.

Current V603 partial checkpoint: read handoffs/MY-SHOP-V603-HANDOFF.md. All9 are NOT completed; rides blocked. Next delivery V604.

Current V602 checkpoint: read handoffs/MY-SHOP-V602-HANDOFF.md. Next delivery V603.

# MY SHOP — Developer Entry Instructions

Read DEVELOPER-POLICY-BN.md first: the consolidated owner rules dated2026-10-09. General policies are kept there once. Latest explicit owner decisions take precedence. Read AGENTS.md, V575-APPROVED-WORK-BN.md and MY-SHOP-DEVELOPER-HANDOFF.md for scoped approvals and the actual checkpoint. Current source is V-602, continued from the V600 full source. Read BUILD-ASSETS-BN.md and handoffs/MY-SHOP-V601-HANDOFF.md; generated runtime assets are prepared from included inputs. Read the current handoff for tests and limitations; this is not a verified signed APK release. Read handoffs/MY-SHOP-V600-HANDOFF.md and V600-APPROVED-WORK-BN.md. The next newly created delivery must use V-603.

## Retained feature-specific owner instructions

## 6. Required task notes for current work

1. **Home header language control:** Put plain `EN` between the moon/theme control and notification bell. Keep it visible, clean like the bell icon, with no border, ring, or emoji, and no overlap.
2. **Speed:** Make MY SHOP's taps, navigation, feed, and media loading feel as responsive as possible, with measured performance improvements and no regressions.
3. **Posting limit (current temporary rule):** Each user may successfully publish one video (including a Reel), one photo post, and one text-only status per rolling 24 hours. Editing an existing post does not consume another quota. Count only successful publishes.
4. **Editing:** Users can edit their existing posts; edits update the same post and do not create a new post or consume another posting quota.


## 8. Current feature notes (2026-10-04)

5. **Home and Live page banner rows:** Home Page 1 and Live Streaming Page 2 keep separately managed banner rows/sections. Admin can enable/disable each row, reorder banners, and hide a row. If a row is hidden, the content below moves up immediately; do not leave an empty gap. Each banner's display interval is configurable in seconds.
6. **Mini-card ads:** Provide 20 premium ready-made card designs and 20 color choices/palettes. Match the approved long, compact horizontal reference: text on the left, a real gallery image on the right, and softly rounded image-side corners. Gallery selection must set the image itself, never the click URL; store the optional destination link separately. Preview must show the selected image and actual card content. Admin separately controls display seconds and the campaign validity duration in days; the number of days is configurable, not fixed at 30. Expired cards stop displaying automatically.
7. **Mini-card animation and placement:** Use smooth, high-quality layered animation (moving light/shimmer, glow, sparkles, gentle photo zoom). Admin can independently enable/disable the card animation and the brief fire/electric-light flash along the top edge when the card appears. Keep the effect clear without obscuring the card.
8. **Moving headline strip:** Add a compact strip with the same overall dimensions as Breaking News, not a large card. It has its own separate Admin module and configuration; do not merge it with or overwrite the Home Page's existing Breaking News headline. Support multiple independent headline/text layers. Admin can add text, drag each text layer into position, set its size and color, choose a preset or custom color with a color wheel, and preview changes. Keep text and its background grouped: they enter from the right, pause at the Admin-selected point if configured, then move out to the left. Admin can enable/disable this strip and its animation separately. Add the optional top-edge flash toggle described above where applicable.
9. **Cross-page placement:** Both mini cards and moving headline strips can be assigned independently to any available page (for example Home Page 1, Page 2, Page 3, Page 4) or multiple/all pages. Placement controls stay separate from Breaking News. Reuse a content item across selected pages instead of requiring duplicate copies; allow page-specific visibility, order/position and preview at that page's mobile size.
10. **Card tap behavior:** Tapping a mini card opens its configured detail view or destination link. Keep banner text concise; provide full information after the tap.
11. **Verification badge expiry:** Admin chooses the badge validity in days whenever granting/extending it. A value such as 30 is only an example; use whatever duration the Admin enters. On expiry, remove the badge automatically without affecting the user's account or posts.



## Owner delivery rule — V597 continuation
Provide the complete versioned source ZIP for GitHub upload. Preserve the original package/signing identity and working Android APK workflow. A successful GitHub build must upload its verified signed APK as an Actions artifact. If local SDK/signing credentials are unavailable, explicitly state that no APK was built; never substitute an older APK or claim build success. Retain all prior releases.
