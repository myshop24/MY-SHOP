import {giftProgressStatements} from './gift-level-progress.js';
import { schemaOnce, measureResult } from './schema-once.js';
import { closeLive } from './live-close.js';
import { agencyApi, ensureAgencyFinance } from './agency.js';
import { ensureWithdrawWalletHold } from './withdraw-wallet-hold.js';
import { readCommission, effectiveCommission, commissionManagement } from './commission-management.js';
import { publicAggregate, invalidatePublicAggregates } from './live-read-cache.js';
import {preparePostAppearance,insertStyledPost} from './post-appearance.js';
import {moderatorDirectory} from './moderator-directory.js';
import { adminActivity } from './admin-activity.js';
import { homeFeaturePresentation } from './feature-presentation.js';
// One unit per distinct event. Launchers that sum active notifications therefore
// count 50 events as 50, rather than summing cumulative 1+2+...+50 counts.
function attachPushBadge(payload, userId, type, eventId) {
  const badgeType=['MESSAGE', 'FRIEND_REQUEST', 'LIVE_START'].includes(String(type));
  if(badgeType&&!/^[1-9][0-9]*$/.test(String(eventId)))return payload; // Preserve legacy pushes that predate inbox event IDs.
  const eligible=badgeType&&/^[1-9][0-9]*$/.test(String(eventId));
  if(!eligible){payload.message.data.badgeEligible='0';payload.message.android.notification.channel_id=String(type).startsWith('LIVE_')?'myshop_live_no_badge_v590':String(type)==='MESSAGE'?'myshop_messages_no_badge_v590':'myshop_general_no_badge_v590';return payload;}
  if(String(type)==='FRIEND_REQUEST')payload.message.android.notification.channel_id='myshop_friend_badge_v590';
  payload.message.data.badgeEventId = String(eventId);
  payload.message.data.badgeEligible = '1';
  payload.message.android.notification.tag = 'myshop_event_' + String(userId) + '_' + String(eventId);
  payload.message.android.notification.notification_count = 1;
  return payload;
}

import {userControlDetails} from './user-control-details.js';
import {adminModerationOverride} from './admin-moderation-override.js';
import {specialUserId,newAccountIdentity,insertSpecialAccount,insertUnreservedAccount} from './special-user-id.js';
import {featureAccess} from './feature-access.js';
import {walletHistory} from './wallet-history.js';
import {profileMenu} from './profile-menu.js';
import {draftReview} from './draft-review.js';
import { bankAccount } from './bank-account.js';
import { readCatalog, termsFor, withdrawCatalog } from './withdraw-catalog.js';
import { visualDesign } from './visual-design.js';
import { appearanceDesign } from './appearance-design.js';
import { featureHistory, featureHistorySchema, writeManagedFeature } from './feature-history.js';
import { verifyDeletionGoogleToken } from './deletion-reauth.js';
import { deletionMediaSchema, drainDeletedMedia, mediaWasDeleted } from './deletion-media.js';
import { createWithdrawal, withdrawalOperationSchema } from './withdraw-request.js';
import { adminFolderControls, applyModeratorChange } from './admin-folder-controls.js';
import {adminWalletRemove} from './wallet-adjust.js';
import {ensureRequestNotices,requestNotices,dispatchRequestNotices,folderRequestNotices} from './request-notices.js';
import agoraRtcTokenPkg from 'agora-token/src/RtcTokenBuilder2.js';
import { commerce } from './commerce.js';
import { productPage } from './product-page.js';
import { payoutInbox } from './payout-inbox.js';
import { payoutAction, payoutActionSchema } from './payout-actions.js';
import { filterPersonalDetailsForViewer, normalizeUserSocialUrl, maskProfileCore, PROFILE_CORE_KEYS } from './profile-details.js';
const { RtcTokenBuilder: AgoraRtcTokenBuilder, Role: AgoraRtcRole } = agoraRtcTokenPkg;
const json = (data, status = 200, extra = {}) => new Response(JSON.stringify(data), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", ...extra }
});

// V-311 Live comments are strictly ephemeral. They live only in Worker isolate memory
// for the active room/session and are never written to D1 or R2.
const liveEphemeralComments = new Map();
const liveEphemeralHighlights = new Map();
let liveEphemeralSeq = 1;
function liveEphemeralKey(hostId,sessionId){ return `${hostId}:${sessionId}`; }
function liveEphemeralPrune(map,key,maxItems=80,maxAgeMs=60*60*1000){
  const now=Date.now(), src=Array.isArray(map.get(key))?map.get(key):[];
  const kept=src.filter(x=>now-Number(x._ts||0)<=maxAgeMs).slice(-maxItems);
  if(kept.length) map.set(key,kept); else map.delete(key);
  return kept;
}
function liveEphemeralPush(map,key,item,maxItems=80,maxAgeMs=60*60*1000){
  const a=liveEphemeralPrune(map,key,maxItems,maxAgeMs); a.push(item);
  while(a.length>maxItems)a.shift(); map.set(key,a); return item;
}
function liveEphemeralClear(hostId,sessionId){
  const key=liveEphemeralKey(hostId,sessionId); liveEphemeralComments.delete(key); liveEphemeralHighlights.delete(key);
}


// V-352: one Durable Object per host keeps active-room realtime events coherent
// across Worker isolates without writing Live comments to D1/R2.
function liveHubStub(env,hostId){
  if(!env?.LIVE_ROOM_HUB||!isFourDigit(hostId))return null;
  const id=env.LIVE_ROOM_HUB.idFromName(String(hostId));
  return env.LIVE_ROOM_HUB.get(id);
}
function bearerRaw(request){
  const auth=String(request.headers.get('authorization')||'');
  return auth.toLowerCase().startsWith('bearer ')?auth.slice(7).trim():'';
}
async function liveHubRegister(request,env,hostId,sessionId,userId){
  const stub=liveHubStub(env,hostId),raw=bearerRaw(request);
  if(!stub||!raw||!sessionId)return null;
  const tokenHash=await sha256(raw);
  const r=await stub.fetch('https://live-hub/register',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({sessionId:String(sessionId),userId:String(userId),tokenHash,expiresAt:Date.now()+120000})});
  return r.ok?await r.json():null;
}
async function liveHubPush(env,hostId,sessionId,kind,payload){
  if(kind==='GIFT'||kind==='DIRTY')invalidatePublicAggregates(env.DB,hostId);
  const stub=liveHubStub(env,hostId);if(!stub||!sessionId)return null;
  const r=await stub.fetch('https://live-hub/push',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({sessionId:String(sessionId),kind:String(kind||'DIRTY'),payload:payload||{}})});
  return r.ok?await r.json():null;
}
async function liveHubDirty(env,hostId,sessionId,reason='STATE'){
  try{return await liveHubPush(env,hostId,sessionId,'DIRTY',{reason:String(reason||'STATE')});}catch(e){return null;}
}
async function liveHubDirtyForHost(env,hostId,reason='STATE'){
  try{
    const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();
    const sessionId=String(meta?.session_id||'');
    if(sessionId)return await liveHubDirty(env,hostId,sessionId,reason);
  }catch(e){}
  return null;
}
async function liveHubClear(env,hostId,sessionId){
  const stub=liveHubStub(env,hostId);if(!stub)return null;
  try{const r=await stub.fetch('https://live-hub/clear',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({sessionId:String(sessionId||'')})});return r.ok;}catch(e){return false;}
}
async function liveRealtime(request,env){
  const u=new URL(request.url),hostId=String(u.searchParams.get('hostId')||'').trim(),sessionId=String(u.searchParams.get('sessionId')||'').trim();
  const afterComment=Math.max(0,Math.floor(Number(u.searchParams.get('afterComment')||0))),afterHighlight=Math.max(0,Math.floor(Number(u.searchParams.get('afterHighlight')||0))),afterGift=Math.max(0,Math.floor(Number(u.searchParams.get('afterGift')||0))),knownRevision=Math.max(0,Math.floor(Number(u.searchParams.get('revision')||0)));
  if(!isFourDigit(hostId)||!sessionId)return json({error:'INVALID_REALTIME_ROOM'},400,cors);
  const raw=bearerRaw(request);if(!raw)return json({error:'UNAUTHORIZED'},401,cors);
  const stub=liveHubStub(env,hostId);if(!stub)return json({error:'REALTIME_HUB_NOT_CONFIGURED'},503,cors);
  const tokenHash=await sha256(raw);
  const q=new URL('https://live-hub/events');q.searchParams.set('sessionId',sessionId);q.searchParams.set('tokenHash',tokenHash);q.searchParams.set('afterComment',String(afterComment));q.searchParams.set('afterHighlight',String(afterHighlight));q.searchParams.set('afterGift',String(afterGift));q.searchParams.set('revision',String(knownRevision));
  const r=await stub.fetch(q.toString());let data={};try{data=await r.json();}catch(e){data={error:'REALTIME_HUB_ERROR'};}
  return json(data,r.status,cors);
}

const cors = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET,POST,PUT,DELETE,OPTIONS",
  "access-control-allow-headers": "Content-Type, Authorization, X-MYSHOP-HEALTH-KEY"
};

function normalizeEmail(v) { return String(v || '').trim().toLowerCase(); }
function normalizeMobile(v) { return String(v || '').trim().replace(/[\s()-]/g, ''); }
function normalizeAnswer(v) { return String(v || '').trim().toLowerCase(); }
function isFourDigit(v) { return /^\d{4}$/.test(String(v || '')); }
function isAdminUser(user){return !!user&&(String(user.role||'').toUpperCase()==='ADMIN'||['0001','0002','0003'].includes(String(user.user_id||'')));}


function bytesToHex(bytes) { return [...new Uint8Array(bytes)].map(b => b.toString(16).padStart(2,'0')).join(''); }
function hexToBytes(hex) { const out = new Uint8Array(hex.length / 2); for (let i=0;i<out.length;i++) out[i]=parseInt(hex.slice(i*2,i*2+2),16); return out; }

async function sha256(text) {
  return bytesToHex(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)));
}

// V-297: compare owner identifiers by hash only. Raw recovery/admin identifiers are not embedded.
async function ownerAdminIdForIdentifier(value) {
  const v=String(value||'').trim().toLowerCase(); if(!v)return '';
  const h=await sha256(v);
  const map={
    '2488f46e89a2ff3d2e5ea9f43ee610d8c74135f931692269d077a73551f8495d':'0001',
    '6d8859a91a72a6ab10acda29c21709493fe5f0f3efcee83e480a609f9abf8969':'0002',
    'b2d53ac69843f7f30f81a770adc18107f230317670eaa701d3135e53731e6b28':'0003'
  };
  return map[h]||'';
}

const PBKDF2_ITERATIONS = 100000;

async function pbkdf2(password, saltHex, iterations = PBKDF2_ITERATIONS) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({name:'PBKDF2', salt:hexToBytes(saltHex), iterations, hash:'SHA-256'}, key, 256);
  return bytesToHex(bits);
}

function randomHex(bytes = 16) {
  const a = new Uint8Array(bytes); crypto.getRandomValues(a); return bytesToHex(a);
}

function guessContentType(file) {
  const raw=String(file?.type||'').toLowerCase().trim();
  if(raw) return raw;
  const name=String(file?.name||'').toLowerCase();
  const ext=name.includes('.')?name.split('.').pop():'';
  const map={jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webp:'image/webp',gif:'image/gif',bmp:'image/bmp',heic:'image/heic',heif:'image/heif',mp3:'audio/mpeg',wav:'audio/wav',m4a:'audio/mp4',aac:'audio/aac',ogg:'audio/ogg',mp4:'video/mp4',webm:'video/webm',mov:'video/quicktime',mkv:'video/x-matroska'};
  return map[ext]||'application/octet-stream';
}

async function hashPassword(password) {
  const salt = randomHex(16);
  const iterations = PBKDF2_ITERATIONS;
  const digest = await pbkdf2(password, salt, iterations);
  return `pbkdf2_sha256$${iterations}$${salt}$${digest}`;
}

async function verifyPassword(password, stored) {
  const p = String(stored || '').split('$');
  if (p.length !== 4 || p[0] !== 'pbkdf2_sha256') return false;
  const digest = await pbkdf2(password, p[2], Number(p[1]));
  return digest === p[3];
}

async function ensureAuthSchema(env){return schemaOnce(env.DB,'ensureAuthSchema',()=>ensureAuthSchemaImpl(env));}
async function ensureAuthSchemaImpl(env) {
  // Additive-only and fault-tolerant. Existing user/auth data is never dropped or cleared.
  const statements = [
    `CREATE TABLE IF NOT EXISTS myshop_auth_users_v108 (user_id TEXT PRIMARY KEY CHECK(length(user_id)=4),full_name TEXT NOT NULL,email TEXT UNIQUE,mobile TEXT UNIQUE,password_hash TEXT NOT NULL,security_q1 TEXT NOT NULL,security_a1_hash TEXT NOT NULL,security_q2 TEXT NOT NULL,security_a2_hash TEXT NOT NULL,security_q3 TEXT NOT NULL,security_a3_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'USER' CHECK(role IN ('USER','ADMIN','MODERATOR')),active INTEGER NOT NULL DEFAULT 1,avatar_url TEXT NOT NULL DEFAULT '',avatar_object_key TEXT NOT NULL DEFAULT '',cover_url TEXT NOT NULL DEFAULT '',cover_object_key TEXT NOT NULL DEFAULT '',bio TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_myshop_auth_email ON myshop_auth_users_v108(email) WHERE email IS NOT NULL AND email <> ''`,
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_myshop_auth_mobile ON myshop_auth_users_v108(mobile) WHERE mobile IS NOT NULL AND mobile <> ''`,
    `CREATE TABLE IF NOT EXISTS myshop_auth_sessions_v108 (token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id) ON DELETE CASCADE,expires_at INTEGER NOT NULL,created_at INTEGER NOT NULL)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_auth_sessions_v108_user ON myshop_auth_sessions_v108(user_id)`,
    `CREATE TABLE IF NOT EXISTS myshop_moderators_v108 (user_id TEXT PRIMARY KEY REFERENCES myshop_auth_users_v108(user_id) ON DELETE CASCADE,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`
  ];
  for (const sql of statements) { try { await env.DB.prepare(sql).run(); } catch (_) {} }
  // Additive migration for databases created by an older MY SHOP release.
  // Never drop/recreate the auth table: existing IDs, users and sessions stay intact.
  try {
    const cols = (await env.DB.prepare(`PRAGMA table_info(myshop_auth_users_v108)`).all()).results || [];
    const names = new Set(cols.map(x => String(x.name || '')));
    if (!names.has('avatar_url')) await env.DB.prepare(`ALTER TABLE myshop_auth_users_v108 ADD COLUMN avatar_url TEXT NOT NULL DEFAULT ''`).run();
    if (!names.has('avatar_object_key')) await env.DB.prepare(`ALTER TABLE myshop_auth_users_v108 ADD COLUMN avatar_object_key TEXT NOT NULL DEFAULT ''`).run();
    if (!names.has('cover_url')) await env.DB.prepare(`ALTER TABLE myshop_auth_users_v108 ADD COLUMN cover_url TEXT NOT NULL DEFAULT ''`).run();
    if (!names.has('cover_object_key')) await env.DB.prepare(`ALTER TABLE myshop_auth_users_v108 ADD COLUMN cover_object_key TEXT NOT NULL DEFAULT ''`).run();
    if (!names.has('bio')) await env.DB.prepare(`ALTER TABLE myshop_auth_users_v108 ADD COLUMN bio TEXT NOT NULL DEFAULT ''`).run();
    if (!names.has('blocked_until')) await env.DB.prepare(`ALTER TABLE myshop_auth_users_v108 ADD COLUMN blocked_until INTEGER NOT NULL DEFAULT 0`).run();
    if (!names.has('gender')) await env.DB.prepare(`ALTER TABLE myshop_auth_users_v108 ADD COLUMN gender TEXT NOT NULL DEFAULT 'UNSPECIFIED'`).run();
  } catch (_) {}
  try { await migratePreviousAuthIfPresent(env); } catch (_) {}
}

async function migratePreviousAuthIfPresent(env) {
  // V-107 may have created the old auth table before a deployment failed.
  // Copy compatible rows forward; never delete or modify the old table.
  try {
    await env.DB.prepare(`INSERT OR IGNORE INTO myshop_auth_users_v108
      (user_id,full_name,email,mobile,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role,active,created_at,updated_at)
      SELECT user_id,full_name,email,mobile,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role,active,created_at,updated_at
      FROM myshop_auth_users`).run();
  } catch (_) {
    // Old table may not exist or may have an incompatible schema. Leave it untouched.
  }
}

async function createSession(env, userId) {
  const raw = `${crypto.randomUUID()}-${randomHex(16)}`;
  const hash = await sha256(raw);
  const days = Math.max(1, Number(env.SESSION_DAYS || 30));
  const expires = Date.now() + days * 86400000;
  await env.DB.prepare('INSERT INTO myshop_auth_sessions_v108(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)')
    .bind(hash, userId, expires, Date.now()).run();
  return raw;
}

async function getUser(request, env) {
  const auth = request.headers.get('authorization') || '';
  if (!auth.toLowerCase().startsWith('bearer ')) return null;
  const raw = auth.slice(7).trim();
  if (!raw) return null;
  const hash = await sha256(raw);
  const row = await env.DB.prepare(`SELECT u.* FROM myshop_auth_sessions_v108 s JOIN myshop_auth_users_v108 u ON u.user_id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.active=1`).bind(hash, Date.now()).first();
  return row && Number(row.blocked_until||0)<=Date.now() ? row : null;
}

function publicUser(u) {
  return { userId:u.user_id, name:u.full_name, email:u.email || '', mobile:u.mobile || '', role:u.role, avatarUrl:u.avatar_url || '', coverUrl:u.cover_url || '', bio:u.bio || '', gender:u.gender || 'UNSPECIFIED' };
}

async function body(request) {
  try { return await request.json(); } catch { return {}; }
}

async function findAuthUser(env, identifier) {
  const id = String(identifier || '').trim();
  let user = null;
  if (isFourDigit(id)) user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(id).first();
  if (!user && id.includes('@')) user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE email=? AND active=1').bind(normalizeEmail(id)).first();
  if (!user) user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE mobile=? AND active=1').bind(normalizeMobile(id)).first();
  return user && Number(user.blocked_until||0)<=Date.now() ? user : null;
}

async function register(request, env) {
  const b = await body(request);
  const name = String(b.name || '').trim();
  if(/[\r\n]/.test(name)||Array.from(name).length>24)return json({error:'PROFILE_NAME_TOO_LONG'},400,cors);
  const email = normalizeEmail(b.email);
  const mobile = normalizeMobile(b.mobile);
  const password = String(b.password || '');
  const rawGender=String(b.gender||'UNSPECIFIED').trim().toUpperCase();
  const gender=['MALE','FEMALE','UNSPECIFIED'].includes(rawGender)?rawGender:'UNSPECIFIED';
  const securityQuestion = String(b.securityQuestion || (Array.isArray(b.securityQuestions) ? b.securityQuestions[0] : '') || '').trim();
  const securityAnswer = String(b.securityAnswer || (Array.isArray(b.securityAnswers) ? b.securityAnswers[0] : '') || '').trim();
  if (!name || (!email && !mobile) || password.length < 6 || !securityQuestion || !securityAnswer) return json({error:'INVALID_INPUT'},400,cors);
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({error:'INVALID_EMAIL'},400,cors);

  const duplicate = await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE (?<>'' AND email=?) OR (?<>'' AND mobile=?) LIMIT 1`)
    .bind(email,email,mobile,mobile).first();
  if (duplicate) return json({error:'ACCOUNT_EXISTS'},409,cors);

  // Keep legacy users untouched, but block duplicate identifiers that already exist there.
  try {
    const legacy = await env.DB.prepare(`SELECT id FROM users WHERE (?<>'' AND lower(email)=?) OR (?<>'' AND mobile=?) LIMIT 1`)
      .bind(email,email,mobile,mobile).first();
    if (legacy) return json({error:'ACCOUNT_EXISTS'},409,cors);
  } catch (_) { /* legacy table may not exist on a fresh database */ }

  const adminId = await ownerAdminIdForIdentifier(email || mobile);
  const role = adminId ? 'ADMIN' : 'USER';
  let userId = adminId;
  if (!userId) {
    const chosen=await newAccountIdentity(env.DB,email,false);if(chosen.error)return json({error:chosen.error},409,cors);userId=chosen.userId;
  } else {
    const occupied = await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=?').bind(userId).first();
    if (occupied) return json({error:'ACCOUNT_EXISTS'},409,cors);
  }

  const ph = await hashPassword(password);
  const answerHash = await sha256(normalizeAnswer(securityAnswer));
  // Keep the existing 3-question columns for backward compatibility. New accounts use only q1/a1.
  const columns=['user_id','full_name','email','mobile','password_hash','security_q1','security_a1_hash','security_q2','security_a2_hash','security_q3','security_a3_hash','role','gender'];
  const values=[userId,name,email||null,mobile||null,ph,securityQuestion,answerHash,'','','','',role,gender];
  try{await insertUnreservedAccount(env.DB,columns,values);}catch(_){return json({error:'ACCOUNT_OR_ID_CHANGED_RETRY'},409,cors);}

  const user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=?').bind(userId).first();
  const token = await createSession(env, userId);
  return json({ok:true,user:publicUser(user),token},201,cors);
}

async function googleLogin(request, env) {
  const b = await body(request);
  const idToken = String(b.idToken || '').trim();
  if (!idToken) return json({error:'GOOGLE_TOKEN_REQUIRED'},400,cors);

  // Google verifies signature/issuer/expiry on tokeninfo. We additionally pin aud to MY SHOP's Web OAuth client.
  let info;
  try {
    const r = await fetch('https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(idToken), {headers:{'accept':'application/json'}});
    info = await r.json();
    if (!r.ok) return json({error:'GOOGLE_TOKEN_INVALID'},401,cors);
  } catch (_) { return json({error:'GOOGLE_VERIFY_UNAVAILABLE'},503,cors); }

  const expectedAud = String(env.GOOGLE_WEB_CLIENT_ID || '595594415596-tj26hl997ult960cug3ia68tgv5bf1rb.apps.googleusercontent.com').trim();
  if (!expectedAud || String(info.aud || '') !== expectedAud) return json({error:'GOOGLE_AUDIENCE_MISMATCH'},401,cors);
  if (!['accounts.google.com','https://accounts.google.com'].includes(String(info.iss || ''))) return json({error:'GOOGLE_ISSUER_INVALID'},401,cors);
  if (String(info.email_verified || '').toLowerCase() !== 'true') return json({error:'GOOGLE_EMAIL_NOT_VERIFIED'},403,cors);
  const email = normalizeEmail(info.email || '');
  if (!email) return json({error:'GOOGLE_EMAIL_REQUIRED'},400,cors);

  let user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE email=? AND active=1').bind(email).first();
  if (!user) {
    const adminId = await ownerAdminIdForIdentifier(email);
    let userId = adminId;let reservation=null;
    if (!userId) {
      const chosen=await newAccountIdentity(env.DB,email,true);if(chosen.error)return json({error:chosen.error},409,cors);userId=chosen.userId;reservation=chosen.reservation;
    }
    const role = adminId ? 'ADMIN' : 'USER';
    const name = String(info.name || email.split('@')[0] || 'MY SHOP User').trim().slice(0,80) || 'MY SHOP User';
    const avatar = String(info.picture || '').startsWith('https://') ? String(info.picture).slice(0,1000) : '';
    const disabledPassword = await hashPassword(crypto.randomUUID() + randomHex(32));
    const disabledAnswer = await sha256(crypto.randomUUID());
    const columns=['user_id','full_name','email','mobile','password_hash','security_q1','security_a1_hash','security_q2','security_a2_hash','security_q3','security_a3_hash','role','avatar_url','gender'];
    const values=[userId,name,email,null,disabledPassword,'Google account',disabledAnswer,'','','','',role,avatar,'UNSPECIFIED'];
    try{if(reservation)await insertSpecialAccount(env.DB,columns,values,reservation);else await insertUnreservedAccount(env.DB,columns,values);}catch(_){return json({error:'ACCOUNT_OR_ID_CHANGED_RETRY'},409,cors);}
    user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=?').bind(userId).first();
  }
  const token = await createSession(env,user.user_id);
  return json({ok:true,user:publicUser(user),token,provider:'GOOGLE'},200,cors);
}

async function login(request, env) {
  const b = await body(request);
  const id = String(b.identifier || '').trim();
  const password = String(b.password || '');
  if (!id || !password) return json({error:'INVALID_INPUT'},400,cors);
  const user = await findAuthUser(env,id);
  if (!user || Number(user.blocked_until||0)>Date.now() || !(await verifyPassword(password,user.password_hash))) return json({error:'INVALID_CREDENTIALS'},401,cors);
  const mappedAdminId = (await ownerAdminIdForIdentifier(normalizeEmail(id) || normalizeMobile(id))) || (isFourDigit(id) && ['0001','0002','0003'].includes(id) ? id : '');
  if (mappedAdminId && user.user_id === mappedAdminId && user.role !== 'ADMIN') {
    await env.DB.prepare("UPDATE myshop_auth_users_v108 SET role='ADMIN', updated_at=CURRENT_TIMESTAMP WHERE user_id=?").bind(mappedAdminId).run();
    user.role = 'ADMIN';
  }
  const token = await createSession(env,user.user_id);
  return json({ok:true,user:publicUser(user),token},200,cors);
}

async function me(request, env) {
  const user = await getUser(request,env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  return json({ok:true,user:publicUser(user)},200,cors);
}

async function logout(request, env) {
  const auth = request.headers.get('authorization') || '';
  if (auth.toLowerCase().startsWith('bearer ')) await env.DB.prepare('DELETE FROM myshop_auth_sessions_v108 WHERE token_hash=?').bind(await sha256(auth.slice(7).trim())).run();
  return json({ok:true},200,cors);
}

async function securityQuestions(request, env) {
  const id = String(new URL(request.url).searchParams.get('identifier') || '').trim();
  const user = await findAuthUser(env,id);
  if (!user) return json({error:'NOT_FOUND'},404,cors);
  return json({ok:true,question:user.security_q1},200,cors);
}

async function resetPassword(request, env) {
  const b = await body(request);
  const id = String(b.identifier || '').trim();
  const answer = String(b.answer || (Array.isArray(b.answers) ? b.answers[0] : '') || '').trim();
  const newPassword = String(b.newPassword || '');
  if (!id || !answer || newPassword.length < 6) return json({error:'INVALID_INPUT'},400,cors);
  const user = await findAuthUser(env,id);
  if (!user) return json({error:'NOT_FOUND'},404,cors);
  const answerHash = await sha256(normalizeAnswer(answer));
  if (!user.security_a1_hash || user.security_a1_hash !== answerHash) return json({error:'ANSWER_NOT_MATCHED'},403,cors);
  const ph = await hashPassword(newPassword);
  await env.DB.prepare('UPDATE myshop_auth_users_v108 SET password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(ph,user.user_id).run();
  await env.DB.prepare('DELETE FROM myshop_auth_sessions_v108 WHERE user_id=?').bind(user.user_id).run();
  return json({ok:true,userId:user.user_id},200,cors);
}

async function changePassword(request, env) {
  const user = await getUser(request,env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  const b = await body(request);
  const currentPassword = String(b.currentPassword || '');
  const newPassword = String(b.newPassword || '');
  if (!currentPassword || newPassword.length < 6) return json({error:'INVALID_INPUT'},400,cors);
  if (!(await verifyPassword(currentPassword,user.password_hash))) return json({error:'CURRENT_PASSWORD_INCORRECT'},403,cors);
  if (currentPassword === newPassword) return json({error:'PASSWORD_UNCHANGED'},400,cors);
  const ph = await hashPassword(newPassword);
  await env.DB.prepare('UPDATE myshop_auth_users_v108 SET password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(ph,user.user_id).run();
  // Security rule: a password change invalidates every existing session for this account.
  await env.DB.prepare('DELETE FROM myshop_auth_sessions_v108 WHERE user_id=?').bind(user.user_id).run();
  return json({ok:true,userId:user.user_id,sessionInvalidated:true},200,cors);
}


async function ensureContentSchema(env){return schemaOnce(env.DB,'ensureContentSchema',()=>ensureContentSchemaImpl(env));}
async function ensureContentSchemaImpl(env) {
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  // Additive, backward-compatible schema bootstrap. Never silently swallow a D1 schema error.
  const statements = [
    `CREATE TABLE IF NOT EXISTS gallery_items (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL DEFAULT '',media_url TEXT NOT NULL DEFAULT '',media_type TEXT NOT NULL DEFAULT 'image',active INTEGER NOT NULL DEFAULT 1,display_order INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_gallery_active_order ON gallery_items(active,display_order)`,
    `CREATE TABLE IF NOT EXISTS feature_buttons (key TEXT PRIMARY KEY,title TEXT NOT NULL DEFAULT '',icon_url TEXT NOT NULL DEFAULT '',target_url TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,display_order INTEGER NOT NULL DEFAULT 1,icon_size INTEGER NOT NULL DEFAULT 40,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_feature_buttons_active_order ON feature_buttons(active,display_order)`,
    `CREATE TABLE IF NOT EXISTS gallery_media (id INTEGER PRIMARY KEY AUTOINCREMENT,folder TEXT NOT NULL,title TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',media_url TEXT NOT NULL DEFAULT '',object_key TEXT NOT NULL DEFAULT '',media_type TEXT NOT NULL DEFAULT 'image',active INTEGER NOT NULL DEFAULT 1,display_order INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_gallery_media_folder_order ON gallery_media(folder,active,display_order,id)`,
    `CREATE TABLE IF NOT EXISTS dashboard_ads (id INTEGER PRIMARY KEY AUTOINCREMENT,box_key TEXT NOT NULL,slot INTEGER NOT NULL,image_url TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',target_url TEXT NOT NULL DEFAULT '',object_key TEXT NOT NULL DEFAULT '',media_type TEXT NOT NULL DEFAULT 'image',active INTEGER NOT NULL DEFAULT 1,duration_sec INTEGER NOT NULL DEFAULT 3,display_mode TEXT NOT NULL DEFAULT 'FULL_IMAGE',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(box_key,slot))`,
    `CREATE INDEX IF NOT EXISTS idx_dashboard_ads_box ON dashboard_ads(box_key,active,slot,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_posts (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id),caption TEXT NOT NULL DEFAULT '',media_url TEXT NOT NULL DEFAULT '',object_key TEXT NOT NULL DEFAULT '',media_type TEXT NOT NULL DEFAULT 'image',status TEXT NOT NULL DEFAULT 'ACTIVE',moderated_by TEXT NOT NULL DEFAULT '',moderated_at TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_posts_feed ON myshop_posts(status,created_at DESC,id DESC)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_posts_user_day ON myshop_posts(user_id,created_at DESC,id DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_post_shares (event_id TEXT PRIMARY KEY,post_id INTEGER NOT NULL,user_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_post_likes (post_id INTEGER NOT NULL,user_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(post_id,user_id))`,
    `CREATE TABLE IF NOT EXISTS myshop_post_comments (id INTEGER PRIMARY KEY AUTOINCREMENT,post_id INTEGER NOT NULL,user_id TEXT NOT NULL,comment TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS managed_links (id INTEGER PRIMARY KEY AUTOINCREMENT,category TEXT NOT NULL,title TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',url TEXT NOT NULL DEFAULT '',icon_url TEXT NOT NULL DEFAULT '',image_url TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,display_order INTEGER NOT NULL DEFAULT 1,price_minor INTEGER NOT NULL DEFAULT 0,offer_text TEXT NOT NULL DEFAULT '',offer_start TEXT NOT NULL DEFAULT '',offer_end TEXT NOT NULL DEFAULT '',time_limit_minutes INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'ACTIVE',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_managed_links_category_order ON managed_links(category,active,display_order,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_visit_history (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,type TEXT NOT NULL DEFAULT 'ITEM',title TEXT NOT NULL DEFAULT '',details TEXT NOT NULL DEFAULT '',ref TEXT NOT NULL DEFAULT '',thumbnail_url TEXT NOT NULL DEFAULT '',action TEXT NOT NULL DEFAULT 'Open',visited_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_visit_history_user_time ON myshop_visit_history(user_id,visited_at DESC,id DESC)`,
    `CREATE TABLE IF NOT EXISTS banner_media (id INTEGER PRIMARY KEY AUTOINCREMENT,folder TEXT NOT NULL,slot INTEGER NOT NULL,object_key TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(folder,slot))`,
    `CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL DEFAULT 'MY SHOP',message TEXT NOT NULL DEFAULT '',audience TEXT NOT NULL DEFAULT 'ALL',user_id TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,type TEXT NOT NULL DEFAULT '',actor_user_id TEXT NOT NULL DEFAULT '',target_id TEXT NOT NULL DEFAULT '',image_url TEXT NOT NULL DEFAULT '',action_url TEXT NOT NULL DEFAULT '',expires_at TEXT NOT NULL DEFAULT '',color_hex TEXT NOT NULL DEFAULT '#FFFFFF',scheduled_at TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'SENT')`,
    `CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at DESC,id DESC)`,
    `CREATE INDEX IF NOT EXISTS idx_notifications_audience_user ON notifications(audience,user_id,created_at DESC)`,
    `CREATE TABLE IF NOT EXISTS notification_reads (notification_id INTEGER NOT NULL,user_id TEXT NOT NULL,read_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(notification_id,user_id))`,
    `CREATE INDEX IF NOT EXISTS idx_notification_reads_user ON notification_reads(user_id,read_at DESC)`,
    `CREATE TABLE IF NOT EXISTS dashboard_config (id INTEGER PRIMARY KEY CHECK(id=1),breaking_news TEXT NOT NULL DEFAULT '',my_shop_url TEXT NOT NULL DEFAULT '',live_tv_url TEXT NOT NULL DEFAULT '',external_movie_url TEXT NOT NULL DEFAULT '',chat_url TEXT NOT NULL DEFAULT '',power_ad_title TEXT NOT NULL DEFAULT 'POWER AD',power_ad_byline TEXT NOT NULL DEFAULT 'by Touhid',dashboard_bg_color TEXT NOT NULL DEFAULT '#07122F',dashboard_blue_color TEXT NOT NULL DEFAULT '#2D72F6',dashboard_purple_color TEXT NOT NULL DEFAULT '#7B3FF2',dashboard_pink_color TEXT NOT NULL DEFAULT '#F02BB7',breaking_news_text_size REAL NOT NULL DEFAULT 13.0,breaking_news_bg_color TEXT NOT NULL DEFAULT '#FFEFF7',breaking_news_text_color TEXT NOT NULL DEFAULT '#414662',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS banners (id INTEGER PRIMARY KEY AUTOINCREMENT,folder TEXT NOT NULL DEFAULT '',slot INTEGER NOT NULL DEFAULT 0,image_url TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',target_url TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,start_at TEXT NOT NULL DEFAULT '',end_at TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(folder,slot))`,
    `CREATE TABLE IF NOT EXISTS myshop_banner_sections (folder TEXT PRIMARY KEY,enabled INTEGER NOT NULL DEFAULT 1,updated_by TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_banner_durations (folder TEXT NOT NULL,slot INTEGER NOT NULL,display_seconds INTEGER NOT NULL DEFAULT 4,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(folder,slot))`,
    `CREATE TABLE IF NOT EXISTS social_links (id INTEGER PRIMARY KEY AUTOINCREMENT,platform TEXT NOT NULL UNIQUE,url TEXT NOT NULL DEFAULT '',icon_key TEXT NOT NULL DEFAULT '',icon_url TEXT NOT NULL DEFAULT '',image_url TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1)`,
    `CREATE TABLE IF NOT EXISTS myshop_live_tv_channels (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,category TEXT NOT NULL DEFAULT 'General',logo_url TEXT NOT NULL DEFAULT '',stream_url TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,published INTEGER NOT NULL DEFAULT 0,display_order INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_coin_wallets (user_id TEXT PRIMARY KEY REFERENCES myshop_auth_users_v108(user_id),balance INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_coin_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id),kind TEXT NOT NULL,amount INTEGER NOT NULL,reference TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'COMPLETED',metadata TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_coin_transactions_user ON myshop_coin_transactions(user_id,created_at,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_coin_purchase_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id),package_coins INTEGER NOT NULL,amount_minor INTEGER NOT NULL,payment_method TEXT NOT NULL,reference TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_coin_purchase_user ON myshop_coin_purchase_requests(user_id,created_at,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_gift_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT,sender_user_id TEXT NOT NULL,receiver_user_id TEXT NOT NULL,coins INTEGER NOT NULL,gift_code TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_gold_wallets (user_id TEXT PRIMARY KEY REFERENCES myshop_auth_users_v108(user_id),balance INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_creator_earnings (user_id TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('COIN','GOLD')),balance INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,currency))`,
    `CREATE TABLE IF NOT EXISTS myshop_creator_withdraw_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('COIN','GOLD')),gross_units INTEGER NOT NULL,service_fee_percent REAL NOT NULL DEFAULT 10,service_fee_units INTEGER NOT NULL,net_units INTEGER NOT NULL,cash_minor INTEGER NOT NULL DEFAULT 0,payment_method TEXT NOT NULL,account TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_creator_withdraw_user ON myshop_creator_withdraw_requests(user_id,currency,status,created_at)`,

    `CREATE TABLE IF NOT EXISTS myshop_gold_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,kind TEXT NOT NULL,amount INTEGER NOT NULL,reference TEXT NOT NULL DEFAULT '',metadata TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_user_badges (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,badge_code TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'ACTIVE',source TEXT NOT NULL DEFAULT 'ADMIN',starts_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,expires_at TEXT,note TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_user_badges_user ON myshop_user_badges(user_id,status,expires_at,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_wallet_purchase_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,item_type TEXT NOT NULL,item_code TEXT NOT NULL,units INTEGER NOT NULL DEFAULT 1,amount_minor INTEGER NOT NULL DEFAULT 0,payment_method TEXT NOT NULL,reference TEXT NOT NULL DEFAULT '',duration TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_store_purchase_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,catalog_id INTEGER NOT NULL,payment_mode TEXT NOT NULL,base_amount INTEGER NOT NULL DEFAULT 0,fee_amount INTEGER NOT NULL DEFAULT 0,total_amount INTEGER NOT NULL DEFAULT 0,payment_method TEXT NOT NULL DEFAULT '',reference TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',approved_by TEXT NOT NULL DEFAULT '',funds_held INTEGER NOT NULL DEFAULT 0,official_held INTEGER NOT NULL DEFAULT 0,payment_state TEXT NOT NULL DEFAULT 'REQUESTED',decision_note TEXT NOT NULL DEFAULT '',approved_at TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_store_purchase_requests_status ON myshop_store_purchase_requests(status,created_at DESC,id DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_store_purchase_events (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,catalog_id INTEGER NOT NULL,event_type TEXT NOT NULL,payment_mode TEXT NOT NULL DEFAULT '',payment_method TEXT NOT NULL DEFAULT '',request_id INTEGER NOT NULL DEFAULT 0,amount INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_store_purchase_events_time ON myshop_store_purchase_events(event_type,created_at DESC,id DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_premium_payment_settings (id INTEGER PRIMARY KEY CHECK(id=1),coin_enabled INTEGER NOT NULL DEFAULT 1,gold_enabled INTEGER NOT NULL DEFAULT 1,cash_enabled INTEGER NOT NULL DEFAULT 0,bkash_enabled INTEGER NOT NULL DEFAULT 0,nagad_enabled INTEGER NOT NULL DEFAULT 0,bkash_number TEXT NOT NULL DEFAULT '',nagad_number TEXT NOT NULL DEFAULT '',instructions TEXT NOT NULL DEFAULT '',reference_required INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_withdraw_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,gold_amount INTEGER NOT NULL,payment_method TEXT NOT NULL,account TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_coin_withdraw_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,coin_amount INTEGER NOT NULL,payment_method TEXT NOT NULL,account TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_owned_items (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,catalog_id INTEGER NOT NULL,item_type TEXT NOT NULL,item_code TEXT NOT NULL,equipped INTEGER NOT NULL DEFAULT 0,expires_at TEXT,source TEXT NOT NULL DEFAULT 'PURCHASE',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(user_id,catalog_id))`,
    `CREATE INDEX IF NOT EXISTS idx_owned_items_user ON myshop_owned_items(user_id,item_type,equipped,created_at)`,
    `CREATE TABLE IF NOT EXISTS myshop_admin_wallet_grants (id INTEGER PRIMARY KEY AUTOINCREMENT,admin_user_id TEXT NOT NULL,target_user_id TEXT NOT NULL,item_type TEXT NOT NULL,item_code TEXT NOT NULL,units INTEGER NOT NULL,days INTEGER NOT NULL DEFAULT 0,note TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_store_catalog (id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT NOT NULL UNIQUE,title TEXT NOT NULL,item_type TEXT NOT NULL,units INTEGER NOT NULL DEFAULT 1,price_minor INTEGER NOT NULL DEFAULT 0,coin_price INTEGER NOT NULL DEFAULT 0,gold_price INTEGER NOT NULL DEFAULT 0,duration_days INTEGER NOT NULL DEFAULT 0,preview_url TEXT NOT NULL DEFAULT '',animation_url TEXT NOT NULL DEFAULT '',animation_mime TEXT NOT NULL DEFAULT '',sound_url TEXT NOT NULL DEFAULT '',sound_volume INTEGER NOT NULL DEFAULT 90,effect_duration_ms INTEGER NOT NULL DEFAULT 3500,sound_duration_ms INTEGER NOT NULL DEFAULT 3000,benefits TEXT NOT NULL DEFAULT '',priority INTEGER NOT NULL DEFAULT 100,limited_edition INTEGER NOT NULL DEFAULT 0,featured INTEGER NOT NULL DEFAULT 0,preview_mode TEXT NOT NULL DEFAULT 'AUTO',animation_speed INTEGER NOT NULL DEFAULT 55,enabled INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_safety_reports (id INTEGER PRIMARY KEY AUTOINCREMENT,reporter_id TEXT NOT NULL,target_user_id TEXT NOT NULL DEFAULT '',content_type TEXT NOT NULL,content_id TEXT NOT NULL DEFAULT '',reason TEXT NOT NULL,details TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'OPEN',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_safety_reports_status ON myshop_safety_reports(status,created_at DESC,id DESC)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_safety_reports_target ON myshop_safety_reports(target_user_id,created_at DESC,id DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_account_deletion_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL DEFAULT '',identifier TEXT NOT NULL DEFAULT '',contact TEXT NOT NULL DEFAULT '',reason TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'OPEN',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_account_deletion_requests_status ON myshop_account_deletion_requests(status,created_at DESC,id DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_play_purchases (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,catalog_id INTEGER NOT NULL,play_product_id TEXT NOT NULL,purchase_token_hash TEXT NOT NULL UNIQUE,order_id TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'VERIFIED',google_payload TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_play_purchases_user ON myshop_play_purchases(user_id,created_at DESC,id DESC)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_store_catalog_order ON myshop_store_catalog(enabled,item_type,priority,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_store_audit (id INTEGER PRIMARY KEY AUTOINCREMENT,admin_user_id TEXT NOT NULL,action TEXT NOT NULL,catalog_id INTEGER,item_code TEXT NOT NULL DEFAULT '',details TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_friend_requests (sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(sender_id,receiver_id),CHECK(sender_id<>receiver_id))`,
    `CREATE INDEX IF NOT EXISTS idx_friend_requests_receiver ON myshop_friend_requests(receiver_id,status,created_at DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_follows (follower_id TEXT NOT NULL,following_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(follower_id,following_id),CHECK(follower_id<>following_id))`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_follows_following ON myshop_follows(following_id,created_at DESC)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_follows_follower ON myshop_follows(follower_id,created_at DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_live_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,viewer_count INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_live_active ON myshop_live_presence(active,last_seen DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_live_seats_dynamic (host_id TEXT NOT NULL,seat_no INTEGER NOT NULL,user_id TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'SPEAKER',muted INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,seat_no),UNIQUE(host_id,user_id),CHECK(seat_no BETWEEN 1 AND 99))`,
    `CREATE TABLE IF NOT EXISTS myshop_live_requests (host_id TEXT NOT NULL,user_id TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,user_id))`,
    `CREATE TABLE IF NOT EXISTS myshop_app_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_app_presence_active ON myshop_app_presence(active,last_seen DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_profile_privacy (user_id TEXT PRIMARY KEY,posts_visibility TEXT NOT NULL DEFAULT 'PUBLIC',media_visibility TEXT NOT NULL DEFAULT 'PUBLIC',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_user_blocks (blocker_id TEXT NOT NULL,blocked_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(blocker_id,blocked_id),CHECK(blocker_id<>blocked_id))`,
    `CREATE TABLE IF NOT EXISTS myshop_schema_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`
  ];
  // V-239 feature-isolated bootstrap: one optional schema failure must never take Feed/Dashboard down.
  for (const sql of statements) {
    try { await env.DB.prepare(sql).run(); }
    catch(e) { console.error('SCHEMA_STATEMENT_FAILED',String(e?.message||e),String(sql).slice(0,96)); }
  }
  try { await env.DB.batch(['hero','promo','live_home'].map(folder=>env.DB.prepare(`INSERT OR IGNORE INTO myshop_banner_sections(folder,enabled) VALUES(?,1)`).bind(folder))); } catch(e) { console.error('BANNER_SECTIONS_SCHEMA_FAILED',String(e?.message||e)); }
  try { await ensureMessageSchema(env); } catch(e) { console.error('MESSAGE_SCHEMA_FAILED',String(e?.message||e)); }
  try { await ensureFriendSchema(env); } catch(e) { console.error('FRIEND_SCHEMA_FAILED',String(e?.message||e)); }
  try { await env.DB.prepare("ALTER TABLE feature_buttons ADD COLUMN icon_size INTEGER NOT NULL DEFAULT 40").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_post_comments ADD COLUMN parent_id INTEGER NOT NULL DEFAULT 0").run(); } catch(_) {}
  try { await env.DB.prepare("CREATE INDEX IF NOT EXISTS idx_post_comments_parent ON myshop_post_comments(post_id,parent_id,id)").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE banners ADD COLUMN start_at TEXT NOT NULL DEFAULT ''").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE banners ADD COLUMN end_at TEXT NOT NULL DEFAULT ''").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_user_badges ADD COLUMN catalog_id INTEGER").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_user_badges ADD COLUMN is_displayed INTEGER NOT NULL DEFAULT 0").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_store_catalog ADD COLUMN play_product_id TEXT NOT NULL DEFAULT ''").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_store_catalog ADD COLUMN gold_price INTEGER NOT NULL DEFAULT 0").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_store_catalog ADD COLUMN featured INTEGER NOT NULL DEFAULT 0").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_store_catalog ADD COLUMN preview_mode TEXT NOT NULL DEFAULT 'AUTO'").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_store_catalog ADD COLUMN animation_speed INTEGER NOT NULL DEFAULT 55").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_store_catalog ADD COLUMN sound_url TEXT NOT NULL DEFAULT ''").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_store_catalog ADD COLUMN sound_volume INTEGER NOT NULL DEFAULT 90").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_store_catalog ADD COLUMN effect_duration_ms INTEGER NOT NULL DEFAULT 3500").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_store_catalog ADD COLUMN sound_duration_ms INTEGER NOT NULL DEFAULT 3000").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_store_purchase_requests ADD COLUMN funds_held INTEGER NOT NULL DEFAULT 0").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_store_purchase_requests ADD COLUMN official_held INTEGER NOT NULL DEFAULT 0").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_store_purchase_requests ADD COLUMN payment_state TEXT NOT NULL DEFAULT 'REQUESTED'").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_store_purchase_requests ADD COLUMN decision_note TEXT NOT NULL DEFAULT ''").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_store_purchase_requests ADD COLUMN approved_at TEXT").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_store_purchase_requests ADD COLUMN vat_percent REAL NOT NULL DEFAULT 0").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_live_comment_assignments ADD COLUMN source TEXT NOT NULL DEFAULT 'ADMIN'").run(); } catch(_) {}
  try { await env.DB.prepare("INSERT OR IGNORE INTO myshop_premium_payment_settings(id,coin_enabled,gold_enabled,cash_enabled,bkash_enabled,nagad_enabled,instructions,reference_required) VALUES(1,0,1,0,0,0,'Diamond only • Hold → Admin Verify → Approve/Reject',0)").run(); } catch(_) {}
  // V-420: clean Premium catalog baseline. Retire all legacy/starter products so Admin can rebuild from zero.
  // Membership identity logic remains supported, but no default product is force-seeded/re-enabled.
  try {
    const clean=await env.DB.prepare(`SELECT value FROM myshop_schema_meta WHERE key='premium_v420_clean_catalog'`).first();
    if(!clean){
      await env.DB.prepare(`UPDATE myshop_store_catalog SET enabled=0,updated_at=CURRENT_TIMESTAMP WHERE item_type NOT IN ('COIN','GOLD')`).run();
      await env.DB.prepare(`INSERT INTO myshop_schema_meta(key,value,updated_at) VALUES('premium_v420_clean_catalog','applied',CURRENT_TIMESTAMP)`).run();
    }
  } catch(e) { console.error('PREMIUM_V420_CLEAN_CATALOG_FAILED',String(e?.message||e)); }
  try { await env.DB.prepare(`INSERT OR IGNORE INTO dashboard_config(id) VALUES(1)`).run(); } catch(e) { console.error('DASHBOARD_SCHEMA_INIT_FAILED',String(e?.message||e)); }
  try { await repairContentSchema(env); } catch(e) { console.error('CONTENT_SCHEMA_REPAIR_FAILED',String(e?.message||e)); }
  try { const bc=(await env.DB.prepare('PRAGMA table_info(banners)').all()).results||[]; if(!bc.some(x=>String(x.name)==='target_url')) await env.DB.prepare("ALTER TABLE banners ADD COLUMN target_url TEXT NOT NULL DEFAULT ''").run(); } catch(e) { console.error('BANNER_TARGET_SCHEMA_FAILED',String(e?.message||e)); }
  try {
    const v412=await env.DB.prepare(`SELECT value FROM myshop_schema_meta WHERE key='premium_v412_gold_only_defaults'`).first();
    if(!v412){
      await env.DB.prepare(`UPDATE myshop_store_catalog SET price_minor=0,coin_price=0,gold_price=CASE WHEN EXISTS(SELECT 1 FROM myshop_store_audit a WHERE a.catalog_id=myshop_store_catalog.id AND a.action IN ('CREATE','UPDATE')) AND gold_price>0 THEN gold_price ELSE 5000 END,duration_days=CASE WHEN EXISTS(SELECT 1 FROM myshop_store_audit a WHERE a.catalog_id=myshop_store_catalog.id AND a.action IN ('CREATE','UPDATE')) AND duration_days>0 THEN duration_days ELSE 30 END,updated_at=CURRENT_TIMESTAMP WHERE item_type NOT IN ('COIN','GOLD')` ).run();
      await env.DB.prepare(`INSERT INTO myshop_schema_meta(key,value,updated_at) VALUES('premium_v412_gold_only_defaults','applied',CURRENT_TIMESTAMP)`).run();
    }
  } catch(e) { console.error('PREMIUM_V412_DEFAULT_MIGRATION_FAILED',String(e?.message||e)); }
  try { await ensureV430MembershipCatalog(env); } catch(e) { console.error('V430_MEMBERSHIP_INSTALL_FAILED',String(e?.message||e)); }
  try { await env.DB.prepare(`INSERT INTO myshop_schema_meta(key,value,updated_at) VALUES('content_schema','239',CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=CURRENT_TIMESTAMP`).run(); } catch(e) { console.error('SCHEMA_META_FAILED',String(e?.message||e)); }
  await ensureRequestNotices(env.DB);
}

async function ensureFriendSchema(env){return schemaOnce(env.DB,'ensureFriendSchema',()=>ensureFriendSchemaImpl(env));}
async function ensureFriendSchemaImpl(env){
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_friend_requests (sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(sender_id,receiver_id),CHECK(sender_id<>receiver_id))`).run();
  const info=(await env.DB.prepare('PRAGMA table_info(myshop_friend_requests)').all()).results||[];
  const cols=new Set(info.map(x=>String(x.name||'')));
  if(!cols.has('status')) await env.DB.prepare("ALTER TABLE myshop_friend_requests ADD COLUMN status TEXT NOT NULL DEFAULT 'PENDING'").run();
  if(!cols.has('created_at')) { await env.DB.prepare("ALTER TABLE myshop_friend_requests ADD COLUMN created_at TEXT NOT NULL DEFAULT ''").run(); await env.DB.prepare("UPDATE myshop_friend_requests SET created_at=CURRENT_TIMESTAMP WHERE created_at=''").run(); }
  if(!cols.has('updated_at')) { await env.DB.prepare("ALTER TABLE myshop_friend_requests ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''").run(); await env.DB.prepare("UPDATE myshop_friend_requests SET updated_at=CURRENT_TIMESTAMP WHERE updated_at=''").run(); }
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_friend_requests_receiver ON myshop_friend_requests(receiver_id,status,created_at DESC)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_user_blocks (blocker_id TEXT NOT NULL,blocked_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(blocker_id,blocked_id),CHECK(blocker_id<>blocked_id))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_follows (follower_id TEXT NOT NULL,following_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(follower_id,following_id),CHECK(follower_id<>following_id))`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_myshop_follows_following ON myshop_follows(following_id,created_at DESC)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_myshop_follows_follower ON myshop_follows(follower_id,created_at DESC)`).run();
}

const MYSHOP_USER_SOCIAL_PLATFORMS=['Facebook','Page','Messenger','WhatsApp','imo','YouTube','TikTok','Telegram','Instagram','X','LinkedIn','Snapchat','Pinterest','Discord','Reddit','Threads','Viber','Signal','Website'];
const MYSHOP_PERSONAL_FIELDS=[['name','Name'],['bio','Bio'],['profile_photo','Profile Photo'],['cover_photo','Cover Photo'],['join_date','Join Date'],['user_id','User ID'],['social_links','Social Links'],['from','From'],['work','Work / Occupation'],['location','Lives In'],['birthday','Birthday'],['relationship','Relationship Status'],['family','Family'],['gender','Gender'],['languages','Languages'],['education','Education'],['contact','Contact Info'],['website','Website'],['interests','Interests'],['other','Other Details']];
async function ensureUserSocialLinksSchema(env){
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_user_social_links (user_id TEXT NOT NULL,platform TEXT NOT NULL,url TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,platform))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_user_social_visibility(user_id TEXT NOT NULL,platform TEXT NOT NULL,visibility TEXT NOT NULL DEFAULT 'PUBLIC',PRIMARY KEY(user_id,platform))`).run();
}
async function ensurePersonalDetailsSchema(env){
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_personal_detail_access(user_id TEXT NOT NULL,field_key TEXT NOT NULL,viewer_id TEXT NOT NULL,PRIMARY KEY(user_id,field_key,viewer_id))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_user_personal_details (user_id TEXT NOT NULL,field_key TEXT NOT NULL,value TEXT NOT NULL DEFAULT '',visibility TEXT NOT NULL DEFAULT 'PUBLIC',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,field_key))`).run();
}
async function myPersonalDetails(request,env){
 const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);await ensurePersonalDetailsSchema(env);
 const rows=(await env.DB.prepare('SELECT field_key,value,visibility FROM myshop_user_personal_details WHERE user_id=?').bind(user.user_id).all()).results||[];
 const grants=(await env.DB.prepare('SELECT field_key,viewer_id FROM myshop_personal_detail_access WHERE user_id=?').bind(user.user_id).all()).results||[];
 const account=await env.DB.prepare('SELECT user_id,full_name,bio,avatar_url,cover_url,created_at FROM myshop_auth_users_v108 WHERE user_id=?').bind(user.user_id).first();
 const liveValues={name:account?.full_name||'',bio:account?.bio||'',profile_photo:account?.avatar_url||'',cover_photo:account?.cover_url||'',join_date:account?.created_at||'',user_id:user.user_id,social_links:'Manage shared social links'};
 const result=[...PROFILE_CORE_KEYS.map(key=>({...rows.find(row=>row.field_key===key),field_key:key,value:liveValues[key],visibility:rows.find(row=>row.field_key===key)?.visibility||'PUBLIC',readOnlyValue:true})),...rows.filter(row=>!PROFILE_CORE_KEYS.includes(row.field_key))];
 for(const row of result)row.allowedUserIds=grants.filter(g=>g.field_key===row.field_key).map(g=>g.viewer_id);
 return json({ok:true,personalDetails:result},200,cors);
}
async function updateMyPersonalDetails(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request),items=b.personalDetails;if(!Array.isArray(items)||items.length>MYSHOP_PERSONAL_FIELDS.length)return json({error:'INVALID_PERSONAL_DETAILS'},400,cors);
  const values=[],access=[],seen=new Set();
  for(const item of items){
    const key=String(item?.field||item?.fieldKey||'').trim().toLowerCase(),field=MYSHOP_PERSONAL_FIELDS.find(x=>x[0]===key);
    if(!field||seen.has(key))return json({error:'INVALID_PERSONAL_DETAIL'},400,cors);seen.add(key);
    const value=PROFILE_CORE_KEYS.includes(key)?'configured':String(item?.value||'').trim().slice(0,250),raw=String(item?.visibility||'PUBLIC').trim().toUpperCase(),visibility=raw==='ONLY ME'||raw==='PRIVATE'?'ONLY_ME':raw;
    if(!['PUBLIC','FRIENDS','ONLY_ME','CUSTOM'].includes(visibility))return json({error:'INVALID_PERSONAL_DETAIL_PRIVACY'},400,cors);
    let viewers=[];
    if(visibility==='CUSTOM'){
      if(!Array.isArray(item.allowedUserIds)||item.allowedUserIds.length>50||item.allowedUserIds.some(id=>!/^\d{4}$/.test(String(id))))return json({error:'INVALID_CUSTOM_AUDIENCE'},400,cors);
      viewers=[...new Set(item.allowedUserIds.map(String))];
    }
    if(value){values.push([key,value,visibility,viewers]);for(const id of viewers)access.push([user.user_id,key,id]);}
  }
  await ensurePersonalDetailsSchema(env);
  const coreMarks=PROFILE_CORE_KEYS.map(()=>'?').join(','),changedCore=values.filter(row=>PROFILE_CORE_KEYS.includes(row[0])).map(row=>row[0]);
  const writes=[env.DB.prepare(`DELETE FROM myshop_user_personal_details WHERE user_id=? AND field_key NOT IN (${coreMarks})`).bind(user.user_id,...PROFILE_CORE_KEYS),env.DB.prepare(`DELETE FROM myshop_personal_detail_access WHERE user_id=? AND field_key NOT IN (${coreMarks})`).bind(user.user_id,...PROFILE_CORE_KEYS)];
  for(const key of changedCore){writes.push(env.DB.prepare('DELETE FROM myshop_user_personal_details WHERE user_id=? AND field_key=?').bind(user.user_id,key),env.DB.prepare('DELETE FROM myshop_personal_detail_access WHERE user_id=? AND field_key=?').bind(user.user_id,key));}
  writes.push(...values.map(([key,value,visibility])=>env.DB.prepare('INSERT INTO myshop_user_personal_details(user_id,field_key,value,visibility,updated_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)').bind(user.user_id,key,value,visibility)),...access.map(row=>env.DB.prepare('INSERT INTO myshop_personal_detail_access(user_id,field_key,viewer_id) VALUES(?,?,?)').bind(...row)));
  await env.DB.batch(writes);
  return json({ok:true,personalDetails:values.map(([field_key,value,visibility,allowedUserIds])=>({field_key,value,visibility,allowedUserIds}))},200,cors);
}
async function userSocialLinksGet(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);await ensureUserSocialLinksSchema(env);
  const rows=(await env.DB.prepare(`SELECT platform,url FROM myshop_user_social_links WHERE user_id=? ORDER BY CASE platform WHEN 'Facebook' THEN 1 WHEN 'Page' THEN 2 WHEN 'Messenger' THEN 3 WHEN 'WhatsApp' THEN 4 WHEN 'imo' THEN 5 WHEN 'YouTube' THEN 6 WHEN 'TikTok' THEN 7 WHEN 'Telegram' THEN 8 ELSE 99 END`).bind(user.user_id).all()).results||[];
  const privacy=(await env.DB.prepare('SELECT platform,visibility FROM myshop_user_social_visibility WHERE user_id=?').bind(user.user_id).all()).results||[];
  return json({ok:true,socialLinks:rows.map(x=>({...x,visibility:privacy.find(p=>p.platform===x.platform)?.visibility||'PUBLIC'}))},200,cors);
}
async function userSocialLinksPut(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);const b=await body(request),items=b.socialLinks;
  if(!Array.isArray(items))return json({error:'INVALID_SOCIAL_LINKS'},400,cors);
  if(items.length>50)return json({error:'TOO_MANY_SOCIAL_LINKS'},400,cors);
  const values=[],seen=new Set();
  for(const item of items){
    const label=String(item?.platform||'').trim(),platform=MYSHOP_USER_SOCIAL_PLATFORMS.find(x=>x.toLowerCase()===label.toLowerCase())||label,key=platform.toLowerCase();
    if(!/^[\p{L}\p{N} ._-]{1,40}$/u.test(platform)||seen.has(key))return json({error:'INVALID_SOCIAL_PLATFORM'},400,cors);seen.add(key);
    const url=normalizeUserSocialUrl(item?.url,platform);if(url===null)return json({error:'INVALID_SOCIAL_URL',platform},400,cors);
    const visibility=item.visibility==null?null:String(item.visibility).trim().toUpperCase().replace('ONLY ME','ONLY_ME');
    if(visibility!==null&&!['PUBLIC','FRIENDS','ONLY_ME'].includes(visibility))return json({error:'INVALID_SOCIAL_PRIVACY'},400,cors);
    if(url)values.push([platform,url,visibility]);
  }
  await ensureUserSocialLinksSchema(env);
  const previous=(await env.DB.prepare('SELECT platform,visibility FROM myshop_user_social_visibility WHERE user_id=?').bind(user.user_id).all()).results||[];
  const statements=[env.DB.prepare('DELETE FROM myshop_user_social_links WHERE user_id=?').bind(user.user_id),env.DB.prepare('DELETE FROM myshop_user_social_visibility WHERE user_id=?').bind(user.user_id)];
  for(const [platform,url,requested] of values){const visibility=requested||previous.find(x=>x.platform.toLowerCase()===platform.toLowerCase())?.visibility||'PUBLIC';statements.push(env.DB.prepare('INSERT INTO myshop_user_social_links(user_id,platform,url,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP)').bind(user.user_id,platform,url),env.DB.prepare('INSERT INTO myshop_user_social_visibility(user_id,platform,visibility) VALUES(?,?,?)').bind(user.user_id,platform,visibility));}
  await env.DB.batch(statements);return json({ok:true},200,cors);
}

async function ensureMessageSchema(env){
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_messages (id INTEGER PRIMARY KEY AUTOINCREMENT,sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL,message TEXT NOT NULL DEFAULT '',read_at TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,CHECK(sender_id<>receiver_id))`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_myshop_messages_pair ON myshop_messages(sender_id,receiver_id,id DESC)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_myshop_messages_receiver_unread ON myshop_messages(receiver_id,read_at,id DESC)`).run();
  for(const sql of [`ALTER TABLE myshop_messages ADD COLUMN delivered_at TEXT`,`ALTER TABLE myshop_messages ADD COLUMN client_nonce TEXT NOT NULL DEFAULT ''`,`ALTER TABLE myshop_messages ADD COLUMN hidden_from_sender INTEGER NOT NULL DEFAULT 0`,`ALTER TABLE myshop_messages ADD COLUMN hidden_from_receiver INTEGER NOT NULL DEFAULT 0`,`ALTER TABLE myshop_messages ADD COLUMN media_url TEXT NOT NULL DEFAULT ''`,`ALTER TABLE myshop_messages ADD COLUMN media_type TEXT NOT NULL DEFAULT ''`]){try{await env.DB.prepare(sql).run();}catch(e){}}
  await env.DB.prepare(`CREATE UNIQUE INDEX IF NOT EXISTS idx_message_send_nonce ON myshop_messages(sender_id,client_nonce) WHERE client_nonce<>''`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_message_typing(sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL,active INTEGER NOT NULL,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(sender_id,receiver_id))`).run();
}

const schemaInitByEnv = new WeakMap();
const bannerRowsSchemaInitByEnv = new WeakMap();

async function ensureBannerRowsSchema(env){
  if(!env?.DB)throw new Error('D1_NOT_CONFIGURED');
  let pending=bannerRowsSchemaInitByEnv.get(env.DB);
  if(!pending){
    pending=(async()=>{
      await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_banner_sections (folder TEXT PRIMARY KEY,enabled INTEGER NOT NULL DEFAULT 1,updated_by TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
      await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_banner_durations (folder TEXT NOT NULL,slot INTEGER NOT NULL,display_seconds INTEGER NOT NULL DEFAULT 4,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(folder,slot))`).run();
      await env.DB.batch(['hero','promo','live_home'].map(folder=>env.DB.prepare(`INSERT OR IGNORE INTO myshop_banner_sections(folder,enabled) VALUES(?,1)`).bind(folder)));
    })().catch(e=>{bannerRowsSchemaInitByEnv.delete(env.DB);throw e;});
    bannerRowsSchemaInitByEnv.set(env.DB,pending);
  }
  return pending;
}

async function ensureSchemasOnce(env){
  let p=schemaInitByEnv.get(env.DB);
  if(!p){
    p=(async()=>{
      await ensureAuthSchema(env);
      await ensureContentSchema(env);
    })().catch(e=>{ schemaInitByEnv.delete(env.DB); throw e; });
    schemaInitByEnv.set(env.DB,p);
  }
  return p;
}

async function ensureNotificationSchema(env){return schemaOnce(env.DB,'ensureNotificationSchema',()=>ensureNotificationSchemaImpl(env));}
async function ensureNotificationSchemaImpl(env){
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL DEFAULT 'MY SHOP',message TEXT NOT NULL DEFAULT '',audience TEXT NOT NULL DEFAULT 'ALL',user_id TEXT NOT NULL DEFAULT '',type TEXT NOT NULL DEFAULT '',actor_user_id TEXT NOT NULL DEFAULT '',target_id TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  const info=(await env.DB.prepare('PRAGMA table_info(notifications)').all()).results||[];
  const cols=new Set(info.map(x=>String(x.name||'')));
  if(!cols.has('type')) await env.DB.prepare("ALTER TABLE notifications ADD COLUMN type TEXT NOT NULL DEFAULT ''").run();
  if(!cols.has('actor_user_id')) await env.DB.prepare("ALTER TABLE notifications ADD COLUMN actor_user_id TEXT NOT NULL DEFAULT ''").run();
  if(!cols.has('target_id')) await env.DB.prepare("ALTER TABLE notifications ADD COLUMN target_id TEXT NOT NULL DEFAULT ''").run();
  if(!cols.has('image_url')) await env.DB.prepare("ALTER TABLE notifications ADD COLUMN image_url TEXT NOT NULL DEFAULT ''").run();
  if(!cols.has('action_url')) await env.DB.prepare("ALTER TABLE notifications ADD COLUMN action_url TEXT NOT NULL DEFAULT ''").run();
  if(!cols.has('expires_at')) await env.DB.prepare("ALTER TABLE notifications ADD COLUMN expires_at TEXT NOT NULL DEFAULT ''").run();
  if(!cols.has('color_hex')) await env.DB.prepare("ALTER TABLE notifications ADD COLUMN color_hex TEXT NOT NULL DEFAULT '#FFFFFF'").run();
  if(!cols.has('scheduled_at')) await env.DB.prepare("ALTER TABLE notifications ADD COLUMN scheduled_at TEXT NOT NULL DEFAULT ''").run();
  if(!cols.has('status')) await env.DB.prepare("ALTER TABLE notifications ADD COLUMN status TEXT NOT NULL DEFAULT 'SENT'").run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at DESC,id DESC)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_notifications_audience_user ON notifications(audience,user_id,created_at DESC)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS notification_reads (notification_id INTEGER NOT NULL,user_id TEXT NOT NULL,read_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(notification_id,user_id))`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_notification_reads_user ON notification_reads(user_id,read_at DESC)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_push_tokens (user_id TEXT NOT NULL,token TEXT NOT NULL,platform TEXT NOT NULL DEFAULT 'ANDROID',active INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,token))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_push_delivery_log(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,type TEXT NOT NULL DEFAULT '',status TEXT NOT NULL,detail TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_notification_preferences(user_id TEXT PRIMARY KEY,messages INTEGER NOT NULL DEFAULT 1,live INTEGER NOT NULL DEFAULT 1,promo INTEGER NOT NULL DEFAULT 1)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_push_tokens_user ON myshop_push_tokens(user_id,active,updated_at DESC)`).run();
}

let fcmAccessCache={token:'',expiresAt:0,identity:''};
function fcmB64urlBytes(bytes){let s='';for(const b of bytes)s+=String.fromCharCode(b);return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function fcmB64urlText(s){return fcmB64urlBytes(new TextEncoder().encode(s));}
function fcmPemPkcs8(pem){const raw=String(pem||'').replace(/-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----|\s+/g,'');const bin=atob(raw);const a=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);return a.buffer;}
async function fcmAccessToken(env){
  const raw=String(env.FCM_SERVICE_ACCOUNT_JSON||'').trim();if(!raw)return null;if(fcmAccessCache.identity===raw&&fcmAccessCache.token&&Date.now()<fcmAccessCache.expiresAt-60000)return fcmAccessCache.token;
  let sa;try{sa=JSON.parse(raw);}catch(e){console.error('FCM_SERVICE_ACCOUNT_JSON_INVALID');return null;}if(!sa.client_email||!sa.private_key||!sa.project_id)return null;
  const now=Math.floor(Date.now()/1000),header=fcmB64urlText(JSON.stringify({alg:'RS256',typ:'JWT'})),payload=fcmB64urlText(JSON.stringify({iss:sa.client_email,scope:'https://www.googleapis.com/auth/firebase.messaging',aud:'https://oauth2.googleapis.com/token',iat:now,exp:now+3300}));
  const key=await crypto.subtle.importKey('pkcs8',fcmPemPkcs8(sa.private_key),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['sign']);
  const sig=new Uint8Array(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',key,new TextEncoder().encode(header+'.'+payload)));const assertion=header+'.'+payload+'.'+fcmB64urlBytes(sig);
  const r=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion})});if(!r.ok)throw new Error('FCM_OAUTH_'+r.status);const j=await r.json();fcmAccessCache={identity:raw,token:String(j.access_token||''),expiresAt:Date.now()+Number(j.expires_in||3000)*1000};return fcmAccessCache.token||null;
}
async function sendPushToUser(env,userId,title,message,type='',actorUserId='',targetId='',notificationId=''){
  try{
    await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_push_delivery_log(
      id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,type TEXT NOT NULL DEFAULT '',status TEXT NOT NULL,detail TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )`).run();
    await ensureNotificationSchema(env);const prefs=await env.DB.prepare(`SELECT messages,live,promo FROM myshop_notification_preferences WHERE user_id=?`).bind(String(userId)).first();const group=String(type)==='MESSAGE'?'messages':String(type).startsWith('LIVE_')?'live':'promo';if(type!=='TEST_PUSH'&&Number(prefs?.[group]??1)!==1)return false;
    const access=await fcmAccessToken(env);if(!access){await env.DB.prepare(`INSERT INTO myshop_push_delivery_log(user_id,type,status,detail) VALUES(?,?,?,?)`).bind(String(userId),String(type||''),'FAILED','FCM_SERVER_NOT_CONFIGURED').run();return false;}let sa;try{sa=JSON.parse(String(env.FCM_SERVICE_ACCOUNT_JSON||''));}catch(e){return false;}
    const rows=(await env.DB.prepare(`SELECT token FROM myshop_push_tokens WHERE user_id=? AND active=1 ORDER BY datetime(updated_at) DESC LIMIT 8`).bind(String(userId)).all()).results||[];if(!rows.length){await env.DB.prepare(`INSERT INTO myshop_push_delivery_log(user_id,type,status,detail) VALUES(?,?,?,?)`).bind(String(userId),String(type||''),'FAILED','NO_ACTIVE_DEVICE_TOKEN').run();return false;}
    let actorName='',actorAvatarUrl='';if(String(actorUserId||'')){const a=await env.DB.prepare(`SELECT COALESCE(full_name,'') full_name,COALESCE(avatar_url,'') avatar_url FROM myshop_auth_users_v108 WHERE user_id=?`).bind(String(actorUserId)).first();actorName=String(a?.full_name||'');actorAvatarUrl=String(a?.avatar_url||'');}
    const displayTitle=String(type)==='MESSAGE'?(actorName||'MY SHOP'):String(title||'MY SHOP');const bodyText=String(type)==='MESSAGE'?String(message||''):String(message||'');
    // Badge metadata is optional: a lookup failure must never block existing push delivery.
    let eventId=String(notificationId||'');
    if(!eventId&&['MESSAGE','FRIEND_REQUEST','LIVE_START'].includes(String(type))){
      try{const event=await env.DB.prepare('SELECT id FROM notifications WHERE user_id=? AND type=? AND actor_user_id=? AND target_id=? ORDER BY id DESC LIMIT 1').bind(String(userId),String(type),String(actorUserId),String(targetId)).first();if(event)eventId=String(event.id);}catch(_){}
    }
    let sent=0;
    for(const row of rows){
      const channel=String(type)==='MESSAGE'?'myshop_messages_v2':(String(type).startsWith('LIVE_')?'myshop_live_alerts_v1':'myshop_general');
      // Use high-priority data-only delivery so MyShopMessagingService receives pushes
      // while backgrounded and owns a PendingIntent to the exact Chat/Live destination.
      // A notification payload plus an unregistered click_action bypassed this service
      // and could leave the app opening generically (or no matching Activity at all).
      const payload={message:{token:String(row.token),notification:{title:displayTitle,body:bodyText},data:{title:displayTitle,body:bodyText,type:String(type||''),actorUserId:String(actorUserId||''),targetId:String(targetId||''),actorAvatarUrl,channel,recipientUserId:String(userId)},android:{priority:'high',ttl:String(type).startsWith('LIVE_')?'300s':'86400s',notification:{channel_id:channel,icon:'ic_myshop_notification',default_sound:true,default_vibrate_timings:true}}}};
      attachPushBadge(payload,userId,type,eventId);
      const r=await fetch(`https://fcm.googleapis.com/v1/projects/${encodeURIComponent(sa.project_id)}/messages:send`,{method:'POST',headers:{authorization:'Bearer '+access,'content-type':'application/json'},body:JSON.stringify(payload)});
      if(!r.ok){const tx=await r.text();if(r.status===404||tx.includes('UNREGISTERED'))await env.DB.prepare(`UPDATE myshop_push_tokens SET active=0,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND token=?`).bind(String(userId),String(row.token)).run();await env.DB.prepare(`INSERT INTO myshop_push_delivery_log(user_id,type,status,detail) VALUES(?,?,?,?)`).bind(String(userId),String(type||''),'FAILED',('FCM_'+r.status+' '+tx).slice(0,500)).run();console.error('FCM_SEND_FAILED',r.status,tx.slice(0,180));}else{sent++;await env.DB.prepare(`INSERT INTO myshop_push_delivery_log(user_id,type,status,detail) VALUES(?,?,?,?)`).bind(String(userId),String(type||''),'SENT','FCM_ACCEPTED').run();}
    }
    return sent>0;
  }catch(e){const detail=String(e?.message||'FCM_TRANSPORT_FAILED').startsWith('FCM_OAUTH_')?String(e.message):'FCM_TRANSPORT_OR_CREDENTIAL_ERROR';try{await env.DB.prepare(`INSERT INTO myshop_push_delivery_log(user_id,type,status,detail) VALUES(?,?,?,?)`).bind(String(userId),String(type||''),'FAILED',detail).run();}catch(ignored){}console.error('FCM_PUSH_FAILED',detail);return false;}
}
async function notificationPreferences(request,env){
 const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureNotificationSchema(env);
 await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_notification_preferences(user_id TEXT PRIMARY KEY,messages INTEGER NOT NULL DEFAULT 1,live INTEGER NOT NULL DEFAULT 1,promo INTEGER NOT NULL DEFAULT 1)`).run();
 if(request.method==='POST'){const b=await body(request);if(['messages','live','promo'].some(k=>typeof b[k]!=='boolean'))return json({error:'INVALID_PREFERENCES'},400,cors);await env.DB.prepare(`INSERT INTO myshop_notification_preferences(user_id,messages,live,promo) VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET messages=excluded.messages,live=excluded.live,promo=excluded.promo`).bind(me.user_id,b.messages?1:0,b.live?1:0,b.promo?1:0).run();}
 const p=await env.DB.prepare(`SELECT messages,live,promo FROM myshop_notification_preferences WHERE user_id=?`).bind(me.user_id).first();return json({ok:true,messages:Number(p?.messages??1)===1,live:Number(p?.live??1)===1,promo:Number(p?.promo??1)===1},200,cors);
}
async function pushDiagnostics(request,env){
 const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureNotificationSchema(env);let sa=null;try{sa=JSON.parse(String(env.FCM_SERVICE_ACCOUNT_JSON||''));}catch(e){}
 const configured=!!(sa?.project_id&&sa?.client_email&&String(sa?.private_key||'').includes('BEGIN PRIVATE KEY')),deviceCount=Number((await env.DB.prepare(`SELECT COUNT(*) n FROM myshop_push_tokens WHERE user_id=? AND active=1`).bind(me.user_id).first())?.n||0);
 const rows=(await env.DB.prepare(`SELECT type,status,CASE WHEN status='SENT' THEN 'FCM accepted' WHEN detail LIKE 'FCM_SERVER_NOT_CONFIGURED%' THEN 'Server Firebase connection missing' WHEN detail LIKE 'NO_ACTIVE_DEVICE_TOKEN%' THEN 'Device token missing' ELSE 'Provider rejected delivery; review Admin server logs' END reason,created_at FROM myshop_push_delivery_log WHERE user_id=? ORDER BY id DESC LIMIT 5`).bind(me.user_id).all()).results||[];
 return json({ok:true,serverConfigured:configured,serverProject:configured?String(sa.project_id):'',activeDeviceCount:deviceCount,deliveries:rows},200,cors);
}
// V575 recovery: these routes existed in V573 but their handlers were missing.
async function messageInbox(request,env){
  await ensureMessageSchema(env);
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_app_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  try{await env.DB.prepare(`ALTER TABLE myshop_app_presence ADD COLUMN visible INTEGER NOT NULL DEFAULT 1`).run();}catch(_){}
  await env.DB.prepare(`UPDATE myshop_messages SET delivered_at=COALESCE(delivered_at,CURRENT_TIMESTAMP) WHERE receiver_id=? AND delivered_at IS NULL`).bind(user.user_id).run();
  await env.DB.prepare(`UPDATE myshop_app_presence SET active=0 WHERE active=1 AND datetime(last_seen)<datetime('now','-30 seconds')`).run();
  const rows=(await env.DB.prepare(`SELECT u.user_id,u.full_name,u.avatar_url,
    (SELECT CASE WHEN m.media_type='AUDIO' THEN '🎙 Voice message' ELSE m.message END FROM myshop_messages m WHERE (((m.sender_id=? AND m.receiver_id=u.user_id) AND COALESCE(m.hidden_from_sender,0)=0) OR ((m.sender_id=u.user_id AND m.receiver_id=?) AND COALESCE(m.hidden_from_receiver,0)=0)) ORDER BY m.id DESC LIMIT 1) last_message,
    (SELECT m.created_at FROM myshop_messages m WHERE (((m.sender_id=? AND m.receiver_id=u.user_id) AND COALESCE(m.hidden_from_sender,0)=0) OR ((m.sender_id=u.user_id AND m.receiver_id=?) AND COALESCE(m.hidden_from_receiver,0)=0)) ORDER BY m.id DESC LIMIT 1) last_at,
    (SELECT COUNT(*) FROM myshop_messages m WHERE m.sender_id=u.user_id AND m.receiver_id=? AND m.read_at IS NULL AND COALESCE(m.hidden_from_receiver,0)=0) unread,
    CASE WHEN EXISTS(SELECT 1 FROM myshop_app_presence ap WHERE ap.user_id=u.user_id AND COALESCE(ap.visible,1)=1 AND ap.active=1 AND datetime(ap.last_seen)>=datetime('now','-30 seconds')) THEN 1 ELSE 0 END online
    FROM myshop_auth_users_v108 u WHERE u.active=1 AND u.user_id<>? AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=u.user_id) OR (b.blocker_id=u.user_id AND b.blocked_id=?)) AND EXISTS(SELECT 1 FROM myshop_messages mm WHERE (mm.sender_id=? AND mm.receiver_id=u.user_id AND COALESCE(mm.hidden_from_sender,0)=0) OR (mm.sender_id=u.user_id AND mm.receiver_id=? AND COALESCE(mm.hidden_from_receiver,0)=0))
    ORDER BY datetime(last_at) DESC LIMIT 100`).bind(user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,user.user_id).all()).results||[];
  const total=rows.reduce((n,x)=>n+Number(x.unread||0),0);
  return json({ok:true,unreadCount:total,conversations:rows.map(x=>({userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',lastMessage:x.last_message||'',lastAt:x.last_at||'',unread:Number(x.unread||0),online:Number(x.online||0)===1}))},200,cors);
}

async function messageThread(request,env){
  await ensureMessageSchema(env);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_app_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();try{await env.DB.prepare(`ALTER TABLE myshop_app_presence ADD COLUMN visible INTEGER NOT NULL DEFAULT 1`).run();}catch(_){}
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const peer=String(new URL(request.url).searchParams.get('userId')||'').trim(); if(!isFourDigit(peer)||peer===user.user_id)return json({error:'INVALID_USER_ID'},400,cors);
  const p=await env.DB.prepare('SELECT user_id,full_name,avatar_url FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(peer).first(); if(!p)return json({error:'USER_NOT_FOUND'},404,cors);
  if(await safetyIsBlocked(env,user.user_id,peer))return json({error:'BLOCKED_USER'},403,cors);
  await env.DB.prepare(`UPDATE myshop_app_presence SET active=0 WHERE active=1 AND datetime(last_seen)<datetime('now','-30 seconds')`).run();
  const presence=await env.DB.prepare(`SELECT active,COALESCE(visible,1) visible,last_seen FROM myshop_app_presence WHERE user_id=?`).bind(peer).first();const online=Number(presence?.active||0)===1&&Number(presence?.visible??1)===1&&!!presence?.last_seen&&!!(await env.DB.prepare(`SELECT datetime(?)>=datetime('now','-30 seconds') fresh`).bind(presence.last_seen).first())?.fresh;
  await env.DB.prepare('UPDATE myshop_messages SET delivered_at=COALESCE(delivered_at,CURRENT_TIMESTAMP),read_at=CURRENT_TIMESTAMP WHERE sender_id=? AND receiver_id=? AND read_at IS NULL AND COALESCE(hidden_from_receiver,0)=0').bind(peer,user.user_id).run();
  try { await ensureNotificationSchema(env); await env.DB.prepare(`INSERT OR IGNORE INTO notification_reads(notification_id,user_id,read_at) SELECT n.id,?,CURRENT_TIMESTAMP FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? WHERE n.audience='USER' AND n.user_id=? AND n.type='MESSAGE' AND n.actor_user_id=? AND r.notification_id IS NULL`).bind(user.user_id,user.user_id,user.user_id,peer).run(); } catch(e) { console.error('MESSAGE_NOTIFICATION_READ_SYNC_FAILED',String(e?.message||e)); }
  const rows=(await env.DB.prepare(`SELECT id,sender_id,receiver_id,message,media_url,media_type,delivered_at,read_at,created_at FROM myshop_messages WHERE ((sender_id=? AND receiver_id=? AND COALESCE(hidden_from_sender,0)=0) OR (sender_id=? AND receiver_id=? AND COALESCE(hidden_from_receiver,0)=0)) ORDER BY id DESC LIMIT 100`).bind(user.user_id,peer,peer,user.user_id).all()).results||[];
  const typing=Number((await env.DB.prepare(`SELECT active FROM myshop_message_typing WHERE sender_id=? AND receiver_id=? AND active=1 AND datetime(last_seen)>=datetime('now','-6 seconds')`).bind(peer,user.user_id).first())?.active||0)===1;
  rows.reverse(); return json({ok:true,typing,peer:{userId:p.user_id,name:p.full_name||'MY SHOP User',avatarUrl:p.avatar_url||'',online,lastSeen:Number(presence?.visible??1)===1?(presence?.last_seen||''):'',activeStatusVisible:Number(presence?.visible??1)===1},messages:rows.map(x=>({id:x.id,senderId:x.sender_id,receiverId:x.receiver_id,message:x.message,mediaUrl:x.media_url||'',mediaType:x.media_type||'',deliveredAt:x.delivered_at||'',readAt:x.read_at||'',createdAt:x.created_at}))},200,cors);
}

async function messageMediaUpload(request,env){
 await ensureMessageSchema(env);const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!env.MEDIA)return json({error:'R2_NOT_CONFIGURED'},503,cors);
 const form=await request.formData(),file=form.get('file');if(!(file instanceof File)||file.size===0)return json({error:'FILE_REQUIRED'},400,cors);
 const ct=guessContentType(file),kind=ct.startsWith('image/')?'IMAGE':ct.startsWith('video/')?'VIDEO':ct.startsWith('audio/')?'AUDIO':'FILE';
 const permitted=kind!=='FILE'||['application/pdf','text/plain','application/vnd.openxmlformats-officedocument.wordprocessingml.document'].includes(ct);
 if(!permitted)return json({error:'UNSUPPORTED_MESSAGE_FILE'},400,cors);if(file.size>20*1024*1024)return json({error:'MESSAGE_FILE_TOO_LARGE'},413,cors);
 const key=`messages/media/${me.user_id}/${crypto.randomUUID()}`;
 await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:ct,cacheControl:'private, no-store'},customMetadata:{owner:me.user_id}});
 return json({ok:true,url:new URL('/v1/media/'+encodeURIComponent(key),request.url).toString(),mediaType:kind,name:String(file.name||'File').slice(0,160)},201,cors);
}

async function messageVoiceUpload(request,env){
  await ensureMessageSchema(env);const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);if(!env.MEDIA)return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(),file=form.get('file');if(!(file instanceof File))return json({error:'FILE_REQUIRED'},400,cors);const ct=guessContentType(file);if(!ct.startsWith('audio/'))return json({error:'VOICE_AUDIO_REQUIRED'},400,cors);if(file.size>5*1024*1024)return json({error:'VOICE_TOO_LARGE'},413,cors);
  const ext=(String(file.name||'voice.m4a').split('.').pop()||'m4a').replace(/[^a-zA-Z0-9]/g,'').slice(0,8)||'m4a',key=`messages/voice/${user.user_id}/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:ct,cacheControl:'private, no-store'},customMetadata:{owner:user.user_id}});const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();return json({ok:true,url,mediaType:'AUDIO'},201,cors);
}

async function messageSend(request,env,ctx){
  await ensureMessageSchema(env);
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors); const b=await body(request); const peer=String(b.userId||'').trim(); const msg=String(b.message||'').trim().slice(0,4000),mediaUrl=String(b.mediaUrl||'').trim().slice(0,1000),mediaType=String(b.mediaType||'').trim().toUpperCase();
  if(!isFourDigit(peer)||peer===user.user_id||(!msg&&!mediaUrl)||(!['','AUDIO','IMAGE','VIDEO','FILE'].includes(mediaType))||(mediaUrl&&!/^https:\/\//i.test(mediaUrl)))return json({error:'INVALID_MESSAGE'},400,cors);
  if(['AUDIO','IMAGE','VIDEO','FILE'].includes(mediaType)){let key='';try{const u=new URL(mediaUrl);if(u.origin!==new URL(request.url).origin)return json({error:'INVALID_MEDIA_ORIGIN'},400,cors);key=decodeURIComponent(u.pathname.slice('/v1/media/'.length));}catch(e){return json({error:'INVALID_MEDIA_URL'},400,cors);}if(!(key.startsWith('messages/media/'+user.user_id+'/')||mediaType==='AUDIO'&&key.startsWith('messages/voice/'+user.user_id+'/'))||!await env.MEDIA?.head(key))return json({error:'MEDIA_NOT_OWNED'},403,cors);}
  const p=await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(peer).first(); if(!p)return json({error:'USER_NOT_FOUND'},404,cors);
  if(await safetyIsBlocked(env,user.user_id,peer))return json({error:'BLOCKED_USER'},403,cors);
  const nonce=String(b.clientNonce||'').trim().slice(0,80);const sameMessage=prior=>prior.receiver_id===peer&&prior.message===msg&&String(prior.media_url||'')===mediaUrl&&String(prior.media_type||'')===mediaType;if(nonce){const prior=await env.DB.prepare(`SELECT id,receiver_id,message,media_url,media_type FROM myshop_messages WHERE sender_id=? AND client_nonce=?`).bind(user.user_id,nonce).first();if(prior)return sameMessage(prior)?json({ok:true,id:prior.id,duplicateSuppressed:true},200,cors):json({error:'MESSAGE_NONCE_CONFLICT'},409,cors);}
  let r;try{r=await env.DB.prepare(`INSERT INTO myshop_messages(sender_id,receiver_id,message,media_url,media_type,client_nonce) VALUES(?,?,?,?,?,?)`).bind(user.user_id,peer,msg,mediaUrl,mediaType,nonce).run();}catch(e){const prior=nonce?await env.DB.prepare(`SELECT id,receiver_id,message,media_url,media_type FROM myshop_messages WHERE sender_id=? AND client_nonce=?`).bind(user.user_id,nonce).first():null;if(prior)return sameMessage(prior)?json({ok:true,id:prior.id,duplicateSuppressed:true},200,cors):json({error:'MESSAGE_NONCE_CONFLICT'},409,cors);throw e;}
  await createUserNotification(env,peer,(user.full_name||('User '+user.user_id)),(mediaType==='AUDIO'?'Voice message':mediaType==='IMAGE'?'Photo':mediaType==='VIDEO'?'Video':mediaType==='FILE'?'File':msg.slice(0,160)),'MESSAGE',user.user_id,user.user_id,ctx);
  return json({ok:true,id:r.meta?.last_row_id||null},201,cors);
}

async function messageDeleteForMe(request,env){
  await ensureMessageSchema(env);const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);const b=await body(request),id=Number(b.messageId||0);const m=await env.DB.prepare(`SELECT sender_id,receiver_id FROM myshop_messages WHERE id=?`).bind(id).first();if(!m||![m.sender_id,m.receiver_id].includes(me.user_id))return json({error:'MESSAGE_NOT_FOUND'},404,cors);if(m.sender_id===me.user_id)await env.DB.prepare(`UPDATE myshop_messages SET hidden_from_sender=1 WHERE id=?`).bind(id).run();else await env.DB.prepare(`UPDATE myshop_messages SET hidden_from_receiver=1 WHERE id=?`).bind(id).run();return json({ok:true,hiddenForUser:true,adminArchiveRetained:true},200,cors);
}

async function messageUnread(request,env){
  await ensureMessageSchema(env); const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors); const r=await env.DB.prepare('SELECT COUNT(*) AS c FROM myshop_messages WHERE receiver_id=? AND read_at IS NULL AND COALESCE(hidden_from_receiver,0)=0').bind(user.user_id).first(); return json({ok:true,unreadCount:Number(r?.c||0)},200,cors); }

async function mediaGet(request,env,key) {
  if(!env.MEDIA) return new Response('R2 not configured',{status:503,headers:cors});
  if(await mediaWasDeleted(env.DB,key))return new Response('Not found',{status:404,headers:{...cors,'Cache-Control':'no-store'}});
  const head=await env.MEDIA.head(key); if(!head) return new Response('Not found',{status:404,headers:cors});
  if(key.startsWith('messages/media/')||key.startsWith('messages/voice/')){
    const me=await getUser(request,env);if(!me)return new Response('Unauthorized',{status:401,headers:cors});
    if(head.customMetadata?.owner!==me.user_id){await ensureMessageSchema(env);const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();const allowed=await env.DB.prepare(`SELECT id FROM myshop_messages WHERE media_url=? AND (sender_id=? OR receiver_id=?) LIMIT 1`).bind(url,me.user_id,me.user_id).first();if(!allowed)return new Response('Forbidden',{status:403,headers:cors});}
  }
  const headers=new Headers(cors); head.writeHttpMetadata(headers); headers.set('etag',head.httpEtag); headers.set('Accept-Ranges','bytes');
  if(key.startsWith('messages/'))headers.set('Cache-Control','private, no-store');
  const range=String(request.headers.get('Range')||request.headers.get('range')||'').trim();
  if(range){
    const m=/^bytes=(\d*)-(\d*)$/i.exec(range); if(!m)return new Response('Invalid range',{status:416,headers});
    const size=Number(head.size||0); let start=m[1]?Number(m[1]):NaN,end=m[2]?Number(m[2]):NaN;
    if(Number.isNaN(start)){const suffix=Math.max(1,Number(end||0));start=Math.max(0,size-suffix);end=size-1;}else if(Number.isNaN(end)){end=size-1;}
    start=Math.max(0,start);end=Math.min(size-1,end);if(start>end||start>=size){headers.set('Content-Range',`bytes */${size}`);return new Response(null,{status:416,headers});}
    const length=end-start+1;const object=await env.MEDIA.get(key,{range:{offset:start,length}});if(!object)return new Response('Not found',{status:404,headers});
    headers.set('Content-Range',`bytes ${start}-${end}/${size}`);headers.set('Content-Length',String(length));
    return new Response(object.body,{status:206,headers});
  }
  const object=await env.MEDIA.get(key); if(!object)return new Response('Not found',{status:404,headers});headers.set('Content-Length',String(head.size||0));return new Response(object.body,{status:200,headers});
}

async function adminSafetyReports(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;try{await env.DB.prepare(`ALTER TABLE myshop_safety_reports ADD COLUMN review_reason TEXT NOT NULL DEFAULT ''`).run();}catch(e){}const u=new URL(request.url),status=String(u.searchParams.get('status')||'OPEN').toUpperCase();const rows=(await env.DB.prepare(`SELECT r.id,r.reporter_id,r.target_user_id,r.content_type,r.content_id,r.reason,r.details,r.status,r.review_reason,r.created_at,ru.full_name reporter_name,tu.full_name target_name FROM myshop_safety_reports r LEFT JOIN myshop_auth_users_v108 ru ON ru.user_id=r.reporter_id LEFT JOIN myshop_auth_users_v108 tu ON tu.user_id=r.target_user_id WHERE (?='ALL' OR r.status=?) ORDER BY CASE r.status WHEN 'OPEN' THEN 0 ELSE 1 END,datetime(r.created_at) DESC,r.id DESC LIMIT 200`).bind(status,status).all()).results||[];return json({ok:true,reports:rows},200,cors);
}

function b64urlBytes(bytes){let s='';for(const b of new Uint8Array(bytes))s+=String.fromCharCode(b);return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function b64urlText(x){return b64urlBytes(new TextEncoder().encode(x));}
function pemPkcs8(pem){const b64=String(pem||'').replace(/-----BEGIN PRIVATE KEY-----/g,'').replace(/-----END PRIVATE KEY-----/g,'').replace(/\s+/g,'');const raw=atob(b64);const out=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out.buffer;}
async function googlePublisherAccessToken(env){
  if(!env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON)throw new Error('PLAY_SERVICE_ACCOUNT_MISSING');const sa=JSON.parse(env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON);if(!sa.client_email||!sa.private_key)throw new Error('PLAY_SERVICE_ACCOUNT_INVALID');const now=Math.floor(Date.now()/1000);
  const unsigned=b64urlText(JSON.stringify({alg:'RS256',typ:'JWT'}))+'.'+b64urlText(JSON.stringify({iss:sa.client_email,scope:'https://www.googleapis.com/auth/androidpublisher',aud:'https://oauth2.googleapis.com/token',iat:now,exp:now+3600}));
  const key=await crypto.subtle.importKey('pkcs8',pemPkcs8(sa.private_key),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['sign']);const sig=await crypto.subtle.sign('RSASSA-PKCS1-v1_5',key,new TextEncoder().encode(unsigned));const assertion=unsigned+'.'+b64urlBytes(sig);
  const form=new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion});const r=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:form.toString()});const j=await r.json();if(!r.ok||!j.access_token)throw new Error('PLAY_OAUTH_FAILED:'+String(j.error_description||j.error||r.status));return j.access_token;
}
async function playGrantAtomic(env,uid,item,productId,tokenHash,orderId,payload){
 const type=String(item.item_type||'').toUpperCase(),units=Number(item.units||1);
 if(!Number.isSafeInteger(units)||units<1)throw new Error('INVALID_CATALOG_UNITS');
 const purchase=env.DB.prepare(`INSERT INTO myshop_play_purchases(user_id,catalog_id,play_product_id,purchase_token_hash,order_id,status,google_payload) VALUES(?,?,?,?,?,'VERIFIED',?)`).bind(uid,item.id,productId,tokenHash,orderId,payload);
 let q=[];
 if(type==='COIN'||type==='GOLD'){
  await ensureLiveRoomSchema(env);await reconcileLevelProgress(env,uid);
  const wallet=type==='GOLD'?'myshop_gold_wallets':'myshop_coin_wallets',tx=type==='GOLD'?'myshop_gold_transactions':'myshop_coin_transactions',col=type==='GOLD'?'official_gold_units':'official_coin_units',threshold=type==='GOLD'?1000:100000,mult=['0001','0002','0003'].includes(uid)?0:(type==='GOLD'?4:2);
  q.push(env.DB.prepare(`INSERT OR IGNORE INTO ${wallet}(user_id,balance) VALUES(?,0)`).bind(uid),env.DB.prepare(`UPDATE ${wallet} SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(units,uid));
  q.push(env.DB.prepare(`INSERT INTO ${tx}(user_id,kind,amount,reference,metadata${type==='COIN'?',status':''}) VALUES(?,'PAID_PURCHASE',?,'GOOGLE_PLAY',?${type==='COIN'?",'COMPLETED'":''})`).bind(uid,units,JSON.stringify({catalogId:item.id,source:'GOOGLE_PLAY',orderId})));
  q.push(env.DB.prepare(`INSERT INTO myshop_wallet_sources(user_id,currency,official_balance,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id,currency) DO UPDATE SET official_balance=official_balance+excluded.official_balance,updated_at=CURRENT_TIMESTAMP`).bind(uid,type,units));
  q.push(env.DB.prepare(`INSERT INTO myshop_star_level_ledger(tx_type,currency,sender_id,receiver_id,units,stars,level_added,official,reference) SELECT 'GOOGLE_PLAY_PURCHASE',?,'GOOGLE_PLAY',user_id,?,CAST((${col}+?)/${threshold} AS INTEGER)-CAST(${col}/${threshold} AS INTEGER),(CAST((${col}+?)/100000 AS INTEGER)-CAST(${col}/100000 AS INTEGER))*${mult},1,? FROM myshop_user_progress WHERE user_id=?`).bind(type,units,units,units,'GOOGLE_PLAY#'+tokenHash,uid));
  q.push(env.DB.prepare(`UPDATE myshop_user_progress SET stars=stars+CAST((${col}+?)/${threshold} AS INTEGER)-CAST(${col}/${threshold} AS INTEGER),level=level+(CAST((${col}+?)/100000 AS INTEGER)-CAST(${col}/100000 AS INTEGER))*${mult},${col}=${col}+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(units,units,units,uid));
 }else{const plan=await premiumGrantPlan(env,uid,item,'GOOGLE_PLAY','Verified Google Play purchase');q.push(...plan.writes);}
 // The unique token claim and every financial/entitlement write commit together.
 await env.DB.batch([purchase,...q]);
}
async function playPurchaseVerify(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureContentSchema(env);const active=await env.DB.prepare('SELECT active FROM myshop_auth_users_v108 WHERE user_id=?').bind(me.user_id).first();if(Number(active?.active)!==1)return json({error:'UNAUTHORIZED'},401,cors);const b=await body(request),catalogId=Math.max(0,Math.floor(Number(b.catalogId||0))),productId=String(b.productId||'').trim().toLowerCase(),token=String(b.purchaseToken||'').trim();if(!productId||token.length<20)return json({error:'INVALID_PLAY_PURCHASE'},400,cors);
  const item=catalogId>0?await env.DB.prepare(`SELECT * FROM myshop_store_catalog WHERE id=? AND enabled=1`).bind(catalogId).first():await env.DB.prepare(`SELECT * FROM myshop_store_catalog WHERE play_product_id=? AND enabled=1`).bind(productId).first();if(!item)return json({error:'CATALOG_NOT_FOUND'},404,cors);if(String(item.play_product_id||'')!==productId)return json({error:'PLAY_PRODUCT_MISMATCH'},409,cors);
  const th=await sha256(token);let prior=await env.DB.prepare(`SELECT user_id,catalog_id,status FROM myshop_play_purchases WHERE purchase_token_hash=?`).bind(th).first();if(prior){if(prior.user_id!==me.user_id||Number(prior.catalog_id)!==Number(item.id))return json({error:'PLAY_TOKEN_ALREADY_USED'},409,cors);return json({ok:true,verified:String(prior.status)==='VERIFIED',alreadyProcessed:true,catalogId:Number(prior.catalog_id)},200,cors);}
  let access;try{access=await googlePublisherAccessToken(env);}catch(e){return json({error:'PLAY_BILLING_NOT_CONFIGURED',message:'Google Play verification is not configured or temporarily unavailable.'},503,cors);}const pkg=String(env.GOOGLE_PLAY_PACKAGE_NAME||'com.myshop.app').trim();const endpoint=`https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${encodeURIComponent(pkg)}/purchases/productsv2/tokens/${encodeURIComponent(token)}`;const gr=await fetch(endpoint,{headers:{authorization:'Bearer '+access}});const gj=await gr.json();if(!gr.ok)return json({error:'PLAY_VERIFICATION_FAILED',message:String(gj?.error?.message||gr.status).slice(0,220)},409,cors);
  if(String(gj?.obfuscatedExternalAccountId||'')!==await sha256('MYSHOP_PLAY_ACCOUNT:'+me.user_id))return json({error:'PLAY_ACCOUNT_MISMATCH',message:'Purchase must belong to the current MY SHOP account.'},409,cors);
  const state=String(gj?.purchaseStateContext?.purchaseState||'');const lines=Array.isArray(gj?.productLineItem)?gj.productLineItem:[];if(state!=='PURCHASED')return json({error:'PURCHASE_NOT_COMPLETED',purchaseState:state},409,cors);if(!lines.some(x=>String(x?.productId||'')===productId))return json({error:'PLAY_PRODUCT_MISMATCH'},409,cors);
  const line=lines.find(x=>String(x?.productId||'')===productId);if(Number(line?.quantity??1)!==1)return json({error:'PLAY_QUANTITY_UNSUPPORTED'},409,cors);
  const orderId=String(gj?.orderId||'').slice(0,160),payload=JSON.stringify({purchaseState:state,productId,orderId,quantity:1});try{await playGrantAtomic(env,me.user_id,item,productId,th,orderId,payload);}catch(e){prior=await env.DB.prepare(`SELECT user_id,catalog_id,status FROM myshop_play_purchases WHERE purchase_token_hash=?`).bind(th).first();if(prior&&prior.user_id===me.user_id&&String(prior.status)==='VERIFIED')return json({ok:true,verified:true,alreadyProcessed:true,catalogId:Number(prior.catalog_id)},200,cors);console.error('PLAY_ATOMIC_GRANT_FAILED');return json({error:'PLAY_GRANT_FAILED',message:'Verified purchase could not be activated. Please retry; the entitlement was not partially applied.'},503,cors);}return json({ok:true,verified:true,catalogId:item.id,productId},200,cors);
}

async function playBillingReady(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);const u=new URL(request.url),catalogId=Math.floor(Number(u.searchParams.get('catalogId')||0)),productId=String(u.searchParams.get('productId')||'').trim().toLowerCase();const row=await env.DB.prepare(`SELECT id,play_product_id,enabled,price_minor FROM myshop_store_catalog WHERE id=?`).bind(catalogId).first();if(!row||Number(row.enabled)!==1)return json({error:'CATALOG_NOT_FOUND'},404,cors);if(!productId||productId!==String(row.play_product_id||''))return json({error:'PLAY_PRODUCT_MISMATCH'},409,cors);if(!env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON)return json({error:'PLAY_BILLING_NOT_CONFIGURED',message:'Worker secret GOOGLE_PLAY_SERVICE_ACCOUNT_JSON is missing.'},503,cors);return json({ok:true,catalogId,productId,accountBinding:await sha256('MYSHOP_PLAY_ACCOUNT:'+me.user_id)},200,cors);
}

async function messageTyping(request,env){
 const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);const b=await body(request),peer=String(b.userId||'');if(!isFourDigit(peer)||peer===me.user_id)return json({error:'INVALID_USER'},400,cors);if(await safetyIsBlocked(env,me.user_id,peer))return json({error:'BLOCKED_USER'},403,cors);
 // Short-lived metadata; it never includes message contents.
 await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_message_typing(sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL,active INTEGER NOT NULL,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(sender_id,receiver_id))`).run();
 await env.DB.prepare(`INSERT INTO myshop_message_typing(sender_id,receiver_id,active,last_seen) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(sender_id,receiver_id) DO UPDATE SET active=excluded.active,last_seen=CURRENT_TIMESTAMP`).bind(me.user_id,peer,b.active===true?1:0).run();return json({ok:true},200,cors);
}

async function pushTokenRegister(request,env){
 const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureNotificationSchema(env);const b=await body(request),token=String(b.token||'').trim().slice(0,4096);if(token.length<20)return json({error:'INVALID_PUSH_TOKEN'},400,cors);
 const project=String(b.firebaseProjectId||'').trim();let serverProject='';try{serverProject=String(JSON.parse(String(env.FCM_SERVICE_ACCOUNT_JSON||'{}')).project_id||'');}catch(e){}if(project&&serverProject&&project!==serverProject)return json({error:'FIREBASE_PROJECT_MISMATCH',message:'APK and Worker must use the same Firebase project.'},409,cors);
 await env.DB.batch([env.DB.prepare(`UPDATE myshop_push_tokens SET active=0 WHERE token=? AND user_id<>?`).bind(token,me.user_id),env.DB.prepare(`INSERT INTO myshop_push_tokens(user_id,token,platform,active,updated_at) VALUES(?,?,'ANDROID',1,CURRENT_TIMESTAMP) ON CONFLICT(user_id,token) DO UPDATE SET active=1,updated_at=CURRENT_TIMESTAMP`).bind(me.user_id,token)]);let serverConfigured=false;try{const sa=JSON.parse(String(env.FCM_SERVICE_ACCOUNT_JSON||'{}'));serverConfigured=!!(sa.project_id&&sa.client_email&&String(sa.private_key||'').includes('BEGIN PRIVATE KEY'));}catch(e){}return json({ok:true,serverConfigured,projectMatched:!!project&&project===serverProject},200,cors);
}

async function pushSelfTest(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);
  if(!isAdminUser(me))return json({error:'ADMIN_ONLY'},403,cors);
  const ok=await sendPushToUser(env,me.user_id,'MY SHOP Test','Device notification test','TEST_PUSH',me.user_id,me.user_id);
  const last=await env.DB.prepare(`SELECT status,detail,created_at FROM myshop_push_delivery_log WHERE user_id=? ORDER BY id DESC LIMIT 1`).bind(me.user_id).first();
  return json({ok:!!ok,result:last||null},ok?200:503,cors);
}
async function createUserNotification(env,userId,title,message,type='',actorUserId='',targetId='',ctx=null){
  const uid=String(userId||'').trim();
  if(!uid) return false;
  const t=String(title||'MY SHOP'), m=String(message||''), kind=String(type||'').slice(0,40), actor=String(actorUserId||'').slice(0,40), target=String(targetId||'').slice(0,120);
  for(let attempt=1;attempt<=2;attempt++){
    try {
      await ensureNotificationSchema(env);
      const r=await env.DB.prepare(`INSERT INTO notifications(title,message,audience,user_id,type,actor_user_id,target_id,created_at) VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)`).bind(t,m,'USER',uid,kind,actor,target).run();
      const id=r.meta?.last_row_id;
      if(id){ const v=await env.DB.prepare('SELECT id FROM notifications WHERE id=? AND user_id=?').bind(id,uid).first(); if(v?.id){const push=sendPushToUser(env,uid,t,m,kind,actor,target,String(v.id));if(ctx&&ctx.waitUntil)ctx.waitUntil(push);else await push;return true;} }
      const v=await env.DB.prepare("SELECT id FROM notifications WHERE title=? AND message=? AND audience='USER' AND user_id=? ORDER BY id DESC LIMIT 1").bind(t,m,uid).first();
      if(v?.id){const push=sendPushToUser(env,uid,t,m,kind,actor,target,String(v.id));if(ctx&&ctx.waitUntil)ctx.waitUntil(push);else await push;return true;}
    } catch (e) {
      console.error('NOTIFICATION_DB_WRITE_FAILED',JSON.stringify({attempt,message:String(e?.message||e)}));
    }
  }
  return false;
}

async function createBroadcastNotification(env,title,message){
  const t=String(title||'MY SHOP'), m=String(message||'');
  for(let attempt=1;attempt<=2;attempt++){
    try {
      await ensureNotificationSchema(env);
      const r=await env.DB.prepare(`INSERT INTO notifications(title,message,audience,user_id,created_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)`).bind(t,m,'ALL','').run();
      const id=r.meta?.last_row_id;
      if(id){ const v=await env.DB.prepare("SELECT id FROM notifications WHERE id=? AND audience='ALL'").bind(id).first(); if(v?.id) return true; }
    } catch (e) {
      console.error('NOTIFICATION_DB_WRITE_FAILED',JSON.stringify({attempt,message:String(e?.message||e)}));
    }
  }
  return false;
}

function validHexColor(v){const x=String(v||'').trim();return /^#[0-9a-fA-F]{6}$/.test(x)?x.toUpperCase():'';}
function parseScheduleIso(v){const raw=String(v||'').trim();if(!raw)return '';const normalized=raw.includes('T')?raw:raw.replace(' ','T');const ms=Date.parse(normalized);return Number.isFinite(ms)?new Date(ms).toISOString():'';}
async function adminOfficialNotice(request,env,ctx){
  const auth=await adminOnly(request,env);if(auth.error)return auth.error;
  await ensureNotificationSchema(env);const b=await body(request);
  const title=String(b.title||'MY SHOP Official').trim().slice(0,120)||'MY SHOP Official';
  const message=String(b.message||'').trim().slice(0,4000);if(!message)return json({error:'NOTICE_MESSAGE_REQUIRED'},400,cors);
  const imageUrl=String(b.imageUrl||'').trim().slice(0,1000),actionUrl=String(b.actionUrl||'').trim().slice(0,1000),expiresAt=parseScheduleIso(b.expiresAt);
  const colorHex=validHexColor(b.colorHex)||'#FFFFFF';
  const scheduledAt=parseScheduleIso(b.scheduledAt);
  if(actionUrl&&!/^https:\/\//i.test(actionUrl))return json({error:'ACTION_URL_MUST_BE_HTTPS'},400,cors);
  if(String(b.scheduledAt||'').trim()&&!scheduledAt)return json({error:'INVALID_SCHEDULE_TIME'},400,cors);
  if(scheduledAt&&Date.parse(scheduledAt)<=Date.now()+5000)return json({error:'SCHEDULE_IN_PAST'},400,cors);
  if(expiresAt&&scheduledAt&&Date.parse(expiresAt)<=Date.parse(scheduledAt))return json({error:'EXPIRY_BEFORE_SCHEDULE'},400,cors);
  const status=scheduledAt?'SCHEDULED':'SENT';
  const r=await env.DB.prepare(`INSERT INTO notifications(title,message,audience,user_id,type,actor_user_id,target_id,image_url,action_url,expires_at,color_hex,scheduled_at,status,created_at) VALUES(?,?, 'ALL','', 'OFFICIAL',?,?,?, ?,?,?,?,?,CURRENT_TIMESTAMP)`).bind(title,message,'MY_SHOP_OFFICIAL','',imageUrl,actionUrl,expiresAt,colorHex,scheduledAt,status).run();
  const id=Number(r.meta?.last_row_id||0);
  if(status==='SENT'){
    const users=(await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE active=1`).all()).results||[];
    const push=Promise.all(users.map(u=>sendPushToUser(env,String(u.user_id),title,message,'OFFICIAL','MY_SHOP_OFFICIAL',String(id))));
    if(ctx&&ctx.waitUntil)ctx.waitUntil(push); else await push;
    return json({ok:true,id,official:true,identityColor:'RED',cardColor:colorHex,status:'SENT',deliveryQueued:users.length},201,cors);
  }
  return json({ok:true,id,official:true,identityColor:'RED',cardColor:colorHex,status:'SCHEDULED',scheduledAt},201,cors);
}

async function processScheduledOfficialNotices(env,ctx){
  await ensureNotificationSchema(env);
  const rows=(await env.DB.prepare(`SELECT id,title,message,image_url,action_url,expires_at,color_hex,scheduled_at FROM notifications WHERE type='OFFICIAL' AND status='SCHEDULED' AND scheduled_at<>'' AND datetime(scheduled_at)<=datetime('now') AND (COALESCE(expires_at,'')='' OR datetime(expires_at)>datetime('now')) ORDER BY id ASC LIMIT 50`).all()).results||[];
  for(const n of rows){
    try{
      const changed=await env.DB.prepare(`UPDATE notifications SET status='SENT' WHERE id=? AND status='SCHEDULED'`).bind(n.id).run();
      if(Number(changed?.meta?.changes||0)!==1)continue;
      const users=(await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE active=1`).all()).results||[];
      const push=Promise.all(users.map(u=>sendPushToUser(env,String(u.user_id),String(n.title||'MY SHOP Official'),String(n.message||''),'OFFICIAL','MY_SHOP_OFFICIAL',String(n.id))));
      if(ctx&&ctx.waitUntil)ctx.waitUntil(push); else await push;
    }catch(e){console.error('OFFICIAL_SCHEDULE_DELIVERY_FAILED',String(e?.message||e));}
  }
  return rows.length;
}

async function adminOfficialNoticeList(request,env){
  const auth=await adminOnly(request,env);if(auth.error)return auth.error;await ensureNotificationSchema(env);
  const rows=(await env.DB.prepare(`SELECT id,title,message,image_url,action_url,expires_at,color_hex,scheduled_at,status,created_at FROM notifications WHERE audience='ALL' AND type='OFFICIAL' ORDER BY id DESC LIMIT 50`).all()).results||[];
  return json({ok:true,notices:rows},200,cors);
}

async function helpTicketSchema(env){
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_support_tickets (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,category TEXT NOT NULL DEFAULT 'GENERAL',subject TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'OPEN',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_support_tickets_user ON myshop_support_tickets(user_id,updated_at DESC,id DESC)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_support_messages (id INTEGER PRIMARY KEY AUTOINCREMENT,ticket_id INTEGER NOT NULL,sender_id TEXT NOT NULL,message TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_support_messages_ticket ON myshop_support_messages(ticket_id,id ASC)`).run();await ensureRequestNotices(env.DB);
}
async function helpTickets(request,env){const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await helpTicketSchema(env);const rows=(await env.DB.prepare(`SELECT id,category,subject,status,created_at,updated_at FROM myshop_support_tickets WHERE user_id=? ORDER BY datetime(updated_at) DESC,id DESC LIMIT 50`).bind(me.user_id).all()).results||[];return json({ok:true,tickets:rows},200,cors);}
async function helpTicketCreate(request,env){const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await helpTicketSchema(env);const b=await body(request),cat=String(b.category||'GENERAL').trim().slice(0,50),subject=String(b.subject||'').trim().slice(0,160),message=String(b.message||'').trim().slice(0,4000);if(!subject||!message)return json({error:'TICKET_FIELDS_REQUIRED'},400,cors);const r=await env.DB.prepare(`INSERT INTO myshop_support_tickets(user_id,category,subject,status) VALUES(?,?,?,'OPEN')`).bind(me.user_id,cat,subject).run();const id=Number(r.meta?.last_row_id||0);await env.DB.prepare(`INSERT INTO myshop_support_messages(ticket_id,sender_id,message) VALUES(?,?,?)`).bind(id,me.user_id,message).run();return json({ok:true,ticketId:id,status:'OPEN'},201,cors);}
async function helpTicketThread(request,env){const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await helpTicketSchema(env);const id=Math.floor(Number(new URL(request.url).searchParams.get('id')||0));const t=await env.DB.prepare(`SELECT id,category,subject,status,created_at,updated_at FROM myshop_support_tickets WHERE id=? AND user_id=?`).bind(id,me.user_id).first();if(!t)return json({error:'TICKET_NOT_FOUND'},404,cors);const rows=(await env.DB.prepare(`SELECT id,sender_id,message,created_at FROM myshop_support_messages WHERE ticket_id=? ORDER BY id ASC LIMIT 200`).bind(id).all()).results||[];return json({ok:true,ticket:t,messages:rows},200,cors);}
async function helpTicketReply(request,env){const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await helpTicketSchema(env);const b=await body(request),id=Math.floor(Number(b.ticketId||0)),message=String(b.message||'').trim().slice(0,4000);if(!id||!message)return json({error:'REPLY_FIELDS_REQUIRED'},400,cors);const t=await env.DB.prepare(`SELECT id,status FROM myshop_support_tickets WHERE id=? AND user_id=?`).bind(id,me.user_id).first();if(!t)return json({error:'TICKET_NOT_FOUND'},404,cors);if(String(t.status)==='CLOSED')return json({error:'TICKET_CLOSED'},409,cors);await env.DB.prepare(`INSERT INTO myshop_support_messages(ticket_id,sender_id,message) VALUES(?,?,?)`).bind(id,me.user_id,message).run();await env.DB.prepare(`UPDATE myshop_support_tickets SET updated_at=CURRENT_TIMESTAMP,status='OPEN' WHERE id=?`).bind(id).run();return json({ok:true},201,cors);}
async function adminHelpTickets(request,env){const auth=await adminOnly(request,env);if(auth.error)return auth.error;await helpTicketSchema(env);const rows=(await env.DB.prepare(`SELECT t.id,t.user_id,t.category,t.subject,t.status,t.created_at,t.updated_at,u.full_name,u.avatar_url FROM myshop_support_tickets t LEFT JOIN myshop_auth_users_v108 u ON u.user_id=t.user_id ORDER BY CASE WHEN t.status='OPEN' THEN 0 ELSE 1 END,datetime(t.updated_at) DESC LIMIT 100`).all()).results||[];return json({ok:true,tickets:rows},200,cors);}
async function adminHelpReply(request,env){const auth=await adminOnly(request,env);if(auth.error)return auth.error;await helpTicketSchema(env);const b=await body(request),id=Math.floor(Number(b.ticketId||0)),message=String(b.message||'').trim().slice(0,4000);if(!id||!message)return json({error:'REPLY_FIELDS_REQUIRED'},400,cors);const t=await env.DB.prepare(`SELECT id,user_id FROM myshop_support_tickets WHERE id=?`).bind(id).first();if(!t)return json({error:'TICKET_NOT_FOUND'},404,cors);await env.DB.prepare(`INSERT INTO myshop_support_messages(ticket_id,sender_id,message) VALUES(?,?,?)`).bind(id,auth.user.user_id,message).run();await env.DB.prepare(`UPDATE myshop_support_tickets SET updated_at=CURRENT_TIMESTAMP,status='WAITING_USER' WHERE id=?`).bind(id).run();await createUserNotification(env,String(t.user_id),'MY SHOP Support','Your Help Center ticket has a new official reply.','SUPPORT_REPLY',auth.user.user_id,String(id),null);return json({ok:true},201,cors);}
async function adminHelpStatus(request,env){const auth=await adminOnly(request,env);if(auth.error)return auth.error;await helpTicketSchema(env);const b=await body(request),id=Math.floor(Number(b.ticketId||0)),status=String(b.status||'OPEN').toUpperCase();if(!id||!['OPEN','WAITING_USER','RESOLVED','CLOSED'].includes(status))return json({error:'INVALID_STATUS'},400,cors);await env.DB.prepare(`UPDATE myshop_support_tickets SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(status,id).run();return json({ok:true,status},200,cors);}

async function ensureReleaseNotification(env){
  const key='release_notice_v242';
  try {
    await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_schema_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
    const sent=await env.DB.prepare('SELECT value FROM myshop_schema_meta WHERE key=?').bind(key).first();
    if(String(sent?.value||'')==='sent') return;
    const ok=await createBroadcastNotification(env,'MY SHOP Update','V-249 is available: live Friends/Followers/Following profile counts, Follow/Unfollow, Facebook-style cover photos, and smoother profile actions.');
    if(ok) await env.DB.prepare(`INSERT INTO myshop_schema_meta(key,value,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=CURRENT_TIMESTAMP`).bind(key,'sent').run();
  } catch(e) { console.error('RELEASE_NOTICE_FAILED',String(e?.message||e)); }
}

async function notificationsList(request,env){
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  try { await ensureNotificationSchema(env); await ensureFriendSchema(env); } catch (e) { return json({error:'NOTIFICATION_SCHEMA_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
  const allowed="('LIKE','COMMENT','FRIEND_REQUEST','FRIEND_ACCEPT','FRIEND_UPDATE','LIVE_START','LIVE_UPCOMING','OFFICIAL')";
  const rows=await env.DB.prepare(`SELECT n.id,n.title,n.message,n.type,n.actor_user_id,n.target_id,n.image_url,n.action_url,n.expires_at,n.color_hex,n.scheduled_at,n.status,n.created_at,CASE WHEN r.notification_id IS NULL THEN 0 ELSE 1 END AS is_read,COALESCE(a.avatar_url,'') AS actor_avatar_url,COALESCE(p.media_url,'') AS thumbnail_url,COALESCE(fr.status,'') AS friend_status FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? LEFT JOIN myshop_auth_users_v108 a ON a.user_id=n.actor_user_id LEFT JOIN myshop_posts p ON CAST(p.id AS TEXT)=n.target_id LEFT JOIN myshop_friend_requests fr ON n.type='FRIEND_REQUEST' AND fr.sender_id=n.actor_user_id AND fr.receiver_id=n.user_id WHERE ((n.audience='USER' AND n.user_id=?) OR n.audience='ALL') AND n.type IN ${allowed} AND COALESCE(n.status,'SENT')='SENT' AND (COALESCE(n.scheduled_at,'')='' OR datetime(n.scheduled_at)<=datetime('now')) AND (COALESCE(n.expires_at,'')='' OR datetime(n.expires_at)>=datetime('now')) ORDER BY n.id DESC LIMIT 80`).bind(user.user_id,user.user_id).all();
  const unread=await env.DB.prepare(`SELECT COUNT(*) AS c FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? WHERE ((n.audience='USER' AND n.user_id=?) OR n.audience='ALL') AND n.type IN ${allowed} AND COALESCE(n.status,'SENT')='SENT' AND (COALESCE(n.scheduled_at,'')='' OR datetime(n.scheduled_at)<=datetime('now')) AND (COALESCE(n.expires_at,'')='' OR datetime(n.expires_at)>=datetime('now')) AND r.notification_id IS NULL`).bind(user.user_id,user.user_id).first();
  return json({ok:true,unreadCount:Number(unread?.c||0),notifications:(rows.results||[]).map(x=>({id:x.id,title:x.title,message:x.message,type:x.type||'',actorUserId:x.actor_user_id||'',targetId:x.target_id||'',imageUrl:x.image_url||'',actionUrl:x.action_url||'',expiresAt:x.expires_at||'',createdAt:x.created_at,isRead:Number(x.is_read||0),actorAvatarUrl:x.actor_avatar_url||'',thumbnailUrl:x.thumbnail_url||'',friendRequestState:x.type==='FRIEND_REQUEST'?(x.friend_status||'CANCELLED'):'',colorHex:x.color_hex||'#FFFFFF',scheduledAt:x.scheduled_at||'',status:x.status||'SENT'}))},200,cors);
}

async function notificationReadOne(request,env){
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors); const b=await body(request); const id=Number(b.id||0); if(!id)return json({error:'INVALID_NOTIFICATION_ID'},400,cors);
  try{await ensureNotificationSchema(env);const n=await env.DB.prepare("SELECT id FROM notifications WHERE id=? AND ((audience='USER' AND user_id=?) OR audience='ALL') AND type IN ('LIKE','COMMENT','FRIEND_REQUEST','FRIEND_ACCEPT','FRIEND_UPDATE','LIVE_START','LIVE_UPCOMING','OFFICIAL') AND COALESCE(status,'SENT')='SENT' AND (COALESCE(scheduled_at,'')='' OR datetime(scheduled_at)<=datetime('now'))").bind(id,user.user_id).first();if(!n)return json({error:'NOT_FOUND'},404,cors);await env.DB.prepare('INSERT OR IGNORE INTO notification_reads(notification_id,user_id,read_at) VALUES(?,?,CURRENT_TIMESTAMP)').bind(id,user.user_id).run();const u=await env.DB.prepare(`SELECT COUNT(*) AS c FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? WHERE ((n.audience='USER' AND n.user_id=?) OR n.audience='ALL') AND n.type IN ('LIKE','COMMENT','FRIEND_REQUEST','FRIEND_ACCEPT','FRIEND_UPDATE','LIVE_START','LIVE_UPCOMING','OFFICIAL') AND COALESCE(n.status,'SENT')='SENT' AND (COALESCE(n.scheduled_at,'')='' OR datetime(n.scheduled_at)<=datetime('now')) AND r.notification_id IS NULL`).bind(user.user_id,user.user_id).first();return json({ok:true,unreadCount:Number(u?.c||0)},200,cors);}catch(e){return json({error:'NOTIFICATION_DB_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);}
}

async function notificationsReadAll(request,env){
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  try { await ensureNotificationSchema(env); await env.DB.prepare(`INSERT OR IGNORE INTO notification_reads(notification_id,user_id,read_at) SELECT n.id,?,CURRENT_TIMESTAMP FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? WHERE ((n.audience='USER' AND n.user_id=?) OR n.audience='ALL') AND n.type IN ('LIKE','COMMENT','FRIEND_REQUEST','FRIEND_ACCEPT','FRIEND_UPDATE','LIVE_START','LIVE_UPCOMING','OFFICIAL') AND r.notification_id IS NULL`).bind(user.user_id,user.user_id,user.user_id).run(); return json({ok:true,unreadCount:0},200,cors); }
  catch(e){ return json({error:'NOTIFICATION_DB_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
}



const REQUIRED_CONTENT_COLUMNS = {
  dashboard_config:['id','breaking_news','my_shop_url','live_tv_url','external_movie_url','chat_url','power_ad_title','power_ad_byline','dashboard_bg_color','dashboard_blue_color','dashboard_purple_color','dashboard_pink_color','breaking_news_text_size','breaking_news_bg_color','breaking_news_text_color','updated_at'],
  banners:['id','folder','slot','image_url','caption','target_url','active','start_at','end_at','updated_at'],
  banner_media:['id','folder','slot','object_key','updated_at'],
  gallery_media:['id','folder','title','caption','media_url','object_key','media_type','active','display_order','updated_at'],
  gallery_items:['id','title','media_url','media_type','active','display_order','updated_at'],
  feature_buttons:['key','title','icon_url','target_url','active','display_order','icon_size','updated_at'],
  social_links:['id','platform','url','icon_key','icon_url','image_url','caption','active'],
  managed_links:['id','category','title','caption','url','icon_url','image_url','active','display_order','price_minor','offer_text','offer_start','offer_end','time_limit_minutes','status','coming_soon_message','revision','archived','updated_at'],
  myshop_visit_history:['id','user_id','type','title','details','ref','thumbnail_url','action','visited_at'],
  dashboard_ads:['id','box_key','slot','image_url','caption','target_url','object_key','media_type','active','duration_sec','updated_at'],
  notifications:['id','title','message','audience','user_id','type','actor_user_id','target_id','image_url','action_url','expires_at','color_hex','scheduled_at','status','created_at'],
  notification_reads:['notification_id','user_id','read_at'],
  myshop_posts:['id','user_id','caption','media_url','object_key','media_type','status','moderated_by','moderated_at','created_at','updated_at'],
  myshop_post_likes:['post_id','user_id','created_at'],
  myshop_post_comments:['id','post_id','user_id','comment','created_at']
};

async function assertContentSchema(env){
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  const missing=[];
  for(const [table,cols] of Object.entries(REQUIRED_CONTENT_COLUMNS)){
    let rows=[];
    try{ rows=(await env.DB.prepare(`PRAGMA table_info(${table})`).all()).results||[]; }
    catch(e){ throw new Error(`D1_SCHEMA_READ_FAILED:${table}:${String(e?.message||e).slice(0,160)}`); }
    if(!rows.length){ missing.push(`${table}:(table missing)`); continue; }
    const names=new Set(rows.map(r=>String(r.name||'')));
    for(const col of cols) if(!names.has(col)) missing.push(`${table}.${col}`);
  }
  if(missing.length) throw new Error('D1_SCHEMA_INCOMPLETE:'+missing.slice(0,20).join(','));
  const cfg=await env.DB.prepare('SELECT id FROM dashboard_config WHERE id=1').first();
  if(!cfg) throw new Error('D1_SCHEMA_INCOMPLETE:dashboard_config.id=1 row missing');
  return true;
}

async function d1WriteProbe(env){
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_health_probe (probe_id TEXT PRIMARY KEY,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  const id=crypto.randomUUID();
  await env.DB.prepare('INSERT INTO myshop_health_probe(probe_id) VALUES(?)').bind(id).run();
  const row=await env.DB.prepare('SELECT probe_id FROM myshop_health_probe WHERE probe_id=?').bind(id).first();
  if(!row?.probe_id) throw new Error('D1_WRITE_VERIFY_FAILED');
  await env.DB.prepare('DELETE FROM myshop_health_probe WHERE probe_id=?').bind(id).run();
  return true;
}

async function r2WriteProbe(env){
  if(!env?.MEDIA) throw new Error('R2_NOT_CONFIGURED');
  const key=`_health/myshop-${crypto.randomUUID()}.txt`;
  const data=new TextEncoder().encode('MY SHOP R2 health probe');
  try{
    await env.MEDIA.put(key,data,{httpMetadata:{contentType:'text/plain',cacheControl:'no-store'}});
    const head=await env.MEDIA.head(key);
    if(!head) throw new Error('R2_WRITE_VERIFY_FAILED');
  } finally {
    try{ await env.MEDIA.delete(key); }catch(_){}
  }
  return true;
}

async function assertWriteReady(env){
  await ensureSchemasOnce(env);
  await assertContentSchema(env);
  return true;
}

async function ensureColumn(env, table, column, definition) {
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  const info = await env.DB.prepare(`PRAGMA table_info(${table})`).all();
  const rows=info.results||[];
  if(!rows.length) throw new Error(`D1_SCHEMA_TABLE_MISSING:${table}`);
  const found = rows.some(r => String(r.name || '') === column);
  if(!found){
    try { await env.DB.prepare(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`).run(); }
    catch(e){ throw new Error(`D1_SCHEMA_REPAIR_FAILED:${table}.${column}:${String(e?.message||e).slice(0,180)}`); }
  }
}

async function repairContentSchema(env) {
  // Existing production databases may use older column names. Repair is additive only.
  await ensureColumn(env,'myshop_auth_users_v108','avatar_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'myshop_auth_users_v108','avatar_object_key',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'myshop_auth_users_v108','bio',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'myshop_auth_users_v108','updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`);

  for (const [c,d] of [
    ['breaking_news',`TEXT NOT NULL DEFAULT ''`],['my_shop_url',`TEXT NOT NULL DEFAULT ''`],['live_tv_url',`TEXT NOT NULL DEFAULT ''`],
    ['external_movie_url',`TEXT NOT NULL DEFAULT ''`],['chat_url',`TEXT NOT NULL DEFAULT ''`],['power_ad_title',`TEXT NOT NULL DEFAULT 'POWER AD'`],
    ['power_ad_byline',`TEXT NOT NULL DEFAULT 'by Touhid'`],['dashboard_bg_color',`TEXT NOT NULL DEFAULT '#07122F'`],
    ['dashboard_blue_color',`TEXT NOT NULL DEFAULT '#2D72F6'`],['dashboard_purple_color',`TEXT NOT NULL DEFAULT '#7B3FF2'`],
    ['dashboard_pink_color',`TEXT NOT NULL DEFAULT '#F02BB7'`],['breaking_news_text_size',`REAL NOT NULL DEFAULT 13.0`],['breaking_news_bg_color',`TEXT NOT NULL DEFAULT '#FFEFF7'`],['breaking_news_text_color',`TEXT NOT NULL DEFAULT '#414662'`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
  ]) await ensureColumn(env,'dashboard_config',c,d);

  // V-355 palette migration: only legacy default values move to the approved dark navy/blue/purple/pink family. Admin custom colors stay untouched.
  await env.DB.prepare(`UPDATE dashboard_config SET dashboard_bg_color=CASE WHEN upper(dashboard_bg_color)='#F8F9FD' THEN '#07122F' ELSE dashboard_bg_color END,dashboard_blue_color=CASE WHEN upper(dashboard_blue_color)='#2E2FBE' THEN '#2D72F6' ELSE dashboard_blue_color END,dashboard_purple_color=CASE WHEN upper(dashboard_purple_color)='#5B26D6' THEN '#7B3FF2' ELSE dashboard_purple_color END,dashboard_pink_color=CASE WHEN upper(dashboard_pink_color)='#EB24A8' THEN '#F02BB7' ELSE dashboard_pink_color END WHERE id=1`).run();

  // V-192 permanent legacy-banner repair: older D1 used section/position/is_active.
  await ensureColumn(env,'banners','folder',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'banners','slot',`INTEGER NOT NULL DEFAULT 0`);
  await ensureColumn(env,'banners','image_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'banners','caption',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'banners','active',`INTEGER NOT NULL DEFAULT 1`);
  await ensureColumn(env,'banners','updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`);
  const bannerCols=(await env.DB.prepare('PRAGMA table_info(banners)').all()).results||[];
  const bn=new Set(bannerCols.map(r=>String(r.name||'')));
  if(bn.has('section')) await env.DB.prepare(`UPDATE banners SET folder=CASE WHEN lower(trim(COALESCE(section,''))) IN ('hero','promo') THEN lower(trim(section)) ELSE CASE WHEN lower(trim(COALESCE(folder,''))) IN ('hero','promo') THEN lower(trim(folder)) ELSE 'hero' END END WHERE trim(COALESCE(folder,''))=''`).run();
  if(bn.has('position')) await env.DB.prepare(`UPDATE banners SET slot=CASE WHEN CAST(COALESCE(position,0) AS INTEGER)>0 THEN CAST(position AS INTEGER) ELSE CASE WHEN slot>0 THEN slot ELSE 1 END END WHERE COALESCE(slot,0)<=0`).run();
  await env.DB.prepare(`UPDATE banners SET folder='hero' WHERE trim(COALESCE(folder,''))=''`).run();
  await env.DB.prepare(`UPDATE banners SET slot=1 WHERE COALESCE(slot,0)<=0`).run();

  for (const [c,d] of [['caption',`TEXT NOT NULL DEFAULT ''`],['object_key',`TEXT NOT NULL DEFAULT ''`],['media_url',`TEXT NOT NULL DEFAULT ''`],['media_type',`TEXT NOT NULL DEFAULT 'image'`],['active',`INTEGER NOT NULL DEFAULT 1`],['display_order',`INTEGER NOT NULL DEFAULT 1`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`],['owner_user_id',`TEXT`]]) await ensureColumn(env,'gallery_media',c,d);
  await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_gallery_media_owner ON gallery_media(owner_user_id,folder,active,updated_at)').run();

  await ensureColumn(env,'dashboard_ads','duration_sec',`INTEGER NOT NULL DEFAULT 3`);
  await ensureColumn(env,'dashboard_ads','display_mode',`TEXT NOT NULL DEFAULT 'FULL_IMAGE'`);
  await ensureColumn(env,'dashboard_ads','media_type',`TEXT NOT NULL DEFAULT 'image'`);
  await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_dashboard_ads_box ON dashboard_ads(box_key,active,slot,id)').run();
  await ensureColumn(env,'banner_media','object_key',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'banner_media','updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`);
  for (const [c,d] of [['caption',`TEXT NOT NULL DEFAULT ''`],['icon_url',`TEXT NOT NULL DEFAULT ''`],['image_url',`TEXT NOT NULL DEFAULT ''`],['active',`INTEGER NOT NULL DEFAULT 1`],['display_order',`INTEGER NOT NULL DEFAULT 1`],['price_minor',`INTEGER NOT NULL DEFAULT 0`],['offer_text',`TEXT NOT NULL DEFAULT ''`],['offer_start',`TEXT NOT NULL DEFAULT ''`],['offer_end',`TEXT NOT NULL DEFAULT ''`],['time_limit_minutes',`INTEGER NOT NULL DEFAULT 0`],['status',`TEXT NOT NULL DEFAULT 'ACTIVE'`],['coming_soon_message',`TEXT NOT NULL DEFAULT ''`],['revision',`INTEGER NOT NULL DEFAULT 0`],['archived',`INTEGER NOT NULL DEFAULT 0`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]]) await ensureColumn(env,'managed_links',c,d);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_visit_history (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,type TEXT NOT NULL DEFAULT 'ITEM',title TEXT NOT NULL DEFAULT '',details TEXT NOT NULL DEFAULT '',ref TEXT NOT NULL DEFAULT '',thumbnail_url TEXT NOT NULL DEFAULT '',action TEXT NOT NULL DEFAULT 'Open',visited_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_myshop_visit_history_user_time ON myshop_visit_history(user_id,visited_at DESC,id DESC)`).run();
  await ensureColumn(env,'social_links','icon_key',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'social_links','icon_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'social_links','image_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'social_links','caption',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'social_links','active',`INTEGER NOT NULL DEFAULT 1`);
  await ensureColumn(env,'myshop_store_catalog','auto_approve',`INTEGER NOT NULL DEFAULT 0`);
  await ensureColumn(env,'myshop_store_purchase_requests','gift_recipient_id',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'myshop_store_purchase_requests','transaction_source',`TEXT NOT NULL DEFAULT 'PURCHASE'`);

  // Full required-column repair audit (additive only). Existing rows are preserved.
  // Primary-key columns are intentionally not ALTERed; their tables are created above when absent.
  const requiredRepairs = {
    gallery_media:[
      ['folder',`TEXT NOT NULL DEFAULT ''`],['title',`TEXT NOT NULL DEFAULT ''`]
    ],
    gallery_items:[
      ['title',`TEXT NOT NULL DEFAULT ''`],['media_url',`TEXT NOT NULL DEFAULT ''`],['media_type',`TEXT NOT NULL DEFAULT 'image'`],
      ['active',`INTEGER NOT NULL DEFAULT 1`],['display_order',`INTEGER NOT NULL DEFAULT 1`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    feature_buttons:[
      ['title',`TEXT NOT NULL DEFAULT ''`],['icon_url',`TEXT NOT NULL DEFAULT ''`],['target_url',`TEXT NOT NULL DEFAULT ''`],
      ['active',`INTEGER NOT NULL DEFAULT 1`],['display_order',`INTEGER NOT NULL DEFAULT 1`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    banner_media:[
      ['folder',`TEXT NOT NULL DEFAULT ''`],['slot',`INTEGER NOT NULL DEFAULT 0`]
    ],
    notifications:[
      ['title',`TEXT NOT NULL DEFAULT 'MY SHOP'`],['message',`TEXT NOT NULL DEFAULT ''`],['audience',`TEXT NOT NULL DEFAULT 'ALL'`],
      ['user_id',`TEXT NOT NULL DEFAULT ''`],['created_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    notification_reads:[
      ['notification_id',`INTEGER`],['user_id',`TEXT`],['read_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    myshop_posts:[
      ['user_id',`TEXT NOT NULL DEFAULT ''`],['caption',`TEXT NOT NULL DEFAULT ''`],['media_url',`TEXT NOT NULL DEFAULT ''`],
      ['object_key',`TEXT NOT NULL DEFAULT ''`],['media_type',`TEXT NOT NULL DEFAULT 'image'`],['status',`TEXT NOT NULL DEFAULT 'ACTIVE'`],
      ['moderated_by',`TEXT NOT NULL DEFAULT ''`],['moderated_at',`TEXT`],['created_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`],
      ['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    myshop_post_likes:[
      ['post_id',`INTEGER`],['user_id',`TEXT`],['created_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    myshop_post_comments:[
      ['post_id',`INTEGER`],['user_id',`TEXT`],['comment',`TEXT NOT NULL DEFAULT ''`],['created_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    managed_links:[
      ['category',`TEXT NOT NULL DEFAULT ''`],['title',`TEXT NOT NULL DEFAULT ''`],['url',`TEXT NOT NULL DEFAULT ''`],['image_url',`TEXT NOT NULL DEFAULT ''`],['price_minor',`INTEGER NOT NULL DEFAULT 0`],['offer_text',`TEXT NOT NULL DEFAULT ''`],['offer_start',`TEXT NOT NULL DEFAULT ''`],['offer_end',`TEXT NOT NULL DEFAULT ''`],['time_limit_minutes',`INTEGER NOT NULL DEFAULT 0`],['status',`TEXT NOT NULL DEFAULT 'ACTIVE'`]
    ],
    dashboard_ads:[
      ['box_key',`TEXT NOT NULL DEFAULT ''`],['slot',`INTEGER NOT NULL DEFAULT 0`],['image_url',`TEXT NOT NULL DEFAULT ''`],
      ['caption',`TEXT NOT NULL DEFAULT ''`],['target_url',`TEXT NOT NULL DEFAULT ''`],['object_key',`TEXT NOT NULL DEFAULT ''`],['media_type',`TEXT NOT NULL DEFAULT 'image'`],
      ['active',`INTEGER NOT NULL DEFAULT 1`],['duration_sec',`INTEGER NOT NULL DEFAULT 3`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ]
  };
  for (const [table, columns] of Object.entries(requiredRepairs)) {
    for (const [column, definition] of columns) await ensureColumn(env,table,column,definition);
  }
}

async function ensureDashboardConfigSchema(env) {
  await ensureContentSchema(env);
}

async function deepHealth(env) {
  const result={ok:true,service:'my-shop-api',database:'unknown',d1Write:'unknown',r2:'unknown',r2Write:'unknown',schema:'unknown',playBilling:env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON?'configured':'missing',time:new Date().toISOString()};
  try {
    await env.DB.prepare('SELECT 1').first();
    result.database='ok';
    await ensureSchemasOnce(env);
    await assertContentSchema(env);
    result.schema='ok';
    await d1WriteProbe(env);
    result.d1Write='ok';
  } catch (e) {
    result.ok=false;
    result.database=result.database==='ok'?'ok':'error';
    result.schema=result.schema==='ok'?'ok':'error';
    result.d1Write='error';
    result.databaseMessage=String(e?.message||e).slice(0,220);
  }
  try {
    if (!env.MEDIA) throw new Error('R2 binding MEDIA is missing');
    await env.MEDIA.list({limit:1});
    result.r2='ok';
    await r2WriteProbe(env);
    result.r2Write='ok';
  } catch (e) {
    result.ok=false;
    result.r2=result.r2==='ok'?'ok':'error';
    result.r2Write='error';
    result.r2Message=String(e?.message||e).slice(0,220);
  }
  return result;
}

async function insertBannerCompat(env,{folder,slot,imageUrl,caption,active=1}) {
  const cols=(await env.DB.prepare('PRAGMA table_info(banners)').all()).results||[];
  const names=new Set(cols.map(r=>String(r.name||'')));
  const fields=['folder','slot','image_url','caption','active'];
  const values=[folder,slot,imageUrl,caption,active];
  if(names.has('section')) { fields.push('section'); values.push(folder); }
  if(names.has('position')) { fields.push('position'); values.push(slot); }
  if(names.has('is_active')) { fields.push('is_active'); values.push(active); }
  fields.push('updated_at');
  const placeholders=[...values.map(()=>'?'),'CURRENT_TIMESTAMP'];
  await env.DB.prepare(`INSERT INTO banners(${fields.join(',')}) VALUES(${placeholders.join(',')})`).bind(...values).run();
}

async function contentWriteSuite(request,env){
  const expected=String(env.MYSHOP_HEALTH_PROBE_KEY||'').trim();
  const supplied=String(request.headers.get('X-MYSHOP-HEALTH-KEY')||'').trim();
  if(!expected || !supplied || supplied!==expected) return json({error:'HEALTH_PROBE_FORBIDDEN'},403,cors);
  const marker=`__health_${crypto.randomUUID().replace(/-/g,'')}`;
  const checks={};
  const created={
    bannerId:null,bannerMediaId:null,galleryItemId:null,galleryMediaId:null,
    socialId:null,featureKey:null,managedLinkId:null,adId:null,notificationId:null,
    notificationReadUserId:null
  };
  let bannerFolder=''; let bannerSlot=0;
  try{
    await ensureSchemasOnce(env);
    await assertContentSchema(env);
    checks.schema='ok';

    await r2WriteProbe(env);
    checks.r2='ok';

    // Banners are constrained in production to hero 1-6 / promo 1-6.
    // Select a free valid slot first; never overwrite a real banner.
    for(const [folder,maxSlot] of [['hero',6],['promo',6]]){
      if(bannerSlot) break;
      for(let slot=1;slot<=maxSlot;slot++){
        const row=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=? LIMIT 1').bind(folder,slot).first();
        if(!row?.id){ bannerFolder=folder; bannerSlot=slot; break; }
      }
    }
    // If all normal slots are occupied, use a temporary folder. Current/legacy
    // schema constrains slot, not folder; this avoids touching existing banners.
    if(!bannerSlot){ bannerFolder=marker; bannerSlot=1; }

    await insertBannerCompat(env,{folder:bannerFolder,slot:bannerSlot,imageUrl:'health://probe',caption:'',active:1});
    const br=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=? ORDER BY id DESC LIMIT 1').bind(bannerFolder,bannerSlot).first();
    created.bannerId=Number(br?.id||0)||null;
    const b=br;
    if(!b?.id) throw new Error('BANNER_WRITE_VERIFY_FAILED');
    created.bannerId=Number(b.id); checks.banners='ok';

    // banner_media has a legacy UNIQUE(folder,slot). Never collide with an orphaned row.
    let mediaFolder=bannerFolder, mediaSlot=bannerSlot;
    for(let i=0;i<20;i++){
      const existing=await env.DB.prepare('SELECT id FROM banner_media WHERE folder=? AND slot=? LIMIT 1').bind(mediaFolder,mediaSlot).first();
      if(!existing?.id) break;
      mediaSlot++;
      if(mediaSlot>6){ mediaFolder=`${marker}_media`; mediaSlot=1; }
    }
    const bmr=await env.DB.prepare('INSERT INTO banner_media(folder,slot,object_key,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP)').bind(mediaFolder,mediaSlot,marker).run();
    created.bannerMediaId=Number(bmr?.meta?.last_row_id||0)||null;
    const bm=await env.DB.prepare('SELECT id FROM banner_media WHERE object_key=?').bind(marker).first();
    if(!bm?.id) throw new Error('BANNER_MEDIA_WRITE_VERIFY_FAILED');
    created.bannerMediaId=Number(bm.id); checks.banner_media='ok';

    const giTitle=`Health Probe ${marker}`;
    const gir=await env.DB.prepare('INSERT INTO gallery_items(title,media_url,media_type,active,display_order,updated_at) VALUES(?,?,?,?,1,CURRENT_TIMESTAMP)').bind(giTitle,'health://probe','image',1).run();
    created.galleryItemId=Number(gir?.meta?.last_row_id||0)||null;
    const gi=await env.DB.prepare('SELECT id FROM gallery_items WHERE id=?').bind(created.galleryItemId).first();
    if(!gi?.id) throw new Error('GALLERY_ITEM_WRITE_VERIFY_FAILED');
    checks.gallery_items='ok';

    const gm=await env.DB.prepare('INSERT INTO gallery_media(folder,title,caption,media_url,object_key,media_type,active,display_order,updated_at) VALUES(?,?,?,?,?,?,1,1,CURRENT_TIMESTAMP)').bind(marker,'Health Probe','', 'health://probe', marker, 'image').run();
    created.galleryMediaId=Number(gm?.meta?.last_row_id||0)||null;
    const gmv=await env.DB.prepare('SELECT id FROM gallery_media WHERE id=?').bind(created.galleryMediaId).first();
    if(!gmv?.id) throw new Error('GALLERY_MEDIA_WRITE_VERIFY_FAILED');
    checks.gallery_media='ok';

    const sl=await env.DB.prepare('INSERT INTO social_links(platform,url,icon_key,caption,active) VALUES(?,?,?,?,1)').bind(marker,'https://example.invalid',marker,'').run();
    created.socialId=Number(sl?.meta?.last_row_id||0)||null;
    const slv=await env.DB.prepare('SELECT id FROM social_links WHERE id=?').bind(created.socialId).first();
    if(!slv?.id) throw new Error('SOCIAL_WRITE_VERIFY_FAILED');
    checks.social_links='ok';

    await env.DB.prepare('INSERT INTO feature_buttons(key,title,icon_url,target_url,active,display_order,updated_at) VALUES(?,?,?,?,1,1,CURRENT_TIMESTAMP)').bind(marker,'Health Probe','','').run();
    const fb=await env.DB.prepare('SELECT key FROM feature_buttons WHERE key=?').bind(marker).first();
    if(!fb?.key) throw new Error('FEATURE_WRITE_VERIFY_FAILED');
    created.featureKey=marker; checks.feature_buttons='ok';

    const ml=await env.DB.prepare('INSERT INTO managed_links(category,title,url,icon_url,active,display_order,updated_at) VALUES(?,?,?,?,1,1,CURRENT_TIMESTAMP)').bind(marker,'Health Probe','','').run();
    created.managedLinkId=Number(ml?.meta?.last_row_id||0)||null;
    const mlv=await env.DB.prepare('SELECT id FROM managed_links WHERE id=?').bind(created.managedLinkId).first();
    if(!mlv?.id) throw new Error('MANAGED_LINK_WRITE_VERIFY_FAILED');
    checks.managed_links='ok';

    // Dashboard ads are constrained by the application to slots 1-6.
    const da=await env.DB.prepare('INSERT INTO dashboard_ads(box_key,slot,image_url,caption,target_url,object_key,active,duration_sec,updated_at) VALUES(?,?,?,?,?,?,1,3,CURRENT_TIMESTAMP)').bind(marker,1,'health://probe','','',marker).run();
    created.adId=Number(da?.meta?.last_row_id||0)||null;
    const dav=await env.DB.prepare('SELECT id FROM dashboard_ads WHERE id=?').bind(created.adId).first();
    if(!dav?.id) throw new Error('DASHBOARD_AD_WRITE_VERIFY_FAILED');
    checks.dashboard_ads='ok';

    const no=await env.DB.prepare('INSERT INTO notifications(title,message,audience,user_id,created_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)').bind('MY SHOP Health Probe',marker,'ALL','').run();
    created.notificationId=Number(no?.meta?.last_row_id||0)||null;
    const nov=await env.DB.prepare('SELECT id FROM notifications WHERE id=?').bind(created.notificationId).first();
    if(!nov?.id) throw new Error('NOTIFICATION_WRITE_VERIFY_FAILED');
    checks.notifications='ok';

    // Prove a dashboard write without changing user-visible values.
    const cfg=await env.DB.prepare('SELECT id FROM dashboard_config WHERE id=1').first();
    if(!cfg?.id) throw new Error('DASHBOARD_CONFIG_READ_VERIFY_FAILED');
    await env.DB.prepare('UPDATE dashboard_config SET updated_at=updated_at WHERE id=1').run();
    const cfg2=await env.DB.prepare('SELECT id FROM dashboard_config WHERE id=1').first();
    if(!cfg2?.id) throw new Error('DASHBOARD_CONFIG_WRITE_VERIFY_FAILED');
    checks.dashboard_config='ok';

    // If the legacy table has a foreign-key/check constraint on user_id, use a real
    // existing account rather than inventing an identity value. No identity row is changed.
    const userRow=await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 ORDER BY user_id LIMIT 1').first();
    const readUserId=String(userRow?.user_id||'0100');
    await env.DB.prepare('INSERT INTO notification_reads(notification_id,user_id,read_at) VALUES(?,?,CURRENT_TIMESTAMP)').bind(created.notificationId,readUserId).run();
    created.notificationReadUserId=readUserId;
    const nr=await env.DB.prepare('SELECT notification_id FROM notification_reads WHERE notification_id=? AND user_id=?').bind(created.notificationId,readUserId).first();
    if(!nr?.notification_id) throw new Error('NOTIFICATION_READ_WRITE_VERIFY_FAILED');
    checks.notification_reads='ok';

    return json({ok:true,checks},200,cors);
  } catch(e){
    return json({ok:false,checks,error:'CONTENT_WRITE_SUITE_FAILED',message:String(e?.message||e).slice(0,240)},503,cors);
  } finally {
    const cleanup=[
      created.notificationReadUserId && created.notificationId
        ? ['DELETE FROM notification_reads WHERE notification_id=? AND user_id=?',[created.notificationId,created.notificationReadUserId]] : null,
      created.notificationId ? ['DELETE FROM notifications WHERE id=?',[created.notificationId]] : null,
      created.adId ? ['DELETE FROM dashboard_ads WHERE id=?',[created.adId]] : null,
      created.managedLinkId ? ['DELETE FROM managed_links WHERE id=?',[created.managedLinkId]] : null,
      created.featureKey ? ['DELETE FROM feature_buttons WHERE key=?',[created.featureKey]] : null,
      created.socialId ? ['DELETE FROM social_links WHERE id=?',[created.socialId]] : null,
      created.galleryMediaId ? ['DELETE FROM gallery_media WHERE id=?',[created.galleryMediaId]] : null,
      created.galleryItemId ? ['DELETE FROM gallery_items WHERE id=?',[created.galleryItemId]] : null,
      created.bannerMediaId ? ['DELETE FROM banner_media WHERE id=?',[created.bannerMediaId]] : null,
      created.bannerId ? ['DELETE FROM banners WHERE id=?',[created.bannerId]] : null
    ].filter(Boolean);
    for(const [sql,args] of cleanup){ try{await env.DB.prepare(sql).bind(...args).run();}catch(_){} }
  }
}

async function adminSystemHealth(request,env){
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const h=await deepHealth(env);
  const counts={};
  const tables=['banners','banner_media','gallery_media','dashboard_ads','social_links','feature_buttons','managed_links','notifications','notification_reads'];
  for(const t of tables){
    try { const r=await env.DB.prepare(`SELECT COUNT(*) AS c FROM ${t}`).first(); counts[t]=Number(r?.c||0); }
    catch(e){ counts[t]={error:String(e?.message||e).slice(0,180)}; }
  }
  let schemaMeta={}; try { schemaMeta=(await env.DB.prepare("SELECT key,value,updated_at FROM myshop_schema_meta WHERE key='content_schema'").first())||{}; } catch(e) { schemaMeta={error:String(e?.message||e).slice(0,180)}; }
  let activePushTokens=0;try{await ensureNotificationSchema(env);const pr=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_push_tokens WHERE active=1`).first();activePushTokens=Number(pr?.c||0);}catch(e){}
  const push={fcmServerConfigured:!!String(env.FCM_SERVICE_ACCOUNT_JSON||'').trim(),activePushTokens};
  return json({ok:h.ok,worker:{version:'2.9.604',build:'V-604'},health:h,push,schemaMeta,counts,time:new Date().toISOString()},h.ok?200:503,cors);
}

const APP_THEME_LIGHT=Array.from({length:31},(_,i)=>'L'+(i+1));
const APP_THEME_DARK=Array.from({length:30},(_,i)=>'D'+(i+1));
async function appThemeConfig(request,env){
 let admin=null;if(request.method!=='GET'||new URL(request.url).pathname.includes('/admin/')){const a=await adminOnly(request,env);if(a.error)return a.error;admin=a.user;}
 await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_app_themes(id INTEGER PRIMARY KEY CHECK(id=1),light_id TEXT NOT NULL DEFAULT 'L1',dark_id TEXT NOT NULL DEFAULT 'D1',draft_light_id TEXT NOT NULL DEFAULT 'L1',draft_dark_id TEXT NOT NULL DEFAULT 'D1',revision INTEGER NOT NULL DEFAULT 0,updated_by TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
 for(const column of ['light_color','dark_color','draft_light_color','draft_dark_color']){try{await env.DB.prepare(`ALTER TABLE myshop_app_themes ADD COLUMN ${column} TEXT NOT NULL DEFAULT ''`).run();}catch(e){}}
 await env.DB.prepare(`INSERT OR IGNORE INTO myshop_app_themes(id) VALUES(1)`).run();
 if(request.method==='PUT'){
  const b=await body(request),action=String(b.action||'SAVE').toUpperCase();if(!['SAVE','PUBLISH','RESET'].includes(action))return json({error:'INVALID_THEME_ACTION'},400,cors);
  const light=String(b.lightId||''),dark=String(b.darkId||'');const lightColor=String(b.lightColor||''),darkColor=String(b.darkColor||'');if(action!=='RESET'&&(!APP_THEME_LIGHT.includes(light)||!APP_THEME_DARK.includes(dark)))return json({error:'INVALID_THEME_ID'},400,cors);if(action!=='RESET'&&((lightColor&&!/^#[0-9a-fA-F]{6}$/.test(lightColor))||(darkColor&&!/^#[0-9a-fA-F]{6}$/.test(darkColor))))return json({error:'INVALID_THEME_COLOR'},400,cors);
  const revision=b.revision;if(!Number.isInteger(revision)||revision<0)return json({error:'THEME_REVISION_REQUIRED'},400,cors);
  let result;if(action==='SAVE')result=await env.DB.prepare(`UPDATE myshop_app_themes SET draft_light_id=?,draft_dark_id=?,draft_light_color=?,draft_dark_color=?,revision=revision+1,updated_by=?,updated_at=CURRENT_TIMESTAMP WHERE id=1 AND revision=?`).bind(light,dark,lightColor,darkColor,admin.user_id,revision).run();
  else if(action==='PUBLISH')result=await env.DB.prepare(`UPDATE myshop_app_themes SET light_id=?,dark_id=?,draft_light_id=?,draft_dark_id=?,light_color=?,dark_color=?,draft_light_color=?,draft_dark_color=?,revision=revision+1,updated_by=?,updated_at=CURRENT_TIMESTAMP WHERE id=1 AND revision=?`).bind(light,dark,light,dark,lightColor,darkColor,lightColor,darkColor,admin.user_id,revision).run();
  else result=await env.DB.prepare(`UPDATE myshop_app_themes SET light_id='L1',dark_id='D1',draft_light_id='L1',draft_dark_id='D1',light_color='',dark_color='',draft_light_color='',draft_dark_color='',revision=revision+1,updated_by=?,updated_at=CURRENT_TIMESTAMP WHERE id=1 AND revision=?`).bind(admin.user_id,revision).run();
  if(Number(result.meta?.changes||0)!==1)return json({error:'THEME_CHANGED_RELOAD_REQUIRED'},409,cors);
 }
 const row=await env.DB.prepare(`SELECT * FROM myshop_app_themes WHERE id=1`).first();const config={lightId:row.light_id,darkId:row.dark_id,lightColor:row.light_color||'',darkColor:row.dark_color||'',revision:Number(row.revision),updatedAt:row.updated_at};if(admin){config.draftLightId=row.draft_light_id;config.draftDarkId=row.draft_dark_id;config.draftLightColor=row.draft_light_color||'';config.draftDarkColor=row.draft_dark_color||'';}return json({ok:true,theme:config},200,{...cors,'Cache-Control':'no-store'});
}
async function contentTranslations(request,env){
 await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_content_translations(content_key TEXT NOT NULL,language TEXT NOT NULL,value TEXT NOT NULL,updated_by TEXT NOT NULL,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(content_key,language))`).run();
 if(request.method==='PUT'){
  const a=await adminOnly(request,env);if(a.error)return a.error;const b=await body(request),key=String(b.key||'').trim();if(!/^(breaking_news|power_ad_title|power_ad_byline|feature_[a-z0-9_]{1,60}|managed_[0-9]+_(title|caption)|ad_[0-9]+_caption)$/.test(key))return json({error:'INVALID_TRANSLATION_KEY'},400,cors);
  const values=b.values;if(!values||typeof values!=='object')return json({error:'TRANSLATION_VALUES_REQUIRED'},400,cors);
  const writes=[];for(const language of ['bn','en','hi','ar']){const value=String(values[language]??'').trim();if(value.length>1000)return json({error:'TRANSLATION_TOO_LONG'},400,cors);writes.push(env.DB.prepare(`INSERT INTO myshop_content_translations(content_key,language,value,updated_by) VALUES(?,?,?,?) ON CONFLICT(content_key,language) DO UPDATE SET value=excluded.value,updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP`).bind(key,language,value,a.user.user_id));}
  await env.DB.batch(writes);
 }
 const rows=(await env.DB.prepare(`SELECT content_key,language,value FROM myshop_content_translations`).all()).results||[];return json({ok:true,translations:rows},200,cors);
}
// V-561 isolated Upcoming Live announcements. Existing ad tables are not changed.
async function upcomingSchema(env){
 await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_upcoming_live(id INTEGER PRIMARY KEY CHECK(id=1),enabled INTEGER NOT NULL DEFAULT 0,entries_json TEXT NOT NULL DEFAULT '[]',revision INTEGER NOT NULL DEFAULT 0,updated_by TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
 await env.DB.prepare(`INSERT OR IGNORE INTO myshop_upcoming_live(id) VALUES(1)`).run();
}
function validateUpcomingEntries(entries){
 if(!Array.isArray(entries)||entries.length>20)return null;
 const ids=new Set(),out=[];
 for(const x of entries){
  if(!x||typeof x!=='object'||typeof x.enabled!=='boolean')return null;
  const id=String(x.id||''),userId=String(x.userId||''),name=String(x.name||'').trim(),identity=String(x.identity||'').trim(),photoUrl=String(x.photoUrl||'').trim(),background=String(x.background||'').toUpperCase(),liveAt=Number(x.liveAt),dwellSec=Number(x.dwellSec);
  if(!/^[a-zA-Z0-9_-]{1,64}$/.test(id)||ids.has(id)||!/^\d{4}$/.test(userId)||!name||name.length>100||identity.length>180||!/^https:\/\//.test(photoUrl)||photoUrl.length>1000||!/^#[0-9A-F]{6}$/.test(background)||!Number.isSafeInteger(liveAt)||liveAt<=0||liveAt>8640000000000000||!Number.isInteger(dwellSec)||dwellSec<1||dwellSec>60)return null;
  ids.add(id);out.push({id,userId,name,identity,photoUrl,background,liveAt,dwellSec,enabled:x.enabled});
 }
 return out;
}
async function upcomingReminderSchema(env){
 await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_upcoming_reminders(scope TEXT NOT NULL,event_id TEXT NOT NULL,user_id TEXT NOT NULL,live_at INTEGER NOT NULL,PRIMARY KEY(scope,event_id,user_id))`).run();
 await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_upcoming_deliveries(scope TEXT NOT NULL,event_id TEXT NOT NULL,user_id TEXT NOT NULL,live_at INTEGER NOT NULL,kind TEXT NOT NULL,PRIMARY KEY(scope,event_id,user_id,live_at,kind))`).run();
}
async function upcomingReminder(request,env){
 const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);
 const b=await body(request);if(!['home','live'].includes(b.scope)||typeof b.enabled!=='boolean'||!String(b.eventId||'').match(/^[a-zA-Z0-9_-]{1,64}$/))return json({error:'INVALID_REMINDER'},400,cors);
 await upcomingReminderSchema(env);
 const row=await env.DB.prepare(`SELECT enabled,entries_json FROM myshop_upcoming_scopes WHERE scope=?`).bind(b.scope).first();
 const item=row&&Number(row.enabled)===1?JSON.parse(row.entries_json).find(x=>x.id===b.eventId&&x.enabled):null;
 if(!item||Number(item.liveAt)<=Date.now())return json({error:'ANNOUNCEMENT_NOT_AVAILABLE'},409,cors);
 if(b.enabled)await env.DB.prepare(`INSERT INTO myshop_upcoming_reminders(scope,event_id,user_id,live_at) VALUES(?,?,?,?) ON CONFLICT(scope,event_id,user_id) DO UPDATE SET live_at=excluded.live_at`).bind(b.scope,b.eventId,me.user_id,item.liveAt).run();
 else await env.DB.prepare(`DELETE FROM myshop_upcoming_reminders WHERE scope=? AND event_id=? AND user_id=?`).bind(b.scope,b.eventId,me.user_id).run();
 return json({ok:true,reminded:b.enabled},200,cors);
}
async function processUpcomingReminders(env){
 await upcomingReminderSchema(env);
 const exists=await env.DB.prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name='myshop_upcoming_scopes'`).first();if(!exists)return;
 const scopes=(await env.DB.prepare(`SELECT scope,entries_json FROM myshop_upcoming_scopes WHERE enabled=1`).all()).results||[];
 for(const row of scopes)for(const event of JSON.parse(row.entries_json)){if(!event.enabled)continue;
  const reminders=(await env.DB.prepare(`SELECT user_id,live_at FROM myshop_upcoming_reminders WHERE scope=? AND event_id=?`).bind(row.scope,event.id).all()).results||[];
  for(const reminder of reminders){const changed=Number(reminder.live_at)!==Number(event.liveAt),due=event.liveAt>Date.now()&&event.liveAt-Date.now()<=300000;if(!changed&&!due)continue;
   const kind=changed?'CHANGE':'DUE';const claim=await env.DB.prepare(`INSERT OR IGNORE INTO myshop_upcoming_deliveries(scope,event_id,user_id,live_at,kind) VALUES(?,?,?,?,?)`).bind(row.scope,event.id,reminder.user_id,event.liveAt,kind).run();if(!Number(claim.meta?.changes||0))continue;
   try{const notified=await createUserNotification(env,reminder.user_id,changed?'Live schedule updated':'Upcoming Live',event.name+(changed?' • সময় পরিবর্তিত হয়েছে':' • ৫ মিনিটের মধ্যে লাইভের নির্ধারিত সময়'),'LIVE_UPCOMING',event.userId,event.userId);if(!notified)throw new Error('UPCOMING_NOTIFICATION_NOT_STORED');if(changed)await env.DB.prepare(`UPDATE myshop_upcoming_reminders SET live_at=? WHERE scope=? AND event_id=? AND user_id=?`).bind(event.liveAt,row.scope,event.id,reminder.user_id).run();}
   catch(e){await env.DB.prepare(`DELETE FROM myshop_upcoming_deliveries WHERE scope=? AND event_id=? AND user_id=? AND live_at=? AND kind=?`).bind(row.scope,event.id,reminder.user_id,event.liveAt,kind).run();throw e;}
  }
 }
}
async function upcomingLive(request,env){
 const url=new URL(request.url),scope=url.searchParams.get('scope')||'legacy';
 if(!['legacy','home','live'].includes(scope))return json({error:'INVALID_UPCOMING_SCOPE'},400,cors);
 const admin=url.pathname.includes('/admin/');
 let auth;if(admin){auth=await adminOnly(request,env);if(auth.error)return auth.error;}
 await upcomingSchema(env);
 // One-time seed preserves the V560 row; independent scopes never write it.
 await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_upcoming_scopes(scope TEXT PRIMARY KEY,enabled INTEGER NOT NULL DEFAULT 0,entries_json TEXT NOT NULL DEFAULT '[]',revision INTEGER NOT NULL DEFAULT 0,updated_by TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
 if(scope!=='legacy')await env.DB.batch(['home','live'].map(page=>env.DB.prepare(`INSERT OR IGNORE INTO myshop_upcoming_scopes(scope,enabled,entries_json) SELECT ?,enabled,entries_json FROM myshop_upcoming_live WHERE id=1`).bind(page)));
 const table=scope==='legacy'?'myshop_upcoming_live':'myshop_upcoming_scopes',where=scope==='legacy'?'id=1':'scope=?';
 if(request.method==='PUT'){
  const b=await body(request),entries=validateUpcomingEntries(b.entries);
  if(!entries||typeof b.enabled!=='boolean'||!Number.isInteger(b.revision)||b.revision<0)return json({error:'INVALID_UPCOMING_LIVE'},400,cors);
  const args=[b.enabled?1:0,JSON.stringify(entries),auth.user.user_id];if(scope!=='legacy')args.push(scope);args.push(b.revision);
  const result=await env.DB.prepare(`UPDATE ${table} SET enabled=?,entries_json=?,revision=revision+1,updated_by=?,updated_at=CURRENT_TIMESTAMP WHERE ${where} AND revision=?`).bind(...args).run();
  if(Number(result.meta?.changes||0)!==1)return json({error:'UPCOMING_CHANGED_RELOAD_REQUIRED'},409,cors);
 }
 const query=env.DB.prepare(`SELECT * FROM ${table} WHERE ${where}`);
 const row=await (scope==='legacy'?query:query.bind(scope)).first();
 const all=JSON.parse(row.entries_json),enabled=Number(row.enabled)===1;
 const entries=admin?all:enabled?all.filter(x=>x.enabled):[];
 if(scope!=='legacy'&&!admin){
  await upcomingReminderSchema(env);const me=await getUser(request,env),reminded=new Set(),liveHosts=new Set();
  if(me){const rows=(await env.DB.prepare(`SELECT event_id FROM myshop_upcoming_reminders WHERE scope=? AND user_id=?`).bind(scope,me.user_id).all()).results||[];for(const row of rows)reminded.add(row.event_id);}
  if(entries.length)try{const hosts=[...new Set(entries.map(x=>x.userId))],marks=hosts.map(()=>'?').join(',');const rows=(await env.DB.prepare(`SELECT p.user_id FROM myshop_live_presence p JOIN myshop_live_room_meta m ON m.host_id=p.user_id WHERE p.user_id IN (${marks}) AND p.active=1 AND datetime(p.last_seen)>=datetime('now','-2 minutes') AND COALESCE(m.session_id,'')<>''`).bind(...hosts).all()).results||[];for(const row of rows)liveHosts.add(row.user_id);}catch(e){}
  for(const entry of entries){entry.reminded=reminded.has(entry.id);entry.isLive=liveHosts.has(entry.userId);}
 }
 // Countdown expiration alone never means the host is live.
 return json({ok:true,scope,enabled,entries,revision:Number(row.revision),serverNow:Date.now()},200,{...cors,'Cache-Control':'no-store'});
}

async function dashboardConfig(request, env) {
  try{await ensureSchemasOnce(env);}catch(e){return json({error:'DASHBOARD_SCHEMA_UNAVAILABLE'},503,cors);}
  let config={}; let banners=[]; let socialLinks=[]; let gallery=[]; let featureButtons=[]; let managedLinks=[]; let media=[];
  try { config=(await env.DB.prepare('SELECT * FROM dashboard_config WHERE id=1').first())||{}; } catch (_) {}
  try { banners=(await env.DB.prepare(`SELECT b.id,b.folder,b.slot,b.image_url,b.caption,b.target_url,b.active,COALESCE(d.display_seconds,4) display_seconds,b.updated_at FROM banners b LEFT JOIN myshop_banner_durations d ON d.folder=b.folder AND d.slot=b.slot WHERE b.active=1 AND (b.folder NOT IN ('hero','promo') OR EXISTS(SELECT 1 FROM myshop_banner_sections s WHERE s.folder=b.folder AND s.enabled=1)) ORDER BY b.folder,b.slot`).all()).results||[]; } catch (_) {}
  let bannerSections=[];try{bannerSections=(await env.DB.prepare(`SELECT folder,enabled FROM myshop_banner_sections WHERE folder IN ('hero','promo')`).all()).results||[];}catch(_){}
  try { socialLinks=(await env.DB.prepare('SELECT platform,url,active,icon_key,icon_url,image_url,caption FROM social_links WHERE active=1 ORDER BY platform').all()).results||[]; } catch (_) {}
  try { gallery=(await env.DB.prepare('SELECT id,title,media_url,media_type,active,display_order FROM gallery_items WHERE active=1 ORDER BY display_order,id').all()).results||[]; } catch (_) {}
  try { featureButtons=(await env.DB.prepare('SELECT key,title,icon_url,target_url,active,display_order,icon_size FROM feature_buttons ORDER BY display_order,key').all()).results||[]; } catch (_) {}
  try { managedLinks=(await env.DB.prepare('SELECT id,category,title,caption,url,icon_url,image_url,active,display_order,price_minor,offer_text,offer_start,offer_end,time_limit_minutes,status,coming_soon_message,revision,archived FROM managed_links ORDER BY category,display_order,id').all()).results||[]; } catch (_) {}
  try { media=(await env.DB.prepare('SELECT id,folder,title,caption,media_url,object_key,media_type,active,display_order FROM gallery_media WHERE active=1 ORDER BY folder,display_order,id').all()).results||[]; } catch (_) {}
  let dashboardAds=[];
  try { dashboardAds=(await env.DB.prepare('SELECT id,box_key,slot,image_url,caption,target_url,media_type,active,duration_sec,display_mode,updated_at FROM dashboard_ads WHERE active=1 ORDER BY box_key,slot').all()).results||[]; } catch (_) {}
  let translations=[];try{translations=(await env.DB.prepare(`SELECT content_key,language,value FROM myshop_content_translations`).all()).results||[];}catch(e){}
  return json({ok:true,config,banners,bannerSections,socialLinks,gallery,featureButtons:homeFeaturePresentation(featureButtons,managedLinks),managedLinks,media,dashboardAds,translations},200,cors);
}

async function adminBannerSection(request,env){
  try{await ensureSchemasOnce(env);}catch(e){return json({error:'BANNER_SCHEMA_UNAVAILABLE'},503,cors);}
  const auth=await adminOnly(request,env);if(auth.error)return auth.error;
  const allowed=['hero','promo','live_home','shop_home','shop_promo'];
  if(request.method==='GET'){
    const folder=String(new URL(request.url).searchParams.get('folder')||'').trim().toLowerCase();
    if(!allowed.includes(folder))return json({error:'INVALID_BANNER_FOLDER'},400,cors);
    let row=await env.DB.prepare('SELECT folder,enabled FROM myshop_banner_sections WHERE folder=?').bind(folder).first();
    if(!row){await env.DB.prepare('INSERT OR IGNORE INTO myshop_banner_sections(folder,enabled) VALUES(?,1)').bind(folder).run();row={folder,enabled:1};}
    return json({ok:true,folder,enabled:Number(row.enabled)!==0},200,cors);
  }
  if(request.method==='PUT'){
    const b=await body(request),folder=String(b.folder||'').trim().toLowerCase();
    if(!allowed.includes(folder)||typeof b.enabled!=='boolean')return json({error:'INVALID_BANNER_SECTION'},400,cors);
    await env.DB.prepare(`INSERT INTO myshop_banner_sections(folder,enabled,updated_by,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(folder) DO UPDATE SET enabled=excluded.enabled,updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP`).bind(folder,b.enabled?1:0,auth.user.user_id).run();
    return json({ok:true,folder,enabled:b.enabled},200,cors);
  }
  return json({error:'METHOD_NOT_ALLOWED'},405,cors);
}

async function adminOnly(request, env) {
  const user = await getUser(request,env);
  if (!user) return {error:json({error:'ADMIN_REQUIRED'},403,cors)};
  const fixedAdmin = ['0001','0002','0003'].includes(String(user.user_id));
  if (fixedAdmin && user.role !== 'ADMIN') {
    await env.DB.prepare("UPDATE myshop_auth_users_v108 SET role='ADMIN', updated_at=CURRENT_TIMESTAMP WHERE user_id=?").bind(user.user_id).run();
    user.role = 'ADMIN';
  }
  if (user.role !== 'ADMIN') return {error:json({error:'ADMIN_REQUIRED'},403,cors)};
  return {user};
}

function safeDashboardHex(value){
  const s=String(value||'').trim().toUpperCase(); return /^#[0-9A-F]{6}$/.test(s)?s:'';
}

async function adminDashboardPut(request, env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const b = await body(request);
  await env.DB.prepare(`UPDATE dashboard_config SET breaking_news=?,my_shop_url=?,live_tv_url=?,external_movie_url=?,chat_url=?,power_ad_title=?,power_ad_byline=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`)
    .bind(String(b.breakingNews||''),String(b.myShopUrl||''),String(b.liveTvUrl||''),String(b.externalMovieUrl||''),String(b.chatUrl||''),String(b.powerAdTitle||'POWER AD').trim().slice(0,60)||'POWER AD',String(b.powerAdByline||'by Touhid').trim().slice(0,60)||'by Touhid').run();
  if(Object.prototype.hasOwnProperty.call(b,'breakingNewsTextSize')){
    const size=Math.max(10,Math.min(24,Number(b.breakingNewsTextSize)||13.0));
    await env.DB.prepare(`UPDATE dashboard_config SET breaking_news_text_size=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`).bind(size).run();
  }
  const bg=safeDashboardHex(b.dashboardBgColor),blue=safeDashboardHex(b.dashboardBlueColor),purple=safeDashboardHex(b.dashboardPurpleColor),pink=safeDashboardHex(b.dashboardPinkColor);
  if(bg&&blue&&purple&&pink){
    await env.DB.prepare(`UPDATE dashboard_config SET dashboard_bg_color=?,dashboard_blue_color=?,dashboard_purple_color=?,dashboard_pink_color=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`).bind(bg,blue,purple,pink).run();
  }
  const breakingBg=safeDashboardHex(b.breakingNewsBgColor),breakingText=safeDashboardHex(b.breakingNewsTextColor);
  if(breakingBg&&breakingText){
    await env.DB.prepare(`UPDATE dashboard_config SET breaking_news_bg_color=?,breaking_news_text_color=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`).bind(breakingBg,breakingText).run();
  }
  await createBroadcastNotification(env,'MY SHOP আপডেট','ড্যাশবোর্ডের কনটেন্ট আপডেট করা হয়েছে।');
  return json({ok:true},200,cors);
}

async function adminContentPut(request, env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const b = await body(request);

  // Non-Live feature edits must go through private Draft and explicit Publish.
  // Reject a mixed legacy payload before any unrelated record is mutated.
  if(Array.isArray(b.managedLinks)&&b.managedLinks.some(x=>/^feature_[a-z0-9_]{1,80}$/.test(String(x?.category||''))&&!/(?:^|_)(?:live|rtc|audio|gift|gifts|room)(?:_|$)/.test(String(x.category))&&!['feature_go_live','feature_top_gifters'].includes(String(x.category))))return json({error:'PRIVATE_DRAFT_AND_EXPLICIT_PUBLISH_REQUIRED'},409,cors);

  const banners = Array.isArray(b.banners) ? b.banners : [];
  for (const x of banners) {
    const folder=String(x.folder||'').trim().toLowerCase(); const slot=Number(x.slot||0);
    if (!['hero','promo'].includes(folder) || !Number.isInteger(slot) || slot<1 || slot>20) continue;
    const imageUrl=String(x.imageUrl||x.image_url||'').trim(); const caption=String(x.caption||'').trim(); const active=x.active===false?0:1;
    if(!imageUrl){ await env.DB.prepare('DELETE FROM myshop_banner_durations WHERE folder=? AND slot=?').bind(folder,slot).run();await env.DB.prepare('DELETE FROM banners WHERE folder=? AND slot=?').bind(folder,slot).run(); continue; }
    const existingBanner=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=? ORDER BY id DESC LIMIT 1').bind(folder,slot).first();
    if(existingBanner?.id){ await env.DB.prepare('UPDATE banners SET image_url=?,caption=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(imageUrl,caption,active,existingBanner.id).run(); }
    else { await insertBannerCompat(env,{folder,slot,imageUrl,caption,active}); }
  }

  const social = Array.isArray(b.socialLinks) ? b.socialLinks : [];
  for (const x of social) {
    const platform=String(x.platform||'').trim(); if(!platform) continue;
    const url=String(x.url||'').trim(); const active=x.active===false?0:(url?1:0); const iconKey=String(x.iconKey||x.icon_key||platform).trim().toLowerCase().slice(0,40); const iconUrl=String(x.iconUrl||x.icon_url||'').trim(); const imageUrl=String(x.imageUrl||x.image_url||'').trim(); const caption=String(x.caption||'').trim().slice(0,160);
    if(!url){ await env.DB.prepare('DELETE FROM social_links WHERE lower(platform)=lower(?)').bind(platform).run(); continue; }
    const existingSocial=await env.DB.prepare('SELECT id FROM social_links WHERE lower(platform)=lower(?) ORDER BY id LIMIT 1').bind(platform).first();
    if(existingSocial?.id){
      await env.DB.prepare('UPDATE social_links SET platform=?,url=?,icon_key=?,icon_url=?,image_url=?,caption=?,active=? WHERE id=?').bind(platform,url,iconKey,iconUrl,imageUrl,caption,active,existingSocial.id).run();
    } else {
      await env.DB.prepare('INSERT INTO social_links(platform,url,icon_key,icon_url,image_url,caption,active) VALUES(?,?,?,?,?,?,?)').bind(platform,url,iconKey,iconUrl,imageUrl,caption,active).run();
    }
  }

  const gallery = Array.isArray(b.gallery) ? b.gallery : [];
  for (const x of gallery) {
    const title=String(x.title||'').trim(); const mediaUrl=String(x.mediaUrl||x.media_url||'').trim(); if(!mediaUrl) continue;
    const mediaType=String(x.mediaType||x.media_type||'image').trim()||'image'; const active=x.active===false?0:1; const order=Math.max(1,Number(x.displayOrder||1));
    const existing=await env.DB.prepare('SELECT id FROM gallery_items WHERE display_order=? LIMIT 1').bind(order).first();
    if(existing) await env.DB.prepare('UPDATE gallery_items SET title=?,media_url=?,media_type=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(title,mediaUrl,mediaType,active,existing.id).run();
    else await env.DB.prepare('INSERT INTO gallery_items(title,media_url,media_type,active,display_order) VALUES(?,?,?,?,?)').bind(title,mediaUrl,mediaType,active,order).run();
  }

  const features = Array.isArray(b.featureButtons) ? b.featureButtons : [];
  if(features.length>100)return json({error:'TOO_MANY_ICONS'},400,cors);
  const orderPage=String(b.orderPage||'');
  if(orderPage&&!['home1','live2'].includes(orderPage))return json({error:'INVALID_ICON_PAGE'},400,cors);
  const normalized=[];const seenKeys=new Set(),seenSlots=new Set();
  for(const x of features){
    const key=String(x.key||'').trim();
    if(!key||seenKeys.has(key)||(orderPage&&!key.startsWith(orderPage+'_')))return json({error:'INVALID_ICON_KEY'},400,cors);
    const order=Number(x.displayOrder??x.display_order??1),size=Number(x.iconSize??x.icon_size??40);
    if(!Number.isInteger(order)||order<1||!Number.isFinite(size))return json({error:'INVALID_ICON_POSITION'},400,cors);
    if(orderPage&&(seenSlots.has(order)||order>features.length))return json({error:'DUPLICATE_ICON_POSITION'},400,cors);
    seenKeys.add(key);seenSlots.add(order);
    normalized.push({key,title:String(x.title||'').trim().slice(0,100),icon:String(x.iconUrl||x.icon_url||'').trim(),target:String(x.targetUrl||x.target_url||'').trim(),active:x.active===false||x.active===0?0:1,order,size:Math.max(28,Math.min(56,Math.round(size)))});
  }
  const writes=[];
  for(const x of normalized){
    const exists=await env.DB.prepare('SELECT key FROM feature_buttons WHERE key=? LIMIT 1').bind(x.key).first();
    writes.push(exists?env.DB.prepare('UPDATE feature_buttons SET title=?,icon_url=?,target_url=?,active=?,display_order=?,icon_size=?,updated_at=CURRENT_TIMESTAMP WHERE key=?').bind(x.title,x.icon,x.target,x.active,x.order,x.size,x.key):env.DB.prepare('INSERT INTO feature_buttons(key,title,icon_url,target_url,active,display_order,icon_size,updated_at) VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)').bind(x.key,x.title,x.icon,x.target,x.active,x.order,x.size));
  }
  if(writes.length)await env.DB.batch(writes);

  // Explicit deletes for content records. User/auth tables are never touched.
  for (const x of (Array.isArray(b.deleteBanners)?b.deleteBanners:[])) {
    const folder=String(x.folder||'').trim().toLowerCase(); const slot=Number(x.slot||0);
    if(['hero','promo'].includes(folder) && Number.isInteger(slot)&&slot>=1&&slot<=20){const media=(await env.DB.prepare('SELECT object_key FROM banner_media WHERE folder=? AND slot=?').bind(folder,slot).all()).results||[];if(env.MEDIA)for(const m of media)if(m.object_key)try{await env.MEDIA.delete(m.object_key);}catch(_){}await env.DB.prepare('DELETE FROM banner_media WHERE folder=? AND slot=?').bind(folder,slot).run();await env.DB.prepare('DELETE FROM banners WHERE folder=? AND slot=?').bind(folder,slot).run();}
  }
  for (const platform of (Array.isArray(b.deleteSocialPlatforms)?b.deleteSocialPlatforms:[])) {
    await env.DB.prepare('DELETE FROM social_links WHERE platform=?').bind(String(platform||'').trim()).run();
  }
  for (const key of (Array.isArray(b.deleteFeatureKeys)?b.deleteFeatureKeys:[])) {
    await env.DB.prepare('UPDATE feature_buttons SET active=0,updated_at=CURRENT_TIMESTAMP WHERE key=?').bind(String(key||'').trim()).run();
  }
  const links = Array.isArray(b.managedLinks) ? b.managedLinks : [];
  for (const x of links) {
    const id=Number(x.id||0); const category=String(x.category||'').trim().toLowerCase(); const title=String(x.title||'').trim(); const caption=String(x.caption||'').trim(); const url=String(x.url||'').trim(); const iconUrl=String(x.iconUrl||x.icon_url||'').trim(); const imageUrl=String(x.imageUrl||x.image_url||'').trim(); const active=x.active===false||x.active===0?0:1; const order=Math.max(1,Number(x.displayOrder??x.display_order??1)); const priceMinor=Math.max(0,Math.round(Number(x.priceMinor??x.price_minor??0))); const offerText=String(x.offerText??x.offer_text??'').trim().slice(0,160); const offerStart=String(x.offerStart??x.offer_start??'').trim().slice(0,80); const offerEnd=String(x.offerEnd??x.offer_end??'').trim().slice(0,80); const timeLimit=Math.max(0,Math.round(Number(x.timeLimitMinutes??x.time_limit_minutes??0))); const status=String(x.status||'').trim().toUpperCase()||'ACTIVE';
    if(!category) continue;
    if(/^feature_[a-z0-9_]{1,80}$/.test(category)){await env.DB.prepare(featureHistorySchema).run();const current=id?await env.DB.prepare('SELECT revision FROM managed_links WHERE id=? AND category=?').bind(id,category).first():null;const saved=await writeManagedFeature(env.DB,auth.user.user_id,x,x.expectedRevision??Number(current?.revision||0));if(saved.error)return json({error:saved.error},saved.statusCode,cors);continue;}
    if(!['ACTIVE','DISABLED','COMING_SOON','UPCOMING','LAUNCHING_SOON'].includes(status)) continue;
    if(id>0) await env.DB.prepare('UPDATE managed_links SET category=?,title=?,caption=?,url=?,icon_url=?,image_url=?,active=?,display_order=?,price_minor=?,offer_text=?,offer_start=?,offer_end=?,time_limit_minutes=?,status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(category,title,caption,url,iconUrl,imageUrl,active,order,priceMinor,offerText,offerStart,offerEnd,timeLimit,status,id).run();
    else await env.DB.prepare('INSERT INTO managed_links(category,title,caption,url,icon_url,image_url,active,display_order,price_minor,offer_text,offer_start,offer_end,time_limit_minutes,status,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?, ?,CURRENT_TIMESTAMP)').bind(category,title,caption,url,iconUrl,imageUrl,active,order,priceMinor,offerText,offerStart,offerEnd,timeLimit,status).run();
  }
  for (const id of (Array.isArray(b.deleteManagedLinkIds)?b.deleteManagedLinkIds:[])) {
    const item=await env.DB.prepare('SELECT * FROM managed_links WHERE id=?').bind(Number(id)).first();
    if(item&&/^feature_[a-z0-9_]{1,80}$/.test(item.category)){await env.DB.prepare(featureHistorySchema).run();const saved=await writeManagedFeature(env.DB,auth.user.user_id,{id:item.id,category:item.category},Number(item.revision||0),'ARCHIVE');if(saved.error)return json({error:saved.error},saved.statusCode,cors);}
    else await env.DB.prepare('DELETE FROM managed_links WHERE id=?').bind(Number(id)).run();
  }

  await createBroadcastNotification(env,'MY SHOP আপডেট','ব্যানার, সোশ্যাল বা ফিচার কনটেন্টে নতুন পরিবর্তন এসেছে।');
  return json({ok:true},200,cors);
}

async function adminBannerUpload(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  if(!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(); const folder=String(form.get('folder')||'').trim().toLowerCase(); const slot=Number(form.get('slot')||0); const file=form.get('file'); const caption=String(form.get('caption')||'').trim(); const targetUrl=String(form.get('targetUrl')||'').trim().slice(0,1000); const startAt=parseScheduleIso(form.get('startAt')); const endAt=parseScheduleIso(form.get('endAt')); const displaySecondsRaw=String(form.get('displaySeconds')||'4').trim();const displaySeconds=Number(displaySecondsRaw); if(!Number.isInteger(displaySeconds)||displaySeconds<1||displaySeconds>30)return json({error:'INVALID_DISPLAY_SECONDS'},400,cors); if(String(form.get('startAt')||'').trim()&&!startAt)return json({error:'INVALID_START_TIME'},400,cors); if(String(form.get('endAt')||'').trim()&&!endAt)return json({error:'INVALID_END_TIME'},400,cors); if(startAt&&endAt&&Date.parse(endAt)<=Date.parse(startAt))return json({error:'END_BEFORE_START'},400,cors);
  const bannerMax=20; if(!managedBannerFolder(folder) || !Number.isInteger(slot) || slot<1 || slot>bannerMax || !(file instanceof File)) return json({error:'INVALID_BANNER'},400,cors);
  const bannerType=guessContentType(file);
  if(!bannerType.startsWith('image/')) return json({error:'BANNER_MUST_BE_IMAGE'},400,cors);
  if(file.size>15*1024*1024) return json({error:'BANNER_TOO_LARGE'},413,cors);
  const old=await env.DB.prepare('SELECT id,object_key FROM banner_media WHERE folder=? AND slot=? ORDER BY id DESC LIMIT 1').bind(folder,slot).first();
  // Safety: never delete the currently working banner until the new object and D1 rows are committed.
  const oldKey=old?.object_key||'';
  const ext=(String(file.name||'jpg').split('.').pop()||'jpg').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'jpg';
  const key=`banners/${folder}/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  try {
    await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:bannerType||'application/octet-stream',cacheControl:'public, max-age=31536000'}});
  } catch (e) {
    return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);
  }
  const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  try {
    // Backward-compatible write path: some existing D1 databases may have been created
    // before the UNIQUE(folder,slot) constraint existed. Do not depend on ON CONFLICT.
    const existingBanner=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=? ORDER BY id DESC LIMIT 1').bind(folder,slot).first();
    if(existingBanner?.id){
      await env.DB.prepare('UPDATE banners SET image_url=?,caption=?,target_url=?,active=1,start_at=?,end_at=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(url,caption,targetUrl,startAt,endAt,existingBanner.id).run();
    } else {
      await insertBannerCompat(env,{folder,slot,imageUrl:url,caption,active:1}); await env.DB.prepare('UPDATE banners SET target_url=?,start_at=?,end_at=? WHERE folder=? AND slot=?').bind(targetUrl,startAt,endAt,folder,slot).run();
    }
    await env.DB.prepare(`INSERT INTO myshop_banner_durations(folder,slot,display_seconds,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(folder,slot) DO UPDATE SET display_seconds=excluded.display_seconds,updated_at=CURRENT_TIMESTAMP`).bind(folder,slot,displaySeconds).run();
    // V-528: one slot = one banner. Clean legacy duplicate rows so replacing a slot can never leave the old banner active.
    const keepBanner=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=? ORDER BY id DESC LIMIT 1').bind(folder,slot).first();
    if(keepBanner?.id) await env.DB.prepare('DELETE FROM banners WHERE folder=? AND slot=? AND id<>?').bind(folder,slot,keepBanner.id).run();
    const existingMedia=await env.DB.prepare('SELECT id FROM banner_media WHERE folder=? AND slot=? ORDER BY id DESC LIMIT 1').bind(folder,slot).first();
    if(existingMedia?.id){
      await env.DB.prepare('UPDATE banner_media SET object_key=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(key,existingMedia.id).run();
      await env.DB.prepare('DELETE FROM banner_media WHERE folder=? AND slot=? AND id<>?').bind(folder,slot,existingMedia.id).run();
    } else {
      await env.DB.prepare('INSERT INTO banner_media(folder,slot,object_key,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP)').bind(folder,slot,key).run();
    }
  } catch(e) {
    try { await env.MEDIA.delete(key); } catch(_) {}
    return json({error:'BANNER_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors);
  }
  if(oldKey && oldKey!==key){ try { await env.MEDIA.delete(oldKey); } catch(_) {} }
  try{await createBroadcastNotification(env,'নতুন ব্যানার','MY SHOP-এ নতুন ব্যানার আপডেট হয়েছে।');}catch(e){console.error('BANNER_NOTIFICATION_FAILED',String(e));}
  return json({ok:true,folder,slot,image_url:url,caption,targetUrl,startAt,endAt},201,cors);
}

async function adminBannerOrder(request,env){
 await ensureBannerRowsSchema(env);
 const auth=await adminOnly(request,env);if(auth.error)return auth.error;
 const b=await body(request),folder=String(b.folder||'').trim().toLowerCase(),slots=b.slots;
 if(!managedBannerFolder(folder)||!Array.isArray(slots)||![6,20].includes(slots.length)||new Set(slots).size!==slots.length||slots.some(n=>!Number.isInteger(n)||n<1||n>slots.length))return json({error:'INVALID_BANNER_ORDER'},400,cors);
 const tables=['banners','banner_media','myshop_banner_durations'];
 const queries=tables.map(table=>env.DB.prepare(`UPDATE ${table} SET slot=slot+100 WHERE folder=? AND slot BETWEEN 1 AND ${slots.length}`).bind(folder));
 for(let i=0;i<slots.length;i++)for(const table of tables)queries.push(env.DB.prepare(`UPDATE ${table} SET slot=? WHERE folder=? AND slot=?`).bind(i+1,folder,slots[i]+100));
 await env.DB.batch(queries);return json({ok:true,folder,slots},200,cors);
}

async function adminGeneralMenuOrder(request,env){
 const auth=await adminOnly(request,env);if(auth.error)return auth.error;
 const b=await body(request);if(!Array.isArray(b.keys))return json({error:'INVALID_GENERAL_ORDER'},400,cors);const keys=b.keys,isProfile=b.page==='profile',prefix=isProfile?'profile_shortcut_':'home_menu_',allowed=isProfile?(keys.includes('gifters')||keys.includes('view_as')?['wallet','shop','live','gifters','view_as','links']:['wallet','shop','live','membership','items','links']):['agent','my_links','deals','whats_new','my_tasks','shorts','events','flash_sale','invite','safety_privacy'],titles=isProfile?(allowed.includes('gifters')?['My Wallet','Store','Join Live','Top Gifters','View As','Links']:['My Wallet','My Shop','Go Live','Membership','My Items','Social Links']):['Agent','My Links','Deals','What’s New','My Tasks','Shorts','Events','Flash Sale','Invite','Safety & Privacy'];
 if(!Array.isArray(keys)||keys.length!==allowed.length||new Set(keys).size!==allowed.length||keys.some(k=>!allowed.includes(k)))return json({error:'INVALID_GENERAL_ORDER'},400,cors);
 const queries=[];for(let i=0;i<keys.length;i++){const category=prefix+keys[i];queries.push(env.DB.prepare(`INSERT INTO managed_links(category,title,caption,url,icon_url,image_url,active,display_order) SELECT ?,?,'','','','',1,? WHERE NOT EXISTS(SELECT 1 FROM managed_links WHERE category=?)`).bind(category,titles[allowed.indexOf(keys[i])],i+1,category));queries.push(env.DB.prepare(`UPDATE managed_links SET display_order=? WHERE category=?`).bind(i+1,category));}
 await env.DB.batch(queries);return json({ok:true,keys},200,cors);
}

async function adminBannerUpdate(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const b=await body(request); const folder=String(b.folder||'').trim().toLowerCase(); const slot=Number(b.slot||0); const caption=String(b.caption||'').trim(); const targetUrl=String(b.targetUrl||'').trim().slice(0,1000); const startAt=parseScheduleIso(b.startAt); const endAt=parseScheduleIso(b.endAt); if(String(b.startAt||'').trim()&&!startAt)return json({error:'INVALID_START_TIME'},400,cors); if(String(b.endAt||'').trim()&&!endAt)return json({error:'INVALID_END_TIME'},400,cors); if(startAt&&endAt&&Date.parse(endAt)<=Date.parse(startAt))return json({error:'END_BEFORE_START'},400,cors); const hasActive=Object.prototype.hasOwnProperty.call(b,'active'); const active=hasActive?(b.active===false?0:1):null;const hasDisplaySeconds=Object.prototype.hasOwnProperty.call(b,'displaySeconds');const displaySeconds=Number(b.displaySeconds);if(hasDisplaySeconds&&(!Number.isInteger(displaySeconds)||displaySeconds<1||displaySeconds>30))return json({error:'INVALID_DISPLAY_SECONDS'},400,cors);
  const bannerMax=20; if(!managedBannerFolder(folder)||!Number.isInteger(slot)||slot<1||slot>bannerMax) return json({error:'INVALID_BANNER'},400,cors);
  const row=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=?').bind(folder,slot).first();
  if(!row) return json({error:'BANNER_NOT_FOUND'},404,cors);
  const fields=['caption=?','target_url=?','start_at=?','end_at=?'];const values=[caption,targetUrl,startAt,endAt];if(hasActive){fields.push('active=?');values.push(active);}fields.push('updated_at=CURRENT_TIMESTAMP');values.push(folder,slot);await env.DB.prepare(`UPDATE banners SET ${fields.join(',')} WHERE folder=? AND slot=?`).bind(...values).run();if(hasDisplaySeconds)await env.DB.prepare(`INSERT INTO myshop_banner_durations(folder,slot,display_seconds,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(folder,slot) DO UPDATE SET display_seconds=excluded.display_seconds,updated_at=CURRENT_TIMESTAMP`).bind(folder,slot,displaySeconds).run();
  try{await createBroadcastNotification(env,'ব্যানার আপডেট','একটি ব্যানারের ক্যাপশন আপডেট হয়েছে।');}catch(e){console.error('BANNER_NOTIFICATION_FAILED',String(e));}
  return json({ok:true,folder,slot,caption,targetUrl,startAt,endAt},200,cors);
}

async function adminBannerDelete(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error; const b=await body(request); const folder=String(b.folder||'').trim().toLowerCase(); const slot=Number(b.slot||0); const bannerMax=20; if(!managedBannerFolder(folder)||!Number.isInteger(slot)||slot<1||slot>bannerMax) return json({error:'INVALID_BANNER'},400,cors);
  const oldRows=(await env.DB.prepare('SELECT object_key FROM banner_media WHERE folder=? AND slot=?').bind(folder,slot).all()).results||[];if(env.MEDIA)for(const old of oldRows)if(old.object_key)try{await env.MEDIA.delete(old.object_key);}catch(e){console.error('BANNER_OBJECT_DELETE_FAILED',String(e?.message||e));}
  await env.DB.prepare('DELETE FROM banner_media WHERE folder=? AND slot=?').bind(folder,slot).run(); await env.DB.prepare('DELETE FROM myshop_banner_durations WHERE folder=? AND slot=?').bind(folder,slot).run(); await env.DB.prepare('DELETE FROM banners WHERE folder=? AND slot=?').bind(folder,slot).run(); try{await createBroadcastNotification(env,'ব্যানার আপডেট','একটি ব্যানার সরানো হয়েছে।');}catch(e){console.error('BANNER_NOTIFICATION_FAILED',String(e));} return json({ok:true,folder,slot,empty:true},200,cors);
}


async function adminLiveHomeBanners(request,env){
  try{await ensureSchemasOnce(env);}catch(e){return json({error:'BANNER_SCHEMA_UNAVAILABLE'},503,cors);}
  const auth=await adminOnly(request,env);if(auth.error)return auth.error;
  const folder=String(new URL(request.url).searchParams.get('folder')||'live_home').toLowerCase();
  if(!managedBannerFolder(folder))return json({error:'INVALID_BANNER_FOLDER'},400,cors);
  const rows=(await env.DB.prepare(`SELECT b.id,b.folder,b.slot,b.image_url,b.caption,b.target_url,b.active,b.start_at,b.end_at,COALESCE(d.display_seconds,4) display_seconds,b.updated_at FROM banners b LEFT JOIN myshop_banner_durations d ON d.folder=b.folder AND d.slot=b.slot WHERE b.folder=? AND b.slot BETWEEN 1 AND 20 AND b.id=(SELECT MAX(id) FROM banners x WHERE x.folder=b.folder AND x.slot=b.slot) ORDER BY b.slot`).bind(folder).all()).results||[];
  let section=await env.DB.prepare('SELECT enabled FROM myshop_banner_sections WHERE folder=?').bind(folder).first();if(!section){await env.DB.prepare('INSERT OR IGNORE INTO myshop_banner_sections(folder,enabled) VALUES(?,1)').bind(folder).run();section={enabled:1};}
  return json({ok:true,banners:rows,folder,maxSlots:20,sectionEnabled:Number(section.enabled)!==0},200,cors);
}

async function publicLiveHomeBanners(request,env){
  try{await ensureBannerRowsSchema(env);}catch(e){return json({error:'BANNER_CONFIG_TEMPORARILY_UNAVAILABLE'},503,cors);}
  const pathname=new URL(request.url).pathname,requested=new URL(request.url).searchParams.get('folder');
  const folder=pathname==='/v1/shop/banners'?(requested==='shop_promo'?'shop_promo':'shop_home'):'live_home';
  // Lightweight public carousel endpoint. Do not run the full schema bootstrap here;
  // if the table is temporarily unavailable, return an empty list and keep the app alive.
  let rows=[],sectionEnabled=true;
  try {
    if(['live_home','shop_home','shop_promo'].includes(folder)){const section=await env.DB.prepare('SELECT enabled FROM myshop_banner_sections WHERE folder=?').bind(folder).first();if(section)sectionEnabled=Number(section.enabled)!==0;}
    const raw=sectionEnabled?((await env.DB.prepare(`SELECT b.id,b.folder,b.slot,b.image_url,b.caption,b.target_url,b.active,b.start_at,b.end_at,COALESCE(d.display_seconds,4) display_seconds,b.updated_at,
      (SELECT bm.object_key FROM banner_media bm WHERE lower(trim(bm.folder))=lower(trim(b.folder)) AND bm.slot=b.slot ORDER BY bm.id DESC LIMIT 1) object_key
      FROM banners b LEFT JOIN myshop_banner_durations d ON d.folder=b.folder AND d.slot=b.slot WHERE lower(trim(b.folder))=? AND b.id=(SELECT MAX(x.id) FROM banners x WHERE lower(trim(x.folder))=? AND x.slot=b.slot) AND COALESCE(b.active,1)=1 AND b.slot BETWEEN 1 AND 20 AND (COALESCE(b.start_at,'')='' OR datetime(b.start_at)<=datetime('now')) AND (COALESCE(b.end_at,'')='' OR datetime(b.end_at)>datetime('now')) ORDER BY b.slot`).bind(folder,folder).all()).results||[]):[];
    const origin=new URL(request.url).origin;
    rows=raw.map(r=>{const direct=String(r.image_url||'').trim(),key=String(r.object_key||'').trim();return {...r,image_url:direct||(key?origin+'/v1/media/'+encodeURIComponent(key):'')};}).filter(r=>String(r.image_url||'').trim()!=='');
  } catch (_) {return json({error:"BANNERS_TEMPORARILY_UNAVAILABLE"},503,cors);}
  return json({ok:true,banners:rows,sectionEnabled},200,cors);
}

async function adminMediaList(request,env) {
  try { await ensureSchemasOnce(env); } catch (_) {}
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const folder=safeMediaFolder(new URL(request.url).searchParams.get('folder')||'');
  const sql=folder
    ? 'SELECT id,folder,title,caption,media_url,object_key,media_type,active,display_order FROM gallery_media WHERE folder=? ORDER BY display_order,id'
    : 'SELECT id,folder,title,caption,media_url,object_key,media_type,active,display_order FROM gallery_media ORDER BY folder,display_order,id';
  const rows=folder ? await env.DB.prepare(sql).bind(folder).all() : await env.DB.prepare(sql).all();
  return json({ok:true,folder:folder||'all',media:rows.results||[]},200,cors);
}

function safeMediaFolder(v){ const f=String(v||'').trim().toLowerCase(); return ['photo','audio','video'].includes(f)?f:''; }
function safeKeyPart(v){ return String(v||'').replace(/[^a-zA-Z0-9._-]/g,'_').slice(0,120); }

async function adminMediaUpload(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  if(!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(); const file=form.get('file'); const folder=safeMediaFolder(form.get('folder'));
  if(!(file instanceof File) || !folder) return json({error:'INVALID_MEDIA'},400,cors);
  const contentType=guessContentType(file);
  const allowed=folder==='photo'?contentType.startsWith('image/'):folder==='audio'?contentType.startsWith('audio/'):contentType.startsWith('video/');
  if(!allowed) return json({error:'MEDIA_TYPE_MISMATCH'},400,cors);
  if(file.size>50*1024*1024) return json({error:'MEDIA_TOO_LARGE'},413,cors);
  const title=String(form.get('title')||'').trim(); const caption=String(form.get('caption')||'').trim(); const targetUrl=String(form.get('targetUrl')||'').trim().slice(0,1000); const order=Math.max(1,Number(form.get('displayOrder')||1));
  const ext=(String(file.name||'bin').split('.').pop()||'bin').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'bin';
  const key=`gallery/${folder}/${Date.now()}-${crypto.randomUUID().slice(0,8)}-${safeKeyPart(file.name||'media')}.${ext}`;
  try {
    await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType,cacheControl:'public, max-age=31536000'}});
  } catch (e) {
    return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);
  }
  const mediaUrl=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  let r;
  try { r=await env.DB.prepare('INSERT INTO gallery_media(folder,title,caption,media_url,object_key,media_type,active,display_order) VALUES(?,?,?,?,?,?,1,?)').bind(folder,title,caption,mediaUrl,key,contentType,order).run(); }
  catch(e){ try{await env.MEDIA.delete(key);}catch(_){} return json({error:'GALLERY_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,220)},500,cors); }
  await createBroadcastNotification(env,'গ্যালারি আপডেট','গ্যালারিতে নতুন মিডিয়া যোগ হয়েছে।');
  return json({ok:true,id:r.meta?.last_row_id||null,folder,title,caption,media_url:mediaUrl,object_key:key,media_type:contentType,display_order:order},201,cors);
}

async function adminMediaUpdate(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const b=await body(request); const id=Number(b.id||0); const title=String(b.title||'').trim(); const caption=String(b.caption||'').trim();
  if(!id) return json({error:'INVALID_MEDIA_ID'},400,cors);
  const row=await env.DB.prepare('SELECT id FROM gallery_media WHERE id=?').bind(id).first();
  if(!row) return json({error:'MEDIA_NOT_FOUND'},404,cors);
  await env.DB.prepare('UPDATE gallery_media SET title=?,caption=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(title,caption,id).run();
  await createBroadcastNotification(env,'গ্যালারি আপডেট','গ্যালারির একটি আইটেম সম্পাদনা করা হয়েছে।');
  return json({ok:true,id,title,caption},200,cors);
}

async function adminMediaDelete(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const b=await body(request); const id=Number(b.id||0); if(!id) return json({error:'INVALID_MEDIA_ID'},400,cors);
  const row=await env.DB.prepare('SELECT object_key FROM gallery_media WHERE id=?').bind(id).first(); if(!row) return json({error:'MEDIA_NOT_FOUND'},404,cors);
  if(env.MEDIA && row.object_key) await env.MEDIA.delete(row.object_key);
  await env.DB.prepare('DELETE FROM gallery_media WHERE id=?').bind(id).run();
  await createBroadcastNotification(env,'গ্যালারি আপডেট','গ্যালারি থেকে একটি মিডিয়া সরানো হয়েছে।');
  return json({ok:true},200,cors);
}



async function userGalleryList(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  const folder=safeMediaFolder(new URL(request.url).searchParams.get('folder')||'');
  if (!folder) return json({error:'INVALID_GALLERY_FOLDER'},400,cors);
  const rows=(await env.DB.prepare(`SELECT id,folder,title,caption,media_url,object_key,media_type,active,display_order,owner_user_id,updated_at FROM gallery_media WHERE active=1 AND folder=? AND (owner_user_id IS NULL OR owner_user_id=?) ORDER BY id DESC`).bind(folder,user.user_id).all()).results||[];
  return json({ok:true,folder,media:rows},200,cors);
}

async function userGalleryUpload(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!isAdminUser(user)) return json({error:'GALLERY_ADMIN_ONLY'},403,cors);
  if (!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(); const file=form.get('file'); const folder=safeMediaFolder(form.get('folder'));
  if (!(file instanceof File) || !folder) return json({error:'INVALID_MEDIA'},400,cors);
  const contentType=guessContentType(file);
  const allowed=folder==='photo'?contentType.startsWith('image/'):folder==='audio'?contentType.startsWith('audio/'):contentType.startsWith('video/');
  if(!allowed) return json({error:'MEDIA_TYPE_MISMATCH'},400,cors);
  // No item-count cap. Each individual object is limited to 50 MB; R2/account quota still applies.
  if(Number(file.size||0)>50*1024*1024) return json({error:'MEDIA_TOO_LARGE'},413,cors);
  const title=String(form.get('title')||'').trim().slice(0,160);
  const caption=String(form.get('caption')||'').trim().slice(0,1000);
  const ext=(String(file.name||'media').split('.').pop()||'bin').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'bin';
  const key=`gallery/users/${user.user_id}/${folder}/${Date.now()}-${crypto.randomUUID().slice(0,8)}-${safeKeyPart(file.name||'media')}.${ext}`;
  try { await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType,cacheControl:'public, max-age=31536000'}}); }
  catch(e){ return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
  const mediaUrl=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  try {
    const r=await env.DB.prepare(`INSERT INTO gallery_media(folder,title,caption,media_url,object_key,media_type,active,display_order,owner_user_id) VALUES(?,?,?,?,?,?,1,?,?)`).bind(folder,title,caption,mediaUrl,key,contentType,1,user.user_id).run();
    await createBroadcastNotification(env,'গ্যালারি আপডেট','একটি নতুন ইউজার গ্যালারি মিডিয়া যোগ হয়েছে।');
    return json({ok:true,id:r.meta?.last_row_id||null,folder,title,caption,media_url:mediaUrl,object_key:key,media_type:contentType,owner_user_id:user.user_id},201,cors);
  } catch(e){ try{await env.MEDIA.delete(key);}catch(_){} return json({error:'GALLERY_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors); }
}

async function userGalleryUpdate(request, env) {
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!isAdminUser(user)) return json({error:'GALLERY_ADMIN_ONLY'},403,cors);
  const b=await body(request); const id=Number(b.id||0); const title=String(b.title||'').trim().slice(0,160); const caption=String(b.caption||'').trim().slice(0,1000);
  if(!id) return json({error:'INVALID_MEDIA_ID'},400,cors);
  const row=await env.DB.prepare('SELECT id FROM gallery_media WHERE id=? AND owner_user_id=?').bind(id,user.user_id).first();
  if(!row) return json({error:'MEDIA_NOT_FOUND'},404,cors);
  await env.DB.prepare('UPDATE gallery_media SET title=?,caption=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND owner_user_id=?').bind(title,caption,id,user.user_id).run();
  return json({ok:true,id,title,caption},200,cors);
}

async function userGalleryDelete(request, env) {
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!isAdminUser(user)) return json({error:'GALLERY_ADMIN_ONLY'},403,cors);
  const b=await body(request); const id=Number(b.id||0); if(!id) return json({error:'INVALID_MEDIA_ID'},400,cors);
  const row=await env.DB.prepare('SELECT object_key FROM gallery_media WHERE id=? AND owner_user_id=?').bind(id,user.user_id).first();
  if(!row) return json({error:'MEDIA_NOT_FOUND'},404,cors);
  if(env.MEDIA && row.object_key) { try{await env.MEDIA.delete(row.object_key);}catch(_){} }
  await env.DB.prepare('DELETE FROM gallery_media WHERE id=? AND owner_user_id=?').bind(id,user.user_id).run();
  return json({ok:true},200,cors);
}


function isModeratorUser(user) { return !!user && ['MODERATOR','ADMIN'].includes(String(user.role || '').toUpperCase()); }

async function feedList(request, env) {
  await ensureSchemasOnce(env);
  await ensureLevelSchema(env);
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  const url = new URL(request.url);
  const limit = Math.min(10, Math.max(1, Number(url.searchParams.get('limit') || 5)));
  const before = Math.max(0, Number(url.searchParams.get('before') || 0));
  const sql = before > 0
    ? `SELECT p.id,p.user_id,p.caption,p.media_url,p.object_key,p.media_type,p.created_at,u.full_name,u.avatar_url,
          (CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=p.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=p.user_id),0)) AS level,
          (SELECT COUNT(*) FROM myshop_post_likes l WHERE l.post_id=p.id AND datetime(l.created_at)>=datetime('now','-24 hours')) AS like_count,
          (SELECT COUNT(*) FROM myshop_post_comments c WHERE c.post_id=p.id) AS comment_count,
          (SELECT COUNT(*) FROM myshop_post_shares sh WHERE sh.post_id=p.id) AS share_count,
          EXISTS(SELECT 1 FROM myshop_post_likes ml WHERE ml.post_id=p.id AND ml.user_id=?) AS liked
       FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id
       WHERE p.status='ACTIVE' AND p.id<? AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=p.user_id) OR (b.blocker_id=p.user_id AND b.blocked_id=?)) ORDER BY p.id DESC LIMIT ?`
    : `SELECT p.id,p.user_id,p.caption,p.media_url,p.object_key,p.media_type,p.created_at,u.full_name,u.avatar_url,
          (CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=p.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=p.user_id),0)) AS level,
          (SELECT COUNT(*) FROM myshop_post_likes l WHERE l.post_id=p.id AND datetime(l.created_at)>=datetime('now','-24 hours')) AS like_count,
          (SELECT COUNT(*) FROM myshop_post_comments c WHERE c.post_id=p.id) AS comment_count,
          (SELECT COUNT(*) FROM myshop_post_shares sh WHERE sh.post_id=p.id) AS share_count,
          EXISTS(SELECT 1 FROM myshop_post_likes ml WHERE ml.post_id=p.id AND ml.user_id=?) AS liked
       FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id
       WHERE p.status='ACTIVE' AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=p.user_id) OR (b.blocker_id=p.user_id AND b.blocked_id=?)) ORDER BY p.id DESC LIMIT ?`;
  const rows = before > 0
    ? (await env.DB.prepare(sql).bind(user.user_id,before,user.user_id,user.user_id,limit).all()).results || []
    : (await env.DB.prepare(sql).bind(user.user_id,user.user_id,user.user_id,limit).all()).results || [];
  const levels=new Map();for(const row of rows){if(!levels.has(row.user_id))levels.set(row.user_id,(await coinLevelFor(env,row.user_id)).level);row.level=levels.get(row.user_id);}
  const today = await env.DB.prepare(`SELECT COUNT(*) AS c FROM myshop_posts WHERE user_id=? AND date(created_at)=date('now')`).bind(user.user_id).first();
  const canPost = isAdminUser(user) || Number(today?.c || 0) < 1;
  return json({ok:true,posts:rows.map(x=>({id:x.id,userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',level:Math.max(0,Number(x.level||0)),caption:x.caption||'',mediaUrl:x.media_url||'',mediaType:x.media_type||'image',createdAt:x.created_at||'',likeCount:Number(x.like_count||0),commentCount:Number(x.comment_count||0),shareCount:Number(x.share_count||0),liked:Boolean(x.liked)})),nextBefore:rows.length?Number(rows[rows.length-1].id):null,hasMore:rows.length===limit,canPost,role:user.role,postsToday:Number(today?.c||0)},200,cors);
}

async function feedPost(request, env) {
  await ensureSchemasOnce(env);
  await ensureLevelSchema(env);
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const id=Number(new URL(request.url).searchParams.get('id')||0); if(!Number.isInteger(id)||id<=0)return json({error:'INVALID_POST_ID'},400,cors);
  const x=await env.DB.prepare(`SELECT p.id,p.user_id,p.caption,p.media_url,p.object_key,p.media_type,p.created_at,u.full_name,u.avatar_url,
      (CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=p.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=p.user_id),0)) AS level,
      (SELECT COUNT(*) FROM myshop_post_likes l WHERE l.post_id=p.id AND datetime(l.created_at)>=datetime('now','-24 hours')) AS like_count,
      (SELECT COUNT(*) FROM myshop_post_comments c WHERE c.post_id=p.id) AS comment_count,
          (SELECT COUNT(*) FROM myshop_post_shares sh WHERE sh.post_id=p.id) AS share_count,
      EXISTS(SELECT 1 FROM myshop_post_likes ml WHERE ml.post_id=p.id AND ml.user_id=?) AS liked
    FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id WHERE p.status='ACTIVE' AND p.id=? AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=p.user_id) OR (b.blocker_id=p.user_id AND b.blocked_id=?)) LIMIT 1`).bind(user.user_id,id,user.user_id,user.user_id).first();
  if(!x)return json({error:'POST_NOT_FOUND'},404,cors);
  if(!(await canViewProfileContent(env,user.user_id,x.user_id,'posts')))return json({error:'POST_NOT_FOUND'},404,cors);
  x.level=(await coinLevelFor(env,x.user_id)).level;
  return json({ok:true,post:{id:x.id,userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',level:Math.max(0,Number(x.level||0)),caption:x.caption||'',mediaUrl:x.media_url||'',mediaType:x.media_type||'image',createdAt:x.created_at||'',likeCount:Number(x.like_count||0),commentCount:Number(x.comment_count||0),shareCount:Number(x.share_count||0),liked:Boolean(x.liked)}},200,cors);
}

async function videoList(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const url=new URL(request.url),limit=Math.max(1,Math.min(30,Number(url.searchParams.get('limit')||15))),before=Math.max(0,Number(url.searchParams.get('before')||0));
  const exactId=Math.max(0,Math.floor(Number(url.searchParams.get('id')||0)));
  if(exactId>0){
    const x=await env.DB.prepare(`SELECT p.id,p.user_id,p.caption,p.media_url,p.created_at,u.full_name,u.avatar_url,(SELECT COUNT(*) FROM myshop_post_likes l WHERE l.post_id=p.id AND datetime(l.created_at)>=datetime('now','-24 hours')) like_count,(SELECT COUNT(*) FROM myshop_post_comments c WHERE c.post_id=p.id) comment_count,EXISTS(SELECT 1 FROM myshop_post_likes ml WHERE ml.post_id=p.id AND ml.user_id=?) liked FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id WHERE p.status='ACTIVE' AND p.media_type='video' AND p.id=? AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=p.user_id) OR (b.blocker_id=p.user_id AND b.blocked_id=?)) LIMIT 1`).bind(user.user_id,exactId,user.user_id,user.user_id).first();
    const videos=x?[{id:x.id,userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',caption:x.caption||'',mediaUrl:x.media_url||'',mediaType:'video',createdAt:x.created_at||'',likeCount:Number(x.like_count||0),commentCount:Number(x.comment_count||0),shareCount:Number(x.share_count||0),liked:Boolean(x.liked)}]:[];
    return json({ok:true,videos,nextBefore:0,hasMore:false},200,cors);
  }
  const sql=before>0
    ? `SELECT p.id,p.user_id,p.caption,p.media_url,p.created_at,u.full_name,u.avatar_url,
        (SELECT COUNT(*) FROM myshop_post_likes l WHERE l.post_id=p.id AND datetime(l.created_at)>=datetime('now','-24 hours')) like_count,
        (SELECT COUNT(*) FROM myshop_post_comments c WHERE c.post_id=p.id) comment_count,
        EXISTS(SELECT 1 FROM myshop_post_likes ml WHERE ml.post_id=p.id AND ml.user_id=?) liked
       FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id WHERE p.status='ACTIVE' AND p.media_type='video' AND p.id<? AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=p.user_id) OR (b.blocker_id=p.user_id AND b.blocked_id=?)) ORDER BY p.id DESC LIMIT ?`
    : `SELECT p.id,p.user_id,p.caption,p.media_url,p.created_at,u.full_name,u.avatar_url,
        (SELECT COUNT(*) FROM myshop_post_likes l WHERE l.post_id=p.id AND datetime(l.created_at)>=datetime('now','-24 hours')) like_count,
        (SELECT COUNT(*) FROM myshop_post_comments c WHERE c.post_id=p.id) comment_count,
        EXISTS(SELECT 1 FROM myshop_post_likes ml WHERE ml.post_id=p.id AND ml.user_id=?) liked
       FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id WHERE p.status='ACTIVE' AND p.media_type='video' AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=p.user_id) OR (b.blocker_id=p.user_id AND b.blocked_id=?)) ORDER BY p.id DESC LIMIT ?`;
  const rows=before>0?(await env.DB.prepare(sql).bind(user.user_id,before,user.user_id,user.user_id,limit).all()).results||[]:(await env.DB.prepare(sql).bind(user.user_id,user.user_id,user.user_id,limit).all()).results||[];
  return json({ok:true,videos:rows.map(x=>({id:x.id,userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',caption:x.caption||'',mediaUrl:x.media_url||'',mediaType:'video',createdAt:x.created_at||'',likeCount:Number(x.like_count||0),commentCount:Number(x.comment_count||0),shareCount:Number(x.share_count||0),liked:Boolean(x.liked)})),nextBefore:rows.length?Number(rows[rows.length-1].id):0,hasMore:rows.length===limit},200,cors);
}

async function feedUpload(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  try { await ensureSchemasOnce(env); } catch (_) {}
  if (!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const isPrivilegedPublisher = isModeratorUser(user);
  const form = await request.formData();
  const file = form.get('file');
  if (!(file instanceof File)) return json({error:'FILE_REQUIRED'},400,cors);
  const contentType = guessContentType(file);
  if (!contentType || contentType === 'application/octet-stream') { return json({error:'POST_MEDIA_TYPE_MISMATCH',message:'The selected file type could not be identified as image/video.'},400,cors); }
  const requestedType = String(form.get('mediaType') || '').trim().toLowerCase();
  const mediaType = requestedType || (contentType.startsWith('video/') ? 'video' : 'image');
  const allowed = mediaType === 'image' ? contentType.startsWith('image/') : mediaType === 'video' ? contentType.startsWith('video/') : false;
  if (!allowed) return json({error:'POST_MEDIA_TYPE_MISMATCH'},400,cors);
  // Admins and moderators are exempt from ordinary-user post count and size caps.
  // Keep a generous 100 MiB transport ceiling so high-quality uploads remain practical.
  const maxBytes = isPrivilegedPublisher ? 100*1024*1024 : (mediaType==='video' ? 20*1024*1024 : 5*1024*1024);
  if (Number(file.size||0) > maxBytes) return json({error:isPrivilegedPublisher?'POST_MEDIA_TOO_LARGE':'USER_POST_TOO_LARGE'},413,cors);
  const caption = String(form.get('caption') || '').trim().slice(0,1000);
  let appearance=null;try{if(form.has('appearance'))appearance=await preparePostAppearance(env,user,caption,JSON.parse(String(form.get('appearance'))));}catch(e){return json({error:e.message},403,cors);}
  if (!isPrivilegedPublisher && !caption) return json({error:'POST_CAPTION_REQUIRED'},400,cors);
  if (!isPrivilegedPublisher) {
    const today = await env.DB.prepare(`SELECT COUNT(*) AS c FROM myshop_posts WHERE user_id=? AND date(created_at)=date('now')`).bind(user.user_id).first();
    if (Number(today?.c||0) >= 1) return json({error:'DAILY_POST_LIMIT',message:'সাধারণ User প্রতিদিন সর্বোচ্চ ১টি পোস্ট করতে পারবে।'},429,cors);
  }
  const ext=(String(file.name||'media').split('.').pop()||'bin').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'bin';
  const key=`posts/${user.user_id}/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  try { await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType,cacheControl:'public, max-age=86400'}}); }
  catch(e) { return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
  const mediaUrl=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  try {
    const r=appearance?await insertStyledPost(env,user,caption,mediaUrl,key,mediaType,appearance):await env.DB.prepare(`INSERT INTO myshop_posts(user_id,caption,media_url,object_key,media_type,status) VALUES(?,?,?,?,?,'ACTIVE')`).bind(user.user_id,caption,mediaUrl,key,mediaType).run();
    await createBroadcastNotification(env,'MY SHOP Feed','নতুন একটি পোস্ট Feed-এ যোগ হয়েছে।');
    return json({ok:true,id:r.meta?.last_row_id||null,post:{id:r.meta?.last_row_id||null,userId:user.user_id,name:user.full_name||'',avatarUrl:user.avatar_url||'',caption,mediaUrl,mediaType}},201,cors);
  } catch(e) { try { await env.MEDIA.delete(key); } catch (_) {} return json({error:'POST_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors); }
}

async function feedText(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  try { await ensureSchemasOnce(env); } catch (_) {}
  const b=await body(request); const caption=String(b.caption||'').trim().slice(0,1000);
  if(!caption) return json({error:'POST_CAPTION_REQUIRED'},400,cors);
  let appearance=null;try{if(b.appearance!==undefined)appearance=await preparePostAppearance(env,user,caption,b.appearance);}catch(e){return json({error:e.message},403,cors);}
  const isPrivilegedPublisher=isModeratorUser(user);
  if(!isPrivilegedPublisher){
    const today=await env.DB.prepare(`SELECT COUNT(*) AS c FROM myshop_posts WHERE user_id=? AND date(created_at)=date('now')`).bind(user.user_id).first();
    if(Number(today?.c||0)>=1)return json({error:'DAILY_POST_LIMIT',message:'সাধারণ User প্রতিদিন সর্বোচ্চ ১টি পোস্ট করতে পারবে।'},429,cors);
  }
  try{
    const r=appearance?await insertStyledPost(env,user,caption,'','','text',appearance):await env.DB.prepare(`INSERT INTO myshop_posts(user_id,caption,media_url,object_key,media_type,status) VALUES(?,?,'','','text','ACTIVE')`).bind(user.user_id,caption).run();
    await createBroadcastNotification(env,'MY SHOP Feed','নতুন একটি text post Feed-এ যোগ হয়েছে।');
    return json({ok:true,id:r.meta?.last_row_id||null,post:{id:r.meta?.last_row_id||null,userId:user.user_id,name:user.full_name||'',avatarUrl:user.avatar_url||'',caption,mediaUrl:'',mediaType:'text'}},201,cors);
  }catch(e){return json({error:'POST_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors);}
}

// Count destination selections, never count opening or cancelling the chooser.
async function feedShare(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  await ensureSchemasOnce(env);const b=await body(request),id=Number(b.postId),event=String(b.eventId||'');
  if(!Number.isSafeInteger(id)||id<=0||!/^[-a-f0-9]{36}$/i.test(event))return json({error:'INVALID_SHARE'},400,cors);
  const post=await env.DB.prepare("SELECT user_id FROM myshop_posts WHERE id=? AND status='ACTIVE'").bind(id).first();
  if(!post||await safetyIsBlocked(env,user.user_id,post.user_id)||!(await canViewProfileContent(env,user.user_id,post.user_id,'posts')))return json({error:'POST_NOT_FOUND'},404,cors);
  await env.DB.prepare('INSERT OR IGNORE INTO myshop_post_shares(event_id,post_id,user_id) VALUES(?,?,?)').bind(event,id,user.user_id).run();
  const count=await env.DB.prepare('SELECT COUNT(*) c FROM myshop_post_shares WHERE post_id=?').bind(id).first();return json({ok:true,shareCount:Number(count?.c||0)},200,cors);
}

async function feedLike(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request); const id=Number(b.postId||0); if(!Number.isInteger(id)||id<=0)return json({error:'INVALID_POST_ID'},400,cors);
  const post=await env.DB.prepare(`SELECT id,user_id,caption FROM myshop_posts WHERE id=? AND status='ACTIVE'`).bind(id).first(); if(!post)return json({error:'POST_NOT_FOUND'},404,cors); if(post.user_id!==user.user_id && await safetyIsBlocked(env,user.user_id,post.user_id))return json({error:'BLOCKED_USER'},403,cors);
  const exists=await env.DB.prepare('SELECT post_id FROM myshop_post_likes WHERE post_id=? AND user_id=?').bind(id,user.user_id).first();
  if(exists){await env.DB.prepare('DELETE FROM myshop_post_likes WHERE post_id=? AND user_id=?').bind(id,user.user_id).run(); const c=await env.DB.prepare(`SELECT COUNT(*) AS c FROM myshop_post_likes WHERE post_id=? AND datetime(created_at)>=datetime('now','-24 hours')`).bind(id).first(); return json({ok:true,liked:false,likeCount:Number(c?.c||0)},200,cors);}
  await env.DB.prepare('INSERT OR IGNORE INTO myshop_post_likes(post_id,user_id) VALUES(?,?)').bind(id,user.user_id).run();
  if(post.user_id!==user.user_id){const actor=await env.DB.prepare('SELECT full_name FROM myshop_auth_users_v108 WHERE user_id=? LIMIT 1').bind(user.user_id).first();const actorName=String(actor?.full_name||('User ID '+user.user_id));await createUserNotification(env,post.user_id,'❤️ New Like',actorName+' liked your post'+(post.caption?': '+String(post.caption).slice(0,90):'.'),'LIKE',user.user_id,String(id));}
  const c=await env.DB.prepare(`SELECT COUNT(*) AS c FROM myshop_post_likes WHERE post_id=? AND datetime(created_at)>=datetime('now','-24 hours')`).bind(id).first(); return json({ok:true,liked:true,likeCount:Number(c?.c||0)},200,cors);
}

async function feedComments(request, env) {
  try{await ensureSchemasOnce(env);}catch(_){}
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const postId=Number(new URL(request.url).searchParams.get('postId')||0); if(!Number.isInteger(postId)||postId<=0)return json({error:'INVALID_POST_ID'},400,cors);
  const post=await env.DB.prepare(`SELECT id,user_id FROM myshop_posts WHERE id=? AND status='ACTIVE'`).bind(postId).first(); if(!post)return json({error:'POST_NOT_FOUND'},404,cors); if(post.user_id!==user.user_id && await safetyIsBlocked(env,user.user_id,post.user_id))return json({error:'BLOCKED_USER'},403,cors);
  const rows=(await env.DB.prepare(`SELECT c.id,c.user_id,c.comment,c.created_at,COALESCE(c.parent_id,0) parent_id,u.full_name,u.avatar_url FROM myshop_post_comments c LEFT JOIN myshop_auth_users_v108 u ON u.user_id=c.user_id WHERE c.post_id=? AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=c.user_id) OR (b.blocker_id=c.user_id AND b.blocked_id=?)) ORDER BY c.id ASC LIMIT 200`).bind(postId,user.user_id,user.user_id).all()).results||[];
  return json({ok:true,comments:rows.map(x=>({id:x.id,userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',comment:x.comment||'',parentId:Number(x.parent_id||0),createdAt:x.created_at||''})),commentCount:rows.length},200,cors);
}

async function feedLikeUsers(request, env) {
  try{await ensureSchemasOnce(env);}catch(_){}
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const postId=Number(new URL(request.url).searchParams.get('postId')||0);if(!Number.isInteger(postId)||postId<=0)return json({error:'INVALID_POST_ID'},400,cors);
  const rows=(await env.DB.prepare(`SELECT l.user_id,u.full_name,u.avatar_url,l.created_at FROM myshop_post_likes l LEFT JOIN myshop_auth_users_v108 u ON u.user_id=l.user_id WHERE l.post_id=? ORDER BY l.created_at DESC LIMIT 200`).bind(postId).all()).results||[];
  return json({ok:true,users:rows.map(x=>({userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',createdAt:x.created_at||''})),likeCount:rows.length},200,cors);
}

async function feedEdit(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  try{await ensureSchemasOnce(env);}catch(_){}
  const b=await body(request),id=Number(b.postId||0),caption=String(b.caption||'').trim().slice(0,1000);
  if(!Number.isSafeInteger(id)||id<=0)return json({error:'INVALID_POST_ID'},400,cors);
  const post=await env.DB.prepare(`SELECT id,user_id,media_type FROM myshop_posts WHERE id=? AND status='ACTIVE'`).bind(id).first();
  if(!post)return json({error:'POST_NOT_FOUND'},404,cors);
  const owner=String(post.user_id)===String(user.user_id),moderator=isModeratorUser(user);
  if(!owner&&!moderator)return json({error:'POST_EDIT_FORBIDDEN'},403,cors);
  await env.DB.prepare(`UPDATE myshop_posts SET caption=? WHERE id=? AND status='ACTIVE'`).bind(caption,id).run();
  if(!owner){await ensureLiveRoomSchema(env);await recordModerationAudit(env,'',user.user_id,post.user_id,'FEED_CAPTION_EDIT');}
  return json({ok:true,postId:id,caption,editedBy:owner?'OWNER':'MODERATOR'},200,cors);
}

async function feedCommentReply(request, env) {
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);try{await ensureSchemasOnce(env);}catch(_){}
  const b=await body(request),postId=Number(b.postId||0),parentId=Number(b.parentId||0),comment=String(b.comment||'').trim().slice(0,1000);if(!Number.isInteger(postId)||postId<=0||!Number.isInteger(parentId)||parentId<=0||!comment)return json({error:'INVALID_REPLY'},400,cors);
  const parent=await env.DB.prepare('SELECT id,user_id FROM myshop_post_comments WHERE id=? AND post_id=?').bind(parentId,postId).first();if(!parent)return json({error:'PARENT_COMMENT_NOT_FOUND'},404,cors);
  await env.DB.prepare('INSERT INTO myshop_post_comments(post_id,user_id,comment,parent_id) VALUES(?,?,?,?)').bind(postId,user.user_id,comment,parentId).run();
  if(parent.user_id!==user.user_id){const actor=await env.DB.prepare('SELECT full_name FROM myshop_auth_users_v108 WHERE user_id=? LIMIT 1').bind(user.user_id).first();await createUserNotification(env,parent.user_id,'💬 New Reply',String(actor?.full_name||'A user')+' replied to your comment.','COMMENT_REPLY',user.user_id,String(postId));}
  const c=await env.DB.prepare('SELECT COUNT(*) c FROM myshop_post_comments WHERE post_id=?').bind(postId).first();return json({ok:true,commentCount:Number(c?.c||0)},201,cors);
}

async function feedComment(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  try { await ensureSchemasOnce(env); } catch (_) {}
  const b=await body(request); const id=Number(b.postId||0); const comment=String(b.comment||'').trim().slice(0,1000);
  if(!Number.isInteger(id)||id<=0||!comment)return json({error:'INVALID_COMMENT'},400,cors);
  try {
    const post=await env.DB.prepare(`SELECT id,user_id FROM myshop_posts WHERE id=? AND status='ACTIVE'`).bind(id).first(); if(!post)return json({error:'POST_NOT_FOUND'},404,cors); if(post.user_id!==user.user_id && await safetyIsBlocked(env,user.user_id,post.user_id))return json({error:'BLOCKED_USER'},403,cors);
    await env.DB.prepare('INSERT INTO myshop_post_comments(post_id,user_id,comment) VALUES(?,?,?)').bind(id,user.user_id,comment).run();
    if(post.user_id!==user.user_id){const actor=await env.DB.prepare('SELECT full_name FROM myshop_auth_users_v108 WHERE user_id=? LIMIT 1').bind(user.user_id).first();const actorName=String(actor?.full_name||('User ID '+user.user_id));await createUserNotification(env,post.user_id,'💬 New Comment',actorName+' commented on your post: '+comment.slice(0,120),'COMMENT',user.user_id,String(id));}
    const c=await env.DB.prepare('SELECT COUNT(*) AS c FROM myshop_post_comments WHERE post_id=?').bind(id).first(); return json({ok:true,commentCount:Number(c?.c||0)},201,cors);
  } catch(e) { console.error('FEED_COMMENT_FAILED',String(e?.message||e)); return json({error:'COMMENT_SERVER_ERROR',message:'Comment could not be saved. Please retry.'},503,cors); }
}

async function feedDeleteOwn(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request); const id=Number(b.id||0); if(!id)return json({error:'INVALID_POST_ID'},400,cors);
  const row=await env.DB.prepare(`SELECT object_key FROM myshop_posts WHERE id=? AND user_id=? AND status='ACTIVE'`).bind(id,user.user_id).first();
  if(!row)return json({error:'POST_NOT_FOUND'},404,cors);
  if(env.MEDIA&&row.object_key){try{await env.MEDIA.delete(row.object_key);}catch(_){} }
  await env.DB.prepare(`UPDATE myshop_posts SET status='REMOVED',moderated_by=?,moderated_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?`).bind(user.user_id,id,user.user_id).run();
  return json({ok:true},200,cors);
}

async function adminFeedList(request,env) {
  const auth=await adminOnly(request,env); if(auth.error)return auth.error;
  try{await ensureSchemasOnce(env);}catch(_){ }
  const rows=(await env.DB.prepare(`SELECT p.id,p.user_id,p.caption,p.media_url,p.media_type,p.status,p.created_at,p.moderated_by,p.moderated_at,u.full_name,u.avatar_url FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id ORDER BY p.id DESC LIMIT 100`).all()).results||[];
  return json({ok:true,posts:rows},200,cors);
}

async function moderatorFeedDelete(request,env) {
  const user=await getUser(request,env);
  if(!user || !isModeratorUser(user)) return json({error:'MODERATOR_REQUIRED'},403,cors);
  try{await ensureSchemasOnce(env);}catch(_){ }
  const b=await body(request); const id=Number(b.id||0); const reason=String(b.reason||'').trim().slice(0,300);
  if(!id)return json({error:'INVALID_POST_ID'},400,cors);
  const row=await env.DB.prepare(`SELECT object_key,status FROM myshop_posts WHERE id=?`).bind(id).first();
  if(!row)return json({error:'POST_NOT_FOUND'},404,cors);
  if(env.MEDIA&&row.object_key){try{await env.MEDIA.delete(row.object_key);}catch(_){} }
  await env.DB.prepare(`UPDATE myshop_posts SET status='REMOVED',moderated_by=?,moderated_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(user.user_id,id).run();
  return json({ok:true,removedBy:user.user_id,reason},200,cors);
}

async function adminAdsList(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error;
  const box=String(new URL(request.url).searchParams.get('box_key')||'').trim().toLowerCase();
  const rows=box?await env.DB.prepare('SELECT id,box_key,slot,image_url,caption,target_url,object_key,media_type,active,duration_sec,display_mode,updated_at FROM dashboard_ads WHERE box_key=? ORDER BY slot').bind(box).all():await env.DB.prepare('SELECT id,box_key,slot,image_url,caption,target_url,object_key,media_type,active,duration_sec,display_mode,updated_at FROM dashboard_ads ORDER BY box_key,slot').all();
  return json({ok:true,ads:rows.results||[]},200,cors);
}

async function adminAdUpload(request,env){
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error)return auth.error;
  if(!env.MEDIA)return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(); const file=form.get('file'); const box=String(form.get('boxKey')||'').trim().toLowerCase().replace(/[^a-z0-9_-]/g,'_').slice(0,60); const slot=Number(form.get('slot')||0); const caption=String(form.get('caption')||'').trim().slice(0,300); const target=String(form.get('targetUrl')||'').trim().slice(0,500); const active=String(form.get('active')||'true').toLowerCase()!=='false'?1:0; const requestedDuration=Number(form.get('durationSec')||3); const duration=box==='startup_ad'?Math.max(1,Math.min(4,requestedDuration)):Math.max(1,Math.min(60,requestedDuration)); const dm=String(form.get('displayMode')||'FULL_IMAGE').toUpperCase(); const displayMode=(dm==='FILL_SCREEN'?'FILL_SCREEN':'FULL_IMAGE');
  if(!(file instanceof File)||!box||!Number.isInteger(slot)||slot<1||slot>20)return json({error:'INVALID_AD'},400,cors);
  const mime=String(file.type||'').toLowerCase(); const mediaType=mime.startsWith('video/')?'video':(mime.startsWith('image/')?'image':'');
  if(!mediaType)return json({error:'AD_MUST_BE_IMAGE_OR_VIDEO'},400,cors);
  const maxBytes=mediaType==='video'?60*1024*1024:15*1024*1024; if(file.size>maxBytes)return json({error:'AD_TOO_LARGE'},413,cors);
  const old=await env.DB.prepare('SELECT object_key FROM dashboard_ads WHERE box_key=? AND slot=?').bind(box,slot).first(); const oldKey=old?.object_key||'';
  const ext=(String(file.name||'jpg').split('.').pop()||'jpg').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'jpg'; const key=`dashboard-ads/${box}/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  try{await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:String(file.type||'image/jpeg'),cacheControl:'public, max-age=31536000'}});}catch(e){return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);}
  const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  try{
    const existing=await env.DB.prepare('SELECT id FROM dashboard_ads WHERE box_key=? AND slot=? LIMIT 1').bind(box,slot).first();
    if(existing?.id){
      await env.DB.prepare('UPDATE dashboard_ads SET image_url=?,caption=?,target_url=?,object_key=?,media_type=?,active=?,duration_sec=?,display_mode=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(url,caption,target,key,mediaType,active,duration,displayMode,existing.id).run();
    } else {
      await env.DB.prepare('INSERT INTO dashboard_ads(box_key,slot,image_url,caption,target_url,object_key,media_type,active,duration_sec,display_mode,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)').bind(box,slot,url,caption,target,key,mediaType,active,duration,displayMode).run();
    }
  }catch(e){try{await env.MEDIA.delete(key);}catch(_){}return json({error:'AD_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,220)},500,cors);}
  if(oldKey&&oldKey!==key){try{await env.MEDIA.delete(oldKey);}catch(_){} }
  return json({ok:true,box_key:box,slot,image_url:url,media_type:mediaType,caption,target_url:target,active,duration_sec:duration,display_mode:displayMode},201,cors);
}

async function adminAdUpdate(request,env){
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; const b=await body(request); const id=Number(b.id||0); if(!id)return json({error:'INVALID_AD_ID'},400,cors);
  const row=await env.DB.prepare('SELECT id FROM dashboard_ads WHERE id=?').bind(id).first(); if(!row)return json({error:'AD_NOT_FOUND'},404,cors);
  const adBox=await env.DB.prepare('SELECT box_key FROM dashboard_ads WHERE id=?').bind(id).first(); const requestedDuration=Number(b.durationSec||3); const duration=adBox?.box_key==='startup_ad'?Math.max(1,Math.min(4,requestedDuration)):Math.max(1,Math.min(60,requestedDuration)); const dm=String(b.displayMode||'FULL_IMAGE').toUpperCase(); const displayMode=(dm==='FILL_SCREEN'?'FILL_SCREEN':'FULL_IMAGE');
  await env.DB.prepare('UPDATE dashboard_ads SET caption=?,target_url=?,active=?,duration_sec=?,display_mode=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(String(b.caption||'').trim().slice(0,300),String(b.targetUrl||'').trim().slice(0,500),b.active===false?0:1,duration,displayMode,id).run(); return json({ok:true,display_mode:displayMode},200,cors);
}

async function adminAdDelete(request,env){
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; const b=await body(request); const id=Number(b.id||0); if(!id)return json({error:'INVALID_AD_ID'},400,cors); const row=await env.DB.prepare('SELECT object_key FROM dashboard_ads WHERE id=?').bind(id).first(); if(!row)return json({error:'AD_NOT_FOUND'},404,cors); if(env.MEDIA&&row.object_key){try{await env.MEDIA.delete(row.object_key);}catch(_){} } await env.DB.prepare('DELETE FROM dashboard_ads WHERE id=?').bind(id).run(); return json({ok:true},200,cors);
}

async function profileUpdate(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  const b = await body(request);
  const name = String(b.name ?? user.full_name).trim();
  if(name!==String(user.full_name||'').trim()&&(!name||/[\r\n]/.test(name)||Array.from(name).length>24))return json({error:'PROFILE_NAME_TOO_LONG',message:'Use a shorter name: maximum 24 characters, one line.'},400,cors);
  // V-534: normal users cannot change login/recovery email or mobile.
  // These contacts are controlled only by Main Admin Account Recovery.
  const email = normalizeEmail(user.email ?? '');
  const mobile = normalizeMobile(user.mobile ?? '');
  const bio = String(b.bio ?? user.bio ?? '').trim().slice(0,500);
  const rawGender=String(b.gender ?? user.gender ?? 'UNSPECIFIED').toUpperCase(); const gender=['MALE','FEMALE','UNSPECIFIED'].includes(rawGender)?rawGender:'UNSPECIFIED';
  if (!name || (!email && !mobile)) return json({error:'INVALID_PROFILE'},400,cors);
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({error:'INVALID_EMAIL'},400,cors);
  const duplicate = await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE user_id<>? AND ((?<>'' AND email=?) OR (?<>'' AND mobile=?)) LIMIT 1`).bind(user.user_id,email,email,mobile,mobile).first();
  if (duplicate) return json({error:'ACCOUNT_EXISTS'},409,cors);
  await env.DB.prepare(`UPDATE myshop_auth_users_v108 SET full_name=?,email=?,mobile=?,bio=?,gender=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(name,email||null,mobile||null,bio,gender,user.user_id).run();
  const fresh=await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(user.user_id).first();
  return json({ok:true,user:publicUser(fresh)},200,cors);
}

async function profileAvatarUpload(request, env) {
  try { await ensureAuthSchema(env); } catch (_) {}
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  let form;
  try { form = await request.formData(); } catch (e) { return json({error:'AVATAR_MULTIPART_INVALID',message:String(e?.message||e).slice(0,180)},400,cors); }
  const file = form.get('file');
  if (!file || typeof file.arrayBuffer !== 'function') return json({error:'FILE_REQUIRED'},400,cors);
  const rawType=String(file.type||'').toLowerCase();
  const fileName=String(file.name||'').toLowerCase();
  const extName=fileName.includes('.')?fileName.split('.').pop():'';
  const guessedType=extName==='png'?'image/png':extName==='webp'?'image/webp':extName==='gif'?'image/gif':(extName==='jpg'||extName==='jpeg')?'image/jpeg':'';
  const type=rawType.startsWith('image/')?rawType:(guessedType||'');
  if (!type.startsWith('image/')) return json({error:'AVATAR_TYPE_MISMATCH'},400,cors);
  if (Number(file.size||0)>5*1024*1024) return json({error:'AVATAR_TOO_LARGE'},413,cors);
  const ext=(extName||type.split('/')[1]||'jpg').replace(/[^a-z0-9]/g,'').slice(0,8)||'jpg';
  const key=`profiles/${user.user_id}/avatar-${Date.now()}-${randomHex(8)}.${ext}`;
  try { await env.MEDIA.put(key,await file.arrayBuffer(),{httpMetadata:{contentType:type,cacheControl:'public, max-age=3600'}}); }
  catch(e){ return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
  try {
    const saved=await env.MEDIA.head(key);
    if(!saved) throw new Error('R2 object verification failed');
  } catch(e) {
    try { await env.MEDIA.delete(key); } catch(_) {}
    return json({error:'R2_VERIFY_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);
  }
  const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  const oldKey=user.avatar_object_key||'';
  try {
    await env.DB.prepare('UPDATE myshop_auth_users_v108 SET avatar_url=?,avatar_object_key=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(url,key,user.user_id).run();
  } catch(e) {
    try { await env.MEDIA.delete(key); } catch(_) {}
    return json({error:'PROFILE_UPDATE_FAILED'},500,cors);
  }
  if(oldKey && oldKey!==key){ try { await env.MEDIA.delete(oldKey); } catch(_) {} }
  const fresh=await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(user.user_id).first();
  return json({ok:true,user:publicUser(fresh)},200,cors);
}


async function profileCoverUpload(request, env) {
  try { await ensureAuthSchema(env); } catch (_) {}
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  if(!env.MEDIA)return json({error:'R2_NOT_CONFIGURED'},503,cors);
  let form; try{form=await request.formData();}catch(e){return json({error:'COVER_MULTIPART_INVALID',message:String(e?.message||e).slice(0,180)},400,cors);}
  const file=form.get('file'); if(!file||typeof file.arrayBuffer!=='function')return json({error:'FILE_REQUIRED'},400,cors);
  const rawType=String(file.type||'').toLowerCase(),fileName=String(file.name||'').toLowerCase(),extName=fileName.includes('.')?fileName.split('.').pop():'';
  const guessedType=extName==='png'?'image/png':extName==='webp'?'image/webp':extName==='gif'?'image/gif':(extName==='jpg'||extName==='jpeg')?'image/jpeg':'';
  const type=rawType.startsWith('image/')?rawType:(guessedType||''); if(!type.startsWith('image/'))return json({error:'COVER_TYPE_MISMATCH'},400,cors);
  if(Number(file.size||0)>8*1024*1024)return json({error:'COVER_TOO_LARGE'},413,cors);
  const ext=(extName||type.split('/')[1]||'jpg').replace(/[^a-z0-9]/g,'').slice(0,8)||'jpg';
  const key=`profiles/${user.user_id}/cover-${Date.now()}-${randomHex(8)}.${ext}`;
  try{await env.MEDIA.put(key,await file.arrayBuffer(),{httpMetadata:{contentType:type,cacheControl:'public, max-age=3600'}});}catch(e){return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);}
  try{if(!await env.MEDIA.head(key))throw new Error('R2 object verification failed');}catch(e){try{await env.MEDIA.delete(key);}catch(_){}return json({error:'R2_VERIFY_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);}
  const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString(),oldKey=user.cover_object_key||'';
  try{await env.DB.prepare('UPDATE myshop_auth_users_v108 SET cover_url=?,cover_object_key=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(url,key,user.user_id).run();}catch(e){try{await env.MEDIA.delete(key);}catch(_){}return json({error:'PROFILE_UPDATE_FAILED'},500,cors);}
  if(oldKey&&oldKey!==key){try{await env.MEDIA.delete(oldKey);}catch(_){} }
  const fresh=await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(user.user_id).first();
  return json({ok:true,user:publicUser(fresh)},200,cors);
}

async function profileCoverDelete(request,env){
  try{await ensureAuthSchema(env);}catch(_){}
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const oldKey=user.cover_object_key||'';
  await env.DB.prepare("UPDATE myshop_auth_users_v108 SET cover_url='',cover_object_key='',updated_at=CURRENT_TIMESTAMP WHERE user_id=?").bind(user.user_id).run();
  if(oldKey&&env.MEDIA){try{await env.MEDIA.delete(oldKey);}catch(_){} }
  const fresh=await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(user.user_id).first();
  return json({ok:true,user:publicUser(fresh)},200,cors);
}

async function socialStatsFor(env,userId){
  await ensureFriendSchema(env);
  const friends=await env.DB.prepare("SELECT COUNT(*) c FROM myshop_friend_requests WHERE status='ACCEPTED' AND (sender_id=? OR receiver_id=?)").bind(userId,userId).first();
  const followers=await env.DB.prepare('SELECT COUNT(*) c FROM myshop_follows WHERE following_id=?').bind(userId).first();
  const following=await env.DB.prepare('SELECT COUNT(*) c FROM myshop_follows WHERE follower_id=?').bind(userId).first();
  const likes=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_post_likes l JOIN myshop_posts p ON p.id=l.post_id WHERE p.user_id=? AND p.status='ACTIVE'`).bind(userId).first();
  const posts=await env.DB.prepare("SELECT COUNT(*) c FROM myshop_posts WHERE user_id=? AND status='ACTIVE'").bind(userId).first();
  return {posts:Number(posts?.c||0),friends:Number(friends?.c||0),followers:Number(followers?.c||0),following:Number(following?.c||0),likes:Number(likes?.c||0)};
}

async function mySocialStats(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  return json({ok:true,stats:await socialStatsFor(env,user.user_id)},200,cors);
}

async function followToggle(request,env){
  await ensureFriendSchema(env);
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request),target=String(b.userId||'').trim();if(!isFourDigit(target)||target===user.user_id)return json({error:'INVALID_USER'},400,cors);
  const found=await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(target).first();if(!found)return json({error:'USER_NOT_FOUND'},404,cors);
  const blocked=await env.DB.prepare(`SELECT 1 ok FROM myshop_user_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1`).bind(user.user_id,target,target,user.user_id).first();if(blocked)return json({error:'NOT_AVAILABLE'},409,cors);
  const row=await env.DB.prepare('SELECT 1 ok FROM myshop_follows WHERE follower_id=? AND following_id=?').bind(user.user_id,target).first();
  let following=false;
  if(row){await env.DB.prepare('DELETE FROM myshop_follows WHERE follower_id=? AND following_id=?').bind(user.user_id,target).run();}
  else{await env.DB.prepare('INSERT OR IGNORE INTO myshop_follows(follower_id,following_id,created_at) VALUES(?,?,CURRENT_TIMESTAMP)').bind(user.user_id,target).run();following=true;try{await createUserNotification(env,target,'New Follower',(user.full_name||'A MY SHOP user')+' started following you.','FOLLOW',user.user_id,user.user_id);}catch(_){} }
  return json({ok:true,following,stats:await socialStatsFor(env,target),myStats:await socialStatsFor(env,user.user_id)},200,cors);
}

// V-446 permanent Live Music Library. Audio stays in R2 while catalog/order/state
// stays in D1, so an APK update can never remove an Admin-managed song.
async function ensureLiveMusicSchema(env){
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_music_albums (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,cover_url TEXT NOT NULL DEFAULT '',description TEXT NOT NULL DEFAULT '',enabled INTEGER NOT NULL DEFAULT 1,published INTEGER NOT NULL DEFAULT 1,sort_order INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_music_songs (id INTEGER PRIMARY KEY AUTOINCREMENT,album_id INTEGER NOT NULL,title TEXT NOT NULL,artist TEXT NOT NULL DEFAULT '',audio_url TEXT NOT NULL,object_key TEXT NOT NULL DEFAULT '',cover_url TEXT NOT NULL DEFAULT '',duration_sec INTEGER NOT NULL DEFAULT 0,language TEXT NOT NULL DEFAULT '',tags TEXT NOT NULL DEFAULT '',license_type TEXT NOT NULL DEFAULT 'ADMIN_CONFIRMED',enabled INTEGER NOT NULL DEFAULT 1,published INTEGER NOT NULL DEFAULT 1,sort_order INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  try{await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_music_songs_album ON myshop_music_songs(album_id,published,enabled,sort_order,id)`).run();}catch(_){}
}
async function liveMusicCatalog(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveMusicSchema(env);
  const admin=isAdminUser(me),where=admin?'1=1':'published=1 AND enabled=1';
  const albums=(await env.DB.prepare(`SELECT * FROM myshop_music_albums WHERE ${where} ORDER BY sort_order,id`).all()).results||[];
  const songs=(await env.DB.prepare(`SELECT * FROM myshop_music_songs WHERE ${where} ORDER BY album_id,sort_order,id`).all()).results||[];
  return json({ok:true,admin,albums,songs},200,cors);
}
async function adminLiveMusicSave(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;await ensureLiveMusicSchema(env);const b=await body(request),entity=String(b.entity||'').toUpperCase();
  if(entity==='ALBUM'){
    const id=Math.max(0,Number(b.id||0)),name=String(b.name||'').trim().slice(0,80);if(!name)return json({error:'ALBUM_NAME_REQUIRED'},400,cors);
    if(id)await env.DB.prepare(`UPDATE myshop_music_albums SET name=?,cover_url=?,description=?,enabled=?,published=?,sort_order=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(name,String(b.coverUrl||'').trim(),String(b.description||'').trim().slice(0,240),b.enabled===false?0:1,b.published===false?0:1,Math.max(0,Number(b.sortOrder||0)),id).run();
    else await env.DB.prepare(`INSERT INTO myshop_music_albums(name,cover_url,description,enabled,published,sort_order) VALUES(?,?,?,?,?,?)`).bind(name,String(b.coverUrl||'').trim(),String(b.description||'').trim().slice(0,240),b.enabled===false?0:1,b.published===false?0:1,Math.max(0,Number(b.sortOrder||0))).run();
  }else if(entity==='SONG'){
    const id=Math.max(0,Number(b.id||0)),albumId=Math.max(1,Number(b.albumId||0)),title=String(b.title||'').trim().slice(0,120),audioUrl=String(b.audioUrl||'').trim();if(!title||!audioUrl)return json({error:'SONG_TITLE_AUDIO_REQUIRED'},400,cors);
    const album=await env.DB.prepare(`SELECT id FROM myshop_music_albums WHERE id=?`).bind(albumId).first();if(!album)return json({error:'ALBUM_NOT_FOUND'},404,cors);
    const values=[albumId,title,String(b.artist||'').trim().slice(0,100),audioUrl,String(b.objectKey||'').trim(),String(b.coverUrl||'').trim(),Math.max(0,Number(b.durationSec||0)),String(b.language||'').trim().slice(0,40),String(b.tags||'').trim().slice(0,240),String(b.licenseType||'ADMIN_CONFIRMED').trim().slice(0,40),b.enabled===false?0:1,b.published===false?0:1,Math.max(0,Number(b.sortOrder||0))];
    if(id)await env.DB.prepare(`UPDATE myshop_music_songs SET album_id=?,title=?,artist=?,audio_url=?,object_key=?,cover_url=?,duration_sec=?,language=?,tags=?,license_type=?,enabled=?,published=?,sort_order=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(...values,id).run();
    else await env.DB.prepare(`INSERT INTO myshop_music_songs(album_id,title,artist,audio_url,object_key,cover_url,duration_sec,language,tags,license_type,enabled,published,sort_order) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(...values).run();
  }else return json({error:'INVALID_MUSIC_ENTITY'},400,cors);
  return json({ok:true},200,cors);
}
async function adminLiveMusicDelete(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;await ensureLiveMusicSchema(env);const b=await body(request),entity=String(b.entity||'').toUpperCase(),id=Math.max(1,Number(b.id||0));
  if(entity==='SONG'){const s=await env.DB.prepare(`SELECT object_key FROM myshop_music_songs WHERE id=?`).bind(id).first();await env.DB.prepare(`DELETE FROM myshop_music_songs WHERE id=?`).bind(id).run();if(s?.object_key&&env.MEDIA)try{await env.MEDIA.delete(String(s.object_key));}catch(_){}}
  else if(entity==='ALBUM'){const rows=(await env.DB.prepare(`SELECT object_key FROM myshop_music_songs WHERE album_id=?`).bind(id).all()).results||[];await env.DB.prepare(`DELETE FROM myshop_music_songs WHERE album_id=?`).bind(id).run();await env.DB.prepare(`DELETE FROM myshop_music_albums WHERE id=?`).bind(id).run();if(env.MEDIA)for(const s of rows)if(s.object_key)try{await env.MEDIA.delete(String(s.object_key));}catch(_){}}
  else return json({error:'INVALID_MUSIC_ENTITY'},400,cors);return json({ok:true,deleted:true},200,cors);
}
async function adminLiveMusicUpload(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;if(!env.MEDIA)return json({error:'R2_NOT_CONFIGURED'},503,cors);const form=await request.formData(),file=form.get('file');if(!(file instanceof File))return json({error:'FILE_REQUIRED'},400,cors);if(file.size>25*1024*1024)return json({error:'MUSIC_FILE_TOO_LARGE'},413,cors);
  const type=String(file.type||'').toLowerCase();if(!type.startsWith('audio/'))return json({error:'MUSIC_AUDIO_REQUIRED'},400,cors);const ext=(String(file.name||'track.mp3').split('.').pop()||'mp3').replace(/[^a-zA-Z0-9]/g,'').slice(0,8)||'mp3',key=`live/music/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:type,cacheControl:'public, max-age=31536000'}});if(!await env.MEDIA.head(key))return json({error:'R2_VERIFY_FAILED'},503,cors);return json({ok:true,url:new URL('/v1/media/'+encodeURIComponent(key),request.url).toString(),objectKey:key},201,cors);
}

async function friendCancel(request,env){
  await ensureFriendSchema(env);
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request),target=String(b.userId||'').trim();if(!isFourDigit(target)||target===user.user_id)return json({error:'INVALID_USER'},400,cors);
  const r=await env.DB.prepare("DELETE FROM myshop_friend_requests WHERE sender_id=? AND receiver_id=? AND status='PENDING'").bind(user.user_id,target).run();
  return json({ok:true,cancelled:Number(r?.meta?.changes||0)>0,status:'NONE',stats:await socialStatsFor(env,user.user_id),peerStats:await socialStatsFor(env,target)},200,cors);
}

async function friendRemove(request,env){
  await ensureFriendSchema(env);
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request),target=String(b.userId||'').trim();if(!isFourDigit(target)||target===user.user_id)return json({error:'INVALID_USER'},400,cors);
  const r=await env.DB.prepare("DELETE FROM myshop_friend_requests WHERE status='ACCEPTED' AND ((sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?))").bind(user.user_id,target,target,user.user_id).run();
  return json({ok:true,removed:Number(r?.meta?.changes||0)>0,stats:await socialStatsFor(env,user.user_id),peerStats:await socialStatsFor(env,target)},200,cors);
}


async function ensureLevelSchema(env){return schemaOnce(env.DB,'ensureLevelSchema',()=>ensureLevelSchemaImpl(env));}
async function ensureLevelSchemaImpl(env){
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_user_progress (user_id TEXT PRIMARY KEY,stars INTEGER NOT NULL DEFAULT 0,level INTEGER NOT NULL DEFAULT 0,normal_coin_units INTEGER NOT NULL DEFAULT 0,normal_gold_units INTEGER NOT NULL DEFAULT 0,official_coin_units INTEGER NOT NULL DEFAULT 0,official_gold_units INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_star_level_ledger (id INTEGER PRIMARY KEY AUTOINCREMENT,tx_type TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('COIN','GOLD')),sender_id TEXT NOT NULL DEFAULT '',receiver_id TEXT NOT NULL,units INTEGER NOT NULL DEFAULT 0,stars INTEGER NOT NULL DEFAULT 0,level_added INTEGER NOT NULL DEFAULT 0,official INTEGER NOT NULL DEFAULT 0,reference TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  for(const sql of [
    `ALTER TABLE myshop_user_progress ADD COLUMN normal_coin_units INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_user_progress ADD COLUMN normal_gold_units INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_user_progress ADD COLUMN official_coin_units INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_user_progress ADD COLUMN official_gold_units INTEGER NOT NULL DEFAULT 0`
  ]){try{await env.DB.prepare(sql).run();}catch(e){}}
}

async function reconcileLevelProgress(env,userId){
  await ensureLevelSchema(env);
  // V-317 one-time legacy backfill. This repairs users who received Coin/Gold from Admin
  // before the Star/Level progress table existed (for example 100,000 official Coin => LV.2).
  // A progress row acts as the migration marker, so current transactions are never counted twice.
  let row=await env.DB.prepare(`SELECT stars,level,normal_coin_units,normal_gold_units,official_coin_units,official_gold_units FROM myshop_user_progress WHERE user_id=?`).bind(userId).first();
  if(!row){
    let history={normal_coin_units:0,normal_gold_units:0,official_coin_units:0,official_gold_units:0};
    try{
      history=await env.DB.prepare(`SELECT
        COALESCE(SUM(CASE WHEN currency='COIN' AND tx_type IN ('GIFT','TRANSFER') AND sender_id NOT IN ('0001','0002','0003') THEN gross_amount ELSE 0 END),0) normal_coin_units,
        COALESCE(SUM(CASE WHEN currency='GOLD' AND tx_type IN ('GIFT','TRANSFER') AND sender_id NOT IN ('0001','0002','0003') THEN gross_amount ELSE 0 END),0) normal_gold_units,
        COALESCE(SUM(CASE WHEN currency='COIN' AND (tx_type='ADMIN_GRANT' OR (tx_type IN ('GIFT','TRANSFER') AND sender_id IN ('0001','0002','0003'))) THEN gross_amount ELSE 0 END),0) official_coin_units,
        COALESCE(SUM(CASE WHEN currency='GOLD' AND (tx_type='ADMIN_GRANT' OR (tx_type IN ('GIFT','TRANSFER') AND sender_id IN ('0001','0002','0003'))) THEN gross_amount ELSE 0 END),0) official_gold_units
        FROM myshop_value_ledger WHERE receiver_id=? AND status='COMPLETED'`).bind(userId).first()||history;
    }catch(e){}
    let oldAdminCoin=0,oldAdminGold=0;
    try{const x=await env.DB.prepare(`SELECT COALESCE(SUM(CASE WHEN amount>0 AND kind='ADMIN_GRANT' AND status='COMPLETED' THEN amount ELSE 0 END),0) total FROM myshop_coin_transactions WHERE user_id=?`).bind(userId).first();oldAdminCoin=Math.max(0,Number(x?.total||0));}catch(e){}
    try{const x=await env.DB.prepare(`SELECT COALESCE(SUM(CASE WHEN amount>0 AND kind='ADMIN_GRANT' THEN amount ELSE 0 END),0) total FROM myshop_gold_transactions WHERE user_id=?`).bind(userId).first();oldAdminGold=Math.max(0,Number(x?.total||0));}catch(e){}
    const nc=Math.max(0,Number(history?.normal_coin_units||0)),ng=Math.max(0,Number(history?.normal_gold_units||0));
    const oc=Math.max(oldAdminCoin,Math.max(0,Number(history?.official_coin_units||0))),og=Math.max(oldAdminGold,Math.max(0,Number(history?.official_gold_units||0)));
    const normalStars=Math.floor(nc/100000)+Math.floor(ng/1000),officialStars=Math.floor(oc/100000)+Math.floor(og/1000);
    await env.DB.prepare(`INSERT OR IGNORE INTO myshop_user_progress(user_id,stars,level,normal_coin_units,normal_gold_units,official_coin_units,official_gold_units,updated_at) VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)`).bind(userId,normalStars+officialStars,['0001','0002','0003'].includes(String(userId))?0:Math.floor(nc/100000)+Math.floor(ng/1000)+Math.floor(oc/100000)*2+Math.floor(og/1000)*2,nc,ng,oc,og).run();
    row=await env.DB.prepare(`SELECT stars,level,normal_coin_units,normal_gold_units,official_coin_units,official_gold_units FROM myshop_user_progress WHERE user_id=?`).bind(userId).first();
  }
  const led=await env.DB.prepare(`SELECT COALESCE(SUM(stars),0) stars,COALESCE(SUM(level_added),0) level,
    COALESCE(SUM(CASE WHEN official=0 AND currency='COIN' THEN units ELSE 0 END),0) normal_coin_units,
    COALESCE(SUM(CASE WHEN official=0 AND currency='GOLD' THEN units ELSE 0 END),0) normal_gold_units,
    COALESCE(SUM(CASE WHEN official=1 AND currency='COIN' THEN units ELSE 0 END),0) official_coin_units,
    COALESCE(SUM(CASE WHEN official=1 AND currency='GOLD' THEN units ELSE 0 END),0) official_gold_units
    FROM myshop_star_level_ledger WHERE receiver_id=?`).bind(userId).first();
  const ledgerStars=Math.max(0,Number(led?.stars||0)),ledgerLevel=Math.max(0,Number(led?.level||0));
  const currentStars=Math.max(0,Number(row?.stars||0)),currentLevel=Math.max(0,Number(row?.level||0));
  const nc=Math.max(Number(row?.normal_coin_units||0),Number(led?.normal_coin_units||0));
  const ng=Math.max(Number(row?.normal_gold_units||0),Number(led?.normal_gold_units||0));
  const oc=Math.max(Number(row?.official_coin_units||0),Number(led?.official_coin_units||0));
  const og=Math.max(Number(row?.official_gold_units||0),Number(led?.official_gold_units||0));
  const cumulativeNormalStars=Math.floor(nc/100000)+Math.floor(ng/1000);
  const cumulativeOfficialStars=Math.floor(oc/100000)+Math.floor(og/1000);
  const reconciledStars=Math.max(currentStars,ledgerStars,cumulativeNormalStars+cumulativeOfficialStars);
  const reconciledLevel=['0001','0002','0003'].includes(String(userId))?0:Math.max(currentLevel,ledgerLevel,Math.floor(nc/100000)+Math.floor(ng/1000)+Math.floor(oc/100000)*2+Math.floor(og/1000)*2);
  if(reconciledStars!==currentStars||reconciledLevel!==currentLevel||nc!==Number(row?.normal_coin_units||0)||ng!==Number(row?.normal_gold_units||0)||oc!==Number(row?.official_coin_units||0)||og!==Number(row?.official_gold_units||0)){
    await env.DB.prepare(`UPDATE myshop_user_progress SET stars=?,level=?,normal_coin_units=?,normal_gold_units=?,official_coin_units=?,official_gold_units=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(reconciledStars,reconciledLevel,nc,ng,oc,og,userId).run();
  }
  return await env.DB.prepare(`SELECT stars,level,normal_coin_units,normal_gold_units,official_coin_units,official_gold_units FROM myshop_user_progress WHERE user_id=?`).bind(userId).first();
}

async function coinLevelFor(env,userId){
  await env.DB.prepare('INSERT OR IGNORE INTO myshop_coin_wallets(user_id,balance) VALUES(?,0)').bind(userId).run();
  const r=await env.DB.prepare(`SELECT COALESCE(SUM(CASE WHEN amount>0 AND status='COMPLETED' AND kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN amount ELSE 0 END),0) AS purchased FROM myshop_coin_transactions WHERE user_id=?`).bind(userId).first();
  const purchased=Math.max(0,Number(r?.purchased||0));
  const legacyPurchaseLevel=Math.max(0,Math.floor(purchased/100000))*2;
  const pr=await reconcileLevelProgress(env,userId);
  const earnedLevel=Math.max(0,Number(pr?.level||0));
  const level=['0001','0002','0003'].includes(String(userId))?0:legacyPurchaseLevel+earnedLevel;
  const currentLevelStart=Math.floor(purchased/100000)*100000;
  const nextLevelAt=(Math.floor(purchased/100000)+1)*100000;
  const progress=Math.max(0,Math.min(100,Math.floor(((purchased-currentLevelStart)/100000)*100)));
  return {level,earnedLevel,stars:Math.max(0,Number(pr?.stars||0)),totalPurchasedCoins:purchased,nextLevelAt,progress};
}

async function coinBalance(request, env) {
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  await env.DB.prepare('INSERT OR IGNORE INTO myshop_coin_wallets(user_id,balance) VALUES(?,0)').bind(user.user_id).run();
  const wallet=await env.DB.prepare('SELECT user_id,balance,updated_at FROM myshop_coin_wallets WHERE user_id=?').bind(user.user_id).first();
  const tx=(await env.DB.prepare('SELECT id,kind,amount,reference,status,metadata,created_at FROM myshop_coin_transactions WHERE user_id=? ORDER BY id DESC LIMIT 50').bind(user.user_id).all()).results||[];
  const levelInfo=await coinLevelFor(env,user.user_id);
  return json({ok:true,balance:Number(wallet?.balance||0),transactions:tx,level:levelInfo.level,totalPurchasedCoins:levelInfo.totalPurchasedCoins,nextLevelAt:levelInfo.nextLevelAt,levelProgress:levelInfo.progress},200,cors);
}

async function giftHistory(request,env){
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const rows=(await env.DB.prepare(`SELECT id,sender_user_id,receiver_user_id,coins,gift_code,created_at FROM myshop_gift_transactions WHERE sender_user_id=? OR receiver_user_id=? ORDER BY id DESC LIMIT 100`).bind(user.user_id,user.user_id).all()).results||[];
  return json({ok:true,gifts:rows},200,cors);
}

async function coinPurchaseRequest(request,env){
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  return json({error:'DIRECT_DIGITAL_PAYMENT_DISABLED',message:'Coin purchases must use Google Play Billing.'},409,cors);
}



async function premiumPaymentSettings(env){
  // V-412 MASTER LOCK: Premium Shop purchases use Diamond only.
  // Coin/mobile-wallet fields remain in the legacy table for compatibility, but are never exposed or accepted for Premium purchases.
  let r=null;try{r=await env.DB.prepare(`SELECT * FROM myshop_premium_payment_settings WHERE id=1`).first();}catch(_){}
  return {coinEnabled:false,goldEnabled:true,cashEnabled:false,bkashEnabled:false,nagadEnabled:false,cashConfigured:false,bkashConfigured:false,nagadConfigured:false,bkashNumber:'',nagadNumber:'',instructions:'Premium purchases use Diamond only. Gold is held until Admin approval; rejection releases the hold.',referenceRequired:false,alternativeBillingAllowed:false};
}
async function logPremiumPurchaseEvent(env,uid,catalogId,eventType,paymentMode='',paymentMethod='',requestId=0,amount=0){try{await env.DB.prepare(`INSERT INTO myshop_store_purchase_events(user_id,catalog_id,event_type,payment_mode,payment_method,request_id,amount) VALUES(?,?,?,?,?,?,?)`).bind(uid,catalogId,eventType,paymentMode,paymentMethod,requestId,amount).run();}catch(e){console.error('PREMIUM_PURCHASE_EVENT_FAILED',eventType,String(e?.message||e));}}
async function notifyPremiumAdmins(env,title,message){for(const adminId of ['0001','0002','0003']){try{await createUserNotification(env,adminId,title,message);}catch(_){}}}
// V-430: new catalog identity; old retired/deleted products are not restored.
const V430_MEMBERSHIP_TIERS = ['KING','QUEEN','ROYAL','VVIP','VIP'];
const V430_MEMBERSHIP_INSTALL_KEY = 'membership_catalog_v430_20260919';
function membershipTier(code){
  const raw=String(code||'').toUpperCase();
  const tier=raw.startsWith('MS430_')?raw.slice(6):raw;
  return V430_MEMBERSHIP_TIERS.includes(tier)?tier:'';
}
function catalogClientRows(rows){
  return (rows||[]).map(row=>{
    const tier=membershipTier(row.code);
    return tier?{...row,catalog_code:row.code,code:tier,membership_tier:tier}:row;
  });
}
function managedBannerFolder(folder){
  return ['hero','promo','shop_home','shop_promo','live_home','live2_promo_1','live2_promo_2','live2_promo_3','live2_promo_4'].includes(folder);
}
async function ensureV430MembershipCatalog(env){
  const marker=await env.DB.prepare('SELECT value FROM myshop_schema_meta WHERE key=?').bind(V430_MEMBERSHIP_INSTALL_KEY).first();
  if(marker)return;
  const inserts=V430_MEMBERSHIP_TIERS.map((tier,index)=>env.DB.prepare(`INSERT OR IGNORE INTO myshop_store_catalog(code,title,item_type,units,price_minor,coin_price,gold_price,duration_days,benefits,priority,enabled,preview_mode) SELECT ?,?,'MEMBERSHIP',1,0,0,5000,30,'Animated profile frame + matching comment box',?,1,'AUTO' WHERE NOT EXISTS(SELECT 1 FROM myshop_schema_meta WHERE key=?)`).bind('MS430_'+tier,tier,index+1,V430_MEMBERSHIP_INSTALL_KEY));
  inserts.push(env.DB.prepare(`INSERT OR IGNORE INTO myshop_schema_meta(key,value,updated_at) VALUES(?,'installed',CURRENT_TIMESTAMP)`).bind(V430_MEMBERSHIP_INSTALL_KEY));
  // One D1 transaction: no partially seeded catalog and no re-seeding after deletion.
  await env.DB.batch(inserts);
}
function membershipStyle(tier){
  const colors={KING:['#351C09','#FFBB37'],QUEEN:['#380D2B','#FF4DB5'],ROYAL:['#21113C','#B16BFF'],VVIP:['#08283C','#38CEFF'],VIP:['#092D1D','#45DD93']};
  const c=colors[tier]||colors.VIP;
  return {backgroundColor:c[0],textColor:'#FFFFFF',nameColor:c[1],levelColor:'#DAEEFF',borderColor:c[1],fontSize:14,fontWeight:'BOLD',borderWidth:1,cornerRadius:14,opacity:100,borderGlow:true,borderGlowColor:c[1],borderGlowIntensity:38,backgroundGlow:false,animation:false,boxAnimation:false,borderAnimation:true,borderAnimationType:'GLOW BORDER',animationSpeed:42,textAnimation:false,nameAnimation:false,levelAnimation:false,membershipTier:tier};
}
async function membershipGrantPlan(env,uid,item,source,note){
  const tier=membershipTier(item.code);if(!tier)throw new Error('INVALID_MEMBERSHIP');
  await ensureLiveRoomSchema(env);
  const key='V430-'+tier;
  // Existing Admin-edited preset is never overwritten by a grant.
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_comment_presets(preset_key,badge,gender,preset_no,style_json) VALUES(?,?,'UNSPECIFIED',1,?)`).bind(key,tier,JSON.stringify(membershipStyle(tier))).run();
  const days=Math.max(1,Math.min(3650,Math.floor(Number(item.duration_days||30))));
  const expiry=new Date(Date.now()+days*86400000).toISOString();
  const writes=[
    env.DB.prepare(`UPDATE myshop_user_badges SET status='REPLACED',is_displayed=0 WHERE user_id=? AND status='ACTIVE' AND badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP')`).bind(uid),
    env.DB.prepare(`INSERT INTO myshop_user_badges(user_id,badge_code,status,source,expires_at,note,catalog_id,is_displayed) VALUES(?,?,'ACTIVE',?,?,?,?,1)`).bind(uid,tier,source,expiry,note,item.id),
    env.DB.prepare(`INSERT INTO myshop_live_comment_assignments(user_id,preset_key,custom_style_json,is_custom,enabled,source,updated_at) VALUES(?,?,'{}',0,1,'MEMBERSHIP',CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET preset_key=excluded.preset_key,custom_style_json='{}',is_custom=0,enabled=1,source='MEMBERSHIP',updated_at=CURRENT_TIMESTAMP`).bind(uid,key)
  ];
  return {writes,result:{tier,expiresAt:expiry}};
}
async function activateMembershipCatalog(env,uid,item,source,note){const plan=await membershipGrantPlan(env,uid,item,source,note);await env.DB.batch(plan.writes);return plan.result;}
async function adminMembershipRevoke(request,env){
  const auth=await adminOnly(request,env);if(auth.error)return auth.error;
  const b=await body(request),uid=String(b.userId||'').trim();
  if(!isFourDigit(uid))return json({error:'INVALID_USER_ID'},400,cors);
  const target=await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(uid).first();
  if(!target)return json({error:'USER_NOT_FOUND'},404,cors);
  await ensureLiveRoomSchema(env);
  await env.DB.batch([
    env.DB.prepare(`UPDATE myshop_user_badges SET status='REVOKED',is_displayed=0 WHERE user_id=? AND status='ACTIVE' AND badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP')`).bind(uid),
    env.DB.prepare(`UPDATE myshop_live_comment_assignments SET enabled=0,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND source='MEMBERSHIP'`).bind(uid),
    env.DB.prepare(`INSERT INTO myshop_store_audit(admin_user_id,action,item_code,details) VALUES(?,'REVOKE_MEMBERSHIP','MEMBERSHIP',?)`).bind(auth.user.user_id,JSON.stringify({userId:uid,reason:String(b.note||'').slice(0,180)}))
  ]);
  return json({ok:true,userId:uid,membershipRemoved:true},200,cors);
}

async function storePurchaseIntent(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);const b=await body(request),id=Math.floor(Number(b.productId||0));if(!id)return json({error:'INVALID_CATALOG_ID'},400,cors);const item=await env.DB.prepare(`SELECT id FROM myshop_store_catalog WHERE id=? AND enabled=1`).bind(id).first();if(!item)return json({error:'CATALOG_NOT_FOUND'},404,cors);await logPremiumPurchaseEvent(env,user.user_id,id,'BUY_STARTED');return json({ok:true},200,cors);
}
async function storeCatalog(request,env){
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors); await ensureLiveRoomSchema(env);
  const rows=(await env.DB.prepare("SELECT id,code,title,item_type,units,price_minor,coin_price,gold_price,duration_days,preview_url,animation_url,animation_mime,benefits,priority,limited_edition,featured,preview_mode,animation_speed,sound_url,sound_volume,effect_duration_ms,sound_duration_ms,play_product_id FROM myshop_store_catalog WHERE enabled=1 ORDER BY CASE code WHEN 'KING' THEN 1 WHEN 'QUEEN' THEN 1 WHEN 'ROYAL' THEN 2 WHEN 'VVIP' THEN 3 WHEN 'VIP' THEN 4 ELSE priority END,priority,id").all()).results||[];
  const cfg=await financeConfig(env),paymentSettings=await premiumPaymentSettings(env);
  return json({ok:true,catalog:catalogClientRows(rows),platformFeePercent:cfg.feePercent,vatPercent:cfg.vatPercent,alternativePaymentEnabled:paymentSettings.cashEnabled,paymentSettings},200,cors);
}
async function adminPremiumPaymentSettings(request,env){const auth=await adminOnly(request,env);if(auth.error)return auth.error;const settings=await premiumPaymentSettings(env);return json({ok:true,settings},200,cors);}
async function adminPremiumPaymentSettingsSave(request,env){
  const auth=await adminOnly(request,env);if(auth.error)return auth.error;
  // V-412: Premium payment policy is intentionally non-configurable: Diamond only.
  await env.DB.prepare(`INSERT INTO myshop_premium_payment_settings(id,coin_enabled,gold_enabled,cash_enabled,bkash_enabled,nagad_enabled,bkash_number,nagad_number,instructions,reference_required,updated_at) VALUES(1,0,1,0,0,0,'','','Diamond only • Hold → Admin Verify → Approve/Reject',0,CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET coin_enabled=0,gold_enabled=1,cash_enabled=0,bkash_enabled=0,nagad_enabled=0,bkash_number='',nagad_number='',instructions='Diamond only • Hold → Admin Verify → Approve/Reject',reference_required=0,updated_at=CURRENT_TIMESTAMP`).run();
  await env.DB.prepare(`INSERT INTO myshop_store_audit(admin_user_id,action,item_code,details) VALUES(?,'PAYMENT_SETTINGS','PREMIUM',?)`).bind(auth.user.user_id,JSON.stringify({goldOnly:true})).run();
  return json({ok:true,settings:await premiumPaymentSettings(env)},200,cors);
}
async function adminStoreCatalog(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error;
  const rows=(await env.DB.prepare("SELECT * FROM myshop_store_catalog WHERE NOT(enabled=0 AND code IN ('KING','QUEEN','ROYAL','VVIP','VIP')) ORDER BY enabled DESC,CASE code WHEN 'KING' THEN 1 WHEN 'QUEEN' THEN 1 WHEN 'ROYAL' THEN 2 WHEN 'VVIP' THEN 3 WHEN 'VIP' THEN 4 ELSE priority END,priority,id").all()).results||[];
  return json({ok:true,catalog:catalogClientRows(rows)},200,cors);
}
async function adminStoreCatalogSave(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; const b=await body(request);
  if(Number(b.id)>0){const original=await env.DB.prepare('SELECT code FROM myshop_store_catalog WHERE id=?').bind(Number(b.id)).first();if(original&&String(original.code).startsWith('MS430_')){b.code=original.code;b.itemType='MEMBERSHIP';}}
  const id=Math.max(0,Math.floor(Number(b.id||0))), code=String(b.code||'').trim().toUpperCase().replace(/[^A-Z0-9_-]/g,'').slice(0,40), title=String(b.title||'').trim().slice(0,80), type=String(b.itemType||'').trim().toUpperCase();
  const units=Math.max(1,Math.floor(Number(b.units||1))), isWalletPack=(type==='COIN'||type==='GOLD'), price=isWalletPack?Math.max(0,Math.floor(Number(b.priceMinor||0))):0, coinPrice=isWalletPack?Math.max(0,Math.floor(Number(b.coinPrice||0))):0, goldPrice=isWalletPack?Math.max(0,Math.floor(Number(b.goldPrice||0))):Math.max(1,Math.floor(Number(b.goldPrice||5000))), days=isWalletPack?Math.max(0,Math.min(1825,Math.floor(Number(b.durationDays||0)))):Math.max(1,Math.min(1825,Math.floor(Number(b.durationDays||30)))), priority=Math.max(1,Math.floor(Number(b.priority||100)));
  const preview=String(b.previewUrl||'').trim().slice(0,1200), animation=String(b.animationUrl||'').trim().slice(0,1200), mime=String(b.animationMime||'').trim().slice(0,80), benefits=String(b.benefits||'').trim().slice(0,1000), limited=b.limitedEdition?1:0, featured=b.featured?1:0, enabled=b.enabled===false?0:1, autoApprove=b.autoApprove===true?1:0;
  const previewMode=String(b.previewMode||'AUTO').trim().toUpperCase().slice(0,24), animationSpeed=Math.max(1,Math.min(100,Math.floor(Number(b.animationSpeed||55)))), soundUrl=String(b.soundUrl||'').trim().slice(0,900), soundVolume=Math.max(0,Math.min(100,Math.floor(Number(b.soundVolume??90)))), effectDurationMs=Math.max(800,Math.min(15000,Math.floor(Number(b.effectDurationMs??3500)))), soundDurationMs=Math.max(0,Math.min(15000,Math.floor(Number(b.soundDurationMs??3000))));
  const playProductId=String(b.playProductId||'').trim().toLowerCase().replace(/[^a-z0-9._]/g,'').slice(0,80);
  const allowed=['COIN','GOLD','BADGE','MEMBERSHIP','FRAME','AVATAR_FRAME','RING','ANIMATED_RING','THEME','LIVE_THEME','WALLPAPER','COMMENT_STYLE','ENTRY_ANIMATION','PROFILE_STYLE','GIFT','LIVE_GIFT'];
  if(!code||!title||!allowed.includes(type)||(enabled&&isWalletPack&&(price<=0&&coinPrice<=0&&goldPrice<=0))||(enabled&&!isWalletPack&&goldPrice<=0))return json({error:'INVALID_CATALOG_ITEM',message:enabled?'Published Premium items require a Diamond price.':'Draft identity is incomplete.'},400,cors);
  const altBilling=String(env.ALTERNATIVE_BILLING_ENABLED||'').trim()==='1';if(enabled&&price>0&&!playProductId&&!altBilling)return json({error:'PLAY_PRODUCT_ID_REQUIRED',message:'Money-priced published digital items require Google Play product ID unless approved alternative billing is enabled.'},400,cors);
  if(type==='WALLPAPER'&&enabled){const c=await env.DB.prepare(`SELECT COUNT(*) n FROM myshop_store_catalog WHERE item_type='WALLPAPER' AND enabled=1 AND id<>?`).bind(id||0).first();if(Number(c?.n||0)>=50)return json({error:'WALLPAPER_ACTIVE_LIMIT',message:'Maximum 50 active Live Wallpapers are allowed.'},409,cors);}
  let r;
  if(id){r=await env.DB.prepare("UPDATE myshop_store_catalog SET code=?,title=?,item_type=?,units=?,price_minor=?,coin_price=?,gold_price=?,duration_days=?,preview_url=?,animation_url=?,animation_mime=?,benefits=?,priority=?,limited_edition=?,featured=?,enabled=?,preview_mode=?,animation_speed=?,sound_url=?,sound_volume=?,effect_duration_ms=?,sound_duration_ms=?,play_product_id=?,auto_approve=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(code,title,type,units,price,coinPrice,goldPrice,days,preview,animation,mime,benefits,priority,limited,featured,enabled,previewMode,animationSpeed,soundUrl,soundVolume,effectDurationMs,soundDurationMs,playProductId,autoApprove,id).run();}
  else{r=await env.DB.prepare("INSERT INTO myshop_store_catalog(code,title,item_type,units,price_minor,coin_price,gold_price,duration_days,preview_url,animation_url,animation_mime,benefits,priority,limited_edition,featured,enabled,preview_mode,animation_speed,sound_url,sound_volume,effect_duration_ms,sound_duration_ms,play_product_id,auto_approve) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)").bind(code,title,type,units,price,coinPrice,goldPrice,days,preview,animation,mime,benefits,priority,limited,featured,enabled,previewMode,animationSpeed,soundUrl,soundVolume,effectDurationMs,soundDurationMs,playProductId,autoApprove).run();}
  const cid=id||r.meta?.last_row_id||0; await env.DB.prepare("INSERT INTO myshop_store_audit(admin_user_id,action,catalog_id,item_code,details) VALUES(?,?,?,?,?)").bind(auth.user.user_id,id?'UPDATE':'CREATE',cid,code,JSON.stringify({title,type,units,price,coinPrice,goldPrice,days,priority,limited,featured,enabled,previewMode,animationSpeed,soundVolume,effectDurationMs,soundDurationMs,playProductId,autoApprove})).run();
  return json({ok:true,id:cid,code},200,cors);
}
async function adminStoreCatalogToggle(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; const b=await body(request); const id=Math.floor(Number(b.id||0)),enabled=b.enabled?1:0; if(!id)return json({error:'INVALID_CATALOG_ID'},400,cors);
  const row=await env.DB.prepare('SELECT code,item_type FROM myshop_store_catalog WHERE id=?').bind(id).first(); if(!row)return json({error:'CATALOG_NOT_FOUND'},404,cors);
  if(enabled&&String(row.item_type||'').toUpperCase()==='WALLPAPER'){const c=await env.DB.prepare(`SELECT COUNT(*) n FROM myshop_store_catalog WHERE item_type='WALLPAPER' AND enabled=1 AND id<>?`).bind(id).first();if(Number(c?.n||0)>=50)return json({error:'WALLPAPER_ACTIVE_LIMIT',message:'Maximum 50 active Live Wallpapers are allowed.'},409,cors);}
  await env.DB.prepare('UPDATE myshop_store_catalog SET enabled=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(enabled,id).run(); await env.DB.prepare("INSERT INTO myshop_store_audit(admin_user_id,action,catalog_id,item_code,details) VALUES(?,?,?,?,?)").bind(auth.user.user_id,enabled?'ENABLE':'DISABLE',id,row.code,'').run(); return json({ok:true,id,enabled},200,cors);
}
async function adminStoreCatalogReorder(request,env){
  const auth=await adminOnly(request,env);if(auth.error)return auth.error;const b=await body(request),sourceId=Math.floor(Number(b.sourceId||0)),targetId=Math.floor(Number(b.targetId||0));if(!sourceId||!targetId||sourceId===targetId)return json({error:'INVALID_REORDER'},400,cors);const a=await env.DB.prepare(`SELECT id,code,item_type,priority FROM myshop_store_catalog WHERE id=?`).bind(sourceId).first(),z=await env.DB.prepare(`SELECT id,code,item_type,priority FROM myshop_store_catalog WHERE id=?`).bind(targetId).first();if(!a||!z)return json({error:'CATALOG_NOT_FOUND'},404,cors);if(String(a.item_type)!=='WALLPAPER'||String(z.item_type)!=='WALLPAPER')return json({error:'WALLPAPER_REORDER_ONLY'},409,cors);const pa=Math.max(1,Number(a.priority||600)),pz=Math.max(1,Number(z.priority||600));await env.DB.batch([env.DB.prepare(`UPDATE myshop_store_catalog SET priority=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(pz,sourceId),env.DB.prepare(`UPDATE myshop_store_catalog SET priority=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(pa,targetId),env.DB.prepare(`INSERT INTO myshop_store_audit(admin_user_id,action,catalog_id,item_code,details) VALUES(?,?,?,?,?)`).bind(auth.user.user_id,'REORDER',sourceId,a.code,JSON.stringify({targetId,targetCode:z.code,from:pa,to:pz}))]);return json({ok:true,sourceId,targetId,sourcePriority:pz,targetPriority:pa},200,cors);
}
async function adminStoreCatalogDelete(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; const b=await body(request); const id=Math.floor(Number(b.id||0)); if(!id)return json({error:'INVALID_CATALOG_ID'},400,cors);
  const row=await env.DB.prepare('SELECT id,code,title,item_type FROM myshop_store_catalog WHERE id=?').bind(id).first(); if(!row)return json({error:'CATALOG_NOT_FOUND'},404,cors);
  // V-424 permanent admin delete: revoke this product everywhere, cancel/refund pending Gold holds,
  // then physically remove the catalog row. There is no startup/default catalog reseed path.
  const pending=(await env.DB.prepare(`SELECT id,user_id,funds_held,official_held FROM myshop_store_purchase_requests WHERE catalog_id=? AND status='PENDING'`).bind(id).all()).results||[];
  for(const r of pending){const held=Math.max(0,Number(r.funds_held||0)),official=Math.max(0,Number(r.official_held||0));if(held>0)await env.DB.prepare(`UPDATE myshop_gold_wallets SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(held,r.user_id).run();if(official>0)await env.DB.prepare(`INSERT INTO myshop_wallet_sources(user_id,currency,official_balance,updated_at) VALUES(?,'GOLD',?,CURRENT_TIMESTAMP) ON CONFLICT(user_id,currency) DO UPDATE SET official_balance=official_balance+excluded.official_balance,updated_at=CURRENT_TIMESTAMP`).bind(r.user_id,official).run();await env.DB.prepare(`UPDATE myshop_store_purchase_requests SET status='REJECTED',funds_held=0,official_held=0,payment_state='PRODUCT_DELETED',decision_note='Product permanently deleted by Admin',updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(r.id).run();}
  await env.DB.prepare(`DELETE FROM myshop_owned_items WHERE catalog_id=?`).bind(id).run();
  const isMembership=String(row.item_type||'').toUpperCase()==='MEMBERSHIP'||!!membershipTier(row.code);
  if(isMembership)await env.DB.prepare(`UPDATE myshop_live_comment_assignments SET enabled=0,updated_at=CURRENT_TIMESTAMP WHERE source='MEMBERSHIP' AND user_id IN (SELECT user_id FROM myshop_user_badges WHERE status='ACTIVE' AND (catalog_id=? OR (catalog_id IS NULL AND badge_code=?)))`).bind(id,membershipTier(row.code)||String(row.code||'').toUpperCase()).run().catch(()=>{});
  await env.DB.prepare(`UPDATE myshop_user_badges SET status='REMOVED',is_displayed=0 WHERE status='ACTIVE' AND (catalog_id=? OR (catalog_id IS NULL AND ?=1 AND badge_code=?))`).bind(id,isMembership?1:0,membershipTier(row.code)||String(row.code||'').toUpperCase()).run().catch(()=>{});
  await env.DB.prepare("INSERT INTO myshop_store_audit(admin_user_id,action,catalog_id,item_code,details) VALUES(?,?,?,?,?)").bind(auth.user.user_id,'PERMANENT_DELETE',id,row.code,JSON.stringify({title:row.title,itemType:row.item_type,revokeAll:true,refundedPending:pending.length})).run();
  await env.DB.prepare('DELETE FROM myshop_store_catalog WHERE id=?').bind(id).run();
  return json({ok:true,id,deleted:true,permanent:true,revokeAll:true},200,cors);
}
async function adminAssetUpload(request,env){
  try{await assertWriteReady(env);}catch(e){return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors);}
  const auth=await adminOnly(request,env);if(auth.error)return auth.error;if(!env.MEDIA)return json({error:'R2_NOT_CONFIGURED'},503,cors);
  let form;try{form=await request.formData();}catch(e){return json({error:'ASSET_MULTIPART_INVALID'},400,cors);}const file=form.get('file');if(!file||typeof file.arrayBuffer!=='function')return json({error:'FILE_REQUIRED'},400,cors);
  const type=String(file.type||'').toLowerCase();if(!type.startsWith('image/'))return json({error:'IMAGE_REQUIRED'},400,cors);if(Number(file.size||0)>8*1024*1024)return json({error:'IMAGE_TOO_LARGE'},413,cors);
  const purpose=String(form.get('purpose')||'asset').toLowerCase().replace(/[^a-z0-9_-]/g,'_').slice(0,60)||'asset';const name=String(file.name||'image.jpg').toLowerCase();const ext=(name.includes('.')?name.split('.').pop():'jpg').replace(/[^a-z0-9]/g,'').slice(0,8)||'jpg';const key=`managed-assets/${purpose}/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  try{await env.MEDIA.put(key,await file.arrayBuffer(),{httpMetadata:{contentType:type,cacheControl:'public, max-age=31536000'}});const h=await env.MEDIA.head(key);if(!h)throw new Error('R2_VERIFY_FAILED');}catch(e){try{await env.MEDIA.delete(key);}catch(_){}return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);}const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();return json({ok:true,image_url:url,object_key:key},201,cors);
}

async function adminStoreAssetUpload(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; if(!env.MEDIA)return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(),file=form.get('file'); if(!(file instanceof File))return json({error:'FILE_REQUIRED'},400,cors); if(file.size>20*1024*1024)return json({error:'PREMIUM_ASSET_TOO_LARGE'},413,cors);
  const ct=guessContentType(file); if(!['image/webp','image/gif','image/png','image/jpeg','audio/mpeg','audio/ogg','audio/wav','audio/x-wav','video/webm','video/mp4'].includes(ct))return json({error:'PREMIUM_ASSET_TYPE_MISMATCH'},400,cors);
  const ext=(String(file.name||'asset').split('.').pop()||'bin').replace(/[^a-zA-Z0-9]/g,'').slice(0,8)||'bin'; const key=`store/premium/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:ct,cacheControl:'public, max-age=31536000'}}); const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString(); return json({ok:true,url,mediaType:ct,objectKey:key},201,cors);
}
async function assignMembershipCommentBox(env,uid,code){
  const tier=String(code||'').toUpperCase();if(!['KING','QUEEN','ROYAL','VVIP','VIP'].includes(tier))return;
  try{await ensureLiveRoomSchema(env);const u=await env.DB.prepare(`SELECT COALESCE(gender,'UNSPECIFIED') gender FROM myshop_auth_users_v108 WHERE user_id=?`).bind(uid).first();let gender=String(u?.gender||'UNSPECIFIED').toUpperCase();if(tier==='KING')gender='MALE';else if(tier==='QUEEN')gender='FEMALE';else if(!['MALE','FEMALE'].includes(gender))gender='MALE';const wanted=`${tier}-${gender}-1`;let preset=await env.DB.prepare(`SELECT preset_key FROM myshop_live_comment_presets WHERE preset_key=?`).bind(wanted).first();if(!preset)preset=await env.DB.prepare(`SELECT preset_key FROM myshop_live_comment_presets WHERE badge=? ORDER BY preset_no LIMIT 1`).bind(tier).first();if(preset)await env.DB.prepare(`INSERT INTO myshop_live_comment_assignments(user_id,preset_key,custom_style_json,is_custom,enabled,source,updated_at) VALUES(?,?,'{}',0,1,'MEMBERSHIP',CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET preset_key=excluded.preset_key,custom_style_json='{}',is_custom=0,enabled=1,source='MEMBERSHIP',updated_at=CURRENT_TIMESTAMP`).bind(uid,preset.preset_key).run();}catch(e){console.error('MEMBERSHIP_COMMENT_AUTO_ASSIGN_FAILED',uid,tier,String(e?.message||e));}
}

function premiumEquipGroup(type){
  if(['THEME','LIVE_THEME','WALLPAPER'].includes(type))return ['THEME','LIVE_THEME','WALLPAPER'];
  if(['FRAME','AVATAR_FRAME'].includes(type))return ['FRAME','AVATAR_FRAME'];
  if(['RING','ANIMATED_RING'].includes(type))return ['RING','ANIMATED_RING'];
  return [type];
}
async function premiumGrantPlan(env,uid,item,source,note){
  if(membershipTier(item.code))return membershipGrantPlan(env,uid,item,source,note);
  const type=String(item.item_type||'').toUpperCase(),code=String(item.code||'').toUpperCase(),days=Math.max(0,Number(item.duration_days||0));
  if(type==='COIN'||type==='GOLD')throw new Error('INVALID_PREMIUM_PRODUCT');
  const exp=days>0?new Date(Date.now()+days*86400000).toISOString():null;
  if(['FRAME','AVATAR_FRAME','THEME','LIVE_THEME','WALLPAPER','GIFT','ENTRY_ANIMATION','COMMENT_STYLE','RING','ANIMATED_RING','PROFILE_STYLE'].includes(type)){
    const group=premiumEquipGroup(type),slots=group.map(()=>'?').join(',');
    return {writes:[env.DB.prepare(`UPDATE myshop_owned_items SET equipped=0 WHERE user_id=? AND item_type IN (${slots})`).bind(uid,...group),env.DB.prepare(`INSERT INTO myshop_owned_items(user_id,catalog_id,item_type,item_code,equipped,expires_at,source) VALUES(?,?,?,?,1,?,?) ON CONFLICT(user_id,catalog_id) DO UPDATE SET equipped=1,expires_at=excluded.expires_at,source=excluded.source`).bind(uid,item.id,type,code,exp,source)]};
  }
  return {writes:[env.DB.prepare('UPDATE myshop_user_badges SET is_displayed=0 WHERE user_id=?').bind(uid),env.DB.prepare(`INSERT INTO myshop_user_badges(user_id,badge_code,status,source,expires_at,note,catalog_id,is_displayed) VALUES(?,?,'ACTIVE',?,?,?,?,1)`).bind(uid,code,source,exp,note,item.id)]};
}
async function grantCatalogItem(env,uid,item,source,note){
  if(membershipTier(item.code))return activateMembershipCatalog(env,uid,item,source,note);
  const type=String(item.item_type||'').toUpperCase(), code=String(item.code||'').toUpperCase(), units=Math.max(1,Number(item.units||1)), days=Math.max(0,Number(item.duration_days||0));
  if(type==='COIN'){await env.DB.prepare('INSERT OR IGNORE INTO myshop_coin_wallets(user_id,balance) VALUES(?,0)').bind(uid).run();await env.DB.prepare('UPDATE myshop_coin_wallets SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(units,uid).run();await env.DB.prepare("INSERT INTO myshop_coin_transactions(user_id,kind,amount,reference,status,metadata) VALUES(?,'STORE_GRANT',?,'CATALOG','COMPLETED',?)").bind(uid,units,JSON.stringify({catalogId:item.id,source,note})).run();if(source==='ADMIN_GRANT'||source==='ADMIN'||source==='GOOGLE_PLAY'){await creditOfficialWalletSource(env,uid,'COIN',units);await applyStarsAndLevels(env,{txType:'STORE_GRANT',currency:'COIN',senderId:(source==='ADMIN_GRANT'||source==='ADMIN')?'MY_SHOP_ADMIN':'GOOGLE_PLAY',receiverId:uid,units,official:true,reference:'OFFICIAL_'+source});}}
  else if(type==='GOLD'){await env.DB.prepare('INSERT OR IGNORE INTO myshop_gold_wallets(user_id,balance) VALUES(?,0)').bind(uid).run();await env.DB.prepare('UPDATE myshop_gold_wallets SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(units,uid).run();await env.DB.prepare("INSERT INTO myshop_gold_transactions(user_id,kind,amount,reference,metadata) VALUES(?,'STORE_GRANT',?,'CATALOG',?)").bind(uid,units,JSON.stringify({catalogId:item.id,source,note})).run();if(source==='ADMIN_GRANT'||source==='ADMIN'||source==='GOOGLE_PLAY'){await creditOfficialWalletSource(env,uid,'GOLD',units);await applyStarsAndLevels(env,{txType:'STORE_GRANT',currency:'GOLD',senderId:(source==='ADMIN_GRANT'||source==='ADMIN')?'MY_SHOP_ADMIN':'GOOGLE_PLAY',receiverId:uid,units,official:true,reference:'OFFICIAL_'+source});}}
  else {const plan=await premiumGrantPlan(env,uid,item,source,note);await env.DB.batch(plan.writes);}
  if(['KING','QUEEN','ROYAL','VVIP','VIP'].includes(code))await assignMembershipCommentBox(env,uid,code);
}
async function activePremiumOwned(env,uid,id){
  const a=await env.DB.prepare(`SELECT id FROM myshop_owned_items WHERE user_id=? AND catalog_id=? AND (expires_at IS NULL OR datetime(expires_at)>datetime('now')) LIMIT 1`).bind(uid,id).first();if(a)return true;
  const b=await env.DB.prepare(`SELECT id FROM myshop_user_badges WHERE user_id=? AND catalog_id=? AND status='ACTIVE' AND (expires_at IS NULL OR datetime(expires_at)>datetime('now')) LIMIT 1`).bind(uid,id).first();return !!b;
}
async function createStorePurchaseRequest(env,user,id,mode,method,ref){
  const item=await env.DB.prepare('SELECT * FROM myshop_store_catalog WHERE id=? AND enabled=1').bind(id).first();if(!item)return {error:'CATALOG_NOT_FOUND',http:404};
  const type=String(item.item_type||'').toUpperCase();if(type==='COIN'||type==='GOLD')return {error:'INVALID_STORE_CURRENCY_PURCHASE',message:'Wallet packs use the approved wallet top-up flow.',http:409};
  if(await activePremiumOwned(env,user.user_id,id))return {error:'ALREADY_OWNED',message:'This Premium item is already active. Use Renew/Extend instead.',productId:id,http:409};
  const prior=await env.DB.prepare(`SELECT id,status,payment_state,payment_mode,total_amount,funds_held,official_held FROM myshop_store_purchase_requests WHERE user_id=? AND catalog_id=? AND status IN ('PENDING','PROCESSING') ORDER BY id DESC LIMIT 1`).bind(user.user_id,id).first();
  if(prior)return {ok:true,status:String(prior.status),paymentState:String(prior.payment_state||'UNDER_REVIEW'),requestId:Number(prior.id),duplicateSuppressed:true,totalAmount:Number(prior.total_amount||0),fundsHeld:Number(prior.funds_held||0),officialHeld:Number(prior.official_held||0)};
  if(String(mode||'').toUpperCase()!=='GOLD')return {error:'PREMIUM_GOLD_ONLY',message:'Premium products can be purchased with Diamond only.',http:409};
  const base=Math.max(0,Number(item.gold_price||0));if(base<=0)return {error:'GOLD_PRICE_NOT_AVAILABLE',http:409};const cfg=await financeConfig(env),vat=calcVat(base,cfg.vatPercent);
  const total=base+vat, fee=vat, src=await walletSourceState(env,user.user_id,'GOLD'), table=src.wallet;
  if(src.total<total)return {error:'INSUFFICIENT_GOLD_BALANCE',balance:src.total,baseAmount:base,vatPercent:cfg.vatPercent,vatAmount:vat,totalAmount:total,http:409};
  const officialHeld=Math.min(total,src.official);
  const rr=await env.DB.prepare(`INSERT INTO myshop_store_purchase_requests(user_id,catalog_id,payment_mode,base_amount,fee_amount,vat_percent,total_amount,payment_method,reference,status,funds_held,official_held,payment_state) VALUES(?,?,?,?,?,?,?,?,?,'PENDING',0,0,'RESERVING')`).bind(user.user_id,id,'GOLD',base,fee,cfg.vatPercent,total,'gold','').run();
  const requestId=Number(rr.meta?.last_row_id||0);let walletHeld=false,sourceHeld=false;
  try{
    const debit=await env.DB.prepare(`UPDATE ${table} SET balance=balance-?,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND balance>=?`).bind(total,user.user_id,total).run();
    if(Number(debit.meta?.changes||0)!==1)throw new Error('INSUFFICIENT_GOLD_BALANCE');walletHeld=true;
    if(officialHeld>0){await env.DB.prepare(`UPDATE myshop_wallet_sources SET official_balance=MAX(0,official_balance-?),updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND currency='GOLD'`).bind(officialHeld,user.user_id).run();sourceHeld=true;}
    await env.DB.prepare(`UPDATE myshop_store_purchase_requests SET funds_held=?,official_held=?,payment_state='FUNDS_HELD',updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(total,officialHeld,requestId).run();
    await env.DB.prepare(`INSERT INTO myshop_gold_transactions(user_id,kind,amount,reference,metadata) VALUES(?,'STORE_PURCHASE_HOLD',?,'PREMIUM_REQ_'||?,?)`).bind(user.user_id,-total,requestId,JSON.stringify({requestId,productId:id,base,vatPercent:cfg.vatPercent,vatAmount:vat,total,status:'PENDING',destination:'MY_SHOP_PREMIUM_REVENUE'})).run();
    // V-430: all Premium activation requires an explicit Admin decision.
    await logPremiumPurchaseEvent(env,user.user_id,id,'PAYMENT_SUBMITTED','GOLD','gold',requestId,total);
    await notifyPremiumAdmins(env,'New Premium Buy Request',`${user.user_id} • ${item.title} • ${total} Diamond held • Verify in Premium Purchase Center.`);
    try{await createUserNotification(env,user.user_id,'Premium Request Received',`${item.title}: ${total} Diamond is safely held until Admin verifies the purchase.`)}catch(_){}
    return {ok:true,status:'PENDING',paymentState:'FUNDS_HELD',requestId,productId:id,baseAmount:base,feeAmount:vat,vatPercent:cfg.vatPercent,vatAmount:vat,totalAmount:total,fundsHeld:total,officialHeld,message:'Diamond held safely. Admin approval activates the item; rejection releases the hold.'};
  }catch(e){
    if(walletHeld)await env.DB.prepare(`UPDATE ${table} SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(total,user.user_id).run().catch(()=>{});
    if(sourceHeld&&officialHeld>0)await env.DB.prepare(`INSERT INTO myshop_wallet_sources(user_id,currency,official_balance,updated_at) VALUES(?,'GOLD',?,CURRENT_TIMESTAMP) ON CONFLICT(user_id,currency) DO UPDATE SET official_balance=official_balance+excluded.official_balance,updated_at=CURRENT_TIMESTAMP`).bind(user.user_id,officialHeld).run().catch(()=>{});
    await env.DB.prepare(`UPDATE myshop_store_purchase_requests SET status='REJECTED',funds_held=0,official_held=0,payment_state='HOLD_FAILED',decision_note=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(String(e?.message||e).slice(0,120),requestId).run().catch(()=>{});
    return {error:String(e?.message||e).startsWith('INSUFFICIENT_')?String(e?.message||e):'PURCHASE_HOLD_FAILED',message:'Could not reserve Diamond safely. Any partial hold was released.',http:409};
  }
}
async function storeGiftPurchaseRequest(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
  const b=await body(request),id=Math.floor(Number(b.productId||0)),recipient=String(b.recipientUserId||'').trim();
  if(!id||!isFourDigit(recipient)||recipient===user.user_id)return json({error:'INVALID_GIFT_RECIPIENT'},400,cors);
  const target=await env.DB.prepare(`SELECT user_id,full_name,avatar_url FROM myshop_auth_users_v108 WHERE user_id=? AND active=1`).bind(recipient).first();
  if(!target)return json({error:'RECIPIENT_NOT_FOUND'},404,cors);
  if(await activePremiumOwned(env,recipient,id))return json({error:'RECIPIENT_ALREADY_OWNS',message:'This Premium item is already active for the selected user. Choose another item or use Renew/Extend.'},409,cors);
  const item=await env.DB.prepare('SELECT * FROM myshop_store_catalog WHERE id=? AND enabled=1').bind(id).first();if(!item)return json({error:'CATALOG_NOT_FOUND'},404,cors);
  const base=Math.max(0,Number(item.gold_price||0));if(base<=0)return json({error:'GOLD_PRICE_NOT_AVAILABLE'},409,cors);const cfg=await financeConfig(env),vat=calcVat(base,cfg.vatPercent),total=base+vat;
  if(['expectedBase','expectedVat','expectedTotal'].some(k=>Object.prototype.hasOwnProperty.call(b,k))){
    if(![b.expectedBase,b.expectedVat,b.expectedTotal].every(Number.isSafeInteger)||b.expectedBase!==base||b.expectedVat!==vat||b.expectedTotal!==total)return json({error:'GIFT_QUOTE_CHANGED',message:'Gift price or tax changed. Reload the catalog and confirm the new total.'},409,cors);
  }
  const prior=await env.DB.prepare(`SELECT id,status,funds_held FROM myshop_store_purchase_requests WHERE user_id=? AND catalog_id=? AND gift_recipient_id=? AND status IN ('PENDING','PROCESSING') ORDER BY id DESC LIMIT 1`).bind(user.user_id,id,recipient).first();
  if(prior)return json({ok:true,status:prior.status,requestId:Number(prior.id),duplicateSuppressed:true,fundsHeld:Number(prior.funds_held||0)},200,cors);
  const src=await walletSourceState(env,user.user_id,'GOLD');if(src.total<total)return json({error:'INSUFFICIENT_GOLD_BALANCE',balance:src.total,baseAmount:base,vatPercent:cfg.vatPercent,vatAmount:vat,totalAmount:total},409,cors);
  const officialHeld=Math.min(total,src.official);
  const rr=await env.DB.prepare(`INSERT INTO myshop_store_purchase_requests(user_id,catalog_id,payment_mode,base_amount,fee_amount,vat_percent,total_amount,payment_method,reference,status,funds_held,official_held,payment_state,gift_recipient_id,transaction_source) VALUES(?,?,?,?,?,?,?,?,?,'PENDING',0,0,'RESERVING',?,'GIFT_PURCHASE')`).bind(user.user_id,id,'GOLD',base,vat,cfg.vatPercent,total,'gold','',recipient).run();
  const requestId=Number(rr.meta?.last_row_id||0);let held=false,sourceHeld=false;
  try{
    const d=await env.DB.prepare(`UPDATE myshop_gold_wallets SET balance=balance-?,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND balance>=?`).bind(total,user.user_id,total).run();if(Number(d.meta?.changes||0)!==1)throw new Error('INSUFFICIENT_GOLD_BALANCE');held=true;
    if(officialHeld>0){await env.DB.prepare(`UPDATE myshop_wallet_sources SET official_balance=MAX(0,official_balance-?),updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND currency='GOLD'`).bind(officialHeld,user.user_id).run();sourceHeld=true;}
    await env.DB.prepare(`UPDATE myshop_store_purchase_requests SET funds_held=?,official_held=?,payment_state='FUNDS_HELD',updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(total,officialHeld,requestId).run();
    await env.DB.prepare(`INSERT INTO myshop_gold_transactions(user_id,kind,amount,reference,metadata) VALUES(?,'GIFT_PURCHASE_HOLD',?,'PREMIUM_REQ_'||?,?)`).bind(user.user_id,-total,requestId,JSON.stringify({requestId,productId:id,recipientUserId:recipient,source:'GIFT_PURCHASE',baseAmount:base,vatPercent:cfg.vatPercent,vatAmount:vat,total})).run();
    await notifyPremiumAdmins(env,'New Premium Gift Request',`${user.user_id} → ${recipient} • ${item.title} • ${total} Diamond held (${vat} VAT).`);
    try{await createUserNotification(env,user.user_id,'Gift Request Received',`${item.title}: ${total} Diamond is held until Admin approval.`)}catch(_){}
    return json({ok:true,status:'PENDING',requestId,productId:id,recipient:{userId:recipient,name:target.full_name||'MY SHOP User',avatarUrl:target.avatar_url||''},baseAmount:base,vatPercent:cfg.vatPercent,vatAmount:vat,totalAmount:total,fundsHeld:total,source:'GIFT_PURCHASE'},201,cors);
  }catch(e){if(held)await env.DB.prepare(`UPDATE myshop_gold_wallets SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(total,user.user_id).run().catch(()=>{});if(sourceHeld&&officialHeld>0)await env.DB.prepare(`UPDATE myshop_wallet_sources SET official_balance=official_balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND currency='GOLD'`).bind(officialHeld,user.user_id).run().catch(()=>{});await env.DB.prepare(`UPDATE myshop_store_purchase_requests SET status='REJECTED',funds_held=0,official_held=0,payment_state='HOLD_FAILED' WHERE id=?`).bind(requestId).run().catch(()=>{});return json({error:String(e?.message||e)},409,cors);}
}
async function liveTvChannels(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const rows=(await env.DB.prepare(`SELECT id,name,category,logo_url,stream_url,display_order FROM myshop_live_tv_channels WHERE active=1 AND published=1 ORDER BY display_order ASC,id ASC`).all()).results||[];
  return json({ok:true,channels:rows},200,cors);
}
async function adminLiveTvChannels(request,env){const auth=await adminOnly(request,env);if(auth.error)return auth.error;const rows=(await env.DB.prepare(`SELECT * FROM myshop_live_tv_channels ORDER BY display_order ASC,id ASC`).all()).results||[];return json({ok:true,channels:rows},200,cors);}
async function adminLiveTvSave(request,env){
  const auth=await adminOnly(request,env);if(auth.error)return auth.error;const b=await body(request),id=Math.floor(Number(b.id||0)),name=String(b.name||'').trim().slice(0,80),category=String(b.category||'General').trim().slice(0,40),logo=String(b.logoUrl||'').trim().slice(0,500),stream=String(b.streamUrl||'').trim().slice(0,1000),order=Math.max(0,Math.floor(Number(b.displayOrder||0))),active=b.active===false?0:1,published=b.published===true?1:0;
  if(!name||!/^https:\/\//i.test(stream))return json({error:'INVALID_CHANNEL',message:'Channel name and HTTPS stream/source are required.'},400,cors);
  if(id){const r=await env.DB.prepare(`UPDATE myshop_live_tv_channels SET name=?,category=?,logo_url=?,stream_url=?,display_order=?,active=?,published=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(name,category,logo,stream,order,active,published,id).run();if(Number(r.meta?.changes||0)!==1)return json({error:'CHANNEL_NOT_FOUND'},404,cors);}
  else{const r=await env.DB.prepare(`INSERT INTO myshop_live_tv_channels(name,category,logo_url,stream_url,display_order,active,published) VALUES(?,?,?,?,?,?,?)`).bind(name,category,logo,stream,order,active,published).run();}
  await env.DB.prepare(`INSERT INTO myshop_store_audit(admin_user_id,action,item_code,details) VALUES(?,'LIVE_TV_SAVE',?,?)`).bind(auth.user.user_id,name,JSON.stringify({id,name,category,order,active,published})).run();return json({ok:true},200,cors);
}
async function adminLiveTvDelete(request,env){const auth=await adminOnly(request,env);if(auth.error)return auth.error;const b=await body(request),id=Math.floor(Number(b.id||0));if(!id)return json({error:'INVALID_CHANNEL_ID'},400,cors);const old=await env.DB.prepare(`SELECT name FROM myshop_live_tv_channels WHERE id=?`).bind(id).first();if(!old)return json({error:'CHANNEL_NOT_FOUND'},404,cors);await env.DB.prepare(`DELETE FROM myshop_live_tv_channels WHERE id=?`).bind(id).run();await env.DB.prepare(`INSERT INTO myshop_store_audit(admin_user_id,action,item_code,details) VALUES(?,'LIVE_TV_DELETE',?,?)`).bind(auth.user.user_id,String(old.name||id),JSON.stringify({id})).run();return json({ok:true,deleted:true},200,cors);}

async function storeDirectPurchase(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),id=Math.floor(Number(b.productId||0)),mode=String(b.paymentMode||'').toUpperCase();if(!id||!['COIN','GOLD'].includes(mode))return json({error:'INVALID_PAYMENT_MODE'},400,cors);const out=await createStorePurchaseRequest(env,user,id,mode,mode.toLowerCase(),'');return json(out,out.error?(out.http||409):(out.duplicateSuppressed?200:201),cors);
}
async function storePurchaseRequest(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),id=Math.floor(Number(b.productId||0)),mode=String(b.paymentMode||'').toUpperCase(),method=String(b.paymentMethod||'').toLowerCase(),ref=String(b.reference||'').trim().slice(0,120);if(!id)return json({error:'INVALID_CATALOG_ID'},400,cors);const out=await createStorePurchaseRequest(env,user,id,mode,method,ref);return json(out,out.error?(out.http||409):(out.duplicateSuppressed?200:201),cors);
}
async function adminStorePurchaseRequests(request,env){
  const auth=await adminOnly(request,env);if(auth.error)return auth.error;
  const rows=(await env.DB.prepare(`SELECT r.*,u.full_name,u.avatar_url,c.code,c.title,c.item_type,c.preview_url,c.animation_url,c.duration_days FROM myshop_store_purchase_requests r LEFT JOIN myshop_auth_users_v108 u ON u.user_id=r.user_id LEFT JOIN myshop_store_catalog c ON c.id=r.catalog_id ORDER BY CASE r.status WHEN 'PENDING' THEN 0 WHEN 'PROCESSING' THEN 1 ELSE 2 END,r.id DESC LIMIT 250`).all()).results||[];
  const totals=await env.DB.prepare(`SELECT SUM(CASE WHEN status='PENDING' THEN 1 ELSE 0 END) pending_count,SUM(CASE WHEN status='PENDING' AND payment_mode='GOLD' AND funds_held>0 AND datetime(updated_at)<=datetime('now','-24 hours') THEN 1 ELSE 0 END) stuck_count,SUM(CASE WHEN status='COMPLETED' THEN 1 ELSE 0 END) completed_count,SUM(CASE WHEN status='REJECTED' THEN 1 ELSE 0 END) rejected_count,SUM(CASE WHEN status='COMPLETED' AND payment_mode='GOLD' THEN total_amount ELSE 0 END) gold_income,SUM(CASE WHEN status='COMPLETED' AND date(updated_at)=date('now') THEN 1 ELSE 0 END) approved_today,SUM(CASE WHEN status='REJECTED' AND date(updated_at)=date('now') THEN 1 ELSE 0 END) rejected_today FROM myshop_store_purchase_requests`).first();
  const funnel=await env.DB.prepare(`SELECT SUM(CASE WHEN event_type='BUY_STARTED' AND date(created_at)=date('now') THEN 1 ELSE 0 END) buy_started_today,SUM(CASE WHEN event_type='PAYMENT_SUBMITTED' AND date(created_at)=date('now') THEN 1 ELSE 0 END) payment_submitted_today,SUM(CASE WHEN event_type='APPROVED' AND date(created_at)=date('now') THEN 1 ELSE 0 END) approved_event_today FROM myshop_store_purchase_events`).first();
  const active=await env.DB.prepare(`SELECT COUNT(DISTINCT user_id) n FROM (SELECT user_id FROM myshop_owned_items WHERE expires_at IS NULL OR datetime(expires_at)>datetime('now') UNION ALL SELECT user_id FROM myshop_user_badges WHERE status='ACTIVE' AND (expires_at IS NULL OR datetime(expires_at)>datetime('now')) AND badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP'))`).first();
  const expiring=await env.DB.prepare(`SELECT COUNT(*) n FROM (SELECT id FROM myshop_owned_items WHERE expires_at IS NOT NULL AND datetime(expires_at)>datetime('now') AND datetime(expires_at)<=datetime('now','+7 days') UNION ALL SELECT id FROM myshop_user_badges WHERE status='ACTIVE' AND expires_at IS NOT NULL AND datetime(expires_at)>datetime('now') AND datetime(expires_at)<=datetime('now','+7 days') AND badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP'))`).first();
  const categoryIncome=(await env.DB.prepare(`SELECT COALESCE(c.item_type,'UNKNOWN') category,r.payment_mode,COUNT(*) sales,SUM(r.total_amount) amount FROM myshop_store_purchase_requests r LEFT JOIN myshop_store_catalog c ON c.id=r.catalog_id WHERE r.status='COMPLETED' GROUP BY COALESCE(c.item_type,'UNKNOWN'),r.payment_mode ORDER BY sales DESC`).all()).results||[];
  const tierSales=(await env.DB.prepare(`SELECT c.code,COUNT(*) sales,SUM(CASE WHEN r.payment_mode='COIN' THEN r.total_amount ELSE 0 END) coin,SUM(CASE WHEN r.payment_mode='GOLD' THEN r.total_amount ELSE 0 END) gold,SUM(CASE WHEN r.payment_mode='MONEY' THEN r.total_amount ELSE 0 END) cash_minor FROM myshop_store_purchase_requests r JOIN myshop_store_catalog c ON c.id=r.catalog_id WHERE r.status='COMPLETED' AND (c.code IN ('KING','QUEEN','ROYAL','VVIP','VIP') OR c.code IN ('MS430_KING','MS430_QUEEN','MS430_ROYAL','MS430_VVIP','MS430_VIP')) GROUP BY c.code ORDER BY sales DESC`).all()).results||[];
  return json({ok:true,requests:catalogClientRows(rows),summary:{pending:Number(totals?.pending_count||0),stuckHeld:Number(totals?.stuck_count||0),completed:Number(totals?.completed_count||0),rejected:Number(totals?.rejected_count||0),goldIncome:Number(totals?.gold_income||0),approvedToday:Number(totals?.approved_today||0),rejectedToday:Number(totals?.rejected_today||0),buyStartedToday:Number(funnel?.buy_started_today||0),paymentSubmittedToday:Number(funnel?.payment_submitted_today||0),activePremiumUsers:Number(active?.n||0),expiring7Days:Number(expiring?.n||0),categoryIncome,tierSales}},200,cors);
}
async function adminStorePurchaseDecision(request,env){
  const auth=await adminOnly(request,env);if(auth.error)return auth.error;const b=await body(request),id=Math.floor(Number(b.requestId||0)),action=String(b.action||'').toUpperCase(),note=String(b.note||'').trim().slice(0,180);if(!id||!['APPROVE','REJECT'].includes(action))return json({error:'INVALID_PURCHASE_DECISION'},400,cors);
  const r=await env.DB.prepare(`SELECT * FROM myshop_store_purchase_requests WHERE id=?`).bind(id).first();if(!r)return json({error:'REQUEST_NOT_FOUND'},404,cors);const recipientUid=String(r.gift_recipient_id||'').trim()||String(r.user_id||'');const txSource=String(r.transaction_source||'PURCHASE').toUpperCase();if(String(r.status)!=='PENDING')return json({error:'REQUEST_ALREADY_DECIDED',status:r.status},409,cors);const mode=String(r.payment_mode||'').toUpperCase(),uid=String(r.user_id||''),total=Math.max(0,Number(r.total_amount||0)),held=Math.max(0,Number(r.funds_held||0)),officialHeld=Math.max(0,Number(r.official_held||0));
  if(action==='REJECT'){
    const claim=await env.DB.prepare("UPDATE myshop_store_purchase_requests SET status='PROCESSING',approved_by=?,decision_note=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='PENDING'").bind(auth.user.user_id,note,id).run();if(Number(claim.meta?.changes||0)!==1)return json({error:'REQUEST_ALREADY_DECIDED'},409,cors);
    const writes=[];
    if((mode==='COIN'||mode==='GOLD')&&held>0){const table=mode==='COIN'?'myshop_coin_wallets':'myshop_gold_wallets';writes.push(env.DB.prepare(`UPDATE ${table} SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(held,uid));if(officialHeld>0)writes.push(env.DB.prepare(`INSERT INTO myshop_wallet_sources(user_id,currency,official_balance,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id,currency) DO UPDATE SET official_balance=official_balance+excluded.official_balance,updated_at=CURRENT_TIMESTAMP`).bind(uid,mode,officialHeld));if(mode==='COIN'){writes.push(env.DB.prepare("UPDATE myshop_coin_transactions SET status='REJECTED' WHERE user_id=? AND reference=? AND status='PENDING'").bind(uid,'PREMIUM_REQ_'+id));writes.push(env.DB.prepare("INSERT INTO myshop_coin_transactions(user_id,kind,amount,reference,status,metadata) VALUES(?,'STORE_PURCHASE_HOLD_RELEASE',?,'PREMIUM_REQ_'||?,'COMPLETED',?)").bind(uid,held,id,JSON.stringify({requestId:id,rejectedBy:auth.user.user_id})));}else writes.push(env.DB.prepare("INSERT INTO myshop_gold_transactions(user_id,kind,amount,reference,metadata) VALUES(?,'STORE_PURCHASE_HOLD_RELEASE',?,'PREMIUM_REQ_'||?,?)").bind(uid,held,id,JSON.stringify({requestId:id,rejectedBy:auth.user.user_id})));}
    writes.push(env.DB.prepare("UPDATE myshop_store_purchase_requests SET status='REJECTED',funds_held=0,official_held=0,payment_state='REJECTED',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='PROCESSING'").bind(id));
    try{await env.DB.batch(writes);}catch(e){await env.DB.prepare("UPDATE myshop_store_purchase_requests SET status='PENDING' WHERE id=? AND status='PROCESSING'").bind(id).run();throw e;}
    await logPremiumPurchaseEvent(env,uid,Number(r.catalog_id),'REJECTED',mode,String(r.payment_method||''),id,total);try{await createUserNotification(env,uid,'Premium Purchase Rejected',held>0?'Your held balance was returned. Open My Premium Collection for status.':'Payment was not approved. No Premium item was activated.')}catch(_){}return json({ok:true,status:'REJECTED',requestId:id,refunded:held},200,cors);
  }
  const lock=await env.DB.prepare(`UPDATE myshop_store_purchase_requests SET status='PROCESSING',approved_by=?,decision_note=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='PENDING'`).bind(auth.user.user_id,note,id).run();if(Number(lock.meta?.changes||0)!==1)return json({error:'REQUEST_ALREADY_DECIDED'},409,cors);
  let legacyDebited=0,legacyOfficialDebited=0;const approvalWrites=[];
  try{
    const item=await env.DB.prepare(`SELECT * FROM myshop_store_catalog WHERE id=?`).bind(Number(r.catalog_id)).first();if(!item)throw new Error('CATALOG_NOT_FOUND');
    if(mode==='GOLD'){
      if(held<total){const src=await walletSourceState(env,uid,mode),table=src.wallet;if(src.total<total)throw new Error('INSUFFICIENT_'+mode+'_BALANCE');const d=await env.DB.prepare(`UPDATE ${table} SET balance=balance-?,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND balance>=?`).bind(total,uid,total).run();if(Number(d.meta?.changes||0)!==1)throw new Error('INSUFFICIENT_'+mode+'_BALANCE');legacyDebited=total;legacyOfficialDebited=Math.min(total,src.official);if(legacyOfficialDebited>0)await env.DB.prepare(`UPDATE myshop_wallet_sources SET official_balance=MAX(0,official_balance-?),updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND currency=?`).bind(legacyOfficialDebited,uid,mode).run();}
      const base=Math.max(0,Number(r.base_amount||0)),fee=0;if(held<total)approvalWrites.push(env.DB.prepare(`INSERT INTO myshop_gold_transactions(user_id,kind,amount,reference,metadata) VALUES(?,'STORE_PURCHASE_APPROVED',?,'PREMIUM_REQ_'||?,?)`).bind(uid,-total,id,JSON.stringify({requestId:id,productId:item.id,base,total,approvedBy:auth.user.user_id,legacy:true})));
      approvalWrites.push(env.DB.prepare(`INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,gross_amount,fee_percent,fee_amount,vat_percent,vat_amount,net_amount,platform_amount,status,reference,metadata) VALUES('PREMIUM_REVENUE','GOLD',?,'MY_SHOP_PREMIUM_REVENUE',?,0,0,?,?, ?,?,'COMPLETED',?,?)`).bind(uid,total,Number(r.vat_percent||0),Number(r.fee_amount||0),total,total,'PREMIUM_REQ_'+id,JSON.stringify({requestId:id,productId:item.id,code:item.code,approvedBy:auth.user.user_id,source:txSource,recipientUserId:recipientUid,vatPercent:Number(r.vat_percent||0),vatAmount:Number(r.fee_amount||0)})));
    }else throw new Error('LEGACY_PAYMENT_REQUIRES_REJECT');
    const plan=await premiumGrantPlan(env,recipientUid,item,txSource==='GIFT_PURCHASE'?'GIFT_PURCHASE':'ADMIN_APPROVED_PURCHASE','Request #'+id);
    approvalWrites.push(...plan.writes,env.DB.prepare(`UPDATE myshop_store_purchase_requests SET status='COMPLETED',approved_by=?,funds_held=0,official_held=0,payment_state='APPROVED',approved_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='PROCESSING'`).bind(auth.user.user_id,id));
    await env.DB.batch(approvalWrites);await logPremiumPurchaseEvent(env,uid,Number(r.catalog_id),'APPROVED',mode,String(r.payment_method||''),id,total);try{await createUserNotification(env,recipientUid,txSource==='GIFT_PURCHASE'?'Premium Gift Received':'Premium Purchase Approved',`${item.title} is now active in My Items.`);if(txSource==='GIFT_PURCHASE'&&recipientUid!==uid)await createUserNotification(env,uid,'Premium Gift Approved',`${item.title} was activated for user ${recipientUid}.`)}catch(_){}return json({ok:true,status:'COMPLETED',requestId:id,userId:uid,recipientUserId:recipientUid,source:txSource,productId:item.id},200,cors);
  }catch(e){if(legacyDebited>0){const table=mode==='COIN'?'myshop_coin_wallets':'myshop_gold_wallets';await env.DB.prepare(`UPDATE ${table} SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(legacyDebited,uid).run().catch(()=>{});if(legacyOfficialDebited>0)await env.DB.prepare(`INSERT INTO myshop_wallet_sources(user_id,currency,official_balance,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id,currency) DO UPDATE SET official_balance=official_balance+excluded.official_balance,updated_at=CURRENT_TIMESTAMP`).bind(uid,mode,legacyOfficialDebited).run().catch(()=>{});}await env.DB.prepare(`UPDATE myshop_store_purchase_requests SET status='PENDING',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='PROCESSING'`).bind(id).run();const m=String(e?.message||e);return json({error:m.startsWith('INSUFFICIENT_')||m==='LEGACY_PAYMENT_REQUIRES_REJECT'||m==='PREMIUM_GOLD_ONLY'?m:'PURCHASE_APPROVAL_FAILED',message:m},409,cors);}
}
async function adminStoreGrant(request,env){
  const auth=await adminOnly(request,env);if(auth.error)return auth.error;const b=await body(request),uid=String(b.userId||'').trim(),id=Math.floor(Number(b.productId||0)),note=String(b.note||'').trim().slice(0,180);if(!isFourDigit(uid)||!id)return json({error:'INVALID_GRANT'},400,cors);const target=await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(uid).first();if(!target)return json({error:'USER_NOT_FOUND'},404,cors);const item=await env.DB.prepare('SELECT * FROM myshop_store_catalog WHERE id=?').bind(id).first();if(!item)return json({error:'CATALOG_NOT_FOUND'},404,cors);if(Number(item.enabled)!==1)return json({error:'CATALOG_NOT_PUBLISHED'},409,cors);if(membershipTier(item.code)&&b.durationDays!==undefined){const days=Number(b.durationDays);if(!Number.isInteger(days)||days<1||days>3650)return json({error:'INVALID_DURATION'},400,cors);item.duration_days=days;}await grantCatalogItem(env,uid,item,'ADMIN_GRANT',note);await env.DB.prepare('INSERT INTO myshop_admin_wallet_grants(admin_user_id,target_user_id,item_type,item_code,units,days,note) VALUES(?,?,?,?,?,?,?)').bind(auth.user.user_id,uid,item.item_type,item.code,item.units,item.duration_days,note).run();try{await createUserNotification(env,uid,'MY SHOP Premium',`${item.title} has been activated on your profile.`)}catch(_){}return json({ok:true,userId:uid,productId:id,code:item.code},200,cors);
}
/** Remove a verified user's entitlement only; catalog, other users and wallet stay unchanged. */
async function adminStoreRevoke(request,env){
  const auth=await adminOnly(request,env);if(auth.error)return auth.error;
  const b=await body(request),uid=String(b.userId||'').trim(),id=Number(b.entitlementId),kind=String(b.entitlementKind||'');
  if(!isFourDigit(uid)||!Number.isSafeInteger(id)||id<1||!['OWNED','BADGE'].includes(kind))return json({error:'INVALID_ENTITLEMENT'},400,cors);
  const target=await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(uid).first();if(!target)return json({error:'USER_NOT_FOUND'},404,cors);
  const table=kind==='OWNED'?'myshop_owned_items':'myshop_user_badges';
  const item=await env.DB.prepare(`SELECT * FROM ${table} WHERE id=? AND user_id=?`).bind(id,uid).first();if(!item)return json({error:'ENTITLEMENT_NOT_FOUND'},404,cors);
  if(kind==='BADGE'&&item.status!=='ACTIVE')return json({error:'ENTITLEMENT_NOT_ACTIVE'},409,cors);
  const writes=[];
  if(kind==='OWNED')writes.push(env.DB.prepare('DELETE FROM myshop_owned_items WHERE id=? AND user_id=?').bind(id,uid));
  else{
    writes.push(env.DB.prepare(`UPDATE myshop_user_badges SET status='REVOKED',is_displayed=0 WHERE id=? AND user_id=?`).bind(id,uid));
    if(membershipTier(item.badge_code)){
      await ensureLiveRoomSchema(env);
      writes.push(env.DB.prepare(`UPDATE myshop_live_comment_assignments SET enabled=0,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND source='MEMBERSHIP' AND NOT EXISTS (SELECT 1 FROM myshop_user_badges WHERE user_id=? AND status='ACTIVE' AND badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP') AND (expires_at IS NULL OR datetime(expires_at)>datetime('now')))` ).bind(uid,uid));
    }
  }
  writes.push(env.DB.prepare(`INSERT INTO myshop_store_audit(admin_user_id,action,catalog_id,item_code,details) VALUES(?,'REVOKE_USER_ITEM',?,?,?)`).bind(auth.user.user_id,item.catalog_id||null,item.item_code||item.badge_code||'',JSON.stringify({userId:uid,entitlementId:id,kind,note:String(b.note||'').slice(0,180)})));
  await env.DB.batch(writes);return json({ok:true,userId:uid,entitlementId:id},200,cors);
}
async function adminStoreReconcileHolds(request,env){
  const auth=await adminOnly(request,env);if(auth.error)return auth.error;
  // Never auto-spend or auto-refund: identify stale held Gold so Admin can verify and decide safely.
  const stale=(await env.DB.prepare(`SELECT r.id,r.user_id,r.catalog_id,r.total_amount,r.funds_held,r.payment_state,r.created_at,c.title FROM myshop_store_purchase_requests r LEFT JOIN myshop_store_catalog c ON c.id=r.catalog_id WHERE r.status='PENDING' AND r.payment_mode='GOLD' AND r.funds_held>0 AND datetime(r.updated_at)<=datetime('now','-24 hours') ORDER BY r.updated_at ASC LIMIT 100`).all()).results||[];
  for(const x of stale){if(String(x.payment_state||'')!=='STUCK_REVIEW')await env.DB.prepare(`UPDATE myshop_store_purchase_requests SET payment_state='STUCK_REVIEW',decision_note=CASE WHEN decision_note='' THEN 'Auto-flagged: held Gold pending >24h' ELSE decision_note END,updated_at=updated_at WHERE id=? AND status='PENDING'`).bind(x.id).run();}
  await env.DB.prepare(`INSERT INTO myshop_store_audit(admin_user_id,action,item_code,details) VALUES(?,'RECONCILE_HELD_GOLD','PREMIUM',?)`).bind(auth.user.user_id,JSON.stringify({flagged:stale.length})).run();
  return json({ok:true,flagged:stale.length,stale},200,cors);
}
async function setActiveBadge(request,env){
 const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);const b=await body(request),badgeId=Math.floor(Number(b.badgeId||0));
 const row=await env.DB.prepare("SELECT id,badge_code,catalog_id FROM myshop_user_badges WHERE id=? AND user_id=? AND status='ACTIVE' AND (expires_at IS NULL OR datetime(expires_at)>datetime('now'))").bind(badgeId,user.user_id).first();if(!row)return json({error:'BADGE_NOT_AVAILABLE'},404,cors);
 const writes=[env.DB.prepare('UPDATE myshop_user_badges SET is_displayed=0 WHERE user_id=?').bind(user.user_id),env.DB.prepare('UPDATE myshop_user_badges SET is_displayed=1 WHERE id=?').bind(badgeId)];
 const tier=membershipTier(row.badge_code);if(tier){await ensureLiveRoomSchema(env);const key='V430-'+tier;await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_comment_presets(preset_key,badge,gender,preset_no,style_json) VALUES(?,?,'UNSPECIFIED',1,?)`).bind(key,tier,JSON.stringify(membershipStyle(tier))).run();writes.push(env.DB.prepare(`INSERT INTO myshop_live_comment_assignments(user_id,preset_key,custom_style_json,is_custom,enabled,source,updated_at) VALUES(?,?,'{}',0,1,'MEMBERSHIP',CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET preset_key=excluded.preset_key,custom_style_json='{}',is_custom=0,enabled=1,source='MEMBERSHIP',updated_at=CURRENT_TIMESTAMP`).bind(user.user_id,key));}
 await env.DB.batch(writes);return json({ok:true,badgeId},200,cors);
}

async function walletProfile(request,env){
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  await env.DB.prepare('INSERT OR IGNORE INTO myshop_gold_wallets(user_id,balance) VALUES(?,0)').bind(user.user_id).run();
  const g=await env.DB.prepare('SELECT balance FROM myshop_gold_wallets WHERE user_id=?').bind(user.user_id).first();
  const badges=(await env.DB.prepare("SELECT b.id,b.badge_code,b.status,b.starts_at,b.expires_at,b.source,b.note,b.is_displayed,b.catalog_id,c.title,c.preview_url,c.animation_url,c.animation_mime,c.benefits,c.duration_days FROM myshop_user_badges b LEFT JOIN myshop_store_catalog c ON c.id=b.catalog_id WHERE b.user_id=? AND b.status='ACTIVE' AND (b.expires_at IS NULL OR datetime(b.expires_at)>datetime('now')) ORDER BY b.is_displayed DESC,CASE b.badge_code WHEN 'ROYAL' THEN 1 WHEN 'VVIP' THEN 2 WHEN 'VIP' THEN 3 WHEN 'BLUE' THEN 4 ELSE 9 END,b.id DESC").bind(user.user_id).all()).results||[];
  const withdrawals=(await env.DB.prepare('SELECT id,gold_amount,payment_method,account,status,created_at FROM myshop_withdraw_requests WHERE user_id=? ORDER BY id DESC LIMIT 30').bind(user.user_id).all()).results||[];
  const levelInfo=await coinLevelFor(env,user.user_id);
  return json({ok:true,goldBalance:Number(g?.balance||0),badges,withdrawals,level:levelInfo.level,totalPurchasedCoins:levelInfo.totalPurchasedCoins,nextLevelAt:levelInfo.nextLevelAt,levelProgress:levelInfo.progress},200,cors);
}

async function walletPurchaseRequest(request,env){
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  return json({error:'DIRECT_DIGITAL_PAYMENT_DISABLED',message:'Use Google Play Billing for Coin, Gold, Badge and Membership purchases.'},409,cors);
}

async function creatorEarningsWithdraw(request,env,currency){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  await ensureContentSchema(env);const b=await body(request);
  const gross=Number(currency==='GOLD'?b.gold:b.coin),method=String(b.paymentMethod||'').trim().toLowerCase(),account=String(b.account||'').trim(),note=String(b.note||'').trim();
  if(!Number.isSafeInteger(gross)||gross<=0||!account||account.length>80||note.length>180)return json({error:'INVALID_WITHDRAW_REQUEST'},400,cors);
  await ensureRequestNotices(env.DB);await env.DB.batch(payoutActionSchema.map(s=>env.DB.prepare(s)));
  await ensureWithdrawWalletHold(env.DB);
  const catalog=await readCatalog(env.DB,currency),cfg=await financeConfig(env,'WITHDRAW');
  // A submitted operation remains retrievable when a package is later disabled or repriced.
  await env.DB.prepare(withdrawalOperationSchema).run();
  const existing=b.requestKey?await env.DB.prepare(`SELECT r.* FROM myshop_withdraw_operations o JOIN myshop_creator_withdraw_requests r ON r.id=o.request_id WHERE o.user_id=? AND o.request_key=?`).bind(user.user_id,String(b.requestKey)).first():null;
  let terms=termsFor(catalog,cfg,gross);
  if(existing)terms={grossAmount:existing.gross_units,serviceFeePercent:existing.service_fee_percent,serviceFeeAmount:existing.service_fee_units,netAmount:existing.net_units,cashMinor:existing.cash_minor};
  if(!existing&&(terms.error||!catalog.methods.includes(method)))return json({error:terms.error||'INVALID_PAYMENT_METHOD'},409,cors);
  if(!existing&&terms.feeMode==='ADDITIONAL'&&(!b.confirmedQuote||b.confirmedQuote.totalDeducted!==terms.totalDeducted||b.confirmedQuote.feeMode!=='ADDITIONAL'))return json({error:'WITHDRAW_TERMS_CHANGED',message:'Reload and confirm the total including additional commission.'},409,cors);
  if(!existing&&b.confirmedQuote){for(const key of ['currency','catalogRevision','grossAmount','serviceFeePercent','serviceFeeAmount','netAmount','cashMinor','processingDays','unitsPer600Taka'])if(b.confirmedQuote[key]!==terms[key])return json({error:'WITHDRAW_TERMS_CHANGED',message:'Please reload and confirm the current withdrawal terms.'},409,cors);}
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_creator_earnings(user_id,currency,balance) VALUES(?,?,0)`).bind(user.user_id,currency).run();
  const deadline=terms.processingDays?new Date(Date.now()+terms.processingDays*86400000).toISOString():null;
  let result;try{result=await createWithdrawal(env.DB,{uid:user.user_id,currency,requestedAmount:gross,gross:existing?Number(existing.gross_units):(terms.totalDeducted??gross),rate:terms.serviceFeePercent,fee:terms.serviceFeeAmount,net:terms.netAmount,cashMinor:terms.cashMinor,method,account,note,requestKey:b.requestKey==null?'':String(b.requestKey),termsSnapshot:existing?null:{...terms,processingDeadline:deadline}});}
  catch(e){if(/INSUFFICIENT_CREATOR_EARNINGS|INSUFFICIENT_WITHDRAWABLE_WALLET/.test(String(e?.message||e)))return json({error:'INSUFFICIENT_CREATOR_EARNINGS',message:'Only eligible Creator Earnings can be withdrawn.'},409,cors);throw e;}
  if(result.error)return json({error:result.error},result.statusCode,cors);
  const r=result.row;const currentWallet=await env.DB.prepare(`SELECT balance FROM ${currency==='GOLD'?'myshop_gold_wallets':'myshop_coin_wallets'} WHERE user_id=?`).bind(user.user_id).first();return json({ok:true,walletBalance:Number(currentWallet?.balance||0),requestId:r.id,status:r.status,currency:r.currency,grossAmount:r.gross_units,serviceFeePercent:r.service_fee_percent,serviceFeeAmount:r.service_fee_units,netAmount:r.net_units,cashMinor:r.cash_minor,alreadyApplied:!!result.alreadyApplied},result.alreadyApplied?200:201,cors);
}
async function goldWithdrawRequest(request,env){ return creatorEarningsWithdraw(request,env,'GOLD'); }
async function coinWithdrawRequest(request,env){ return creatorEarningsWithdraw(request,env,'COIN'); }

async function syncExpiredPremium(env,uid){
  try{await env.DB.prepare(`UPDATE myshop_owned_items SET equipped=0 WHERE user_id=? AND equipped=1 AND expires_at IS NOT NULL AND datetime(expires_at)<=datetime('now')`).bind(uid).run();await env.DB.prepare(`UPDATE myshop_user_badges SET status='EXPIRED',is_displayed=0 WHERE user_id=? AND status='ACTIVE' AND expires_at IS NOT NULL AND datetime(expires_at)<=datetime('now')`).bind(uid).run();const active=await env.DB.prepare(`SELECT id FROM myshop_user_badges WHERE user_id=? AND status='ACTIVE' AND badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP') AND (expires_at IS NULL OR datetime(expires_at)>datetime('now')) LIMIT 1`).bind(uid).first();if(!active)await env.DB.prepare(`UPDATE myshop_live_comment_assignments SET enabled=0,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND source='MEMBERSHIP'`).bind(uid).run();}catch(e){console.error('PREMIUM_EXPIRY_SYNC_FAILED',uid,String(e?.message||e));}
}
async function myOwnedItems(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);await ensureContentSchema(env);await syncExpiredPremium(env,user.user_id);
  const rows=(await env.DB.prepare(`SELECT o.id,o.catalog_id,o.item_type,o.item_code,o.equipped,o.expires_at,o.source,o.created_at,c.title,c.preview_url,c.animation_url,c.animation_mime,c.benefits,c.duration_days,CASE WHEN o.expires_at IS NOT NULL AND datetime(o.expires_at)<=datetime('now') THEN 1 ELSE 0 END AS expired FROM myshop_owned_items o LEFT JOIN myshop_store_catalog c ON c.id=o.catalog_id WHERE o.user_id=? ORDER BY expired ASC,o.item_type,o.equipped DESC,o.id DESC`).bind(user.user_id).all()).results||[];
  const memberships=(await env.DB.prepare(`SELECT b.id,b.catalog_id,b.badge_code,b.status,b.source,b.expires_at,b.created_at,c.title,c.preview_url,c.animation_url,c.animation_mime,c.benefits,c.duration_days,CASE WHEN b.status<>'ACTIVE' OR (b.expires_at IS NOT NULL AND datetime(b.expires_at)<=datetime('now')) THEN 1 ELSE 0 END AS expired FROM myshop_user_badges b LEFT JOIN myshop_store_catalog c ON c.id=b.catalog_id WHERE b.user_id=? AND b.badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP') ORDER BY expired ASC,b.id DESC`).bind(user.user_id).all()).results||[];
  const requests=(await env.DB.prepare(`SELECT r.id,r.catalog_id,r.payment_mode,r.payment_method,r.base_amount,r.fee_amount,r.total_amount,r.reference,r.status,r.funds_held,r.payment_state,r.decision_note,r.created_at,r.updated_at,r.approved_at,c.code,c.title,c.item_type,c.preview_url,c.animation_url,c.duration_days FROM myshop_store_purchase_requests r LEFT JOIN myshop_store_catalog c ON c.id=r.catalog_id WHERE r.user_id=? ORDER BY r.id DESC LIMIT 40`).bind(user.user_id).all()).results||[];
  return json({ok:true,items:rows,memberships,purchaseRequests:requests},200,cors);
}
async function equipOwnedItem(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);await ensureContentSchema(env);const b=await body(request),id=Number(b.id||0);const row=await env.DB.prepare(`SELECT id,item_type FROM myshop_owned_items WHERE id=? AND user_id=? AND (expires_at IS NULL OR datetime(expires_at)>datetime('now'))`).bind(id,user.user_id).first();if(!row)return json({error:'ITEM_NOT_OWNED'},404,cors);const type=String(row.item_type||'');const group=premiumEquipGroup(type);await env.DB.batch([env.DB.prepare(`UPDATE myshop_owned_items SET equipped=0 WHERE user_id=? AND item_type IN (${group.map(()=>'?').join(',')})`).bind(user.user_id,...group),env.DB.prepare(`UPDATE myshop_owned_items SET equipped=1 WHERE id=? AND user_id=?`).bind(id,user.user_id)]);return json({ok:true,id,itemType:type},200,cors);
}

async function adminWalletPreview(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error;
  const uid=String(new URL(request.url).searchParams.get('userId')||'').trim(); if(!isFourDigit(uid))return json({error:'INVALID_USER_ID'},400,cors);
  const u=await env.DB.prepare(`SELECT user_id,full_name,avatar_url,active FROM myshop_auth_users_v108 WHERE user_id=?`).bind(uid).first(); if(!u)return json({error:'USER_NOT_FOUND'},404,cors);
  const cw=await env.DB.prepare(`SELECT balance FROM myshop_coin_wallets WHERE user_id=?`).bind(uid).first();
  const gw=await env.DB.prepare(`SELECT balance FROM myshop_gold_wallets WHERE user_id=?`).bind(uid).first();
  const levelInfo=await coinLevelFor(env,uid);
  const membership=await env.DB.prepare(`SELECT badge_code,expires_at FROM myshop_user_badges WHERE user_id=? AND status='ACTIVE' AND (expires_at IS NULL OR datetime(expires_at)>datetime('now')) ORDER BY is_displayed DESC,id DESC LIMIT 1`).bind(uid).first();
  const premiumItems=(await env.DB.prepare(`SELECT o.id,o.catalog_id,'OWNED' entitlement_kind,o.item_type,o.item_code,o.equipped,o.expires_at,c.title FROM myshop_owned_items o LEFT JOIN myshop_store_catalog c ON c.id=o.catalog_id WHERE o.user_id=? AND (o.expires_at IS NULL OR datetime(o.expires_at)>datetime('now')) ORDER BY o.equipped DESC,o.id DESC`).bind(uid).all()).results||[];
  const badges=(await env.DB.prepare(`SELECT b.id,b.catalog_id,'BADGE' entitlement_kind,COALESCE(c.item_type,'BADGE') item_type,b.badge_code item_code,b.is_displayed equipped,b.expires_at,COALESCE(c.title,b.badge_code) title FROM myshop_user_badges b LEFT JOIN myshop_store_catalog c ON c.id=b.catalog_id WHERE b.user_id=? AND b.status='ACTIVE' AND (b.expires_at IS NULL OR datetime(b.expires_at)>datetime('now')) ORDER BY b.id DESC`).bind(uid).all()).results||[];
  premiumItems.push(...badges);
  return json({ok:true,user:{userId:u.user_id,name:u.full_name||'MY SHOP User',avatarUrl:u.avatar_url||''},coinBalance:Number(cw?.balance||0),goldBalance:Number(gw?.balance||0),stars:Number(levelInfo.stars||0),level:Number(levelInfo.level||0),membership:membership||null,activePremiumItems:premiumItems},200,cors);
}

async function adminWalletGrant(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; const b=await body(request); const uid=String(b.userId||'').trim(),type=String(b.itemType||'').trim().toUpperCase(),code=String(b.itemCode||'').trim().toUpperCase(); const units=Math.floor(Number(b.units||1)),days=Math.max(0,Math.floor(Number(b.days||0))),note=String(b.note||'').trim().slice(0,180);
  if(!isFourDigit(uid)||!['COIN','GOLD','BADGE'].includes(type)||units<=0)return json({error:'INVALID_GRANT'},400,cors); const target=await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(uid).first(); if(!target)return json({error:'USER_NOT_FOUND'},404,cors);
  if(type==='COIN'||type==='GOLD')await reconcileLevelProgress(env,uid);
  if(type==='COIN'){ await env.DB.prepare('INSERT OR IGNORE INTO myshop_coin_wallets(user_id,balance) VALUES(?,0)').bind(uid).run(); await env.DB.prepare('UPDATE myshop_coin_wallets SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(units,uid).run(); await env.DB.prepare("INSERT INTO myshop_coin_transactions(user_id,kind,amount,reference,status,metadata) VALUES(?,'ADMIN_GRANT',?,'ADMIN','COMPLETED',?)").bind(uid,units,JSON.stringify({admin:auth.user.user_id,note})).run(); }
  else if(type==='GOLD'){ await env.DB.prepare('INSERT OR IGNORE INTO myshop_gold_wallets(user_id,balance) VALUES(?,0)').bind(uid).run(); await env.DB.prepare('UPDATE myshop_gold_wallets SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(units,uid).run(); await env.DB.prepare("INSERT INTO myshop_gold_transactions(user_id,kind,amount,reference,metadata) VALUES(?,'ADMIN_GRANT',?,'ADMIN',?)").bind(uid,units,JSON.stringify({admin:auth.user.user_id,note})).run(); }
  else { if(!code)return json({error:'INVALID_BADGE'},400,cors); const exp=days>0?new Date(Date.now()+days*86400000).toISOString():null; await env.DB.prepare("UPDATE myshop_user_badges SET is_displayed=0 WHERE user_id=?").bind(uid).run(); await env.DB.prepare("INSERT INTO myshop_user_badges(user_id,badge_code,status,source,expires_at,note,is_displayed) VALUES(?,?,'ACTIVE','ADMIN',?,?,1)").bind(uid,code,exp,note).run(); }
  await env.DB.prepare('INSERT INTO myshop_admin_wallet_grants(admin_user_id,target_user_id,item_type,item_code,units,days,note) VALUES(?,?,?,?,?,?,?)').bind(auth.user.user_id,uid,type,code,units,days,note).run();
  let progress={stars:0,levelAdded:0};
  if(type==='COIN'||type==='GOLD'){await creditOfficialWalletSource(env,uid,type,units);await env.DB.prepare(`INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,gross_amount,fee_percent,fee_amount,net_amount,platform_amount,reference,metadata) VALUES('ADMIN_GRANT',?,?,?, ?,0,0,?,0,'OFFICIAL_ADMIN_GRANT',?)`).bind(type,auth.user.user_id,uid,units,units,JSON.stringify({note})).run();progress=await applyStarsAndLevels(env,{txType:'ADMIN_GRANT',currency:type,senderId:auth.user.user_id,receiverId:uid,units,official:true,reference:'OFFICIAL_ADMIN_GRANT'});}
  try{await createUserNotification(env,uid,'MY SHOP Wallet Update',type==='BADGE'?`${code} badge/membership added to your profile.`:`${units} ${type==='COIN'?'Coin':'Diamond'} added by Admin.`);}catch(_){}
  const cw=await env.DB.prepare(`SELECT balance FROM myshop_coin_wallets WHERE user_id=?`).bind(uid).first(); const gw=await env.DB.prepare(`SELECT balance FROM myshop_gold_wallets WHERE user_id=?`).bind(uid).first(); const levelInfo=await coinLevelFor(env,uid);
  return json({ok:true,reference:'OFFICIAL_ADMIN_GRANT',userId:uid,itemType:type,itemCode:code,units,days,serviceFeePercent:0,starsAdded:Number(progress.stars||0),levelsAdded:Number(progress.levelAdded||0),coinBalance:Number(cw?.balance||0),goldBalance:Number(gw?.balance||0),stars:Number(levelInfo.stars||0),level:Number(levelInfo.level||0)},200,cors);
}


async function publicUserProfile(request,env){
  await ensureFriendSchema(env);await ensureLevelSchema(env);
  await ensureUserSocialLinksSchema(env);await ensurePersonalDetailsSchema(env);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_app_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();try{await env.DB.prepare(`ALTER TABLE myshop_app_presence ADD COLUMN visible INTEGER NOT NULL DEFAULT 1`).run();}catch(_){}await env.DB.prepare(`UPDATE myshop_app_presence SET active=0 WHERE active=1 AND datetime(last_seen)<datetime('now','-30 seconds')`).run();
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const peer=String(new URL(request.url).searchParams.get('userId')||'').trim(); if(!isFourDigit(peer))return json({error:'INVALID_USER_ID'},400,cors);
  const p=await env.DB.prepare('SELECT user_id,full_name,avatar_url,cover_url,bio,gender,created_at FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(peer).first(); if(!p)return json({error:'USER_NOT_FOUND'},404,cors);
  if(peer!==user.user_id && await safetyIsBlocked(env,user.user_id,peer))return json({error:'BLOCKED_USER'},403,cors);
  const publicPreview=peer===user.user_id&&new URL(request.url).searchParams.get('viewAs')==='public';
  let state=peer===user.user_id&&!publicPreview?'SELF':'NONE';
  if(state!=='SELF'&&!publicPreview){
    const f=await env.DB.prepare(`SELECT sender_id,receiver_id,status FROM myshop_friend_requests WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) LIMIT 1`).bind(user.user_id,peer,peer,user.user_id).first();
    if(f){ if(f.status==='ACCEPTED')state='FRIEND'; else if(f.status==='PENDING')state=f.sender_id===user.user_id?'REQUESTED':'INCOMING'; }
  }
  const follow=peer===user.user_id?false:!!(await env.DB.prepare('SELECT 1 ok FROM myshop_follows WHERE follower_id=? AND following_id=?').bind(user.user_id,peer).first());
  const badges=(await env.DB.prepare("SELECT b.id,b.badge_code,b.expires_at,b.is_displayed,c.title,c.preview_url,c.animation_url,c.animation_mime FROM myshop_user_badges b LEFT JOIN myshop_store_catalog c ON c.id=b.catalog_id WHERE b.user_id=? AND b.status='ACTIVE' AND (b.expires_at IS NULL OR datetime(b.expires_at)>datetime('now')) ORDER BY b.is_displayed DESC,CASE b.badge_code WHEN 'ROYAL' THEN 1 WHEN 'VVIP' THEN 2 WHEN 'VIP' THEN 3 WHEN 'BLUE' THEN 4 ELSE 9 END,b.id DESC LIMIT 4").bind(peer).all()).results||[];
  const levelInfo=await coinLevelFor(env,peer);
  const presence=await env.DB.prepare(`SELECT active,COALESCE(visible,1) visible,last_seen FROM myshop_app_presence WHERE user_id=?`).bind(peer).first();const activeStatusVisible=Number(presence?.visible??1)===1;const online=activeStatusVisible&&Number(presence?.active||0)===1&&!!(await env.DB.prepare(`SELECT datetime(?)>=datetime('now','-30 seconds') fresh`).bind(presence?.last_seen||'').first())?.fresh;
  const socialLinks=(await env.DB.prepare(`SELECT platform,url FROM myshop_user_social_links WHERE user_id=? ORDER BY CASE platform WHEN 'Facebook' THEN 1 WHEN 'Page' THEN 2 WHEN 'Messenger' THEN 3 WHEN 'WhatsApp' THEN 4 WHEN 'imo' THEN 5 WHEN 'YouTube' THEN 6 WHEN 'TikTok' THEN 7 WHEN 'Telegram' THEN 8 ELSE 99 END`).bind(peer).all()).results||[];
  const linkPrivacy=(await env.DB.prepare('SELECT platform,visibility FROM myshop_user_social_visibility WHERE user_id=?').bind(peer).all()).results||[];
  const visibleSocialLinks=socialLinks.filter(link=>{const visibility=linkPrivacy.find(p=>p.platform===link.platform)?.visibility||'PUBLIC';return state==='SELF'||visibility==='PUBLIC'||(visibility==='FRIENDS'&&state==='FRIEND');});
  const personalRows=(await env.DB.prepare(`SELECT field_key,value,visibility FROM myshop_user_personal_details WHERE user_id=? ORDER BY CASE field_key WHEN 'location' THEN 1 WHEN 'birthday' THEN 2 WHEN 'relationship' THEN 3 WHEN 'family' THEN 4 WHEN 'gender' THEN 5 WHEN 'languages' THEN 6 WHEN 'education' THEN 7 ELSE 99 END`).bind(peer).all()).results||[];
  const detailGrants=(await env.DB.prepare('SELECT field_key,viewer_id FROM myshop_personal_detail_access WHERE user_id=? AND viewer_id=?').bind(peer,publicPreview?'':user.user_id).all()).results||[];
  const personalDetails=filterPersonalDetailsForViewer(personalRows.filter(row=>!PROFILE_CORE_KEYS.includes(row.field_key)),peer,publicPreview?'':user.user_id,state,detailGrants);
  // Wallet purchase totals and registration gender are private profile data.
  // Gender can be shared only through the per-field Personal Details privacy rule.
  const profile=maskProfileCore({userId:p.user_id,name:p.full_name||'MY SHOP User',avatarUrl:p.avatar_url||'',coverUrl:p.cover_url||'',bio:p.bio||'',joinedAt:p.created_at||'',state,isFollowing:follow,online,activeStatusVisible,lastSeen:activeStatusVisible?(presence?.last_seen||''):'',stats:await socialStatsFor(env,peer),badges,level:levelInfo.level,socialLinks:visibleSocialLinks,personalDetails},personalRows,peer,publicPreview?'':user.user_id,state,detailGrants);
  if(peer===user.user_id&&!publicPreview)profile.totalPurchasedCoins=levelInfo.totalPurchasedCoins;
  return json({ok:true,profile},200,cors);
}

async function newPeople(request,env) {
  await ensureFriendSchema(env);await ensureLevelSchema(env);
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_app_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  try{await env.DB.prepare(`ALTER TABLE myshop_app_presence ADD COLUMN visible INTEGER NOT NULL DEFAULT 1`).run();}catch(e){}
  await env.DB.prepare(`UPDATE myshop_app_presence SET active=0 WHERE active=1 AND datetime(last_seen)<datetime('now','-30 seconds')`).run();
  const myPresence=await env.DB.prepare(`SELECT COALESCE(visible,1) visible FROM myshop_app_presence WHERE user_id=?`).bind(user.user_id).first();
  const canSeePresence=Number(myPresence?.visible??1)===1?1:0;
  const u=new URL(request.url),limit=Math.max(1,Math.min(500,Number(u.searchParams.get('limit')||20))),offset=Math.max(0,Number(u.searchParams.get('offset')||0));
  const membership=String(u.searchParams.get('membership')||'').trim().toUpperCase();
  if(membership&&!V430_MEMBERSHIP_TIERS.includes(membership))return json({error:'INVALID_MEMBERSHIP_FILTER'},400,cors);
  if(membership)await ensureContentSchema(env);
  const memberWhere=membership?` AND EXISTS(SELECT 1 FROM myshop_user_badges mb WHERE mb.user_id=a.user_id AND mb.badge_code=? AND mb.status='ACTIVE' AND (mb.expires_at IS NULL OR datetime(mb.expires_at)>datetime('now')))` : '';
  const rows=(await env.DB.prepare(`SELECT a.user_id,a.full_name,a.avatar_url,a.created_at,
    EXISTS(SELECT 1 FROM myshop_follows ff WHERE ff.follower_id=? AND ff.following_id=a.user_id) AS following,
    (CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=a.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=a.user_id),0)) AS level,
    COALESCE((SELECT COUNT(*) FROM myshop_live_votes v WHERE v.host_id=a.user_id),0) AS vote_count,
    CASE WHEN ?=1 AND EXISTS(SELECT 1 FROM myshop_app_presence ap WHERE ap.user_id=a.user_id AND COALESCE(ap.visible,1)=1 AND ap.active=1 AND datetime(ap.last_seen)>=datetime('now','-30 seconds')) THEN 1 ELSE 0 END AS online,
    CASE WHEN ?=1 THEN COALESCE((SELECT CASE WHEN COALESCE(ap.visible,1)=1 THEN ap.last_seen ELSE '' END FROM myshop_app_presence ap WHERE ap.user_id=a.user_id),'') ELSE '' END AS last_seen,
    CASE
      WHEN EXISTS(SELECT 1 FROM myshop_friend_requests f WHERE f.sender_id=? AND f.receiver_id=a.user_id AND f.status='PENDING') THEN 'REQUESTED'
      WHEN EXISTS(SELECT 1 FROM myshop_friend_requests f WHERE f.sender_id=a.user_id AND f.receiver_id=? AND f.status='PENDING') THEN 'INCOMING'
      WHEN EXISTS(SELECT 1 FROM myshop_friend_requests f WHERE f.status='ACCEPTED' AND ((f.sender_id=? AND f.receiver_id=a.user_id) OR (f.sender_id=a.user_id AND f.receiver_id=?))) THEN 'FRIEND'
      ELSE 'NONE'
    END AS relation_state
    FROM myshop_auth_users_v108 a
    WHERE a.active=1 AND a.user_id<>?
      AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=a.user_id) OR (b.blocker_id=a.user_id AND b.blocked_id=?))
    ${memberWhere}
    ORDER BY datetime(a.created_at) DESC,online DESC,a.user_id DESC LIMIT ? OFFSET ?`).bind(user.user_id,canSeePresence,canSeePresence,user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,...(membership?[membership]:[]),limit,offset).all()).results||[];
  return json({ok:true,membershipFilter:membership,presenceVisible:!!canSeePresence,people:rows.map(x=>({userId:x.user_id,name:x.full_name||'New Member',avatarUrl:x.avatar_url||'',joinedAt:x.created_at||'',state:x.relation_state||'NONE',following:Number(x.following||0)===1,level:Math.max(0,Number(x.level||0)),online:Number(x.online||0)===1,lastActive:x.last_seen||'',vote:Number(x.vote_count||0)})),hasMore:rows.length===limit,nextOffset:offset+rows.length},200,cors);
}


async function ensureVisitHistorySchema(env){
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_visit_history (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,type TEXT NOT NULL DEFAULT 'ITEM',title TEXT NOT NULL DEFAULT '',details TEXT NOT NULL DEFAULT '',ref TEXT NOT NULL DEFAULT '',thumbnail_url TEXT NOT NULL DEFAULT '',action TEXT NOT NULL DEFAULT 'Open',visited_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_myshop_visit_history_user_time ON myshop_visit_history(user_id,visited_at DESC,id DESC)`).run();
}
async function historyRecord(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);await ensureVisitHistorySchema(env);const b=await body(request);
  const type=String(b.type||'ITEM').trim().toUpperCase().slice(0,40);const title=String(b.title||'MY SHOP').trim().slice(0,160);const details=String(b.details||'').trim().slice(0,220);const ref=String(b.ref||'').trim().slice(0,220);const thumbnail=String(b.thumbnailUrl||b.thumbnail_url||'').trim().slice(0,700);const action=String(b.action||'Open').trim().slice(0,80);
  if(!type||!title)return json({error:'HISTORY_ITEM_INVALID'},400,cors);
  const recent=await env.DB.prepare(`SELECT id FROM myshop_visit_history WHERE user_id=? AND type=? AND title=? AND ref=? AND visited_at>=datetime('now','-30 seconds') ORDER BY id DESC LIMIT 1`).bind(user.user_id,type,title,ref).first();
  if(!recent) await env.DB.prepare(`INSERT INTO myshop_visit_history(user_id,type,title,details,ref,thumbnail_url,action,visited_at) VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)`).bind(user.user_id,type,title,details,ref,thumbnail,action).run();
  else await env.DB.prepare(`UPDATE myshop_visit_history SET details=?,thumbnail_url=CASE WHEN ?<>'' THEN ? ELSE thumbnail_url END,action=CASE WHEN ?<>'' AND ?<>'Open' THEN ? ELSE action END,visited_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?`).bind(details,thumbnail,thumbnail,action,action,action,Number(recent.id),user.user_id).run();
  await env.DB.prepare(`DELETE FROM myshop_visit_history WHERE user_id=? AND id NOT IN (SELECT id FROM myshop_visit_history WHERE user_id=? ORDER BY id DESC LIMIT 100)`).bind(user.user_id,user.user_id).run();
  return json({ok:true},200,cors);
}
async function historyList(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);await ensureVisitHistorySchema(env);const url=new URL(request.url),limit=Math.max(1,Math.min(100,Number(url.searchParams.get('limit')||50))),offset=Math.max(0,Number(url.searchParams.get('offset')||0));
  const rows=(await env.DB.prepare(`SELECT id,type,title,details,ref,thumbnail_url,action,visited_at FROM myshop_visit_history WHERE user_id=? ORDER BY datetime(visited_at) DESC,id DESC LIMIT ? OFFSET ?`).bind(user.user_id,limit,offset).all()).results||[];
  return json({ok:true,history:rows.map(x=>({id:Number(x.id||0),type:x.type||'ITEM',title:x.title||'MY SHOP',details:x.details||'',ref:x.ref||'',thumbnailUrl:x.thumbnail_url||'',action:x.action||'Open',visitedAt:x.visited_at||''})),hasMore:rows.length===limit,nextOffset:offset+rows.length},200,cors);
}
async function historyClear(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);await ensureVisitHistorySchema(env);await env.DB.prepare('DELETE FROM myshop_visit_history WHERE user_id=?').bind(user.user_id).run();return json({ok:true},200,cors);
}

async function profileConnections(request,env){
  const viewer=await getUser(request,env);if(!viewer)return json({error:'UNAUTHORIZED'},401,cors);
  await ensureFriendSchema(env);const q=new URL(request.url).searchParams,target=String(q.get('userId')||''),kind=String(q.get('kind')||'friends');
  if(!isFourDigit(target)||!['friends','following','followers'].includes(kind))return json({error:'INVALID_PROFILE_LIST'},400,cors);
  const owner=await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1`).bind(target).first();if(!owner)return json({error:'USER_NOT_FOUND'},404,cors);
  if(await safetyIsBlocked(env,viewer.user_id,target))return json({error:'BLOCKED_USER'},403,cors);
  const offset=Math.min(100000,Math.max(0,Math.floor(Number(q.get('offset')||0)||0))),limit=Math.min(50,Math.max(1,Math.floor(Number(q.get('limit')||30)||30)));
  let base,binds;
  if(kind==='friends'){base=`FROM myshop_friend_requests r JOIN myshop_auth_users_v108 u ON u.user_id=CASE WHEN r.sender_id=? THEN r.receiver_id ELSE r.sender_id END WHERE (r.sender_id=? OR r.receiver_id=?) AND r.status='ACCEPTED'`;binds=[target,target,target];}
  else if(kind==='following'){base=`FROM myshop_follows r JOIN myshop_auth_users_v108 u ON u.user_id=r.following_id WHERE r.follower_id=?`;binds=[target];}
  else{base=`FROM myshop_follows r JOIN myshop_auth_users_v108 u ON u.user_id=r.follower_id WHERE r.following_id=?`;binds=[target];}
  base+=` AND u.active=1 AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=u.user_id) OR (b.blocker_id=u.user_id AND b.blocked_id=?))`;binds.push(viewer.user_id,viewer.user_id);
  const rows=(await env.DB.prepare(`SELECT DISTINCT u.user_id,u.full_name,u.avatar_url ${base} ORDER BY u.user_id LIMIT ? OFFSET ?`).bind(...binds,limit+1,offset).all()).results||[];
  return json({ok:true,users:rows.slice(0,limit).map(x=>({userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||''})),hasMore:rows.length>limit,nextOffset:offset+Math.min(rows.length,limit)},200,cors);
}

async function friendRequest(request,env) {
  await ensureFriendSchema(env);
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request),target=String(b.userId||'').trim(); if(!target||target===user.user_id)return json({error:'INVALID_USER'},400,cors);
  const found=await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1`).bind(target).first(); if(!found)return json({error:'USER_NOT_FOUND'},404,cors);
  const blocked=await env.DB.prepare(`SELECT 1 ok FROM myshop_user_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1`).bind(user.user_id,target,target,user.user_id).first(); if(blocked)return json({error:'NOT_AVAILABLE'},409,cors);
  // One D1 transaction creates the request and independent follow. Opposite-direction
  // pending requests and retries cannot create duplicate relationship rows.
  const result=await env.DB.batch([
    env.DB.prepare(`INSERT INTO myshop_friend_requests(sender_id,receiver_id,status,created_at,updated_at)
      SELECT ?,?,'PENDING',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP
      WHERE NOT EXISTS(SELECT 1 FROM myshop_friend_requests WHERE ((sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)) AND status IN ('PENDING','ACCEPTED'))
      AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?))
      ON CONFLICT(sender_id,receiver_id) DO UPDATE SET status='PENDING',created_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE myshop_friend_requests.status='DECLINED'`)
      .bind(user.user_id,target,user.user_id,target,target,user.user_id,user.user_id,target,target,user.user_id),
    env.DB.prepare(`INSERT OR IGNORE INTO myshop_follows(follower_id,following_id)
      SELECT ?,? WHERE EXISTS(SELECT 1 FROM myshop_friend_requests WHERE sender_id=? AND receiver_id=? AND status='PENDING')
      AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?))`)
      .bind(user.user_id,target,user.user_id,target,user.user_id,target,target,user.user_id)
  ]);
  const row=await env.DB.prepare(`SELECT sender_id,status FROM myshop_friend_requests WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) LIMIT 1`).bind(user.user_id,target,target,user.user_id).first();
  if(!row)return json({error:'NOT_AVAILABLE'},409,cors);
  if(row.status==='ACCEPTED')return json({error:'ALREADY_FRIENDS'},409,cors);
  if(row.sender_id!==user.user_id)return json({error:'REQUEST_PENDING'},409,cors);
  if(Number(result[0]?.meta?.changes||0)>0)await createUserNotification(env,target,'Friend Request',(user.full_name||'A MY SHOP user')+' sent you a friend request.','FRIEND_REQUEST',user.user_id,user.user_id);
  return json({ok:true,status:'REQUESTED',following:true},Number(result[0]?.meta?.changes||0)>0?201:200,cors);
}

async function friendRequestsList(request,env){
  await ensureFriendSchema(env);
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const incoming=(await env.DB.prepare(`SELECT f.sender_id AS user_id,u.full_name,u.avatar_url,f.created_at FROM myshop_friend_requests f JOIN myshop_auth_users_v108 u ON u.user_id=f.sender_id WHERE f.receiver_id=? AND f.status='PENDING' AND u.active=1 ORDER BY datetime(f.created_at) DESC`).bind(user.user_id).all()).results||[];
  const outgoing=(await env.DB.prepare(`SELECT f.receiver_id AS user_id,u.full_name,u.avatar_url,f.created_at FROM myshop_friend_requests f JOIN myshop_auth_users_v108 u ON u.user_id=f.receiver_id WHERE f.sender_id=? AND f.status='PENDING' AND u.active=1 ORDER BY datetime(f.created_at) DESC`).bind(user.user_id).all()).results||[];
  const friends=(await env.DB.prepare(`SELECT CASE WHEN f.sender_id=? THEN f.receiver_id ELSE f.sender_id END AS user_id,u.full_name,u.avatar_url,f.updated_at FROM myshop_friend_requests f JOIN myshop_auth_users_v108 u ON u.user_id=CASE WHEN f.sender_id=? THEN f.receiver_id ELSE f.sender_id END WHERE (f.sender_id=? OR f.receiver_id=?) AND f.status='ACCEPTED' AND u.active=1 ORDER BY datetime(f.updated_at) DESC`).bind(user.user_id,user.user_id,user.user_id,user.user_id).all()).results||[];
  return json({ok:true,incoming:incoming.map(x=>({userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',createdAt:x.created_at||''})),outgoing:outgoing.map(x=>({userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',createdAt:x.created_at||''})),friends:friends.map(x=>({userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||''})),stats:await socialStatsFor(env,user.user_id)},200,cors);
}

async function friendRespond(request,env){
  await ensureFriendSchema(env);
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request),sender=String(b.userId||'').trim(),action=String(b.action||'').trim().toUpperCase();if(!sender||!['ACCEPT','DECLINE'].includes(action))return json({error:'INVALID_REQUEST'},400,cors);
  const row=await env.DB.prepare(`SELECT status FROM myshop_friend_requests WHERE sender_id=? AND receiver_id=?`).bind(sender,user.user_id).first();
  if(!row)return json({error:'REQUEST_NOT_FOUND'},404,cors);
  if(row.status==='ACCEPTED'&&action==='ACCEPT') return json({ok:true,status:'ACCEPTED',already:true,stats:await socialStatsFor(env,user.user_id),peerStats:await socialStatsFor(env,sender)},200,cors);
  if(row.status!=='PENDING')return json({error:'REQUEST_NOT_PENDING',status:row.status},409,cors);
  const status=action==='ACCEPT'?'ACCEPTED':'DECLINED';
  const changed=await env.DB.prepare(`UPDATE myshop_friend_requests SET status=?,updated_at=CURRENT_TIMESTAMP WHERE sender_id=? AND receiver_id=? AND status='PENDING'`).bind(status,sender,user.user_id).run();
  if(Number(changed?.meta?.changes||0)<1)return json({error:'FRIEND_UPDATE_FAILED'},409,cors);
  await createUserNotification(env,sender,action==='ACCEPT'?'Friend Request Accepted':'Friend Request Update',(user.full_name||'A MY SHOP user')+(action==='ACCEPT'?' accepted your friend request.':' declined your friend request.'),action==='ACCEPT'?'FRIEND_ACCEPT':'FRIEND_UPDATE',user.user_id,user.user_id);
  return json({ok:true,status,stats:await socialStatsFor(env,user.user_id),peerStats:await socialStatsFor(env,sender)},200,cors);
}


async function appPresenceRead(request,env){const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);const ids=[...new Set(String(new URL(request.url).searchParams.get('ids')||'').split(',').filter(id=>/^\d{4}$/.test(id)))].slice(0,50);if(!ids.length)return json({ok:true,users:[]},200,cors);await ensureFriendSchema(env);await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_app_presence(user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,visible INTEGER NOT NULL DEFAULT 1)`).run();try{await env.DB.prepare(`ALTER TABLE myshop_app_presence ADD COLUMN visible INTEGER NOT NULL DEFAULT 1`).run();}catch(_){}const own=await env.DB.prepare(`SELECT visible FROM myshop_app_presence WHERE user_id=?`).bind(me.user_id).first();const visible=Number(own?.visible??1)===1;if(!visible)return json({ok:true,users:ids.map(userId=>({userId,online:false}))},200,cors);const marks=ids.map(()=>'?').join(',');const rows=(await env.DB.prepare(`SELECT p.user_id FROM myshop_app_presence p WHERE p.user_id IN (${marks}) AND p.active=1 AND COALESCE(p.visible,1)=1 AND datetime(p.last_seen)>=datetime('now','-30 seconds') AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=p.user_id) OR (b.blocker_id=p.user_id AND b.blocked_id=?))`).bind(...ids,me.user_id,me.user_id).all()).results||[],online=new Set(rows.map(x=>x.user_id));return json({ok:true,users:ids.map(userId=>({userId,online:online.has(userId)}))},200,cors);}
async function appPresence(request,env){
 const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
 await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_app_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
 try{await env.DB.prepare(`ALTER TABLE myshop_app_presence ADD COLUMN visible INTEGER NOT NULL DEFAULT 1`).run();}catch(e){}
 await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_app_presence_sessions(user_id TEXT NOT NULL,device_id TEXT NOT NULL,sequence INTEGER NOT NULL,active INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,device_id))`).run();
 const b=await body(request),old=await env.DB.prepare(`SELECT active,last_seen,COALESCE(visible,1) visible FROM myshop_app_presence WHERE user_id=?`).bind(user.user_id).first();
 const visible=Object.prototype.hasOwnProperty.call(b,'visible')?(b.visible===false?0:1):Number(old?.visible??1);
 if(!Object.prototype.hasOwnProperty.call(b,'active')){
  await env.DB.prepare(`INSERT INTO myshop_app_presence(user_id,active,visible) VALUES(?,0,?) ON CONFLICT(user_id) DO UPDATE SET visible=excluded.visible`).bind(user.user_id,visible).run();return json({ok:true,visible:!!visible,active:!!Number(old?.active||0)},200,cors);
 }
 const active=b.active===true?1:0,device=String(b.deviceId||'legacy').slice(0,80),seq=b.deviceId?Number(b.sequence):Date.now();
 if(!/^[a-zA-Z0-9_-]{1,80}$/.test(device)||!Number.isSafeInteger(seq)||seq<0)return json({error:'INVALID_PRESENCE'},400,cors);
 await env.DB.batch([
  env.DB.prepare(`INSERT INTO myshop_app_presence_sessions(user_id,device_id,sequence,active,last_seen) VALUES(?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id,device_id) DO UPDATE SET sequence=excluded.sequence,active=excluded.active,last_seen=CURRENT_TIMESTAMP WHERE excluded.sequence>myshop_app_presence_sessions.sequence`).bind(user.user_id,device,seq,active),
  env.DB.prepare(`INSERT INTO myshop_app_presence(user_id,active,last_seen,visible) VALUES(?,(SELECT CASE WHEN EXISTS(SELECT 1 FROM myshop_app_presence_sessions WHERE user_id=? AND active=1 AND datetime(last_seen)>=datetime('now','-30 seconds')) THEN 1 ELSE 0 END),CURRENT_TIMESTAMP,?) ON CONFLICT(user_id) DO UPDATE SET active=excluded.active,last_seen=COALESCE((SELECT MAX(last_seen) FROM myshop_app_presence_sessions WHERE user_id=?),myshop_app_presence.last_seen),visible=excluded.visible`).bind(user.user_id,user.user_id,visible,user.user_id)
 ]);
 const state=await env.DB.prepare(`SELECT active FROM myshop_app_presence WHERE user_id=?`).bind(user.user_id).first();return json({ok:true,active:!!Number(state?.active||0),visible:!!visible,expiresAfterSeconds:30},200,cors);
}


async function livePresence(request,env,ctx){
  await ensureFriendSchema(env); const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,viewer_count INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await ensureLiveRoomSchema(env);
  const b=await body(request),active=b.active===false?0:1;
  const prev=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(user.user_id).first();
  const oldMeta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(user.user_id).first();
  const starting=active && (Number(prev?.active||0)!==1 || !oldMeta?.session_id);
  let requestedTitle='',requestedTopic=String(b.topic||'').trim().slice(0,120);
  if(starting && Object.prototype.hasOwnProperty.call(b,'title')){
    const policy=await applyLiveNamePolicy(env,user.user_id,String(b.title||''));
    if(!policy.ok)return json({error:policy.error,remainingSeconds:policy.remainingSeconds||0,cost:policy.cost||0},409,cors);
    requestedTitle=String(policy.name||'').trim().slice(0,40);
  }
  if(!starting) await env.DB.prepare(`INSERT INTO myshop_live_presence(user_id,active,viewer_count,last_seen) VALUES(?,?,0,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET active=excluded.active,last_seen=CURRENT_TIMESTAMP`).bind(user.user_id,active).run();
  if(starting){
    const sessionId=crypto.randomUUID();
    // V-369: MUTE/KICK are live-session states only. A fresh Live must never inherit them.
    // Permanent BLOCK remains untouched and is the only moderation state that survives a new Live.
    await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND state IN ('MUTED','KICKED')`).bind(user.user_id).run();
    const prevReact=await env.DB.prepare(`SELECT COALESCE(react_count,0) react_count,COALESCE(react_reward_milestone,0) react_reward_milestone,COALESCE(react_window_started_at,'') react_window_started_at FROM myshop_live_room_meta WHERE host_id=?`).bind(user.user_id).first();
    let carryReact=Number(prevReact?.react_count||0),carryMilestone=Number(prevReact?.react_reward_milestone||0),carryWindow=String(prevReact?.react_window_started_at||'');
    const carryWindowMs=carryWindow?Date.parse(carryWindow.replace(' ','T')+'Z'):NaN;
    if(!carryWindow||!Number.isFinite(carryWindowMs)||Date.now()-carryWindowMs>=86400000){carryReact=0;carryMilestone=0;carryWindow=new Date().toISOString();}
    const initialTitle=(requestedTitle||(user.full_name||('Live '+user.user_id))).slice(0,40);
    const initialTopic=(requestedTopic||'Audio Live').slice(0,120);
    await env.DB.batch([
      env.DB.prepare(`INSERT OR REPLACE INTO myshop_live_room_meta(host_id,special_guest_id,locked,title,topic,started_at,peak_viewers,share_count,pinned_message,pinned_until,theme_key,react_count,react_reward_milestone,react_window_started_at,session_id,welcome_message,goal_type,goal_target,pinned_product_id,updated_at) VALUES(?,NULL,0,?,?,CURRENT_TIMESTAMP,0,0,'',NULL,'GUITAR_BLUE',?,?,?,?,'','NONE',0,0,CURRENT_TIMESTAMP)`).bind(user.user_id,initialTitle,initialTopic,carryReact,carryMilestone,carryWindow,sessionId),
      env.DB.prepare(`DELETE FROM myshop_live_seats_dynamic WHERE host_id=?`).bind(user.user_id),
      env.DB.prepare(`DELETE FROM myshop_live_requests WHERE host_id=?`).bind(user.user_id),
      env.DB.prepare(`DELETE FROM myshop_live_invites WHERE host_id=?`).bind(user.user_id),
      env.DB.prepare(`DELETE FROM myshop_live_viewers WHERE host_id=?`).bind(user.user_id),
      env.DB.prepare(`DELETE FROM myshop_live_seat_locks WHERE host_id=?`).bind(user.user_id),
      env.DB.prepare(`DELETE FROM myshop_live_comments WHERE host_id=?`).bind(user.user_id),
      env.DB.prepare(`DELETE FROM myshop_live_highlight_comments WHERE host_id=?`).bind(user.user_id),
      env.DB.prepare(`DELETE FROM myshop_live_events WHERE host_id=?`).bind(user.user_id),
      env.DB.prepare(`DELETE FROM myshop_live_entry_events WHERE host_id=?`).bind(user.user_id),
      env.DB.prepare(`INSERT INTO myshop_live_presence(user_id,active,viewer_count,last_seen) VALUES(?,?,0,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET active=excluded.active,last_seen=CURRENT_TIMESTAMP`).bind(user.user_id,active)
    ]);
    liveEphemeralClear(user.user_id,String(oldMeta?.session_id||''));
    try{await liveHubClear(env,user.user_id,sessionId);}catch(e){}
    // Activate the nearest scheduled live and notify only users who explicitly requested a reminder.
    try{
      const sch=await env.DB.prepare(`SELECT id,title FROM myshop_live_schedules WHERE host_id=? AND status='SCHEDULED' AND datetime(scheduled_at)>=datetime('now','-12 hours') ORDER BY ABS(strftime('%s',scheduled_at)-strftime('%s','now')) LIMIT 1`).bind(user.user_id).first();
      if(sch){
        await env.DB.prepare(`UPDATE myshop_live_schedules SET status='LIVE',updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(sch.id).run();
        const reminders=(await env.DB.prepare(`SELECT user_id FROM myshop_live_reminders WHERE schedule_id=?`).bind(sch.id).all()).results||[];
        for(const r of reminders){try{await createUserNotification(env,String(r.user_id),'Scheduled Live Started',(user.full_name||'Host')+' is live now.','LIVE_SCHEDULE_START',user.user_id,user.user_id);}catch(e){}}
      }
    }catch(e){console.error('LIVE_SCHEDULE_ACTIVATE_FAILED',String(e?.message||e));}
  }
  if(!active){
    const m=await env.DB.prepare(`SELECT title,topic,started_at,peak_viewers,share_count,COALESCE(react_count,0) react_count,COALESCE(react_reward_milestone,0) react_reward_milestone,COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(user.user_id).first();
    if(m?.started_at){
      const seen=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_listener_seen WHERE host_id=? AND started_at=?`).bind(user.user_id,m.started_at).first();
      await env.DB.prepare(`INSERT INTO myshop_live_history(host_id,title,topic,started_at,ended_at,duration_seconds,peak_viewers,total_listeners,share_count,react_count,react_reward_coin,session_id) VALUES(?,?,?,?,CURRENT_TIMESTAMP,MAX(0,CAST((julianday('now')-julianday(?))*86400 AS INTEGER)),?,?,?,?,?,?)`).bind(user.user_id,m.title||'',m.topic||'',m.started_at,m.started_at,Number(m.peak_viewers||0),Number(seen?.c||0),Number(m.share_count||0),Number(m.react_count||0),Number(m.react_reward_milestone||0)*1000,String(m.session_id||'')).run();
      // V-304: Live comments are a transient session buffer only. They are never retained as history.
      await env.DB.prepare(`DELETE FROM myshop_live_comments WHERE host_id=? AND session_id=?`).bind(user.user_id,String(m.session_id||'')).run();
      await env.DB.prepare(`DELETE FROM myshop_live_highlight_comments WHERE host_id=? AND session_id=?`).bind(user.user_id,String(m.session_id||'')).run();
      liveEphemeralClear(user.user_id,String(m.session_id||''));
      try{await liveHubClear(env,user.user_id,String(m.session_id||''));}catch(e){}
      try{await env.DB.prepare(`UPDATE myshop_live_schedules SET status='ENDED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND status='LIVE'`).bind(user.user_id).run();}catch(e){}
      try{await env.DB.prepare(`UPDATE myshop_live_pk_rounds SET status='ENDED',ended_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE status='ACTIVE' AND (host_a=? OR host_b=?)`).bind(user.user_id,user.user_id).run();}catch(e){}
    }
    await env.DB.prepare(`DELETE FROM myshop_live_seats_dynamic WHERE host_id=?`).bind(user.user_id).run();
    await env.DB.prepare(`DELETE FROM myshop_live_requests WHERE host_id=?`).bind(user.user_id).run();
    await env.DB.prepare(`DELETE FROM myshop_live_invites WHERE host_id=?`).bind(user.user_id).run();
    await env.DB.prepare(`DELETE FROM myshop_live_viewers WHERE host_id=?`).bind(user.user_id).run();
    await env.DB.prepare(`DELETE FROM myshop_live_seat_locks WHERE host_id=?`).bind(user.user_id).run();
    // V-369: clear only temporary live-session moderation; keep explicit BLOCK permanent.
    await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND state IN ('MUTED','KICKED')`).bind(user.user_id).run();
    await env.DB.prepare(`DELETE FROM myshop_live_room_meta WHERE host_id=?`).bind(user.user_id).run();
    await env.DB.prepare(`UPDATE myshop_live_presence SET viewer_count=0 WHERE user_id=?`).bind(user.user_id).run();
  }
  if(starting){
    const notifyFollowers=async()=>{
    try{
      await ensureNotificationSchema(env);
      const liveTitle='🔴 Live Now';
      const liveBody=(requestedTitle||user.full_name||'A MY SHOP user')+' is live now. Tap to join.';
      await env.DB.prepare(`INSERT INTO notifications(title,message,audience,user_id,type,actor_user_id,target_id,created_at)
        SELECT ?,?,'USER',f.follower_id,'LIVE_START',?, ?,CURRENT_TIMESTAMP FROM myshop_follows f JOIN myshop_auth_users_v108 u ON u.user_id=f.follower_id WHERE f.following_id=? AND u.active=1`).bind(liveTitle,liveBody,user.user_id,user.user_id,user.user_id).run();
      // V-340: real Android heads-up push only to users who follow this host and registered an active FCM token.
      const targets=(await env.DB.prepare(`SELECT DISTINCT p.user_id FROM myshop_push_tokens p JOIN myshop_follows f ON f.follower_id=p.user_id WHERE p.active=1 AND f.following_id=? LIMIT 5000`).bind(user.user_id).all()).results||[];
      for(let i=0;i<targets.length;i+=40){const batch=targets.slice(i,i+40);await Promise.all(batch.map(r=>sendPushToUser(env,String(r.user_id),liveTitle,liveBody,'LIVE_START',user.user_id,user.user_id)));}
    }catch(e){console.error('LIVE_NOTIFICATION_FAILED',String(e?.message||e));}
      };
    if(ctx?.waitUntil)ctx.waitUntil(notifyFollowers());else await notifyFollowers();
  }
  let activeMeta=null;if(active){try{activeMeta=await env.DB.prepare(`SELECT title,topic,COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(user.user_id).first();}catch(e){}}
  const wallet=active?await env.DB.prepare(`SELECT COALESCE((SELECT balance FROM myshop_coin_wallets WHERE user_id=?),0) coinBalance,COALESCE((SELECT balance FROM myshop_gold_wallets WHERE user_id=?),0) goldBalance`).bind(user.user_id,user.user_id).first():null;
  return json({ok:true,active:!!active,title:String(activeMeta?.title||requestedTitle||''),topic:String(activeMeta?.topic||requestedTopic||''),sessionId:String(activeMeta?.session_id||''),hostStats:wallet||{}},200,cors);
}

// V-307: server-confirmed, idempotent host End Live endpoint.
// Heartbeats refresh an existing session only; a delayed heartbeat cannot resurrect an ended room.
async function liveHostHeartbeat(request,env){
 const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
 await ensureLiveRoomSchema(env);const b=await body(request),session=String(b.sessionId||'').trim();
 if(!session)return json({error:'LIVE_SESSION_REQUIRED'},409,cors);
 const updated=await env.DB.prepare(`UPDATE myshop_live_presence SET last_seen=CURRENT_TIMESTAMP WHERE user_id=? AND active=1 AND EXISTS(SELECT 1 FROM myshop_live_room_meta WHERE host_id=? AND session_id=?)`).bind(user.user_id,user.user_id,session).run();
 if(Number(updated.meta?.changes||0)!==1)return json({error:'LIVE_NOT_ACTIVE'},409,cors);
 return json({ok:true,sessionId:session},200,cors);
}

async function liveEnd(request,env){
 const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
 await ensureLiveRoomSchema(env);const result=await closeLive(env.DB,user.user_id);
 if(!result.closed)return json({error:'LIVE_END_NOT_CONFIRMED'},409,cors);
 invalidatePublicAggregates(env.DB,user.user_id);liveEphemeralClear(user.user_id,result.sessionId);
 if(result.sessionId)await liveHubClear(env,user.user_id,result.sessionId);
 return json(result,200,cors);
}

async function liveViewer(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request),hostId=String(b.hostId||'').trim(),joined=b.joined===false?0:1,freshJoin=b.freshJoin===true;
  if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,viewer_count INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await ensureLiveRoomSchema(env);
  const row=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();
  // Leave is an idempotent cleanup operation and must still succeed just after Host ends.
  if(joined&&(!row||Number(row.active)!==1))return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  const sanction=await liveSanctionFor(env,hostId,user.user_id);await ensureFriendSchema(env);const persistentHostBlock=await env.DB.prepare(`SELECT 1 ok FROM myshop_user_blocks WHERE blocker_id=? AND blocked_id=? LIMIT 1`).bind(hostId,user.user_id).first();if(joined&&(sanction==='BLOCKED'||persistentHostBlock))return json({error:'LIVE_BLOCKED'},403,cors);if(joined&&['KICKED','MUTED'].includes(sanction))await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state IN ('KICKED','MUTED')`).bind(hostId,user.user_id).run();
  const currentMeta=await env.DB.prepare(`SELECT COALESCE(started_at,'') started_at,COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();
  const currentSessionId=String(currentMeta?.session_id||'');
  if(user.user_id!==hostId){
    if(joined){
      const claimed=await env.DB.batch([
        env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_viewers(host_id,user_id,last_seen,joined_at) VALUES(?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)`).bind(hostId,user.user_id),
        env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) SELECT ?,?,?,'JOIN','joined the live' WHERE changes()>0`).bind(hostId,user.user_id,currentSessionId)
      ]);
      const was=Number(claimed[0]?.meta?.changes||0)===0;
      if(freshJoin)await env.DB.prepare(`UPDATE myshop_live_requests SET status='CANCELLED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=? AND status='PENDING'`).bind(hostId,user.user_id,currentSessionId).run();
      await env.DB.prepare(`INSERT INTO myshop_live_viewers(host_id,user_id,last_seen,joined_at) VALUES(?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id) DO UPDATE SET last_seen=CURRENT_TIMESTAMP,joined_at=CASE WHEN ?=1 THEN CURRENT_TIMESTAMP WHEN COALESCE(myshop_live_viewers.joined_at,'')='' THEN CURRENT_TIMESTAMP ELSE myshop_live_viewers.joined_at END`).bind(hostId,user.user_id,freshJoin?1:0).run();
      const started=String(currentMeta?.started_at||'');
      if(started)await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_listener_seen(host_id,started_at,user_id) VALUES(?,?,?)`).bind(hostId,started,user.user_id).run();
      if(!was){
        if(currentSessionId)await liveHubDirty(env,hostId,currentSessionId,'VIEWER_JOINED');
        try{
          const tier=await currentTier(env,user.user_id);
          const entry=await env.DB.prepare(`SELECT o.item_code,c.animation_url,c.animation_mime,c.sound_url,c.sound_volume,c.effect_duration_ms,c.sound_duration_ms,c.animation_speed FROM myshop_owned_items o JOIN myshop_store_catalog c ON c.id=o.catalog_id WHERE o.user_id=? AND o.item_type='ENTRY_ANIMATION' AND o.equipped=1 AND (o.expires_at IS NULL OR datetime(o.expires_at)>datetime('now')) ORDER BY o.id DESC LIMIT 1`).bind(user.user_id).first();
          await env.DB.prepare(`INSERT INTO myshop_live_entry_events(host_id,user_id,tier,item_code,animation_url,animation_mime,sound_url,sound_volume,effect_duration_ms,sound_duration_ms,animation_speed) VALUES(?,?,?,?,?,?,?,?,?,?,?)`).bind(hostId,user.user_id,tier,String(entry?.item_code||''),String(entry?.animation_url||''),String(entry?.animation_mime||''),String(entry?.sound_url||''),Math.max(0,Math.min(100,Number(entry?.sound_volume??90))),Math.max(800,Math.min(15000,Number(entry?.effect_duration_ms??3500))),Math.max(0,Math.min(15000,Number(entry?.sound_duration_ms??3000))),Math.max(1,Math.min(100,Number(entry?.animation_speed||55)))).run();
          await env.DB.prepare(`UPDATE myshop_live_fan_club SET points=points+1,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND active=1`).bind(hostId,user.user_id).run();
        }catch(e){}
      }
    }else{
      const was=await env.DB.prepare(`SELECT 1 x FROM myshop_live_viewers WHERE host_id=? AND user_id=?`).bind(hostId,user.user_id).first();
      await env.DB.prepare(`DELETE FROM myshop_live_viewers WHERE host_id=? AND user_id=?`).bind(hostId,user.user_id).run();
      await env.DB.prepare(`DELETE FROM myshop_live_seats_dynamic WHERE host_id=? AND user_id=? AND seat_no>1`).bind(hostId,user.user_id).run();
      await env.DB.prepare(`UPDATE myshop_live_requests SET status='CANCELLED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=? AND status='PENDING'`).bind(hostId,user.user_id,currentSessionId).run();
      await env.DB.prepare(`UPDATE myshop_live_invites SET status='CANCELLED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=? AND status='PENDING'`).bind(hostId,user.user_id,currentSessionId).run();
      await env.DB.prepare(`UPDATE myshop_live_room_meta SET special_guest_id=NULL,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND special_guest_id=?`).bind(hostId,user.user_id).run();
      if(was){await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'LEAVE','left the live')`).bind(hostId,user.user_id,currentSessionId).run();if(currentSessionId)await liveHubDirty(env,hostId,currentSessionId,'VIEWER_LEFT');}
    }
  }
  await env.DB.prepare(`DELETE FROM myshop_live_viewers WHERE host_id=? AND datetime(last_seen)<datetime('now','-25 seconds')`).bind(hostId).run();
  const c=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_viewers WHERE host_id=?`).bind(hostId).first();
  const next=Math.max(0,Number(c?.c||0));
  await env.DB.prepare(`UPDATE myshop_live_presence SET viewer_count=? WHERE user_id=?`).bind(next,hostId).run();
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET peak_viewers=MAX(COALESCE(peak_viewers,0),?),updated_at=CURRENT_TIMESTAMP WHERE host_id=?`).bind(next,hostId).run();
  return json({ok:true,viewerCount:next,cleaned:!joined},200,cors);
}

async function ensureLiveRoomSchemaImpl(env){
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_reward_claims(reward_key TEXT PRIMARY KEY,host_id TEXT NOT NULL,session_id TEXT NOT NULL,amount INTEGER NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_seats_dynamic (host_id TEXT NOT NULL,seat_no INTEGER NOT NULL,user_id TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'SPEAKER',muted INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,seat_no),UNIQUE(host_id,user_id),CHECK(seat_no BETWEEN 1 AND 99))`).run();
  for(const sql of [
    `ALTER TABLE myshop_live_seats_dynamic ADD COLUMN mic_on INTEGER NOT NULL DEFAULT 1`,
    `ALTER TABLE myshop_live_seats_dynamic ADD COLUMN speaking INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_seats_dynamic ADD COLUMN network_quality TEXT NOT NULL DEFAULT 'GOOD'`
  ]){try{await env.DB.prepare(sql).run();}catch(e){}}
  // Migrate deployed V-536 seat assignments once from the old 1..12 constrained table.
  // A one-time marker prevents deleted/stale rows from being copied back on later requests.
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_schema_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  const seatMigration=await env.DB.prepare(`SELECT value FROM myshop_schema_meta WHERE key='live_seats_dynamic_v537_migrated'`).first();
  if(!seatMigration){try{await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_seats_dynamic(host_id,seat_no,user_id,role,muted,updated_at) SELECT host_id,seat_no,user_id,role,muted,updated_at FROM myshop_live_seats`).run();}catch(e){}await env.DB.prepare(`INSERT INTO myshop_schema_meta(key,value,updated_at) VALUES('live_seats_dynamic_v537_migrated','1',CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value='1',updated_at=CURRENT_TIMESTAMP`).run();}
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_requests (host_id TEXT NOT NULL,user_id TEXT NOT NULL,session_id TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,user_id))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_invites (host_id TEXT NOT NULL,user_id TEXT NOT NULL,session_id TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',expires_at TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,user_id,session_id))`).run();
  try{await env.DB.prepare(`ALTER TABLE myshop_live_invites ADD COLUMN invited_by TEXT NOT NULL DEFAULT ''`).run();}catch(e){}
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_call_suggestions (host_id TEXT NOT NULL,admin_id TEXT NOT NULL,user_id TEXT NOT NULL,session_id TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,admin_id,user_id,session_id))`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_invites_user ON myshop_live_invites(user_id,status,expires_at)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_viewers (host_id TEXT NOT NULL,user_id TEXT NOT NULL,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,user_id))`).run();
  try{await env.DB.prepare(`ALTER TABLE myshop_live_viewers ADD COLUMN joined_at TEXT NOT NULL DEFAULT ''`).run();}catch(e){}
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_room_meta (host_id TEXT PRIMARY KEY,special_guest_id TEXT,locked INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_votes (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,voter_id TEXT NOT NULL,session_id TEXT NOT NULL DEFAULT '',voted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_polls (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,session_id TEXT NOT NULL,question TEXT NOT NULL,option_a TEXT NOT NULL,option_b TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'ACTIVE',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,closed_at TEXT)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_poll_votes (poll_id INTEGER NOT NULL,user_id TEXT NOT NULL,choice TEXT NOT NULL CHECK(choice IN ('A','B')),created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(poll_id,user_id))`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_votes_voter_host_time ON myshop_live_votes(voter_id,host_id,voted_at DESC)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_votes_host_session ON myshop_live_votes(host_id,session_id,id)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_wallet_sources (user_id TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('COIN','GOLD')),official_balance INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,currency))`).run();
  for(const sql of [
    `ALTER TABLE myshop_live_room_meta ADD COLUMN title TEXT NOT NULL DEFAULT 'Let''s Talk Together'`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN topic TEXT NOT NULL DEFAULT 'Audio Live'`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN started_at TEXT`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN peak_viewers INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN share_count INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN pinned_message TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN theme_key TEXT NOT NULL DEFAULT 'GUITAR_BLUE'`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN welcome_message TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN goal_type TEXT NOT NULL DEFAULT 'NONE'`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN goal_target INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN pinned_product_id INTEGER NOT NULL DEFAULT 0`
  ]){try{await env.DB.prepare(sql).run();}catch(e){}}
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_seat_locks (host_id TEXT NOT NULL,seat_no INTEGER NOT NULL,locked INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,seat_no))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_events (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,user_id TEXT,event_type TEXT NOT NULL,message TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  try{await env.DB.prepare(`ALTER TABLE myshop_live_events ADD COLUMN session_id TEXT NOT NULL DEFAULT ''`).run();}catch(e){}
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_events_session ON myshop_live_events(host_id,session_id,id DESC)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_comments (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,user_id TEXT NOT NULL,message TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_comment_ui (id INTEGER PRIMARY KEY CHECK(id=1),font_size INTEGER NOT NULL DEFAULT 15,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_comment_ui(id,font_size) VALUES(1,15)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_comment_global (id INTEGER PRIMARY KEY CHECK(id=1),style_json TEXT NOT NULL DEFAULT '{}',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_comment_global(id,style_json) VALUES(1,'{}')`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_comment_presets (preset_key TEXT PRIMARY KEY,badge TEXT NOT NULL,gender TEXT NOT NULL,preset_no INTEGER NOT NULL,style_json TEXT NOT NULL DEFAULT '{}',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_comment_assignments (user_id TEXT PRIMARY KEY,preset_key TEXT NOT NULL DEFAULT '',custom_style_json TEXT NOT NULL DEFAULT '{}',is_custom INTEGER NOT NULL DEFAULT 0,enabled INTEGER NOT NULL DEFAULT 1,source TEXT NOT NULL DEFAULT 'ADMIN',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  try{await env.DB.prepare(`ALTER TABLE myshop_live_comment_assignments ADD COLUMN source TEXT NOT NULL DEFAULT 'ADMIN'`).run();}catch(e){}
  const commentPresetSeeds=[
    ['VIP','MALE',['#3A237A','#243A88','#1F5C78','#5A2A79','#78411E']],['VIP','FEMALE',['#7E2A72','#8A2D64','#683A86','#A02F67','#744083']],
    ['VVIP','MALE',['#53206F','#3C286F','#6B224B','#332C83','#71334A']],['VVIP','FEMALE',['#8E145F','#A51A6D','#7D2788','#A62E73','#853379']],
    ['ROYAL','MALE',['#74510F','#67460B','#70591E','#5B4611','#805A13']],['ROYAL','FEMALE',['#8C5D26','#91612F','#7D5730','#9D6A34','#8B6335']],
    ['KING','MALE',['#083A8C','#0B4B8F','#173D78','#0F5689','#254A82']],['QUEEN','FEMALE',['#9C145F','#A51F70','#8B2A7D','#A13372','#903B82']]
  ];
  for(const [badge,gender,colors] of commentPresetSeeds){for(let i=0;i<5;i++){const key=`${badge}-${gender}-${i+1}`,bg=colors[i],accent=badge==='KING'?'#FFB62E':badge==='QUEEN'?'#FF4EB4':badge==='ROYAL'?'#A65BFF':badge==='VVIP'?'#34CDFF':badge==='VIP'?'#53E07E':gender==='FEMALE'?'#FF5DB1':'#A855F7';const st={backgroundColor:bg,textColor:'#FFFFFF',nameColor:'#FFD54F',levelColor:'#40D9FF',borderColor:accent,fontSize:17,fontWeight:'BOLD',borderWidth:2,cornerRadius:16,opacity:100,borderGlow:true,borderGlowColor:accent,borderGlowIntensity:60,backgroundGlow:false,animation:true,animationType:'PULSE',animationSpeed:55,boxAnimation:true,boxAnimationType:'PULSE',borderAnimation:true,borderAnimationType:'GLOW BORDER',textAnimation:false,textAnimationType:'FADE TEXT',nameAnimation:false,nameAnimationType:'SOFT GLOW',levelAnimation:false,levelAnimationType:'SOFT GLOW'};await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_comment_presets(preset_key,badge,gender,preset_no,style_json) VALUES(?,?,?,?,?)`).bind(key,badge,gender,i+1,JSON.stringify(st)).run();}}
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_listener_seen (host_id TEXT NOT NULL,started_at TEXT NOT NULL,user_id TEXT NOT NULL,PRIMARY KEY(host_id,started_at,user_id))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_history (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,title TEXT,topic TEXT,started_at TEXT,ended_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,duration_seconds INTEGER NOT NULL DEFAULT 0,peak_viewers INTEGER NOT NULL DEFAULT 0,total_listeners INTEGER NOT NULL DEFAULT 0,share_count INTEGER NOT NULL DEFAULT 0,react_count INTEGER NOT NULL DEFAULT 0,react_reward_coin INTEGER NOT NULL DEFAULT 0)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_themes (theme_key TEXT PRIMARY KEY,name TEXT NOT NULL,background_url TEXT NOT NULL DEFAULT '',accent TEXT NOT NULL DEFAULT '#8A2BE2',coin_price INTEGER NOT NULL DEFAULT 0,enabled INTEGER NOT NULL DEFAULT 1,sort_order INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  // V-300 recovery: migrate old production D1 safely BEFORE touching new theme columns.
  for(const sql of [
    `ALTER TABLE myshop_live_themes ADD COLUMN name TEXT NOT NULL DEFAULT 'Theme'`,
    `ALTER TABLE myshop_live_themes ADD COLUMN background_url TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_themes ADD COLUMN accent TEXT NOT NULL DEFAULT '#8A2BE2'`,
    `ALTER TABLE myshop_live_themes ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1`,
    `ALTER TABLE myshop_live_themes ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_themes ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_themes ADD COLUMN coin_price INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_themes ADD COLUMN fit_mode TEXT NOT NULL DEFAULT 'CENTER_CROP'`
  ]){try{await env.DB.prepare(sql).run();}catch(e){}}
  try{await env.DB.prepare(`UPDATE myshop_live_themes SET name=COALESCE(NULLIF(name,''),theme_key),background_url=COALESCE(background_url,''),accent=COALESCE(NULLIF(accent,''),'#8A2BE2'),coin_price=COALESCE(coin_price,0),enabled=COALESCE(enabled,1),sort_order=COALESCE(sort_order,0)`).run();}catch(e){}
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_themes(theme_key,name,background_url,accent,coin_price,enabled,sort_order) VALUES('GUITAR_BLUE','Guitar Blue','','#5B67FF',0,1,0)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_ui_settings (id INTEGER PRIMARY KEY CHECK(id=1),join_font_size REAL NOT NULL DEFAULT 18.0,join_text_color TEXT NOT NULL DEFAULT '#FFFFFF',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_ui_settings(id,join_font_size,join_text_color) VALUES(1,18.0,'#FFFFFF')`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_room_admins (host_id TEXT NOT NULL,user_id TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,user_id))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_room_admin_invites (host_id TEXT NOT NULL,user_id TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,user_id))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_reacts (host_id TEXT NOT NULL,session_id TEXT NOT NULL,user_id TEXT NOT NULL,react_count INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,session_id,user_id))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_seat_cooldowns (host_id TEXT NOT NULL,seat_no INTEGER NOT NULL,released_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,seat_no))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_sanctions (host_id TEXT NOT NULL,user_id TEXT NOT NULL,state TEXT NOT NULL DEFAULT 'NONE',reason TEXT NOT NULL DEFAULT '',updated_by TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,user_id))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_gifts (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('COIN','GOLD')),price INTEGER NOT NULL DEFAULT 1,category TEXT NOT NULL DEFAULT 'ALL',preview_url TEXT NOT NULL DEFAULT '',animation_url TEXT NOT NULL DEFAULT '',animation_mime TEXT NOT NULL DEFAULT '',animation_enabled INTEGER NOT NULL DEFAULT 1,sound_url TEXT NOT NULL DEFAULT '',sound_enabled INTEGER NOT NULL DEFAULT 1,sound_volume INTEGER NOT NULL DEFAULT 85,effect_duration_ms INTEGER NOT NULL DEFAULT 2800,sound_duration_ms INTEGER NOT NULL DEFAULT 2500,sound_trim_start_pct INTEGER NOT NULL DEFAULT 0,sound_trim_end_pct INTEGER NOT NULL DEFAULT 100,vat_percent INTEGER NOT NULL DEFAULT 10,board_position TEXT NOT NULL DEFAULT 'CENTER',animation_scale INTEGER NOT NULL DEFAULT 70,size_mode TEXT NOT NULL DEFAULT 'MEDIUM',catalog_animation_enabled INTEGER NOT NULL DEFAULT 1,catalog_animation_type TEXT NOT NULL DEFAULT 'AUTO',catalog_preview_size INTEGER NOT NULL DEFAULT 68,catalog_animation_strength INTEGER NOT NULL DEFAULT 42,catalog_animation_speed INTEGER NOT NULL DEFAULT 45,catalog_glow_particle INTEGER NOT NULL DEFAULT 35,catalog_loop INTEGER NOT NULL DEFAULT 1,catalog_animation_url TEXT NOT NULL DEFAULT '',sort_order INTEGER NOT NULL DEFAULT 100,enabled INTEGER NOT NULL DEFAULT 1,deleted INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_gift_events (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL,gift_id INTEGER NOT NULL,currency TEXT NOT NULL,price INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'COMPLETED',client_nonce TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  for(const sql of [
    `ALTER TABLE myshop_live_gifts ADD COLUMN category TEXT NOT NULL DEFAULT 'ALL'`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN animation_scale INTEGER NOT NULL DEFAULT 70`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN effect_duration_ms INTEGER NOT NULL DEFAULT 2800`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN sound_duration_ms INTEGER NOT NULL DEFAULT 2500`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN sound_trim_start_pct INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN sound_trim_end_pct INTEGER NOT NULL DEFAULT 100`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN vat_percent INTEGER NOT NULL DEFAULT 10`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN board_position TEXT NOT NULL DEFAULT 'CENTER'`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN catalog_animation_enabled INTEGER NOT NULL DEFAULT 1`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN catalog_animation_type TEXT NOT NULL DEFAULT 'AUTO'`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN catalog_preview_size INTEGER NOT NULL DEFAULT 68`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN catalog_animation_strength INTEGER NOT NULL DEFAULT 42`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN catalog_animation_speed INTEGER NOT NULL DEFAULT 45`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN catalog_glow_particle INTEGER NOT NULL DEFAULT 35`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN catalog_loop INTEGER NOT NULL DEFAULT 1`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN catalog_animation_url TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_gift_events ADD COLUMN client_nonce TEXT NOT NULL DEFAULT ''`
  ]){try{await env.DB.prepare(sql).run();}catch(e){}}
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_setting_history(id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,actor_id TEXT NOT NULL,previous_json TEXT NOT NULL,new_json TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_gift_transactions (host_id TEXT NOT NULL,session_id TEXT NOT NULL,sender_id TEXT NOT NULL,nonce TEXT NOT NULL,allowed INTEGER NOT NULL CHECK(allowed=1),response_json TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,session_id,sender_id,nonce))`).run();
  try{await env.DB.prepare(`CREATE UNIQUE INDEX IF NOT EXISTS idx_live_gift_nonce ON myshop_live_gift_events(host_id,session_id,sender_id,client_nonce) WHERE client_nonce<>''`).run();}catch(e){}
  // V-381: user-approved replacement Live Gift pack — exactly 20 Coin + 20 Diamond gifts.
  // This is a one-time SOFT replacement: old rows are disabled/deleted so transaction history stays intact.
  // Admin CRUD, pricing, position/reorder, sound upload/replace/trim/volume, animation controls and accounting remain unchanged.
  const v381GiftPack=[["Red Rose","COIN",10,"LOVE","MEDIUM",68,3900,3200,"PULSE",1],["Heart Pop","COIN",20,"LOVE","MEDIUM",68,3900,3200,"PULSE",2],["Love Letter","COIN",30,"LOVE","MEDIUM",66,3800,3200,"GLOW",3],["Teddy Bear","COIN",50,"FUN","MEDIUM",68,3900,3200,"PULSE",4],["Chocolate Box","COIN",60,"LOVE","MEDIUM",68,3900,3200,"GLOW",5],["Flower Bouquet","COIN",80,"LOVE","MEDIUM",70,4000,3300,"SPARKLE",6],["Balloon Blast","COIN",100,"FUN","LARGE",72,4200,3400,"GLOW",7],["Coffee Cup","COIN",120,"FUN","MEDIUM",68,3900,3200,"GLOW",8],["Cute Ring","COIN",150,"LOVE","LARGE",74,4300,3500,"SPARKLE",9],["Butterfly","COIN",180,"FANTASY","LARGE",74,4300,3500,"GLOW",10],["Sparkle Star","COIN",220,"EFFECTS","LARGE",76,4400,3500,"SPARKLE",11],["Rainbow","COIN",260,"FANTASY","LARGE",76,4400,3500,"GLOW",12],["Cute Cake","COIN",320,"FUN","LARGE",76,4400,3500,"PULSE",13],["Ice Cream","COIN",380,"FUN","LARGE",76,4400,3500,"GLOW",14],["Perfume","COIN",450,"LUXURY","LARGE",78,4500,3600,"SPARKLE",15],["Guitar Tune","COIN",600,"MUSIC","LARGE",78,4600,3600,"GLOW",16],["Magic Wand","COIN",800,"FANTASY","LARGE",80,4700,3700,"SPARKLE",17],["Firecracker","COIN",1000,"EFFECTS","LARGE",82,4800,3800,"SPARKLE",18],["Moon Light","COIN",1200,"FANTASY","LARGE",82,4800,3800,"GLOW",19],["Party Popper","COIN",1500,"EFFECTS","LARGE",84,4900,3900,"SPARKLE",20],["Red Rose Royal","GOLD",100,"LOVE","LARGE",88,5200,4400,"SPARKLE",1],["Diamond Ring","GOLD",150,"LUXURY","LARGE",88,5200,4400,"SPARKLE",2],["Golden Crown","GOLD",200,"ROYAL","LARGE",90,5300,4500,"SPARKLE",3],["Royal Throne","GOLD",300,"ROYAL","FULL_SCREEN",92,5400,4600,"GLOW",4],["Luxury Car","GOLD",500,"LUXURY","FULL_SCREEN",94,5600,4700,"GLOW",5],["Super Bike","GOLD",700,"LUXURY","FULL_SCREEN",94,5600,4700,"GLOW",6],["Private Jet","GOLD",1000,"LUXURY","FULL_SCREEN",96,5800,4800,"SPARKLE",7],["Yacht","GOLD",1200,"LUXURY","FULL_SCREEN",96,5800,4800,"GLOW",8],["Treasure Chest","GOLD",1500,"ROYAL","FULL_SCREEN",96,5900,4900,"SPARKLE",9],["Diamond Rain","GOLD",2000,"EFFECTS","FULL_SCREEN",98,6000,5000,"SPARKLE",10],["Fireworks Show","GOLD",2500,"EFFECTS","FULL_SCREEN",100,6200,5200,"SPARKLE",11],["Golden Dragon","GOLD",3000,"FANTASY","FULL_SCREEN",100,6300,5200,"SPARKLE",12],["Palace","GOLD",4000,"ROYAL","FULL_SCREEN",100,6400,5300,"GLOW",13],["Phoenix Fire","GOLD",5000,"FANTASY","FULL_SCREEN",100,6500,5400,"SPARKLE",14],["Angel Wings","GOLD",6000,"FANTASY","FULL_SCREEN",100,6500,5400,"GLOW",15],["Galaxy Love","GOLD",8000,"LOVE","FULL_SCREEN",100,6600,5500,"SPARKLE",16],["Golden Peacock","GOLD",10000,"ROYAL","FULL_SCREEN",100,6700,5500,"SPARKLE",17],["Lion King","GOLD",12000,"ROYAL","FULL_SCREEN",100,6800,5600,"GLOW",18],["Golden Elephant","GOLD",15000,"ROYAL","FULL_SCREEN",100,6800,5600,"GLOW",19],["Moon Palace","GOLD",20000,"ROYAL","FULL_SCREEN",100,7000,5800,"SPARKLE",20]];
  let v381GiftPackApplied=false;
  try{
    const meta=await env.DB.prepare(`SELECT value FROM myshop_schema_meta WHERE key='live_gift_catalog_pack'`).first();
    v381GiftPackApplied=String(meta?.value||'')==='V-381';
  }catch(e){}
  if(!v381GiftPackApplied){
    // Keep historical gift IDs/events, but remove every previous catalog item from the active catalog.
    await env.DB.prepare(`UPDATE myshop_live_gifts SET deleted=1,enabled=0,updated_at=CURRENT_TIMESTAMP WHERE COALESCE(deleted,0)=0`).run();
    for(const [name,currency,price,category,size,scale,effectMs,soundMs,catType,sortOrder] of v381GiftPack){
      await env.DB.prepare(`INSERT INTO myshop_live_gifts(name,currency,price,category,size_mode,sort_order,enabled,animation_enabled,sound_enabled,sound_volume,animation_scale,effect_duration_ms,sound_duration_ms,sound_trim_start_pct,sound_trim_end_pct,vat_percent,board_position,catalog_animation_enabled,catalog_animation_type,catalog_preview_size,catalog_animation_strength,catalog_animation_speed,catalog_glow_particle,catalog_loop,deleted) VALUES(?,?,?,?,?,?,1,1,1,?,?,?, ?,0,100,10,'CENTER',1,?,78,34,42,58,1,0)`).bind(name,currency,price,category,size,sortOrder,currency==='GOLD'?98:95,scale,effectMs,soundMs,catType).run();
    }
    await env.DB.prepare(`INSERT INTO myshop_schema_meta(key,value,updated_at) VALUES('live_gift_catalog_pack','V-381',CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value='V-381',updated_at=CURRENT_TIMESTAMP`).run();
  }

  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_global_bans (user_id TEXT PRIMARY KEY,reason TEXT NOT NULL DEFAULT '',permanent INTEGER NOT NULL DEFAULT 1,banned_by TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_finance_config (id INTEGER PRIMARY KEY CHECK(id=1),platform_fee_percent REAL NOT NULL DEFAULT 10.0,vat_percent REAL NOT NULL DEFAULT 0,highlight_comment_coin_price INTEGER NOT NULL DEFAULT 1000,coin_units_per_600_taka INTEGER NOT NULL DEFAULT 100000,updated_by TEXT NOT NULL DEFAULT '0001',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  // V-317 production-safe finance migration: old D1 databases may predate coin_units_per_600_taka.
  for(const sql of [
    `ALTER TABLE myshop_finance_config ADD COLUMN platform_fee_percent REAL NOT NULL DEFAULT 10.0`,
    `ALTER TABLE myshop_finance_config ADD COLUMN vat_percent REAL NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_finance_config ADD COLUMN highlight_comment_coin_price INTEGER NOT NULL DEFAULT 1000`,
    `ALTER TABLE myshop_finance_config ADD COLUMN coin_units_per_600_taka INTEGER NOT NULL DEFAULT 100000`,
    `ALTER TABLE myshop_finance_config ADD COLUMN updated_by TEXT NOT NULL DEFAULT '0001'`,
    `ALTER TABLE myshop_finance_config ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''`
  ]){try{await env.DB.prepare(sql).run();}catch(e){}}
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_finance_config(id,platform_fee_percent,highlight_comment_coin_price,coin_units_per_600_taka,updated_by) VALUES(1,10.0,1000,100000,'0001')`).run();
  try{await env.DB.prepare(`UPDATE myshop_finance_config SET coin_units_per_600_taka=COALESCE(coin_units_per_600_taka,100000),platform_fee_percent=COALESCE(platform_fee_percent,10.0),highlight_comment_coin_price=COALESCE(highlight_comment_coin_price,1000) WHERE id=1`).run();}catch(e){}
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_name_policy (user_id TEXT PRIMARY KEY,live_name TEXT NOT NULL,changed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_value_ledger (id INTEGER PRIMARY KEY AUTOINCREMENT,tx_type TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('COIN','GOLD')),sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL DEFAULT '',host_id TEXT NOT NULL DEFAULT '',gift_id INTEGER NOT NULL DEFAULT 0,gross_amount INTEGER NOT NULL,fee_percent REAL NOT NULL DEFAULT 0,fee_amount INTEGER NOT NULL DEFAULT 0,vat_percent REAL NOT NULL DEFAULT 0,vat_amount INTEGER NOT NULL DEFAULT 0,net_amount INTEGER NOT NULL DEFAULT 0,platform_amount INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'COMPLETED',reference TEXT NOT NULL DEFAULT '',metadata TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  try{await env.DB.prepare(`ALTER TABLE myshop_value_ledger ADD COLUMN vat_percent REAL NOT NULL DEFAULT 0`).run();}catch(e){}
  try{await env.DB.prepare(`ALTER TABLE myshop_value_ledger ADD COLUMN vat_amount INTEGER NOT NULL DEFAULT 0`).run();}catch(e){}
  await ensureAgencyFinance(env.DB);
  await ensureLevelSchema(env);
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_value_ledger_sender ON myshop_value_ledger(sender_id,created_at,id)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_value_ledger_receiver ON myshop_value_ledger(receiver_id,created_at,id)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_value_ledger_host ON myshop_value_ledger(host_id,created_at,id)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_highlight_comments (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,user_id TEXT NOT NULL,message TEXT NOT NULL,coin_cost INTEGER NOT NULL DEFAULT 0,free_privilege INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'QUEUED',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_moderation_audit (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,actor_id TEXT NOT NULL,target_id TEXT NOT NULL,action TEXT NOT NULL,reason TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_mute_records (host_id TEXT NOT NULL,user_id TEXT NOT NULL,muted_by TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,user_id))`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_mute_records_host ON myshop_live_mute_records(host_id,updated_at)`).run();
  // V-375 legacy recovery: import old persisted MUTED sanctions before session cleanup,
  // so users muted by earlier builds remain visible in Profile -> Muted Users and can be unmuted normally.
  try{await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_mute_records(host_id,user_id,muted_by,created_at,updated_at) SELECT host_id,user_id,COALESCE(updated_by,''),updated_at,updated_at FROM myshop_live_sanctions WHERE state='MUTED'`).run();}catch(e){}
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_entry_events (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,user_id TEXT NOT NULL,tier TEXT NOT NULL DEFAULT 'STANDARD',item_code TEXT NOT NULL DEFAULT '',animation_url TEXT NOT NULL DEFAULT '',animation_mime TEXT NOT NULL DEFAULT '',sound_url TEXT NOT NULL DEFAULT '',sound_volume INTEGER NOT NULL DEFAULT 90,effect_duration_ms INTEGER NOT NULL DEFAULT 3500,sound_duration_ms INTEGER NOT NULL DEFAULT 3000,animation_speed INTEGER NOT NULL DEFAULT 55,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  for(const sql of [
    `ALTER TABLE myshop_live_entry_events ADD COLUMN item_code TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_entry_events ADD COLUMN animation_url TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_entry_events ADD COLUMN animation_mime TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_entry_events ADD COLUMN sound_url TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_entry_events ADD COLUMN sound_volume INTEGER NOT NULL DEFAULT 90`,
    `ALTER TABLE myshop_live_entry_events ADD COLUMN effect_duration_ms INTEGER NOT NULL DEFAULT 3500`,
    `ALTER TABLE myshop_live_entry_events ADD COLUMN sound_duration_ms INTEGER NOT NULL DEFAULT 3000`,
    `ALTER TABLE myshop_live_entry_events ADD COLUMN animation_speed INTEGER NOT NULL DEFAULT 55`
  ]){try{await env.DB.prepare(sql).run();}catch(_){}}
  for(const sql of [
    `ALTER TABLE myshop_live_room_meta ADD COLUMN pinned_until TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN slow_mode_seconds INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN entry_effects_enabled INTEGER NOT NULL DEFAULT 1`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN gift_combo_enabled INTEGER NOT NULL DEFAULT 1`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN react_count INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN react_reward_milestone INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN react_window_started_at TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN session_id TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_requests ADD COLUMN session_id TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_comments ADD COLUMN session_id TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_comments ADD COLUMN client_nonce TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_highlight_comments ADD COLUMN session_id TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_themes ADD COLUMN coin_price INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_history ADD COLUMN react_count INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_history ADD COLUMN react_reward_coin INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_history ADD COLUMN session_id TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_gift_events ADD COLUMN quantity INTEGER NOT NULL DEFAULT 1`,
    `ALTER TABLE myshop_live_gift_events ADD COLUMN session_id TEXT NOT NULL DEFAULT ''`
  ]){try{await env.DB.prepare(sql).run();}catch(e){}}
  try{await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_comments_session ON myshop_live_comments(host_id,session_id,id)`).run();}catch(e){}
  try{await env.DB.prepare(`CREATE UNIQUE INDEX IF NOT EXISTS idx_live_comments_nonce ON myshop_live_comments(host_id,session_id,user_id,client_nonce) WHERE client_nonce<>''`).run();}catch(e){}
  try{await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_highlights_session ON myshop_live_highlight_comments(host_id,session_id,id)`).run();}catch(e){}
  try{await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_gifts_session ON myshop_live_gift_events(host_id,session_id,id)`).run();}catch(e){}
  try{await env.DB.prepare(`CREATE UNIQUE INDEX IF NOT EXISTS idx_live_gift_nonce ON myshop_live_gift_events(host_id,session_id,sender_id,client_nonce) WHERE client_nonce<>''`).run();}catch(e){}
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_fan_club (host_id TEXT NOT NULL,user_id TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,points INTEGER NOT NULL DEFAULT 0,joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,user_id))`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_fan_club_host ON myshop_live_fan_club(host_id,active,points)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_schedules (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,title TEXT NOT NULL,topic TEXT NOT NULL DEFAULT '',scheduled_at TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'SCHEDULED',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_schedules_host ON myshop_live_schedules(host_id,status,scheduled_at)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_reminders (schedule_id INTEGER NOT NULL,user_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(schedule_id,user_id))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_pk_rounds (id INTEGER PRIMARY KEY AUTOINCREMENT,host_a TEXT NOT NULL,host_b TEXT NOT NULL,session_a TEXT NOT NULL DEFAULT '',session_b TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',started_at TEXT,ended_at TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_pk_hosts ON myshop_live_pk_rounds(host_a,host_b,status,created_at)`).run();
  await env.DB.batch([
    env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_v596_viewer_seen ON myshop_live_viewers(host_id,datetime(last_seen))`),
    env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_v596_listener_started ON myshop_live_listener_seen(host_id,started_at)`),
    env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_v596_history_session ON myshop_live_history(host_id,session_id)`),
    env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_v596_coin_purchased ON myshop_coin_transactions(user_id,status,kind,amount)`),
    env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_v596_owned_frame ON myshop_owned_items(user_id,equipped,item_type,id)`),
    env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_v596_gift_session ON myshop_live_gift_events(host_id,status,session_id,created_at)`),
    env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_v596_badge_user ON myshop_user_badges(user_id,status,id)`)
  ]);

}
const liveSchemaInitByEnv = new WeakMap();
async function ensureLiveRoomSchema(env){
  let p=liveSchemaInitByEnv.get(env.DB);
  if(!p){
    p=ensureLiveRoomSchemaImpl(env).catch(e=>{ liveSchemaInitByEnv.delete(env.DB); throw e; });
    liveSchemaInitByEnv.set(env.DB,p);
  }
  return p;
}
async function liveSanctionFor(env,hostId,userId){
  const r=await env.DB.prepare(`SELECT state FROM myshop_live_sanctions WHERE host_id=? AND user_id=?`).bind(hostId,userId).first();
  return String(r?.state||'NONE').toUpperCase();
}
async function isRoomAdmin(env,hostId,userId){
  if(hostId===userId)return true;
  const r=await env.DB.prepare(`SELECT active FROM myshop_live_room_admins WHERE host_id=? AND user_id=?`).bind(hostId,userId).first();
  return Number(r?.active||0)===1;
}
async function livePermissionSet(env,actor,hostId){
 const all={view:true,mute:true,unmute:true,kick:true,block:true,unblock:true,invite:true,requests:true,pin:true,room_admin:true,settings:true,end:true};
 if(actor.user_id===hostId||isAdminUser(actor))return all;
 const current=await env.DB.prepare('SELECT active,role FROM myshop_auth_users_v108 WHERE user_id=?').bind(actor.user_id).first();
 if(Number(current?.active)!==1)return Object.fromEntries(Object.keys(all).map(k=>[k,false]));
 if(String(current.role).toUpperCase()==='MODERATOR'){
  all.room_admin=false;all.requests=false;all.end=false;
  const table=await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='myshop_folder_grants'").first();
  if(table){const rows=(await env.DB.prepare("SELECT action,enabled FROM myshop_folder_grants WHERE user_id=? AND folder='feature_live_streaming'").bind(actor.user_id).all()).results||[];for(const row of rows)if(Object.hasOwn(all,row.action))all[row.action]=Number(row.enabled)===1;}
  if(!all.view)for(const key of Object.keys(all))all[key]=false;
  return all;
 }
 const room=await isRoomAdmin(env,hostId,actor.user_id);
 return {...all,view:room,mute:room,unmute:room,kick:false,block:room,unblock:room,invite:room,requests:false,pin:room,room_admin:false,settings:room,end:false};
}
async function hasLivePermission(env,actor,hostId,action){return Boolean((await livePermissionSet(env,actor,hostId))[action]);}
async function liveModerationAction(request,env){
  const actor=await getUser(request,env); if(!actor)return json({error:'UNAUTHORIZED'},401,cors); await ensureLiveRoomSchema(env);
  const b=await body(request),hostId=String(b.hostId||'').trim(),uid=String(b.userId||'').trim(),action=String(b.action||'').toUpperCase();
  if(!isFourDigit(hostId)||!isFourDigit(uid)||uid===hostId)return json({error:'INVALID_TARGET'},400,cors);
  if(['ACCEPT_ROOM_ADMIN','DECLINE_ROOM_ADMIN'].includes(action)){
    if(uid!==actor.user_id)return json({error:'FORBIDDEN'},403,cors);const inv=await env.DB.prepare(`SELECT status FROM myshop_live_room_admin_invites WHERE host_id=? AND user_id=?`).bind(hostId,uid).first();if(!inv||String(inv.status)!=='PENDING')return json({error:'ADMIN_INVITE_NOT_PENDING'},409,cors);
    if(action==='DECLINE_ROOM_ADMIN'){await env.DB.prepare(`UPDATE myshop_live_room_admin_invites SET status='DECLINED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=?`).bind(hostId,uid).run();await liveHubDirtyForHost(env,hostId,'ROOM_ADMIN_DECLINED');return json({ok:true,status:'DECLINED'},200,cors);}
    const c=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_room_admins WHERE host_id=? AND active=1`).bind(hostId).first();if(Number(c?.c||0)>=5)return json({error:'ROOM_ADMIN_LIMIT'},409,cors);
    await env.DB.prepare(`INSERT INTO myshop_live_room_admins(host_id,user_id,active) VALUES(?,?,1) ON CONFLICT(host_id,user_id) DO UPDATE SET active=1`).bind(hostId,uid).run();await env.DB.prepare(`UPDATE myshop_live_room_admin_invites SET status='ACCEPTED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=?`).bind(hostId,uid).run();await recordModerationAudit(env,hostId,hostId,uid,'ADD_ROOM_ADMIN_ACCEPTED');await liveHubDirtyForHost(env,hostId,'ROOM_ADMIN_ACCEPTED');return json({ok:true,status:'ACCEPTED'},200,cors);
  }
  if(['ACCEPT_CALL_SUGGESTION','DECLINE_CALL_SUGGESTION'].includes(action)){
    if(actor.user_id!==hostId)return json({error:'HOST_ONLY'},403,cors);const sug=await env.DB.prepare(`SELECT admin_id,user_id,session_id,status FROM myshop_live_call_suggestions WHERE host_id=? AND user_id=? AND status='PENDING' ORDER BY created_at ASC LIMIT 1`).bind(hostId,uid).first();if(!sug)return json({error:'CALL_SUGGESTION_NOT_PENDING'},409,cors);
    if(action==='DECLINE_CALL_SUGGESTION'){await env.DB.prepare(`UPDATE myshop_live_call_suggestions SET status='DECLINED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND admin_id=? AND user_id=? AND session_id=?`).bind(hostId,sug.admin_id,uid,sug.session_id).run();await liveHubDirty(env,hostId,sug.session_id,'CALL_SUGGESTION_DECLINED');return json({ok:true,status:'DECLINED'},200,cors);}
    await env.DB.prepare(`UPDATE myshop_live_call_suggestions SET status='ACCEPTED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND admin_id=? AND user_id=? AND session_id=?`).bind(hostId,sug.admin_id,uid,sug.session_id).run();
    await env.DB.prepare(`INSERT INTO myshop_live_invites(host_id,user_id,session_id,status,expires_at,created_at,updated_at,invited_by) VALUES(?,?,?,'PENDING',datetime('now','+90 seconds'),CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,?) ON CONFLICT(host_id,user_id,session_id) DO UPDATE SET status='PENDING',expires_at=datetime('now','+90 seconds'),updated_at=CURRENT_TIMESTAMP,invited_by=excluded.invited_by`).bind(hostId,uid,sug.session_id,sug.admin_id).run();
    const target=await env.DB.prepare(`SELECT full_name FROM myshop_auth_users_v108 WHERE user_id=?`).bind(uid).first();const admin=await env.DB.prepare(`SELECT full_name FROM myshop_auth_users_v108 WHERE user_id=?`).bind(sug.admin_id).first();await createUserNotification(env,uid,'Live Call Suggestion Accepted',(actor.full_name||'Host')+' accepted '+(admin?.full_name||'Admin')+' suggestion. Join the live call?','LIVE_CALL_INVITE',sug.admin_id,hostId);await liveHubDirty(env,hostId,sug.session_id,'CALL_SUGGESTION_ACCEPTED');return json({ok:true,status:'INVITED'},200,cors);
  }
  const hostActor=actor.user_id===hostId, roomAdmin=await isRoomAdmin(env,hostId,actor.user_id), globalAdmin=isAdminUser(actor), globalModerator=String(actor.role||'').toUpperCase()==='MODERATOR'||await isAssignedModerator(env,actor.user_id);
  const permissionKey={MUTE:'mute',UNMUTE:'unmute',KICK:'kick',BLOCK:'block',UNBLOCK:'unblock',ADD_ROOM_ADMIN:'room_admin',REMOVE_ROOM_ADMIN:'room_admin',END:'end'}[action];
  if(permissionKey&&!(await hasLivePermission(env,actor,hostId,permissionKey)))return json({error:'LIVE_PERMISSION_REQUIRED',action:permissionKey},403,cors);
  if(action==='END'){const result=await closeLive(env.DB,hostId);if(!result.closed)return json({error:'LIVE_END_NOT_CONFIRMED'},409,cors);invalidatePublicAggregates(env.DB,hostId);liveEphemeralClear(hostId,result.sessionId);if(result.sessionId)await liveHubClear(env,hostId,result.sessionId);await recordModerationAudit(env,hostId,actor.user_id,hostId,'END');return json(result,200,cors);}
  if(['MUTE','UNMUTE'].includes(action)){
    if(!(hostActor||roomAdmin||globalAdmin||globalModerator))return json({error:'FORBIDDEN'},403,cors);
    if(action==='MUTE'){
      // V-375: mute is a persistent audio-only moderator state. It never blocks comments,
      // viewer visibility or host call invitations, and it can be reversed from Live or Profile.
      await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state='MUTED'`).bind(hostId,uid).run();
      await env.DB.prepare(`INSERT INTO myshop_live_mute_records(host_id,user_id,muted_by,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id) DO UPDATE SET muted_by=excluded.muted_by,updated_at=CURRENT_TIMESTAMP`).bind(hostId,uid,actor.user_id).run();
      await env.DB.prepare(`UPDATE myshop_live_seats_dynamic SET muted=1,mic_on=0,speaking=0,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND seat_no>1`).bind(hostId,uid).run();
    } else {
      // Legacy builds persisted MUTED in myshop_live_sanctions. Always clear that stale state, even if the user is audience now.
      await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state='MUTED'`).bind(hostId,uid).run();
      await env.DB.prepare(`UPDATE myshop_live_seats_dynamic SET muted=0,mic_on=1,speaking=0,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND seat_no>1`).bind(hostId,uid).run();
      await env.DB.prepare(`DELETE FROM myshop_live_mute_records WHERE host_id=? AND user_id=?`).bind(hostId,uid).run();
    }
    await recordModerationAudit(env,hostId,actor.user_id,uid,action); await liveHubDirtyForHost(env,hostId,'MODERATION_'+action); return json({ok:true,state:action==='MUTE'?'MUTED':'NONE'},200,cors);
  }
  if(roomAdmin&&!hostActor&&!globalAdmin&&!globalModerator&&!['BLOCK','UNBLOCK'].includes(action))return json({error:'ROOM_ADMIN_ACTION_FORBIDDEN'},403,cors);
  if(action==='KICK'){
    if(!(hostActor||globalAdmin||globalModerator))return json({error:'FORBIDDEN'},403,cors);
    await env.DB.prepare(`INSERT INTO myshop_live_sanctions(host_id,user_id,state,updated_by,updated_at) VALUES(?,?,'KICKED',?,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id) DO UPDATE SET state='KICKED',updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP`).bind(hostId,uid,actor.user_id).run();
    await env.DB.prepare(`DELETE FROM myshop_live_viewers WHERE host_id=? AND user_id=?`).bind(hostId,uid).run(); await env.DB.prepare(`DELETE FROM myshop_live_seats_dynamic WHERE host_id=? AND user_id=? AND seat_no>1`).bind(hostId,uid).run();
    await recordModerationAudit(env,hostId,actor.user_id,uid,'KICK'); await liveHubDirtyForHost(env,hostId,'MODERATION_KICK'); return json({ok:true,state:'KICKED'},200,cors);
  }
  if(['BLOCK','UNBLOCK'].includes(action)){
    if(!(hostActor||roomAdmin||globalAdmin||globalModerator))return json({error:'FORBIDDEN'},403,cors);
    if(action==='BLOCK'){
      await env.DB.prepare(`INSERT INTO myshop_live_sanctions(host_id,user_id,state,updated_by,updated_at) VALUES(?,?,'BLOCKED',?,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id) DO UPDATE SET state='BLOCKED',updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP`).bind(hostId,uid,actor.user_id).run();
      if(actor.user_id===hostId){await ensureFriendSchema(env);await env.DB.prepare(`INSERT OR IGNORE INTO myshop_user_blocks(blocker_id,blocked_id) VALUES(?,?)`).bind(hostId,uid).run();}
      await env.DB.prepare(`DELETE FROM myshop_live_viewers WHERE host_id=? AND user_id=?`).bind(hostId,uid).run(); await env.DB.prepare(`DELETE FROM myshop_live_seats_dynamic WHERE host_id=? AND user_id=? AND seat_no>1`).bind(hostId,uid).run();
    } else {
      await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state='BLOCKED'`).bind(hostId,uid).run();
      if(actor.user_id===hostId){await ensureFriendSchema(env);await env.DB.prepare(`DELETE FROM myshop_user_blocks WHERE blocker_id=? AND blocked_id=?`).bind(hostId,uid).run();}
    }
    await recordModerationAudit(env,hostId,actor.user_id,uid,action); await liveHubDirtyForHost(env,hostId,'MODERATION_'+action); return json({ok:true,state:action==='BLOCK'?'BLOCKED':'NONE'},200,cors);
  }
  if(['ADD_ROOM_ADMIN','REMOVE_ROOM_ADMIN'].includes(action)){
    if(!(hostActor||globalAdmin||globalModerator))return json({error:'HOST_ONLY'},403,cors);
    if(action==='ADD_ROOM_ADMIN'){
      const c=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_room_admins WHERE host_id=? AND active=1`).bind(hostId).first();if(Number(c?.c||0)>=5)return json({error:'ROOM_ADMIN_LIMIT'},409,cors);
      const present=await env.DB.prepare(`SELECT 1 ok FROM myshop_live_viewers WHERE host_id=? AND user_id=? AND datetime(last_seen)>=datetime('now','-25 seconds')`).bind(hostId,uid).first();if(!present)return json({error:'USER_NOT_IN_LIVE'},409,cors);
      await env.DB.prepare(`INSERT INTO myshop_live_room_admin_invites(host_id,user_id,status,created_at,updated_at) VALUES(?,?,'PENDING',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id) DO UPDATE SET status='PENDING',created_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP`).bind(hostId,uid).run();
      await liveHubDirtyForHost(env,hostId,'ROOM_ADMIN_INVITED');return json({ok:true,status:'PENDING_ACCEPTANCE'},200,cors);
    } else {await env.DB.prepare(`UPDATE myshop_live_room_admins SET active=0 WHERE host_id=? AND user_id=?`).bind(hostId,uid).run();await env.DB.prepare(`UPDATE myshop_live_room_admin_invites SET status='REVOKED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=?`).bind(hostId,uid).run();}
    await recordModerationAudit(env,hostId,actor.user_id,uid,action);await liveHubDirtyForHost(env,hostId,'ROOM_ADMIN_'+action);return json({ok:true},200,cors);
  }
  if(action==='PERMANENT_BAN'){
    if(!(await isFixedMainAdminId(actor.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);
    await env.DB.prepare(`INSERT INTO myshop_global_bans(user_id,banned_by) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET banned_by=excluded.banned_by,created_at=CURRENT_TIMESTAMP`).bind(uid,actor.user_id).run();
    await env.DB.prepare(`UPDATE myshop_auth_users_v108 SET active=0 WHERE user_id=? AND user_id NOT IN ('0001','0002','0003')`).bind(uid).run();
    await recordModerationAudit(env,hostId,actor.user_id,uid,'PERMANENT_BAN'); await liveHubDirtyForHost(env,hostId,'PERMANENT_BAN'); return json({ok:true,permanent:true},200,cors);
  }
  return json({error:'UNSUPPORTED_ACTION'},400,cors);
}
async function isFixedMainAdminId(userId){return ['0001','0002','0003'].includes(String(userId||''));}
async function isAssignedModerator(env,userId){
  const r=await env.DB.prepare(`SELECT active FROM myshop_moderators_v108 WHERE user_id=?`).bind(String(userId||'')).first();
  return Number(r?.active||0)===1;
}
async function financeConfig(env,feature='GIFT'){
  await ensureLiveRoomSchema(env);
  await schemaOnce(env.DB,'finance-columns',async()=>{
  for(const sql of [`ALTER TABLE myshop_finance_config ADD COLUMN highlight_host_share_enabled INTEGER NOT NULL DEFAULT 0`,`ALTER TABLE myshop_finance_config ADD COLUMN highlight_host_share_percent REAL NOT NULL DEFAULT 0`]){try{await env.DB.prepare(sql).run();}catch(_) {}}
  for(const column of ['coin_commission_percent','gold_commission_percent']){try{await env.DB.prepare(`ALTER TABLE myshop_finance_config ADD COLUMN ${column} REAL`).run();}catch(_) {}}
  });
  const r=await env.DB.prepare(`SELECT coin_commission_percent,gold_commission_percent,platform_fee_percent,vat_percent,highlight_comment_coin_price,coin_units_per_600_taka,highlight_host_share_enabled,highlight_host_share_percent FROM myshop_finance_config WHERE id=1`).first();
  const managed=await readCommission(env.DB);
  return {commissionConfig:managed.config,coinCommissionPercent:effectiveCommission(managed.config,'COIN',feature,Number(r?.coin_commission_percent??10)),goldCommissionPercent:effectiveCommission(managed.config,'GOLD',feature,Number(r?.gold_commission_percent??5)),feePercent:Math.max(0,Math.min(100,Number(r?.platform_fee_percent||0))),vatPercent:0,highlightPrice:Math.max(0,Number(r?.highlight_comment_coin_price??1000)),highlightHostShareEnabled:Number(r?.highlight_host_share_enabled||0)===1,highlightHostSharePercent:Math.max(0,Math.min(100,Number(r?.highlight_host_share_percent||0))),unitsPer600Taka:Math.max(10000,Number(r?.coin_units_per_600_taka||100000)),liveNameEarlyChangePrice:0};
}
function commissionRate(cfg,currency){return currency==='GOLD'?cfg.goldCommissionPercent:cfg.coinCommissionPercent;}
function splitPlatformFee(gross,pct){const g=Math.max(0,Math.floor(Number(gross||0)));const fee=Math.max(0,Math.min(g,Math.round(g*Number(pct||0)/100)));return {gross:g,fee,net:g-fee};}
function calcVat(base,pct){const amount=Math.max(0,Math.floor(Number(base||0)));const rate=Math.max(0,Math.min(100,Number(pct||0)));return Math.max(0,Math.round(amount*rate/100));}
function starCountFor(currency,units){const divisor=String(currency).toUpperCase()==='GOLD'?1000:100000;return Math.max(0,Math.floor(Number(units||0)/divisor));}
async function applyStarsAndLevels(env,{txType,currency,senderId='',receiverId,units=0,official=false,reference=''}){
  await reconcileLevelProgress(env,receiverId);
  const cur=String(currency||'COIN').toUpperCase()==='GOLD'?'GOLD':'COIN', amount=Math.max(0,Math.floor(Number(units||0)));
  if(!receiverId||amount<=0)return {stars:0,levelAdded:0};
  const col=official?(cur==='GOLD'?'official_gold_units':'official_coin_units'):(cur==='GOLD'?'normal_gold_units':'normal_coin_units');
  const threshold=cur==='GOLD'?1000:100000;
  const beforeRow=await env.DB.prepare(`SELECT ${col} units FROM myshop_user_progress WHERE user_id=?`).bind(receiverId).first();
  const before=Math.max(0,Number(beforeRow?.units||0)),after=before+amount;
  const starThreshold=cur==='GOLD'?1000:100000;
  const stars=Math.max(0,Math.floor(after/starThreshold)-Math.floor(before/starThreshold));
  const levelUnits=Math.max(0,Math.floor(after/threshold)-Math.floor(before/threshold));
  const levelAdded=(await isFixedMainAdminId(receiverId))?0:levelUnits*(official?2:1);
  await env.DB.prepare(`UPDATE myshop_user_progress SET ${col}=?,stars=stars+?,level=level+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(after,stars,levelAdded,receiverId).run();
  await env.DB.prepare(`INSERT INTO myshop_star_level_ledger(tx_type,currency,sender_id,receiver_id,units,stars,level_added,official,reference) VALUES(?,?,?,?,?,?,?,?,?)`).bind(txType,cur,senderId,receiverId,amount,stars,levelAdded,official?1:0,reference).run();
  return {stars,levelAdded};
}

async function walletSourceState(env,userId,currency){
  const cur=String(currency||'COIN').toUpperCase()==='GOLD'?'GOLD':'COIN',wallet=cur==='GOLD'?'myshop_gold_wallets':'myshop_coin_wallets';
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_wallet_sources (user_id TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('COIN','GOLD')),official_balance INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,currency))`).run();
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_wallet_sources(user_id,currency,official_balance) VALUES(?,?,0)`).bind(userId,cur).run();
  await env.DB.prepare(`INSERT OR IGNORE INTO ${wallet}(user_id,balance) VALUES(?,0)`).bind(userId).run();
  const w=await env.DB.prepare(`SELECT balance FROM ${wallet} WHERE user_id=?`).bind(userId).first(),src=await env.DB.prepare(`SELECT official_balance FROM myshop_wallet_sources WHERE user_id=? AND currency=?`).bind(userId,cur).first();
  const total=Math.max(0,Number(w?.balance||0)),rawOfficial=Math.max(0,Number(src?.official_balance||0)),official=Math.min(total,rawOfficial);
  if(official!==rawOfficial)await env.DB.prepare(`UPDATE myshop_wallet_sources SET official_balance=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND currency=?`).bind(official,userId,cur).run();
  return {currency:cur,wallet,total,official,normal:Math.max(0,total-official)};
}
async function creditOfficialWalletSource(env,userId,currency,amount){
  const cur=String(currency||'COIN').toUpperCase()==='GOLD'?'GOLD':'COIN',n=Math.max(0,Math.floor(Number(amount||0)));if(!n)return;
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_wallet_sources (user_id TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('COIN','GOLD')),official_balance INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,currency))`).run();
  await env.DB.prepare(`INSERT INTO myshop_wallet_sources(user_id,currency,official_balance,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id,currency) DO UPDATE SET official_balance=official_balance+excluded.official_balance,updated_at=CURRENT_TIMESTAMP`).bind(userId,cur,n).run();
}

async function currentTier(env,userId){
  const r=await env.DB.prepare(`SELECT badge_code FROM myshop_user_badges WHERE user_id=? AND status='ACTIVE' AND (expires_at IS NULL OR datetime(expires_at)>datetime('now')) AND badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP') ORDER BY CASE badge_code WHEN 'KING' THEN 1 WHEN 'QUEEN' THEN 1 WHEN 'ROYAL' THEN 2 WHEN 'VVIP' THEN 3 WHEN 'VIP' THEN 4 ELSE 9 END LIMIT 1`).bind(userId).first();
  return String(r?.badge_code||'STANDARD');
}
async function recordModerationAudit(env,hostId,actorId,targetId,action,reason=''){
  await env.DB.prepare(`INSERT INTO myshop_live_moderation_audit(host_id,actor_id,target_id,action,reason) VALUES(?,?,?,?,?)`).bind(hostId,actorId,targetId,action,String(reason||'').slice(0,180)).run();
}
async function liveHighlightConfig(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);const c=await financeConfig(env);const free=(await isFixedMainAdminId(me.user_id))||(await isAssignedModerator(env,me.user_id));return json({ok:true,coinPrice:c.highlightPrice,free},200,cors);
}
async function liveHighlightComment(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||'').trim(),message=String(b.message||'').trim().slice(0,180);if(!isFourDigit(hostId)||!message)return json({error:'INVALID_HIGHLIGHT_COMMENT'},400,cors);
  const messageHash=await sha256(message);
  const retryId=String(b.requestId||'').trim();let priorPayment=null;if(retryId){try{priorPayment=await env.DB.prepare(`SELECT * FROM myshop_highlight_payments WHERE request_id=?`).bind(retryId).first();}catch(e){if(!String(e).includes('no such table'))throw e;}}
  if(priorPayment){if(priorPayment.sender_id!==me.user_id||priorPayment.host_id!==hostId||priorPayment.message_hash!==messageHash)return json({error:'REQUEST_ID_CONFLICT'},409,cors);if(priorPayment.status==='DELIVERED')return json({ok:true,duplicate:true,coinCost:priorPayment.amount,totalCost:priorPayment.amount},200,cors);}
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  const sanction=await liveSanctionFor(env,hostId,me.user_id);if(sanction==='MUTED')await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state='MUTED'`).bind(hostId,me.user_id).run();if(['BLOCKED','KICKED'].includes(sanction))return json({error:'LIVE_NOT_ALLOWED'},403,cors);
  const cfg=await financeConfig(env),free=(await isFixedMainAdminId(me.user_id))||(await isAssignedModerator(env,me.user_id));let cost=priorPayment?Number(priorPayment.amount):(free?0:cfg.highlightPrice),vat=0,totalCost=cost;
  const readySession=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();if(!readySession?.session_id)return json({error:'LIVE_SESSION_NOT_READY'},409,cors);
  const paymentKey=String(b.requestId||'').trim();
  if(cost>0){
    if(!/^[A-Za-z0-9_-]{16,100}$/.test(paymentKey))return json({error:'HIGHLIGHT_REQUEST_ID_REQUIRED'},400,cors);
    const senderSource=await walletSourceState(env,me.user_id,'COIN');await walletSourceState(env,hostId,'COIN');
    await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_highlight_payments(request_id TEXT PRIMARY KEY,sender_id TEXT NOT NULL,host_id TEXT NOT NULL,amount INTEGER NOT NULL,official_amount INTEGER NOT NULL,host_amount INTEGER NOT NULL,message_hash TEXT NOT NULL,session_id TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
    await env.DB.prepare(`CREATE TRIGGER IF NOT EXISTS myshop_highlight_payment_atomic AFTER INSERT ON myshop_highlight_payments BEGIN
      SELECT CASE WHEN COALESCE((SELECT balance FROM myshop_coin_wallets WHERE user_id=NEW.sender_id),0)<NEW.amount THEN RAISE(ABORT,'INSUFFICIENT_COIN_BALANCE') END;
      UPDATE myshop_coin_wallets SET balance=balance-NEW.amount,updated_at=CURRENT_TIMESTAMP WHERE user_id=NEW.sender_id;
      UPDATE myshop_wallet_sources SET official_balance=MAX(0,official_balance-NEW.official_amount),updated_at=CURRENT_TIMESTAMP WHERE user_id=NEW.sender_id AND currency='COIN';
    END`).run();
    await env.DB.prepare(`CREATE TRIGGER IF NOT EXISTS myshop_highlight_payment_complete AFTER UPDATE OF status ON myshop_highlight_payments WHEN NEW.status='DELIVERED' AND OLD.status='PENDING' BEGIN
      UPDATE myshop_coin_wallets SET balance=balance+NEW.host_amount,updated_at=CURRENT_TIMESTAMP WHERE user_id=NEW.host_id;
      INSERT INTO myshop_coin_transactions(user_id,kind,amount,reference,status,metadata) VALUES(NEW.sender_id,'HIGHLIGHT_COMMENT',-NEW.amount,NEW.request_id,'COMPLETED','{}');
      INSERT INTO myshop_coin_transactions(user_id,kind,amount,reference,status,metadata) SELECT NEW.host_id,'HIGHLIGHT_HOST_INCOME',NEW.host_amount,NEW.request_id,'COMPLETED','{}' WHERE NEW.host_amount>0;
      INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,host_id,gross_amount,fee_percent,fee_amount,vat_percent,vat_amount,net_amount,platform_amount,reference,metadata) VALUES('HIGHLIGHT_COMMENT','COIN',NEW.sender_id,NEW.host_id,NEW.host_id,NEW.amount,100.0*(NEW.amount-NEW.host_amount)/NEW.amount,NEW.amount-NEW.host_amount,0,0,NEW.host_amount,NEW.amount-NEW.host_amount,NEW.request_id,'{}');
    END`).run();
    await env.DB.prepare(`CREATE TRIGGER IF NOT EXISTS myshop_highlight_payment_refund AFTER DELETE ON myshop_highlight_payments WHEN OLD.status='PENDING' BEGIN
      UPDATE myshop_coin_wallets SET balance=balance+OLD.amount WHERE user_id=OLD.sender_id;
      UPDATE myshop_wallet_sources SET official_balance=official_balance+OLD.official_amount WHERE user_id=OLD.sender_id AND currency='COIN';
    END`).run();
    const existing=await env.DB.prepare(`SELECT * FROM myshop_highlight_payments WHERE request_id=?`).bind(paymentKey).first();
    if(existing){
      if(existing.sender_id!==me.user_id||existing.host_id!==hostId||existing.message_hash!==messageHash||existing.session_id!==readySession.session_id)return json({error:'REQUEST_ID_CONFLICT'},409,cors);
      if(existing.status==='DELIVERED')return json({ok:true,duplicate:true,coinCost:existing.amount,totalCost:existing.amount},200,cors);
      cost=Number(existing.amount);totalCost=cost;
    }else{
      const hostShare=cfg.highlightHostShareEnabled?Math.floor(cost*cfg.highlightHostSharePercent/100):0;
      try{await env.DB.prepare(`INSERT INTO myshop_highlight_payments(request_id,sender_id,host_id,amount,official_amount,host_amount,message_hash,session_id) VALUES(?,?,?,?,?,?,?,?)`).bind(paymentKey,me.user_id,hostId,cost,Math.min(cost,senderSource.official),hostShare,messageHash,readySession.session_id).run();}
      catch(e){if(String(e).includes('INSUFFICIENT_COIN_BALANCE'))return json({error:'INSUFFICIENT_COIN_BALANCE',required:cost},409,cors);if(String(e).includes('UNIQUE'))return json({error:'HIGHLIGHT_PENDING',message:'Retry with the same request ID.'},409,cors);throw e;}
    }
  }
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first(),sessionId=String(meta?.session_id||'');
  if(!sessionId)return json({error:'LIVE_SESSION_NOT_READY'},409,cors);
  const baseItem={request_id:paymentKey,user_id:me.user_id,message,coin_cost:cost,free_privilege:free?1:0,created_at:new Date().toISOString(),full_name:me.full_name||me.user_id,avatar_url:me.avatar_url||'',gender:me.gender||'UNSPECIFIED'};
  let item=null;try{const pushed=await liveHubPush(env,hostId,sessionId,'HIGHLIGHT',baseItem);if(pushed?.item)item=pushed.item;}catch(e){}
  if(item)liveEphemeralPush(liveEphemeralHighlights,liveEphemeralKey(hostId,sessionId),{...item,_ts:Date.now()},20,12000);
  else{if(cost>0)await env.DB.prepare(`DELETE FROM myshop_highlight_payments WHERE request_id=? AND status='PENDING'`).bind(paymentKey).run();return json({error:'REALTIME_DELIVERY_FAILED',message:'Highlight not delivered; no Coin charged. Retry with the same request ID.'},503,cors);}
  if(cost>0)await env.DB.prepare(`UPDATE myshop_highlight_payments SET status='DELIVERED' WHERE request_id=?`).bind(paymentKey).run();
  return json({ok:true,id:Number(item.id||0),coinCost:cost,totalCost,free,ephemeral:true,realtime:true,sessionId,comment:item,animation:{direction:'RIGHT_TO_LEFT',placement:'MIDDLE',queue:true}},201,cors);
}
async function userVerificationSchema(env){await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_user_verification(user_id TEXT PRIMARY KEY,verified INTEGER NOT NULL DEFAULT 0,updated_by TEXT,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,expires_at TEXT)`).run();const cols=new Set(((await env.DB.prepare(`PRAGMA table_info(myshop_user_verification)`).all()).results||[]).map(x=>String(x.name)));if(!cols.has('expires_at'))await env.DB.prepare(`ALTER TABLE myshop_user_verification ADD COLUMN expires_at TEXT`).run();}
async function userVerification(request,env){const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await userVerificationSchema(env);if(request.method==='GET'){const ids=[...new Set(String(new URL(request.url).searchParams.get('ids')||'').split(',').filter(isFourDigit))].slice(0,100);const users=[];for(const id of ids){const r=await env.DB.prepare(`SELECT verified,expires_at FROM myshop_user_verification WHERE user_id=?`).bind(id).first();const expiry=String(r?.expires_at||'');const expiryMs=expiry?Date.parse(expiry.includes('T')?expiry:expiry.replace(' ','T')+'Z'):0;const permanent=['0001','0002','0003'].includes(id),active=permanent||(Number(r?.verified)===1&&(!expiry||expiryMs>Date.now()));users.push({userId:id,verified:active,expiresAt:permanent?'':expiry});}return json({ok:true,users},200,{...cors,'cache-control':'no-store'});}if(!isAdminUser(me))return json({error:'ADMIN_ONLY'},403,cors);const b=await body(request),id=String(b.userId||'');if(!isFourDigit(id)||typeof b.verified!=='boolean')return json({error:'INVALID_VERIFICATION'},400,cors);if(['0001','0002','0003'].includes(id)&&!b.verified)return json({error:'AUTHORITY_BADGE_PERMANENT'},409,cors);const exists=await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=?`).bind(id).first();if(!exists)return json({error:'USER_NOT_FOUND'},404,cors);let expiresAt=null;if(b.verified){const days=Math.trunc(Number(b.expiresInDays||30));if(!Number.isFinite(days)||days<1||days>3650)return json({error:'INVALID_EXPIRY_DAYS'},400,cors);expiresAt=new Date(Date.now()+days*86400000).toISOString();}await env.DB.prepare(`INSERT INTO myshop_user_verification(user_id,verified,updated_by,expires_at) VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET verified=excluded.verified,updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP,expires_at=excluded.expires_at`).bind(id,b.verified?1:0,me.user_id,expiresAt).run();await ensureLiveRoomSchema(env);await recordModerationAudit(env,'',me.user_id,id,b.verified?'BLUE_BADGE_GRANT':'BLUE_BADGE_REVOKE');return json({ok:true,userId:id,verified:b.verified,expiresAt},200,cors);}
async function miniAdsSchema(env){await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_mini_ads(scope TEXT PRIMARY KEY,revision INTEGER NOT NULL DEFAULT 0,payload TEXT NOT NULL,previous_payload TEXT,updated_by TEXT,updated_at TEXT DEFAULT CURRENT_TIMESTAMP)`).run();await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_mini_ad_events(scope TEXT,card_id TEXT,user_id TEXT,event TEXT,day TEXT,PRIMARY KEY(scope,card_id,user_id,event,day))`).run();}
async function headlineStripSchema(env){await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_headline_strips(scope TEXT PRIMARY KEY,revision INTEGER NOT NULL DEFAULT 0,payload TEXT NOT NULL,previous_payload TEXT,updated_by TEXT,updated_at TEXT DEFAULT CURRENT_TIMESTAMP)`).run();}
async function overlayPlacementSchema(env){await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_overlay_placements(kind TEXT PRIMARY KEY,revision INTEGER NOT NULL DEFAULT 0,payload TEXT NOT NULL,updated_by TEXT)`).run();}
async function overlaySource(env,kind,target){await overlayPlacementSchema(env);const r=await env.DB.prepare(`SELECT * FROM myshop_overlay_placements WHERE kind=?`).bind(kind).first();return r?JSON.parse(r.payload)[target]||target:target;}
async function overlayPlacements(request,env){const me=await getUser(request,env);if(!me||!isAdminUser(me))return json({error:'ADMIN_ONLY'},403,cors);const write=request.method==='POST',b=write?await body(request):{},kind=String(write?b.kind:new URL(request.url).searchParams.get('kind'));if(!['mini','headline'].includes(kind))return json({error:'INVALID_KIND'},400,cors);await overlayPlacementSchema(env);const old=await env.DB.prepare(`SELECT * FROM myshop_overlay_placements WHERE kind=?`).bind(kind).first(),mapping=old?JSON.parse(old.payload):{},revision=Number(old?.revision||0);if(!write)return json({ok:true,revision,mapping},200,cors);if(Number(b.revision)!==revision)return json({error:'REVISION_CONFLICT'},409,cors);const scopes=['home','live','shop','live_room'],source=String(b.source);if(!scopes.includes(source)||!Array.isArray(b.targets)||b.targets.some(t=>!scopes.includes(t)))return json({error:'INVALID_SCOPE'},400,cors);if(mapping[source])return json({error:'SOURCE_USES_ANOTHER_PAGE'},409,cors);const table=kind==='mini'?'myshop_mini_ads':'myshop_headline_strips';const config=await env.DB.prepare(`SELECT * FROM ${table} WHERE scope=?`).bind(source).first();if(!config)return json({error:'SAVE_SOURCE_FIRST'},409,cors);for(const target of scopes){if(mapping[target]===source&&!b.targets.includes(target))delete mapping[target];if(target!==source&&b.targets.includes(target))mapping[target]=source;}for(const target of scopes)if(mapping[target]&&mapping[mapping[target]])return json({error:'CIRCULAR_PLACEMENT'},409,cors);if(old){const r=await env.DB.prepare(`UPDATE myshop_overlay_placements SET payload=?,revision=?,updated_by=? WHERE kind=? AND revision=?`).bind(JSON.stringify(mapping),revision+1,me.user_id,kind,revision).run();if(!r.meta?.changes)return json({error:'REVISION_CONFLICT'},409,cors);}else{try{await env.DB.prepare(`INSERT INTO myshop_overlay_placements(kind,revision,payload,updated_by) VALUES(?,?,?,?)`).bind(kind,1,JSON.stringify(mapping),me.user_id).run();}catch(_){return json({error:'REVISION_CONFLICT'},409,cors);}}return json({ok:true,revision:revision+1,mapping},200,cors);}
const panelDesignScopes=['home_quick','home_general','live_discover','shop','withdrawal','home_support'];
async function panelDesign(request,env){
 const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);
 const write=request.method==='POST';if(write&&!isAdminUser(me))return json({error:'ADMIN_ONLY'},403,cors);
 const b=write?await body(request):{},scope=String(write?b.scope:new URL(request.url).searchParams.get('scope'));
 if(!panelDesignScopes.includes(scope))return json({error:'INVALID_SCOPE'},400,cors);
 await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_panel_designs(scope TEXT PRIMARY KEY,revision INTEGER NOT NULL DEFAULT 0,payload TEXT NOT NULL,updated_by TEXT,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
 const old=await env.DB.prepare(`SELECT * FROM myshop_panel_designs WHERE scope=?`).bind(scope).first();
 if(!write)return json({ok:true,scope,revision:Number(old?.revision||0),...(old?JSON.parse(old.payload):{background:scope==='shop'?'#E8F5FF':['home_quick','home_general','live_discover'].includes(scope)?'#291B3D':'#FFFFFF',template:1,qrUrl:'',supportLink:'https://wa.me/8801860626700'})},200,cors);
 if(Number(b.revision)!==Number(old?.revision||0))return json({error:'REVISION_CONFLICT'},409,cors);
 if(!/^#[0-9a-f]{6}$/i.test(String(b.background))||!Number.isInteger(b.template)||b.template<1||b.template>20)return json({error:'INVALID_DESIGN'},400,cors);
 const qrUrl=String(b.qrUrl||'');if(qrUrl&&!/^https:\/\//i.test(qrUrl))return json({error:'HTTPS_REQUIRED'},400,cors);
 const supportLink=String(b.supportLink||'https://wa.me/8801860626700');let link;try{link=new URL(supportLink);}catch(_){return json({error:'INVALID_SUPPORT_LINK'},400,cors);}if(link.protocol!=='https:'||!['wa.me','api.whatsapp.com','www.whatsapp.com','chat.whatsapp.com'].includes(link.hostname))return json({error:'INVALID_SUPPORT_LINK'},400,cors);
 const value={background:String(b.background).toUpperCase(),template:b.template,qrUrl:qrUrl.slice(0,2048),supportLink:supportLink.slice(0,2048)},revision=Number(old?.revision||0)+1;
 if(old){const updated=await env.DB.prepare(`UPDATE myshop_panel_designs SET payload=?,revision=?,updated_by=?,updated_at=CURRENT_TIMESTAMP WHERE scope=? AND revision=?`).bind(JSON.stringify(value),revision,me.user_id,scope,Number(b.revision)).run();if(!updated.meta?.changes)return json({error:'REVISION_CONFLICT'},409,cors);}else{try{await env.DB.prepare(`INSERT INTO myshop_panel_designs(scope,revision,payload,updated_by) VALUES(?,?,?,?)`).bind(scope,revision,JSON.stringify(value),me.user_id).run();}catch(_){return json({error:'REVISION_CONFLICT'},409,cors);}}
 return json({ok:true,scope,revision,...value},200,cors);
}

async function headlineStripRead(request,env){const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);const u=new URL(request.url),scope=u.searchParams.get('scope');if(!['home','live','shop','live_room'].includes(scope))return json({error:'INVALID_SCOPE'},400,cors);const admin=u.searchParams.get('admin')==='1';if(admin&&!isAdminUser(me))return json({error:'ADMIN_ONLY'},403,cors);await headlineStripSchema(env);const row=await env.DB.prepare(`SELECT * FROM myshop_headline_strips WHERE scope=?`).bind(scope).first();const data=row?JSON.parse(row.payload):{enabled:false,animate:true,flashEnabled:true,layers:[]};if(!admin){const source=await overlaySource(env,"headline",scope);if(source!==scope){const shared=await env.DB.prepare(`SELECT * FROM myshop_headline_strips WHERE scope=?`).bind(source).first();if(shared){const content=JSON.parse(shared.payload);data.layers=content.layers;data.enabled=content.enabled;data.sourceScope=source;}}}return json({ok:true,...data,scope,revision:Number(row?.revision||0)},200,cors);}
async function headlineStripSave(request,env){const me=await getUser(request,env);if(!me||!isAdminUser(me))return json({error:'ADMIN_ONLY'},403,cors);await headlineStripSchema(env);const b=await body(request),scope=String(b.scope||'');if(!['home','live','shop','live_room'].includes(scope))return json({error:'INVALID_SCOPE'},400,cors);const old=await env.DB.prepare(`SELECT * FROM myshop_headline_strips WHERE scope=?`).bind(scope).first();if(Number(b.revision)!==Number(old?.revision||0))return json({error:'REVISION_CONFLICT'},409,cors);if(b.restore){if(!old?.previous_payload)return json({error:'NO_PREVIOUS_SETTINGS'},409,cors);const payload=old.previous_payload,rev=Number(old.revision||0)+1;await env.DB.prepare(`UPDATE myshop_headline_strips SET payload=?,previous_payload=?,revision=?,updated_by=?,updated_at=CURRENT_TIMESTAMP WHERE scope=?`).bind(payload,old.payload,rev,me.user_id,scope).run();return json({ok:true,scope,revision:rev,...JSON.parse(payload)},200,cors);}if(!Array.isArray(b.layers)||b.layers.length>20)return json({error:'INVALID_LAYERS'},400,cors);const ids=new Set(),layers=[];for(const x of b.layers){const id=String(x.id||'');const size=Number(x.size||14),position=Number(x.position??0.5),pause=Number(x.pauseSeconds||0);if(!/^[A-Za-z0-9_-]{1,80}$/.test(id)||ids.has(id)||!String(x.text||'').trim()||!Number.isInteger(size)||size<10||size>24||!Number.isFinite(position)||position<0||position>1||!Number.isFinite(pause)||pause<0||pause>30)return json({error:'INVALID_HEADLINE_LAYER'},400,cors);for(const color of [x.textColor||'#FFFFFF',x.backgroundColor||'#31205B'])if(!/^#[0-9a-f]{6}$/i.test(String(color)))return json({error:'INVALID_COLOR'},400,cors);if(x.yPosition!=null&&(!Number.isFinite(Number(x.yPosition))||Number(x.yPosition)<0||Number(x.yPosition)>1))return json({error:'INVALID_HEADLINE_POSITION'},400,cors);ids.add(id);layers.push({...(x.yPosition!=null?{yPosition:Number(x.yPosition)}:{}),id,text:String(x.text).trim().slice(0,180),textColor:String(x.textColor||'#FFFFFF').toUpperCase(),backgroundColor:String(x.backgroundColor||'#31205B').toUpperCase(),size,position,pauseSeconds:pause,enabled:x.enabled!==false});}const data={enabled:!!b.enabled,animate:b.animate!==false,flashEnabled:b.flashEnabled!==false,layers};const revision=Number(old?.revision||0)+1;await env.DB.prepare(`INSERT INTO myshop_headline_strips(scope,revision,payload,previous_payload,updated_by) VALUES(?,?,?,?,?) ON CONFLICT(scope) DO UPDATE SET revision=excluded.revision,previous_payload=myshop_headline_strips.payload,payload=excluded.payload,updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP`).bind(scope,revision,JSON.stringify(data),old?.payload||null,me.user_id).run();return json({ok:true,scope,revision,...data},200,cors);}
async function miniAdsRead(request,env){const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await miniAdsSchema(env);const u=new URL(request.url),scope=u.searchParams.get('scope');if(!['home','live','shop','live_room'].includes(scope))return json({error:'INVALID_SCOPE'},400,cors);const admin=u.searchParams.get('admin')==='1';if(admin&&!isAdminUser(me))return json({error:'ADMIN_ONLY'},403,cors);const row=await env.DB.prepare(`SELECT * FROM myshop_mini_ads WHERE scope=?`).bind(scope).first();const data=row?JSON.parse(row.payload):{enabled:false,x:scope==='live_room'?1:.68,y:scope==='live_room'?.19:.65,cards:[]};if(!admin){const source=await overlaySource(env,"mini",scope);if(source!==scope){const shared=await env.DB.prepare(`SELECT * FROM myshop_mini_ads WHERE scope=?`).bind(source).first();if(shared){const content=JSON.parse(shared.payload);data.cards=content.cards;data.enabled=content.enabled;data.sourceScope=source;}}const now=Date.now();data.cards=data.cards.filter(c=>c.enabled!==false&&(!c.startsAt||Date.parse(c.startsAt)<=now)&&(!c.endsAt||Date.parse(c.endsAt)>now));}else{data.metrics=(await env.DB.prepare(`SELECT card_id,event,COUNT(*) total FROM myshop_mini_ad_events WHERE scope=? GROUP BY card_id,event`).bind(scope).all()).results||[];}return json({ok:true,...data,scope,revision:Number(row?.revision||0)},200,cors);}
async function miniAdsSave(request,env){const me=await getUser(request,env);if(!me||!isAdminUser(me))return json({error:'ADMIN_ONLY'},403,cors);await miniAdsSchema(env);const b=await body(request),scope=String(b.scope||'');if(!['home','live','shop','live_room'].includes(scope))return json({error:'INVALID_SCOPE'},400,cors);const row=await env.DB.prepare(`SELECT * FROM myshop_mini_ads WHERE scope=?`).bind(scope).first();if(Number(b.revision)!==Number(row?.revision||0))return json({error:'REVISION_CONFLICT'},409,cors);let data;if(b.restore){if(!row?.previous_payload)return json({error:'NO_PREVIOUS_SETTINGS'},409,cors);data=JSON.parse(row.previous_payload);}else{if(!Array.isArray(b.cards)||b.cards.length>20)return json({error:'MAX_20_CARDS'},400,cors);const colors=['#123B9A','#6332C9','#ED2788','#079BB6','#128358','#C46C13','#563524','#152047','#05070D','#63B5E8','#6D4C41','#4E342E','#FF7A24','#E9447A','#00A896','#7B2CBF','#2D6A4F','#D4A017','#34495E','#F1F4F9'];const ids=new Set();const cards=[];for(const c of b.cards){const id=String(c.id||'');const template=Number(c.template||1),validityDays=Number(c.validityDays||30);if(!/^[a-zA-Z0-9_-]{1,80}$/.test(id)||ids.has(id)||!Number.isInteger(c.seconds)||c.seconds<1||c.seconds>5||!Number.isInteger(template)||template<1||template>20||!Number.isInteger(validityDays)||validityDays<1||validityDays>3650)return json({error:'INVALID_CARD'},400,cors);ids.add(id);for(const value of [c.imageUrl,c.link])if(value&&!/^https:\/\//i.test(String(value)))return json({error:'HTTPS_LINK_REQUIRED'},400,cors);for(const date of [c.startsAt,c.endsAt])if(date&&!Number.isFinite(Date.parse(date)))return json({error:'INVALID_DATE'},400,cors);cards.push({id,title:String(c.title||'').slice(0,60),caption:String(c.caption||'').slice(0,120),imageUrl:String(c.imageUrl||'').slice(0,2048),link:String(c.link||'').slice(0,2048),color:/^#[0-9a-f]{6}$/i.test(String(c.color||''))?String(c.color).toUpperCase():colors[0],seconds:c.seconds,template,validityDays,animationEnabled:c.animationEnabled!==false,flashEnabled:c.flashEnabled!==false,enabled:c.enabled!==false,startsAt:String(c.startsAt||''),endsAt:String(c.endsAt||'')});}data={enabled:!!b.enabled,x:Math.max(0,Math.min(1,Number(b.x)||0)),y:Math.max(0,Math.min(1,Number(b.y)||0)),cards};}
const payload=JSON.stringify(data),revision=Number(row?.revision||0)+1;if(row){const r=await env.DB.prepare(`UPDATE myshop_mini_ads SET previous_payload=payload,payload=?,revision=?,updated_by=?,updated_at=CURRENT_TIMESTAMP WHERE scope=? AND revision=?`).bind(payload,revision,me.user_id,scope,Number(b.revision)).run();if(!r.meta?.changes)return json({error:'REVISION_CONFLICT'},409,cors);}else{try{await env.DB.prepare(`INSERT INTO myshop_mini_ads(scope,payload,revision,updated_by) VALUES(?,?,?,?)`).bind(scope,payload,revision,me.user_id).run();}catch(e){return json({error:'REVISION_CONFLICT'},409,cors);}}await ensureLiveRoomSchema(env);await recordModerationAudit(env,'',me.user_id,'','MINI_ADS_'+scope);return json({ok:true,revision},200,cors);}
async function miniAdEvent(request,env){const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await miniAdsSchema(env);const b=await body(request);if(!['VIEW','CLICK'].includes(b.event))return json({error:'INVALID_EVENT'},400,cors);const source=await overlaySource(env,"mini",String(b.scope));const row=await env.DB.prepare(`SELECT payload FROM myshop_mini_ads WHERE scope=?`).bind(source).first();if(!row||!JSON.parse(row.payload).cards.some(c=>c.id===b.cardId))return json({error:'CARD_NOT_FOUND'},404,cors);await env.DB.prepare(`INSERT OR IGNORE INTO myshop_mini_ad_events(scope,card_id,user_id,event,day) VALUES(?,?,?,?,date('now'))`).bind(b.scope,b.cardId,me.user_id,b.event).run();return json({ok:true},200,cors);}

async function liveGiftSummary(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const u=new URL(request.url),hostId=String(u.searchParams.get('hostId')||'').trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();let sessionId=String(meta?.session_id||'');if(!sessionId){const h=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_history WHERE host_id=? ORDER BY id DESC LIMIT 1`).bind(hostId).first();sessionId=String(h?.session_id||'');}
  const recent=(await env.DB.prepare(`SELECT e.id,e.sender_id,e.receiver_id,e.currency,e.price,e.created_at,g.name gift_name,u.full_name FROM myshop_live_gift_events e LEFT JOIN myshop_live_gifts g ON g.id=e.gift_id LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id WHERE e.host_id=? AND e.status='COMPLETED' AND (?='' OR e.session_id=?) ORDER BY e.id DESC LIMIT 50`).bind(hostId,sessionId,sessionId).all()).results||[];
  const top=(await env.DB.prepare(`SELECT e.sender_id,u.full_name,u.avatar_url,SUM(CASE WHEN e.currency='GOLD' THEN e.price*100 ELSE e.price END) total_value,SUM(CASE WHEN e.currency='COIN' THEN e.price ELSE 0 END) coin_value,SUM(CASE WHEN e.currency='GOLD' THEN e.price ELSE 0 END) gold_value,SUM(COALESCE(e.quantity,1)) gift_count FROM myshop_live_gift_events e LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id WHERE e.host_id=? AND e.sender_id<>e.host_id AND e.status='COMPLETED' GROUP BY e.sender_id ORDER BY total_value DESC,MAX(CASE WHEN e.price>0 THEN e.id ELSE 0 END) ASC,e.sender_id ASC LIMIT 20`).bind(hostId).all()).results||[];
  const myRank=await env.DB.prepare(`SELECT * FROM (SELECT sender_id,SUM(CASE WHEN currency='COIN' THEN price ELSE 0 END) coin_value,SUM(CASE WHEN currency='GOLD' THEN price ELSE 0 END) gold_value,ROW_NUMBER() OVER(ORDER BY SUM(CASE WHEN currency='GOLD' THEN price*100 ELSE price END) DESC,MAX(CASE WHEN price>0 THEN id ELSE 0 END) ASC,sender_id ASC) rank FROM myshop_live_gift_events WHERE host_id=? AND sender_id<>host_id AND status='COMPLETED' GROUP BY sender_id) WHERE sender_id=?`).bind(hostId,me.user_id).first();return json({ok:true,sessionId,recent,myRank,topSupporters:top.map((x,i)=>({...x,rank:i+1}))},200,cors);
}
async function userValueHistory(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const rows=(await env.DB.prepare(`SELECT id,tx_type,currency,sender_id,receiver_id,host_id,gift_id,gross_amount,fee_percent,fee_amount,net_amount,status,reference,created_at FROM myshop_value_ledger WHERE sender_id=? OR receiver_id=? ORDER BY id DESC LIMIT 200`).bind(me.user_id,me.user_id).all()).results||[];return json({ok:true,transactions:rows},200,cors);
}
async function adminFinanceSummary(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);await ensureLiveRoomSchema(env);const totals=await env.DB.prepare(`SELECT COALESCE(SUM(gross_amount),0) gross,COALESCE(SUM(fee_amount),0) fees,COALESCE(SUM(net_amount),0) net,COUNT(*) tx_count FROM myshop_value_ledger WHERE status='COMPLETED'`).first();const sold=await env.DB.prepare(`SELECT COALESCE(SUM(CASE WHEN amount>0 AND status='COMPLETED' AND kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN amount ELSE 0 END),0) coin_sold FROM myshop_coin_transactions`).first();const recent=(await env.DB.prepare(`SELECT * FROM myshop_value_ledger ORDER BY id DESC LIMIT 300`).all()).results||[];const starLevel=(await env.DB.prepare(`SELECT * FROM myshop_star_level_ledger ORDER BY id DESC LIMIT 300`).all()).results||[];const cfg=await financeConfig(env);return json({ok:true,config:cfg,starLevel,totals:{gross:Number(totals?.gross||0),fees:Number(totals?.fees||0),net:Number(totals?.net||0),transactions:Number(totals?.tx_count||0),coinSold:Number(sold?.coin_sold||0)},recent},200,cors);
}
async function adminFinanceConfig(request,env){
 const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);await ensureLiveRoomSchema(env);if(request.method==='GET')return json({ok:true,...await financeConfig(env)},200,cors);
 const b=await body(request),old=await financeConfig(env),coin=Number(b.coinCommissionPercent??old.coinCommissionPercent),gold=Number(b.goldCommissionPercent??old.goldCommissionPercent),fee=Number(b.platformFeePercent??old.feePercent),vat=Number(b.vatPercent??old.vatPercent),price=Number(b.highlightCommentCoinPrice??old.highlightPrice),shareEnabled=b.highlightHostShareEnabled===undefined?old.highlightHostShareEnabled:b.highlightHostShareEnabled===true,sharePercent=Number(b.highlightHostSharePercent??old.highlightHostSharePercent);
 if(![coin,gold,fee,vat,price,sharePercent].every(Number.isFinite)||coin!==10||gold!==5||fee<0||fee>100||vat<0||vat>100||!Number.isSafeInteger(price)||price<0||price>100000000||sharePercent<0||sharePercent>100)return json({error:'INVALID_FINANCE_SETTINGS'},400,cors);
 await env.DB.prepare(`UPDATE myshop_finance_config SET coin_commission_percent=?,gold_commission_percent=?,platform_fee_percent=?,vat_percent=?,highlight_comment_coin_price=?,highlight_host_share_enabled=?,highlight_host_share_percent=?,updated_by=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`).bind(coin,gold,fee,vat,price,shareEnabled?1:0,sharePercent,me.user_id).run();
 return json({ok:true,coinCommissionPercent:coin,goldCommissionPercent:gold,platformFeePercent:fee,vatPercent:vat,highlightCommentCoinPrice:price,highlightHostShareEnabled:shareEnabled,highlightHostSharePercent:sharePercent},200,cors);
}
async function liveValueTransfer(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
  const b=await body(request),to=String(b.receiverId||'').trim(),currency=String(b.currency||'COIN').toUpperCase(),gross=Math.max(1,Math.floor(Number(b.amount||0)));
  if(!isFourDigit(to)||to===me.user_id||!['COIN','GOLD'].includes(currency))return json({error:'INVALID_TRANSFER'},400,cors);
  const exists=await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1`).bind(to).first();if(!exists)return json({error:'USER_NOT_FOUND'},404,cors);
  await reconcileLevelProgress(env,to);const adminSender=await isFixedMainAdminId(me.user_id),src=await walletSourceState(env,me.user_id,currency),cfg=await financeConfig(env,'TRANSFER');
  const officialPrincipal=adminSender?gross:Math.min(gross,src.official),normalPrincipal=Math.max(0,gross-officialPrincipal),officialDebit=officialPrincipal,commissionPercent=commissionRate(cfg,currency),commission=Math.round(normalPrincipal*commissionPercent/100),net=gross,vat=0,totalDebit=gross+commission;
  if(src.total<totalDebit)return json({error:'INSUFFICIENT_BALANCE',baseAmount:gross,commissionAmount:commission,required:totalDebit},409,cors);
  await env.DB.prepare(`INSERT OR IGNORE INTO ${src.wallet}(user_id,balance) VALUES(?,0)`).bind(to).run();
  const batch=[
    env.DB.prepare(`UPDATE ${src.wallet} SET balance=balance-?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(totalDebit,me.user_id),
    env.DB.prepare(`UPDATE ${src.wallet} SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(net,to),
    env.DB.prepare(`UPDATE myshop_wallet_sources SET official_balance=MAX(0,official_balance-?),updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND currency=?`).bind(officialDebit,me.user_id,currency),
    env.DB.prepare(`INSERT INTO myshop_wallet_sources(user_id,currency,official_balance,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id,currency) DO UPDATE SET official_balance=official_balance+excluded.official_balance,updated_at=CURRENT_TIMESTAMP`).bind(to,currency,officialPrincipal),
    env.DB.prepare(`INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,gross_amount,fee_percent,fee_amount,vat_percent,vat_amount,net_amount,platform_amount,reference,metadata) VALUES('TRANSFER',?,?,?,?,?,?,?,?,?,?, 'USER_TRANSFER',?)`).bind(currency,me.user_id,to,gross,normalPrincipal>0?commissionPercent:0,commission,cfg.vatPercent,vat,net,commission+vat,JSON.stringify({commissionLabel:'MY SHOP Commission',officialSpend:officialPrincipal,normalSpend:normalPrincipal,vatPercent:cfg.vatPercent,vatAmount:vat,totalDebit}))
  ];
  const progressRef='TRANSFER#'+crypto.randomUUID();
  if(officialPrincipal>0)batch.push(...giftProgressStatements(env.DB,{txType:'TRANSFER',currency,senderId:me.user_id,receiverId:to,units:officialPrincipal,official:true,reference:progressRef+'#OFFICIAL'}));
  if(normalPrincipal>0)batch.push(...giftProgressStatements(env.DB,{txType:'TRANSFER',currency,senderId:me.user_id,receiverId:to,units:normalPrincipal,official:false,reference:progressRef+'#NORMAL'}));
  const r=await env.DB.batch(batch);
  const progress=await env.DB.prepare('SELECT COALESCE(SUM(stars),0) stars,COALESCE(SUM(level_added),0) levelAdded FROM myshop_star_level_ledger WHERE receiver_id=? AND reference IN (?,?)').bind(to,progressRef+'#OFFICIAL',progressRef+'#NORMAL').first();
  const stars=Number(progress?.stars||0),levelAdded=Number(progress?.levelAdded||0);
  return json({ok:true,id:Number(r?.[4]?.meta?.last_row_id||0),reference:'MY_SHOP_TRANSFER',gross,feePercent:normalPrincipal>0?commissionPercent:0,feeAmount:commission,vatPercent:cfg.vatPercent,vatAmount:vat,totalDebit,netAmount:net,officialAmount:officialPrincipal,unofficialAmount:normalPrincipal,commissionLabel:'MY SHOP Commission',stars,levelAdded},201,cors);
}
async function liveModerationAudit(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!isModeratorUser(me))return json({error:'MODERATOR_REQUIRED'},403,cors);await ensureLiveRoomSchema(env);const hostId=String(new URL(request.url).searchParams.get('hostId')||'').trim();const admin=isAdminUser(me);const rows=(await env.DB.prepare(`SELECT * FROM myshop_live_moderation_audit WHERE (?='' OR host_id=?) AND (?=1 OR actor_id=?) ORDER BY id DESC LIMIT 300`).bind(hostId,hostId,admin?1:0,me.user_id).all()).results||[];return json({ok:true,audit:rows,scope:admin?'ALL':'MY_ACTIONS'},200,cors);
}

async function liveGiftCatalog(request,env){
  const me=await getUser(request,env); if(!me)return json({error:'UNAUTHORIZED'},401,cors); await ensureLiveRoomSchema(env);
  const c=await env.DB.prepare(`SELECT balance FROM myshop_coin_wallets WHERE user_id=?`).bind(me.user_id).first(),g=await env.DB.prepare(`SELECT balance FROM myshop_gold_wallets WHERE user_id=?`).bind(me.user_id).first();
  const cfg=await financeConfig(env);
  const rows=(await env.DB.prepare(`SELECT * FROM myshop_live_gifts WHERE enabled=1 AND COALESCE(deleted,0)=0 ORDER BY currency,sort_order,id LIMIT 100`).all()).results||[];
  const cs=await walletSourceState(env,me.user_id,'COIN'),gs=await walletSourceState(env,me.user_id,'GOLD');return json({ok:true,coinBalance:Number(c?.balance||0),goldBalance:Number(g?.balance||0),officialCoinBalance:cs.official,officialGoldBalance:gs.official,authority:await isFixedMainAdminId(me.user_id),coinCommissionPercent:cfg.coinCommissionPercent,goldCommissionPercent:cfg.goldCommissionPercent,vatPercent:0,gifts:rows},200,cors);
}
async function liveGiftThankYou(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||me.user_id).trim(),senderId=String(b.senderId||'').trim();if(hostId!==me.user_id&&!isAdminUser(me))return json({error:'HOST_ONLY'},403,cors);if(!isFourDigit(senderId)||senderId===hostId)return json({error:'INVALID_SUPPORTER'},400,cors);const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first(),sid=String(meta?.session_id||'');const gift=await env.DB.prepare(`SELECT id FROM myshop_live_gift_events WHERE host_id=? AND sender_id=? AND status='COMPLETED' AND (?='' OR session_id=?) ORDER BY id DESC LIMIT 1`).bind(hostId,senderId,sid,sid).first();if(!gift)return json({error:'NO_COMPLETED_GIFT'},404,cors);const message=(me.full_name||'The Host')+' thanked you for supporting the Live.';await createUserNotification(env,senderId,'💝 Thank You from Host',message,'LIVE_GIFT_THANKS',hostId,hostId);try{await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'GIFT_THANKS',?)`).bind(hostId,senderId,sid,message).run();await liveHubPush(env,hostId,sid,'GIFT_THANKS',{hostId,senderId,hostName:String(me.full_name||'Host'),message});}catch(e){}return json({ok:true,senderId,message},200,cors);
}
async function liveGiftSend(request,env,ctx){
 const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
 const b=await body(request),hostId=String(b.hostId||'').trim(),giftId=Number(b.giftId),quantity=Number(b.quantity??1),nonce=String(b.clientNonce||'').trim();
 const receiverIds=[...new Set((Array.isArray(b.receiverIds)?b.receiverIds:[b.receiverId||hostId]).map(x=>String(x).trim()))];
 if(!isFourDigit(hostId)||!Number.isSafeInteger(giftId)||giftId<=0||!Number.isSafeInteger(quantity)||quantity<1||quantity>1000||!receiverIds.length||receiverIds.length>100||receiverIds.some(x=>!isFourDigit(x)||x===me.user_id)||!/^[a-zA-Z0-9_-]{8,80}$/.test(nonce))return json({error:'INVALID_GIFT_TARGET_OR_QUANTITY'},400,cors);
 const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id,COALESCE(gift_combo_enabled,1) gift_combo_enabled FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first(),sessionId=String(meta?.session_id||'');
 if(!sessionId)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
 const prior=await env.DB.prepare(`SELECT response_json FROM myshop_live_gift_transactions WHERE host_id=? AND session_id=? AND sender_id=? AND nonce=?`).bind(hostId,sessionId,me.user_id,nonce).first();
 if(prior){const saved=JSON.parse(prior.response_json);if(Number(saved.gift?.id)!==giftId||Number(saved.quantity)!==quantity||JSON.stringify([...(saved.receiverIds||[])].sort())!==JSON.stringify([...receiverIds].sort()))return json({error:'IDEMPOTENCY_CONFLICT'},409,cors);return json({...saved,duplicateSuppressed:true},200,cors);}
 const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(Number(live?.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
 if(['BLOCKED','KICKED'].includes(await liveSanctionFor(env,hostId,me.user_id)))return json({error:'LIVE_NOT_ALLOWED'},403,cors);
 const eligible=(await env.DB.prepare(`SELECT user_id FROM myshop_live_seats_dynamic WHERE host_id=?`).bind(hostId).all()).results||[],allowed=new Set([hostId,...eligible.map(x=>String(x.user_id))]);
 if(receiverIds.some(x=>!allowed.has(x)))return json({error:'RECIPIENT_NOT_IN_CALL'},409,cors);
 const gift=await env.DB.prepare(`SELECT * FROM myshop_live_gifts WHERE id=? AND enabled=1 AND COALESCE(deleted,0)=0`).bind(giftId).first();if(!gift)return json({error:'GIFT_NOT_AVAILABLE'},404,cors);
 const unitPrice=Math.max(1,Math.floor(Number(gift.price||1))),price=unitPrice*quantity,cfg=await financeConfig(env),vat=0;
 const source=await walletSourceState(env,me.user_id,gift.currency),wallet=source.wallet,adminSender=await isFixedMainAdminId(me.user_id),w=await env.DB.prepare(`SELECT balance FROM ${wallet} WHERE user_id=?`).bind(me.user_id).first();
 let officialRemaining=source.official;const splits=receiverIds.map(receiverId=>{const official=adminSender?price:Math.min(price,officialRemaining),normal=price-official;officialRemaining=Math.max(0,officialRemaining-official);return{receiverId,official,normal,officialDebit:official,fee:Math.round(normal*commissionRate(cfg,gift.currency)/100)};});
 const totalDebit=splits.reduce((n,x)=>n+price+x.fee,0),debitEach=price;
 if(!Number.isSafeInteger(totalDebit))return json({error:'INVALID_GIFT_AMOUNT'},400,cors);
 if(Number(w?.balance||0)<totalDebit)return json({error:gift.currency==='COIN'?'INSUFFICIENT_COIN_BALANCE':'INSUFFICIENT_GOLD_BALANCE',required:totalDebit},409,cors);
 // Initialize missing recipient progress before this gift enters the value ledger.
 // Otherwise legacy backfill would count the first gift and deferred credit would add it twice.
 const existingProgress=new Set(((await env.DB.prepare(`SELECT user_id FROM myshop_user_progress WHERE user_id IN (${receiverIds.map(()=>'?').join(',')})`).bind(...receiverIds).all()).results||[]).map(x=>String(x.user_id)));
 for(const receiverId of receiverIds)if(!existingProgress.has(receiverId))await reconcileLevelProgress(env,receiverId);
 const senderLevel=Number((await env.DB.prepare(`SELECT COALESCE(level,0) level FROM myshop_user_progress WHERE user_id=?`).bind(me.user_id).first())?.level||0);
 const response={ok:true,gift,receiverId:receiverIds[0],receiverIds,quantity,combo:quantity>=5&&Number(meta.gift_combo_enabled)!==0?quantity:1,grossAmount:price*receiverIds.length,vatPercent:cfg.vatPercent,vatAmount:0,feeAmount:splits.reduce((n,x)=>n+x.fee,0),commissionLabel:'MY SHOP Commission',totalDebit,balance:Number(w.balance)-totalDebit,sessionId,senderName:String(me.full_name||me.user_id),senderAvatar:String(me.avatar_url||''),senderLevel,animationQueue:true,fastAck:true};
 const statements=[
  // The nonce claim, balance check, room check, debit, credits, events and receipts
  // run in ONE D1 transaction. Concurrent duplicates or insufficient balances abort it.
  env.DB.prepare(`INSERT INTO myshop_live_gift_transactions(host_id,session_id,sender_id,nonce,allowed,response_json) VALUES(?,?,?,?,(SELECT CASE WHEN COALESCE((SELECT balance FROM ${wallet} WHERE user_id=?),0)>=? AND COALESCE((SELECT official_balance FROM myshop_wallet_sources WHERE user_id=? AND currency=?),0)=? AND EXISTS(SELECT 1 FROM myshop_live_presence p JOIN myshop_live_room_meta m ON m.host_id=p.user_id WHERE p.user_id=? AND p.active=1 AND m.session_id=?) THEN 1 ELSE 0 END),?)`).bind(hostId,sessionId,me.user_id,nonce,me.user_id,totalDebit,me.user_id,gift.currency,source.official,hostId,sessionId,JSON.stringify(response)),
  env.DB.prepare(`UPDATE ${wallet} SET balance=balance-?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(totalDebit,me.user_id),
  env.DB.prepare(`UPDATE myshop_wallet_sources SET official_balance=MAX(0,official_balance-?),updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND currency=?`).bind(splits.reduce((n,x)=>n+x.officialDebit,0),me.user_id,gift.currency)
 ];
 for(const [i,s] of splits.entries()){
  statements.push(env.DB.prepare(`INSERT INTO myshop_creator_earnings(user_id,currency,balance) VALUES(?,?,?) ON CONFLICT(user_id,currency) DO UPDATE SET balance=balance+excluded.balance,updated_at=CURRENT_TIMESTAMP`).bind(s.receiverId,gift.currency,price));
  if(s.official>0)statements.push(...giftProgressStatements(env.DB,{currency:gift.currency,senderId:me.user_id,receiverId:s.receiverId,units:s.official,official:true,reference:'LIVE_GIFT_OFFICIAL#'+sessionId+'#'+nonce+'-'+s.receiverId}));
  if(s.normal>0)statements.push(...giftProgressStatements(env.DB,{currency:gift.currency,senderId:me.user_id,receiverId:s.receiverId,units:s.normal,official:false,reference:'LIVE_GIFT_NORMAL#'+sessionId+'#'+nonce+'-'+s.receiverId}));
  statements.push(env.DB.prepare(`INSERT INTO myshop_live_gift_events(host_id,sender_id,receiver_id,gift_id,currency,price,session_id,client_nonce,quantity) VALUES(?,?,?,?,?,?,?,?,?)`).bind(hostId,me.user_id,s.receiverId,giftId,gift.currency,price,sessionId,nonce+'-'+i,quantity));
  statements.push(env.DB.prepare(`INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,host_id,gift_id,gross_amount,fee_percent,fee_amount,vat_percent,vat_amount,net_amount,platform_amount,reference,metadata) VALUES('GIFT',?,?,?,?,?,?,?,?,?,?,?,?, 'LIVE_GIFT',?)`).bind(gift.currency,me.user_id,s.receiverId,hostId,giftId,price,s.normal>0?commissionRate(cfg,gift.currency):0,s.fee,cfg.vatPercent,vat,price,s.fee+vat,JSON.stringify({clientNonce:nonce,sessionId,quantity,unitPrice,commissionLabel:'MY SHOP Commission',officialSpend:s.official,normalSpend:s.normal,totalDebit:price+s.fee})));
 }
 statements.push(env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'GIFT',?)`).bind(hostId,me.user_id,sessionId,'sent '+gift.name+' ×'+quantity));
 try{await env.DB.batch(statements);}catch(e){const duplicate=await env.DB.prepare(`SELECT response_json FROM myshop_live_gift_transactions WHERE host_id=? AND session_id=? AND sender_id=? AND nonce=?`).bind(hostId,sessionId,me.user_id,nonce).first();if(duplicate)return json({...JSON.parse(duplicate.response_json),duplicateSuppressed:true},200,cors);return json({error:'GIFT_NOT_COMPLETED',message:'Balance or room changed. No gift was charged.'},409,cors);}
 const events=(await env.DB.prepare(`SELECT id,receiver_id,quantity FROM myshop_live_gift_events WHERE host_id=? AND session_id=? AND sender_id=? AND client_nonce IN (${receiverIds.map(()=>'?').join(',')}) ORDER BY id`).bind(hostId,sessionId,me.user_id,...receiverIds.map((_,i)=>nonce+'-'+i)).all()).results||[];
 response.eventId=Number(events[0]?.id||0);response.eventIds=events.map(e=>Number(e.id));
 await env.DB.prepare(`UPDATE myshop_live_gift_transactions SET response_json=? WHERE host_id=? AND session_id=? AND sender_id=? AND nonce=?`).bind(JSON.stringify(response),hostId,sessionId,me.user_id,nonce).run();
 const afterSend=async()=>{
  for(const event of events){await liveHubPush(env,hostId,sessionId,'GIFT',{...gift,...event,name:String(gift.name||'Gift'),sender_id:me.user_id,sender_name:response.senderName,sender_avatar:response.senderAvatar,sender_level:senderLevel,price,quantity,combo:quantity>=5&&Number(meta.gift_combo_enabled)!==0?quantity:1,currency:gift.currency,created_at:new Date().toISOString()});}
  await env.DB.prepare(`UPDATE myshop_live_fan_club SET points=points+?,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND active=1`).bind(Math.max(1,Math.floor(price*receiverIds.length/10)),hostId,me.user_id).run();
 };
 if(ctx?.waitUntil)ctx.waitUntil(afterSend());else await afterSend();return json(response,201,cors);
}


async function liveGiftEvents(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const u=new URL(request.url),hostId=String(u.searchParams.get('hostId')||'').trim(),after=Math.max(0,Math.floor(Number(u.searchParams.get('after')||0)));if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first(),sessionId=String(meta?.session_id||'');
  const vr=me.user_id===hostId?null:await env.DB.prepare(`SELECT joined_at FROM myshop_live_viewers WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).first();
  const cutoff=me.user_id===hostId?'1970-01-01 00:00:00':String(vr?.joined_at||new Date().toISOString().slice(0,19).replace('T',' '));
  const events=(await env.DB.prepare(`SELECT e.id,e.sender_id,e.receiver_id,e.currency,e.price,e.quantity,CASE WHEN e.quantity>=5 AND COALESCE((SELECT gift_combo_enabled FROM myshop_live_room_meta WHERE host_id=e.host_id),1)=1 THEN e.quantity ELSE 1 END combo,e.created_at,g.name,g.preview_url,g.animation_url,g.animation_mime,g.animation_enabled,g.sound_url,g.sound_enabled,g.sound_volume,g.effect_duration_ms,g.sound_duration_ms,g.sound_trim_start_pct,g.sound_trim_end_pct,g.vat_percent,g.board_position,g.animation_scale,g.size_mode,u.full_name sender_name,u.avatar_url sender_avatar,(CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=e.sender_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=e.sender_id),0)) AS sender_level,ru.full_name receiver_name FROM myshop_live_gift_events e JOIN myshop_live_gifts g ON g.id=e.gift_id LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id LEFT JOIN myshop_auth_users_v108 ru ON ru.user_id=e.receiver_id WHERE e.host_id=? AND e.session_id=? AND e.status='COMPLETED' AND e.id>? AND datetime(e.created_at)>=datetime(?) ORDER BY e.id ASC LIMIT 50`).bind(hostId,sessionId,after,cutoff).all()).results||[];
  return json({ok:true,sessionId,events,lastEventId:events.length?Number(events[events.length-1].id):after},200,cors);
}
async function adminLiveGifts(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;await ensureLiveRoomSchema(env);
  const cur=String(new URL(request.url).searchParams.get('currency')||'').toUpperCase();
  const filtered=cur==='COIN'||cur==='GOLD';
  const stmt=filtered?env.DB.prepare(`SELECT * FROM myshop_live_gifts WHERE COALESCE(deleted,0)=0 AND currency=? ORDER BY sort_order,id`).bind(cur):env.DB.prepare(`SELECT * FROM myshop_live_gifts WHERE COALESCE(deleted,0)=0 ORDER BY currency,sort_order,id`);
  const rows=(await stmt.all()).results||[];
  return json({ok:true,gifts:rows,currency:cur||'ALL'},200,cors);
}
async function adminLiveGiftSave(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;await ensureLiveRoomSchema(env);const b=await body(request),id=Math.max(0,Math.floor(Number(b.id||0))),currency=String(b.currency||'COIN').toUpperCase(),scale=Math.max(0,Math.min(100,Math.floor(Number(b.animationScale??70)))),size=scale<=20?'SMALL':scale<=58?'MEDIUM':scale<=84?'LARGE':'FULL_SCREEN';
  if(!['COIN','GOLD'].includes(currency)||!['SMALL','MEDIUM','LARGE','FULL_SCREEN'].includes(size))return json({error:'INVALID_GIFT_CONFIG'},400,cors);
  const giftName=String(b.name||'Gift').trim().slice(0,60)||'Gift',price=Math.max(1,Math.floor(Number(b.price||1))),category=String(b.category||'ALL').trim().toUpperCase().replace(/[^A-Z0-9_-]/g,'').slice(0,32)||'ALL';
  const preview=String(b.previewUrl||'').trim().slice(0,1400),animation=String(b.animationUrl||'').trim().slice(0,1400),animationMime=String(b.animationMime||'').trim().slice(0,100),sound=String(b.soundUrl||'').trim().slice(0,1400),catalogAnimationUrl=String(b.catalogAnimationUrl||'').trim().slice(0,1400);
  let boardPosition=String(b.boardPosition||'CENTER').trim().toUpperCase();if(!['CENTER','TOP','BOTTOM','FULL_SCREEN'].includes(boardPosition))boardPosition='CENTER';
  const animationEnabled=b.animationEnabled===false?0:1,soundEnabled=b.soundEnabled===false?0:1,soundVolume=Math.max(0,Math.min(100,Math.floor(Number(b.soundVolume??85)))),effectDurationMs=Math.max(500,Math.min(15000,Math.floor(Number(b.effectDurationMs??2800)))),soundDurationMs=Math.max(0,Math.min(15000,Math.floor(Number(b.soundDurationMs??2500)))),soundTrimStartPct=Math.max(0,Math.min(99,Math.floor(Number(b.soundTrimStartPct??0)))),soundTrimEndRaw=Math.max(1,Math.min(100,Math.floor(Number(b.soundTrimEndPct??100)))),soundTrimEndPct=Math.max(soundTrimStartPct+1,soundTrimEndRaw),vatPercent=Math.max(0,Math.min(100,Math.floor(Number(b.vatPercent??10)))),sortOrder=Math.max(0,Math.floor(Number(b.sortOrder||100))),enabled=b.enabled===false?0:1;
  const catalogAnimationEnabled=b.catalogAnimationEnabled===false?0:1,catalogLoop=b.catalogLoop===false?0:1,catalogPreviewSize=Math.max(0,Math.min(100,Math.floor(Number(b.catalogPreviewSize??68)))),catalogAnimationStrength=Math.max(0,Math.min(100,Math.floor(Number(b.catalogAnimationStrength??42)))),catalogAnimationSpeed=Math.max(0,Math.min(100,Math.floor(Number(b.catalogAnimationSpeed??45)))),catalogGlowParticle=Math.max(0,Math.min(100,Math.floor(Number(b.catalogGlowParticle??35))));
  const allowedCatalogTypes=['AUTO','PULSE','BOUNCE','FLOAT','GLOW','SPARKLE','ROTATE','SLIDE'];let catalogAnimationType=String(b.catalogAnimationType||'AUTO').trim().toUpperCase();if(!allowedCatalogTypes.includes(catalogAnimationType))catalogAnimationType='AUTO';
  if(!id){
    const c=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_gifts WHERE currency=? AND COALESCE(deleted,0)=0`).bind(currency).first();if(Number(c?.c||0)>=50)return json({error:'GIFT_LIMIT_50'},409,cors);
    const r=await env.DB.prepare(`INSERT INTO myshop_live_gifts(name,currency,price,category,preview_url,animation_url,animation_mime,animation_enabled,sound_url,sound_enabled,sound_volume,effect_duration_ms,sound_duration_ms,sound_trim_start_pct,sound_trim_end_pct,vat_percent,board_position,animation_scale,size_mode,catalog_animation_enabled,catalog_animation_type,catalog_preview_size,catalog_animation_strength,catalog_animation_speed,catalog_glow_particle,catalog_loop,catalog_animation_url,sort_order,enabled,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)`).bind(giftName,currency,price,category,preview,animation,animationMime,animationEnabled,sound,soundEnabled,soundVolume,effectDurationMs,soundDurationMs,soundTrimStartPct,soundTrimEndPct,vatPercent,boardPosition,scale,size,catalogAnimationEnabled,catalogAnimationType,catalogPreviewSize,catalogAnimationStrength,catalogAnimationSpeed,catalogGlowParticle,catalogLoop,catalogAnimationUrl,sortOrder,enabled).run();
    return json({ok:true,id:r.meta?.last_row_id||0,currency,price,soundVolume,effectDurationMs,soundDurationMs,soundTrimStartPct,soundTrimEndPct,vatPercent,boardPosition,animationScale:scale,catalogAnimationEnabled:!!catalogAnimationEnabled,catalogAnimationType,catalogPreviewSize,catalogAnimationStrength,catalogAnimationSpeed,catalogGlowParticle,catalogLoop:!!catalogLoop,sizeMode:size,updated:true},201,cors);
  }
  const exists=await env.DB.prepare(`SELECT id,currency FROM myshop_live_gifts WHERE id=? AND COALESCE(deleted,0)=0`).bind(id).first();if(!exists)return json({error:'GIFT_NOT_FOUND'},404,cors);
  if(String(exists.currency||'').toUpperCase()!==currency)return json({error:'GIFT_CURRENCY_LOCKED',message:'Coin and Diamond gifts are managed in separate catalogs. Delete and add a new gift to change currency.'},409,cors);
  await env.DB.prepare(`UPDATE myshop_live_gifts SET name=?,price=?,category=?,preview_url=?,animation_url=?,animation_mime=?,animation_enabled=?,sound_url=?,sound_enabled=?,sound_volume=?,effect_duration_ms=?,sound_duration_ms=?,sound_trim_start_pct=?,sound_trim_end_pct=?,vat_percent=?,board_position=?,animation_scale=?,size_mode=?,catalog_animation_enabled=?,catalog_animation_type=?,catalog_preview_size=?,catalog_animation_strength=?,catalog_animation_speed=?,catalog_glow_particle=?,catalog_loop=?,catalog_animation_url=?,sort_order=?,enabled=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(giftName,price,category,preview,animation,animationMime,animationEnabled,sound,soundEnabled,soundVolume,effectDurationMs,soundDurationMs,soundTrimStartPct,soundTrimEndPct,vatPercent,boardPosition,scale,size,catalogAnimationEnabled,catalogAnimationType,catalogPreviewSize,catalogAnimationStrength,catalogAnimationSpeed,catalogGlowParticle,catalogLoop,catalogAnimationUrl,sortOrder,enabled,id).run();
  return json({ok:true,id,currency,price,soundVolume,effectDurationMs,soundDurationMs,soundTrimStartPct,soundTrimEndPct,vatPercent,boardPosition,animationScale:scale,catalogAnimationEnabled:!!catalogAnimationEnabled,catalogAnimationType,catalogPreviewSize,catalogAnimationStrength,catalogAnimationSpeed,catalogGlowParticle,catalogLoop:!!catalogLoop,sizeMode:size,updated:true},200,cors);
}
async function adminLiveGiftBulkVat(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;await ensureLiveRoomSchema(env);const b=await body(request);const currency=String(b.currency||'').toUpperCase(),vatPercent=Math.max(0,Math.min(100,Math.floor(Number(b.vatPercent??10))));
  if(!['COIN','GOLD'].includes(currency))return json({error:'INVALID_CURRENCY'},400,cors);
  const r=await env.DB.prepare(`UPDATE myshop_live_gifts SET vat_percent=?,updated_at=CURRENT_TIMESTAMP WHERE currency=? AND COALESCE(deleted,0)=0`).bind(vatPercent,currency).run();
  return json({ok:true,currency,vatPercent,updated:Number(r.meta?.changes||0)},200,cors);
}
async function adminLiveGiftReorder(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;await ensureLiveRoomSchema(env);const b=await body(request),currency=String(b.currency||'').toUpperCase(),ids=Array.isArray(b.ids)?b.ids.map(x=>Math.max(0,Math.floor(Number(x||0)))).filter(Boolean):[];
  if(!['COIN','GOLD'].includes(currency)||!ids.length||ids.length>50)return json({error:'INVALID_GIFT_ORDER'},400,cors);
  const unique=[...new Set(ids)];if(unique.length!==ids.length)return json({error:'DUPLICATE_GIFT_ID'},400,cors);
  const qs=unique.map(()=>'?').join(',');const rows=(await env.DB.prepare(`SELECT id FROM myshop_live_gifts WHERE currency=? AND COALESCE(deleted,0)=0 AND id IN (${qs})`).bind(currency,...unique).all()).results||[];
  if(rows.length!==unique.length)return json({error:'GIFT_ORDER_CURRENCY_MISMATCH'},409,cors);
  const stmts=unique.map((id,i)=>env.DB.prepare(`UPDATE myshop_live_gifts SET sort_order=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND currency=? AND COALESCE(deleted,0)=0`).bind(i+1,id,currency));if(typeof env.DB.batch==='function')await env.DB.batch(stmts);else for(const q of stmts)await q.run();
  return json({ok:true,currency,updated:unique.length},200,cors);
}
async function adminLiveGiftDelete(request,env){const a=await adminOnly(request,env);if(a.error)return a.error;await ensureLiveRoomSchema(env);const b=await body(request),id=Math.max(0,Math.floor(Number(b.id||0)));if(!id)return json({error:'INVALID_GIFT_ID'},400,cors);await env.DB.prepare(`UPDATE myshop_live_gifts SET deleted=1,enabled=0,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(id).run();return json({ok:true,id,deleted:true},200,cors);}
async function adminLiveGiftAssetUpload(request,env){const a=await adminOnly(request,env);if(a.error)return a.error;if(!env.MEDIA)return json({error:'R2_NOT_CONFIGURED'},503,cors);const form=await request.formData(),file=form.get('file');if(!(file instanceof File))return json({error:'FILE_REQUIRED'},400,cors);if(file.size>12*1024*1024)return json({error:'GIFT_ASSET_TOO_LARGE'},413,cors);const ct=guessContentType(file);const ok=ct.startsWith('image/')||ct.startsWith('audio/')||ct==='application/json'||ct==='video/webm';if(!ok)return json({error:'GIFT_ASSET_TYPE_MISMATCH'},400,cors);const ext=(String(file.name||'asset').split('.').pop()||'bin').replace(/[^a-zA-Z0-9]/g,'').slice(0,8)||'bin';const key=`live/gifts/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:ct,cacheControl:'public, max-age=31536000'}});const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();return json({ok:true,url,mediaType:ct,objectKey:key},201,cors);}


async function adminGateStatus(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);
  await ensureLiveRoomSchema(env);const cfg=await env.DB.prepare(`SELECT security_question FROM myshop_admin_gate WHERE id=1`).first();
  let unlocked=false;if(cfg){const auth=String(request.headers.get('Authorization')||'');const raw=auth.toLowerCase().startsWith('bearer ')?auth.slice(7).trim():'';if(raw){const h=await sha256(raw);const r=await env.DB.prepare(`SELECT 1 ok FROM myshop_admin_gate_sessions WHERE token_hash=? AND datetime(expires_at)>datetime('now')`).bind(h).first();unlocked=!!r;}}
  return json({ok:true,configured:!!cfg,unlocked,securityQuestion:String(cfg?.security_question||'')},200,cors);
}
async function adminGateSetup(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);await ensureLiveRoomSchema(env);
  const existing=await env.DB.prepare(`SELECT id FROM myshop_admin_gate WHERE id=1`).first();if(existing)return json({error:'ADMIN_GATE_ALREADY_CONFIGURED'},409,cors);
  const b=await body(request),password=String(b.password||''),q=String(b.securityQuestion||'').trim().slice(0,160),a=normalizeAnswer(b.securityAnswer||'');
  if(password.length<6||!q||a.length<2)return json({error:'ADMIN_GATE_SETUP_INVALID'},400,cors);
  await env.DB.prepare(`INSERT INTO myshop_admin_gate(id,password_hash,security_question,security_answer_hash,updated_by) VALUES(1,?,?,?,?)`).bind(await hashPassword(password),q,await sha256(a),me.user_id).run();
  return json({ok:true},201,cors);
}
async function adminGateUnlock(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);await ensureLiveRoomSchema(env);const b=await body(request),password=String(b.password||'');
  const cfg=await env.DB.prepare(`SELECT password_hash FROM myshop_admin_gate WHERE id=1`).first();if(!cfg)return json({error:'ADMIN_GATE_NOT_CONFIGURED'},409,cors);if(!(await verifyPassword(password,cfg.password_hash)))return json({error:'ADMIN_GATE_PASSWORD_INCORRECT'},403,cors);
  const auth=String(request.headers.get('Authorization')||'');const raw=auth.toLowerCase().startsWith('bearer ')?auth.slice(7).trim():'';if(!raw)return json({error:'UNAUTHORIZED'},401,cors);const h=await sha256(raw);
  await env.DB.prepare(`INSERT INTO myshop_admin_gate_sessions(token_hash,user_id,expires_at,unlocked_at) VALUES(?,?,datetime('now','+8 hours'),CURRENT_TIMESTAMP) ON CONFLICT(token_hash) DO UPDATE SET user_id=excluded.user_id,expires_at=excluded.expires_at,unlocked_at=CURRENT_TIMESTAMP`).bind(h,me.user_id).run();
  return json({ok:true,expiresInSeconds:28800},200,cors);
}
async function adminGateRecover(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);
  await ensureLiveRoomSchema(env);const b=await body(request),mode=String(b.mode||'QUESTION').toUpperCase(),newPassword=String(b.newPassword||'');if(newPassword.length<6)return json({error:'NEW_PASSWORD_TOO_SHORT'},400,cors);const cfg=await env.DB.prepare(`SELECT security_answer_hash FROM myshop_admin_gate WHERE id=1`).first();if(!cfg)return json({error:'ADMIN_GATE_NOT_CONFIGURED'},409,cors);
  let ok=false;if(mode==='QUESTION'){ok=(await sha256(normalizeAnswer(b.securityAnswer||'')))===cfg.security_answer_hash;}
  else if(mode==='OWNER_IDS'){const raw=[b.id1,b.id2,b.id3].map(x=>String(x||'').trim().toLowerCase()).filter(Boolean);const allowedHashes=new Set(['2488f46e89a2ff3d2e5ea9f43ee610d8c74135f931692269d077a73551f8495d','6d8859a91a72a6ab10acda29c21709493fe5f0f3efcee83e480a609f9abf8969','b2d53ac69843f7f30f81a770adc18107f230317670eaa701d3135e53731e6b28']);const matched=new Set();for(const x of raw){const h=await sha256(x);if(allowedHashes.has(h))matched.add(h);}ok=matched.size>=2;}
  if(!ok)return json({error:'RECOVERY_NOT_MATCHED'},403,cors);await env.DB.prepare(`UPDATE myshop_admin_gate SET password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`).bind(await hashPassword(newPassword)).run();await env.DB.prepare(`DELETE FROM myshop_admin_gate_sessions`).run();return json({ok:true,reset:true},200,cors);
}
async function adminGateIsUnlocked(request,env){
  const auth=String(request.headers.get('Authorization')||'');const raw=auth.toLowerCase().startsWith('bearer ')?auth.slice(7).trim():'';if(!raw)return false;const h=await sha256(raw);const r=await env.DB.prepare(`SELECT 1 ok FROM myshop_admin_gate_sessions WHERE token_hash=? AND datetime(expires_at)>datetime('now')`).bind(h).first();return !!r;
}
async function applyLiveNamePolicy(env,userId,newName){
  const name=String(newName||'').trim().slice(0,40);if(!name)return {ok:false,error:'LIVE_NAME_REQUIRED'};const old=await env.DB.prepare(`SELECT live_name,changed_at FROM myshop_live_name_policy WHERE user_id=?`).bind(userId).first();if(!old){await env.DB.prepare(`INSERT INTO myshop_live_name_policy(user_id,live_name,changed_at) VALUES(?,?,CURRENT_TIMESTAMP)`).bind(userId,name).run();return {ok:true,name,cost:0,remainingSeconds:0};}if(String(old.live_name)===name)return {ok:true,name,cost:0,remainingSeconds:0};
  // V-399: Live Name can be changed freely; no 24-hour lock and no Coin charge.
  const cost=0;
  await env.DB.prepare(`UPDATE myshop_live_name_policy SET live_name=?,changed_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(name,userId).run();return {ok:true,name,cost,remainingSeconds:0};
}
async function liveReact(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||'').trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(Number(live?.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  await resetLiveReactionWindow(env,hostId);
  const meta=await env.DB.prepare(`SELECT session_id,react_window_started_at FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();const sessionId=String(meta?.session_id||'');if(!sessionId)return json({error:'LIVE_SESSION_NOT_READY'},409,cors);
  const change=await env.DB.prepare(`INSERT INTO myshop_live_reacts(host_id,session_id,user_id,react_count,updated_at) VALUES(?,?,?,1,CURRENT_TIMESTAMP) ON CONFLICT(host_id,session_id,user_id) DO UPDATE SET react_count=react_count+1,updated_at=CURRENT_TIMESTAMP WHERE react_count<100`).bind(hostId,sessionId,me.user_id).run();
  if(!Number(change.meta?.changes||0))return json({error:'LOVE_REACT_LIMIT',limit:100},409,cors);
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET react_count=(SELECT COALESCE(SUM(react_count),0) FROM myshop_live_reacts WHERE host_id=? AND session_id=?),updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND session_id=?`).bind(hostId,sessionId,hostId,sessionId).run();
  const total=await env.DB.prepare(`SELECT react_count FROM myshop_live_room_meta WHERE host_id=? AND session_id=?`).bind(hostId,sessionId).first();const count=Number(total?.react_count||0);
  await awardLiveReaction(env,hostId,sessionId,String(meta?.react_window_started_at||''),count);
  await liveHubDirty(env,hostId,sessionId,'REACTION');
  const mine=await env.DB.prepare(`SELECT react_count FROM myshop_live_reacts WHERE host_id=? AND session_id=? AND user_id=?`).bind(hostId,sessionId,me.user_id).first();
  return json({ok:true,reactCount:count,myReactCount:Number(mine?.react_count||0),perUserLimit:100,sessionScoped:true},200,cors);
}
async function resetLiveReactionWindow(env,hostId){
  await env.DB.batch([
    env.DB.prepare(`DELETE FROM myshop_live_reacts WHERE host_id=? AND EXISTS(SELECT 1 FROM myshop_live_room_meta WHERE host_id=? AND (COALESCE(react_window_started_at,'')='' OR datetime(react_window_started_at)<=datetime('now','-24 hours')))` ).bind(hostId,hostId),
    env.DB.prepare(`UPDATE myshop_live_room_meta SET react_count=0,react_reward_milestone=0,react_window_started_at=CURRENT_TIMESTAMP WHERE host_id=? AND (COALESCE(react_window_started_at,'')='' OR datetime(react_window_started_at)<=datetime('now','-24 hours'))`).bind(hostId)
  ]);
}
async function awardLiveReaction(env,hostId,sessionId,window,count){
  if(count<2000)return;
  const key=hostId+'|'+sessionId+'|'+window+'|2000';
  await env.DB.batch([
    env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_reward_claims(reward_key,host_id,session_id,amount,status) VALUES(?,?,?,1000,'PENDING')`).bind(key,hostId,sessionId),
    env.DB.prepare(`INSERT OR IGNORE INTO myshop_coin_wallets(user_id,balance) VALUES(?,0)`).bind(hostId),
    env.DB.prepare(`UPDATE myshop_coin_wallets SET balance=balance+1000,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND EXISTS(SELECT 1 FROM myshop_live_reward_claims WHERE reward_key=? AND status='PENDING')`).bind(hostId,key),
    env.DB.prepare(`INSERT INTO myshop_coin_transactions(user_id,kind,amount,reference,status,metadata) SELECT ?,'REACTION_REWARD',1000,?,'COMPLETED',? WHERE EXISTS(SELECT 1 FROM myshop_live_reward_claims WHERE reward_key=? AND status='PENDING')`).bind(hostId,key,JSON.stringify({hostId,sessionId,reacts:2000,earned:true}),key),
    env.DB.prepare(`UPDATE myshop_live_room_meta SET react_reward_milestone=MAX(react_reward_milestone,1) WHERE host_id=? AND session_id=?`).bind(hostId,sessionId),
    env.DB.prepare(`UPDATE myshop_live_reward_claims SET status='COMPLETED' WHERE reward_key=? AND status='PENDING'`).bind(key)
  ]);
}
async function liveVote(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||'').trim();if(!isFourDigit(hostId)||hostId===me.user_id)return json({error:'INVALID_VOTE_TARGET'},400,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  const lvl=await coinLevelFor(env,me.user_id);if(Number(lvl.level||0)<2)return json({error:'VOTE_LEVEL_REQUIRED',requiredLevel:2,currentLevel:Number(lvl.level||0)},403,cors);
  const last=await env.DB.prepare(`SELECT voted_at FROM myshop_live_votes WHERE voter_id=? AND host_id=? AND datetime(voted_at)>datetime('now','-24 hours') ORDER BY id DESC LIMIT 1`).bind(me.user_id,hostId).first();if(last)return json({error:'VOTE_LIMIT_24H',lastVoteAt:last.voted_at},409,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first(),sessionId=String(meta?.session_id||'');
  await env.DB.prepare(`INSERT INTO myshop_live_votes(host_id,voter_id,session_id,voted_at) VALUES(?,?,?,CURRENT_TIMESTAMP)`).bind(hostId,me.user_id,sessionId).run();
  const c=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_votes WHERE host_id=?`).bind(hostId).first();
  await liveHubDirty(env,hostId,sessionId,'VOTE');
  return json({ok:true,voteCount:Number(c?.c||0),hostId,sessionId,rule:'PERMANENT_TOTAL_ONE_VOTE_PER_HOST_PER_24H'},201,cors);
}
async function adminUserAudit(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);
  await ensureLiveRoomSchema(env);await ensureMessageSchema(env);
  const uid=String(new URL(request.url).searchParams.get('userId')||'').trim();if(!isFourDigit(uid))return json({error:'INVALID_USER_ID'},400,cors);
  const u=await env.DB.prepare(`SELECT user_id,full_name,email,mobile,active,blocked_until,role,created_at FROM myshop_auth_users_v108 WHERE user_id=?`).bind(uid).first();if(!u)return json({error:'USER_NOT_FOUND'},404,cors);
  const ledger=(await env.DB.prepare(`SELECT * FROM myshop_value_ledger WHERE sender_id=? OR receiver_id=? OR host_id=? ORDER BY id DESC LIMIT 500`).bind(uid,uid,uid).all()).results||[];
  const msgs=(await env.DB.prepare(`SELECT id,sender_id,receiver_id,created_at,hidden_from_sender,hidden_from_receiver FROM myshop_messages WHERE sender_id=? OR receiver_id=? ORDER BY id DESC LIMIT 200`).bind(uid,uid).all()).results||[];
  const liveHistory=(await env.DB.prepare(`SELECT id,title,topic,started_at,ended_at,duration_seconds,peak_viewers,total_listeners,share_count,react_count,session_id FROM myshop_live_history WHERE host_id=? ORDER BY id DESC LIMIT 100`).bind(uid).all()).results||[];
  let membership=[];try{membership=(await env.DB.prepare(`SELECT * FROM myshop_store_entitlements WHERE user_id=? ORDER BY id DESC LIMIT 100`).bind(uid).all()).results||[];}catch(e){}
  let adminActions=[];try{adminActions=(await env.DB.prepare(`SELECT id,admin_id,user_id,action,note,created_at FROM myshop_admin_user_actions WHERE user_id=? ORDER BY id DESC LIMIT 200`).bind(uid).all()).results||[];}catch(e){}
  let blocks=[];try{blocks=(await env.DB.prepare(`SELECT * FROM myshop_user_blocks WHERE blocker_id=? OR blocked_id=? ORDER BY id DESC LIMIT 200`).bind(uid,uid).all()).results||[];}catch(e){}
  let recoveryHistory=[];try{await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_account_recovery_audit(id INTEGER PRIMARY KEY AUTOINCREMENT,admin_id TEXT NOT NULL,user_id TEXT NOT NULL,old_email TEXT NOT NULL DEFAULT '',new_email TEXT NOT NULL DEFAULT '',old_mobile TEXT NOT NULL DEFAULT '',new_mobile TEXT NOT NULL DEFAULT '',action TEXT NOT NULL DEFAULT 'CONTACT_UPDATE',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();try{await env.DB.prepare(`ALTER TABLE myshop_account_recovery_audit ADD COLUMN action TEXT NOT NULL DEFAULT 'CONTACT_UPDATE'`).run();}catch(e){}recoveryHistory=(await env.DB.prepare(`SELECT id,admin_id,user_id,old_email,new_email,old_mobile,new_mobile,action,created_at FROM myshop_account_recovery_audit WHERE user_id=? ORDER BY id DESC LIMIT 50`).bind(uid).all()).results||[];}catch(e){}
  const sums=await env.DB.prepare(`SELECT COALESCE(SUM(CASE WHEN receiver_id=? THEN net_amount ELSE 0 END),0) incoming,COALESCE(SUM(CASE WHEN sender_id=? THEN gross_amount ELSE 0 END),0) outgoing,COALESCE(SUM(CASE WHEN sender_id=? THEN fee_amount ELSE 0 END),0) fees FROM myshop_value_ledger WHERE status='COMPLETED' AND (sender_id=? OR receiver_id=? OR host_id=?)`).bind(uid,uid,uid,uid,uid,uid).first();
  const withdrawalRequests=(await env.DB.prepare('SELECT id,currency,gross_units,service_fee_units,net_units,status,created_at,updated_at FROM myshop_creator_withdraw_requests WHERE user_id=? ORDER BY id DESC LIMIT 100').bind(uid).all()).results||[];
  const purchaseRequests=(await env.DB.prepare('SELECT r.id,r.status,r.created_at,r.decision_note,c.title,c.item_type FROM myshop_store_purchase_requests r LEFT JOIN myshop_store_catalog c ON c.id=r.catalog_id WHERE r.user_id=? ORDER BY r.id DESC LIMIT 100').bind(uid).all()).results||[];
  const currencySummary=(await env.DB.prepare("SELECT currency,SUM(CASE WHEN receiver_id=? THEN net_amount ELSE 0 END) incoming,SUM(CASE WHEN sender_id=? THEN gross_amount ELSE 0 END) outgoing,SUM(CASE WHEN sender_id=? THEN fee_amount ELSE 0 END) fees FROM myshop_value_ledger WHERE status='COMPLETED' AND (sender_id=? OR receiver_id=? OR host_id=?) GROUP BY currency").bind(uid,uid,uid,uid,uid,uid).all()).results||[];
  return json({ok:true,user:u,summary:{incoming:Number(sums?.incoming||0),outgoing:Number(sums?.outgoing||0),fees:Number(sums?.fees||0),transactions:ledger.length,messages:msgs.length,liveSessions:liveHistory.length},transactions:ledger,messages:msgs,liveHistory,membership,blocks,adminActions,recoveryHistory,withdrawalRequests,purchaseRequests,currencySummary},200,cors);
}
async function adminAccountRecoveryUpdate(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);
  if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);
  const b=await body(request),uid=String(b.userId||'').trim(),emailInput=String(b.email||'').trim().toLowerCase(),mobileInput=normalizeMobile(b.mobile||'');
  if(!isFourDigit(uid))return json({error:'INVALID_USER_ID'},400,cors);
  const u=await env.DB.prepare(`SELECT user_id,full_name,email,mobile FROM myshop_auth_users_v108 WHERE user_id=?`).bind(uid).first();if(!u)return json({error:'USER_NOT_FOUND'},404,cors);
  const clearEmail=b.clearEmail===true,clearMobile=b.clearMobile===true;
  if((clearEmail||clearMobile)&&b.confirm!==true)return json({error:'CONTACT_REMOVAL_CONFIRMATION_REQUIRED'},400,cors);
  if(clearEmail&&emailInput||clearMobile&&mobileInput)return json({error:'CONFLICTING_CONTACT_CHANGE'},400,cors);
  const email=clearEmail?'':emailInput||String(u.email||'').trim().toLowerCase(),mobile=clearMobile?'':mobileInput||normalizeMobile(u.mobile||'');
  if(!email&&!mobile)return json({error:'EMAIL_OR_MOBILE_REQUIRED'},400,cors);
  if(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return json({error:'INVALID_EMAIL'},400,cors);
  if(mobile&&mobile.length<6)return json({error:'INVALID_MOBILE'},400,cors);
  if(email){const dupe=await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE lower(email)=lower(?) AND user_id<>?`).bind(email,uid).first();if(dupe)return json({error:'EMAIL_ALREADY_USED'},409,cors);}
  if(mobile){const dupe=await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE mobile=? AND user_id<>?`).bind(mobile,uid).first();if(dupe)return json({error:'MOBILE_ALREADY_USED'},409,cors);}
  const oldEmail=String(u.email||''),oldMobile=String(u.mobile||'');
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_account_recovery_audit(id INTEGER PRIMARY KEY AUTOINCREMENT,admin_id TEXT NOT NULL,user_id TEXT NOT NULL,old_email TEXT NOT NULL DEFAULT '',new_email TEXT NOT NULL DEFAULT '',old_mobile TEXT NOT NULL DEFAULT '',new_mobile TEXT NOT NULL DEFAULT '',action TEXT NOT NULL DEFAULT 'CONTACT_UPDATE',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  const mask=(v)=>{v=String(v||'');if(!v)return '';if(v.includes('@')){const [a,d]=v.split('@');return (a.slice(0,2)+'***@'+d);}return v.length<=4?'****':v.slice(0,2)+'***'+v.slice(-2);};
  await env.DB.batch([
    env.DB.prepare(`UPDATE myshop_auth_users_v108 SET email=?,mobile=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(email||null,mobile||null,uid),
    env.DB.prepare(`INSERT INTO myshop_account_recovery_audit(admin_id,user_id,old_email,new_email,old_mobile,new_mobile,action) VALUES(?,?,?,?,?,?,'CONTACT_UPDATE')`).bind(me.user_id,uid,mask(oldEmail),mask(email),mask(oldMobile),mask(mobile))
  ]);
  try{await createUserNotification(env,uid,'myshop Account Security','Your account recovery contact information was updated by myshop Main Admin.','ACCOUNT_SECURITY',me.user_id,uid,null);}catch(e){}
  return json({ok:true,userId:uid,name:u.full_name||'',email:mask(email),mobile:mask(mobile),userIdUnchanged:true},200,cors);
}


async function adminAccountPasswordReset(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);
  if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);
  await ensureAuthSchema(env);
  const b=await body(request),uid=String(b.userId||'').trim(),temporaryPassword=String(b.temporaryPassword||'');
  if(!isFourDigit(uid))return json({error:'INVALID_USER_ID'},400,cors);
  if(temporaryPassword.length<6)return json({error:'PASSWORD_TOO_SHORT'},400,cors);
  const u=await env.DB.prepare(`SELECT user_id,full_name FROM myshop_auth_users_v108 WHERE user_id=?`).bind(uid).first();if(!u)return json({error:'USER_NOT_FOUND'},404,cors);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_account_recovery_audit(id INTEGER PRIMARY KEY AUTOINCREMENT,admin_id TEXT NOT NULL,user_id TEXT NOT NULL,old_email TEXT NOT NULL DEFAULT '',new_email TEXT NOT NULL DEFAULT '',old_mobile TEXT NOT NULL DEFAULT '',new_mobile TEXT NOT NULL DEFAULT '',action TEXT NOT NULL DEFAULT 'CONTACT_UPDATE',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  try{await env.DB.prepare(`ALTER TABLE myshop_account_recovery_audit ADD COLUMN action TEXT NOT NULL DEFAULT 'CONTACT_UPDATE'`).run();}catch(e){}
  await env.DB.batch([
    env.DB.prepare(`UPDATE myshop_auth_users_v108 SET password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(await hashPassword(temporaryPassword),uid),
    env.DB.prepare(`DELETE FROM myshop_auth_sessions_v108 WHERE user_id=?`).bind(uid),
    env.DB.prepare(`INSERT INTO myshop_account_recovery_audit(admin_id,user_id,action) VALUES(?,?,'PASSWORD_RESET')`).bind(me.user_id,uid)
  ]);
  try{await createUserNotification(env,uid,'MY SHOP Account Security','Main Admin reset your login password. Sign in with the temporary password, then change it from Settings.','ACCOUNT_SECURITY',me.user_id,uid,null);}catch(e){}
  return json({ok:true,userId:uid,name:u.full_name||'',sessionsRevoked:true,mustChangePassword:true},200,cors);
}

async function adminFinanceOverview(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);
  await ensureLiveRoomSchema(env);
  const agg=async where=>await env.DB.prepare(`SELECT COALESCE(SUM(gross_amount),0) gross,COALESCE(SUM(fee_amount),0) fees,COALESCE(SUM(vat_amount),0) vat,COALESCE(SUM(platform_amount),0) platform,COALESCE(SUM(net_amount),0) net,COUNT(*) tx FROM myshop_value_ledger WHERE status='COMPLETED' ${where}`).first();
  const today=await agg(`AND date(created_at)=date('now')`),all=await agg('');
  const currencyRows=(await env.DB.prepare(`SELECT UPPER(COALESCE(currency,'COIN')) currency, COUNT(*) tx_count, COALESCE(SUM(CASE WHEN date(created_at)=date('now') THEN gross_amount ELSE 0 END),0) today_gross, COALESCE(SUM(CASE WHEN date(created_at)=date('now') THEN vat_amount ELSE 0 END),0) today_vat, COALESCE(SUM(CASE WHEN date(created_at)=date('now') THEN platform_amount ELSE 0 END),0) today_platform, COALESCE(SUM(CASE WHEN date(created_at)=date('now') THEN net_amount ELSE 0 END),0) today_net, COALESCE(SUM(gross_amount),0) all_gross, COALESCE(SUM(vat_amount),0) all_vat, COALESCE(SUM(platform_amount),0) all_platform, COALESCE(SUM(net_amount),0) all_net FROM myshop_value_ledger WHERE status='COMPLETED' GROUP BY UPPER(COALESCE(currency,'COIN'))`).all()).results||[];
  const currencySummary={COIN:{txCount:0,todayGross:0,todayVat:0,todayPlatform:0,todayNet:0,allGross:0,allVat:0,allPlatform:0,allNet:0},GOLD:{txCount:0,todayGross:0,todayVat:0,todayPlatform:0,todayNet:0,allGross:0,allVat:0,allPlatform:0,allNet:0}};
  for(const r of currencyRows){const k=(r.currency==='GOLD'||r.currency==='GOLD_COIN')?'GOLD':'COIN';currencySummary[k]={txCount:Number(r.tx_count||0),todayGross:Number(r.today_gross||0),todayVat:Number(r.today_vat||0),todayPlatform:Number(r.today_platform||0),todayNet:Number(r.today_net||0),allGross:Number(r.all_gross||0),allVat:Number(r.all_vat||0),allPlatform:Number(r.all_platform||0),allNet:Number(r.all_net||0)};}
  const cats=(await env.DB.prepare(`SELECT tx_type,currency,COUNT(*) tx_count,COALESCE(SUM(gross_amount),0) gross,COALESCE(SUM(platform_amount),0) platform,COALESCE(SUM(net_amount),0) net FROM myshop_value_ledger WHERE status='COMPLETED' GROUP BY tx_type,currency ORDER BY gross DESC`).all()).results||[];
  const recent=(await env.DB.prepare(`SELECT * FROM myshop_value_ledger ORDER BY id DESC LIMIT 200`).all()).results||[];
  return json({ok:true,today,allTime:all,currencySummary,categories:cats,recent,config:await financeConfig(env)},200,cors);
}
async function liveRtcToken(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);
  const body=await request.json().catch(()=>({}));const hostId=String(body.hostId||'').trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  const seat=await env.DB.prepare(`SELECT role FROM myshop_live_seats_dynamic WHERE host_id=? AND user_id=? LIMIT 1`).bind(hostId,me.user_id).first();
  const role=(me.user_id===hostId||String(seat?.role||'').toUpperCase()==='SPEAKER')?'PUBLISHER':'AUDIENCE';
  // App Certificate is server-only. It must be a Cloudflare Worker Secret and is never returned to clients.
  const appId=String(env.AGORA_APP_ID||'d6bc66d261fe41a296af1b2bf45f48a8').trim();
  const appCertificate=String(env.AGORA_APP_CERTIFICATE||'').trim();
  if(!appId||!appCertificate)return json({error:'AGORA_RTC_NOT_CONFIGURED',message:'AGORA_APP_CERTIFICATE Worker secret is required.'},503,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();
  const rtcSession=String(meta?.session_id||'').replace(/[^A-Za-z0-9_-]/g,'').slice(0,28);
  if(!rtcSession)return json({error:'LIVE_SESSION_NOT_READY'},409,cors);
  const channel=`myshop_${hostId}_${rtcSession}`;
  const uid=Number.parseInt(String(me.user_id),10);
  if(!Number.isInteger(uid)||uid<=0)return json({error:'INVALID_RTC_UID'},400,cors);
  const expiresIn=3600;
  const agoraRole=role==='PUBLISHER'?AgoraRtcRole.PUBLISHER:AgoraRtcRole.SUBSCRIBER;
  let rtcToken='';
  try{rtcToken=AgoraRtcTokenBuilder.buildTokenWithUid(appId,appCertificate,channel,uid,agoraRole,expiresIn,expiresIn);}catch(e){return json({error:'RTC_TOKEN_SIGN_FAILED'},500,cors);}
  if(!rtcToken)return json({error:'RTC_TOKEN_SIGN_FAILED'},500,cors);
  const rn=await env.DB.prepare(`SELECT COALESCE(NULLIF(title,''),'') title FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();
  return json({ok:true,appId,token:rtcToken,channel,uid,role,liveName:String(rn?.title||''),expiresIn,expiresAt:Date.now()+expiresIn*1000},200,cors);
}
async function liveRoomState(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
  const hostId=String(new URL(request.url).searchParams.get('hostId')||'').trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const live=await env.DB.prepare(`SELECT active,viewer_count FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  // Public viewer maintenance coalesces across participants; auth and sanctions remain per request.
  const viewerNow=await publicAggregate(env.DB,hostId+':viewerReconcile',async()=>{
    await env.DB.prepare(`DELETE FROM myshop_live_viewers WHERE host_id=? AND datetime(last_seen)<datetime('now','-25 seconds')`).bind(hostId).run();
    const viewerRow=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_viewers WHERE host_id=?`).bind(hostId).first();
    const count=Math.max(0,Number(viewerRow?.c||0));
    await env.DB.prepare(`UPDATE myshop_live_presence SET viewer_count=? WHERE user_id=? AND viewer_count<>?`).bind(count,hostId,count).run();
    await env.DB.prepare(`UPDATE myshop_live_room_meta SET peak_viewers=MAX(COALESCE(peak_viewers,0),?),updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND COALESCE(peak_viewers,0)<?`).bind(count,hostId,count).run();
    return count;
  });
  live.viewer_count=viewerNow;
  await env.DB.prepare(`DELETE FROM myshop_live_seats_dynamic WHERE host_id=? AND seat_no>99`).bind(hostId).run();
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_seats_dynamic(host_id,seat_no,user_id,role,mic_on,speaking,network_quality) VALUES(?,1,?,'HOST',1,0,'GOOD')`).bind(hostId,hostId).run();
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_room_meta(host_id,special_guest_id,locked,started_at) VALUES(?,NULL,0,CURRENT_TIMESTAMP)`).bind(hostId).run();
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET started_at=COALESCE(started_at,CURRENT_TIMESTAMP) WHERE host_id=?`).bind(hostId).run();
  await resetLiveReactionWindow(env,hostId);
  const seats=(await measureResult(env,'room.seats',env.DB.prepare(`SELECT s.seat_no,s.user_id,s.role,s.muted,COALESCE(s.mic_on,1) mic_on,COALESCE(s.speaking,0) speaking,COALESCE(s.network_quality,'GOOD') network_quality,u.full_name,u.avatar_url,COALESCE(u.gender,'UNSPECIFIED') gender,
      COALESCE(cw.balance,0) coin_balance,COALESCE(gw.balance,0) gold_balance,
      (CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=s.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=s.user_id),0)) AS level,
      COALESCE((SELECT b.badge_code FROM myshop_user_badges b WHERE b.user_id=s.user_id AND b.status='ACTIVE' AND (b.expires_at IS NULL OR datetime(b.expires_at)>datetime('now')) AND b.badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP') ORDER BY CASE b.badge_code WHEN 'KING' THEN 1 WHEN 'QUEEN' THEN 1 WHEN 'ROYAL' THEN 2 WHEN 'VVIP' THEN 3 WHEN 'VIP' THEN 4 ELSE 9 END LIMIT 1),'STANDARD') AS tier,
      COALESCE((SELECT COALESCE(NULLIF(c.animation_url,''),c.preview_url,'') FROM myshop_owned_items o JOIN myshop_store_catalog c ON c.id=o.catalog_id WHERE o.user_id=s.user_id AND o.equipped=1 AND o.item_type IN ('FRAME','AVATAR_FRAME','RING','ANIMATED_RING','PROFILE_STYLE') AND (o.expires_at IS NULL OR datetime(o.expires_at)>datetime('now')) ORDER BY CASE WHEN o.item_type IN ('FRAME','AVATAR_FRAME') THEN 1 ELSE 2 END,o.id DESC LIMIT 1),'') AS frame_url,COALESCE((SELECT COALESCE(NULLIF(mc.animation_url,''),mc.preview_url,'') FROM myshop_user_badges mb JOIN myshop_store_catalog mc ON mc.id=mb.catalog_id WHERE mb.user_id=s.user_id AND mb.status='ACTIVE' AND mb.badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP') AND (mb.expires_at IS NULL OR datetime(mb.expires_at)>datetime('now')) ORDER BY mb.is_displayed DESC,mb.id DESC LIMIT 1),'') AS membership_frame_url,
      CASE WHEN EXISTS(SELECT 1 FROM myshop_live_room_admins ra WHERE ra.host_id=s.host_id AND ra.user_id=s.user_id AND ra.active=1) THEN 1 ELSE 0 END AS room_admin,
      CASE WHEN EXISTS(SELECT 1 FROM myshop_live_mute_records mr WHERE mr.host_id=s.host_id AND mr.user_id=s.user_id) THEN 1 ELSE 0 END AS saved_muted,
      COALESCE((SELECT fc.points FROM myshop_live_fan_club fc WHERE fc.host_id=s.host_id AND fc.user_id=s.user_id AND fc.active=1),0) AS fan_points
      FROM myshop_live_seats_dynamic s
      LEFT JOIN myshop_auth_users_v108 u ON u.user_id=s.user_id
      LEFT JOIN myshop_coin_wallets cw ON cw.user_id=s.user_id
      LEFT JOIN myshop_gold_wallets gw ON gw.user_id=s.user_id
      WHERE s.host_id=? AND s.seat_no<=99 ORDER BY s.seat_no`).bind(hostId).all())).results||[];
  const livePermissions=await livePermissionSet(env,me,hostId);
  const reqMeta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();const requestSession=String(reqMeta?.session_id||'');if(requestSession)await env.DB.prepare(`UPDATE myshop_live_requests SET status='EXPIRED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND session_id=? AND status='PENDING' AND datetime(created_at)<datetime('now','-30 seconds')`).bind(hostId,requestSession).run();const requests=livePermissions.requests?((await env.DB.prepare(`SELECT r.user_id,r.status,r.created_at,u.full_name,u.avatar_url,COALESCE(fc.points,0) fan_points,CASE WHEN b.badge_code IN ('KING','QUEEN') THEN 5 WHEN b.badge_code='ROYAL' THEN 4 WHEN b.badge_code='VVIP' THEN 3 WHEN b.badge_code='VIP' THEN 2 ELSE 0 END tier_priority,COALESCE(b.badge_code,'STANDARD') tier FROM myshop_live_requests r LEFT JOIN myshop_auth_users_v108 u ON u.user_id=r.user_id LEFT JOIN myshop_live_fan_club fc ON fc.host_id=r.host_id AND fc.user_id=r.user_id AND fc.active=1 LEFT JOIN myshop_user_badges b ON b.user_id=r.user_id AND b.status='ACTIVE' AND (b.expires_at IS NULL OR datetime(b.expires_at)>datetime('now')) AND b.badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP') WHERE r.host_id=? AND r.status='PENDING' AND r.session_id=? GROUP BY r.user_id ORDER BY tier_priority DESC,fan_points DESC,r.created_at`).bind(hostId,requestSession).all()).results||[]):[];
  const inviteMeta=reqMeta;
  await env.DB.prepare(`UPDATE myshop_live_invites SET status='EXPIRED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND status='PENDING' AND datetime(expires_at)<=datetime('now')`).bind(hostId).run();
  const incomingInvite=me.user_id===hostId?null:await env.DB.prepare(`SELECT i.host_id,i.user_id,i.session_id,i.status,i.expires_at,i.created_at,i.invited_by,u.full_name host_name,iu.full_name inviter_name FROM myshop_live_invites i LEFT JOIN myshop_auth_users_v108 u ON u.user_id=i.host_id LEFT JOIN myshop_auth_users_v108 iu ON iu.user_id=i.invited_by WHERE i.host_id=? AND i.user_id=? AND i.session_id=? AND i.status='PENDING' AND datetime(i.expires_at)>datetime('now') LIMIT 1`).bind(hostId,me.user_id,String(inviteMeta?.session_id||'')).first();
  const outgoingInvites=me.user_id===hostId?((await env.DB.prepare(`SELECT i.user_id,i.status,i.expires_at,i.created_at,u.full_name,u.avatar_url FROM myshop_live_invites i LEFT JOIN myshop_auth_users_v108 u ON u.user_id=i.user_id WHERE i.host_id=? AND i.session_id=? AND i.status='PENDING' AND datetime(i.expires_at)>datetime('now') ORDER BY i.created_at DESC`).bind(hostId,String(inviteMeta?.session_id||'')).all()).results||[]):[];
  const meta=await env.DB.prepare(`SELECT special_guest_id,locked,title,topic,started_at,peak_viewers,share_count,pinned_message,theme_key,COALESCE(react_count,0) react_count,COALESCE(react_reward_milestone,0) react_reward_milestone,COALESCE(session_id,'') session_id,COALESCE(welcome_message,'') welcome_message,COALESCE(goal_type,'NONE') goal_type,COALESCE(goal_target,0) goal_target,COALESCE(pinned_product_id,0) pinned_product_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();
  const lockedRows=(await env.DB.prepare(`SELECT seat_no FROM myshop_live_seat_locks WHERE host_id=? AND locked=1 AND seat_no BETWEEN 2 AND 99 ORDER BY seat_no`).bind(hostId).all()).results||[];
  const events=(await env.DB.prepare(`SELECT e.id,e.event_type,e.message,e.created_at,u.full_name,u.avatar_url,
    COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=e.user_id),0) level
    FROM myshop_live_events e LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.user_id WHERE e.host_id=? AND e.session_id=? ORDER BY e.id DESC LIMIT 8`).bind(hostId,String(meta?.session_id||'')).all()).results||[];
  const ephKey=liveEphemeralKey(hostId,String(meta?.session_id||''));
  const myViewerJoin=me.user_id===hostId?null:await env.DB.prepare(`SELECT joined_at FROM myshop_live_viewers WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).first();
  const joinRaw=String(myViewerJoin?.joined_at||'');const joinParsed=joinRaw?Date.parse(joinRaw.includes('T')?joinRaw:(joinRaw.replace(' ','T')+'Z')):Date.now();const visibleSinceMs=me.user_id===hostId?0:Math.max(0,joinParsed||Date.now());
  const comments=liveEphemeralPrune(liveEphemeralComments,ephKey,80,60*60*1000).filter(x=>Number(x._ts||0)>=visibleSinceMs).slice(-80).map(x=>{const y={...x};delete y._ts;return y;});
  let theme=await env.DB.prepare(`SELECT theme_key,name,background_url,accent,COALESCE(fit_mode,'CENTER_CROP') fit_mode FROM myshop_live_themes WHERE theme_key=? AND enabled=1`).bind(String(meta?.theme_key||'GUITAR_BLUE')).first();
  const ownedTheme=await env.DB.prepare(`SELECT c.code theme_key,c.title name,COALESCE(NULLIF(c.animation_url,''),c.preview_url,'') background_url,'#7C5CFF' accent,'CENTER_CROP' fit_mode FROM myshop_owned_items o JOIN myshop_store_catalog c ON c.id=o.catalog_id WHERE o.user_id=? AND o.equipped=1 AND o.item_type IN ('THEME','LIVE_THEME','WALLPAPER') AND (o.expires_at IS NULL OR datetime(o.expires_at)>datetime('now')) ORDER BY o.id DESC LIMIT 1`).bind(hostId).first();if(ownedTheme)theme=ownedTheme;
  const seen=await publicAggregate(env.DB,hostId+':seen:'+String(reqMeta?.session_id||''),async()=>await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_listener_seen WHERE host_id=? AND started_at=?`).bind(hostId,String(meta?.started_at||'')).first());
  const topSupporters=await publicAggregate(env.DB,hostId+':topSupporters:'+String(reqMeta?.session_id||''),async()=>(await env.DB.prepare(`SELECT e.sender_id,u.full_name,u.avatar_url,u.gender,COALESCE((SELECT badge_code FROM myshop_user_badges ub WHERE ub.user_id=e.sender_id AND ub.status='ACTIVE' AND (ub.expires_at IS NULL OR datetime(ub.expires_at)>datetime('now')) ORDER BY ub.is_displayed DESC LIMIT 1),'STANDARD') tier,COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=e.sender_id),0) level,SUM(CASE WHEN e.currency='COIN' THEN e.price ELSE 0 END) coin_value,SUM(CASE WHEN e.currency='GOLD' THEN e.price ELSE 0 END) gold_value,SUM(CASE WHEN e.currency='GOLD' THEN e.price*100 ELSE e.price END) total_value,SUM(COALESCE(e.quantity,1)) gift_count FROM myshop_live_gift_events e LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id WHERE e.host_id=? AND e.sender_id<>e.host_id AND e.status='COMPLETED' GROUP BY e.sender_id ORDER BY total_value DESC,MAX(CASE WHEN e.price>0 THEN e.id ELSE 0 END) ASC,e.sender_id ASC LIMIT 20`).bind(hostId).all()).results||[]);
  const lifetimeTop1=String(topSupporters[0]?.sender_id||'');
  const viewerProfiles=(await measureResult(env,'room.viewers',env.DB.prepare(`SELECT v.user_id,u.full_name,u.avatar_url,COALESCE(u.gender,'UNSPECIFIED') gender,COALESCE(cw.balance,0) coin_balance,COALESCE(gw.balance,0) gold_balance,(CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=v.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=v.user_id),0)) AS level,COALESCE((SELECT b.badge_code FROM myshop_user_badges b WHERE b.user_id=v.user_id AND b.status='ACTIVE' AND (b.expires_at IS NULL OR datetime(b.expires_at)>datetime('now')) AND b.badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP') ORDER BY CASE b.badge_code WHEN 'KING' THEN 1 WHEN 'QUEEN' THEN 1 WHEN 'ROYAL' THEN 2 WHEN 'VVIP' THEN 3 WHEN 'VIP' THEN 4 ELSE 9 END LIMIT 1),'STANDARD') AS tier,COALESCE((SELECT COALESCE(NULLIF(c.animation_url,''),c.preview_url,'') FROM myshop_owned_items o JOIN myshop_store_catalog c ON c.id=o.catalog_id WHERE o.user_id=v.user_id AND o.equipped=1 AND o.item_type IN ('FRAME','AVATAR_FRAME','RING','ANIMATED_RING','PROFILE_STYLE') AND (o.expires_at IS NULL OR datetime(o.expires_at)>datetime('now')) ORDER BY CASE WHEN o.item_type IN ('FRAME','AVATAR_FRAME') THEN 1 ELSE 2 END,o.id DESC LIMIT 1),'') AS frame_url,COALESCE((SELECT COALESCE(NULLIF(mc.animation_url,''),mc.preview_url,'') FROM myshop_user_badges mb JOIN myshop_store_catalog mc ON mc.id=mb.catalog_id WHERE mb.user_id=v.user_id AND mb.status='ACTIVE' AND mb.badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP') AND (mb.expires_at IS NULL OR datetime(mb.expires_at)>datetime('now')) ORDER BY mb.is_displayed DESC,mb.id DESC LIMIT 1),'') AS membership_frame_url,CASE WHEN EXISTS(SELECT 1 FROM myshop_live_room_admins ra WHERE ra.host_id=v.host_id AND ra.user_id=v.user_id AND ra.active=1) THEN 1 ELSE 0 END AS room_admin,CASE WHEN EXISTS(SELECT 1 FROM myshop_live_mute_records mr WHERE mr.host_id=v.host_id AND mr.user_id=v.user_id) THEN 1 ELSE 0 END AS saved_muted,COALESCE((SELECT fc.points FROM myshop_live_fan_club fc WHERE fc.host_id=v.host_id AND fc.user_id=v.user_id AND fc.active=1),0) AS fan_points FROM myshop_live_viewers v LEFT JOIN myshop_auth_users_v108 u ON u.user_id=v.user_id LEFT JOIN myshop_coin_wallets cw ON cw.user_id=v.user_id LEFT JOIN myshop_gold_wallets gw ON gw.user_id=v.user_id WHERE v.host_id=? AND datetime(v.last_seen)>=datetime('now','-25 seconds') ORDER BY CASE WHEN v.user_id=? THEN 0 ELSE 1 END,CASE tier WHEN 'KING' THEN 1 WHEN 'QUEEN' THEN 1 WHEN 'ROYAL' THEN 2 WHEN 'VVIP' THEN 3 WHEN 'VIP' THEN 4 ELSE 9 END,coin_balance DESC,datetime(v.last_seen) DESC,v.user_id ASC LIMIT 100`).bind(hostId,lifetimeTop1).all())).results||[];
  let mySanction=await liveSanctionFor(env,hostId,me.user_id);if(mySanction==='MUTED'){await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state='MUTED'`).bind(hostId,me.user_id).run();mySanction='NONE';}const myRoomAdmin=await isRoomAdmin(env,hostId,me.user_id);const myGlobalModerator=String(me.role||'').toUpperCase()==='MODERATOR'||await isAssignedModerator(env,me.user_id);const canSuggestCall=(me.user_id===hostId||myRoomAdmin||isAdminUser(me)||myGlobalModerator);
  const liveStart=String(meta?.started_at||''),sessionId=String(meta?.session_id||'');
  try{await liveHubRegister(request,env,hostId,sessionId,me.user_id);}catch(e){}

  const hourlyTop=await publicAggregate(env.DB,hostId+':hourlyTop:'+String(reqMeta?.session_id||''),async()=>(await env.DB.prepare(`SELECT e.sender_id,u.full_name,u.avatar_url,SUM(CASE WHEN e.currency='GOLD' THEN e.price*100 ELSE e.price END) total_value,SUM(CASE WHEN e.currency='COIN' THEN e.price ELSE 0 END) coin_value,SUM(CASE WHEN e.currency='GOLD' THEN e.price ELSE 0 END) gold_value,SUM(COALESCE(e.quantity,1)) gift_count FROM myshop_live_gift_events e LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id WHERE e.host_id=? AND e.status='COMPLETED' AND datetime(e.created_at)>=datetime('now','-1 hour') AND (?='' OR e.session_id=?) GROUP BY e.sender_id ORDER BY total_value DESC,gift_count DESC LIMIT 10`).bind(hostId,sessionId,sessionId).all()).results||[]);
  const rankMap=new Map(topSupporters.map((x,i)=>[String(x.sender_id),i+1]));
  const visibleIds=[...new Set([...viewerProfiles,...seats].map(x=>String(x.user_id||'')).filter(Boolean))];const progressRows=visibleIds.length?((await env.DB.prepare(`SELECT user_id,COALESCE(stars,0) stars FROM myshop_user_progress WHERE user_id IN (${visibleIds.map(()=>'?').join(',')})`).bind(...visibleIds).all()).results||[]):[];const starsMap=new Map(progressRows.map(x=>[String(x.user_id),Math.max(0,Number(x.stars||0))]));
  for(const v of viewerProfiles){v.supporterRank=rankMap.get(String(v.user_id))||0;v.roomAdmin=Number(v.room_admin||0)===1;v.saved_muted=Number(v.saved_muted||0);v.fanPoints=Number(v.fan_points||0);v.coin_balance=Math.max(0,Number(v.coin_balance||0));v.gold_balance=Math.max(0,Number(v.gold_balance||0));v.stars=starsMap.get(String(v.user_id))||0;delete v.room_admin;delete v.fan_points;}
  for(const seat of seats){seat.roomAdmin=Number(seat.room_admin||0)===1;seat.fanPoints=Number(seat.fan_points||0);seat.coin_balance=Math.max(0,Number(seat.coin_balance||0));seat.gold_balance=Math.max(0,Number(seat.gold_balance||0));seat.stars=starsMap.get(String(seat.user_id))||0;delete seat.room_admin;delete seat.fan_points;}
  const visibleProfileMap=new Map(viewerProfiles.map(x=>[String(x.user_id),x]));for(const r of requests){const v=visibleProfileMap.get(String(r.user_id));if(v){r.level=Number(v.level||0);r.coin_balance=Number(v.coin_balance||0);r.gold_balance=Number(v.gold_balance||0);r.stars=Number(v.stars||0);r.tier=String(v.tier||r.tier||'STANDARD');}}
  // Only the lifetime Top1 has priority over memberships; KING and QUEEN share a tier.
  const tierRank={KING:1,QUEEN:1,ROYAL:2,VVIP:3,VIP:4,STANDARD:9};viewerProfiles.sort((a,b)=>{
    const at=String(a.user_id)===lifetimeTop1,bt=String(b.user_id)===lifetimeTop1;
    if(at!==bt)return at?-1:1;
    const tr=(tierRank[String(a.tier||'STANDARD').toUpperCase()]||9)-(tierRank[String(b.tier||'STANDARD').toUpperCase()]||9);
    if(tr)return tr;return Number(b.coin_balance||0)-Number(a.coin_balance||0);
  });
  const highlights=liveEphemeralPrune(liveEphemeralHighlights,ephKey,20,12000).filter(x=>Number(x._ts||0)>=visibleSinceMs).slice(-10).reverse().map(x=>{const y={...x};delete y._ts;return y;});
  const myTier=await currentTier(env,me.user_id);const myLevelInfo=await coinLevelFor(env,me.user_id);
  const startedMs=liveStart?Date.parse(liveStart.replace(' ','T')+'Z'):0;const elapsedSeconds=startedMs&&Number.isFinite(startedMs)?Math.max(0,Math.floor((Date.now()-startedMs)/1000)):0;
  const giftAgg=await publicAggregate(env.DB,hostId+':giftAgg:'+String(reqMeta?.session_id||''),async()=>await env.DB.prepare(`SELECT COALESCE(SUM(price),0) total,COUNT(DISTINCT sender_id) supporters FROM myshop_live_gift_events WHERE host_id=? AND status='COMPLETED' AND ((?<>'' AND session_id=?) OR (?='' AND (?='' OR datetime(created_at)>=datetime(?))))`).bind(hostId,sessionId,sessionId,sessionId,liveStart,liveStart).first());
  const goalType=String(meta?.goal_type||'NONE').toUpperCase(),goalTarget=Math.max(0,Number(meta?.goal_target||0));let goalCurrent=0;if(goalType==='COIN')goalCurrent=Number(giftAgg?.total||0);else if(goalType==='SUPPORTERS')goalCurrent=Number(giftAgg?.supporters||0);else if(goalType==='MINUTES')goalCurrent=Math.floor(elapsedSeconds/60);else if(goalType==='VIEWERS')goalCurrent=Number(live.viewer_count||0);
  const fan=await env.DB.prepare(`SELECT active,points FROM myshop_live_fan_club WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).first();const fanCountRow=await publicAggregate(env.DB,hostId+':fanCountRow:'+String(reqMeta?.session_id||''),async()=>await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_fan_club WHERE host_id=? AND active=1`).bind(hostId).first());
  const hist=await publicAggregate(env.DB,hostId+':hist:'+String(reqMeta?.session_id||''),async()=>await env.DB.prepare(`SELECT COUNT(*) live_count,COALESCE(SUM(duration_seconds),0) total_duration,COALESCE(MAX(peak_viewers),0) best_peak FROM myshop_live_history WHERE host_id=?`).bind(hostId).first());const allGifts=await publicAggregate(env.DB,hostId+':allGifts:'+String(reqMeta?.session_id||''),async()=>await env.DB.prepare(`SELECT COALESCE(SUM(price),0) total FROM myshop_live_gift_events WHERE host_id=? AND status='COMPLETED'`).bind(hostId).first());
  const hostLiveLevel=Math.min(99,Math.max(1,1+Math.floor((Number(hist?.live_count||0)*2+Number(hist?.total_duration||0)/1800+Number(allGifts?.total||0)/5000)/5)));const roomLevel=Math.min(99,Math.max(1,1+Math.floor((Number(live.viewer_count||0)+Number(meta?.react_count||0)/100+Number(giftAgg?.total||0)/500)/10)));
  const entryEvents=(await env.DB.prepare(`SELECT e.id,e.user_id,e.tier,e.item_code,e.animation_url,e.animation_mime,e.sound_url,e.sound_volume,e.effect_duration_ms,e.sound_duration_ms,e.animation_speed,e.created_at,u.full_name,u.avatar_url,COALESCE((SELECT COALESCE(NULLIF(c.animation_url,''),c.preview_url,'') FROM myshop_user_badges b JOIN myshop_store_catalog c ON c.id=b.catalog_id WHERE b.user_id=e.user_id AND b.status='ACTIVE' AND b.badge_code=e.tier AND (b.expires_at IS NULL OR datetime(b.expires_at)>datetime('now')) ORDER BY b.id DESC LIMIT 1),'') membership_frame_url FROM myshop_live_entry_events e LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.user_id WHERE e.host_id=? AND datetime(e.created_at)>=datetime('now','-9 seconds') AND (?='' OR datetime(e.created_at)>=datetime(?)) ORDER BY e.id DESC LIMIT 8`).bind(hostId,liveStart,liveStart).all()).results||[];
  const viewerCutoffSql=me.user_id===hostId?'1970-01-01 00:00:00':String(myViewerJoin?.joined_at||new Date().toISOString().slice(0,19).replace('T',' '));
  const giftEvents=(await env.DB.prepare(`SELECT e.id,e.sender_id,e.receiver_id,e.currency,e.price,e.created_at,g.name,g.preview_url,g.animation_url,g.animation_mime,g.animation_enabled,g.sound_url,g.sound_enabled,g.sound_volume,g.effect_duration_ms,g.sound_duration_ms,g.sound_trim_start_pct,g.sound_trim_end_pct,g.vat_percent,g.board_position,g.animation_scale,g.size_mode,u.full_name sender_name,u.avatar_url sender_avatar,(CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=e.sender_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=e.sender_id),0)) AS sender_level,ru.full_name receiver_name FROM myshop_live_gift_events e JOIN myshop_live_gifts g ON g.id=e.gift_id LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id LEFT JOIN myshop_auth_users_v108 ru ON ru.user_id=e.receiver_id WHERE e.host_id=? AND e.status='COMPLETED' AND datetime(e.created_at)>=datetime('now','-60 seconds') AND datetime(e.created_at)>=datetime(?) AND (?='' OR e.session_id=?) ORDER BY e.id ASC LIMIT 30`).bind(hostId,viewerCutoffSql,sessionId,sessionId).all()).results||[];
  const hostWallet=await env.DB.prepare(`SELECT COALESCE(cw.balance,0) coin_balance,COALESCE(gw.balance,0) gold_balance,COALESCE(up.stars,0) stars FROM myshop_auth_users_v108 u LEFT JOIN myshop_coin_wallets cw ON cw.user_id=u.user_id LEFT JOIN myshop_gold_wallets gw ON gw.user_id=u.user_id LEFT JOIN myshop_user_progress up ON up.user_id=u.user_id WHERE u.user_id=?`).bind(hostId).first();
  const giftTotal=await env.DB.prepare(`SELECT COUNT(*) total FROM myshop_live_gift_events WHERE host_id=? AND status='COMPLETED' AND (?='' OR session_id=?)`).bind(hostId,sessionId,sessionId).first();
  const hostStats={totalGift:Number(giftTotal?.total||0),coinBalance:Number(hostWallet?.coin_balance||0),goldBalance:Number(hostWallet?.gold_balance||0),stars:Number(hostWallet?.stars||0)};
  const voteRow=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_votes WHERE host_id=?`).bind(hostId).first();const voteCount=Number(voteRow?.c||0);
  let pinnedProduct=null;if(Number(meta?.pinned_product_id||0)>0)try{pinnedProduct=await env.DB.prepare(`SELECT id,title,description,category,image_url,price,stock FROM shop_products WHERE id=? AND enabled=1 AND deleted=0`).bind(Number(meta.pinned_product_id)).first();}catch(e){}
  let pk=null;const pkRow=await env.DB.prepare(`SELECT * FROM myshop_live_pk_rounds WHERE (host_a=? OR host_b=?) AND status IN ('PENDING','ACTIVE') ORDER BY id DESC LIMIT 1`).bind(hostId,hostId).first();if(pkRow){let scoreA=0,scoreB=0;if(String(pkRow.status)==='ACTIVE'){const sa=await env.DB.prepare(`SELECT COALESCE(SUM(price),0) s FROM myshop_live_gift_events WHERE host_id=? AND status='COMPLETED' AND (?='' OR session_id=?) AND datetime(created_at)>=datetime(?)`).bind(pkRow.host_a,String(pkRow.session_a||''),String(pkRow.session_a||''),String(pkRow.started_at||'1970-01-01')).first();const sb=await env.DB.prepare(`SELECT COALESCE(SUM(price),0) s FROM myshop_live_gift_events WHERE host_id=? AND status='COMPLETED' AND (?='' OR session_id=?) AND datetime(created_at)>=datetime(?)`).bind(pkRow.host_b,String(pkRow.session_b||''),String(pkRow.session_b||''),String(pkRow.started_at||'1970-01-01')).first();scoreA=Number(sa?.s||0);scoreB=Number(sb?.s||0);}pk={id:Number(pkRow.id),hostA:String(pkRow.host_a),hostB:String(pkRow.host_b),status:String(pkRow.status),incoming:me.user_id===hostId&&String(pkRow.status)==='PENDING'&&String(pkRow.host_b)===hostId,scoreA,scoreB};}
  const milestones=[];const vcNow=Number(live.viewer_count||0);for(const x of [10,50,100,500,1000])if(vcNow>=x)milestones.push('VIEWERS_'+x);if(goalTarget>0&&goalCurrent>=goalTarget)milestones.push('GOAL_COMPLETE');if(Number(meta?.react_count||0)>=2000)milestones.push('REACT_2K');
  // V-394: request state is synchronized for every participant. Requester identity remains
  // host-only, but everybody can see the shared count and each requester sees their own status.
  const requestCountRow=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_requests WHERE host_id=? AND status='PENDING' AND session_id=?`).bind(hostId,sessionId).first();
  const myRequestRow=me.user_id===hostId?null:await env.DB.prepare(`SELECT status FROM myshop_live_requests WHERE host_id=? AND user_id=? AND session_id=? LIMIT 1`).bind(hostId,me.user_id,sessionId).first();
  const requestCount=Math.max(0,Number(requestCountRow?.c||0)),myRequestStatus=String(myRequestRow?.status||'NONE');
  const hostFollowRow=me.user_id===hostId?null:await env.DB.prepare(`SELECT 1 ok FROM myshop_follows WHERE follower_id=? AND following_id=? LIMIT 1`).bind(me.user_id,hostId).first();
  const hostFollowing=me.user_id!==hostId&&!!hostFollowRow;
  const adminInvite=me.user_id===hostId?null:await env.DB.prepare(`SELECT i.host_id,i.status,i.created_at,u.full_name host_name FROM myshop_live_room_admin_invites i LEFT JOIN myshop_auth_users_v108 u ON u.user_id=i.host_id WHERE i.host_id=? AND i.user_id=? AND i.status='PENDING' LIMIT 1`).bind(hostId,me.user_id).first();
  const poll=await env.DB.prepare(`SELECT p.*,(SELECT COUNT(*) FROM myshop_live_poll_votes v WHERE v.poll_id=p.id AND v.choice='A') votes_a,(SELECT COUNT(*) FROM myshop_live_poll_votes v WHERE v.poll_id=p.id AND v.choice='B') votes_b,(SELECT choice FROM myshop_live_poll_votes v WHERE v.poll_id=p.id AND v.user_id=?) my_choice FROM myshop_live_polls p WHERE p.host_id=? AND p.session_id=? AND p.status='ACTIVE' ORDER BY p.id DESC LIMIT 1`).bind(me.user_id,hostId,sessionId).first();
  const callSuggestions=me.user_id===hostId?((await env.DB.prepare(`SELECT s.admin_id,s.user_id,s.created_at,au.full_name admin_name,au.avatar_url admin_avatar,tu.full_name user_name,tu.avatar_url user_avatar,COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=s.user_id),0) user_level FROM myshop_live_call_suggestions s LEFT JOIN myshop_auth_users_v108 au ON au.user_id=s.admin_id LEFT JOIN myshop_auth_users_v108 tu ON tu.user_id=s.user_id WHERE s.host_id=? AND s.session_id=? AND s.status='PENDING' AND datetime(s.created_at)>=datetime('now','-30 seconds') ORDER BY s.created_at ASC LIMIT 10`).bind(hostId,sessionId).all()).results||[]):[];
  return json({ok:true,hostId,hostFollowing,viewerCount:Number(live.viewer_count||0),seats,requests,requestCount,myRequestStatus,incomingInvite:incomingInvite||null,incomingAdminInvite:adminInvite||null,callSuggestions,outgoingInvites,specialGuestId:String(meta?.special_guest_id||''),locked:Number(meta?.locked||0)===1,lockedSeats:lockedRows.map(x=>Number(x.seat_no)),title:String(meta?.title||"Let's Talk Together"),topic:String(meta?.topic||'Audio Live'),startedAt:String(meta?.started_at||''),elapsedSeconds,peakViewers:Number(meta?.peak_viewers||0),totalListeners:Number(seen?.c||0),shareCount:Number(meta?.share_count||0),reactCount:Number(meta?.react_count||0),voteCount,reactRewardMilestone:Number(meta?.react_reward_milestone||0),sessionId,pinnedMessage:(!meta?.pinned_until||Date.parse(meta.pinned_until)>Date.now())?String(meta?.pinned_message||''):'',welcomeMessage:String(meta?.welcome_message||''),goal:{type:goalType,target:goalTarget,current:goalCurrent,completed:goalTarget>0&&goalCurrent>=goalTarget},pinnedProduct:pinnedProduct||null,poll:poll||null,hostLiveLevel,roomLevel,fanClub:{joined:Number(fan?.active||0)===1,points:Number(fan?.points||0),memberCount:Number(fanCountRow?.c||0)},pk,milestones,theme:theme||{theme_key:'GUITAR_BLUE',name:'Guitar Blue',background_url:'',accent:'#5B67FF',fit_mode:'CENTER_CROP'},viewerProfiles,topSupporters:topSupporters.map((x,i)=>({...x,rank:i+1})),hourlyTop:hourlyTop.map((x,i)=>({...x,rank:i+1})),highlightComments:highlights.reverse(),highlightDirection:'RIGHT_TO_LEFT',entryTier:myTier,myLevel:Number(myLevelInfo.level||0),entryEvents,giftEvents,hostStats,events:events.reverse(),comments:comments,myRole:me.user_id===hostId?'HOST':(seats.some(x=>x.user_id===me.user_id)?'SPEAKER':'AUDIENCE'),mySanction,myRoomAdmin,livePermissions,canSuggestCall:livePermissions.invite,canPinComments:livePermissions.pin},200,cors);
}
async function liveSpeakRequest(request,env,ctx){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);await env.DB.prepare(`UPDATE myshop_live_requests SET status='EXPIRED',updated_at=CURRENT_TIMESTAMP WHERE status='PENDING' AND datetime(created_at)<datetime('now','-2 minutes')`).run();const b=await body(request),hostId=String(b.hostId||'').trim();if(!isFourDigit(hostId)||hostId===me.user_id)return json({error:'INVALID_REQUEST'},400,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  const sanction=await liveSanctionFor(env,hostId,me.user_id);if(sanction==='BLOCKED'||sanction==='KICKED')return json({error:'LIVE_BLOCKED'},403,cors);if(sanction==='MUTED')await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state='MUTED'`).bind(hostId,me.user_id).run();
  const seated=await env.DB.prepare(`SELECT seat_no FROM myshop_live_seats_dynamic WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).first();if(seated)return json({ok:true,status:'ACCEPTED',seatNo:Number(seated.seat_no),alreadySeated:true},200,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();const sessionId=String(meta?.session_id||'');if(!sessionId)return json({error:'LIVE_SESSION_NOT_READY'},409,cors);
  const privileged=(await isRoomAdmin(env,hostId,me.user_id))||isAdminUser(me)||String(me.role||'').toUpperCase()==='MODERATOR'||await isAssignedModerator(env,me.user_id);
  if(privileged){const free=await env.DB.prepare(`WITH RECURSIVE n(x) AS (SELECT 2 UNION ALL SELECT x+1 FROM n WHERE x<99) SELECT x seat_no FROM n WHERE x NOT IN (SELECT seat_no FROM myshop_live_seats_dynamic WHERE host_id=?) AND x NOT IN (SELECT seat_no FROM myshop_live_seat_locks WHERE host_id=? AND locked=1) AND x NOT IN (SELECT seat_no FROM myshop_live_seat_cooldowns WHERE host_id=? AND datetime(released_at)>datetime('now','-3 seconds')) ORDER BY x LIMIT 1`).bind(hostId,hostId,hostId).first();if(!free)return json({error:'NO_FREE_SEAT'},409,cors);await env.DB.prepare(`INSERT INTO myshop_live_seats_dynamic(host_id,seat_no,user_id,role,muted,mic_on,speaking,updated_at) VALUES(?,?,?,'SPEAKER',0,1,0,CURRENT_TIMESTAMP)`).bind(hostId,free.seat_no,me.user_id).run();await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'SPEAKER_JOIN','joined call with privileged auto-join')`).bind(hostId,me.user_id,sessionId).run();await liveHubDirty(env,hostId,sessionId,'PRIVILEGED_AUTO_JOIN');return json({ok:true,status:'ACCEPTED',seatNo:Number(free.seat_no),autoJoined:true},200,cors);}
  // Any call request is also proof that this viewer is actively inside the room.
  await env.DB.prepare(`INSERT INTO myshop_live_viewers(host_id,user_id,last_seen,joined_at) VALUES(?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id) DO UPDATE SET last_seen=CURRENT_TIMESTAMP`).bind(hostId,me.user_id).run();
  const existing=await env.DB.prepare(`SELECT status,COALESCE(session_id,'') session_id FROM myshop_live_requests WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).first();
  if(existing&&String(existing.status)==='PENDING'&&String(existing.session_id||'')===sessionId)return json({ok:true,status:'PENDING',duplicateSuppressed:true},200,cors);
  await env.DB.prepare(`INSERT INTO myshop_live_requests(host_id,user_id,session_id,status,created_at,updated_at) VALUES(?,?,?,'PENDING',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id) DO UPDATE SET session_id=excluded.session_id,status='PENDING',created_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP`).bind(hostId,me.user_id,sessionId).run();
  await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'JOIN_REQUEST','requested to join the call')`).bind(hostId,me.user_id,sessionId).run();
  await liveHubDirty(env,hostId,sessionId,'JOIN_REQUEST');
  const notice=createUserNotification(env,hostId,'Live Join Request',(me.full_name||'A user')+' wants to join your live call.','LIVE_JOIN_REQUEST',me.user_id,hostId).catch(e=>console.error('LIVE_NOTICE_FAILED',String(e?.message||e)));if(ctx?.waitUntil)ctx.waitUntil(notice);else await notice;
  return json({ok:true,status:'PENDING'},200,cors);
}
async function liveCancelSpeakRequest(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
  const b=await body(request),hostId=String(b.hostId||'').trim();if(!isFourDigit(hostId)||hostId===me.user_id)return json({error:'INVALID_REQUEST'},400,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();const sessionId=String(meta?.session_id||'');
  if(!sessionId)return json({ok:true,status:'CANCELLED',alreadyClosed:true},200,cors);
  const changed=await env.DB.prepare(`UPDATE myshop_live_requests SET status='CANCELLED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=? AND status='PENDING'`).bind(hostId,me.user_id,sessionId).run();
  await liveHubDirty(env,hostId,sessionId,'JOIN_REQUEST_CANCELLED');
  return json({ok:true,status:'CANCELLED',changed:Number(changed?.meta?.changes||0)>0},200,cors);
}
async function liveRequestAction(request,env,ctx){
  const host=await getUser(request,env);if(!host)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);await env.DB.prepare(`UPDATE myshop_live_requests SET status='EXPIRED',updated_at=CURRENT_TIMESTAMP WHERE status='PENDING' AND datetime(created_at)<datetime('now','-2 minutes')`).run();const b=await body(request),rid=String(b.requesterId||'').trim(),action=String(b.action||'').toUpperCase();const targetHostId=String(b.hostId||host.user_id);if(!isFourDigit(targetHostId)||!(await hasLivePermission(env,host,targetHostId,'requests')))return json({error:'LIVE_PERMISSION_REQUIRED',action:'requests'},403,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(targetHostId).first();if(!live||Number(live.active)!==1)return json({error:'HOST_NOT_LIVE'},403,cors);if(!isFourDigit(rid)||!['ACCEPT','REJECT'].includes(action))return json({error:'INVALID_REQUEST'},400,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(targetHostId).first();const sessionId=String(meta?.session_id||'');const req=await env.DB.prepare(`SELECT status,COALESCE(session_id,'') session_id FROM myshop_live_requests WHERE host_id=? AND user_id=?`).bind(targetHostId,rid).first();if(!req||String(req.status)!=='PENDING'||(String(req.session_id||'')!==''&&String(req.session_id||'')!==sessionId))return json({error:'REQUEST_NOT_PENDING'},409,cors);if(String(req.session_id||'')==='')await env.DB.prepare(`UPDATE myshop_live_requests SET session_id=?,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=?`).bind(sessionId,targetHostId,rid).run();
  if(action==='REJECT'){
    await env.DB.prepare(`UPDATE myshop_live_requests SET status='REJECTED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=?`).bind(targetHostId,rid,sessionId).run();
    await liveHubDirty(env,targetHostId,sessionId,'JOIN_REQUEST_REJECTED');
    const notice=createUserNotification(env,rid,'Live Request Update',(host.full_name||'Host')+' declined your join request.','LIVE_JOIN_REJECTED',targetHostId,targetHostId).catch(e=>console.error('LIVE_NOTICE_FAILED',String(e?.message||e)));if(ctx?.waitUntil)ctx.waitUntil(notice);else await notice;
    return json({ok:true,status:'REJECTED'},200,cors);
  }
  const free=await env.DB.prepare(`WITH RECURSIVE n(x) AS (SELECT 2 UNION ALL SELECT x+1 FROM n WHERE x<99) SELECT x seat_no FROM n WHERE x NOT IN (SELECT seat_no FROM myshop_live_seats_dynamic WHERE host_id=?) AND x NOT IN (SELECT seat_no FROM myshop_live_seat_locks WHERE host_id=? AND locked=1) AND x NOT IN (SELECT seat_no FROM myshop_live_seat_cooldowns WHERE host_id=? AND datetime(released_at)>datetime('now','-3 seconds')) ORDER BY x LIMIT 1`).bind(targetHostId,targetHostId,targetHostId).first();if(!free)return json({error:'NO_FREE_SEAT'},409,cors);
  const already=await env.DB.prepare(`SELECT seat_no FROM myshop_live_seats_dynamic WHERE host_id=? AND user_id=?`).bind(targetHostId,rid).first();if(already)return json({ok:true,status:'ACCEPTED',seatNo:Number(already.seat_no),alreadySeated:true},200,cors);
  // V-398: a newly accepted speaker always enters visible and mic-on. Previous mute records must never auto-mute a fresh call join.
  await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state='MUTED'`).bind(targetHostId,rid).run();
  await env.DB.prepare(`DELETE FROM myshop_live_mute_records WHERE host_id=? AND user_id=?`).bind(targetHostId,rid).run();
  await env.DB.prepare(`INSERT INTO myshop_live_seats_dynamic(host_id,seat_no,user_id,role,muted,mic_on,speaking,updated_at) VALUES(?,?,?,'SPEAKER',0,1,0,CURRENT_TIMESTAMP)`).bind(targetHostId,free.seat_no,rid).run();
  await env.DB.prepare(`UPDATE myshop_live_requests SET status='ACCEPTED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=?`).bind(targetHostId,rid,sessionId).run();
  await env.DB.prepare(`UPDATE myshop_live_invites SET status='CANCELLED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND status='PENDING'`).bind(targetHostId,rid).run();
  await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'SPEAKER_JOIN','joined the call after host accepted request')`).bind(targetHostId,rid,sessionId).run();
  await liveHubDirty(env,targetHostId,sessionId,'SPEAKER_ACCEPTED');
  const notice=createUserNotification(env,rid,'Join Request Accepted',(host.full_name||'Host')+' accepted you into the live call.','LIVE_JOIN_ACCEPTED',targetHostId,targetHostId).catch(e=>console.error('LIVE_NOTICE_FAILED',String(e?.message||e)));if(ctx?.waitUntil)ctx.waitUntil(notice);else await notice;
  return json({ok:true,status:'ACCEPTED',seatNo:Number(free.seat_no)},200,cors);
}
async function liveInvite(request,env,ctx){
  const actor=await getUser(request,env);if(!actor)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
  const b=await body(request),uid=String(b.userId||'').trim(),requestedHostId=String(b.hostId||'').trim();
  const hostId=isFourDigit(requestedHostId)?requestedHostId:actor.user_id;
  if(!isFourDigit(hostId)||!isFourDigit(uid)||uid===hostId)return json({error:'INVALID_INVITE_TARGET'},400,cors);
  const hostActor=actor.user_id===hostId,roomAdmin=await isRoomAdmin(env,hostId,actor.user_id),globalAdmin=isAdminUser(actor),globalModerator=String(actor.role||'').toUpperCase()==='MODERATOR'||await isAssignedModerator(env,actor.user_id);
  if(!(await hasLivePermission(env,actor,hostId,'invite')))return json({error:'LIVE_PERMISSION_REQUIRED',action:'invite'},403,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'HOST_NOT_LIVE'},403,cors);
  const viewer=await env.DB.prepare(`SELECT 1 x FROM myshop_live_viewers WHERE host_id=? AND user_id=? AND datetime(last_seen)>=datetime('now','-30 seconds')`).bind(hostId,uid).first();if(!viewer)return json({error:'USER_NOT_IN_LIVE'},409,cors);
  // A viewer visible in the top audience strip must remain callable while the host acts on it.
  // Refresh presence on a valid invite so a heartbeat race cannot invalidate the call between render and tap.
  await env.DB.prepare(`UPDATE myshop_live_viewers SET last_seen=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=?`).bind(hostId,uid).run();
  const seated=await env.DB.prepare(`SELECT seat_no FROM myshop_live_seats_dynamic WHERE host_id=? AND user_id=?`).bind(hostId,uid).first();if(seated)return json({error:'ALREADY_SPEAKER'},409,cors);
  const sanction=await liveSanctionFor(env,hostId,uid);if(['BLOCKED','KICKED'].includes(sanction))return json({error:'USER_NOT_ELIGIBLE_FOR_CALL'},403,cors);
  // Repair legacy stale MUTED rows so they can never hide a user or block a call suggestion.
  if(sanction==='MUTED')await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state='MUTED'`).bind(hostId,uid).run();
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();const sessionId=String(meta?.session_id||'');if(!sessionId)return json({error:'LIVE_SESSION_NOT_READY'},409,cors);
  // Host, Room Admin, global Admin and Moderator can send the viewer a direct invite. The viewer accepts; no second host approval is required.
  const openInvite=await env.DB.prepare(`SELECT status,expires_at FROM myshop_live_invites WHERE host_id=? AND user_id=? AND session_id=?`).bind(hostId,uid,sessionId).first();
  if(openInvite&&String(openInvite.status)==='PENDING'&&Date.parse(String(openInvite.expires_at).replace(' ','T')+'Z')>Date.now())return json({ok:true,status:'PENDING',duplicateSuppressed:true,expiresInSeconds:90},200,cors);
  await env.DB.prepare(`INSERT INTO myshop_live_invites(host_id,user_id,session_id,status,expires_at,created_at,updated_at,invited_by) VALUES(?,?,?,'PENDING',datetime('now','+90 seconds'),CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,?) ON CONFLICT(host_id,user_id,session_id) DO UPDATE SET status='PENDING',expires_at=datetime('now','+90 seconds'),updated_at=CURRENT_TIMESTAMP,invited_by=excluded.invited_by`).bind(hostId,uid,sessionId,actor.user_id).run();
  await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'CALL_INVITE','was invited to join the call')`).bind(hostId,uid,sessionId).run();
  const hostUser=hostActor?actor:await env.DB.prepare(`SELECT full_name FROM myshop_auth_users_v108 WHERE user_id=?`).bind(hostId).first();
  await liveHubDirty(env,hostId,sessionId,'CALL_INVITE');
  const notice=createUserNotification(env,uid,'Live Call Invitation',(hostUser?.full_name||'Host')+' invited you to join the live call.','LIVE_CALL_INVITE',actor.user_id,hostId).catch(e=>console.error('Call notification failed',String(e)));
  if(ctx?.waitUntil)ctx.waitUntil(notice);else await notice;
  return json({ok:true,status:'PENDING',invitedBy:actor.user_id,expiresInSeconds:90},200,cors);
}
async function liveInviteAction(request,env,ctx){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||'').trim(),action=String(b.action||'').toUpperCase();if(!isFourDigit(hostId)||!['ACCEPT','DECLINE'].includes(action))return json({error:'INVALID_INVITE_ACTION'},400,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();const sessionId=String(meta?.session_id||'');
  const inv=await env.DB.prepare(`SELECT status,expires_at FROM myshop_live_invites WHERE host_id=? AND user_id=? AND session_id=?`).bind(hostId,me.user_id,sessionId).first();if(!inv||String(inv.status)!=='PENDING')return json({error:'INVITE_NOT_PENDING'},409,cors);if(Date.parse(String(inv.expires_at).replace(' ','T')+'Z')<=Date.now()){await env.DB.prepare(`UPDATE myshop_live_invites SET status='EXPIRED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=?`).bind(hostId,me.user_id,sessionId).run();await liveHubDirty(env,hostId,sessionId,'CALL_INVITE_EXPIRED');return json({error:'INVITE_EXPIRED'},409,cors);}
  if(action==='DECLINE'){await env.DB.prepare(`UPDATE myshop_live_invites SET status='DECLINED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=?`).bind(hostId,me.user_id,sessionId).run();await createUserNotification(env,hostId,'Call Invitation Update',(me.full_name||'A user')+' declined your live call invitation.','LIVE_CALL_INVITE_DECLINED',me.user_id,hostId,ctx);await liveHubDirty(env,hostId,sessionId,'CALL_INVITE_DECLINED');return json({ok:true,status:'DECLINED'},200,cors);}
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  // V-388: accepting a still-pending invite is itself an active room interaction. Repair a
  // delayed heartbeat once so weak networks do not make RECEIVE fail after the user taps it.
  await env.DB.prepare(`INSERT INTO myshop_live_viewers(host_id,user_id,last_seen,joined_at) VALUES(?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id) DO UPDATE SET last_seen=CURRENT_TIMESTAMP`).bind(hostId,me.user_id).run();
  const sanction=await liveSanctionFor(env,hostId,me.user_id);if(['BLOCKED','KICKED'].includes(sanction))return json({error:'NOT_ELIGIBLE_FOR_CALL'},403,cors);if(sanction==='MUTED')await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state='MUTED'`).bind(hostId,me.user_id).run();
  const already=await env.DB.prepare(`SELECT seat_no FROM myshop_live_seats_dynamic WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).first();if(already){await env.DB.prepare(`UPDATE myshop_live_invites SET status='ACCEPTED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=?`).bind(hostId,me.user_id,sessionId).run();await liveHubDirty(env,hostId,sessionId,'SPEAKER_ALREADY_SEATED');return json({ok:true,status:'ACCEPTED',seatNo:Number(already.seat_no),alreadySeated:true},200,cors);}
  const free=await env.DB.prepare(`WITH RECURSIVE n(x) AS (SELECT 2 UNION ALL SELECT x+1 FROM n WHERE x<99) SELECT x seat_no FROM n WHERE x NOT IN (SELECT seat_no FROM myshop_live_seats_dynamic WHERE host_id=?) AND x NOT IN (SELECT seat_no FROM myshop_live_seat_locks WHERE host_id=? AND locked=1) AND x NOT IN (SELECT seat_no FROM myshop_live_seat_cooldowns WHERE host_id=? AND datetime(released_at)>datetime('now','-3 seconds')) ORDER BY x LIMIT 1`).bind(hostId,hostId,hostId).first();if(!free)return json({error:'NO_FREE_SEAT'},409,cors);
  // V-398: accepting an invite starts the call unmuted; only explicit live moderation/user action may mute afterward.
  await env.DB.prepare(`DELETE FROM myshop_live_mute_records WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).run();
  await env.DB.prepare(`INSERT INTO myshop_live_seats_dynamic(host_id,seat_no,user_id,role,muted,mic_on,speaking,updated_at) VALUES(?,?,?,'SPEAKER',0,1,0,CURRENT_TIMESTAMP)`).bind(hostId,free.seat_no,me.user_id).run();
  await env.DB.prepare(`UPDATE myshop_live_invites SET status='ACCEPTED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=?`).bind(hostId,me.user_id,sessionId).run();
  await env.DB.prepare(`UPDATE myshop_live_requests SET status='ACCEPTED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=? AND status='PENDING'`).bind(hostId,me.user_id,sessionId).run();
  await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'SPEAKER_JOIN','joined the call after accepting host invitation')`).bind(hostId,me.user_id,sessionId).run();
  await liveHubDirty(env,hostId,sessionId,'SPEAKER_INVITE_ACCEPTED');
  const notice=createUserNotification(env,hostId,'Call Invitation Accepted',(me.full_name||'A user')+' accepted your invitation and joined the call.','LIVE_CALL_INVITE_ACCEPTED',me.user_id,hostId).catch(e=>console.error('LIVE_NOTICE_FAILED',String(e?.message||e)));if(ctx?.waitUntil)ctx.waitUntil(notice);else await notice;
  return json({ok:true,status:'ACCEPTED',seatNo:Number(free.seat_no)},200,cors);
}
async function liveLeaveSeat(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||'').trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const existing=await env.DB.prepare(`SELECT seat_no FROM myshop_live_seats_dynamic WHERE host_id=? AND user_id=? AND seat_no>1 LIMIT 1`).bind(hostId,me.user_id).first();
  await env.DB.prepare(`DELETE FROM myshop_live_seats_dynamic WHERE host_id=? AND user_id=? AND seat_no>1`).bind(hostId,me.user_id).run();if(existing)await env.DB.prepare(`INSERT INTO myshop_live_seat_cooldowns(host_id,seat_no,released_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(host_id,seat_no) DO UPDATE SET released_at=CURRENT_TIMESTAMP`).bind(hostId,Number(existing.seat_no)).run();
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET special_guest_id=NULL,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND special_guest_id=?`).bind(hostId,me.user_id).run();
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();
  if(existing&&String(meta?.session_id||''))await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'SPEAKER_LEAVE','left the call')`).bind(hostId,me.user_id,String(meta.session_id)).run();
  if(existing&&String(meta?.session_id||''))await liveHubDirty(env,hostId,String(meta.session_id),'SPEAKER_LEFT');
  return json({ok:true,role:'AUDIENCE',wasSpeaker:!!existing},200,cors);
}

async function liveSeatAssign(request,env){
  const actor=await getUser(request,env);if(!actor)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
  const b=await body(request),seatNo=Math.floor(Number(b.seatNo||0));if(seatNo<2||seatNo>99)return json({error:'INVALID_SEAT_ASSIGNMENT'},400,cors);
  const requestedHostId=String(b.hostId||'').trim();
  const selfMove=isFourDigit(requestedHostId)&&requestedHostId!==actor.user_id;
  const hostId=selfMove?requestedHostId:actor.user_id;
  const uid=selfMove?actor.user_id:String(b.userId||'').trim();
  if(!isFourDigit(hostId)||!isFourDigit(uid)||uid===hostId)return json({error:'INVALID_SEAT_ASSIGNMENT'},400,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'HOST_NOT_LIVE'},403,cors);
  if(!selfMove && hostId!==actor.user_id)return json({error:'HOST_ONLY'},403,cors);
  const speaker=await env.DB.prepare(`SELECT seat_no FROM myshop_live_seats_dynamic WHERE host_id=? AND user_id=?`).bind(hostId,uid).first();if(!speaker)return json({error:'USER_NOT_SPEAKER'},409,cors);
  const locked=await env.DB.prepare(`SELECT locked FROM myshop_live_seat_locks WHERE host_id=? AND seat_no=?`).bind(hostId,seatNo).first();if(Number(locked?.locked||0)===1)return json({error:'SEAT_LOCKED'},409,cors);
  const occupied=await env.DB.prepare(`SELECT user_id FROM myshop_live_seats_dynamic WHERE host_id=? AND seat_no=?`).bind(hostId,seatNo).first();if(occupied&&String(occupied.user_id)!==uid)return json({error:'SEAT_OCCUPIED'},409,cors);
  await env.DB.prepare(`UPDATE myshop_live_seats_dynamic SET seat_no=?,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=?`).bind(seatNo,hostId,uid).run();
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET special_guest_id=NULL,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND special_guest_id=?`).bind(hostId,uid).run();
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();
  await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'SEAT_MOVE',?)`).bind(hostId,uid,String(meta?.session_id||''),'moved to guest seat '+seatNo).run();
  if(String(meta?.session_id||''))await liveHubDirty(env,hostId,String(meta.session_id),'SEAT_MOVED');
  return json({ok:true,userId:uid,seatNo,selfMove},200,cors);
}

async function liveSpecialGuest(request,env){
  const host=await getUser(request,env);if(!host)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
  const b=await body(request),uid=String(b.userId||'').trim(),clear=b.clear===true;
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(host.user_id).first();if(!live||Number(live.active)!==1)return json({error:'HOST_NOT_LIVE'},403,cors);
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_room_meta(host_id,special_guest_id,locked) VALUES(?,NULL,0)`).bind(host.user_id).run();
  if(clear){await env.DB.prepare(`UPDATE myshop_live_room_meta SET special_guest_id=NULL,updated_at=CURRENT_TIMESTAMP WHERE host_id=?`).bind(host.user_id).run();await liveHubDirtyForHost(env,host.user_id,'SPECIAL_GUEST_CLEARED');return json({ok:true,specialGuestId:''},200,cors);}
  if(!isFourDigit(uid)||uid===host.user_id)return json({error:'INVALID_SPECIAL_GUEST'},400,cors);
  const seated=await env.DB.prepare(`SELECT seat_no FROM myshop_live_seats_dynamic WHERE host_id=? AND user_id=? AND seat_no>1`).bind(host.user_id,uid).first();
  if(!seated)return json({error:'USER_NOT_ON_SPEAKER_SEAT'},409,cors);
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET special_guest_id=?,updated_at=CURRENT_TIMESTAMP WHERE host_id=?`).bind(uid,host.user_id).run();
  await liveHubDirtyForHost(env,host.user_id,'SPECIAL_GUEST_SET');
  return json({ok:true,specialGuestId:uid,seatNo:Number(seated.seat_no)},200,cors);
}
async function liveSpeakerRemove(request,env){
  const host=await getUser(request,env);if(!host)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),uid=String(b.userId||'').trim();
  if(!isFourDigit(uid)||uid===host.user_id)return json({error:'INVALID_SPEAKER'},400,cors);
  await env.DB.prepare(`DELETE FROM myshop_live_seats_dynamic WHERE host_id=? AND user_id=? AND seat_no>1`).bind(host.user_id,uid).run();
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET special_guest_id=NULL,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND special_guest_id=?`).bind(host.user_id,uid).run();
  await liveHubDirtyForHost(env,host.user_id,'SPEAKER_REMOVED');
  return json({ok:true},200,cors);
}


async function liveCommentUiConfig(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);await ensureLevelSchema(env);
  const legacy=await env.DB.prepare(`SELECT font_size FROM myshop_live_comment_ui WHERE id=1`).first();
  const grow=await env.DB.prepare(`SELECT style_json FROM myshop_live_comment_global WHERE id=1`).first();
  let globalStyle={};try{globalStyle=JSON.parse(String(grow?.style_json||'{}'));}catch(e){}
  if(!globalStyle.fontSize)globalStyle={backgroundColor:'#0A1841',textColor:'#FFFFFF',nameColor:'#FFFFFF',levelColor:'#FFD54F',borderColor:'#4B67BD',fontSize:Number(legacy?.font_size||15),fontWeight:'NORMAL',borderWidth:1,cornerRadius:14,opacity:92,borderGlow:false,borderGlowColor:'#A855F7',borderGlowIntensity:55,backgroundGlow:false,animation:false,animationType:'PULSE',animationSpeed:55};
  const pr=(await env.DB.prepare(`SELECT preset_key,badge,gender,preset_no,style_json FROM myshop_live_comment_presets ORDER BY badge,gender,preset_no`).all()).results||[];
  const presets=pr.map(r=>{let o={};try{o=JSON.parse(String(r.style_json||'{}'));}catch(e){}return {...o,presetKey:r.preset_key,badge:r.badge,gender:r.gender,presetNo:Number(r.preset_no||1)};});
  // Expiry is enforced at Live-config read time too, so a membership/comment skin can never
  // remain visible merely because the owner has not opened My Items after its expiry time.
  try{
    await env.DB.prepare(`UPDATE myshop_user_badges SET status='EXPIRED',is_displayed=0 WHERE status='ACTIVE' AND expires_at IS NOT NULL AND datetime(expires_at)<=datetime('now')`).run();
    await env.DB.prepare(`UPDATE myshop_live_comment_assignments AS a SET enabled=0,updated_at=CURRENT_TIMESTAMP WHERE a.source='MEMBERSHIP' AND a.enabled=1 AND NOT EXISTS (SELECT 1 FROM myshop_user_badges b WHERE b.user_id=a.user_id AND b.status='ACTIVE' AND b.badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP') AND (b.expires_at IS NULL OR datetime(b.expires_at)>datetime('now')))`).run();
  }catch(e){console.error('PREMIUM_LIVE_EXPIRY_SYNC_FAILED',String(e?.message||e));}
  const ar=(await env.DB.prepare(`SELECT a.user_id,a.preset_key,a.custom_style_json,a.is_custom,a.enabled,u.full_name AS name,COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=a.user_id),0) AS level FROM myshop_live_comment_assignments a LEFT JOIN myshop_auth_users_v108 u ON u.user_id=a.user_id WHERE a.enabled=1`).all()).results||[];
  const assignments=ar.map(r=>{let c={};try{c=JSON.parse(String(r.custom_style_json||'{}'));}catch(e){}return {userId:r.user_id,presetKey:r.preset_key||'',customStyle:c,isCustom:Number(r.is_custom||0)===1,enabled:Number(r.enabled||0)===1,name:r.name||'',level:Number(r.level||0)};});
  return json({ok:true,globalStyle,presets,assignments},200,cors);
}
function cleanCommentStyle(input){
  const s=(input&&typeof input==='object')?input:{};const hex=(v,d)=>/^#[0-9A-Fa-f]{6}$/.test(String(v||''))?String(v).toUpperCase():d;
  const pick=(v,allowed,d)=>allowed.includes(String(v||d).toUpperCase())?String(v||d).toUpperCase():d;
  return {backgroundColor:hex(s.backgroundColor,'#0A1841'),textColor:hex(s.textColor,'#FFFFFF'),nameColor:hex(s.nameColor,'#FFFFFF'),levelColor:hex(s.levelColor,'#FFD54F'),borderColor:hex(s.borderColor,'#4B67BD'),fontSize:Math.max(12,Math.min(28,Math.floor(Number(s.fontSize||15)))),fontWeight:String(s.fontWeight||'NORMAL').toUpperCase()==='BOLD'?'BOLD':'NORMAL',borderWidth:Math.max(1,Math.min(6,Math.floor(Number(s.borderWidth||1)))),cornerRadius:Math.max(4,Math.min(30,Math.floor(Number(s.cornerRadius||14)))),opacity:Math.max(30,Math.min(100,Math.floor(Number(s.opacity||92)))),borderGlow:s.borderGlow===true,borderGlowColor:hex(s.borderGlowColor,'#A855F7'),borderGlowIntensity:Math.max(0,Math.min(100,Math.floor(Number(s.borderGlowIntensity||55)))),backgroundGlow:s.backgroundGlow===true,animation:s.animation===true,animationType:pick(s.animationType,['PULSE','SOFT FADE','FADE','POP','NONE'],'PULSE'),animationSpeed:Math.max(10,Math.min(100,Math.floor(Number(s.animationSpeed||55)))),boxAnimation:s.boxAnimation===true,boxAnimationType:pick(s.boxAnimationType,['FADE','PULSE','POP','NONE'],'FADE'),borderAnimation:s.borderAnimation===true,borderAnimationType:pick(s.borderAnimationType,['GLOW BORDER','PULSE BORDER','SOFT FLASH','NONE'],'GLOW BORDER'),textAnimation:s.textAnimation===true,textAnimationType:pick(s.textAnimationType,['FADE TEXT','PULSE TEXT','NONE'],'FADE TEXT'),nameAnimation:s.nameAnimation===true,nameAnimationType:pick(s.nameAnimationType,['SOFT GLOW','FADE','NONE'],'SOFT GLOW'),levelAnimation:s.levelAnimation===true,levelAnimationType:pick(s.levelAnimationType,['SOFT GLOW','FADE','NONE'],'SOFT GLOW')};
}
async function adminLiveCommentGlobalSave(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!isAdminUser(me))return json({error:'FORBIDDEN'},403,cors);await ensureLiveRoomSchema(env);const b=await body(request),style=cleanCommentStyle(b.style);
  await env.DB.prepare(`INSERT INTO myshop_live_comment_global(id,style_json,updated_at) VALUES(1,?,CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET style_json=excluded.style_json,updated_at=CURRENT_TIMESTAMP`).bind(JSON.stringify(style)).run();
  await env.DB.prepare(`UPDATE myshop_live_comment_ui SET font_size=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`).bind(style.fontSize).run();
  return json({ok:true,style},200,cors);
}
async function adminLiveCommentPresetSave(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!isAdminUser(me))return json({error:'FORBIDDEN'},403,cors);await ensureLiveRoomSchema(env);const b=await body(request);
  if(b.membershipPreset===true){
    const tier=membershipTier(b.badge);if(!tier)return json({error:'INVALID_BADGE'},400,cors);
    const key='V430-'+tier,style=cleanCommentStyle({...b,animation:false,boxAnimation:false});
    await env.DB.prepare(`INSERT INTO myshop_live_comment_presets(preset_key,badge,gender,preset_no,style_json,updated_at) VALUES(?,?,'UNSPECIFIED',1,?,CURRENT_TIMESTAMP) ON CONFLICT(preset_key) DO UPDATE SET style_json=excluded.style_json,updated_at=CURRENT_TIMESTAMP`).bind(key,tier,JSON.stringify(style)).run();
    return json({ok:true,presetKey:key,style},200,cors);
  }
  const badge=String(b.badge||'').trim().toUpperCase(),gender=String(b.gender||'').trim().toUpperCase(),presetNo=Math.max(1,Math.min(5,Math.floor(Number(b.presetNo||1))));
  if(!['VIP','VVIP','ROYAL','KING','QUEEN'].includes(badge))return json({error:'INVALID_BADGE'},400,cors);if(!['MALE','FEMALE'].includes(gender))return json({error:'INVALID_GENDER'},400,cors);if(badge==='KING'&&gender!=='MALE')return json({error:'KING_MALE_ONLY'},400,cors);if(badge==='QUEEN'&&gender!=='FEMALE')return json({error:'QUEEN_FEMALE_ONLY'},400,cors);
  const key=`${badge}-${gender}-${presetNo}`,style=cleanCommentStyle(b);
  await env.DB.prepare(`INSERT INTO myshop_live_comment_presets(preset_key,badge,gender,preset_no,style_json,updated_at) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(preset_key) DO UPDATE SET badge=excluded.badge,gender=excluded.gender,preset_no=excluded.preset_no,style_json=excluded.style_json,updated_at=CURRENT_TIMESTAMP`).bind(key,badge,gender,presetNo,JSON.stringify(style)).run();
  return json({ok:true,presetKey:key,style},200,cors);
}
async function adminLiveCommentAssignmentSave(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!isAdminUser(me))return json({error:'FORBIDDEN'},403,cors);await ensureLiveRoomSchema(env);await ensureLevelSchema(env);const b=await body(request),uid=String(b.userId||'').trim();
  if(!isFourDigit(uid))return json({error:'INVALID_USER_ID'},400,cors);const u=await env.DB.prepare(`SELECT user_id,full_name AS name,COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=myshop_auth_users_v108.user_id),0) AS level FROM myshop_auth_users_v108 WHERE user_id=?`).bind(uid).first();if(!u)return json({error:'USER_NOT_FOUND'},404,cors);
  const isCustom=b.custom===true,presetKey=isCustom?'':String(b.presetKey||'').trim().toUpperCase(),enabled=b.enabled===false?0:1;let custom={};
  if(!enabled){
    await env.DB.prepare(`INSERT INTO myshop_live_comment_assignments(user_id,preset_key,custom_style_json,is_custom,enabled,source,updated_at) VALUES(?,?,?,?,0,'ADMIN',CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET preset_key='',custom_style_json='{}',is_custom=0,enabled=0,source='ADMIN',updated_at=CURRENT_TIMESTAMP`).bind(uid,'','{}',0).run();
    return json({ok:true,userId:uid,name:u.name||'',level:Number(u.level||0),presetKey:'',isCustom:false,enabled:false},200,cors);
  }
  if(isCustom)custom=cleanCommentStyle(b.customStyle);else{if(!presetKey)return json({error:'PRESET_REQUIRED'},400,cors);const p=await env.DB.prepare(`SELECT preset_key FROM myshop_live_comment_presets WHERE preset_key=?`).bind(presetKey).first();if(!p)return json({error:'SAVE_PRESET_FIRST'},409,cors);}
  await env.DB.prepare(`INSERT INTO myshop_live_comment_assignments(user_id,preset_key,custom_style_json,is_custom,enabled,source,updated_at) VALUES(?,?,?,?,?,'ADMIN',CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET preset_key=excluded.preset_key,custom_style_json=excluded.custom_style_json,is_custom=excluded.is_custom,enabled=excluded.enabled,source='ADMIN',updated_at=CURRENT_TIMESTAMP`).bind(uid,presetKey,JSON.stringify(custom),isCustom?1:0,enabled).run();
  return json({ok:true,userId:uid,name:u.name||'',level:Number(u.level||0),presetKey,isCustom},200,cors);
}
async function liveBatchSettings(request,env){
 const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=request.method==='POST'?await body(request):{},hostId=String(b.hostId||new URL(request.url).searchParams.get('hostId')||'');
 if(!isFourDigit(hostId))return json({error:'INVALID_HOST'},400,cors);if(me.user_id!==hostId&&!isAdminUser(me)&&!(await isRoomAdmin(env,hostId,me.user_id))&&!(await isAssignedModerator(env,me.user_id)))return json({error:'FORBIDDEN'},403,cors);
 if(!(await hasLivePermission(env,me,hostId,'settings')))return json({error:'LIVE_PERMISSION_REQUIRED',action:'settings'},403,cors);
 const meta=await env.DB.prepare(`SELECT slow_mode_seconds,gift_combo_enabled,pinned_message,pinned_until,session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();if(!meta)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
 if(request.method==='POST'){
  if((b.restore===true||Object.prototype.hasOwnProperty.call(b,'pinnedMessage')||Object.prototype.hasOwnProperty.call(b,'pinnedUntil'))&&!(await hasLivePermission(env,me,hostId,'pin')))return json({error:'LIVE_PERMISSION_REQUIRED',action:'pin'},403,cors);
  let values=b;
  if(b.restore===true){const prior=await env.DB.prepare(`SELECT previous_json FROM myshop_live_setting_history WHERE host_id=? ORDER BY id DESC LIMIT 1`).bind(hostId).first();if(!prior)return json({error:'NO_PREVIOUS_SETTINGS'},404,cors);values=JSON.parse(prior.previous_json);}
  const seconds=Number(values.slowModeSeconds??meta.slow_mode_seconds),enabled=values.giftComboEnabled??(Number(meta.gift_combo_enabled)===1),minutes=Number(values.pinnedMinutes??0),pin=String(values.pinnedMessage??meta.pinned_message).slice(0,180);
  if(!Number.isInteger(seconds)||seconds<0||seconds>60||typeof enabled!=='boolean'||!Number.isInteger(minutes)||minutes<0||minutes>1440)return json({error:'INVALID_SETTINGS'},400,cors);
  const until=values.pinnedUntil??(Object.prototype.hasOwnProperty.call(values,'pinnedMessage')?(minutes?new Date(Date.now()+minutes*60000).toISOString():''):meta.pinned_until);
  const previous={slowModeSeconds:Number(meta.slow_mode_seconds),giftComboEnabled:Number(meta.gift_combo_enabled)===1,pinnedMessage:String(meta.pinned_message||''),pinnedUntil:String(meta.pinned_until||'')};
  await env.DB.batch([env.DB.prepare(`INSERT INTO myshop_live_setting_history(host_id,actor_id,previous_json,new_json) VALUES(?,?,?,?)`).bind(hostId,me.user_id,JSON.stringify(previous),JSON.stringify({slowModeSeconds:seconds,giftComboEnabled:enabled,pinnedMessage:pin,pinnedUntil:until})),env.DB.prepare(`UPDATE myshop_live_room_meta SET slow_mode_seconds=?,gift_combo_enabled=?,pinned_message=?,pinned_until=?,updated_at=CURRENT_TIMESTAMP WHERE host_id=?`).bind(seconds,enabled?1:0,pin,until,hostId)]);
  await liveHubDirtyForHost(env,hostId,'SETTINGS_CHANGED');return json({ok:true},200,cors);
 }
 return json({ok:true,slowModeSeconds:Number(meta.slow_mode_seconds||0),giftComboEnabled:Number(meta.gift_combo_enabled)===1,pinnedMessage:meta.pinned_message||''},200,cors);
}

async function liveRoomConfig(request,env){
  const actor=await getUser(request,env);if(!actor)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request);
  const targetHostId=String(b.hostId||actor.user_id).trim();if(!isFourDigit(targetHostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const hostActor=actor.user_id===targetHostId,roomAdmin=await isRoomAdmin(env,targetHostId,actor.user_id),globalAdmin=isAdminUser(actor),globalModerator=String(actor.role||'').toUpperCase()==='MODERATOR';
  const onlyPin=Object.prototype.hasOwnProperty.call(b,'pinnedMessage')&&!Object.prototype.hasOwnProperty.call(b,'title')&&!Object.prototype.hasOwnProperty.call(b,'topic')&&!Object.prototype.hasOwnProperty.call(b,'themeKey')&&!Object.prototype.hasOwnProperty.call(b,'slowModeSeconds')&&!Object.prototype.hasOwnProperty.call(b,'entryEffectsEnabled')&&!Object.prototype.hasOwnProperty.call(b,'giftComboEnabled');
  if(!(await hasLivePermission(env,actor,targetHostId,onlyPin?'pin':'settings')))return json({error:'LIVE_PERMISSION_REQUIRED'},403,cors);
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_room_meta(host_id,started_at) VALUES(?,CURRENT_TIMESTAMP)`).bind(targetHostId).run();
  const host=actor,fields=[],vals=[];
  if(Object.prototype.hasOwnProperty.call(b,'title')){const policy=await applyLiveNamePolicy(env,host.user_id,String(b.title||''));if(!policy.ok)return json({error:policy.error,remainingSeconds:policy.remainingSeconds||0,cost:policy.cost||0},409,cors);fields.push('title=?');vals.push(policy.name);}
  if(Object.prototype.hasOwnProperty.call(b,'topic')){fields.push('topic=?');vals.push(String(b.topic||'').trim().slice(0,120)||'Audio Live');}
  if(Object.prototype.hasOwnProperty.call(b,'pinnedMessage')){fields.push('pinned_message=?');vals.push(String(b.pinnedMessage||'').trim().slice(0,180));}
  if(Object.prototype.hasOwnProperty.call(b,'themeKey')){const k=String(b.themeKey||'').trim();const ok=await env.DB.prepare(`SELECT 1 x FROM myshop_live_themes WHERE theme_key=? AND enabled=1`).bind(k).first();if(!ok)return json({error:'THEME_NOT_AVAILABLE'},409,cors);fields.push('theme_key=?');vals.push(k);}
  if(Object.prototype.hasOwnProperty.call(b,'slowModeSeconds')){fields.push('slow_mode_seconds=?');vals.push(Math.max(0,Math.min(60,Number(b.slowModeSeconds||0))));}
  if(Object.prototype.hasOwnProperty.call(b,'entryEffectsEnabled')){fields.push('entry_effects_enabled=?');vals.push(b.entryEffectsEnabled===false?0:1);}
  if(Object.prototype.hasOwnProperty.call(b,'giftComboEnabled')){fields.push('gift_combo_enabled=?');vals.push(b.giftComboEnabled===false?0:1);}
  if(fields.length){vals.push(targetHostId);await env.DB.prepare(`UPDATE myshop_live_room_meta SET ${fields.join(',')},updated_at=CURRENT_TIMESTAMP WHERE host_id=?`).bind(...vals).run();await liveHubDirtyForHost(env,targetHostId,'ROOM_CONFIG');}
  return json({ok:true},200,cors);
}
async function liveSeatLock(request,env){
  const host=await getUser(request,env);if(!host)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),seatNo=Number(b.seatNo||0),locked=b.locked!==false;
  if(seatNo<2||seatNo>99)return json({error:'INVALID_SEAT'},400,cors);const occupied=await env.DB.prepare(`SELECT 1 x FROM myshop_live_seats_dynamic WHERE host_id=? AND seat_no=?`).bind(host.user_id,seatNo).first();if(occupied&&locked)return json({error:'SEAT_OCCUPIED'},409,cors);
  if(locked)await env.DB.prepare(`INSERT INTO myshop_live_seat_locks(host_id,seat_no,locked,updated_at) VALUES(?,?,1,CURRENT_TIMESTAMP) ON CONFLICT(host_id,seat_no) DO UPDATE SET locked=1,updated_at=CURRENT_TIMESTAMP`).bind(host.user_id,seatNo).run();
  else await env.DB.prepare(`DELETE FROM myshop_live_seat_locks WHERE host_id=? AND seat_no=?`).bind(host.user_id,seatNo).run();
  await liveHubDirtyForHost(env,host.user_id,locked?'SEAT_LOCKED':'SEAT_UNLOCKED');
  return json({ok:true,seatNo,locked},200,cors);
}
async function liveParticipantState(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||'').trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const micOn=b.micOn===false?0:1,speaking=b.speaking===true?1:0,userAction=b.userAction===true;let nq=String(b.networkQuality||'GOOD').toUpperCase();if(!['GOOD','FAIR','WEAK','OFFLINE'].includes(nq))nq='GOOD';
  // Heartbeats may never bypass a Host/Admin mute. Saved mute is audio-only and is
  // deliberately separate from comments, presence and call-invite eligibility.
  const savedMute=await env.DB.prepare(`SELECT 1 ok FROM myshop_live_mute_records WHERE host_id=? AND user_id=? LIMIT 1`).bind(hostId,me.user_id).first();
  if(savedMute){
    await env.DB.prepare(`UPDATE myshop_live_seats_dynamic SET mic_on=0,speaking=0,network_quality=?,muted=1,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND (mic_on<>0 OR speaking<>0 OR muted<>1 OR network_quality<>?)`).bind(nq,hostId,me.user_id,nq).run();
    return json({ok:true,muted:true},200,cors);
  }
  await env.DB.prepare(`UPDATE myshop_live_seats_dynamic SET mic_on=?,speaking=?,network_quality=?,muted=0,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND (mic_on<>? OR speaking<>? OR muted<>0 OR network_quality<>?)`).bind(micOn,speaking,nq,hostId,me.user_id,micOn,speaking,nq).run();
  if(micOn&&userAction)await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state='MUTED'`).bind(hostId,me.user_id).run();
  return json({ok:true,muted:false},200,cors);
}
async function liveShare(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||'').trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET share_count=COALESCE(share_count,0)+1,updated_at=CURRENT_TIMESTAMP WHERE host_id=?`).bind(hostId).run();const r=await env.DB.prepare(`SELECT share_count FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();return json({ok:true,shareCount:Number(r?.share_count||0)},200,cors);
}
async function liveComment(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
  const b=await body(request),hostId=String(b.hostId||'').trim(),message=String(b.message||'').trim().slice(0,240),clientNonce=String(b.clientNonce||'').trim().slice(0,80);
  if(!isFourDigit(hostId)||!message)return json({error:'INVALID_COMMENT'},400,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  const sanction=await liveSanctionFor(env,hostId,me.user_id);if(sanction==='MUTED')await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state='MUTED'`).bind(hostId,me.user_id).run();if(sanction==='BLOCKED'||sanction==='KICKED')return json({error:'LIVE_BLOCKED'},403,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(slow_mode_seconds,0) slow_mode_seconds,COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();
  const sessionId=String(meta?.session_id||'');if(!sessionId)return json({error:'LIVE_SESSION_NOT_READY'},409,cors);
  // A delivered comment must make its sender visible to Host even if a heartbeat was delayed.
  if(me.user_id!==hostId)await env.DB.prepare(`INSERT INTO myshop_live_viewers(host_id,user_id,last_seen,joined_at) VALUES(?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id) DO UPDATE SET last_seen=CURRENT_TIMESTAMP`).bind(hostId,me.user_id).run();
  const key=liveEphemeralKey(hostId,sessionId),list=liveEphemeralPrune(liveEphemeralComments,key,80,60*60*1000);
  const slow=Math.max(0,Math.min(60,Number(meta?.slow_mode_seconds||0)));
  if(slow>0&&!await isFixedMainAdminId(me.user_id)&&!(await isAssignedModerator(env,me.user_id))){
    const last=[...list].reverse().find(x=>String(x.user_id)===String(me.user_id));
    if(last){const age=(Date.now()-Number(last._ts||0))/1000;if(age<slow)return json({error:'SLOW_MODE',retryAfter:Math.ceil(slow-age)},429,cors);}
  }
  if(clientNonce){const old=list.find(x=>String(x.user_id)===String(me.user_id)&&String(x.client_nonce||'')===clientNonce);if(old){const c={...old};delete c._ts;return json({ok:true,duplicateSuppressed:true,sessionId,comment:c},200,cors);}}
  const dup=[...list].reverse().find(x=>String(x.user_id)===String(me.user_id)&&String(x.message)===message&&Date.now()-Number(x._ts||0)<=2000);
  if(dup){const c={...dup};delete c._ts;return json({ok:true,duplicateSuppressed:true,sessionId,comment:c},200,cors);}
  const commentLevel=await coinLevelFor(env,me.user_id);const equippedComment=await env.DB.prepare(`SELECT o.item_code,COALESCE(NULLIF(c.animation_url,''),c.preview_url,'') style_url FROM myshop_owned_items o JOIN myshop_store_catalog c ON c.id=o.catalog_id WHERE o.user_id=? AND o.item_type='COMMENT_STYLE' AND o.equipped=1 AND (o.expires_at IS NULL OR datetime(o.expires_at)>datetime('now')) ORDER BY o.id DESC LIMIT 1`).bind(me.user_id).first();const comment={user_id:me.user_id,message,client_nonce:clientNonce,created_at:new Date().toISOString(),full_name:me.full_name||me.user_id,avatar_url:me.avatar_url||'',gender:me.gender||'UNSPECIFIED',level:Number(commentLevel.level||0),tier:await currentTier(env,me.user_id),comment_style_code:String(equippedComment?.item_code||''),comment_style_url:String(equippedComment?.style_url||'')};
  let out=null;
  try{const pushed=await liveHubPush(env,hostId,sessionId,'COMMENT',comment);if(pushed?.item)out=pushed.item;}catch(e){}
  if(out){if(!list.some(x=>Number(x.id||0)===Number(out.id||0)))liveEphemeralPush(liveEphemeralComments,key,{...out,_ts:Date.now()},80,60*60*1000);}
  else return json({error:'REALTIME_DELIVERY_FAILED',message:'Comment was not delivered. Please retry.'},503,cors);
  return json({ok:true,ephemeral:true,realtime:true,sessionId,comment:out},201,cors);
}
async function liveThemes(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const rows=(await env.DB.prepare(`SELECT theme_key,name,background_url,accent,COALESCE(fit_mode,'CENTER_CROP') fit_mode,COALESCE(coin_price,0) coin_price,sort_order FROM myshop_live_themes WHERE enabled=1 ORDER BY sort_order,name`).all()).results||[];return json({ok:true,themes:rows},200,cors);
}
async function adminLiveTheme(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!isAdminUser(me))return json({error:'FORBIDDEN'},403,cors);await ensureLiveRoomSchema(env);const b=await body(request),action=String(b.action||'UPSERT').toUpperCase(),key=String(b.themeKey||'').trim().toUpperCase();if(!/^[A-Z0-9_-]{2,40}$/.test(key))return json({error:'INVALID_THEME_KEY'},400,cors);
  if(action==='DELETE'){if(key==='GUITAR_BLUE')return json({error:'DEFAULT_THEME_PROTECTED'},409,cors);await env.DB.prepare(`DELETE FROM myshop_live_themes WHERE theme_key=?`).bind(key).run();return json({ok:true},200,cors);}
  const name=String(b.name||key).trim().slice(0,60),bg=String(b.backgroundUrl||'').trim().slice(0,500),accent=String(b.accent||'#5B67FF').trim().slice(0,16),coinPrice=Math.max(0,Math.floor(Number(b.coinPrice||0))),enabled=b.enabled===false?0:1,sort=Number(b.sortOrder||0),fitMode=['FIT','FILL','CENTER_CROP'].includes(String(b.fitMode||'CENTER_CROP').toUpperCase())?String(b.fitMode||'CENTER_CROP').toUpperCase():'CENTER_CROP';
  await env.DB.prepare(`INSERT INTO myshop_live_themes(theme_key,name,background_url,accent,coin_price,enabled,sort_order,fit_mode,updated_at) VALUES(?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(theme_key) DO UPDATE SET name=excluded.name,background_url=excluded.background_url,accent=excluded.accent,coin_price=excluded.coin_price,enabled=excluded.enabled,sort_order=excluded.sort_order,fit_mode=excluded.fit_mode,updated_at=CURRENT_TIMESTAMP`).bind(key,name,bg,accent,coinPrice,enabled,sort,fitMode).run();return json({ok:true,coinPrice},200,cors);
}
async function liveUiSettings(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
  const r=await env.DB.prepare(`SELECT join_font_size,join_text_color FROM myshop_live_ui_settings WHERE id=1`).first();
  return json({ok:true,joinFontSize:Math.max(14,Math.min(26,Number(r?.join_font_size||18))),joinTextColor:String(r?.join_text_color||'#FFFFFF')},200,cors);
}
async function adminLiveUiSettings(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!isAdminUser(me))return json({error:'FORBIDDEN'},403,cors);await ensureLiveRoomSchema(env);const b=await body(request);
  const fs=Math.max(14,Math.min(26,Number(b.joinFontSize||18)));let color=String(b.joinTextColor||'#FFFFFF').trim().toUpperCase();if(!/^#[0-9A-F]{6}$/.test(color))color='#FFFFFF';
  await env.DB.prepare(`INSERT INTO myshop_live_ui_settings(id,join_font_size,join_text_color,updated_at) VALUES(1,?,?,CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET join_font_size=excluded.join_font_size,join_text_color=excluded.join_text_color,updated_at=CURRENT_TIMESTAMP`).bind(fs,color).run();
  return json({ok:true,joinFontSize:fs,joinTextColor:color},200,cors);
}
async function liveSummary(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const hostId=String(new URL(request.url).searchParams.get('hostId')||me.user_id).trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const r=await env.DB.prepare(`SELECT title,topic,started_at,ended_at,duration_seconds,peak_viewers,total_listeners,share_count,COALESCE(react_count,0) react_count,COALESCE(react_reward_coin,0) react_reward_coin,COALESCE(session_id,'') session_id FROM myshop_live_history WHERE host_id=? ORDER BY id DESC LIMIT 1`).bind(hostId).first();if(!r)return json({ok:true,summary:null},200,cors);const sid=String(r.session_id||'');
  const gifts=await env.DB.prepare(`SELECT COALESCE(SUM(price),0) total_gift_value,COALESCE(SUM(CASE WHEN currency='COIN' THEN price ELSE 0 END),0) total_coin_value,COALESCE(SUM(CASE WHEN currency='GOLD' THEN price ELSE 0 END),0) total_gold_value,SUM(COALESCE(quantity,1)) gift_count,COUNT(DISTINCT sender_id) supporter_count FROM myshop_live_gift_events WHERE host_id=? AND status='COMPLETED' AND ((?<>'' AND session_id=?) OR (?='' AND datetime(created_at)>=datetime(?)))`).bind(hostId,sid,sid,sid,String(r.started_at||'')).first();
  const top=(await env.DB.prepare(`SELECT e.sender_id,u.full_name,u.avatar_url,u.gender,COALESCE((SELECT badge_code FROM myshop_user_badges ub WHERE ub.user_id=e.sender_id AND ub.status='ACTIVE' AND (ub.expires_at IS NULL OR datetime(ub.expires_at)>datetime('now')) ORDER BY ub.is_displayed DESC LIMIT 1),'STANDARD') tier,COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=e.sender_id),0) level,SUM(CASE WHEN e.currency='COIN' THEN e.price ELSE 0 END) coin_value,SUM(CASE WHEN e.currency='GOLD' THEN e.price ELSE 0 END) gold_value,SUM(CASE WHEN e.currency='GOLD' THEN e.price*100 ELSE e.price END) total_value,SUM(COALESCE(e.quantity,1)) gift_count FROM myshop_live_gift_events e LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id WHERE e.host_id=? AND e.status='COMPLETED' AND ((?<>'' AND e.session_id=?) OR (?='' AND datetime(e.created_at)>=datetime(?))) GROUP BY e.sender_id ORDER BY total_value DESC,gift_count DESC LIMIT 20`).bind(hostId,sid,sid,sid,String(r.started_at||'')).all()).results||[];
  const recent=(await env.DB.prepare(`SELECT e.id,e.sender_id,e.receiver_id,e.currency,e.price,e.created_at,g.name gift_name,su.full_name sender_name,su.avatar_url sender_avatar,ru.full_name receiver_name FROM myshop_live_gift_events e JOIN myshop_live_gifts g ON g.id=e.gift_id LEFT JOIN myshop_auth_users_v108 su ON su.user_id=e.sender_id LEFT JOIN myshop_auth_users_v108 ru ON ru.user_id=e.receiver_id WHERE e.host_id=? AND e.status='COMPLETED' AND ((?<>'' AND e.session_id=?) OR (?='' AND datetime(e.created_at)>=datetime(?))) ORDER BY e.id DESC LIMIT 20`).bind(hostId,sid,sid,sid,String(r.started_at||'')).all()).results||[];
  const beforeFollowers=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_follows WHERE following_id=? AND datetime(created_at)>=datetime(?) AND datetime(created_at)<=datetime(?)`).bind(hostId,String(r.started_at||''),String(r.ended_at||'')).first();
  const hostProfile=await env.DB.prepare(`SELECT u.full_name,u.avatar_url,COALESCE(p.level,0) level FROM myshop_auth_users_v108 u LEFT JOIN myshop_user_progress p ON p.user_id=u.user_id WHERE u.user_id=? LIMIT 1`).bind(hostId).first();
  return json({ok:true,summary:{...r,hostId,hostName:String(hostProfile?.full_name||hostId),hostAvatar:String(hostProfile?.avatar_url||''),hostLevel:Number(hostProfile?.level||0),totalGiftValue:Number(gifts?.total_gift_value||0),totalCoinGift:Number(gifts?.total_coin_value||0),totalGoldGift:Number(gifts?.total_gold_value||0),giftCount:Number(gifts?.gift_count||0),supporterCount:Number(gifts?.supporter_count||0),commentCount:0,newFollowers:Number(beforeFollowers?.c||0),topSupporters:top.map((x,i)=>({...x,rank:i+1,supporterRank:i+1,role:'GIFT_SENDER'})),recentGifts:recent}},200,cors);
}

// MY SHOP V-304 premium live ecosystem endpoints. All mutations remain scoped to the authenticated user/host.
async function livePremiumConfig(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(me.user_id).first();if(!live||Number(live.active)!==1)return json({error:'HOST_NOT_LIVE'},409,cors);
  const b=await body(request);const sets=[],vals=[];
  if(Object.prototype.hasOwnProperty.call(b,'welcomeMessage')){sets.push('welcome_message=?');vals.push(String(b.welcomeMessage||'').trim().slice(0,180));}
  if(Object.prototype.hasOwnProperty.call(b,'goalType')){let gt=String(b.goalType||'NONE').trim().toUpperCase();if(!['NONE','COIN','SUPPORTERS','MINUTES','VIEWERS'].includes(gt))return json({error:'INVALID_GOAL_TYPE'},400,cors);sets.push('goal_type=?');vals.push(gt);}
  if(Object.prototype.hasOwnProperty.call(b,'goalTarget')){const n=Math.max(0,Math.min(100000000,Math.floor(Number(b.goalTarget||0))));sets.push('goal_target=?');vals.push(n);}
  if(Object.prototype.hasOwnProperty.call(b,'pinnedProductId')){const id=Math.max(0,Math.floor(Number(b.pinnedProductId||0)));if(id>0){let item=null;try{item=await env.DB.prepare(`SELECT id FROM shop_products WHERE id=? AND enabled=1 AND deleted=0`).bind(id).first();}catch(e){}if(!item)return json({error:'PRODUCT_NOT_FOUND'},404,cors);}sets.push('pinned_product_id=?');vals.push(id);}
  if(!sets.length)return json({error:'NO_CHANGES'},400,cors);sets.push('updated_at=CURRENT_TIMESTAMP');vals.push(me.user_id);
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET ${sets.join(',')} WHERE host_id=?`).bind(...vals).run();
  return json({ok:true},200,cors);
}
async function livePollStart(request,env){const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(me.user_id).first();if(Number(live?.active||0)!==1)return json({error:'HOST_NOT_LIVE'},409,cors);const b=await body(request),question=String(b.question||'').trim().slice(0,120),a=String(b.optionA||'').trim().slice(0,50),z=String(b.optionB||'').trim().slice(0,50);if(!question||!a||!z)return json({error:'POLL_FIELDS_REQUIRED'},400,cors);const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(me.user_id).first(),sid=String(meta?.session_id||'');await env.DB.prepare(`UPDATE myshop_live_polls SET status='CLOSED',closed_at=CURRENT_TIMESTAMP WHERE host_id=? AND status='ACTIVE'`).bind(me.user_id).run();const r=await env.DB.prepare(`INSERT INTO myshop_live_polls(host_id,session_id,question,option_a,option_b) VALUES(?,?,?,?,?)`).bind(me.user_id,sid,question,a,z).run();try{await liveHubPush(env,me.user_id,sid,'POLL',{id:Number(r.meta?.last_row_id||0),question,option_a:a,option_b:z});}catch(e){}return json({ok:true,id:Number(r.meta?.last_row_id||0)},201,cors);}
async function livePollVote(request,env){const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),id=Math.max(0,Math.floor(Number(b.pollId||0))),choice=String(b.choice||'').toUpperCase();if(!['A','B'].includes(choice))return json({error:'INVALID_POLL_CHOICE'},400,cors);const p=await env.DB.prepare(`SELECT host_id,session_id FROM myshop_live_polls WHERE id=? AND status='ACTIVE'`).bind(id).first();if(!p)return json({error:'POLL_CLOSED'},409,cors);await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_poll_votes(poll_id,user_id,choice) VALUES(?,?,?)`).bind(id,me.user_id,choice).run();const counts=await env.DB.prepare(`SELECT SUM(CASE WHEN choice='A' THEN 1 ELSE 0 END) a,SUM(CASE WHEN choice='B' THEN 1 ELSE 0 END) b FROM myshop_live_poll_votes WHERE poll_id=?`).bind(id).first();try{await liveHubPush(env,String(p.host_id),String(p.session_id),'POLL_VOTE',{pollId:id,votesA:Number(counts?.a||0),votesB:Number(counts?.b||0)});}catch(e){}return json({ok:true,choice,votesA:Number(counts?.a||0),votesB:Number(counts?.b||0)},200,cors);}
async function livePollClose(request,env){const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),id=Math.max(0,Math.floor(Number(b.pollId||0)));const r=await env.DB.prepare(`UPDATE myshop_live_polls SET status='CLOSED',closed_at=CURRENT_TIMESTAMP WHERE id=? AND host_id=? AND status='ACTIVE'`).bind(id,me.user_id).run();if(Number(r?.meta?.changes||0)<1)return json({error:'POLL_NOT_FOUND'},404,cors);return json({ok:true},200,cors);}
async function liveFanClub(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const hostId=String(new URL(request.url).searchParams.get('hostId')||me.user_id).trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const mine=await env.DB.prepare(`SELECT active,points,joined_at FROM myshop_live_fan_club WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).first();const count=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_fan_club WHERE host_id=? AND active=1`).bind(hostId).first();
  const top=(await env.DB.prepare(`SELECT f.user_id,f.points,f.joined_at,u.full_name,u.avatar_url FROM myshop_live_fan_club f LEFT JOIN myshop_auth_users_v108 u ON u.user_id=f.user_id WHERE f.host_id=? AND f.active=1 ORDER BY f.points DESC,datetime(f.joined_at) ASC LIMIT 50`).bind(hostId).all()).results||[];
  return json({ok:true,hostId,joined:Number(mine?.active||0)===1,points:Number(mine?.points||0),memberCount:Number(count?.c||0),members:top.map((x,i)=>({...x,rank:i+1}))},200,cors);
}
async function liveFanClubToggle(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||'').trim();if(!isFourDigit(hostId)||hostId===me.user_id)return json({error:'INVALID_HOST_ID'},400,cors);
  const host=await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1`).bind(hostId).first();if(!host)return json({error:'HOST_NOT_FOUND'},404,cors);const old=await env.DB.prepare(`SELECT active FROM myshop_live_fan_club WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).first();const active=old&&Number(old.active)===1?0:1;
  await env.DB.prepare(`INSERT INTO myshop_live_fan_club(host_id,user_id,active,points,joined_at,updated_at) VALUES(?,?,?,0,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id) DO UPDATE SET active=excluded.active,updated_at=CURRENT_TIMESTAMP`).bind(hostId,me.user_id,active).run();
  if(active){try{await createUserNotification(env,hostId,'New Fan Club Member',(me.full_name||'A user')+' joined your Fan Club.','LIVE_FAN_JOIN',me.user_id,hostId);}catch(e){}}
  return json({ok:true,joined:active===1},200,cors);
}
async function liveCreatorCenter(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const hostId=String(new URL(request.url).searchParams.get('hostId')||me.user_id).trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const profile=await env.DB.prepare(`SELECT user_id,full_name,avatar_url FROM myshop_auth_users_v108 WHERE user_id=? AND active=1`).bind(hostId).first();if(!profile)return json({error:'USER_NOT_FOUND'},404,cors);
  const agg=await env.DB.prepare(`SELECT COUNT(*) live_count,COALESCE(SUM(duration_seconds),0) total_seconds,COALESCE(MAX(peak_viewers),0) best_peak,COALESCE(SUM(total_listeners),0) total_listeners,COALESCE(SUM(share_count),0) shares,COALESCE(SUM(react_count),0) reacts FROM myshop_live_history WHERE host_id=?`).bind(hostId).first();
  const gifts=await env.DB.prepare(`SELECT COALESCE(SUM(price),0) gift_value,COUNT(*) gift_count,COUNT(DISTINCT sender_id) supporters FROM myshop_live_gift_events WHERE host_id=? AND status='COMPLETED'`).bind(hostId).first();
  const fans=await env.DB.prepare(`SELECT COUNT(*) c,COALESCE(SUM(points),0) points FROM myshop_live_fan_club WHERE host_id=? AND active=1`).bind(hostId).first();const social=await socialStatsFor(env,hostId);
  const history=(await env.DB.prepare(`SELECT id,title,topic,started_at,ended_at,duration_seconds,peak_viewers,total_listeners,share_count,react_count,session_id FROM myshop_live_history WHERE host_id=? ORDER BY id DESC LIMIT 30`).bind(hostId).all()).results||[];
  const top=(await env.DB.prepare(`SELECT e.sender_id,u.full_name,u.avatar_url,SUM(CASE WHEN e.currency='GOLD' THEN e.price*100 ELSE e.price END) total_value,SUM(CASE WHEN e.currency='COIN' THEN e.price ELSE 0 END) coin_value,SUM(CASE WHEN e.currency='GOLD' THEN e.price ELSE 0 END) gold_value,SUM(COALESCE(e.quantity,1)) gift_count FROM myshop_live_gift_events e LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id WHERE e.host_id=? AND e.sender_id<>e.host_id AND e.status='COMPLETED' GROUP BY e.sender_id ORDER BY total_value DESC,MAX(CASE WHEN e.price>0 THEN e.id ELSE 0 END) ASC,e.sender_id ASC LIMIT 20`).bind(hostId).all()).results||[];
  const liveLevel=Math.min(99,Math.max(1,1+Math.floor((Number(agg?.live_count||0)*2+Number(agg?.total_seconds||0)/1800+Number(gifts?.gift_value||0)/5000)/5)));
  const achievements=[];if(Number(agg?.live_count||0)>=1)achievements.push('FIRST_LIVE');if(Number(agg?.live_count||0)>=10)achievements.push('10_LIVES');if(Number(agg?.best_peak||0)>=100)achievements.push('100_PEAK');if(Number(gifts?.supporters||0)>=10)achievements.push('10_SUPPORTERS');if(Number(fans?.c||0)>=50)achievements.push('50_FANS');
  return json({ok:true,creator:{...profile,liveLevel,liveCount:Number(agg?.live_count||0),totalLiveSeconds:Number(agg?.total_seconds||0),bestPeak:Number(agg?.best_peak||0),totalListeners:Number(agg?.total_listeners||0),shares:Number(agg?.shares||0),reacts:Number(agg?.reacts||0),giftValue:Number(gifts?.gift_value||0),giftCount:Number(gifts?.gift_count||0),supporterCount:Number(gifts?.supporters||0),fanCount:Number(fans?.c||0),fanPoints:Number(fans?.points||0),social,achievements,history,topSupporters:top.map((x,i)=>({...x,rank:i+1}))}},200,cors);
}
async function liveDiscover(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureFriendSchema(env);await ensureLiveRoomSchema(env);const url=new URL(request.url),category=String(url.searchParams.get('category')||'LIVE_NOW').toUpperCase(),limit=Math.max(1,Math.min(100,Number(url.searchParams.get('limit')||50)));
  await env.DB.prepare(`UPDATE myshop_live_presence SET active=0 WHERE active=1 AND datetime(last_seen)<datetime('now','-2 minutes')`).run();
  let extra='',order=`l.viewer_count DESC,datetime(l.last_seen) DESC`;const binds=[];
  if(category==='FRIENDS')extra=` AND EXISTS(SELECT 1 FROM myshop_friend_requests f WHERE f.status='ACCEPTED' AND ((f.sender_id=? AND f.receiver_id=l.user_id) OR (f.receiver_id=? AND f.sender_id=l.user_id)))`,binds.push(me.user_id,me.user_id);
  else if(category==='FOLLOWING')extra=` AND EXISTS(SELECT 1 FROM myshop_follows f WHERE f.follower_id=? AND f.following_id=l.user_id)`,binds.push(me.user_id);
  else if(category==='NEW_HOST')order=`COALESCE((SELECT COUNT(*) FROM myshop_live_history h WHERE h.host_id=l.user_id),0) ASC,datetime(l.last_seen) DESC`;
  else if(category==='TRENDING')order=`(l.viewer_count*10+COALESCE(m.react_count,0)/50+COALESCE((SELECT SUM(g.price) FROM myshop_live_gift_events g WHERE g.host_id=l.user_id AND g.status='COMPLETED' AND g.session_id=m.session_id),0)/20) DESC`;
  else if(category==='SHOP_LIVE')extra=` AND COALESCE(m.pinned_product_id,0)>0`;
  else if(category==='TALK_ROOM')extra=` AND COALESCE(m.pinned_product_id,0)=0`;
  const rows=(await env.DB.prepare(`SELECT l.user_id,l.viewer_count,l.last_seen,u.full_name,u.avatar_url,COALESCE(m.title,'Live') title,COALESCE(m.topic,'Audio Live') topic,COALESCE(m.pinned_product_id,0) pinned_product_id,COALESCE(m.react_count,0) react_count,(CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=l.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=l.user_id),0)) level,COALESCE((SELECT b.badge_code FROM myshop_user_badges b WHERE b.user_id=l.user_id AND b.status='ACTIVE' AND (b.expires_at IS NULL OR datetime(b.expires_at)>datetime('now')) ORDER BY b.is_displayed DESC,b.id DESC LIMIT 1),'') membership_tier,COALESCE((SELECT COUNT(*) FROM myshop_live_votes v WHERE v.host_id=l.user_id),0) vote_count FROM myshop_live_presence l JOIN myshop_auth_users_v108 u ON u.user_id=l.user_id LEFT JOIN myshop_live_room_meta m ON m.host_id=l.user_id WHERE l.active=1 AND u.active=1 ${extra} ORDER BY ${order} LIMIT ?`).bind(...binds,limit).all()).results||[];
  let topSupporters=[];if(category==='TOP_SUPPORTERS')topSupporters=(await env.DB.prepare(`SELECT e.sender_id user_id,u.full_name,u.avatar_url,SUM(e.price) total_value,SUM(COALESCE(e.quantity,1)) gift_count FROM myshop_live_gift_events e LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id WHERE e.status='COMPLETED' GROUP BY e.sender_id ORDER BY total_value DESC LIMIT ?`).bind(limit).all()).results||[];
  return json({ok:true,category,rooms:rows.map(x=>({userId:x.user_id,name:x.title||x.full_name||'MY SHOP User',profileName:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',viewerCount:Number(x.viewer_count||0),level:Number(x.level||0),title:x.title||'Live',topic:x.topic||'',shopLive:Number(x.pinned_product_id||0)>0,reactCount:Number(x.react_count||0),membershipTier:String(x.membership_tier||'').toUpperCase(),voteCount:Number(x.vote_count||0)})),topSupporters:topSupporters.map((x,i)=>({...x,rank:i+1}))},200,cors);
}
async function liveScheduleList(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const hostId=String(new URL(request.url).searchParams.get('hostId')||me.user_id).trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const rows=(await env.DB.prepare(`SELECT s.id,s.host_id,s.title,s.topic,s.scheduled_at,s.status,s.created_at,CASE WHEN EXISTS(SELECT 1 FROM myshop_live_reminders r WHERE r.schedule_id=s.id AND r.user_id=?) THEN 1 ELSE 0 END reminded,(SELECT COUNT(*) FROM myshop_live_reminders r WHERE r.schedule_id=s.id) reminder_count FROM myshop_live_schedules s WHERE s.host_id=? AND s.status IN ('SCHEDULED','LIVE') ORDER BY datetime(s.scheduled_at) ASC LIMIT 50`).bind(me.user_id,hostId).all()).results||[];return json({ok:true,schedules:rows},200,cors);
}
async function liveScheduleSave(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),title=String(b.title||'Scheduled Live').trim().slice(0,80),topic=String(b.topic||'').trim().slice(0,120),at=String(b.scheduledAt||'').trim();if(!at||!Number.isFinite(Date.parse(at.replace(' ','T'))))return json({error:'INVALID_SCHEDULE_TIME'},400,cors);if(Date.parse(at.replace(' ','T'))<Date.now()-60000)return json({error:'SCHEDULE_IN_PAST'},400,cors);const id=Math.max(0,Math.floor(Number(b.id||0)));
  if(id){const own=await env.DB.prepare(`SELECT id FROM myshop_live_schedules WHERE id=? AND host_id=? AND status='SCHEDULED'`).bind(id,me.user_id).first();if(!own)return json({error:'SCHEDULE_NOT_EDITABLE'},404,cors);await env.DB.prepare(`UPDATE myshop_live_schedules SET title=?,topic=?,scheduled_at=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(title,topic,at,id).run();return json({ok:true,id},200,cors);}
  const r=await env.DB.prepare(`INSERT INTO myshop_live_schedules(host_id,title,topic,scheduled_at,status) VALUES(?,?,?,?,'SCHEDULED')`).bind(me.user_id,title,topic,at).run();return json({ok:true,id:r.meta?.last_row_id||0},201,cors);
}
async function liveScheduleCancel(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),id=Math.max(0,Math.floor(Number(b.id||0)));const r=await env.DB.prepare(`UPDATE myshop_live_schedules SET status='CANCELLED',updated_at=CURRENT_TIMESTAMP WHERE id=? AND host_id=? AND status='SCHEDULED'`).bind(id,me.user_id).run();if(Number(r?.meta?.changes||0)<1)return json({error:'SCHEDULE_NOT_FOUND'},404,cors);return json({ok:true},200,cors);
}
async function liveScheduleReminder(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),id=Math.max(0,Math.floor(Number(b.scheduleId||0)));const s=await env.DB.prepare(`SELECT host_id,status FROM myshop_live_schedules WHERE id=?`).bind(id).first();if(!s||String(s.status)!=='SCHEDULED')return json({error:'SCHEDULE_NOT_FOUND'},404,cors);const old=await env.DB.prepare(`SELECT 1 x FROM myshop_live_reminders WHERE schedule_id=? AND user_id=?`).bind(id,me.user_id).first();if(old){await env.DB.prepare(`DELETE FROM myshop_live_reminders WHERE schedule_id=? AND user_id=?`).bind(id,me.user_id).run();return json({ok:true,reminded:false},200,cors);}await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_reminders(schedule_id,user_id) VALUES(?,?)`).bind(id,me.user_id).run();return json({ok:true,reminded:true},200,cors);
}
async function livePkStart(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),peer=String(b.hostId||'').trim();if(!isFourDigit(peer)||peer===me.user_id)return json({error:'INVALID_PK_HOST'},400,cors);const a=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(me.user_id).first(),z=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(peer).first();if(Number(a?.active||0)!==1||Number(z?.active||0)!==1)return json({error:'BOTH_HOSTS_MUST_BE_LIVE'},409,cors);const ma=await env.DB.prepare(`SELECT session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(me.user_id).first(),mb=await env.DB.prepare(`SELECT session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(peer).first();const open=await env.DB.prepare(`SELECT id FROM myshop_live_pk_rounds WHERE status IN ('PENDING','ACTIVE') AND (host_a=? OR host_b=?) LIMIT 1`).bind(me.user_id,me.user_id).first();if(open)return json({error:'PK_ALREADY_OPEN'},409,cors);const r=await env.DB.prepare(`INSERT INTO myshop_live_pk_rounds(host_a,host_b,session_a,session_b,status) VALUES(?,?,?,?,'PENDING')`).bind(me.user_id,peer,String(ma?.session_id||''),String(mb?.session_id||'')).run();try{await createUserNotification(env,peer,'Live PK Invitation',(me.full_name||'Host')+' invited you to a friendly Live PK.','LIVE_PK_INVITE',me.user_id,me.user_id);}catch(e){}return json({ok:true,id:r.meta?.last_row_id||0,status:'PENDING'},201,cors);
}
async function livePkAction(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),id=Math.max(0,Math.floor(Number(b.id||0))),action=String(b.action||'').toUpperCase();const r=await env.DB.prepare(`SELECT * FROM myshop_live_pk_rounds WHERE id=?`).bind(id).first();if(!r)return json({error:'PK_NOT_FOUND'},404,cors);
  if(action==='ACCEPT'&&String(r.host_b)===me.user_id&&String(r.status)==='PENDING'){await env.DB.prepare(`UPDATE myshop_live_pk_rounds SET status='ACTIVE',started_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(id).run();return json({ok:true,status:'ACTIVE'},200,cors);}if(action==='DECLINE'&&String(r.host_b)===me.user_id&&String(r.status)==='PENDING'){await env.DB.prepare(`UPDATE myshop_live_pk_rounds SET status='DECLINED',ended_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(id).run();return json({ok:true,status:'DECLINED'},200,cors);}if(action==='END'&&(String(r.host_a)===me.user_id||String(r.host_b)===me.user_id)&&String(r.status)==='ACTIVE'){await env.DB.prepare(`UPDATE myshop_live_pk_rounds SET status='ENDED',ended_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(id).run();return json({ok:true,status:'ENDED'},200,cors);}return json({error:'PK_ACTION_NOT_ALLOWED'},403,cors);
}

async function liveProfiles(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,viewer_count INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_app_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  try{await env.DB.prepare(`ALTER TABLE myshop_app_presence ADD COLUMN visible INTEGER NOT NULL DEFAULT 1`).run();}catch(e){}
  await env.DB.prepare(`UPDATE myshop_app_presence SET active=0 WHERE active=1 AND datetime(last_seen)<datetime('now','-30 seconds')`).run();
  const limit=Math.max(1,Math.min(100,Number(new URL(request.url).searchParams.get('limit')||4)));
  await env.DB.prepare(`UPDATE myshop_live_presence SET active=0 WHERE active=1 AND datetime(last_seen)<datetime('now','-2 minutes')`).run();
  const liveRows=(await env.DB.prepare(`SELECT l.user_id,l.viewer_count,l.last_seen,u.full_name,u.avatar_url,COALESCE(NULLIF(m.title,''),u.full_name) live_name,(CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=l.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=l.user_id),0)) AS level,CASE WHEN EXISTS(SELECT 1 FROM myshop_app_presence ap WHERE ap.user_id=l.user_id AND COALESCE(ap.visible,1)=1 AND ap.active=1 AND datetime(ap.last_seen)>=datetime('now','-30 seconds')) THEN 1 ELSE 0 END AS online,CASE WHEN EXISTS(SELECT 1 FROM myshop_follows f WHERE f.follower_id=? AND f.following_id=l.user_id) THEN 1 ELSE 0 END AS followed FROM myshop_live_presence l JOIN myshop_auth_users_v108 u ON u.user_id=l.user_id LEFT JOIN myshop_live_room_meta m ON m.host_id=l.user_id WHERE l.active=1 AND u.active=1 ORDER BY followed DESC,datetime(l.last_seen) DESC LIMIT ?`).bind(user.user_id,limit).all()).results||[];
  const profiles=liveRows.map(x=>({userId:x.user_id,name:x.live_name||x.full_name||'MY SHOP User',profileName:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',viewerCount:Number(x.viewer_count||0),lastSeen:x.last_seen,live:true,level:Math.max(0,Number(x.level||0)),online:Number(x.online||0)===1,followed:Number(x.followed||0)===1}));
  if(profiles.length<limit){
    const need=limit-profiles.length;
    const recent=(await env.DB.prepare(`SELECT a.user_id,a.full_name,a.avatar_url,a.created_at,
      (CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=a.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=a.user_id),0)) AS level,
    COALESCE((SELECT COUNT(*) FROM myshop_live_votes v WHERE v.host_id=a.user_id),0) AS vote_count,
      CASE WHEN EXISTS(SELECT 1 FROM myshop_app_presence ap WHERE ap.user_id=a.user_id AND COALESCE(ap.visible,1)=1 AND ap.active=1 AND datetime(ap.last_seen)>=datetime('now','-30 seconds')) THEN 1 ELSE 0 END AS online,
      CASE WHEN EXISTS(SELECT 1 FROM myshop_friend_requests f WHERE f.sender_id=? AND f.receiver_id=a.user_id AND f.status='PENDING') THEN 'REQUESTED'
           WHEN EXISTS(SELECT 1 FROM myshop_friend_requests f WHERE f.sender_id=a.user_id AND f.receiver_id=? AND f.status='PENDING') THEN 'INCOMING'
           WHEN EXISTS(SELECT 1 FROM myshop_friend_requests f WHERE f.status='ACCEPTED' AND ((f.sender_id=? AND f.receiver_id=a.user_id) OR (f.sender_id=a.user_id AND f.receiver_id=?))) THEN 'FRIEND'
           ELSE 'NONE' END AS relation_state
      FROM myshop_auth_users_v108 a WHERE a.active=1 AND a.user_id<>? AND NOT EXISTS(SELECT 1 FROM myshop_live_presence l WHERE l.user_id=a.user_id AND l.active=1) ORDER BY datetime(a.created_at) DESC,a.user_id DESC LIMIT ?`).bind(user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,need).all()).results||[];
    for(const x of recent)profiles.push({userId:x.user_id,name:x.full_name||'New Member',avatarUrl:x.avatar_url||'',viewerCount:0,lastSeen:'',joinedAt:x.created_at||'',live:false,state:x.relation_state||'NONE',level:Math.max(0,Number(x.level||0)),online:Number(x.online||0)===1});
  }
  let pendingPremium=0,newPremium=0,upcoming=null;try{const p=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_store_purchase_requests WHERE user_id=? AND status='PENDING'`).bind(user.user_id).first();pendingPremium=Number(p?.c||0);const n=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_store_catalog WHERE enabled=1 AND COALESCE(deleted,0)=0 AND datetime(updated_at)>=datetime('now','-7 days')`).first();newPremium=Number(n?.c||0);upcoming=await env.DB.prepare(`SELECT s.id,s.host_id,s.title,s.scheduled_at,u.full_name host_name,u.avatar_url host_avatar FROM myshop_live_schedules s JOIN myshop_auth_users_v108 u ON u.user_id=s.host_id WHERE s.status='SCHEDULED' AND datetime(s.scheduled_at)>datetime('now') AND (s.host_id=? OR EXISTS(SELECT 1 FROM myshop_follows f WHERE f.follower_id=? AND f.following_id=s.host_id)) ORDER BY datetime(s.scheduled_at) ASC LIMIT 1`).bind(user.user_id,user.user_id).first();}catch(e){}
  return json({ok:true,profiles,liveCount:liveRows.length,pendingPremium,newPremium,upcomingLive:upcoming||null,fillMode:liveRows.length>=limit?'LIVE_ONLY':(liveRows.length>0?'LIVE_THEN_NEW':'NEWEST_USERS')},200,cors);
}
async function getProfilePrivacy(env,userId){
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_profile_privacy (user_id TEXT PRIMARY KEY,posts_visibility TEXT NOT NULL DEFAULT 'PUBLIC',media_visibility TEXT NOT NULL DEFAULT 'PUBLIC',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_profile_privacy(user_id) VALUES(?)`).bind(userId).run();
  return await env.DB.prepare(`SELECT posts_visibility,media_visibility FROM myshop_profile_privacy WHERE user_id=?`).bind(userId).first();
}
async function myPrivacy(request,env){const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);return json({ok:true,privacy:await getProfilePrivacy(env,user.user_id)},200,cors);}
async function updateMyPrivacy(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);const b=await body(request);const allowed=['PUBLIC','FRIENDS','PRIVATE'];const posts=String(b.postsVisibility||'PUBLIC').toUpperCase(),media=String(b.mediaVisibility||'PUBLIC').toUpperCase();if(!allowed.includes(posts)||!allowed.includes(media))return json({error:'INVALID_VISIBILITY'},400,cors);
  await getProfilePrivacy(env,user.user_id);await env.DB.prepare(`UPDATE myshop_profile_privacy SET posts_visibility=?,media_visibility=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(posts,media,user.user_id).run();return json({ok:true,privacy:{posts_visibility:posts,media_visibility:media}},200,cors);
}
async function canViewProfileContent(env,viewer,target,kind){if(viewer===target)return true;const p=await getProfilePrivacy(env,target),v=String(kind==='media'?p?.media_visibility:p?.posts_visibility||'PUBLIC').toUpperCase();if(v==='PUBLIC')return true;if(v==='PRIVATE')return false;const f=await env.DB.prepare(`SELECT 1 ok FROM myshop_friend_requests WHERE status='ACCEPTED' AND ((sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)) LIMIT 1`).bind(viewer,target,target,viewer).first();return !!f;}
async function userPosts(request,env){
  await ensureSchemasOnce(env);
  await ensureFriendSchema(env);const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);const u=new URL(request.url),target=String(u.searchParams.get('userId')||'').trim(),media=String(u.searchParams.get('media')||'all').toLowerCase();if(!isFourDigit(target))return json({error:'INVALID_USER_ID'},400,cors);const publicPreview=target===user.user_id&&u.searchParams.get('viewAs')==='public';const kind=media==='all'?'posts':'media';if(await safetyIsBlocked(env,user.user_id,target))return json({ok:true,visible:false,posts:[]},200,cors);if(!(await canViewProfileContent(env,publicPreview?'':user.user_id,target,kind)))return json({ok:true,visible:false,posts:[]},200,cors);
  let where=`p.user_id=? AND p.status='ACTIVE'`,binds=[target];if(media==='media')where+=` AND p.media_type IN ('image','video')`;else if(media==='photo')where+=` AND p.media_type='image'`;else if(media==='video')where+=` AND p.media_type='video'`;else if(media==='reels')where+=` AND p.media_type IN ('reel','short','video')`;
  const rows=(await env.DB.prepare(`SELECT p.id,p.caption,p.media_url,p.media_type,p.created_at,(SELECT COUNT(*) FROM myshop_post_likes l WHERE l.post_id=p.id AND datetime(l.created_at)>=datetime('now','-24 hours')) like_count,(SELECT COUNT(*) FROM myshop_post_comments c WHERE c.post_id=p.id) comment_count,(SELECT COUNT(*) FROM myshop_post_shares sh WHERE sh.post_id=p.id) share_count FROM myshop_posts p WHERE ${where} ORDER BY p.id DESC LIMIT 100`).bind(...binds).all()).results||[];return json({ok:true,visible:true,posts:rows.map(x=>({id:x.id,caption:x.caption||'',mediaUrl:x.media_url||'',mediaType:x.media_type||'text',createdAt:x.created_at,likeCount:Number(x.like_count||0),commentCount:Number(x.comment_count||0),shareCount:Number(x.share_count||0)}))},200,cors);
}


async function safetyIsBlocked(env,a,b){
  if(!isFourDigit(a)||!isFourDigit(b))return false;
  try{await ensureFriendSchema(env);const row=await env.DB.prepare(`SELECT 1 ok FROM myshop_user_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1`).bind(a,b,b,a).first();return !!row;}catch(_){return false;}
}

async function safetyBlock(request,env){
  await ensureFriendSchema(env);const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);const b=await body(request),target=String(b.userId||'').trim(),blocked=b.blocked!==false;
  if(!isFourDigit(target)||target===me.user_id)return json({error:'INVALID_USER_ID'},400,cors);const u=await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1`).bind(target).first();if(!u)return json({error:'USER_NOT_FOUND'},404,cors);
  if(blocked){
    await env.DB.prepare(`INSERT OR IGNORE INTO myshop_user_blocks(blocker_id,blocked_id) VALUES(?,?)`).bind(me.user_id,target).run();
    await env.DB.prepare(`DELETE FROM myshop_friend_requests WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)`).bind(me.user_id,target,target,me.user_id).run();
    await env.DB.prepare(`DELETE FROM myshop_follows WHERE (follower_id=? AND following_id=?) OR (follower_id=? AND following_id=?)`).bind(me.user_id,target,target,me.user_id).run();
  }else {await env.DB.prepare(`DELETE FROM myshop_user_blocks WHERE blocker_id=? AND blocked_id=?`).bind(me.user_id,target).run();try{await ensureLiveRoomSchema(env);await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state='BLOCKED'`).bind(me.user_id,target).run();}catch(_){}}
  return json({ok:true,userId:target,blocked},200,cors);
}

async function safetyBlocks(request,env){
  await ensureFriendSchema(env);const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);
  const rows=(await env.DB.prepare(`SELECT b.blocked_id user_id,u.full_name,u.avatar_url,b.created_at FROM myshop_user_blocks b LEFT JOIN myshop_auth_users_v108 u ON u.user_id=b.blocked_id WHERE b.blocker_id=? ORDER BY datetime(b.created_at) DESC`).bind(me.user_id).all()).results||[];
  return json({ok:true,blocks:rows.map(x=>({userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',createdAt:x.created_at||''}))},200,cors);
}

async function safetyReport(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);const b=await body(request);
  const target=String(b.targetUserId||'').trim(),type=String(b.contentType||'USER').trim().toUpperCase().replace(/[^A-Z0-9_]/g,'').slice(0,40),contentId=String(b.contentId||'').trim().slice(0,80),reason=String(b.reason||'OTHER').trim().toUpperCase().replace(/[^A-Z0-9_]/g,'').slice(0,40),details=String(b.details||'').trim().slice(0,800);
  if(target&&(!isFourDigit(target)||target===me.user_id))return json({error:'INVALID_REPORT_TARGET'},400,cors);if(!type||!reason)return json({error:'INVALID_REPORT'},400,cors);
  const r=await env.DB.prepare(`INSERT INTO myshop_safety_reports(reporter_id,target_user_id,content_type,content_id,reason,details) VALUES(?,?,?,?,?,?)`).bind(me.user_id,target,type,contentId,reason,details).run();
  return json({ok:true,reportId:r.meta?.last_row_id||0,status:'OPEN'},201,cors);
}

async function liveMutedUsers(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
  const rows=(await env.DB.prepare(`SELECT m.user_id,u.full_name,u.avatar_url,m.updated_at FROM myshop_live_mute_records m LEFT JOIN myshop_auth_users_v108 u ON u.user_id=m.user_id WHERE m.host_id=? ORDER BY datetime(m.updated_at) DESC`).bind(me.user_id).all()).results||[];
  return json({ok:true,muted:rows.map(x=>({userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',updatedAt:x.updated_at||''}))},200,cors);
}
async function liveUnmuteSavedUser(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),uid=String(b.userId||'').trim();
  if(!isFourDigit(uid)||uid===me.user_id)return json({error:'INVALID_TARGET'},400,cors);
  await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state='MUTED'`).bind(me.user_id,uid).run();
  await env.DB.prepare(`UPDATE myshop_live_seats_dynamic SET muted=0,mic_on=1,speaking=0,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND seat_no>1`).bind(me.user_id,uid).run();
  await env.DB.prepare(`DELETE FROM myshop_live_mute_records WHERE host_id=? AND user_id=?`).bind(me.user_id,uid).run();
  await recordModerationAudit(env,me.user_id,me.user_id,uid,'UNMUTE_SAVED');await liveHubDirtyForHost(env,me.user_id,'MODERATION_UNMUTE');
  return json({ok:true,userId:uid,muted:false},200,cors);
}
function legalShell(title,bodyHtml){return new Response(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title} • MY SHOP</title><style>body{font-family:system-ui,-apple-system,sans-serif;background:#f7f8fc;color:#18213c;margin:0}.wrap{max-width:760px;margin:auto;padding:28px 18px 60px}.card{background:white;border:1px solid #e3e6f0;border-radius:18px;padding:22px;box-shadow:0 8px 24px #1d2b5012}h1{color:#293fba}a{color:#4939d7}input,textarea{width:100%;box-sizing:border-box;padding:12px;margin:7px 0;border:1px solid #cfd4e5;border-radius:10px}button{background:#4939d7;color:white;border:0;border-radius:10px;padding:12px 18px;font-weight:700}.muted{color:#66708d;font-size:.92rem}</style></head><body><div class="wrap"><div class="card">${bodyHtml}</div></div></body></html>`,{status:200,headers:{...cors,'content-type':'text/html; charset=utf-8','cache-control':'public, max-age=300'}});}

function privacyPage(){return legalShell('Privacy Policy',`<h1>MY SHOP Privacy Policy</h1><p>MY SHOP may process account details, profile information, posts and media, private messages, Live-room participation, purchase and entitlement records, and limited technical data needed to operate and secure the service.</p><p>Microphone access is requested only for Audio Live features that need it. MY SHOP does not require location access for its core service.</p><p>Users can report or block other users. Reports may be retained for safety and moderation.</p><h2>Profile visibility and security</h2><p>Supported personal Profile-page fields can be set to Public, Friends, Only Me or Custom (selected user IDs). Friends means accepted friends. Profile-page visibility does not remove names or photos already shared in other public content. Private account email, mobile, recovery information and wallet details are not automatically displayed on the public Profile. Active Status can be hidden.</p><p>Raw passwords are not stored or shown to administrators. Password authentication uses a salted, one-way hash. Never share your password, OTP or verification code.</p><h2>Service providers</h2><p>MY SHOP uses Cloudflare for backend, database and media processing; Firebase for supported device notifications; Agora for supported Live audio; and Google services for supported sign-in or Play purchases. These providers process the information needed for those features under their applicable terms. This is not a promise that no third-party processing occurs.</p><h2>Account deletion</h2><p>Users can delete their account from <b>Profile Menu → Settings &amp; Privacy → Account &amp; Data → Delete Account</b>, or use the web deletion request page. Personal profile data, sessions, private messages and user-created content are deleted or anonymized as part of the deletion process. A non-public immutable MY SHOP ID and minimal security, fraud-prevention, transaction, payout or legally required records may be retained where necessary and are not reassigned to another person.</p><h2>Privacy contact</h2><p>For privacy or account-data requests, use the in-app <b>Settings &amp; Privacy</b> support/deletion controls or the account-deletion request page linked by MY SHOP. The verified account owner contact used for Google Play publication must also be maintained in the Play Console and public app listing.</p>`);}
function termsPage(){return legalShell('Terms & Conditions',`<h1>MY SHOP Terms &amp; Conditions</h1><p>Use MY SHOP respectfully and lawfully. Do not impersonate others, abuse Live or messaging features, post prohibited content, harass users, manipulate payments, or interfere with the service.</p><p>Digital products sold in the Google Play build use Google Play Billing. Admin grants are owner-controlled entitlements and do not replace Play checkout for user-paid digital purchases.</p><p>MY SHOP may moderate reported content or accounts when needed for safety, integrity or legal compliance.</p>`);}
function communityGuidelinesPage(){return legalShell('Community Guidelines',`<h1>MY SHOP Community Guidelines</h1><p>Use Profiles, Posts, Messages and Live rooms respectfully. Harassment, hate, fraud, impersonation, illegal content and sexual abuse or exploitation of children are prohibited. Do not upload or stream copyrighted material without appropriate rights.</p><h2>Report and block</h2><p>Report harmful content or accounts using the app's Report / Block controls. Moderation actions follow granted permissions and may include content removal or account restrictions. Blocking and account deletion are separate controls.</p><p>For safety concerns, use the in-app support/report system. Published safety contact details and applicable reporting procedures must be maintained by MY SHOP.</p>`);}
function accountDeletionPage(){return legalShell('Delete Account',`<h1>Delete your MY SHOP account</h1><p>The fastest verified method is inside the app: <b>Profile Menu → Settings &amp; Privacy → Account &amp; Data → Delete Account</b>. You will verify account ownership with your current password or your associated Google account before confirming deletion.</p><p>App identification: <b>MY SHOP</b> (Android package <b>com.myshop.app</b>).</p><h2>Data removed and retained</h2><p>Verified deletion removes or anonymizes your public profile, personal details, sessions, private messages, user posts/media and applicable Store personal information. Media cleanup can continue through a secure retry process. Financial transactions, payouts, orders and necessary security/audit records may be retained for accounting, fraud prevention, disputes or applicable requirements; retained data does not remain a public Profile. Deletion does not cancel an existing order.</p><p>For account-deletion contact, provide a reachable email or mobile in the form below so the support team can verify ownership. Do not submit passwords, OTPs or access tokens.</p><p>If you cannot sign in, submit a deletion request below. The request does not bypass identity verification; support must verify ownership before deleting the account.</p><form id="f"><input id="identifier" placeholder="MY SHOP ID / registered email or mobile" required><input id="contact" placeholder="Contact email or mobile for verification" required><textarea id="reason" placeholder="Optional reason"></textarea><button>Submit deletion request</button></form><p id="out" class="muted"></p><script>document.getElementById('f').onsubmit=async(e)=>{e.preventDefault();const out=document.getElementById('out');out.textContent='Submitting…';try{const r=await fetch('/v1/account/deletion-request',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({identifier:identifier.value,contact:contact.value,reason:reason.value})});const j=await r.json();out.textContent=r.ok?'Request received. Keep the request number: '+j.requestId:'Could not submit: '+(j.error||r.status);}catch(x){out.textContent='Network error. Please try again.';}};</script>`);}

async function accountDeletionRequest(request,env){
  const b=await body(request),identifier=String(b.identifier||'').trim().slice(0,160),contact=String(b.contact||'').trim().slice(0,160),reason=String(b.reason||'').trim().slice(0,600);if(identifier.length<2||contact.length<3)return json({error:'INVALID_DELETE_REQUEST'},400,cors);
  let uid='';try{const u=await findAuthUser(env,identifier);uid=u?.user_id||'';}catch(_){}
  const r=await env.DB.prepare(`INSERT INTO myshop_account_deletion_requests(user_id,identifier,contact,reason) VALUES(?,?,?,?)`).bind(uid,identifier,contact,reason).run();return json({ok:true,requestId:r.meta?.last_row_id||0,status:'OPEN'},201,cors);
}

async function accountDelete(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request),password=String(b.password||'');
  if(b.googleIdToken){const verification=await verifyDeletionGoogleToken(b.googleIdToken,me,env);if(!verification.ok)return json({error:verification.error},verification.statusCode,cors);}
  else if(!password||!(await verifyPassword(password,me.password_hash)))return json({error:'INVALID_DELETE_PASSWORD'},403,cors);
  const uid=me.user_id,tomb='deleted$'+randomHex(24);
  await env.DB.prepare(deletionMediaSchema).run();
  const tables=new Set(((await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table'").all()).results||[]).map(x=>x.name));
  const keys=new Set([me.avatar_object_key,me.cover_object_key].filter(Boolean));
  for(const [table,owner] of [['myshop_posts','user_id'],['gallery_media','owner_user_id']])if(tables.has(table)){
    const rows=(await env.DB.prepare(`SELECT object_key FROM ${table} WHERE ${owner}=? AND object_key<>''`).bind(uid).all()).results||[];
    for(const row of rows)keys.add(row.object_key);
  }
  if(tables.has('myshop_messages')){
    const rows=(await env.DB.prepare(`SELECT media_url FROM myshop_messages WHERE sender_id=? AND media_url<>''`).bind(uid).all()).results||[];
    for(const row of rows){try{const url=new URL(row.media_url,request.url);if(url.origin===new URL(request.url).origin&&url.pathname.startsWith('/v1/media/'))keys.add(decodeURIComponent(url.pathname.slice('/v1/media/'.length)));}catch(_){}}
  }
  const cleanup=[...keys].map(key=>env.DB.prepare(`INSERT OR IGNORE INTO myshop_deleted_media(object_key,user_id) VALUES(?,?)`).bind(key,uid));
  for(const table of ['shop_cart','shop_saved','shop_price_alerts','shop_reviews','shop_notices','shop_clicks'])if(tables.has(table))cleanup.push(env.DB.prepare(`DELETE FROM ${table} WHERE user_id=?`).bind(uid));
  if(tables.has('shop_orders'))cleanup.push(env.DB.prepare('UPDATE shop_orders SET address=? WHERE user_id=?').bind(JSON.stringify({name:'Deleted User',phone:'',address:'Removed by account deletion'}),uid));
  if(tables.has('myshop_auth_sessions_v108')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_auth_sessions_v108 WHERE user_id=?`).bind(uid));
  if(tables.has('myshop_post_likes')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_post_likes WHERE user_id=? OR post_id IN (SELECT id FROM myshop_posts WHERE user_id=?)`).bind(uid,uid));
  if(tables.has('myshop_post_comments')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_post_comments WHERE user_id=? OR post_id IN (SELECT id FROM myshop_posts WHERE user_id=?)`).bind(uid,uid));
  if(tables.has('myshop_posts')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_posts WHERE user_id=?`).bind(uid));
  if(tables.has('gallery_media')) cleanup.push(env.DB.prepare(`DELETE FROM gallery_media WHERE owner_user_id=?`).bind(uid));
  if(tables.has('myshop_messages')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_messages WHERE sender_id=? OR receiver_id=?`).bind(uid,uid));
  if(tables.has('myshop_friend_requests')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_friend_requests WHERE sender_id=? OR receiver_id=?`).bind(uid,uid));
  if(tables.has('myshop_follows')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_follows WHERE follower_id=? OR following_id=?`).bind(uid,uid));
  if(tables.has('myshop_user_blocks')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_user_blocks WHERE blocker_id=? OR blocked_id=?`).bind(uid,uid));
  if(tables.has('myshop_profile_privacy')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_profile_privacy WHERE user_id=?`).bind(uid));
  if(tables.has('myshop_user_social_links')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_user_social_links WHERE user_id=?`).bind(uid));
  if(tables.has('myshop_user_social_visibility')) cleanup.push(env.DB.prepare('DELETE FROM myshop_user_social_visibility WHERE user_id=?').bind(uid));
  for(const table of ['myshop_private_bank_account','myshop_private_bank_audit'])if(tables.has(table))cleanup.push(env.DB.prepare(`DELETE FROM ${table} WHERE user_id=?`).bind(uid));
  if(tables.has('myshop_personal_detail_access')) cleanup.push(env.DB.prepare('DELETE FROM myshop_personal_detail_access WHERE user_id=? OR viewer_id=?').bind(uid,uid));
  if(tables.has('myshop_user_personal_details')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_user_personal_details WHERE user_id=?`).bind(uid));
  if(tables.has('myshop_app_presence')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_app_presence WHERE user_id=?`).bind(uid));
  if(tables.has('myshop_live_presence')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_live_presence WHERE user_id=?`).bind(uid));
  if(tables.has('myshop_live_viewers')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_live_viewers WHERE user_id=?`).bind(uid));
  if(tables.has('myshop_live_requests')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_live_requests WHERE user_id=? OR host_id=?`).bind(uid,uid));
  if(tables.has('myshop_live_invites')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_live_invites WHERE user_id=? OR host_id=?`).bind(uid,uid));
  if(tables.has('myshop_live_seats_dynamic')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_live_seats_dynamic WHERE user_id=? OR host_id=?`).bind(uid,uid));
  if(tables.has('myshop_upcoming_reminders')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_upcoming_reminders WHERE user_id=?`).bind(uid));
  if(tables.has('myshop_upcoming_deliveries')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_upcoming_deliveries WHERE user_id=?`).bind(uid));
  if(tables.has('myshop_folder_notice_reads')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_folder_notice_reads WHERE admin_id=?`).bind(uid));
  if(tables.has('myshop_folder_notice_migration')) cleanup.push(env.DB.prepare(`DELETE FROM myshop_folder_notice_migration WHERE admin_id=?`).bind(uid));
  if(tables.has('notification_reads')) cleanup.push(env.DB.prepare(`DELETE FROM notification_reads WHERE user_id=?`).bind(uid));
  if(tables.has('notifications')) cleanup.push(env.DB.prepare(`DELETE FROM notifications WHERE user_id=? OR actor_user_id=?`).bind(uid,uid));
  if(tables.has('myshop_safety_reports')) cleanup.push(env.DB.prepare(`UPDATE myshop_safety_reports SET reporter_id=CASE WHEN reporter_id=? THEN '' ELSE reporter_id END,target_user_id=CASE WHEN target_user_id=? THEN '' ELSE target_user_id END,updated_at=CURRENT_TIMESTAMP WHERE reporter_id=? OR target_user_id=?`).bind(uid,uid,uid,uid));
  if(tables.has('myshop_account_deletion_requests')) cleanup.push(env.DB.prepare(`UPDATE myshop_account_deletion_requests SET identifier='',contact='',reason='',status=CASE WHEN EXISTS(SELECT 1 FROM myshop_deleted_media WHERE user_id=? AND state='PENDING') THEN 'MEDIA_PENDING' ELSE 'COMPLETED' END,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(uid,uid));
  cleanup.push(env.DB.prepare(`UPDATE myshop_auth_users_v108 SET full_name='Deleted User',email=NULL,mobile=NULL,password_hash=?,security_q1='',security_a1_hash='',security_q2='',security_a2_hash='',security_q3='',security_a3_hash='',role='USER',active=0,avatar_url='',avatar_object_key='',cover_url='',cover_object_key='',bio='',gender='UNSPECIFIED',updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(tomb,uid));
  if(tables.has('myshop_folder_grants'))cleanup.push(env.DB.prepare('UPDATE myshop_folder_grants SET enabled=0,revision=revision+1,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(uid));
  if(tables.has('myshop_moderators_v108'))cleanup.push(env.DB.prepare('UPDATE myshop_moderators_v108 SET active=0 WHERE user_id=?').bind(uid));
  // Every personal-data cleanup and durable media tombstone commits together; failure reports no success.
  await env.DB.batch(cleanup);
  try{await drainDeletedMedia(env);}catch(_){console.error('ACCOUNT_MEDIA_CLEANUP_RETRY_PENDING');}
  const pending=await env.DB.prepare("SELECT COUNT(*) total FROM myshop_deleted_media WHERE user_id=? AND state='PENDING'").bind(uid).first();
  return json({ok:true,deleted:true,mediaCleanupPending:Number(pending?.total||0)>0,userIdRetainedForSecurity:true},200,cors);
}
async function adminSafetyReportAction(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;try{await env.DB.prepare(`ALTER TABLE myshop_safety_reports ADD COLUMN review_reason TEXT NOT NULL DEFAULT ''`).run();}catch(e){}const b=await body(request),id=Math.floor(Number(b.id||0)),status=String(b.status||'').toUpperCase();if(!id||!['RESOLVED','DISMISSED','OPEN','REVIEWING'].includes(status))return json({error:'INVALID_REPORT_ACTION'},400,cors);const r=await env.DB.prepare(`UPDATE myshop_safety_reports SET status=?,review_reason=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(status,String(b.reason||'').slice(0,800),id).run();if(!Number(r.meta?.changes||0))return json({error:'REPORT_NOT_FOUND'},404,cors);return json({ok:true,id,status},200,cors);
}
async function adminDeletionRequests(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;const u=new URL(request.url),status=String(u.searchParams.get('status')||'OPEN').toUpperCase();const rows=(await env.DB.prepare(`SELECT id,user_id,identifier,contact,reason,status,created_at,updated_at FROM myshop_account_deletion_requests WHERE (?='ALL' OR status=?) ORDER BY CASE status WHEN 'OPEN' THEN 0 ELSE 1 END,datetime(created_at) DESC,id DESC LIMIT 200`).bind(status,status).all()).results||[];return json({ok:true,requests:rows},200,cors);
}
async function adminDeletionRequestAction(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;
  const b=await body(request),id=Number(b.id),status=String(b.status||'').toUpperCase();
  if(!Number.isSafeInteger(id)||id<1||!['VERIFIED','COMPLETED','DISMISSED','OPEN'].includes(status))return json({error:'INVALID_DELETE_REQUEST_ACTION'},400,cors);
  const row=await env.DB.prepare(`SELECT id,user_id,status FROM myshop_account_deletion_requests WHERE id=?`).bind(id).first();
  if(!row)return json({error:'DELETE_REQUEST_NOT_FOUND'},404,cors);
  if(status==='COMPLETED'){
    const account=row.user_id?await env.DB.prepare('SELECT active,password_hash FROM myshop_auth_users_v108 WHERE user_id=?').bind(row.user_id).first():null;
    if(!account||Number(account.active)!==0||!String(account.password_hash||'').startsWith('deleted$'))return json({error:'ACCOUNT_NOT_DELETED'},409,cors);
    await env.DB.prepare(deletionMediaSchema).run();
    const media=await env.DB.prepare("SELECT COUNT(*) total FROM myshop_deleted_media WHERE user_id=? AND state='PENDING'").bind(row.user_id).first();
    if(Number(media?.total||0)>0)return json({error:'MEDIA_DELETION_PENDING'},409,cors);
  }
  if(row.status===status)return json({ok:true,id,status,alreadyApplied:true},200,cors);
  if(['COMPLETED','MEDIA_PENDING'].includes(row.status)||status==='VERIFIED'&&!['OPEN','VERIFIED'].includes(row.status))return json({error:'INVALID_DELETE_REQUEST_TRANSITION'},409,cors);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_deletion_review_audit(id INTEGER PRIMARY KEY AUTOINCREMENT,request_id INTEGER NOT NULL,actor_id TEXT NOT NULL,old_status TEXT NOT NULL,new_status TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  const actor=a.user||await getUser(request,env);
  const result=await env.DB.batch([
    env.DB.prepare('UPDATE myshop_account_deletion_requests SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND status=?').bind(status,id,row.status),
    env.DB.prepare('INSERT INTO myshop_deletion_review_audit(request_id,actor_id,old_status,new_status) SELECT ?,?,?,? WHERE changes()=1').bind(id,actor.user_id,row.status,status)
  ]);
  if(!Number(result[0]?.meta?.changes||0))return json({error:'DELETE_REQUEST_CHANGED_RELOAD'},409,cors);
  return json({ok:true,id,userId:row.user_id||'',status,note:status==='VERIFIED'?'Ownership review recorded. Account deletion must still be completed through the authenticated owner flow.':''},200,cors);
}

async function adminPermissions(request,env) {
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const user = auth.user;
  const mods = await env.DB.prepare('SELECT user_id,active FROM myshop_moderators_v108 ORDER BY user_id LIMIT 5').all();
  return json({ok:true,role:user.role,admin:true,moderators:mods.results||[]},200,cors);
}

async function adminAction(request,env) {
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const actor=auth.user||auth.me||null, b = await body(request);
  const uid = String(b.userId||'').trim(), action = String(b.action||'').toLowerCase();
  if (!isFourDigit(uid)) return json({error:'INVALID_USER_ID'},400,cors);
  const target=await env.DB.prepare('SELECT user_id,active FROM myshop_auth_users_v108 WHERE user_id=?').bind(uid).first();
  if(!target)return json({error:'USER_NOT_FOUND'},404,cors);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_admin_user_actions(
    id INTEGER PRIMARY KEY AUTOINCREMENT,admin_id TEXT NOT NULL,user_id TEXT NOT NULL,action TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`).run();
  if (action==='add_moderator'||action==='remove_moderator') {
    return await applyModeratorChange(env,actor,uid,action,b.note,{json,cors});
  } else if(action==='ban_user'||action==='block_user'){
    if(uid==='0001'||uid==='0002'||uid==='0003')return json({error:'PROTECTED_ADMIN'},403,cors);
    await env.DB.prepare('UPDATE myshop_auth_users_v108 SET active=0 WHERE user_id=?').bind(uid).run();
  } else if(action==='temporary_block'){
    if(['0001','0002','0003'].includes(uid))return json({error:'PROTECTED_ADMIN'},403,cors);
    const hours=Number(b.hours);if(!Number.isSafeInteger(hours)||hours<1||hours>8760)return json({error:'INVALID_BLOCK_HOURS'},400,cors);
    await env.DB.prepare('UPDATE myshop_auth_users_v108 SET blocked_until=? WHERE user_id=?').bind(Date.now()+hours*3600000,uid).run();
  } else if(action==='unban_user'||action==='unblock_user'){
    await env.DB.prepare('UPDATE myshop_auth_users_v108 SET active=1,blocked_until=0 WHERE user_id=?').bind(uid).run();
  } else return json({error:'UNSUPPORTED_ACTION'},400,cors);
  const adminId=String(actor?.user_id||'ADMIN');
  await env.DB.prepare('INSERT INTO myshop_admin_user_actions(admin_id,user_id,action,note) VALUES(?,?,?,?)').bind(adminId,uid,action,String(b.note||'')).run();
  return json({ok:true,userId:uid,action},200,cors);
}


export class LiveRoomHub {
  constructor(state,env){this.state=state;this.env=env;}
  async resetForSession(sessionId){
    const current=String((await this.state.storage.get('sessionId'))||'');
    if(current===String(sessionId))return false;
    await this.state.storage.deleteAll();
    await this.state.storage.put({sessionId:String(sessionId),stateRevision:0,commentSeq:0,highlightSeq:0,comments:[],highlights:[],gifts:[]});
    return true;
  }
  async bumpState(){
    const revision=Math.max(0,Number((await this.state.storage.get('stateRevision'))||0))+1;
    await this.state.storage.put('stateRevision',revision);return revision;
  }
  async fetch(request){
    const u=new URL(request.url),p=u.pathname;
    if(p==='/register'&&request.method==='POST'){
      const b=await request.json(),sessionId=String(b.sessionId||''),tokenHash=String(b.tokenHash||''),userId=String(b.userId||'');
      if(!sessionId||!tokenHash||!userId)return json({error:'INVALID_REGISTER'},400);
      await this.resetForSession(sessionId);
      const ticketKey='participant:'+tokenHash,previous=await this.state.storage.get(ticketKey),now=Date.now();
      const registeredAt=previous&&String(previous.userId||'')===userId?Math.max(0,Number(previous.registeredAt||now)):now;
      await this.state.storage.put(ticketKey,{userId,registeredAt,expiresAt:Math.max(now+5000,Number(b.expiresAt||0))});
      try{await this.state.storage.setAlarm(Date.now()+2*60*60*1000);}catch(e){}
      return json({ok:true,sessionId},200);
    }
    if(p==='/push'&&request.method==='POST'){
      const b=await request.json(),sessionId=String(b.sessionId||''),kind=String(b.kind||'DIRTY').toUpperCase(),payload=(b.payload&&typeof b.payload==='object')?b.payload:{};
      if(!sessionId)return json({error:'INVALID_SESSION'},400);
      await this.resetForSession(sessionId);
      let item=null;
      if(kind==='COMMENT'){
        const now=Date.now();let a=Array.isArray(await this.state.storage.get('comments'))?await this.state.storage.get('comments'):[];
        a=a.filter(x=>now-Number(x._ts||0)<=60*60*1000).slice(-79);
        const nonce=String(payload.client_nonce||''),uid=String(payload.user_id||''),message=String(payload.message||'');
        const duplicate=[...a].reverse().find(x=>String(x.user_id||'')===uid&&((nonce&&String(x.client_nonce||'')===nonce)||(!nonce&&String(x.message||'')===message&&now-Number(x._ts||0)<=2000)));
        if(duplicate)item=duplicate;
        else{
          const seq=Math.max(0,Number((await this.state.storage.get('commentSeq'))||0))+1;
          item={...payload,id:seq,_ts:now};a.push(item);
          await this.state.storage.put({commentSeq:seq,comments:a});
        }
      }else if(kind==='HIGHLIGHT'){
        const requestId=String(payload.request_id||''),prior=requestId?await this.state.storage.get('highlightRequest:'+requestId):null;
        if(prior&&String(prior.user_id||'')===String(payload.user_id||''))item=prior;
        else{const seq=Math.max(0,Number((await this.state.storage.get('highlightSeq'))||0))+1;item={...payload,id:seq,_ts:Date.now()};let a=Array.isArray(await this.state.storage.get('highlights'))?await this.state.storage.get('highlights'):[];a=a.filter(x=>Date.now()-Number(x._ts||0)<=20000).slice(-19);a.push(item);await this.state.storage.put({highlightSeq:seq,highlights:a});if(requestId)await this.state.storage.put('highlightRequest:'+requestId,item);}
      }else if(kind==='GIFT'){
        item={...payload,_ts:Date.now()};let a=Array.isArray(await this.state.storage.get('gifts'))?await this.state.storage.get('gifts'):[];
        const eid=Math.max(0,Number(item.id||0));a=a.filter(x=>Date.now()-Number(x._ts||0)<=5*60*1000&&Number(x.id||0)!==eid).slice(-39);a.push(item);
        await this.state.storage.put('gifts',a);
      }
      // V-392: a gift is both an effect event and a room-state change. Bump revision so
      // clients that miss the direct gift payload still perform a safety snapshot and recover it.
      const revision=(kind==='DIRTY'||kind==='GIFT')?await this.bumpState():Math.max(0,Number((await this.state.storage.get('stateRevision'))||0));
      const out=item?{...item}:null;if(out)delete out._ts;
      return json({ok:true,revision,item:out},200);
    }
    if(p==='/events'&&request.method==='GET'){
      const sessionId=String(u.searchParams.get('sessionId')||''),tokenHash=String(u.searchParams.get('tokenHash')||'');
      const current=String((await this.state.storage.get('sessionId'))||'');
      if(!sessionId||sessionId!==current)return json({error:'REALTIME_SESSION_MISMATCH'},409);
      const participant=await this.state.storage.get('participant:'+tokenHash);
      if(!participant||Number(participant.expiresAt||0)<Date.now())return json({error:'REALTIME_TICKET_EXPIRED'},401);
      const afterComment=Math.max(0,Number(u.searchParams.get('afterComment')||0)),afterHighlight=Math.max(0,Number(u.searchParams.get('afterHighlight')||0)),afterGift=Math.max(0,Number(u.searchParams.get('afterGift')||0)),knownRevision=Math.max(0,Number(u.searchParams.get('revision')||0));
      const revision=Math.max(0,Number((await this.state.storage.get('stateRevision'))||0)),visibleSince=Math.max(0,Number(participant.registeredAt||0));
      const comments=(Array.isArray(await this.state.storage.get('comments'))?await this.state.storage.get('comments'):[]).filter(x=>Number(x.id||0)>afterComment&&Number(x._ts||0)>=visibleSince).map(x=>{const y={...x};delete y._ts;return y;});
      const highlights=(Array.isArray(await this.state.storage.get('highlights'))?await this.state.storage.get('highlights'):[]).filter(x=>Number(x.id||0)>afterHighlight&&Number(x._ts||0)>=visibleSince).map(x=>{const y={...x};delete y._ts;return y;});
      const gifts=(Array.isArray(await this.state.storage.get('gifts'))?await this.state.storage.get('gifts'):[]).filter(x=>Number(x.id||0)>afterGift&&Number(x._ts||0)>=visibleSince).map(x=>{const y={...x};delete y._ts;return y;});
      return json({ok:true,sessionId,revision,changed:revision>knownRevision,comments,highlights,gifts},200);
    }
    if(p==='/clear'&&request.method==='POST'){await this.state.storage.deleteAll();return json({ok:true},200);}
    return json({error:'NOT_FOUND'},404);
  }
  async alarm(){await this.state.storage.deleteAll();}
}


// V-379 compatibility export: production already has Durable Objects created
// under the historical class name LiveRoomRealtime. Keep that exact class
// exported and backed by the current LiveRoomHub implementation so existing
// Durable Object storage/namespaces are preserved during deployment.
export class LiveRoomRealtime extends LiveRoomHub {}


function liveSharePage(url){
  const hostId=String(url.searchParams.get('hostId')||''),sessionId=String(url.searchParams.get('sessionId')||'');
  if(!isFourDigit(hostId)||!/^[A-Za-z0-9_-]{1,160}$/.test(sessionId))return new Response('Invalid live link',{status:400});
  const apk='https://github.com/myshop24/MY-SHOP/releases/latest/download/MY_SHOP_FINAL_RELEASE.apk';
  const deep='intent://live?hostId='+encodeURIComponent(hostId)+'&sessionId='+encodeURIComponent(sessionId)+'#Intent;scheme=myshop;package=com.myshop.app;S.browser_fallback_url='+encodeURIComponent(apk)+';end';
  return new Response('<!doctype html><html lang="bn"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MY SHOP Live</title><style>body{font-family:system-ui;background:#101b38;color:white;text-align:center;padding:60px 20px}a{display:block;margin:24px auto;padding:18px;background:#723bec;border-radius:16px;color:white;text-decoration:none;max-width:300px}</style><h1>MY SHOP লাইভ</h1><p>শেয়ার করা লাইভটি অ্যাপে খুলুন।</p><a href="'+deep+'">লাইভে প্রবেশ করুন</a><a href="'+apk+'">অ্যাপ ডাউনলোড করুন</a></html>',{headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store','content-security-policy':"default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; frame-ancestors 'none'"}});
}

function profileSharePage(url){
 const id=String(url.searchParams.get('userId')||'');if(!isFourDigit(id))return new Response('Invalid profile link',{status:400});
 const apk='https://github.com/myshop24/MY-SHOP/releases/latest/download/MY_SHOP_FINAL_RELEASE.apk';
 const deep='intent://profile?userId='+id+'#Intent;scheme=myshop;package=com.myshop.app;S.browser_fallback_url='+encodeURIComponent(apk)+';end';
 return new Response('<!doctype html><html lang="bn"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MY SHOP • ID '+id+'</title><body><h1>MY SHOP • ID '+id+'</h1><p>অ্যাপে এই প্রোফাইলটি দেখুন।</p><p><a href="'+deep+'">প্রোফাইল খুলুন</a></p><p><a href="'+apk+'">সর্বশেষ অ্যাপ ডাউনলোড করুন</a></p></body></html>',{headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store','content-security-policy':"default-src 'none'; base-uri 'none'; frame-ancestors 'none'"}});
}

export default {
  async scheduled(controller, env, ctx) { try { await drainDeletedMedia(env);await processUpcomingReminders(env);if(controller.cron==='* * * * *')return; try{await env.DB.prepare(`DELETE FROM myshop_highlight_payments WHERE status='PENDING' AND datetime(created_at)<datetime('now','-2 minutes')`).run();}catch(e){} await processScheduledOfficialNotices(env,ctx);await dispatchRequestNotices(env); } catch(e) { console.error('SCHEDULED_HANDLER_FAILED',String(e?.message||e)); } },
  async fetch(request, env, ctx) {
    if (request.method === 'OPTIONS') return new Response(null,{status:204,headers:cors});
    const url = new URL(request.url); const p=url.pathname;
    try {
      if(request.method==='GET' && p==='/live')return liveSharePage(url);
      if(request.method==='GET' && p==='/profile')return profileSharePage(url);
      if(p==='/v1/agency')return await agencyApi(request,env,{getUser,json,cors,notify:(...args)=>createUserNotification(...args,ctx)});
      if(p==='/v1/admin/commission-management')return await commissionManagement(request,env,{getUser,json,cors});
      if(request.method==='GET' && p==='/v1/wallet/transfer/config'){const u=await getUser(request,env);if(!u)return json({error:'UNAUTHORIZED'},401,cors);const c=await financeConfig(env,'TRANSFER');return json({ok:true,vatPercent:c.vatPercent,coinCommissionPercent:c.coinCommissionPercent,goldCommissionPercent:c.goldCommissionPercent},200,{...cors,'cache-control':'no-store'});}
      if(request.method==='GET' && p.startsWith('/shop/product/'))return await productPage(request,env);
      if(['/v1/me/admin-folders','/v1/admin/folder-grants','/v1/admin/features/draft','/v1/admin/features/publish'].includes(p)){await ensureAuthSchema(env);return await adminFolderControls(request,env,{getUser,json,cors});}
      if(p==='/v1/admin/wallet/remove'){await ensureAuthSchema(env);await ensureLiveRoomSchema(env);return await adminWalletRemove(request,env,{getUser,adminOnly,ensureContentSchema,walletSourceState,json,cors});}
      if(p==='/v1/admin/payouts/action'){await ensureAuthSchema(env);await ensureLiveRoomSchema(env);return await payoutAction(request,env,{getUser,adminOnly,ensureContentSchema,json,cors});}
      if(p==='/v1/payouts'||p==='/v1/admin/payouts'){await ensureAuthSchema(env);return await payoutInbox(request,env,{getUser,adminOnly,ensureContentSchema,json,cors},p==='/v1/admin/payouts');}
      if(p==='/v1/admin/moderator-directory'){await ensureAuthSchema(env);return await moderatorDirectory(request,env,{getUser,json,cors});}
      if(p.startsWith('/v1/commerce/')){await ensureAuthSchema(env);return await commerce(request,env,{getUser,adminOnly,json,cors,ensureRequestNotices});}
      if(p==='/v1/admin/folder-notices'){await ensureAuthSchema(env);return await folderRequestNotices(request,env,{getUser,adminOnly,json,cors});}
      if(p==='/v1/admin/request-notices'){await ensureAuthSchema(env);return await requestNotices(request,env,{getUser,adminOnly,json,cors});}
      if (request.method==='GET' && p==='/health') return json({ok:true,service:'my-shop-api',version:'2.9.604',build:'V-604',database:'my-shop-db',r2:'MEDIA',time:new Date().toISOString()},200,cors);
      if (request.method==='GET' && p==='/health/deep') {
        try { await ensureAuthSchema(env); } catch (_) {}
        try { await ensureSchemasOnce(env); } catch (_) {}
        const h=await deepHealth(env);
        return json(h,h.ok?200:503,cors);
      }
      if(request.method==='GET' && p==='/community-guidelines') return communityGuidelinesPage();
      if (request.method==='GET' && p==='/privacy') return privacyPage();
      if (request.method==='GET' && p==='/terms') return termsPage();
      if (request.method==='GET' && p==='/account-deletion') return accountDeletionPage();
      // V-352 realtime path intentionally bypasses D1/schema bootstrap after a room ticket
      // has been registered by the authenticated room-state request.
      if (request.method==='GET' && p==='/v1/live/realtime') return await liveRealtime(request,env);
      if (request.method==='POST' && p==='/v1/account/deletion-request') { await ensureSchemasOnce(env); return await accountDeletionRequest(request,env); }
      // Dashboard config is public read data. Do not let an unrelated auth/content schema
      // initialization failure turn a simple config read into SERVER_ERROR.
      if (request.method==='GET' && p==='/v1/dashboard/config') {
        try { await ensureSchemasOnce(env); } catch (_) {}
        return await dashboardConfig(request,env);
      }
      // V-362 auth isolation: Login/session checks must not be blocked by unrelated
      // Live/Gift/content schema migrations. Bring up only the auth tables for these
      // endpoints, then return immediately. This preserves account data and keeps
      // login usable even if another module has a temporary schema problem.
      if (request.method==='POST' && p==='/v1/auth/register') { await ensureAuthSchema(env); return await register(request,env); }
      if (request.method==='POST' && p==='/v1/auth/login') { await ensureAuthSchema(env); return await login(request,env); }
      if (request.method==='POST' && p==='/v1/auth/google') { await ensureAuthSchema(env); return await googleLogin(request,env); }
      if (request.method==='POST' && p==='/v1/auth/logout') { await ensureAuthSchema(env); return await logout(request,env); }
      if (request.method==='GET' && p==='/v1/auth/password/questions') { await ensureAuthSchema(env); return await securityQuestions(request,env); }
      if (request.method==='POST' && p==='/v1/auth/password/reset') { await ensureAuthSchema(env); return await resetPassword(request,env); }
      if (request.method==='POST' && p==='/v1/auth/password/change') { await ensureAuthSchema(env); return await changePassword(request,env); }
      if (request.method==='GET' && p==='/v1/me') { await ensureAuthSchema(env); return await me(request,env); }
      if (request.method==='GET' && p==='/v1/live-home/banners') return await publicLiveHomeBanners(request,env);
      // V-363 stability isolation: presence refresh must not trigger the full module schema bootstrap.
      if ((request.method==='GET'||request.method==='POST')&&p==='/v1/live/settings')return await liveBatchSettings(request,env);
      if ((request.method==='GET'||request.method==='POST')&&p==='/v1/notifications/preferences')return await notificationPreferences(request,env);
      if (request.method==='GET'&&p==='/v1/push/diagnostics')return await pushDiagnostics(request,env);
      if (request.method==='POST'&&p==='/v1/messages/typing')return await messageTyping(request,env);
      if (request.method==='POST' && p==='/v1/app/presence') { await ensureAuthSchema(env); return await appPresence(request,env); }

      await ensureSchemasOnce(env);
      // V-300: the second Admin Locker is app-local only. Backend authorization remains ADMIN role/identity based.
      if (request.method==='GET' && p==='/v1/admin/gate/status') return json({ok:true,localOnly:true},200,cors);
      if (p==='/v1/admin/gate/setup' || p==='/v1/admin/gate/unlock' || p==='/v1/admin/gate/recover') return json({ok:true,localOnly:true},200,cors);
      if (request.method==='POST' && p==='/v1/account/delete') return await accountDelete(request,env);
      if (request.method==='POST' && p==='/v1/safety/block') return await safetyBlock(request,env);
      if (request.method==='GET' && p==='/v1/safety/blocks') return await safetyBlocks(request,env);
      if (request.method==='GET' && p==='/v1/live/muted-users') return await liveMutedUsers(request,env);
      if (request.method==='POST' && p==='/v1/live/muted-users/unmute') return await liveUnmuteSavedUser(request,env);
      if (request.method==='POST' && p==='/v1/safety/report') return await safetyReport(request,env);
      if (request.method==='GET' && p==='/v1/play/billing-ready') return await playBillingReady(request,env);
      if (request.method==='POST' && p==='/v1/play/purchase/verify') return await playPurchaseVerify(request,env);
      if (request.method==='GET' && p==='/v1/people/new') return await newPeople(request,env);
      if (request.method==='GET' && p==='/v1/history') return await historyList(request,env);
      if (request.method==='POST' && p==='/v1/history/record') return await historyRecord(request,env);
      if (request.method==='POST' && p==='/v1/history/clear') return await historyClear(request,env);
      if (request.method==='GET' && p==='/v1/users/connections') return await profileConnections(request,env);
      if (request.method==='GET' && p==='/v1/users/profile') return await publicUserProfile(request,env);
      if (request.method==='POST' && p==='/v1/friends/request') return await friendRequest(request,env);
      if (request.method==='GET' && p==='/v1/friends') return await friendRequestsList(request,env);
      if (request.method==='POST' && p==='/v1/friends/respond') return await friendRespond(request,env);
      if (request.method==='POST' && p==='/v1/friends/cancel') return await friendCancel(request,env);
      if (request.method==='POST' && p==='/v1/friends/remove') return await friendRemove(request,env);
      if (request.method==='POST' && p==='/v1/follow/toggle') return await followToggle(request,env);
      if (request.method==='GET' && p==='/v1/live/music') return await liveMusicCatalog(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/music/save') return await adminLiveMusicSave(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/music/delete') return await adminLiveMusicDelete(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/music/upload') return await adminLiveMusicUpload(request,env);
      if (request.method==='GET' && p==='/v1/live/profiles') return await liveProfiles(request,env);
      if (request.method==='POST' && p==='/v1/push/token') return await pushTokenRegister(request,env);
      if (request.method==='POST' && p==='/v1/push/self-test') return await pushSelfTest(request,env);
      if (request.method==='POST' && p==='/v1/live/presence') return await livePresence(request,env,ctx);
      if (request.method==='POST' && p==='/v1/live/heartbeat') return await liveHostHeartbeat(request,env);
      if (request.method==='POST' && p==='/v1/live/end') return await liveEnd(request,env);
      if (request.method==='POST' && p==='/v1/live/viewer') return await liveViewer(request,env);
      if (request.method==='GET' && p==='/v1/live/room') return await liveRoomState(request,env);
      if (request.method==='POST' && p==='/v1/live/rtc/token') return await liveRtcToken(request,env);
      if (request.method==='POST' && p==='/v1/live/request') return await liveSpeakRequest(request,env,ctx);
      if (request.method==='POST' && p==='/v1/live/request/cancel') return await liveCancelSpeakRequest(request,env);
      if (request.method==='POST' && p==='/v1/live/request/action') return await liveRequestAction(request,env,ctx);
      if (request.method==='POST' && p==='/v1/live/invite') return await liveInvite(request,env,ctx);
      if (request.method==='POST' && p==='/v1/live/invite/action') return await liveInviteAction(request,env,ctx);
      if (request.method==='POST' && p==='/v1/live/seat/leave') return await liveLeaveSeat(request,env);
      if (request.method==='POST' && p==='/v1/live/seat/assign') return await liveSeatAssign(request,env);
      if (request.method==='POST' && p==='/v1/live/special-guest') return await liveSpecialGuest(request,env);
      if (request.method==='POST' && p==='/v1/live/speaker/remove') return await liveSpeakerRemove(request,env);
      if ((request.method==='GET'||request.method==='POST') && p==='/v1/live/comment-ui') return await liveCommentUiConfig(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/comment-global/save') return await adminLiveCommentGlobalSave(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/comment-preset/save') return await adminLiveCommentPresetSave(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/comment-assignment/save') return await adminLiveCommentAssignmentSave(request,env);
      if (request.method==='POST' && p==='/v1/live/room/config') return await liveRoomConfig(request,env);
      if (request.method==='POST' && p==='/v1/live/room/premium') return await livePremiumConfig(request,env);
      if (request.method==='POST' && p==='/v1/live/poll/start') return await livePollStart(request,env);
      if (request.method==='POST' && p==='/v1/live/poll/vote') return await livePollVote(request,env);
      if (request.method==='POST' && p==='/v1/live/poll/close') return await livePollClose(request,env);
      if (request.method==='GET' && p==='/v1/live/fan-club') return await liveFanClub(request,env);
      if (request.method==='POST' && p==='/v1/live/fan-club/toggle') return await liveFanClubToggle(request,env);
      if (request.method==='GET' && p==='/v1/live/creator-center') return await liveCreatorCenter(request,env);
      if (request.method==='GET' && p==='/v1/live/discover') return await liveDiscover(request,env);
      if (request.method==='GET' && p==='/v1/live/schedules') return await liveScheduleList(request,env);
      if (request.method==='POST' && p==='/v1/live/schedules/save') return await liveScheduleSave(request,env);
      if (request.method==='POST' && p==='/v1/live/schedules/cancel') return await liveScheduleCancel(request,env);
      if (request.method==='POST' && p==='/v1/live/schedules/reminder') return await liveScheduleReminder(request,env);
      if (request.method==='POST' && p==='/v1/live/pk/start') return await livePkStart(request,env);
      if (request.method==='POST' && p==='/v1/live/pk/action') return await livePkAction(request,env);
      if (request.method==='POST' && p==='/v1/live/seat/lock') return await liveSeatLock(request,env);
      if (request.method==='POST' && p==='/v1/live/participant/state') return await liveParticipantState(request,env);
      if (request.method==='POST' && p==='/v1/live/share') return await liveShare(request,env);
      if (request.method==='POST' && p==='/v1/live/comment') return await liveComment(request,env);
      if (request.method==='POST' && p==='/v1/live/react') return await liveReact(request,env);
      if (request.method==='POST' && p==='/v1/live/vote') return await liveVote(request,env);
      if (request.method==='GET' && p==='/v1/live/highlight/config') return await liveHighlightConfig(request,env);
      if (request.method==='POST' && p==='/v1/live/highlight/comment') return await liveHighlightComment(request,env);
      if (request.method==='GET' && p==='/v1/live/gifts/summary') return await liveGiftSummary(request,env);
      if (request.method==='POST' && p==='/v1/wallet/transfer') return await liveValueTransfer(request,env);
      if (request.method==='GET' && p==='/v1/admin/user-control/details') return await userControlDetails(request,env,{getUser,json,cors});
      if (request.method==='POST' && p==='/v1/admin/user-control/moderation') return await adminModerationOverride(request,env,{getUser,json,cors,liveHubDirtyForHost});
      if (['GET','POST'].includes(request.method) && p==='/v1/admin/special-user-id') return await specialUserId(request,env,{getUser,json,cors,ownerAdminIdForIdentifier});
      if (request.method==='GET' && p==='/v1/features/access') return await featureAccess(request,env,{getUser,json,cors});
      if (request.method==='GET' && p==='/v1/wallet/history') return await walletHistory(request,env,{getUser,json,cors});
      if (request.method==='GET' && p==='/v1/wallet/value-history') return await userValueHistory(request,env);
      if (request.method==='POST' && p==='/v1/live/moderation') return await liveModerationAction(request,env);
      if (request.method==='GET' && p==='/v1/live/gifts') return await liveGiftCatalog(request,env);
      if (request.method==='POST' && p==='/v1/live/gifts/thank-you') return await liveGiftThankYou(request,env);
      if (request.method==='GET' && p==='/v1/live/gifts/events') return await liveGiftEvents(request,env);
      if (request.method==='POST' && p==='/v1/live/gifts/send') return await liveGiftSend(request,env,ctx);
      if (request.method==='GET' && p==='/v1/admin/live/gifts') return await adminLiveGifts(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/gifts/save') return await adminLiveGiftSave(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/gifts/bulk-vat') return await adminLiveGiftBulkVat(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/gifts/reorder') return await adminLiveGiftReorder(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/gifts/delete') return await adminLiveGiftDelete(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/gifts/asset/upload') return await adminLiveGiftAssetUpload(request,env);
      if (request.method==='GET' && p==='/v1/admin/activity') return await adminActivity(request,env,{getUser,json,cors});
      if (request.method==='GET' && p==='/v1/admin/finance/overview') return await adminFinanceOverview(request,env);
      if (request.method==='GET' && p==='/v1/admin/user-audit') return await adminUserAudit(request,env);
      if (request.method==='POST' && p==='/v1/admin/account-recovery/update') return await adminAccountRecoveryUpdate(request,env);
      if (request.method==='POST' && p==='/v1/admin/account-recovery/password-reset') return await adminAccountPasswordReset(request,env);
      if ((request.method==='GET'||request.method==='POST') && p==='/v1/admin/finance/config') return await adminFinanceConfig(request,env);
      if (request.method==='GET' && p==='/v1/admin/finance/summary') return await adminFinanceSummary(request,env);
      if (request.method==='GET' && p==='/v1/admin/live/moderation/audit') return await liveModerationAudit(request,env);
      if (request.method==='GET' && p==='/v1/live/themes') return await liveThemes(request,env);
      if (request.method==='GET' && p==='/v1/live/ui-settings') return await liveUiSettings(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/themes') return await adminLiveTheme(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/ui-settings') return await adminLiveUiSettings(request,env);
      if (request.method==='GET' && p==='/v1/live/summary') return await liveSummary(request,env);
      if (request.method==='GET' && p==='/v1/users/posts') return await userPosts(request,env);
      if (request.method==='GET' && p==='/v1/me/privacy') return await myPrivacy(request,env);
      if (request.method==='PUT' && p==='/v1/me/privacy') return await updateMyPrivacy(request,env);
      if (request.method==='GET' && p==='/v1/me/social-links') return await userSocialLinksGet(request,env);
      if (request.method==='PUT' && p==='/v1/me/social-links') return await userSocialLinksPut(request,env);
      if (request.method==='GET' && p==='/v1/me/personal-details') return await myPersonalDetails(request,env);
      if (request.method==='PUT' && p==='/v1/me/personal-details') return await updateMyPersonalDetails(request,env);
      if (request.method==='GET' && p==='/v1/me/social-stats') return await mySocialStats(request,env);
      if (request.method==='GET' && p==='/v1/messages/inbox') return await messageInbox(request,env);
      if (request.method==='GET' && p==='/v1/messages/thread') return await messageThread(request,env);
      if (request.method==='POST' && p==='/v1/messages/send') return await messageSend(request,env,ctx);
      if (request.method==='GET' && p==='/v1/app/themes')return await appThemeConfig(request,env);
      if (['GET','PUT'].includes(request.method) && p==='/v1/admin/app/themes')return await appThemeConfig(request,env);
      if(request.method==='POST' && p==='/v1/upcoming-live/reminder')return await upcomingReminder(request,env);
      if(request.method==='GET' && p==='/v1/upcoming-live')return await upcomingLive(request,env);
      if(['GET','PUT'].includes(request.method) && p==='/v1/admin/upcoming-live')return await upcomingLive(request,env);
      if (request.method==='GET' && p==='/v1/content/translations')return await contentTranslations(request,env);
      if (request.method==='PUT' && p==='/v1/admin/content/translations')return await contentTranslations(request,env);
      if (request.method==='POST' && p==='/v1/messages/media/upload') return await messageMediaUpload(request,env);
      if (request.method==='POST' && p==='/v1/messages/voice/upload') return await messageVoiceUpload(request,env);
      if (request.method==='POST' && p==='/v1/messages/delete-for-me') return await messageDeleteForMe(request,env);
      if (request.method==='GET' && p==='/v1/messages/unread') return await messageUnread(request,env);
      if (request.method==='PUT' && p==='/v1/me/profile') return await profileUpdate(request,env);
      if (request.method==='POST' && p==='/v1/me/avatar/upload') return await profileAvatarUpload(request,env);
      if (request.method==='POST' && p==='/v1/me/cover/upload') return await profileCoverUpload(request,env);
      if (request.method==='POST' && p==='/v1/me/cover/delete') return await profileCoverDelete(request,env);
      if (request.method==='GET' && p==='/v1/gallery') return await userGalleryList(request,env);
      if (request.method==='POST' && p==='/v1/gallery/upload') return await userGalleryUpload(request,env);
      if (request.method==='PUT' && p==='/v1/gallery/update') return await userGalleryUpdate(request,env);
      if (request.method==='POST' && p==='/v1/gallery/delete') return await userGalleryDelete(request,env);
      if (request.method==='GET' && p==='/v1/feed') return await feedList(request,env);
      if(request.method==='POST'&&p==='/v1/admin/banner-order')return await adminBannerOrder(request,env);
      if(request.method==='POST'&&p==='/v1/admin/general-menu/order')return await adminGeneralMenuOrder(request,env);
      if(request.method==='GET' && p==='/v1/shop/banners')return await publicLiveHomeBanners(request,env);
      if (request.method==='GET' && p==='/v1/feed/post') return await feedPost(request,env);
      if (request.method==='GET' && p==='/v1/videos') return await videoList(request,env);
      if (request.method==='POST' && p==='/v1/feed/upload') return await feedUpload(request,env);
       if (request.method==='POST' && p==='/v1/feed/text') return await feedText(request,env);
      if (request.method==='POST' && p==='/v1/feed/delete') return await feedDeleteOwn(request,env);
      if (request.method==='POST' && p==='/v1/feed/share') return await feedShare(request,env);
      if (request.method==='POST' && p==='/v1/feed/like') return await feedLike(request,env);
      if (request.method==='POST' && p==='/v1/feed/edit') return await feedEdit(request,env);
      if (request.method==='GET' && p==='/v1/feed/comments') return await feedComments(request,env);
      if (request.method==='GET' && p==='/v1/feed/likes') return await feedLikeUsers(request,env);
      if (request.method==='POST' && p==='/v1/feed/comment') return await feedComment(request,env);
      if (request.method==='POST' && p==='/v1/feed/comment/reply') return await feedCommentReply(request,env);
      if (request.method==='GET' && p==='/v1/admin/feed') return await adminFeedList(request,env);
      if (request.method==='POST' && p==='/v1/admin/feed/delete') return await moderatorFeedDelete(request,env);
      if (request.method==='GET' && p==='/v1/admin/safety/reports') return await adminSafetyReports(request,env);
      if (request.method==='POST' && p==='/v1/admin/safety/report/action') return await adminSafetyReportAction(request,env);
      if (request.method==='GET' && p==='/v1/admin/account-deletion-requests') return await adminDeletionRequests(request,env);
      if (request.method==='POST' && p==='/v1/admin/account-deletion-request/action') return await adminDeletionRequestAction(request,env);
      if (request.method==='GET' && p==='/v1/coins') return await coinBalance(request,env);
      if (request.method==='GET' && p==='/v1/gifts/history') return await giftHistory(request,env);
      if (request.method==='POST' && p==='/v1/coins/purchase-request') return await coinPurchaseRequest(request,env);
      if (request.method==='GET' && p==='/v1/store/catalog') return await storeCatalog(request,env);
      if (request.method==='POST' && p==='/v1/store/purchase-intent') return await storePurchaseIntent(request,env);
      if (request.method==='POST' && p==='/v1/store/purchase') return await storeDirectPurchase(request,env);
      if (request.method==='POST' && p==='/v1/store/purchase-request') return await storePurchaseRequest(request,env);
      if (request.method==='POST' && p==='/v1/store/gift-purchase-request') return await storeGiftPurchaseRequest(request,env);
      if (request.method==='GET' && p==='/v1/live-tv/channels') return await liveTvChannels(request,env);
      if (request.method==='GET' && p==='/v1/admin/live-tv/channels') return await adminLiveTvChannels(request,env);
      if (request.method==='POST' && p==='/v1/admin/live-tv/save') return await adminLiveTvSave(request,env);
      if (request.method==='POST' && p==='/v1/admin/live-tv/delete') return await adminLiveTvDelete(request,env);
      if (request.method==='POST' && p==='/v1/badges/active') return await setActiveBadge(request,env);
      if (request.method==='GET' && p==='/v1/admin/store/catalog') return await adminStoreCatalog(request,env);
      if (request.method==='GET' && p==='/v1/admin/store/payment-settings') return await adminPremiumPaymentSettings(request,env);
      if (request.method==='POST' && p==='/v1/admin/store/payment-settings/save') return await adminPremiumPaymentSettingsSave(request,env);
      if (request.method==='POST' && p==='/v1/admin/store/catalog/save') return await adminStoreCatalogSave(request,env);
      if (request.method==='POST' && p==='/v1/admin/store/catalog/toggle') return await adminStoreCatalogToggle(request,env);
      if (request.method==='POST' && p==='/v1/admin/store/catalog/delete') return await adminStoreCatalogDelete(request,env);
      if (request.method==='POST' && p==='/v1/admin/store/catalog/reorder') return await adminStoreCatalogReorder(request,env);
      if (request.method==='POST' && p==='/v1/admin/asset/upload') return await adminAssetUpload(request,env);
      if (request.method==='POST' && p==='/v1/admin/store/asset/upload') return await adminStoreAssetUpload(request,env);
      if (request.method==='POST' && p==='/v1/admin/store/grant') return await adminStoreGrant(request,env);
      if (request.method==='POST' && p==='/v1/admin/store/revoke') return await adminStoreRevoke(request,env);
      if (request.method==='POST' && p==='/v1/admin/store/membership/revoke') return await adminMembershipRevoke(request,env);
      if (request.method==='GET' && p==='/v1/admin/store/purchase-requests') return await adminStorePurchaseRequests(request,env);
      if (request.method==='POST' && p==='/v1/admin/store/purchase-decision') return await adminStorePurchaseDecision(request,env);
      if (request.method==='POST' && p==='/v1/admin/store/reconcile-holds') return await adminStoreReconcileHolds(request,env);
      if (request.method==='GET' && p==='/v1/wallet/profile') return await walletProfile(request,env);
      if (request.method==='POST' && p==='/v1/wallet/purchase-request') return await walletPurchaseRequest(request,env);
      if(request.method==='GET'&&p==='/v1/users/verification')return await userVerification(request,env);
      if(request.method==='POST'&&p==='/v1/admin/user-verification')return await userVerification(request,env);
      if(request.method==='GET'&&p==='/v1/app/presence')return await appPresenceRead(request,env);
      if((request.method==='GET'||request.method==='POST')&&p==='/v1/admin/overlay-placements')return await overlayPlacements(request,env);
      if(p==='/v1/wallet/withdraw-options'||p==='/v1/admin/withdraw-catalog')return await withdrawCatalog(request,env,{getUser,json,cors,financeConfig});
      if(p==='/v1/me/bank-account')return await bankAccount(request,env,{getUser,json,cors});
      if(p==='/v1/profile-menu'||p==='/v1/admin/profile-menu')return await profileMenu(request,env,{getUser,json,cors});
      if(p==='/v1/admin/draft-review')return await draftReview(request,env,{getUser,json,cors});
      if(p==='/v1/appearance'||p==='/v1/admin/appearance-grant')return await appearanceDesign(request,env,{getUser,json,cors});
      if(p==='/v1/visual-design'||p==='/v1/admin/visual-design')return await visualDesign(request,env,{getUser,json,cors});
      if((request.method==='GET'&&p==='/v1/panel-design')||(request.method==='POST'&&p==='/v1/admin/panel-design'))return await panelDesign(request,env);
      if(request.method==='GET'&&p==='/v1/mini-ads')return await miniAdsRead(request,env);
      if(request.method==='POST'&&p==='/v1/admin/mini-ads')return await miniAdsSave(request,env);
      if(request.method==='POST'&&p==='/v1/mini-ads/event')return await miniAdEvent(request,env);
      if(request.method==='GET'&&p==='/v1/headline-strip')return await headlineStripRead(request,env);
      if(request.method==='POST'&&p==='/v1/admin/headline-strip')return await headlineStripSave(request,env);
      if (request.method==='POST' && p==='/v1/wallet/withdraw-request') return await goldWithdrawRequest(request,env);
      if (request.method==='POST' && p==='/v1/wallet/coin-withdraw-request') return await coinWithdrawRequest(request,env);
      if (request.method==='GET' && p==='/v1/wallet/owned-items') return await myOwnedItems(request,env);
      if (request.method==='POST' && p==='/v1/wallet/owned-items/equip') return await equipOwnedItem(request,env);
      if (request.method==='GET' && p==='/v1/admin/wallet/preview') return await adminWalletPreview(request,env);
      if (request.method==='POST' && p==='/v1/admin/wallet/grant') return await adminWalletGrant(request,env);
      if (request.method==='POST' && p==='/v1/admin/official-notice') return await adminOfficialNotice(request,env,ctx);
      if (request.method==='GET' && p==='/v1/admin/official-notices') return await adminOfficialNoticeList(request,env);
      if (request.method==='GET' && p==='/v1/help/tickets') return await helpTickets(request,env);
      if (request.method==='POST' && p==='/v1/help/ticket') return await helpTicketCreate(request,env);
      if (request.method==='GET' && p==='/v1/help/ticket') return await helpTicketThread(request,env);
      if (request.method==='POST' && p==='/v1/help/ticket/reply') return await helpTicketReply(request,env);
      if (request.method==='GET' && p==='/v1/admin/help/tickets') return await adminHelpTickets(request,env);
      if (request.method==='POST' && p==='/v1/admin/help/ticket/reply') return await adminHelpReply(request,env);
      if (request.method==='POST' && p==='/v1/admin/help/ticket/status') return await adminHelpStatus(request,env);
      if (request.method==='GET' && p==='/v1/notifications') { try { await ensureSchemasOnce(env); } catch (_) {} return await notificationsList(request,env); }
      if (request.method==='POST' && p==='/v1/notifications/read') { try { await ensureSchemasOnce(env); } catch (_) {} return await notificationReadOne(request,env); }
      if (request.method==='POST' && p==='/v1/notifications/read-all') { try { await ensureSchemasOnce(env); } catch (_) {} return await notificationsReadAll(request,env); }
      if (request.method==='GET' && p==='/health/content-write-suite') return await contentWriteSuite(request,env);
      if (request.method==='GET' && p==='/v1/admin/system/health') return await adminSystemHealth(request,env);
      if (request.method==='GET' && p==='/v1/admin/permissions') return await adminPermissions(request,env);
      if (request.method==='PUT' && p==='/v1/admin/dashboard/config') return await adminDashboardPut(request,env);
      if(p==='/v1/admin/features/history')return await featureHistory(request,env,{adminOnly,getUser,json,cors});
      if (request.method==='PUT' && p==='/v1/admin/content') return await adminContentPut(request,env);
      if (request.method==='GET' && p==='/v1/admin/media') return await adminMediaList(request,env);
      if (request.method==='POST' && p==='/v1/admin/media/upload') return await adminMediaUpload(request,env);
      if (request.method==='GET' && p==='/v1/admin/ads') return await adminAdsList(request,env);
      if (request.method==='POST' && p==='/v1/admin/ad/upload') return await adminAdUpload(request,env);
      if (request.method==='PUT' && p==='/v1/admin/ad/update') return await adminAdUpdate(request,env);
      if (request.method==='POST' && p==='/v1/admin/ad/delete') return await adminAdDelete(request,env);
      if (request.method==='GET' && p==='/v1/admin/live-home/banners') return await adminLiveHomeBanners(request,env);
      if ((request.method==='GET'||request.method==='PUT') && p==='/v1/admin/banner-section') return await adminBannerSection(request,env);
      if (request.method==='POST' && p==='/v1/admin/banner/upload') return await adminBannerUpload(request,env);
      if (request.method==='POST' && p==='/v1/admin/banner/delete') return await adminBannerDelete(request,env);
      if (request.method==='PUT' && p==='/v1/admin/banner/update') return await adminBannerUpdate(request,env);
      if (request.method==='PUT' && p==='/v1/admin/media/update') return await adminMediaUpdate(request,env);
      if (request.method==='POST' && p==='/v1/admin/media/delete') return await adminMediaDelete(request,env);
      if (request.method==='GET' && p.startsWith('/v1/media/')) return await mediaGet(request,env,decodeURIComponent(p.slice('/v1/media/'.length)));
      if (request.method==='POST' && p==='/v1/admin/actions') return await adminAction(request,env);
      return json({error:'NOT_FOUND'},404,cors);
    } catch (e) {
      return json({error:'SERVER_ERROR',message:String(e?.message||e)},500,cors);
    }
  }
};
