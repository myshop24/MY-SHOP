package com.myshop.app;
import android.content.Context;
import android.graphics.*;
import android.view.View;
/** Small stable emblem with moving jewel-light; no translation of text/portrait. */
public final class MembershipEmblemView extends View {
 private static Bitmap atlas;private final int index;private final boolean animate;
 private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
 public MembershipEmblemView(Context c,String tier){super(c);String[] tiers={"KING","QUEEN","ROYAL","VVIP","VIP"};int found=0;for(int i=0;i<tiers.length;i++)if(tiers[i].equals(tier))found=i;index=found;
 animate=!c.getSharedPreferences("myshop_accessibility",Context.MODE_PRIVATE).getBoolean("reduce_animation",false);
 if(atlas==null)try(java.io.InputStream in=c.getAssets().open("membership_v603/emblems.webp")){atlas=BitmapFactory.decodeStream(in);}catch(Exception ignored){}
 setContentDescription(tier+" animated emblem");
 }
 @Override protected void onDraw(Canvas c){super.onDraw(c);if(atlas==null)return;
 int w=atlas.getWidth()/5;Rect src=new Rect(index*w,Math.round(atlas.getHeight()*70f/682f),(index+1)*w,Math.round(atlas.getHeight()*570f/682f));
 float side=Math.min(getWidth(),getHeight());RectF dst=new RectF((getWidth()-side)/2,(getHeight()-side)/2,(getWidth()+side)/2,(getHeight()+side)/2);
 p.setShader(null);c.drawBitmap(atlas,src,dst,p);
 if(animate&&isShown()){float phase=(android.os.SystemClock.uptimeMillis()%2400)/2400f;int save=c.saveLayer(dst,null);c.drawBitmap(atlas,src,dst,p);
 p.setShader(new LinearGradient(dst.left+side*(phase*1.6f-.5f),dst.top,dst.left+side*(phase*1.6f-.3f),dst.bottom,new int[]{0x00FFFFFF,0x88FFFFFF,0x00FFFFFF},null,Shader.TileMode.CLAMP));
 p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));c.drawRect(dst,p);p.setXfermode(null);p.setShader(null);c.restoreToCount(save);
 p.setColor(Color.WHITE);p.setAlpha((int)(120+100*Math.sin(phase*Math.PI)));float x=dst.left+side*.52f,y=dst.top+side*.36f;c.drawLine(x-2,y,x+2,y,p);c.drawLine(x,y-2,x,y+2,p);p.setAlpha(255);postInvalidateOnAnimation();}
 }
}
