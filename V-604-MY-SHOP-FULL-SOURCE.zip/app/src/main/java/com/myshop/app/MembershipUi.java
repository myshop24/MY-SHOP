package com.myshop.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import java.util.Locale;

/** Shared identity contract for Shop, Admin, Profile and Live. */
public final class MembershipUi {
    private MembershipUi(){}
    public static String tier(String raw){String c=raw==null?"":raw.trim().toUpperCase(Locale.US);if(c.startsWith("MS430_"))c=c.substring(6);return isTier(c)?c:"";}
    public static boolean isTier(String c){return "KING".equals(c)||"QUEEN".equals(c)||"ROYAL".equals(c)||"VVIP".equals(c)||"VIP".equals(c);}
    public static boolean hasFrame(String c){return "TOP1".equals(c)||isTier(tier(c));}
    public static int accent(String c){switch(c){case "TOP1":return 0xFFFFDC66;case "KING":return 0xFF79C8FF;case "QUEEN":return 0xFFD99CFF;case "ROYAL":return 0xFF81E2A4;case "VVIP":return 0xFFFFAE35;default:return 0xFF9ABEFF;}}
    public static android.graphics.drawable.Drawable commentBackground(Context c,String tier){
        int ac=accent(tier);int[] colors;
        switch(tier){case "TOP1":colors=new int[]{0xFF07394D,0xFF22647A,0xFF40311B};break;
            case "KING":colors=new int[]{0xFF071E52,0xFF082F79,0xFF081737};break;
            case "QUEEN":colors=new int[]{0xFF44155B,0xFF7C3474,0xFF371148};break;
            case "ROYAL":colors=new int[]{0xFF042D22,0xFF073F2C,0xFF041E19};break;
            case "VVIP":colors=new int[]{0xFF722313,0xFF402219,0xFF8B4B16};break;
            default:colors=new int[]{0xFF211032,0xFF32164B,0xFF26103B};}
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);
        bg.setCornerRadius(dp(c,8));bg.setStroke(dp(c,2),ac);return new MembershipCommentDrawable(bg,c,tier,ac);
    }
    public static View comment(Context c,String tier,String name,String url){
        return comment(c,tier,name,url,"");
    }
    public static View comment(Context c,String tier,String name,String url,String frameUrl){
        int ac=accent(tier);LinearLayout row=new LinearLayout(c);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(c,3),dp(c,3),dp(c,3),dp(c,3));
        row.setBackground(commentBackground(c,tier));
        MembershipIdentityView icon=new MembershipIdentityView(c,tier,url);icon.setFrameAsset(frameUrl);if("Demo User".equals(name))icon.setDemo();row.addView(icon,new LinearLayout.LayoutParams(dp(c,35),dp(c,35)));
        LinearLayout text=new LinearLayout(c);text.setOrientation(LinearLayout.VERTICAL);TextView n=new TextView(c);n.setText((name==null||name.isEmpty()?"Your name":name)+" • "+tier);n.setTextColor(ac);n.setTextSize(8.5f);n.setTypeface(null,Typeface.BOLD);n.setSingleLine(true);text.addView(n);TextView body=new TextView(c);body.setText("Welcome to MY SHOP ❤️");body.setTextColor(Color.WHITE);body.setTextSize(8);body.setMaxLines(2);text.addView(body);row.addView(text,new LinearLayout.LayoutParams(0,-2,1));row.addView(new MembershipEmblemView(c,tier),new LinearLayout.LayoutParams(dp(c,25),dp(c,30)));return row;
    }
    /** Preserve the original avatar, click listeners and container. Removal is reversible. */
    public static void attach(ImageView avatar,String code,String url){attach(avatar,code,url,"");}
    public static void attach(ImageView avatar,String code,String url,String frameUrl){
        attach(avatar,code,url,frameUrl,"");
    }
    public static void attach(ImageView avatar,String code,String url,String frameUrl,String expiry){
        if(avatar==null||!(avatar.getParent() instanceof FrameLayout))return;FrameLayout parent=(FrameLayout)avatar.getParent();String tag="membership430:"+System.identityHashCode(avatar);View old=parent.findViewWithTag(tag);
        if(old instanceof MembershipIdentityView&&((MembershipIdentityView)old).matches(code,url,frameUrl)){
            MembershipIdentityView existing=(MembershipIdentityView)old;existing.setExpiry(expiry,()->{avatar.setAlpha(1f);parent.removeView(existing);});return;
        }
        if(old!=null)parent.removeView(old);
        String tier=tier(code);if(tier.isEmpty()){avatar.setAlpha(1f);return;}MembershipIdentityView view=new MembershipIdentityView(avatar.getContext(),tier,url);view.setFrameAsset(frameUrl);view.setTag(tag);view.setClickable(false);view.setFocusable(false);parent.addView(view,parent.indexOfChild(avatar)+1,new FrameLayout.LayoutParams((FrameLayout.LayoutParams)avatar.getLayoutParams()));avatar.setAlpha(0f);
        view.setExpiry(expiry,()->{avatar.setAlpha(1f);parent.removeView(view);});
    }
    private static int dp(Context c,int v){return Math.round(v*c.getResources().getDisplayMetrics().density);}
}
