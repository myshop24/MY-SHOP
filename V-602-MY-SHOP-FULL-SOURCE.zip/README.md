# MY SHOP V602 / 2.9.602

Complete compact source; start with AGENTS.md and the developer policy/instructions.
Read MY-SHOP-DEVELOPER-HANDOFF.md, handoffs/MY-SHOP-V601-HANDOFF.md and BUILD-ASSETS-BN.md.
Upload/build: UPLOAD-INSTRUCTIONS-BN.md. All inputs/scripts are included; no older ZIP needed.

Generated GIF/WAV/runtime duplicate assets are restored byte-for-byte before build.
Lossless images retain every original RGBA pixel. Local/fresh-extract source/backend
checks passed; Android compile/signed APK and real-device Live/UI are not verified.
No new V601 APK or production deployment is included. Original package, signing,
user IDs, economy and bindings are preserved. Next newly created delivery: V602.
