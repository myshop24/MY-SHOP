# V-62 verification checklist

1. Exactly one Android APK is produced by the workflow.
2. No checksum/non-APK file is uploaded as the APK artifact.
3. Main dashboard has no vertical ScrollView and no horizontal LIVE NOW ScrollView.
4. Six LIVE/advertisement slots are visible in a compact 3x2 grid.
5. Dashboard language switch: বাংলা / English.
6. Login language switch: বাংলা / English.
7. Existing applicationId remains `com.myshop.app`.
8. Account preference namespace remains `myshop_accounts_v2`; Admin content namespace remains `myshop_admin_content_v60` to avoid deliberate reset.
9. Admin management supports Add/Upload, Edit and Delete in the local store and retains Admin session role after approved admin login.
10. V-59/V-60/V-61 packages are not overwritten by this package.

Build caveat: this environment cannot download the Gradle wrapper/distributions because external network resolution is unavailable. GitHub Actions must perform the final compile/install verification.
