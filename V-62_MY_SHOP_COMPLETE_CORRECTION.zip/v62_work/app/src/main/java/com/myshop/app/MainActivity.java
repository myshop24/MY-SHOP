package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** MY SHOP V-62 — compact fixed dashboard. */
public class MainActivity extends AppCompatActivity {
    private static final int BG=Color.rgb(248,249,252), TEXT=Color.rgb(25,31,45);
    private static final int BLUE=Color.rgb(29,82,225), PURPLE=Color.rgb(98,36,225), RED=Color.rgb(235,35,55), ORANGE=Color.rgb(245,92,18);
    private static final int MAX_BANNERS=6; private static final long SLIDE_MS=3500L;
    private final Handler handler=new Handler(); private int bannerIndex=0;
    private final ImageView[] bannerImages=new ImageView[3];
    private final int[] topLeft={R.drawable.banner_top_left_1,R.drawable.banner_top_left_2,R.drawable.banner_top_left_3,R.drawable.banner_top_left_4,R.drawable.banner_top_left_5,R.drawable.banner_top_left_6};
    private final int[] topRight={R.drawable.banner_top_right_1,R.drawable.banner_top_right_2,R.drawable.banner_top_right_3,R.drawable.banner_top_right_4,R.drawable.banner_top_right_5,R.drawable.banner_top_right_6};
    private final int[] wide={R.drawable.banner_wide_1,R.drawable.banner_wide_2,R.drawable.banner_wide_3,R.drawable.banner_wide_4,R.drawable.banner_wide_5,R.drawable.banner_wide_6};
    private int activeLiveCount=0;
    private final String[] liveNames={"Cute Girl Live","Music Live","Gaming Live","Talk & Fun","Dance Live","Comedy Live"};
    private final int[] liveColors={0xFFEC417E,0xFF0E4896,0xFF122341,0xFF1576BE,0xFF652155,0xFF23233C};

    @Override protected void onCreate(Bundle b){super.onCreate(b); try{setContentView(buildDashboard());startCarousel();}catch(Throwable t){setContentView(buildSafeHome());}}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}

    private View buildDashboard(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        LinearLayout content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(10),dp(4),dp(10),0);
        final int screenWidth=getResources().getDisplayMetrics().widthPixels;

        // Header: compact enough to stay fixed on common mobile widths.
        LinearLayout header=row();
        ImageView avatar=new ImageView(this); avatar.setImageResource(R.drawable.myshop_profile_avatar); avatar.setScaleType(ImageView.ScaleType.CENTER_CROP); avatar.setBackground(round(Color.WHITE,0xFFDCE0E8,dp(26))); avatar.setClipToOutline(true); header.addView(avatar,lp(dp(42),dp(42)));
        LinearLayout user=new LinearLayout(this); user.setOrientation(LinearLayout.VERTICAL); user.setGravity(Gravity.CENTER_VERTICAL);
        String id=SessionManager.getUserId(this); String name=getSharedPreferences("myshop_session",MODE_PRIVATE).getString("full_name",""); if(name.trim().isEmpty())name=SessionManager.isAdmin(this)?"Admin":"My Shop User";
        user.addView(text("Hi, "+name+" 👋",TEXT,13,true)); user.addView(text("ID: "+(id.isEmpty()?"Guest":id)+(SessionManager.isLoggedIn(this)?"  ✓":""),BLUE,11,true)); header.addView(user,weight(0.82f,dp(44)));
        EditText search=new EditText(this); search.setSingleLine(true); search.setHint(LanguageManager.t(this,"search")); search.setTextSize(11); search.setPadding(dp(9),0,dp(5),0); search.setBackground(round(Color.WHITE,0xFFDCE0E8,dp(22))); header.addView(search,weight(1.75f,dp(40)));
        TextView bell=pill("🔔 12",RED,Color.WHITE); header.addView(bell,lp(dp(46),dp(40)));
        Button menu=plainButton("☰",TEXT,23); header.addView(menu,lp(dp(40),dp(40)));
        menu.setOnClickListener(v->startActivity(new Intent(this,SessionManager.isAdmin(this)?AdminManagementActivity.class:AccountActivity.class)));
        content.addView(header,lp(-1,dp(45)));

        // Language switch is always visible on the dashboard.
        LinearLayout lang=row(); lang.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        Button bn=plainButton("বাংলা",LanguageManager.BN.equals(LanguageManager.get(this))?BLUE:TEXT,10); Button en=plainButton("English",LanguageManager.EN.equals(LanguageManager.get(this))?BLUE:TEXT,10);
        bn.setOnClickListener(v->{LanguageManager.set(this,LanguageManager.BN);recreate();}); en.setOnClickListener(v->{LanguageManager.set(this,LanguageManager.EN);recreate();});
        lang.addView(bn,lp(dp(62),dp(28))); lang.addView(en,lp(dp(62),dp(28))); content.addView(lang,lp(-1,dp(30)));

        int sideH=Math.max(dp(64),Math.round((screenWidth-dp(26))*0.53f/2f));
        LinearLayout top=row(); bannerImages[0]=bannerImage(topLeft[0]); bannerImages[1]=bannerImage(topRight[0]);
        top.addView(bannerImages[0],weight(1,sideH)); top.addView(space(),lp(dp(5),1)); top.addView(bannerImages[1],weight(1,sideH)); content.addView(top,lp(-1,sideH));
        TextView dots=text("●  ○  ○  ○  ○  ○",PURPLE,9,true); dots.setGravity(Gravity.CENTER); content.addView(dots,lp(-1,dp(16)));
        int wideH=Math.max(dp(44),Math.round((screenWidth-dp(20))*0.1894f)); bannerImages[2]=bannerImage(wide[0]); content.addView(bannerImages[2],lp(-1,wideH));

        LinearLayout br=row(); br.setBackground(round(Color.WHITE,0xFFE1E4EB,dp(12))); TextView bt=text("🔴  "+LanguageManager.t(this,"breaking")+"  |  বাংলাদেশে আজ স্বর্ণের দাম কিছুটা কমেছে...",TEXT,10,true); br.addView(bt,weight(1,dp(38))); br.addView(text(LanguageManager.t(this,"seeAll"),BLUE,10,true),lp(dp(50),dp(38))); content.addView(br,lp(-1,dp(40)));

        LinearLayout lh=row(); lh.addView(text("🔴  "+LanguageManager.t(this,"liveNow"),TEXT,12,true),weight(1,dp(28))); lh.addView(text(LanguageManager.t(this,"seeAll"),BLUE,10,true),lp(dp(50),dp(28))); content.addView(lh,lp(-1,dp(30)));
        // No horizontal ScrollView: all six live slots are visible as a compact 3x2 grid.
        GridLayout grid=new GridLayout(this); grid.setColumnCount(3); grid.setRowCount(2); grid.setUseDefaultMargins(false);
        int gap=dp(4); int cardW=Math.max(dp(88),(screenWidth-dp(20)-gap*2)/3); int cardH=dp(68);
        for(int i=0;i<6;i++){TextView c=i<activeLiveCount?liveCard(i):advertisementCard(i); GridLayout.LayoutParams gp=new GridLayout.LayoutParams(); gp.width=cardW;gp.height=cardH;gp.setMargins(i%3==0?0:gap,i/3==0?0:gap,0,0);grid.addView(c,gp);} content.addView(grid,lp(-1,dp(140)));

        LinearLayout approved=row(); approved.addView(featureImage(R.drawable.feature_my_feed_selected,LanguageManager.t(this,"feed"),"my_feed"),weight(1,dp(52))); approved.addView(space(),lp(dp(5),1)); approved.addView(featureImage(R.drawable.feature_my_shop_selected,LanguageManager.t(this,"shop"),"my_shop"),weight(1,dp(52))); content.addView(approved,lp(-1,dp(56)));

        // Compact lower controls; no vertical scrolling.
        LinearLayout lower=row(); LinearLayout left=new LinearLayout(this);left.setOrientation(LinearLayout.VERTICAL);LinearLayout right=new LinearLayout(this);right.setOrientation(LinearLayout.VERTICAL);
        addSmallImage(left,R.drawable.feature_gallery_selected,LanguageManager.t(this,"gallery"),"gallery"); addSmallImage(left,R.drawable.feature_live_tv_selected,LanguageManager.t(this,"tv"),"live_tv");
        addSmallImage(right,R.drawable.feature_external_selected,LanguageManager.t(this,"movie"),"external_movie"); addSmallImage(right,R.drawable.feature_social_selected,LanguageManager.t(this,"social"),"social_media");
        lower.addView(left,weight(1,dp(96))); lower.addView(goLiveImage(),lp(dp(104),dp(96))); lower.addView(right,weight(1,dp(96))); content.addView(lower,lp(-1,dp(100)));

        root.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=row();nav.setPadding(dp(3),dp(2),dp(3),dp(2));nav.setBackground(round(Color.WHITE,0xFFE1E4EB,dp(20)));
        Button home=navButton("⌂\n"+LanguageManager.t(this,"home"),BLUE),store=navButton("🛒\n"+LanguageManager.t(this,"store"),TEXT),live=navButton("◉\n"+LanguageManager.t(this,"live"),TEXT),chat=navButton("💬\n"+LanguageManager.t(this,"chat"),TEXT),more=navButton("▦\n"+LanguageManager.t(this,"more"),TEXT);
        nav.addView(home,weight(1,dp(46)));nav.addView(store,weight(1,dp(46)));nav.addView(live,weight(1,dp(46)));nav.addView(chat,weight(1,dp(46)));nav.addView(more,weight(1,dp(46)));root.addView(nav,lp(-1,dp(52)));
        store.setOnClickListener(v->openFeature(LanguageManager.t(this,"shop"),"my_shop"));live.setOnClickListener(v->openFeature(LanguageManager.t(this,"live"),"live_now"));chat.setOnClickListener(v->openFeature(LanguageManager.t(this,"chat"),"chat"));more.setOnClickListener(v->startActivity(new Intent(this,AccountActivity.class)));
        // Keep content centered without ScrollView. If the device is very short, Android clips rather than creating the broken scroll behavior.
        return root;
    }

    private TextView advertisementCard(int i){TextView v=card("ADVERTISEMENT\nAd Slot "+(i+1)+"\n"+LanguageManager.t(this,"menu"),Color.WHITE,ORANGE,8);v.setGravity(Gravity.CENTER);v.setOnClickListener(x->openFeature("ADVERTISEMENT "+(i+1),"advertisement"));return v;}
    private TextView liveCard(int i){TextView v=card("LIVE  "+liveNames[i]+"\nID: 10"+(i+1)+" ✓\nWATCH NOW",Color.WHITE,liveColors[i],8);v.setGravity(Gravity.CENTER);v.setOnClickListener(x->openFeature(liveNames[i],"live_room"));return v;}
    private void addSmallImage(LinearLayout p,int res,String desc,String key){ImageView v=featureImage(res,desc,key);v.setScaleType(ImageView.ScaleType.CENTER_CROP);LinearLayout.LayoutParams q=lp(-1,dp(45));q.bottomMargin=dp(3);p.addView(v,q);}
    private ImageView goLiveImage(){ImageView v=featureImage(R.drawable.feature_go_live_selected,LanguageManager.t(this,"goLive"),"go_live");v.setScaleType(ImageView.ScaleType.CENTER_INSIDE);return v;}
    private ImageView featureImage(int res,String desc,String key){ImageView v=new ImageView(this);v.setImageResource(res);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(round(Color.WHITE,0xFFE1E4EB,dp(10)));v.setClipToOutline(true);v.setContentDescription(desc);v.setOnClickListener(x->openFeature(desc,key));return v;}
    private Button navButton(String label,int color){return plainButton(label,color,9);}
    private Button plainButton(String label,int color,float size){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setGravity(Gravity.CENTER);b.setTextColor(color);b.setTextSize(size);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setMinHeight(0);b.setMinimumHeight(0);b.setPadding(0,0,0,0);b.setBackground(round(Color.WHITE,0xFFE0E3EB,dp(10)));return b;}
    private ImageView bannerImage(int res){ImageView v=new ImageView(this);v.setImageResource(res);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(round(Color.WHITE,0xFFE1E4EB,dp(10)));v.setClipToOutline(true);return v;}
    private TextView card(String s,int bg,int fg,float size){TextView v=text(s,fg,size,true);v.setGravity(Gravity.CENTER);v.setPadding(dp(3),dp(2),dp(3),dp(2));v.setBackground(round(bg,0xFFE1E4EB,dp(9)));return v;}
    private TextView pill(String s,int bg,int fg){TextView v=text(s,fg,9,true);v.setGravity(Gravity.CENTER);v.setBackground(round(bg,bg,dp(18)));return v;}
    private TextView text(String s,int c,float z,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextColor(c);v.setTextSize(z);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private View space(){return new View(this);}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(radius);g.setStroke(dp(1),stroke);return g;}
    private void startCarousel(){handler.postDelayed(new Runnable(){public void run(){bannerIndex=(bannerIndex+1)%MAX_BANNERS;bannerImages[0].setImageResource(topLeft[bannerIndex]);bannerImages[1].setImageResource(topRight[bannerIndex]);bannerImages[2].setImageResource(wide[bannerIndex]);handler.postDelayed(this,SLIDE_MS);}},SLIDE_MS);}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
    private void openFeature(String t,String k){try{Intent i=new Intent(this,FeatureActivity.class);i.putExtra("title",t);i.putExtra("feature_key",k);startActivity(i);}catch(Throwable x){Toast.makeText(this,t,Toast.LENGTH_SHORT).show();}}
    private View buildSafeHome(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setGravity(Gravity.CENTER);TextView t=text("MY SHOP + LIVE",PURPLE,24,true);t.setGravity(Gravity.CENTER);r.addView(t,lp(-1,-2));return r;}
}
