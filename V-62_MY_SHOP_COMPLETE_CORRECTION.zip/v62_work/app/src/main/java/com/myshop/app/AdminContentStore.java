package com.myshop.app;

import android.content.Context;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Local admin content store used by the V-60 management UI.
 * It preserves content by stable item id and never changes user/profile IDs.
 * A future backend adapter can mirror these records without changing the UI contract.
 */
public final class AdminContentStore {
    private static final String PREF = "myshop_admin_content_v60"; // keep stable across V-60+ updates
    private AdminContentStore() {}

    public static final class Item {
        public final String id, type, title, value;
        public Item(String id, String type, String title, String value) {
            this.id=id; this.type=type; this.title=title; this.value=value;
        }
    }

    public static List<Item> list(Context c, String type) {
        ArrayList<Item> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(PREF,0).getString(type,"[]"));
            for (int i=0;i<a.length();i++) {
                JSONObject o=a.getJSONObject(i);
                out.add(new Item(o.optString("id"),type,o.optString("title"),o.optString("value")));
            }
        } catch(Exception ignored) {}
        return out;
    }

    public static Item add(Context c, String type, String title, String value) {
        String id = UUID.randomUUID().toString();
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(PREF,0).getString(type,"[]"));
            JSONObject o=new JSONObject(); o.put("id",id); o.put("title",title); o.put("value",value); a.put(o);
            c.getSharedPreferences(PREF,0).edit().putString(type,a.toString()).apply();
        } catch(Exception ignored) {}
        return new Item(id,type,title,value);
    }


    public static boolean update(Context c, String type, String id, String title, String value) {
        try {
            JSONArray a=new JSONArray(c.getSharedPreferences(PREF,0).getString(type,"[]"));
            for(int i=0;i<a.length();i++){ JSONObject o=a.getJSONObject(i); if(id.equals(o.optString("id"))){o.put("title",title==null?"":title);o.put("value",value==null?"":value);c.getSharedPreferences(PREF,0).edit().putString(type,a.toString()).commit();return true;} }
        } catch(Exception ignored) {}
        return false;
    }

    public static boolean delete(Context c, String type, String id) {
        try {
            JSONArray old=new JSONArray(c.getSharedPreferences(PREF,0).getString(type,"[]"));
            JSONArray next=new JSONArray(); boolean removed=false;
            for(int i=0;i<old.length();i++) { JSONObject o=old.getJSONObject(i); if(id.equals(o.optString("id"))) {removed=true;} else next.put(o); }
            c.getSharedPreferences(PREF,0).edit().putString(type,next.toString()).apply();
            return removed;
        } catch(Exception e) { return false; }
    }

    public static boolean canUse(Context c) { return SessionManager.isAdmin(c); }
}
