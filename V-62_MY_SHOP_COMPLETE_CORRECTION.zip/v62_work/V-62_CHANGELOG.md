# MY SHOP V-62 — Dashboard / ID / Admin / Language correction

- Removed the broken vertical ScrollView from the main dashboard.
- Removed the broken horizontal LIVE NOW ScrollView; six slots are rendered in a compact 3x2 grid so the dashboard does not require horizontal scrolling.
- Added always-visible বাংলা / English switching on the dashboard and login screen.
- Login text/hints/buttons now follow the selected language.
- Preserved the existing applicationId and account preference keys so in-place updates do not intentionally reset local account records.
- Admin role is retained on the account record after an approved admin login and the Admin Management screen remains protected by session role.
- Admin content store keeps the V-60 preference namespace and now supports Add/Upload, Edit and Delete.
- Media picker now requests persistable read permission.
- Build output is constrained to exactly one APK; no checksum file is placed in the APK artifact directory.
- Previous V-59/V-60/V-61 source packages are not overwritten.

Important production note: server-generated immutable User IDs and server-side Admin authorization remain backend responsibilities under the preserved MY SHOP contracts. This client must not be represented as a substitute for the production backend.
