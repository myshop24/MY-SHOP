from pathlib import Path
import json, re
root=Path(__file__).resolve().parents[1]
assert 'MY-SHOP-V59-SOURCE-ROOT-BUILD-LOCK' in (root/'SOURCE_BUILD_ID.txt').read_text()
build=(root/"app/build.gradle").read_text()
assert "applicationId 'com.myshop.app'" in build
assert re.search(r"versionCode\s+\d+", build)
assert re.search(r"versionName\s+'2\.9\.\d+'", build)
assert re.search(r"versionCode\s+59", build), 'V-59 source version missing'
main=(root/'app/src/main/java/com/myshop/app/MainActivity.java').read_text()
login=(root/'app/src/main/java/com/myshop/app/LoginActivity.java').read_text()
reg=(root/'app/src/main/java/com/myshop/app/RegisterActivity.java').read_text()
uid=(root/'app/src/main/java/com/myshop/app/UserIdManager.java').read_text()
admin=(root/'app/src/main/java/com/myshop/app/AdminIdentifiers.java').read_text()
inv=json.loads((root/'app/src/main/assets/final_feature_inventory.json').read_text())
assert 'MAX_BANNERS_PER_FOLDER = 6' in main
for p in ['banner_top_left','banner_top_right','banner_wide']:
    files=sorted((root/'app/src/main/res/drawable').glob(p+'_*.png'))
    assert len(files)==6,(p,len(files))
assert 'Email অথবা Mobile' in reg
assert 'No OTP' in (root/'app/src/main/res/layout/activity_login.xml').read_text()
assert 'FIRST_ID = 100' in uid and '%04d' in uid
for ident in ['myshopsatkania@gmail.com','touhidsatkania@gmail.com','01860626700']:
    assert ident in admin
assert 'six_moderators' not in inv['features'], 'Old six-moderator contract remains'
assert 'five_moderators' in inv['features'], 'Five-moderator contract missing'
print('V-58 source structural validation PASSED')
