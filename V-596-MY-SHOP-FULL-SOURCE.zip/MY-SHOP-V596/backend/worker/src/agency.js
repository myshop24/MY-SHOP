// Six-slot agencies, explicit mutual enrollment, no Live/admin authority.
const ready=new WeakMap();
export const agencySchema=[
`CREATE TABLE IF NOT EXISTS myshop_agencies(slot INTEGER PRIMARY KEY CHECK(slot BETWEEN 1 AND 6),agent_id TEXT NOT NULL UNIQUE,name TEXT NOT NULL,photo TEXT NOT NULL DEFAULT '',whatsapp TEXT NOT NULL DEFAULT '',rules TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,revision INTEGER NOT NULL DEFAULT 1)`,
`CREATE TABLE IF NOT EXISTS myshop_agency_requests(id INTEGER PRIMARY KEY AUTOINCREMENT,slot INTEGER NOT NULL,host_id TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('JOIN','INVITE')),message TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
`CREATE UNIQUE INDEX IF NOT EXISTS agency_pending ON myshop_agency_requests(slot,host_id) WHERE status='PENDING'`,
`CREATE TABLE IF NOT EXISTS myshop_agency_members(host_id TEXT PRIMARY KEY,slot INTEGER NOT NULL,joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
`CREATE INDEX IF NOT EXISTS agency_members_slot ON myshop_agency_members(slot,host_id)`,
`CREATE TABLE IF NOT EXISTS myshop_agency_share(slot INTEGER NOT NULL,currency TEXT NOT NULL,feature TEXT NOT NULL,percent REAL NOT NULL CHECK(percent BETWEEN 0 AND 100),PRIMARY KEY(slot,currency,feature))`,
`CREATE TABLE IF NOT EXISTS myshop_agency_income(ledger_id INTEGER PRIMARY KEY,slot INTEGER NOT NULL,agent_id TEXT NOT NULL,host_id TEXT NOT NULL,currency TEXT NOT NULL,feature TEXT NOT NULL,commission INTEGER NOT NULL,share_percent REAL NOT NULL,amount INTEGER NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
`CREATE INDEX IF NOT EXISTS agency_income_agent ON myshop_agency_income(agent_id,ledger_id)`,
`CREATE TABLE IF NOT EXISTS myshop_agency_audit(id INTEGER PRIMARY KEY AUTOINCREMENT,actor_id TEXT NOT NULL,action TEXT NOT NULL,slot INTEGER NOT NULL,host_id TEXT NOT NULL DEFAULT '',reason TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`];
export async function ensureAgency(DB){let p=ready.get(DB);if(!p){p=DB.batch(agencySchema.map(q=>DB.prepare(q))).catch(e=>{ready.delete(DB);throw e;});ready.set(DB,p);}await p;}
export async function agencyApi(request,env,h){
 const me=await h.getUser(request,env);if(!me)return h.json({error:'UNAUTHORIZED'},401,h.cors);
 const DB=env.DB,uid=String(me.user_id),admin=['0001','0002','0003'].includes(uid);await ensureAgency(DB);
 const send=(x,s=200)=>h.json(x,s,{...h.cors,'cache-control':'no-store'});
 const own=await DB.prepare('SELECT slot FROM myshop_agencies WHERE agent_id=? AND active=1').bind(uid).first();
 if(request.method==='GET'){
 const slot=Number(new URL(request.url).searchParams.get('slot')||0);
 const agencies=await DB.prepare(`SELECT a.*,u.full_name agentName,u.avatar_url agentAvatar,(SELECT COUNT(*) FROM myshop_agency_members m WHERE m.slot=a.slot) hostCount FROM myshop_agencies a JOIN myshop_auth_users_v108 u ON u.user_id=a.agent_id AND u.active=1 ${admin?'':'WHERE a.active=1'} ORDER BY a.slot`).all();
 const requests=await DB.prepare(`SELECT r.*,u.full_name hostName,u.avatar_url hostAvatar FROM myshop_agency_requests r JOIN myshop_auth_users_v108 u ON u.user_id=r.host_id WHERE r.host_id=? OR r.slot=? ${admin?'OR 1=1':''} ORDER BY r.id DESC LIMIT 100`).bind(uid,own?.slot||0).all();
 const membership=await DB.prepare('SELECT m.*,a.name,a.agent_id FROM myshop_agency_members m JOIN myshop_agencies a ON a.slot=m.slot WHERE m.host_id=?').bind(uid).first();
 const hosts=slot&&agencies.results.some(a=>a.slot===slot)?(await DB.prepare('SELECT m.host_id userId,u.full_name name,u.avatar_url avatarUrl,m.joined_at FROM myshop_agency_members m JOIN myshop_auth_users_v108 u ON u.user_id=m.host_id AND u.active=1 WHERE m.slot=? ORDER BY m.joined_at DESC LIMIT 100').bind(slot).all()).results:[];
 const reportSlot=admin?slot:Number(own?.slot||0);const income=reportSlot?(await DB.prepare('SELECT * FROM myshop_agency_income WHERE slot=? AND (?=1 OR agent_id=?) ORDER BY ledger_id DESC LIMIT 100').bind(reportSlot,admin?1:0,uid).all()).results:[];const shares=reportSlot?(await DB.prepare('SELECT * FROM myshop_agency_share WHERE slot=?').bind(reportSlot).all()).results:[];
 return send({ok:true,income,shares,admin,agentSlot:own?.slot||0,agencies:agencies.results,requests:requests.results,membership,hosts});
 }
 if(request.method!=='POST')return send({error:'METHOD_NOT_ALLOWED'},405);
 const b=await request.json().catch(()=>null);if(!b)return send({error:'INVALID_REQUEST'},400);
 const action=String(b.action||''),slot=Number(b.slot),reason=String(b.reason||'').trim().slice(0,500);
 const audit=(a,host='')=>DB.prepare('INSERT INTO myshop_agency_audit(actor_id,action,slot,host_id,reason) VALUES(?,?,?,?,?)').bind(uid,a,slot,host,reason);
 if(action==='SAVE'){
 if(!admin)return send({error:'OWNER_ONLY'},403);
 const id=String(b.agentId||''),name=String(b.name||'').trim().slice(0,60),photo=String(b.photo||'').trim(),whatsapp=String(b.whatsapp||'').trim(),rules=String(b.rules||'').trim().slice(0,2000);
 if(!Number.isInteger(slot)||slot<1||slot>6||!/^\d{4}$/.test(id)||!name||photo&&!/^https:\/\//.test(photo)||whatsapp&&!/^https:\/\/wa\.me\/\d{7,15}$/.test(whatsapp))return send({error:'INVALID_AGENCY'},400);
 if(!await DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(id).first())return send({error:'USER_NOT_FOUND'},404);
 if(await DB.prepare('SELECT slot FROM myshop_agencies WHERE agent_id=? AND slot<>?').bind(id,slot).first())return send({error:'AGENT_ALREADY_APPOINTED'},409);
 const old=await DB.prepare('SELECT revision FROM myshop_agencies WHERE slot=?').bind(slot).first();if(Number(b.revision||0)!==Number(old?.revision||0))return send({error:'REVISION_CONFLICT'},409);
 const write=old?DB.prepare('UPDATE myshop_agencies SET agent_id=?,name=?,photo=?,whatsapp=?,rules=?,active=?,revision=revision+1 WHERE slot=? AND revision=?').bind(id,name,photo,whatsapp,rules,b.active===false?0:1,slot,b.revision):DB.prepare('INSERT OR IGNORE INTO myshop_agencies(slot,agent_id,name,photo,whatsapp,rules,active) VALUES(?,?,?,?,?,?,?)').bind(slot,id,name,photo,whatsapp,rules,b.active===false?0:1);
 const r=await DB.batch([write,DB.prepare('INSERT INTO myshop_agency_audit(actor_id,action,slot,reason) SELECT ?,?,?,? WHERE changes()=1').bind(uid,'SAVE',slot,reason)]);return send({ok:Number(r[0].meta.changes)===1},Number(r[0].meta.changes)?200:409);
 }
 const a=await DB.prepare('SELECT * FROM myshop_agencies WHERE slot=? AND active=1').bind(slot).first();if(!a)return send({error:'AGENCY_NOT_ACTIVE'},409);
 const agent=uid===a.agent_id;
 if(action==='SHARES'){
 if(!admin)return send({error:'OWNER_ONLY'},403);
 const values=b.shares;if(!Array.isArray(values)||values.length!==6)return send({error:'INVALID_SHARES'},400);
 const seen=new Set();for(const x of values){const k=x.currency+':'+x.feature;if(!['COIN','GOLD'].includes(x.currency)||!['GIFT','TRANSFER','WITHDRAW'].includes(x.feature)||seen.has(k)||typeof x.percent!=='number'||!Number.isFinite(x.percent)||x.percent<0||x.percent>100)return send({error:'INVALID_SHARES'},400);seen.add(k);}
 await DB.batch([...values.map(x=>DB.prepare('INSERT INTO myshop_agency_share(slot,currency,feature,percent) VALUES(?,?,?,?) ON CONFLICT(slot,currency,feature) DO UPDATE SET percent=excluded.percent').bind(slot,x.currency,x.feature,x.percent)),audit('SHARES',JSON.stringify(values))]);return send({ok:true});
 }
 if(action==='JOIN'||action==='INVITE'){
 const host=action==='JOIN'?uid:String(b.hostId||'');if(action==='INVITE'&&!agent&&!admin)return send({error:'AGENT_ONLY'},403);
 if(host===a.agent_id||!/^\d{4}$/.test(host))return send({error:'INVALID_HOST'},400);
 if(!await DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(host).first())return send({error:'USER_NOT_FOUND'},404);
 const r=await DB.batch([DB.prepare(`INSERT OR IGNORE INTO myshop_agency_requests(slot,host_id,kind,message) SELECT ?,?,?,? WHERE NOT EXISTS(SELECT 1 FROM myshop_agency_members WHERE host_id=?)`).bind(slot,host,action==='JOIN'?'JOIN':'INVITE',String(b.message||'').slice(0,500),host),DB.prepare('INSERT INTO myshop_agency_audit(actor_id,action,slot,host_id) SELECT ?,?,?,? WHERE changes()=1').bind(uid,action,slot,host)]);return send({ok:true,created:Number(r[0].meta.changes)===1});
 }
 if(action==='REMOVE'||action==='LEAVE'){
 const host=action==='LEAVE'?uid:String(b.hostId||'');if(action==='REMOVE'&&!agent&&!admin)return send({error:'AGENT_ONLY'},403);if(!reason)return send({error:'REASON_REQUIRED'},400);
 await DB.batch([DB.prepare('DELETE FROM myshop_agency_members WHERE host_id=? AND slot=?').bind(host,slot),DB.prepare('INSERT INTO myshop_agency_audit(actor_id,action,slot,host_id,reason) SELECT ?,?,?,?,? WHERE changes()=1').bind(uid,action,slot,host,reason)]);return send({ok:true});
 }
 if(!['ACCEPT','REJECT','CANCEL'].includes(action)||!Number.isSafeInteger(Number(b.requestId))||Number(b.requestId)<1)return send({error:'INVALID_ACTION_OR_REQUEST'},400);
 const r=await DB.prepare("SELECT * FROM myshop_agency_requests WHERE id=? AND slot=? AND status='PENDING'").bind(Number(b.requestId),slot).first();if(!r)return send({error:'REQUEST_NOT_PENDING'},409);
 const canDecide=r.kind==='JOIN'?agent||admin:uid===r.host_id;
 if(action==='ACCEPT'){
 if(!canDecide)return send({error:'FORBIDDEN'},403);
 const accepted=await DB.batch([DB.prepare(`INSERT OR IGNORE INTO myshop_agency_members(host_id,slot) SELECT ?,? WHERE EXISTS(SELECT 1 FROM myshop_agency_requests WHERE id=? AND status='PENDING') AND EXISTS(SELECT 1 FROM myshop_agencies WHERE slot=? AND active=1 AND (agent_id=? OR ?=1 OR ?=?))`).bind(r.host_id,slot,r.id,slot,uid,admin?1:0,r.kind,uid===r.host_id?'INVITE':''),DB.prepare("UPDATE myshop_agency_requests SET status='ACCEPTED',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='PENDING' AND EXISTS(SELECT 1 FROM myshop_agency_members WHERE host_id=? AND slot=?)").bind(r.id,r.host_id,slot),DB.prepare("INSERT INTO myshop_agency_audit(actor_id,action,slot,host_id) SELECT ?,'ACCEPT',?,? WHERE changes()=1").bind(uid,slot,r.host_id),DB.prepare("UPDATE myshop_agency_requests SET status='CANCELLED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND status='PENDING' AND changes()=1").bind(r.host_id)]);return Number(accepted[0].meta.changes)?send({ok:true}):send({error:'HOST_ALREADY_ENROLLED_OR_PERMISSION_CHANGED'},409);
 }
 if(action==='REJECT'||action==='CANCEL'){
 if(action==='REJECT'?!canDecide:!(r.kind==='JOIN'?uid===r.host_id:agent||admin))return send({error:'FORBIDDEN'},403);
 await DB.batch([DB.prepare("UPDATE myshop_agency_requests SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='PENDING'").bind(action==='REJECT'?'REJECTED':'CANCELLED',r.id),DB.prepare('INSERT INTO myshop_agency_audit(actor_id,action,slot,host_id) SELECT ?,?,?,? WHERE changes()=1').bind(uid,action,slot,r.host_id)]);return send({ok:true});
 }
 return send({error:'UNKNOWN_ACTION'},400);
}

// One immutable share per completed transaction; paid from the platform commission.
const financeReady=new WeakMap();
export async function ensureAgencyFinance(DB){let p=financeReady.get(DB);if(!p){p=(async()=>{await ensureAgency(DB);await DB.batch([
DB.prepare(`CREATE TRIGGER IF NOT EXISTS agency_income_credit AFTER INSERT ON myshop_agency_income BEGIN
 UPDATE myshop_value_ledger SET platform_amount=platform_amount-NEW.amount WHERE id=NEW.ledger_id;
 INSERT INTO myshop_coin_wallets(user_id,balance) SELECT NEW.agent_id,NEW.amount WHERE NEW.currency='COIN' ON CONFLICT(user_id) DO UPDATE SET balance=balance+excluded.balance;
 INSERT INTO myshop_gold_wallets(user_id,balance) SELECT NEW.agent_id,NEW.amount WHERE NEW.currency='GOLD' ON CONFLICT(user_id) DO UPDATE SET balance=balance+excluded.balance;
 INSERT INTO myshop_creator_earnings(user_id,currency,balance) VALUES(NEW.agent_id,NEW.currency,NEW.amount) ON CONFLICT(user_id,currency) DO UPDATE SET balance=balance+excluded.balance;
 END`),
DB.prepare(`CREATE TRIGGER IF NOT EXISTS agency_ledger_share AFTER INSERT ON myshop_value_ledger WHEN NEW.status='COMPLETED' AND NEW.fee_amount>0 AND NEW.tx_type IN ('GIFT','TRANSFER','CREATOR_WITHDRAW_PAID') BEGIN
 INSERT OR IGNORE INTO myshop_agency_income(ledger_id,slot,agent_id,host_id,currency,feature,commission,share_percent,amount)
 SELECT NEW.id,a.slot,a.agent_id,m.host_id,NEW.currency,s.feature,NEW.fee_amount,s.percent,CAST(NEW.fee_amount*s.percent/100 AS INTEGER)
 FROM myshop_agency_members m JOIN myshop_agencies a ON a.slot=m.slot AND a.active=1 JOIN myshop_auth_users_v108 u ON u.user_id=a.agent_id AND u.active=1
 JOIN myshop_agency_share s ON s.slot=a.slot AND s.currency=NEW.currency AND s.feature=CASE NEW.tx_type WHEN 'CREATOR_WITHDRAW_PAID' THEN 'WITHDRAW' ELSE NEW.tx_type END
 WHERE m.host_id=CASE WHEN NEW.tx_type='CREATOR_WITHDRAW_PAID' THEN NEW.sender_id ELSE NEW.receiver_id END AND s.percent>0 AND CAST(NEW.fee_amount*s.percent/100 AS INTEGER)>0;
 END`)]);})().catch(e=>{financeReady.delete(DB);throw e;});financeReady.set(DB,p);}await p;}
