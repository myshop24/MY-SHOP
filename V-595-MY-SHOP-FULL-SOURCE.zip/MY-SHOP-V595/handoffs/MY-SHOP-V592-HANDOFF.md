# MY SHOP V-590 — requested full-source development checkpoint

VersionCode 590; versionName 2.9.590; SOURCE_BUILD_ID MY SHOP V-590. Last delivered V589; next file delivery V591. Resume this exact source, do not restart from earlier files. No production deployment performed. No APK included: Android SDK/Gradle/device tools unavailable. Local source/resource/Java fixture/Worker SQLite suite passed; this is not a full Android compilation or runtime acceptance.

Read AGENTS.md, mandatory developer rules and V590-ACTIVE-WORK.md before work. Owner-approved scoped Live override removes a selected block/forced mute with owner authorization, confirmation/reason, atomic permanent audit and retry identity. It preserves user mic_on and other hosts; existing audio/RTC and host endpoints unchanged. Live retained history now paged, full stored duration totals available. Device room refresh/audio/rejoin still needs checking.

Implemented checkpoint scope: eligible per-event launcher badge metadata without replacing existing device/in-app push; obsolete Live TV admin-folder removal; four non-Live navigation spacing and flat blue headline icons; bounded wallet/feed loading; selected text style controls in existing scopes; canonical Home feature editor/custom coming-soon/permanent slot deletion; withdrawal amount plus additional commission and immutable snapshots; latest30 wallet summaries with retained ledgers and actual recipient/net/total values; red main-user panel/contact safeguards; owner four-digit new-user Special ID reservation with verified Google claim and immutable existing IDs. See active-work notes and current test log for exact boundaries.

This is an incomplete development checkpoint requested by the owner, not a finished release. The owner-facing remaining-work list is provided in chat. Existing signing/package/backend configuration retained. Do not run production deployment merely to verify this checkpoint.

Tests: bash tools/v590_verify.sh. Evidence: verification/V590-working-verification.log. Historical V587 handoff preserved separately; current notes supersede earlier incomplete status for specific newly implemented controls.

# APK build checkpoint — 2026-10-09

This is working continuation from delivered V-590, not a completed V-591 release.

Completed and tested: consolidated developer policy saved; manual build-only workflow; source selector accepts canonical V-prefixed archives and both MY-SHOP-V590/V-590-FULL-SOURCE formats; ambiguous newest sources rejected; existing identity is verified without rewriting it; V590 regression tests added to APK CI. Exact shipped source-selector tests, shell syntax and tools/v590_verify.sh passed locally.

APK procedure: extract the complete source into repository root INCLUDING .github/workflows/my-shop-apk.yml, replacing the previous release pipeline. Uploading only a ZIP does not install the workflow inside it. Open Actions → MY SHOP Android APK → Run workflow. Preserve original signing secrets/cache and Firebase credentials. This workflow does not deploy the Worker or publish a release. It tests, builds and verifies one signed APK against original certificate and source version, then uploads an APK artifact. Missing credentials or build failures must be resolved from actual logs.

Unverified: Android compilation/device acceptance, original signing access and successful signed APK. No production changes performed. Source identity remains V-590 until actual V-591 delivery preparation; do not label an old APK as V-591.

Remaining implementation: full Moderator assignment/edit/removal and per-action permissions; all 104 controls on every applicable item; general cross-page drag/drop with persistent position; text/style editor coverage across all app elements; real device notification count/lock-screen regression; live RTC/audio/gift/moderation acceptance. Existing scoped implementations and previous handoff are retained, not certified as complete.

Next checkpoint: install reviewed build-only workflow at GitHub root and obtain actual signed APK build logs; continue remaining items serially. Keep original working Live and notification systems protected.

## Continuation checkpoint 2026-10-09 — V591 candidate
# V591 working checkpoint — 2026-10-09

Continued from delivered V590; candidate source identity MY SHOP V-591 / versionName 2.9.591 / versionCode 591. NOT a completed release. No signed V591 APK, Android compilation, device acceptance or production deployment.

Implemented this checkpoint: owner-only moderator directory and mobile management entry, user ID lookup, confirmed existing audited assignment/removal, actual folder-name picker and existing revision-checked folder grants. Full moderator per-action presets/ACL remain pending. Legacy moderators without a registry may require reassignment to repair that registry before removal; do not claim this edge is finished.

Shared Color Wheel now used by AdminSection color inputs. General menu has stable visual-editor targets; icon/emoji image dimensions 28–56dp can be saved/published through existing protected design workflow, image centering and default restoration retained. Font labels can wrap. Non-image targets reject icon resizing. Existing Live scopes remain excluded.

Verification: tools/v590_verify.sh PASS; 200 Java sources parsed and callback checks PASS, NOT Android type checking. Actual SQLite moderator-directory and icon-style tests PASS. Exact shipped dimension fragment compiled/executed with UI doubles, including image-only sizing. V561/V566/V570 worker fixtures PASS after updating dependencies and explicit Draft/Publish expectation. ZIP source-selector tests and CI shell syntax PASS. See verification/V591-* logs.

Build blocker: GitHub isolated build branch creation rejected with HTTP 403 Resource not accessible by integration. No GitHub write succeeded. Original signing key is not available locally; SDK/Gradle are not installed. Reviewed build-only workflow and exact-source reconstruction patch are in the checkpoint auxiliary ci-build-review folder. Original production pipeline must not be rerun: it deploys Worker before APK build.

Remaining serial work: 1 full moderator per-action controls/presets and legacy registry handling; 2 applicable 104 controls throughout; 3 persistent arbitrary cross-page drag/drop; 4 editor coverage for remaining app elements; 5 signed APK and real launcher badge/lockscreen regression; 6 real-device Live RTC/audio/gift acceptance. Scoped prior implementations are preserved, not certified as entirely completed.

Next step: obtain authorized isolated GitHub build-only execution, validate exact source/signature/versions, then continue remaining items. No old APK may be relabelled as V591. Preserve original Live and device/in-app notification delivery.

## V-592 delivery — upload compatibility correction
Complete source continued from V591; feature scope unchanged. Identity V592, Android 2.9.592/versionCode592. Canonical V-592-MY-SHOP-FULL-SOURCE.zip matches existing main workflow push V-*.zip and numeric source selector. Upload ZIP to repository root unchanged. Existing release pipeline deploys included Worker then builds/signs APK with original secrets/cache. Embedded manual workflow is not installed by ZIP upload. No remote Android build/sign/device acceptance performed. APK not included. All previously pending implementation remains pending.
