# MY SHOP V-594
Full V593 continuation; prior checkpoint: handoffs/MY-SHOP-V593-HANDOFF.md. Package/signing/assets/Live unchanged. VersionCode594, versionName2.9.594, SOURCE_BUILD_ID MY SHOP V-594.

Scope: writing-field colors for profile name/ID, new text/media status, edited caption, headline and feature labels. Reuses original color wheel/editor: selected text, solid/gradient, background and private preview. ID remains immutable. Profile/caption Save publishes colors; a partial color failure is shown with retry. Headline/features retain explicit Draft/Publish. Only active owners or scoped grants may edit; published styles render publicly. Live excluded.

Optional appearance travels with new text/media posts. post-appearance.js validates source/ranges and rechecks grants inside an atomic D1 batch saving post, published style and audit. Failures roll back. Plain quotas, media checks and notifications retained exactly.

PASS: V594 SQLite atomic publication, revocation, audit rollback, validation, exact plain-feed preservation; V593 targeted checks; V590 retained regression (345 PASS). CI runs V594 through v593_verify.sh. V575 scoped exceptions add feedText/feedUpload only; baseline tests separately enforce their plain behavior. V594WritingColorsTest Robolectric included, NOT run locally. Android full compile/APK/device QA NOT performed: dependencies, SDK/signing unavailable. No production deployment.

Upload the full ZIP through the existing GitHub pipeline; deploy its Worker alongside APK. Keep original repository signing secrets/Firebase. Never relabel an old APK. All V593 files retained; ZIP below 25,000,000 bytes. Continue from this source; verify actual APK colors on a phone before release.
