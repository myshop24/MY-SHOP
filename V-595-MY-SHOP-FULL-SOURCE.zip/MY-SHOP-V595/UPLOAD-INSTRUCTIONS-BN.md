# V-593 GitHub আপলোড ও বিল্ড

১. V-593-MY-SHOP-FULL-SOURCE.zip নাম অপরিবর্তিত রেখে আপনার আগের MY-SHOP repository-এর মূল জায়গায় Upload ও Commit করুন। এটি পূর্ণ সোর্স; শুধু patch নয়।
২. আগের installed MY SHOP PERMANENT RELEASE PIPELINE সর্বশেষ V-*.zip নির্বাচন করে Worker deploy ও APK build করে—আগের handoff-এ এই আচরণ লেখা আছে। ওই রান সত্যি V593 নিয়েছে কি না লগে দেখুন। Pages success APK build নয়।
৩. আগের signing key/cache/secrets, Firebase ও Cloudflare সেটিংস রাখুন। ZIP-এর ভেতরের workflow শুধু ZIP আপলোডে repository-তে install হয় না। Included manual build-only workflow ব্যবহার করতে পুরো project (লুকানো .github সহ) root-এ extract/install করুন; সেটি Worker deploy করে না। নতুন endpoint কার্যকর করতে matching Worker deployment প্রয়োজন।
৪. Android signed build সফল হলে সেই exact রান থেকে একটি MY_SHOP_FINAL_RELEASE.apk নিন। versionCode593 / versionName2.9.593 / SOURCE_BUILD_ID MY SHOP V-593 ও আগের certificate যাচাই করুন। manual workflow artifact: MY-SHOP-V-593-APK; existing permanent workflow-এর artifact নাম installed workflow অনুযায়ী হবে।
৫. এই source ZIP-এ নতুন APK নেই: স্থানীয় Gradle download/SDK/original signing key বাধায় এখানে signed build করা যায়নি। পুরোনো V592 APK নতুন নামে দেওয়া হয়নি। SOURCE ZIP২৫,০০০,০০০ bytes-এর নিচে; ভবিষ্যৎ APK সাইজ build হলে আলাদাভাবে মাপতে হবে।

ব্যবহার: Admin Users → ID খুঁজুন → রঙ দিন / রঙ করার অনুমতি দিন বা তুলে নিন। Feature editor → সাধারণ SAVE → saved Draft Preview → Publish নিশ্চিত করুন; আলাদা SAVE PRIVATE DRAFT ইউজারের কাছে পরিবর্তন দেখায় না। রঙ editor-এ Draft Save → Preview → Publish। মূল নাম/স্ট্যাটাস/হেডলাইন আগের editor-এ লিখুন; রঙ editor-এ তার অংশ বেছে সাজান।
