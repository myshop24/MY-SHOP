# MY SHOP — Mandatory Developer Entry Point

Read `DEVELOPER-POLICY-BN.md` and `MY-SHOP-DEVELOPER-INSTRUCTIONS.md` BEFORE inspecting implementation, editing, building or producing a delivery. Read `V575-APPROVED-WORK-BN.md` for current scope and `MY-SHOP-DEVELOPER-HANDOFF.md` for the last verified checkpoint. The latest owner instruction overrides historical notes. Never infer completion from a requirement document or an old log.

**LIVE IS A CRITICAL / HIGH-RISK ZONE.** Before changing Live Streaming code, design, audio, realtime, or its related backend, explain the exact proposed change and impact to the owner, discuss it and obtain explicit owner approval. This includes shared helpers, bug fixes, optimization, deletion and styling that would alter Live. Read-only inspection/testing is allowed. Continue independent non-Live work while a Live decision is pending.

Keep unrelated approved modules locked. Make scoped changes, preserve data/signing/package identity and run target plus regression verification. Never publish, deploy, overwrite an old version or claim a real-device test that was not performed.
