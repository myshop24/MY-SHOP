from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent;o=r/'V542-SOURCE-SHA256.json'
f={p.relative_to(r).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(r.rglob('*')) if p.is_file() and p!=o and not any(x in {'build','.gradle','node_modules','__pycache__'} for x in p.relative_to(r).parts)}
o.write_text(json.dumps({'build':'V-542','algorithm':'SHA-256','files':f},indent=2)+'\n')
