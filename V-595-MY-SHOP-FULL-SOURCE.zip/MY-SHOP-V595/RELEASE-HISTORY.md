## V-543
Nine scoped visual/theme corrections. 20 Theme Admin presets with draft/preview/publish/reset, authoritative feed levels. Source/local checks only; phone/signing/push limits documented.

# V-542 source delivery

Complete V-541 base; local verification and remaining device/configuration blockers in V542-VERIFICATION.md. No production deployment or signed APK acceptance claimed. Next V-543.

## V-438 — 2026-09-19 — Gallery, paired links and premium management
- Implements the 12 current conversation requirements at source level.
- Clean Android Debug/unsigned Release builds and lint pass; 91 backend behavior checks pass.
- Device acceptance, real push delivery, release signing and deployment remain pending.
- Implementation commit a31c48e00c0d71f13f264f127e8e7c8d93abd603. See the V-438 handoff for details.

## V-435 — Full-source recovery and release identity alignment
- Base: V-433 full Android/Page 2 correction source from Library.
- Preserved the matching Backend Worker and all V-433 functional changes.
- Added one coherent release identity across source, Android and Worker: V-435 / 2.9.435 / versionCode 435.
- Corrects the V-434 backend-only package failure; clean CI, signed APK and device regression remain pending.

## V-396 — One-APK Root Pipeline Packaging Fix
- User-facing GitHub artifact contains only `MY_SHOP_FINAL_RELEASE.apk`; verification metadata stays internal.
- V-395 Home/Page2/Admin implementation preserved; protected Live/Wallet files unchanged.

## V-395 — Home Page 1 + Page 2 Admin/Visual Reference Implementation
- See V-395_RELEASE_NOTES.md and MY-SHOP-DEVELOPER-HANDOFF.md.

# V-392 — Live Realtime / Audio / Gift Reliability Fix
- Cross-client seat/join state recovery hardened and fallback sync accelerated.
- Agora publisher/playback role recovery fixed, including invite-accept audience→speaker promotion.
- Join action visibility improved; successful speaker joins are announced to every refreshed client.
- Host End Summary displays immediately from authoritative `/live/end` response.
- Gift realtime revision + D1 recovery added to prevent sender-only effects.
- Live Name/Caption made atomic at session start and preferred in live discovery display.
- Identity advanced to 392 / 2.9.392.

# V-391 — Compile Hotfix
- Full source carried forward from V-390.
- Fixed missing `android.view.ViewGroup` import in `AudioLiveRoomActivity.java`.
- Advanced release identity to 391 / 2.9.391.
- No functional redesign.

# MY SHOP RELEASE HISTORY — RECOVERY INDEX

## V-537 — 2026-10-01 — Source implementation and pending device QA
- Base: V-536 source archive; identity advanced consistently to V-537 / 2.9.537 / versionCode 537.
- Implements locked menu, Messenger, push, VAT, recovery, History, Live Room, Social Links, banner/scroll, profile and optional Personal Details corrections; see `V-537-CHANGES-BN.md` and `MY-SHOP-V537-REQUIREMENTS-CHECKLIST-BN.md`.
- Local Node regression: 43 passed. XML/manifest/resource static checks and workflow/release-shell syntax checks pass.
- Android build, device reference review, actual FCM delivery, production D1 validation and two-device RTC/audio remain pending; not published or deployed.
- The final V-537 ZIP is withheld until the locked release checks are satisfied.

- V-327: Premium Gift Admin Catalog baseline; source used for V-328.
- V-328: Premium Experience + Stability Foundation. Shared PremiumUi, Live Hub/Room polish, gap-free live-comment acknowledgement, Feature/Chat/Inbox polish, existing FCM notification presentation refinement, Master State recovery system added.

Rule: Never delete this file. Append each future V-number with scope, base version, key modified modules, regression status and rollback source.

## V-330
Coin & Gold Coin Catalog admin completion pass: navigation disambiguation, full Gift Studio lock/preservation, separate COIN/GOLD finance summary, version 2.9.330. Runtime acceptance pending CI/device.

## V-352
Base V-351. Live stabilization pass: D1 full-room polling reduced from sub-second to 12-second reconciliation; temporary Live comments/highlights and gift delivery use a per-room Durable Object realtime hub; join/invite/seat/moderation mutations trigger lightweight dirty signals; additive D1 read indexes added; repeated Agora publish/mic reconfiguration suppressed. Approved V-350/V-351 Live UI and unrelated working modules locked. Runtime Cloud + two-device acceptance pending.
## V-353
Base V-352. Audio-only recovery pass: restored Agora live voice playback/publish application after V-352 idempotency regression; remote audio/speaker route kept active; gift sounds switched to MEDIA/MUSIC playback and no longer steal transient audio focus from RTC. V-352 D1/realtime/comment work and unrelated modules locked. Runtime two-device acceptance pending.


## V-390
Base V-389. Screen-match correction pass: Quick Links clipping/overlay protection; transparent parent strip behind the approved five-color bottom navigation on Home + Live Home; Love React removed from comment rendering; Host End Summary premature-finish bug removed; Inbox accessible from active Live; Live Streaming Home top header aligned to Main Home profile/language/notification/message structure; GitHub final install artifact staged as one APK only. Host top-viewer Call/Invite and production Worker URL/retry behavior preserved. Static source checks PASS; CI/device/production runtime acceptance pending.

## V-405 — Premium Catalog Products + Admin Approval
- User/Admin catalog product cards now visibly populated.
- Approved KING/QUEEN/ROYAL/VVIP/VIP membership previews bundled with matching comment-box visual.
- 50 wallpapers + 30 entry animations visible; Admin controls final assets/prices/duration.
- Admin purchase request approval added; Coin/Gold deduct only after approval.
- Wallpaper drag/drop order persistence added.
- Live-only premium application preserved; My Feed unchanged.

V-406: Live premium profile-fit + visible catalog lock. Premium effects remain Live-only; My Feed untouched.

## V-412 — Premium Gold Safety + Grid Catalog
- Gold Coin-only Premium purchase enforcement.
- Compact visual grid catalog.
- Safe Hold → Approve/Reject flow and Premium Revenue ledger.
- Stuck/Held Gold Admin review.
- White + Red Premium Admin shell and double-confirm Admin Grant.
- Static V-412 guard 37/37 PASS; runtime verification pending.

- V-421: Dedicated Entry / Ride Animation light user GRID + separate Admin route, animation/video + sound controls, Live join Ride playback; regression-scoped.
## V-442 — Live lifecycle reliability

- Atomic audience leave clears viewer, speaker seat, pending request and pending invite.
- Fresh rejoin resets comment visibility and permits a new call request.
- Comment/request activity repairs delayed viewer presence for Host visibility.
- Realtime delivery failures no longer appear as locally successful comments.
- Each Live session receives an isolated Agora channel; speaker promotion renews publisher privileges.
- Clean Debug/Release/lint build plus targeted lifecycle and SQLite transition checks passed.
## V-443 — Live request controls and latency

- Join/Requested control enlarged and made more readable.
- Pending Join Request can be cancelled without leaving Live.
- Host request list receives realtime cancellation state.
- Authoritative room fallback refresh reduced from 1.8 seconds to 1 second.

## V-444 — Premium Live Room visual system

- Continuous dark navy/purple glass styling across comments and the bottom dock.
- Custom 3D eye, Coin, Gold, Vote and Love statistics replace visible system emoji.
- Empty seats retain the approved dark fill, soft gold glow and white chair artwork.
- Layered center stage: MS logo when empty; stable guest profile with transparent gold animation when occupied.
- Main-stage animations are cancelled on detach to prevent long-session animation buildup.
- Subtle membership-accent comment surfaces and custom Mic/Gift/Love controls.
- Debug APK, unsigned Release APK, lint, unit-test task and V-444 identity checks passed.

## V-445 — GitHub-compatible premium Live delivery

- Carries forward the verified V-444 premium Live Room implementation under a new, unique release identity.
- Provides a workflow-compatible `V-*.zip` delivery below the strict 25,000,000-byte upload limit.
- Preserves Live lifecycle, realtime comments, request cancellation, RTC audio and all premium visual behavior.

## V-447 — Live 5+5 final alignment

- Normal guest seats locked to 5+5 = 10; Host and Main Guest separate.
- Host-only Music moved to right rail; Mic directly below it. Guest/Audience have no empty Music slot.
- Audience Mic control mutes/unmutes Live playback; Host/Speaker Mic controls outgoing voice.
- Bottom composer is comment → Send → Message → Join/Leave/End with duplicate Mic/Music removed.
- Worker JS syntax PASS; local backend regression 37 PASS. Android compile/runtime NOT VERIFIED locally (Gradle executable/wrapper JAR unavailable).

## V-449 — Final Dashboard UI Alignment

- Base V-448. Replaced the six-button/two-row Dashboard action area with exactly five compact one-row premium actions: GAMES, PREMIUM SHOP, LIVE STREAMING, WATCH HISTORY, AGENT.
- Added small left-side icon art per action and single-line no-scroll layout.
- Removed LIVE HUB and GENERAL from the Dashboard top action area.
- Changed the large MY SHOP Dashboard portal to open the full physical store while keeping Premium Shop routed to the existing premium catalog.
- Preserved existing Feed, Quick Links, Bottom Navigation, Live/RTC, permanent IDs and backend targets.
- Android compile/runtime and production deployment remain pending local/CI/device validation.


## V-512
- Exact CI compile errors from the latest V-511 runner were corrected without overwriting historical V-511 files.
- Release identity: V-512 / 2.9.512 / versionCode 512.
- Full Android build remains a required CI verification step.

- V-521: Home reference fidelity + Live Page 2 realtime/premium update + feed like/reply enhancements.
- V-522: V-521 regression correction pack — Home 3-line/menu polish, compact headline-to-menu spacing, subtle EN control, composer Photo/Video/Post alignment, single post overflow menu, unclipped/pulsing Live icon, Page 2 All/Following/New/Explore row, realtime LIVE_NOW list, smooth looping peek-carousel banners on Home 1 + Page 2, Page 2 six-slot admin banner path, and approved premium Start Live modal.

- V-523: Post-V-522 Live Room locked-reference + reliability pack — exact Main Guest MS artwork, 8-seat 4+4 default, locked right/bottom control order, universal top-right ❌ exit/end, accepted Live Admin invitations, Admin call-suggestion Host approval, privileged auto-seat, 100 Love React/session cap, seat cooldown, join expiry, gift animation queue, explicit Top 1/2/3 Summary labels, Page 2 premium row/no-live corrections; static/backend/local tests PASS.

- V-524: Build-repair release based on V-523. Fixed GitHub `:app:mergeReleaseResources` / AAPT failure caused by `live_main_guest_logo.png` containing JPEG/JFIF bytes. Exact artwork preserved byte-for-byte as `live_main_guest_logo.jpg`; Android resource name remains `R.drawable.live_main_guest_logo`. Release identity advanced to 2.9.524 / versionCode 524; V-523 locked features preserved.
- V-527: Build-repair release based on V-526. Removed invalid extension-less Android drawable test file that crashed `verifyMyShopResourceReferences`; hardened verifier against future extension-less resource files; release identity advanced to 2.9.527 / versionCode 527 while preserving V-526 functionality.

## V-531 / 2.9.531
P0 notification/presence hardening, direct feature routing, faster Live discovery, full-width Home/Live headers, Page-2 banner authority/cache fix, History chrome fix. See V-531-CHANGES-BN.md.

## V-534
- Locked auth redesign + official myshop branding/icon.
- Main Admin account recovery, Support/Agent WhatsApp slots, premium icon restoration, notification/presence preservation, permanent friend download flow.
- See V-534-CHANGES-BN.md.

## V-535
- Fixed release AAPT resource compile failure caused by JPEG/JFIF bytes stored as `drawable/myshop_icon.png`.
- Re-encoded icon as valid PNG while preserving 1536x1536 visual content.
- Added PNG signature regression guard to master verifier.
- Added `LIVE-ROOM-AUDIT-V535-BN.md` with source-grounded Live Room findings; no risky Live Room rewrite in this build-fix release.

## V-536
- Numbered correction batch: #1 splash brand, #2 registration email, #3 More Apps stable navigation, #9 Main Admin recovery expansion.


## V-537 source handoff clarification
Owner explicitly requested the file now. Deliver the complete V-537 source ZIP below 25,000,000 bytes with Android build, real-device push and RTC acceptance still pending. This does not authorize production deployment or public APK publication. Subsequent delivered changes must use the next sequential version.


## V-541
- Matched Page 2 More Apps to Page 1 Quick Links while leaving peer navigation artwork intact; isolated Page 2 banners to `live_home`, cleared empty-cache state, and advanced the carousel through configured slots left-to-right.
- Fixed legacy inbox-presence migration/visibility checks and added an Active Now row; only active, visible, fresh heartbeats show green.
- Highlight comments now use the one Admin-set coin amount without stacking global VAT; FCM send results no longer report success when every token fails.
- Added V-541 SQLite regression coverage for presence, highlight charging, FCM error paths, and self-like behavior. Debug/release builds and release lint pass; real FCM remains unverified because client/server secrets and device are unavailable in this environment.

## V-544
- Reworked the Live room lower row to Comment/Game/Mic/More and the right rail to Love/Vote/Gift/Join; separate comment composer keeps Rocket and Send out of the main dashboard. Removed external waveform teeth from the animated main guest ring; host header now uses Level/Follow and a compact five-avatar/+99 viewer line.
- Added S1–S10 Sun palettes, L11 Pure White, visual no-code light/dark custom color selection, published custom color persistence, and 12-second foreground refresh for user-visible screens. Existing Moon set and fixed blue header remain.
- Worker behavior suite 63/63 passes and Worker syntax passes. Android build, phone/Agora QA, production Worker deployment and signing were not available in this environment.

## V-545
- Preserved V-544 app behavior and advanced the Android/Worker release identity to 2.9.545 / versionCode 545.
- Updated the Android APK workflow to select both V-numbered ZIP names and the repository's `MY-SHOP-V545-SOURCE.zip` naming, and added V544 Worker tests before APK assembly.
- APK artifact requires the GitHub Android workflow; no APK, production Worker deployment, or device acceptance is claimed in this source handoff.

## V-546
- Fixed the Java compiler error in AppThemeAdminActivity: Color.colorToHSV requires a float[] HSV output buffer, not int[].
- Advanced versionCode/versionName and Worker health to 546 / 2.9.546.
- APK is pending a successful GitHub Actions build of this corrected source; no local APK was produced.

## V-547
- Based on the verified V-546 source archive; advanced Android/Worker identity to V-547 / 2.9.547.
- Refined Live Room header, metrics, right-side labels, fixed two-tone Join animation, main guest mark/border, compact comment composer, More controls, mic mute mark, summary actions and long host-name ticker.
- Corrected Agora local speaker indicator to follow the documented local UID (`0`); remote speaker matching remains UID based.
- Changed authorized Room Admin/global Admin/Moderator calls to send direct viewer invitations; added a SQLite-backed test for direct invite and viewer acceptance.
- Worker and regression test suites passed. Android APK build, device RTC/notification test and production Worker deployment remain unverified; see `V547-VERIFICATION.md`.

## V-548
- Fixed source ZIP naming compatibility with the existing APK pipeline.
- Release selector accepts both V-numbered ZIP naming formats; rejects duplicate highest versions.
- Preserved V547 Live source changes; advanced Android and Worker identity to 548 / 2.9.548. APK build/device QA pending.
