# Current source: MY SHOP V-593

Complete continuation project. Start with AGENTS.md, DEVELOPER-POLICY-BN.md and MY-SHOP-DEVELOPER-HANDOFF.md. Build/upload: UPLOAD-INSTRUCTIONS-BN.md. No V593 APK is claimed locally.

# Current release: V-570 / 2.9.570

Source update; full APK build and device QA are not verified. See MY-SHOP-DEVELOPER-HANDOFF.md for current scope and limitations. Earlier notes below are historical.

# MY SHOP V-569

Complete source based on V568. Corrected MiniHeadlineOverlay Java lambda compile failure. Upload V-569-MY-SHOP-SOURCE.zip directly to the same repository root used for V568; use the existing permanent release pipeline. See MY-SHOP-DEVELOPER-HANDOFF.md for exact tests and limits.
