# MY SHOP — Canonical Developer Rules

The merged, deduplicated policy is DEVELOPER-POLICY-BN.md (2026-10-09). Read that file before implementation/build/delivery. Read MY-SHOP-DEVELOPER-INSTRUCTIONS.md for retained distinct feature instructions, AGENTS.md for Live approval scope, and MY-SHOP-DEVELOPER-HANDOFF.md for actual continuation state. This file is an entry point rather than a duplicate policy. Latest owner instructions override historical notes.
