-- V-566: keep badge grants automatically time-limited without changing user/account state.
ALTER TABLE myshop_user_verification ADD COLUMN expires_at TEXT;
