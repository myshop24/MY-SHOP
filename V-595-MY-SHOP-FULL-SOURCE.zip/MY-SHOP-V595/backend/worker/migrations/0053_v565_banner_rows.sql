-- V-565: independently hide Home Page 1 and Live Page 2 banner sections and
-- persist carousel duration separately so legacy banner rows remain untouched.
CREATE TABLE IF NOT EXISTS myshop_banner_sections (
  folder TEXT PRIMARY KEY,
  enabled INTEGER NOT NULL DEFAULT 1,
  updated_by TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT OR IGNORE INTO myshop_banner_sections(folder,enabled) VALUES
  ('hero',1),
  ('promo',1),
  ('live_home',1);

CREATE TABLE IF NOT EXISTS myshop_banner_durations (
  folder TEXT NOT NULL,
  slot INTEGER NOT NULL,
  display_seconds INTEGER NOT NULL DEFAULT 4,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(folder,slot)
);
