-- V-566: scoped moving headline strips remain separate from the Breaking News headline.
CREATE TABLE IF NOT EXISTS myshop_headline_strips (
  scope TEXT PRIMARY KEY,
  revision INTEGER NOT NULL DEFAULT 0,
  payload TEXT NOT NULL,
  previous_payload TEXT,
  updated_by TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
