CREATE TABLE IF NOT EXISTS myshop_overlay_placements(kind TEXT PRIMARY KEY,revision INTEGER NOT NULL DEFAULT 0,payload TEXT NOT NULL,updated_by TEXT);
