-- Additive only. The new endpoint also lazily ensures these tables on first use.
CREATE TABLE IF NOT EXISTS myshop_appearance_grants (
 user_id TEXT PRIMARY KEY, identity INTEGER NOT NULL DEFAULT 0,
 status INTEGER NOT NULL DEFAULT 0, revision INTEGER NOT NULL DEFAULT 0,
 actor_id TEXT, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS myshop_visual_designs (
 scope TEXT PRIMARY KEY, revision INTEGER NOT NULL DEFAULT 0,
 draft_revision INTEGER NOT NULL DEFAULT 0, published TEXT NOT NULL DEFAULT '{}',
 draft TEXT NOT NULL DEFAULT '{}', actor_id TEXT,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS myshop_visual_design_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT, scope TEXT NOT NULL, actor_id TEXT NOT NULL,
 action TEXT NOT NULL, revision INTEGER NOT NULL, old_payload TEXT NOT NULL,
 new_payload TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
