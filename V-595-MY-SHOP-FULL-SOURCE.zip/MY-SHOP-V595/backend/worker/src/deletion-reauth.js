// Uses the existing Google login identity contract (verified email and pinned OAuth audience).
export async function verifyDeletionGoogleToken(idToken,owner,env){
  if(!owner?.email||typeof idToken!=='string'||!idToken.trim()||idToken.length>12000)return {error:'GOOGLE_REAUTH_REQUIRED',statusCode:403};
  let response,info;
  try{response=await fetch('https://oauth2.googleapis.com/tokeninfo?id_token='+encodeURIComponent(idToken),{headers:{accept:'application/json'}});info=await response.json();}
  catch(_){return {error:'GOOGLE_REAUTH_UNAVAILABLE',statusCode:503};}
  const expected=String(env.GOOGLE_WEB_CLIENT_ID||'595594415596-tj26hl997ult960cug3ia68tgv5bf1rb.apps.googleusercontent.com').trim();
  const now=Math.floor(Date.now()/1000),issued=Number(info.iat),expires=Number(info.exp);
  if(!response.ok||!expected||String(info.aud||'')!==expected||!['accounts.google.com','https://accounts.google.com'].includes(String(info.iss||''))||String(info.email_verified).toLowerCase()!=='true'||String(info.email||'').trim().toLowerCase()!==String(owner.email).trim().toLowerCase()||!Number.isSafeInteger(issued)||!Number.isSafeInteger(expires)||expires<=now||issued>now+60||now-issued>600)return {error:'GOOGLE_REAUTH_INVALID',statusCode:403};
  return {ok:true};
}
