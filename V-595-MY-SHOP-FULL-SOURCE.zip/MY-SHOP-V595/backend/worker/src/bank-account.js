// Private payout details only. Never participates in public profile or Live state.
export async function bankAccount(request,env,h){
 const fail=(error,status=400)=>h.json({error},status,{...h.cors,'cache-control':'no-store'});
 const me=await h.getUser(request,env);if(!me)return fail('UNAUTHORIZED',401);
 const DB=env.DB,uid=String(me.user_id);
 const active=await DB.prepare('SELECT active FROM myshop_auth_users_v108 WHERE user_id=?').bind(uid).first();if(Number(active?.active)!==1)return fail('UNAUTHORIZED',401);
 if(!['GET','PUT','DELETE'].includes(request.method))return fail('METHOD_NOT_ALLOWED',405);
 if(new URL(request.url).search)return fail('INVALID_ACCOUNT_QUERY');
 await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_private_bank_account(user_id TEXT PRIMARY KEY,bank_name TEXT NOT NULL DEFAULT '',holder_name TEXT NOT NULL DEFAULT '',account_number TEXT NOT NULL DEFAULT '',branch TEXT NOT NULL DEFAULT '',revision INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
 await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_private_bank_audit(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,action TEXT NOT NULL,revision INTEGER NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
 const old=await DB.prepare('SELECT * FROM myshop_private_bank_account WHERE user_id=?').bind(uid).first();
 const output=row=>({ok:true,revision:Number(row?.revision||0),account:row?.account_number?{bank:row.bank_name,holder:row.holder_name,number:row.account_number,branch:row.branch}:null});
 if(request.method==='GET')return h.json(output(old),200,{...h.cors,'cache-control':'no-store'});
 let b;try{b=await request.json();}catch(_){return fail('INVALID_JSON');}
 if(!b||typeof b!=='object'||Array.isArray(b)||Object.keys(b).some(k=>!['expectedRevision','bank','holder','number','branch'].includes(k)))return fail('INVALID_ACCOUNT_DETAILS');
 if(!Number.isSafeInteger(b.expectedRevision)||b.expectedRevision<0)return fail('INVALID_REVISION');
 if(b.expectedRevision!==Number(old?.revision||0))return fail('ACCOUNT_REVISION_CONFLICT',409);
 const values=request.method==='DELETE'?['','','','']:['bank','holder','number','branch'].map(k=>typeof b[k]==='string'?b[k].trim():'');
 if(request.method==='PUT'&&(!values[0]||!values[1]||!values[3]||values[0].length>80||values[1].length>80||values[3].length>60||!/^\d[\d -]{6,38}\d$/.test(values[2])||values.some(s=>/[\x00-\x1f\x7f]/.test(s))||('Bank: '+values[0]+' | Holder: '+values[1]+' | Branch: '+values[3]).length>180))return fail('INVALID_ACCOUNT_DETAILS');
 const acl='EXISTS(SELECT 1 FROM myshop_auth_users_v108 WHERE user_id=? AND active=1)';
 const write=old?DB.prepare('UPDATE myshop_private_bank_account SET bank_name=?,holder_name=?,account_number=?,branch=?,revision=revision+1,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND revision=? AND '+acl).bind(...values,uid,b.expectedRevision,uid):DB.prepare('INSERT OR IGNORE INTO myshop_private_bank_account(user_id,bank_name,holder_name,account_number,branch,revision) SELECT ?,?,?,?,?,1 WHERE '+acl).bind(uid,...values,uid);
 const results=await DB.batch([write,DB.prepare('INSERT INTO myshop_private_bank_audit(user_id,action,revision) SELECT ?,?,? WHERE changes()=1').bind(uid,request.method==='DELETE'?'DELETE':'SAVE',b.expectedRevision+1)]);
 if(!Number(results[0]?.meta?.changes))return fail('ACCOUNT_STATE_CHANGED',409);
 const saved=await DB.prepare('SELECT * FROM myshop_private_bank_account WHERE user_id=?').bind(uid).first();return h.json(output(saved),200,{...h.cors,'cache-control':'no-store'});
}
