export const commissionFeatures=['GIFT','TRANSFER','WITHDRAW'];
const schema=[`CREATE TABLE IF NOT EXISTS myshop_commission_management(id INTEGER PRIMARY KEY CHECK(id=1),revision INTEGER NOT NULL,payload TEXT NOT NULL,actor_id TEXT NOT NULL,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,`CREATE TABLE IF NOT EXISTS myshop_commission_audit(id INTEGER PRIMARY KEY AUTOINCREMENT,revision INTEGER NOT NULL,actor_id TEXT NOT NULL,old_payload TEXT NOT NULL,new_payload TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`];
const ready=new WeakMap();
async function ensure(DB){let p=ready.get(DB);if(!p){p=DB.batch(schema.map(s=>DB.prepare(s))).catch(e=>{ready.delete(DB);throw e;});ready.set(DB,p);}await p;}
const percent=n=>{if(typeof n!=='number'||!Number.isFinite(n)||n<0||n>100||Math.abs(n*100-Math.round(n*100))>1e-6)throw Error('INVALID_COMMISSION_PERCENT');return n;};
export function normalizeCommission(input){
 if(!input||typeof input!=='object')throw Error('INVALID_COMMISSION_CONFIG');
 const central={},features={};for(const c of ['COIN','GOLD']){const x=input.central?.[c];if(!x||typeof x.enabled!=='boolean')throw Error('INVALID_CENTRAL_SETTING');central[c]={enabled:x.enabled,percent:percent(x.percent)};features[c]={};for(const f of commissionFeatures){if(input.features?.[c]?.[f]!=null)features[c][f]=percent(input.features[c][f]);}}
 const freeUntil=Number(input.freeUntil||0);if(!Number.isSafeInteger(freeUntil)||freeUntil<0)throw Error('INVALID_FREE_PERIOD');
 return {central,features,freeUntil};
}
export function effectiveCommission(config,currency,feature,fallback,now=Date.now()){
 if(config.freeUntil>now)return 0;
 if(config.central[currency]?.enabled)return config.central[currency].percent;
 return config.features[currency]?.[feature]??fallback;
}
export async function readCommission(DB){await ensure(DB);const r=await DB.prepare('SELECT revision,payload FROM myshop_commission_management WHERE id=1').first();return {revision:Number(r?.revision||0),config:r?normalizeCommission(JSON.parse(r.payload)):{central:{COIN:{enabled:false,percent:10},GOLD:{enabled:false,percent:5}},features:{COIN:{},GOLD:{}},freeUntil:0}};}
export async function commissionManagement(request,env,h){
 const me=await h.getUser(request,env);if(!me||!['0001','0002','0003'].includes(String(me.user_id)))return h.json({error:'OWNER_FINANCE_PERMISSION_REQUIRED'},403,h.cors);
 const active=await env.DB.prepare('SELECT active FROM myshop_auth_users_v108 WHERE user_id=?').bind(me.user_id).first();if(Number(active?.active)!==1)return h.json({error:'UNAUTHORIZED'},401,h.cors);
 const old=await readCommission(env.DB);if(request.method==='GET')return h.json({ok:true,...old,features:commissionFeatures,commissionLabel:'MY SHOP Commission'},200,{...h.cors,'cache-control':'no-store'});
 if(request.method!=='POST')return h.json({error:'METHOD_NOT_ALLOWED'},405,h.cors);
 const b=await request.json().catch(()=>null);if(!b||b.expectedRevision!==old.revision)return h.json({error:'REVISION_CONFLICT'},409,h.cors);
 let next;try{next=normalizeCommission(b.config);next.freeUntil=old.config.freeUntil;if(b.freeHours!=null){if(typeof b.freeHours!=='number'||!Number.isFinite(b.freeHours)||b.freeHours<0||b.freeHours>720)throw Error('INVALID_FREE_HOURS');next.freeUntil=b.freeHours?Date.now()+Math.round(b.freeHours*3600000):0;}}catch(e){return h.json({error:e.message},400,h.cors);}
 const acl="EXISTS(SELECT 1 FROM myshop_auth_users_v108 WHERE user_id=? AND active=1 AND user_id IN ('0001','0002','0003'))",payload=JSON.stringify(next);
 const write=old.revision?env.DB.prepare(`UPDATE myshop_commission_management SET revision=revision+1,payload=?,actor_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=1 AND revision=? AND ${acl}`).bind(payload,me.user_id,old.revision,me.user_id):env.DB.prepare(`INSERT OR IGNORE INTO myshop_commission_management(id,revision,payload,actor_id) SELECT 1,1,?,? WHERE ${acl}`).bind(payload,me.user_id,me.user_id);
 const r=await env.DB.batch([write,env.DB.prepare('INSERT INTO myshop_commission_audit(revision,actor_id,old_payload,new_payload) SELECT ?,?,?,? WHERE changes()=1').bind(old.revision+1,me.user_id,JSON.stringify(old.config),payload)]);
 if(!Number(r[0]?.meta?.changes))return h.json({error:'REVISION_OR_PERMISSION_CHANGED'},409,h.cors);
 return h.json({ok:true,revision:old.revision+1,config:next},200,h.cors);
}
