import { ensureWithdrawWalletHold } from './withdraw-wallet-hold.js';
// Payment recording only: this endpoint never sends money to a payment provider.
export const payoutActionSchema=[
 `CREATE TABLE IF NOT EXISTS myshop_payout_actions(id INTEGER PRIMARY KEY AUTOINCREMENT,request_id INTEGER NOT NULL,actor_id TEXT NOT NULL,old_status TEXT NOT NULL,new_status TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
 `CREATE TRIGGER IF NOT EXISTS myshop_withdraw_reserve_guard BEFORE INSERT ON myshop_creator_withdraw_requests WHEN NEW.status IN ('PENDING','PROCESSING') BEGIN SELECT CASE WHEN NEW.gross_units<=0 OR NEW.gross_units>COALESCE((SELECT balance FROM myshop_creator_earnings WHERE user_id=NEW.user_id AND currency=NEW.currency),0)-COALESCE((SELECT SUM(gross_units) FROM myshop_creator_withdraw_requests WHERE user_id=NEW.user_id AND currency=NEW.currency AND status IN ('PENDING','PROCESSING')),0) THEN RAISE(ABORT,'INSUFFICIENT_CREATOR_EARNINGS') END; END`,
 `CREATE TRIGGER IF NOT EXISTS myshop_withdraw_paid_guard BEFORE UPDATE OF status ON myshop_creator_withdraw_requests WHEN NEW.status='PAID' AND OLD.status<>'PAID' BEGIN SELECT CASE WHEN OLD.status<>'PROCESSING' OR NEW.gross_units>COALESCE((SELECT balance FROM myshop_creator_earnings WHERE user_id=NEW.user_id AND currency=NEW.currency),0) THEN RAISE(ABORT,'INVALID_PAYOUT_BALANCE') END; UPDATE myshop_creator_earnings SET balance=balance-NEW.gross_units,updated_at=CURRENT_TIMESTAMP WHERE user_id=NEW.user_id AND currency=NEW.currency; END`
];
export async function payoutAction(request,env,h){
 const a=await h.adminOnly(request,env);if(a.error)return a.error;
 if(request.method!=='POST')return h.json({error:'METHOD_NOT_ALLOWED'},405,h.cors);
 await h.ensureContentSchema(env);await env.DB.batch(payoutActionSchema.map(s=>env.DB.prepare(s)));await ensureWithdrawWalletHold(env.DB);
 const me=await h.getUser(request,env),b=await request.json().catch(()=>({})),id=Number(b.id),action=String(b.action||''),note=String(b.note||'').trim().slice(0,300);
 if(!Number.isSafeInteger(id)||id<1||!['APPROVE','REJECT','PAID'].includes(action))return h.json({error:'INVALID_ACTION'},400,h.cors);
 if(action==='PAID'&&!note)return h.json({error:'PAYMENT_REFERENCE_REQUIRED'},400,h.cors);
 const r=await env.DB.prepare('SELECT * FROM myshop_creator_withdraw_requests WHERE id=?').bind(id).first();if(!r)return h.json({error:'REQUEST_NOT_FOUND'},404,h.cors);
 const target=action==='APPROVE'?'PROCESSING':action==='REJECT'?'REJECTED':'PAID';
 if(r.status===target)return h.json({ok:true,id,status:target,alreadyApplied:true},200,h.cors);
 if(!(r.status==='PENDING'&&['PROCESSING','REJECTED'].includes(target)||r.status==='PROCESSING'&&['PAID','REJECTED'].includes(target)))return h.json({error:'INVALID_STATUS_TRANSITION'},409,h.cors);
 // The audit is inserted only when the guarded update succeeds; D1 batch is atomic.
 const result=await env.DB.batch([
  env.DB.prepare('UPDATE myshop_creator_withdraw_requests SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND status=?').bind(target,id,r.status),
  env.DB.prepare('INSERT INTO myshop_payout_actions(request_id,actor_id,old_status,new_status,note) SELECT ?,?,?,?,? WHERE changes()=1').bind(id,me.user_id,r.status,target,note),
  ...(target==='PAID'?[env.DB.prepare("INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,gross_amount,fee_percent,fee_amount,net_amount,platform_amount,status,reference,metadata) SELECT 'CREATOR_WITHDRAW_PAID',currency,user_id,'WITHDRAWAL',gross_units,service_fee_percent,service_fee_units,net_units,service_fee_units,'COMPLETED',?,? FROM myshop_creator_withdraw_requests WHERE id=? AND changes()=1").bind('MYSHOP_PAYOUT_PAID_'+id,JSON.stringify({recordedBy:me.user_id,paymentReference:note,cashMinor:r.cash_minor}),id)]:[])
 ]);
 if(!result[0].meta?.changes)return h.json({error:'REQUEST_CHANGED_RELOAD'},409,h.cors);
 return h.json({ok:true,id,status:target,paymentSent:false},200,h.cors);
}
