import {ensureCommerceFinance,commerceFinance} from './commerce-finance.js';
// Physical goods only. Prices are integer paisa; no Coin/Gold wallet writes.
export const schema = [
`CREATE TABLE IF NOT EXISTS shop_reviews(user_id TEXT NOT NULL,product_id INTEGER NOT NULL,rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),review TEXT NOT NULL,image_url TEXT NOT NULL DEFAULT '',PRIMARY KEY(user_id,product_id))`,
`CREATE TABLE IF NOT EXISTS shop_notices(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,message TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
`CREATE TABLE IF NOT EXISTS shop_clicks(user_id TEXT NOT NULL,product_id INTEGER NOT NULL,folder INTEGER NOT NULL DEFAULT 0,day TEXT NOT NULL DEFAULT CURRENT_DATE,PRIMARY KEY(user_id,product_id,folder,day))`,
`CREATE TABLE IF NOT EXISTS shop_products(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,description TEXT NOT NULL DEFAULT '',category TEXT NOT NULL DEFAULT '',image_url TEXT NOT NULL DEFAULT '',price INTEGER NOT NULL CHECK(price>0),stock INTEGER NOT NULL CHECK(stock>=0),enabled INTEGER NOT NULL DEFAULT 1,deleted INTEGER NOT NULL DEFAULT 0)`,
`CREATE TABLE IF NOT EXISTS shop_cart(user_id TEXT NOT NULL,product_id INTEGER NOT NULL,qty INTEGER NOT NULL CHECK(qty BETWEEN 1 AND 99),PRIMARY KEY(user_id,product_id))`,
`CREATE TABLE IF NOT EXISTS shop_orders(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,request_key TEXT NOT NULL,address TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'PENDING' CHECK(status IN ('PENDING','CONFIRMED','SHIPPED','DELIVERED','CANCELLED')),payment TEXT NOT NULL DEFAULT 'COD' CHECK(payment='COD'),created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(user_id,request_key))`,
`CREATE TABLE IF NOT EXISTS shop_order_items(order_id TEXT NOT NULL,product_id INTEGER NOT NULL,title TEXT NOT NULL,qty INTEGER NOT NULL CHECK(qty>0),unit_price INTEGER NOT NULL CHECK(unit_price>0),PRIMARY KEY(order_id,product_id))`,
`CREATE TABLE IF NOT EXISTS shop_events(order_id TEXT NOT NULL,status TEXT NOT NULL,actor TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
`CREATE TABLE IF NOT EXISTS shop_saved(user_id TEXT NOT NULL,product_id INTEGER NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('WISH','STOCK')),PRIMARY KEY(user_id,product_id,kind))`,
`CREATE TABLE IF NOT EXISTS shop_price_alerts(user_id TEXT NOT NULL,product_id INTEGER NOT NULL,watched_price INTEGER NOT NULL,PRIMARY KEY(user_id,product_id))`,
`CREATE TABLE IF NOT EXISTS shop_promos(folder INTEGER NOT NULL CHECK(folder BETWEEN 1 AND 4),slot INTEGER NOT NULL CHECK(slot BETWEEN 1 AND 4),product_id INTEGER NOT NULL,offer_price INTEGER NOT NULL CHECK(offer_price>0),ends_at INTEGER NOT NULL,enabled INTEGER NOT NULL DEFAULT 1,PRIMARY KEY(folder,slot))`,
`CREATE TRIGGER IF NOT EXISTS shop_reserve BEFORE INSERT ON shop_order_items BEGIN SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM shop_products WHERE id=NEW.product_id AND enabled=1 AND deleted=0 AND stock>=NEW.qty) THEN RAISE(ABORT,'OUT_OF_STOCK') END; UPDATE shop_products SET stock=stock-NEW.qty WHERE id=NEW.product_id; END`,
`CREATE TRIGGER IF NOT EXISTS shop_order_notice AFTER UPDATE OF status ON shop_orders WHEN NEW.status<>OLD.status BEGIN INSERT INTO shop_notices(user_id,message) VALUES(NEW.user_id,'Order '||NEW.id||': '||NEW.status); END`,
`CREATE TRIGGER IF NOT EXISTS shop_stock_notice AFTER UPDATE OF stock ON shop_products WHEN OLD.stock=0 AND NEW.stock>0 AND NEW.enabled=1 AND NEW.deleted=0 BEGIN INSERT INTO shop_notices(user_id,message) SELECT user_id,NEW.title||' is back in stock' FROM shop_saved WHERE product_id=NEW.id AND kind='STOCK'; DELETE FROM shop_saved WHERE product_id=NEW.id AND kind='STOCK'; END`,
`CREATE TRIGGER IF NOT EXISTS shop_restore AFTER UPDATE OF status ON shop_orders WHEN NEW.status='CANCELLED' AND OLD.status<>'CANCELLED' BEGIN UPDATE shop_products SET stock=stock+COALESCE((SELECT qty FROM shop_order_items WHERE order_id=NEW.id AND product_id=shop_products.id),0) WHERE id IN (SELECT product_id FROM shop_order_items WHERE order_id=NEW.id); END`
];
const integer=(n,min,max)=>{n=Number(n);if(!Number.isSafeInteger(n)||n<min||n>max)throw Error('INVALID_NUMBER');return n;};
const str=(s,max)=>String(s||'').trim().slice(0,max);
export function transition(old,next){return ({PENDING:['CONFIRMED','CANCELLED'],CONFIRMED:['SHIPPED','CANCELLED'],SHIPPED:['DELIVERED'],DELIVERED:[],CANCELLED:[]}[old]||[]).includes(next);}
// Invoked only after the existing account-deletion password check. Preserve
// transaction snapshots/internal IDs, but never retain shipping contact fields.
export async function eraseCommercePersonalData(env,userId){
 const exists=await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='shop_orders'").first();
 if(!exists)return;
 await env.DB.batch([
  ...['shop_cart','shop_saved','shop_price_alerts','shop_reviews','shop_notices','shop_clicks'].map(table=>env.DB.prepare(`DELETE FROM ${table} WHERE user_id=?`).bind(userId)),
  env.DB.prepare('UPDATE shop_orders SET address=? WHERE user_id=?').bind(JSON.stringify({name:'Deleted User',phone:'',address:'Removed by account deletion'}),userId)
 ]);
}
export async function commerce(request,env,helpers){
 const {getUser,adminOnly,json,cors}=helpers;
 const send=(d,s=200)=>json(d,s,cors),u=new URL(request.url),path=u.pathname.replace('/v1/commerce/',''),db=env.DB;
 const me=await getUser(request,env);if(!me)return send({error:'UNAUTHORIZED'},401);
 const admin=path.startsWith('admin/');if(admin){const a=await adminOnly(request,env);if(a.error)return a.error;}
 await db.batch(schema.map(s=>db.prepare(s)));
 await ensureCommerceFinance(db);
 if(helpers.ensureRequestNotices)await helpers.ensureRequestNotices(db);
 const rows=async(sql,...args)=>(await db.prepare(sql).bind(...args).all()).results||[];
 const now=Date.now();
 const priceSql=`COALESCE((SELECT MIN(offer_price) FROM shop_promos WHERE product_id=p.id AND enabled=1 AND ends_at>${now}),p.price)`;
 const products=()=>rows(`SELECT p.*,${priceSql} effective_price,(SELECT MIN(ends_at) FROM shop_promos WHERE product_id=p.id AND enabled=1 AND ends_at>${now}) offer_end FROM shop_products p WHERE deleted=0 ${admin?'':'AND enabled=1'} ORDER BY id DESC LIMIT 500`);
 if(request.method==='GET'){
  if(path==='admin/finance')return send({ok:true,...await commerceFinance(db)});
  if(path==='notices')return send({notices:await rows('SELECT * FROM shop_notices WHERE user_id=? ORDER BY id DESC LIMIT 100',me.user_id)});
  if(path==='reviews'){const id=Number(u.searchParams.get('product_id'));if(!Number.isSafeInteger(id)||id<1||id>1e9)return send({error:'INVALID_PRODUCT_ID'},400);return send({reviews:await rows('SELECT rating,review,image_url FROM shop_reviews WHERE product_id=?',id)});}
  if(path==='admin/analytics')return send({products:await rows(`SELECT p.id,p.title,(SELECT COUNT(*) FROM shop_clicks WHERE product_id=p.id) daily_unique_clicks,COALESCE((SELECT SUM(i.qty) FROM shop_order_items i JOIN shop_orders o ON o.id=i.order_id WHERE i.product_id=p.id AND o.status='DELIVERED'),0) delivered_units,COALESCE((SELECT SUM(i.qty*i.unit_price) FROM shop_order_items i JOIN shop_orders o ON o.id=i.order_id WHERE i.product_id=p.id AND o.status='DELIVERED'),0) delivered_revenue FROM shop_products p ORDER BY p.id DESC`)});
  if(path==='products'||path==='admin/products')return send({products:await products()});
  if(path==='promos')return send({promos:await rows('SELECT s.*,p.title,p.image_url,p.price,p.stock FROM shop_promos s JOIN shop_products p ON p.id=s.product_id WHERE s.enabled=1 AND s.ends_at>? AND p.enabled=1 AND p.deleted=0 ORDER BY s.folder,s.slot',now)});
  if(path==='cart')return send({items:await rows(`SELECT p.*,c.qty,${priceSql} effective_price FROM shop_cart c JOIN shop_products p ON p.id=c.product_id WHERE c.user_id=?`,me.user_id)});
  if(path==='saved')return send({items:await rows("SELECT s.*,p.title,p.stock FROM shop_saved s JOIN shop_products p ON p.id=s.product_id WHERE s.user_id=? AND s.kind='WISH'",me.user_id),priceAlerts:await rows('SELECT a.*,p.title,p.price FROM shop_price_alerts a JOIN shop_products p ON p.id=a.product_id WHERE a.user_id=?',me.user_id)});
  if(path==='orders'||path==='admin/orders'){const orders=await rows(`SELECT o.*,COALESCE((SELECT SUM(qty*unit_price) FROM shop_order_items WHERE order_id=o.id),0) total FROM shop_orders o ${admin?'':'WHERE user_id=?'} ORDER BY created_at DESC LIMIT 200`,...(admin?[]:[me.user_id]));for(const o of orders){o.items=await rows('SELECT * FROM shop_order_items WHERE order_id=?',o.id);o.events=await rows('SELECT status,created_at FROM shop_events WHERE order_id=? ORDER BY rowid',o.id);}return send({orders});}
  return send({error:'NOT_FOUND'},404);
 }
 if(request.method!=='POST')return send({error:'METHOD_NOT_ALLOWED'},405);
 let b;try{b=await request.json();}catch(_){return send({error:'INVALID_JSON'},400);}
 try{
 if(path==='click'){await db.prepare('INSERT OR IGNORE INTO shop_clicks(user_id,product_id,folder) SELECT ?,id,? FROM shop_products WHERE id=? AND deleted=0 AND enabled=1').bind(me.user_id,integer(b.folder||0,0,4),integer(b.product_id,1,1e9)).run();return send({ok:true});}
 if(path==='review'){
  const id=integer(b.product_id,1,1e9),rating=integer(b.rating,1,5),review=str(b.review,1200),image=str(b.image_url,1000);
  if(!review||(image&&!/^https:\/\//i.test(image)))throw Error('REVIEW_AND_HTTPS_PHOTO_REQUIRED');
  const bought=await db.prepare("SELECT 1 ok FROM shop_order_items i JOIN shop_orders o ON o.id=i.order_id WHERE o.user_id=? AND i.product_id=? AND o.status='DELIVERED' LIMIT 1").bind(me.user_id,id).first();if(!bought)return send({error:'DELIVERED_BUYERS_ONLY'},403);
  await db.prepare('INSERT INTO shop_reviews(user_id,product_id,rating,review,image_url) VALUES(?,?,?,?,?) ON CONFLICT(user_id,product_id) DO UPDATE SET rating=excluded.rating,review=excluded.review,image_url=excluded.image_url').bind(me.user_id,id,rating,review,image).run();return send({ok:true});
 }
 if(path==='admin/expense'){
  const amount=integer(b.amount,1,1e9),category=str(b.category,80),note=str(b.note,300),day=str(b.expense_day,10),key=str(b.request_key,80);
  if(!category||!note||!/^\d{4}-\d{2}-\d{2}$/.test(day)||Number.isNaN(Date.parse(day))||new Date(day).toISOString().slice(0,10)!==day||!/^[-a-zA-Z0-9]{16,80}$/.test(key))throw Error('EXPENSE_FIELDS_REQUIRED');
  const prior=await db.prepare('SELECT * FROM shop_expenses WHERE request_key=?').bind(key).first();if(prior){if(Number(prior.amount)!==amount||prior.category!==category||prior.note!==note||prior.expense_day!==day)throw Error('REQUEST_KEY_CONFLICT');return send({ok:true,id:prior.id,alreadyApplied:true});}
  const r=await db.prepare('INSERT INTO shop_expenses(request_key,actor_id,amount,category,note,expense_day) VALUES(?,?,?,?,?,?)').bind(key,me.user_id,amount,category,note,day).run();return send({ok:true,id:r.meta?.last_row_id},201);
 }
 if(path==='admin/product'){
  const id=integer(b.id||0,0,1e9),title=str(b.title,120),price=integer(b.price,1,1e9),stock=integer(b.stock,0,1e6),image=str(b.image_url,1000);
  if(!title||(image&&!/^https:\/\//i.test(image)))throw Error('TITLE_OR_HTTPS_IMAGE_REQUIRED');
  if(b.unit_cost!==undefined&&b.unit_cost!==null)integer(b.unit_cost,0,1e9);
  if(id){const old=await db.prepare('SELECT price FROM shop_products WHERE id=? AND deleted=0').bind(id).first();const changed=await db.prepare('UPDATE shop_products SET title=?,description=?,category=?,image_url=?,price=?,stock=?,enabled=? WHERE id=? AND deleted=0 AND stock=?').bind(title,str(b.description,3000),str(b.category,80),image,price,stock,b.enabled===false?0:1,id,integer(b.expected_stock,0,1e6)).run();if(!changed.meta?.changes)throw Error('STOCK_CHANGED_RELOAD_PRODUCT');if(old&&price<Number(old.price)){await db.prepare("INSERT INTO shop_notices(user_id,message) SELECT user_id,? FROM shop_price_alerts WHERE product_id=? AND watched_price>?").bind(title+' price dropped to '+(price/100).toFixed(2)+' BDT',id,price).run();await db.prepare('UPDATE shop_price_alerts SET watched_price=? WHERE product_id=? AND watched_price>?').bind(price,id,price).run();}}
  else {const r=await db.prepare('INSERT INTO shop_products(title,description,category,image_url,price,stock,enabled) VALUES(?,?,?,?,?,?,?)').bind(title,str(b.description,3000),str(b.category,80),image,price,stock,b.enabled===false?0:1).run();b.id=Number(r.meta?.last_row_id);}if(b.unit_cost!==undefined){const cost=b.unit_cost===null?null:integer(b.unit_cost,0,1e9);await db.prepare('UPDATE shop_products SET unit_cost=? WHERE id=?').bind(cost,id||b.id).run();}return send({ok:true});
 }
 if(path==='admin/delete'){await db.prepare('UPDATE shop_products SET deleted=1,enabled=0 WHERE id=?').bind(integer(b.id,1,1e9)).run();return send({ok:true});}
 if(path==='admin/promo'){
  const folder=integer(b.folder,1,4),slot=integer(b.slot,1,4);if(b.remove===true){await db.prepare('DELETE FROM shop_promos WHERE folder=? AND slot=?').bind(folder,slot).run();return send({ok:true});}
  const product=await db.prepare('SELECT * FROM shop_products WHERE id=? AND deleted=0 AND enabled=1').bind(integer(b.product_id,1,1e9)).first();if(!product)throw Error('PRODUCT_NOT_FOUND');
  const offer=integer(b.offer_price,1,product.price),end=integer(b.ends_at,now+1,now+366*86400000);
  await db.prepare('INSERT INTO shop_promos(folder,slot,product_id,offer_price,ends_at,enabled) VALUES(?,?,?,?,?,?) ON CONFLICT(folder,slot) DO UPDATE SET product_id=excluded.product_id,offer_price=excluded.offer_price,ends_at=excluded.ends_at,enabled=excluded.enabled').bind(folder,slot,product.id,offer,end,b.enabled===false?0:1).run();return send({ok:true});
 }
 if(path==='cart'){
  const id=integer(b.product_id,1,1e9),qty=integer(b.qty,0,99);if(!qty)await db.prepare('DELETE FROM shop_cart WHERE user_id=? AND product_id=?').bind(me.user_id,id).run();
  else{const p=await db.prepare('SELECT stock FROM shop_products WHERE id=? AND enabled=1 AND deleted=0').bind(id).first();if(!p||p.stock<qty)throw Error('OUT_OF_STOCK');await db.prepare('INSERT INTO shop_cart(user_id,product_id,qty) VALUES(?,?,?) ON CONFLICT(user_id,product_id) DO UPDATE SET qty=excluded.qty').bind(me.user_id,id,qty).run();}return send({ok:true});
 }
 if(path==='saved'){const id=integer(b.product_id,1,1e9);if(b.kind==='PRICE'){if(b.remove===true)await db.prepare('DELETE FROM shop_price_alerts WHERE user_id=? AND product_id=?').bind(me.user_id,id).run();else await db.prepare('INSERT INTO shop_price_alerts(user_id,product_id,watched_price) SELECT ?,id,price FROM shop_products WHERE id=? AND deleted=0 ON CONFLICT(user_id,product_id) DO UPDATE SET watched_price=excluded.watched_price').bind(me.user_id,id).run();return send({ok:true});}const kind=b.kind==='STOCK'?'STOCK':'WISH';if(b.remove===true)await db.prepare('DELETE FROM shop_saved WHERE user_id=? AND product_id=? AND kind=?').bind(me.user_id,id,kind).run();else await db.prepare('INSERT OR IGNORE INTO shop_saved(user_id,product_id,kind) SELECT ?,id,? FROM shop_products WHERE id=? AND deleted=0').bind(me.user_id,kind,id).run();return send({ok:true});}
 if(path==='checkout'){
  const key=str(b.request_key,80),a=b.address||{};if(!/^[a-zA-Z0-9-]{16,80}$/.test(key)||!str(a.name,80)||!/^\+?[0-9 -]{8,20}$/.test(String(a.phone||''))||str(a.address,500).length<10)throw Error('NAME_PHONE_ADDRESS_REQUIRED');
  const existing=await db.prepare('SELECT id FROM shop_orders WHERE user_id=? AND request_key=?').bind(me.user_id,key).first();if(existing)return send({ok:true,order_id:existing.id});
  const items=await rows(`SELECT p.*,c.qty,${priceSql} effective_price FROM shop_cart c JOIN shop_products p ON p.id=c.product_id WHERE c.user_id=?`,me.user_id);if(!items.length||items.length>30)throw Error('CART_MUST_HAVE_1_TO_30_ITEMS');
  const total=items.reduce((n,p)=>n+p.qty*p.effective_price,0);if(Number(b.expected_total)!==total)throw Error('PRICE_CHANGED_RELOAD_CART');
  const id=crypto.randomUUID(),address=JSON.stringify({name:str(a.name,80),phone:str(a.phone,24),address:str(a.address,500)});
  const batch=[db.prepare('INSERT INTO shop_orders(id,user_id,request_key,address) VALUES(?,?,?,?)').bind(id,me.user_id,key,address)];
  for(const p of items){batch.push(db.prepare('INSERT INTO shop_order_items(order_id,product_id,title,qty,unit_price,unit_cost) VALUES(?,?,?,?,?,?)').bind(id,p.id,p.title,p.qty,p.effective_price,p.unit_cost??null));batch.push(db.prepare('DELETE FROM shop_cart WHERE user_id=? AND product_id=? AND qty=?').bind(me.user_id,p.id,p.qty));}
  batch.push(db.prepare("INSERT INTO shop_events(order_id,status,actor) VALUES(?,'PENDING',?)").bind(id,me.user_id));
  try{await db.batch(batch);}catch(e){const retry=await db.prepare('SELECT id FROM shop_orders WHERE user_id=? AND request_key=?').bind(me.user_id,key).first();if(retry)return send({ok:true,order_id:retry.id});throw Error('STOCK_CHANGED_RELOAD_CART');}return send({ok:true,order_id:id},201);
 }
 if(path==='admin/status'){
  const id=str(b.id,80),next=str(b.status,20),o=await db.prepare('SELECT * FROM shop_orders WHERE id=?').bind(id).first();if(!o||!transition(o.status,next))throw Error('INVALID_STATUS_TRANSITION');
  await db.batch([db.prepare('UPDATE shop_orders SET status=? WHERE id=? AND status=?').bind(next,id,o.status),db.prepare('INSERT INTO shop_events(order_id,status,actor) SELECT id,?,? FROM shop_orders WHERE id=? AND status=? AND changes()=1').bind(next,me.user_id,id,next)]);return send({ok:true});
 }
 return send({error:'NOT_FOUND'},404);
 }catch(e){return send({error:String(e.message||'INVALID_REQUEST')},409);}
}
