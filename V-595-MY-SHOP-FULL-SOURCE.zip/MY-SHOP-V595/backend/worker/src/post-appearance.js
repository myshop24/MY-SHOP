import {normalizeAppearance,appearanceTarget,grantSchema} from './appearance-design.js';
const acl=`EXISTS(SELECT 1 FROM myshop_auth_users_v108 a WHERE a.user_id=? AND a.active=1 AND ((a.user_id IN ('0001','0002','0003') AND a.role='ADMIN') OR EXISTS(SELECT 1 FROM myshop_appearance_grants g WHERE g.user_id=a.user_id AND g.status=1)))`;
export async function preparePostAppearance(env,user,caption,input){
 if(input===undefined)return null;
 const styles=normalizeAppearance(input,appearanceTarget('post_1'));
 for(const part of styles.element_caption?.segments||[])if(part.source!==caption)throw Error('TEXT_SOURCE_CHANGED');
 await grantSchema(env.DB);
 if(!await env.DB.prepare(`SELECT 1 AS allowed WHERE ${acl}`).bind(user.user_id).first())throw Error('APPEARANCE_PERMISSION_REQUIRED');
 return styles;
}
export async function insertStyledPost(env,user,caption,mediaUrl,key,type,styles){
 const payload=JSON.stringify(styles);
 const writes=[env.DB.prepare(`INSERT INTO myshop_posts(user_id,caption,media_url,object_key,media_type,status) SELECT ?,?,?,?,?,'ACTIVE' WHERE ${acl}`).bind(user.user_id,caption,mediaUrl,key,type,user.user_id),
 env.DB.prepare(`INSERT INTO myshop_visual_designs(scope,revision,draft_revision,published,draft,actor_id) SELECT 'appearance:post_'||last_insert_rowid(),1,1,?,?,? WHERE changes()=1`).bind(payload,payload,user.user_id),
 env.DB.prepare(`INSERT INTO myshop_visual_design_events(scope,actor_id,action,revision,old_payload,new_payload) SELECT 'appearance:post_'||(SELECT MAX(id) FROM myshop_posts WHERE user_id=?),?,'PUBLISH',1,'{}',? WHERE changes()=1`).bind(user.user_id,user.user_id,payload)];
 const result=await env.DB.batch(writes);
 if(!Number(result[0]?.meta?.changes))throw Error('APPEARANCE_PERMISSION_CHANGED');
 return result[0];
}
