// Read-only summaries. Limiting display NEVER deletes the financial ledgers.
export function walletSummaryAmounts(row,uid){
 let meta={};try{meta=JSON.parse(row.metadata||'{}')}catch(_){}
 const units=value=>Number.isSafeInteger(Number(value))&&Number(value)>=0?Number(value):0;
 const gross=units(row.gross_amount),received=row.net_amount==null?gross:units(row.net_amount);
 // The stored debit is authoritative: gift fees can be additional, while
 // transfer and withdrawal commissions have different existing contracts.
 const total=meta.totalDebit==null?gross:units(meta.totalDebit);
 const sent=String(row.sender_id)===uid,credited=String(row.receiver_id)===uid;
 const amount=sent?total:credited?received:0;
 const affectsBalance=String(row.status||'COMPLETED')==='COMPLETED'&&!(sent&&row.tx_type==='ADMIN_GRANT');
 return {sender_total:total,receiver_net:received,display_amount:amount,direction:sent?'OUT':'IN',summary_delta:affectsBalance?(sent?-amount:amount):0};
}
export function recentWalletSummaries(ledger,coin,gold,uid){
 const rows=ledger.map(t=>({...t,key:'LEDGER:'+t.id,currency:t.currency==='GOLD_COIN'?'GOLD':t.currency}));
 const matched=new Set();
 for(const [currency,list] of [['COIN',coin],['GOLD',gold]])for(const t of list){
  let meta={};try{meta=JSON.parse(t.metadata||'{}')}catch(_){}
  const signed=Number(t.amount),reference=String(t.reference||'');
  // A transfer/gift commonly writes both ledgers. Use its canonical participants
  // and fees once; consume matches individually so repeated grants remain distinct.
  const index=rows.findIndex((r,i)=>!matched.has(i)&&r.key.startsWith('LEDGER:')&&r.currency===currency&&reference&&r.reference===reference&&r.created_at===t.created_at&&
    (signed<0?r.sender_id===uid&&(walletSummaryAmounts(r,uid).sender_total===-signed||Number(r.gross_amount)+Number(r.vat_amount||0)===-signed):r.receiver_id===uid&&(Number(r.net_amount)===signed||Number(r.gross_amount)===signed)));
  if(index>=0){matched.add(index);continue;}
  const other=String(meta.recipientUserId||meta.receiverId||meta.senderId||meta.admin||meta.removedBy||meta.rejectedBy||meta.destination||meta.source||'MY_SHOP');
  rows.push({key:currency+':'+t.id,tx_type:t.kind,currency,sender_id:signed<0?uid:other,receiver_id:signed<0?other:uid,gross_amount:Math.abs(signed),net_amount:Math.abs(signed),fee_amount:Number(meta.feeAmount||0),vat_amount:Number(meta.vatAmount||0),status:t.status||meta.status||'COMPLETED',reference,created_at:t.created_at});
 }
 const epoch=s=>{const text=String(s||'').replace(' ','T');return Date.parse(/(?:Z|[+-]\d{2}:?\d{2})$/.test(text)?text:text+'Z')||0;};
 return rows.sort((a,b)=>epoch(b.created_at)-epoch(a.created_at)||Number(String(b.key).split(':')[1])-Number(String(a.key).split(':')[1])||a.key.localeCompare(b.key)).slice(0,30).map(row=>({...row,...walletSummaryAmounts(row,uid)}));
}
export async function walletHistory(request,env,h){
 const me=await h.getUser(request,env);if(!me)return h.json({error:'UNAUTHORIZED'},401,h.cors);
 const existing=new Set(((await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name IN ('myshop_value_ledger','myshop_coin_transactions','myshop_gold_transactions')").all()).results||[]).map(t=>t.name));
 const read=async(table,where,args)=>existing.has(table)?(await env.DB.prepare(`SELECT * FROM ${table} WHERE ${where} ORDER BY id DESC LIMIT 30`).bind(...args).all()).results||[]:[];
 const uid=String(me.user_id);
 const [ledger,coin,gold]=await Promise.all([read('myshop_value_ledger','sender_id=? OR receiver_id=?',[uid,uid]),read('myshop_coin_transactions','user_id=?',[uid]),read('myshop_gold_transactions','user_id=?',[uid])]);
 const transactions=recentWalletSummaries(ledger,coin,gold,uid);
 const ids=[...new Set(transactions.flatMap(t=>[t.sender_id,t.receiver_id]).filter(Boolean))];
 const people=ids.length?(await env.DB.prepare(`SELECT user_id,full_name FROM myshop_auth_users_v108 WHERE user_id IN (${ids.map(()=>'?').join(',')})`).bind(...ids).all()).results||[]:[];
 const names=new Map(people.map(p=>[p.user_id,p.full_name]));
 for(const t of transactions){t.sender_name=names.get(t.sender_id)||t.sender_id;t.receiver_name=names.get(t.receiver_id)||t.receiver_id;delete t.metadata;}
 return h.json({ok:true,transactions,displayLimit:30,ledgerRetained:true,readOnly:true},200,h.cors);
}
