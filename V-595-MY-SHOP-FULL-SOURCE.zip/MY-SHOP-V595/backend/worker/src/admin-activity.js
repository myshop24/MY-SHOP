// Admin TV activity reads existing records only. It never bootstraps or mutates
// Live, wallet, authentication, orders or event tables.
export async function adminActivity(request,env,h){
 const fail=(error,status)=>h.json({error},status,h.cors);
 const me=await h.getUser(request,env);if(!me)return fail('UNAUTHORIZED',401);
 const actor=await env.DB.prepare('SELECT active,role FROM myshop_auth_users_v108 WHERE user_id=?').bind(me.user_id).first();
 if(!['0001','0002','0003'].includes(String(me.user_id))||Number(actor?.active)!==1||actor?.role!=='ADMIN')return fail('MAIN_ADMIN_ONLY',403);
 const tables=new Set(((await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table'").all()).results||[]).map(x=>x.name));
 const events=[];
 const append=async(table,sql,kind)=>{if(!tables.has(table))return;for(const row of (await env.DB.prepare(sql).all()).results||[])events.push({...row,kind,key:kind+':'+row.id});};
 await append('myshop_auth_users_v108',"SELECT user_id id,user_id,full_name title,created_at event_at FROM myshop_auth_users_v108 ORDER BY created_at DESC,user_id DESC LIMIT 10",'NEW_USER');
 await append('myshop_value_ledger',"SELECT id,sender_id user_id,receiver_id target_id,tx_type title,currency,gross_amount amount,created_at event_at FROM myshop_value_ledger WHERE status='COMPLETED' AND (tx_type LIKE '%TRANSFER%' OR tx_type LIKE '%GIFT%') ORDER BY id DESC LIMIT 10",'VALUE');
 await append('myshop_store_purchase_requests',"SELECT id,user_id,status title,total_amount amount,created_at event_at FROM myshop_store_purchase_requests ORDER BY id DESC LIMIT 10",'PURCHASE_REQUEST');
 await append('myshop_live_history',"SELECT id,host_id user_id,title,started_at event_at FROM myshop_live_history ORDER BY id DESC LIMIT 10",'LIVE_STARTED');
 const epoch=value=>{const s=String(value||'').replace(' ','T');return Date.parse(/(?:Z|[+-]\d{2}:?\d{2})$/.test(s)?s:s+'Z')||0;};
 events.sort((a,b)=>epoch(b.event_at)-epoch(a.event_at)||String(b.key).localeCompare(String(a.key)));
 return h.json({ok:true,events:events.slice(0,10),refreshSeconds:15,readOnly:true},200,h.cors);
}
