export const featureHistorySchema=`CREATE TABLE IF NOT EXISTS myshop_feature_history(id INTEGER PRIMARY KEY AUTOINCREMENT,feature_id INTEGER NOT NULL,category TEXT NOT NULL,revision INTEGER NOT NULL,actor_id TEXT NOT NULL,action TEXT NOT NULL,old_payload TEXT NOT NULL,new_payload TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`;
const fields=['title','caption','url','icon_url','image_url','active','display_order','price_minor','offer_text','offer_start','offer_end','time_limit_minutes','status','coming_soon_message','archived'];
const names={icon_url:'iconUrl',image_url:'imageUrl',display_order:'displayOrder',price_minor:'priceMinor',offer_text:'offerText',offer_start:'offerStart',offer_end:'offerEnd',time_limit_minutes:'timeLimitMinutes',coming_soon_message:'comingSoonMessage'};
const safeUrl=value=>{if(!value)return true;try{const u=new URL(value);return ['https:','http:'].includes(u.protocol)&&!!u.hostname&&!u.username&&!u.password;}catch(_){return false;}};
export async function writeManagedFeature(DB,actor,input,expectedRevision,action='SAVE',eventId=0,draftRevision=null){
  const fail=(error,statusCode=400)=>({error,statusCode});
  if(!input||typeof input!=='object'||Array.isArray(input)||!Number.isSafeInteger(expectedRevision)||expectedRevision<0||!['SAVE','ARCHIVE','RESTORE','ROLLBACK'].includes(action))return fail('INVALID_FEATURE_CHANGE');
  const id=Number(input.id||0),category=String(input.category||'');
  if(!Number.isSafeInteger(id)||id<0||!/^feature_[a-z0-9_]{1,80}$/.test(category))return fail('INVALID_FEATURE_CATEGORY');
  const old=id?await DB.prepare('SELECT * FROM managed_links WHERE id=? AND category=?').bind(id,category).first():null;
  if(id&&!old)return fail('FEATURE_NOT_FOUND',404);
  if(Number(old?.revision||0)!==expectedRevision)return fail('FEATURE_REVISION_CONFLICT',409);
  let source=input;
  if(action==='ARCHIVE'){if(!old)return fail('SAVE_FEATURE_FIRST',409);source={...old,active:0,status:'DISABLED',archived:1};}
  if(['RESTORE','ROLLBACK'].includes(action)){
    if(!old||!Number.isSafeInteger(eventId)||eventId<1)return fail('INVALID_HISTORY_ITEM');
    const event=await DB.prepare('SELECT * FROM myshop_feature_history WHERE id=? AND feature_id=? AND category=?').bind(eventId,id,category).first();
    if(!event)return fail('HISTORY_NOT_FOUND',404);
    source=JSON.parse(action==='RESTORE'?event.old_payload:event.new_payload);
    if(action==='ROLLBACK')source.id=event.feature_id;
    if(!source?.id)return fail('NO_PREVIOUS_FEATURE',409);
  }
  const next={...(old||{}),id,category};
  for(const field of fields){const v=source[field]??source[names[field]];if(v!==undefined)next[field]=v;}
  for(const [field,max] of [['title',100],['caption',1000],['url',2000],['icon_url',2000],['image_url',2000],['offer_text',160],['offer_start',80],['offer_end',80],['coming_soon_message',500]]){next[field]=String(next[field]??'').trim();if(next[field].length>max)return fail('FEATURE_TEXT_TOO_LONG');}
  if(!next.title)return fail('FEATURE_TITLE_REQUIRED');
  for(const field of ['url','icon_url','image_url'])if(!(field==='icon_url'&&/^emoji:.{1,64}$/u.test(next[field]))&&!safeUrl(next[field]))return fail('INVALID_FEATURE_LINK');
  for(const [field,initial,max] of [['display_order',1,999],['price_minor',0,Number.MAX_SAFE_INTEGER],['time_limit_minutes',0,1000000000]]){next[field]=Number(next[field]??initial);if(!Number.isSafeInteger(next[field])||next[field]<initial||next[field]>max)return fail('INVALID_FEATURE_NUMBER');}
  next.status=String(next.status||'ACTIVE').toUpperCase();if(!['ACTIVE','DISABLED','COMING_SOON','UPCOMING','LAUNCHING_SOON'].includes(next.status))return fail('INVALID_FEATURE_STATUS');
  next.archived=action==='ARCHIVE'?1:Number(next.archived||0);next.active=next.active===false||Number(next.active)===0?0:1;
  if(next.archived||next.status==='DISABLED')next.active=0;
  next.revision=expectedRevision+1;
  let acl="EXISTS(SELECT 1 FROM myshop_auth_users_v108 a WHERE a.user_id=? AND a.active=1 AND (a.role='ADMIN' OR a.user_id IN ('0001','0002','0003')))";
  if(draftRevision!==null){if(!Number.isSafeInteger(draftRevision)||draftRevision<1)return fail('INVALID_DRAFT_REVISION');acl+=` AND EXISTS(SELECT 1 FROM myshop_feature_drafts WHERE category='${category}' AND revision=${draftRevision})`;}
  let write;
  if(old)write=DB.prepare(`UPDATE managed_links SET ${fields.map(f=>f+'=?').join(',')},revision=revision+1,updated_at=CURRENT_TIMESTAMP WHERE id=? AND category=? AND revision=? AND ${acl}`).bind(...fields.map(f=>next[f]),id,category,expectedRevision,actor);
  else{
    const exists=await DB.prepare('SELECT id FROM managed_links WHERE category=? LIMIT 1').bind(category).first();if(exists)return fail('FEATURE_ALREADY_EXISTS',409);
    write=DB.prepare(`INSERT INTO managed_links(category,${fields.join(',')},revision) SELECT ?,${fields.map(()=>'?').join(',')},1 WHERE ${acl} AND NOT EXISTS(SELECT 1 FROM managed_links WHERE category=?)`).bind(category,...fields.map(f=>next[f]),actor,category);
  }
  const results=await DB.batch([write,DB.prepare(`INSERT INTO myshop_feature_history(feature_id,category,revision,actor_id,action,old_payload,new_payload) SELECT ${old?'?':'last_insert_rowid()'},?,?,?,?,?,${old?'?':"json_set(?, '$.id', last_insert_rowid())"} WHERE changes()=1`).bind(...(old?[id]:[]),category,next.revision,actor,action,JSON.stringify(old||{}),JSON.stringify(next))]);
  if(!Number(results[0]?.meta?.changes||0))return fail('FEATURE_REVISION_OR_PERMISSION_CHANGED',409);
  const saved=await DB.prepare('SELECT * FROM managed_links WHERE category=? AND id=?').bind(category,old?id:Number(results[0].meta.last_row_id)).first();
  return {ok:true,feature:saved,revision:next.revision};
}
export async function featureHistory(request,env,h){
  const authorization=await h.adminOnly(request,env);if(authorization.error)return authorization.error;
  const me=authorization.user||await h.getUser(request,env),url=new URL(request.url),category=url.searchParams.get('category')||'';
  if(!/^feature_[a-z0-9_]{1,80}$/.test(category))return h.json({error:'INVALID_FEATURE_CATEGORY'},400,h.cors);
  await env.DB.prepare(featureHistorySchema).run();
  if(request.method==='GET'){
    const feature=await env.DB.prepare('SELECT * FROM managed_links WHERE category=? ORDER BY display_order,id LIMIT 1').bind(category).first();
    const history=feature?(await env.DB.prepare('SELECT id,revision,actor_id,action,created_at FROM myshop_feature_history WHERE feature_id=? AND category=? ORDER BY id DESC LIMIT 50').bind(feature.id,category).all()).results||[]:[];
    let legacyPresentation=null;
    if(/^feature_home1_[a-z0-9_]+$/.test(category)&&!/(?:^|_)(?:live|rtc|audio|gift|gifts|room)(?:_|$)/.test(category)){
      const exists=await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='feature_buttons'").first();
      if(exists)legacyPresentation=await env.DB.prepare('SELECT key,title,icon_url,target_url,active,display_order,icon_size FROM feature_buttons WHERE key=?').bind(category.slice(8)).first();
    }
    return h.json({ok:true,feature,revision:Number(feature?.revision||0),history,legacyPresentation},200,h.cors);
  }
  if(request.method!=='POST')return h.json({error:'METHOD_NOT_ALLOWED'},405,h.cors);
  let body;try{body=await request.json();}catch(_){return h.json({error:'INVALID_JSON'},400,h.cors);}
  if(!body||typeof body!=='object'||Array.isArray(body)||body.config?.category!==category)return h.json({error:'INVALID_FEATURE_CHANGE'},400,h.cors);
  const protectedLive=/(?:^|_)(?:live|rtc|audio|gift|gifts|room)(?:_|$)/.test(category)||['feature_go_live','feature_top_gifters'].includes(category);
  if(!protectedLive&&(body.action||'SAVE')==='SAVE')return h.json({error:'PRIVATE_DRAFT_AND_EXPLICIT_PUBLISH_REQUIRED'},409,h.cors);
  if(!protectedLive&&!['0001','0002','0003'].includes(String(me.user_id)))return h.json({error:'OWNER_PERMISSION_REQUIRED'},403,h.cors);
  if(body.action==='PERMANENT_DELETE'){
    if(!['0001','0002','0003'].includes(String(me.user_id)))return h.json({error:'OWNER_PERMISSION_REQUIRED'},403,h.cors);
    if(/(?:live|rtc|audio|room|gift|wallet|coin|gold|withdraw|payment|order|membership|profile)/.test(category))return h.json({error:'PROTECTED_DEPENDENCY'},409,h.cors);
    const id=Number(body.config.id),reason=String(body.reason||'').trim();
    if(body.confirm!==true||reason.length<5||reason.length>500||!Number.isSafeInteger(id)||id<1||!Number.isSafeInteger(body.expectedRevision))return h.json({error:'CONFIRMATION_AND_REASON_REQUIRED'},400,h.cors);
    const old=await env.DB.prepare('SELECT * FROM managed_links WHERE id=? AND category=?').bind(id,category).first();
    if(!old)return h.json({error:'FEATURE_NOT_FOUND'},404,h.cors);
    if(Number(old.archived)!==1||Number(old.active)!==0)return h.json({error:'ARCHIVE_FEATURE_FIRST'},409,h.cors);
    const acl="EXISTS(SELECT 1 FROM myshop_auth_users_v108 WHERE user_id=? AND active=1 AND user_id IN ('0001','0002','0003'))";
    const writes=[
      env.DB.prepare(`INSERT INTO myshop_feature_history(feature_id,category,revision,actor_id,action,old_payload,new_payload) SELECT id,category,revision+1,?,'PERMANENT_DELETE',?,? FROM managed_links WHERE id=? AND category=? AND revision=? AND archived=1 AND active=0 AND ${acl}`).bind(me.user_id,JSON.stringify(old),JSON.stringify({reason,deleted:true}),id,category,body.expectedRevision,me.user_id),
      env.DB.prepare('DELETE FROM managed_links WHERE id=? AND category=? AND revision=? AND changes()=1').bind(id,category,body.expectedRevision)
    ];
    // Keep the deleted fixed slot hidden on reload rather than resurrecting its
    // built-in default when the owning managed feature is permanently removed.
    const icons=category.startsWith('feature_home1_')?await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='feature_buttons'").first():null;
    if(icons)writes.push(env.DB.prepare("UPDATE feature_buttons SET active=0,title='Deleted',icon_url='',target_url='',updated_at=CURRENT_TIMESTAMP WHERE key=? AND changes()=1").bind(category.slice(8)));
    const drafts=await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='myshop_feature_drafts'").first();
    if(drafts)writes.push(env.DB.prepare("DELETE FROM myshop_feature_drafts WHERE category=? AND NOT EXISTS(SELECT 1 FROM managed_links WHERE id=? AND category=?) AND EXISTS(SELECT 1 FROM myshop_feature_history WHERE feature_id=? AND category=? AND revision=? AND actor_id=? AND action='PERMANENT_DELETE')").bind(category,id,category,id,category,body.expectedRevision+1,me.user_id));
    const results=await env.DB.batch(writes);
    if(!Number(results[1]?.meta?.changes))return h.json({error:'REVISION_OR_PERMISSION_CHANGED'},409,h.cors);
    return h.json({ok:true,deleted:true,auditRetained:true,financialDataUnchanged:true},200,h.cors);
  }
  const result=await writeManagedFeature(env.DB,me.user_id,body.config,body.expectedRevision,body.action||'SAVE',body.eventId||0);
  return h.json(result,result.error?result.statusCode:200,h.cors);
}
