// Read the published managed feature. Draft settings cannot lock users out.
export async function featureAccess(request,env,h){
 const me=await h.getUser(request,env);if(!me)return h.json({error:'UNAUTHORIZED'},401,h.cors);
 const key=String(new URL(request.url).searchParams.get('key')||'');
 if(!/^[a-z0-9_]{1,80}$/.test(key))return h.json({error:'INVALID_FEATURE_KEY'},400,h.cors);
 const short=key.startsWith('home1_')?key.slice(6):key;
 const aliases=[...new Set(['feature_'+key,'feature_'+short,key])];
 const row=await env.DB.prepare(`SELECT category,title,active,status,archived,coming_soon_message FROM managed_links WHERE category IN (${aliases.map(()=>'?').join(',')}) ORDER BY CASE WHEN category=? THEN 0 WHEN category=? THEN 1 ELSE 2 END,id DESC LIMIT 1`).bind(...aliases,'feature_'+key,'feature_'+short).first();
 if(!row)return h.json({ok:true,configured:false,allowed:true},200,h.cors);
 const allowed=Number(row.active)===1&&Number(row.archived||0)===0&&String(row.status||'ACTIVE').toUpperCase()==='ACTIVE';
 return h.json({ok:true,configured:true,allowed,status:row.status||'ACTIVE',title:row.title,message:allowed?'':String(row.coming_soon_message||'').trim()||'Coming Soon — এই ফিচারটি এখনও চালু হয়নি।'},200,h.cors);
}
