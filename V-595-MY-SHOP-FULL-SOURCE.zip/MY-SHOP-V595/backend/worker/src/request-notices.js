export async function ensureRequestNotices(db){
 await db.prepare(`CREATE TABLE IF NOT EXISTS myshop_request_notices(event_key TEXT PRIMARY KEY,kind TEXT NOT NULL,request_id TEXT NOT NULL,user_id TEXT NOT NULL,message TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,whatsapp_status TEXT NOT NULL DEFAULT 'PENDING',whatsapp_error TEXT NOT NULL DEFAULT '')`).run();
 for(const [table,kind,id] of [['myshop_creator_withdraw_requests','WITHDRAW','NEW.id'],['myshop_store_purchase_requests','PREMIUM','NEW.id'],['shop_orders','ORDER','NEW.id']]){
  const exists=await db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").bind(table).first();if(!exists)continue;
  await db.prepare(`CREATE TRIGGER IF NOT EXISTS myshop_notice_${kind.toLowerCase()} AFTER INSERT ON ${table} BEGIN INSERT OR IGNORE INTO myshop_request_notices(event_key,kind,request_id,user_id,message) VALUES('${kind}:'||${id},'${kind}',${id},NEW.user_id,'MY SHOP ${kind} request #'||${id}||' • ID '||NEW.user_id); END`).run();
 }
 for(const [table,kind,owner] of [['myshop_coin_purchase_requests','COIN_PURCHASE','user_id'],['myshop_wallet_purchase_requests','WALLET_PURCHASE','user_id'],['myshop_support_tickets','SUPPORT','user_id'],['myshop_safety_reports','REPORT','reporter_id'],['myshop_account_deletion_requests','ACCOUNT_DELETE','user_id']]){
  const exists=await db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").bind(table).first();if(!exists)continue;
  await db.prepare(`CREATE TRIGGER IF NOT EXISTS myshop_folder_notice_${kind.toLowerCase()} AFTER INSERT ON ${table} BEGIN INSERT OR IGNORE INTO myshop_request_notices(event_key,kind,request_id,user_id,message,whatsapp_status) VALUES('${kind}:'||NEW.id,'${kind}',NEW.id,NEW.${owner},'MY SHOP ${kind} request #'||NEW.id||' • ID '||NEW.${owner},'NOT_REQUESTED'); END`).run();
  await db.prepare(`INSERT OR IGNORE INTO myshop_request_notices(event_key,kind,request_id,user_id,message,created_at,whatsapp_status) SELECT '${kind}:'||id,'${kind}',id,${owner},'MY SHOP ${kind} request #'||id||' • ID '||${owner},created_at,'NOT_REQUESTED' FROM ${table} WHERE status IN ('PENDING','OPEN','WAITING_USER')`).run();
 }
 await db.prepare(`CREATE TABLE IF NOT EXISTS myshop_request_notice_reads(admin_id TEXT PRIMARY KEY,last_seen TEXT NOT NULL)`).run();
}
export async function ensureFolderNoticeReads(db){
 await db.prepare(`CREATE TABLE IF NOT EXISTS myshop_folder_notice_migration(admin_id TEXT PRIMARY KEY)`).run();
 await db.prepare(`CREATE TABLE IF NOT EXISTS myshop_folder_notice_reads(admin_id TEXT NOT NULL,event_key TEXT NOT NULL,PRIMARY KEY(admin_id,event_key))`).run();
}
export async function folderRequestNotices(request,env,h){
 const a=await h.adminOnly(request,env);if(a.error)return a.error;const me=await h.getUser(request,env);await ensureRequestNotices(env.DB);await ensureFolderNoticeReads(env.DB);
 const migrated=await env.DB.prepare(`SELECT 1 x FROM myshop_folder_notice_migration WHERE admin_id=?`).bind(me.user_id).first();if(!migrated)await env.DB.batch([env.DB.prepare(`INSERT OR IGNORE INTO myshop_folder_notice_reads(admin_id,event_key) SELECT ?,n.event_key FROM myshop_request_notices n JOIN myshop_request_notice_reads old ON old.admin_id=? WHERE datetime(n.created_at)<=datetime(old.last_seen)`).bind(me.user_id,me.user_id),env.DB.prepare(`INSERT OR IGNORE INTO myshop_folder_notice_migration(admin_id) VALUES(?)`).bind(me.user_id)]);
 const scope=new URL(request.url).searchParams.get('kind')||'ALL';if(!['ALL','SHOP','WITHDRAW','PREMIUM','ORDER','COIN_PURCHASE','WALLET_PURCHASE','SUPPORT','REPORT','ACCOUNT_DELETE','NONE'].includes(scope)&&!/^PREMIUM_[A-Z_]{1,40}$/.test(scope))return h.json({error:'INVALID_FOLDER'},400,h.cors);
 if(request.method==='POST'){const b=await request.json();if(typeof b.eventKey!=='string')return h.json({error:'INVALID_EVENT'},400,h.cors);await env.DB.prepare(`INSERT OR IGNORE INTO myshop_folder_notice_reads(admin_id,event_key) SELECT ?,event_key FROM myshop_request_notices WHERE event_key=?`).bind(me.user_id,b.eventKey).run();}
 const rows=(await env.DB.prepare(`SELECT n.*,COALESCE(u.full_name,'') name,COALESCE(u.avatar_url,'') avatar_url,CASE WHEN r.event_key IS NULL THEN 0 ELSE 1 END is_read FROM myshop_request_notices n LEFT JOIN myshop_auth_users_v108 u ON u.user_id=n.user_id LEFT JOIN myshop_folder_notice_reads r ON r.admin_id=? AND r.event_key=n.event_key WHERE (?='ALL' OR n.kind=? OR (?='SHOP' AND n.kind IN ('PREMIUM','ORDER'))) ORDER BY n.created_at DESC,n.event_key DESC LIMIT 200`).bind(me.user_id,scope.startsWith('PREMIUM_')?'PREMIUM':scope,scope.startsWith('PREMIUM_')?'PREMIUM':scope,scope).all()).results||[];
 // Read-only snapshots: notification viewing never changes a request or wallet.
 for(const [kind,table] of [['WITHDRAW','myshop_creator_withdraw_requests'],['PREMIUM','myshop_store_purchase_requests'],['ORDER','shop_orders'],['COIN_PURCHASE','myshop_coin_purchase_requests'],['WALLET_PURCHASE','myshop_wallet_purchase_requests'],['SUPPORT','myshop_support_tickets'],['REPORT','myshop_safety_reports'],['ACCOUNT_DELETE','myshop_account_deletion_requests']]){
  const ids=rows.filter(x=>x.kind===kind).map(x=>x.request_id);if(!ids.length)continue;
  const exists=await env.DB.prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name=?`).bind(table).first();if(!exists)continue;
  const marks=ids.map(()=>'?').join(',');
  const query=kind==='PREMIUM'?`SELECT r.*,c.title,c.item_type,c.preview_url FROM myshop_store_purchase_requests r LEFT JOIN myshop_store_catalog c ON c.id=r.catalog_id WHERE r.id IN (${marks})`:`SELECT * FROM ${table} WHERE id IN (${marks})`;
  const details=(await env.DB.prepare(query).bind(...ids).all()).results||[];
  for(const n of rows.filter(x=>x.kind===kind)){const d=details.find(x=>String(x.id)===n.request_id);if(!d)continue;n.request_status=d.status;n.item_title=d.title||d.subject||d.reason||d.item_code||'';n.item_type=d.item_type||kind;n.image_url=d.preview_url||'';n.folder_kind=kind==='PREMIUM'?'PREMIUM_'+String(d.item_type||'UNKNOWN').toUpperCase():kind;n.amount=kind==='WITHDRAW'?Number(d.gross_units):kind==='PREMIUM'?Number(d.total_amount):null;n.currency=kind==='WITHDRAW'?d.currency:kind==='PREMIUM'?d.payment_mode:'';}
 }
 const counts=(await env.DB.prepare(`SELECT n.kind,COUNT(*) unread FROM myshop_request_notices n LEFT JOIN myshop_folder_notice_reads r ON r.admin_id=? AND r.event_key=n.event_key WHERE r.event_key IS NULL GROUP BY n.kind`).bind(me.user_id).all()).results||[];
 const typed=(await env.DB.prepare(`SELECT 'PREMIUM_'||UPPER(COALESCE(c.item_type,'UNKNOWN')) kind,COUNT(*) unread FROM myshop_request_notices n JOIN myshop_store_purchase_requests p ON CAST(p.id AS TEXT)=n.request_id JOIN myshop_store_catalog c ON c.id=p.catalog_id LEFT JOIN myshop_folder_notice_reads r ON r.admin_id=? AND r.event_key=n.event_key WHERE n.kind='PREMIUM' AND r.event_key IS NULL GROUP BY UPPER(COALESCE(c.item_type,'UNKNOWN'))`).bind(me.user_id).all()).results||[];
 const pendingCounts=[];
 for(const [kind,table] of [['WITHDRAW','myshop_creator_withdraw_requests'],['PREMIUM','myshop_store_purchase_requests'],['ORDER','shop_orders'],['SUPPORT','myshop_support_tickets'],['REPORT','myshop_safety_reports'],['COIN_PURCHASE','myshop_coin_purchase_requests'],['WALLET_PURCHASE','myshop_wallet_purchase_requests'],['ACCOUNT_DELETE','myshop_account_deletion_requests']]){
  const exists=await env.DB.prepare(`SELECT name FROM sqlite_master WHERE type='table' AND name=?`).bind(table).first();if(!exists)continue;
  const q=await env.DB.prepare(`SELECT COUNT(*) pending FROM ${table} WHERE UPPER(COALESCE(status,'')) NOT IN ('PAID','COMPLETED','REJECTED','CANCELLED','CLOSED','RESOLVED','DISMISSED','DELIVERED')`).first();pendingCounts.push({kind,pending:Number(q?.pending||0)});
 }
 const premiumPending=(await env.DB.prepare(`SELECT 'PREMIUM_'||UPPER(COALESCE(c.item_type,'UNKNOWN')) kind,COUNT(*) pending FROM myshop_store_purchase_requests p JOIN myshop_store_catalog c ON c.id=p.catalog_id WHERE UPPER(COALESCE(p.status,'')) NOT IN ('PAID','COMPLETED','REJECTED','CANCELLED','CLOSED','RESOLVED','DISMISSED','DELIVERED') GROUP BY UPPER(COALESCE(c.item_type,'UNKNOWN'))`).all()).results||[];
 pendingCounts.push(...premiumPending.map(x=>({kind:x.kind,pending:Number(x.pending||0)})));
 return h.json({ok:true,notices:scope.startsWith('PREMIUM_')?rows.filter(x=>x.folder_kind===scope):rows,counts:[...counts,...typed],pendingCounts,unread:counts.reduce((n,x)=>n+Number(x.unread),0)},200,h.cors);
}
export async function requestNotices(request,env,h){
 const a=await h.adminOnly(request,env);if(a.error)return a.error;await ensureRequestNotices(env.DB);const me=await h.getUser(request,env);
 if(request.method==='POST'){await env.DB.prepare('INSERT INTO myshop_request_notice_reads(admin_id,last_seen) VALUES(?,CURRENT_TIMESTAMP) ON CONFLICT(admin_id) DO UPDATE SET last_seen=CURRENT_TIMESTAMP').bind(me.user_id).run();return h.json({ok:true},200,h.cors);}
 if(request.method!=='GET')return h.json({error:'METHOD_NOT_ALLOWED'},405,h.cors);
 const list=(await env.DB.prepare('SELECT event_key,kind,request_id,user_id,message,created_at,whatsapp_status,whatsapp_error FROM myshop_request_notices ORDER BY created_at DESC,event_key DESC LIMIT 200').all()).results||[];
 const n=await env.DB.prepare("SELECT COUNT(*) n FROM myshop_request_notices WHERE datetime(created_at)>COALESCE((SELECT datetime(last_seen) FROM myshop_request_notice_reads WHERE admin_id=?),'1970-01-01')").bind(me.user_id).first();
 return h.json({ok:true,notices:list,unread:Number(n?.n||0),whatsappConfigured:whatsappConfigured(env),whatsappStatus:whatsappConfigured(env)?'READY':'SETUP_REQUIRED'},200,h.cors);
}
export function whatsappConfigured(env){return !!(env.MYSHOP_WHATSAPP_TOKEN&&/^\d{5,30}$/.test(env.MYSHOP_WHATSAPP_PHONE_ID||'')&&/^\d{8,15}$/.test(env.MYSHOP_WHATSAPP_ADMIN_NUMBER||'')&&/^v\d+\.\d+$/.test(env.MYSHOP_WHATSAPP_GRAPH_VERSION||'')&&/^[a-z0-9_]{1,100}$/.test(env.MYSHOP_WHATSAPP_TEMPLATE||'')&&env.MYSHOP_WHATSAPP_TEMPLATE_LANGUAGE);}
export async function dispatchRequestNotices(env){
 if(!whatsappConfigured(env))return;await ensureRequestNotices(env.DB);
 const rows=(await env.DB.prepare("SELECT event_key,message FROM myshop_request_notices WHERE whatsapp_status='PENDING' ORDER BY created_at LIMIT 20").all()).results||[];
 for(const r of rows){
  const claim=await env.DB.prepare("UPDATE myshop_request_notices SET whatsapp_status='SENDING' WHERE event_key=? AND whatsapp_status='PENDING'").bind(r.event_key).run();if(!claim.meta?.changes)continue;
  try{
   const response=await fetch(`https://graph.facebook.com/${env.MYSHOP_WHATSAPP_GRAPH_VERSION}/${env.MYSHOP_WHATSAPP_PHONE_ID}/messages`,{method:'POST',headers:{authorization:'Bearer '+env.MYSHOP_WHATSAPP_TOKEN,'content-type':'application/json'},body:JSON.stringify({messaging_product:'whatsapp',to:env.MYSHOP_WHATSAPP_ADMIN_NUMBER,type:'template',template:{name:env.MYSHOP_WHATSAPP_TEMPLATE,language:{code:env.MYSHOP_WHATSAPP_TEMPLATE_LANGUAGE},components:[{type:'body',parameters:[{type:'text',text:r.message}]}]}}),signal:AbortSignal.timeout(15000)});
   const data=await response.json().catch(()=>({}));if(!response.ok||!data.messages?.[0]?.id)throw Error('WHATSAPP_API_'+response.status);
   await env.DB.prepare("UPDATE myshop_request_notices SET whatsapp_status='ACCEPTED',whatsapp_error='' WHERE event_key=? AND whatsapp_status='SENDING'").bind(r.event_key).run();
  }catch(e){await env.DB.prepare("UPDATE myshop_request_notices SET whatsapp_status='REVIEW_REQUIRED',whatsapp_error=? WHERE event_key=? AND whatsapp_status='SENDING'").bind(String(e.message).slice(0,120),r.event_key).run();}
 }
}
