// Home icon presentation reads the same published record as its click gate.
// Live-related keys, other pages, and unconfigured legacy icons stay byte-for-byte
// equivalent. Position/size are still saved by the existing icon order endpoint.
export function homeFeaturePresentation(buttons,managed){
 return buttons.map(button=>{
  const key=String(button.key||'');
  if(!/^home1_[a-z0-9_]+$/.test(key)||/(?:^|_)(?:live|rtc|audio|gift|gifts|room)(?:_|$)/.test(key))return button;
  const category='feature_'+key;
  const direct=managed.filter(x=>x.category===category).sort((a,b)=>Number(b.id)-Number(a.id))[0];
  const canonical=direct||managed.filter(x=>x.category==='feature_'+key.slice(6)).sort((a,b)=>Number(b.id)-Number(a.id))[0];
  if(!canonical)return button;
  return {...button,title:canonical.title,icon_url:canonical.image_url||canonical.icon_url||'',target_url:canonical.url||'',active:Number(button.active)===1&&Number(canonical.active)===1&&!Number(canonical.archived||0)?1:0,canonical_feature:true};
 });
}
