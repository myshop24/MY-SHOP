// Owner-approved scope: remove a selected restriction; never enable a microphone.
export async function adminModerationOverride(request,env,h){
 const fail=(error,status=400)=>h.json({error},status,h.cors);
 const me=await h.getUser(request,env);if(!me)return fail('UNAUTHORIZED',401);
 const role=await env.DB.prepare('SELECT active,role FROM myshop_auth_users_v108 WHERE user_id=?').bind(me.user_id).first();
 if(!['0001','0002','0003'].includes(String(me.user_id))||Number(role?.active)!==1||role?.role!=='ADMIN')return fail('MAIN_ADMIN_ONLY',403);
 if(request.method!=='POST')return fail('METHOD_NOT_ALLOWED',405);
 const b=await request.json().catch(()=>null);if(!b)return fail('INVALID_JSON');
 const host=String(b.hostId||''),target=String(b.userId||''),action=String(b.action||''),key=String(b.requestKey||''),reason=String(b.reason||'').trim(),stamp=String(b.expectedAt||'');
 if(!/^\d{4}$/.test(host)||!/^\d{4}$/.test(target)||host===target||!['UNBLOCK','UNMUTE'].includes(action)||!/^[-a-zA-Z0-9_]{16,80}$/.test(key)||!reason||reason.length>300||!stamp||b.confirm!==true)return fail('INVALID_CONFIRMED_ACTION');
 await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_admin_moderation_actions(request_key TEXT PRIMARY KEY,actor_id TEXT NOT NULL,host_id TEXT NOT NULL,target_id TEXT NOT NULL,action TEXT NOT NULL,reason TEXT NOT NULL,expected_at TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
 const previous=await env.DB.prepare('SELECT * FROM myshop_admin_moderation_actions WHERE request_key=?').bind(key).first();
 const reply=async duplicate=>{await h.liveHubDirtyForHost(env,host,'MAIN_ADMIN_'+action);return h.json({ok:true,action,hostId:host,userId:target,alreadyApplied:duplicate,microphoneEnabled:false},200,h.cors);};
 const same=r=>r.actor_id===String(me.user_id)&&r.host_id===host&&r.target_id===target&&r.action===action&&r.reason===reason&&r.expected_at===stamp;
 if(previous)return same(previous)?reply(true):fail('REQUEST_KEY_CONFLICT',409);
 const tables=new Set(((await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table'").all()).results||[]).map(r=>r.name));
 const table=action==='UNBLOCK'?'myshop_user_blocks':'myshop_live_mute_records';if(!tables.has(table))return fail('RESTRICTION_NOT_FOUND',404);
 const condition=action==='UNBLOCK'?'blocker_id=? AND blocked_id=? AND created_at=?':'host_id=? AND user_id=? AND updated_at=?';
 const record=await env.DB.prepare(`SELECT 1 found FROM ${table} WHERE ${condition}`).bind(host,target,stamp).first();if(!record)return fail('RESTRICTION_CHANGED_RELOAD',409);
 const guarded=`EXISTS(SELECT 1 FROM myshop_admin_moderation_actions WHERE request_key=? AND actor_id=? AND host_id=? AND target_id=? AND action=?)`;
 const guardArgs=[key,String(me.user_id),host,target,action];
 const writes=[
  env.DB.prepare(`INSERT INTO myshop_admin_moderation_actions(request_key,actor_id,host_id,target_id,action,reason,expected_at) SELECT ?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM ${table} WHERE ${condition})`).bind(key,String(me.user_id),host,target,action,reason,stamp,host,target,stamp),
  env.DB.prepare(`DELETE FROM ${table} WHERE ${condition} AND ${guarded}`).bind(host,target,stamp,...guardArgs)
 ];
 if(tables.has('myshop_live_sanctions'))writes.push(env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state=? AND ${guarded}`).bind(host,target,action==='UNBLOCK'?'BLOCKED':'MUTED',...guardArgs));
 if(action==='UNMUTE'&&tables.has('myshop_live_seats_dynamic'))writes.push(env.DB.prepare(`UPDATE myshop_live_seats_dynamic SET muted=0,speaking=0,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND seat_no>1 AND ${guarded}`).bind(host,target,...guardArgs));
 if(tables.has('myshop_live_moderation_audit'))writes.push(env.DB.prepare(`INSERT INTO myshop_live_moderation_audit(host_id,actor_id,target_id,action,reason) SELECT ?,?,?,?,? WHERE ${guarded}`).bind(host,String(me.user_id),target,'MAIN_ADMIN_'+action,reason,...guardArgs));
 try{const result=await env.DB.batch(writes);if(!result[0]?.meta?.changes)return fail('RESTRICTION_CHANGED_RELOAD',409);}
 catch(_){const row=await env.DB.prepare('SELECT * FROM myshop_admin_moderation_actions WHERE request_key=?').bind(key).first();if(row&&same(row))return reply(true);return fail('ACTION_NOT_APPLIED_RELOAD',409);}
 return reply(false);
}
