// Private operation keys make retries return the same withdrawal, without another hold or ledger row.
export const withdrawalOperationSchema = `CREATE TABLE IF NOT EXISTS myshop_withdraw_operations(user_id TEXT NOT NULL,request_key TEXT NOT NULL,fingerprint TEXT NOT NULL,request_id INTEGER NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,request_key))`;
export async function createWithdrawal(DB, data) {
  await DB.prepare(withdrawalOperationSchema).run();
  await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_withdraw_terms(request_id INTEGER PRIMARY KEY,payload TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  const key=data.requestKey || crypto.randomUUID(); // Legacy clients retain their original request contract.
  if(!/^[A-Za-z0-9_-]{16,100}$/.test(key))return {error:'INVALID_REQUEST_KEY',statusCode:400};
  const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify([data.currency,data.requestedAmount??data.gross,data.method,data.account,data.note])));
  const fingerprint=Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('');
  const read=()=>DB.prepare(`SELECT o.fingerprint,r.* FROM myshop_withdraw_operations o JOIN myshop_creator_withdraw_requests r ON r.id=o.request_id WHERE o.user_id=? AND o.request_key=?`).bind(data.uid,key).first();
  const existing=await read();
  if(existing)return existing.fingerprint===fingerprint?{row:existing,alreadyApplied:true}:{error:'REQUEST_KEY_CONFLICT',statusCode:409};
  await DB.batch([
    DB.prepare(`INSERT INTO myshop_creator_withdraw_requests(user_id,currency,gross_units,service_fee_percent,service_fee_units,net_units,cash_minor,payment_method,account,note,status) SELECT ?,?,?,?,?,?,?,?,?,?,'PENDING' WHERE NOT EXISTS(SELECT 1 FROM myshop_withdraw_operations WHERE user_id=? AND request_key=?)`).bind(data.uid,data.currency,data.gross,data.rate,data.fee,data.net,data.cashMinor,data.method,data.account,data.note,data.uid,key),
    DB.prepare(`INSERT INTO myshop_withdraw_operations(user_id,request_key,fingerprint,request_id) SELECT ?,?,?,last_insert_rowid() WHERE changes()=1`).bind(data.uid,key,fingerprint),
    DB.prepare(`INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,gross_amount,fee_percent,fee_amount,net_amount,platform_amount,status,reference,metadata) SELECT 'CREATOR_WITHDRAW_REQUEST',?,?,?,?,?,?,?,?,'PENDING','MYSHOP_PAYOUT',? WHERE changes()=1`).bind(data.currency,data.uid,'WITHDRAWAL',data.gross,data.rate,data.fee,data.net,data.fee,JSON.stringify({cashMinor:data.cashMinor,method:data.method})),
    DB.prepare(`INSERT OR IGNORE INTO myshop_withdraw_terms(request_id,payload) SELECT request_id,? FROM myshop_withdraw_operations WHERE user_id=? AND request_key=?`).bind(JSON.stringify(data.termsSnapshot||{}),data.uid,key)
  ]);
  const row=await read();
  if(!row)throw new Error('WITHDRAW_OPERATION_NOT_RECORDED');
  return row.fingerprint===fingerprint?{row}:{error:'REQUEST_KEY_CONFLICT',statusCode:409};
}
