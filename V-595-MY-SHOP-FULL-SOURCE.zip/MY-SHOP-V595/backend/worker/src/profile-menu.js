// Compact Profile drawer only. Existing Live/legacy drawer and routes are unchanged.
export const profileMenuKeys=['home','new_hub','my_feed','myshop','categories','orders','cart','gallery','external','earn','history','website','profile_actions','notifications','reduce_animation','support','social','share','language','about'];
export function normalizeProfileMenu(rows){
 if(!Array.isArray(rows)||rows.length!==profileMenuKeys.length)throw Error('COMPLETE_MENU_REQUIRED');const seen=new Set(),orders=new Set();return rows.map(row=>{
  if(!row||typeof row!=='object'||Array.isArray(row)||Object.keys(row).some(k=>!['key','title','iconUrl','visible','order'].includes(k)))throw Error('INVALID_MENU_ITEM');
  if(!profileMenuKeys.includes(row.key)||seen.has(row.key))throw Error('INVALID_OR_DUPLICATE_MENU_KEY');seen.add(row.key);
  if(typeof row.title!=='string'||!row.title.trim()||row.title.trim().length>60||/[\u0000-\u001f]/.test(row.title))throw Error('INVALID_MENU_TITLE');
  if(typeof row.visible!=='boolean'||!Number.isSafeInteger(row.order)||row.order<0||row.order>=profileMenuKeys.length||orders.has(row.order))throw Error('INVALID_MENU_POSITION');orders.add(row.order);
  const iconUrl=String(row.iconUrl||'').trim();if(iconUrl){let u;try{u=new URL(iconUrl);}catch(_){throw Error('INVALID_MENU_ICON');}if(u.protocol!=='https:'||u.username||u.password||iconUrl.length>2000||!u.hostname||!(/\.(?:png|webp|jpe?g)$/i.test(u.pathname)))throw Error('INVALID_MENU_ICON');}
  return {key:row.key,title:row.title.trim(),iconUrl,visible:row.visible,order:row.order};
 }).sort((a,b)=>a.order-b.order);
}
export async function profileMenu(request,env,h){
 const fail=(error,status=400)=>h.json({error},status,h.cors),me=await h.getUser(request,env);if(!me)return fail('UNAUTHORIZED',401);
 const u=await env.DB.prepare('SELECT active FROM myshop_auth_users_v108 WHERE user_id=?').bind(me.user_id).first();if(!u||Number(u.active)!==1)return fail('UNAUTHORIZED',401);
 const admin=new URL(request.url).pathname.startsWith('/v1/admin/');if(admin&&!['0001','0002','0003'].includes(String(me.user_id)))return fail('OWNER_MENU_PERMISSION_REQUIRED',403);
 if(request.method!=='GET'&&(request.method!=='POST'||!admin))return fail('METHOD_NOT_ALLOWED',405);
 await env.DB.prepare("CREATE TABLE IF NOT EXISTS myshop_profile_menu(id INTEGER PRIMARY KEY CHECK(id=1),revision INTEGER NOT NULL DEFAULT 0,draft_revision INTEGER NOT NULL DEFAULT 0,published TEXT NOT NULL DEFAULT '[]',draft TEXT NOT NULL DEFAULT '[]',actor_id TEXT,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)").run();
 const old=await env.DB.prepare('SELECT * FROM myshop_profile_menu WHERE id=1').first();
 const result=row=>({ok:true,revision:Number(row?.revision||0),items:JSON.parse(row?.published||'[]'),...(admin?{draftRevision:Number(row?.draft_revision||0),draft:JSON.parse(row?.draft||'[]')}: {})});
 if(request.method==='GET'){
  const query=new URL(request.url);
  if(query.searchParams.get('history')==='1'){
   if(!admin)return fail('OWNER_MENU_PERMISSION_REQUIRED',403);
   const after=Number(query.searchParams.get('before')||0);if(!Number.isSafeInteger(after)||after<0)return fail('INVALID_HISTORY_CURSOR');
   const exists=await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='myshop_profile_menu_events'").first();
   const events=exists?(await env.DB.prepare('SELECT id,actor_id,action,created_at FROM myshop_profile_menu_events WHERE (?=0 OR id<?) ORDER BY id DESC LIMIT 31').bind(after,after).all()).results||[]:[];
   return h.json({ok:true,history:events.slice(0,30),next:events.length>30?events[29].id:null},200,{...h.cors,'cache-control':'no-store'});
  }
  return h.json(result(old),200,{...h.cors,'cache-control':'no-store'});
 }
 let b;try{b=await request.json();}catch(_){return fail('INVALID_JSON');}
 if(!b||!['SAVE_DRAFT','PUBLISH','RESTORE_DRAFT'].includes(b.action)||!Number.isSafeInteger(b.expectedRevision)||!Number.isSafeInteger(b.expectedDraftRevision))return fail('INVALID_CHANGE');
 const revision=Number(old?.revision||0),draftRevision=Number(old?.draft_revision||0);if(revision!==b.expectedRevision||draftRevision!==b.expectedDraftRevision)return fail('REVISION_CONFLICT',409);
 if(b.action==='PUBLISH'&&!old)return fail('SAVE_DRAFT_FIRST',409);
 let input=b.items;if(b.action==='RESTORE_DRAFT'){
  if(!Number.isSafeInteger(b.eventId)||b.eventId<1)return fail('INVALID_HISTORY_EVENT');
  const exists=await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='myshop_profile_menu_events'").first();
  const event=exists?await env.DB.prepare('SELECT new_payload FROM myshop_profile_menu_events WHERE id=?').bind(b.eventId).first():null;
  if(!event)return fail('HISTORY_EVENT_NOT_FOUND',404);
  try{input=JSON.parse(event.new_payload);}catch(_){return fail('CORRUPT_HISTORY_EVENT',409);}
 }
 let items;try{items=normalizeProfileMenu(b.action==='PUBLISH'?JSON.parse(old.draft):input);}catch(e){return fail(e.message);}
 if(b.action==='PUBLISH'&&items.some(x=>x.iconUrl)&&b.rightsAccepted!==true)return fail('ICON_RIGHTS_CONFIRMATION_REQUIRED');
 const auditAction=b.action==='PUBLISH'&&items.some(x=>x.iconUrl)?'PUBLISH_RIGHTS_CONFIRMED':b.action;
 const payload=JSON.stringify(items),publish=b.action==='PUBLISH',acl="EXISTS(SELECT 1 FROM myshop_auth_users_v108 WHERE user_id=? AND active=1 AND user_id IN ('0001','0002','0003'))";
 await env.DB.prepare('CREATE TABLE IF NOT EXISTS myshop_profile_menu_events(id INTEGER PRIMARY KEY AUTOINCREMENT,actor_id TEXT NOT NULL,action TEXT NOT NULL,old_payload TEXT NOT NULL,new_payload TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)').run();
 const write=old?env.DB.prepare(`UPDATE myshop_profile_menu SET ${publish?'published=?,revision=revision+1':'draft=?,draft_revision=draft_revision+1'},actor_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=1 AND revision=? AND draft_revision=? AND ${acl}`).bind(payload,me.user_id,revision,draftRevision,me.user_id):env.DB.prepare(`INSERT OR IGNORE INTO myshop_profile_menu(id,draft,draft_revision,actor_id) SELECT 1,?,1,? WHERE ${acl}`).bind(payload,me.user_id,me.user_id);
 const results=await env.DB.batch([write,env.DB.prepare('INSERT INTO myshop_profile_menu_events(actor_id,action,old_payload,new_payload) SELECT ?,?,?,? WHERE changes()=1').bind(me.user_id,auditAction,publish?old?.published||'[]':old?.draft||'[]',payload)]);
 if(!Number(results[0]?.meta?.changes))return fail('REVISION_OR_PERMISSION_CHANGED',409);
 return h.json(result(await env.DB.prepare('SELECT * FROM myshop_profile_menu WHERE id=1').first()),200,h.cors);
}
