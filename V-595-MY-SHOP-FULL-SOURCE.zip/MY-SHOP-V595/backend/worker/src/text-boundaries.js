// UTF-16 offsets, matching Android selection offsets; never split a grapheme/Indic conjunct.
export function textBoundaries(source){
 const result=new Set([0,source.length]);
 for(const part of new Intl.Segmenter('bn',{granularity:'grapheme'}).segment(source))result.add(part.index);
 for(const offset of [...result]){
  if(offset===0||offset===source.length)continue;
  const before=source.slice(0,offset),after=source.slice(offset);
  if(/[\u09CD\u200D]$/.test(before)||/^[\p{Mark}\u200D]/u.test(after))result.delete(offset);
 }
 return result;
}
