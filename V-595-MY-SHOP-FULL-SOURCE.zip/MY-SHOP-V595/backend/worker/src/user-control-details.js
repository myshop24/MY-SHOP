// Read-only: existing host, session, moderation and block records are never changed.
export async function userControlDetails(request,env,h){
 const me=await h.getUser(request,env);if(!me)return h.json({error:'UNAUTHORIZED'},401,h.cors);
 const admin=await env.DB.prepare('SELECT active,role FROM myshop_auth_users_v108 WHERE user_id=?').bind(me.user_id).first();
 if(!['0001','0002','0003'].includes(String(me.user_id))||Number(admin?.active)!==1||admin?.role!=='ADMIN')return h.json({error:'MAIN_ADMIN_ONLY'},403,h.cors);
 const params=new URL(request.url).searchParams;const uid=String(params.get('userId')||'');if(!/^\d{4}$/.test(uid))return h.json({error:'INVALID_USER_ID'},400,h.cors);
 const rawCursor=params.get('liveBefore')||'';if(rawCursor&&!/^[1-9][0-9]{0,14}$/.test(rawCursor))return h.json({error:'INVALID_HISTORY_CURSOR'},400,h.cors);const cursor=rawCursor?Number(rawCursor):null;
 const user=await env.DB.prepare('SELECT user_id,full_name FROM myshop_auth_users_v108 WHERE user_id=?').bind(uid).first();if(!user)return h.json({error:'USER_NOT_FOUND'},404,h.cors);
 const tables=new Set(((await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table'").all()).results||[]).map(t=>t.name));
 const read=async(table,columns,where,args,order)=>tables.has(table)?(await env.DB.prepare(`SELECT ${columns} FROM ${table} WHERE ${where} ORDER BY ${order} LIMIT 200`).bind(...args).all()).results||[]:[];
 const [blocks,mutes,moderation,liveHistory]=await Promise.all([
  read('myshop_user_blocks','blocker_id,blocked_id,created_at','blocker_id=? OR blocked_id=?',[uid,uid],'created_at DESC,blocker_id,blocked_id'),
  read('myshop_live_mute_records','host_id,user_id,muted_by,created_at,updated_at','host_id=? OR user_id=? OR muted_by=?',[uid,uid,uid],'updated_at DESC,host_id,user_id'),
  read('myshop_live_moderation_audit','id,host_id,actor_id,target_id,action,reason,created_at','host_id=? OR actor_id=? OR target_id=?',[uid,uid,uid],'id DESC'),
  read('myshop_live_history','id,title,started_at,ended_at,duration_seconds,session_id',cursor?'host_id=? AND id<?':'host_id=?',cursor?[uid,cursor]:[uid],'id DESC')]);
 const liveTotals=tables.has('myshop_live_history')?await env.DB.prepare('SELECT COUNT(*) sessions,COALESCE(SUM(MAX(0,COALESCE(duration_seconds,0))),0) seconds FROM myshop_live_history WHERE host_id=?').bind(uid).first():{sessions:0,seconds:0};
 const last=liveHistory[liveHistory.length-1];const more=last&&tables.has('myshop_live_history')?await env.DB.prepare('SELECT 1 found FROM myshop_live_history WHERE host_id=? AND id<? LIMIT 1').bind(uid,last.id).first():null;
 return h.json({ok:true,user,blocks,mutes,moderation,liveHistory,liveTotals,liveNextBefore:more?String(last.id):null,readOnly:true,historyLimit:200},200,h.cors);
}
