// Read-only view over canonical drafts. No shadow queue and no financial/live writes.
import {visualScopes} from './visual-design.js';
const protectedFeature=x=>/(?:^|_)(?:live|rtc|audio|gift|gifts|room)(?:_|$)/.test(x)||['feature_go_live','feature_top_gifters'].includes(x);
const stable=x=>JSON.stringify(x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,JSON.parse(stable(x[k]))])):Array.isArray(x)?x.map(v=>JSON.parse(stable(v))):x);
const featureFields={title:['title',''],caption:['caption',''],url:['url',''],iconUrl:['icon_url',''],imageUrl:['image_url',''],active:['active',1],displayOrder:['display_order',1],priceMinor:['price_minor',0],offerText:['offer_text',''],offerStart:['offer_start',''],offerEnd:['offer_end',''],timeLimitMinutes:['time_limit_minutes',0],status:['status','ACTIVE'],comingSoonMessage:['coming_soon_message','']};
function sameFeature(draft,published){if(!published||Number(published.archived))return false;for(const [key,[column,fallback]] of Object.entries(featureFields)){let a=draft[key]??draft[column]??fallback,b=published[column]??fallback;if(key==='active'){a=Number(a);b=Number(b);}if(String(a)!==String(b))return false;}return true;}
export async function draftReview(request,env,h){
 const fail=(error,status)=>h.json({error},status,h.cors),me=await h.getUser(request,env);if(!me)return fail('UNAUTHORIZED',401);
 const user=await env.DB.prepare('SELECT active FROM myshop_auth_users_v108 WHERE user_id=?').bind(me.user_id).first();
 if(!user||Number(user.active)!==1)return fail('UNAUTHORIZED',401);
 if(!['0001','0002','0003'].includes(String(me.user_id)))return fail('OWNER_REVIEW_PERMISSION_REQUIRED',403);
 if(request.method!=='GET')return fail('METHOD_NOT_ALLOWED',405);
 const url=new URL(request.url),after=url.searchParams.get('after')||'',kind=url.searchParams.get('kind')||'all',search=(url.searchParams.get('search')||'').trim().toLowerCase();
 if(!['all','feature','design','menu'].includes(kind)||after&&!/^(feature|design|menu):[a-z0-9_]{1,90}$/.test(after)||search.length>100)return fail('INVALID_FILTER',400);
 const existing=(await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name IN ('myshop_feature_drafts','managed_links','myshop_visual_designs','myshop_profile_menu')").all()).results||[],tables=new Set(existing.map(x=>x.name)),items=[];
 if(['all','feature'].includes(kind)&&tables.has('myshop_feature_drafts')){
  const drafts=(await env.DB.prepare('SELECT category,payload,revision,actor_id,updated_at FROM myshop_feature_drafts ORDER BY category LIMIT 1001').all()).results||[];
  if(drafts.length>1000)return fail('REVIEW_INVENTORY_LIMIT',409);
  let publicItems=[];if(tables.has('managed_links'))publicItems=(await env.DB.prepare("SELECT * FROM managed_links WHERE category LIKE 'feature_%' ORDER BY id LIMIT 2001").all()).results||[];
  if(publicItems.length>2000)return fail('REVIEW_INVENTORY_LIMIT',409);
  for(const d of drafts){let config;try{config=JSON.parse(d.payload);}catch(_){return fail('CORRUPT_FEATURE_DRAFT',409);}if(!config||config.category!==d.category)return fail('CORRUPT_FEATURE_DRAFT',409);const matches=publicItems.filter(x=>x.category===d.category);if(matches.length>1)return fail('AMBIGUOUS_FEATURE_SOURCE',409);const published=matches[0];if(sameFeature(config,published))continue;items.push({key:'feature:'+d.category,kind:'feature',scope:d.category,title:String(config.title||d.category),draftRevision:d.revision,publishedRevision:Number(published?.revision||0),actorId:d.actor_id,updatedAt:d.updated_at,requiresLiveApproval:protectedFeature(d.category)});}
 }
 if(['all','design'].includes(kind)&&tables.has('myshop_visual_designs')){
  const rows=(await env.DB.prepare('SELECT scope,revision,draft_revision,published,draft,actor_id,updated_at FROM myshop_visual_designs ORDER BY scope LIMIT 101').all()).results||[];
  for(const d of rows){if(!visualScopes.has(d.scope)||!Number(d.draft_revision))continue;let different;try{different=stable(JSON.parse(d.draft))!==stable(JSON.parse(d.published));}catch(_){return fail('CORRUPT_DESIGN_DRAFT',409);}if(different)items.push({key:'design:'+d.scope,kind:'design',scope:d.scope,title:d.scope,draftRevision:d.draft_revision,publishedRevision:d.revision,actorId:d.actor_id,updatedAt:d.updated_at,requiresLiveApproval:false});}
 }
 if(['all','menu'].includes(kind)&&tables.has('myshop_profile_menu')){
  const row=await env.DB.prepare('SELECT revision,draft_revision,published,draft,actor_id,updated_at FROM myshop_profile_menu WHERE id=1').first();
  if(row&&Number(row.draft_revision)){let different;try{different=stable(JSON.parse(row.draft))!==stable(JSON.parse(row.published));}catch(_){return fail('CORRUPT_MENU_DRAFT',409);}if(different)items.push({key:'menu:profile_menu',kind:'menu',scope:'profile_menu',title:'Compact Profile Menu',draftRevision:row.draft_revision,publishedRevision:row.revision,actorId:row.actor_id,updatedAt:row.updated_at,requiresLiveApproval:false});}
 }
 const filtered=items.filter(x=>x.key>after&&(!search||(x.title+' '+x.scope+' '+x.actorId).toLowerCase().includes(search))).sort((a,b)=>a.key<b.key?-1:a.key>b.key?1:0),page=filtered.slice(0,30);
 return h.json({ok:true,items:page,next:filtered.length>30?page[page.length-1].key:null,total:items.length,source:'canonical_drafts'},200,{...h.cors,'cache-control':'no-store'});
}
