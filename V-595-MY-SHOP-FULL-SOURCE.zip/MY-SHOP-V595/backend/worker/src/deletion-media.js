export const deletionMediaSchema = `CREATE TABLE IF NOT EXISTS myshop_deleted_media(object_key TEXT PRIMARY KEY,user_id TEXT NOT NULL,state TEXT NOT NULL DEFAULT 'PENDING',attempts INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`;
export async function drainDeletedMedia(env,limit=20){
  if(!env.DB||!env.MEDIA)return;
  const exists=await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='myshop_deleted_media'").first();if(!exists)return;
  const rows=(await env.DB.prepare(`SELECT object_key FROM myshop_deleted_media WHERE state='PENDING' ORDER BY updated_at,object_key LIMIT ?`).bind(Math.max(1,Math.min(100,limit))).all()).results||[];
  for(const row of rows){
    try{await env.MEDIA.delete(row.object_key);await env.DB.prepare(`UPDATE myshop_deleted_media SET state='DELETED',attempts=attempts+1,updated_at=CURRENT_TIMESTAMP WHERE object_key=?`).bind(row.object_key).run();}
    catch(_){await env.DB.prepare(`UPDATE myshop_deleted_media SET attempts=attempts+1,updated_at=CURRENT_TIMESTAMP WHERE object_key=?`).bind(row.object_key).run();}
  }
  const requests=await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='myshop_account_deletion_requests'").first();
  if(requests)await env.DB.prepare(`UPDATE myshop_account_deletion_requests SET status='COMPLETED',updated_at=CURRENT_TIMESTAMP WHERE status='MEDIA_PENDING' AND NOT EXISTS(SELECT 1 FROM myshop_deleted_media m WHERE m.user_id=myshop_account_deletion_requests.user_id AND m.state='PENDING') AND EXISTS(SELECT 1 FROM myshop_auth_users_v108 u WHERE u.user_id=myshop_account_deletion_requests.user_id AND u.active=0 AND u.password_hash LIKE 'deleted$%')`).run();
}
export async function mediaWasDeleted(DB,key){
  const exists=await DB.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='myshop_deleted_media'").first();
  return !!(exists&&await DB.prepare('SELECT 1 blocked FROM myshop_deleted_media WHERE object_key=?').bind(key).first());
}
