export function filterPersonalDetailsForViewer(rows,ownerId,viewerId,relation,grants=[]){
  const self=String(ownerId)===String(viewerId);
  return (Array.isArray(rows)?rows:[]).filter(x=>{
    if(!String(x?.value||'').trim())return false;
    if(self)return true;
    const privacy=String(x?.visibility||'PUBLIC').trim().toUpperCase();
    return privacy==='PUBLIC'||(privacy==='FRIENDS'&&relation==='FRIEND')||(privacy==='CUSTOM'&&String(viewerId)!==''&&grants.some(g=>g.field_key===x.field_key&&String(g.viewer_id)===String(viewerId)));
  }).map(x=>({field_key:String(x.field_key||''),value:String(x.value||'').trim()}));
}

export function normalizeUserSocialUrl(value,platform){
  let raw=String(value||'').trim();if(!raw)return '';if(raw.length>512)return null;if(platform==='imo'&&raw.startsWith('tel:'))raw=raw.slice(4);
  if(platform==='imo'&&/^\+?[0-9().\s-]{8,24}$/.test(raw)){const digits=raw.replace(/[^0-9+]/g,'');return digits.length>=8?`tel:${digits}`:null;}
  try{const u=new URL(/^https?:\/\//i.test(raw)?raw:`https://${raw}`);if(!['http:','https:'].includes(u.protocol)||!u.hostname||u.username||u.password)return null;return u.toString();}catch(_){return null;}
}

export const PROFILE_CORE_KEYS=['name','bio','profile_photo','cover_photo','join_date','user_id','social_links'];
/** Core visibility is scoped to this Profile page, not identity already shown in public content. */
export function maskProfileCore(profile,rows,ownerId,viewerId,relation,grants=[]){
 const permissions={};
 for(const key of PROFILE_CORE_KEYS){const row=rows.find(x=>x.field_key===key);permissions[key]=!row||filterPersonalDetailsForViewer([{...row,value:'configured'}],ownerId,viewerId,relation,grants).length>0;}
 const result={...profile,userIdVisible:permissions.user_id};
 for(const [key,property,fallback] of [['name','name','MY SHOP User'],['bio','bio',''],['profile_photo','avatarUrl',''],['cover_photo','coverUrl',''],['join_date','joinedAt',''],['social_links','socialLinks',[]]])if(!permissions[key])result[property]=fallback;
 return result;
}
