import {textBoundaries} from './text-boundaries.js';
// Separate, bounded appearance configuration. Live and locked Profile are excluded.
export const visualScopes = new Set(['user_menu','profile_menu','home_quick','home_general','shop','withdrawal','home_header','media_center','profile_settings','wallet']);
export function normalizeVisualStyles(input, maxTargets=120) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw Error('INVALID_STYLES');
  const entries = Object.entries(input);
  if (entries.length > maxTargets) throw Error('TOO_MANY_TARGETS');
  const result = {};
  const colors = ['background','backgroundEnd','text','textEnd','border','icon'];
  const numbers = {iconSize:[28,56],fontSize:[9,28],radius:[0,32],shadow:[0,8],padding:[0,20],borderWidth:[0,3],rotation:[-180,180],opacity:[0.2,1]};
  for (const [target,style] of entries) {
    if (! /^(?:root(?:\/[0-9]{1,3}){0,12}|element_[a-z0-9_]{1,80})$/.test(target) || !style || typeof style !== 'object' || Array.isArray(style)) throw Error('INVALID_TARGET');
    const next = {};
    for (const [key,value] of Object.entries(style)) {
      if (colors.includes(key)) { if (!/^#[0-9a-f]{6}$/i.test(String(value))) throw Error('INVALID_COLOR'); next[key]=value.toUpperCase(); }
      else if (key in numbers) { const [min,max]=numbers[key]; if (!Number.isFinite(value)||value<min||value>max) throw Error('INVALID_SIZE'); next[key]=value; }
      else if (key==='segments') {
        if(!Array.isArray(value)||value.length>32)throw Error('INVALID_TEXT_SEGMENTS');
        next.segments=value.map(part=>{
          if(!part||typeof part!=='object'||Array.isArray(part)||Object.keys(part).some(k=>!['start','end','source','text','textEnd','fontSize'].includes(k)))throw Error('INVALID_TEXT_SEGMENT');
          if(typeof part.source!=='string'||part.source.length>2000||!Number.isSafeInteger(part.start)||!Number.isSafeInteger(part.end)||part.start<0||part.end<=part.start||part.end>part.source.length)throw Error('INVALID_TEXT_RANGE');
          const boundaries=textBoundaries(part.source);if(!boundaries.has(part.start)||!boundaries.has(part.end))throw Error('TEXT_GRAPHEME_SPLIT');
          const segment={start:part.start,end:part.end,source:part.source};
          for(const color of ['text','textEnd'])if(part[color]!==undefined){if(!/^#[0-9a-f]{6}$/i.test(String(part[color])))throw Error('INVALID_COLOR');segment[color]=part[color].toUpperCase();}
          if(part.fontSize!==undefined){if(!Number.isFinite(part.fontSize)||part.fontSize<9||part.fontSize>48)throw Error('INVALID_SIZE');segment.fontSize=part.fontSize;}
          return segment;
        });
      }
      else if (key==='word') { if (typeof value!=='string'||value.length>80) throw Error('INVALID_WORD'); next.word=value; }
      else throw Error('INVALID_STYLE_PROPERTY');
    }
    result[target]=next;
  }
  return result;
}
export async function publicVisualStyles(input){
  const safe=JSON.parse(JSON.stringify(input));
  for(const style of Object.values(safe))for(const part of style.segments||[]){
    if(typeof part.source==='string'){
      const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(part.source));
      part.sourceHash=Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join('');delete part.source;
    }
  }
  return safe;
}
export async function schema(DB) {
  await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_visual_designs(scope TEXT PRIMARY KEY,revision INTEGER NOT NULL DEFAULT 0,draft_revision INTEGER NOT NULL DEFAULT 0,published TEXT NOT NULL DEFAULT '{}',draft TEXT NOT NULL DEFAULT '{}',actor_id TEXT,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_visual_design_events(id INTEGER PRIMARY KEY AUTOINCREMENT,scope TEXT NOT NULL,actor_id TEXT NOT NULL,action TEXT NOT NULL,revision INTEGER NOT NULL,old_payload TEXT NOT NULL,new_payload TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
}
export async function visualDesign(request,env,h) {
  const fail=(error,status=400)=>h.json({error},status,h.cors);
  const me=await h.getUser(request,env);if(!me)return fail('UNAUTHORIZED',401);
  const url=new URL(request.url),admin=url.pathname.startsWith('/v1/admin/');
  const active=await env.DB.prepare('SELECT active,role FROM myshop_auth_users_v108 WHERE user_id=?').bind(me.user_id).first();
  if(!active||Number(active.active)!==1)return fail('UNAUTHORIZED',401);
  const main=['0001','0002','0003'].includes(String(me.user_id));
  if(admin&&(!main||active.role!=='ADMIN'))return fail('OWNER_DESIGN_PERMISSION_REQUIRED',403);
  if(!['GET','POST'].includes(request.method)||request.method==='POST'&&!admin)return fail('METHOD_NOT_ALLOWED',405);
  let b={};if(request.method==='POST'){try{b=await request.json();}catch(_){return fail('INVALID_JSON');}}
  if(!b||typeof b!=='object'||Array.isArray(b))return fail('INVALID_JSON');
  const scope=String(request.method==='POST'?b.scope:url.searchParams.get('scope')||'');
  if(!visualScopes.has(scope))return fail('PROTECTED_OR_INVALID_SCOPE',403);
  await schema(env.DB);
  const old=await env.DB.prepare('SELECT * FROM myshop_visual_designs WHERE scope=?').bind(scope).first();
  const revision=Number(old?.revision||0),draftRevision=Number(old?.draft_revision||0);
  const response=row=>({ok:true,scope,revision:Number(row?.revision||0),styles:JSON.parse(row?.published||'{}'),...(admin?{draftRevision:Number(row?.draft_revision||0),draft:JSON.parse(row?.draft||'{}')}: {})});
  if(request.method==='GET'){
    const result=response(old);if(!admin)result.styles=await publicVisualStyles(result.styles);
    if(admin&&url.searchParams.get('history')==='1')result.history=(await env.DB.prepare("SELECT id,action,revision,actor_id,created_at FROM myshop_visual_design_events WHERE scope=? AND action='PUBLISH' ORDER BY id DESC LIMIT 50").bind(scope).all()).results||[];
    return h.json(result,200,h.cors);
  }
  if(!['SAVE_DRAFT','PUBLISH','RESTORE_DRAFT'].includes(b.action)||!Number.isSafeInteger(b.expectedRevision)||!Number.isSafeInteger(b.expectedDraftRevision))return fail('INVALID_CHANGE');
  if(b.expectedRevision!==revision||b.expectedDraftRevision!==draftRevision)return fail('REVISION_CONFLICT',409);
  let input=b.styles;
  if(b.action==='RESTORE_DRAFT'){
    if(!Number.isSafeInteger(b.eventId)||b.eventId<1)return fail('INVALID_HISTORY_ITEM');
    const event=await env.DB.prepare("SELECT new_payload FROM myshop_visual_design_events WHERE id=? AND scope=? AND action='PUBLISH'").bind(b.eventId,scope).first();
    if(!event)return fail('HISTORY_NOT_FOUND',404);
    input=JSON.parse(event.new_payload);
  }
  let styles;try{styles=normalizeVisualStyles(b.action==='PUBLISH'?JSON.parse(old?.draft||'{}'):input,['user_menu','profile_menu'].includes(scope)?240:120);}catch(e){return fail(e.message);}
  if(b.action==='PUBLISH'&&!old)return fail('SAVE_DRAFT_FIRST',409);
  const payload=JSON.stringify(styles),publish=b.action==='PUBLISH';
  const acl="EXISTS(SELECT 1 FROM myshop_auth_users_v108 WHERE user_id=? AND active=1 AND user_id IN ('0001','0002','0003'))";
  let write;
  if(old)write=env.DB.prepare(`UPDATE myshop_visual_designs SET ${publish?'published=?,revision=revision+1':'draft=?,draft_revision=draft_revision+1'},actor_id=?,updated_at=CURRENT_TIMESTAMP WHERE scope=? AND revision=? AND draft_revision=? AND ${acl}`).bind(payload,me.user_id,scope,revision,draftRevision,me.user_id);
  else write=env.DB.prepare(`INSERT OR IGNORE INTO myshop_visual_designs(scope,draft,draft_revision,actor_id) SELECT ?,?,1,? WHERE ${acl}`).bind(scope,payload,me.user_id,me.user_id);
  const results=await env.DB.batch([write,env.DB.prepare('INSERT INTO myshop_visual_design_events(scope,actor_id,action,revision,old_payload,new_payload) SELECT ?,?,?,?,?,? WHERE changes()=1').bind(scope,me.user_id,b.action,publish?revision+1:draftRevision+1,publish?old?.published||'{}':old?.draft||'{}',payload)]);
  if(!Number(results[0]?.meta?.changes))return fail('REVISION_OR_PERMISSION_CHANGED',409);
  const saved=await env.DB.prepare('SELECT * FROM myshop_visual_designs WHERE scope=?').bind(scope).first();
  return h.json(response(saved),200,h.cors);
}
