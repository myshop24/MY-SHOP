// Only public aggregates. Never cache room permission, wallet or private viewer state.
const databases=new WeakMap();
export async function publicAggregate(DB,key,load,ttl=5000){
 let cache=databases.get(DB);if(!cache){cache=new Map();databases.set(DB,cache);}
 const now=Date.now(),old=cache.get(key);if(old&&old.until>now)return old.value;
 if(cache.size>=256){for(const [k,v] of cache)if(v.until<=now)cache.delete(k);if(cache.size>=256)cache.delete(cache.keys().next().value);}
 const entry={until:now+ttl,value:null};entry.value=Promise.resolve().then(load).catch(e=>{if(cache.get(key)===entry)cache.delete(key);throw e;});cache.set(key,entry);return entry.value;
}
export function invalidatePublicAggregates(DB,host){const c=databases.get(DB);if(c)for(const k of c.keys())if(k.startsWith(host+':'))c.delete(k);}
