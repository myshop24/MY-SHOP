from pathlib import Path
import re
s=(Path(__file__).resolve().parents[2]/'app/src/main/java/com/myshop/app/AppThemePalette.java').read_text()
def luminance(c):
 channels=[((c>>shift)&255)/255 for shift in (16,8,0)]
 linear=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in channels]
 return sum(x*w for x,w in zip(linear,[.2126,.7152,.0722]))
def ratio(x,y):
 a,b=sorted([luminance(x),luminance(y)]);return (b+.05)/(a+.05)
def blend(x,y,f):
 return sum(int(((x>>shift)&255)*(1-f)+((y>>shift)&255)*f+.5)<<shift for shift in (16,8,0))
worst=99
for name in ['LIGHT','DARK']:
 colors=[int(x,16) for x in re.search(name+r'=\{([^}]+)',s).group(1).split(',')]
 assert len(colors)==(31 if name=="LIGHT" else 30)
 for i,bg in enumerate(colors):
  dark=name=='DARK';card=blend(bg,0xffffff,.075 if dark else .74)
  for fg in ([0xf1f4fb,0xbbc6d9] if dark else [0x192237,0x59677d]):
   for surface in [bg,card]:
    contrast=ratio(fg,surface);worst=min(worst,contrast);assert contrast>=4.5,(name,i+1,contrast)
print('PASS: all 61 presets, text and secondary text on background/card >= 4.5:1; minimum %.2f:1'%worst)
print('Actual device rendering is NOT tested by this numerical check.')
