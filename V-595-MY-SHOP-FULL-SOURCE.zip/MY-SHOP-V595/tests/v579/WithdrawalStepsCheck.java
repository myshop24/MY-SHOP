import java.nio.file.*;
import java.util.*;
import javax.tools.*;
public class WithdrawalStepsCheck {
 public static void main(String[] args)throws Exception {
  String source=Files.readString(Path.of("app/src/main/java/com/myshop/app/CoinWithdrawalActivity.java"));
  int start=source.indexOf("    private void showStep(){"),end=source.indexOf("\n",start);String method=source.substring(start,end);
  Path root=Files.createTempDirectory("withdrawal-steps-");
  String stub="""
  class View {static final int VISIBLE=0,GONE=8;int visibility;boolean enabled;String label;void setVisibility(int n){visibility=n;}void setEnabled(boolean b){enabled=b;}void setText(String s){label=s;}}
  class Quotes {int length(){return 1;}}
  public class Fixture {View next=new View(),previous=new View(),submit=new View(),currencySection=new View(),amountSection=new View(),methodSection=new View();int step;boolean balanceLoaded=true,optionsLoaded=true,balanceFailed,optionsFailed,sending;Quotes quotes=new Quotes();Object quote(){return new Object();}
  """;
  String check="""
  static void check(boolean v){if(!v)throw new AssertionError();}public static void main(String[]args){Fixture f=new Fixture();f.showStep();check(f.currencySection.visibility==0&&f.amountSection.visibility==8&&f.methodSection.visibility==8&&f.next.enabled&&!f.previous.enabled&&f.submit.visibility==8);f.step=1;f.showStep();check(f.currencySection.visibility==8&&f.amountSection.visibility==0&&f.methodSection.visibility==8&&f.next.enabled);f.step=2;f.showStep();check(f.currencySection.visibility==8&&f.amountSection.visibility==8&&f.methodSection.visibility==0&&f.next.visibility==8&&f.submit.visibility==0);f.sending=true;f.step=0;f.showStep();check(!f.next.enabled&&!f.previous.enabled);f.sending=false;f.balanceFailed=true;f.showStep();check(!f.next.enabled);f.balanceFailed=false;f.optionsFailed=true;f.showStep();check(!f.next.enabled);System.out.println("PASS shipped withdrawal steps: one section at a time, payment browsing independent of earnings, loading/error/sending gates.");}}
  """;
  try{Files.writeString(root.resolve("Fixture.java"),stub+method+check);JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();try(var fm=compiler.getStandardFileManager(null,null,null)){if(!compiler.getTask(null,fm,null,List.of("-proc:none","-d",root.toString()),null,fm.getJavaFileObjects(root.resolve("Fixture.java").toFile())).call())throw new AssertionError("Withdrawal steps javac failed");}try(var loader=new java.net.URLClassLoader(new java.net.URL[]{root.toUri().toURL()})){loader.loadClass("Fixture").getMethod("main",String[].class).invoke(null,(Object)new String[0]);}}
  finally{try(var paths=Files.walk(root)){for(Path p:paths.sorted(Comparator.reverseOrder()).toList())Files.delete(p);}}
 }
}
