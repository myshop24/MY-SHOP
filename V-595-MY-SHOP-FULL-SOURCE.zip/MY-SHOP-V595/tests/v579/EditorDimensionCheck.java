import java.nio.file.*;import java.util.*;import javax.tools.*;
/** Executes the exact shipped target/dimension control fragment with UI doubles, not Android rendering. */
public class EditorDimensionCheck {
 public static void main(String[] args)throws Exception{
  String shipped=Files.readString(Path.of("app/src/main/java/com/myshop/app/VisualDesign.java"));int start=shipped.indexOf("String[] sizes="),end=shipped.indexOf("Button view=",start);if(start<0||end<0)throw new AssertionError("Dimension fragment missing");String fragment=shipped.substring(start,end);
  Path root=Files.createTempDirectory("myshop-editor-dimensions-");try{
   Files.writeString(root.resolve("R.java"),"package android;public class R {public static class layout {public static final int simple_spinner_dropdown_item=1;}}");
   String stubs="""
    class View {} class ImageView extends View {} class Metrics {float scaledDensity=2,density=2;}class Resources {Metrics getDisplayMetrics(){return new Metrics();}}class Activity {Resources getResources(){return new Resources();}}
    class ArrayAdapter<T> {ArrayAdapter(Activity a,int id,T[] values){}}
    class AdapterView<T> {interface OnItemSelectedListener {void onItemSelected(AdapterView<?> p,View v,int n,long id);void onNothingSelected(AdapterView<?> p);}}
    class Spinner extends AdapterView<Object> {int n;OnItemSelectedListener listener;Spinner(Activity a){}void setAdapter(Object a){}int getSelectedItemPosition(){return n;}void setOnItemSelectedListener(OnItemSelectedListener l){listener=l;}void setSelection(int n){this.n=n;if(listener!=null)listener.onItemSelected(this,new View(),n,n);}}
    class TextView {String text="";TextView(Activity a){}void setText(String s){text=s;}}
    class Box {void addView(Object v){}}
    class SeekBar {int value,max;OnSeekBarChangeListener listener;SeekBar(Activity a){}interface OnSeekBarChangeListener {void onStartTrackingTouch(SeekBar s);void onStopTrackingTouch(SeekBar s);void onProgressChanged(SeekBar s,int n,boolean user);}void setMax(int n){max=n;}void setProgress(int n){value=n;if(listener!=null)listener.onProgressChanged(this,n,false);}void setOnSeekBarChangeListener(OnSeekBarChangeListener l){listener=l;}void userProgress(int n){listener.onStartTrackingTouch(this);value=n;listener.onProgressChanged(this,n,true);listener.onStopTrackingTouch(this);}}
    class JSONObject {java.util.Map<String,Object> map=new java.util.HashMap<>();JSONObject optJSONObject(String key){return (JSONObject)map.get(key);}double optDouble(String key,double fallback){return map.containsKey(key)?((Number)map.get(key)).doubleValue():fallback;}JSONObject put(String key,Object value){map.put(key,value);return this;}}
    class Original {float font=30,rotation=-45,alpha=.35f;int iconWidth=76;View view=new View();}class State {JSONObject draft=new JSONObject();java.util.Map<String,Original> targets=new java.util.HashMap<>();}
   """;
   String setup="""
    public class Fixture {public static void main(String[] args){Activity a=new Activity();Box box=new Box();State data=new State();java.util.List<String> paths=java.util.List.of("root","root/1");for(String p:paths)data.targets.put(p,new Original());data.draft.put("root",new JSONObject().put("fontSize",21));Spinner target=new Spinner(a);TextView status=new TextView(a);int[] edits={0};Runnable checkpoint=()->edits[0]++;Runnable preview=()->{};java.util.function.Function<String,JSONObject> style=path->{JSONObject s=data.draft.optJSONObject(path);if(s==null){s=new JSONObject();data.draft.put(path,s);}return s;};
   """;
   String checks="""
    if(amount.value!=12||!dimensionValue.text.equals("Font size: 21"))throw new AssertionError("Saved dimension not loaded");
    dimension.setSelection(6);if(amount.value!=15||!dimensionValue.text.equals("Opacity %: 35%"))throw new AssertionError("Original opacity wrong");
    dimension.setSelection(5);if(amount.value!=135||!dimensionValue.text.equals("Rotate: -45"))throw new AssertionError("Original rotation wrong");
    target.setSelection(1);dimension.setSelection(0);if(amount.value!=6||!dimensionValue.text.equals("Font size: 15"))throw new AssertionError("Target switch did not use original sp dimension");
    amount.userProgress(19);if(data.draft.optJSONObject("root/1").optDouble("fontSize",0)!=28||data.draft.optJSONObject("root").optDouble("fontSize",0)!=21||edits[0]!=1)throw new AssertionError("User edit applied to wrong target or duplicated");
    dimension.setSelection(7);if(amount.value!=10)throw new AssertionError("Original icon dp wrong");amount.userProgress(28);if(data.draft.optJSONObject("root/1").map.containsKey("iconSize"))throw new AssertionError("Text target accepted icon sizing");data.targets.get("root/1").view=new ImageView();amount.userProgress(28);if(data.draft.optJSONObject("root/1").optDouble("iconSize",0)!=56)throw new AssertionError("Image target size not saved");
    System.out.println("PASS shipped dimension controls: javac, saved target values, original rotation/opacity/sp units, target switch, selected-target-only edit.");}}
   """;
   Files.writeString(root.resolve("Fixture.java"),stubs+setup+fragment+checks);
   JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();try(var fm=compiler.getStandardFileManager(null,null,null)){if(!compiler.getTask(null,fm,null,List.of("-proc:none","-d",root.toString()),null,fm.getJavaFileObjects(root.resolve("R.java").toFile(),root.resolve("Fixture.java").toFile())).call())throw new AssertionError("Shipped dimension controls failed javac");}
   try(var loader=new java.net.URLClassLoader(new java.net.URL[]{root.toUri().toURL()})){loader.loadClass("Fixture").getMethod("main",String[].class).invoke(null,(Object)new String[0]);}
  }finally{try(var paths=Files.walk(root)){for(Path p:paths.sorted(Comparator.reverseOrder()).toList())Files.delete(p);}}
 }
}
