const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const {DatabaseSync}=require('node:sqlite'),{webcrypto}=require('node:crypto');
const root=path.resolve(__dirname,'../..'),source=fs.readFileSync(path.join(root,'backend/worker/src/index.js'),'utf8');
const db=new DatabaseSync(':memory:');let counts={total:0,ddl:0};function track(sql){counts.total++;if(/^(CREATE|ALTER|DROP)/i.test(sql.trim()))counts.ddl++;}
function stmt(sql,args=[]){return{sql,args,bind(...a){if(a.some(v=>v===undefined))throw Error('undefined SQL bind');return stmt(sql,a)},async first(k){track(sql);const x=db.prepare(sql).get(...args);return x?(k?x[k]:x):null},async all(){track(sql);return{results:db.prepare(sql).all(...args)}},async run(){track(sql);const x=db.prepare(sql).run(...args);return{success:true,meta:{changes:Number(x.changes),last_row_id:Number(x.lastInsertRowid)}}}}}
const DB={prepare:stmt,async batch(xs){db.exec('BEGIN');try{const out=[];for(const x of xs)out.push(await x.run());db.exec('COMMIT');return out}catch(e){db.exec('ROLLBACK');throw e}},async exec(sql){db.exec(sql);return{count:1}}};
const c={Response,Request,Headers,URL,URLSearchParams,File,FormData,Blob,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,atob,btoa,crypto:webcrypto,agoraRtcTokenPkg:{RtcTokenBuilder:{},Role:{}},setTimeout,clearTimeout,console,fetch:async()=>{throw Error('unexpected network')}};vm.createContext(c);require('../v595/load-modules.cjs')(c,root);
vm.runInContext(fs.readFileSync(path.join(root,'backend/worker/src/request-notices.js'),'utf8').replace(/export /g,''),c);
vm.runInContext(source.replace(/^import .*;\s*$/mg,'').replace(/export default\s*\{/,'const worker = {').replace(/export class /g,'class '),c);
for(const m of source.matchAll(/`(CREATE TABLE IF NOT EXISTS [\s\S]*?)`/g)){if(!m[1].includes('${'))try{db.exec(m[1])}catch(e){throw Error('DDL '+e.message)}}
const env={DB,MEDIA:{async delete(){},async put(){}},LIVE_ROOM_HUB:null};
vm.runInContext(`getUser=async r=>{const a=r.headers.get('authorization');if(a==='Bearer admin')return{user_id:'0001',role:'ADMIN',full_name:'Admin'};if(a==='Bearer host')return{user_id:'0456',role:'USER',full_name:'Host'};if(a==='Bearer viewer')return{user_id:'0123',role:'USER',full_name:'Viewer'};return null};`,c);

(async()=>{
 await c.ensureLiveRoomSchema(env);
 for(const [id,name] of [['0123','Old Sender'],['0456','Host']])db.prepare("INSERT INTO myshop_auth_users_v108(user_id,full_name,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,active) VALUES(?,?,'test','q','a','q','a','q','a',1)").run(id,name);
 for(const [currency,value] of [['COIN',900],['GOLD',12]]){
 db.prepare("INSERT INTO myshop_live_gift_events(host_id,sender_id,receiver_id,gift_id,currency,price,status,created_at) VALUES('0456','0123','0456',1,?,?,'COMPLETED','2023-11-01 10:00:00')").run(currency,value);
 db.prepare("INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,host_id,gross_amount,net_amount,status,created_at) VALUES('GIFT',?,'0123','0456','0456',?,?,'COMPLETED','2023-11-01 10:00:00')").run(currency,value,value);
 }
 const reports=[];
 for(let round=1;round<=2;round++){
 counts={total:0,ddl:0};
 const r=await c.liveGiftSummary(new Request('https://test.local/v1/live/gifts/summary?hostId=0456',{headers:{authorization:'Bearer viewer'}}),env);assert.equal(r.status,200);const x=await r.json();assert.equal(x.topSupporters[0].coin_value,900);assert.equal(x.topSupporters[0].gold_value,12);assert.equal(x.myRank.rank,1);reports.push({endpoint:'giftSummary',round,...counts});
 counts={total:0,ddl:0};const f=await c.adminFinanceOverview(new Request('https://test.local/v1/admin/finance/overview',{headers:{authorization:'Bearer admin'}}),env);assert.equal(f.status,200);const y=await f.json();assert.equal(y.allTime.tx,2);assert.equal(y.currencySummary.COIN.allGross,900);assert.equal(y.currencySummary.GOLD.allGross,12);assert.equal(y.recent.filter(z=>z.created_at.startsWith('2023')).length,2);reports.push({endpoint:'financeOverview',round,...counts});
 }
 assert.equal(db.prepare('SELECT COUNT(*) n FROM myshop_live_gift_events').get().n,2);assert.equal(db.prepare('SELECT COUNT(*) n FROM myshop_value_ledger').get().n,2);
 console.log('PASS shipped read endpoints include 2023 completed gifts/ledger, preserve rows; local fixture SQL counts (not production latency): '+JSON.stringify(reports));
})().catch(e=>{console.error(e);process.exit(1)});
