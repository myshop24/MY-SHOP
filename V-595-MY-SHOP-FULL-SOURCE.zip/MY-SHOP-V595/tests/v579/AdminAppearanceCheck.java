import java.nio.file.*;
import java.util.*;
import javax.tools.*;
/** Compile and execute the shipped AdminAppearance against minimal UI doubles; not Android/device QA. */
public class AdminAppearanceCheck {
 static void source(Path root,String path,String text)throws Exception{Path p=root.resolve(path);Files.createDirectories(p.getParent());Files.writeString(p,text);}
 public static void main(String[] args)throws Exception{
  Path root=Files.createTempDirectory("myshop-admin-wheel-");
  try{
   source(root,"android/content/SharedPreferences.java","""
    package android.content; public class SharedPreferences {
      public final java.util.Map<String,Object> values=new java.util.HashMap<>();
      public int getInt(String k,int d){return (int)values.getOrDefault(k,d);} public boolean getBoolean(String k,boolean d){return (boolean)values.getOrDefault(k,d);}
      public SharedPreferences edit(){return this;} public SharedPreferences putInt(String k,int v){values.put(k,v);return this;} public SharedPreferences putBoolean(String k,boolean v){values.put(k,v);return this;} public void apply(){}
    }
   """);
   source(root,"android/app/Activity.java","""
    package android.app; public class Activity {
      public static final int MODE_PRIVATE=0; private final android.content.SharedPreferences prefs=new android.content.SharedPreferences();
      public android.content.SharedPreferences getSharedPreferences(String n,int m){return prefs;} public Resources getResources(){return new Resources();}
      public static class Resources {public Metrics getDisplayMetrics(){return new Metrics();}} public static class Metrics {public float density=1;}
    }
   """);
   source(root,"android/graphics/Color.java","package android.graphics; public class Color {public static final int WHITE=-1;public static int red(int c){return(c>>16)&255;}public static int green(int c){return(c>>8)&255;}public static int blue(int c){return c&255;}}");
   source(root,"android/widget/TextView.java","""
    package android.widget;public class TextView {public TextView(android.app.Activity a){}public void setText(String s){}public void setTextSize(int s){}public void setTextColor(int c){}public void setPadding(int a,int b,int c,int d){}public void setBackgroundColor(int c){}}
   """);
   source(root,"android/widget/Button.java","package android.widget;public class Button extends TextView {public Button(android.app.Activity a){super(a);}public interface Click {void call(Button b);}private Click click;public void setOnClickListener(Click c){click=c;}public void press(){click.call(this);}}");
   source(root,"android/widget/LinearLayout.java","package android.widget;public class LinearLayout extends TextView {public static final int VERTICAL=1;public final java.util.List<TextView> children=new java.util.ArrayList<>();public LinearLayout(android.app.Activity a){super(a);}public void setOrientation(int n){}public void addView(TextView v){children.add(v);}}");
   source(root,"com/myshop/app/Doubles.java","""
    package com.myshop.app;
    class SessionManager {static String getUserId(android.app.Activity a){return "0001";}}
    class ColorPicker {interface Selected {void color(int c);}static Selected pending;static void show(android.app.Activity a,int initial,Selected selected){pending=selected;}}
    class MyShopDialogBuilder {
      interface Click {void click(MyShopDialogBuilder d,int n);}static MyShopDialogBuilder last;android.widget.LinearLayout view;Click items,positive;
      MyShopDialogBuilder(android.app.Activity a){}MyShopDialogBuilder setTitle(String s){return this;}MyShopDialogBuilder setView(android.widget.LinearLayout v){view=v;return this;}
      MyShopDialogBuilder setItems(String[] s,Click c){items=c;return this;}MyShopDialogBuilder setSingleChoiceItems(String[] s,int at,Click c){items=c;return this;}
      MyShopDialogBuilder setPositiveButton(String s,Click c){positive=c;return this;}MyShopDialogBuilder setNegativeButton(String s,Click c){return this;}
      MyShopDialogBuilder show(){last=this;return this;}void dismiss(){}
    }
   """);
   source(root,"com/myshop/app/AdminAppearance.java",Files.readString(Path.of("app/src/main/java/com/myshop/app/AdminAppearance.java")));
   source(root,"com/myshop/app/WheelChecks.java","""
    package com.myshop.app;public class WheelChecks {public static void main(String[] args){
      android.app.Activity a=new android.app.Activity();int[] redraw={0};Runnable draw=()->redraw[0]++;
      int originalBg=AdminAppearance.background(a),originalCard=AdminAppearance.card(a);
      AdminAppearance.theme(a,draw);MyShopDialogBuilder.last.items.click(MyShopDialogBuilder.last,20);MyShopDialogBuilder custom=MyShopDialogBuilder.last;
      ((android.widget.Button)custom.view.children.get(1)).press();ColorPicker.pending.color(0xffffffff);
      ((android.widget.Button)custom.view.children.get(2)).press();ColorPicker.pending.color(0xff0044aa);
      if(AdminAppearance.background(a)!=originalBg||AdminAppearance.card(a)!=originalCard||redraw[0]!=0)throw new AssertionError("Selection changed persisted theme before Save");
      custom.positive.click(custom,0);MyShopDialogBuilder preview=MyShopDialogBuilder.last;
      if(AdminAppearance.background(a)!=originalBg||AdminAppearance.card(a)!=originalCard)throw new AssertionError("Preview persisted theme");
      preview.positive.click(preview,0);
      if(AdminAppearance.background(a)!=0xffffffff||AdminAppearance.card(a)!=0xff0044aa||redraw[0]!=1)throw new AssertionError("Explicit Save did not apply both selected colors exactly once");
      if(AdminAppearance.zoom(a)!=1f||AdminAppearance.english(a))throw new AssertionError("Unrelated preferences changed");
      System.out.println("PASS actual AdminAppearance: javac, shared picker for both targets, selection/preview do not save, explicit Save persists and redraws once, unrelated preferences retained.");
    }}
   """);
   JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();try(var fm=compiler.getStandardFileManager(null,null,null);var files=Files.walk(root)){
    var java=files.filter(p->p.toString().endsWith(".java")).map(Path::toFile).toList();if(!compiler.getTask(null,fm,null,List.of("-proc:none","-d",root.toString()),null,fm.getJavaFileObjectsFromFiles(java)).call())throw new AssertionError("AdminAppearance Java type check failed");
   }
   try(var loader=new java.net.URLClassLoader(new java.net.URL[]{root.toUri().toURL()})){loader.loadClass("com.myshop.app.WheelChecks").getMethod("main",String[].class).invoke(null,(Object)new String[0]);}
  }finally{try(var paths=Files.walk(root)){for(Path p:paths.sorted(Comparator.reverseOrder()).toList())Files.delete(p);}}
 }
}
