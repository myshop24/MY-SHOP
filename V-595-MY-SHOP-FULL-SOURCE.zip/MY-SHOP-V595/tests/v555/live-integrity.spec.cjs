const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const {DatabaseSync}=require('node:sqlite'),{webcrypto}=require('node:crypto');
const root=path.resolve(__dirname,'../..'),source=fs.readFileSync(path.join(root,'backend/worker/src/index.js'),'utf8');
const db=new DatabaseSync(':memory:');
function stmt(sql,args=[]){return{sql,args,bind(...a){if(a.some(v=>v===undefined))throw Error('undefined SQL bind');return stmt(sql,a)},async first(k){const x=db.prepare(sql).get(...args);return x?(k?x[k]:x):null},async all(){return{results:db.prepare(sql).all(...args)}},async run(){const x=db.prepare(sql).run(...args);return{success:true,meta:{changes:Number(x.changes),last_row_id:Number(x.lastInsertRowid)}}}}}
const DB={prepare:stmt,async batch(xs){db.exec('BEGIN');try{const out=[];for(const x of xs)out.push(await x.run());db.exec('COMMIT');return out}catch(e){db.exec('ROLLBACK');throw e}},async exec(sql){db.exec(sql);return{count:1}}};
const c={Response,Request,Headers,URL,URLSearchParams,File,FormData,Blob,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,atob,btoa,crypto:webcrypto,agoraRtcTokenPkg:{RtcTokenBuilder:{},Role:{}},setTimeout,clearTimeout,console,fetch:async()=>{throw Error('unexpected network')}};vm.createContext(c);require('../v595/load-modules.cjs')(c,root);
vm.runInContext(source.replace(/^import .*;\s*$/mg,'').replace(/export default\s*\{/,'const worker = {').replace(/export class /g,'class '),c);
for(const m of source.matchAll(/`(CREATE TABLE IF NOT EXISTS [\s\S]*?)`/g)){if(!m[1].includes('${'))try{db.exec(m[1])}catch(e){throw Error('DDL '+e.message)}}
const env={DB,MEDIA:{async delete(){},async put(){}},LIVE_ROOM_HUB:null};
vm.runInContext(`getUser=async r=>{const a=r.headers.get('authorization');if(a==='Bearer admin')return{user_id:'0001',role:'ADMIN',full_name:'Admin'};if(a==='Bearer host')return{user_id:'0456',role:'USER',full_name:'Host'};if(a==='Bearer viewer')return{user_id:'0123',role:'USER',full_name:'Viewer'};return null};isRoomAdmin=async()=>false;isAssignedModerator=async()=>false;liveSanctionFor=async()=>'';createUserNotification=async()=>{};liveHubDirty=async()=>{};`,c);
const req=(body,actor)=>new Request('https://test.local/v1/live/invite',{method:'POST',headers:{authorization:'Bearer '+actor,'content-type':'application/json'},body:JSON.stringify(body)});
(async()=>{
 await c.ensureLiveRoomSchema(env);await c.ensureFriendSchema(env);
 vm.runInContext(`applyLiveNamePolicy=async(e,u,n)=>({ok:true,name:n});`,c);
 const jobs=[];const ctx={waitUntil(p){jobs.push(p)}};
 let res=await c.livePresence(req({active:true,title:'Touhid'},'host'),env,ctx);let out=await res.json();assert.equal(res.status,200);assert.ok(out.sessionId);
 let meta=db.prepare("SELECT * FROM myshop_live_room_meta WHERE host_id='0456'").get();assert.equal(meta.theme_key,'GUITAR_BLUE');assert.ok(!meta.pinned_until);assert.equal(meta.title,'Touhid');assert.equal(meta.session_id,out.sessionId);
 await Promise.all(jobs);
 const first=out.sessionId;
 res=await c.liveReact(req({hostId:'0456'},'viewer'),env);assert.equal(res.status,200);assert.equal((await res.json()).reactCount,1);
 res=await c.liveReact(req({hostId:'0456'},'viewer'),env);assert.equal((await res.json()).reactCount,2);
 await DB.prepare("INSERT INTO myshop_live_events(host_id,session_id,user_id,event_type,message) VALUES('0456',?,'0123','JOIN','old join')").bind(first).run();
 await DB.prepare("INSERT INTO myshop_live_seats_dynamic(host_id,seat_no,user_id) VALUES('0456',2,'0123')").run();
 await DB.prepare("UPDATE myshop_live_presence SET active=0 WHERE user_id='0456'").run();
 res=await c.livePresence(req({active:true,title:'Touhid'},'host'),env,ctx);out=await res.json();assert.notEqual(out.sessionId,first);assert.equal(db.prepare("SELECT COUNT(*) n FROM myshop_live_events WHERE host_id='0456'").get().n,0);assert.equal(db.prepare("SELECT COUNT(*) n FROM myshop_live_seats_dynamic WHERE host_id='0456'").get().n,0);
 await Promise.all(jobs);
 // Late failure must roll back session metadata and active publication together.
 await DB.prepare("UPDATE myshop_live_presence SET active=0 WHERE user_id='0456'").run();
 const previous=db.prepare("SELECT session_id FROM myshop_live_room_meta WHERE host_id='0456'").get().session_id;
 db.exec("CREATE TRIGGER reject_live BEFORE UPDATE ON myshop_live_presence WHEN NEW.active=1 BEGIN SELECT RAISE(ABORT,'publish failure');END;");
 await assert.rejects(c.livePresence(req({active:true,title:'Touhid'},'host'),env,ctx),/publish failure/);
 assert.equal(db.prepare("SELECT active FROM myshop_live_presence WHERE user_id='0456'").get().active,0);assert.equal(db.prepare("SELECT session_id FROM myshop_live_room_meta WHERE host_id='0456'").get().session_id,previous);db.exec('DROP TRIGGER reject_live');
 // Repair active orphan left by failed V553 start.
 await DB.prepare("DELETE FROM myshop_live_room_meta WHERE host_id='0456'").run();await DB.prepare("UPDATE myshop_live_presence SET active=1 WHERE user_id='0456'").run();
 res=await c.livePresence(req({active:true,title:'Touhid'},'host'),env,ctx);assert.ok((await res.json()).sessionId);await Promise.all(jobs);
 db.exec("INSERT OR IGNORE INTO myshop_auth_users_v108(user_id,full_name,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash) VALUES('0456','Host','test','q','a','q','a','q','a'),('0123','Viewer','test','q','a','q','a','q','a')");
 const sid=db.prepare("SELECT session_id FROM myshop_live_room_meta WHERE host_id='0456'").get().session_id;
 const window='2026-10-03 00:00:00';
 await c.awardLiveReaction(env,'0456',sid,window,1999);assert.equal(db.prepare("SELECT count(*) n FROM myshop_live_reward_claims").get().n,0);
 await c.awardLiveReaction(env,'0456',sid,window,2000);await c.awardLiveReaction(env,'0456',sid,window,2100);
 assert.equal(db.prepare("SELECT balance FROM myshop_coin_wallets WHERE user_id='0456'").get().balance,1000);
 assert.equal(db.prepare("SELECT count(*) n FROM myshop_coin_transactions WHERE kind='REACTION_REWARD'").get().n,1);
 db.exec("CREATE TRIGGER reject_reward BEFORE INSERT ON myshop_coin_transactions WHEN NEW.kind='REACTION_REWARD' BEGIN SELECT RAISE(ABORT,'reward failure');END;");
 await assert.rejects(c.awardLiveReaction(env,'0456',sid,'other-window',2000),/reward failure/);
 assert.equal(db.prepare("SELECT balance FROM myshop_coin_wallets WHERE user_id='0456'").get().balance,1000);
 assert.equal(db.prepare("SELECT count(*) n FROM myshop_live_reward_claims").get().n,1);db.exec('DROP TRIGGER reject_reward');
 await DB.prepare("INSERT INTO myshop_live_reacts(host_id,session_id,user_id,react_count) VALUES('0456',?,'0123',100)").bind(sid).run();
 db.exec("UPDATE myshop_live_room_meta SET react_window_started_at=datetime('now','-25 hours'),react_count=100,react_reward_milestone=1 WHERE host_id='0456'");
 await c.resetLiveReactionWindow(env,'0456');assert.equal(db.prepare("SELECT count(*) n FROM myshop_live_reacts").get().n,0);assert.equal(db.prepare("SELECT react_count FROM myshop_live_room_meta WHERE host_id='0456'").get().react_count,0);
 res=await c.liveReact(req({hostId:'0456'},'viewer'),env);assert.equal((await res.json()).reactCount,1);
 for(let n=1;n<100;n++)await c.liveReact(req({hostId:'0456'},'viewer'),env);
 res=await c.liveReact(req({hostId:'0456'},'viewer'),env);assert.equal(res.status,409);assert.equal(db.prepare("SELECT react_count FROM myshop_live_room_meta WHERE host_id='0456'").get().react_count,100);
 // Retried viewer registration must add exactly one JOIN event.
 await c.liveViewer(req({hostId:'0456',joined:true},'viewer'),env);await c.liveViewer(req({hostId:'0456',joined:true},'viewer'),env);
 assert.equal(db.prepare("SELECT count(*) n FROM myshop_live_events WHERE host_id='0456' AND event_type='JOIN'").get().n,1);
 const landing=c.liveSharePage(new URL('https://test.local/live?hostId=0456&sessionId='+sid));assert.equal(landing.status,200);const html=await landing.text();assert.ok(html.includes('intent://live?hostId=0456'));assert.ok(html.includes('MY_SHOP_FINAL_RELEASE.apk'));assert.ok(!html.includes('SOURCE.zip'));assert.equal(c.liveSharePage(new URL('https://test.local/live?hostId=<script>&sessionId=x')).status,400);
 console.log('PASS — reward threshold, once-only credit, ledger, atomic reward rollback, 24h reset, per-user limit, duplicate JOIN prevention, validated live landing');
 console.log('PASS — real SQLite start, 20-column metadata, fresh session, stale event/seat cleanup, reaction counts, atomic rollback, orphan recovery, background notification scheduling');
})().catch(e=>{console.error(e);process.exit(1)});
