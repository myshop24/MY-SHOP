const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('backend/worker/src/index.js','utf8');const start=source.indexOf('async function storeGiftPurchaseRequest('),end=source.indexOf('async function liveTvChannels(',start);
let touchedBalance=false;
const context={Response,cors:{},getUser:async()=>({user_id:'0100'}),ensureLiveRoomSchema:async()=>{},body:r=>r.json(),isFourDigit:v=>/^\d{4}$/.test(v),activePremiumOwned:async()=>null,financeConfig:async()=>({vatPercent:10}),calcVat:(base,rate)=>Math.round(base*rate/100),walletSourceState:async()=>{touchedBalance=true;throw Error('BALANCE_REACHED')},json:(value,status)=>new Response(JSON.stringify(value),{status})};vm.createContext(context);vm.runInContext(source.slice(start,end),context);
const env={DB:{prepare:sql=>({bind(){return this},async first(){if(sql.includes('myshop_auth_users'))return{user_id:'0101',full_name:'Recipient'};if(sql.includes('FROM myshop_store_catalog'))return{id:1,gold_price:1000};return null;}})}};
const request=quote=>new Request('https://test/gift',{method:'POST',body:JSON.stringify({productId:1,recipientUserId:'0101',...quote})});
(async()=>{
 for(const quote of [{expectedBase:1000,expectedVat:0,expectedTotal:1000},{expectedBase:1000},{expectedBase:'1000',expectedVat:100,expectedTotal:1100}]){touchedBalance=false;const response=await context.storeGiftPurchaseRequest(request(quote),env);assert.equal(response.status,409);assert.equal((await response.json()).error,'GIFT_QUOTE_CHANGED');assert.equal(touchedBalance,false);}
 for(const quote of [{expectedBase:1000,expectedVat:100,expectedTotal:1100},{}]){await assert.rejects(context.storeGiftPurchaseRequest(request(quote),env),/BALANCE_REACHED/);}
 console.log('PASS changed/invalid Gift quote refused before balance access; matching quote and legacy clients retain existing path');
})().catch(e=>{console.error(e);process.exitCode=1});
