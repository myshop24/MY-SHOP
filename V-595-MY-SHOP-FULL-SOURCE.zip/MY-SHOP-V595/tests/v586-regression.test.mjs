import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {filterPersonalDetailsForViewer,maskProfileCore} from '../backend/worker/src/profile-details.js';
import {normalizeVisualStyles} from '../backend/worker/src/visual-design.js';
test('Custom details require current exact field grant; public preview and revoked grants reveal nothing',()=>{
 const rows=[{field_key:'contact',value:'private number',visibility:'CUSTOM'},{field_key:'location',value:'city',visibility:'PUBLIC'}];
 const grants=[{field_key:'contact',viewer_id:'0101'}];
 assert.equal(filterPersonalDetailsForViewer(rows,'0100','0101','NONE',grants).length,2);
 for(const viewer of ['','0102'])assert.deepEqual(filterPersonalDetailsForViewer(rows,'0100',viewer,'FRIEND',grants),[{field_key:'location',value:'city'}]);
 assert.equal(filterPersonalDetailsForViewer(rows,'0100','0101','NONE',[]).length,1);
 assert.equal(filterPersonalDetailsForViewer(rows,'0100','0100','SELF',[]).length,2);
});
test('selected text styles validate ranges and bounded font sizes without accepting routes or HTML properties',()=>{
 const segment={source:'MY SHOP',start:0,end:2,text:'#ff0000',fontSize:32};
 assert.equal(normalizeVisualStyles({root:{segments:[segment]}}).root.segments[0].text,'#FF0000');
 for(const invalid of [{...segment,start:-1},{...segment,end:99},{...segment,fontSize:49},{...segment,route:'delete'}])assert.throws(()=>normalizeVisualStyles({root:{segments:[invalid]}}));
});
test('withdrawal amount editor and quote-driven selection remain present without new demo presets',()=>{
 const screen=fs.readFileSync('app/src/main/java/com/myshop/app/CoinWithdrawalActivity.java','utf8');
 const editor=fs.readFileSync('app/src/main/java/com/myshop/app/WithdrawalCatalogAdminActivity.java','utf8');
 assert.match(screen,/BackendClient\.withdrawalOptions/);assert.match(screen,/requestQuotedWithdrawal/);assert.match(screen,/quotes=d\.optJSONArray\("quotes"\)/);
 assert.match(editor,/amounts\.setText\(values\)/);assert.match(editor,/put\("amounts",values\)/);
});

test('core Profile visibility masks actual response fields and preserves owner/allowed Custom access',()=>{
 const profile={userId:'0100',name:'Real name',bio:'private bio',avatarUrl:'photo',coverUrl:'cover',joinedAt:'date',socialLinks:[{url:'link'}]};
 const rows=[{field_key:'name',value:'configured',visibility:'ONLY_ME'},{field_key:'bio',value:'configured',visibility:'FRIENDS'},{field_key:'profile_photo',value:'configured',visibility:'CUSTOM'},{field_key:'social_links',value:'configured',visibility:'ONLY_ME'},{field_key:'user_id',value:'configured',visibility:'ONLY_ME'}];
 const stranger=maskProfileCore(profile,rows,'0100','0102','NONE',[]);assert.equal(stranger.name,'MY SHOP User');assert.equal(stranger.bio,'');assert.equal(stranger.avatarUrl,'');assert.deepEqual(stranger.socialLinks,[]);assert.equal(stranger.userIdVisible,false);assert.equal(stranger.coverUrl,'cover');
 const friend=maskProfileCore(profile,rows,'0100','0101','FRIEND',[{field_key:'profile_photo',viewer_id:'0101'}]);assert.equal(friend.bio,'private bio');assert.equal(friend.avatarUrl,'photo');assert.equal(friend.name,'MY SHOP User');
 const owner=maskProfileCore(profile,rows,'0100','0100','SELF',[]);assert.equal(owner.name,'Real name');assert.equal(owner.avatarUrl,'photo');assert.equal(owner.userIdVisible,true);
 assert.equal(maskProfileCore(profile,[], '0100','0102','NONE').name,'Real name');
});
