const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const {DatabaseSync}=require('node:sqlite'),{webcrypto}=require('node:crypto');
const root=path.resolve(__dirname,'../..'),source=fs.readFileSync(path.join(root,'backend/worker/src/index.js'),'utf8');
const db=new DatabaseSync(':memory:');
function stmt(sql,args=[]){return{sql,args,bind(...a){if(a.some(v=>v===undefined))throw Error('undefined SQL bind');return stmt(sql,a)},async first(k){const x=db.prepare(sql).get(...args);return x?(k?x[k]:x):null},async all(){return{results:db.prepare(sql).all(...args)}},async run(){const x=db.prepare(sql).run(...args);return{success:true,meta:{changes:Number(x.changes),last_row_id:Number(x.lastInsertRowid)}}}}}
const DB={prepare:stmt,async batch(xs){db.exec('BEGIN');try{const out=[];for(const x of xs)out.push(await x.run());db.exec('COMMIT');return out}catch(e){db.exec('ROLLBACK');throw e}},async exec(sql){db.exec(sql);return{count:1}}};
const c={Response,Request,Headers,URL,URLSearchParams,File,FormData,Blob,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,atob,btoa,crypto:webcrypto,agoraRtcTokenPkg:{RtcTokenBuilder:{},Role:{}},setTimeout,clearTimeout,console,fetch:async()=>{throw Error('unexpected network')}};vm.createContext(c);require('../v595/load-modules.cjs')(c,root);
vm.runInContext(source.replace(/^import .*;\s*$/mg,'').replace(/export default\s*\{/,'const worker = {').replace(/export class /g,'class '),c);
for(const m of source.matchAll(/`(CREATE TABLE IF NOT EXISTS [\s\S]*?)`/g)){if(!m[1].includes('${'))try{db.exec(m[1])}catch(e){throw Error('DDL '+e.message)}}
const env={DB,MEDIA:{async delete(){},async put(){}},LIVE_ROOM_HUB:null};
vm.runInContext(`getUser=async r=>{const a=r.headers.get('authorization');if(a==='Bearer admin')return{user_id:'0001',role:'ADMIN',full_name:'Admin'};if(a==='Bearer viewer')return{user_id:'0123',role:'USER',full_name:'Viewer'};return null};isRoomAdmin=async()=>false;isAssignedModerator=async()=>false;liveSanctionFor=async()=>'';createUserNotification=async()=>{};liveHubDirty=async()=>{};`,c);
const req=(body,actor)=>new Request('https://test.local/v1/live/invite',{method:'POST',headers:{authorization:'Bearer '+actor,'content-type':'application/json'},body:JSON.stringify(body)});
(async()=>{
 await c.ensureLiveRoomSchema(env);
 for(const [id,name,role] of [['0001','Admin','ADMIN'],['0456','Host','USER'],['0123','Viewer','USER']])await DB.prepare("INSERT INTO myshop_auth_users_v108(user_id,full_name,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role,active) VALUES(?,?,'test','q','a','q','a','q','a',?,1)").bind(id,name,role).run();
 await DB.prepare("INSERT INTO myshop_live_presence(user_id,active) VALUES('0456',1)").run();
 await DB.prepare("INSERT INTO myshop_live_viewers(host_id,user_id,last_seen,joined_at) VALUES('0456','0123',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)").run();
 await DB.prepare("INSERT INTO myshop_live_room_meta(host_id,session_id) VALUES('0456','v547-direct-call')").run();
 const result=await c.liveInvite(req({hostId:'0456',userId:'0123'},'admin'),env),body=await result.json();
 assert.equal(result.status,200);assert.equal(body.status,'PENDING');assert.equal(body.invitedBy,'0001');
 assert.equal(db.prepare("SELECT status FROM myshop_live_invites WHERE host_id='0456' AND user_id='0123'").get().status,'PENDING');
 assert.equal(db.prepare("SELECT COUNT(*) n FROM myshop_live_call_suggestions WHERE host_id='0456'").get().n,0);
 const accept=new Request('https://test.local/v1/live/invite/action',{method:'POST',headers:{authorization:'Bearer viewer','content-type':'application/json'},body:JSON.stringify({hostId:'0456',action:'ACCEPT'})});
 const accepted=await c.liveInviteAction(accept,env),ack=await accepted.json();assert.equal(accepted.status,200);assert.equal(ack.status,'ACCEPTED');
 assert.ok(db.prepare("SELECT seat_no FROM myshop_live_seats_dynamic WHERE host_id='0456' AND user_id='0123'").get());
 console.log('PASS — Admin sends a direct viewer invite; viewer acceptance seats them without host approval');
})().catch(e=>{console.error(e);process.exitCode=1});
