const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const {DatabaseSync}=require('node:sqlite'),{webcrypto}=require('node:crypto');
const root=path.resolve(__dirname,'../..'),source=fs.readFileSync(path.join(root,'backend/worker/src/index.js'),'utf8');
const db=new DatabaseSync(':memory:');
function stmt(sql,args=[]){return{sql,args,bind(...a){if(a.some(v=>v===undefined))throw Error('undefined SQL bind');return stmt(sql,a)},async first(k){const x=db.prepare(sql).get(...args);return x?(k?x[k]:x):null},async all(){return{results:db.prepare(sql).all(...args)}},async run(){const x=db.prepare(sql).run(...args);return{success:true,meta:{changes:Number(x.changes),last_row_id:Number(x.lastInsertRowid)}}}}}
const DB={prepare:stmt,async batch(xs){db.exec('BEGIN');try{const out=[];for(const x of xs)out.push(await x.run());db.exec('COMMIT');return out}catch(e){db.exec('ROLLBACK');throw e}},async exec(sql){db.exec(sql);return{count:1}}};
const c={Response,Request,Headers,URL,URLSearchParams,File,FormData,Blob,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,atob,btoa,crypto:webcrypto,agoraRtcTokenPkg:{RtcTokenBuilder:{},Role:{}},setTimeout,clearTimeout,console,fetch:async()=>{throw Error('unexpected network')}};vm.createContext(c);require('../v595/load-modules.cjs')(c,root);
vm.runInContext(source.replace(/^import .*;\s*$/mg,'').replace(/export default\s*\{/,'const worker = {').replace(/export class /g,'class '),c);
for(const m of source.matchAll(/`(CREATE TABLE IF NOT EXISTS [\s\S]*?)`/g)){if(!m[1].includes('${'))try{db.exec(m[1])}catch(e){throw Error('DDL '+e.message)}}
const env={DB,MEDIA:{async delete(){},async put(){}},LIVE_ROOM_HUB:null};
vm.runInContext(`getUser=async r=>{const a=r.headers.get('authorization');if(a==='Bearer admin')return{user_id:'0001',role:'ADMIN',full_name:'Admin'};if(a==='Bearer host')return{user_id:'0456',role:'USER',full_name:'Host'};if(a==='Bearer viewer')return{user_id:'0123',role:'USER',full_name:'Viewer'};return null};isRoomAdmin=async()=>false;isAssignedModerator=async()=>false;liveSanctionFor=async()=>'';createUserNotification=async()=>{};liveHubDirty=async()=>{};`,c);
const req=(body,actor)=>new Request('https://test.local/v1/live/invite',{method:'POST',headers:{authorization:'Bearer '+actor,'content-type':'application/json'},body:JSON.stringify(body)});
(async()=>{
 await c.ensureLiveRoomSchema(env);
 await DB.prepare("INSERT INTO myshop_live_presence(user_id,active) VALUES('0456',1)").run();
 await DB.prepare("INSERT INTO myshop_live_room_meta(host_id,session_id) VALUES('0456','session-a')").run();
 assert.equal((await c.liveHostHeartbeat(req({sessionId:'session-a'},'host'),env)).status,200);
 assert.equal((await c.liveHostHeartbeat(req({sessionId:'wrong'},'host'),env)).status,409);
 assert.equal((await c.liveHostHeartbeat(req({sessionId:'session-a'},'viewer'),env)).status,409);
 assert.equal((await c.liveHostHeartbeat(req({},'host'),env)).status,409);
 assert.equal((await c.liveHostHeartbeat(req({sessionId:'session-a'},'unknown'),env)).status,401);
 await DB.prepare("UPDATE myshop_live_room_meta SET started_at=CURRENT_TIMESTAMP WHERE host_id='0456'").run();
 await DB.prepare("INSERT INTO myshop_live_seats_dynamic(host_id,seat_no,user_id) VALUES('0456',2,'0123')").run();
 const end=await c.liveEnd(req({},'host'),env);assert.equal(end.status,200);assert.equal((await end.json()).closed,true);
 assert.equal(db.prepare("SELECT active FROM myshop_live_presence WHERE user_id='0456'").get().active,0);
 assert.equal(db.prepare("SELECT COUNT(*) n FROM myshop_live_seats_dynamic WHERE host_id='0456'").get().n,0);
 assert.equal(db.prepare("SELECT COUNT(*) n FROM myshop_live_history WHERE host_id='0456'").get().n,1);
 assert.equal((await c.liveHostHeartbeat(req({sessionId:'session-a'},'host'),env)).status,409);
 assert.equal(db.prepare("SELECT active FROM myshop_live_presence WHERE user_id='0456'").get().active,0);
 assert.equal((await c.liveEnd(req({},'host'),env)).status,200);
 await DB.prepare("UPDATE myshop_live_presence SET active=1 WHERE user_id='0456'").run();
 await DB.prepare("INSERT INTO myshop_live_room_meta(host_id,session_id) VALUES('0456','session-b')").run();
 assert.equal((await c.liveHostHeartbeat(req({sessionId:'session-a'},'host'),env)).status,409);
 assert.equal((await c.liveHostHeartbeat(req({sessionId:'session-b'},'host'),env)).status,200);
 console.log('PASS — session heartbeat ownership, stale-session rejection, end closure, idempotent end, delayed-heartbeat non-resurrection');
})().catch(e=>{console.error(e);process.exitCode=1});
