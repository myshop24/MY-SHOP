from pathlib import Path
import sqlite3

root = Path(__file__).resolve().parents[2]
worker = (root / 'backend/worker/src/index.js').read_text()
main = (root / 'app/src/main/java/com/myshop/app/MainActivity.java').read_text()
live = (root / 'app/src/main/java/com/myshop/app/LiveHomeActivity.java').read_text()
admin = (root / 'app/src/main/java/com/myshop/app/BannerAdminActivity.java').read_text()
page2_admin = (root / 'app/src/main/java/com/myshop/app/LiveHomeAdminActivity.java').read_text()

# Apply the forward-only migration to a representative pre-V565 D1 schema and
# verify that an existing banner remains while all three independent sections default on.
db = sqlite3.connect(':memory:')
db.executescript('CREATE TABLE banners (id INTEGER PRIMARY KEY, folder TEXT, slot INTEGER, image_url TEXT); INSERT INTO banners VALUES (7, "hero", 1, "https://example.test/banner.jpg");')
db.executescript((root / 'backend/worker/migrations/0053_v565_banner_rows.sql').read_text())
assert db.execute('SELECT folder,enabled FROM myshop_banner_sections ORDER BY folder').fetchall() == [('hero', 1), ('live_home', 1), ('promo', 1)]
assert db.execute('SELECT image_url FROM banners WHERE id=7').fetchone() == ('https://example.test/banner.jpg',)
# Per-banner settings live in a separate table; legacy banner rows are not rewritten.
db.execute("INSERT INTO myshop_banner_durations(folder,slot) VALUES('hero',1)")
assert db.execute("SELECT display_seconds FROM myshop_banner_durations WHERE folder='hero' AND slot=1").fetchone() == (4,)
assert 'display_seconds' not in {row[1] for row in db.execute('PRAGMA table_info(banners)')}

# Cross-layer contracts: admin settings are persisted server-side, hidden rows are omitted,
# and client carousel timers read the configured per-banner seconds.
assert "async function adminBannerSection" in worker and "myshop_banner_sections" in worker
assert "myshop_banner_durations" in worker and "display_seconds" in worker and "sectionEnabled" in worker
assert "WHERE b.active=1 AND (b.folder NOT IN ('hero','promo')" in worker
assert 'adminBannerSection(' in admin and 'SAVE/PUBLISH' in admin
assert 'adminBannerSection(' in page2_admin and 'readSeconds(duration)' in page2_admin
assert 'currentHeroIntervalMs()' in main and 'display_seconds' in main
assert 'bannerSectionEnabled' in live and 'currentBannerIntervalMs()' in live
print('PASS V-565 banner section migration preserves existing banners, defaults sections enabled, and exposes per-banner durations through admin and carousel paths')
