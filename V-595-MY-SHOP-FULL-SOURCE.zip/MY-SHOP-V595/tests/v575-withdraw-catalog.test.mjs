import {DatabaseSync} from 'node:sqlite';import assert from 'node:assert/strict';
import {readCatalog,termsFor,normalizeCatalog,withdrawCatalog} from '../backend/worker/src/withdraw-catalog.js';
const db=new DatabaseSync(':memory:');db.exec(`CREATE TABLE myshop_auth_users_v108(user_id TEXT PRIMARY KEY,active INTEGER);INSERT INTO myshop_auth_users_v108 VALUES('0001',1),('0100',1),('0002',0);`);
let failAudit=false;const prepare=(sql,args=[])=>({bind(...v){return prepare(sql,v)},async first(){return db.prepare(sql).get(...args)||null},async run(){if(failAudit&&sql.startsWith('INSERT INTO myshop_withdraw_catalog_audit'))throw Error('AUDIT_FAILURE');const r=db.prepare(sql).run(...args);return {meta:{changes:Number(r.changes)}}}});let queue=Promise.resolve();const DB={prepare,batch(list){const r=queue.then(async()=>{db.exec('BEGIN');try{const result=[];for(const s of list)result.push(await s.run());db.exec('COMMIT');return result}catch(e){db.exec('ROLLBACK');throw e}});queue=r.catch(()=>{});return r}};
const finance={coinCommissionPercent:10,goldCommissionPercent:5,unitsPer600Taka:100000};
const h={getUser:async r=>({user_id:r.headers.get('actor')}),financeConfig:async()=>finance,json:(d,status)=>new Response(JSON.stringify(d),{status}),cors:{}};
const call=(actor,currency,body=null,admin=false)=>withdrawCatalog(new Request(`https://test/v1/${admin?'admin/withdraw-catalog':'wallet/withdraw-options'}?currency=${currency}`,{method:body?'POST':'GET',headers:{actor,'content-type':'application/json'},...(body?{body:JSON.stringify(body)}:{})}),{DB},h);
let coin=await readCatalog(DB,'COIN'),gold=await readCatalog(DB,'GOLD');assert(coin.amounts.includes(300000));
assert.equal(termsFor(coin,finance,300000).cashMinor,180000);assert.equal(termsFor(gold,finance,300000).cashMinor,180000);
assert.equal(termsFor({...coin,enabled:false},finance,300000).error,'WITHDRAWAL_UNAVAILABLE');
assert.equal(termsFor({...coin,endsAt:'2026-01-01'},finance,300000,Date.parse('2026-01-02')).error,'WITHDRAWAL_UNAVAILABLE');
assert.throws(()=>normalizeCatalog({amounts:[-1],methods:['bank']}),/INVALID_AMOUNT/);assert.throws(()=>normalizeCatalog({amounts:[1000],methods:['fake']}),/INVALID_METHOD/);
for (const property of ['enabled','published']) for (const value of ['false','true',0,1,null,{},[]]) {
 assert.throws(()=>normalizeCatalog({amounts:[300000],methods:['bkash'],[property]:value}),/INVALID_AVAILABILITY/);
}
assert.equal((await call('0100','COIN',null,true)).status,403);assert.equal((await call('0002','COIN',null,true)).status,401);
const config={feeMode:'INCLUDED',amounts:[300000,800000],methods:['bkash','bank'],processingDays:7,unitsPer600Taka:200000,enabled:true,published:true};const update={currency:'COIN',expectedRevision:0,config};
assert.equal((await call('0001','COIN',update,true)).status,200);assert.equal((await call('0001','COIN',update,true)).status,409);
const options=await(await call('0100','COIN')).json();assert.equal(options.quotes[0].cashMinor,81000);assert.equal(options.quotes[0].processingDays,7);assert.deepEqual(options.methods,['bkash','bank']);
assert.equal((await readCatalog(DB,'GOLD')).revision,0);
failAudit=true;await assert.rejects(call('0001','COIN',{...update,expectedRevision:1,config:{...config,enabled:false}},true),/AUDIT_FAILURE/);failAudit=false;
assert.equal((await readCatalog(DB,'COIN')).enabled,true);
const raced=await Promise.all([call('0001','COIN',{...update,expectedRevision:1},true),call('0001','COIN',{...update,expectedRevision:1,config:{...config,published:false}},true)]);assert.equal(raced.filter(r=>r.status===200).length,1);
console.log('PASS withdrawal catalog: separate currencies, server amounts/conversion/commission, published availability, processing terms, owner authorization, revision conflict and audit rollback');
