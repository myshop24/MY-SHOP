import com.myshop.app.SlotOrder;
import com.myshop.app.Home2Metrics;
import java.util.*;

/** Runs real pure-Java production helpers, not a reimplementation of their algorithms. */
public final class SlotAndLayoutTest {
    private static int cases;
    private static void require(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args){
        for(int size=1;size<=24;size++)for(int from=0;from<size;from++)for(int to=0;to<size;to++){
            List<Integer> actual=new ArrayList<>();for(int i=0;i<size;i++)actual.add(i);
            require(SlotOrder.move(actual,from,to)==(from!=to),"change result");
            require(actual.size()==size&&actual.get(to)==from,"exact destination");
            require(new HashSet<>(actual).size()==size,"every icon preserved once");
            List<Integer> others=new ArrayList<>(actual);others.remove(Integer.valueOf(from));
            List<Integer> originalOthers=new ArrayList<>();for(int i=0;i<size;i++)if(i!=from)originalOthers.add(i);
            require(others.equals(originalOthers),"others must shift, not swap");cases++;
        }
        List<Integer> one=new ArrayList<>(Arrays.asList(7));
        require(!SlotOrder.move(null,0,1),"null list");require(!SlotOrder.move(one,-1,0),"negative index");
        require(!SlotOrder.move(one,0,3)&&one.equals(Arrays.asList(7)),"invalid position does not mutate");
        System.out.println("PASS: "+cases+" real insert-at-slot ordering cases, plus invalid-index guards.");
        int layouts=0;
        for(int width:new int[]{320,360,375,390,393,412,430,480,600,800}){
            Home2Metrics m=new Home2Metrics(width);
            for(int[] row:new int[][]{{4,4},{8,3},{3,4},{6,4}}){int total=m.itemWidthDp(row[0],row[1])*row[0]+row[1]*(row[0]-1);require(total<=m.widthDp,"horizontal row exceeds available width");require(m.itemWidthDp(row[0],row[1])>0,"positive width");layouts++;}
            require(m.bannerHeightDp>=58&&m.bannerHeightDp<=98,"bounded banner height");
            require(m.bodyHeightDp()<=625,"normal-density dashboard size budget");
        }
        System.out.println("PASS: "+layouts+" horizontal row-width cases and banner/dashboard height budgets.");
        System.out.println("Android measured rendering, font scaling and touch gestures: NOT TESTED here.");
    }
}
