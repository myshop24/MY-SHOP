import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {preparePostAppearance,insertStyledPost} from '../backend/worker/src/post-appearance.js';
import fs from 'node:fs';
const db=new DatabaseSync(':memory:');db.exec(`CREATE TABLE myshop_auth_users_v108(user_id TEXT PRIMARY KEY,role TEXT,active INTEGER);INSERT INTO myshop_auth_users_v108 VALUES('0001','ADMIN',1),('0106','USER',1),('0107','USER',1);CREATE TABLE myshop_posts(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT,caption TEXT,media_url TEXT,object_key TEXT,media_type TEXT,status TEXT);`);
const prepare=(sql,args=[])=>({bind(...a){return prepare(sql,a)},async first(){return db.prepare(sql).get(...args)||null},async run(){const r=db.prepare(sql).run(...args);return {meta:{changes:Number(r.changes),last_row_id:Number(r.lastInsertRowid)}}}});
const DB={prepare,async batch(items){db.exec('BEGIN');try{const out=[];for(const i of items)out.push(await i.run());db.exec('COMMIT');return out;}catch(e){db.exec('ROLLBACK');throw e;}}};const env={DB},admin={user_id:'0001'},user={user_id:'0106'};
const styles={element_caption:{text:'#FF0000',textEnd:'#0000FF',background:'#FFFFFF',segments:[{source:'Hello world',start:6,end:11,text:'#00FF00'}]}};
assert.equal(await preparePostAppearance(env,user,'plain',undefined),null);
assert.deepEqual(await preparePostAppearance(env,admin,'Hello world',styles),styles);
await assert.rejects(()=>preparePostAppearance(env,user,'Hello world',styles),/PERMISSION/);
await assert.rejects(()=>preparePostAppearance(env,admin,'changed',styles),/SOURCE_CHANGED/);
await assert.rejects(()=>preparePostAppearance(env,admin,'Hello world',{element_name:{text:'#FF0000'}}),/INVALID_APPEARANCE/);
let r=await insertStyledPost(env,admin,'Hello world','','','text',styles);assert.equal(r.meta.last_row_id,1);
let row=db.prepare("SELECT * FROM myshop_visual_designs WHERE scope='appearance:post_1'").get();assert.deepEqual(JSON.parse(row.published),styles);assert.equal(row.revision,1);assert.equal(db.prepare('SELECT COUNT(*) n FROM myshop_visual_design_events').get().n,1);
db.exec("INSERT INTO myshop_appearance_grants(user_id,status) VALUES('0106',1)");await preparePostAppearance(env,user,'Hello world',styles);r=await insertStyledPost(env,user,'Hello world','url','key','image',styles);assert.equal(r.meta.last_row_id,2);
db.exec("UPDATE myshop_appearance_grants SET status=0 WHERE user_id='0106'");await assert.rejects(()=>insertStyledPost(env,user,'Hello world','','','text',styles),/PERMISSION_CHANGED/);assert.equal(db.prepare('SELECT COUNT(*) n FROM myshop_posts').get().n,2);assert.equal(db.prepare('SELECT COUNT(*) n FROM myshop_visual_designs').get().n,2);
db.exec("CREATE TRIGGER audit_fail BEFORE INSERT ON myshop_visual_design_events BEGIN SELECT RAISE(ABORT,'audit unavailable'); END");await assert.rejects(()=>insertStyledPost(env,admin,'Hello world','','','text',styles),/audit unavailable/);assert.equal(db.prepare('SELECT COUNT(*) n FROM myshop_posts').get().n,2);assert.equal(db.prepare('SELECT COUNT(*) n FROM myshop_visual_designs').get().n,2);
const worker=fs.readFileSync('backend/worker/src/index.js','utf8');const oldWorker=fs.readFileSync('tests/v594-feed-baseline.txt','utf8');
function fn(source,name){const start=source.indexOf('async function '+name+'('),end=source.indexOf('\nasync function ',start+1);return source.slice(start,end<0?undefined:end).trim();}
for(const name of ['feedText','feedUpload']){let now=fn(worker,name);now=now.replace(/^  let appearance=null;try\{.*\}\n/gm,'').replace('appearance?await insertStyledPost(env,user,caption,mediaUrl,key,mediaType,appearance):','').replace("appearance?await insertStyledPost(env,user,caption,'','','text',appearance):",'');assert.equal(now,fn(oldWorker,name),'plain publishing/quota exact V593 preservation');}
console.log('PASS V594 styled text/media atomic insert, public publication, permission denial/revocation, source validation, audit rollback and exact plain-feed preservation');
