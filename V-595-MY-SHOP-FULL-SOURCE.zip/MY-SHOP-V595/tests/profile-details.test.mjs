import assert from 'node:assert/strict';
import test from 'node:test';
import {filterPersonalDetailsForViewer, normalizeUserSocialUrl} from '../backend/worker/src/profile-details.js';

const details=[
  {field_key:'location',value:'Satkania',visibility:'PUBLIC'},
  {field_key:'birthday',value:'January 1',visibility:'FRIENDS'},
  {field_key:'family',value:'',visibility:'PUBLIC'},
  {field_key:'gender',value:'Female',visibility:'ONLY_ME'},
];

test('owner can see filled Personal Details at every privacy level, without empty fields',()=>{
  assert.deepEqual(filterPersonalDetailsForViewer(details,'0100','0100','SELF'),[
    {field_key:'location',value:'Satkania'},
    {field_key:'birthday',value:'January 1'},
    {field_key:'gender',value:'Female'},
  ]);
});

test('public viewers see only Public details',()=>{
  assert.deepEqual(filterPersonalDetailsForViewer(details,'0100','0101','NONE'),[
    {field_key:'location',value:'Satkania'},
  ]);
});

test('accepted friends see Public and Friends details, not Only Me',()=>{
  assert.deepEqual(filterPersonalDetailsForViewer(details,'0100','0101','FRIEND'),[
    {field_key:'location',value:'Satkania'},
    {field_key:'birthday',value:'January 1'},
  ]);
});

test('social URL normalization keeps safe web links and imo phone links',()=>{
  assert.equal(normalizeUserSocialUrl('facebook.com/example','Facebook'),'https://facebook.com/example');
  assert.equal(normalizeUserSocialUrl('+1 (234) 567-8901','imo'),'tel:+12345678901');
  assert.equal(normalizeUserSocialUrl('javascript:alert(1)','TikTok'),null);
  assert.equal(normalizeUserSocialUrl('https://user:secret@example.com','Page'),null);
});
