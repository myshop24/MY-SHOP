const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
module.exports=function(context,root){
 for(const name of ['live-read-cache','commission-management','withdraw-wallet-hold']){
  const source=fs.readFileSync(path.join(root,'backend/worker/src',name+'.js'),'utf8');
  const names=[...source.matchAll(/export\s+(?:async\s+)?(?:function|const)\s+(\w+)/g)].map(m=>m[1]);
  vm.runInContext('(()=>{'+source.replace(/export /g,'')+';Object.assign(globalThis,{'+names.join(',')+'});})()',context,{filename:name+'.js'});
 }
};
