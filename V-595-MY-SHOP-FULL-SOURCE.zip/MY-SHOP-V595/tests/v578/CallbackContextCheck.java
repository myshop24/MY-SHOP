import java.nio.file.*;
import java.util.*;
import javax.tools.*;
import com.sun.source.tree.*;
import com.sun.source.util.*;

/** Finds bare-this Context arguments in anonymous classes, including their nested lambdas. */
public class CallbackContextCheck {
 public static void main(String[] args)throws Exception {
  JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();int[] failures={0},count={0};
  try(var fm=compiler.getStandardFileManager(null,null,null)){
   List<java.io.File> files=new ArrayList<>();try(var paths=Files.walk(Path.of(args[0]))){paths.filter(p->p.toString().endsWith(".java")).forEach(p->files.add(p.toFile()));}
   JavacTask task=(JavacTask)compiler.getTask(null,fm,null,List.of("-proc:none"),null,fm.getJavaFileObjectsFromFiles(files));
   for(CompilationUnitTree unit:task.parse()){
    count[0]++;new TreePathScanner<Void,Void>(){
     int anonymous=0;
     public Void visitClass(ClassTree c,Void x){boolean a=c.getSimpleName().length()==0;if(a)anonymous++;super.visitClass(c,x);if(a)anonymous--;return null;}
     void report(Tree tree){long pos=Trees.instance(task).getSourcePositions().getStartPosition(unit,tree);System.out.println(unit.getSourceFile().getName()+":"+unit.getLineMap().getLineNumber(pos)+": callback Context argument: "+tree);failures[0]++;}
     public Void visitMethodInvocation(MethodInvocationTree m,Void x){
      String select=m.getMethodSelect().toString();if(anonymous>0&&!m.getArguments().isEmpty()&&m.getArguments().get(0).toString().equals("this")&&(select.startsWith("SessionManager.")||select.startsWith("LanguageManager.")||select.startsWith("UiStrings.")||select.equals("Toast.makeText")))report(m);
      return super.visitMethodInvocation(m,x);
     }
     public Void visitNewClass(NewClassTree c,Void x){if(anonymous>0&&!c.getArguments().isEmpty()&&c.getArguments().get(0).toString().equals("this")&&Set.of("Intent","MyShopDialogBuilder","MyShopCompatDialogBuilder","TextView","Button","ImageView","LinearLayout").contains(c.getIdentifier().toString()))report(c);return super.visitNewClass(c,x);}
    }.scan(unit,null);
   }
  }
  if(failures[0]>0)throw new AssertionError(failures[0]+" unsafe callback Context arguments found");
  System.out.println("PASS callback Context audit: "+count[0]+" Java sources; targeted scope rule, not full Android type checking.");
 }
}
