import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import javax.tools.*;

/** Real javac type checking of the shipped cache statement in its callback/lambda scope. */
public class FeedCacheTypeCheck {
 static boolean compile(Path source,Path output)throws Exception{
  String text=Files.readString(source);Matcher m=Pattern.compile("getSharedPreferences\\(\"myshop_feed_cache\",MODE_PRIVATE\\)\\.edit\\(\\)\\.remove\\(\"first_page\"\\).*?\\.apply\\(\\);").matcher(text);if(!m.find())throw new AssertionError("Shipped cache statement not found");
  String fixture="class Context {} interface Callback { void onSuccess(); } class SessionManager { static String getUserId(Context c){ return \"0123\"; } } class Prefs { Prefs edit(){return this;} Prefs remove(String s){return this;} Prefs putString(String k,String v){return this;} Prefs putLong(String k,long v){return this;} void apply(){} } class MainActivity extends Context { static int MODE_PRIVATE=0; Prefs getSharedPreferences(String s,int x){return new Prefs();} void runOnUiThread(Runnable r){} void action(Object d){Callback callback=new Callback(){public void onSuccess(){runOnUiThread(()->{"+m.group()+"});}};} }";
  Path file=output.resolve("MainActivity.java");Files.writeString(file,fixture);
  JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();DiagnosticCollector<JavaFileObject> errors=new DiagnosticCollector<>();
  try(var fm=compiler.getStandardFileManager(errors,null,null)){
   boolean ok=compiler.getTask(null,fm,errors,List.of("-proc:none","-d",output.toString()),null,fm.getJavaFileObjects(file.toFile())).call();
   long count=errors.getDiagnostics().stream().filter(e->e.getKind()==Diagnostic.Kind.ERROR).count();System.out.println(source.getParent().getFileName()+": javac success="+ok+", errors="+count);if(!ok&&count!=2)throw new AssertionError("Expected exactly two Context type errors: "+errors.getDiagnostics());return ok;
  }
 }
 public static void main(String[] args)throws Exception{
  Path dir=Files.createTempDirectory("myshop-v578-types-");try{
   if(compile(Path.of(args[0]),dir))throw new AssertionError("V577 no longer reproduces compile error");
   if(!compile(Path.of(args[1]),dir))throw new AssertionError("V578 compile failure");
   System.out.println("PASS actual feed cache statement: V577 two errors; V578 compiles in callback/lambda Context scope. Full Android build separate.");
  }finally{try(var files=Files.walk(dir)){for(Path p:files.sorted(Comparator.reverseOrder()).toList())Files.delete(p);}}
 }
}
