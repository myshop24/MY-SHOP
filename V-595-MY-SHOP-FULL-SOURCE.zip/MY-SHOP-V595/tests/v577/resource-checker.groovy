import groovy.lang.GroovyShell
import groovy.lang.Binding
import java.nio.file.Files

// Executes the exact shipped task body on Groovy3; only Gradle's fileTree/task API is adapted.
class GradleException extends RuntimeException { GradleException(String text){super(text)} }
class TestTree {
 File root; String pattern='**/*'
 TestTree matching(Closure c){def spec=new Expando();spec.include={String p->pattern=p};c.delegate=spec;c.resolveStrategy=Closure.DELEGATE_FIRST;c.call();this}
 Set<File> getFiles(){def files=[] as Set;root.eachFileRecurse{f->if(f.isFile()){
  String path=root.toPath().relativize(f.toPath()).toString().replace('\\','/')
  boolean keep=pattern=='**/*'||pattern=='**/*.java'&&path.endsWith('.java')||pattern=='**/*.xml'&&path.endsWith('.xml')||pattern=='values*/**/*.xml'&&path.split('/')[0].startsWith('values')&&path.endsWith('.xml')
  if(keep)files.add(f)
 }};files}
}
class TestProject {File root; File file(String p){new File(root,p)};TestTree fileTree(File f){new TestTree(root:f)}}
class TestTask {void doLast(Closure c){c.call()}}
class TestTasks {void register(String name,Closure c){c.delegate=new TestTask();c.resolveStrategy=Closure.DELEGATE_FIRST;c.call()}}
File project=new File(args[0]).canonicalFile
File gradle=new File(args.length>1?args[1]:new File(project,'app/build.gradle').path)
String source=gradle.text
int begin=source.indexOf("tasks.register('verifyMyShopResourceReferences')")
int end=source.indexOf("tasks.register('verifyMyShopReleaseIdentity')",begin)
assert begin>=0&&end>begin
String body=source.substring(begin,end)
def check={->def binding=new Binding([rootProject:new TestProject(root:project),tasks:new TestTasks()]);new GroovyShell(this.class.classLoader,binding).evaluate(body)}
if(args.length>1){check();return}
check()
File declaration=new File(project,'app/src/main/res/values/visual_design_ids.xml');String old=declaration.text
File negative=new File(project,'app/src/main/java/com/myshop/app/V577MissingResourceFixture.java')
try{
 declaration.text='<resources><item name = "visual_design_state" type = "id" /></resources>'
 check()
 declaration.text="<resources><item type = 'id' name = 'visual_design_state' /></resources>"
 check()
 negative.text='class V577MissingResourceFixture { int x = R.id.v577_missing_probe; }'
 boolean rejected=false
 try{check()}catch(Exception e){rejected=e.message.contains('v577_missing_probe')}
 assert rejected:'Checker did not reject a truly missing resource'
}finally{declaration.text=old;negative.delete()}
println 'PASS V577: exact Groovy task, real resource tree, both attribute orders/spacing; missing-resource negative case remains enforced. Android compilation is separate.'
