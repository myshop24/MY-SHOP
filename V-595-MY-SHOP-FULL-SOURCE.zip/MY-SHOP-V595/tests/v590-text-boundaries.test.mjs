import assert from 'node:assert/strict';import {textBoundaries} from '../backend/worker/src/text-boundaries.js';import {normalizeVisualStyles} from '../backend/worker/src/visual-design.js';
for(const source of ['ক্ষ','মাইশপ','কি','👩‍💻','🇧🇩','ক্‍ষ']){const boundary=textBoundaries(source);assert.ok(boundary.has(0));assert.ok(boundary.has(source.length));for(let i=1;i<source.length;i++)if(!boundary.has(i))assert.throws(()=>normalizeVisualStyles({element_home1_website_label:{segments:[{source,start:0,end:i,text:'#FF0000'}]}}),/TEXT_GRAPHEME_SPLIT/);}
assert.equal(textBoundaries('ক্ষ').size,2);assert.equal(textBoundaries('👩‍💻').size,2);
assert.ok(normalizeVisualStyles({element_home1_website_label:{segments:[{source:'MY SHOP',start:3,end:7,text:'#FFFFFF',textEnd:'#FFC000',fontSize:20}]}}));
console.log('PASS stable named target, Bengali conjunct/mark and emoji ZWJ/flag selection cannot split; valid selected text style retained');
