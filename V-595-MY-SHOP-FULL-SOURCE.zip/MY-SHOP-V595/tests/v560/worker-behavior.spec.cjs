'use strict';
// Runs the shipped Worker functions against actual in-memory SQLite transactions.
// Authentication identities, R2 and outbound notifications are test doubles, not production services.
const fs=require('node:fs'), vm=require('node:vm'), path=require('node:path');
const assert=require('node:assert/strict'); const {DatabaseSync}=require('node:sqlite');const {webcrypto}=require('node:crypto');
const root=path.resolve(__dirname,'../..');let source=fs.readFileSync(path.join(root,'backend/worker/src/index.js'),'utf8');
const db=new DatabaseSync(':memory:');let injectFailure=null;
function stmt(sql,args=[]){return {sql,args,bind(...a){if(a.some(v=>v===undefined))throw Error('Undefined SQL bind: '+sql);return stmt(sql,a);},async first(key){const row=db.prepare(sql).get(...args);return row?(key?row[key]:row):null;},async all(){return {results:db.prepare(sql).all(...args)};},async run(){if(injectFailure&&injectFailure(sql)){injectFailure=null;throw Error('INJECTED_DATABASE_FAILURE');}const v=db.prepare(sql).run(...args);return {success:true,meta:{changes:Number(v.changes),last_row_id:Number(v.lastInsertRowid)}};}};}
const DB={prepare:stmt,async batch(statements){db.exec('BEGIN');try{const result=[];for(const s of statements)result.push(await s.run());db.exec('COMMIT');return result;}catch(e){db.exec('ROLLBACK');throw e;}},async exec(sql){db.exec(sql);return {count:1};}};
const errors=[];const c={Response,Request,Headers,URL,URLSearchParams,File,FormData,Blob,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,atob,btoa,crypto:webcrypto,setTimeout,clearTimeout,console:{log:console.log,error:(...v)=>errors.push(v.join(' ')),warn:console.warn},fetch:async()=>{throw Error('Unexpected network access in unit test');},agoraRtcTokenPkg:{RtcTokenBuilder:{},Role:{}}};vm.createContext(c);require('../v595/load-modules.cjs')(c,root);
const executable=source.replace(/^import .*;\s*$/mg,'').replace(/export default\s*\{/,'const worker = {').replace(/export class /g,'class ');
vm.runInContext(fs.readFileSync(path.join(root,'backend/worker/src/request-notices.js'),'utf8').replace(/export /g,''),c,{filename:'request-notices.js'});
vm.runInContext(executable,c,{filename:'shipped-worker.js'});
// Real SQL schemas are extracted from the shipped Worker, not a separate invented model.
for(const m of source.matchAll(/`(CREATE TABLE IF NOT EXISTS [\s\S]*?)`/g)){if(m[1].includes('${'))continue;try{db.exec(m[1]);}catch(e){throw Error('Fixture DDL failed: '+m[1].slice(0,90)+' '+e.message);}}
// Literal additive migrations (columns defined by the source's older schema upgrades).
for(const m of source.matchAll(/prepare\(("|`)(ALTER TABLE .*?)\1\)/g)){if(m[2].includes('${'))continue;try{db.exec(m[2]);}catch(e){if(!/duplicate column|no such table/i.test(e.message))throw e;}}
vm.runInContext(`
getUser=async request=>{const a=request.headers.get('authorization');return a==='Bearer admin'?{user_id:'0001',role:'ADMIN'}:a==='Bearer user'?{user_id:'0123',role:'USER'}:null;};
createBroadcastNotification=async()=>{};createUserNotification=async()=>{};
`,c);
const env={DB,MEDIA:{async delete(){},async put(){}},LIVE_ROOM_HUB:null};
const req=(data={},role='admin',url='https://test.local/v1/test',method='POST')=>new Request(url,{method,headers:{authorization:'Bearer '+role,'content-type':'application/json'},...(method==='GET'?{}:{body:JSON.stringify(data)})});
let tests=0;function pass(name){tests++;console.log('PASS '+tests+' — '+name);}
const sql=(query,...args)=>db.prepare(query).all(...args);
(async()=>{
 const get=(admin=true)=>req({},admin?'admin':'user',admin?'https://test.local/v1/admin/upcoming-live':'https://test.local/v1/upcoming-live','GET');
 let state=await(await c.upcomingLive(get(),env)).json();assert.equal(state.enabled,false);assert.equal(state.entries.length,0);pass('Fresh installs hide the entire optional row');
 const now=Date.now();const items=Array.from({length:20},(_,i)=>({id:'banner-'+i,userId:String(i+100).padStart(4,'0'),name:'Guest '+i,identity:'Creator',photoUrl:'https://test.local/photo/'+i,background:'#101C4A',liveAt:now+(i+1)*3600000,dwellSec:i%5+1,enabled:true}));
 let data={revision:state.revision,enabled:true,entries:items};
 assert.equal((await c.upcomingLive(req(data,'user','https://test.local/v1/admin/upcoming-live','PUT'),env)).status,403);pass('Non-admin cannot publish or edit');
 assert.equal((await c.upcomingLive(req(data,'admin','https://test.local/v1/admin/upcoming-live','PUT'),env)).status,200);
 state=await(await c.upcomingLive(get(false),env)).json();assert.equal(state.entries.length,20);assert.equal(new Set(state.entries.map(x=>x.liveAt)).size,20);assert.equal(state.entries[19].dwellSec,5);pass('20 independent target times and dwell intervals persist');
 const before=sql('SELECT * FROM myshop_upcoming_live');assert.equal((await c.upcomingLive(req(data,'admin','https://test.local/v1/admin/upcoming-live','PUT'),env)).status,409);assert.deepEqual(sql('SELECT * FROM myshop_upcoming_live'),before);pass('Stale edits cannot overwrite another admin update');
 for(const invalid of [[...items,items[0]],items.map(x=>({...x,id:'same'})),items.map(x=>({...x,dwellSec:0})),items.map(x=>({...x,liveAt:NaN})),items.map(x=>({...x,background:'not-a-color'})),items.map(x=>({...x,photoUrl:'javascript:bad'})),items.map(x=>({...x,userId:'12345'}))]){const res=await c.upcomingLive(req({enabled:true,revision:1,entries:invalid},'admin','https://test.local/v1/admin/upcoming-live','PUT'),env);assert.equal(res.status,400);assert.deepEqual(sql('SELECT * FROM myshop_upcoming_live'),before);}pass('Invalid counts, IDs, URLs, target times, colors, durations leave data unchanged');
 let reversed=[...items].reverse();reversed[3]={...reversed[3],enabled:false};data={enabled:true,revision:1,entries:reversed};assert.equal((await c.upcomingLive(req(data,'admin','https://test.local/v1/admin/upcoming-live','PUT'),env)).status,200);state=await(await c.upcomingLive(get(false),env)).json();assert.equal(state.entries.length,19);assert.equal(state.entries[0].id,items[19].id);pass('Drag order persists; disabled card is omitted');
 data={...data,enabled:false,revision:2};await c.upcomingLive(req(data,'admin','https://test.local/v1/admin/upcoming-live','PUT'),env);state=await(await c.upcomingLive(get(false),env)).json();assert.equal(state.entries.length,0);assert.equal((await(await c.upcomingLive(get(),env)).json()).entries.length,20);pass('Global disable removes all public entries without deleting admin data');
 const stable=sql('SELECT * FROM myshop_upcoming_live');injectFailure=q=>q.startsWith('UPDATE myshop_upcoming_live');await assert.rejects(()=>c.upcomingLive(req({...data,revision:3,enabled:true},'admin','https://test.local/v1/admin/upcoming-live','PUT'),env));assert.deepEqual(sql('SELECT * FROM myshop_upcoming_live'),stable);pass('Database failure retains published state');
 for(let i=1;i<=20;i++){db.prepare("INSERT INTO banners(folder,slot,image_url,active) VALUES('live_home',?,?,1)").run(i,'https://test.local/'+i);db.prepare("INSERT INTO banner_media(folder,slot,object_key) VALUES('live_home',?,?)").run(i,'object-'+i);}
 state=await(await c.publicLiveHomeBanners(req({},'user','https://test.local/v1/live-home/banners','GET'),env)).json();assert.equal(state.banners.length,20);assert.equal(state.banners[19].slot,20);pass('Public banner carousel returns slots 1 through 20');
 assert.equal((await c.adminBannerUpdate(req({folder:'live_home',slot:21}),env)).status,400);assert.equal((await c.adminBannerUpdate(req({folder:'live_home',slot:20,caption:'Last banner',active:false}),env)).status,200);assert.equal(sql("SELECT active FROM banners WHERE folder='live_home' AND slot=20")[0].active,0);pass('Slot 20 can be edited; slot 21 rejected');
 const order=Array.from({length:20},(_,i)=>20-i);await c.adminBannerOrder(req({folder:'live_home',slots:order}),env);assert.equal(sql("SELECT image_url FROM banners WHERE folder='live_home' AND slot=1")[0].image_url,'https://test.local/20');assert.equal(sql("SELECT object_key FROM banner_media WHERE folder='live_home' AND slot=1")[0].object_key,'object-20');pass('20-slot reorder moves banner and media together');
 const positions=sql("SELECT slot,image_url FROM banners WHERE folder='live_home' ORDER BY slot");injectFailure=q=>q.includes('UPDATE banner_media SET slot=?');await assert.rejects(()=>c.adminBannerOrder(req({folder:'live_home',slots:order}),env));assert.deepEqual(sql("SELECT slot,image_url FROM banners WHERE folder='live_home' ORDER BY slot"),positions);pass('Failed banner reorder rolls back both tables');
 await c.adminBannerOrder(req({folder:'live_home',slots:[6,5,4,3,2,1]}),env);assert.equal(sql("SELECT image_url FROM banners WHERE folder='live_home' AND slot=20")[0].image_url,'https://test.local/1');pass('Legacy 6-slot clients leave newer slots intact');
 console.log('PASS '+tests+' V560 behavior groups');
})().catch(e=>{console.error(e);process.exitCode=1;});
