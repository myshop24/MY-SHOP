"""Compile and execute the real MiniAd editor save lambda, with minimal UI doubles."""
from pathlib import Path
import shutil, subprocess, sys, tempfile
project=Path(__file__).resolve().parents[2]
source_path=Path(sys.argv[1]) if len(sys.argv)>1 else project/'app/src/main/java/com/myshop/app/MiniAdAdminActivity.java'
source=source_path.read_text()
init=source.split('private void edit(int n){',1)[1].split('\n',1)[0]
listener=source.split('dialog.setOnShowListener(',1)[1].split('dialog.show();',1)[0]
listener='dialog.setOnShowListener('+listener+'dialog.show();'
harness='''import java.util.*;
public class MiniCardSaveCheck {
 static class JSONObject { final Map<String,Object> data=new HashMap<>(); JSONObject put(String k,Object v){data.put(k,v);return this;} String optString(String k,String d){return data.containsKey(k)?String.valueOf(data.get(k)):d;} }
 static class Cards { final ArrayList<JSONObject> data=new ArrayList<>(); JSONObject optJSONObject(int n){return n>=0&&n<data.size()?data.get(n):null;} void put(JSONObject c){data.add(c);} void put(int n,JSONObject c){while(data.size()<=n)data.add(null);data.set(n,c);} }
 static class EditText {String value;String error;EditText(String s){value=s;}String getText(){return value;}void setError(String s){error=s;}}
 static class Spinner {int getSelectedItemPosition(){return 0;}}
 static class Switch {boolean isChecked(){return true;}}
 static class Status {void setText(String s){throw new AssertionError(s);}}
 interface Listener {void accept(Object o);}
 static class Button {Listener listener;void setOnClickListener(Listener l){listener=l;}void click(){listener.accept(null);}}
 static class Dialog {final Button b=new Button();Listener show;Button getButton(int n){return b;}void setOnShowListener(Listener l){show=l;}void show(){show.accept(null);b.click();}void dismiss(){}}
 final Cards cards=new Cards(); final Status status=new Status();int renders;
 void render(){renders++;}String isoAfterDays(int days){return "expiry-"+days;}
 void edit(int n){
INIT
 EditText title=new EditText("Updated"),caption=new EditText("caption"),image=new EditText("https://image"),link=new EditText("https://link"),start=new EditText(""),end=new EditText(""),days=new EditText("30");
 Spinner template=new Spinner(),seconds=new Spinner(); Switch on=new Switch(),animate=new Switch(),flash=new Switch();String[] color={"#123B9A"};Dialog dialog=new Dialog();
LISTENER
 }
 public static void main(String[] args){
  MiniCardSaveCheck add=new MiniCardSaveCheck();add.edit(-1);if(add.cards.data.size()!=1||!add.cards.data.get(0).optString("id","").startsWith("card_"))throw new AssertionError("Add failed");
  MiniCardSaveCheck edit=new MiniCardSaveCheck();edit.cards.put(new JSONObject().put("id","existing-id"));edit.edit(0);if(edit.cards.data.size()!=1||!edit.cards.data.get(0).optString("id","").equals("existing-id"))throw new AssertionError("Edit replaced ID or duplicated card");
  MiniCardSaveCheck missing=new MiniCardSaveCheck();missing.cards.put((JSONObject)null);missing.edit(0);if(missing.cards.data.get(0)==null)throw new AssertionError("Null card fallback failed");
  if(add.renders!=1||edit.renders!=1||missing.renders!=1)throw new AssertionError("Render missing");
  System.out.println("PASS actual MiniAd save lambda: Java17 compiles; add/edit/null fallback save; existing ID preserved without duplicate");
 }
}
'''.replace('INIT',init).replace('LISTENER',listener)
with tempfile.TemporaryDirectory() as td:
 p=Path(td)/'MiniCardSaveCheck.java';p.write_text(harness)
 compiler=[shutil.which('javac')] if shutil.which('javac') else ['java','com.sun.tools.javac.Main']
 subprocess.run(compiler+['-encoding','UTF-8','-d',td,str(p)],check=True)
 subprocess.run(['java','-cp',td,'MiniCardSaveCheck'],check=True)
