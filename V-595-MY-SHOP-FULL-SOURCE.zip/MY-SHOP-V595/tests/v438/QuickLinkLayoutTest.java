import com.myshop.app.QuickLinkLayout;
import java.util.*;
public final class QuickLinkLayoutTest {
 public static void main(String[] args){
  for(int count=0;count<=200;count++){
   Set<Integer> seen=new HashSet<>();int top=0,bottom=0;
   for(int col=0;col<QuickLinkLayout.columns(count);col++)for(int row=0;row<2;row++){
    int index=QuickLinkLayout.index(col,row,count);if(index<0)continue;
    if(!seen.add(index)||index>=count)throw new AssertionError("duplicate / outside item");
    if(row==0)top++;else bottom++;
   }
   if(seen.size()!=count||top-bottom<0||top-bottom>1)throw new AssertionError("unpaired overflow "+count);
  }
  if(QuickLinkLayout.columns(14)!=7||QuickLinkLayout.index(6,1,14)!=13)throw new AssertionError("14 links must make 7 complete pairs");
  System.out.println("PASS: 201 catalog sizes, stable two-row pairs, no missing / duplicate links; 14 = 7 + 7");
 }
}
