'use strict';
// V566 regression coverage runs the shipped Worker handlers against in-memory SQLite.
const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const {DatabaseSync}=require('node:sqlite'),{webcrypto}=require('node:crypto');
const root=path.resolve(__dirname,'../..'),source=fs.readFileSync(path.join(root,'backend/worker/src/index.js'),'utf8'),db=new DatabaseSync(':memory:');
function stmt(sql,args=[]){return{sql,args,bind(...a){if(a.some(v=>v===undefined))throw Error('undefined bind');return stmt(sql,a)},async first(k){const r=db.prepare(sql).get(...args);return r?(k?r[k]:r):null},async all(){return{results:db.prepare(sql).all(...args)}},async run(){const r=db.prepare(sql).run(...args);return{success:true,meta:{changes:Number(r.changes),last_row_id:Number(r.lastInsertRowid)}}}}}
const DB={prepare:stmt,async batch(xs){db.exec('BEGIN');try{const r=[];for(const x of xs)r.push(await x.run());db.exec('COMMIT');return r}catch(e){db.exec('ROLLBACK');throw e}},async exec(s){db.exec(s);return{count:1}}};
const c={Response,Request,Headers,URL,URLSearchParams,File,FormData,Blob,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,atob,btoa,crypto:webcrypto,setTimeout,clearTimeout,console,fetch:async()=>{throw Error('network disabled')},agoraRtcTokenPkg:{RtcTokenBuilder:{},Role:{}}};vm.createContext(c);require('../v595/load-modules.cjs')(c,root);
vm.runInContext(fs.readFileSync(path.join(root,'backend/worker/src/request-notices.js'),'utf8').replace(/export /g,''),c);
vm.runInContext(fs.readFileSync(path.join(root,'backend/worker/src/payout-actions.js'),'utf8').replace(/^import .*;\s*$/mg,'').replace(/export /g,''),c);
vm.runInContext(fs.readFileSync(path.join(root,'backend/worker/src/withdraw-request.js'),'utf8').replace(/export /g,''),c);
vm.runInContext(fs.readFileSync(path.join(root,'backend/worker/src/deletion-media.js'),'utf8').replace(/export /g,''),c);
vm.runInContext(fs.readFileSync(path.join(root,'backend/worker/src/feature-history.js'),'utf8').replace(/export /g,''),c);
vm.runInContext(source.replace(/^import .*;\s*$/mg,'').replace(/export default\s*\{/,'const worker = {').replace(/export class /g,'class '),c);
for(const m of source.matchAll(/`(CREATE TABLE IF NOT EXISTS [\s\S]*?)`/g)){if(m[1].includes('${'))continue;try{db.exec(m[1])}catch(e){throw Error('DDL failed: '+e.message)}}
const roles={'admin':{user_id:'0001',role:'ADMIN',full_name:'Admin'},'moderator':{user_id:'0124',role:'MODERATOR',full_name:'Moderator'},'user':{user_id:'0123',role:'USER',full_name:'User'}};
vm.runInContext(`getUser=async r=>roles[r.headers.get('authorization')?.replace('Bearer ','')]||null;createBroadcastNotification=async()=>{};createUserNotification=async()=>{};`,Object.assign(c,{roles}));
const env={DB,MEDIA:{async put(){},async delete(){}}};
const req=(body,who='admin',url='https://test.local/v1/test',method='POST')=>new Request(url,{method,headers:{authorization:'Bearer '+who,'content-type':'application/json'},...(method==='GET'?{}:{body:JSON.stringify(body)})});

(async()=>{
  for(const [token,u] of Object.entries(roles))db.prepare("INSERT INTO myshop_auth_users_v108(user_id,full_name,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role,active) VALUES(?,?,'test','q','a','q','a','q','a',?,1)").run(u.user_id,u.full_name,u.role);
  await c.ensureFriendSchema(env);
  let response=await c.friendRequest(req({userId:'0124'},'user'),env);assert.equal(response.status,201);assert.equal((await response.json()).following,true);
  assert.equal((await c.friendRequest(req({userId:'0124'},'user'),env)).status,200);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM myshop_friend_requests').get().n,1);
  assert.equal(db.prepare('SELECT COUNT(*) n FROM myshop_follows').get().n,1);
  assert.equal((await c.friendRequest(req({userId:'0123'},'moderator'),env)).status,409);
  db.prepare("UPDATE myshop_friend_requests SET status='ACCEPTED'").run();
  let list=await(await c.profileConnections(req({},'user','https://test.local/v1/users/connections?userId=0123&kind=friends','GET'),env)).json();assert.equal(list.users.length,1);assert.equal(list.users[0].userId,'0124');assert.deepEqual(Object.keys(list.users[0]).sort(),['avatarUrl','name','userId']);
  db.prepare("INSERT INTO myshop_user_blocks(blocker_id,blocked_id) VALUES('0123','0124')").run();
  list=await(await c.profileConnections(req({},'user','https://test.local/v1/users/connections?userId=0123&kind=friends','GET'),env)).json();assert.equal(list.users.length,0);
  assert.equal((await c.friendRequest(req({userId:'0124'},'user'),env)).status,409);
  assert.equal((await c.profileConnections(req({},'user','https://test.local/v1/users/connections?userId=0124&kind=friends','GET'),env)).status,403);
  assert.equal((await c.profileConnections(req({},'user','https://test.local/v1/users/connections?userId=0123&kind=private','GET'),env)).status,400);
  assert.equal((await c.adminGeneralMenuOrder(req({page:'profile'},'admin'),env)).status,400);
  const existing=db.prepare('SELECT COUNT(*) n FROM myshop_friend_requests').get().n;
  const original=DB.batch;DB.batch=async xs=>{db.exec('BEGIN');try{await xs[0].run();throw Error('injected failure')}finally{db.exec('ROLLBACK')}};
  await assert.rejects(c.friendRequest(req({userId:'0001'},'user'),env),/injected failure/);DB.batch=original;
  assert.equal(db.prepare('SELECT COUNT(*) n FROM myshop_friend_requests').get().n,existing);
  assert.equal(db.prepare("SELECT COUNT(*) n FROM myshop_follows WHERE following_id='0001'").get().n,0);
  await c.ensureRequestNotices(DB);
  db.prepare("INSERT INTO myshop_store_catalog(id,code,title,item_type) VALUES(901,'test_member','Membership','MEMBERSHIP'),(902,'test_ride','Ride','RIDE')").run();
  db.prepare("INSERT INTO myshop_store_purchase_requests(user_id,catalog_id,payment_mode) VALUES('0123',901,'COIN'),('0123',902,'GOLD')").run();
  const h={adminOnly:c.adminOnly,getUser:c.getUser,json:(data,status=200)=>new Response(JSON.stringify(data),{status}),cors:{}};
  let notices=await(await c.folderRequestNotices(req({},'admin','https://test.local/v1/admin/folder-notices?kind=PREMIUM_MEMBERSHIP','GET'),env,h)).json();
  assert.equal(notices.notices.length,1);assert.equal(notices.pendingCounts.find(x=>x.kind==='PREMIUM_MEMBERSHIP').pending,1);assert.equal(notices.pendingCounts.find(x=>x.kind==='PREMIUM_RIDE').pending,1);
  await c.folderRequestNotices(req({eventKey:notices.notices[0].event_key},'admin','https://test.local/v1/admin/folder-notices?kind=PREMIUM_MEMBERSHIP'),env,h);
  notices=await(await c.folderRequestNotices(req({},'admin','https://test.local/v1/admin/folder-notices?kind=PREMIUM_MEMBERSHIP','GET'),env,h)).json();assert.equal(notices.pendingCounts.find(x=>x.kind==='PREMIUM_MEMBERSHIP').pending,1);
  db.prepare("UPDATE myshop_store_purchase_requests SET status='COMPLETED' WHERE catalog_id=901").run();
  notices=await(await c.folderRequestNotices(req({},'admin','https://test.local/v1/admin/folder-notices?kind=PREMIUM_MEMBERSHIP','GET'),env,h)).json();assert.equal(notices.pendingCounts.some(x=>x.kind==='PREMIUM_MEMBERSHIP'),false);assert.equal(notices.pendingCounts.find(x=>x.kind==='PREMIUM_RIDE').pending,1);
  console.log('PASS V571: independent Auto Follow, retry/opposite-request deduplication, transactional rollback, public identity lists, block enforcement, input validation.');
})().catch(e=>{console.error(e);process.exitCode=1});
