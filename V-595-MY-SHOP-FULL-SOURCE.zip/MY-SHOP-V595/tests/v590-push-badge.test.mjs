import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('../backend/worker/src/index.js',import.meta.url),'utf8');
const start=source.indexOf('function attachPushBadge('),end=source.indexOf('\n}',start)+2;
const attachPushBadge=vm.runInNewContext('('+source.slice(start,end)+')');
const base = () => ({ message: { notification: { title: 'Existing title', body: 'Existing body' }, data: { recipientUserId: '1234' }, android: { priority: 'high', notification: { channel_id: 'myshop_messages_v2', default_sound: true, default_vibrate_timings: true } } } });
const active = new Map();
for (let id=1; id<=50; id++) {
  const p=attachPushBadge(base(),'1234',['MESSAGE','FRIEND_REQUEST','LIVE_START'][id%3],id);
  active.set(p.message.android.notification.tag,p.message.android.notification.notification_count);
  assert.equal(p.message.android.priority,'high');
  assert.equal(p.message.android.notification.default_sound,true);
  assert.equal(p.message.android.notification.default_vibrate_timings,true);
  assert.deepEqual(p.message.notification,base().message.notification);
}
assert.equal([...active.values()].reduce((a,b)=>a+b,0),50);
const duplicate=attachPushBadge(base(),'1234','MESSAGE',1);
active.set(duplicate.message.android.notification.tag,duplicate.message.android.notification.notification_count);
assert.equal(active.size,50);
assert.notEqual(attachPushBadge(base(),'5678','MESSAGE',1).message.android.notification.tag,duplicate.message.android.notification.tag);
for(const type of ['OFFICIAL','LIKE','LIVE_UPCOMING','LIVE_CALL_INVITE','TEST_PUSH']){const p=attachPushBadge(base(),'1234',type,1);assert.equal(p.message.data.badgeEligible,'0');assert.ok(p.message.android.notification.channel_id.includes('no_badge'));assert.equal(p.message.android.notification.tag,undefined);assert.deepEqual(p.message.notification,base().message.notification);assert.equal(p.message.android.notification.default_sound,true);}
for(const id of ['',0,-1,'not-an-id']) assert.deepEqual(attachPushBadge(base(),'1234','MESSAGE',id),base());
assert.equal(attachPushBadge(base(),'1234','FRIEND_REQUEST',1).message.android.notification.channel_id,'myshop_friend_badge_v590');
console.log('PASS 50 distinct badge event tags, duplicate replacement, account isolation and original push presentation fields. This is metadata verification, NOT Android launcher or lock-screen acceptance.');
