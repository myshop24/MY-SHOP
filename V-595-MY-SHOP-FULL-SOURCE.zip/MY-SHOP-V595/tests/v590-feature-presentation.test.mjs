import assert from 'node:assert/strict';
import {homeFeaturePresentation} from '../backend/worker/src/feature-presentation.js';
const website={key:'home1_website',title:'Old',icon_url:'old.png',target_url:'https://old.test',active:1,display_order:8,icon_size:56};
const live={...website,key:'home1_live_tv'};
const page2={...website,key:'live2_website'};
const row={id:1,category:'feature_home1_website',title:'নতুন নাম',icon_url:'emoji:🌟',image_url:'',url:'https://new.test',active:1,archived:0,status:'COMING_SOON'};
const result=homeFeaturePresentation([website,live,page2],[row,{...row,category:'feature_home1_live_tv'},{...row,category:'feature_live2_website'}]);
assert.equal(result[0].title,'নতুন নাম');assert.equal(result[0].icon_url,'emoji:🌟');assert.equal(result[0].display_order,8);assert.equal(result[0].icon_size,56);assert.equal(result[0].active,1);assert.equal(result[0].canonical_feature,true);
assert.strictEqual(result[1],live);assert.strictEqual(result[2],page2);
assert.equal(homeFeaturePresentation([website],[{...row,archived:1}])[0].active,0);
assert.equal(homeFeaturePresentation([{...website,active:0}],[row])[0].active,0);
assert.strictEqual(homeFeaturePresentation([website],[])[0],website);
console.log('PASS owning published feature drives Home icon/name/link, coming-soon remains visible, archive/hide respected, position/size retained, Live/other pages/legacy untouched');

const alias={...row,category:'feature_website',title:'Legacy published'};assert.equal(homeFeaturePresentation([website],[alias])[0].title,'Legacy published');assert.equal(homeFeaturePresentation([website],[alias,row])[0].title,row.title);
console.log('PASS legacy short category remains usable until canonical Home record published, full category takes precedence consistently with click gate');
