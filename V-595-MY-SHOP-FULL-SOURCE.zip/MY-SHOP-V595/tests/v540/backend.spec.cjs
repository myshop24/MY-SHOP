'use strict';
// Runs the shipped Worker functions against actual in-memory SQLite transactions.
// Authentication identities, R2 and outbound notifications are test doubles, not production services.
const fs=require('node:fs'), vm=require('node:vm'), path=require('node:path');
const assert=require('node:assert/strict'); const {DatabaseSync}=require('node:sqlite');const {webcrypto}=require('node:crypto');
const root=path.resolve(__dirname,'../..');let source=fs.readFileSync(path.join(root,'backend/worker/src/index.js'),'utf8');
const db=new DatabaseSync(':memory:');let injectFailure=null;
function stmt(sql,args=[]){return {sql,args,bind(...a){if(a.some(v=>v===undefined))throw Error('Undefined SQL bind: '+sql);return stmt(sql,a);},async first(key){const row=db.prepare(sql).get(...args);return row?(key?row[key]:row):null;},async all(){return {results:db.prepare(sql).all(...args)};},async run(){if(injectFailure&&injectFailure(sql)){injectFailure=null;throw Error('INJECTED_DATABASE_FAILURE');}const v=db.prepare(sql).run(...args);return {success:true,meta:{changes:Number(v.changes),last_row_id:Number(v.lastInsertRowid)}};}};}
const DB={prepare:stmt,async batch(statements){db.exec('BEGIN');try{const result=[];for(const s of statements)result.push(await s.run());db.exec('COMMIT');return result;}catch(e){db.exec('ROLLBACK');throw e;}},async exec(sql){db.exec(sql);return {count:1};}};
const errors=[];const c={Response,Request,Headers,URL,URLSearchParams,File,FormData,Blob,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,atob,btoa,crypto:webcrypto,setTimeout,clearTimeout,console:{log:console.log,error:(...v)=>errors.push(v.join(' ')),warn:console.warn},fetch:async()=>{throw Error('Unexpected network access in unit test');},agoraRtcTokenPkg:{RtcTokenBuilder:{},Role:{}}};vm.createContext(c);require('../v595/load-modules.cjs')(c,root);
const executable=source.replace(/^import .*;\s*$/mg,'').replace(/export default\s*\{/,'const worker = {').replace(/export class /g,'class ');
vm.runInContext(fs.readFileSync(path.join(root,'backend/worker/src/request-notices.js'),'utf8').replace(/export /g,''),c,{filename:'request-notices.js'});
vm.runInContext(executable,c,{filename:'shipped-worker.js'});
// Real SQL schemas are extracted from the shipped Worker, not a separate invented model.
for(const m of source.matchAll(/`(CREATE TABLE IF NOT EXISTS [\s\S]*?)`/g)){if(m[1].includes('${'))continue;try{db.exec(m[1]);}catch(e){throw Error('Fixture DDL failed: '+m[1].slice(0,90)+' '+e.message);}}
// Literal additive migrations (columns defined by the source's older schema upgrades).
for(const m of source.matchAll(/prepare\(("|`)(ALTER TABLE .*?)\1\)/g)){if(m[2].includes('${'))continue;try{db.exec(m[2]);}catch(e){if(!/duplicate column|no such table/i.test(e.message))throw e;}}
vm.runInContext(`
getUser=async request=>{const a=request.headers.get('authorization');return a==='Bearer admin'?{user_id:'0001',role:'ADMIN'}:a==='Bearer user'?{user_id:'0123',role:'USER'}:null;};
createBroadcastNotification=async()=>{};createUserNotification=async()=>{};
`,c);
const env={DB,MEDIA:{async delete(){},async put(){}},LIVE_ROOM_HUB:null};
const req=(data={},role='admin',url='https://test.local/v1/test',method='POST')=>new Request(url,{method,headers:{authorization:'Bearer '+role,'content-type':'application/json'},...(method==='GET'?{}:{body:JSON.stringify(data)})});
vm.runInContext(`ensureSchemasOnce=async()=>{};ensureLevelSchema=async()=>{};`,c);
let tests=0;function pass(name){tests++;console.log('PASS '+tests+' — '+name);}
const sql=(query,...args)=>db.prepare(query).all(...args);
(async()=>{
 await c.ensureContentSchema(env);
 for(const uid of ['0001','0123','0456'])await DB.prepare("INSERT INTO myshop_auth_users_v108(user_id,full_name,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role,active) VALUES(?,?,'test-only','q','a','q','a','q','a',?,1)").bind(uid,'Test User',uid==='0001'?'ADMIN':'USER').run();
 const general=['agent','my_links','deals','whats_new','my_tasks','shorts','events','flash_sale','invite','safety_privacy'];
 assert.equal((await c.adminGeneralMenuOrder(req({keys:general},'user'),env)).status,403);pass('User cannot publish icon positions');
 assert.equal((await c.adminGeneralMenuOrder(req({keys:[...general.slice(1),general[1]]}),env)).status,400);pass('Duplicate or missing icon rejected');
 await DB.prepare("INSERT INTO managed_links(category,title,url,active,display_order) VALUES('home_menu_agent','My Agent','https://wa.me/8801700000000',0,1)").run();
 assert.equal((await c.adminGeneralMenuOrder(req({keys:[...general].reverse()}),env)).status,200);
 let agent=sql("SELECT * FROM managed_links WHERE category='home_menu_agent'")[0];assert.equal(agent.display_order,10);assert.equal(agent.title,'My Agent');assert.equal(agent.active,0);assert.equal(agent.url,'https://wa.me/8801700000000');pass('Reorder saves exact position and preserves contact, title and hidden state');
 const profile=['wallet','shop','live','membership','items','links'];
 assert.equal((await c.adminGeneralMenuOrder(req({page:'profile',keys:profile.reverse()}),env)).status,200);assert.equal(sql("SELECT category FROM managed_links WHERE category LIKE 'profile_shortcut_%' ORDER BY display_order")[0].category,'profile_shortcut_links');pass('Profile shortcut order is server-persisted independently');
 const previous=sql("SELECT category,display_order FROM managed_links ORDER BY id");injectFailure=q=>q.startsWith('UPDATE managed_links');await assert.rejects(()=>c.adminGeneralMenuOrder(req({keys:general}),env),/INJECTED/);assert.deepEqual(sql("SELECT category,display_order FROM managed_links ORDER BY id"),previous);pass('Failed order publish rolls back all positions');
 for(const folder of ['live_home','shop_home']){
  await DB.prepare("INSERT INTO banners(folder,slot,image_url,active) VALUES(?,1,'https://test/image.jpg',1)").bind(folder).run();
  await DB.prepare("INSERT INTO banner_media(folder,slot,object_key) VALUES(?,1,'test-key')").bind(folder).run();
  const endpoint=folder==='shop_home'?'/v1/shop/banners':'/v1/live-home/banners';
  assert.equal((await(await c.publicLiveHomeBanners(req({},'user','https://test'+endpoint,'GET'),env)).json()).banners.length,1);
  assert.equal((await c.adminBannerDelete(req({folder,slot:1}),env)).status,200);
  assert.equal(sql('SELECT id FROM banner_media WHERE folder=?',folder).length,0);
  assert.equal((await(await c.publicLiveHomeBanners(req({},'user','https://test'+endpoint,'GET'),env)).json()).banners.length,0);pass(folder+' delete clears metadata/media and stays empty on reload');
 }
 await DB.prepare("INSERT INTO banners(folder,slot,image_url,active,start_at,end_at) VALUES('shop_home',2,'https://test/future',1,'2099-01-01T00:00:00Z','')").run();
 await DB.prepare("INSERT INTO banners(folder,slot,image_url,active,start_at,end_at) VALUES('shop_home',3,'https://test/expired',1,'','2000-01-01T00:00:00Z')").run();
 assert.equal((await(await c.publicLiveHomeBanners(req({},'user','https://test/v1/shop/banners','GET'),env)).json()).banners.length,0);pass('Future and expired shop banners remain hidden');
 await DB.prepare("INSERT INTO myshop_posts(user_id,caption,media_url,object_key,media_type,status) VALUES('0456','Example','','','text','ACTIVE')").run();
 const id=sql('SELECT id FROM myshop_posts')[0].id,event='01234567-0123-0123-0123-012345678901';
 assert.equal((await c.feedShare(req({postId:id,eventId:event},''),env)).status,401);pass('Share recording requires authentication');
 assert.equal((await c.feedShare(req({postId:id,eventId:'invalid'},'user'),env)).status,400);pass('Malformed share event rejected');
 assert.equal((await(await c.feedShare(req({postId:id,eventId:event},'user'),env)).json()).shareCount,1);
 assert.equal((await(await c.feedShare(req({postId:id,eventId:event},'user'),env)).json()).shareCount,1);pass('Repeated share delivery is idempotent');
 const post=await(await c.feedPost(req({},'user','https://test/v1/feed/post?id='+id,'GET'),env)).json();assert.equal(post.post.shareCount,1);pass('Post reload exposes the persisted share count');
 await DB.prepare("UPDATE myshop_profile_privacy SET posts_visibility='PRIVATE' WHERE user_id='0456'").run();
 assert.equal((await c.feedPost(req({},'user','https://test/v1/feed/post?id='+id,'GET'),env)).status,404);assert.equal((await c.feedShare(req({postId:id,eventId:'01234567-0123-0123-0123-012345678902'},'user'),env)).status,404);pass('Saved post reload and share respect current privacy');
 await DB.prepare("INSERT INTO banners(folder,slot,image_url,active) VALUES('shop_home',1,'https://test/moved',1)").run();await DB.prepare("INSERT INTO banner_media(folder,slot,object_key) VALUES('shop_home',1,'move-key')").run();
 assert.equal((await c.adminBannerOrder(req({folder:'shop_home',slots:[6,5,4,3,2,1]},'user'),env)).status,403);pass('Banner move requires server admin permission');
 assert.equal((await c.adminBannerOrder(req({folder:'shop_home',slots:[1,1,3,4,5,6]}),env)).status,400);pass('Invalid banner permutation rejected');
 assert.equal((await c.adminBannerOrder(req({folder:'shop_home',slots:[6,5,4,3,2,1]}),env)).status,200);assert.equal(sql("SELECT slot FROM banners WHERE image_url='https://test/moved'")[0].slot,6);assert.equal(sql("SELECT slot FROM banner_media WHERE object_key='move-key'")[0].slot,6);pass('Banner reorder moves image and media ownership together');
 const bannersBefore=sql("SELECT id,slot FROM banners ORDER BY id");injectFailure=q=>q.includes('slot=?');await assert.rejects(()=>c.adminBannerOrder(req({folder:'shop_home',slots:[6,5,4,3,2,1]}),env),/INJECTED/);assert.deepEqual(sql("SELECT id,slot FROM banners ORDER BY id"),bannersBefore);pass('Failed banner position save rolls back all records');
 console.log(tests+' V540 local SQLite tests passed; authentication, R2 and notifications use test doubles.');
})().catch(e=>{console.error(e);process.exitCode=1;});
