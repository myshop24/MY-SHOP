import assert from 'node:assert/strict';
import {verifyDeletionGoogleToken} from '../backend/worker/src/deletion-reauth.js';
const original=globalThis.fetch,now=Math.floor(Date.now()/1000),owner={email:'owner@example.com'},env={GOOGLE_WEB_CLIENT_ID:'approved-client'};
const valid={aud:'approved-client',iss:'https://accounts.google.com',email_verified:'true',email:'owner@example.com',iat:now,exp:now+3600};
try{
 const verify=async (patch={},ok=true)=>{globalThis.fetch=async()=>({ok,json:async()=>({...valid,...patch})});return verifyDeletionGoogleToken('test-token',owner,env);};
 assert.equal((await verify()).ok,true);
 for(const patch of [{email:'other@example.com'},{aud:'wrong-client'},{iss:'https://evil.example'},{email_verified:'false'},{exp:now-1},{iat:now-601},{iat:now+120},{iat:null}])assert.equal((await verify(patch)).error,'GOOGLE_REAUTH_INVALID');
 assert.equal((await verify({},false)).statusCode,403);
 assert.equal((await verifyDeletionGoogleToken('',owner,env)).statusCode,403);
 assert.equal((await verifyDeletionGoogleToken('test-token',{},env)).statusCode,403);
 globalThis.fetch=async()=>{throw Error('offline');};assert.equal((await verifyDeletionGoogleToken('test-token',owner,env)).statusCode,503);
 console.log('PASS deletion Google reauth: matching owner, pinned audience/issuer, verified email, freshness/expiry and failure isolation');
}finally{globalThis.fetch=original;}
