import java.nio.file.*;import java.util.*;import javax.tools.*;
public class DraftReviewCheck {
 public static void main(String[] args)throws Exception{
  String source=Files.readString(Path.of("app/src/main/java/com/myshop/app/AdminSectionActivity.java"));
  String review=source.substring(source.indexOf("    private void reviewSavedFeatureDraft()"),source.indexOf("    private void featureCardUi()"));
  String input=source.substring(source.indexOf("    private JSONObject featureDraftInput()"),source.indexOf("    private void savePrivateFeatureDraft()"));
  String fixture="""
  import java.util.*;
  class JSONObject {static Map<String,Map<String,Object>> copies=new HashMap<>();Map<String,Object> values=new HashMap<>();JSONObject(){}JSONObject(String copy){values.putAll(copies.get(copy));}JSONObject put(String key,Object value){values.put(key,value);return this;}JSONObject optJSONObject(String key){return (JSONObject)values.get(key);}String optString(String key){return optString(key,"");}String optString(String key,String fallback){Object v=values.get(key);return v==null?fallback:v.toString();}int optInt(String key){return optInt(key,0);}int optInt(String key,int fallback){return ((Number)values.getOrDefault(key,fallback)).intValue();}long optLong(String key){return ((Number)values.getOrDefault(key,0)).longValue();}boolean optBoolean(String key,boolean fallback){return (Boolean)values.getOrDefault(key,fallback);}public String toString(){String key=UUID.randomUUID().toString();copies.put(key,new HashMap<>(values));return key;}}
  class EditText {String value="";String getText(){return value;}void setText(String v){value=v;}}
  class CheckBox {boolean value;boolean isChecked(){return value;}void setChecked(boolean v){value=v;}}
  class SessionManager {static String getToken(Object activity){return "token";}static String getUserId(Object activity){return "0001";}}
  class AuthorityBadge {static boolean authorized=true;static boolean isAuthority(String id){return authorized;}}
  class BackendClient {interface Callback{void onSuccess(JSONObject d);void onError(String m);}static int calls;static Callback pending;static void featureDraft(String token,String folder,Callback cb){calls++;pending=cb;}}
  class MyShopDialogBuilder {interface Click {void run(Object dialog,int which);}static Click accept;MyShopDialogBuilder(Object activity){}MyShopDialogBuilder setTitle(String title){return this;}MyShopDialogBuilder setMessage(String message){return this;}MyShopDialogBuilder setNegativeButton(String title,Click action){return this;}MyShopDialogBuilder setPositiveButton(String title,Click action){accept=action;return this;}void show(){}}
  public class AdminSectionActivity {boolean featureSaving,featureReady=true,gone;String managedCategory="feature_news",managedDisplayTitle="News";int draftRevision=-1;long singleId=45;JSONObject loadedReviewDraft;String toast="";
  EditText singleTitle=new EditText(),singleCaption=new EditText(),singleUrl=new EditText(),singleIcon=new EditText(),singleImage=new EditText(),singleSoonMessage=new EditText(),singlePrice=new EditText(),singleOffer=new EditText(),singleOfferStart=new EditText(),singleOfferEnd=new EditText(),singleTimeLimit=new EditText(),singlePosition=new EditText();CheckBox singleActive=new CheckBox(),singleComingSoon=new CheckBox();boolean separateDraft(){return true;}boolean isFinishing(){return gone;}boolean isDestroyed(){return gone;}void runOnUiThread(Runnable r){r.run();}void toast(String v){toast=v;}
  """;
  String checks="""
  static void check(boolean value){if(!value)throw new AssertionError();}public static void main(String[] args)throws Exception{
   var a=new AdminSectionActivity();a.singleTitle.setText("Unsaved edit");a.reviewSavedFeatureDraft();check(a.featureSaving&&BackendClient.calls==1);a.reviewSavedFeatureDraft();check(BackendClient.calls==1);
   JSONObject draft=new JSONObject().put("category","feature_news").put("title","Moderator draft").put("caption","Description").put("iconUrl","icon").put("imageUrl","image").put("priceMinor",700).put("offerText","offer").put("timeLimitMinutes",20).put("displayOrder",4).put("active",false).put("status","COMING_SOON").put("futureUnknownSetting","keep");
   JSONObject reply=new JSONObject().put("draft",draft).put("revision",3);BackendClient.pending.onSuccess(reply);check(!a.featureSaving&&a.singleTitle.getText().equals("Unsaved edit"));MyShopDialogBuilder.accept.run(null,0);check(a.singleTitle.getText().equals("Moderator draft")&&a.singleImage.getText().equals("image")&&a.draftRevision==3&&!a.singleActive.isChecked()&&a.singleComingSoon.isChecked());
   JSONObject result=a.featureDraftInput();check(result.optString("futureUnknownSetting").equals("keep")&&result.optLong("priceMinor")==700&&result.optLong("id")==45);check(draft.optString("title").equals("Moderator draft"));a.singleTitle.setText("Reviewed");check(a.featureDraftInput().optString("title").equals("Reviewed"));check(a.loadedReviewDraft.optString("title").equals("Moderator draft"));
   a.reviewSavedFeatureDraft();BackendClient.pending.onError("offline");check(!a.featureSaving&&a.toast.contains("offline"));int before=BackendClient.calls;AuthorityBadge.authorized=false;a.reviewSavedFeatureDraft();check(BackendClient.calls==before);AuthorityBadge.authorized=true;a.reviewSavedFeatureDraft();a.gone=true;BackendClient.pending.onSuccess(reply);check(!a.featureSaving);
   System.out.println("PASS shipped Admin Draft Review: authorization, duplicate-read guard, confirm before replacement, saved fields/image/revision, unknown settings preservation, failure and closed activity.");
  }}
  """;
  Path root=Files.createTempDirectory("draft-review-");try{
   Files.writeString(root.resolve("AdminSectionActivity.java"),fixture+review+input+checks);var compiler=ToolProvider.getSystemJavaCompiler();try(var fm=compiler.getStandardFileManager(null,null,null)){if(!compiler.getTask(null,fm,null,List.of("-proc:none","-d",root.toString()),null,fm.getJavaFileObjects(root.resolve("AdminSectionActivity.java").toFile())).call())throw new AssertionError("Draft Review javac failed");}try(var loader=new java.net.URLClassLoader(new java.net.URL[]{root.toUri().toURL()})){loader.loadClass("AdminSectionActivity").getMethod("main",String[].class).invoke(null,(Object)new String[0]);}
  }finally{try(var paths=Files.walk(root)){for(Path path:paths.sorted(Comparator.reverseOrder()).toList())Files.delete(path);}}
 }
}
