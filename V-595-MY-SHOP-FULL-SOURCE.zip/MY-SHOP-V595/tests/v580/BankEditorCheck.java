import java.nio.file.*;import java.util.*;import javax.tools.*;
public class BankEditorCheck {
 public static void main(String[] args)throws Exception{
  String source=Files.readString(Path.of("app/src/main/java/com/myshop/app/CoinWithdrawalActivity.java"));String code=source.substring(source.indexOf("    private void setBankEditorEnabled("),source.indexOf("    private void refreshCurrencyButtons()"));
  String fixture="""
  class View{boolean enabled=true;void setEnabled(boolean value){enabled=value;}}
  class EditText extends View{}
  class TextView extends View{String text="";void setText(String value){text=value;}}
  class LinearLayout{View[] children={new EditText(),new EditText(),new TextView()};int getChildCount(){return children.length;}View getChildAt(int i){return children[i];}}
  class JSONObject{JSONObject account;JSONObject optJSONObject(String key){return account;}int optInt(String key){return 2;}}
  class androidx{static class appcompat{static class app{static class AlertDialog{boolean showing=true,cancel=true,outside=true;View[] buttons={new View(),new View(),new View()};View getButton(int i){return buttons[-i-1];}void setCancelable(boolean v){cancel=v;}void setCanceledOnTouchOutside(boolean v){outside=v;}boolean isShowing(){return showing;}void dismiss(){showing=false;}}}}}
  class BackendClient{interface Callback{void onSuccess(JSONObject d);void onError(String m);}static int calls;static boolean throwing;static Callback pending;static void bankAccountSave(String token,JSONObject body,boolean remove,Callback cb){if(throwing)throw new RuntimeException();calls++;pending=cb;}}
  class SessionManager{static String getToken(Object activity){return "token";}}
  class Toast{static int LENGTH_SHORT=0;static Toast makeText(Object activity,String message,int length){return new Toast();}void show(){}}
  public class CoinWithdrawalActivity{boolean bankBusy,sending,gone;JSONObject savedBank=new JSONObject();int bankRevision;TextView bankState=new TextView();boolean isFinishing(){return gone;}boolean isDestroyed(){return gone;}void runOnUiThread(Runnable r){r.run();}
  """;
  String checks="""
  static void check(boolean v){if(!v)throw new AssertionError();}public static void main(String[] args){var a=new CoinWithdrawalActivity();var form=new LinearLayout();var dialog=new androidx.appcompat.app.AlertDialog();var message=new TextView();a.saveBankAccount(new JSONObject(),false,dialog,message,form);check(a.bankBusy&&!form.children[0].enabled&&!form.children[1].enabled&&form.children[2].enabled&&!dialog.cancel&&!dialog.outside&&!dialog.getButton(-2).enabled);a.saveBankAccount(new JSONObject(),false,dialog,message,form);check(BackendClient.calls==1);BackendClient.pending.onError("offline");check(!a.bankBusy&&form.children[0].enabled&&dialog.cancel&&dialog.getButton(-2).enabled&&message.text.contains("offline"));BackendClient.throwing=true;a.saveBankAccount(new JSONObject(),false,dialog,message,form);check(!a.bankBusy&&form.children[0].enabled);BackendClient.throwing=false;a.saveBankAccount(new JSONObject(),false,dialog,message,form);JSONObject reply=new JSONObject();reply.account=new JSONObject();BackendClient.pending.onSuccess(reply);check(!a.bankBusy&&!dialog.showing&&a.savedBank==reply.account&&a.bankRevision==2);int before=BackendClient.calls;a.saveBankAccount(new JSONObject(),false,dialog,message,form);check(BackendClient.calls==before);System.out.println("PASS shipped Bank editor: pending field/cancel freeze, duplicate submission, offline/synchronous failure recovery, revision/success and dismissed-dialog guard.");}}
  """;
  Path root=Files.createTempDirectory("bank-editor-");try{Files.writeString(root.resolve("CoinWithdrawalActivity.java"),fixture+code+checks);var compiler=ToolProvider.getSystemJavaCompiler();try(var fm=compiler.getStandardFileManager(null,null,null)){if(!compiler.getTask(null,fm,null,List.of("-proc:none","-d",root.toString()),null,fm.getJavaFileObjects(root.resolve("CoinWithdrawalActivity.java").toFile())).call())throw new AssertionError("Bank editor javac failed");}try(var loader=new java.net.URLClassLoader(new java.net.URL[]{root.toUri().toURL()})){loader.loadClass("CoinWithdrawalActivity").getMethod("main",String[].class).invoke(null,(Object)new String[0]);}}finally{try(var paths=Files.walk(root)){for(Path p:paths.sorted(Comparator.reverseOrder()).toList())Files.delete(p);}}
 }
}
