import java.nio.file.*;import java.util.*;import javax.tools.*;
public class EditorSaveCheck {
 public static void main(String[]args)throws Exception{
  String source=Files.readString(Path.of("app/src/main/java/com/myshop/app/VisualDesign.java"));String code=source.substring(source.indexOf("    private static void save("),source.indexOf("    private VisualDesign()"));Path root=Files.createTempDirectory("editor-save-");
  String stubs="""
  class View {boolean enabled=true;Object tag;void setEnabled(boolean v){enabled=v;}Object getTag(int key){return tag;}}
  class ViewGroup extends View {View[] views={new View(),new View()};int getChildCount(){return views.length;}View getChildAt(int i){return views[i];}}
  class TextView extends View {String text="";void setText(String s){text=s;}}
  class JSONObject {String value;int revision;JSONObject published,draft;JSONObject(){value="{}";}JSONObject(String s){value=s;}JSONObject put(String k,Object v){return this;}int optInt(String k){return revision;}JSONObject optJSONObject(String k){return k.equals("styles")?published:draft;}public String toString(){return value;}}
  class Activity {boolean gone;boolean isFinishing(){return gone;}boolean isDestroyed(){return gone;}void runOnUiThread(Runnable r){r.run();}Prefs getSharedPreferences(String n,int m){return new Prefs();}}
  class Prefs {Prefs edit(){return this;}Prefs putString(String k,String v){return this;}void apply(){}}
  class SessionManager {static String getToken(Activity a){return "token";}}
  class BackendClient {interface Callback{void onSuccess(JSONObject d);void onError(String m);}static int calls;static Callback pending;static void visualDesignSave(String token,JSONObject request,Callback cb){calls++;pending=cb;}}
  class androidx {static class appcompat {static class app {static class AlertDialog{TextView yes=new TextView(),publish=new TextView();boolean dismissed;TextView getButton(int n){return n==-1?yes:publish;}void dismiss(){dismissed=true;}}}}}
  class R {static class id{static int visual_design_state=1;}}
  public class Fixture {static class State {boolean saving,editing=true;String savedDraft="{}";JSONObject draft=new JSONObject(),published=new JSONObject();int revision,draftRevision;}
  """;
  String checks="""
  static void check(boolean v){if(!v)throw new AssertionError();}public static void main(String[]args){Activity a=new Activity();View root=new View();State s=new State();root.tag=s;ViewGroup controls=new ViewGroup();TextView status=new TextView();var dialog=new androidx.appcompat.app.AlertDialog();save(a,root,"home_quick",s,false,status,dialog,controls);check(s.saving&&!controls.enabled&&!controls.views[0].enabled&&!dialog.yes.enabled&&BackendClient.calls==1);save(a,root,"home_quick",s,false,status,dialog,controls);check(BackendClient.calls==1);BackendClient.pending.onError("offline");check(!s.saving&&controls.enabled&&controls.views[0].enabled&&dialog.yes.enabled&&status.text.contains("offline"));s.draft=new JSONObject("unsaved");save(a,root,"home_quick",s,true,status,dialog,controls);check(BackendClient.calls==1&&status.text.contains("Draft Save"));save(a,root,"home_quick",s,false,status,dialog,controls);JSONObject reply=new JSONObject();reply.revision=2;reply.published=new JSONObject();reply.draft=new JSONObject("saved");BackendClient.pending.onSuccess(reply);check(!s.saving&&s.savedDraft.equals("saved")&&s.revision==2&&controls.enabled);save(a,root,"home_quick",s,false,status,dialog,controls);s.editing=false;BackendClient.pending.onSuccess(reply);check(!s.saving);System.out.println("PASS shipped editor Save: all controls freeze, repeated-save prevention, failure recovery, saved-draft publish guard, callback and closed-editor handling.");}}
  """;
  try{Files.writeString(root.resolve("Fixture.java"),stubs+code+checks);var compiler=ToolProvider.getSystemJavaCompiler();try(var fm=compiler.getStandardFileManager(null,null,null)){if(!compiler.getTask(null,fm,null,List.of("-proc:none","-d",root.toString()),null,fm.getJavaFileObjects(root.resolve("Fixture.java").toFile())).call())throw new AssertionError("Editor Save javac failed");}try(var loader=new java.net.URLClassLoader(new java.net.URL[]{root.toUri().toURL()})){loader.loadClass("Fixture").getMethod("main",String[].class).invoke(null,(Object)new String[0]);}}finally{try(var paths=Files.walk(root)){for(Path p:paths.sorted(Comparator.reverseOrder()).toList())Files.delete(p);}}
 }
}
