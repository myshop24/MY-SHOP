"""Exercise the exact source-selector code shipped in the GitHub workflow."""
import os
from pathlib import Path
import subprocess
import tempfile
import textwrap
import zipfile

project = Path(__file__).resolve().parents[2]
workflow = (project/'.github/workflows/my-shop-apk.yml').read_text()
block = workflow.split("          python3 - <<'PY'\n", 1)[1].split('\n          PY', 1)[0]
code = textwrap.dedent(block)
compile(code, '<shipped-workflow-source-selector>', 'exec')

def fixture(folder, version):
    folder.mkdir(parents=True, exist_ok=True)
    (folder/'app').mkdir(exist_ok=True)
    (folder/'tools').mkdir(exist_ok=True)
    (folder/'SOURCE_BUILD_ID.txt').write_text(f'MY SHOP V-{version}\n')
    (folder/'SOURCE_VERSION_NAME.txt').write_text(f'2.9.{version}\n')
    (folder/'app/build.gradle').write_text(f'versionCode {version}\n')
    (folder/'tools/ci-apk-build.sh').write_text('#!/bin/bash\n')

def run(root, success=True, expected=None):
    output = root/'output.txt'
    env = dict(os.environ, GITHUB_OUTPUT=str(output))
    result = subprocess.run(['python3', '-c', code], cwd=root, env=env, capture_output=True, text=True)
    assert (result.returncode == 0) == success, result.stderr
    if expected:
        assert expected in (output.read_text() if success else result.stderr), result

with tempfile.TemporaryDirectory() as tmp:
    base = Path(tmp)
    root = base/'unpacked'; fixture(root, 567)
    run(root, expected='project=.\nversion=567')
    root = base/'nested'; fixture(root/'MY-SHOP-V-567', 567)
    run(root, expected='project=MY-SHOP-V-567\nversion=567')
    source = base/'source'; fixture(source, 567)
    for n, name in enumerate(['V-567-MY-SHOP-SOURCE.zip', 'MY-SHOP-V-567-SOURCE.zip', 'MY-SHOP-V567-SOURCE.zip', 'MY-SHOP-V-567-FULL-SOURCE.zip', 'MY-SHOP-V567-FULL-SOURCE.zip', 'V-567-MY-SHOP-FULL-SOURCE.zip']):
        root = base/f'zip{n}'; root.mkdir()
        with zipfile.ZipFile(root/name, 'w') as z:
            for file in source.rglob('*'):
                if file.is_file(): z.write(file, file.relative_to(source))
        run(root, expected='project=.ci-source\nversion=567')
    # Highest archive must beat stale unpacked source.
    root=base/'mixed'; fixture(root, 566)
    with zipfile.ZipFile(root/'V-567-MY-SHOP-SOURCE.zip','w') as z:
        for file in source.rglob('*'):
            if file.is_file(): z.write(file, file.relative_to(source))
    run(root, expected='version=567')
    root=base/'mismatch'; root.mkdir()
    with zipfile.ZipFile(root/'V-568-MY-SHOP-SOURCE.zip','w') as z:
        for file in source.rglob('*'):
            if file.is_file(): z.write(file, file.relative_to(source))
    run(root, success=False, expected='identity differ')
    root=base/'duplicate'; root.mkdir()
    for name in ['V-567-FIRST.zip', 'V-567-SECOND.zip']:
        with zipfile.ZipFile(root/name, 'w') as z:
            for file in source.rglob('*'):
                if file.is_file(): z.write(file, file.relative_to(source))
    run(root, success=False, expected='Multiple source projects')
    root=base/'unsafe'; root.mkdir()
    with zipfile.ZipFile(root/'V-567-MY-SHOP-SOURCE.zip','w') as z: z.writestr('../outside','no')
    run(root, success=False, expected='Unsafe ZIP path')
print('PASS V567 shipped source selector: root/nested, 6 ZIP names, newest selection, mismatched identity duplicate newest source and unsafe path rejection')
