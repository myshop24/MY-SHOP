const fs=require('node:fs'),vm=require('node:vm'),path=require('node:path'),assert=require('node:assert/strict');
const {DatabaseSync}=require('node:sqlite'),{webcrypto}=require('node:crypto');
const root=path.resolve(__dirname,'../..'),source=fs.readFileSync(path.join(root,'backend/worker/src/index.js'),'utf8');
const db=new DatabaseSync(':memory:');
function stmt(sql,args=[]){return{sql,args,bind(...a){if(a.some(v=>v===undefined))throw Error('undefined SQL bind');return stmt(sql,a)},async first(k){const x=db.prepare(sql).get(...args);return x?(k?x[k]:x):null},async all(){return{results:db.prepare(sql).all(...args)}},async run(){const x=db.prepare(sql).run(...args);return{success:true,meta:{changes:Number(x.changes),last_row_id:Number(x.lastInsertRowid)}}}}}
const DB={prepare:stmt,async batch(xs){db.exec('BEGIN');try{const out=[];for(const x of xs)out.push(await x.run());db.exec('COMMIT');return out}catch(e){db.exec('ROLLBACK');throw e}},async exec(sql){db.exec(sql);return{count:1}}};
const c={Response,Request,Headers,URL,URLSearchParams,File,FormData,Blob,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,atob,btoa,crypto:webcrypto,agoraRtcTokenPkg:{RtcTokenBuilder:{},Role:{}},setTimeout,clearTimeout,console,fetch:async()=>{throw Error('unexpected network')}};vm.createContext(c);require('../v595/load-modules.cjs')(c,root);
vm.runInContext(fs.readFileSync(path.join(root,'backend/worker/src/request-notices.js'),'utf8').replace(/export /g,''),c);
vm.runInContext(source.replace(/^import .*;\s*$/mg,'').replace(/export default\s*\{/,'const worker = {').replace(/export class /g,'class '),c);
for(const m of source.matchAll(/`(CREATE TABLE IF NOT EXISTS [\s\S]*?)`/g)){if(!m[1].includes('${'))try{db.exec(m[1])}catch(e){throw Error('DDL '+e.message)}}
const env={DB,MEDIA:{async delete(){},async put(){}},LIVE_ROOM_HUB:null};
vm.runInContext(`getUser=async r=>{const a=r.headers.get('authorization');if(a==='Bearer admin')return{user_id:'0001',role:'ADMIN',full_name:'Admin'};if(a==='Bearer host')return{user_id:'0456',role:'USER',full_name:'Host'};if(a==='Bearer viewer')return{user_id:'0123',role:'USER',full_name:'Viewer'};return null};isRoomAdmin=async()=>false;isAssignedModerator=async()=>false;liveSanctionFor=async()=>'';createUserNotification=async()=>{};liveHubDirty=async()=>{};`,c);
const req=(body,actor)=>new Request('https://test.local/v1/live/invite',{method:'POST',headers:{authorization:'Bearer '+actor,'content-type':'application/json'},body:JSON.stringify(body)});
(async()=>{
 await c.ensureLiveRoomSchema(env);await c.ensureMessageSchema(env);await c.ensureNotificationSchema(env);
 for(const [id,name]of [['0123','Sender'],['0456','Host'],['0789','Guest']])await DB.prepare("INSERT INTO myshop_auth_users_v108(user_id,full_name,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,active) VALUES(?,?,'test','q','a','q','a','q','a',1)").bind(id,name).run();
 vm.runInContext(`reconcileLevelProgress=async()=>{};applyStarsAndLevels=async()=>{};liveHubPush=async()=>{};`,c);
 await DB.prepare("INSERT INTO myshop_live_presence(user_id,active) VALUES('0456',1)").run();await DB.prepare("INSERT INTO myshop_live_room_meta(host_id,session_id) VALUES('0456','s552')").run();
 await DB.prepare("INSERT INTO myshop_live_seats_dynamic(host_id,seat_no,user_id) VALUES('0456',2,'0789')").run();
 await DB.prepare("INSERT INTO myshop_coin_wallets(user_id,balance) VALUES('0123',100000)").run();
 await DB.prepare("UPDATE myshop_finance_config SET vat_percent=0 WHERE id=1").run();
 const gift=await DB.prepare("SELECT id,price FROM myshop_live_gifts WHERE currency='COIN' AND enabled=1 LIMIT 1").first();assert.ok(gift);
 const send=(nonce,qty,rec=['0456','0789'])=>c.liveGiftSend(req({hostId:'0456',giftId:gift.id,receiverIds:rec,quantity:qty,clientNonce:nonce},'viewer'),env);
 const before=db.prepare("SELECT balance FROM myshop_coin_wallets WHERE user_id='0123'").get().balance;
 let res=await send('test-combo-552-01',10),out=await res.json();assert.equal(res.status,201,JSON.stringify(out));assert.equal(out.combo,10);assert.equal(out.quantity,10);assert.equal(out.eventIds.length,2);assert.equal(db.prepare("SELECT balance FROM myshop_creator_earnings WHERE user_id='0456' AND currency='COIN'").get().balance,gift.price*10);assert.equal(out.totalDebit,(gift.price*10+Math.round(gift.price*10*.1))*2);
 assert.equal(db.prepare("SELECT balance FROM myshop_coin_wallets WHERE user_id='0123'").get().balance,before-(gift.price*10+Math.round(gift.price*10*.1))*2);
 assert.equal(db.prepare("SELECT COUNT(*) n FROM myshop_value_ledger WHERE sender_id='0123'").get().n,2);
 res=await send('test-combo-552-01',10);assert.equal(res.status,200);assert.equal((await res.json()).duplicateSuppressed,true);assert.equal(db.prepare("SELECT balance FROM myshop_coin_wallets WHERE user_id='0123'").get().balance,before-(gift.price*10+Math.round(gift.price*10*.1))*2);
 const count=db.prepare("SELECT COUNT(*) n FROM myshop_live_gift_events").get().n;
 for(const [nonce,qty,targets,code]of [['invalid-552-1',0,['0456'],400],['invalid-552-2',1,['0123'],400],['invalid-552-3',1,['0999'],409],['invalid-552-4',1.5,['0456'],400]])assert.equal((await send(nonce,qty,targets)).status,code);
 assert.equal(db.prepare("SELECT COUNT(*) n FROM myshop_live_gift_events").get().n,count);
 // Force a late recipient-credit failure: debit and nonce claim must roll back.
 db.exec("CREATE TRIGGER reject_credit BEFORE INSERT ON myshop_creator_earnings WHEN NEW.user_id='0789' BEGIN SELECT RAISE(ABORT,'test failure');END;");
 const balanceNow=db.prepare("SELECT balance FROM myshop_coin_wallets WHERE user_id='0123'").get().balance;
 res=await send('test-rollback-552',6);assert.equal(res.status,409);assert.equal(db.prepare("SELECT balance FROM myshop_coin_wallets WHERE user_id='0123'").get().balance,balanceNow);assert.equal(db.prepare("SELECT COUNT(*) n FROM myshop_live_gift_transactions WHERE nonce='test-rollback-552'").get().n,0);db.exec('DROP TRIGGER reject_credit');
 await DB.prepare("UPDATE myshop_coin_wallets SET balance=0 WHERE user_id='0123'").run();assert.equal((await send('test-poor-552-01',20)).status,409);
 await DB.prepare("UPDATE myshop_coin_wallets SET balance=100000 WHERE user_id='0123'").run();assert.equal((await send('test-threshold552',5,['0456'])).status,201);const threshold=await(await send('test-threshold552',5,['0456'])).json();assert.equal(threshold.combo,5);
 // Ordered device presence: a delayed foreground heartbeat cannot reverse background.
 const presence=(b)=>c.appPresence(req(b,'viewer'),env);
 await presence({active:true,deviceId:'phoneA',sequence:1});await presence({active:false,deviceId:'phoneA',sequence:3});await presence({active:true,deviceId:'phoneA',sequence:2});assert.equal(db.prepare("SELECT active FROM myshop_app_presence WHERE user_id='0123'").get().active,0);
 await presence({visible:false});assert.equal(db.prepare("SELECT active FROM myshop_app_presence WHERE user_id='0123'").get().active,0);
 await presence({active:true,deviceId:'phoneB',sequence:1});await presence({active:false,deviceId:'phoneA',sequence:4});assert.equal(db.prepare("SELECT active FROM myshop_app_presence WHERE user_id='0123'").get().active,1);
 db.exec("UPDATE myshop_app_presence_sessions SET last_seen=datetime('now','-31 seconds') WHERE user_id='0123'");await presence({active:false,deviceId:'phoneA',sequence:5});assert.equal(db.prepare("SELECT active FROM myshop_app_presence WHERE user_id='0123'").get().active,0);
 // Regular user cannot send self-test push; diagnostics do not expose credentials.
 assert.equal((await c.pushSelfTest(req({},'viewer'),env)).status,403);const diag=await(await c.pushDiagnostics(req({},'viewer'),env)).json();assert.equal(diag.serverConfigured,false);assert.equal(JSON.stringify(diag).includes('private_key'),false);

 // Messenger: server acceptance differs from receiver delivery and explicit read.
 vm.runInContext('safetyIsBlocked=async()=>false;',c);
 const msgReq=(b,actor)=>req(b,actor);
 let message=await c.messageSend(msgReq({userId:'0456',message:'draft survives',clientNonce:'msg-552-01'},'viewer'),env),msgOut=await message.json();assert.equal(message.status,201);
 assert.equal((await c.messageSend(msgReq({userId:'0456',message:'draft survives',clientNonce:'msg-552-01'},'viewer'),env)).status,200);assert.equal(db.prepare("SELECT COUNT(*) n FROM myshop_messages WHERE client_nonce='msg-552-01'").get().n,1);
 // A retry key must never silently accept changed text, recipient or attachment.
 env.MEDIA.head=async()=>({size:100});
 for(const changed of [{userId:'0456',message:'changed text'},{userId:'0789',message:'draft survives'},{userId:'0456',message:'draft survives',mediaType:'IMAGE',mediaUrl:'https://test.local/v1/media/messages/media/0123/photo.jpg'}]){
  assert.equal((await c.messageSend(msgReq({...changed,clientNonce:'msg-552-01'},'viewer'),env)).status,409);
 }
 assert.equal(db.prepare("SELECT COUNT(*) n FROM myshop_messages WHERE client_nonce='msg-552-01'").get().n,1);
 for(const [mediaUrl,status] of [['https://external.test/voice.mp3',400],['https://test.local/v1/media/messages/voice/0456/voice.mp3',403]]){
  assert.equal((await c.messageSend(msgReq({userId:'0456',mediaType:'AUDIO',mediaUrl,clientNonce:'audio-private-552'},'viewer'),env)).status,status);
 }
 assert.equal(db.prepare('SELECT delivered_at FROM myshop_messages WHERE id=?').get(msgOut.id).delivered_at,null);
 await c.messageInbox(new Request('https://test.local/v1/messages/inbox',{headers:{authorization:'Bearer host'}}),env);assert.ok(db.prepare('SELECT delivered_at FROM myshop_messages WHERE id=?').get(msgOut.id).delivered_at);
 await c.messageThread(new Request('https://test.local/v1/messages/thread?userId=0123',{headers:{authorization:'Bearer host'}}),env);assert.ok(db.prepare('SELECT read_at FROM myshop_messages WHERE id=?').get(msgOut.id).read_at);
 await c.messageTyping(msgReq({userId:'0456',active:true},'viewer'),env);let thread=await(await c.messageThread(new Request('https://test.local/v1/messages/thread?userId=0123',{headers:{authorization:'Bearer host'}}),env)).json();assert.equal(thread.typing,true);
 db.exec("UPDATE myshop_message_typing SET last_seen=datetime('now','-7 seconds')");thread=await(await c.messageThread(new Request('https://test.local/v1/messages/thread?userId=0123',{headers:{authorization:'Bearer host'}}),env)).json();assert.equal(thread.typing,false);
 assert.equal((await c.notificationPreferences(msgReq({messages:false,live:true,promo:false},'viewer'),env)).status,200);assert.equal(db.prepare("SELECT messages FROM myshop_notification_preferences WHERE user_id='0123'").get().messages,0);
 // Room settings: actor authorization, no partial invalid save, history + restore.
 assert.equal((await c.liveBatchSettings(req({hostId:'0456',slowModeSeconds:4},'viewer'),env)).status,403);
 assert.equal((await c.liveBatchSettings(req({hostId:'0456',slowModeSeconds:4,giftComboEnabled:false,pinnedMessage:'5 minute notice',pinnedMinutes:5},'host'),env)).status,200);
 assert.equal(db.prepare("SELECT slow_mode_seconds FROM myshop_live_room_meta WHERE host_id='0456'").get().slow_mode_seconds,4);
 assert.equal((await c.liveBatchSettings(req({hostId:'0456',slowModeSeconds:61},'host'),env)).status,400);
 assert.equal((await c.liveBatchSettings(req({hostId:'0456',restore:true},'host'),env)).status,200);assert.equal(db.prepare("SELECT slow_mode_seconds FROM myshop_live_room_meta WHERE host_id='0456'").get().slow_mode_seconds,0);
 assert.equal(db.prepare("SELECT COUNT(*) n FROM myshop_live_setting_history WHERE host_id='0456'").get().n,2);
 // Configured currency rates must be shared by gift, transfer and withdrawal.
 const cfgResponse=await c.adminFinanceConfig(req({coinCommissionPercent:10,goldCommissionPercent:5},'admin'),env);assert.equal(cfgResponse.status,200);
 const cfg557=await c.financeConfig(env);assert.equal(c.commissionRate(cfg557,'COIN'),10);assert.equal(c.commissionRate(cfg557,'GOLD'),5);
 assert.equal((await c.adminFinanceConfig(req({coinCommissionPercent:101,goldCommissionPercent:23},'admin'),env)).status,400);assert.equal((await c.financeConfig(env)).coinCommissionPercent,10);
 assert.equal((await c.adminFinanceConfig(req({coinCommissionPercent:0},'viewer'),env)).status,403);
 assert.equal(c.profileSharePage(new URL('https://test/profile?userId=0001')).status,200);assert.equal(c.profileSharePage(new URL('https://test/profile?userId=%3Cscript%3E')).status,400);
 // Play currency grant: purchase, wallet, purchased source and progress share one transaction.
 await c.ensureLevelSchema(env);db.prepare("INSERT OR IGNORE INTO myshop_user_progress(user_id) VALUES('0123')").run();
 const pack={id:991,item_type:'COIN',units:100000};
 const walletBefore=db.prepare("SELECT balance FROM myshop_coin_wallets WHERE user_id='0123'").get().balance;
 await c.playGrantAtomic(env,'0123',pack,'coin.pack','play-token-552','order552','{}');
 assert.equal(db.prepare("SELECT balance FROM myshop_coin_wallets WHERE user_id='0123'").get().balance,walletBefore+100000);
 assert.equal(db.prepare("SELECT COUNT(*) n FROM myshop_play_purchases WHERE purchase_token_hash='play-token-552'").get().n,1);
 const srcBefore=db.prepare("SELECT official_balance FROM myshop_wallet_sources WHERE user_id='0123' AND currency='COIN'").get().official_balance;
 await assert.rejects(()=>c.playGrantAtomic(env,'0123',pack,'coin.pack','play-token-552','order552','{}'));
 assert.equal(db.prepare("SELECT official_balance FROM myshop_wallet_sources WHERE user_id='0123' AND currency='COIN'").get().official_balance,srcBefore);
 db.exec("CREATE TRIGGER fail_play_progress BEFORE INSERT ON myshop_star_level_ledger WHEN NEW.tx_type='GOOGLE_PLAY_PURCHASE' BEGIN SELECT RAISE(ABORT,'test failure'); END;");
 await assert.rejects(()=>c.playGrantAtomic(env,'0123',pack,'coin.pack','play-failure-552','order553','{}'));
 assert.equal(db.prepare("SELECT balance FROM myshop_coin_wallets WHERE user_id='0123'").get().balance,walletBefore+100000);
 assert.equal(db.prepare("SELECT COUNT(*) n FROM myshop_play_purchases WHERE purchase_token_hash='play-failure-552'").get().n,0);
 db.exec('DROP TRIGGER fail_play_progress');
 // Endpoint rejects wrong purchase account and pending payment before any credit.
 await c.ensureContentSchema(env);
 db.prepare("INSERT INTO myshop_store_catalog(id,code,title,item_type,units,play_product_id,enabled) VALUES(991,'COIN_TEST','Coin Test','COIN',100000,'coin.pack',1)").run();
 vm.runInContext("googlePublisherAccessToken=async()=> 'test-access';",c);
 const purchaseBody={catalogId:991,productId:'coin.pack',purchaseToken:'purchase-token-552-unique'};
 const playReq=()=>new Request('https://test.local/v1/play/purchase/verify',{method:'POST',headers:{authorization:'Bearer viewer'},body:JSON.stringify(purchaseBody)});
 let googleResult={obfuscatedExternalAccountId:'wrong-account',purchaseStateContext:{purchaseState:'PURCHASED'},productLineItem:[{productId:'coin.pack',quantity:1}]};
 c.fetch=async()=>new Response(JSON.stringify(googleResult),{status:200});
 assert.equal((await c.playPurchaseVerify(playReq(),env)).status,409);
 googleResult.obfuscatedExternalAccountId=await c.sha256('MYSHOP_PLAY_ACCOUNT:0123');googleResult.purchaseStateContext.purchaseState='PENDING';
 assert.equal((await c.playPurchaseVerify(playReq(),env)).status,409);
 googleResult.purchaseStateContext.purchaseState='PURCHASED';
 assert.equal((await c.playPurchaseVerify(playReq(),env)).status,200);
 assert.equal((await c.playPurchaseVerify(playReq(),env)).status,200);
 assert.equal(db.prepare("SELECT balance FROM myshop_coin_wallets WHERE user_id='0123'").get().balance,walletBefore+200000);
 console.log('PASS V557 — separate commission rates, rejected invalid/unauthorized update, safe profile landing');
 console.log('PASS — combo threshold, multi recipients, exact debit/credits, retry idempotency, full rollback, insufficient balance, ordered/multidevice presence, privacy, stale expiry, Admin-only test and secret-free diagnostics');
})().catch(e=>{console.error(e);process.exitCode=1});
