import java.nio.file.*;
import java.util.*;
import javax.tools.*;
import com.sun.source.util.JavacTask;

/** Real javac parsing only; Android symbol resolution and APK assembly are separate checks. */
public final class JavaSourceSyntaxCheck {
 public static void main(String[] args)throws Exception{
  JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();if(compiler==null)throw new IllegalStateException("JDK compiler unavailable");
  DiagnosticCollector<JavaFileObject> errors=new DiagnosticCollector<>();ArrayList<java.io.File> sources=new ArrayList<>();
  try(var paths=Files.walk(Path.of(args.length==0?"app/src/main/java":args[0]))){paths.filter(p->p.toString().endsWith(".java")).forEach(p->sources.add(p.toFile()));}
  try(StandardJavaFileManager files=compiler.getStandardFileManager(errors,null,null)){
   JavacTask task=(JavacTask)compiler.getTask(null,files,errors,List.of("-proc:none","-source","17"),null,files.getJavaFileObjectsFromFiles(sources));task.parse();
   boolean failed=false;for(var error:errors.getDiagnostics())if(error.getKind()==Diagnostic.Kind.ERROR){System.err.println(error);failed=true;}
   if(failed)System.exit(1);System.out.println("PASS — javac parsed "+sources.size()+" Java sources; Android types and APK NOT checked");
  }
 }
}
