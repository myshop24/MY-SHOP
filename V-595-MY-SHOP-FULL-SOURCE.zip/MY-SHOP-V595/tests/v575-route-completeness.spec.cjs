const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),file=path.join(root,'backend/worker/src/index.js'),source=fs.readFileSync(file,'utf8');
const router=source.slice(source.indexOf('export default {'));
const defined=new Set([...source.matchAll(/(?:async\s+)?function\s+(\w+)\s*\(/g)].map(m=>m[1]));
for(const m of source.matchAll(/import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"]/g)) {
 const dependency=fs.readFileSync(path.resolve(path.dirname(file),m[2]),'utf8');
 for(const part of m[1].split(',')) {const [exported,local]=part.trim().split(/\s+as\s+/);if(!exported)continue;defined.add(local||exported);assert.match(dependency,new RegExp('export\\s+(?:async\\s+)?(?:function|const|class|let)\\s+'+exported+'\\b'),'Missing imported export '+exported);}
}
const handlers=new Set([...router.matchAll(/return\s+(?:await\s+)?(\w+)\s*\(request\s*,\s*env/g)].map(m=>m[1]));
assert.ok(handlers.size>100,'Route scan unexpectedly incomplete');
for(const name of handlers)assert.ok(defined.has(name),'Route references missing handler: '+name);
for(const name of ['messageInbox','messageThread','messageMediaUpload','messageVoiceUpload','messageSend','messageDeleteForMe','messageUnread','mediaGet','adminSafetyReports','playBillingReady','playPurchaseVerify'])assert.ok(handlers.has(name),'Recovery handler has no route: '+name);
console.log('PASS '+handlers.size+' routed handlers and named module exports exist; this is structural coverage, not endpoint runtime coverage.');
