import java.nio.file.*;import javax.tools.*;
class IconCheck593 {
 public static void main(String[] args)throws Exception{
  Path dir=Files.createTempDirectory("icon593-");Path source=dir.resolve("IconPixels.java");Files.copy(Path.of("app/src/main/java/com/myshop/app/IconPixels.java"),source);
  Path check=dir.resolve("Check.java");Files.writeString(check,"""
  package com.myshop.app;
  public class Check {
   static void yes(boolean value){if(!value)throw new AssertionError();}
   public static void main(String[] args){
    int[] source={0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xff000000,0xff000000,0xffffffff,0xffffffff,0xff000000,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff};
    int[] clean=IconPixels.prepare(source,4,4,true);yes(source[0]==0xffffffff);yes(clean[0]==0);yes(clean[5]==0xff000000);yes(clean[10]==0);int[] bounds=IconPixels.bounds(clean,4,4);yes(bounds[0]==1&&bounds[1]==1&&bounds[2]==2&&bounds[3]==2);
    int[] enclosed=new int[25];java.util.Arrays.fill(enclosed,0xffffffff);for(int y=1;y<4;y++)for(int x=1;x<4;x++)enclosed[y*5+x]=0xff000000;enclosed[12]=0xffffffff;clean=IconPixels.prepare(enclosed,5,5,true);yes(clean[12]==0xffffffff);yes(clean[0]==0);
    yes(java.util.Arrays.equals(IconPixels.prepare(enclosed,5,5,false),enclosed));
    int[] alpha=new int[16];alpha[5]=0xffff0000;alpha[6]=0xffff0000;alpha[9]=0xff0000ff;alpha[10]=0xff0000ff;bounds=IconPixels.bounds(alpha,4,4);yes(bounds[0]==1&&bounds[1]==1&&bounds[2]==2&&bounds[3]==2);
    bounds=IconPixels.bounds(new int[12],4,3);yes(bounds[2]==4&&bounds[3]==3);
    int[] rectangular=new int[15];rectangular[6]=0xffff0000;rectangular[7]=0xffff0000;rectangular[8]=0xffff0000;bounds=IconPixels.bounds(rectangular,5,3);yes(bounds[2]==3&&bounds[3]==1);
    System.out.println("PASS actual IconPixels: connected edge cleanup, enclosed white logo preserved, original retained, transparent crop, rectangular aspect and empty-image fallback");
   }
  }
  """);int exit=ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",dir.toString(),source.toString(),check.toString());if(exit!=0)throw new AssertionError("compile failed");try(var loader=new java.net.URLClassLoader(new java.net.URL[]{dir.toUri().toURL()})){loader.loadClass("com.myshop.app.Check").getMethod("main",String[].class).invoke(null,(Object)new String[0]);}
 }
}
