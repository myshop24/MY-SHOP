from pathlib import Path
import hashlib,json
root=Path('.');out=root/'V540-SOURCE-SHA256.json';records={}
for p in sorted(root.rglob('*')):
 if p.is_file() and p!=out and not any(x in {'build','.gradle','.git','node_modules'} for x in p.parts):records[p.relative_to(root).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
out.write_text(json.dumps({'build':'V-540','algorithm':'SHA-256','files':records},indent=2)+'\n')
