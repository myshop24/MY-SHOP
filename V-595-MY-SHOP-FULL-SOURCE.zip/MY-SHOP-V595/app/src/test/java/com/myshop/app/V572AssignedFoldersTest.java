package com.myshop.app;

import android.app.Application;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(org.robolectric.RobolectricTestRunner.class)
@Config(sdk=28, application=Application.class)
public class V572AssignedFoldersTest {
    @Test public void ordinaryUsersAndUnassignedAdminsCannotOpenPermissionManagement() {
        for (Role role : new Role[]{Role.GUEST, Role.USER, Role.ADMIN}) {
            SessionManager.setSession(RuntimeEnvironment.getApplication(), role, "0104");
            AssignedAdminFoldersActivity activity = Robolectric.buildActivity(AssignedAdminFoldersActivity.class).create().get();
            assertTrue("Unauthorized management screen opened for " + role, activity.isFinishing());
        }
    }
    @Test public void mainAdminControlsFitNarrowScreensWithUsableTouchTargets() {
        SessionManager.setSession(RuntimeEnvironment.getApplication(), Role.ADMIN, "0001");
        AssignedAdminFoldersActivity activity = Robolectric.buildActivity(AssignedAdminFoldersActivity.class).setup().get();
        ViewGroup root = activity.findViewById(android.R.id.content);
        float density = activity.getResources().getDisplayMetrics().density;
        for (int width : new int[]{320,360,480}) {
            int pixels = Math.round(width*density);
            root.measure(View.MeasureSpec.makeMeasureSpec(pixels,View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(Math.round(800*density),View.MeasureSpec.EXACTLY));
            root.layout(0,0,pixels,root.getMeasuredHeight());
            assertEquals(2, checkButtons(root,density));
        }
        activity.finish();
    }
    private int checkButtons(ViewGroup group, float density) {
        int count=0;
        for(int i=0;i<group.getChildCount();i++) {
            View child=group.getChildAt(i);
            if(child instanceof Button) {
                assertTrue(child.getMeasuredHeight()>=Math.round(48*density));
                assertTrue(child.getLeft()>=0 && child.getRight()<=group.getWidth());
                count++;
            }
            if(child instanceof ViewGroup) count+=checkButtons((ViewGroup)child,density);
        }
        return count;
    }
}
