package com.myshop.app;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;
import org.json.JSONObject;

/** Server-authoritative central and per-feature rates; owner accounts only. */
public class CommissionManagementActivity extends androidx.appcompat.app.AppCompatActivity {
 private JSONObject config;private int revision;private boolean busy;private LinearLayout body;private TextView status;
 private final String[] currencies={"COIN","GOLD"};
 private final String[] features={"GIFT","TRANSFER","WITHDRAW","HISTORY"};
 private final String[] names={"Gift","Transfer","Withdraw","Ledger"};
 protected void onCreate(Bundle b){super.onCreate(b);String id=SessionManager.getUserId(this);if(!"0001".equals(id)&&!"0002".equals(id)&&!"0003".equals(id)){finish();return;}setContentView(text("কমিশন সেটিং লোড হচ্ছে…",18));load();}
 private void load(){busy=true;BackendClient.commissionManagement(SessionManager.getToken(this),null,new BackendClient.Callback(){public void onSuccess(JSONObject d){busy=false;revision=d.optInt("revision");config=d.optJSONObject("config");render();}public void onError(String m){busy=false;Toast.makeText(CommissionManagementActivity.this,m,Toast.LENGTH_LONG).show();}});}
 private TextView text(String label,int size){TextView t=new TextView(this);t.setText(label);t.setTextSize(size);t.setTextColor(0xff17223f);t.setPadding(dp(8),dp(8),dp(8),dp(8));return t;}
 private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 private void render(){if(config==null)return;ScrollView scroll=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(1);body.setPadding(dp(12),dp(12),dp(12),dp(20));body.setBackgroundColor(Color.WHITE);scroll.addView(body);setContentView(scroll);
 TextView header=text("‹  কমিশন ম্যানেজমেন্ট",22);header.setOnClickListener(v->finish());body.addView(header);
 LinearLayout central=new LinearLayout(this);central.setGravity(Gravity.CENTER);
 for(String c:currencies){JSONObject x=config.optJSONObject("central").optJSONObject(c);TextView icon=text((c.equals("COIN")?"🪙 Coin":"💎 Diamond")+"\n"+x.optDouble("percent")+"% · "+(x.optBoolean("enabled")?"Enabled":"Disabled"),17);icon.setGravity(Gravity.CENTER);icon.setOnClickListener(v->editCentral(c));central.addView(icon,new LinearLayout.LayoutParams(0,dp(104),1));}body.addView(central);
 status=text("Free → কেন্দ্রীয় হার → ফিচারের নিজস্ব হার\nনতুন লেনদেনে কার্যকর; পুরোনো হিসাব বদলাবে না।",13);long until=config.optLong("freeUntil");if(until>System.currentTimeMillis())status.append("\nFree ends: "+android.text.format.DateFormat.format("dd MMM, HH:mm",until));body.addView(status);
 Button free=new Button(this);free.setText("সব কমিশন Free • সময় নির্ধারণ");free.setOnClickListener(v->editFree());body.addView(free);
 LinearLayout row=new LinearLayout(this);for(int i=0;i<4;i++){final String f=features[i];TextView folder=text(new String[]{"🎁","↔","↗","👑"}[i]+"\n"+names[i],13);folder.setGravity(Gravity.CENTER);folder.setOnClickListener(v->{if("HISTORY".equals(f))startActivity(new Intent(this,AdminFinanceActivity.class));else editFeature(f);});row.addView(folder,new LinearLayout.LayoutParams(0,dp(94),1));}body.addView(row);
 body.addView(text("কেনা ব্যালেন্স উত্তোলনযোগ্য নয়। বিদ্যমান Official/Admin কমিশন ছাড় বজায় থাকবে।",12));}
 private EditText number(String hint,double value){EditText e=new EditText(this);e.setHint(hint);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);e.setText(String.valueOf(value));return e;}
 private void editCentral(String c){if(busy)return;JSONObject x=config.optJSONObject("central").optJSONObject(c);LinearLayout box=new LinearLayout(this);box.setOrientation(1);Switch enabled=new Switch(this);enabled.setText("সব ফিচারে কেন্দ্রীয় হার কার্যকর");enabled.setChecked(x.optBoolean("enabled"));box.addView(enabled);EditText percent=number("Commission %",x.optDouble("percent"));box.addView(percent);new MyShopDialogBuilder(this).setTitle(c.equals("COIN")?"Coin":"Diamond").setView(box).setPositiveButton("Save",(d,w)->{try{JSONObject next=new JSONObject(config.toString());next.getJSONObject("central").put(c,new JSONObject().put("enabled",enabled.isChecked()).put("percent",Double.parseDouble(percent.getText().toString())));save(next,null);}catch(Exception e){Toast.makeText(this,"সঠিক হার দিন",Toast.LENGTH_SHORT).show();}}).setNegativeButton("Cancel",null).show();}
 private void editFeature(String f){if(busy)return;LinearLayout box=new LinearLayout(this);box.setOrientation(1);EditText[] rates=new EditText[2];for(int i=0;i<2;i++){String c=currencies[i];box.addView(text(c.equals("COIN")?"Coin":"Diamond",15));double fallback=f.equals("PREMIUM")?0:c.equals("COIN")?10:5;rates[i]=number("Commission %",config.optJSONObject("features").optJSONObject(c).optDouble(f,fallback));box.addView(rates[i]);}new MyShopDialogBuilder(this).setTitle(f+" • পৃথক কমিশন").setView(box).setPositiveButton("Save",(d,w)->{try{JSONObject next=new JSONObject(config.toString());for(int i=0;i<2;i++)next.getJSONObject("features").getJSONObject(currencies[i]).put(f,Double.parseDouble(rates[i].getText().toString()));save(next,null);}catch(Exception e){Toast.makeText(this,"সঠিক হার দিন",Toast.LENGTH_SHORT).show();}}).setNegativeButton("Cancel",null).show();}
 private void editFree(){if(busy)return;EditText hours=number("কত ঘণ্টা? ০ দিলে Free বন্ধ",1);new MyShopDialogBuilder(this).setTitle("সময় নির্ধারিত Free").setView(hours).setPositiveButton("Save",(d,w)->{try{save(new JSONObject(config.toString()),Double.parseDouble(hours.getText().toString()));}catch(Exception e){Toast.makeText(this,"সঠিক সময় দিন",Toast.LENGTH_SHORT).show();}}).setNegativeButton("Cancel",null).show();}
 private void save(JSONObject next,Double hours){if(busy)return;try{JSONObject b=new JSONObject().put("expectedRevision",revision).put("config",next);if(hours!=null)b.put("freeHours",hours);busy=true;BackendClient.commissionManagement(SessionManager.getToken(this),b,new BackendClient.Callback(){public void onSuccess(JSONObject d){busy=false;revision=d.optInt("revision");config=d.optJSONObject("config");render();Toast.makeText(CommissionManagementActivity.this,"কমিশন সেটিং সংরক্ষিত",Toast.LENGTH_SHORT).show();}public void onError(String m){busy=false;Toast.makeText(CommissionManagementActivity.this,m,Toast.LENGTH_LONG).show();load();}});}catch(Exception e){busy=false;}}
}
