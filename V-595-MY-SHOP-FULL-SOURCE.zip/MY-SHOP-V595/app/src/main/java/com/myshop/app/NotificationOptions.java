package com.myshop.app;

import android.app.Activity;
import android.graphics.Color;
import android.widget.*;
import org.json.JSONObject;

/** Account notification choices. Diagnostics never block entry to a Live. */
public final class NotificationOptions {
    private NotificationOptions(){}
    public static void show(Activity activity){
        LinearLayout box=new LinearLayout(activity);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(24,18,24,18);box.setBackgroundColor(0xff14224a);
        String[] names={"Messages","Live alerts","Offers & updates"};Switch[] switches=new Switch[3];String[] keys={"messages","live","promo"};
        for(int i=0;i<3;i++){Switch sw=new Switch(activity);sw.setText(names[i]);sw.setTextColor(Color.WHITE);sw.setEnabled(false);sw.setMinHeight((int)(48*activity.getResources().getDisplayMetrics().density));box.addView(sw);switches[i]=sw;}
        TextView state=new TextView(activity);state.setTextColor(0xffb6cdfa);state.setText("Checking notification connection…");state.setPadding(0,16,0,16);box.addView(state);
        Button settings=new Button(activity);settings.setText("Device notification settings");settings.setOnClickListener(v->NotificationSettings.open(activity));box.addView(settings);
        androidx.appcompat.app.AlertDialog dialog=new MyShopCompatDialogBuilder(activity).setTitle("Notifications").setView(box).setPositiveButton("Save",null).setNegativeButton("Close",null).create();dialog.show();dialog.getButton(-1).setEnabled(false);
        BackendClient.notificationPreferences(SessionManager.getToken(activity),new BackendClient.Callback(){public void onSuccess(JSONObject d){activity.runOnUiThread(()->{if(activity.isFinishing())return;for(int i=0;i<3;i++){switches[i].setChecked(d.optBoolean(keys[i],true));switches[i].setEnabled(true);}dialog.getButton(-1).setEnabled(true);});}public void onError(String error){activity.runOnUiThread(()->state.setText("Settings unavailable • retry when connected"));}});
        BackendClient.pushDiagnostics(SessionManager.getToken(activity),new BackendClient.Callback(){public void onSuccess(JSONObject d){activity.runOnUiThread(()->{android.content.SharedPreferences p=activity.getSharedPreferences("myshop_push_v349",0);boolean enabled=androidx.core.app.NotificationManagerCompat.from(activity).areNotificationsEnabled();String reason=!enabled?"Device permission is off":!PushRegistration.firebaseConfigured()?"App Firebase connection is missing":!p.getBoolean("token_registered",false)?"Device registration is pending":!d.optBoolean("serverConfigured",false)?"Server Firebase connection needs Admin setup":!BuildConfig.FIREBASE_PROJECT_ID.equals(d.optString("serverProject"))?"App and server Firebase projects differ":"Settings ready • device delivery needs a test";state.setText(reason);});}public void onError(String error){activity.runOnUiThread(()->state.setText("Connection check unavailable"));}});
        dialog.getButton(-1).setOnClickListener(v->{JSONObject values=new JSONObject();try{for(int i=0;i<3;i++)values.put(keys[i],switches[i].isChecked());}catch(Exception ignored){}v.setEnabled(false);BackendClient.notificationPreferencesSave(SessionManager.getToken(activity),values,new BackendClient.Callback(){public void onSuccess(JSONObject d){activity.runOnUiThread(()->{for(int i=0;i<3;i++)AccountPreferences.get(activity,"notification_options").edit().putBoolean(keys[i],switches[i].isChecked()).apply();dialog.dismiss();});}public void onError(String error){activity.runOnUiThread(()->{v.setEnabled(true);Toast.makeText(activity,"Could not save • retry",android.widget.Toast.LENGTH_SHORT).show();});}});});
    }
}
