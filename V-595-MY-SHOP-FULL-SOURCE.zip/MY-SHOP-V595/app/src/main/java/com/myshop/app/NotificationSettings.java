package com.myshop.app;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;
import androidx.core.app.NotificationManagerCompat;

/** User-controlled system alert settings; never silently reset a muted channel. */
public final class NotificationSettings {
    private NotificationSettings(){}
    public static String blockedChannel(Activity activity){
        if(!NotificationManagerCompat.from(activity).areNotificationsEnabled())return "APP";
        NotificationManager manager=(NotificationManager)activity.getSystemService(Activity.NOTIFICATION_SERVICE);
        if(manager!=null&&Build.VERSION.SDK_INT>=26){MyShopMessagingService.ensureChannels(manager);for(String id:new String[]{MyShopMessagingService.MESSAGE_CHANNEL,MyShopMessagingService.LIVE_CHANNEL}){NotificationChannel channel=manager.getNotificationChannel(id);if(channel!=null&&channel.getImportance()<NotificationManager.IMPORTANCE_HIGH)return id;}}
        return "";
    }
    public static void open(Activity activity){if(Build.VERSION.SDK_INT<26){activity.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+activity.getPackageName())));return;}String channel=blockedChannel(activity);Intent i=new Intent(Build.VERSION.SDK_INT>=26&&!channel.isEmpty()&&!"APP".equals(channel)?Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS:Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,activity.getPackageName());if(!channel.isEmpty())i.putExtra(Settings.EXTRA_CHANNEL_ID,channel);try{activity.startActivity(i);}catch(Exception e){activity.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+activity.getPackageName())));}}
    public static void explain(Activity activity){new MyShopDialogBuilder(activity).setTitle("মেসেজ ও Live notification চালু করুন").setMessage("Settings-এ myshop notifications চালু করুন। Messages ও Live Alerts-এর Sound, Pop on screen / Banner এবং Lock screen notification অনুমতি দিন। ফোন Silent বা Do Not Disturb থাকলে popup বা sound বন্ধ থাকতে পারে।").setPositiveButton("Open settings",(d,w)->open(activity)).setNegativeButton("পরে",null).show();}
}
