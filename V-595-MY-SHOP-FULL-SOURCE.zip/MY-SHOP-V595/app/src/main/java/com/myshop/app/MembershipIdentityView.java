package com.myshop.app;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import android.animation.ValueAnimator;

/** A real profile photo inside an ornament. Only the light layer animates. */
public final class MembershipIdentityView extends FrameLayout {
    private final ImageView photo;private final AnimatedOrnament ornament;
    private final Sparkles sparkles;
    private final String tier;
    private float cx=168,cy=139,radius=88;
    public MembershipIdentityView(Context context,String code,String avatarUrl){
        super(context);tier=MembershipUi.tier(code);setClipChildren(false);setClipToPadding(false);
        switch(tier){case "KING":cx=166;cy=139;radius=83;break;case "QUEEN":cx=165;cy=141;radius=84;break;case "ROYAL":cx=168;cy=136;radius=85;break;case "VVIP":cx=168;cy=141;radius=88;break;}
        photo=new ImageView(context);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);photo.setImageResource(R.drawable.myshop_profile_avatar);
        GradientDrawable circle=new GradientDrawable();circle.setShape(GradientDrawable.OVAL);circle.setColor(0xFF15253E);photo.setBackground(circle);photo.setClipToOutline(true);addView(photo,new LayoutParams(1,1));
        if(avatarUrl!=null&&!avatarUrl.trim().isEmpty())AnimatedAssetLoader.load(photo,avatarUrl,false);
        ornament=new AnimatedOrnament(context);ornament.setImageResource(MembershipUi.ornament(tier));ornament.setScaleType(ImageView.ScaleType.FIT_CENTER);addView(ornament,new LayoutParams(-1,-1));
        sparkles=new Sparkles(context,MembershipUi.accent(tier),ornament);addView(sparkles,new LayoutParams(-1,-1));
        setContentDescription(tier+" membership frame with your profile photo");setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
    }
    public void setPortraitBitmap(android.graphics.Bitmap bitmap){if(bitmap!=null)photo.setImageBitmap(bitmap);}
    public void setDemo(){setContentDescription(tier+" demo membership");}
    /** Custom PNG/WebP/GIF keeps the documented 320x275 transparent portrait window. */
    public void setFrameAsset(String url){
        if(url==null||url.trim().isEmpty())return;
        String lower=url.toLowerCase(java.util.Locale.US).split("\\?",2)[0];
        if(lower.endsWith(".mp4")||lower.endsWith(".webm")||lower.endsWith(".3gp"))return;
        ornament.custom=true;AnimatedAssetLoader.load(ornament,url.trim(),true);
    }
    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){super.onSizeChanged(w,h,oldw,oldh);float s=Math.min(w/320f,h/275f),left=(w-320*s)/2,top=(h-275*s)/2;
        LayoutParams p=new LayoutParams(Math.round(radius*2*s)+2,Math.round(radius*2*s)+2);p.leftMargin=Math.round(left+(cx-radius)*s)-1;p.topMargin=Math.round(top+(cy-radius)*s)-1;photo.setLayoutParams(p);
        sparkles.cx=left+cx*s;sparkles.cy=top+cy*s;sparkles.radius=radius*s;}
    /** Independently moving wings and crown lighting keep the photo and circular frame stable. */
    private static final class AnimatedOrnament extends androidx.appcompat.widget.AppCompatImageView {
        float phase;boolean custom;
        AnimatedOrnament(Context c){super(c);}
        @Override protected void onDraw(Canvas canvas){
            if(custom){super.onDraw(canvas);return;}float width=getWidth(),height=getHeight();
            int save=canvas.save();canvas.clipRect(width*.25f,0,width*.78f,height);super.onDraw(canvas);canvas.restoreToCount(save);
            for(int side=0;side<2;side++){save=canvas.save();float edge=side==0?width*.25f:width*.78f;canvas.clipRect(side==0?0:edge,0,side==0?edge:width,height);canvas.rotate((float)Math.sin(phase*Math.PI*2)*(side==0?3.5f:-3.5f),edge,height*.57f);super.onDraw(canvas);canvas.restoreToCount(save);}
        }
    }
    private static final class Sparkles extends View {
        final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);final int color;final AnimatedOrnament ornament;float phase,cx,cy,radius;ValueAnimator light;
        Sparkles(Context c,int color,AnimatedOrnament ornament){super(c);this.color=color;this.ornament=ornament;setClickable(false);}
        @Override protected void onAttachedToWindow(){super.onAttachedToWindow();if(android.os.Build.VERSION.SDK_INT<26||ValueAnimator.areAnimatorsEnabled()){light=ValueAnimator.ofFloat(0f,1f);light.setDuration(4200);light.setRepeatCount(ValueAnimator.INFINITE);light.addUpdateListener(a->{phase=(float)a.getAnimatedValue();ornament.phase=phase;ornament.invalidate();invalidate();});light.start();}}
        @Override protected void onDetachedFromWindow(){if(light!=null){light.cancel();light=null;}super.onDetachedFromWindow();}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);float unit=Math.max(1,getWidth()/160f);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(unit);p.setColor(color);p.setAlpha(180);c.drawCircle(cx,cy,radius,p);
            // Traveling light around the ring, without covering the profile photo.
            p.setColor(Color.WHITE);p.setAlpha(230);c.drawArc(cx-radius,cy-radius,cx+radius,cy+radius,phase*360,34,false,p);p.setStyle(Paint.Style.FILL);
            for(int i=0;i<12;i++){double angle=(phase+i/12f)*Math.PI*2;float x=cx+(float)Math.cos(angle)*(radius+getWidth()*.055f),y=cy+(float)Math.sin(angle)*(radius+getHeight()*.07f);p.setColor(i%2==0?Color.WHITE:color);p.setAlpha(80+(int)(170*Math.abs(Math.sin(angle*2))));float d=unit*(.6f+.55f*(float)Math.abs(Math.sin(angle)));Path star=new Path();star.moveTo(x,y-d*3);star.lineTo(x+d*.55f,y-d*.55f);star.lineTo(x+d*3,y);star.lineTo(x+d*.55f,y+d*.55f);star.lineTo(x,y+d*3);star.lineTo(x-d*.55f,y+d*.55f);star.lineTo(x-d*3,y);star.lineTo(x-d*.55f,y-d*.55f);star.close();c.drawPath(star,p);}
            // Tiny rising gems beside the crown; particles never drift over the face.
            for(int i=0;i<5;i++){float f=(phase+i*.2f)%1f,x=cx+(i-2)*getWidth()*.10f,y=Math.max(unit*3,cy-radius)-f*getHeight()*.12f;p.setColor(i%2==0?color:Color.WHITE);p.setAlpha((int)(170*(1-f)));float d=unit*1.5f;Path gem=new Path();gem.moveTo(x,y-d*2);gem.lineTo(x+d,y);gem.lineTo(x,y+d*2);gem.lineTo(x-d,y);gem.close();c.drawPath(gem,p);}
        }

    }
}
