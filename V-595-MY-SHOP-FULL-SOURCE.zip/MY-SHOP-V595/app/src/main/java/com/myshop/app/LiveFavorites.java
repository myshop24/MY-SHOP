package com.myshop.app;
import android.app.Activity;
import android.content.Intent;
import org.json.JSONObject;
import java.util.ArrayList;
public final class LiveFavorites {
 private LiveFavorites(){}
 public static void toggle(Activity a,String id,String name){android.content.SharedPreferences p=AccountPreferences.get(a,"favorite_live");if(p.contains(id)){p.edit().remove(id).apply();android.widget.Toast.makeText(a,"Removed from favourites",android.widget.Toast.LENGTH_SHORT).show();}else{p.edit().putString(id,name).apply();android.widget.Toast.makeText(a,"Added to favourites",android.widget.Toast.LENGTH_SHORT).show();}}
 public static void show(Activity a){android.content.SharedPreferences p=AccountPreferences.get(a,"favorite_live");ArrayList<String> ids=new ArrayList<>(p.getAll().keySet());java.util.Collections.sort(ids);if(ids.isEmpty()){android.widget.Toast.makeText(a,"Favourite a host from More inside their Live",android.widget.Toast.LENGTH_SHORT).show();return;}String[] names=new String[ids.size()];for(int i=0;i<ids.size();i++)names[i]=p.getString(ids.get(i),"Host")+" • "+ids.get(i);new MyShopCompatDialogBuilder(a).setTitle("Favourite Live hosts").setItems(names,(d,n)->{String id=ids.get(n);BackendClient.liveRoomState(SessionManager.getToken(a),id,new BackendClient.Callback(){public void onSuccess(JSONObject o){a.runOnUiThread(()->a.startActivity(new Intent(a,AudioLiveRoomActivity.class).putExtra("hostId",id)));}public void onError(String e){a.runOnUiThread(()->new MyShopCompatDialogBuilder(a).setTitle("Host is offline").setMessage("This favourite host is not Live now.").setPositiveButton("View profile",(dd,w)->a.startActivity(new Intent(a,UserProfileActivity.class).putExtra("userId",id))).setNeutralButton("Remove",(dd,w)->p.edit().remove(id).apply()).setNegativeButton("Close",null).show());}});}).setNegativeButton("Close",null).show();}
}
