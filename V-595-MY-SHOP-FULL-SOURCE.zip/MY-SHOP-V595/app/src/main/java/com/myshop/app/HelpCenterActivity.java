package com.myshop.app;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;

/** V-507: full Help Center shell with FAQ + real backend support tickets. */
public class HelpCenterActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(247,249,253),DARK=Color.rgb(24,34,72),MUTED=Color.rgb(105,112,132),BLUE=Color.rgb(45,114,246),RED=Color.rgb(221,45,58),GREEN=Color.rgb(21,151,94);
    private LinearLayout list, supportContacts; private TextView status;
    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(build());loadSupportContacts();loadTickets();}
    private View build(){
        LinearLayout root=col();root.setBackgroundColor(BG);root.setPadding(dp(10),dp(8),dp(10),dp(18));
        LinearLayout head=row();TextView back=button("‹",DARK,28);back.setOnClickListener(v->finish());head.addView(back,lp(dp(44),dp(46)));LinearLayout hb=col();hb.addView(txt("HELP CENTER",DARK,18,true),lp(-1,dp(25)));hb.addView(txt("FAQ • Support Ticket • Official Notice • Safety",MUTED,8.5f,false),lp(-1,dp(20)));head.addView(hb,weight(1,dp(46)));root.addView(head,lp(-1,dp(52)));
        TextView search=txt("🔍  Search Help",DARK,11,true);search.setGravity(Gravity.CENTER_VERTICAL);search.setBackground(round(Color.WHITE,Color.rgb(224,228,239),14));search.setPadding(dp(12),0,dp(12),0);root.addView(search,lp(-1,dp(46)));
        root.addView(section("💬 SUPPORT WHATSAPP",GREEN),top(lp(-1,dp(28)),10));
        supportContacts=col();root.addView(supportContacts,lp(-1,-2));
        root.addView(section("📚 FAQ",BLUE),top(lp(-1,dp(28)),10));
        String[][] faq={{"Login & Account","Login, password reset and account settings."},{"myshop / Order","Product, order and shopping help."},{"Live Streaming","Go Live, Live room and streaming problems."},{"Messages & Chat","Message, notification and conversation help."},{"Payment & Membership","Payment, membership and entitlement help."},{"Safety & Report","Report abuse, block users and safety support."}};
        for(String[] f:faq){LinearLayout c=card();c.addView(txt(f[0],DARK,11.5f,true),lp(-1,dp(25)));c.addView(txt(f[1],MUTED,9.5f,false),lp(-1,dp(30)));c.setOnClickListener(v->showFaq(f[0],f[1]));root.addView(c,top(lp(-1,-2),5));}
        root.addView(section("🎫 MY SUPPORT REQUESTS",BLUE),top(lp(-1,dp(28)),12));
        status=txt("Loading support requests…",MUTED,9,false);root.addView(status,lp(-1,dp(26)));list=col();root.addView(list,lp(-1,-2));
        TextView create=action("＋  CREATE SUPPORT REQUEST",RED);create.setOnClickListener(v->createTicket());root.addView(create,top(lp(-1,dp(46)),10));
        TextView official=action("🔴  myshop OFFICIAL NOTICE",RED);official.setOnClickListener(v->startActivity(new android.content.Intent(this,NotificationActivity.class)));root.addView(official,top(lp(-1,dp(44)),7));
        TextView safety=action("🚨  REPORT / SAFETY",Color.rgb(92,67,219));safety.setOnClickListener(v->createTicket("SAFETY"));root.addView(safety,top(lp(-1,dp(44)),7));
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(root);return sv;
    }
    private void loadSupportContacts(){
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->renderSupportContacts(d.optJSONArray("managedLinks")));}
            public void onError(String m){runOnUiThread(()->renderSupportContacts(null));}
        });
    }
    private void renderSupportContacts(JSONArray a){
        supportContacts.removeAllViews();JSONObject[] slots=new JSONObject[6];
        if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String cat=x.optString("category","");if(cat.startsWith("feature_support_slot_")){try{int n=Integer.parseInt(cat.substring("feature_support_slot_".length()));if(n>=1&&n<=6)slots[n-1]=x;}catch(Exception ignored){}}}
        LinearLayout row=null;
        for(int i=0;i<6;i++){final int slot=i+1;JSONObject x=slots[i];boolean active=x!=null&&x.optInt("active",1)==1;if(!active&&!SessionManager.isAdmin(this))continue;
            if(row==null){row=row();supportContacts.addView(row,top(lp(-1,dp(92)),4));}
            String name=x==null?"Support "+slot:x.optString("title","Support "+slot);String link=x==null?"":x.optString("url","");String image=x==null?"":x.optString("image_url",x.optString("imageUrl",""));
            LinearLayout c=col();c.setGravity(Gravity.CENTER);c.setPadding(dp(4),dp(5),dp(4),dp(5));c.setBackground(round(Color.WHITE,Color.rgb(224,230,240),12));
            ImageView photo=new ImageView(this);photo.setImageResource(R.drawable.myshop_profile_avatar);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);photo.setBackground(round(Color.rgb(241,245,255),Color.rgb(220,228,242),22));photo.setClipToOutline(true);if(!image.trim().isEmpty())loadSupportImage(photo,image.trim());c.addView(photo,lp(dp(42),dp(42)));TextView nm=txt(name,DARK,9.5f,true);nm.setGravity(Gravity.CENTER);nm.setMaxLines(2);c.addView(nm,lp(-1,dp(30)));
            c.setAlpha(active?1f:.5f);c.setOnClickListener(v->{if(SessionManager.isAdmin(this)){Intent q=new Intent(this,AdminSectionActivity.class);q.putExtra("section","feature_card");q.putExtra("managed_category","feature_support_slot_"+slot);q.putExtra("managed_title","SUPPORT "+slot);q.putExtra("admin_context",true);startActivity(q);return;}String target=whatsappTarget(link);if(!target.isEmpty()){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception ignored){Toast.makeText(this,"WhatsApp could not open",Toast.LENGTH_SHORT).show();}}else Toast.makeText(this,"Support contact is not configured yet",Toast.LENGTH_SHORT).show();});
            row.addView(c,weight(1,dp(86)));
            if(row.getChildCount()==3)row=null;
        }
        if(supportContacts.getChildCount()==0){TextView e=txt(SessionManager.isAdmin(this)?"Configure Support 1–6 from Admin":"Support contacts will appear here",MUTED,9,false);e.setGravity(Gravity.CENTER);supportContacts.addView(e,lp(-1,dp(44)));}
    }
    private String whatsappTarget(String raw){String v=raw==null?"":raw.trim();if(v.isEmpty())return "";if(FeatureRegistry.isSafeHttpUrl(v))return v;String digits=v.replaceAll("[^0-9]","");if(digits.length()>=7)return "https://wa.me/"+digits;return "";}
    private void loadSupportImage(ImageView v,String u){new android.os.AsyncTask<Void,Void,android.graphics.Bitmap>(){protected android.graphics.Bitmap doInBackground(Void...x){try{java.net.URL q=new java.net.URL(u);java.net.URLConnection c=q.openConnection();c.setConnectTimeout(5000);c.setReadTimeout(7000);return android.graphics.BitmapFactory.decodeStream(c.getInputStream());}catch(Exception e){return null;}}protected void onPostExecute(android.graphics.Bitmap b){if(b!=null&&!isFinishing())v.setImageBitmap(b);}}.execute();}
    private void loadTickets(){String t=SessionManager.getToken(this);if(t==null||t.isEmpty()){status.setText("Login required");return;}BackendClient.helpTickets(t,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->renderTickets(d.optJSONArray("tickets")));}public void onError(String m){runOnUiThread(()->status.setText("Unable to load support requests • retry later"));}});}
    private void renderTickets(JSONArray a){list.removeAllViews();int n=a==null?0:a.length();status.setText(n==0?"No support requests yet":n+" support request"+(n==1?"":"s"));if(n==0)return;for(int i=0;i<n;i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;long id=x.optLong("id");LinearLayout c=card();LinearLayout header=row();header.addView(txt("#"+id+"  "+x.optString("subject","Support"),DARK,11,true),weight(1,dp(28)));String st=x.optString("status","OPEN");header.addView(chip(st,"CLOSED".equals(st)?MUTED:GREEN),lp(dp(92),dp(26)));c.addView(header);c.addView(txt(x.optString("category","GENERAL")+"  •  "+x.optString("updated_at",x.optString("updatedAt","")),MUTED,8.5f,false),lp(-1,dp(24)));c.setOnClickListener(v->openTicket(id));list.addView(c,top(lp(-1,-2),5));}}
    private void createTicket(){createTicket("GENERAL");}
    private void createTicket(String preset){LinearLayout box=col();EditText cat=field("Category",preset);EditText subject=field("Subject");EditText message=field("Describe your problem");message.setMinLines(4);box.addView(cat);box.addView(subject);box.addView(message);CheckBox diagnostics=new CheckBox(this);diagnostics.setText("Attach app version & notification connection status");diagnostics.setChecked(false);box.addView(diagnostics);AlertDialog d=new MyShopDialogBuilder(this).setTitle("Create Support Request").setView(box).setNegativeButton(UiStrings.label(HelpCenterActivity.this,"Cancel"),null).setPositiveButton("Submit",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String c=cat.getText().toString().trim(),s=subject.getText().toString().trim(),m=message.getText().toString().trim();if(s.isEmpty()||m.isEmpty()){Toast.makeText(this,"Subject and message are required",Toast.LENGTH_SHORT).show();return;}v.setEnabled(false);String submitted=m+(diagnostics.isChecked()?"\n\n[User-approved diagnostics]\n"+SupportDiagnostics.summary(this):"");BackendClient.createHelpTicket(SessionManager.getToken(this),c,s,submitted,new BackendClient.Callback(){public void onSuccess(JSONObject o){d.dismiss();loadTickets();}public void onError(String e){v.setEnabled(true);Toast.makeText(HelpCenterActivity.this,e,Toast.LENGTH_LONG).show();}});}));d.show();}
    private void openTicket(long id){BackendClient.helpTicket(SessionManager.getToken(this),id,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->showThread(d));}public void onError(String m){Toast.makeText(HelpCenterActivity.this,m,Toast.LENGTH_SHORT).show();}});}
    private void showThread(JSONObject d){JSONObject t=d.optJSONObject("ticket");JSONArray a=d.optJSONArray("messages");StringBuilder sb=new StringBuilder();if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;sb.append("\n").append(x.optString("senderId").equals(SessionManager.getUserId(this))?"You":"myshop Support").append(": ").append(x.optString("message")).append("\n");}LinearLayout box=col();TextView thread=txt(sb.toString().trim(),DARK,10.5f,false);thread.setPadding(dp(8),dp(8),dp(8),dp(8));box.addView(thread,lp(-1,dp(260)));EditText reply=field("Reply…","");box.addView(reply);new MyShopDialogBuilder(this).setTitle("#"+t.optLong("id")+" • "+t.optString("subject")).setView(box).setNegativeButton(UiStrings.label(HelpCenterActivity.this,"Close"),null).setPositiveButton("Reply",(dlg,w)->{String m=reply.getText().toString().trim();if(!m.isEmpty())BackendClient.replyHelpTicket(SessionManager.getToken(this),t.optLong("id"),m,new BackendClient.Callback(){public void onSuccess(JSONObject o){loadTickets();}public void onError(String e){Toast.makeText(HelpCenterActivity.this,e,Toast.LENGTH_SHORT).show();}});}).show();}
    private void showFaq(String q,String a){new MyShopDialogBuilder(this).setTitle(q).setMessage(a+"\n\nIf this does not solve the problem, create a Support Request from Help Center.").setPositiveButton("OK",null).show();}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private TextView txt(String s,int c,float z,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}private TextView section(String s,int c){TextView t=txt(s,c,11,true);return t;}private EditText field(String h){return field(h,"");}private EditText field(String h,String v){EditText e=new EditText(this);e.setHint(h);e.setText(v);e.setTextColor(DARK);e.setTextSize(11);e.setPadding(dp(7),0,dp(7),0);return e;}private TextView button(String s,int c,float z){TextView t=txt(s,c,z,true);t.setGravity(Gravity.CENTER);t.setBackgroundColor(Color.TRANSPARENT);return t;}private TextView action(String s,int c){TextView t=txt(s,Color.WHITE,10.5f,true);t.setGravity(Gravity.CENTER);t.setBackground(round(c,c,12));return t;}private TextView chip(String s,int c){TextView t=txt(s,Color.WHITE,8.5f,true);t.setGravity(Gravity.CENTER);t.setBackground(round(c,c,10));return t;}private LinearLayout card(){LinearLayout c=col();c.setPadding(dp(10),dp(8),dp(10),dp(8));c.setBackground(round(Color.WHITE,Color.rgb(226,230,239),13));return c;}private GradientDrawable round(int fill,int stroke,int r){GradientDrawable g=new GradientDrawable();g.setColor(fill);if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);g.setCornerRadius(dp(r));return g;}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
