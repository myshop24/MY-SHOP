package com.myshop.app;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

/**
 * V-274 real myshop in-app presence.
 * A user is considered online only while the app process has a visible Activity.
 * Foreground heartbeat prevents stale "online" dots; background transition clears it immediately when possible.
 */
public class MyShopApplication extends Application implements Application.ActivityLifecycleCallbacks {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private int startedActivities=0;
    private boolean foreground=false;
    private boolean presenceInFlight=false;
    private boolean queuedPresence=false;
    private boolean queuedActive=false;
    private long lastPushSyncAt=0L;private long lastThemeSyncAt=0L;private boolean themeSyncing=false;
    private final java.util.WeakHashMap<Activity,String> appearances=new java.util.WeakHashMap<>();
    private final Runnable heartbeat=new Runnable(){
        @Override public void run(){
            if(!foreground)return;
            publish(true);syncThemes();
            // Keep server-side online TTL fresh without hammering the Worker every 30 seconds.
            // 15s heartbeat remains inside the 45s server presence window and removes the exact 30s regression trigger.
            handler.postDelayed(this,10000L);
        }
    };

    @Override public void onCreate(){
        super.onCreate();
        registerActivityLifecycleCallbacks(this);
        try{
            android.app.NotificationManager nm=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(nm!=null)MyShopMessagingService.ensureChannels(nm);
            if(PushRegistration.firebaseConfigured()&&com.google.firebase.FirebaseApp.getApps(this).isEmpty()){
                com.google.firebase.FirebaseOptions o=new com.google.firebase.FirebaseOptions.Builder().setApiKey(BuildConfig.FIREBASE_API_KEY).setApplicationId(BuildConfig.FIREBASE_APP_ID).setProjectId(BuildConfig.FIREBASE_PROJECT_ID).setGcmSenderId(BuildConfig.FIREBASE_SENDER_ID).build();com.google.firebase.FirebaseApp.initializeApp(this,o);
            }
            PushRegistration.sync(this);
        }catch(Exception ignored){}
    }

    private void publish(boolean active){
        final String owner=SessionManager.getUserId(this);String token=SessionManager.getToken(this);
        if(token==null||token.trim().isEmpty())return;
        // Never stack presence requests during Activity transitions or a slow network.
        // Queue only the newest state; this avoids request bursts and lifecycle races.
        if(presenceInFlight){queuedPresence=true;queuedActive=active;return;}
        presenceInFlight=true;
        android.content.SharedPreferences presencePrefs=getSharedPreferences("myshop_presence_v552",MODE_PRIVATE);String device=presencePrefs.getString("device","");if(device.isEmpty()){device=java.util.UUID.randomUUID().toString();presencePrefs.edit().putString("device",device).apply();}long sequence=presencePrefs.getLong("sequence",0)+1;presencePrefs.edit().putLong("sequence",sequence).apply();
        BackendClient.setAppPresence(token,active,device,sequence,new BackendClient.Callback(){
            private void done(){handler.post(()->{
                presenceInFlight=false;
                if(queuedPresence){boolean next=queuedActive;queuedPresence=false;publish(next);}
            });}
            public void onSuccess(org.json.JSONObject data){if(owner.equals(SessionManager.getUserId(MyShopApplication.this))&&data!=null&&data.has("visible"))AccountPreferences.get(MyShopApplication.this,"privacy").edit().putBoolean("presence_visible",data.optBoolean("visible",true)).apply();done();}
            public void onError(String message){done();}
        });
    }

    @Override public void onActivityStarted(Activity activity){
        startedActivities++;
        if(startedActivities==1){
            foreground=true;
            MyShopMessagingService.clearDisplayedPush(this);
            handler.removeCallbacks(heartbeat);
            publish(true);
            long now=System.currentTimeMillis();
            if(now-lastPushSyncAt>120000L){lastPushSyncAt=now;try{PushRegistration.sync(this);}catch(Exception ignored){}}
            handler.postDelayed(heartbeat,10000L);
        }
    }

    @Override public void onActivityStopped(Activity activity){
        startedActivities=Math.max(0,startedActivities-1);
        if(startedActivities==0 && !activity.isChangingConfigurations()){
            foreground=false;
            handler.removeCallbacks(heartbeat);
            publish(false);
        }
    }


    @Override public void onTrimMemory(int level){
        super.onTrimMemory(level);
        if(level>=TRIM_MEMORY_UI_HIDDEN){foreground=false;handler.removeCallbacks(heartbeat);publish(false);}
    }

    @Override public void onTerminate(){
        foreground=false;handler.removeCallbacks(heartbeat);publish(false);super.onTerminate();
    }

    private void syncThemes(){
        long now=System.currentTimeMillis();
        if(themeSyncing||now-lastThemeSyncAt<12000)return;
        themeSyncing=true;lastThemeSyncAt=now;
        BackendClient.appThemes(SessionManager.getToken(this),false,new BackendClient.Callback(){
            public void onSuccess(org.json.JSONObject d){
                String before=AppThemePalette.signature(MyShopApplication.this);
                AppThemePalette.cache(MyShopApplication.this,d.optJSONObject("theme"));
                String after=AppThemePalette.signature(MyShopApplication.this);
                handler.post(()->{
                    themeSyncing=false;boolean changed=!before.equals(after);
                    for(Activity a:new java.util.ArrayList<>(appearances.keySet())){
                        if(a==null||a.isDestroyed())continue;
                        if(changed&&!Appearance.live(a)&&!a.isFinishing()){
                            appearances.put(a,LanguageManager.get(a)+Appearance.dark(a)+after);a.recreate();
                        }else Appearance.apply(a);
                    }
                });
            }
            public void onError(String m){handler.post(()->themeSyncing=false);}
        });
    }
    @Override public void onActivityCreated(Activity activity, Bundle state){
        appearances.put(activity,LanguageManager.get(activity)+Appearance.dark(activity)+AppThemePalette.signature(activity));
        activity.getWindow().getDecorView().getViewTreeObserver().addOnGlobalLayoutListener(()->Appearance.apply(activity));
    }
    @Override public void onActivityResumed(Activity activity){syncThemes();String key=LanguageManager.get(activity)+Appearance.dark(activity)+AppThemePalette.signature(activity);String old=appearances.get(activity);if(old!=null&&!old.equals(key)&&!Appearance.live(activity)){appearances.put(activity,key);activity.recreate();return;}Appearance.apply(activity);}
    @Override public void onActivityPaused(Activity activity){}
    @Override public void onActivitySaveInstanceState(Activity activity, Bundle outState){}
    @Override public void onActivityDestroyed(Activity activity){}
}
