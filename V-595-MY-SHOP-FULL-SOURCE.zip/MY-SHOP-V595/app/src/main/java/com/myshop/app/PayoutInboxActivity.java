package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.*;
import org.json.*;

/** Payout review and receipts. Recording payment never sends money. */
public class PayoutInboxActivity extends androidx.appcompat.app.AppCompatActivity {
 private LinearLayout content;
 private TextView state;
 private boolean admin,loading;
 private String currency="COIN";
 private long next=0;
 private int generation=0;
 @Override protected void onCreate(Bundle b){
  super.onCreate(b);
  admin=getIntent().getBooleanExtra("admin",false);
  if(admin&&(!SessionManager.isAdmin(this)||!SessionManager.isAdminGateUnlocked())){finish();return;}
  currency="GOLD".equals(getIntent().getStringExtra("currency"))?"GOLD":"COIN";
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);
  root.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(dp(12)+i.getSystemWindowInsetLeft(),dp(12)+i.getSystemWindowInsetTop(),dp(12)+i.getSystemWindowInsetRight(),dp(12)+i.getSystemWindowInsetBottom());return i;});
  root.addView(label(admin?"ADMIN · Withdrawal Requests":"My Withdrawal Requests",20));
  LinearLayout controls=new LinearLayout(this);
  add(controls,"Back",()->finish());add(controls,"Coin",()->{currency="COIN";load(true);});add(controls,"Diamond",()->{currency="GOLD";load(true);});
  root.addView(controls);add(root,"Refresh / Retry",()->load(true));state=label("",14);root.addView(state);
  ScrollView scroll=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  add(root,"Load older requests",()->{if(next>0&&!loading)load(false);});
  setContentView(root);root.requestApplyInsets();load(true);
 }
 private void load(boolean reset){
  if(loading&&!reset)return;loading=true;final int seq=++generation;
  final String selected=currency;if(reset){next=0;content.removeAllViews();}state.setText("Loading "+selected+"…");
  BackendClient.payoutInbox(SessionManager.getToken(this),admin,selected,reset?0:next,new BackendClient.Callback(){
   public void onSuccess(JSONObject x){if(isFinishing()||seq!=generation)return;loading=false;next=x.optLong("nextCursor",0);
    state.setText(selected+" · Pending: "+x.optInt("pendingCount")+(admin?"":" · Available earned balance: "+x.optLong("availableEarnings"))+"\nRequest received does not mean paid.");
    JSONArray list=x.optJSONArray("requests");if(reset&&(list==null||list.length()==0))content.addView(label("No requests in this currency",16));
    if(list!=null)for(int j=0;j<list.length();j++){JSONObject r=list.optJSONObject(j);if(r==null)continue;
     String details="#"+r.optLong("id")+" · "+r.optString("status")+"\n";
     if(admin)details+=r.optString("full_name")+" · ID "+r.optString("user_id")+"\n";
     JSONObject terms=r.optJSONObject("terms");
     details+="Requested: "+(terms==null?r.optLong("gross_units"):terms.optLong("grossAmount",r.optLong("gross_units")))+" "+selected+"\nmyshop Commission: "+r.optLong("service_fee_units")+" · Total deducted / held: "+r.optLong("gross_units")+" · Units converted to cash: "+r.optLong("net_units")+"\nServer cash quote: ৳"+String.format(java.util.Locale.US,"%.2f",r.optLong("cash_minor")/100.0)+"\n"+r.optString("payment_method")+" · "+r.optString("account")+"\n"+r.optString("created_at")+" UTC\n"+r.optString("note");
     if(terms!=null){details+="\nProcessing: "+terms.optInt("processingDays")+" days";if(!terms.isNull("processingDeadline")&&!terms.optString("processingDeadline").isEmpty())details+="\nProcessing deadline: "+terms.optString("processingDeadline");}
     TextView card=label(details,14);card.setPadding(dp(8),dp(12),dp(8),dp(12));content.addView(card);
     if(admin){String status=r.optString("status");long requestId=r.optLong("id");LinearLayout actions=new LinearLayout(PayoutInboxActivity.this);
      if("PENDING".equals(status))add(actions,"Approve",()->decide(requestId,"APPROVE"));
      if("PENDING".equals(status)||"PROCESSING".equals(status))add(actions,"Reject",()->decide(requestId,"REJECT"));
      if("PROCESSING".equals(status))add(actions,"Record paid",()->decide(requestId,"PAID"));content.addView(actions);}

    }
   }
   public void onError(String m){if(isFinishing()||seq!=generation)return;loading=false;state.setText("Could not load requests. Tap Refresh / Retry.\n"+m);}
  });
 }
 private void decide(long id,String action){EditText note=new EditText(this);note.setHint("PAID".equals(action)?"Payment reference (required)":"Decision note");new androidx.appcompat.app.AlertDialog.Builder(this).setTitle(action+" #"+id).setMessage("PAID".equals(action)?"Record only after you have sent payment. This button does not send money.":"Confirm this request decision.").setView(note).setNegativeButton("Cancel",null).setPositiveButton("Confirm",(d,w)->{String n=note.getText().toString().trim();if("PAID".equals(action)&&n.isEmpty()){state.setText("Payment reference is required");return;}BackendClient.payoutAction(SessionManager.getToken(this),id,action,n,new BackendClient.Callback(){public void onSuccess(JSONObject x){load(true);}public void onError(String e){state.setText(e);load(true);}});}).show();}
 private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 private TextView label(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(0xff172347);return t;}
 private void add(LinearLayout box,String title,Runnable action){Button b=new Button(this);b.setText(title);b.setOnClickListener(v->action.run());box.addView(b);}
}
