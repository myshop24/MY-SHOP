package com.myshop.app;
import android.content.Context;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
/** Actual wallpaper plus a clearly marked room layout preview. Controls aren't part of the image. */
public final class WallpaperPreviewView extends FrameLayout {
 public WallpaperPreviewView(Context c,JSONObject item,boolean room){super(c);ImageView image=new ImageView(c);image.setScaleType(ImageView.ScaleType.CENTER_CROP);String url=item.optString("animation_url");if(url.isEmpty())url=item.optString("preview_url");if(!url.isEmpty())AnimatedAssetLoader.load(image,url,false);else image.setImageDrawable(new PremiumWallpaperDrawable(item.optString("code")));addView(image,new LayoutParams(-1,-1));if(room)addView(new RoomOverlay(c),new LayoutParams(-1,-1));}
 private static final class RoomOverlay extends View {
  private final Paint p=new Paint(3);RoomOverlay(Context c){super(c);setContentDescription("Live room wallpaper demo");}
  @Override protected void onDraw(Canvas c){float w=getWidth(),h=getHeight();p.setColor(0x74040B24);c.drawRect(0,0,w,h,p);p.setColor(0xB8141C35);c.drawRoundRect(w*.06f,h*.05f,w*.94f,h*.16f,12,12,p);p.setColor(Color.WHITE);p.setTextSize(w*.065f);c.drawText("Live Room · DEMO",w*.1f,h*.12f,p);for(int r=0;r<2;r++)for(int n=0;n<4;n++){float x=w*(.17f+n*.22f),y=h*(.30f+r*.17f);p.setColor(0x90293855);c.drawCircle(x,y,w*.065f,p);p.setColor(0xBFFFFFFF);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);c.drawCircle(x,y,w*.065f,p);p.setStyle(Paint.Style.FILL);}p.setColor(0xAC15203B);c.drawRoundRect(w*.05f,h*.69f,w*.9f,h*.76f,9,9,p);c.drawRoundRect(w*.05f,h*.79f,w*.95f,h*.88f,9,9,p);p.setColor(Color.WHITE);p.setTextSize(w*.043f);c.drawText("Comments & room controls",w*.09f,h*.845f,p);}
 }
}
