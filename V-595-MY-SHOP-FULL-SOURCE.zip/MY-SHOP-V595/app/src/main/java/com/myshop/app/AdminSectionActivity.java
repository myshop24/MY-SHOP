package com.myshop.app;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.OpenableColumns;
import java.io.InputStream;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;

/** V-227 focused admin detail board. One folder at a time; no giant all-in-one settings page. */
// workflow guard: SAVE / EDIT
public class AdminSectionActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(246,248,252), DARK=Color.rgb(22,28,55), PURPLE=Color.rgb(83,32,180), BLUE=Color.rgb(31,73,210), ORANGE=Color.rgb(238,132,15), GREEN=Color.rgb(17,139,88), RED=Color.rgb(210,45,55), MUTED=Color.rgb(100,106,122);
    private String section;
    private LinearLayout body;
    private EditText news,shopUrl,tvUrl,movieUrl,chatUrl,powerAdTitle,powerAdByline,dashBgColor,dashBlueColor,dashPurpleColor,dashPinkColor,newsBgColor,newsTextColor;
    private TextView newsSizeLabel,newsPreview;
    private float newsSizeSp=13.0f;
    private final EditText[] featureTitle=new EditText[8],featureUrl=new EditText[8],featureIcon=new EditText[8]; private final CheckBox[] featureActive=new CheckBox[8];
    private final EditText[] socialPlatform=new EditText[8],socialUrl=new EditText[8],socialCaption=new EditText[8],socialIcon=new EditText[8],socialImage=new EditText[8]; private final ImageView[] socialPreview=new ImageView[8];
    private final EditText[] itemTitle=new EditText[3],itemCaption=new EditText[3],itemUrl=new EditText[3],itemIcon=new EditText[3],itemImage=new EditText[3]; private final CheckBox[] itemActive=new CheckBox[3]; private final long[] itemId=new long[3];
    private String managedCategory="",managedDisplayTitle=""; private long singleId=0; private long featureRevision; private boolean featureSaving,featureReady; private String featureBaseline=""; private EditText singleSoonMessage; private EditText singleTitle,singleCaption,singleUrl,singleIcon,singleImage,singlePrice,singleOffer,singleOfferStart,singleOfferEnd,singleTimeLimit,singlePosition; private CheckBox singleActive,singleComingSoon;
    private static final int REQ_FEATURE_IMAGE=7711; private EditText pendingImageField; private ImageView pendingPreview; private String pendingAssetBox=""; private int pendingAssetSlot=1;
    private final EditText[] extTitle=new EditText[6],extCaption=new EditText[6],extUrl=new EditText[6],extIcon=new EditText[6],extImage=new EditText[6]; private final ImageView[] extPreview=new ImageView[6]; private final long[] extId=new long[6];
    private boolean socialSaving=false;
    private EditText officialTitle,officialMessage,officialImage,officialAction,officialExpiry,officialColor,officialSchedule;
    private EditText[] menuName,menuUrl,menuIcon; private CheckBox[] menuActive; private final EditText[] dynamicTitle=new EditText[4],dynamicCaption=new EditText[4],dynamicUrl=new EditText[4],dynamicIcon=new EditText[4],dynamicImage=new EditText[4]; private final CheckBox[] dynamicActive=new CheckBox[4]; private final long[] dynamicId=new long[4];
    private final String[] menuKeys={"menu_home","menu_shop","menu_gallery","menu_external","menu_go_live","menu_join_live","menu_earn","menu_live_tv","menu_live","menu_social","menu_chat","menu_music","menu_news","menu_more","menu_share","menu_support","menu_jobs","menu_coupon","menu_booking","menu_wallet","menu_settings","menu_language","menu_logout"};
    private final String[] menuNames={"HOME","myshop","GALLERY","EXTERNAL MOVIE","GO LIVE","JOIN LIVE","EARN & REWARD","LIVE TV","LIVE","SOCIAL MEDIA","CHAT","MUSIC","BREAKING NEWS","MORE APPS","SHARE APP","কাস্টমার সাপোর্ট","JOBS","COUPON","BOOKING","WALLET","SETTINGS","LANGUAGE","LOGOUT"};
    private final String[] featureKeys={"my_feed","live_now","go_live","live_tv","my_shop","external_movie","gallery","social_media"};
    private final String[] featureNames={"MY FEED","LIVE","GO LIVE","LIVE TV","myshop","EXTERNAL MOVIE","GALLERY","SOCIAL MEDIA"};

    @Override protected void onCreate(Bundle b){super.onCreate(b);section=getIntent().getStringExtra("section");if(section==null)section="dashboard";managedCategory=getIntent().getStringExtra("managed_category");if(managedCategory==null)managedCategory="";managedDisplayTitle=getIntent().getStringExtra("managed_title");if(managedDisplayTitle==null)managedDisplayTitle="";if(!SessionManager.isAdmin(this) || !getIntent().getBooleanExtra("admin_context",false)){finish();return;}if("moderators".equals(section)){startActivity(new Intent(this,AdminModeratorActivity.class));finish();return;}build();load();}

    private void build(){
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);LinearLayout root=col();root.setBackgroundColor(BG);root.setPadding(dp(12),dp(10),dp(12),dp(22));
        LinearLayout head=row();head.setGravity(Gravity.CENTER_VERTICAL);Button back=button("‹",DARK,28);back.setOnClickListener(v->onBackPressed());head.addView(back,lp(dp(42),dp(46)));LinearLayout hb=col();hb.addView(txt(title(),18,DARK,true),lp(-1,dp(25)));hb.addView(txt((LanguageManager.BN.equals(LanguageManager.get(this))?"শুধু Admin • ID ":"Admin only • ID ")+SessionManager.getUserId(this),9,MUTED,true),lp(-1,dp(18)));head.addView(hb,weight(1));TextView lang=action("🌐 "+(LanguageManager.BN.equals(LanguageManager.get(this))?"বাংলা":"EN"),BLUE,()->LanguageManager.showPicker(this,this::recreate));head.addView(lang,lp(dp(84),dp(38)));root.addView(head,lp(-1,dp(54)));
        LinearLayout flow=card();flow.setPadding(dp(11),dp(8),dp(11),dp(8));flow.addView(txt(LanguageManager.BN.equals(LanguageManager.get(this))?"সহজ ধাপ:  যোগ/বাছাই  →  সম্পাদনা  →  প্রিভিউ  →  সংরক্ষণ/প্রকাশ":"Simple flow: Add/select → Edit → Preview → Save/Publish",10,MUTED,true),lp(-1,dp(28)));root.addView(flow,lp(-1,-2));
        body=col();root.addView(body,lp(-1,-2));
        if("dashboard".equals(section))dashboardUi();else if("feature_card".equals(section))featureCardUi();else if("features".equals(section))featuresUi();else if("social".equals(section))socialUi();else if("more_apps".equals(section))moreAppsUi();else if("menu".equals(section))menuUi();else if("dynamic_content".equals(section))dynamicContentUi();else if("external_movie".equals(section))externalMovieUi();else if("moderators".equals(section))moderatorUi();else if("help_support".equals(section))helpSupportUi();else managedUi();
        TextView back2=action("←  এডমিন ফোল্ডার তালিকা",DARK,this::onBackPressed);root.addView(back2,lp(-1,dp(44)));sv.addView(root);setContentView(sv);
    }
    private String title(){if("feature_card".equals(section))return (managedDisplayTitle.isEmpty()?"FEATURE":managedDisplayTitle)+" অ্যাডমিন";if("dashboard".equals(section))return "ড্যাশবোর্ড / ব্রেকিং নিউজ";if("menu".equals(section))return "৩-লাইন মেনু ম্যানেজমেন্ট";if("features".equals(section))return "ফিচার ম্যানেজমেন্ট";if("social".equals(section))return "সোশ্যাল লিংক";if("moderators".equals(section))return "মডারেটর / এডমিন";if("help_support".equals(section))return "কাস্টমার সাপোর্ট";return section.replace('_',' ').toUpperCase();}

    private void dashboardUi(){
        addHeader("ব্রেকিং নিউজ • অ্যাডমিন নিয়ন্ত্রণ — ডান থেকে বামে অ্যানিমেশন অপরিবর্তিত থাকবে।");
        news=field("শিরোনামের লেখা");
        body.addView(news);if(AuthorityBadge.isAuthority(SessionManager.getUserId(this)))body.addView(action("রঙ দিন • হেডলাইনের শব্দ / গ্রেডিয়েন্ট",PURPLE,()->{TextView label=news;TextStyleEditor.open(this,"headline",TextAppearance.labels("element_headline",label));}),lp(-1,dp(48)));

        TextView sizeHeading=txt("ব্রেকিং নিউজ ফন্ট সাইজ",11,DARK,true); sizeHeading.setGravity(Gravity.CENTER_VERTICAL);
        body.addView(sizeHeading,lp(-1,dp(28)));

        // V-274: explicit, always-visible font-size controller. The previous generic action row
        // could occupy space without visibly rendering on some device/theme combinations.
        LinearLayout sizePanel=row(); sizePanel.setGravity(Gravity.CENTER_VERTICAL); sizePanel.setPadding(dp(5),dp(4),dp(5),dp(4));
        sizePanel.setBackground(round(Color.rgb(241,244,250),Color.rgb(218,223,235),12));
        TextView minus=fontSizeButton("−",PURPLE,()->changeNewsSize(-1.0f));
        newsSizeLabel=txt("১৩ px",14,DARK,true); newsSizeLabel.setGravity(Gravity.CENTER); newsSizeLabel.setSingleLine(true);
        newsSizeLabel.setBackground(round(Color.WHITE,Color.rgb(206,212,228),10));
        newsSizeLabel.setContentDescription("বর্তমান ব্রেকিং নিউজ ফন্ট সাইজ");
        TextView plus=fontSizeButton("+",BLUE,()->changeNewsSize(1.0f));
        sizePanel.addView(minus,new LinearLayout.LayoutParams(0,dp(44),1.2f));
        sizePanel.addView(gap(7),lp(dp(7),1));
        sizePanel.addView(newsSizeLabel,new LinearLayout.LayoutParams(0,dp(44),.9f));
        sizePanel.addView(gap(7),lp(dp(7),1));
        sizePanel.addView(plus,new LinearLayout.LayoutParams(0,dp(44),1.2f));
        LinearLayout.LayoutParams sizePanelLp=lp(-1,dp(54)); sizePanelLp.setMargins(0,dp(2),0,dp(8));
        body.addView(sizePanel,sizePanelLp);

        addHeader("ব্রেকিং নিউজের নিজস্ব ব্যাকগ্রাউন্ড ও লেখার রং — নিচের ড্যাশবোর্ড থিমের রং থেকে আলাদা।");
        newsBgColor=field("ব্রেকিং নিউজ ব্যাকগ্রাউন্ড HEX  #FFEFF7");
        body.addView(newsBgColor);
        body.addView(action("🎨  ব্রেকিং নিউজ ব্যাকগ্রাউন্ড রং বাছুন",PURPLE,()->showColorPicker(newsBgColor,"ব্রেকিং নিউজ ব্যাকগ্রাউন্ড রং")),lp(-1,dp(44)));
        newsTextColor=field("ব্রেকিং নিউজ লেখার HEX  #414662");
        body.addView(newsTextColor);
        body.addView(action("🎨  ব্রেকিং নিউজ লেখার রং বাছুন",BLUE,()->showColorPicker(newsTextColor,"ব্রেকিং নিউজ লেখার রং")),lp(-1,dp(44)));

        newsPreview=txt("📣 শিরোনাম প্রিভিউ",13,DARK,true); newsPreview.setGravity(Gravity.CENTER_VERTICAL); newsPreview.setPadding(dp(12),0,dp(12),0);
        body.addView(newsPreview,lp(-1,dp(52)));
        body.addView(action("◉  লাইভ প্রিভিউ দেখুন",BLUE,()->applyHeadlinePreview()),lp(-1,dp(44)));

        LinearLayout headlineActions=row();
        headlineActions.addView(action("✎  সম্পাদনা / সংরক্ষণ",GREEN,()->saveDashboard()),wt(1));
        headlineActions.addView(gap(6));
        headlineActions.addView(action("⌫  মুছুন",RED,()->deleteHeadline()),wt(1));
        body.addView(headlineActions,lp(-1,dp(46)));

        addHeader("ব্রেকিং নিউজের সাইজ/রং সার্ভারে সংরক্ষণ হবে; APK আপডেট লাগবে না। ড্যাশবোর্ড সেটিংস নিচে আলাদা আছে।");
        shopUrl=field("myshop লিংক URL");tvUrl=field("লাইভ টিভি URL");movieUrl=field("এক্সটার্নাল মুভি URL");chatUrl=field("চ্যাট URL");powerAdTitle=field("পাওয়ার বিজ্ঞাপনের শিরোনাম");powerAdByline=field("পাওয়ার বিজ্ঞাপনের ছোট পরিচিতি");
        body.addView(shopUrl);body.addView(tvUrl);body.addView(movieUrl);body.addView(chatUrl);body.addView(powerAdTitle);body.addView(powerAdByline);
        addHeader("ড্যাশবোর্ড থিমের রং — সংরক্ষণ করলে মূল ড্যাশবোর্ড সার্ভার থেকে সর্বশেষ রং নিয়ে প্রয়োগ করবে।");
        dashBgColor=field("ড্যাশবোর্ড ব্যাকগ্রাউন্ড HEX  #07122F");dashBlueColor=field("প্রধান নীল HEX  #2D72F6");dashPurpleColor=field("বেগুনি HEX  #7B3FF2");dashPinkColor=field("গোলাপি/ম্যাজেন্টা HEX  #F02BB7");
        body.addView(dashBgColor); body.addView(action("🎨 ড্যাশবোর্ড ব্যাকগ্রাউন্ডের রং বাছুন",PURPLE,()->showColorPicker(dashBgColor,"ড্যাশবোর্ড ব্যাকগ্রাউন্ডের রং")),lp(-1,dp(42)));
        body.addView(dashBlueColor); body.addView(action("🎨 প্রধান নীল রং বাছুন",BLUE,()->showColorPicker(dashBlueColor,"ড্যাশবোর্ডের প্রধান নীল")),lp(-1,dp(42)));
        body.addView(dashPurpleColor); body.addView(action("🎨 বেগুনি রং বাছুন",PURPLE,()->showColorPicker(dashPurpleColor,"ড্যাশবোর্ডের বেগুনি")),lp(-1,dp(42)));
        body.addView(dashPinkColor); body.addView(action("🎨 গোলাপি / ম্যাজেন্টা বাছুন",RED,()->showColorPicker(dashPinkColor,"ড্যাশবোর্ডের গোলাপি / ম্যাজেন্টা")),lp(-1,dp(42)));
        for(EditText colorField:new EditText[]{newsBgColor,newsTextColor,dashBgColor,dashBlueColor,dashPurpleColor,dashPinkColor}){colorField.setShowSoftInputOnFocus(false);colorField.setOnClickListener(v->showColorPicker(colorField,"রং বাছুন"));}
        body.addView(action("✓ সব ড্যাশবোর্ড সেটিংস সংরক্ষণ করুন",GREEN,()->saveDashboard()),lp(-1,dp(52)));
    }

    private void changeNewsSize(float delta){
        newsSizeSp=Math.max(10.0f,Math.min(24.0f,newsSizeSp+delta));
        if(newsSizeLabel!=null)newsSizeLabel.setText(String.format(java.util.Locale.US,"%.0f px",newsSizeSp));
        applyHeadlinePreview();
    }

    private void applyHeadlinePreview(){
        if(newsPreview==null)return;
        String bg=newsBgColor==null?"#FFEFF7":newsBgColor.getText().toString().trim();
        String fg=newsTextColor==null?"#414662":newsTextColor.getText().toString().trim();
        if(!ThemeConfig.valid(bg)||!ThemeConfig.valid(fg)){toast("রং অবশ্যই #FFEFF7-এর মতো HEX হতে হবে");return;}
        newsPreview.setText("📣  "+(news==null||news.getText().toString().trim().isEmpty()?"শিরোনাম প্রিভিউ":news.getText().toString().trim()));
        newsPreview.setTextSize(newsSizeSp); newsPreview.setTextColor(Color.parseColor(fg)); newsPreview.setBackground(round(Color.parseColor(bg),Color.argb(55,Color.red(Color.parseColor(fg)),Color.green(Color.parseColor(fg)),Color.blue(Color.parseColor(fg))),14));
    }


    private void showColorPicker(EditText target,String title){
        int initial=Color.WHITE;
        try{String raw=target.getText().toString().trim();if(ThemeConfig.valid(raw))initial=Color.parseColor(raw);}catch(Exception ignored){}
        ColorPicker.show(this,initial,chosen->{target.setText(String.format(java.util.Locale.US,"#%06X",chosen&0xffffff));applyHeadlinePreview();});
    }
    private int bestContrast(int color){double y=(299*Color.red(color)+587*Color.green(color)+114*Color.blue(color))/1000.0;return y>=145?Color.rgb(25,29,45):Color.WHITE;}

    private void deleteHeadline(){
        new MyShopDialogBuilder(this).setTitle("শিরোনাম মুছবেন?").setMessage("শিরোনামের লেখা মুছে যাবে। অ্যানিমেটেড 📣 আইকন থাকবে।")
            .setNegativeButton("CANCEL",null)
            .setPositiveButton("DELETE",(d,w)->{news.setText("");saveDashboard();}).show();
    }

    private void externalMovieUi(){
        addHeader("সর্বোচ্চ ৬টি এক্সটার্নাল মুভি/লিংক। নাম + ওয়েবসাইট URL দিলেই সংরক্ষণ হবে; ক্যাপশন, আইকন ও ছবি ঐচ্ছিক। প্রতিটি বক্সের নিচে নিজস্ব যোগ / সম্পাদনা / সংরক্ষণ / মুছুন আছে।");
        for(int i=0;i<6;i++){final int x=i;LinearLayout c=card();c.addView(txt("EXTERNAL MOVIE  "+(i+1),13,DARK,true),lp(-1,dp(25)));extTitle[i]=field("নাম / শিরোনাম");extCaption[i]=field("ক্যাপশন (ঐচ্ছিক)");extUrl[i]=field("Website URL (https://...)");extIcon[i]=field("আইকন URL (ঐচ্ছিক)");extImage[i]=field("ছবির URL / কাস্টম আপলোড (ঐচ্ছিক)");extPreview[i]=preview();c.addView(extTitle[i]);c.addView(extCaption[i]);c.addView(extUrl[i]);c.addView(extIcon[i]);c.addView(extImage[i]);c.addView(extPreview[i],lp(-1,dp(92)));c.addView(action("🖼 গ্যালারি / ফাইল → প্রিভিউ",BLUE,()->pickFeatureImage(extImage[x],"external_movie_icon",x+1,extPreview[x])),lp(-1,dp(40)));c.addView(actionRow4(()->prepareExternalItem(x),()->editFields(extTitle[x],extCaption[x],extUrl[x],extIcon[x],extImage[x]),()->saveExternalItem(x),()->deleteExternalItem(x)),lp(-1,dp(42)));body.addView(c,lp(-1,-2));}
        body.addView(action("↻ পুনরায় লোড",BLUE,()->load()),lp(-1,dp(44)));
    }
    private void prepareExternalItem(int i){extId[i]=0;extTitle[i].setText("");extCaption[i].setText("");extUrl[i].setText("");extIcon[i].setText("");extImage[i].setText("");editFields(extTitle[i],extCaption[i],extUrl[i],extIcon[i],extImage[i]);toast("নতুন এক্সটার্নাল মুভি স্লট প্রস্তুত");}

    private void featuresUi(){
        body.addView(action("MASTER FEATURE CONTROLS • Search / Coming Soon / Delete / History",PURPLE,()->startActivity(new Intent(this,MasterFeatureAdminActivity.class))),lp(-1,dp(52)));
        addHeader("একটি ফিচার খুলে নাম, আইকন URL, লিংক এবং দেখান/লুকান নিয়ন্ত্রণ করুন।");
        for(int i=0;i<8;i++){final int x=i;LinearLayout c=card();c.addView(txt(featureNames[i],13,DARK,true),lp(-1,dp(25)));featureTitle[i]=field("দেখানোর শিরোনাম / ক্যাপশন (ঐচ্ছিক)");featureUrl[i]=field("গন্তব্য URL");featureIcon[i]=field("আইকন URL (ঐচ্ছিক)");featureActive[i]=new CheckBox(this);featureActive[i].setText("ড্যাশবোর্ডে দেখাবে");featureActive[i].setTextSize(11);featureActive[i].setChecked(true);c.addView(featureTitle[i]);c.addView(featureUrl[i]);c.addView(featureIcon[i]);c.addView(featureActive[i],lp(-1,dp(36)));c.addView(actionRow4(()->prepareFeatureSlot(x),()->editFields(featureTitle[x],featureUrl[x],featureIcon[x]),()->saveFeature(x),()->deleteFeature(x)),lp(-1,dp(42)));body.addView(c,lp(-1,-2));}
        body.addView(action("➕ নতুন ফিচার যোগ করুন",PURPLE,()->addNewFeature()),lp(-1,dp(44)));
    }

    private void prepareFeatureSlot(int i){featureTitle[i].setText(featureNames[i]);featureUrl[i].setText("");featureIcon[i].setText("");featureActive[i].setChecked(true);editFields(featureTitle[i],featureUrl[i],featureIcon[i]);toast("ফিচার স্লট প্রস্তুত");}

    private void moreAppsUi(){
        addHeader("MORE-এ Facebook, Page, YouTube, WhatsApp, imo, Instagram, Telegram-এর লোগোসহ বাটনের লিংক এখানে বসান। লিংক বসিয়ে সংরক্ষণ / সম্পাদনা চাপুন।");
        String[] names={"Facebook","Page","YouTube","WhatsApp","imo","Instagram","Telegram","TikTok"};
        for(int i=0;i<8;i++ ){final int x=i;LinearLayout c=card();c.addView(txt(names[i],13,DARK,true),lp(-1,dp(25)));socialPlatform[i]=field("প্ল্যাটফর্ম / নাম");socialPlatform[i].setText(names[i]);socialUrl[i]=field("লিংক / URL");socialCaption[i]=field("ক্যাপশন / শিরোনাম (ঐচ্ছিক)");socialIcon[i]=field("আইকন URL (ঐচ্ছিক)");socialImage[i]=field("কাস্টম আইকন/ছবির URL (আপলোড ঐচ্ছিক)");socialPreview[i]=preview();c.addView(socialPlatform[i]);c.addView(socialUrl[i]);c.addView(socialCaption[i]);c.addView(socialIcon[i]);c.addView(socialImage[i]);c.addView(socialPreview[i],lp(-1,dp(82)));c.addView(action("🖼 কাস্টম আইকন আপলোড",BLUE,()->pickFeatureImage(socialImage[x],"social_icon",x+1,socialPreview[x])),lp(-1,dp(40)));c.addView(actionRow4(()->prepareMoreApp(x,names[x]),()->editFields(socialPlatform[x],socialUrl[x],socialCaption[x],socialIcon[x],socialImage[x]),()->saveSocial(x),()->deleteSocial(x)),lp(-1,dp(44)));body.addView(c,lp(-1,-2));}
        body.addView(action("✓ সব সোশ্যাল লিংক সংরক্ষণ",GREEN,this::saveAllSocialLinks),lp(-1,dp(46)));
        addHeader("কাস্টমার সাপোর্টের আলাদা যোগ / সম্পাদনা / সংরক্ষণ / মুছুন + ছবি নিয়ন্ত্রণ আছে।");
        body.addView(action("কাস্টমার সাপোর্ট অ্যাডমিন",PURPLE,()->startActivity(new android.content.Intent(this,AdminSectionActivity.class).putExtra("section","help_support").putExtra("admin_context",true))),lp(-1,dp(44)));
    }

    private void prepareMoreApp(int i,String name){socialPlatform[i].setText(name);socialUrl[i].setText("");socialCaption[i].setText("");if(socialIcon[i]!=null)socialIcon[i].setText("");if(socialImage[i]!=null)socialImage[i].setText("");if(socialPreview[i]!=null)socialPreview[i].setImageDrawable(null);editFields(socialPlatform[i],socialUrl[i],socialCaption[i],socialIcon[i],socialImage[i]);toast(name+" ready");}

    private void socialUi(){
        addHeader("প্রতি ঘরে একটি করে Social platform। ভুল হলে Delete করে Save করুন।");
        for(int i=0;i<8;i++){final int x=i;LinearLayout c=card();c.addView(txt("SOCIAL LINK  "+(i+1),13,DARK,true),lp(-1,dp(25)));socialPlatform[i]=field("Platform name (Facebook / YouTube / TikTok...)");socialUrl[i]=field("Social URL");socialCaption[i]=field("ক্যাপশন / শিরোনাম (ঐচ্ছিক)");socialIcon[i]=field("আইকন URL (ঐচ্ছিক)");socialImage[i]=field("কাস্টম আইকন/ছবির URL (আপলোড ঐচ্ছিক)");socialPreview[i]=preview();c.addView(socialPlatform[i]);c.addView(socialUrl[i]);c.addView(socialCaption[i]);c.addView(socialIcon[i]);c.addView(socialImage[i]);c.addView(socialPreview[i],lp(-1,dp(82)));c.addView(action("🖼 কাস্টম আইকন আপলোড",BLUE,()->pickFeatureImage(socialImage[x],"social_icon",x+1,socialPreview[x])),lp(-1,dp(40)));c.addView(actionRow4(()->prepareSocial(x),()->editFields(socialPlatform[x],socialUrl[x],socialCaption[x],socialIcon[x],socialImage[x]),()->saveSocial(x),()->deleteSocial(x)),lp(-1,dp(42)));body.addView(c,lp(-1,-2));}
    }

    private void prepareSocial(int i){socialPlatform[i].setText("");socialUrl[i].setText("");socialCaption[i].setText("");if(socialIcon[i]!=null)socialIcon[i].setText("");if(socialImage[i]!=null)socialImage[i].setText("");if(socialPreview[i]!=null)socialPreview[i].setImageDrawable(null);editFields(socialPlatform[i],socialUrl[i],socialCaption[i],socialIcon[i],socialImage[i]);toast("New social link ready");}

    private void helpSupportUi(){
        addHeader("HELP CENTER ADMIN • Support configuration + myshop Official Message. Official messages are permanently identified in RED on the User Side.");
        body.addView(action("OPEN USER HELP CENTER",RED,()->startActivity(new Intent(this,HelpCenterActivity.class))),lp(-1,dp(44)));
        addHeader("🔴 myshop OFFICIAL MESSAGE");
        officialTitle=field("Official title");officialMessage=field("Official message");officialMessage.setMinLines(5);officialImage=field("Image URL (optional)");officialAction=field("Action URL https:// (optional)");officialExpiry=field("Expiry datetime (optional)");officialSchedule=field("Schedule datetime (optional)");officialColor=field("Message card color (managed by Color Picker)");officialColor.setText("#FFF8F9");
        body.addView(officialTitle);body.addView(officialMessage);body.addView(officialImage);body.addView(officialAction);body.addView(officialExpiry);body.addView(officialSchedule);body.addView(officialColor);
        body.addView(action("🎨 CHOOSE MESSAGE CARD COLOR",PURPLE,()->showColorPicker(officialColor,"myshop Official message card color")),lp(-1,dp(44)));
        body.addView(action("🔴 SEND NOW / SCHEDULE OFFICIAL MESSAGE",RED,()->sendOfficialNotice()),lp(-1,dp(46)));
        body.addView(action("REFRESH OFFICIAL NOTICE HISTORY",BLUE,()->loadOfficialNotices()),lp(-1,dp(42)));
        addHeader("🎫 SUPPORT TICKETS • Admin queue");
        body.addView(action("OPEN SUPPORT TICKET QUEUE",PURPLE,()->showAdminTickets()),lp(-1,dp(44)));
        addHeader("Support WhatsApp • 6 photo folders");
        for(int i=0;i<6;i++){final int slot=i+1;body.addView(action("OPEN SUPPORT "+slot+" • Photo / Name / WhatsApp",GREEN,()->{Intent z=new Intent(this,AdminSectionActivity.class);z.putExtra("section","feature_card");z.putExtra("managed_category","feature_support_slot_"+slot);z.putExtra("managed_title","SUPPORT "+slot);z.putExtra("admin_context",true);startActivity(z);}),lp(-1,dp(44)));body.addView(gap(5),lp(1,dp(5)));}
        addHeader("Legacy Support Links / Help Center configuration");
        for(int i=0;i<3;i++){final int x=i;LinearLayout c=card();c.addView(txt("SUPPORT "+(i+1),13,DARK,true),lp(-1,dp(25)));itemTitle[i]=field("Name / title (optional)");itemCaption[i]=field("Caption / description (optional)");itemUrl[i]=field("Link / URL / value (optional)");itemIcon[i]=field("আইকন URL (ঐচ্ছিক)");itemImage[i]=field("Image URL (optional)");itemActive[i]=new CheckBox(this);itemActive[i].setText("Active / frontend-এ দেখাবে");itemActive[i].setChecked(true);c.addView(itemTitle[i]);c.addView(itemCaption[i]);c.addView(itemUrl[i]);c.addView(itemIcon[i]);c.addView(itemImage[i]);c.addView(itemActive[i],lp(-1,dp(36)));c.addView(actionRow4(()->prepareManagedSlot(x),()->editFields(itemTitle[x],itemCaption[x],itemUrl[x],itemIcon[x],itemImage[x]),()->saveManaged(x),()->deleteManaged(x)),lp(-1,dp(42)));body.addView(c,lp(-1,-2));}
    }
    private void sendOfficialNotice(){String title=officialTitle.getText().toString().trim(),msg=officialMessage.getText().toString().trim(),color=officialColor.getText().toString().trim(),schedule=officialSchedule.getText().toString().trim();if(msg.isEmpty()){toast("Official message is required");return;}if(!ThemeConfig.valid(color)){toast("Color Picker দিয়ে message card color ঠিক করুন");return;}BackendClient.adminOfficialNotice(SessionManager.getToken(this),title,msg,officialImage.getText().toString().trim(),officialAction.getText().toString().trim(),officialExpiry.getText().toString().trim(),color,schedule,result(schedule.isEmpty()?"🔴 myshop Official message sent":"🔴 myshop Official message scheduled"));}
    private void loadOfficialNotices(){BackendClient.adminOfficialNotices(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("notices");new MyShopDialogBuilder(AdminSectionActivity.this).setTitle("myshop Official History").setMessage(a==null||a.length()==0?"No official notices yet":a.length()+" official notice(s) stored in backend.").setPositiveButton("OK",null).show();});}public void onError(String m){toast(m);}});}
    private void showAdminTickets(){BackendClient.adminHelpTickets(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("tickets");if(a==null||a.length()==0){new MyShopDialogBuilder(AdminSectionActivity.this).setTitle("Support Tickets").setMessage("No tickets yet.").setPositiveButton("OK",null).show();return;}StringBuilder b=new StringBuilder();for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;b.append("#").append(x.optLong("id")).append(" • ").append(x.optString("status")).append(" • ").append(x.optString("subject")).append("\n");}new MyShopDialogBuilder(AdminSectionActivity.this).setTitle("Support Ticket Queue").setMessage(b.toString()).setPositiveButton("OK",null).show();});}public void onError(String m){toast(m);}});}
    private void managedUi(){
        addHeader("help_support".equals(section)?"Customer Support: সব ঘর optional। শুধু Link, শুধু Image, শুধু Name — যেটা চান সেটাই দিয়ে SAVE করতে পারবেন।":"সব ঘর optional। যে তথ্য দিতে চান সেটাই দিয়ে SAVE করুন।");
        for(int i=0;i<3;i++){final int x=i;LinearLayout c=card();c.addView(txt(("help_support".equals(section)?"SUPPORT ":"ITEM ")+(i+1),13,DARK,true),lp(-1,dp(25)));itemTitle[i]=field("Name / title (optional)");itemCaption[i]=field("Caption / description (optional)");itemUrl[i]=field("Link / URL / value (optional)");itemIcon[i]=field("আইকন URL (ঐচ্ছিক)");itemImage[i]=field("Image URL (optional)");itemActive[i]=new CheckBox(this);itemActive[i].setText("Active / frontend-এ দেখাবে");itemActive[i].setTextSize(11);itemActive[i].setChecked(true);c.addView(itemTitle[i]);c.addView(itemCaption[i]);c.addView(itemUrl[i]);c.addView(itemIcon[i]);c.addView(itemImage[i]);c.addView(action("CHOOSE / UPLOAD IMAGE (OPTIONAL)",BLUE,()->pickFeatureImage(itemImage[x],"feature_asset_"+section,x+1)),lp(-1,dp(40)));c.addView(itemActive[i],lp(-1,dp(36)));c.addView(actionRow4(()->prepareManagedSlot(x),()->editFields(itemTitle[x],itemCaption[x],itemUrl[x],itemIcon[x],itemImage[x]),()->saveManaged(x),()->deleteManaged(x)),lp(-1,dp(42)));body.addView(c,lp(-1,-2));}
    }
    private void prepareManagedSlot(int i){itemId[i]=0;itemTitle[i].setText("");itemCaption[i].setText("");itemUrl[i].setText("");itemIcon[i].setText("");itemImage[i].setText("");itemActive[i].setChecked(true);toast("New item ready — fill fields and press SAVE / EDIT");}

    private int draftRevision=-1;
    private JSONObject loadedReviewDraft;
    private boolean separateDraft(){return managedCategory.matches("feature_[a-z0-9_]{1,80}")&&!managedCategory.matches(".*(?:^|_)(?:live|rtc|audio|gift|gifts|room)(?:_|$).*")&&!"feature_go_live".equals(managedCategory)&&!"feature_top_gifters".equals(managedCategory);}
    private void loadDraftRevision(){BackendClient.featureDraft(SessionManager.getToken(this),managedCategory,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->draftRevision=d.optInt("revision"));}public void onError(String m){runOnUiThread(()->toast("Draft unavailable: "+m));}});}
    private void reviewSavedFeatureDraft(){
        if(featureSaving||!featureReady||!separateDraft()||!AuthorityBadge.isAuthority(SessionManager.getUserId(this)))return;
        featureSaving=true;toast("Saved Draft লোড হচ্ছে…");
        BackendClient.featureDraft(SessionManager.getToken(this),managedCategory,new BackendClient.Callback(){
            public void onSuccess(JSONObject result){runOnUiThread(()->{
                featureSaving=false;if(isFinishing()||isDestroyed())return;
                JSONObject draft=result.optJSONObject("draft");int revision=result.optInt("revision");
                if(draft==null||!managedCategory.equals(draft.optString("category"))){toast("No saved Draft for this folder");return;}
                new MyShopDialogBuilder(AdminSectionActivity.this).setTitle("Load saved Draft for review?")
                    .setMessage("Revision: "+revision+"\nName: "+draft.optString("title")+"\nThis replaces the editor's unsaved fields. Public content stays unchanged.")
                    .setNegativeButton("Cancel",null).setPositiveButton("Load Draft",(dialog,which)->{
                        if(featureSaving||!featureReady)return;
                        try{loadedReviewDraft=new JSONObject(draft.toString());draftRevision=revision;
                            singleTitle.setText(draft.optString("title",managedDisplayTitle));singleCaption.setText(draft.optString("caption"));singleUrl.setText(draft.optString("url"));
                            singleIcon.setText(draft.optString("iconUrl"));singleImage.setText(draft.optString("imageUrl"));singleSoonMessage.setText(draft.optString("comingSoonMessage"));
                            singlePrice.setText(String.valueOf(draft.optLong("priceMinor")));singleOffer.setText(draft.optString("offerText"));singleOfferStart.setText(draft.optString("offerStart"));singleOfferEnd.setText(draft.optString("offerEnd"));
                            singleTimeLimit.setText(String.valueOf(draft.optLong("timeLimitMinutes")));singlePosition.setText(String.valueOf(draft.optInt("displayOrder",1)));
                            singleActive.setChecked(draft.optBoolean("active",true));singleComingSoon.setChecked("COMING_SOON".equals(draft.optString("status")));
                            toast("Saved Draft loaded • Preview before Publish");
                        }catch(Exception e){toast("Draft could not be loaded");}
                    }).show();
            });}
            public void onError(String message){runOnUiThread(()->{featureSaving=false;if(!isFinishing()&&!isDestroyed())toast("Draft not loaded: "+message);});}
        });
    }
    private void featureCardUi(){
        if(managedCategory.isEmpty()){addHeader("Feature category missing.");return;}
        addHeader("Save → Preview → Publish: সাধারণ Save-এর পরে প্রকাশ নিশ্চিত করুন। Save Private Draft শুধু ব্যক্তিগত খসড়া রাখে।");
        LinearLayout c=card();
        singleTitle=field("Name / title");singleCaption=field("Caption / description");singleUrl=field("Link / URL");singleIcon=field("আইকন ছবির লিংক অথবা emoji:🌟");singleImage=field("Image URL (ঐচ্ছিক)");
        singlePrice=field("Price (minor unit; 0 = no price)");singleOffer=field("Offer / discount text");singleOfferStart=field("Offer start date/time");singleOfferEnd=field("Offer end / expiry date/time");singleTimeLimit=field("Time limit in minutes; 0 = unlimited");singlePosition=field("Position / order (1 = first)");
        c.addView(singleTitle);c.addView(singleCaption);c.addView(singleUrl);c.addView(singleIcon);c.addView(singleImage);
        c.addView(action("🖼 GALLERY / FILE → SELECT FEATURE IMAGE",BLUE,()->pickFeatureImage(singleImage,"feature_asset_"+managedCategory,1)),lp(-1,dp(40)));
        c.addView(singlePrice);c.addView(singleOffer);c.addView(singleOfferStart);c.addView(singleOfferEnd);c.addView(singleTimeLimit);c.addView(singlePosition);singleSoonMessage=field("Coming Soon message");c.addView(singleSoonMessage);
        LinearLayout flags=row();flags.setGravity(Gravity.CENTER_VERTICAL);
        singleActive=new CheckBox(this);singleActive.setText("Enable / Active");singleActive.setChecked(true);singleActive.setTextSize(10.5f);flags.addView(singleActive,weight(1));
        singleComingSoon=new CheckBox(this);singleComingSoon.setText("Coming Soon / Upcoming");singleComingSoon.setTextSize(10.5f);flags.addView(singleComingSoon,weight(1));c.addView(flags,lp(-1,dp(44)));
        c.addView(txt("Position / reorder uses the feature's saved display order. This panel controls only this feature.",9,MUTED,false),lp(-1,dp(28)));
        c.addView(actionRow4(this::prepareFeatureCard,()->editFields(singleTitle,singleCaption,singleUrl,singleIcon,singleImage,singlePrice,singleOffer,singleOfferStart,singleOfferEnd,singleTimeLimit,singlePosition),this::saveFeatureCard,this::deleteFeatureCard),lp(-1,dp(46)));
        c.addView(action("PREVIEW DRAFT",BLUE,()->{LinearLayout preview=col();preview.setPadding(dp(12),dp(10),dp(12),dp(10));String image=singleImage.getText().toString().trim();if(!image.isEmpty()){ImageView photo=new ImageView(this);photo.setScaleType(ImageView.ScaleType.FIT_CENTER);SafeImageLoader.load(photo,image);preview.addView(photo,lp(-1,dp(140)));}preview.addView(txt(singleTitle.getText().toString(),17,DARK,true));preview.addView(txt(singleCaption.getText().toString(),12,MUTED,false));preview.addView(txt(singleActive.isChecked()?"Enabled":"Disabled",11,BLUE,true));preview.addView(txt("Price: "+singlePrice.getText()+" · "+singleOffer.getText(),11,DARK,false));preview.addView(txt(singleUrl.getText().toString(),10,MUTED,false));new MyShopDialogBuilder(this).setTitle("Preview · unsaved draft").setView(preview).setPositiveButton(UiStrings.label(AdminSectionActivity.this,"Close"),null).show();}),lp(-1,dp(42)));
        c.addView(action("CANCEL / CLOSE",RED,()->{if(featureSaving){toast("Save is in progress");return;}new MyShopDialogBuilder(this).setTitle("Close feature editor?").setMessage("Unsaved field changes will be discarded.").setPositiveButton(UiStrings.label(AdminSectionActivity.this,"Close"),(d,w)->finish()).setNegativeButton("Keep editing",null).show();}),lp(-1,dp(42)));
        if(managedCategory.matches("feature_[a-z0-9_]{1,80}"))c.addView(action("HISTORY / RESTORE / PREVIOUS VERSION",BLUE,this::showFeatureHistory),lp(-1,dp(48)));
        if(managedCategory.matches("feature_[a-z0-9_]{1,80}")&&AuthorityBadge.isAuthority(SessionManager.getUserId(this))&&!managedCategory.matches(".*(live|rtc|audio|room|gift|wallet|coin|gold|withdraw|payment|order|membership|profile).*"))c.addView(action("PERMANENT DELETE • archived feature",RED,this::permanentlyDeleteFeature),lp(-1,dp(48)));
        if(separateDraft()){c.addView(action("SAVE PRIVATE DRAFT",BLUE,this::savePrivateFeatureDraft),lp(-1,dp(44)));if(AuthorityBadge.isAuthority(SessionManager.getUserId(this))){c.addView(action("LOAD SAVED DRAFT FOR REVIEW",BLUE,this::reviewSavedFeatureDraft),lp(-1,dp(44)));c.addView(action("PUBLISH SAVED DRAFT",PURPLE,this::publishSavedFeatureDraft),lp(-1,dp(44)));c.addView(action("SAVE → PREVIEW → PUBLISH • ইউজারের কাছে কার্যকর",PURPLE,()->savePrivateFeatureDraft(true)),lp(-1,dp(48)));}loadDraftRevision();}
        body.addView(c,lp(-1,-2));
        if(managedCategory.startsWith("feature_home1_")&&!managedCategory.matches(".*(?:live|rtc|audio|gift|room).*")){body.addView(action("আইকনের মাপ / অবস্থান / Show–Hide",BLUE,()->startActivity(new Intent(this,PageIconAdminActivity.class).putExtra("page","home1"))),lp(-1,dp(48)));body.addView(action("লেখার অংশের রং / গ্রেডিয়েন্ট / ফন্ট মাপ",PURPLE,()->startActivity(new Intent(this,MainActivity.class).putExtra("open_design_scope","home_quick"))),lp(-1,dp(48)));}
        if(separateDraft()&&AuthorityBadge.isAuthority(SessionManager.getUserId(this)))body.addView(action("রঙ দিন • আইকনের নাম / ক্যাপশন",PURPLE,()->{TextView title=singleTitle,caption=singleCaption;java.util.LinkedHashMap<String,TextView> labels=TextAppearance.labels("element_title",title);labels.put("element_caption",caption);TextStyleEditor.open(this,managedCategory,labels);}),lp(-1,dp(48)));
        if("feature_gallery".equals(managedCategory))body.addView(action("OPEN GALLERY CONTENT ADMIN",BLUE,()->startActivity(new Intent(this,GalleryAdminActivity.class))),lp(-1,dp(44)));
        if("feature_more_apps".equals(managedCategory))body.addView(action("OPEN MORE / SOCIAL ADMIN",BLUE,()->startActivity(new Intent(this,AdminSectionActivity.class).putExtra("section","more_apps").putExtra("admin_context",true))),lp(-1,dp(44)));
        if("feature_external_movie".equals(managedCategory))body.addView(action("OPEN EXTERNAL LINKS ADMIN",BLUE,()->startActivity(new Intent(this,AdminSectionActivity.class).putExtra("section","external_movie").putExtra("admin_context",true))),lp(-1,dp(44)));
        if("feature_social_media".equals(managedCategory))body.addView(action("OPEN SOCIAL LINKS ADMIN",BLUE,()->startActivity(new Intent(this,AdminSectionActivity.class).putExtra("section","social").putExtra("admin_context",true))),lp(-1,dp(44)));
    }
    private void prepareFeatureCard(){if(featureSaving)return;loadedReviewDraft=null;if(singleSoonMessage!=null)singleSoonMessage.setText("");singleTitle.setText(managedDisplayTitle);singleCaption.setText("");singleUrl.setText("");singleIcon.setText("");singleImage.setText("");singlePrice.setText("0");singleOffer.setText("");singleOfferStart.setText("");singleOfferEnd.setText("");singleTimeLimit.setText("0");singlePosition.setText("1");singleActive.setChecked(true);singleComingSoon.setChecked(false);toast(singleId>0?"Current feature cleared for replacement — press SAVE / EDIT":"New setting ready — press SAVE / EDIT");}
    private void saveFeatureCard(){if(separateDraft()){savePrivateFeatureDraft(AuthorityBadge.isAuthority(SessionManager.getUserId(this)));return;}if(featureSaving)return;if(managedCategory.matches("feature_[a-z0-9_]{1,80}")&&!featureReady){toast("Load the current feature before saving");return;}try{String title=singleTitle.getText().toString().trim();if(title.isEmpty())title=managedDisplayTitle;long price=Long.parseLong(singlePrice.getText().toString().trim().isEmpty()?"0":singlePrice.getText().toString().trim());long limit=Long.parseLong(singleTimeLimit.getText().toString().trim().isEmpty()?"0":singleTimeLimit.getText().toString().trim());if(price<0||limit<0)throw new IllegalArgumentException();String status=singleComingSoon.isChecked()?"COMING_SOON":(singleActive.isChecked()?"ACTIVE":"DISABLED");JSONObject x=new JSONObject().put("id",singleId).put("category",managedCategory).put("title",title).put("caption",singleCaption.getText().toString().trim()).put("url",singleUrl.getText().toString().trim()).put("iconUrl",singleIcon.getText().toString().trim()).put("imageUrl",singleImage.getText().toString().trim()).put("active",singleActive.isChecked()).put("displayOrder",Math.max(1,Math.min(999,Integer.parseInt(singlePosition.getText().toString().trim().isEmpty()?"1":singlePosition.getText().toString().trim())))).put("priceMinor",price).put("offerText",singleOffer.getText().toString().trim()).put("offerStart",singleOfferStart.getText().toString().trim()).put("offerEnd",singleOfferEnd.getText().toString().trim()).put("timeLimitMinutes",limit).put("status",status);x.put("comingSoonMessage",singleSoonMessage.getText().toString().trim());if(managedCategory.matches("feature_[a-z0-9_]{1,80}"))featureMutation(x,"SAVE",0);else BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("managedLinks",new JSONArray().put(x)),result("Feature saved"));}catch(Exception e){toast("Feature data invalid");}}
    private JSONObject featureDraftInput() throws Exception{String title=singleTitle.getText().toString().trim();if(title.isEmpty())title=managedDisplayTitle;long price=Long.parseLong(singlePrice.getText().toString().trim().isEmpty()?"0":singlePrice.getText().toString().trim());long limit=Long.parseLong(singleTimeLimit.getText().toString().trim().isEmpty()?"0":singleTimeLimit.getText().toString().trim());if(price<0||limit<0)throw new IllegalArgumentException();String status=singleComingSoon.isChecked()?"COMING_SOON":(singleActive.isChecked()?"ACTIVE":"DISABLED");JSONObject x=(loadedReviewDraft==null?new JSONObject():new JSONObject(loadedReviewDraft.toString())).put("id",singleId).put("category",managedCategory).put("title",title).put("caption",singleCaption.getText().toString().trim()).put("url",singleUrl.getText().toString().trim()).put("iconUrl",singleIcon.getText().toString().trim()).put("imageUrl",singleImage.getText().toString().trim()).put("active",singleActive.isChecked()).put("displayOrder",Math.max(1,Math.min(999,Integer.parseInt(singlePosition.getText().toString().trim().isEmpty()?"1":singlePosition.getText().toString().trim())))).put("priceMinor",price).put("offerText",singleOffer.getText().toString().trim()).put("offerStart",singleOfferStart.getText().toString().trim()).put("offerEnd",singleOfferEnd.getText().toString().trim()).put("timeLimitMinutes",limit).put("status",status);x.put("comingSoonMessage",singleSoonMessage.getText().toString().trim());return x;}
    private void savePrivateFeatureDraft(){savePrivateFeatureDraft(false);}
    private void savePrivateFeatureDraft(boolean publishAfter){if(featureSaving||!featureReady)return;if(draftRevision<0){toast("Load Draft settings first");loadDraftRevision();return;}try{JSONObject config=featureDraftInput();JSONObject data=new JSONObject().put("expectedRevision",draftRevision).put("config",config);featureSaving=true;lockFeatureFields(false);BackendClient.saveFeatureDraft(SessionManager.getToken(this),managedCategory,data,new BackendClient.Callback(){public void onSuccess(JSONObject result){runOnUiThread(()->{featureSaving=false;lockFeatureFields(true);if(isFinishing()||isDestroyed())return;draftRevision=result.optInt("revision");toast("Private Draft saved • public feature unchanged");if(publishAfter)publishSavedFeatureDraft();});}public void onError(String m){runOnUiThread(()->{featureSaving=false;lockFeatureFields(true);toast("Draft not saved: "+m);});}});}catch(Exception e){featureSaving=false;lockFeatureFields(true);toast("Feature data invalid");}}
    private void publishSavedFeatureDraft(){if(featureSaving||!featureReady||!AuthorityBadge.isAuthority(SessionManager.getUserId(this)))return;featureSaving=true;BackendClient.featureDraft(SessionManager.getToken(this),managedCategory,new BackendClient.Callback(){public void onSuccess(JSONObject result){runOnUiThread(()->{featureSaving=false;JSONObject draft=result.optJSONObject("draft");if(draft==null){toast("Save a Draft first");return;}int expected=result.optInt("revision");new MyShopDialogBuilder(AdminSectionActivity.this).setTitle("Publish saved Draft?").setMessage("Folder: "+managedCategory+"\nDraft revision: "+expected+"\nName: "+draft.optString("title")+"\nDescription: "+draft.optString("caption")+"\nURL: "+draft.optString("url")+"\nStatus: "+draft.optString("status")+"\nPrice: "+draft.optLong("priceMinor")+"\nThe SAVED Draft will replace the public feature. Unsaved edits are excluded.").setNegativeButton("Cancel",null).setPositiveButton("Publish",(d,n)->{try{featureSaving=true;JSONObject request=new JSONObject().put("category",managedCategory).put("draftRevision",expected).put("featureRevision",featureRevision);BackendClient.publishFeatureDraft(SessionManager.getToken(AdminSectionActivity.this),request,new BackendClient.Callback(){public void onSuccess(JSONObject r){runOnUiThread(()->{featureSaving=false;featureRevision=r.optInt("revision");JSONObject feature=r.optJSONObject("feature");if(feature!=null)singleId=feature.optLong("id");toast("Published • revision "+featureRevision);});}public void onError(String m){runOnUiThread(()->{featureSaving=false;toast("Publish blocked: "+m);});}});}catch(Exception e){featureSaving=false;toast("Publish failed");}}).show();});}public void onError(String m){runOnUiThread(()->{featureSaving=false;toast("Draft unavailable: "+m);});}});}
    private void deleteFeatureCard(){if(featureSaving)return;if(managedCategory.matches("feature_[a-z0-9_]{1,80}")){if(singleId<=0){toast("No saved feature to archive");return;}new MyShopDialogBuilder(this).setTitle("Archive this feature?").setMessage("The public entry will be disabled. Its saved settings and history remain available for restore.").setNegativeButton("CANCEL",null).setPositiveButton("ARCHIVE",(d,w)->{try{featureMutation(new JSONObject().put("id",singleId).put("category",managedCategory),"ARCHIVE",0);}catch(Exception e){toast("Archive failed");}}).show();return;}try{JSONObject x=new JSONObject().put("id",singleId).put("category",managedCategory).put("title",singleTitle.getText().toString().trim()).put("caption",singleCaption.getText().toString().trim()).put("url",singleUrl.getText().toString().trim()).put("iconUrl",singleIcon.getText().toString().trim()).put("imageUrl",singleImage.getText().toString().trim()).put("active",false).put("displayOrder",Math.max(1,Math.min(999,Integer.parseInt(singlePosition.getText().toString().trim().isEmpty()?"1":singlePosition.getText().toString().trim())))).put("status","DISABLED");BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("managedLinks",new JSONArray().put(x)),result("Feature deleted / hidden"));}catch(Exception e){toast("Delete failed");}}

    private void permanentlyDeleteFeature(){
        if(featureSaving||!featureReady||singleId<=0)return;
        EditText reason=field("Deletion reason (required)");
        new MyShopDialogBuilder(this).setTitle("Permanently delete archived feature?").setMessage("Archive first. This removes only the saved public feature configuration. Ordinary Restore will not be available. Financial records, purchased items and audit history remain intact.").setView(reason).setNegativeButton("Cancel",null).setPositiveButton("Continue",(d,w)->{
            String note=reason.getText().toString().trim();if(note.length()<5||note.length()>500){toast("Enter a reason of 5–500 characters");return;}
            new MyShopDialogBuilder(this).setTitle("Final confirmation").setMessage(managedDisplayTitle+"\nReason: "+note+"\nThis cannot be restored through the ordinary feature editor.").setNegativeButton("Cancel",null).setPositiveButton("Permanently delete",(confirm,n)->{
                try{featureSaving=true;JSONObject request=new JSONObject().put("config",new JSONObject().put("id",singleId).put("category",managedCategory)).put("action","PERMANENT_DELETE").put("confirm",true).put("reason",note).put("expectedRevision",featureRevision);
                    BackendClient.saveFeatureHistory(SessionManager.getToken(this),managedCategory,request,new BackendClient.Callback(){public void onSuccess(JSONObject result){runOnUiThread(()->{featureSaving=false;singleId=0;featureRevision=0;toast("Feature deleted • audit retained");loadFeatureHistory();});}public void onError(String m){runOnUiThread(()->{featureSaving=false;toast(m);});}});
                }catch(Exception e){featureSaving=false;toast("Delete failed");}
            }).show();
        }).show();
    }
    private void loadFeatureHistory(){
        featureReady=false;
        BackendClient.featureHistory(SessionManager.getToken(this),managedCategory,new BackendClient.Callback(){
            public void onSuccess(JSONObject data){runOnUiThread(()->{if(isFinishing())return;try{JSONObject item=data.optJSONObject("feature");featureRevision=data.optLong("revision");JSONObject oldIcon=data.optJSONObject("legacyPresentation");apply(new JSONObject().put("managedLinks",item==null?new JSONArray():new JSONArray().put(item)).put("featureButtons",oldIcon==null?new JSONArray():new JSONArray().put(oldIcon)));featureReady=true;featureBaseline=featureValues();}catch(Exception e){toast("Could not read feature settings");}});}
            public void onError(String message){runOnUiThread(()->toast("Feature load failed: "+message));}
        });
    }
    private void featureMutation(JSONObject config,String action,long eventId){
        if(featureSaving||!featureReady)return;
        try{featureSaving=true;lockFeatureFields(false);BackendClient.saveFeatureHistory(SessionManager.getToken(this),managedCategory,new JSONObject().put("config",config).put("expectedRevision",featureRevision).put("action",action).put("eventId",eventId),new BackendClient.Callback(){
            public void onSuccess(JSONObject data){runOnUiThread(()->{featureSaving=false;lockFeatureFields(true);toast("Feature change saved");loadFeatureHistory();});}
            public void onError(String message){runOnUiThread(()->{featureSaving=false;lockFeatureFields(true);toast("Change not saved: "+message);});}
        });}catch(Exception e){featureSaving=false;lockFeatureFields(true);toast("Invalid feature change");}
    }
    private void showFeatureHistory(){
        if(featureSaving)return;
        BackendClient.featureHistory(SessionManager.getToken(this),managedCategory,new BackendClient.Callback(){
            public void onError(String message){runOnUiThread(()->toast(message));}
            public void onSuccess(JSONObject data){runOnUiThread(()->{
                JSONArray rows=data.optJSONArray("history");if(rows==null||rows.length()==0){toast("No saved history yet");return;}
                String[] labels=new String[rows.length()];for(int i=0;i<labels.length;i++){JSONObject row=rows.optJSONObject(i);labels[i]=row==null?"":("Version "+row.optLong("revision")+" · "+row.optString("action")+" · "+row.optString("created_at"));}
                new MyShopDialogBuilder(AdminSectionActivity.this).setTitle("Feature history").setItems(labels,(d,n)->{
                    JSONObject selected=rows.optJSONObject(n);if(selected==null)return;boolean restore="ARCHIVE".equals(selected.optString("action"));
                    new MyShopDialogBuilder(AdminSectionActivity.this).setTitle(restore?"Restore archived feature?":"Use this previous version?").setMessage("Current version: "+featureRevision+"\nSelected version: "+selected.optLong("revision")+"\nA new audited version will be created. A conflicting edit will block this change.").setNegativeButton("CANCEL",null).setPositiveButton(restore?"RESTORE":"ROLLBACK",(dialog,which)->{try{featureMutation(new JSONObject().put("id",singleId).put("category",managedCategory),restore?"RESTORE":"ROLLBACK",selected.optLong("id"));}catch(Exception e){toast("Could not restore this version");}}).show();
                }).setNegativeButton("CLOSE",null).show();
            });}
        });
    }

    private EditText[] featureFields(){return new EditText[]{singleTitle,singleCaption,singleUrl,singleIcon,singleImage,singlePrice,singleOffer,singleOfferStart,singleOfferEnd,singleTimeLimit,singlePosition,singleSoonMessage};}
    private void lockFeatureFields(boolean enabled){for(EditText field:featureFields())if(field!=null)field.setEnabled(enabled);if(singleActive!=null)singleActive.setEnabled(enabled);if(singleComingSoon!=null)singleComingSoon.setEnabled(enabled);}
    private String featureValues(){JSONArray values=new JSONArray();for(EditText field:featureFields())values.put(field==null?"":field.getText().toString());values.put(singleActive!=null&&singleActive.isChecked()).put(singleComingSoon!=null&&singleComingSoon.isChecked());return values.toString();}
    @Override public void onBackPressed(){
        if("feature_card".equals(section)&&managedCategory.matches("feature_[a-z0-9_]{1,80}")){
            if(featureSaving){toast("Save is in progress");return;}
            if(featureReady&&!featureBaseline.equals(featureValues())){new MyShopDialogBuilder(this).setTitle("Unsaved changes").setMessage("Keep editing or discard unsaved changes.").setNegativeButton("KEEP EDITING",null).setPositiveButton("DISCARD",(d,w)->finish()).show();return;}
        }
        super.onBackPressed();
    }

    private void menuUi(){
        if(AuthorityBadge.isAuthority(SessionManager.getUserId(this)))body.addView(action("COMPACT PROFILE MENU ADMIN",BLUE,()->startActivity(new Intent(this,ProfileMenuAdminActivity.class))),lp(-1,dp(48)));
        addHeader("৩-line menu-এর প্রতিটি item-এর নাম, icon, link ও show/hide নিয়ন্ত্রণ করুন। Save / Edit / Delete কাজ করবে এবং frontend reload হলে পরিবর্তন দেখাবে।");
        menuName=new EditText[menuKeys.length]; menuUrl=new EditText[menuKeys.length]; menuIcon=new EditText[menuKeys.length]; menuActive=new CheckBox[menuKeys.length];
        for(int i=0;i<menuKeys.length;i++){final int x=i;LinearLayout c=card();c.addView(txt(menuNames[i],13,DARK,true),lp(-1,dp(25)));menuName[i]=field("Menu name");menuUrl[i]=field("Target / Link (optional)");menuIcon[i]=field("Icon URL / icon key");menuActive[i]=new CheckBox(this);menuActive[i].setText("Show in 3-line menu");menuActive[i].setChecked(true);c.addView(menuName[i]);c.addView(menuUrl[i]);c.addView(menuIcon[i]);c.addView(menuActive[i]);c.addView(actionRow4(()->prepareMenuSlot(x),()->editFields(menuName[x],menuUrl[x],menuIcon[x]),()->saveMenuItem(x),()->deleteMenuItem(x)),lp(-1,dp(42)));body.addView(c,lp(-1,-2));}
        body.addView(action("➕ ADD NEW MENU",PURPLE,this::addNewMenu),lp(-1,dp(44)));
    }
    private void prepareMenuSlot(int i){menuName[i].setText(menuNames[i]);menuUrl[i].setText("");menuIcon[i].setText("");menuActive[i].setChecked(true);editFields(menuName[i],menuUrl[i],menuIcon[i]);toast("Menu slot ready");}
    private void saveMenuItem(int i){try{String title=menuName[i].getText().toString().trim();if(title.isEmpty()){toast("Menu name required");return;}JSONObject item=new JSONObject().put("key",menuKeys[i]).put("title",title).put("targetUrl",menuUrl[i].getText().toString().trim()).put("iconUrl",menuIcon[i].getText().toString().trim()).put("active",menuActive[i].isChecked()).put("displayOrder",i+1);BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("featureButtons",new JSONArray().put(item)),result("Menu saved"));}catch(Exception e){toast("Menu data invalid");}}
    private void deleteMenuItem(int i){try{BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("deleteFeatureKeys",new JSONArray().put(menuKeys[i])),result("Menu deleted"));}catch(Exception e){toast("Delete failed");}}
    private void addNewMenu(){final EditText name=field("Menu name");final EditText url=field("Target / Link (optional)");final EditText icon=field("Icon URL / icon key");LinearLayout box=col();box.setPadding(dp(8),0,dp(8),0);box.addView(name);box.addView(url);box.addView(icon);new MyShopDialogBuilder(this).setTitle("ADD MENU ITEM").setView(box).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(d,w)->{try{String n=name.getText().toString().trim();if(n.isEmpty()){toast("Menu name required");return;}String key="menu_custom_"+System.currentTimeMillis();JSONObject item=new JSONObject().put("key",key).put("title",n).put("targetUrl",url.getText().toString().trim()).put("iconUrl",icon.getText().toString().trim()).put("active",true).put("displayOrder",99);BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("featureButtons",new JSONArray().put(item)),result("Menu added"));}catch(Exception e){toast("Menu data invalid");}}).show();}

    private void dynamicContentUi(){
        addHeader("নতুন আলাদা Dynamic row নেই। Dashboard-এর EXISTING ছোট circular/live row-এর প্রতিটি slot আলাদাভাবে edit করুন। Hidden slot-ও এই তালিকা থেকে আবার চালু করা যাবে।");
        final String[] names={"SHOPPING / SLOT 1","GADGET / SLOT 2","FASHION / SLOT 3","GAMING / SLOT 4","LIVE / SLOT 5","AD / SLOT 6"};
        for(int i=0;i<6;i++){final int slot=i+1;final String label=names[i];body.addView(action("OPEN  "+label,BLUE,()->{Intent z=new Intent(this,AdminSectionActivity.class);z.putExtra("section","feature_card");z.putExtra("managed_category","dashboard_slot_"+slot);z.putExtra("managed_title","DASHBOARD SLOT "+slot);z.putExtra("admin_context",true);startActivity(z);}),lp(-1,dp(44)));body.addView(gap(6),lp(1,dp(6)));}
    }
    private void saveDynamicContent(String cat,int order){try{String title=dynamicTitle[order].getText().toString().trim();if(title.isEmpty()){toast("Name / title required");return;}JSONObject x=new JSONObject().put("id",dynamicId[order]).put("category",cat).put("title",title).put("caption",dynamicCaption[order].getText().toString().trim()).put("url",dynamicUrl[order].getText().toString().trim()).put("iconUrl",dynamicIcon[order].getText().toString().trim()).put("imageUrl",dynamicImage[order].getText().toString().trim()).put("active",dynamicActive[order].isChecked()).put("displayOrder",order+1);BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("managedLinks",new JSONArray().put(x)),result("Dynamic item saved"));}catch(Exception e){toast("Dynamic data invalid");}}
    private void deleteDynamicContent(String cat,int order){long id=dynamicId[order];if(id<=0){toast("Already empty");return;}try{BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("deleteManagedLinkIds",new JSONArray().put(id)),result("Dynamic item deleted"));}catch(Exception e){toast("Delete failed");}}
    private void addDynamicContent(){final EditText cat=field("Category (live_now / advertisement / social_media / caption)");final EditText title=field("Name / title");final EditText cap=field("Caption");final EditText url=field("লিংক / URL");final EditText icon=field("Icon URL");final EditText image=field("Image / Banner URL");LinearLayout box=col();box.addView(cat);box.addView(title);box.addView(cap);box.addView(url);box.addView(icon);box.addView(image);new MyShopDialogBuilder(this).setTitle("ADD DYNAMIC ITEM").setView(box).setPositiveButton("SAVE",(d,w)->{try{String c=cat.getText().toString().trim().toLowerCase();if(c.isEmpty()||title.getText().toString().trim().isEmpty()){toast("Category and title required");return;}JSONObject x=new JSONObject().put("category",c).put("title",title.getText().toString().trim()).put("caption",cap.getText().toString().trim()).put("url",url.getText().toString().trim()).put("iconUrl",icon.getText().toString().trim()).put("imageUrl",image.getText().toString().trim()).put("active",true).put("displayOrder",99);BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("managedLinks",new JSONArray().put(x)),result("Dynamic item added"));}catch(Exception e){toast("Dynamic data invalid");}}).setNegativeButton("CANCEL",null).show();}

    private void moderatorUi(){
        if(java.util.Arrays.asList("0001","0002","0003").contains(SessionManager.getUserId(this)))body.addView(action("FOLDER PERMISSIONS",PURPLE,()->startActivity(new Intent(this,AssignedAdminFoldersActivity.class))),lp(-1,dp(44)));
        addHeader("Moderator ID যোগ/সরানো। Permanent Admin ID পরিবর্তন করা যাবে না।");
        EditText id=field("4-digit User ID");body.addView(id);LinearLayout a=row();a.addView(action("ADD MODERATOR",GREEN,()->moderator(id.getText().toString(),"add_moderator")),wt(1));a.addView(gap(5));a.addView(action("REMOVE",RED,()->moderator(id.getText().toString(),"remove_moderator")),wt(1));body.addView(a,lp(-1,dp(42)));
        body.addView(action("RELOAD MODERATOR STATUS",BLUE,()->load()),lp(-1,dp(42)));
    }

    private void addHeader(String s){TextView t=txt(s,10,MUTED,false);t.setPadding(dp(4),dp(2),dp(4),dp(12));body.addView(t,lp(-1,-2));}

    private void load(){if("feature_card".equals(section)&&managedCategory.matches("feature_[a-z0-9_]{1,80}")){loadFeatureHistory();return;}String token=SessionManager.getToken(this);if(token==null||token.isEmpty())return;BackendClient.dashboard(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->apply(d));}public void onError(String m){runOnUiThread(()->toast(LanguageManager.BN.equals(LanguageManager.get(AdminSectionActivity.this))?"ডাটা লোড করা যায়নি। আবার চেষ্টা করুন।":"Could not load data. Please try again."));}});}
    private void apply(JSONObject d){try{
        if("dashboard".equals(section)){JSONObject c=d.optJSONObject("config");if(c!=null){news.setText(c.optString("breaking_news",""));newsSizeSp=(float)Math.max(10.0,Math.min(24.0,c.optDouble("breaking_news_text_size",13.0)));if(newsSizeLabel!=null)newsSizeLabel.setText(String.format(java.util.Locale.US,"%.0f px",newsSizeSp));newsBgColor.setText(c.optString("breaking_news_bg_color","#FFEFF7"));newsTextColor.setText(c.optString("breaking_news_text_color","#414662"));applyHeadlinePreview();shopUrl.setText(c.optString("my_shop_url",""));tvUrl.setText(c.optString("live_tv_url",""));movieUrl.setText(c.optString("external_movie_url",""));chatUrl.setText(c.optString("chat_url",""));powerAdTitle.setText(c.optString("power_ad_title","POWER AD"));powerAdByline.setText(c.optString("power_ad_byline","by Touhid"));dashBgColor.setText(c.optString("dashboard_bg_color",ThemeConfig.DEF_BG));dashBlueColor.setText(c.optString("dashboard_blue_color",ThemeConfig.DEF_BLUE));dashPurpleColor.setText(c.optString("dashboard_purple_color",ThemeConfig.DEF_PURPLE));dashPinkColor.setText(c.optString("dashboard_pink_color",ThemeConfig.DEF_PINK));}}
        else if("feature_card".equals(section)){singleId=0;JSONArray a=d.optJSONArray("managedLinks");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&managedCategory.equalsIgnoreCase(x.optString("category",""))){singleId=x.optLong("id",0);featureRevision=x.optLong("revision");if(singleSoonMessage!=null)singleSoonMessage.setText(x.optString("coming_soon_message",""));singleTitle.setText(x.optString("title",managedDisplayTitle));singleCaption.setText(x.optString("caption",""));singleUrl.setText(x.optString("url",""));singleIcon.setText(x.optString("icon_url",""));singleImage.setText(x.optString("image_url",""));singleActive.setChecked(x.optInt("active",1)==1);if(singlePrice!=null)singlePrice.setText(String.valueOf(x.optLong("price_minor",0)));if(singleOffer!=null)singleOffer.setText(x.optString("offer_text",""));if(singleOfferStart!=null)singleOfferStart.setText(x.optString("offer_start",""));if(singleOfferEnd!=null)singleOfferEnd.setText(x.optString("offer_end",""));if(singleTimeLimit!=null)singleTimeLimit.setText(String.valueOf(x.optInt("time_limit_minutes",0)));if(singlePosition!=null)singlePosition.setText(String.valueOf(Math.max(1,x.optInt("display_order",1))));if(singleComingSoon!=null){String st=x.optString("status","ACTIVE");singleComingSoon.setChecked("COMING_SOON".equalsIgnoreCase(st)||"UPCOMING".equalsIgnoreCase(st)||"LAUNCHING_SOON".equalsIgnoreCase(st));}break;}}if(singleId==0&&singleTitle!=null){singleTitle.setText(managedDisplayTitle);singlePrice.setText("0");singleTimeLimit.setText("0");singlePosition.setText("1");singleComingSoon.setChecked(false);JSONArray oldIcons=d.optJSONArray("featureButtons");if(oldIcons!=null&&oldIcons.length()>0){JSONObject oldIcon=oldIcons.optJSONObject(0);if(oldIcon!=null){singleTitle.setText(oldIcon.optString("title",managedDisplayTitle));singleUrl.setText(oldIcon.optString("target_url",""));singleIcon.setText(oldIcon.optString("icon_url",""));singlePosition.setText(String.valueOf(Math.max(1,oldIcon.optInt("display_order",1))));singleActive.setChecked(oldIcon.optInt("active",1)==1);}}}}
        else if("dynamic_content".equals(section)){/* V-228: slot launcher only; each slot loads in its own feature_card panel. */}
        else if("external_movie".equals(section)){JSONArray a=d.optJSONArray("managedLinks");if(a!=null){int n=0;for(int i=0;i<a.length()&&n<6;i++){JSONObject x=a.optJSONObject(i);if(x==null||!"external_movie".equalsIgnoreCase(x.optString("category","")))continue;extId[n]=x.optLong("id",0);extTitle[n].setText(x.optString("title",""));extCaption[n].setText(x.optString("caption",""));extUrl[n].setText(x.optString("url",""));extIcon[n].setText(x.optString("icon_url",""));extImage[n].setText(x.optString("image_url",""));if(extPreview[n]!=null&&!x.optString("image_url","").trim().isEmpty())loadPreview(extPreview[n],x.optString("image_url",""));n++;}}}
        else if("features".equals(section)){JSONArray a=d.optJSONArray("featureButtons");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;for(int j=0;j<featureKeys.length;j++)if(featureKeys[j].equals(x.optString("key",""))){featureTitle[j].setText(x.optString("title",featureNames[j]));featureUrl[j].setText(x.optString("target_url",""));featureIcon[j].setText(x.optString("icon_url",""));featureActive[j].setChecked(x.optInt("active",1)==1);}}}
        else if("menu".equals(section)){JSONArray a=d.optJSONArray("featureButtons");if(a!=null&&menuName!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String key=x.optString("key","");for(int j=0;j<menuKeys.length;j++)if(menuKeys[j].equals(key)){menuName[j].setText(x.optString("title",menuNames[j]));menuUrl[j].setText(x.optString("target_url",""));menuIcon[j].setText(x.optString("icon_url",""));menuActive[j].setChecked(x.optInt("active",1)==1);}}}
        else if("social".equals(section)){JSONArray a=d.optJSONArray("socialLinks");if(a!=null)for(int i=0;i<Math.min(8,a.length());i++){JSONObject x=a.optJSONObject(i);if(x!=null){socialPlatform[i].setText(x.optString("platform",""));socialUrl[i].setText(x.optString("url",""));socialCaption[i].setText(x.optString("caption",""));if(socialIcon[i]!=null)socialIcon[i].setText(x.optString("icon_url",""));if(socialImage[i]!=null)socialImage[i].setText(x.optString("image_url",""));if(socialPreview[i]!=null&&!x.optString("image_url","").trim().isEmpty())loadPreview(socialPreview[i],x.optString("image_url",""));}}}
        else if("more_apps".equals(section)){JSONArray a=d.optJSONArray("socialLinks");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String p=x.optString("platform","");for(int j=0;j<8;j++){if(p.equalsIgnoreCase(new String[]{"Facebook","Page","YouTube","WhatsApp","imo","Instagram","Telegram","TikTok"}[j])){socialPlatform[j].setText(p);socialUrl[j].setText(x.optString("url",""));socialCaption[j].setText(x.optString("caption",""));if(socialIcon[j]!=null)socialIcon[j].setText(x.optString("icon_url",""));if(socialImage[j]!=null)socialImage[j].setText(x.optString("image_url",""));if(socialPreview[j]!=null&&!x.optString("image_url","").trim().isEmpty())loadPreview(socialPreview[j],x.optString("image_url",""));}}}}
        else if(!"moderators".equals(section)){JSONArray a=d.optJSONArray("managedLinks");if(itemTitle[0]!=null)for(int z=0;z<3;z++){itemId[z]=0;itemTitle[z].setText("");itemCaption[z].setText("");itemUrl[z].setText("");itemIcon[z].setText("");itemImage[z].setText("");itemActive[z].setChecked(true);}if(a!=null){int n=0;for(int i=0;i<a.length()&&n<3;i++){JSONObject x=a.optJSONObject(i);if(x==null||!section.equals(x.optString("category","")))continue;itemId[n]=x.optLong("id",0);itemTitle[n].setText(x.optString("title",""));itemCaption[n].setText(x.optString("caption",""));itemUrl[n].setText(x.optString("url",""));itemIcon[n].setText(x.optString("icon_url",""));itemImage[n].setText(x.optString("image_url",""));itemActive[n].setChecked(x.optInt("active",1)==1);n++;}}}
    }catch(Exception e){toast("Config read error");}}

    private void saveSupport(){if(itemTitle[0]!=null)saveManaged(0);}
    private void saveExternalItem(int i){try{String title=extTitle[i].getText().toString().trim(),caption=extCaption[i].getText().toString().trim(),url=extUrl[i].getText().toString().trim(),icon=extIcon[i].getText().toString().trim(),image=extImage[i].getText().toString().trim();if(title.isEmpty()&&url.isEmpty()){toast("Title or URL required");return;}JSONObject q=new JSONObject();JSONArray a=new JSONArray();a.put(new JSONObject().put("id",extId[i]).put("category","external_movie").put("title",title).put("caption",caption).put("url",url).put("iconUrl",icon).put("imageUrl",image).put("active",!url.isEmpty()).put("displayOrder",i+1));q.put("managedLinks",a);BackendClient.adminContentPut(SessionManager.getToken(this),q,result("External Movie "+(i+1)+" saved"));}catch(Exception e){toast("External Movie data invalid");}}
    private void deleteExternalItem(int i){if(extId[i]<=0){extTitle[i].setText("");extCaption[i].setText("");extUrl[i].setText("");extIcon[i].setText("");extImage[i].setText("");toast("Already empty");return;}new MyShopDialogBuilder(this).setTitle("Delete External Movie?").setMessage("শুধু এই link মুছে যাবে।").setPositiveButton("DELETE",(d,w)->{try{JSONObject q=new JSONObject().put("deleteManagedLinkIds",new JSONArray().put(extId[i]));BackendClient.adminContentPut(SessionManager.getToken(this),q,result("External Movie deleted"));}catch(Exception e){toast("Delete failed");}}).setNegativeButton("CANCEL",null).show();}
    private void saveExternalMovie(){
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){JSONObject c=d.optJSONObject("config");String breaking=c==null?"":c.optString("breaking_news","");String shop=c==null?"":c.optString("my_shop_url","");String tv=c==null?"":c.optString("live_tv_url","");String chat=c==null?"":c.optString("chat_url","");String pat=c==null?"POWER AD":c.optString("power_ad_title","POWER AD");String pab=c==null?"by Touhid":c.optString("power_ad_byline","by Touhid");BackendClient.adminDashboardPut(SessionManager.getToken(AdminSectionActivity.this),breaking,shop,tv,movieUrl.getText().toString().trim(),chat,pat,pab,result("External Movie saved"));}public void onError(String m){toast("Cannot read current Dashboard config: "+m);}});
    }
    private void saveDashboard(){String bg=dashBgColor.getText().toString().trim(),blue=dashBlueColor.getText().toString().trim(),purple=dashPurpleColor.getText().toString().trim(),pink=dashPinkColor.getText().toString().trim(),newsBg=newsBgColor.getText().toString().trim(),newsFg=newsTextColor.getText().toString().trim();if(!ThemeConfig.valid(bg)||!ThemeConfig.valid(blue)||!ThemeConfig.valid(purple)||!ThemeConfig.valid(pink)||!ThemeConfig.valid(newsBg)||!ThemeConfig.valid(newsFg)){toast("Color must be HEX like #07122F");return;}BackendClient.adminDashboardPut(SessionManager.getToken(this),news.getText().toString().trim(),shopUrl.getText().toString().trim(),tvUrl.getText().toString().trim(),movieUrl.getText().toString().trim(),chatUrl.getText().toString().trim(),powerAdTitle.getText().toString().trim(),powerAdByline.getText().toString().trim(),bg,blue,purple,pink,newsSizeSp,newsBg,newsFg,result("Dashboard + Breaking News style saved"));}
    private void deleteFeature(int i){
        try{ JSONObject q=new JSONObject().put("deleteFeatureKeys",new JSONArray().put(featureKeys[i])); BackendClient.adminContentPut(SessionManager.getToken(this),q,result("Feature deleted")); }catch(Exception e){toast("Delete failed");}
    }
    private void addNewFeature(){
        final EditText name=field("Feature name / Caption (optional)"); final EditText url=field("Target URL (optional)"); final EditText icon=field("আইকন URL (ঐচ্ছিক)");
        LinearLayout box=col(); box.setPadding(dp(8),0,dp(8),0); box.addView(name); box.addView(url); box.addView(icon);
        new MyShopDialogBuilder(this).setTitle("ADD NEW FEATURE").setView(box).setPositiveButton("ADD / SAVE",(d,w)->{
            try{ String title=name.getText().toString().trim(); String target=url.getText().toString().trim(); String iconUrl=icon.getText().toString().trim(); if(title.isEmpty()&&target.isEmpty()){toast("Feature name or link required");return;} String key="custom_"+System.currentTimeMillis(); JSONObject item=new JSONObject().put("key",key).put("title",title).put("iconUrl",iconUrl).put("targetUrl",target).put("active",true).put("displayOrder",99); BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("featureButtons",new JSONArray().put(item)),result("New feature added")); }catch(Exception e){toast("Feature data invalid");}
        }).setNegativeButton("CANCEL",null).show();
    }
    private void saveFeature(int i){try{JSONObject p=new JSONObject();JSONArray a=new JSONArray();a.put(new JSONObject().put("key",featureKeys[i]).put("title",featureTitle[i].getText().toString().trim()).put("iconUrl",featureIcon[i].getText().toString().trim()).put("targetUrl",featureUrl[i].getText().toString().trim()).put("active",featureActive[i].isChecked()).put("displayOrder",i+1));p.put("featureButtons",a);BackendClient.adminContentPut(SessionManager.getToken(this),p,result("Feature saved"));}catch(Exception e){toast("Feature data invalid");}}
    private TextView saveSocialButton(String label,int index){
        Button b=new Button(this); b.setText(label); b.setTextSize(11); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setGravity(Gravity.CENTER); b.setPadding(dp(8),0,dp(8),0); b.setMinHeight(0); b.setMinimumHeight(0); b.setBackground(round(GREEN,GREEN,12)); b.setElevation(dp(2));
        if(android.os.Build.VERSION.SDK_INT>=21){android.graphics.drawable.Drawable base=b.getBackground();b.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(Color.argb(42,255,255,255)),base,null));}
        b.setOnClickListener(v->saveSocial(index)); return b;
    }
    private String normalizeSocialUrl(String platform,String raw){
        String u=raw==null?"":raw.trim(); if(u.isEmpty()) return "";
        if(u.startsWith("http://")||u.startsWith("https://")||u.startsWith("tel:")) return u;
        String digits=u.replaceAll("[^0-9]","");
        if(platform.equalsIgnoreCase("WhatsApp") && digits.length()>=8) return "https://wa.me/"+digits;
        if(platform.equalsIgnoreCase("imo") && digits.length()>=8) return "tel:"+digits;
        if(u.startsWith("www.") || u.contains(".")) return "https://"+u;
        return u;
    }
    private JSONObject socialPayloadItem(int i) throws org.json.JSONException {
        String p=socialPlatform[i].getText().toString().trim(),u=normalizeSocialUrl(p,socialUrl[i].getText().toString()),cap=socialCaption[i].getText().toString().trim();
        return new JSONObject().put("platform",p).put("url",u).put("caption",cap).put("iconUrl",socialIcon[i]==null?"":socialIcon[i].getText().toString().trim()).put("imageUrl",socialImage[i]==null?"":socialImage[i].getText().toString().trim()).put("active",!u.isEmpty());
    }
    private void saveSocial(int i){
        if(socialSaving)return;
        try{String p=socialPlatform[i].getText().toString().trim();if(p.isEmpty()){toast("Platform name required");return;}String u=normalizeSocialUrl(p,socialUrl[i].getText().toString());
            socialSaving=true; JSONObject q=new JSONObject(); q.put("socialLinks",new JSONArray().put(socialPayloadItem(i)));
            BackendClient.adminContentPut(SessionManager.getToken(this),q,new BackendClient.Callback(){public void onSuccess(JSONObject d){socialSaving=false;toast("✓ "+p+" saved");load();}public void onError(String m){socialSaving=false;toast("Save failed: "+m);}});
        }catch(Exception e){socialSaving=false;toast("Social data invalid");}
    }
    private void saveAllSocialLinks(){
        if(socialSaving)return;
        try{JSONArray a=new JSONArray();int count=0;for(int i=0;i<8;i++){String p=socialPlatform[i].getText().toString().trim();String u=normalizeSocialUrl(p,socialUrl[i].getText().toString());if(p.isEmpty())continue;a.put(socialPayloadItem(i));count++;}if(count==0){toast("Platform name পাওয়া যায়নি");return;}final int savedCount=count; socialSaving=true;JSONObject q=new JSONObject().put("socialLinks",a);BackendClient.adminContentPut(SessionManager.getToken(this),q,new BackendClient.Callback(){public void onSuccess(JSONObject d){socialSaving=false;toast("✓ "+savedCount+"টি Social link saved");load();}public void onError(String m){socialSaving=false;toast("Save failed: "+m);}});}catch(Exception e){socialSaving=false;toast("Social data invalid");}
    }
    private void deleteSocial(int i){try{String p=socialPlatform[i].getText().toString().trim();if(p.isEmpty()){toast("Already empty");return;}JSONObject q=new JSONObject().put("deleteSocialPlatforms",new JSONArray().put(p));BackendClient.adminContentPut(SessionManager.getToken(this),q,result("Social link deleted"));}catch(Exception e){toast("Delete failed");}}
    private void saveManaged(int i){try{String title=itemTitle[i].getText().toString().trim(),url=itemUrl[i].getText().toString().trim();JSONObject q=new JSONObject();JSONArray a=new JSONArray();a.put(new JSONObject().put("id",itemId[i]).put("category",section).put("title",title).put("caption",itemCaption[i].getText().toString().trim()).put("url",url).put("iconUrl",itemIcon[i].getText().toString().trim()).put("imageUrl",itemImage[i].getText().toString().trim()).put("active",itemActive[i].isChecked()).put("displayOrder",i+1));q.put("managedLinks",a);BackendClient.adminContentPut(SessionManager.getToken(this),q,result("Item saved"));}catch(Exception e){toast("Item data invalid");}}
    private void deleteManaged(int i){if(itemId[i]<=0){prepareManagedSlot(i);toast("Already empty");return;}new MyShopDialogBuilder(this).setTitle("Delete item?").setMessage("শুধু এই item-এর record মুছে যাবে।").setPositiveButton("DELETE",(d,w)->{try{JSONObject q=new JSONObject().put("deleteManagedLinkIds",new JSONArray().put(itemId[i]));BackendClient.adminContentPut(SessionManager.getToken(this),q,result("Item deleted"));}catch(Exception e){toast("Delete failed");}}).setNegativeButton("CANCEL",null).show();}
    private void pickFeatureImage(EditText target,String boxKey,int slot){pickFeatureImage(target,boxKey,slot,null);}
    private void pickFeatureImage(EditText target,String boxKey,int slot,ImageView previewTarget){pendingImageField=target;pendingPreview=previewTarget;pendingAssetBox=(boxKey==null?"feature_asset":boxKey).toLowerCase().replaceAll("[^a-z0-9_-]","_");pendingAssetSlot=Math.max(1,Math.min(6,slot));Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);i.setType("image/*");startActivityForResult(i,REQ_FEATURE_IMAGE);}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=REQ_FEATURE_IMAGE||resultCode!=RESULT_OK||data==null||data.getData()==null||pendingImageField==null)return;
        final Uri uri=data.getData();final EditText target=pendingImageField;final ImageView previewTarget=pendingPreview;final String purpose=pendingAssetBox;
        new Thread(()->{
            try{
                android.graphics.BitmapFactory.Options dimensions=new android.graphics.BitmapFactory.Options();dimensions.inJustDecodeBounds=true;
                try(InputStream probe=getContentResolver().openInputStream(uri)){if(probe==null)throw new java.io.IOException("Image cannot be opened");android.graphics.BitmapFactory.decodeStream(probe,null,dimensions);}
                if(dimensions.outWidth<=0||dimensions.outHeight<=0){toast("Unsupported image. Choose PNG, JPEG or WebP.");return;}
                if(dimensions.outWidth>16000||dimensions.outHeight>16000){toast("Image dimensions too large. Resize before upload.");return;}
                if(Math.min(dimensions.outWidth,dimensions.outHeight)<128)toast("Clarity warning: image is small; 512×512 recommended for icons.");
                if((purpose.contains("icon")||purpose.contains("feature_asset_feature_"))&&!purpose.matches(".*(?:live|rtc|audio|room|gift).*")){
                    android.graphics.BitmapFactory.Options sample=new android.graphics.BitmapFactory.Options();sample.inSampleSize=1;while(Math.max(dimensions.outWidth,dimensions.outHeight)/sample.inSampleSize>768)sample.inSampleSize*=2;
                    android.graphics.Bitmap bitmap;try(InputStream bytes=getContentResolver().openInputStream(uri)){bitmap=android.graphics.BitmapFactory.decodeStream(bytes,null,sample);}if(bitmap==null)throw new java.io.IOException("Image decode failed");
                    try(InputStream exifBytes=getContentResolver().openInputStream(uri)){android.media.ExifInterface exif=new android.media.ExifInterface(exifBytes);int orientation=exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION,1);android.graphics.Matrix matrix=new android.graphics.Matrix();switch(orientation){case 2:matrix.setScale(-1,1);break;case 3:matrix.setRotate(180);break;case 4:matrix.setScale(1,-1);break;case 5:matrix.setRotate(90);matrix.postScale(-1,1);break;case 6:matrix.setRotate(90);break;case 7:matrix.setRotate(270);matrix.postScale(-1,1);break;case 8:matrix.setRotate(270);break;}if(!matrix.isIdentity()){android.graphics.Bitmap rotated=android.graphics.Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);if(rotated!=bitmap)bitmap.recycle();bitmap=rotated;}}catch(Exception ignored){}
                    final android.graphics.Bitmap source=bitmap;runOnUiThread(()->{if(isFinishing()||isDestroyed()){source.recycle();return;}IconUploadPreview.show(this,source,bytes->BackendClient.adminAssetUpload(SessionManager.getToken(this),bytes,"shortcut-icon.png","image/png",purpose,new BackendClient.Callback(){public void onSuccess(JSONObject result){runOnUiThread(()->{if(isFinishing()||isDestroyed())return;String url=result.optString("image_url","");target.setText(url);if(previewTarget!=null)loadPreview(previewTarget,url);toast("আইকন আপলোড হয়েছে • Save করে Publish করুন");});}public void onError(String m){toast("আইকন আপলোড হয়নি: "+m);}}));});return;
                }
                final String mime=getContentResolver().getType(uri);String name=queryName(uri);InputStream input=getContentResolver().openInputStream(uri);if(input==null)throw new java.io.IOException("Image cannot be opened");
                BackendClient.adminAssetUpload(SessionManager.getToken(this),input,name,mime==null?"image/jpeg":mime,purpose,new BackendClient.Callback(){
                    public void onSuccess(JSONObject result){String url=result.optString("image_url","");runOnUiThread(()->{if(isFinishing())return;target.setText(url);if(previewTarget!=null&&!url.isEmpty())loadPreview(previewTarget,url);toast(url.isEmpty()?"Upload response missing URL":"Image uploaded • auto-fit preview ready; Save Draft next");});}
                    public void onError(String m){toast("Image upload failed: "+m);}
                });
            }catch(Exception e){toast("Image could not be uploaded. Please retry.");}
        },"myshop-admin-image-check").start();
    }

    private String queryName(Uri u){try(android.database.Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}catch(Exception ignored){}return "myshop-feature-image.jpg";}

    private ImageView preview(){ImageView v=new ImageView(this);v.setScaleType(ImageView.ScaleType.FIT_CENTER);v.setBackground(round(Color.rgb(242,244,250),Color.rgb(215,218,228),10));v.setContentDescription("Selected image preview");return v;}
    private void loadPreview(ImageView v,String url){new Thread(()->{try{java.net.HttpURLConnection c=(java.net.HttpURLConnection)new java.net.URL(url).openConnection();c.setConnectTimeout(5000);c.setReadTimeout(7000);try(InputStream in=c.getInputStream()){android.graphics.Bitmap b=android.graphics.BitmapFactory.decodeStream(in);if(b!=null)runOnUiThread(()->v.setImageBitmap(b));}c.disconnect();}catch(Exception ignored){}}).start();}

    private void moderator(String id,String act){if(!id.matches("\\d{4}")){toast("Enter a valid 4-digit User ID");return;}BackendClient.adminAction(SessionManager.getToken(this),id,act,result(act.equals("add_moderator")?"Moderator added":"Moderator removed"));}
    private BackendClient.Callback result(String ok){return new BackendClient.Callback(){public void onSuccess(JSONObject d){toast("✓ "+ok);load();}public void onError(String m){toast("Save failed: "+m);}};}

    private LinearLayout card(){LinearLayout c=col();c.setPadding(dp(10),dp(9),dp(10),dp(9));c.setBackground(round(Color.WHITE,Color.rgb(224,226,235),10));c.setElevation(dp(1));LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(8);c.setLayoutParams(p);return c;}
    private LinearLayout actionRow4(Runnable add,Runnable edit,Runnable save,Runnable delete){LinearLayout r=row();r.addView(action("ADD",PURPLE,add),wt(1));r.addView(gap(4),lp(dp(4),1));r.addView(action("EDIT",ORANGE,edit),wt(1));r.addView(gap(4),lp(dp(4),1));r.addView(action("SAVE",GREEN,save),wt(1));r.addView(gap(4),lp(dp(4),1));r.addView(action("DELETE",RED,delete),wt(1));return r;}
    private void editFields(EditText... fields){if(fields!=null)for(EditText f:fields)if(f!=null)f.setEnabled(true);if(fields!=null&&fields.length>0&&fields[0]!=null){fields[0].requestFocus();fields[0].setSelection(fields[0].length());}toast("Edit mode");}

    private TextView fontSizeButton(String label,int color,Runnable action){
        TextView t=txt(label,23,Color.WHITE,true); t.setGravity(Gravity.CENTER); t.setSingleLine(true);
        t.setIncludeFontPadding(false); t.setPadding(0,0,0,dp(2)); t.setBackground(round(color,color,11)); t.setElevation(dp(2));
        t.setContentDescription(("−".equals(label)?"Decrease":"Increase")+" Breaking News font size");
        if(android.os.Build.VERSION.SDK_INT>=21){android.graphics.drawable.Drawable base=t.getBackground();t.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(Color.argb(48,255,255,255)),base,null));}
        t.setOnClickListener(v->action.run()); return t;
    }

    private TextView action(String s,int c,Runnable r){TextView t=txt(s,11,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(12),0,dp(12),0);t.setBackground(round(c,c,12));t.setElevation(dp(2));if(android.os.Build.VERSION.SDK_INT>=21){android.graphics.drawable.Drawable base=t.getBackground();t.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(Color.argb(42,255,255,255)),base,null));}t.setOnClickListener(v->r.run());return t;}
    private EditText field(String h){EditText e=new EditText(this);e.setHint(h);e.setTextSize(12);e.setSingleLine(true);e.setPadding(dp(10),0,dp(10),0);e.setTextColor(DARK);e.setHintTextColor(Color.rgb(145,148,160));e.setBackground(round(Color.WHITE,Color.rgb(215,218,228),7));LinearLayout.LayoutParams p=lp(-1,dp(44));p.bottomMargin=dp(6);e.setLayoutParams(p);return e;}
    private Button button(String s,int c,float z){Button b=new Button(this);b.setText(s);b.setTextColor(c);b.setTextSize(z);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackgroundColor(Color.TRANSPARENT);b.setPadding(0,0,0,0);return b;}
    private TextView txt(String s,float z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private View gap(int d){return new View(this);}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams wt(float w){return new LinearLayout.LayoutParams(0,dp(42),w);}private LinearLayout.LayoutParams weight(float w){return new LinearLayout.LayoutParams(0,dp(52),w);}private GradientDrawable round(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
}
