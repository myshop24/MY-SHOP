package com.myshop.app;

import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;

/** One effect at a time, with stale callbacks and double-release guarded. No RTC setting changes. */
public final class ManagedSoundPlayer {
    public interface Error { void failed(String message); }
    private final Handler handler=new Handler(Looper.getMainLooper());private MediaPlayer player;private int generation;
    public void play(String url,int volume,int durationMs,Error error){play(null,url,volume,durationMs,error);}
    public void play(android.content.Context context,String url,int volume,int durationMs,Error error){
        stop();if(url==null||url.trim().isEmpty()){if(error!=null)error.failed("No sound has been configured for this item.");return;}
        if(volume<=0)return;final int ticket=generation;final MediaPlayer p=new MediaPlayer();player=p;
        try{p.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());if(context!=null)p.setDataSource(context,android.net.Uri.parse(url.trim()));else p.setDataSource(url.trim());
            p.setOnPreparedListener(mp->{if(player!=mp||ticket!=generation)return;try{float level=Math.min(100,Math.max(0,volume))/100f;mp.setVolume(level,level);mp.start();if(durationMs>0)handler.postDelayed(()->{if(player==mp&&ticket==generation)stop();},Math.min(15000,durationMs));}catch(Exception e){if(player==mp)stop();if(error!=null)error.failed("Sound could not start.");}});
            p.setOnCompletionListener(mp->{if(player==mp&&ticket==generation)stop();});p.setOnErrorListener((mp,what,extra)->{if(player==mp&&ticket==generation){stop();if(error!=null)error.failed("Sound unavailable. Check the saved sound link / format.");}return true;});p.prepareAsync();
        }catch(Exception e){if(player==p)stop();if(error!=null)error.failed("Sound link could not be opened.");}
    }
    public void stop(){generation++;handler.removeCallbacksAndMessages(null);MediaPlayer old=player;player=null;if(old!=null){try{old.setOnPreparedListener(null);old.setOnCompletionListener(null);old.setOnErrorListener(null);old.release();}catch(Exception ignored){}}}
}
