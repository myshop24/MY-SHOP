package com.myshop.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.content.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

public class UserHistoryAdminActivity extends Activity {
  private LinearLayout body; private EditText search; private String token,userId="";
  private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
  private TextView tv(String s,float sp,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextColor(Color.BLACK);v.setTextSize(sp);v.setPadding(dp(12),dp(9),dp(12),dp(9));if(bold)v.setTypeface(null,android.graphics.Typeface.BOLD);return v;}
  @Override public void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)||!SessionManager.isAdminGateUnlocked()){finish();return;}token=SessionManager.getToken(this);build();}
  private void build(){
    ScrollView sc=new ScrollView(this);sc.setBackgroundColor(Color.WHITE);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(14),dp(18),dp(14),dp(30));sc.addView(body);
    body.addView(tv("USER HISTORY",24,true));body.addView(tv("User ID দিয়ে account, transaction, message ও audit history দেখুন।",12,false));
    LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);search=new EditText(this);search.setHint("User ID");search.setSingleLine(true);search.setTextColor(Color.BLACK);search.setHintTextColor(Color.GRAY);
    Button go=new Button(this);go.setText("SEARCH");r.addView(search,new LinearLayout.LayoutParams(0,dp(54),1));r.addView(go,new LinearLayout.LayoutParams(dp(110),dp(54)));body.addView(r);go.setOnClickListener(v->load());
    setContentView(sc);
  }
  private void load(){
    userId=search.getText().toString().trim(); if(!userId.matches("\\d{4}")){Toast.makeText(this,"Valid User ID দিন",Toast.LENGTH_SHORT).show();return;}
    BackendClient.adminUserAudit(token,userId,new BackendClient.Callback(){
      public void onSuccess(JSONObject d){runOnUiThread(()->render(d));}
      public void onError(String e){runOnUiThread(()->Toast.makeText(UserHistoryAdminActivity.this,e,Toast.LENGTH_LONG).show());}
    });
  }
  private void render(JSONObject d){
    while(body.getChildCount()>3)body.removeViewAt(3);
    JSONObject u=d.optJSONObject("user"),s=d.optJSONObject("summary");
    if(u==null)return;
    body.addView(tv((u.optString("full_name","User")+"  •  ID "+u.optString("user_id")),18,true));
    body.addView(tv("Account: "+(u.optInt("active",1)==1?"ACTIVE":"INACTIVE")+"   •   Joined: "+u.optString("created_at","—"),12,false));
    if(s!=null)body.addView(tv("Incoming: "+s.optDouble("incoming",0)+"   Outgoing: "+s.optDouble("outgoing",0)+"   Fees: "+s.optDouble("fees",0),13,true));
    JSONArray tx=d.optJSONArray("transactions");body.addView(tv("TRANSACTIONS ("+(tx==null?0:tx.length())+")",15,true));
    if(tx!=null)for(int i=0;i<Math.min(tx.length(),100);i++){JSONObject x=tx.optJSONObject(i);if(x!=null)body.addView(tv("#"+x.optString("id")+"  "+x.optString("tx_type")+"  "+x.optString("currency")+"  "+x.optString("gross_amount")+"  "+x.optString("status")+"\\n"+x.optString("created_at"),11,false));}
    JSONArray ms=d.optJSONArray("messages");body.addView(tv("MESSAGE ACTIVITY ("+(ms==null?0:ms.length())+")",15,true));
    if(ms!=null)for(int i=0;i<Math.min(ms.length(),50);i++){JSONObject x=ms.optJSONObject(i);if(x!=null)body.addView(tv(x.optString("sender_id")+" → "+x.optString("receiver_id")+"   "+x.optString("created_at"),11,false));}
    body.addView(tv("ADMIN CONTROLS",15,true));
    LinearLayout ar=new LinearLayout(this);String[][] acts={{"BAN","ban_user"},{"UNBAN","unban_user"},{"BLOCK","block_user"},{"UNBLOCK","unblock_user"}};
    for(String[] a:acts){Button z=new Button(this);z.setText(a[0]);z.setOnClickListener(v->confirm(a[1]));ar.addView(z,new LinearLayout.LayoutParams(0,dp(48),1));}body.addView(ar);
    Button membership=new Button(this);membership.setText("MEMBERSHIP MANAGEMENT");membership.setOnClickListener(v->startActivity(new Intent(this,MembershipAdminActivity.class).putExtra("userId",userId)));body.addView(membership);
    Button wallet=new Button(this);wallet.setText("COIN / DIAMOND / BENEFIT");wallet.setOnClickListener(v->startActivity(new Intent(this,AdminWalletActivity.class).putExtra("userId",userId)));body.addView(wallet);
  }
  private void confirm(String action){new MyShopDialogBuilder(this).setTitle("Confirm admin action").setMessage(action+" • User "+userId).setNegativeButton(UiStrings.label(UserHistoryAdminActivity.this,"Cancel"),null).setPositiveButton("Confirm",(d,w)->BackendClient.adminAction(token,userId,action,new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->{Toast.makeText(UserHistoryAdminActivity.this,"Saved",Toast.LENGTH_SHORT).show();load();});}public void onError(String e){runOnUiThread(()->Toast.makeText(UserHistoryAdminActivity.this,e,Toast.LENGTH_LONG).show());}})).show();}
}
