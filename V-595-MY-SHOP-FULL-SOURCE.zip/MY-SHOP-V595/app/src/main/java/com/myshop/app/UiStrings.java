package com.myshop.app;
import android.content.Context;
import java.util.HashMap;
/** Local, curated system labels only. Never processes user messages, names or posts. */
public final class UiStrings {
 private static final HashMap<String,String[]> WORDS=new HashMap<>();static {
WORDS.put("All",new String[]{"All","সব","सभी","الكل"});
WORDS.put("Unread",new String[]{"Unread","অপঠিত","अपठित","غير مقروء"});
WORDS.put("New",new String[]{"New","নতুন","नया","جديد"});
WORDS.put("Messages",new String[]{"Messages","বার্তা","संदेश","الرسائل"});
WORDS.put("Chat settings",new String[]{"Chat settings","চ্যাট সেটিংস","चैट सेटिंग","إعدادات الدردشة"});
WORDS.put("Show Active Status",new String[]{"Show Active Status","সক্রিয় অবস্থা দেখান","सक्रिय स्थिति दिखाएँ","إظهار الحالة النشطة"});
WORDS.put("Mute notifications",new String[]{"Mute notifications","নোটিফিকেশন বন্ধ","सूचनाएँ म्यूट करें","كتم الإشعارات"});
WORDS.put("View profile",new String[]{"View profile","প্রোফাইল দেখুন","प्रोफ़ाइल देखें","عرض الملف"});
WORDS.put("Block / Report",new String[]{"Block / Report","ব্লক / রিপোর্ট","ब्लॉक / रिपोर्ट","حظر / إبلاغ"});
WORDS.put("Close",new String[]{"Close","বন্ধ","बंद","إغلاق"});
WORDS.put("Cancel",new String[]{"Cancel","বাতিল","रद्द करें","إلغاء"});
WORDS.put("Save",new String[]{"Save","সংরক্ষণ","सहेजें","حفظ"});
WORDS.put("Delete",new String[]{"Delete","মুছুন","हटाएँ","حذف"});
WORDS.put("Edit",new String[]{"Edit","সম্পাদনা","संपादित करें","تعديل"});
WORDS.put("Search",new String[]{"Search","খুঁজুন","खोजें","بحث"});
WORDS.put("New Message",new String[]{"New Message","নতুন বার্তা","नया संदेश","رسالة جديدة"});
WORDS.put("Search Messages",new String[]{"Search Messages","বার্তা খুঁজুন","संदेश खोजें","بحث الرسائل"});
WORDS.put("Open Chat",new String[]{"Open Chat","চ্যাট খুলুন","चैट खोलें","فتح الدردشة"});
WORDS.put("Name, ID or message",new String[]{"Name, ID or message","নাম, আইডি বা বার্তা","नाम, आईडी या संदेश","الاسم أو المعرّف أو الرسالة"});
WORDS.put("Message…",new String[]{"Message…","বার্তা…","संदेश…","رسالة…"});
WORDS.put("Online",new String[]{"Online","অনলাইন","ऑनलाइन","متصل"});
WORDS.put("Offline",new String[]{"Offline","অফলাইন","ऑफ़लाइन","غير متصل"});
WORDS.put("Connecting…",new String[]{"Connecting…","সংযোগ হচ্ছে…","कनेक्ट हो रहा है…","جارٍ الاتصال…"});
WORDS.put("Updating…",new String[]{"Updating…","আপডেট হচ্ছে…","अपडेट हो रहा है…","جارٍ التحديث…"});
WORDS.put("All messages read",new String[]{"All messages read","সব বার্তা পড়া হয়েছে","सभी संदेश पढ़े गए","تمت قراءة كل الرسائل"});
WORDS.put("No unread messages",new String[]{"No unread messages","অপঠিত বার্তা নেই","कोई अपठित संदेश नहीं","لا رسائل غير مقروءة"});
WORDS.put("No conversations yet",new String[]{"No conversations yet","এখনও কোনো চ্যাট নেই","अभी कोई बातचीत नहीं","لا توجد محادثات بعد"});
WORDS.put("Loading conversations…",new String[]{"Loading conversations…","চ্যাট লোড হচ্ছে…","बातचीत लोड हो रही है…","جارٍ تحميل المحادثات…"});
WORDS.put("Loading messages…",new String[]{"Loading messages…","বার্তা লোড হচ্ছে…","संदेश लोड हो रहे हैं…","جارٍ تحميل الرسائل…"});
WORDS.put("Media options",new String[]{"Media options","মিডিয়া অপশন","मीडिया विकल्प","خيارات الوسائط"});
WORDS.put("Photo",new String[]{"Photo","ছবি","फ़ोटो","صورة"});
WORDS.put("Video",new String[]{"Video","ভিডিও","वीडियो","فيديو"});
WORDS.put("Camera",new String[]{"Camera","ক্যামেরা","कैमरा","الكاميرا"});
WORDS.put("Voice",new String[]{"Voice","ভয়েস","आवाज़","صوت"});
WORDS.put("File",new String[]{"File","ফাইল","फ़ाइल","ملف"});
WORDS.put("Share link",new String[]{"Share link","লিংক শেয়ার","लिंक साझा करें","مشاركة رابط"});
WORDS.put("Send",new String[]{"Send","পাঠান","भेजें","إرسال"});
WORDS.put("Home",new String[]{"Home","হোম","होम","الرئيسية"});
WORDS.put("My Shop",new String[]{"My Shop","মাই শপ","माय शॉप","متجري"});
WORDS.put("Go Live",new String[]{"Go Live","লাইভ যান","लाइव जाएँ","ابدأ البث"});
WORDS.put("Live",new String[]{"Live","লাইভ","लाइव","مباشر"});
WORDS.put("Support",new String[]{"Support","সাপোর্ট","सहायता","الدعم"});
WORDS.put("More Apps",new String[]{"More Apps","আরও অ্যাপস","और ऐप्स","المزيد من التطبيقات"});
WORDS.put("Media",new String[]{"Media","মিডিয়া","मीडिया","الوسائط"});
WORDS.put("Membership",new String[]{"Membership","মেম্বারশিপ","सदस्यता","العضوية"});
WORDS.put("General",new String[]{"General","সাধারণ","सामान्य","عام"});
WORDS.put("History",new String[]{"History","ইতিহাস","इतिहास","السجل"});
WORDS.put("Games",new String[]{"Games","গেমস","खेल","الألعاب"});
WORDS.put("Earn",new String[]{"Earn","আয়","कमाएँ","اربح"});
WORDS.put("Following",new String[]{"Following","ফলো করছি","फ़ॉलो कर रहे हैं","المتابَعون"});
WORDS.put("New",new String[]{"New","নতুন","नया","جديد"});
WORDS.put("Explore",new String[]{"Explore","খুঁজে দেখুন","खोजें","استكشاف"});
WORDS.put("LIVE NOW",new String[]{"LIVE NOW","এখন লাইভ","अभी लाइव","مباشر الآن"});
WORDS.put("My Feed",new String[]{"My Feed","মাই ফিড","मेरी फ़ीड","خلاصتي"});
WORDS.put("What's on your mind?",new String[]{"What's on your mind?","কী ভাবছেন?","आप क्या सोच रहे हैं?","بم تفكر؟"});
WORDS.put("Write a comment…",new String[]{"Write a comment…","কমেন্ট লিখুন…","टिप्पणी लिखें…","اكتب تعليقًا…"});
WORDS.put("Write a comment...",new String[]{"Write a comment...","কমেন্ট লিখুন…","टिप्पणी लिखें…","اكتب تعليقًا…"});
WORDS.put("Post",new String[]{"Post","পোস্ট","पोस्ट","نشر"});
WORDS.put("Like",new String[]{"Like","লাইক","पसंद","إعجاب"});
WORDS.put("Comment",new String[]{"Comment","কমেন্ট","टिप्पणी","تعليق"});
WORDS.put("Share",new String[]{"Share","শেয়ার","साझा करें","مشاركة"});
WORDS.put("Profile",new String[]{"Profile","প্রোফাইল","प्रोफ़ाइल","الملف الشخصي"});
WORDS.put("Edit Profile",new String[]{"Edit Profile","প্রোফাইল সম্পাদনা","प्रोफ़ाइल संपादित करें","تعديل الملف"});
WORDS.put("Share Profile",new String[]{"Share Profile","প্রোফাইল শেয়ার","प्रोफ़ाइल साझा करें","مشاركة الملف"});
WORDS.put("My Wallet",new String[]{"My Wallet","মাই ওয়ালেট","मेरा वॉलेट","محفظتي"});
WORDS.put("Wallet",new String[]{"Wallet","ওয়ালেট","वॉलेट","المحفظة"});
WORDS.put("Personal details",new String[]{"Personal details","ব্যক্তিগত তথ্য","व्यक्तिगत जानकारी","التفاصيل الشخصية"});
WORDS.put("Links",new String[]{"Links","লিংক","लिंक","الروابط"});
WORDS.put("Education",new String[]{"Education","শিক্ষা","शिक्षा","التعليم"});
WORDS.put("Photos",new String[]{"Photos","ছবি","फ़ोटो","الصور"});
WORDS.put("Videos",new String[]{"Videos","ভিডিও","वीडियो","الفيديوهات"});
WORDS.put("Posts",new String[]{"Posts","পোস্ট","पोस्ट","المنشورات"});
WORDS.put("Friends",new String[]{"Friends","বন্ধু","मित्र","الأصدقاء"});
WORDS.put("Followers",new String[]{"Followers","ফলোয়ার","फ़ॉलोअर","المتابعون"});
WORDS.put("Likes",new String[]{"Likes","লাইক","पसंद","الإعجابات"});
WORDS.put("Notifications",new String[]{"Notifications","নোটিফিকেশন","सूचनाएँ","الإشعارات"});
WORDS.put("Settings",new String[]{"Settings","সেটিংস","सेटिंग","الإعدادات"});
WORDS.put("Menu",new String[]{"Menu","মেনু","मेन्यू","القائمة"});
WORDS.put("Admin",new String[]{"Admin","এডমিন","व्यवस्थापक","المسؤول"});
WORDS.put("Quick Links • See All",new String[]{"Quick Links • See All","দ্রুত লিংক • সব দেখুন","त्वरित लिंक • सभी देखें","روابط سريعة • عرض الكل"});
WORDS.put("Light mode",new String[]{"Light mode","লাইট মোড","लाइट मोड","الوضع الفاتح"});
WORDS.put("Dark mode",new String[]{"Dark mode","ডার্ক মোড","डार्क मोड","الوضع الداكن"});
WORDS.put("Highlight Fee & Host Share",new String[]{"Highlight Fee & Host Share","হাইলাইট ফি ও হোস্টের অংশ","हाइलाइट शुल्क और होस्ट हिस्सा","رسوم التمييز وحصة المضيف"});
WORDS.put("Enable host share",new String[]{"Enable host share","হোস্টের অংশ চালু","होस्ट का हिस्सा सक्षम करें","تفعيل حصة المضيف"});
WORDS.put("Highlight comment fee (Coins)",new String[]{"Highlight comment fee (Coins)","হাইলাইট কমেন্ট ফি (কয়েন)","हाइलाइट टिप्पणी शुल्क (कॉइन)","رسوم تعليق مميز (عملات)"});
WORDS.put("Host share (%)",new String[]{"Host share (%)","হোস্টের অংশ (%)","होस्ट का हिस्सा (%)","حصة المضيف (%)"});
WORDS.put("No one is live right now",new String[]{"No one is live right now","এখন কেউ লাইভে নেই","अभी कोई लाइव नहीं है","لا أحد يبث الآن"});
WORDS.put("Live rooms will appear here automatically when a host goes live.",new String[]{"Live rooms will appear here automatically when a host goes live.","হোস্ট লাইভে এলে এখানে রুম দেখা যাবে।","होस्ट के लाइव होने पर यहाँ कमरे दिखेंगे।","ستظهر الغرف هنا عندما يبدأ المضيف البث."});
WORDS.put("Loading gifts…",new String[]{"Loading gifts…","গিফট লোড হচ্ছে…","उपहार लोड हो रहे हैं…","جارٍ تحميل الهدايا…"});
WORDS.put("Could not load gifts. Tap to retry.",new String[]{"Could not load gifts. Tap to retry.","গিফট লোড হয়নি। আবার চেষ্টা করতে চাপুন।","उपहार लोड नहीं हुए। फिर कोशिश करें।","تعذر تحميل الهدايا. اضغط للمحاولة مجددًا."});
WORDS.put("No published gifts in this catalog.",new String[]{"No published gifts in this catalog.","এই ক্যাটালগে প্রকাশিত গিফট নেই।","इस सूची में प्रकाशित उपहार नहीं हैं।","لا توجد هدايا منشورة في هذه القائمة."});
WORDS.put("Select recipients",new String[]{"Select recipients","প্রাপক নির্বাচন করুন","प्राप्तकर्ता चुनें","اختر المستلمين"});
WORDS.put("Choose recipients and quantity",new String[]{"Choose recipients and quantity","প্রাপক ও পরিমাণ নির্বাচন করুন","प्राप्तकर्ता और मात्रा चुनें","اختر المستلمين والكمية"});
WORDS.put("Select a gift",new String[]{"Select a gift","গিফট নির্বাচন করুন","उपहार चुनें","اختر هدية"});
WORDS.put("SEND",new String[]{"SEND","পাঠান","भेजें","إرسال"});
WORDS.put("🎁  SEND A GIFT",new String[]{"🎁  SEND A GIFT","🎁  গিফট পাঠান","🎁  उपहार भेजें","🎁  أرسل هدية"});
}
 public static void cache(Context c,org.json.JSONArray rows){android.content.SharedPreferences.Editor e=c.getSharedPreferences("myshop_translations",0).edit();if(rows==null)return; e.clear();if(rows!=null)for(int i=0;i<rows.length();i++){org.json.JSONObject x=rows.optJSONObject(i);if(x!=null)e.putString(x.optString("content_key")+"_"+x.optString("language"),x.optString("value"));}e.apply();}
 public static String content(Context c,String key,String fallback){String v=c.getSharedPreferences("myshop_translations",0).getString(key+"_"+LanguageManager.get(c),"");return v.isEmpty()?label(c,fallback):v;}
 public static String[] labels(Context c,String[] source){String[] result=source.clone();for(int i=0;i<result.length;i++)result[i]=label(c,result[i]);return result;}
 private UiStrings(){}
 public static String label(Context c,String original){String[] v=WORDS.get(original);if(v==null)return original;String l=LanguageManager.get(c);return v["bn".equals(l)?1:"hi".equals(l)?2:"ar".equals(l)?3:0];}
 public static String localized(Context c,org.json.JSONObject object,String key){if(object==null)return "";String v=object.optString(key+"_"+LanguageManager.get(c),"").trim();return v.isEmpty()?object.optString(key,""):v;}
}
