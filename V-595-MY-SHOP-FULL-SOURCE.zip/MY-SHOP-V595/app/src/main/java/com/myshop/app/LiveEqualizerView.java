package com.myshop.app;
import android.content.Context;import android.graphics.*;import android.view.View;
/** Decorative activity bars, never represented as real audio metering. */
public final class LiveEqualizerView extends View {private final Paint p=new Paint(3);public LiveEqualizerView(Context c){super(c);setContentDescription("Live activity animation");}@Override protected void onDraw(Canvas c){super.onDraw(c);p.setColor(0xff43d7e6);float w=getWidth()/7f,h=getHeight(),t=android.os.SystemClock.uptimeMillis()/240f;for(int i=0;i<3;i++){float height=h*(.25f+.6f*(.5f+.5f*(float)Math.sin(t+i*1.8)));c.drawRoundRect((i*2+1)*w,h-height,(i*2+2)*w,h,w/3,w/3,p);}if(isShown())postInvalidateDelayed(70);}}
