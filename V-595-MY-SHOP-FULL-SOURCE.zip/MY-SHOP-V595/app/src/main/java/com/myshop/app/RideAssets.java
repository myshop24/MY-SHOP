package com.myshop.app;
import android.content.Context;
import org.json.JSONObject;
import java.util.Locale;
/** Bundled defaults never overwrite the Admin's published sound or artwork. */
public final class RideAssets {
 private RideAssets(){}
 public static boolean video(JSONObject x){String u=x.optString("animation_url").toLowerCase(Locale.US).split("\\?",2)[0];return x.optString("animation_mime").startsWith("video/")||u.endsWith(".mp4")||u.endsWith(".webm");}
 private static String key(JSONObject x){return (x.optString("item_code",x.optString("code"))+" "+x.optString("title")).toUpperCase(Locale.US);}
 public static String sound(Context c,JSONObject x){String saved=x.optString("sound_url","").trim();if(!saved.isEmpty()||video(x))return saved;String k=key(x);int raw=0;
  if(k.contains("BICYCLE"))raw=R.raw.ride_bicycle;
  else if(k.contains("MOTOR")||k.contains("BIKE"))raw=R.raw.ride_motorcycle;
  else if(k.contains("CAR")||k.contains("LIMO"))raw=R.raw.ride_car;
  else if(k.contains("HELICOPTER"))raw=R.raw.ride_helicopter;
  else if(k.contains("JET"))raw=R.raw.ride_jet;
  else if(k.contains("ROCKET")||k.contains("SPACESHIP"))raw=R.raw.ride_rocket;
  else if(k.contains("HORSE")||k.contains("CHARIOT"))raw=R.raw.ride_horse;
  else if(k.contains("BOAT"))raw=R.raw.ride_boat;
  else if(k.contains("UFO"))raw=R.raw.ride_ufo;
  else if(k.contains("DRAGON"))raw=R.raw.gift_v381_golden_dragon_sound;
  else if(k.contains("EAGLE"))raw=R.raw.ride_eagle;
  else if(k.contains("TIGER"))raw=R.raw.ride_tiger;
  else if(k.contains("CLOUD"))raw=R.raw.ride_cloud;
  else if(k.contains("LION"))raw=R.raw.gift_v381_lion_king_sound;
  else if(k.contains("PHOENIX"))raw=R.raw.gift_v381_phoenix_fire_sound;
  else if(k.contains("UNICORN"))raw=R.raw.gift_v375_rainbow_unicorn_sound;
  else if(k.contains("PORTAL"))raw=R.raw.gift_v375_time_portal_sound;
  else if(k.contains("BALLOON"))raw=R.raw.gift_v375_love_balloons_sound;
  return raw==0?"":"android.resource://"+c.getPackageName()+"/"+raw;
 }
 public static int art(JSONObject x){String k=key(x);if(k.contains("MOTOR")||k.contains("BIKE"))return R.drawable.gift_v381_super_bike;if(k.contains("CAR")||k.contains("LIMO"))return R.drawable.gift_v381_luxury_car;if(k.contains("JET"))return R.drawable.gift_v381_private_jet;if(k.contains("DRAGON"))return R.drawable.gift_v381_golden_dragon;if(k.contains("LION"))return R.drawable.gift_v381_lion_king;if(k.contains("PHOENIX"))return R.drawable.gift_v381_phoenix_fire;if(k.contains("PORTAL"))return R.drawable.gift_v375_time_portal;if(k.contains("BALLOON"))return R.drawable.gift_v381_balloon_blast;return 0;}
 public static String symbol(JSONObject x){String k=key(x);if(k.contains("BICYCLE"))return "🚲";if(k.contains("HELICOPTER"))return "🚁";if(k.contains("ROCKET")||k.contains("SPACESHIP"))return "🚀";if(k.contains("HORSE")||k.contains("CHARIOT"))return "🐎";if(k.contains("UNICORN"))return "🦄";if(k.contains("BOAT"))return "🚤";if(k.contains("UFO"))return "🛸";if(k.contains("EAGLE"))return "🦅";if(k.contains("TIGER"))return "🐯";if(k.contains("CLOUD"))return "☁";return "✨";}
}
