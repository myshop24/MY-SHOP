package com.myshop.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.LinkedHashMap;

/** Owner appearance editor. It never changes routes, data, Live, or Profile layout. */
public final class VisualDesign {
    private static final java.util.Set<String> SCOPES=new java.util.HashSet<>(java.util.Arrays.asList("user_menu","profile_menu","home_quick","home_general","shop","withdrawal","home_header","media_center","profile_settings","wallet"));
    private static boolean owner(Activity a){return AuthorityBadge.isAuthority(SessionManager.getUserId(a))&&SessionManager.isAdmin(a);}
    private static int dp(Activity a,int n){return Math.round(n*a.getResources().getDisplayMetrics().density);}
    private static final class Original {
        final View view;final Drawable background;final float elevation,rotation,alpha;final int[] padding;final int iconWidth,iconHeight;final ImageView.ScaleType imageScale;
        final CharSequence text;final android.content.res.ColorStateList textColor;final float font;final Shader shader;final android.graphics.ColorFilter iconFilter;
        Original(View v){iconWidth=v.getLayoutParams()==null?0:v.getLayoutParams().width;iconHeight=v.getLayoutParams()==null?0:v.getLayoutParams().height;imageScale=v instanceof ImageView?((ImageView)v).getScaleType():null;view=v;background=v.getBackground();elevation=v.getElevation();rotation=v.getRotation();alpha=v.getAlpha();padding=new int[]{v.getPaddingLeft(),v.getPaddingTop(),v.getPaddingRight(),v.getPaddingBottom()};
            iconFilter=v instanceof ImageView?((ImageView)v).getColorFilter():null;TextView t=v instanceof TextView?(TextView)v:null;text=t==null?null:t.getText();textColor=t==null?null:t.getTextColors();font=t==null?0:t.getTextSize();shader=t==null?null:t.getPaint().getShader();}
        void restore(){view.setTag(R.id.visual_design_active,null);view.setBackground(background);view.setElevation(elevation);view.setRotation(rotation);view.setAlpha(alpha);view.setPadding(padding[0],padding[1],padding[2],padding[3]);if(view instanceof TextView){TextView t=(TextView)view;if(t.getText() instanceof android.text.Spannable){android.text.Spannable current=(android.text.Spannable)t.getText();for(DesignColorSpan span:current.getSpans(0,current.length(),DesignColorSpan.class))current.removeSpan(span);for(DesignSizeSpan span:current.getSpans(0,current.length(),DesignSizeSpan.class))current.removeSpan(span);}t.setTextColor(textColor);t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX,font);t.getPaint().setShader(shader);t.invalidate();}if(view instanceof ImageView){ImageView image=(ImageView)view;image.setColorFilter(iconFilter);image.setScaleType(imageScale);ViewGroup.LayoutParams dimensions=image.getLayoutParams();if(dimensions!=null&&(dimensions.width!=iconWidth||dimensions.height!=iconHeight)){dimensions.width=iconWidth;dimensions.height=iconHeight;image.setLayoutParams(dimensions);}}}
    }
    private static final class DesignColorSpan extends ForegroundColorSpan {DesignColorSpan(int color){super(color);}}
    private static boolean segmentMatches(String text,JSONObject segment){if(segment.has("source"))return text.equals(segment.optString("source"));try{byte[] hash=java.security.MessageDigest.getInstance("SHA-256").digest(text.getBytes(java.nio.charset.StandardCharsets.UTF_8));StringBuilder hex=new StringBuilder();for(byte b:hash)hex.append(String.format(java.util.Locale.US,"%02x",b&255));return hex.toString().equals(segment.optString("sourceHash"));}catch(Exception e){return false;}}
    private static void gradientParts(SpannableString target,String source,int start,int end,int first,int last){
        java.util.ArrayList<Integer> points=new java.util.ArrayList<>();points.add(start);for(int n=start+1;n<end;n++)if(TextBoundaries.valid(source,n))points.add(n);points.add(end);
        for(int i=0;i<points.size()-1;i++){float ratio=points.size()>2?i/(float)(points.size()-2):.5f;int color=Color.rgb(Math.round(Color.red(first)+(Color.red(last)-Color.red(first))*ratio),Math.round(Color.green(first)+(Color.green(last)-Color.green(first))*ratio),Math.round(Color.blue(first)+(Color.blue(last)-Color.blue(first))*ratio));target.setSpan(new DesignColorSpan(color),points.get(i),points.get(i+1),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}
    }
    private static final class DesignSizeSpan extends android.text.style.AbsoluteSizeSpan {DesignSizeSpan(int size){super(size,true);}}
    private static final class State {
        final LinkedHashMap<String,String> aliases=new LinkedHashMap<>();final LinkedHashMap<String,Original> targets=new LinkedHashMap<>();JSONObject published=new JSONObject(),draft=new JSONObject();int revision,draftRevision;String savedDraft="{}",copiedStyle="";boolean editing,saving;int capacity=120;final java.util.ArrayDeque<String> undo=new java.util.ArrayDeque<>(),redo=new java.util.ArrayDeque<>();
    }
    private static void collect(State state,View v,String path){if(state.targets.size()>=state.capacity||path.split("/").length>13)return;Object key=v.getTag(R.id.visual_design_key);String stable=key instanceof String&&((String)key).matches("element_[a-z0-9_]{1,80}")?(String)key:path;state.targets.put(stable,new Original(v));if(!stable.equals(path))state.aliases.put(stable,path);if(v instanceof ViewGroup){ViewGroup group=(ViewGroup)v;for(int i=0;i<group.getChildCount();i++)collect(state,group.getChildAt(i),path+"/"+i);}}
    public static void apply(Activity a,View root,String scope){
        if(!SCOPES.contains(scope)||a instanceof LiveHomeActivity||a instanceof AudioLiveRoomActivity)return;
        Object previous=root.getTag(R.id.visual_design_state);if(previous instanceof State){Original original=((State)previous).targets.get("root");if(original!=null)original.restore();}State state=new State();if("profile_menu".equals(scope)||"user_menu".equals(scope))state.capacity=240;collect(state,root,"root");root.setTag(R.id.visual_design_state,state);
        try{state.published=new JSONObject(a.getSharedPreferences("visual_design575",0).getString(scope,"{}"));}catch(Exception ignored){}
        paint(a,state,state.published);
        BackendClient.visualDesign(SessionManager.getToken(a),scope,false,new BackendClient.Callback(){public void onSuccess(JSONObject d){a.runOnUiThread(()->{if(a.isFinishing()||a.isDestroyed()||root.getTag(R.id.visual_design_state)!=state||state.editing)return;state.published=d.optJSONObject("styles");if(state.published==null)state.published=new JSONObject();state.revision=d.optInt("revision");a.getSharedPreferences("visual_design575",0).edit().putString(scope,state.published.toString()).apply();paint(a,state,state.published);});}public void onError(String m){}});
        if(owner(a))root.setOnLongClickListener(v->{edit(a,root,scope);return true;});
        if(owner(a)&&SessionManager.isAdminGateUnlocked()&&!a.getIntent().hasExtra("menu_preview")&&scope.equals(a.getIntent().getStringExtra("open_design_scope"))){a.getIntent().removeExtra("open_design_scope");root.post(()->{if(!a.isFinishing()&&!a.isDestroyed()&&root.getTag(R.id.visual_design_state)==state)edit(a,root,scope);});}
    }
    public static boolean isEditing(View root){Object tag=root==null?null:root.getTag(R.id.visual_design_state);return tag instanceof State&&(((State)tag).editing||((State)tag).saving);}
    private static int color(JSONObject style,String key,int fallback){try{return Color.parseColor(style.optString(key));}catch(Exception e){return fallback;}}
    private static void paint(Activity a,State state,JSONObject styles){
        for(Original o:state.targets.values())o.restore();if(styles==null)return;
        for(String path:state.targets.keySet()){
            JSONObject s=styles.optJSONObject(path);if(s==null&&state.aliases.containsKey(path))s=styles.optJSONObject(state.aliases.get(path));if(s==null)continue;View v=state.targets.get(path).view;v.setTag(R.id.visual_design_active,Boolean.TRUE);
            if(s.has("rotation"))v.setRotation((float)s.optDouble("rotation"));if(s.has("opacity"))v.setAlpha((float)s.optDouble("opacity",1));
            if(s.has("background")||s.has("border")||s.has("radius")){
                GradientDrawable g=new GradientDrawable();if(s.has("backgroundEnd"))g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{color(s,"background",Color.WHITE),color(s,"backgroundEnd",Color.WHITE)});else g.setColor(color(s,"background",Color.TRANSPARENT));
                g.setCornerRadius(dp(a,s.optInt("radius",12)));g.setStroke(dp(a,s.optInt("borderWidth",1)),color(s,"border",Color.TRANSPARENT));v.setBackground(g);
            }
            if(s.has("padding")){int p=dp(a,s.optInt("padding"));v.setPadding(p,p,p,p);}
            if(s.has("shadow"))v.setElevation(dp(a,s.optInt("shadow")));
            if(v instanceof ImageView&&s.has("iconSize")){ViewGroup.LayoutParams size=v.getLayoutParams();if(size!=null){int requested=dp(a,Math.max(28,Math.min(56,s.optInt("iconSize",38))));if(v.getParent() instanceof View){View parent=(View)v.getParent();int available=parent.getWidth()-parent.getPaddingLeft()-parent.getPaddingRight();if(available>0)requested=Math.min(requested,available);}size.width=requested;size.height=requested;v.setLayoutParams(size);((ImageView)v).setScaleType(ImageView.ScaleType.CENTER_INSIDE);}}
            if(v instanceof ImageView&&s.has("icon"))((ImageView)v).setColorFilter(color(s,"icon",Color.WHITE));
            if(v instanceof TextView){TextView t=(TextView)v;
                if(s.has("fontSize"))t.setTextSize((float)s.optDouble("fontSize",14));
                if(s.has("text")){
                    String word=s.optString("word");int tint=color(s,"text",t.getCurrentTextColor());
                    if(!word.isEmpty()){String text=t.getText().toString();SpannableString span=new SpannableString(t.getText());int at=text.indexOf(word);while(at>=0){int wordStart=TextBoundaries.start(text,at),wordEnd=TextBoundaries.end(text,at+word.length());if(s.has("textEnd"))gradientParts(span,text,wordStart,wordEnd,tint,color(s,"textEnd",tint));else span.setSpan(new DesignColorSpan(tint),wordStart,wordEnd,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);at=text.indexOf(word,at+word.length());}t.setText(span);}
                    else{t.setTextColor(tint);if(s.has("textEnd"))t.getPaint().setShader(new LinearGradient(0,0,Math.max(1,t.getPaint().measureText(t.getText().toString())),0,tint,color(s,"textEnd",tint),Shader.TileMode.CLAMP));}
                }
                org.json.JSONArray segments=s.optJSONArray("segments");
                if(segments!=null){String current=t.getText().toString();SpannableString styled=new SpannableString(t.getText());for(int index=0;index<segments.length();index++){JSONObject part=segments.optJSONObject(index);if(part==null||!segmentMatches(current,part))continue;int start=part.optInt("start"),end=part.optInt("end");if(start<0||end<=start||end>current.length()||!TextBoundaries.valid(current,start)||!TextBoundaries.valid(current,end))continue;if(part.has("text")){int ink=color(part,"text",t.getCurrentTextColor());if(part.has("textEnd"))gradientParts(styled,current,start,end,ink,color(part,"textEnd",ink));else styled.setSpan(new DesignColorSpan(ink),start,end,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}if(part.has("fontSize"))styled.setSpan(new DesignSizeSpan(part.optInt("fontSize",14)),start,end,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}t.setText(styled);}
            }
        }
        Original original=state.targets.get("root");Object layout=original==null?null:original.view.getTag(R.id.visual_design_layout);if(layout instanceof Runnable)((Runnable)layout).run();
    }
    private static String name(String path,Original o){if(path.equals("root"))return "পুরো অংশের background";View v=o.view;CharSequence label=v instanceof TextView?((TextView)v).getText():v.getContentDescription();String text=label==null?"":label.toString().replace('\n',' ');if(text.length()>38)text=text.substring(0,38)+"…";return (text.isEmpty()?v.getClass().getSimpleName():text)+" • "+path;}
    public static void edit(Activity a,View root,String scope){
        if(!owner(a)||!SCOPES.contains(scope))return;
        State state=(State)root.getTag(R.id.visual_design_state);if(state==null){apply(a,root,scope);state=(State)root.getTag(R.id.visual_design_state);}if(state==null||state.editing||state.saving)return;
        final State data=state;data.editing=true;
        BackendClient.visualDesign(SessionManager.getToken(a),scope,true,new BackendClient.Callback(){public void onSuccess(JSONObject d){a.runOnUiThread(()->{if(a.isFinishing()||a.isDestroyed()||root.getTag(R.id.visual_design_state)!=data){data.editing=false;return;}data.revision=d.optInt("revision");data.draftRevision=d.optInt("draftRevision");data.published=d.optJSONObject("styles");data.draft=d.optJSONObject("draft");if(data.draft==null||data.draftRevision==0)data.draft=data.published==null?new JSONObject():data.published;for(String stable:data.aliases.keySet()){String old=data.aliases.get(stable);if(data.draft.has(old)&&!data.draft.has(stable)){try{data.draft.put(stable,data.draft.get(old));data.draft.remove(old);}catch(Exception ignored){}}}data.savedDraft=data.draft.toString();open(a,root,scope,data);});}public void onError(String m){a.runOnUiThread(()->{data.editing=false;if(a.isFinishing()||a.isDestroyed()||root.getTag(R.id.visual_design_state)!=data)return;Toast.makeText(a,m,Toast.LENGTH_LONG).show();});}});
    }
    private static void open(Activity a,View root,String scope,State data){
        LinearLayout box=new LinearLayout(a);box.setOrientation(1);box.setPadding(dp(a,12),dp(a,8),dp(a,12),dp(a,8));
        TextView explanation=new TextView(a);explanation.setText("১. যে অংশ বদলাবেন সেটি বাছুন\n২. রং/মাপ বাছুন\nPreview-তে আসল পেজ দেখুন। Draft অন্যদের দেখায় না।");box.addView(explanation);
        ArrayList<String> paths=new ArrayList<>(data.targets.keySet()),labels=new ArrayList<>();for(String path:paths)labels.add(name(path,data.targets.get(path)));
        Spinner target=new Spinner(a);target.setAdapter(new ArrayAdapter<>(a,android.R.layout.simple_spinner_dropdown_item,labels));box.addView(target);
        String[] props={"Background","Background gradient end","Text / selected word","Text gradient end","Border","Icon color"};String[] keys={"background","backgroundEnd","text","textEnd","border","icon"};Spinner property=new Spinner(a);property.setAdapter(new ArrayAdapter<>(a,android.R.layout.simple_spinner_dropdown_item,props));box.addView(property);
        EditText word=new EditText(a);word.setHint("শুধু কোনো শব্দে রং চাইলে লিখুন; ফাঁকা = পুরো লেখা");box.addView(word);
        TextView status=new TextView(a);status.setText("অংশ: "+scope+" • Published "+data.revision+" • Draft "+data.draftRevision);box.addView(status);
        Runnable preview=()->paint(a,data,data.draft);Runnable checkpoint=()->{data.undo.addLast(data.draft.toString());while(data.undo.size()>20)data.undo.removeFirst();data.redo.clear();};
        java.util.function.Function<String,JSONObject> style=path->{JSONObject s=data.draft.optJSONObject(path);if(s==null){s=new JSONObject();try{data.draft.put(path,s);}catch(Exception ignored){}}return s;};
        Button pick=new Button(a);pick.setText("রঙের চাকা • সাদা থেকে সব রং");box.addView(pick);pick.setOnClickListener(v->{String path=paths.get(target.getSelectedItemPosition()),key=keys[property.getSelectedItemPosition()];JSONObject s=style.apply(path);ColorPicker.show(a,color(s,key,Color.WHITE),selected->{try{checkpoint.run();s.put(key,String.format(java.util.Locale.US,"#%06X",selected&0xffffff));if(key.equals("text"))s.put("word",word.getText().toString().trim());preview.run();}catch(Exception ignored){}});});
        Button textParts=new Button(a);textParts.setText("অক্ষর / শব্দ বাছুন • আলাদা রং ও ফন্ট মাপ");box.addView(textParts);
        textParts.setOnClickListener(v->{String path=paths.get(target.getSelectedItemPosition());View chosen=data.targets.get(path).view;if(!(chosen instanceof TextView)||chosen instanceof EditText){status.setText("একটি লেখা বা আইকনের নাম বাছুন");return;}TextView label=(TextView)chosen;String source=label.getText().toString();if(source.isEmpty()||source.length()>2000){status.setText("এই লেখাটি নির্বাচন করা যাচ্ছে না");return;}
            LinearLayout form=new LinearLayout(a);form.setOrientation(1);form.setPadding(dp(a,12),dp(a,8),dp(a,12),dp(a,8));TextView hint=new TextView(a);hint.setText("লেখায় দীর্ঘ চাপ দিয়ে যে অংশ বদলাবেন বাছুন। লেখা সম্পাদনা হবে না।");form.addView(hint);EditText selection=new EditText(a);selection.setText(source);selection.setTextSize(17);selection.setSelectAllOnFocus(false);selection.setKeyListener(null);selection.setTextIsSelectable(true);form.addView(selection,new LinearLayout.LayoutParams(-1,dp(a,110)));
            final int[] ink={label.getCurrentTextColor()},endInk={ink[0]},size={Math.round(label.getTextSize()/a.getResources().getDisplayMetrics().scaledDensity)};final boolean[] useColor={false},useGradient={false},useSize={false};
            TextView example=new TextView(a);example.setText("নির্বাচিত অংশের Preview");form.addView(example);Button first=new Button(a);first.setText("রং বাছুন");form.addView(first);first.setOnClickListener(click->ColorPicker.show(a,ink[0],c->{ink[0]=c;useColor[0]=true;example.setTextColor(c);}));Button gradient=new Button(a);gradient.setText("Gradient • দ্বিতীয় রং");form.addView(gradient);gradient.setOnClickListener(click->ColorPicker.show(a,endInk[0],c->{endInk[0]=c;useColor[0]=true;useGradient[0]=true;example.getPaint().setShader(new LinearGradient(0,0,Math.max(1,example.getWidth()),0,ink[0],c,Shader.TileMode.CLAMP));example.invalidate();}));TextView measure=new TextView(a);measure.setText("ফন্ট: "+size[0]);form.addView(measure);SeekBar font=new SeekBar(a);font.setMax(39);font.setProgress(Math.max(0,Math.min(39,size[0]-9)));form.addView(font);font.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}public void onProgressChanged(SeekBar b,int n,boolean user){if(user){size[0]=n+9;useSize[0]=true;measure.setText("ফন্ট: "+size[0]);example.setTextSize(size[0]);}}});
            androidx.appcompat.app.AlertDialog parts=new MyShopCompatDialogBuilder(a).setTitle("নির্বাচিত অংশের ডিজাইন").setView(form).setPositiveButton("Apply to Draft",null).setNegativeButton("Cancel",null).create();parts.show();parts.getButton(-1).setOnClickListener(click->{int start=selection.getSelectionStart(),end=selection.getSelectionEnd();if(start>end){int swap=start;start=end;end=swap;}if(start<0||end<=start||!useColor[0]&&!useSize[0]){hint.setText("আগে অংশ নির্বাচন এবং রং বা ফন্ট মাপ বাছুন");return;}start=TextBoundaries.start(source,start);end=TextBoundaries.end(source,end);try{JSONObject selectedStyle=style.apply(path);org.json.JSONArray segments=selectedStyle.optJSONArray("segments");if(segments==null)segments=new org.json.JSONArray();if(segments.length()>=32){hint.setText("সর্বোচ্চ ৩২টি অংশ • Reset করে আবার বাছুন");return;}checkpoint.run();JSONObject segment=new JSONObject().put("source",source).put("start",start).put("end",end);if(useColor[0])segment.put("text",String.format(java.util.Locale.US,"#%06X",ink[0]&0xffffff));if(useGradient[0])segment.put("textEnd",String.format(java.util.Locale.US,"#%06X",endInk[0]&0xffffff));if(useSize[0])segment.put("fontSize",size[0]);segments.put(segment);selectedStyle.put("segments",segments);preview.run();status.setText("নির্বাচিত অংশ বদলেছে • Preview দেখে Draft Save করুন");parts.dismiss();}catch(Exception e){hint.setText("পরিবর্তন প্রয়োগ হয়নি");}});
        });
        String[] sizes={"Font size","Corner radius","Shadow","Spacing","Border width","Rotate","Opacity %","আইকন / ইমোজির মাপ"},sizeKeys={"fontSize","radius","shadow","padding","borderWidth","rotation","opacity","iconSize"};int[] minimum={9,0,0,0,0,-180,20,28},maximum={28,32,8,20,3,180,100,56};Spinner dimension=new Spinner(a);dimension.setAdapter(new ArrayAdapter<>(a,android.R.layout.simple_spinner_dropdown_item,sizes));box.addView(dimension);
        SeekBar amount=new SeekBar(a);box.addView(amount);TextView dimensionValue=new TextView(a);box.addView(dimensionValue);
        Runnable syncDimension=()->{int n=dimension.getSelectedItemPosition();String path=paths.get(target.getSelectedItemPosition());JSONObject selected=data.draft.optJSONObject(path);Original original=data.targets.get(path);double fallback=n==0?(original.font>0?original.font/a.getResources().getDisplayMetrics().scaledDensity:14):n==1?12:n==4?1:n==5?original.rotation:n==6?original.alpha:n==7?(original.iconWidth>0?original.iconWidth/a.getResources().getDisplayMetrics().density:38):0;double value=selected==null?fallback:selected.optDouble(sizeKeys[n],fallback);if(n==6)value*=100;int bounded=Math.max(minimum[n],Math.min(maximum[n],(int)Math.round(value)));amount.setMax(maximum[n]-minimum[n]);amount.setProgress(bounded-minimum[n]);dimensionValue.setText(sizes[n]+": "+bounded+(n==6?"%":""));};
        AdapterView.OnItemSelectedListener syncSelection=new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int n,long id){syncDimension.run();}public void onNothingSelected(AdapterView<?> p){}};dimension.setOnItemSelectedListener(syncSelection);target.setOnItemSelectedListener(syncSelection);syncDimension.run();amount.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){checkpoint.run();}public void onStopTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar seek,int n,boolean user){if(!user)return;int at=dimension.getSelectedItemPosition();if(at==7&&!(data.targets.get(paths.get(target.getSelectedItemPosition())).view instanceof ImageView)){status.setText("আগে আইকন / ছবির অংশ বাছুন");return;}dimensionValue.setText(sizes[at]+": "+(n+minimum[at])+(at==6?"%":""));try{style.apply(paths.get(target.getSelectedItemPosition())).put(sizeKeys[at],at==6?(n+minimum[at])/100.0:n+minimum[at]);preview.run();}catch(Exception ignored){}}});
        Button view=new Button(a);view.setText("আসল পেজে Preview");box.addView(view);
        Button selectOnPage=new Button(a);selectOnPage.setText("আসল পেজে চাপ দিয়ে অংশ বাছুন");box.addView(selectOnPage);
        Button history=new Button(a);history.setText("প্রকাশিত ডিজাইনের History / Restore");box.addView(history);
        history.setOnClickListener(v->BackendClient.visualDesignHistory(SessionManager.getToken(a),scope,new BackendClient.Callback(){
            public void onSuccess(JSONObject result){a.runOnUiThread(()->{
                if(a.isFinishing()||a.isDestroyed()||root.getTag(R.id.visual_design_state)!=data||!data.editing)return;
                org.json.JSONArray rows=result.optJSONArray("history");if(rows==null||rows.length()==0){status.setText("প্রকাশিত History নেই");return;}
                String[] names=new String[rows.length()];for(int i=0;i<rows.length();i++){JSONObject row=rows.optJSONObject(i);names[i]="Version "+row.optInt("revision")+" • "+row.optString("created_at");}
                new MyShopDialogBuilder(a).setTitle("আগের ডিজাইন বাছুন").setItems(names,(d,index)->new MyShopDialogBuilder(a).setTitle("Draft-এ Restore করবেন?").setMessage("বর্তমান প্রকাশিত পেজ বদলাবে না। Restore-এর পরে Preview করে আলাদা Publish করুন। Unsaved পরিবর্তন বদলে যাবে।").setNegativeButton("Cancel",null).setPositiveButton("Restore Draft",(confirm,n)->{
                    try{JSONObject request=new JSONObject().put("scope",scope).put("action","RESTORE_DRAFT").put("expectedRevision",data.revision).put("expectedDraftRevision",data.draftRevision).put("eventId",rows.optJSONObject(index).optLong("id"));
                    if(data.saving)return;data.saving=true;setControlsEnabled(box,false);
                    BackendClient.visualDesignSave(SessionManager.getToken(a),request,new BackendClient.Callback(){public void onSuccess(JSONObject saved){a.runOnUiThread(()->{data.saving=false;if(a.isFinishing()||a.isDestroyed()||root.getTag(R.id.visual_design_state)!=data||!data.editing)return;setControlsEnabled(box,true);data.revision=saved.optInt("revision");data.draftRevision=saved.optInt("draftRevision");data.draft=saved.optJSONObject("draft");data.savedDraft=data.draft.toString();preview.run();status.setText("Draft Restore হয়েছে • Preview করে Publish করুন");});}public void onError(String m){a.runOnUiThread(()->{data.saving=false;if(!a.isFinishing()&&!a.isDestroyed()&&root.getTag(R.id.visual_design_state)==data&&data.editing){setControlsEnabled(box,true);status.setText(m);}});}});
                    }catch(Exception e){data.saving=false;setControlsEnabled(box,true);status.setText("Restore হয়নি");}
                }).show()).show();
            });}
            public void onError(String m){a.runOnUiThread(()->{if(!a.isFinishing()&&!a.isDestroyed()&&root.getTag(R.id.visual_design_state)==data&&data.editing)status.setText(m);});}
        }));
        Button all=new Button(a);all.setText("বাছাই করা রং এই অংশের সব একই ধরনের উপাদানে");box.addView(all);
        all.setOnClickListener(v->{String key=keys[property.getSelectedItemPosition()];JSONObject chosen=data.draft.optJSONObject(paths.get(target.getSelectedItemPosition()));
            if(chosen==null||!chosen.has(key)){status.setText("আগে বাছাই করা অংশে এই রং সেট করুন।");return;}
            final String value=chosen.optString(key);
            new MyShopDialogBuilder(a).setTitle("এই অংশে সব জায়গায় রং লাগাবেন?").setMessage("শুধু বর্তমান অংশে বাছাই করা ধরনের রং বদলাবে। অন্য পেজ বদলাবে না। Preview দেখে Draft Save ও Publish করুন।")
                .setNegativeButton("Cancel",null).setPositiveButton("Apply",(d,n)->{checkpoint.run();try{int count=0;
                    for(String path:paths){View item=data.targets.get(path).view;
                        if((key.equals("text")||key.equals("textEnd"))&&!(item instanceof TextView))continue;
                        if(key.equals("icon")&&!(item instanceof ImageView))continue;
                        style.apply(path).put(key,value);count++;
                    }
                    preview.run();status.setText(count+"টি অংশে রং লাগানো হয়েছে • Preview দেখুন");
                }catch(Exception ignored){status.setText("রং লাগানো হয়নি।");}}).show();
        });
        Button reset=new Button(a);reset.setText("বাছাই করা অংশ Reset");box.addView(reset);reset.setOnClickListener(v->{checkpoint.run();data.draft.remove(paths.get(target.getSelectedItemPosition()));preview.run();syncDimension.run();});
        LinearLayout styleTools=new LinearLayout(a);box.addView(styleTools);
        Button copy=new Button(a);copy.setText("Copy style");styleTools.addView(copy);copy.setOnClickListener(v->{JSONObject selected=data.draft.optJSONObject(paths.get(target.getSelectedItemPosition()));data.copiedStyle=selected==null?"{}":selected.toString();status.setText("Style copied • এবার অন্য অংশ বাছুন");});
        Button paste=new Button(a);paste.setText("Paste style");styleTools.addView(paste);paste.setOnClickListener(v->{if(data.copiedStyle.isEmpty())return;try{checkpoint.run();data.draft.put(paths.get(target.getSelectedItemPosition()),new JSONObject(data.copiedStyle));preview.run();syncDimension.run();}catch(Exception ignored){}});
        LinearLayout historyTools=new LinearLayout(a);box.addView(historyTools);
        Button undo=new Button(a);undo.setText("Undo");historyTools.addView(undo);undo.setOnClickListener(v->{if(data.undo.isEmpty())return;try{data.redo.addLast(data.draft.toString());data.draft=new JSONObject(data.undo.removeLast());preview.run();syncDimension.run();}catch(Exception ignored){}});
        Button redo=new Button(a);redo.setText("Redo");historyTools.addView(redo);redo.setOnClickListener(v->{if(data.redo.isEmpty())return;try{data.undo.addLast(data.draft.toString());data.draft=new JSONObject(data.redo.removeLast());preview.run();syncDimension.run();}catch(Exception ignored){}});
        ScrollView scroll=new ScrollView(a);scroll.addView(box);
        androidx.appcompat.app.AlertDialog dialog=new MyShopCompatDialogBuilder(a).setTitle("ডিজাইন • "+scope).setView(scroll).setPositiveButton("Draft Save",null).setNeutralButton("Publish",null).setNegativeButton("Cancel",null).create();
        dialog.setOnDismissListener(d->{data.editing=false;paint(a,data,data.published);});dialog.show();
        dialog.getButton(-1).setOnClickListener(v->save(a,root,scope,data,false,status,dialog,box));
        dialog.getButton(-3).setOnClickListener(v->new MyShopDialogBuilder(a).setTitle("প্রকাশ করবেন?").setMessage("সেভ করা Draft এই অংশে সব ব্যবহারকারী দেখবে। Live বা Profile layout বদলাবে না।").setNegativeButton("Cancel",null).setPositiveButton("Publish",(d,n)->save(a,root,scope,data,true,status,dialog,box)).show());
        view.setOnClickListener(v->{paint(a,data,data.draft);dialog.hide();new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(()->{if(!a.isFinishing()&&!a.isDestroyed()&&root.getTag(R.id.visual_design_state)==data&&data.editing)dialog.show();},3500);});
        selectOnPage.setOnClickListener(v->{
            paint(a,data,data.draft);dialog.hide();ViewGroup decor=(ViewGroup)a.getWindow().getDecorView();
            final android.graphics.Rect marker=new android.graphics.Rect();
            View selector=new View(a){protected void onDraw(android.graphics.Canvas canvas){super.onDraw(canvas);if(!marker.isEmpty()){android.graphics.Paint ink=new android.graphics.Paint();ink.setColor(0x994880ff);ink.setStyle(android.graphics.Paint.Style.STROKE);ink.setStrokeWidth(dp(a,2));canvas.drawRect(marker,ink);}}};
            selector.setBackgroundColor(0x08000000);selector.setContentDescription("Tap the part to customize");
            Runnable finish=()->{decor.removeView(selector);if(!a.isFinishing()&&!a.isDestroyed()&&root.getTag(R.id.visual_design_state)==data&&data.editing)dialog.show();};
            android.os.Handler handler=new android.os.Handler(android.os.Looper.getMainLooper());
            selector.setOnTouchListener((surface,event)->{if(event.getAction()!=android.view.MotionEvent.ACTION_UP)return true;
                int x=(int)event.getRawX(),y=(int)event.getRawY();android.graphics.Rect bounds=new android.graphics.Rect();int selected=0;
                for(int i=0;i<paths.size();i++){View candidate=data.targets.get(paths.get(i)).view;if(candidate.isShown()&&candidate.getGlobalVisibleRect(bounds)&&bounds.contains(x,y))selected=i;}
                target.setSelection(selected);View chosen=data.targets.get(paths.get(selected)).view;chosen.getGlobalVisibleRect(marker);int[] origin=new int[2];selector.getLocationOnScreen(origin);marker.offset(-origin[0],-origin[1]);selector.invalidate();
                status.setText("বাছাই: "+labels.get(selected));handler.removeCallbacks(finish);handler.postDelayed(finish,450);return true;
            });decor.addView(selector,new ViewGroup.LayoutParams(-1,-1));handler.postDelayed(finish,10000);
        });
    }
    private static void save(Activity a,View root,String scope,State data,boolean publish,TextView status,androidx.appcompat.app.AlertDialog dialog,View controls){
        if(data.saving)return;
        if(publish&&!data.savedDraft.equals(data.draft.toString())){status.setText("আগে এই পরিবর্তনের Draft Save করুন, তারপর Publish।");return;}
        try{JSONObject request=new JSONObject().put("scope",scope).put("action",publish?"PUBLISH":"SAVE_DRAFT").put("expectedRevision",data.revision).put("expectedDraftRevision",data.draftRevision).put("styles",data.draft);
            data.saving=true;setControlsEnabled(controls,false);dialog.getButton(-1).setEnabled(false);dialog.getButton(-3).setEnabled(false);
            BackendClient.visualDesignSave(SessionManager.getToken(a),request,new BackendClient.Callback(){public void onSuccess(JSONObject d){a.runOnUiThread(()->{data.saving=false;if(a.isFinishing()||a.isDestroyed()||root.getTag(R.id.visual_design_state)!=data||!data.editing)return;setControlsEnabled(controls,true);data.revision=d.optInt("revision");data.draftRevision=d.optInt("draftRevision");data.published=d.optJSONObject("styles");data.draft=d.optJSONObject("draft");data.savedDraft=data.draft.toString();status.setText(publish?"Published • "+data.revision:"Draft সেভ হয়েছে • অন্যদের পেজ বদলায়নি");a.getSharedPreferences("visual_design575",0).edit().putString(scope,data.published.toString()).apply();dialog.getButton(-1).setEnabled(true);dialog.getButton(-3).setEnabled(true);if(publish)dialog.dismiss();});}public void onError(String m){a.runOnUiThread(()->{data.saving=false;if(a.isFinishing()||a.isDestroyed()||root.getTag(R.id.visual_design_state)!=data||!data.editing)return;setControlsEnabled(controls,true);status.setText("সেভ হয়নি • "+m);dialog.getButton(-1).setEnabled(true);dialog.getButton(-3).setEnabled(true);});}});
        }catch(Exception e){data.saving=false;setControlsEnabled(controls,true);dialog.getButton(-1).setEnabled(true);dialog.getButton(-3).setEnabled(true);status.setText("সেভ হয়নি");}
    }
    private static void setControlsEnabled(View view,boolean enabled){view.setEnabled(enabled);if(view instanceof ViewGroup){ViewGroup group=(ViewGroup)view;for(int i=0;i<group.getChildCount();i++)setControlsEnabled(group.getChildAt(i),enabled);}}
    private VisualDesign(){}
}
