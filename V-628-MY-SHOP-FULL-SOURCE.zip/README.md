# MY SHOP V628 / 2.9.628

Full Android project source and GitHub APK build package, continued from delivered V627. No APK is bundled. Eight current correction groups are described in V628-APPROVED-WORK-BN.md; actual checks and remaining limits are in MY-SHOP-DEVELOPER-HANDOFF.md and verification/V628-RESULTS.md.

Start with AGENTS.md, DEVELOPER-POLICY-BN.md and MY-SHOP-DEVELOPER-INSTRUCTIONS.md. Follow GITHUB-UPLOAD-V628-BN.md for build-only GitHub setup. Original package, signing identity, baseline entries and existing assets are retained. Credentials are setup requirements, not source values.

Run `bash tools/v628_target_verify.sh` for the current source tests. Full build in the configured environment: `bash tools/ci-apk-build.sh`. Asset dependencies/generation are described in BUILD-ASSETS-BN.md, tools/requirements-build-assets.txt and SIGNING-SETUP.md.

Use APK628 together with reviewed backend628 for new ID/Grant/Gift receipt behavior. Included GitHub workflow does not deploy Worker/D1. Production deployment and real-device/RTC/payment acceptance were not performed by this task. Historical handoffs remain for continuity; latest owner decisions take priority. Next changed delivery V629.
