package com.myshop.app;

import android.os.Handler;
import android.os.Looper;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

/** Small dependency-free HTTP client for the Cloudflare Worker backend. */
public final class BackendClient {
    private static final ExecutorService IO = Executors.newCachedThreadPool();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private BackendClient() {}

    public interface Callback { void onSuccess(JSONObject data); void onError(String message); }

    private static String baseUrl() { return BuildConfig.MYSHOP_BACKEND_URL == null ? "" : BuildConfig.MYSHOP_BACKEND_URL.trim().replaceAll("/$", ""); }
    public static boolean configured() { return !baseUrl().isEmpty() && !baseUrl().contains("YOUR-WORKER"); }

    public static void googleLogin(String idToken, Callback cb) {
        try { JSONObject b=new JSONObject().put("idToken",idToken); post("/v1/auth/google",b,null,cb); }
        catch(Exception e){ cb.onError("Invalid Google login request"); }
    }

    public static void adminStoreGrant628(String token,String userId,JSONArray products,boolean extend,boolean unpublished,String key,Callback cb){try{post("/v1/admin/store/grant",new JSONObject().put("userId",userId).put("productIds",products).put("extend",extend).put("allowUnpublished",unpublished).put("requestKey",key),token,cb);}catch(Exception e){cb.onError("Invalid products");}}
    public static void adminPublicIdPreview628(String token,String userId,String number,String expectedId,Callback cb){try{post("/v1/admin/public-id",new JSONObject().put("userId",userId).put("number",number).put("expectedId",expectedId).put("preview",true),token,cb);}catch(Exception e){cb.onError("Invalid ID");}}
    public static void adminPublicId626(String token,String userId,String number,String expectedId,Callback cb){try{post("/v1/admin/public-id",new JSONObject().put("userId",userId).put("number",number).put("expectedId",expectedId).put("confirm",true),token,cb);}catch(Exception e){cb.onError("Invalid ID");}}
    public static void login(String identifier, String password, Callback cb) {
        try { JSONObject b=new JSONObject().put("identifier",identifier).put("password",password); post("/v1/auth/login",b,null,cb); }
        catch(Exception e){ cb.onError("Invalid login request"); }
    }

    public static void register(String name,String email,String mobile,String password,String question,String answer,String gender,Callback cb) {
        try {
            JSONObject b=new JSONObject().put("name",name).put("email",email).put("mobile",mobile).put("password",password).put("securityQuestion",question).put("securityAnswer",answer).put("gender",gender==null?"UNSPECIFIED":gender);
            post("/v1/auth/register",b,null,cb);
        } catch(Exception e){ cb.onError("Invalid registration request"); }
    }

    public static void resetPassword(String identifier,String answer,String newPassword,Callback cb) {
        try { JSONObject b=new JSONObject().put("identifier",identifier).put("answer",answer).put("newPassword",newPassword); post("/v1/auth/password/reset",b,null,cb); }
        catch(Exception e){ cb.onError("Invalid reset request"); }
    }

    public static void changePassword(String token,String currentPassword,String newPassword,Callback cb) {
        try { JSONObject b=new JSONObject().put("currentPassword",currentPassword).put("newPassword",newPassword); post("/v1/auth/password/change",b,token,cb); }
        catch(Exception e){ cb.onError("Invalid password change request"); }
    }

    public static void me(String token,Callback cb) { get("/v1/me",token,cb); }
    public static void coinInfo(String token,Callback cb) { get("/v1/coins",token,cb); }
    public static void securityQuestions(String identifier,Callback cb) {
        try { get("/v1/auth/password/questions?identifier=" + java.net.URLEncoder.encode(identifier,"UTF-8"), null, cb); }
        catch(Exception e){ cb.onError("Invalid identifier"); }
    }
    public static void appearance(String token,String target,boolean history,Callback cb){get("/v1/appearance?target="+android.net.Uri.encode(target)+(history?"&history=1":""),token,cb);}
    public static void appearanceSave(String token,JSONObject data,Callback cb){post("/v1/appearance",data,token,cb);}
    public static void appearanceGrant(String token,String id,Callback cb){get("/v1/admin/appearance-grant?userId="+android.net.Uri.encode(id),token,cb);}
    public static void appearanceGrantSave(String token,JSONObject data,Callback cb){post("/v1/admin/appearance-grant",data,token,cb);}
    public static void agency(String token,String query,JSONObject data,Callback cb){request(data==null?"GET":"POST","/v1/agency"+(query==null?"":query),data,token,cb);}
    public static void commissionManagement(String token,JSONObject data,Callback cb){request(data==null?"GET":"POST","/v1/admin/commission-management",data,token,cb);}
    private static final java.util.Map<String,java.util.List<Callback>> DASHBOARD_WAITERS=new java.util.HashMap<>();
    public static void dashboard(String token,Callback cb) {
        final String key=token==null?"":token;
        synchronized(DASHBOARD_WAITERS){java.util.List<Callback> waiting=DASHBOARD_WAITERS.get(key);if(waiting!=null){waiting.add(cb);return;}waiting=new java.util.ArrayList<>();waiting.add(cb);DASHBOARD_WAITERS.put(key,waiting);}
        get("/v1/dashboard/config",token,new Callback(){
            private java.util.List<Callback> drain(){synchronized(DASHBOARD_WAITERS){return DASHBOARD_WAITERS.remove(key);}}
            public void onSuccess(JSONObject d){java.util.List<Callback> xs=drain();if(xs!=null)for(Callback x:xs){try{x.onSuccess(new JSONObject(d.toString()));}catch(Exception e){x.onError("Invalid dashboard response");}}}
            public void onError(String m){java.util.List<Callback> xs=drain();if(xs!=null)for(Callback x:xs)x.onError(m);}
        });
    }
    public static void liveHomeBanners(String token,Callback cb) { get("/v1/live-home/banners",token,cb); }
    public static void notifications(String token,Callback cb) { get("/v1/notifications",token,cb); }
    public static void helpTickets(String token,Callback cb) { get("/v1/help/tickets",token,cb); }
    public static void createHelpTicket(String token,String category,String subject,String message,Callback cb) { try { request("POST","/v1/help/ticket",new JSONObject().put("category",category).put("subject",subject).put("message",message),token,cb); } catch(Exception e){ cb.onError("Invalid support request"); } }
    public static void helpTicket(String token,long id,Callback cb) { get("/v1/help/ticket?id="+id,token,cb); }
    public static void replyHelpTicket(String token,long id,String message,Callback cb) { try { request("POST","/v1/help/ticket/reply",new JSONObject().put("ticketId",id).put("message",message),token,cb); } catch(Exception e){ cb.onError("Invalid support reply"); } }
    public static void adminOfficialNotice(String token,String title,String message,String imageUrl,String actionUrl,String expiresAt,String colorHex,String scheduledAt,Callback cb) { try { request("POST","/v1/admin/official-notice",new JSONObject().put("title",title).put("message",message).put("imageUrl",imageUrl).put("actionUrl",actionUrl).put("expiresAt",expiresAt).put("colorHex",colorHex).put("scheduledAt",scheduledAt),token,cb); } catch(Exception e){ cb.onError("Invalid official notice"); } }
    public static void adminOfficialNotices(String token,Callback cb) { get("/v1/admin/official-notices",token,cb); }
    public static void adminHelpTickets(String token,Callback cb) { get("/v1/admin/help/tickets",token,cb); }
    public static void membershipPeople(String token,String tier,int limit,int offset,Callback cb) {
        String membership=MembershipUi.tier(tier);get("/v1/people/new?limit="+Math.max(1,Math.min(60,limit))+"&offset="+Math.max(0,offset)+"&membership="+membership,token,cb);
    }
    public static void newPeople(String token,int limit,int offset,Callback cb) { get("/v1/people/new?limit="+Math.max(1,Math.min(500,limit))+"&offset="+Math.max(0,offset),token,cb); }
    public static void historyList(String token,int limit,int offset,Callback cb) { get("/v1/history?limit="+Math.max(1,Math.min(100,limit))+"&offset="+Math.max(0,offset),token,cb); }
    public static void historyRecord(String token,JSONObject payload,Callback cb) { post("/v1/history/record",payload,token,cb); }
    /** V-512 compatibility alias used by the history UI. */
    public static void historyAdd(String token,String type,String title,String details,String ref,String thumbnailUrl,String action,Callback cb) { try { historyRecord(token,new JSONObject().put("type",type).put("title",title).put("details",details).put("ref",ref).put("thumbnailUrl",thumbnailUrl).put("action",action),cb); } catch(Exception e){ cb.onError("History save failed"); } }
    public static void historyClear(String token,Callback cb) { post("/v1/history/clear",new JSONObject(),token,cb); }
    public static void profileConnections(String token,String userId,String kind,int offset,int limit,Callback cb){try{get("/v1/users/connections?userId="+java.net.URLEncoder.encode(userId,"UTF-8")+"&kind="+java.net.URLEncoder.encode(kind,"UTF-8")+"&offset="+Math.max(0,offset)+"&limit="+limit,token,cb);}catch(Exception e){cb.onError("Profile list unavailable");}}
    public static void userProfile(String token,String userId,boolean publicPreview,Callback cb){try{get("/v1/users/profile?userId="+java.net.URLEncoder.encode(userId,"UTF-8")+(publicPreview?"&viewAs=public":""),token,cb);}catch(Exception e){cb.onError("Invalid profile");}}
    public static void userPosts(String token,String userId,String media,boolean publicPreview,Callback cb){try{get("/v1/users/posts?userId="+java.net.URLEncoder.encode(userId,"UTF-8")+"&media="+java.net.URLEncoder.encode(media==null?"all":media,"UTF-8")+(publicPreview?"&viewAs=public":""),token,cb);}catch(Exception e){cb.onError("Profile posts unavailable");}}
    public static void userProfile(String token,String userId,Callback cb){ try{get("/v1/users/profile?userId="+java.net.URLEncoder.encode(userId,"UTF-8"),token,cb);}catch(Exception e){cb.onError("Invalid profile");} }
    public static void userSocialLinks(String token,Callback cb){ get("/v1/me/social-links",token,cb); }
    public static void saveUserSocialLinks(String token,JSONArray links,Callback cb){ try{request("PUT","/v1/me/social-links",new JSONObject().put("socialLinks",links),token,cb);}catch(Exception e){cb.onError("Invalid Social Links");} }
    public static void myPersonalDetails(String token,Callback cb){ get("/v1/me/personal-details",token,cb); }
    public static void savePersonalDetails(String token,JSONArray details,Callback cb){ try{request("PUT","/v1/me/personal-details",new JSONObject().put("personalDetails",details),token,cb);}catch(Exception e){cb.onError("Invalid Personal Details");} }
    public static void sendFriendRequest(String token,String userId,Callback cb) { try { post("/v1/friends/request",new JSONObject().put("userId",userId),token,cb); } catch(Exception e){ cb.onError("Invalid friend request"); } }
    public static void friends(String token,Callback cb){ get("/v1/friends",token,cb); }
    public static void removeFriend(String token,String userId,Callback cb){ try{post("/v1/friends/remove",new JSONObject().put("userId",userId),token,cb);}catch(Exception e){cb.onError("Invalid friend remove request");} }
    public static void cancelFriendRequest(String token,String userId,Callback cb){ try{post("/v1/friends/cancel",new JSONObject().put("userId",userId),token,cb);}catch(Exception e){cb.onError("Invalid friend cancel request");} }
    public static void toggleFollow(String token,String userId,Callback cb){ try{post("/v1/follow/toggle",new JSONObject().put("userId",userId),token,cb);}catch(Exception e){cb.onError("Invalid follow request");} }
    public static void liveMusic(String token,Callback cb){ get("/v1/live/music",token,cb); }
    public static void adminLiveMusicSave(String token,JSONObject data,Callback cb){ post("/v1/admin/live/music/save",data,token,cb); }
    public static void adminLiveMusicDelete(String token,String entity,long id,Callback cb){ try{post("/v1/admin/live/music/delete",new JSONObject().put("entity",entity).put("id",id),token,cb);}catch(Exception e){cb.onError("Music delete failed");} }
    public static void adminLiveMusicUpload(String token,java.io.InputStream input,String fileName,String mime,Callback cb){ uploadMultipart(token,"/v1/admin/live/music/upload",input,fileName,mime,null,cb); }
    public static void socialStats(String token,Callback cb){ get("/v1/me/social-stats",token,cb); }
    public static void liveProfiles(String token,int limit,Callback cb){ get("/v1/live/profiles?limit="+Math.max(1,Math.min(100,limit)),token,cb); }
    public static void appPresenceRead(String token,String ids,Callback cb){get("/v1/app/presence?ids="+ids,token,cb);}
    public static void setAppPresence(String token,boolean active,String device,long sequence,Callback cb){try{post("/v1/app/presence",new JSONObject().put("active",active).put("deviceId",device).put("sequence",sequence),token,cb);}catch(Exception e){cb.onError("Presence unavailable");}}
    public static void setAppPresence(String token,boolean active,Callback cb){ try{post("/v1/app/presence",new JSONObject().put("active",active),token,cb);}catch(Exception e){cb.onError("App presence failed");} }
    public static void setPresencePrivacy(String token,boolean visible,Callback cb){ try{post("/v1/app/presence",new JSONObject().put("visible",visible),token,cb);}catch(Exception e){cb.onError("Active status update failed");} }
    public static void setLivePresence(String token,boolean active,Callback cb){ setLivePresence(token,active,null,null,cb); }
    // V-392: Live start sends the chosen Live Name/Caption in the same authoritative request
    // that creates the room session. This prevents a short stale-profile-name room from being
    // visible before a second config request arrives.
    public static void setLivePresence(String token,boolean active,String title,String topic,Callback cb){
        try{JSONObject j=new JSONObject().put("active",active);if(title!=null)j.put("title",title);if(topic!=null)j.put("topic",topic);post("/v1/live/presence",j,token,cb);}catch(Exception e){cb.onError("Live presence failed");}
    }
    public static void liveHostHeartbeat(String token,String sessionId,Callback cb){try{post("/v1/live/heartbeat",new JSONObject().put("sessionId",sessionId==null?"":sessionId),token,cb);}catch(Exception e){cb.onError("Live heartbeat failed");}}
    public static void endLive(String token,Callback cb){ try{post("/v1/live/end",new JSONObject(),token,cb);}catch(Exception e){cb.onError("Live end failed");} }
    public static void liveViewer(String token,String hostId,boolean joined,Callback cb){ liveViewer(token,hostId,joined,false,cb); }
    public static void liveViewer(String token,String hostId,boolean joined,boolean freshJoin,Callback cb){ try{post("/v1/live/viewer",new JSONObject().put("hostId",hostId).put("joined",joined).put("freshJoin",freshJoin),token,cb);}catch(Exception e){cb.onError("Live viewer update failed");} }
    public static void liveRoomState(String token,String hostId,Callback cb){ get("/v1/live/room?hostId="+hostId,token,cb); }
    public static void liveRealtime(String token,String hostId,String sessionId,long afterComment,long afterHighlight,long afterGift,int revision,Callback cb){
        try{
            String q="/v1/live/realtime?hostId="+java.net.URLEncoder.encode(hostId,"UTF-8")+"&sessionId="+java.net.URLEncoder.encode(sessionId,"UTF-8")+"&afterComment="+Math.max(0,afterComment)+"&afterHighlight="+Math.max(0,afterHighlight)+"&afterGift="+Math.max(0,afterGift)+"&revision="+Math.max(0,revision);
            get(q,token,cb);
        }catch(Exception e){cb.onError("Live realtime unavailable");}
    }
    public static void agoraRtcToken(String token,String hostId,Callback cb){ try{post("/v1/live/rtc/token",new JSONObject().put("hostId",hostId),token,cb);}catch(Exception e){cb.onError("RTC token request failed");} }
    public static void cancelStoreRequest625(String token,long id,Callback cb){try{post("/v1/store/request/cancel",new JSONObject().put("requestId",id),token,cb);}catch(Exception e){cb.onError("Invalid request");}}
    public static void myStoreRequests625(String token,Callback cb){get("/v1/store/my-requests",token,cb);}
    public static void staffJoin625(String token,String hostId,int seat,Callback cb){try{post("/v1/live/request",new JSONObject().put("hostId",hostId).put("seatNo",seat),token,cb);}catch(Exception e){cb.onError("Join failed");}}
    public static void staffClose625(String token,String hostId,Callback cb){try{post("/v1/live/list-close",new JSONObject().put("hostId",hostId),token,cb);}catch(Exception e){cb.onError("Close failed");}}
    public static void liveSpeakRequest(String token,String hostId,Callback cb){ try{post("/v1/live/request",new JSONObject().put("hostId",hostId),token,cb);}catch(Exception e){cb.onError("Speak request failed");} }
    public static void liveCancelSpeakRequest(String token,String hostId,Callback cb){ try{post("/v1/live/request/cancel",new JSONObject().put("hostId",hostId),token,cb);}catch(Exception e){cb.onError("Cancel request failed");} }
    public static void liveRequestActionForHost(String token,String hostId,String requesterId,boolean accept,Callback cb){try{post("/v1/live/request/action",new JSONObject().put("hostId",hostId).put("requesterId",requesterId).put("action",accept?"ACCEPT":"REJECT"),token,cb);}catch(Exception e){cb.onError("Request action failed");}}
    public static void liveRequestAction(String token,String requesterId,boolean accept,Callback cb){ try{post("/v1/live/request/action",new JSONObject().put("requesterId",requesterId).put("action",accept?"ACCEPT":"REJECT"),token,cb);}catch(Exception e){cb.onError("Request action failed");} }
    public static void liveInvite(String token,String hostId,String userId,Callback cb){ try{post("/v1/live/invite",new JSONObject().put("hostId",hostId).put("userId",userId),token,cb);}catch(Exception e){cb.onError("Call invitation failed");} }
    public static void liveInvite(String token,String userId,Callback cb){ liveInvite(token,"",userId,cb); }
    public static void liveInviteAction(String token,String hostId,boolean accept,Callback cb){ try{post("/v1/live/invite/action",new JSONObject().put("hostId",hostId).put("action",accept?"ACCEPT":"DECLINE"),token,cb);}catch(Exception e){cb.onError("Invitation action failed");} }
    public static void liveLeaveSeat(String token,String hostId,Callback cb){ try{post("/v1/live/seat/leave",new JSONObject().put("hostId",hostId),token,cb);}catch(Exception e){cb.onError("Leave seat failed");} }
    public static void liveSeatAssign(String token,String userId,int seatNo,Callback cb){ try{post("/v1/live/seat/assign",new JSONObject().put("userId",userId).put("seatNo",seatNo),token,cb);}catch(Exception e){cb.onError("Guest seat update failed");} }
    public static void liveSelfSeatAssign(String token,String hostId,int seatNo,Callback cb){ try{post("/v1/live/seat/assign",new JSONObject().put("hostId",hostId).put("seatNo",seatNo),token,cb);}catch(Exception e){cb.onError("Seat change failed");} }
        public static void pushSelfTest(String token,Callback cb){ try{post("/v1/push/self-test",new JSONObject(),token,cb);}catch(Exception e){cb.onError("Push test failed");} }
public static void registerPushToken(String token,String pushToken,Callback cb){ try{post("/v1/push/token",new JSONObject().put("token",pushToken).put("firebaseProjectId",BuildConfig.FIREBASE_PROJECT_ID),token,cb);}catch(Exception e){cb.onError("Push registration failed");} }
    public static void liveSpecialGuest(String token,String userId,boolean clear,Callback cb){ try{post("/v1/live/special-guest",new JSONObject().put("userId",userId==null?"":userId).put("clear",clear),token,cb);}catch(Exception e){cb.onError("Special guest update failed");} }
    public static void liveSpeakerRemove(String token,String userId,Callback cb){ try{post("/v1/live/speaker/remove",new JSONObject().put("userId",userId),token,cb);}catch(Exception e){cb.onError("Speaker remove failed");} }
    public static void liveBatchSettings(String token,String hostId,JSONObject values,Callback cb){try{if(values==null)get("/v1/live/settings?hostId="+java.net.URLEncoder.encode(hostId,"UTF-8"),token,cb);else post("/v1/live/settings",values.put("hostId",hostId),token,cb);}catch(Exception e){cb.onError("Settings unavailable");}}
    public static void liveRoomConfig(String token,String title,String topic,String pinned,String themeKey,Callback cb){ try{JSONObject j=new JSONObject(); if(title!=null)j.put("title",title); if(topic!=null)j.put("topic",topic); if(pinned!=null)j.put("pinnedMessage",pinned); if(themeKey!=null)j.put("themeKey",themeKey); post("/v1/live/room/config",j,token,cb);}catch(Exception e){cb.onError("Room settings failed");} }
    public static void livePinnedMessage(String token,String hostId,String pinned,Callback cb){ try{post("/v1/live/room/config",new JSONObject().put("hostId",hostId).put("pinnedMessage",pinned==null?"":pinned),token,cb);}catch(Exception e){cb.onError("Pin update failed");} }
    public static void liveSeatLock(String token,int seatNo,boolean locked,Callback cb){ try{post("/v1/live/seat/lock",new JSONObject().put("seatNo",seatNo).put("locked",locked),token,cb);}catch(Exception e){cb.onError("Seat lock failed");} }
    public static void liveParticipantState(String token,String hostId,boolean micOn,boolean speaking,String networkQuality,Callback cb){ liveParticipantState(token,hostId,micOn,speaking,networkQuality,false,cb); }
    public static void liveParticipantState(String token,String hostId,boolean micOn,boolean speaking,String networkQuality,boolean userAction,Callback cb){ try{post("/v1/live/participant/state",new JSONObject().put("hostId",hostId).put("micOn",micOn).put("speaking",speaking).put("networkQuality",networkQuality).put("userAction",userAction),token,cb);}catch(Exception e){cb.onError("Participant state failed");} }
    public static void liveShare(String token,String hostId,Callback cb){ try{post("/v1/live/share",new JSONObject().put("hostId",hostId),token,cb);}catch(Exception e){cb.onError("Share count failed");} }
    public static void liveComment(String token,String hostId,String message,Callback cb){ liveComment(token,hostId,message,"",cb); }
    public static void liveComment(String token,String hostId,String message,String clientNonce,Callback cb){ try{post("/v1/live/comment",new JSONObject().put("hostId",hostId).put("message",message).put("clientNonce",clientNonce==null?"":clientNonce),token,cb);}catch(Exception e){cb.onError("Comment failed");} }
    public static void liveReact(String token,String hostId,Callback cb){ try{post("/v1/live/react",new JSONObject().put("hostId",hostId),token,cb);}catch(Exception e){cb.onError("React failed");} }
    public static void liveVote(String token,String hostId,Callback cb){ try{post("/v1/live/vote",new JSONObject().put("hostId",hostId),token,cb);}catch(Exception e){cb.onError("Vote failed");} }
    public static void walletTransferQuote623(String token,String receiver,String currency,long amount,Callback cb){get("/v1/wallet/transfer/quote?receiverId="+android.net.Uri.encode(receiver)+"&currency="+android.net.Uri.encode(currency)+"&amount="+amount,token,cb);}
    public static void walletTransfer623(String token,String receiver,String currency,long amount,JSONObject quote,Callback cb){try{post("/v1/wallet/transfer",new JSONObject().put("receiverId",receiver).put("currency",currency).put("amount",amount).put("expectedTotal",quote.getLong("totalDebit")).put("expectedCommission",quote.getLong("commissionAmount")).put("expectedCommissionRevision",quote.getLong("commissionRevision")),token,cb);}catch(Exception e){cb.onError("Invalid transfer quote");}}
    public static void walletTransfer(String token,String receiverId,String currency,long amount,Callback cb){ try{post("/v1/wallet/transfer",new JSONObject().put("receiverId",receiverId).put("currency",currency).put("amount",amount),token,cb);}catch(Exception e){cb.onError("Transfer failed");} }
    public static void liveHighlightConfig(String token,Callback cb){ get("/v1/live/highlight/config",token,cb); }
    public static void liveCommentUi(String token,Callback cb){ get("/v1/live/comment-ui",token,cb); }
    public static void adminLiveCommentFont(String token,int size,Callback cb){ try{post("/v1/live/comment-ui",new JSONObject().put("fontSize",size),token,cb);}catch(Exception e){cb.onError("Comment font update failed");} }
    public static void adminLiveCommentGlobalSave(String token,JSONObject style,Callback cb){ try{post("/v1/admin/live/comment-global/save",new JSONObject().put("style",style),token,cb);}catch(Exception e){cb.onError("Global comment style save failed");} }
    public static void adminLiveCommentPresetSave(String token,JSONObject style,Callback cb){ try{post("/v1/admin/live/comment-preset/save",style,token,cb);}catch(Exception e){cb.onError("Comment preset save failed");} }
    public static void adminLiveCommentAssignmentSave(String token,String userId,String presetKey,JSONObject customStyle,boolean custom,boolean enabled,Callback cb){ try{post("/v1/admin/live/comment-assignment/save",new JSONObject().put("userId",userId).put("presetKey",presetKey).put("customStyle",customStyle==null?new JSONObject():customStyle).put("custom",custom).put("enabled",enabled),token,cb);}catch(Exception e){cb.onError("Comment assignment save failed");} }
    public static void liveHighlightComment(String token,String hostId,String message,String requestId,Callback cb){ try{post("/v1/live/highlight/comment",new JSONObject().put("hostId",hostId).put("message",message).put("requestId",requestId),token,cb);}catch(Exception e){cb.onError("Highlight comment failed");} }
    public static void liveGiftSummary(String token,String hostId,Callback cb){ get("/v1/live/gifts/summary?hostId="+hostId,token,cb); }
    public static void adminUserControlLiveHistory(String token,String uid,String before,Callback cb){ get("/v1/admin/user-control/details?userId="+android.net.Uri.encode(uid)+"&liveBefore="+android.net.Uri.encode(before==null?"":before),token,cb); }
    public static void adminUserControlDetails(String token,String uid,Callback cb){ get("/v1/admin/user-control/details?userId="+android.net.Uri.encode(uid),token,cb); }
    public static void adminModerationOverride(String token,JSONObject data,Callback cb){post("/v1/admin/user-control/moderation",data,token,cb);}
    public static void adminSpecialIds(String token,Callback cb){get("/v1/admin/special-user-id",token,cb);}
    public static void adminReserveSpecialId(String token,JSONObject data,Callback cb){post("/v1/admin/special-user-id",data,token,cb);}
    public static void featureAccess(String token,String key,Callback cb){ get("/v1/features/access?key="+android.net.Uri.encode(key),token,cb); }
    public static void walletHistory(String token,Callback cb){ get("/v1/wallet/history",token,cb); }
    public static void valueHistory(String token,Callback cb){ get("/v1/wallet/value-history",token,cb); }
    public static void liveThemes(String token,Callback cb){ get("/v1/live/themes",token,cb); }
    public static void liveUiSettings(String token,Callback cb){ get("/v1/live/ui-settings",token,cb); }
    public static void liveSummary(String token,String hostId,Callback cb){ get("/v1/live/summary?hostId="+hostId,token,cb); }
    public static void liveModeration(String token,String hostId,String userId,String action,Callback cb){ try{post("/v1/live/moderation",new JSONObject().put("hostId",hostId).put("userId",userId).put("action",action),token,cb);}catch(Exception e){cb.onError("Moderation failed");} }
    public static void feedGift(String token,long postId,long giftId,long price,long total,String nonce,Callback cb){try{post("/v1/feed/gift",new JSONObject().put("postId",postId).put("giftId",giftId).put("expectedPrice",price).put("expectedTotal",total).put("clientNonce",nonce),token,cb);}catch(Exception e){cb.onError("Could not prepare gift");}}
    public static void adminGiftControls618(String token,JSONObject data,Callback cb){post("/v1/admin/live/gifts/controls618",data,token,cb);}
    public static void liveGifts(String token,Callback cb){ get("/v1/live/gifts",token,cb); }
    public static void liveGiftEvents(String token,String hostId,long after,Callback cb){ try{get("/v1/live/gifts/events?hostId="+java.net.URLEncoder.encode(hostId,"UTF-8")+"&after="+Math.max(0,after),token,cb);}catch(Exception e){cb.onError("Gift events unavailable");} }
    public static void liveGiftSendQuoted613(String token,String hostId,JSONArray recipients,long giftId,int quantity,String nonce,long price,long total,String session,Callback cb){try{post("/v1/live/gifts/send",new JSONObject().put("hostId",hostId).put("receiverIds",recipients).put("giftId",giftId).put("quantity",quantity).put("clientNonce",nonce).put("expectedUnitPrice",price).put("expectedTotal",total).put("expectedSessionId",session),token,cb);}catch(Exception e){cb.onError("Gift send failed");}}
    public static void giftSound622(String token,String host,boolean on,int volume,Callback cb){try{post("/v1/live/gift-sound",new JSONObject().put("hostId",host).put("enabled",on).put("volume",volume),token,cb);}catch(Exception e){cb.onError("Sound setting not saved");}}
    public static void giftSound613(String token,String host,boolean on,Callback cb){try{post("/v1/live/gift-sound",new JSONObject().put("hostId",host).put("enabled",on),token,cb);}catch(Exception e){cb.onError("Sound setting not saved");}}
    public static void liveGiftSend(String token,String hostId,JSONArray recipients,long giftId,int quantity,String nonce,Callback cb){try{post("/v1/live/gifts/send",new JSONObject().put("hostId",hostId).put("receiverIds",recipients).put("giftId",giftId).put("quantity",quantity).put("clientNonce",nonce),token,cb);}catch(Exception e){cb.onError("Gift send failed");}}
    public static void liveGiftSend(String token,String hostId,String receiverId,long giftId,Callback cb){ liveGiftSend(token,hostId,receiverId,giftId,java.util.UUID.randomUUID().toString(),cb); }
    public static void liveGiftSend(String token,String hostId,String receiverId,long giftId,String clientNonce,Callback cb){ try{post("/v1/live/gifts/send",new JSONObject().put("hostId",hostId).put("receiverId",receiverId).put("giftId",giftId).put("clientNonce",clientNonce==null?"":clientNonce),token,cb);}catch(Exception e){cb.onError("Gift send failed");} }
    public static void liveGiftThankYou(String token,String hostId,String senderId,Callback cb){try{post("/v1/live/gifts/thank-you",new JSONObject().put("hostId",hostId).put("senderId",senderId),token,cb);}catch(Exception e){cb.onError("Thank You failed");}}
    // V-304 premium Live ecosystem
    public static void livePremiumConfig(String token,String welcome,String goalType,long goalTarget,long pinnedProductId,Callback cb){ try{JSONObject j=new JSONObject();if(welcome!=null)j.put("welcomeMessage",welcome);if(goalType!=null)j.put("goalType",goalType);if(goalTarget>=0)j.put("goalTarget",goalTarget);if(pinnedProductId>=0)j.put("pinnedProductId",pinnedProductId);post("/v1/live/room/premium",j,token,cb);}catch(Exception e){cb.onError("Premium room settings failed");} }
    public static void livePollStart(String token,String question,String optionA,String optionB,Callback cb){try{post("/v1/live/poll/start",new JSONObject().put("question",question).put("optionA",optionA).put("optionB",optionB),token,cb);}catch(Exception e){cb.onError("Poll start failed");}}
    public static void livePollVote(String token,long pollId,String choice,Callback cb){try{post("/v1/live/poll/vote",new JSONObject().put("pollId",pollId).put("choice",choice),token,cb);}catch(Exception e){cb.onError("Poll vote failed");}}
    public static void livePollClose(String token,long pollId,Callback cb){try{post("/v1/live/poll/close",new JSONObject().put("pollId",pollId),token,cb);}catch(Exception e){cb.onError("Poll close failed");}}
    public static void liveFanClub(String token,String hostId,Callback cb){ try{get("/v1/live/fan-club?hostId="+java.net.URLEncoder.encode(hostId,"UTF-8"),token,cb);}catch(Exception e){cb.onError("Fan Club failed");} }
    public static void liveFanClubToggle(String token,String hostId,Callback cb){ try{post("/v1/live/fan-club/toggle",new JSONObject().put("hostId",hostId),token,cb);}catch(Exception e){cb.onError("Fan Club update failed");} }
    public static void liveCreatorCenter(String token,String hostId,Callback cb){ try{get("/v1/live/creator-center?hostId="+java.net.URLEncoder.encode(hostId,"UTF-8"),token,cb);}catch(Exception e){cb.onError("Creator Center failed");} }
    public static void myLevel621(String token,Callback cb){request("GET","/v1/me/level-progress",null,token,cb);}
    public static void liveDirectoryRevision621(Callback cb){request("GET","/v1/live/directory-revision",null,null,cb);}
    public static void liveDiscover(String token,String category,int limit,Callback cb){ try{get("/v1/live/discover?category="+java.net.URLEncoder.encode(category,"UTF-8")+"&limit="+Math.max(1,Math.min(100,limit)),token,cb);}catch(Exception e){cb.onError("Discover failed");} }
    public static void liveSchedules(String token,String hostId,Callback cb){ try{get("/v1/live/schedules?hostId="+java.net.URLEncoder.encode(hostId,"UTF-8"),token,cb);}catch(Exception e){cb.onError("Schedules failed");} }
    public static void liveScheduleSave(String token,long id,String title,String topic,String scheduledAt,Callback cb){ try{post("/v1/live/schedules/save",new JSONObject().put("id",id).put("title",title).put("topic",topic).put("scheduledAt",scheduledAt),token,cb);}catch(Exception e){cb.onError("Schedule save failed");} }
    public static void liveScheduleCancel(String token,long id,Callback cb){ try{post("/v1/live/schedules/cancel",new JSONObject().put("id",id),token,cb);}catch(Exception e){cb.onError("Schedule cancel failed");} }
    public static void liveScheduleReminder(String token,long scheduleId,Callback cb){ try{post("/v1/live/schedules/reminder",new JSONObject().put("scheduleId",scheduleId),token,cb);}catch(Exception e){cb.onError("Reminder update failed");} }
    public static void livePkStart(String token,String hostId,Callback cb){ try{post("/v1/live/pk/start",new JSONObject().put("hostId",hostId),token,cb);}catch(Exception e){cb.onError("PK start failed");} }
    public static void livePkAction(String token,long id,String action,Callback cb){ try{post("/v1/live/pk/action",new JSONObject().put("id",id).put("action",action),token,cb);}catch(Exception e){cb.onError("PK action failed");} }

    public static void adminGateStatus(String token,Callback cb){ get("/v1/admin/gate/status",token,cb); }
    public static void adminGateSetup(String token,String password,String question,String answer,Callback cb){ try{post("/v1/admin/gate/setup",new JSONObject().put("password",password).put("securityQuestion",question).put("securityAnswer",answer),token,cb);}catch(Exception e){cb.onError("Admin gate setup failed");} }
    public static void adminGateUnlock(String token,String password,Callback cb){ try{post("/v1/admin/gate/unlock",new JSONObject().put("password",password),token,cb);}catch(Exception e){cb.onError("Admin gate unlock failed");} }
    public static void adminGateRecoverQuestion(String token,String answer,String newPassword,Callback cb){ try{post("/v1/admin/gate/recover",new JSONObject().put("mode","QUESTION").put("securityAnswer",answer).put("newPassword",newPassword),token,cb);}catch(Exception e){cb.onError("Recovery failed");} }
    public static void adminGateRecoverIds(String token,String id1,String id2,String id3,String newPassword,Callback cb){ try{post("/v1/admin/gate/recover",new JSONObject().put("mode","OWNER_IDS").put("id1",id1).put("id2",id2).put("id3",id3).put("newPassword",newPassword),token,cb);}catch(Exception e){cb.onError("Recovery failed");} }
    public static void adminActivity(String token,Callback cb){get("/v1/admin/activity",token,cb);}
    public static void adminFinanceOverview(String token,Callback cb){ get("/v1/admin/finance/overview",token,cb); }
    public static void saveHighlightSettings(String token,int price,boolean enabled,double percent,Callback cb){try{post("/v1/admin/finance/config",new JSONObject().put("highlightCommentCoinPrice",price).put("highlightHostShareEnabled",enabled).put("highlightHostSharePercent",percent),token,cb);}catch(Exception e){cb.onError("Invalid highlight settings");}}
    public static void adminFinanceConfig(String token,Callback cb){ get("/v1/admin/finance/config",token,cb); }
    public static void adminFinanceConfigSave(String token,double feePercent,int highlightPrice,Callback cb){ try{post("/v1/admin/finance/config",new JSONObject().put("platformFeePercent",feePercent).put("highlightCommentCoinPrice",highlightPrice),token,cb);}catch(Exception e){cb.onError("Finance config failed");} }
    public static void adminFinanceConfigSave(String token,double feePercent,double vatPercent,int highlightPrice,Callback cb){ try{post("/v1/admin/finance/config",new JSONObject().put("platformFeePercent",feePercent).put("vatPercent",vatPercent).put("highlightCommentCoinPrice",highlightPrice),token,cb);}catch(Exception e){cb.onError("Finance config failed");} }
    public static void walletTransferConfig(String token,Callback cb){get("/v1/wallet/transfer/config",token,cb);}
    public static void adminCommissionSave(String token,double coin,double gold,Callback cb){try{post("/v1/admin/finance/config",new JSONObject().put("coinCommissionPercent",coin).put("goldCommissionPercent",gold),token,cb);}catch(Exception e){cb.onError("Commission config failed");}}
    public static void adminUserAudit(String token,String userId,Callback cb){ try{get("/v1/admin/user-audit?userId="+java.net.URLEncoder.encode(userId,"UTF-8"),token,cb);}catch(Exception e){cb.onError("User audit failed");} }
    public static void moderationAudit(String token,Callback cb){get("/v1/admin/live/moderation/audit",token,cb);}
    public static void adminAccountRecoveryUpdate(String token,String userId,String email,String mobile,Callback cb){ try{post("/v1/admin/account-recovery/update",new JSONObject().put("userId",userId).put("email",email==null?"":email.trim()).put("mobile",mobile==null?"":mobile.trim()),token,cb);}catch(Exception e){cb.onError("Account recovery update failed");} }
    public static void adminAccountRecoveryUpdate(String token,String userId,String email,String mobile,boolean clearEmail,boolean clearMobile,Callback cb){try{post("/v1/admin/account-recovery/update",new JSONObject().put("userId",userId).put("email",email==null?"":email.trim()).put("mobile",mobile==null?"":mobile.trim()).put("clearEmail",clearEmail).put("clearMobile",clearMobile).put("confirm",true),token,cb);}catch(Exception e){cb.onError("Account recovery update failed");}}
    public static void adminAccountPasswordReset(String token,String userId,String temporaryPassword,Callback cb){ try{post("/v1/admin/account-recovery/password-reset",new JSONObject().put("userId",userId).put("temporaryPassword",temporaryPassword),token,cb);}catch(Exception e){cb.onError("Password reset failed");} }
    public static void adminLiveGifts(String token,Callback cb){ get("/v1/admin/live/gifts",token,cb); }
    public static void adminLiveGifts(String token,String currency,Callback cb){ try{get("/v1/admin/live/gifts?currency="+java.net.URLEncoder.encode(currency==null?"":currency,"UTF-8"),token,cb);}catch(Exception e){cb.onError("Gift catalog unavailable");} }
    public static void adminLiveGiftSave(String token,JSONObject gift,Callback cb){ post("/v1/admin/live/gifts/save",gift,token,cb); }
    public static void adminLiveGiftBulkVat(String token,JSONObject payload,Callback cb){ post("/v1/admin/live/gifts/bulk-vat",payload,token,cb); }
    public static void adminLiveGiftReorder(String token,String currency,org.json.JSONArray ids,Callback cb){ try{post("/v1/admin/live/gifts/reorder",new JSONObject().put("currency",currency).put("ids",ids),token,cb);}catch(Exception e){cb.onError("Gift reorder failed");} }
    public static void adminLiveGiftDelete(String token,long id,Callback cb){ try{post("/v1/admin/live/gifts/delete",new JSONObject().put("id",id),token,cb);}catch(Exception e){cb.onError("Gift delete failed");} }
    public static void adminLiveGiftAssetUpload(String token,java.io.InputStream input,String fileName,String mime,Callback cb){ uploadMultipart(token,"/v1/admin/live/gifts/asset/upload",input,fileName,mime,null,cb); }
    public static void adminLiveTheme(String token,String action,String key,String name,String backgroundUrl,String accent,boolean enabled,int sortOrder,Callback cb){ adminLiveTheme(token,action,key,name,backgroundUrl,accent,enabled,sortOrder,0,"CENTER_CROP",cb); }
    public static void adminLiveTheme(String token,String action,String key,String name,String backgroundUrl,String accent,boolean enabled,int sortOrder,int coinPrice,Callback cb){ adminLiveTheme(token,action,key,name,backgroundUrl,accent,enabled,sortOrder,coinPrice,"CENTER_CROP",cb); }
    public static void adminLiveTheme(String token,String action,String key,String name,String backgroundUrl,String accent,boolean enabled,int sortOrder,int coinPrice,String fitMode,Callback cb){ try{post("/v1/admin/live/themes",new JSONObject().put("action",action).put("themeKey",key).put("name",name).put("backgroundUrl",backgroundUrl).put("accent",accent).put("enabled",enabled).put("sortOrder",sortOrder).put("coinPrice",Math.max(0,coinPrice)).put("fitMode",fitMode==null?"CENTER_CROP":fitMode),token,cb);}catch(Exception e){cb.onError("Live theme update failed");} }
    public static void adminLiveUiSettings(String token,float joinFontSize,String joinTextColor,Callback cb){ try{post("/v1/admin/live/ui-settings",new JSONObject().put("joinFontSize",joinFontSize).put("joinTextColor",joinTextColor),token,cb);}catch(Exception e){cb.onError("Live UI settings update failed");} }
    public static void userPosts(String token,String userId,String media,Callback cb){ try{get("/v1/users/posts?userId="+java.net.URLEncoder.encode(userId,"UTF-8")+"&media="+java.net.URLEncoder.encode(media==null?"all":media,"UTF-8"),token,cb);}catch(Exception e){cb.onError("Profile posts unavailable");} }
    public static void profilePrivacy(String token,Callback cb){ get("/v1/me/privacy",token,cb); }
    public static void updateProfilePrivacy(String token,String posts,String media,Callback cb){ try{request("PUT","/v1/me/privacy",new JSONObject().put("postsVisibility",posts).put("mediaVisibility",media),token,cb);}catch(Exception e){cb.onError("Invalid privacy setting");} }
    public static void messageInbox(String token,Callback cb){ get("/v1/messages/inbox",token,cb); }
    public static void messageThread(String token,String userId,Callback cb){ try{get("/v1/messages/thread?userId="+java.net.URLEncoder.encode(userId,"UTF-8"),token,cb);}catch(Exception e){cb.onError("Invalid conversation");} }
    public static void messageTyping(String token,String peer,boolean active,Callback cb){try{post("/v1/messages/typing",new JSONObject().put("userId",peer).put("active",active),token,cb);}catch(Exception e){cb.onError("Typing unavailable");}}
    public static void messageSend(String token,String peer,String message,String nonce,Callback cb){try{post("/v1/messages/send",new JSONObject().put("userId",peer).put("message",message).put("clientNonce",nonce),token,cb);}catch(Exception e){cb.onError("Message failed");}}
    public static void notificationPreferences(String token,Callback cb){get("/v1/notifications/preferences",token,cb);}
    public static void notificationPreferencesSave(String token,JSONObject values,Callback cb){post("/v1/notifications/preferences",values,token,cb);}
    public static void pushDiagnostics(String token,Callback cb){get("/v1/push/diagnostics",token,cb);}
    public static void messageSend(String token,String userId,String message,Callback cb){ try{post("/v1/messages/send",new JSONObject().put("userId",userId).put("message",message),token,cb);}catch(Exception e){cb.onError("Invalid message");} }
    public static void messageVoiceSend(String token,String userId,String mediaUrl,Callback cb){ try{post("/v1/messages/send",new JSONObject().put("userId",userId).put("message","").put("mediaUrl",mediaUrl).put("mediaType","AUDIO"),token,cb);}catch(Exception e){cb.onError("Invalid voice message");} }
    public static void messageMediaUpload(String token,java.io.InputStream input,String filename,String mime,Callback cb){uploadMultipart(token,"/v1/messages/media/upload",input,filename,mime,null,cb);}
    public static void messageMediaSend(String token,String userId,String url,String type,String name,Callback cb){try{post("/v1/messages/send",new JSONObject().put("userId",userId).put("mediaUrl",url).put("mediaType",type).put("message",name),token,cb);}catch(Exception e){cb.onError("Invalid media message");}}
    public static void messageVoiceUpload(String token,java.io.InputStream input,String fileName,String mime,Callback cb){ uploadMultipart(token,"/v1/messages/voice/upload",input,fileName,mime,null,cb); }
    public static void messageUnread(String token,Callback cb){ get("/v1/messages/unread",token,cb); }
    public static void respondFriendRequest(String token,String userId,String action,Callback cb){ try{post("/v1/friends/respond",new JSONObject().put("userId",userId).put("action",action),token,cb);}catch(Exception e){cb.onError("Invalid response");} }
    public static void adminSystemHealth(String token,Callback cb) { get("/v1/admin/system/health",token,cb); }
    public static void feedList(String token, int limit, long before, Callback cb) {
        try {
            String q="/v1/feed?limit="+Math.max(1,Math.min(10,limit));
            if(before>0) q += "&before="+before;
            get(q,token,cb);
        } catch(Exception e){ cb.onError("Invalid Feed request"); }
    }
    public static void feedPost(String token,long postId,Callback cb) {
        try { get("/v1/feed/post?id="+postId,token,cb); } catch(Exception e){ cb.onError("Invalid post request"); }
    }
    public static void videoList(String token,int limit,long before,Callback cb) {
        try { String q="/v1/videos?limit="+Math.max(1,Math.min(30,limit)); if(before>0)q+="&before="+before; get(q,token,cb); }
        catch(Exception e){ cb.onError("Invalid video request"); }
    }
    public static void videoById(String token,long videoId,Callback cb) {
        try { get("/v1/videos?id="+Math.max(0,videoId),token,cb); }
        catch(Exception e){ cb.onError("Invalid video request"); }
    }
    public static void feedUpload(String token, java.io.InputStream input, String fileName, String mime, String mediaType, String caption, Callback cb) {
        uploadMultipart(token,"/v1/feed/upload",input,fileName,mime,new String[][]{{"mediaType",mediaType},{"caption",caption}},cb);
    }
    public static void adminBannerOrder(String token,String folder,JSONArray slots,Callback cb){try{request("POST","/v1/admin/banner-order",new JSONObject().put("folder",folder).put("slots",slots),token,cb);}catch(Exception e){cb.onError("Invalid banner order");}}
    public static void adminBannerSection(String token,String folder,Boolean enabled,Callback cb){try{String path="/v1/admin/banner-section?folder="+java.net.URLEncoder.encode(folder,"UTF-8");if(enabled==null)get(path,token,cb);else request("PUT","/v1/admin/banner-section",new JSONObject().put("folder",folder).put("enabled",enabled),token,cb);}catch(Exception e){cb.onError("Banner section settings unavailable");}}
    public static void feedShare(String token,long id,String event,Callback cb){try{request("POST","/v1/feed/share",new JSONObject().put("postId",id).put("eventId",event),token,cb);}catch(Exception e){cb.onError("Invalid share request");}}
    public static void feedLike(String token,long postId,Callback cb){ try { request("POST","/v1/feed/like",new JSONObject().put("postId",postId),token,cb); } catch(Exception e){ cb.onError("Invalid like request"); } }
    public static void feedEdit(String token,long postId,String caption,Callback cb){try{request("POST","/v1/feed/edit",new JSONObject().put("postId",postId).put("caption",caption==null?"":caption),token,cb);}catch(Exception e){cb.onError("Invalid post edit request");}}
    public static void feedComment(String token,long postId,String comment,Callback cb){ try { request("POST","/v1/feed/comment",new JSONObject().put("postId",postId).put("comment",comment),token,cb); } catch(Exception e){ cb.onError("Invalid comment request"); } }
    public static void feedComments(String token,long postId,Callback cb){ try { get("/v1/feed/comments?postId="+postId,token,cb); } catch(Exception e){ cb.onError("Invalid comments request"); } }
    public static void feedLikeUsers(String token,long postId,Callback cb){ try { get("/v1/feed/likes?postId="+postId,token,cb); } catch(Exception e){ cb.onError("Invalid likes request"); } }
    public static void feedCommentReply(String token,long postId,long parentId,String comment,Callback cb){ try { request("POST","/v1/feed/comment/reply",new JSONObject().put("postId",postId).put("parentId",parentId).put("comment",comment),token,cb); } catch(Exception e){ cb.onError("Invalid reply request"); } }
    public static void feedText(String token,String caption,JSONObject colors,Callback cb){if(colors==null||colors.length()==0){feedText(token,caption,cb);return;}try{request("POST","/v1/feed/text",new JSONObject().put("caption",caption).put("appearance",colors),token,cb);}catch(Exception e){cb.onError("Invalid colored post");}}
    public static void feedUpload(String token,java.io.InputStream in,String name,String mime,String type,String caption,JSONObject colors,Callback cb){if(colors==null||colors.length()==0){feedUpload(token,in,name,mime,type,caption,cb);return;}uploadMultipart(token,"/v1/feed/upload",in,name,mime,new String[][]{{"mediaType",type},{"caption",caption},{"appearance",colors.toString()}},cb);}
    public static void feedText(String token, String caption, Callback cb) { try { request("POST","/v1/feed/text",new JSONObject().put("caption",caption==null?"":caption),token,cb); } catch(Exception e){ cb.onError("Invalid text post request"); } }
    public static void feedDelete(String token,long id,Callback cb) {
        try { post("/v1/feed/delete",new JSONObject().put("id",id),token,cb); } catch(Exception e){ cb.onError("Invalid post delete request"); }
    }
    public static void adminFeedList(String token,Callback cb) { get("/v1/admin/feed",token,cb); }
    public static void moderatorFeedDelete(String token,long id,String reason,Callback cb) {
        try { post("/v1/admin/feed/delete",new JSONObject().put("id",id).put("reason",reason==null?"":reason),token,cb); } catch(Exception e){ cb.onError("Invalid moderation request"); }
    }
    public static void adminSafetyReports(String token,String status,Callback cb){ try{get("/v1/admin/safety/reports?status="+java.net.URLEncoder.encode(status==null?"OPEN":status,"UTF-8"),token,cb);}catch(Exception e){cb.onError("Invalid safety report query");} }
    public static void adminSafetyReportAction(String token,long id,String status,String reason,Callback cb){try{post("/v1/admin/safety/report/action",new JSONObject().put("id",id).put("status",status).put("reason",reason),token,cb);}catch(Exception e){cb.onError("Invalid report");}}
    public static void adminSafetyReportAction(String token,long id,String status,Callback cb){ try{post("/v1/admin/safety/report/action",new JSONObject().put("id",id).put("status",status),token,cb);}catch(Exception e){cb.onError("Invalid safety report action");} }
    public static void adminDeletionRequests(String token,String status,Callback cb){ try{get("/v1/admin/account-deletion-requests?status="+java.net.URLEncoder.encode(status==null?"OPEN":status,"UTF-8"),token,cb);}catch(Exception e){cb.onError("Invalid deletion request query");} }
    public static void adminDeletionRequestAction(String token,long id,String status,Callback cb){ try{post("/v1/admin/account-deletion-request/action",new JSONObject().put("id",id).put("status",status),token,cb);}catch(Exception e){cb.onError("Invalid deletion request action");} }
    public static void markNotificationRead(String token,long id,Callback cb) { try{post("/v1/notifications/read",new JSONObject().put("id",id),token,cb);}catch(Exception e){cb.onError("Invalid notification");} }
    public static void markNotificationsRead(String token,Callback cb) { post("/v1/notifications/read-all", new JSONObject(), token, cb); }
    public static void logout(String token,Callback cb) { post("/v1/auth/logout",new JSONObject(),token,cb); }
    public static void assignedAdminFolders(String token,Callback cb){get("/v1/me/admin-folders",token,cb);}
    public static void folderGrants(String token,String userId,String folder,Callback cb){try{get("/v1/admin/folder-grants?userId="+java.net.URLEncoder.encode(userId,"UTF-8")+"&folder="+java.net.URLEncoder.encode(folder,"UTF-8"),token,cb);}catch(Exception e){cb.onError("Invalid folder");}}
    public static void saveFolderGrant(String token,JSONObject data,Callback cb){request("PUT","/v1/admin/folder-grants",data,token,cb);}
    public static void publishFeatureDraft(String token,JSONObject data,Callback cb){post("/v1/admin/features/publish",data,token,cb);}
    public static void profileMenu(String token,boolean admin,Callback cb){get(admin?"/v1/admin/profile-menu":"/v1/profile-menu",token,cb);}
    public static void profileMenuHistory(String token,long before,Callback cb){get("/v1/admin/profile-menu?history=1&before="+before,token,cb);}
    public static void profileMenuSave(String token,JSONObject data,Callback cb){request("POST","/v1/admin/profile-menu",data,token,cb);}
    public static void draftReview(String token,String after,String search,String kind,Callback cb){try{get("/v1/admin/draft-review?after="+java.net.URLEncoder.encode(after,"UTF-8")+"&search="+java.net.URLEncoder.encode(search,"UTF-8")+"&kind="+java.net.URLEncoder.encode(kind,"UTF-8"),token,cb);}catch(Exception e){cb.onError("Invalid review filter");}}
    public static void featureDraft(String token,String folder,Callback cb){try{get("/v1/admin/features/draft?category="+java.net.URLEncoder.encode(folder,"UTF-8"),token,cb);}catch(Exception e){cb.onError("Invalid folder");}}
    public static void saveFeatureDraft(String token,String folder,JSONObject data,Callback cb){try{request("PUT","/v1/admin/features/draft?category="+java.net.URLEncoder.encode(folder,"UTF-8"),data,token,cb);}catch(Exception e){cb.onError("Invalid draft");}}
    public static void adminPermissions(String token, Callback cb) { get("/v1/admin/permissions", token, cb); }
    public static void updateProfile(String token, String name, String email, String mobile, String bio, String gender, Callback cb) {
        try { request("PUT", "/v1/me/profile", new JSONObject().put("name",name).put("email",email).put("mobile",mobile).put("bio",bio).put("gender",gender), token, cb); }
        catch(Exception e) { cb.onError("Invalid profile data"); }
    }
    public static void uploadAvatar(String token, java.io.InputStream input, String fileName, String mime, Callback cb) {
        uploadMultipart(token,"/v1/me/avatar/upload",input,fileName,mime,null,cb);
    }
    public static void uploadCover(String token, java.io.InputStream input, String fileName, String mime, Callback cb) {
        uploadMultipart(token,"/v1/me/cover/upload",input,fileName,mime,null,cb);
    }
    public static void deleteCover(String token, Callback cb) { post("/v1/me/cover/delete",new JSONObject(),token,cb); }
    public static void coins(String token, Callback cb) { get("/v1/coins",token,cb); }
    public static void giftHistory(String token, Callback cb) { get("/v1/gifts/history",token,cb); }
    public static void requestCoinPurchase(String token, int coins, int amountMinor, String method, String reference, Callback cb) {
        try { request("POST","/v1/coins/purchase-request",new JSONObject().put("coins",coins).put("amountMinor",amountMinor).put("paymentMethod",method).put("reference",reference),token,cb); }
        catch(Exception e) { cb.onError("Invalid coin purchase request"); }
    }
    public static void walletProfile(String token, Callback cb) { get("/v1/wallet/profile",token,cb); }
    public static void friendWishlist611(String token,String uid,Callback cb){get("/v1/store/experience?userId="+uid,token,cb);}
    public static void storeCommissionQuote623(String token,long id,Callback cb){get("/v1/store/commission-quote?productId="+id,token,cb);}
    public static void storeGift611(String token,long id,String uid,long base,long vat,long total,String message,Callback cb){try{post("/v1/store/gift-purchase-request",new JSONObject().put("productId",id).put("recipientUserId",uid).put("expectedBase",base).put("expectedVat",vat).put("expectedTotal",total).put("giftMessage",message),token,cb);}catch(Exception e){cb.onError("Invalid gift");}}
    public static void storeGift611(String token,long id,String uid,long base,long vat,long total,String message,long revision,Callback cb){try{post("/v1/store/gift-purchase-request",new JSONObject().put("productId",id).put("recipientUserId",uid).put("expectedBase",base).put("expectedVat",vat).put("expectedTotal",total).put("expectedCommissionRevision",revision<0?null:Long.valueOf(revision)).put("giftMessage",message),token,cb);}catch(Exception e){cb.onError("Invalid gift");}}
    public static void storePurchase611(String token,long id,boolean renew,long base,long vat,long total,int days,Callback cb){try{post("/v1/store/purchase-request",new JSONObject().put("productId",id).put("paymentMode","GOLD").put("paymentMethod","gold").put("renew",renew).put("expectedBase",base).put("expectedVat",vat).put("expectedTotal",total).put("expectedDays",days),token,cb);}catch(Exception e){cb.onError("Invalid quote");}}
    public static void storePurchase611(String token,long id,boolean renew,long base,long vat,long total,int days,long revision,Callback cb){try{post("/v1/store/purchase-request",new JSONObject().put("productId",id).put("paymentMode","GOLD").put("paymentMethod","gold").put("renew",renew).put("expectedBase",base).put("expectedVat",vat).put("expectedTotal",total).put("expectedCommissionRevision",revision<0?null:Long.valueOf(revision)).put("expectedDays",days),token,cb);}catch(Exception e){cb.onError("Invalid quote");}}
    public static void storeExperience(String token,boolean admin,Callback cb){get(admin?"/v1/admin/store/experience":"/v1/store/experience",token,cb);}
    public static void storeExperienceSave(String token,boolean admin,JSONObject data,Callback cb){post(admin?"/v1/admin/store/experience":"/v1/store/experience",data,token,cb);}
    public static void storeCatalog(String token, Callback cb) { get("/v1/store/catalog",token,cb); }
    public static void adminStoreCatalog(String token, Callback cb) { get("/v1/admin/store/catalog",token,cb); }
    public static void storePurchaseIntent(String token,long productId,Callback cb){ try{request("POST","/v1/store/purchase-intent",new JSONObject().put("productId",productId),token,cb);}catch(Exception e){cb.onError("Invalid premium purchase intent");} }
    public static void storePurchase(String token,long productId,String paymentMode,String method,String reference,Callback cb){ try{request("POST","/v1/store/purchase-request",new JSONObject().put("productId",productId).put("paymentMode",paymentMode).put("paymentMethod",method).put("reference",reference),token,cb);}catch(Exception e){cb.onError("Invalid store purchase");} }
    public static void storeGiftPurchaseQuoted(String token,long productId,String recipientUserId,long expectedBase,long expectedVat,long expectedTotal,Callback cb){try{request("POST","/v1/store/gift-purchase-request",new JSONObject().put("productId",productId).put("recipientUserId",recipientUserId).put("expectedBase",expectedBase).put("expectedVat",expectedVat).put("expectedTotal",expectedTotal),token,cb);}catch(Exception e){cb.onError("Invalid gift quote");}}
    public static void storeGiftPurchase(String token,long productId,String recipientUserId,Callback cb){ try{request("POST","/v1/store/gift-purchase-request",new JSONObject().put("productId",productId).put("recipientUserId",recipientUserId),token,cb);}catch(Exception e){cb.onError("Invalid gift purchase");} }
    public static void liveTvChannels(String token,Callback cb){ get("/v1/live-tv/channels",token,cb); }
    public static void adminLiveTvChannels(String token,Callback cb){ get("/v1/admin/live-tv/channels",token,cb); }
    public static void adminLiveTvSave(String token,JSONObject item,Callback cb){ request("POST","/v1/admin/live-tv/save",item,token,cb); }
    public static void adminLiveTvDelete(String token,long id,Callback cb){ try{request("POST","/v1/admin/live-tv/delete",new JSONObject().put("id",id),token,cb);}catch(Exception e){cb.onError("Invalid channel delete");} }
    /** Legacy route kept for old callers; server now creates an Admin-approved pending request instead of instant activation. */
    public static void storeDirectPurchase(String token,long productId,String paymentMode,Callback cb){ try{request("POST","/v1/store/purchase",new JSONObject().put("productId",productId).put("paymentMode",paymentMode),token,cb);}catch(Exception e){cb.onError("Invalid premium purchase request");} }
    public static void blockUser(String token,String userId,boolean blocked,Callback cb){ try{request("POST","/v1/safety/block",new JSONObject().put("userId",userId).put("blocked",blocked),token,cb);}catch(Exception e){cb.onError("Invalid block request");} }
    public static void blockedUsers(String token,Callback cb){ get("/v1/safety/blocks",token,cb); }
    public static void liveMutedUsers(String token,Callback cb){ get("/v1/live/muted-users",token,cb); }
    public static void unmuteSavedLiveUser(String token,String userId,Callback cb){ try{post("/v1/live/muted-users/unmute",new JSONObject().put("userId",userId),token,cb);}catch(Exception e){cb.onError("Unmute failed");} }
    public static void report(String token,String targetUserId,String contentType,String contentId,String reason,String details,Callback cb){ try{request("POST","/v1/safety/report",new JSONObject().put("targetUserId",targetUserId==null?"":targetUserId).put("contentType",contentType==null?"USER":contentType).put("contentId",contentId==null?"":contentId).put("reason",reason==null?"OTHER":reason).put("details",details==null?"":details),token,cb);}catch(Exception e){cb.onError("Invalid report");} }
    public static void deleteAccount(String token,String password,Callback cb){ try{request("POST","/v1/account/delete",new JSONObject().put("password",password),token,cb);}catch(Exception e){cb.onError("Invalid delete request");} }
    public static void deleteAccountGoogle(String token,String googleIdToken,Callback cb){try{request("POST","/v1/account/delete",new JSONObject().put("googleIdToken",googleIdToken),token,cb);}catch(Exception e){cb.onError("Invalid deletion verification");}}
    public static void accountDeletionRequest(String identifier,String contact,String reason,Callback cb){ try{request("POST","/v1/account/deletion-request",new JSONObject().put("identifier",identifier).put("contact",contact).put("reason",reason),null,cb);}catch(Exception e){cb.onError("Invalid deletion request");} }
    public static void playBillingReady(String token,long catalogId,String productId,Callback cb){ try{get("/v1/play/billing-ready?catalogId="+catalogId+"&productId="+java.net.URLEncoder.encode(productId,"UTF-8"),token,cb);}catch(Exception e){cb.onError("Google Play product is not ready");} }
    public static void playPurchaseVerify(String token,long catalogId,String productId,String purchaseToken,Callback cb){ try{request("POST","/v1/play/purchase/verify",new JSONObject().put("catalogId",catalogId).put("productId",productId).put("purchaseToken",purchaseToken),token,cb);}catch(Exception e){cb.onError("Google Play verification failed");} }
    public static void setActiveBadge(String token,long badgeId,Callback cb){ try{request("POST","/v1/badges/active",new JSONObject().put("badgeId",badgeId),token,cb);}catch(Exception e){cb.onError("Invalid badge selection");} }
    public static void adminStoreSave(String token,JSONObject item,Callback cb){ request("POST","/v1/admin/store/catalog/save",item,token,cb); }
    public static void adminStoreToggle(String token,long id,boolean enabled,Callback cb){ try{request("POST","/v1/admin/store/catalog/toggle",new JSONObject().put("id",id).put("enabled",enabled),token,cb);}catch(Exception e){cb.onError("Invalid catalog item");} }
    public static void adminStoreDelete(String token,long id,Callback cb){ try{request("POST","/v1/admin/store/catalog/delete",new JSONObject().put("id",id),token,cb);}catch(Exception e){cb.onError("Invalid catalog item");} }
    public static void adminStoreReorder(String token,long sourceId,long targetId,Callback cb){ try{request("POST","/v1/admin/store/catalog/reorder",new JSONObject().put("sourceId",sourceId).put("targetId",targetId),token,cb);}catch(Exception e){cb.onError("Invalid catalog reorder");} }
    public static void adminStoreRevoke(String token,String userId,long entitlementId,String kind,Callback cb){try{post("/v1/admin/store/revoke",new JSONObject().put("userId",userId).put("entitlementId",entitlementId).put("entitlementKind",kind),token,cb);}catch(Exception e){cb.onError("Invalid removal request");}}
    public static void adminStoreGrant626(String token,String userId,JSONArray ids,boolean extend,String key,Callback cb){try{post("/v1/admin/store/grant",new JSONObject().put("userId",userId).put("productIds",ids).put("extend",extend).put("requestKey",key),token,cb);}catch(Exception e){cb.onError("Invalid grant");}}
    public static void adminStoreGrant(String token,String userId,long productId,String note,Callback cb){ try{request("POST","/v1/admin/store/grant",new JSONObject().put("userId",userId).put("productId",productId).put("note",note).put("requestKey",java.util.UUID.randomUUID().toString()),token,cb);}catch(Exception e){cb.onError("Invalid catalog grant");} }
    public static void adminStorePurchaseRequests(String token,Callback cb){ get("/v1/admin/store/purchase-requests",token,cb); }
    public static void adminStorePurchaseDecision(String token,long requestId,String action,Callback cb){ adminStorePurchaseDecision(token,requestId,action,"",cb); }
    public static void adminStorePurchaseDecision(String token,long requestId,String action,String note,Callback cb){ try{request("POST","/v1/admin/store/purchase-decision",new JSONObject().put("requestId",requestId).put("action",action).put("note",note==null?"":note),token,cb);}catch(Exception e){cb.onError("Invalid purchase decision");} }
    public static void adminStoreReconcileHolds(String token,Callback cb){ try{request("POST","/v1/admin/store/reconcile-holds",new JSONObject(),token,cb);}catch(Exception e){cb.onError("Hold reconciliation failed");} }
    public static void adminPremiumPaymentSettings(String token,Callback cb){ get("/v1/admin/store/payment-settings",token,cb); }
    public static void adminPremiumPaymentSettingsSave(String token,JSONObject settings,Callback cb){ request("POST","/v1/admin/store/payment-settings/save",settings,token,cb); }
    public static void adminStoreAssetUpload(String token,java.io.InputStream input,String fileName,String mime,Callback cb){ uploadMultipart(token,"/v1/admin/store/asset/upload",input,fileName,mime,null,cb); }
    public static void adminAssetUpload(String token,java.io.InputStream input,String fileName,String mime,String purpose,Callback cb){ uploadMultipart(token,"/v1/admin/asset/upload",input,fileName,mime,new String[][]{{"purpose",purpose==null?"asset":purpose}},cb); }
    public static void requestWalletPurchase(String token,String itemType,String itemCode,int units,int amountMinor,String method,String reference,String duration,Callback cb){
        try{ request("POST","/v1/wallet/purchase-request",new JSONObject().put("itemType",itemType).put("itemCode",itemCode).put("units",units).put("amountMinor",amountMinor).put("paymentMethod",method).put("reference",reference).put("duration",duration),token,cb); }catch(Exception e){cb.onError("Invalid purchase request");}
    }
    public static void bankAccount(String token,Callback cb){get("/v1/me/bank-account",token,cb);}
    public static void bankAccountSave(String token,JSONObject values,boolean remove,Callback cb){request(remove?"DELETE":"PUT","/v1/me/bank-account",values,token,cb);}
    public static void withdrawalOptions(String token,String currency,Callback cb){get("/v1/wallet/withdraw-options?currency="+currency,token,cb);}
    public static void withdrawalCatalog(String token,String currency,Callback cb){get("/v1/admin/withdraw-catalog?currency="+currency,token,cb);}
    public static void withdrawalCatalogSave(String token,JSONObject data,Callback cb){post("/v1/admin/withdraw-catalog",data,token,cb);}
    public static void requestQuotedWithdrawal(android.content.Context context,String token,String currency,int units,String method,String account,String note,JSONObject quote,Callback cb){
        try{WithdrawalOperation operation=WithdrawalOperation.begin(context,currency,units,method,account,note);request("POST",currency.equals("GOLD")?"/v1/wallet/withdraw-request":"/v1/wallet/coin-withdraw-request",new JSONObject().put(currency.equals("GOLD")?"gold":"coin",units).put("paymentMethod",method).put("account",account).put("note",note).put("confirmedQuote",quote).put("requestKey",operation.key),token,new Callback(){public void onSuccess(JSONObject d){operation.confirmed();cb.onSuccess(d);}public void onError(String m){cb.onError(m);}});}catch(Exception e){cb.onError("Could not safely prepare withdrawal");}
    }
    public static void requestGoldWithdrawal(android.content.Context context,String token,int gold,String method,String account,String note,Callback cb){
        requestWithdrawal(context,token,"GOLD",gold,method,account,note,cb);
    }
    public static void requestCoinWithdrawal(android.content.Context context,String token,int coins,String method,String account,String note,Callback cb){
        requestWithdrawal(context,token,"COIN",coins,method,account,note,cb);
    }
    private static void requestWithdrawal(android.content.Context context,String token,String currency,int units,String method,String account,String note,Callback cb){
        try{
            WithdrawalOperation operation=WithdrawalOperation.begin(context,currency,units,method,account,note);
            request("POST",currency.equals("GOLD")?"/v1/wallet/withdraw-request":"/v1/wallet/coin-withdraw-request",new JSONObject().put(currency.equals("GOLD")?"gold":"coin",units).put("paymentMethod",method).put("account",account).put("note",note).put("requestKey",operation.key),token,new Callback(){
                public void onSuccess(JSONObject data){operation.confirmed();cb.onSuccess(data);}
                public void onError(String message){cb.onError(message);}
            });
        }catch(Exception e){cb.onError("Could not safely prepare withdrawal request");}
    }
    public static void adminWalletRemove(String token,String uid,String currency,long amount,String note,String requestKey,Callback cb){try{post("/v1/admin/wallet/remove",new JSONObject().put("userId",uid).put("currency",currency).put("amount",amount).put("note",note).put("requestKey",requestKey),token,cb);}catch(Exception e){cb.onError("Invalid wallet removal");}}
    public static void folderNotices(String token,String kind,Callback cb){get("/v1/admin/folder-notices?kind="+kind,token,cb);}
    public static void folderNoticeRead(String token,String key,Callback cb){try{post("/v1/admin/folder-notices",new JSONObject().put("eventKey",key),token,cb);}catch(Exception e){cb.onError("Invalid event");}}
    public static void adminRequestNotices(String token,Callback cb){get("/v1/admin/request-notices",token,cb);}
    public static void markAdminRequestNoticesRead(String token,Callback cb){post("/v1/admin/request-notices",new JSONObject(),token,cb);}
    public static void payoutAction(String token,long id,String action,String note,Callback cb){try{post("/v1/admin/payouts/action",new JSONObject().put("id",id).put("action",action).put("note",note),token,cb);}catch(Exception e){cb.onError("Invalid payout action");}}
    public static void payoutInbox(String token,boolean admin,String currency,long before,Callback cb){get((admin?"/v1/admin/payouts":"/v1/payouts")+"?currency="+("GOLD".equals(currency)?"GOLD":"COIN")+(before>0?"&before="+before:""),token,cb);}
    public static void ownedItems(String token,Callback cb){ get("/v1/wallet/owned-items",token,cb); }
    public static void equipOwnedItem(String token,long id,Callback cb){ try{ request("POST","/v1/wallet/owned-items/equip",new JSONObject().put("id",id),token,cb); }catch(Exception e){cb.onError("Invalid item selection");} }
    public static void adminWalletGrant(String token,String userId,String itemType,String itemCode,int units,int days,String note,Callback cb){
        try{ request("POST","/v1/admin/wallet/grant",new JSONObject().put("userId",userId).put("itemType",itemType).put("itemCode",itemCode).put("units",units).put("days",days).put("note",note),token,cb); }catch(Exception e){cb.onError("Invalid admin grant");}
    }
    public static void adminWalletPreview(String token,String userId,Callback cb){ try{ get("/v1/admin/wallet/preview?userId="+java.net.URLEncoder.encode(userId,"UTF-8"),token,cb); }catch(Exception e){cb.onError("User preview unavailable");} }

    public static void adminDashboardPut(String token, String breakingNews, String myShopUrl, String liveTvUrl, String externalMovieUrl, String chatUrl, String powerAdTitle, String powerAdByline, Callback cb) {
        adminDashboardPut(token,breakingNews,myShopUrl,liveTvUrl,externalMovieUrl,chatUrl,powerAdTitle,powerAdByline,null,null,null,null,cb);
    }
    public static void adminDashboardPut(String token, String breakingNews, String myShopUrl, String liveTvUrl, String externalMovieUrl, String chatUrl, String powerAdTitle, String powerAdByline, String dashboardBgColor, String dashboardBlueColor, String dashboardPurpleColor, String dashboardPinkColor, Callback cb) {
        adminDashboardPutInternal(token,breakingNews,myShopUrl,liveTvUrl,externalMovieUrl,chatUrl,powerAdTitle,powerAdByline,dashboardBgColor,dashboardBlueColor,dashboardPurpleColor,dashboardPinkColor,null,null,null,cb);
    }
    public static void adminDashboardPut(String token, String breakingNews, String myShopUrl, String liveTvUrl, String externalMovieUrl, String chatUrl, String powerAdTitle, String powerAdByline, String dashboardBgColor, String dashboardBlueColor, String dashboardPurpleColor, String dashboardPinkColor, float breakingNewsTextSize, Callback cb) {
        adminDashboardPutInternal(token,breakingNews,myShopUrl,liveTvUrl,externalMovieUrl,chatUrl,powerAdTitle,powerAdByline,dashboardBgColor,dashboardBlueColor,dashboardPurpleColor,dashboardPinkColor,breakingNewsTextSize,null,null,cb);
    }
    public static void adminDashboardPut(String token, String breakingNews, String myShopUrl, String liveTvUrl, String externalMovieUrl, String chatUrl, String powerAdTitle, String powerAdByline, String dashboardBgColor, String dashboardBlueColor, String dashboardPurpleColor, String dashboardPinkColor, float breakingNewsTextSize, String breakingNewsBgColor, String breakingNewsTextColor, Callback cb) {
        adminDashboardPutInternal(token,breakingNews,myShopUrl,liveTvUrl,externalMovieUrl,chatUrl,powerAdTitle,powerAdByline,dashboardBgColor,dashboardBlueColor,dashboardPurpleColor,dashboardPinkColor,breakingNewsTextSize,breakingNewsBgColor,breakingNewsTextColor,cb);
    }
    private static void adminDashboardPutInternal(String token, String breakingNews, String myShopUrl, String liveTvUrl, String externalMovieUrl, String chatUrl, String powerAdTitle, String powerAdByline, String dashboardBgColor, String dashboardBlueColor, String dashboardPurpleColor, String dashboardPinkColor, Float breakingNewsTextSize, String breakingNewsBgColor, String breakingNewsTextColor, Callback cb) {
        try {
            JSONObject b = new JSONObject().put("breakingNews", breakingNews).put("myShopUrl", myShopUrl).put("liveTvUrl", liveTvUrl).put("externalMovieUrl", externalMovieUrl).put("chatUrl", chatUrl).put("powerAdTitle", powerAdTitle).put("powerAdByline", powerAdByline);
            if(dashboardBgColor!=null)b.put("dashboardBgColor",dashboardBgColor); if(dashboardBlueColor!=null)b.put("dashboardBlueColor",dashboardBlueColor); if(dashboardPurpleColor!=null)b.put("dashboardPurpleColor",dashboardPurpleColor); if(dashboardPinkColor!=null)b.put("dashboardPinkColor",dashboardPinkColor);
            if(breakingNewsTextSize!=null)b.put("breakingNewsTextSize",breakingNewsTextSize); if(breakingNewsBgColor!=null)b.put("breakingNewsBgColor",breakingNewsBgColor); if(breakingNewsTextColor!=null)b.put("breakingNewsTextColor",breakingNewsTextColor);
            request("PUT", "/v1/admin/dashboard/config", b, token, cb);
        } catch(Exception e) { cb.onError("Invalid admin settings"); }
    }
    public static void adminTemporaryBlock(String token,String uid,int hours,Callback cb){try{post("/v1/admin/actions",new JSONObject().put("userId",uid).put("action","temporary_block").put("hours",hours),token,cb);}catch(Exception e){cb.onError("Invalid block duration");}}
    public static void adminModeratorDirectory(String token,String query,Callback cb){get("/v1/admin/moderator-directory?"+query,token,cb);}
    public static void adminModeratorChange(String token,String uid,String action,String note,Callback cb){try{post("/v1/admin/actions",new JSONObject().put("userId",uid).put("action",action).put("note",note),token,cb);}catch(Exception e){cb.onError("Invalid moderator action");}}
    public static void adminAction(String token, String userId, String action, Callback cb) {
        try {
            JSONObject b = new JSONObject().put("userId", userId).put("action", action);
            post("/v1/admin/actions", b, token, cb);
        } catch(Exception e) { cb.onError("Invalid admin action"); }
    }
    public static void appThemes(String token,boolean admin,Callback cb){request("GET",admin?"/v1/admin/app/themes":"/v1/app/themes",null,token,cb);}
    public static void saveAppThemes(String token,JSONObject value,Callback cb){request("PUT","/v1/admin/app/themes",value,token,cb);}
    public static void upcomingReminder(String token,String scope,String eventId,boolean enabled,Callback cb){try{post("/v1/upcoming-live/reminder",new JSONObject().put("scope",scope).put("eventId",eventId).put("enabled",enabled),token,cb);}catch(Exception e){cb.onError("Reminder update failed");}}
    public static void upcomingLive(String token,boolean admin,String scope,Callback cb){request("GET",(admin?"/v1/admin/upcoming-live":"/v1/upcoming-live")+"?scope="+scope,null,token,cb);}
    public static void saveUpcomingLive(String token,JSONObject value,String scope,Callback cb){request("PUT","/v1/admin/upcoming-live?scope="+scope,value,token,cb);}
    public static void upcomingLive(String token,boolean admin,Callback cb){request("GET",admin?"/v1/admin/upcoming-live":"/v1/upcoming-live",null,token,cb);}
    public static void saveUpcomingLive(String token,JSONObject value,Callback cb){request("PUT","/v1/admin/upcoming-live",value,token,cb);}
    public static void contentTranslations(String token,Callback cb){request("GET","/v1/content/translations",null,token,cb);}
    public static void saveContentTranslations(String token,JSONObject value,Callback cb){request("PUT","/v1/admin/content/translations",value,token,cb);}
    public static void featureHistory(String token,String category,Callback cb){get("/v1/admin/features/history?category="+category,token,cb);}
    public static void saveFeatureHistory(String token,String category,JSONObject payload,Callback cb){post("/v1/admin/features/history?category="+category,payload,token,cb);}
    public static void adminContentPut(String token, JSONObject payload, Callback cb) { request("PUT", "/v1/admin/content", payload, token, cb); }
    public static void adminMediaList(String token, String folder, Callback cb) {
        String f = folder == null ? "" : folder.trim().toLowerCase();
        try { get("/v1/admin/media?folder=" + java.net.URLEncoder.encode(f,"UTF-8"), token, cb); }
        catch(Exception e) { cb.onError("Invalid gallery folder"); }
    }
    public static void adminBannerDelete(String token, String folder, int slot, Callback cb) { try { post("/v1/admin/banner/delete", new JSONObject().put("folder",folder).put("slot",slot), token, cb); } catch(Exception e) { cb.onError("Invalid banner slot"); } }
    public static void adminBannerUpload(String token, java.io.InputStream input, String fileName, String mime, String folder, int slot, String caption, String targetUrl, Callback cb) { adminBannerUpload(token,input,fileName,mime,folder,slot,caption,targetUrl,"","",cb); }
    public static void adminBannerUpdate(String token, String folder, int slot, String caption, String targetUrl, Callback cb) { try { request("PUT", "/v1/admin/banner/update", new JSONObject().put("folder",folder).put("slot",slot).put("caption",caption).put("targetUrl",targetUrl), token, cb); } catch(Exception e) { cb.onError("Invalid banner update"); } }
    public static void adminBannerUpdate(String token, String folder, int slot, String caption, String targetUrl, boolean active, String startAt, String endAt, Callback cb) { try { request("PUT", "/v1/admin/banner/update", new JSONObject().put("folder",folder).put("slot",slot).put("caption",caption).put("targetUrl",targetUrl).put("active",active).put("startAt",startAt).put("endAt",endAt), token, cb); } catch(Exception e) { cb.onError("Invalid banner update"); } }
    public static void adminBannerUpdate(String token,String folder,int slot,String caption,String targetUrl,boolean active,String startAt,String endAt,int displaySeconds,Callback cb){try{request("PUT","/v1/admin/banner/update",new JSONObject().put("folder",folder).put("slot",slot).put("caption",caption).put("targetUrl",targetUrl).put("active",active).put("startAt",startAt).put("endAt",endAt).put("displaySeconds",displaySeconds),token,cb);}catch(Exception e){cb.onError("Invalid banner update");}}
    public static void adminBannerUpdate(String token, String folder, int slot, String caption, String targetUrl, boolean active, Callback cb) { adminBannerUpdate(token,folder,slot,caption,targetUrl,active,"","",cb); }
    /** Page 2 independently managed main/product advertising folders. */
    public static void adminBannerFolder(String token,String folder,Callback cb){
        if(folder==null||!folder.matches("hero|promo|live_home|live2_promo_[1-4]|shop_home|shop_promo")){cb.onError("Invalid banner folder");return;}
        get("/v1/admin/live-home/banners?folder="+folder,token,cb);
    }
    public static void adminMembershipGrant(String token,String userId,long productId,int days,Callback cb){
        try{post("/v1/admin/store/grant",new JSONObject().put("userId",userId).put("productId",productId).put("durationDays",days).put("note","Membership Admin direct grant"),token,cb);}catch(Exception e){cb.onError("Invalid membership request");}
    }
    public static void adminMembershipRevoke(String token,String userId,String note,Callback cb){
        try{post("/v1/admin/store/membership/revoke",new JSONObject().put("userId",userId).put("note",note),token,cb);}catch(Exception e){cb.onError("Invalid membership request");}
    }
    public static void adminGeneralOrder(String token,JSONObject payload,Callback cb){post("/v1/admin/general-menu/order",payload,token,cb);}
    public static void bannerFolder(String token,String folder,Callback cb){if(!"shop_home".equals(folder)&&!"shop_promo".equals(folder)){cb.onError("Invalid banner folder");return;}get("/v1/shop/banners?folder="+folder,token,cb);}
    public static void adminLiveHomeBanners(String token, Callback cb) { get("/v1/admin/live-home/banners",token,cb); }
    public static void adminBannerUpload(String token, java.io.InputStream input, String fileName, String mime, String folder, int slot, String caption, String targetUrl, String startAt, String endAt, Callback cb) {
        uploadMultipart(token,"/v1/admin/banner/upload",input,fileName,mime,new String[][]{{"folder",folder},{"slot",String.valueOf(slot)},{"caption",caption},{"targetUrl",targetUrl},{"startAt",startAt},{"endAt",endAt}},cb);
    }
    public static void adminBannerUpload(String token,java.io.InputStream input,String fileName,String mime,String folder,int slot,String caption,String targetUrl,String startAt,String endAt,int displaySeconds,Callback cb){uploadMultipart(token,"/v1/admin/banner/upload",input,fileName,mime,new String[][]{{"folder",folder},{"slot",String.valueOf(slot)},{"caption",caption},{"targetUrl",targetUrl},{"startAt",startAt},{"endAt",endAt},{"displaySeconds",String.valueOf(displaySeconds)}},cb);}
    public static void adminMediaDelete(String token, long id, Callback cb) { try { post("/v1/admin/media/delete", new JSONObject().put("id", id), token, cb); } catch(Exception e) { cb.onError("Invalid media id"); } }
    public static void adminMediaUpdate(String token, long id, String title, String caption, Callback cb) { try { request("PUT", "/v1/admin/media/update", new JSONObject().put("id",id).put("title",title).put("caption",caption), token, cb); } catch(Exception e) { cb.onError("Invalid media update"); } }

    // User-owned Gallery: unlimited item count; each file is still subject to server/R2 limits.
    public static void galleryList(String token, String folder, Callback cb) {
        try { get("/v1/gallery?folder=" + java.net.URLEncoder.encode(folder==null?"":folder,"UTF-8"), token, cb); }
        catch(Exception e) { cb.onError("Invalid gallery folder"); }
    }
    public static void galleryUpload(String token, java.io.InputStream input, String fileName, String mime, String folder, String title, String caption, Callback cb) {
        uploadMultipart(token,"/v1/gallery/upload",input,fileName,mime,new String[][]{{"folder",folder},{"title",title},{"caption",caption}},cb);
    }
    public static void galleryUpdate(String token,long id,String title,String caption,Callback cb) {
        try { request("PUT","/v1/gallery/update",new JSONObject().put("id",id).put("title",title).put("caption",caption),token,cb); }
        catch(Exception e){ cb.onError("Invalid Gallery edit request"); }
    }
    public static void galleryDelete(String token,long id,Callback cb) {
        try { post("/v1/gallery/delete",new JSONObject().put("id",id),token,cb); }
        catch(Exception e){ cb.onError("Invalid Gallery delete request"); }
    }
    public static void adminAds(String token,String boxKey,Callback cb) {
        try { get("/v1/admin/ads?box_key="+java.net.URLEncoder.encode(boxKey==null?"":boxKey,"UTF-8"),token,cb); }
        catch(Exception e){ cb.onError("Invalid ad folder"); }
    }
    public static void adminAdUpload(String token,java.io.InputStream input,String fileName,String mime,String boxKey,int slot,String caption,String targetUrl,boolean active,int durationSec,String displayMode,Callback cb) {
        uploadMultipart(token,"/v1/admin/ad/upload",input,fileName,mime,new String[][]{{"boxKey",boxKey},{"slot",String.valueOf(slot)},{"caption",caption},{"targetUrl",targetUrl},{"active",String.valueOf(active)},{"durationSec",String.valueOf(durationSec)},{"displayMode",displayMode==null?"FULL_IMAGE":displayMode}},cb);
    }
    public static void adminAdUpload(String token,java.io.InputStream input,String fileName,String mime,String boxKey,int slot,String caption,String targetUrl,boolean active,int durationSec,Callback cb) {
        adminAdUpload(token,input,fileName,mime,boxKey,slot,caption,targetUrl,active,durationSec,"FULL_IMAGE",cb);
    }
    public static void adminAdUpload(String token,java.io.InputStream input,String fileName,String mime,String boxKey,int slot,String caption,String targetUrl,int durationSec,Callback cb) {
        adminAdUpload(token,input,fileName,mime,boxKey,slot,caption,targetUrl,true,durationSec,"FULL_IMAGE",cb);
    }
    public static void adminAdUpdate(String token,long id,String caption,String targetUrl,boolean active,int durationSec,String displayMode,Callback cb) {
        try { request("PUT","/v1/admin/ad/update",new JSONObject().put("id",id).put("caption",caption).put("targetUrl",targetUrl).put("active",active).put("durationSec",durationSec).put("displayMode",displayMode==null?"FULL_IMAGE":displayMode),token,cb); }
        catch(Exception e){ cb.onError("Invalid ad update request"); }
    }
    public static void adminAdUpdate(String token,long id,String caption,String targetUrl,boolean active,int durationSec,Callback cb) {
        adminAdUpdate(token,id,caption,targetUrl,active,durationSec,"FULL_IMAGE",cb);
    }
    public static void adminAdDelete(String token,long id,Callback cb) {
        try { post("/v1/admin/ad/delete",new JSONObject().put("id",id),token,cb); }
        catch(Exception e){ cb.onError("Invalid ad delete request"); }
    }

    public static void adminMediaUpload(String token, java.io.InputStream input, long length, String fileName, String mime, String folder, String title, String caption, int displayOrder, Callback cb) {
        IO.execute(() -> {
            HttpURLConnection c=null; String boundary="----MYSHOP"+System.currentTimeMillis();
            try {
                c=(HttpURLConnection)new URL(baseUrl()+"/v1/admin/media/upload").openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setDoOutput(true); c.setChunkedStreamingMode(8192); c.setRequestProperty("Accept","application/json"); c.setRequestProperty("Authorization","Bearer "+token); c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
                try(OutputStream os=c.getOutputStream()) {
                    writePart(os,boundary,"folder",folder,null,null); writePart(os,boundary,"title",title,null,null); writePart(os,boundary,"caption",caption,null,null); writePart(os,boundary,"displayOrder",String.valueOf(displayOrder),null,null);
                    String safe=fileName==null?"media":fileName.replace("\"","_");
                    os.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\"file\"; filename=\""+safe+"\"\r\nContent-Type: "+(mime==null?"application/octet-stream":mime)+"\r\n\r\n").getBytes(StandardCharsets.UTF_8));
                    byte[] buf=new byte[8192]; int n; while((n=input.read(buf))!=-1) os.write(buf,0,n); os.write("\r\n".getBytes(StandardCharsets.UTF_8)); os.write(("--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8));
                } finally { try { input.close(); } catch(Exception ignored){} }
                int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream(); StringBuilder outText=new StringBuilder(); if(in!=null){try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)outText.append(line);}}
                JSONObject out=outText.length()>0?new JSONObject(outText.toString()):new JSONObject(); MAIN.post(() -> {if(code>=200&&code<300)cb.onSuccess(out);else cb.onError(errorText(out,code));});
            } catch(Exception e){ MAIN.post(() -> cb.onError("Media upload failed: "+e.getMessage())); } finally {if(c!=null)c.disconnect();}
        });
    }
    private static void uploadMultipart(String token,String path,java.io.InputStream input,String fileName,String mime,String[][] fields,Callback cb){
        IO.execute(() -> { HttpURLConnection c=null; String boundary="----MYSHOP"+System.currentTimeMillis(); try {
            c=(HttpURLConnection)new URL(baseUrl()+path).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setDoOutput(true); c.setChunkedStreamingMode(8192); c.setRequestProperty("Accept","application/json"); c.setRequestProperty("Authorization","Bearer "+token); c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
            try(OutputStream os=c.getOutputStream()){ if(fields!=null)for(String[] f:fields)writePart(os,boundary,f[0],f[1],null,null); String safe=fileName==null?"media":fileName.replace("\"","_"); os.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\"file\"; filename=\""+safe+"\"\r\nContent-Type: "+(mime==null?"application/octet-stream":mime)+"\r\n\r\n").getBytes(StandardCharsets.UTF_8)); byte[] buf=new byte[8192];int n;while((n=input.read(buf))!=-1)os.write(buf,0,n);os.write("\r\n".getBytes(StandardCharsets.UTF_8));os.write(("--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8)); } finally {try{input.close();}catch(Exception ignored){}}
            int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();StringBuilder st=new StringBuilder();if(in!=null){try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)st.append(line);}} JSONObject out=st.length()>0?new JSONObject(st.toString()):new JSONObject();MAIN.post(()->{if(code>=200&&code<300)cb.onSuccess(out);else cb.onError(errorText(out,code));});
        }catch(Exception e){MAIN.post(()->cb.onError("Upload failed: "+e.getMessage()));}finally{if(c!=null)c.disconnect();}});
    }

    private static void writePart(OutputStream os,String boundary,String name,String value,String ignored1,String ignored2) throws Exception { String v=value==null?"":value; os.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\""+name+"\"\r\n\r\n"+v+"\r\n").getBytes(StandardCharsets.UTF_8)); }

    public static void commerce(String path,JSONObject data,String token,Callback cb){request(data==null?"GET":"POST","/v1/commerce/"+path,data,token,cb);}
    public static void userVerification(String token,String id,Callback cb){get("/v1/users/verification?ids="+id,token,cb);}
    public static void adminUserVerification(String token,String id,boolean verified,Callback cb){adminUserVerification(token,id,verified,30,cb);}
    public static void adminUserVerification(String token,String id,boolean verified,int expiresInDays,Callback cb){try{post("/v1/admin/user-verification",new JSONObject().put("userId",id).put("verified",verified).put("expiresInDays",Math.max(1,Math.min(3650,expiresInDays))),token,cb);}catch(Exception e){cb.onError("Invalid verification request");}}
 public static void overlayPlacements(String token,String kind,Callback cb){request("GET","/v1/admin/overlay-placements?kind="+kind,null,token,cb);}
 public static void overlayPlacementsSave(String token,JSONObject data,Callback cb){request("POST","/v1/admin/overlay-placements",data,token,cb);}
    public static void visualDesign(String token,String scope,boolean admin,Callback cb){get((admin?"/v1/admin/visual-design":"/v1/visual-design")+"?scope="+scope,token,cb);}
    public static void visualDesignHistory(String token,String scope,Callback cb){get("/v1/admin/visual-design?scope="+scope+"&history=1",token,cb);}
    public static void visualDesignSave(String token,JSONObject data,Callback cb){post("/v1/admin/visual-design",data,token,cb);}
    public static void panelDesign(String token,String scope,Callback cb){get("/v1/panel-design?scope="+scope,token,cb);}
    public static void panelDesignSave(String token,JSONObject data,Callback cb){post("/v1/admin/panel-design",data,token,cb);}
    public static void miniAds(String token,String scope,boolean admin,Callback cb){get("/v1/mini-ads?scope="+scope+(admin?"&admin=1":""),token,cb);}
    public static void miniAdsSave(String token,JSONObject data,Callback cb){post("/v1/admin/mini-ads",data,token,cb);}
    public static void headlineStrip(String token,String scope,boolean admin,Callback cb){get("/v1/headline-strip?scope="+scope+(admin?"&admin=1":""),token,cb);}
    public static void headlineStripSave(String token,JSONObject data,Callback cb){post("/v1/admin/headline-strip",data,token,cb);}
    public static void miniAdEvent(String token,JSONObject data,Callback cb){post("/v1/mini-ads/event",data,token,cb);}
    private static void get(String path,String token,Callback cb) { request("GET",path,null,token,cb); }
    private static void post(String path,JSONObject body,String token,Callback cb) { request("POST",path,body,token,cb); }

    private static void request(String method,String path,JSONObject body,String token,Callback cb) {
        if(!configured()){ cb.onError("Backend URL is not configured yet."); return; }
        IO.execute(() -> {
            Exception lastError=null;
            final boolean safeGiftRetry628="/v1/live/gifts/send".equals(path)&&body!=null&&!body.optString("clientNonce").isEmpty();
            final int maxAttempts="GET".equals(method)||safeGiftRetry628?2:1;
            for(int attempt=0;attempt<maxAttempts;attempt++){
                HttpURLConnection c=null;
                try {
                    c=(HttpURLConnection)new URL(baseUrl()+path).openConnection(); c.setRequestMethod(method); c.setConnectTimeout(8000); c.setReadTimeout(12000); c.setRequestProperty("Accept","application/json"); c.setRequestProperty("Cache-Control","no-cache");
                    if(token!=null&&!token.isEmpty()) c.setRequestProperty("Authorization","Bearer "+token);
                    if(body!=null){ c.setRequestProperty("Content-Type","application/json; charset=utf-8"); c.setDoOutput(true); try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));} }
                    int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream(); StringBuilder text=new StringBuilder();
                    if(in!=null){try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)text.append(line);}}
                    JSONObject out=text.length()>0?new JSONObject(text.toString()):new JSONObject();
                    MAIN.post(() -> { if(code>=200&&code<300){DisplayIds611.observe(out);Iso611.observe(out);cb.onSuccess(out);} else cb.onError(errorText(out,code)); });
                    return;
                } catch(Exception e){
                    lastError=e;
                    if(attempt+1<maxAttempts){ try{Thread.sleep(350L);}catch(InterruptedException ie){Thread.currentThread().interrupt();break;} }
                } finally { if(c!=null)c.disconnect(); }
            }
            final String detail=lastError==null?"network unavailable":lastError.getClass().getSimpleName();
            MAIN.post(() -> cb.onError("Backend connection failed ("+detail+"). Please retry."));
        });
    }
    private static String errorText(JSONObject o,int code){ String e=o.optString("error",""); String detail=o.optString("message",""); if((e+" "+detail).contains("daily row read limit"))return "D1_DAILY_READ_LIMIT • Server daily data limit reached; saved data may be outdated. Try after quota reset."; if("ACCOUNT_EXISTS".equals(e))return "এই Email/Mobile দিয়ে Account আগে থেকেই আছে।"; if("INVALID_CREDENTIALS".equals(e))return "Login ID অথবা Password ভুল।"; if("ANSWER_NOT_MATCHED".equals(e))return "সিকিউরিটি উত্তর সঠিক নয়।"; if("NO_ID_AVAILABLE".equals(e))return "নতুন User ID পাওয়া যাচ্ছে না।"; if("R2_NOT_CONFIGURED".equals(e))return "R2 storage is not configured on the Worker."; if("AVATAR_TOO_LARGE".equals(e))return "Profile photo is too large (max 5 MB)."; if("AVATAR_TYPE_MISMATCH".equals(e))return "Please select an image for the profile photo."; if("COVER_TOO_LARGE".equals(e))return "Cover photo is too large (max 8 MB)."; if("COVER_TYPE_MISMATCH".equals(e))return "Please select an image for the cover photo."; if("COVER_MULTIPART_INVALID".equals(e))return "Cover photo upload format was rejected by the Worker: "+detail; if("PROFILE_UPDATE_FAILED".equals(e))return "Profile could not be saved safely. Your account was not changed."; if("R2_WRITE_FAILED".equals(e))return "R2 upload failed: "+detail; if("R2_VERIFY_FAILED".equals(e))return "R2 upload verification failed: "+detail; if("AVATAR_MULTIPART_INVALID".equals(e))return "Profile photo upload format was rejected by the Worker: "+detail; if("MEDIA_TOO_LARGE".equals(e))return "Media file is too large (max 50 MB)."; if("MEDIA_TYPE_MISMATCH".equals(e))return "Selected file type does not match the selected Gallery folder."; if("GALLERY_DB_UPDATE_FAILED".equals(e))return "Gallery save failed safely; the selected media was not kept without a database record."; if("MEDIA_NOT_FOUND".equals(e))return "This Gallery item is no longer available."; if("INVALID_GALLERY_FOLDER".equals(e))return "Gallery folder is invalid."; if("AD_DB_UPDATE_FAILED".equals(e))return "Advertisement save failed safely; the old advertisement was kept."; if("AD_TOO_LARGE".equals(e))return "Advertisement image is too large (max 15 MB)."; if("AD_MUST_BE_IMAGE".equals(e)||"AD_MUST_BE_IMAGE_OR_VIDEO".equals(e))return "Please select an image or video for the advertisement."; if("D1_WRITE_READY_FAILED".equals(e))return "myshop database write check failed: "+detail; if("NOTIFICATION_DB_WRITE_FAILED".equals(e))return "Notification database write failed: "+detail; if("NOTIFICATION_SCHEMA_FAILED".equals(e))return "Notification schema failed: "+detail; if("BANNER_DB_UPDATE_FAILED".equals(e))return "Banner save failed: "+detail; if("DAILY_POST_LIMIT".equals(e))return "আজকের ১টি পোস্ট ইতিমধ্যে করা হয়েছে। আগামীকাল আবার পোস্ট করতে পারবেন।";  if("FILE_REQUIRED".equals(e))return "No media file was received. Please choose the photo again."; if("POST_MEDIA_TYPE_MISMATCH".equals(e))return "Selected file type is not allowed for this post."; if("POST_CAPTION_REQUIRED".equals(e))return "Please add a caption before publishing the post."; if("USER_POST_TOO_LARGE".equals(e))return "User post is too large (image max 5 MB, video max 20 MB)."; if("POST_DB_UPDATE_FAILED".equals(e))return "Post save failed safely; the uploaded media was not kept without a database record."; if("POST_NOT_FOUND".equals(e))return "This post is no longer available."; if("MODERATOR_REQUIRED".equals(e))return "Moderator permission is required."; if("ADMIN_GATE_LOCKED".equals(e))return "Admin Panel locked. Unlock the main Admin Gate first."; if("ADMIN_GATE_PASSWORD_INCORRECT".equals(e))return "Admin password is incorrect."; if("RECOVERY_NOT_MATCHED".equals(e))return "Recovery information did not match."; if("BLOCKED_USER".equals(e))return "এই user-এর সাথে interaction block করা আছে।"; if("PLAY_BILLING_NOT_CONFIGURED".equals(e))return "Google Play Billing server setup এখনো সম্পূর্ণ হয়নি।"; if("PLAY_PRODUCT_ID_REQUIRED".equals(e))return "এই paid item-এর Google Play Product ID সেট করুন।"; if("WALLPAPER_ACTIVE_LIMIT".equals(e))return "সর্বোচ্চ ৫০টি Live Wallpaper active রাখা যাবে।"; if("PLAY_PRODUCT_MISMATCH".equals(e))return "Google Play product এবং myshop catalog item মিলছে না।"; if("PURCHASE_NOT_COMPLETED".equals(e))return "Google Play purchase এখনো completed নয়।"; if("ALREADY_OWNED".equals(e))return "এই Premium item ইতিমধ্যে আপনার Collection-এ আছে।"; if("INSUFFICIENT_COIN_BALANCE".equals(e))return "Coin balance যথেষ্ট নয়।"; if("INSUFFICIENT_GOLD_BALANCE".equals(e))return "Diamond balance যথেষ্ট নয়।"; if("DIRECT_PURCHASE_FAILED".equals(e))return detail.isEmpty()?"Purchase complete হয়নি; balance restore করা হয়েছে।":detail; if("DIRECT_DIGITAL_PAYMENT_DISABLED".equals(e))return "Play Store build-এ digital purchase Google Play Billing দিয়ে করতে হবে।"; if("INVALID_DELETE_PASSWORD".equals(e))return "Account delete করার password সঠিক নয়।"; if("PLAY_VERIFICATION_FAILED".equals(e))return detail.isEmpty()?"Google Play purchase verify করা যায়নি।":"Google Play verification: "+detail; if("PLAY_GRANT_FAILED".equals(e))return detail.isEmpty()?"Verified purchase activate করা যায়নি—আবার চেষ্টা করুন।":"Purchase activation: "+detail; if("INVALID_REQUEST".equals(e))return "Join request পাঠানো যায়নি। Live room refresh করে আবার চেষ্টা করুন।"; if("REQUEST_NOT_PENDING".equals(e))return "এই Join Request আর pending নেই।"; if("ALREADY_SPEAKER".equals(e))return "আপনি ইতিমধ্যে Live Call-এ আছেন।"; if("NO_FREE_SEAT".equals(e))return "এই মুহূর্তে কোনো Guest seat খালি নেই।"; if("LIVE_SESSION_NOT_READY".equals(e))return "Live room এখনো প্রস্তুত হচ্ছে—একটু পরে আবার চেষ্টা করুন।"; if("USER_NOT_IN_LIVE".equals(e)||"NOT_IN_LIVE".equals(e))return "User বর্তমানে এই Live room-এ নেই।"; if("INVITE_NOT_PENDING".equals(e))return "এই Call invitation আর pending নেই।"; if("INVITE_EXPIRED".equals(e))return "Call invitation-এর সময় শেষ হয়েছে।"; if("SEAT_LOCKED".equals(e))return "এই Guest seat Host lock করে রেখেছেন।"; if("SEAT_OCCUPIED".equals(e))return "এই Guest seat-এ অন্য user আছেন।"; if("USER_NOT_SPEAKER".equals(e))return "User এখনো speaker/call seat-এ নেই।"; if("INVALID_SEAT_ASSIGNMENT".equals(e))return "Guest seat নির্বাচন সঠিক নয়।"; if("VOTE_LEVEL_REQUIRED".equals(e))return "Vote দিতে Level 2 বা তার বেশি প্রয়োজন।"; if("VOTE_LIMIT_24H".equals(e))return "এই Host-কে ২৪ ঘণ্টায় ১টি Vote দেওয়া যায়।"; if("LOVE_REACT_LIMIT".equals(e))return "এই Live-এ একজন User সর্বোচ্চ ১০০টি Love React দিতে পারে।"; if("ADMIN_INVITE_NOT_PENDING".equals(e))return "এই Live Admin invitation আর pending নেই।"; if("SERVER_ERROR".equals(e))return detail.isEmpty()?"Server error ("+code+")":"Server error: "+detail; return e.isEmpty()?"Server error ("+code+")":e; }
}
