# MY SHOP Developer Handoff

Current version: V-273
Base: V-272-MY-SHOP-FOUR-CRITICAL-FIXES-FINAL

Completed in V-273:
- Profile name/cover overlap fix.
- Breaking News font size +/- admin control polished to 1-unit steps with visible integer size.
- Dashboard people card redesign: no NEW/LIVE overlay badge; plain name line; compact ID + crown level line; no purple level background; reduced gaps.

Preserve all existing backend/social/live/navigation functionality. Do not reintroduce NEW or LIVE overlay badges on people profile images.
