MY SHOP V-157

Build-only hotfix from V-156.
- Fixed MainActivity notification polling compile error caused by self-reference in a field initializer.
- Polling behavior unchanged: refresh every 15 seconds while resumed; callbacks removed on pause.
- No backend/D1/R2 schema or data changes.
- No user/account/ID deletion or regeneration.
- No OTP/verification-code changes.
- versionCode 157 / versionName 2.9.157.
