package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;
import org.json.JSONObject;

/**
 * MY SHOP V-138 Profile foundation.
 * Account identity stays backend-authoritative. User ID is read-only and is never edited here.
 */
public class AccountActivity extends AppCompatActivity {
    private static final int PICK_AVATAR=7001;
    private ImageView avatar; private TextView name,id,contact,bio,coins;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        avatar=findViewById(R.id.profileAvatar); name=findViewById(R.id.profileName); id=findViewById(R.id.profileId);
        contact=findViewById(R.id.profileContact); bio=findViewById(R.id.profileBio); coins=findViewById(R.id.coinBalance);
        renderLocal(); loadMe(); loadCoins();

        findViewById(R.id.profileBack).setOnClickListener(v -> finish());
        findViewById(R.id.profileSettings).setOnClickListener(v -> Toast.makeText(this,"Profile settings",Toast.LENGTH_SHORT).show());
        findViewById(R.id.changeAvatarButton).setOnClickListener(v -> chooseAvatar());
        findViewById(R.id.profileButton).setOnClickListener(v -> editProfile());
        findViewById(R.id.profileShareButton).setOnClickListener(v -> shareProfile());
        findViewById(R.id.buyCoinsButton).setOnClickListener(v -> buyCoinsDialog());
        findViewById(R.id.coinHistoryButton).setOnClickListener(v -> showCoinHistory());
        findViewById(R.id.giftHistoryButton).setOnClickListener(v -> showGiftHistory());
        findViewById(R.id.sendGiftButton).setOnClickListener(v -> Toast.makeText(this,"Live room খুলে Broadcast-এ Gift পাঠানো যাবে।",Toast.LENGTH_LONG).show());
        findViewById(R.id.myLiveButton).setOnClickListener(v -> startActivity(new Intent(this,MainActivity.class)));
        findViewById(R.id.passwordButton).setOnClickListener(v -> Toast.makeText(this,"Password reset/change is handled by secure backend authentication.",Toast.LENGTH_LONG).show());
        Switch notifications=findViewById(R.id.notificationSwitch);
        notifications.setChecked(getPreferences(MODE_PRIVATE).getBoolean("notifications",true));
        notifications.setOnCheckedChangeListener((button,checked)->getPreferences(MODE_PRIVATE).edit().putBoolean("notifications",checked).apply());
        findViewById(R.id.reportButton).setOnClickListener(v -> Toast.makeText(this,"Support and report tools can be connected to the backend without changing your account data.",Toast.LENGTH_LONG).show());
        findViewById(R.id.blockButton).setOnClickListener(v -> Toast.makeText(this,"Block List",Toast.LENGTH_SHORT).show());
        findViewById(R.id.historyButton).setOnClickListener(v -> Toast.makeText(this,"History",Toast.LENGTH_SHORT).show());
        findViewById(R.id.galleryButton).setOnClickListener(v -> startActivity(new Intent(this,GalleryActivity.class)));
        findViewById(R.id.logoutButton).setOnClickListener(v -> logout());
    }

    private void renderLocal(){
        String uid=SessionManager.getUserId(this); String n=getPrefs("full_name"); String e=getPrefs("email"); String m=getPrefs("mobile"); String b=SessionManager.getBio(this);
        name.setText(n.isEmpty()?"MY SHOP User":n); id.setText("User ID: "+(uid.isEmpty()?"Not assigned":uid));
        contact.setText(!e.isEmpty()?e:(!m.isEmpty()?m:"")); bio.setText(b); bio.setVisibility(b.isEmpty()?View.GONE:View.VISIBLE);
        String av=SessionManager.getAvatarUrl(this); if(!av.isEmpty()) loadImage(av,avatar);
    }
    private String getPrefs(String key){return getSharedPreferences("myshop_session",MODE_PRIVATE).getString(key,"");}

    private void loadMe(){String token=SessionManager.getToken(this); if(token.isEmpty())return; BackendClient.me(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{try{JSONObject u=d.optJSONObject("user");if(u==null)return;SessionManager.saveProfile(AccountActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""),u.optString("avatarUrl",""),u.optString("bio",""));renderLocal();}catch(Exception ignored){}});}public void onError(String m){}});}
    private void loadCoins(){String token=SessionManager.getToken(this); if(token.isEmpty()){coins.setText("0 Coins");return;} BackendClient.coins(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->coins.setText(String.format("%,d Coins",d.optLong("balance",0))));}public void onError(String m){runOnUiThread(()->coins.setText("0 Coins"));}});}

    private void editProfile(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(36,8,36,8);
        EditText n=input("Full Name",getPrefs("full_name")); EditText e=input("Email",getPrefs("email")); EditText m=input("Mobile",getPrefs("mobile")); EditText b=input("Bio",SessionManager.getBio(this));
        box.addView(n);box.addView(e);box.addView(m);box.addView(b);
        new AlertDialog.Builder(this).setTitle("Edit Profile").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Update",(d,w)->{
            String token=SessionManager.getToken(this); BackendClient.updateProfile(token,n.getText().toString(),e.getText().toString(),m.getText().toString(),b.getText().toString(),new BackendClient.Callback(){public void onSuccess(JSONObject x){try{JSONObject u=x.optJSONObject("user");SessionManager.saveProfile(AccountActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""),u.optString("avatarUrl",""),u.optString("bio",""));renderLocal();Toast.makeText(AccountActivity.this,"Profile updated safely. User ID remains unchanged.",Toast.LENGTH_LONG).show();}catch(Exception ex){Toast.makeText(AccountActivity.this,"Profile response invalid.",Toast.LENGTH_SHORT).show();}}public void onError(String msg){Toast.makeText(AccountActivity.this,msg,Toast.LENGTH_LONG).show();}});
        }).show();
    }
    private EditText input(String hint,String value){EditText x=new EditText(this);x.setHint(hint);x.setSingleLine(false);x.setText(value);x.setPadding(8,10,8,10);return x;}

    private void chooseAvatar(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_AVATAR);}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode!=PICK_AVATAR||resultCode!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();try{InputStream in=getContentResolver().openInputStream(uri);String mime=getContentResolver().getType(uri);String name="avatar.jpg";if(mime!=null&&mime.contains("png"))name="avatar.png";BackendClient.uploadAvatar(SessionManager.getToken(this),in,name,mime==null?"image/jpeg":mime,new BackendClient.Callback(){public void onSuccess(JSONObject d){try{JSONObject u=d.optJSONObject("user");SessionManager.saveProfile(AccountActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""),u.optString("avatarUrl",""),u.optString("bio",""));renderLocal();Toast.makeText(AccountActivity.this,"Profile photo updated.",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(AccountActivity.this,"Photo response invalid.",Toast.LENGTH_SHORT).show();}}public void onError(String m){Toast.makeText(AccountActivity.this,m,Toast.LENGTH_LONG).show();}});}catch(Exception e){Toast.makeText(this,"Could not open selected photo.",Toast.LENGTH_SHORT).show();}}

    private void loadImage(String url,ImageView target){Executors.newSingleThreadExecutor().execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(10000);Bitmap b=BitmapFactory.decodeStream(c.getInputStream());c.disconnect();runOnUiThread(()->{if(b!=null)target.setImageBitmap(b);});}catch(Exception ignored){}});}

    private void showCoinHistory(){
        BackendClient.coins(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                StringBuilder s=new StringBuilder(); s.append("Current balance: ").append(String.format("%,d",d.optLong("balance",0))).append(" Coins\n\n");
                org.json.JSONArray a=d.optJSONArray("transactions"); if(a==null||a.length()==0)s.append("No coin transactions yet."); else for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;s.append(x.optString("kind","Transaction")).append("  ").append(x.optInt("amount",0)>=0?"+":"").append(x.optInt("amount",0)).append(" coins\n").append(x.optString("created_at","")).append("\n\n");}
                new AlertDialog.Builder(AccountActivity.this).setTitle("🪙 Coin History").setMessage(s.toString()).setPositiveButton("CLOSE",null).show();
            }
            public void onError(String m){Toast.makeText(AccountActivity.this,m,Toast.LENGTH_LONG).show();}
        });
    }
    private void showGiftHistory(){
        BackendClient.giftHistory(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                StringBuilder s=new StringBuilder(); org.json.JSONArray a=d.optJSONArray("gifts"); if(a==null||a.length()==0)s.append("No gift transactions yet."); else for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;boolean sent=SessionManager.getUserId(AccountActivity.this).equals(x.optString("sender_user_id",""));s.append(sent?"Gift sent → ":"Gift received ← ").append(x.optInt("coins",0)).append(" coins\n").append(x.optString("gift_code","Gift")).append(" • ").append(x.optString("created_at","")).append("\n\n");}
                new AlertDialog.Builder(AccountActivity.this).setTitle("🎁 Gift History").setMessage(s.toString()).setPositiveButton("CLOSE",null).show();
            }
            public void onError(String m){Toast.makeText(AccountActivity.this,m,Toast.LENGTH_LONG).show();}
        });
    }

    private void buyCoinsDialog(){
        String[] packages={"120 Coins — ৳50","300 Coins — ৳100","650 Coins — ৳200","1,350 Coins — ৳400","2,750 Coins — ৳800","6,000 Coins — ৳1,600"};
        String[] methods={"bKash","Nagad","Bangla QR Code"};
        final int[] selected={2};
        new AlertDialog.Builder(this).setTitle("Buy Coins").setSingleChoiceItems(packages,selected[0],(d,w)->selected[0]=w).setPositiveButton("Choose Payment",(d,w)->{
            int[] coinVals={120,300,650,1350,2750,6000}; int[] amount={5000,10000,20000,40000,80000,160000};
            new AlertDialog.Builder(this).setTitle("Payment Method").setItems(methods,(dd,which)->{
                final String[] keys={"bkash","nagad","bangla_qr"};
                EditText ref=new EditText(this); ref.setHint("Payment reference (optional)");
                new AlertDialog.Builder(this).setTitle("Payment Reference").setView(ref).setMessage("Selected: "+methods[which]+"\nAmount: ৳"+(amount[selected[0]]/100)+"\nCoins: "+coinVals[selected[0]]+"\n\nPayment is recorded as Pending until server-side approval.").setNegativeButton("Cancel",null).setPositiveButton("Submit Request",(x,y)->BackendClient.requestCoinPurchase(SessionManager.getToken(this),coinVals[selected[0]],amount[selected[0]],keys[which],ref.getText().toString(),new BackendClient.Callback(){public void onSuccess(JSONObject q){Toast.makeText(AccountActivity.this,"Payment request submitted. Coins will be added only after approval.",Toast.LENGTH_LONG).show();}public void onError(String msg){Toast.makeText(AccountActivity.this,msg,Toast.LENGTH_LONG).show();}})).show();
            }).show();
        }).setNegativeButton("Cancel",null).show();
    }

    private void shareProfile(){ try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"MY SHOP Profile");i.putExtra(Intent.EXTRA_TEXT,"MY SHOP profile • User ID "+SessionManager.getUserId(this));startActivity(Intent.createChooser(i,"Share profile"));}catch(Exception e){Toast.makeText(this,"Share is not available.",Toast.LENGTH_SHORT).show();}}

    private void logout(){String token=SessionManager.getToken(this);SessionManager.clear(this);Intent i=new Intent(this,LoginActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(i);if(!token.isEmpty())BackendClient.logout(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){}public void onError(String m){}});}
}
