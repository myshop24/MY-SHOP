from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'app' / 'build.gradle'
MANIFEST = ROOT / 'app' / 'src' / 'main' / 'AndroidManifest.xml'
LOGIN = ROOT / 'app' / 'src' / 'main' / 'java' / 'com' / 'myshop' / 'app' / 'LoginActivity.java'
ACCOUNT = list(ROOT.rglob('AccountStore.java'))

assert APP.is_file(), 'missing app/build.gradle'
assert MANIFEST.is_file(), 'missing AndroidManifest.xml'
assert LOGIN.is_file(), 'missing LoginActivity.java'
assert len(ACCOUNT) == 1, f'expected 1 AccountStore.java, found {len(ACCOUNT)}'

s = APP.read_text(encoding='utf-8')
assert re.search(r'\bapplicationId\s+[\'\"]com\.myshop\.app[\'\"]', s)
assert re.search(r'\bversionCode\s+80\b', s)
assert re.search(r'\bversionName\s+[\'\"]2\.9\.80[\'\"]', s)

m = MANIFEST.read_text(encoding='utf-8')
for x in ['android:name=".LoginActivity"','android:name="android.intent.action.MAIN"','android:name="android.intent.category.LAUNCHER"','android:exported="true"']:
    assert x in m, f'missing manifest launcher contract: {x}'

l = LOGIN.read_text(encoding='utf-8')
assert 'public class LoginActivity extends android.app.Activity' in l
assert 'androidx.appcompat.app.AppCompatActivity' not in l

print('V-80 MASTER VALIDATION PASSED')
print('package=com.myshop.app')
print('versionCode=80')
print('versionName=2.9.80')
print('launcher=com.myshop.app.LoginActivity')
