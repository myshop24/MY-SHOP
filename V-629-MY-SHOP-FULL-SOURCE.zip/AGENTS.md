Current V629 / 2.9.629 source checkpoint: owner-approved corrections, source checks complete; full Android/device/production acceptance pending. Read V629-APPROVED-WORK-BN.md, handoffs/MY-SHOP-V629-HANDOFF.md and GITHUB-UPLOAD-V629-BN.md. Gradle download blocked locally; no APK bundled. Next changed delivery V630. Latest owner instructions override historical notes below.

Current V628 / 2.9.628: owner-approved eight correction groups continued from verified delivered V627. Read MY-SHOP-DEVELOPER-HANDOFF.md, V628-APPROVED-WORK-BN.md and GITHUB-UPLOAD-V628-BN.md first. Source/SQLite/Java-double checks are not Android/device acceptance. No APK bundled, no remote deployment performed. Next changed delivery V629. Latest owner instructions override historical notes below.

Current V627 / 2.9.627: scoped V626 Java overlay compiler fix. Read MY-SHOP-DEVELOPER-HANDOFF.md and GITHUB-UPLOAD-V627-BN.md first. No bundled APK; full Android/device acceptance pending. V626 unfinished feature work remains unfinished. Next changed delivery V628. Latest owner instructions override historical notes below.

Current V626 / 2.9.626 PARTIAL SOURCE CHECKPOINT. Read MY-SHOP-DEVELOPER-HANDOFF.md and V626-APPROVED-WORK-BN.md first. Owner authorized tasks 1–10 on 2026-10-15. Source tests are not Android/device/reference acceptance. Do not auto-deploy this checkpoint; ID expansion and visual/build verification remain pending. Next changed delivery V627. Latest owner instructions override older notes.

Current V625 /2.9.625: continue exact source. Read MY-SHOP-DEVELOPER-HANDOFF.md and V625-APPROVED-WORK-BN.md. Preserve existing modules, prices, currency rules and signing secrets. Next changed delivery V626. Latest owner instructions override historical notes.

Current V624 /2.9.624: read MY-SHOP-DEVELOPER-HANDOFF.md and V624-APPROVED-WORK-BN.md. Owner approved eight scoped corrections including Live Join/progress/sound icon. Preserve unrelated modules and signing secrets. Next changed version V625.

Current V623 /2.9.623: read MY-SHOP-DEVELOPER-HANDOFF.md and V623-APPROVED-WORK-BN.md. Owner authorized Master Commission and exact V622 Java build fix. Preserve other V622 features/Signing Secrets. Next newly changed delivery V624. Latest owner instructions override historical notes.

Current V622 /2.9.622: read MY-SHOP-DEVELOPER-HANDOFF.md. Six task groups source-tested; Task4 premium cinematic quality incomplete. Android/signedAPK/production/device acceptance pending. Next new deliveryV623. Latest owner rules supersede historical notes.

Current V621 /2.9.621: read handoffs/MY-SHOP-V621-HANDOFF.md. D1 mitigations, compact gift panel, recharge/office levels and live directory revision source implemented; local checks pass; fullAndroid/production/device acceptance pending. Next new deliveryV622.

Current V620 /2.9.620: read handoffs/MY-SHOP-V620-HANDOFF.md. Latest three-item source scope implemented,20additive gifts; local tests pass. ProductionD1, fullAndroid/signedAPK/device acceptance pending. Next changeddeliveryV621.

CurrentV619 /2.9.619: handoffs/MY-SHOP-V619-HANDOFF.md. Three actual compiler errors fixed/tested;6 basic free3D/sound prototypes.200 premium gifts/reference/device/signedAPK remainpending. Next changed deliveryV620.

Current V618 /2.9.618 partial checkpoint. Read handoffs/MY-SHOP-V618-HANDOFF.md.200 real media/production/reference/device/APK acceptance remain pending. Next changed deliveryV619.

Current V617 /2.9.617: read handoffs/MY-SHOP-V617-HANDOFF.md. Local tests passed; APK/device/real media/production acceptance pending. Next delivery V618.

Current V616 /2.9.616: read handoffs/MY-SHOP-V616-HANDOFF.md. Full source checkpoint, partial14-task completion. Local target/regression pass; actual new Rider/Gift videos, Android APK/device, full localization and production D1/policy acceptance pending. Next new delivery V617.

Current V615 /2.9.615: read handoffs/MY-SHOP-V615-HANDOFF.md. Partial13-task source correction; true3D media/full localization/production D1/device acceptance pending. Next delivery V616.

Current V614 / 2.9.614: read handoffs/MY-SHOP-V614-HANDOFF.md. GitHub missing Dialog import corrected; local target/regression checks passed, full Android build pending network. Next delivery V615.

Current V613 / 2.9.613: read handoffs/MY-SHOP-V613-HANDOFF.md. Partial source checkpoint; true3D media, full Android/device acceptance pending. Next delivery V614.

Current V612 / 2.9.612: read handoffs/MY-SHOP-V612-HANDOFF.md. Store/Mini Card source corrections and local tests; full Android/device acceptance pending. Next V613.

Current V611 / 2.9.611: read handoffs/MY-SHOP-V611-HANDOFF.md. Approved source changes and local checks; full Android/device acceptance pending. Next delivery V612.

Current V610 / 2.9.610: read handoffs/MY-SHOP-V610-HANDOFF.md. Version-correct canonical delivery; next V611.

Current V609 / 2.9.609: read handoffs/MY-SHOP-V609-HANDOFF.md. Approved Store/frame/comment source changes and local checks complete; full Android and phone acceptance pending. D1 optimization excluded. Next delivery V610.

Current V608 /2.9.608: read handoffs/MY-SHOP-V608-HANDOFF.md. Scoped missing-key compilation fix; next deliveryV609.

Current V607 /2.9.607: read handoffs/MY-SHOP-V607-HANDOFF.md. Eight approved source correction groups checked locally; signed APK/device acceptance and Admin animation reproduction pending. Next deliveryV608.

Current V606 /2.9.606: read handoffs/MY-SHOP-V606-HANDOFF.md. Seven approved source groups implemented; signed APK/full Android/device checks pending. Next new deliveryV607.

Current V605 /2.9.605: read handoffs/MY-SHOP-V605-HANDOFF.md. Six-group correction is PARTIAL; new30 rides and signed APK/device checks remain pending. Next deliveryV606.

Current V604 /2.9.604: read handoffs/MY-SHOP-V604-HANDOFF.md. Canonical source<=25,000,000 bytes. Next deliveryV605. No APK; inherited partial work recorded.

Current V603 partial checkpoint: read handoffs/MY-SHOP-V603-HANDOFF.md. All9 are NOT completed; rides blocked. Next delivery V604.

Current V602 checkpoint: read handoffs/MY-SHOP-V602-HANDOFF.md. Next delivery V603.

# MY SHOP — Mandatory Developer Entry Point

Read `DEVELOPER-POLICY-BN.md` and `MY-SHOP-DEVELOPER-INSTRUCTIONS.md` BEFORE inspecting implementation, editing, building or producing a delivery. Read `V575-APPROVED-WORK-BN.md` for current scope and `MY-SHOP-DEVELOPER-HANDOFF.md` for the last verified checkpoint. The latest owner instruction overrides historical notes. Never infer completion from a requirement document or an old log.

Current continuation: **V603 / 2.9.603**. Read `V600-APPROVED-WORK-BN.md` and `handoffs/MY-SHOP-V600-HANDOFF.md` after the entry rules. V600's membership visuals, General filters and Host lifetime Top1 ranking were explicitly discussed and authorized by the owner; no repeated approval is needed inside that scope. Other Live changes still require their own scope discussion. Read `handoffs/MY-SHOP-V601-HANDOFF.md` and `BUILD-ASSETS-BN.md`; prepare generated assets before local checks/build. Cleanup only changes source storage/build generation; runtime GIF/WAV bytes and image pixels are verified unchanged. Next new delivery is V604.

**LIVE IS A CRITICAL / HIGH-RISK ZONE.** Before changing Live Streaming code, design, audio, realtime, or its related backend, explain the exact proposed change and impact to the owner, discuss it and obtain explicit owner approval. This includes shared helpers, bug fixes, optimization, deletion and styling that would alter Live. Read-only inspection/testing is allowed. Continue independent non-Live work while a Live decision is pending.

Keep unrelated approved modules locked. Make scoped changes, preserve data/signing/package identity and run target plus regression verification. Never publish, deploy, overwrite an old version or claim a real-device test that was not performed.
