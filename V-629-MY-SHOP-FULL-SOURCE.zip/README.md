# MY SHOP V629 / 2.9.629

Full Android project source, continued from delivered V628. No APK bundled. Read AGENTS.md, V629-APPROVED-WORK-BN.md, handoffs/MY-SHOP-V629-HANDOFF.md and GITHUB-UPLOAD-V629-BN.md. Original package, release signing identity, finance rules, sources and runtime assets retained. One historical non-build log archive is excluded as documented.

Tests: bash tools/v629_target_verify.sh. Complete source regression: bash tools/v626_target_verify.sh (retained historical entry point). Prepare generated assets first per BUILD-ASSETS-BN.md. Full configured GitHub build: bash tools/ci-apk-build.sh. Included workflow selects highest source version and is build-only; it never deploys Worker/D1. Original signing and Firebase configuration required; credentials are not included.

New V629 endpoints require matching reviewed backend V629. Stage backend/API and Android/device tests before production release. Local full Android compilation was blocked by Gradle download network access; no APK, phone/launcher, production, RTC or payment acceptance claimed. Read verification/V629-RESULTS.md for actual checks. Historical unfinished features are not declared finished. Next changed delivery V630.
