package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** MY SHOP + LIVE — V-53 final locked dashboard foundation. */
public class MainActivity extends AppCompatActivity {
    private static final int BG = Color.rgb(248,249,252), TEXT = Color.rgb(25,31,45);
    private static final int BLUE = Color.rgb(29,82,225), PURPLE = Color.rgb(98,36,225), PINK = Color.rgb(230,34,142);
    private static final int RED = Color.rgb(235,35,55), ORANGE = Color.rgb(245,92,18), GREEN = Color.rgb(26,160,78);
    private static final int MAX_BANNERS_PER_FOLDER = 6;
    private static final long SLIDE_MS = 3500L;
    private final Handler handler = new Handler();
    private int bannerIndex = 0;
    private final ImageView[] bannerImages = new ImageView[3];
    // Six slots per banner folder. The approved artwork is used as the current default set;
    // each folder remains six-slot ready for Admin remote replacement.
    private final int[] topLeftBanners = {R.drawable.banner_top_left_1,R.drawable.banner_top_left_2,R.drawable.banner_top_left_3,R.drawable.banner_top_left_4,R.drawable.banner_top_left_5,R.drawable.banner_top_left_6};
    private final int[] topRightBanners = {R.drawable.banner_top_right_1,R.drawable.banner_top_right_2,R.drawable.banner_top_right_3,R.drawable.banner_top_right_4,R.drawable.banner_top_right_5,R.drawable.banner_top_right_6};
    private final int[] wideBanners = {R.drawable.banner_wide_1,R.drawable.banner_wide_2,R.drawable.banner_wide_3,R.drawable.banner_wide_4,R.drawable.banner_wide_5,R.drawable.banner_wide_6};
    private final TextView[] liveSlots = new TextView[6];
    // Backend/remote-config will supply this value in production. Zero means six advertisement slots.
    private int activeLiveCount = 0;
    private final String[] liveNames = {"Cute Girl Live","Music Live","Gaming Live","Talk & Fun","Dance Live","Comedy Live"};
    private final int[] liveColors = {Color.rgb(236,65,126),Color.rgb(14,72,150),Color.rgb(18,35,65),Color.rgb(21,118,190),Color.rgb(101,33,85),Color.rgb(35,35,60)};

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        try { setContentView(buildDashboard()); startCarousel(); }
        catch (Throwable t) { setContentView(buildSafeHome()); }
    }

    private int dp(int v){ return Math.round(v * getResources().getDisplayMetrics().density); }
    private LinearLayout.LayoutParams lp(int w,int h){ return new LinearLayout.LayoutParams(w,h); }
    private LinearLayout.LayoutParams weight(float w,int h){ return new LinearLayout.LayoutParams(0,h,w); }

    private View buildDashboard(){
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(12),dp(8),dp(12),dp(10));

        // Header — selected dashboard header, not changed below the approved top section.
        LinearLayout header = row();
        ImageView avatar = new ImageView(this); avatar.setImageResource(R.drawable.myshop_profile_avatar); avatar.setScaleType(ImageView.ScaleType.CENTER_CROP); avatar.setBackground(round(Color.WHITE,Color.rgb(220,224,232),dp(30))); avatar.setClipToOutline(true); header.addView(avatar, lp(dp(64),dp(64)));
        LinearLayout user = new LinearLayout(this); user.setOrientation(LinearLayout.VERTICAL); user.setGravity(Gravity.CENTER_VERTICAL);
        TextView hi = text("Hi, Touhid 👋", TEXT, 16, true); user.addView(hi); user.addView(text("ID: 1024  ✓", BLUE, 13, true));
        header.addView(user, weight(0.8f,dp(62)));
        EditText search = new EditText(this); search.setSingleLine(true); search.setHint("খুঁজুন পণ্য, লাইভ, ইউজার..."); search.setTextSize(14); search.setPadding(dp(12),0,dp(8),0); search.setBackground(round(Color.WHITE,Color.rgb(220,224,232),dp(26))); header.addView(search,weight(2.1f,dp(58)));
        TextView bell = pill("🔔 12", RED, Color.WHITE); header.addView(bell,lp(dp(66),dp(58)));
        Button menu = plainButton("☰", TEXT, 28); header.addView(menu,lp(dp(56),dp(58))); menu.setOnClickListener(v->startActivity(new Intent(this,AccountActivity.class)));
        content.addView(header,lp(-1,dp(68)));

        // Top: two side-by-side banners, each rotates through its own 6-item folder.
        LinearLayout top = row();
        bannerImages[0] = bannerImage(topLeftBanners[0]); bannerImages[1] = bannerImage(topRightBanners[0]);
        top.addView(bannerImages[0],weight(1,dp(154))); top.addView(space(dp(6),dp(1))); top.addView(bannerImages[1],weight(1,dp(154)));
        content.addView(top,lp(-1,dp(160)));
        TextView dots = text("●   ○   ○   ○   ○   ○", PURPLE, 13, true); dots.setGravity(Gravity.CENTER); content.addView(dots,lp(-1,dp(24)));

        // Full-width banner: independent 6-item folder.
        bannerImages[2] = bannerImage(wideBanners[0]); LinearLayout.LayoutParams w = lp(-1,dp(108)); w.topMargin=dp(4); content.addView(bannerImages[2],w);

        TextView breaking = card("🔴  BREAKING NEWS    |    বাংলাদেশে আজ স্বর্ণের দাম কিছুটা কমেছে...                         View All", Color.WHITE, TEXT, 13);
        LinearLayout.LayoutParams br=lp(-1,dp(50)); br.topMargin=dp(8); content.addView(breaking,br);

        // Six live slots. If zero live streams exist, the same six positions show admin-controlled placeholders/ads.
        LinearLayout liveHead=row(); liveHead.addView(text(activeLiveCount == 0 ? "🔴  LIVE NOW  (Advertisement)" : "🔴  LIVE NOW",TEXT,15,true),weight(1,dp(42))); TextView va=text("View All",BLUE,13,true); liveHead.addView(va,lp(dp(72),dp(42))); content.addView(liveHead,lp(-1,dp(44)));
        HorizontalScrollView hsv=new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false); LinearLayout liveRow=row();
        for(int i=0;i<6;i++){ liveSlots[i]=(i < activeLiveCount) ? liveCard(i) : advertisementCard(i); liveRow.addView(liveSlots[i],lp(dp(154),dp(236))); if(i<5) liveRow.addView(space(dp(7),1)); }
        hsv.addView(liveRow); content.addView(hsv,lp(-1,dp(244)));

        // Approved My Feed + My Shop pair. Do not move/change the upper section.
        LinearLayout approved=row(); ImageView feed=featureImage(R.drawable.feature_my_feed_selected, "MY FEED", "my_feed"); ImageView shop=featureImage(R.drawable.feature_my_shop_selected, "MY SHOP", "my_shop"); approved.addView(feed,weight(1,dp(78))); approved.addView(space(dp(7),1)); approved.addView(shop,weight(1,dp(78))); content.addView(approved,lp(-1,dp(84)));

        // Lower controls: Go Live centered, surrounding six functions arranged in two columns.
        LinearLayout lower = row();
        LinearLayout left = new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL); LinearLayout right = new LinearLayout(this); right.setOrientation(LinearLayout.VERTICAL);
        addSmallImage(left,R.drawable.feature_gallery_selected,"GALLERY","gallery"); addSmallImage(left,R.drawable.feature_live_tv_selected,"LIVE TV","live_tv"); addSmallImage(left,R.drawable.feature_earn_selected,"EARN & REWARD","earn_reward");
        addSmallImage(right,R.drawable.feature_external_selected,"EXTERNAL","external_movie"); addSmallImage(right,R.drawable.feature_social_selected,"SOCIAL","social_media"); addSmallImage(right,R.drawable.feature_share_selected,"SHARE","share");
        lower.addView(left,weight(1,dp(258))); lower.addView(goLiveImage(),lp(dp(176),dp(258))); lower.addView(right,weight(1,dp(258))); content.addView(lower,lp(-1,dp(264)));

        scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        // Bottom navigation: Home, Store, Live, Chat, More.
        LinearLayout nav=row(); nav.setPadding(dp(5),dp(4),dp(5),dp(4)); nav.setBackground(round(Color.WHITE,Color.rgb(225,228,235),dp(26)));
        Button home=navButton("⌂\nHOME",BLUE); Button store=navButton("🛒\nSTORE",TEXT); Button live=navButton("◉\nLIVE",TEXT); Button chat=navButton("💬\nCHAT",TEXT); Button more=navButton("▦\nMORE",TEXT);
        nav.addView(home,weight(1,dp(62))); nav.addView(store,weight(1,dp(62))); nav.addView(live,weight(1,dp(62))); nav.addView(chat,weight(1,dp(62))); nav.addView(more,weight(1,dp(62))); root.addView(nav,lp(-1,dp(70)));
        store.setOnClickListener(v->openFeature("MY SHOP","my_shop")); live.setOnClickListener(v->openFeature("LIVE","live_now")); chat.setOnClickListener(v->openFeature("CHAT","chat")); more.setOnClickListener(v->startActivity(new Intent(this,AccountActivity.class)));
        return root;
    }

    private TextView advertisementCard(int i){
        TextView v=card("ADVERTISEMENT\nAd Slot "+(i+1)+"\nAdmin controlled\nVIEW  ▶",Color.WHITE,ORANGE,12);
        v.setGravity(Gravity.CENTER);
        v.setOnClickListener(x->openFeature("ADVERTISEMENT "+(i+1),"advertisement"));
        return v;
    }
    private TextView liveCard(int i){
        TextView v=card("LIVE\n"+liveNames[i]+"\nID: 10"+(i+1)+"  ✓\n👁 "+(12-i*1.7f)+"K\nWATCH NOW  ▶",Color.WHITE,liveColors[i],12);
        v.setGravity(Gravity.CENTER); v.setOnClickListener(x->openFeature(liveNames[i],"live_room")); return v;
    }
    private void addSmall(LinearLayout parent,String label,String key,int color){ Button b=feature(label,key,color); parent.addView(b,lp(-1,dp(78))); }
    private void addSmallImage(LinearLayout parent,int resId,String desc,String key){ ImageView v=featureImage(resId,desc,key); v.setScaleType(ImageView.ScaleType.CENTER_CROP); LinearLayout.LayoutParams p=lp(-1,dp(82)); p.bottomMargin=dp(4); parent.addView(v,p); }
    private ImageView goLiveImage(){ ImageView v=featureImage(R.drawable.feature_go_live_selected,"GO LIVE","go_live"); v.setScaleType(ImageView.ScaleType.CENTER_INSIDE); return v; }
    private ImageView featureImage(int resId,String desc,String key){ ImageView v=new ImageView(this); v.setImageResource(resId); v.setScaleType(ImageView.ScaleType.CENTER_CROP); v.setBackground(round(Color.WHITE,Color.rgb(225,228,235),dp(14))); v.setClipToOutline(true); v.setContentDescription(desc); v.setOnClickListener(x->openFeature(desc,key)); return v; }
    private Button feature(String label,String key,int color){ Button b=plainButton(label,color,12); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setOnClickListener(v->openFeature(label,key)); return b; }
    private Button navButton(String label,int color){ return plainButton(label,color,12); }
    private Button plainButton(String label,int color,float size){ Button b=new Button(this); b.setText(label); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setTextColor(color); b.setTextSize(size); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setBackground(round(Color.WHITE,Color.rgb(224,227,235),dp(14))); return b; }
    private ImageView bannerImage(int resId){ ImageView v=new ImageView(this); v.setImageResource(resId); v.setScaleType(ImageView.ScaleType.CENTER_CROP); v.setBackground(round(Color.WHITE,Color.rgb(225,228,235),dp(14))); v.setClipToOutline(true); v.setContentDescription("MY SHOP promotional banner"); return v; }
    private TextView card(String label,int bg,int fg,float size){ TextView v=text(label,fg,size,true); v.setGravity(Gravity.CENTER); v.setPadding(dp(7),dp(5),dp(7),dp(5)); v.setBackground(round(bg,Color.rgb(225,228,235),dp(14))); return v; }
    private TextView pill(String label,int bg,int fg){ TextView v=text(label,fg,12,true); v.setGravity(Gravity.CENTER); v.setBackground(round(bg,bg,dp(22))); return v; }
    private TextView text(String s,int c,float size,boolean bold){ TextView v=new TextView(this); v.setText(s); v.setTextColor(c); v.setTextSize(size); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private View space(int w,int h){ View v=new View(this); return v; }
    private LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private GradientDrawable round(int fill,int stroke,int radius){ GradientDrawable g=new GradientDrawable(); g.setColor(fill); g.setCornerRadius(radius); g.setStroke(dp(1),stroke); return g; }
    private GradientDrawable circleGradient(int fill,int ignored){ GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{fill,Color.rgb(245,25,110)}); g.setShape(GradientDrawable.OVAL); return g; }
    private void startCarousel(){ handler.postDelayed(new Runnable(){ public void run(){ bannerIndex=(bannerIndex+1)%MAX_BANNERS_PER_FOLDER; bannerImages[0].setImageResource(topLeftBanners[bannerIndex]); bannerImages[1].setImageResource(topRightBanners[bannerIndex]); bannerImages[2].setImageResource(wideBanners[bannerIndex]); handler.postDelayed(this,SLIDE_MS); }},SLIDE_MS); }
    @Override protected void onDestroy(){ handler.removeCallbacksAndMessages(null); super.onDestroy(); }
    private void openFeature(String t,String k){ try{Intent i=new Intent(this,FeatureActivity.class); i.putExtra("title",t); i.putExtra("feature_key",k); startActivity(i);}catch(Throwable x){Toast.makeText(this,t+" is ready.",Toast.LENGTH_SHORT).show();} }
    private View buildSafeHome(){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setGravity(Gravity.CENTER); r.setBackgroundColor(BG); TextView t=text("MY SHOP + LIVE\nHome Dashboard",PURPLE,26,true); t.setGravity(Gravity.CENTER); r.addView(t,lp(-1,-2)); Button retry=plainButton("OPEN DASHBOARD",BLUE,15); retry.setOnClickListener(v->recreate()); r.addView(retry,lp(-1,dp(64))); return r; }
}
