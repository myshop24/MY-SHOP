package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** V-53: MY SHOP + LIVE login; backend role check is authoritative. */
public class LoginActivity extends AppCompatActivity {
    private static final String BRAND = "MY SHOP";
    private EditText loginId;
    private EditText loginPassword;
    private TextView emailTab, mobileTab, loginPrefix;
    private boolean mobileMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // V-47: preserve the existing account/session across normal app updates.
        // This only works when Android performs an in-place update with the same signing key.
        String existingId = SessionManager.getUserId(this);
        if (SessionManager.isLoggedIn(this) && !existingId.isEmpty() && AccountStore.exists(this, existingId)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        loginId = findViewById(R.id.loginId);
        loginPassword = findViewById(R.id.loginPassword);
        Button login = findViewById(R.id.loginButton);
        TextView create = findViewById(R.id.createAccountButton);
        TextView forgot = findViewById(R.id.forgotButton);
        ImageButton toggle = findViewById(R.id.passwordToggle);
        emailTab = findViewById(R.id.emailTab);
        mobileTab = findViewById(R.id.mobileTab);
        loginPrefix = findViewById(R.id.loginPrefix);
        emailTab.setOnClickListener(v -> setLoginMode(false));
        mobileTab.setOnClickListener(v -> setLoginMode(true));
        setLoginMode(false);

        create.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
        login.setOnClickListener(v -> login());
        forgot.setOnClickListener(v -> Toast.makeText(this, "Password reset will be connected to the secure backend.", Toast.LENGTH_LONG).show());
        toggle.setOnClickListener(v -> {
            int pos = loginPassword.getSelectionStart();
            boolean hidden = (loginPassword.getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) != 0;
            loginPassword.setInputType(InputType.TYPE_CLASS_TEXT | (hidden ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            loginPassword.setSelection(Math.max(0, pos));
        });
    }

    private void setLoginMode(boolean mobile) {
        mobileMode = mobile;
        if (mobile) {
            loginId.setHint("1XXXXXXXXX");
            loginId.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
            loginPrefix.setText("+880  ▾");
            loginPrefix.setVisibility(TextView.VISIBLE);
            mobileTab.setTextColor(android.graphics.Color.WHITE);
            mobileTab.setBackgroundResource(com.myshop.app.R.drawable.bg_mobile_active);
            emailTab.setTextColor(android.graphics.Color.DKGRAY);
            emailTab.setBackgroundResource(com.myshop.app.R.drawable.bg_email_inactive);
        } else {
            loginId.setHint("enter@example.com");
            loginId.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
            loginPrefix.setText("");
            loginPrefix.setVisibility(TextView.GONE);
            emailTab.setTextColor(android.graphics.Color.WHITE);
            emailTab.setBackgroundResource(com.myshop.app.R.drawable.bg_email_tab);
            mobileTab.setTextColor(android.graphics.Color.DKGRAY);
            mobileTab.setBackgroundResource(com.myshop.app.R.drawable.bg_mobile_tab);
        }
    }

    private void login() {
        String identifier = loginId.getText().toString().trim();
        String pass = loginPassword.getText().toString();
        if (identifier.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Email/Mobile and Password are required.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            AccountStore.Account account = AccountStore.authenticate(this, identifier, pass);
            if (account == null && mobileMode && !identifier.startsWith("+880")) {
                account = AccountStore.authenticate(this, "+880" + identifier, pass);
            }
            if (account == null) {
                Toast.makeText(this, "Login failed. Check your Email/Mobile and Password.", Toast.LENGTH_LONG).show();
                return;
            }
            Role role = AdminIdentifiers.isAdminIdentifier(identifier) ? Role.ADMIN : Role.USER;
            SessionManager.setSession(this, role, account.userId);
            SessionManager.saveProfile(this, account.name, account.email, account.mobile);
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        } catch (Throwable t) {
            Toast.makeText(this, "Login failed safely. Your account data was not changed.", Toast.LENGTH_LONG).show();
        }
    }
}
