# MY SHOP Developer Handoff — V-248

## Base / checkpoint
- Current source: V-248, created from preserved V-247.
- Previous source must not be overwritten. Next version is V-249.

## Completed in this source
1. LIVE STREAMING action ratio corrected to Go Live 40% / Join Live 60%; Join Live remains the stronger pulse/glow action.
2. Dashboard live profile row now calls backend live presence data (up to 4 real active profiles), with clean waiting fallback when nobody is active.
3. External Movie Admin slots now support Gallery/File custom image upload, preview, and save through the existing R2 admin upload path.
4. MORE APPS / Social Admin entries now support custom icon/image upload + preview.
5. Social icon priority is Custom Upload → Icon URL → platform-name built-in icon → default icon.
6. Gallery audio PLAY opens AudioPlayerActivity inside MY SHOP instead of Chrome.
7. Account profile keeps premium cover/avatar structure and adds Posts, Photos/Videos, Privacy surfaces.
8. Friends / Followers / Following remain backend-derived; friend accept response now returns both live stat sets.
9. Profile Timeline/Media uses backend posts with PUBLIC/FRIENDS/PRIVATE visibility controls.

## Backend / schema
- Added social_links.icon_url and social_links.image_url.
- Added myshop_live_presence and myshop_profile_privacy.
- Added migration 0004_v248_social_live_privacy.sql.

## Pending operational step
- Cloudflare Worker must be deployed through the approved GitHub workflow so new endpoints/schema reach production.
- GitHub build/preflight remains the release acceptance gate.

## Exact stop point
- Source implementation and local compile/validation are the last checkpoint. Production deployment is not claimed from this handoff.
