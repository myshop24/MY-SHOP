# V654 APK build checkpoint
No APK built. Local Gradle8.11.1 download blocked by network; Android SDK/original signing key unavailable. Full GitHub workflow/setup/source included. Exact V654 GitHub run and signed artifact must still be built/verified. Do not reuse older APK. Read GITHUB-UPLOAD-V654-BN.md and current handoff. New DEX marker gate covers Cricket and per-card Publish/Toggle.
