package com.myshop.app;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.OpenableColumns;
import java.io.InputStream;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;

/** V-227 focused admin detail board. One folder at a time; no giant all-in-one settings page. */
public class AdminSectionActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(246,248,252), DARK=Color.rgb(22,28,55), PURPLE=Color.rgb(83,32,180), BLUE=Color.rgb(31,73,210), GREEN=Color.rgb(17,139,88), RED=Color.rgb(210,45,55), MUTED=Color.rgb(100,106,122);
    private String section;
    private LinearLayout body;
    private EditText news,shopUrl,tvUrl,movieUrl,chatUrl,powerAdTitle,powerAdByline,dashBgColor,dashBlueColor,dashPurpleColor,dashPinkColor;
    private TextView newsSizeLabel;
    private float newsSizeSp=8.6f;
    private final EditText[] featureTitle=new EditText[8],featureUrl=new EditText[8],featureIcon=new EditText[8]; private final CheckBox[] featureActive=new CheckBox[8];
    private final EditText[] socialPlatform=new EditText[8],socialUrl=new EditText[8],socialCaption=new EditText[8];
    private final EditText[] itemTitle=new EditText[3],itemCaption=new EditText[3],itemUrl=new EditText[3],itemIcon=new EditText[3],itemImage=new EditText[3]; private final CheckBox[] itemActive=new CheckBox[3]; private final long[] itemId=new long[3];
    private String managedCategory="",managedDisplayTitle=""; private long singleId=0; private EditText singleTitle,singleCaption,singleUrl,singleIcon,singleImage; private CheckBox singleActive;
    private static final int REQ_FEATURE_IMAGE=7711; private EditText pendingImageField; private String pendingAssetBox=""; private int pendingAssetSlot=1;
    private final EditText[] extTitle=new EditText[6],extCaption=new EditText[6],extUrl=new EditText[6],extIcon=new EditText[6],extImage=new EditText[6]; private final long[] extId=new long[6];
    private boolean socialSaving=false;
    private EditText[] menuName,menuUrl,menuIcon; private CheckBox[] menuActive; private final EditText[] dynamicTitle=new EditText[4],dynamicCaption=new EditText[4],dynamicUrl=new EditText[4],dynamicIcon=new EditText[4],dynamicImage=new EditText[4]; private final CheckBox[] dynamicActive=new CheckBox[4]; private final long[] dynamicId=new long[4];
    private final String[] menuKeys={"menu_home","menu_shop","menu_gallery","menu_external","menu_go_live","menu_join_live","menu_earn","menu_live_tv","menu_live","menu_social","menu_chat","menu_music","menu_news","menu_more","menu_share","menu_support","menu_jobs","menu_coupon","menu_booking","menu_wallet","menu_settings","menu_language","menu_logout"};
    private final String[] menuNames={"HOME","MY SHOP","GALLERY","EXTERNAL MOVIE","GO LIVE","JOIN LIVE","EARN & REWARD","LIVE TV","LIVE","SOCIAL MEDIA","CHAT","MUSIC","BREAKING NEWS","MORE APPS","SHARE APP","CUSTOMER SUPPORT","JOBS","COUPON","BOOKING","WALLET","SETTINGS","LANGUAGE","LOGOUT"};
    private final String[] featureKeys={"my_feed","live_now","go_live","live_tv","my_shop","external_movie","gallery","social_media"};
    private final String[] featureNames={"MY FEED","LIVE","GO LIVE","LIVE TV","MY SHOP","EXTERNAL MOVIE","GALLERY","SOCIAL MEDIA"};

    @Override protected void onCreate(Bundle b){super.onCreate(b);section=getIntent().getStringExtra("section");if(section==null)section="dashboard";managedCategory=getIntent().getStringExtra("managed_category");if(managedCategory==null)managedCategory="";managedDisplayTitle=getIntent().getStringExtra("managed_title");if(managedDisplayTitle==null)managedDisplayTitle="";if(!SessionManager.isAdmin(this) || !getIntent().getBooleanExtra("admin_context",false)){finish();return;}build();load();}

    private void build(){
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);LinearLayout root=col();root.setBackgroundColor(BG);root.setPadding(dp(12),dp(10),dp(12),dp(22));
        LinearLayout head=row();Button back=button("‹",DARK,28);back.setOnClickListener(v->finish());head.addView(back,lp(dp(42),dp(46)));LinearLayout hb=col();hb.addView(txt(title(),19,DARK,true),lp(-1,dp(25)));hb.addView(txt("ADMIN ONLY  •  ID "+SessionManager.getUserId(this),9,MUTED,true),lp(-1,dp(18)));head.addView(hb,weight(1));root.addView(head,lp(-1,dp(54)));
        body=col();root.addView(body,lp(-1,-2));
        if("dashboard".equals(section))dashboardUi();else if("feature_card".equals(section))featureCardUi();else if("features".equals(section))featuresUi();else if("social".equals(section))socialUi();else if("more_apps".equals(section))moreAppsUi();else if("menu".equals(section))menuUi();else if("dynamic_content".equals(section))dynamicContentUi();else if("external_movie".equals(section))externalMovieUi();else if("moderators".equals(section))moderatorUi();else managedUi();
        TextView back2=action("←  ADMIN FOLDER LIST",DARK,()->finish());root.addView(back2,lp(-1,dp(44)));sv.addView(root);setContentView(sv);
    }
    private String title(){if("feature_card".equals(section))return (managedDisplayTitle.isEmpty()?"FEATURE":managedDisplayTitle)+" ADMIN";if("dashboard".equals(section))return "DASHBOARD / BREAKING NEWS";if("menu".equals(section))return "3-LINE MENU MANAGEMENT";if("features".equals(section))return "FEATURE MANAGEMENT";if("social".equals(section))return "SOCIAL LINKS";if("moderators".equals(section))return "MODERATOR / ADMIN";if("help_support".equals(section))return "CUSTOMER SUPPORT";return section.replace('_',' ').toUpperCase();}

    private void dashboardUi(){
        addHeader("Headline box-এ User শুধু animated 📣 + headline দেখবে। Admin এখানে Edit / Delete / Save এবং Size +/- করতে পারবে।");
        news=field("Headline text");
        body.addView(news);

        LinearLayout sizeRow=row();
        TextView minus=action("A−",PURPLE,()->changeNewsSize(-0.5f));
        newsSizeLabel=txt("Text size  8.6sp",12,DARK,true); newsSizeLabel.setGravity(Gravity.CENTER);
        TextView plus=action("A＋",BLUE,()->changeNewsSize(0.5f));
        sizeRow.addView(minus,wt(1)); sizeRow.addView(gap(6)); sizeRow.addView(newsSizeLabel,wt(1.4f)); sizeRow.addView(gap(6)); sizeRow.addView(plus,wt(1));
        body.addView(sizeRow,lp(-1,dp(44)));

        LinearLayout headlineActions=row();
        headlineActions.addView(action("✎  EDIT / SAVE",GREEN,()->saveDashboard()),wt(1));
        headlineActions.addView(gap(6));
        headlineActions.addView(action("⌫  DELETE",RED,()->deleteHeadline()),wt(1));
        body.addView(headlineActions,lp(-1,dp(44)));

        addHeader("অন্য Dashboard link/settings নিচে আছে। Approved default colors Admin নিজে না বদলালে অপরিবর্তিত থাকবে।");
        shopUrl=field("MY SHOP URL");tvUrl=field("LIVE TV URL");movieUrl=field("External Movie URL");chatUrl=field("Chat URL");powerAdTitle=field("POWER AD title (default: POWER AD)");powerAdByline=field("POWER AD byline (default: by Touhid)");
        body.addView(shopUrl);body.addView(tvUrl);body.addView(movieUrl);body.addView(chatUrl);body.addView(powerAdTitle);body.addView(powerAdByline);
        addHeader("Dashboard + button default colors reference image অনুযায়ী locked. শুধু Admin চাইলে এখানে HEX color বদলাতে পারবে.");
        dashBgColor=field("Dashboard BG HEX  #F8F9FD");dashBlueColor=field("Primary Blue HEX  #2E2FBE");dashPurpleColor=field("Purple HEX  #5B26D6");dashPinkColor=field("Pink/Magenta HEX  #EB24A8");body.addView(dashBgColor);body.addView(dashBlueColor);body.addView(dashPurpleColor);body.addView(dashPinkColor);
        body.addView(action("✓  SAVE ALL DASHBOARD SETTINGS",GREEN,()->saveDashboard()),lp(-1,dp(46)));
    }

    private void changeNewsSize(float delta){
        newsSizeSp=Math.max(7.0f,Math.min(16.0f,newsSizeSp+delta));
        if(newsSizeLabel!=null)newsSizeLabel.setText(String.format(java.util.Locale.US,"Text size  %.1fsp",newsSizeSp));
    }

    private void deleteHeadline(){
        new AlertDialog.Builder(this).setTitle("Delete headline?").setMessage("Headline text will be cleared. The animated 📣 icon will remain.")
            .setNegativeButton("CANCEL",null)
            .setPositiveButton("DELETE",(d,w)->{news.setText("");saveDashboard();}).show();
    }

    private void externalMovieUi(){
        addHeader("এখানে সর্বোচ্চ ৬টি External Movie/Link রাখুন। প্রতিটিতে Caption + URL দিয়ে Save, Edit বা Delete করতে পারবেন।");
        for(int i=0;i<6;i++){final int x=i;LinearLayout c=card();c.addView(txt("EXTERNAL MOVIE  "+(i+1),13,DARK,true),lp(-1,dp(25)));extTitle[i]=field("Name / Title");extCaption[i]=field("Caption (optional)");extUrl[i]=field("Website URL (https://...)");extIcon[i]=field("Icon URL (optional)");extImage[i]=field("Image URL (optional)");c.addView(extTitle[i]);c.addView(extCaption[i]);c.addView(extUrl[i]);c.addView(extIcon[i]);c.addView(extImage[i]);LinearLayout a=row();a.addView(action("SAVE / EDIT",GREEN,()->saveExternalItem(x)),wt(1));a.addView(gap(5));a.addView(action("DELETE",RED,()->deleteExternalItem(x)),wt(1));c.addView(a,lp(-1,dp(42)));body.addView(c,lp(-1,-2));}
        body.addView(action("↻  RELOAD",BLUE,()->load()),lp(-1,dp(44)));
    }

    private void featuresUi(){
        addHeader("একটি Feature খুলে নাম, Icon URL, Link এবং Show/Hide নিয়ন্ত্রণ করুন।");
        for(int i=0;i<8;i++){final int x=i;LinearLayout c=card();c.addView(txt(featureNames[i],13,DARK,true),lp(-1,dp(25)));featureTitle[i]=field("Display title / Caption (optional)");featureUrl[i]=field("Target URL");featureIcon[i]=field("Icon URL (optional)");featureActive[i]=new CheckBox(this);featureActive[i].setText("Dashboard-এ দেখাবে");featureActive[i].setTextSize(11);featureActive[i].setChecked(true);c.addView(featureTitle[i]);c.addView(featureUrl[i]);c.addView(featureIcon[i]);c.addView(featureActive[i],lp(-1,dp(36)));LinearLayout fa=row();fa.addView(action("SAVE / EDIT",GREEN,()->saveFeature(x)),wt(1));fa.addView(gap(5));fa.addView(action("DELETE",RED,()->deleteFeature(x)),wt(1));c.addView(fa,lp(-1,dp(42)));body.addView(c,lp(-1,-2));}
        body.addView(action("➕  ADD NEW FEATURE",PURPLE,()->addNewFeature()),lp(-1,dp(44)));
    }

    private void moreAppsUi(){
        addHeader("MORE-এ Facebook, Page, YouTube, WhatsApp, imo, Instagram, Telegram-এর logo-সহ button-এর link এখানে বসান। Link বসিয়ে SAVE / EDIT চাপুন।");
        String[] names={"Facebook","Page","YouTube","WhatsApp","imo","Instagram","Telegram","TikTok"};
        for(int i=0;i<8;i++ ){final int x=i;LinearLayout c=card();c.addView(txt(names[i],13,DARK,true),lp(-1,dp(25)));socialPlatform[i]=field("Platform / Name");socialPlatform[i].setText(names[i]);socialUrl[i]=field("Link / URL");socialCaption[i]=field("Caption / headline (optional)");c.addView(socialPlatform[i]);c.addView(socialUrl[i]);c.addView(socialCaption[i]);LinearLayout ma=row();ma.addView(saveSocialButton("SAVE / EDIT",x),wt(1));ma.addView(gap(5));ma.addView(action("DELETE",RED,()->deleteSocial(x)),wt(1));c.addView(ma,lp(-1,dp(44)));body.addView(c,lp(-1,-2));}
        body.addView(action("✓  SAVE ALL SOCIAL LINKS",GREEN,this::saveAllSocialLinks),lp(-1,dp(46)));
        addHeader("Customer Support-এর আলাদা Add / Edit / Save / Delete + Image control আছে।");
        body.addView(action("CUSTOMER SUPPORT ADMIN",PURPLE,()->startActivity(new android.content.Intent(this,AdminSectionActivity.class).putExtra("section","help_support").putExtra("admin_context",true))),lp(-1,dp(44)));
    }

    private void socialUi(){
        addHeader("প্রতি ঘরে একটি করে Social platform। ভুল হলে Delete করে Save করুন।");
        for(int i=0;i<8;i++){final int x=i;LinearLayout c=card();c.addView(txt("SOCIAL LINK  "+(i+1),13,DARK,true),lp(-1,dp(25)));socialPlatform[i]=field("Platform name (Facebook / YouTube / TikTok...)");socialUrl[i]=field("Social URL");socialCaption[i]=field("Caption / headline (optional)");c.addView(socialPlatform[i]);c.addView(socialUrl[i]);c.addView(socialCaption[i]);LinearLayout a=row();a.addView(action("SAVE",GREEN,()->saveSocial(x)),wt(1));a.addView(gap(5));a.addView(action("DELETE",RED,()->deleteSocial(x)),wt(1));c.addView(a,lp(-1,dp(42)));body.addView(c,lp(-1,-2));}
    }

    private void managedUi(){
        addHeader("help_support".equals(section)?"Customer Support: সব ঘর optional। শুধু Link, শুধু Image, শুধু Name — যেটা চান সেটাই দিয়ে SAVE করতে পারবেন।":"সব ঘর optional। যে তথ্য দিতে চান সেটাই দিয়ে SAVE করুন।");
        for(int i=0;i<3;i++){final int x=i;LinearLayout c=card();c.addView(txt(("help_support".equals(section)?"SUPPORT ":"ITEM ")+(i+1),13,DARK,true),lp(-1,dp(25)));itemTitle[i]=field("Name / title (optional)");itemCaption[i]=field("Caption / description (optional)");itemUrl[i]=field("Link / URL / value (optional)");itemIcon[i]=field("Icon URL (optional)");itemImage[i]=field("Image URL (optional)");itemActive[i]=new CheckBox(this);itemActive[i].setText("Active / frontend-এ দেখাবে");itemActive[i].setTextSize(11);itemActive[i].setChecked(true);c.addView(itemTitle[i]);c.addView(itemCaption[i]);c.addView(itemUrl[i]);c.addView(itemIcon[i]);c.addView(itemImage[i]);c.addView(action("CHOOSE / UPLOAD IMAGE (OPTIONAL)",BLUE,()->pickFeatureImage(itemImage[x],"feature_asset_"+section,x+1)),lp(-1,dp(40)));c.addView(itemActive[i],lp(-1,dp(36)));c.addView(action("✓  SAVE / EDIT THIS ITEM",GREEN,()->saveManaged(x)),lp(-1,dp(46)));LinearLayout controls=row();controls.addView(action("ADD / CLEAR",PURPLE,()->prepareManagedSlot(x)),wt(1));controls.addView(gap(5));controls.addView(action("DELETE",RED,()->deleteManaged(x)),wt(1));c.addView(controls,lp(-1,dp(42)));body.addView(c,lp(-1,-2));}
    }
    private void prepareManagedSlot(int i){itemId[i]=0;itemTitle[i].setText("");itemCaption[i].setText("");itemUrl[i].setText("");itemIcon[i].setText("");itemImage[i].setText("");itemActive[i].setChecked(true);toast("New item ready — fill fields and press SAVE / EDIT");}

    private void featureCardUi(){
        if(managedCategory.isEmpty()){addHeader("Feature category missing.");return;}
        addHeader("এই Button/Feature-এর নিজস্ব Admin Panel। Name, Caption, Link, Icon, Image এবং Active status বদলান। Save করলে শুধু এই button-টাই update হবে।");
        LinearLayout c=card(); singleTitle=field("Name / title (optional)");singleCaption=field("Caption / description (optional)");singleUrl=field("Link / URL (optional)");singleIcon=field("Icon URL (optional)");singleImage=field("Image URL (optional)");singleActive=new CheckBox(this);singleActive.setText("Active / frontend-এ দেখাবে");singleActive.setChecked(true);c.addView(singleTitle);c.addView(singleCaption);c.addView(singleUrl);c.addView(singleIcon);c.addView(singleImage);c.addView(action("CHOOSE / UPLOAD IMAGE (OPTIONAL)",BLUE,()->pickFeatureImage(singleImage,"feature_asset_"+managedCategory,1)),lp(-1,dp(40)));c.addView(singleActive,lp(-1,dp(36)));c.addView(action("✓  SAVE THIS FEATURE",GREEN,this::saveFeatureCard),lp(-1,dp(48)));LinearLayout r=row();r.addView(action("ADD / CLEAR",PURPLE,this::prepareFeatureCard),wt(1));r.addView(gap(5));r.addView(action("DELETE",RED,this::deleteFeatureCard),wt(1));c.addView(r,lp(-1,dp(42)));body.addView(c,lp(-1,-2));
        if("feature_gallery".equals(managedCategory))body.addView(action("OPEN GALLERY CONTENT ADMIN",BLUE,()->startActivity(new android.content.Intent(this,GalleryAdminActivity.class))),lp(-1,dp(44)));
        if("feature_more_apps".equals(managedCategory))body.addView(action("OPEN MORE / SOCIAL ADMIN",BLUE,()->startActivity(new android.content.Intent(this,AdminSectionActivity.class).putExtra("section","more_apps").putExtra("admin_context",true))),lp(-1,dp(44)));
        if("feature_external_movie".equals(managedCategory))body.addView(action("OPEN EXTERNAL LINKS ADMIN",BLUE,()->startActivity(new android.content.Intent(this,AdminSectionActivity.class).putExtra("section","external_movie").putExtra("admin_context",true))),lp(-1,dp(44)));
        if("feature_social_media".equals(managedCategory))body.addView(action("OPEN SOCIAL LINKS ADMIN",BLUE,()->startActivity(new android.content.Intent(this,AdminSectionActivity.class).putExtra("section","social").putExtra("admin_context",true))),lp(-1,dp(44)));
    }
    private void prepareFeatureCard(){singleTitle.setText(managedDisplayTitle);singleCaption.setText("");singleUrl.setText("");singleIcon.setText("");singleImage.setText("");singleActive.setChecked(true);toast(singleId>0?"Current feature cleared for replacement — press SAVE / EDIT":"New setting ready — press SAVE / EDIT");}
    private void saveFeatureCard(){try{String title=singleTitle.getText().toString().trim();if(title.isEmpty())title=managedDisplayTitle;JSONObject x=new JSONObject().put("id",singleId).put("category",managedCategory).put("title",title).put("caption",singleCaption.getText().toString().trim()).put("url",singleUrl.getText().toString().trim()).put("iconUrl",singleIcon.getText().toString().trim()).put("imageUrl",singleImage.getText().toString().trim()).put("active",singleActive.isChecked()).put("displayOrder",1);BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("managedLinks",new JSONArray().put(x)),result("Feature saved"));}catch(Exception e){toast("Feature data invalid");}}
    private void deleteFeatureCard(){try{String title=singleTitle.getText().toString().trim();JSONObject x=new JSONObject().put("id",singleId).put("category",managedCategory).put("title",title).put("caption",singleCaption.getText().toString().trim()).put("url",singleUrl.getText().toString().trim()).put("iconUrl",singleIcon.getText().toString().trim()).put("imageUrl",singleImage.getText().toString().trim()).put("active",false).put("displayOrder",1);BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("managedLinks",new JSONArray().put(x)),result("Feature deleted / hidden"));}catch(Exception e){toast("Delete failed");}}

    private void menuUi(){
        addHeader("৩-line menu-এর প্রতিটি item-এর নাম, icon, link ও show/hide নিয়ন্ত্রণ করুন। Save / Edit / Delete কাজ করবে এবং frontend reload হলে পরিবর্তন দেখাবে।");
        menuName=new EditText[menuKeys.length]; menuUrl=new EditText[menuKeys.length]; menuIcon=new EditText[menuKeys.length]; menuActive=new CheckBox[menuKeys.length];
        for(int i=0;i<menuKeys.length;i++){final int x=i;LinearLayout c=card();c.addView(txt(menuNames[i],13,DARK,true),lp(-1,dp(25)));menuName[i]=field("Menu name");menuUrl[i]=field("Target / Link (optional)");menuIcon[i]=field("Icon URL / icon key");menuActive[i]=new CheckBox(this);menuActive[i].setText("Show in 3-line menu");menuActive[i].setChecked(true);c.addView(menuName[i]);c.addView(menuUrl[i]);c.addView(menuIcon[i]);c.addView(menuActive[i]);LinearLayout r=row();r.addView(action("SAVE / EDIT",GREEN,()->saveMenuItem(x)),wt(1));r.addView(gap(5));r.addView(action("DELETE",RED,()->deleteMenuItem(x)),wt(1));c.addView(r,lp(-1,dp(42)));body.addView(c,lp(-1,-2));}
        body.addView(action("➕ ADD NEW MENU",PURPLE,this::addNewMenu),lp(-1,dp(44)));
    }
    private void saveMenuItem(int i){try{String title=menuName[i].getText().toString().trim();if(title.isEmpty()){toast("Menu name required");return;}JSONObject item=new JSONObject().put("key",menuKeys[i]).put("title",title).put("targetUrl",menuUrl[i].getText().toString().trim()).put("iconUrl",menuIcon[i].getText().toString().trim()).put("active",menuActive[i].isChecked()).put("displayOrder",i+1);BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("featureButtons",new JSONArray().put(item)),result("Menu saved"));}catch(Exception e){toast("Menu data invalid");}}
    private void deleteMenuItem(int i){try{BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("deleteFeatureKeys",new JSONArray().put(menuKeys[i])),result("Menu deleted"));}catch(Exception e){toast("Delete failed");}}
    private void addNewMenu(){final EditText name=field("Menu name");final EditText url=field("Target / Link (optional)");final EditText icon=field("Icon URL / icon key");LinearLayout box=col();box.setPadding(dp(8),0,dp(8),0);box.addView(name);box.addView(url);box.addView(icon);new AlertDialog.Builder(this).setTitle("ADD MENU ITEM").setView(box).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(d,w)->{try{String n=name.getText().toString().trim();if(n.isEmpty()){toast("Menu name required");return;}String key="menu_custom_"+System.currentTimeMillis();JSONObject item=new JSONObject().put("key",key).put("title",n).put("targetUrl",url.getText().toString().trim()).put("iconUrl",icon.getText().toString().trim()).put("active",true).put("displayOrder",99);BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("featureButtons",new JSONArray().put(item)),result("Menu added"));}catch(Exception e){toast("Menu data invalid");}}).show();}

    private void dynamicContentUi(){
        addHeader("নতুন আলাদা Dynamic row নেই। Dashboard-এর EXISTING ছোট circular/live row-এর প্রতিটি slot আলাদাভাবে edit করুন। Hidden slot-ও এই তালিকা থেকে আবার চালু করা যাবে।");
        final String[] names={"SHOPPING / SLOT 1","GADGET / SLOT 2","FASHION / SLOT 3","GAMING / SLOT 4","LIVE / SLOT 5","AD / SLOT 6"};
        for(int i=0;i<6;i++){final int slot=i+1;final String label=names[i];body.addView(action("OPEN  "+label,BLUE,()->{Intent z=new Intent(this,AdminSectionActivity.class);z.putExtra("section","feature_card");z.putExtra("managed_category","dashboard_slot_"+slot);z.putExtra("managed_title","DASHBOARD SLOT "+slot);z.putExtra("admin_context",true);startActivity(z);}),lp(-1,dp(44)));body.addView(gap(6),lp(1,dp(6)));}
    }
    private void saveDynamicContent(String cat,int order){try{String title=dynamicTitle[order].getText().toString().trim();if(title.isEmpty()){toast("Name / title required");return;}JSONObject x=new JSONObject().put("id",dynamicId[order]).put("category",cat).put("title",title).put("caption",dynamicCaption[order].getText().toString().trim()).put("url",dynamicUrl[order].getText().toString().trim()).put("iconUrl",dynamicIcon[order].getText().toString().trim()).put("imageUrl",dynamicImage[order].getText().toString().trim()).put("active",dynamicActive[order].isChecked()).put("displayOrder",order+1);BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("managedLinks",new JSONArray().put(x)),result("Dynamic item saved"));}catch(Exception e){toast("Dynamic data invalid");}}
    private void deleteDynamicContent(String cat,int order){long id=dynamicId[order];if(id<=0){toast("Already empty");return;}try{BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("deleteManagedLinkIds",new JSONArray().put(id)),result("Dynamic item deleted"));}catch(Exception e){toast("Delete failed");}}
    private void addDynamicContent(){final EditText cat=field("Category (live_now / advertisement / social_media / caption)");final EditText title=field("Name / title");final EditText cap=field("Caption");final EditText url=field("Link / URL");final EditText icon=field("Icon URL");final EditText image=field("Image / Banner URL");LinearLayout box=col();box.addView(cat);box.addView(title);box.addView(cap);box.addView(url);box.addView(icon);box.addView(image);new AlertDialog.Builder(this).setTitle("ADD DYNAMIC ITEM").setView(box).setPositiveButton("SAVE",(d,w)->{try{String c=cat.getText().toString().trim().toLowerCase();if(c.isEmpty()||title.getText().toString().trim().isEmpty()){toast("Category and title required");return;}JSONObject x=new JSONObject().put("category",c).put("title",title.getText().toString().trim()).put("caption",cap.getText().toString().trim()).put("url",url.getText().toString().trim()).put("iconUrl",icon.getText().toString().trim()).put("imageUrl",image.getText().toString().trim()).put("active",true).put("displayOrder",99);BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("managedLinks",new JSONArray().put(x)),result("Dynamic item added"));}catch(Exception e){toast("Dynamic data invalid");}}).setNegativeButton("CANCEL",null).show();}

    private void moderatorUi(){
        addHeader("Moderator ID যোগ/সরানো। Permanent Admin ID পরিবর্তন করা যাবে না।");
        EditText id=field("4-digit User ID");body.addView(id);LinearLayout a=row();a.addView(action("ADD MODERATOR",GREEN,()->moderator(id.getText().toString(),"add_moderator")),wt(1));a.addView(gap(5));a.addView(action("REMOVE",RED,()->moderator(id.getText().toString(),"remove_moderator")),wt(1));body.addView(a,lp(-1,dp(42)));
        body.addView(action("RELOAD MODERATOR STATUS",BLUE,()->load()),lp(-1,dp(42)));
    }

    private void addHeader(String s){TextView t=txt(s,10,MUTED,false);t.setPadding(dp(4),dp(2),dp(4),dp(12));body.addView(t,lp(-1,-2));}

    private void load(){String token=SessionManager.getToken(this);if(token==null||token.isEmpty())return;BackendClient.dashboard(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->apply(d));}public void onError(String m){runOnUiThread(()->toast("Server config unavailable: "+m));}});}
    private void apply(JSONObject d){try{
        if("dashboard".equals(section)){JSONObject c=d.optJSONObject("config");if(c!=null){news.setText(c.optString("breaking_news",""));newsSizeSp=(float)Math.max(7.0,Math.min(16.0,c.optDouble("breaking_news_text_size",8.6)));if(newsSizeLabel!=null)newsSizeLabel.setText(String.format(java.util.Locale.US,"Text size  %.1fsp",newsSizeSp));shopUrl.setText(c.optString("my_shop_url",""));tvUrl.setText(c.optString("live_tv_url",""));movieUrl.setText(c.optString("external_movie_url",""));chatUrl.setText(c.optString("chat_url",""));powerAdTitle.setText(c.optString("power_ad_title","POWER AD"));powerAdByline.setText(c.optString("power_ad_byline","by Touhid"));dashBgColor.setText(c.optString("dashboard_bg_color",ThemeConfig.DEF_BG));dashBlueColor.setText(c.optString("dashboard_blue_color",ThemeConfig.DEF_BLUE));dashPurpleColor.setText(c.optString("dashboard_purple_color",ThemeConfig.DEF_PURPLE));dashPinkColor.setText(c.optString("dashboard_pink_color",ThemeConfig.DEF_PINK));}}
        else if("feature_card".equals(section)){singleId=0;JSONArray a=d.optJSONArray("managedLinks");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&managedCategory.equalsIgnoreCase(x.optString("category",""))){singleId=x.optLong("id",0);singleTitle.setText(x.optString("title",managedDisplayTitle));singleCaption.setText(x.optString("caption",""));singleUrl.setText(x.optString("url",""));singleIcon.setText(x.optString("icon_url",""));singleImage.setText(x.optString("image_url",""));singleActive.setChecked(x.optInt("active",1)==1);break;}}if(singleId==0&&singleTitle!=null)singleTitle.setText(managedDisplayTitle);}
        else if("dynamic_content".equals(section)){/* V-228: slot launcher only; each slot loads in its own feature_card panel. */}
        else if("external_movie".equals(section)){JSONArray a=d.optJSONArray("managedLinks");if(a!=null){int n=0;for(int i=0;i<a.length()&&n<6;i++){JSONObject x=a.optJSONObject(i);if(x==null||!"external_movie".equalsIgnoreCase(x.optString("category","")))continue;extId[n]=x.optLong("id",0);extTitle[n].setText(x.optString("title",""));extCaption[n].setText(x.optString("caption",""));extUrl[n].setText(x.optString("url",""));extIcon[n].setText(x.optString("icon_url",""));extImage[n].setText(x.optString("image_url",""));n++;}}}
        else if("features".equals(section)){JSONArray a=d.optJSONArray("featureButtons");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;for(int j=0;j<featureKeys.length;j++)if(featureKeys[j].equals(x.optString("key",""))){featureTitle[j].setText(x.optString("title",featureNames[j]));featureUrl[j].setText(x.optString("target_url",""));featureIcon[j].setText(x.optString("icon_url",""));featureActive[j].setChecked(x.optInt("active",1)==1);}}}
        else if("menu".equals(section)){JSONArray a=d.optJSONArray("featureButtons");if(a!=null&&menuName!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String key=x.optString("key","");for(int j=0;j<menuKeys.length;j++)if(menuKeys[j].equals(key)){menuName[j].setText(x.optString("title",menuNames[j]));menuUrl[j].setText(x.optString("target_url",""));menuIcon[j].setText(x.optString("icon_url",""));menuActive[j].setChecked(x.optInt("active",1)==1);}}}
        else if("social".equals(section)){JSONArray a=d.optJSONArray("socialLinks");if(a!=null)for(int i=0;i<Math.min(8,a.length());i++){JSONObject x=a.optJSONObject(i);if(x!=null){socialPlatform[i].setText(x.optString("platform",""));socialUrl[i].setText(x.optString("url",""));socialCaption[i].setText(x.optString("caption",""));}}}
        else if("more_apps".equals(section)){JSONArray a=d.optJSONArray("socialLinks");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String p=x.optString("platform","");for(int j=0;j<8;j++){if(p.equalsIgnoreCase(new String[]{"Facebook","Page","YouTube","WhatsApp","imo","Instagram","Telegram","TikTok"}[j])){socialPlatform[j].setText(p);socialUrl[j].setText(x.optString("url",""));socialCaption[j].setText(x.optString("caption",""));}}}}
        else if(!"moderators".equals(section)){JSONArray a=d.optJSONArray("managedLinks");if(itemTitle[0]!=null)for(int z=0;z<3;z++){itemId[z]=0;itemTitle[z].setText("");itemCaption[z].setText("");itemUrl[z].setText("");itemIcon[z].setText("");itemImage[z].setText("");itemActive[z].setChecked(true);}if(a!=null){int n=0;for(int i=0;i<a.length()&&n<3;i++){JSONObject x=a.optJSONObject(i);if(x==null||!section.equals(x.optString("category","")))continue;itemId[n]=x.optLong("id",0);itemTitle[n].setText(x.optString("title",""));itemCaption[n].setText(x.optString("caption",""));itemUrl[n].setText(x.optString("url",""));itemIcon[n].setText(x.optString("icon_url",""));itemImage[n].setText(x.optString("image_url",""));itemActive[n].setChecked(x.optInt("active",1)==1);n++;}}}
    }catch(Exception e){toast("Config read error");}}

    private void saveSupport(){if(itemTitle[0]!=null)saveManaged(0);}
    private void saveExternalItem(int i){try{String title=extTitle[i].getText().toString().trim(),caption=extCaption[i].getText().toString().trim(),url=extUrl[i].getText().toString().trim(),icon=extIcon[i].getText().toString().trim(),image=extImage[i].getText().toString().trim();if(title.isEmpty()&&url.isEmpty()){toast("Title or URL required");return;}JSONObject q=new JSONObject();JSONArray a=new JSONArray();a.put(new JSONObject().put("id",extId[i]).put("category","external_movie").put("title",title).put("caption",caption).put("url",url).put("iconUrl",icon).put("imageUrl",image).put("active",!url.isEmpty()).put("displayOrder",i+1));q.put("managedLinks",a);BackendClient.adminContentPut(SessionManager.getToken(this),q,result("External Movie "+(i+1)+" saved"));}catch(Exception e){toast("External Movie data invalid");}}
    private void deleteExternalItem(int i){if(extId[i]<=0){extTitle[i].setText("");extCaption[i].setText("");extUrl[i].setText("");extIcon[i].setText("");extImage[i].setText("");toast("Already empty");return;}new AlertDialog.Builder(this).setTitle("Delete External Movie?").setMessage("শুধু এই link মুছে যাবে।").setPositiveButton("DELETE",(d,w)->{try{JSONObject q=new JSONObject().put("deleteManagedLinkIds",new JSONArray().put(extId[i]));BackendClient.adminContentPut(SessionManager.getToken(this),q,result("External Movie deleted"));}catch(Exception e){toast("Delete failed");}}).setNegativeButton("CANCEL",null).show();}
    private void saveExternalMovie(){
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){JSONObject c=d.optJSONObject("config");String breaking=c==null?"":c.optString("breaking_news","");String shop=c==null?"":c.optString("my_shop_url","");String tv=c==null?"":c.optString("live_tv_url","");String chat=c==null?"":c.optString("chat_url","");String pat=c==null?"POWER AD":c.optString("power_ad_title","POWER AD");String pab=c==null?"by Touhid":c.optString("power_ad_byline","by Touhid");BackendClient.adminDashboardPut(SessionManager.getToken(AdminSectionActivity.this),breaking,shop,tv,movieUrl.getText().toString().trim(),chat,pat,pab,result("External Movie saved"));}public void onError(String m){toast("Cannot read current Dashboard config: "+m);}});
    }
    private void saveDashboard(){String bg=dashBgColor.getText().toString().trim(),blue=dashBlueColor.getText().toString().trim(),purple=dashPurpleColor.getText().toString().trim(),pink=dashPinkColor.getText().toString().trim();if(!ThemeConfig.valid(bg)||!ThemeConfig.valid(blue)||!ThemeConfig.valid(purple)||!ThemeConfig.valid(pink)){toast("Color must be HEX like #F8F9FD");return;}BackendClient.adminDashboardPut(SessionManager.getToken(this),news.getText().toString().trim(),shopUrl.getText().toString().trim(),tvUrl.getText().toString().trim(),movieUrl.getText().toString().trim(),chatUrl.getText().toString().trim(),powerAdTitle.getText().toString().trim(),powerAdByline.getText().toString().trim(),bg,blue,purple,pink,newsSizeSp,result("Dashboard + headline size saved"));}
    private void deleteFeature(int i){
        try{ JSONObject q=new JSONObject().put("deleteFeatureKeys",new JSONArray().put(featureKeys[i])); BackendClient.adminContentPut(SessionManager.getToken(this),q,result("Feature deleted")); }catch(Exception e){toast("Delete failed");}
    }
    private void addNewFeature(){
        final EditText name=field("Feature name / Caption (optional)"); final EditText url=field("Target URL (optional)"); final EditText icon=field("Icon URL (optional)");
        LinearLayout box=col(); box.setPadding(dp(8),0,dp(8),0); box.addView(name); box.addView(url); box.addView(icon);
        new AlertDialog.Builder(this).setTitle("ADD NEW FEATURE").setView(box).setPositiveButton("ADD / SAVE",(d,w)->{
            try{ String title=name.getText().toString().trim(); String target=url.getText().toString().trim(); String iconUrl=icon.getText().toString().trim(); if(title.isEmpty()&&target.isEmpty()){toast("Feature name or link required");return;} String key="custom_"+System.currentTimeMillis(); JSONObject item=new JSONObject().put("key",key).put("title",title).put("iconUrl",iconUrl).put("targetUrl",target).put("active",true).put("displayOrder",99); BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("featureButtons",new JSONArray().put(item)),result("New feature added")); }catch(Exception e){toast("Feature data invalid");}
        }).setNegativeButton("CANCEL",null).show();
    }
    private void saveFeature(int i){try{JSONObject p=new JSONObject();JSONArray a=new JSONArray();a.put(new JSONObject().put("key",featureKeys[i]).put("title",featureTitle[i].getText().toString().trim()).put("iconUrl",featureIcon[i].getText().toString().trim()).put("targetUrl",featureUrl[i].getText().toString().trim()).put("active",featureActive[i].isChecked()).put("displayOrder",i+1));p.put("featureButtons",a);BackendClient.adminContentPut(SessionManager.getToken(this),p,result("Feature saved"));}catch(Exception e){toast("Feature data invalid");}}
    private TextView saveSocialButton(String label,int index){
        Button b=new Button(this); b.setText(label); b.setTextSize(11); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setGravity(Gravity.CENTER); b.setPadding(dp(8),0,dp(8),0); b.setMinHeight(0); b.setMinimumHeight(0); b.setBackground(round(GREEN,GREEN,12)); b.setElevation(dp(2));
        if(android.os.Build.VERSION.SDK_INT>=21){android.graphics.drawable.Drawable base=b.getBackground();b.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(Color.argb(42,255,255,255)),base,null));}
        b.setOnClickListener(v->saveSocial(index)); return b;
    }
    private String normalizeSocialUrl(String platform,String raw){
        String u=raw==null?"":raw.trim(); if(u.isEmpty()) return "";
        if(u.startsWith("http://")||u.startsWith("https://")||u.startsWith("tel:")) return u;
        String digits=u.replaceAll("[^0-9]","");
        if(platform.equalsIgnoreCase("WhatsApp") && digits.length()>=8) return "https://wa.me/"+digits;
        if(platform.equalsIgnoreCase("imo") && digits.length()>=8) return "tel:"+digits;
        if(u.startsWith("www.") || u.contains(".")) return "https://"+u;
        return u;
    }
    private JSONObject socialPayloadItem(int i) throws org.json.JSONException {
        String p=socialPlatform[i].getText().toString().trim(),u=normalizeSocialUrl(p,socialUrl[i].getText().toString()),cap=socialCaption[i].getText().toString().trim();
        return new JSONObject().put("platform",p).put("url",u).put("caption",cap).put("active",!u.isEmpty());
    }
    private void saveSocial(int i){
        if(socialSaving)return;
        try{String p=socialPlatform[i].getText().toString().trim();if(p.isEmpty()){toast("Platform name required");return;}String u=normalizeSocialUrl(p,socialUrl[i].getText().toString());
            socialSaving=true; JSONObject q=new JSONObject(); q.put("socialLinks",new JSONArray().put(socialPayloadItem(i)));
            BackendClient.adminContentPut(SessionManager.getToken(this),q,new BackendClient.Callback(){public void onSuccess(JSONObject d){socialSaving=false;toast("✓ "+p+" saved");load();}public void onError(String m){socialSaving=false;toast("Save failed: "+m);}});
        }catch(Exception e){socialSaving=false;toast("Social data invalid");}
    }
    private void saveAllSocialLinks(){
        if(socialSaving)return;
        try{JSONArray a=new JSONArray();int count=0;for(int i=0;i<8;i++){String p=socialPlatform[i].getText().toString().trim();String u=normalizeSocialUrl(p,socialUrl[i].getText().toString());if(p.isEmpty())continue;a.put(socialPayloadItem(i));count++;}if(count==0){toast("Platform name পাওয়া যায়নি");return;}final int savedCount=count; socialSaving=true;JSONObject q=new JSONObject().put("socialLinks",a);BackendClient.adminContentPut(SessionManager.getToken(this),q,new BackendClient.Callback(){public void onSuccess(JSONObject d){socialSaving=false;toast("✓ "+savedCount+"টি Social link saved");load();}public void onError(String m){socialSaving=false;toast("Save failed: "+m);}});}catch(Exception e){socialSaving=false;toast("Social data invalid");}
    }
    private void deleteSocial(int i){try{String p=socialPlatform[i].getText().toString().trim();if(p.isEmpty()){toast("Already empty");return;}JSONObject q=new JSONObject().put("deleteSocialPlatforms",new JSONArray().put(p));BackendClient.adminContentPut(SessionManager.getToken(this),q,result("Social link deleted"));}catch(Exception e){toast("Delete failed");}}
    private void saveManaged(int i){try{String title=itemTitle[i].getText().toString().trim(),url=itemUrl[i].getText().toString().trim();JSONObject q=new JSONObject();JSONArray a=new JSONArray();a.put(new JSONObject().put("id",itemId[i]).put("category",section).put("title",title).put("caption",itemCaption[i].getText().toString().trim()).put("url",url).put("iconUrl",itemIcon[i].getText().toString().trim()).put("imageUrl",itemImage[i].getText().toString().trim()).put("active",itemActive[i].isChecked()).put("displayOrder",i+1));q.put("managedLinks",a);BackendClient.adminContentPut(SessionManager.getToken(this),q,result("Item saved"));}catch(Exception e){toast("Item data invalid");}}
    private void deleteManaged(int i){if(itemId[i]<=0){prepareManagedSlot(i);toast("Already empty");return;}new AlertDialog.Builder(this).setTitle("Delete item?").setMessage("শুধু এই item-এর record মুছে যাবে।").setPositiveButton("DELETE",(d,w)->{try{JSONObject q=new JSONObject().put("deleteManagedLinkIds",new JSONArray().put(itemId[i]));BackendClient.adminContentPut(SessionManager.getToken(this),q,result("Item deleted"));}catch(Exception e){toast("Delete failed");}}).setNegativeButton("CANCEL",null).show();}
    private void pickFeatureImage(EditText target,String boxKey,int slot){pendingImageField=target;pendingAssetBox=(boxKey==null?"feature_asset":boxKey).toLowerCase().replaceAll("[^a-z0-9_-]","_");pendingAssetSlot=Math.max(1,Math.min(6,slot));Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);i.setType("image/*");startActivityForResult(i,REQ_FEATURE_IMAGE);}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode!=REQ_FEATURE_IMAGE||resultCode!=RESULT_OK||data==null||data.getData()==null||pendingImageField==null)return;Uri u=data.getData();try{InputStream in=getContentResolver().openInputStream(u);if(in==null){toast("Image could not be opened");return;}String mime=getContentResolver().getType(u);if(mime==null||!mime.startsWith("image/"))mime="image/jpeg";String name=queryName(u);final EditText target=pendingImageField;BackendClient.adminAdUpload(SessionManager.getToken(this),in,name,mime,pendingAssetBox,pendingAssetSlot,"Feature image","",3,new BackendClient.Callback(){public void onSuccess(JSONObject d){String url=d.optString("image_url","");runOnUiThread(()->{target.setText(url);toast(url.isEmpty()?"Upload response missing URL":"✓ Image uploaded — press SAVE / EDIT");});}public void onError(String m){runOnUiThread(()->toast("Image upload failed: "+m));}});}catch(Exception e){toast("Image upload failed");}}
    private String queryName(Uri u){try(android.database.Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}catch(Exception ignored){}return "myshop-feature-image.jpg";}

    private void moderator(String id,String act){if(!id.matches("\\d{4}")){toast("Enter a valid 4-digit User ID");return;}BackendClient.adminAction(SessionManager.getToken(this),id,act,result(act.equals("add_moderator")?"Moderator added":"Moderator removed"));}
    private BackendClient.Callback result(String ok){return new BackendClient.Callback(){public void onSuccess(JSONObject d){toast("✓ "+ok);load();}public void onError(String m){toast("Save failed: "+m);}};}

    private LinearLayout card(){LinearLayout c=col();c.setPadding(dp(10),dp(9),dp(10),dp(9));c.setBackground(round(Color.WHITE,Color.rgb(224,226,235),10));c.setElevation(dp(1));LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(8);c.setLayoutParams(p);return c;}
    private TextView action(String s,int c,Runnable r){TextView t=txt(s,11,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(12),0,dp(12),0);t.setBackground(round(c,c,12));t.setElevation(dp(2));if(android.os.Build.VERSION.SDK_INT>=21){android.graphics.drawable.Drawable base=t.getBackground();t.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(Color.argb(42,255,255,255)),base,null));}t.setOnClickListener(v->r.run());return t;}
    private EditText field(String h){EditText e=new EditText(this);e.setHint(h);e.setTextSize(12);e.setSingleLine(true);e.setPadding(dp(10),0,dp(10),0);e.setTextColor(DARK);e.setHintTextColor(Color.rgb(145,148,160));e.setBackground(round(Color.WHITE,Color.rgb(215,218,228),7));LinearLayout.LayoutParams p=lp(-1,dp(44));p.bottomMargin=dp(6);e.setLayoutParams(p);return e;}
    private Button button(String s,int c,float z){Button b=new Button(this);b.setText(s);b.setTextColor(c);b.setTextSize(z);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackgroundColor(Color.TRANSPARENT);b.setPadding(0,0,0,0);return b;}
    private TextView txt(String s,float z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private View gap(int d){return new View(this);}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams wt(float w){return new LinearLayout.LayoutParams(0,dp(42),w);}private LinearLayout.LayoutParams weight(float w){return new LinearLayout.LayoutParams(0,dp(52),w);}private GradientDrawable round(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
}
