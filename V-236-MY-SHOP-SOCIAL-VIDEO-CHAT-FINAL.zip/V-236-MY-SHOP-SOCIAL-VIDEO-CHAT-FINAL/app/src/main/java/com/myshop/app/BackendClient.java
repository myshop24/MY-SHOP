package com.myshop.app;

import android.os.Handler;
import android.os.Looper;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

/** Small dependency-free HTTP client for the Cloudflare Worker backend. */
public final class BackendClient {
    private static final ExecutorService IO = Executors.newCachedThreadPool();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private BackendClient() {}

    public interface Callback { void onSuccess(JSONObject data); void onError(String message); }

    private static String baseUrl() { return BuildConfig.MYSHOP_BACKEND_URL == null ? "" : BuildConfig.MYSHOP_BACKEND_URL.trim().replaceAll("/$", ""); }
    public static boolean configured() { return !baseUrl().isEmpty() && !baseUrl().contains("YOUR-WORKER"); }

    public static void login(String identifier, String password, Callback cb) {
        try { JSONObject b=new JSONObject().put("identifier",identifier).put("password",password); post("/v1/auth/login",b,null,cb); }
        catch(Exception e){ cb.onError("Invalid login request"); }
    }

    public static void register(String name,String email,String mobile,String password,String question,String answer,Callback cb) {
        try {
            JSONObject b=new JSONObject().put("name",name).put("email",email).put("mobile",mobile).put("password",password).put("securityQuestion",question).put("securityAnswer",answer);
            post("/v1/auth/register",b,null,cb);
        } catch(Exception e){ cb.onError("Invalid registration request"); }
    }

    public static void resetPassword(String identifier,String answer,String newPassword,Callback cb) {
        try { JSONObject b=new JSONObject().put("identifier",identifier).put("answer",answer).put("newPassword",newPassword); post("/v1/auth/password/reset",b,null,cb); }
        catch(Exception e){ cb.onError("Invalid reset request"); }
    }

    public static void me(String token,Callback cb) { get("/v1/me",token,cb); }
    public static void securityQuestions(String identifier,Callback cb) {
        try { get("/v1/auth/password/questions?identifier=" + java.net.URLEncoder.encode(identifier,"UTF-8"), null, cb); }
        catch(Exception e){ cb.onError("Invalid identifier"); }
    }
    public static void dashboard(String token,Callback cb) { get("/v1/dashboard/config",token,cb); }
    public static void notifications(String token,Callback cb) { get("/v1/notifications",token,cb); }
    public static void newPeople(String token,int limit,int offset,Callback cb) { get("/v1/people/new?limit="+Math.max(1,Math.min(100,limit))+"&offset="+Math.max(0,offset),token,cb); }
    public static void sendFriendRequest(String token,String userId,Callback cb) { try { post("/v1/friends/request",new JSONObject().put("userId",userId),token,cb); } catch(Exception e){ cb.onError("Invalid friend request"); } }
    public static void friends(String token,Callback cb){ get("/v1/friends",token,cb); }
    public static void respondFriendRequest(String token,String userId,String action,Callback cb){ try{post("/v1/friends/respond",new JSONObject().put("userId",userId).put("action",action),token,cb);}catch(Exception e){cb.onError("Invalid response");} }
    public static void adminSystemHealth(String token,Callback cb) { get("/v1/admin/system/health",token,cb); }
    public static void feedList(String token, int limit, long before, Callback cb) {
        try {
            String q="/v1/feed?limit="+Math.max(1,Math.min(10,limit));
            if(before>0) q += "&before="+before;
            get(q,token,cb);
        } catch(Exception e){ cb.onError("Invalid Feed request"); }
    }
    public static void feedUpload(String token, java.io.InputStream input, String fileName, String mime, String mediaType, String caption, Callback cb) {
        uploadMultipart(token,"/v1/feed/upload",input,fileName,mime,new String[][]{{"mediaType",mediaType},{"caption",caption}},cb);
    }
    public static void feedLike(String token,long postId,Callback cb){ try { request("POST","/v1/feed/like",new JSONObject().put("postId",postId),token,cb); } catch(Exception e){ cb.onError("Invalid like request"); } }
    public static void feedComment(String token,long postId,String comment,Callback cb){ try { request("POST","/v1/feed/comment",new JSONObject().put("postId",postId).put("comment",comment),token,cb); } catch(Exception e){ cb.onError("Invalid comment request"); } }
    public static void feedText(String token, String caption, Callback cb) { try { request("POST","/v1/feed/text",new JSONObject().put("caption",caption==null?"":caption),token,cb); } catch(Exception e){ cb.onError("Invalid text post request"); } }
    public static void feedDelete(String token,long id,Callback cb) {
        try { post("/v1/feed/delete",new JSONObject().put("id",id),token,cb); } catch(Exception e){ cb.onError("Invalid post delete request"); }
    }
    public static void adminFeedList(String token,Callback cb) { get("/v1/admin/feed",token,cb); }
    public static void moderatorFeedDelete(String token,long id,String reason,Callback cb) {
        try { post("/v1/admin/feed/delete",new JSONObject().put("id",id).put("reason",reason==null?"":reason),token,cb); } catch(Exception e){ cb.onError("Invalid moderation request"); }
    }
    public static void markNotificationsRead(String token,Callback cb) { post("/v1/notifications/read-all", new JSONObject(), token, cb); }
    public static void logout(String token,Callback cb) { post("/v1/auth/logout",new JSONObject(),token,cb); }
    public static void adminPermissions(String token, Callback cb) { get("/v1/admin/permissions", token, cb); }
    public static void updateProfile(String token, String name, String email, String mobile, String bio, Callback cb) {
        try { request("PUT", "/v1/me/profile", new JSONObject().put("name",name).put("email",email).put("mobile",mobile).put("bio",bio), token, cb); }
        catch(Exception e) { cb.onError("Invalid profile data"); }
    }
    public static void uploadAvatar(String token, java.io.InputStream input, String fileName, String mime, Callback cb) {
        uploadMultipart(token,"/v1/me/avatar/upload",input,fileName,mime,null,cb);
    }
    public static void coins(String token, Callback cb) { get("/v1/coins",token,cb); }
    public static void giftHistory(String token, Callback cb) { get("/v1/gifts/history",token,cb); }
    public static void requestCoinPurchase(String token, int coins, int amountMinor, String method, String reference, Callback cb) {
        try { request("POST","/v1/coins/purchase-request",new JSONObject().put("coins",coins).put("amountMinor",amountMinor).put("paymentMethod",method).put("reference",reference),token,cb); }
        catch(Exception e) { cb.onError("Invalid coin purchase request"); }
    }

    public static void adminDashboardPut(String token, String breakingNews, String myShopUrl, String liveTvUrl, String externalMovieUrl, String chatUrl, String powerAdTitle, String powerAdByline, Callback cb) {
        adminDashboardPut(token,breakingNews,myShopUrl,liveTvUrl,externalMovieUrl,chatUrl,powerAdTitle,powerAdByline,null,null,null,null,cb);
    }
    public static void adminDashboardPut(String token, String breakingNews, String myShopUrl, String liveTvUrl, String externalMovieUrl, String chatUrl, String powerAdTitle, String powerAdByline, String dashboardBgColor, String dashboardBlueColor, String dashboardPurpleColor, String dashboardPinkColor, Callback cb) {
        adminDashboardPutInternal(token,breakingNews,myShopUrl,liveTvUrl,externalMovieUrl,chatUrl,powerAdTitle,powerAdByline,dashboardBgColor,dashboardBlueColor,dashboardPurpleColor,dashboardPinkColor,null,cb);
    }
    public static void adminDashboardPut(String token, String breakingNews, String myShopUrl, String liveTvUrl, String externalMovieUrl, String chatUrl, String powerAdTitle, String powerAdByline, String dashboardBgColor, String dashboardBlueColor, String dashboardPurpleColor, String dashboardPinkColor, float breakingNewsTextSize, Callback cb) {
        adminDashboardPutInternal(token,breakingNews,myShopUrl,liveTvUrl,externalMovieUrl,chatUrl,powerAdTitle,powerAdByline,dashboardBgColor,dashboardBlueColor,dashboardPurpleColor,dashboardPinkColor,breakingNewsTextSize,cb);
    }
    private static void adminDashboardPutInternal(String token, String breakingNews, String myShopUrl, String liveTvUrl, String externalMovieUrl, String chatUrl, String powerAdTitle, String powerAdByline, String dashboardBgColor, String dashboardBlueColor, String dashboardPurpleColor, String dashboardPinkColor, Float breakingNewsTextSize, Callback cb) {
        try {
            JSONObject b = new JSONObject().put("breakingNews", breakingNews).put("myShopUrl", myShopUrl).put("liveTvUrl", liveTvUrl).put("externalMovieUrl", externalMovieUrl).put("chatUrl", chatUrl).put("powerAdTitle", powerAdTitle).put("powerAdByline", powerAdByline);
            if(dashboardBgColor!=null)b.put("dashboardBgColor",dashboardBgColor); if(dashboardBlueColor!=null)b.put("dashboardBlueColor",dashboardBlueColor); if(dashboardPurpleColor!=null)b.put("dashboardPurpleColor",dashboardPurpleColor); if(dashboardPinkColor!=null)b.put("dashboardPinkColor",dashboardPinkColor);
            if(breakingNewsTextSize!=null)b.put("breakingNewsTextSize",breakingNewsTextSize);
            request("PUT", "/v1/admin/dashboard/config", b, token, cb);
        } catch(Exception e) { cb.onError("Invalid admin settings"); }
    }
    public static void adminAction(String token, String userId, String action, Callback cb) {
        try {
            JSONObject b = new JSONObject().put("userId", userId).put("action", action);
            post("/v1/admin/actions", b, token, cb);
        } catch(Exception e) { cb.onError("Invalid admin action"); }
    }
    public static void adminContentPut(String token, JSONObject payload, Callback cb) { request("PUT", "/v1/admin/content", payload, token, cb); }
    public static void adminMediaList(String token, String folder, Callback cb) {
        String f = folder == null ? "" : folder.trim().toLowerCase();
        try { get("/v1/admin/media?folder=" + java.net.URLEncoder.encode(f,"UTF-8"), token, cb); }
        catch(Exception e) { cb.onError("Invalid gallery folder"); }
    }
    public static void adminBannerDelete(String token, String folder, int slot, Callback cb) { try { post("/v1/admin/banner/delete", new JSONObject().put("folder",folder).put("slot",slot), token, cb); } catch(Exception e) { cb.onError("Invalid banner slot"); } }
    public static void adminBannerUpdate(String token, String folder, int slot, String caption, Callback cb) { try { request("PUT", "/v1/admin/banner/update", new JSONObject().put("folder",folder).put("slot",slot).put("caption",caption), token, cb); } catch(Exception e) { cb.onError("Invalid banner update"); } }
    public static void adminBannerUpload(String token, java.io.InputStream input, String fileName, String mime, String folder, int slot, String caption, Callback cb) {
        uploadMultipart(token,"/v1/admin/banner/upload",input,fileName,mime,new String[][]{{"folder",folder},{"slot",String.valueOf(slot)},{"caption",caption}},cb);
    }
    public static void adminMediaDelete(String token, long id, Callback cb) { try { post("/v1/admin/media/delete", new JSONObject().put("id", id), token, cb); } catch(Exception e) { cb.onError("Invalid media id"); } }
    public static void adminMediaUpdate(String token, long id, String title, String caption, Callback cb) { try { request("PUT", "/v1/admin/media/update", new JSONObject().put("id",id).put("title",title).put("caption",caption), token, cb); } catch(Exception e) { cb.onError("Invalid media update"); } }

    // User-owned Gallery: unlimited item count; each file is still subject to server/R2 limits.
    public static void galleryList(String token, String folder, Callback cb) {
        try { get("/v1/gallery?folder=" + java.net.URLEncoder.encode(folder==null?"":folder,"UTF-8"), token, cb); }
        catch(Exception e) { cb.onError("Invalid gallery folder"); }
    }
    public static void galleryUpload(String token, java.io.InputStream input, String fileName, String mime, String folder, String title, String caption, Callback cb) {
        uploadMultipart(token,"/v1/gallery/upload",input,fileName,mime,new String[][]{{"folder",folder},{"title",title},{"caption",caption}},cb);
    }
    public static void galleryUpdate(String token,long id,String title,String caption,Callback cb) {
        try { request("PUT","/v1/gallery/update",new JSONObject().put("id",id).put("title",title).put("caption",caption),token,cb); }
        catch(Exception e){ cb.onError("Invalid Gallery edit request"); }
    }
    public static void galleryDelete(String token,long id,Callback cb) {
        try { post("/v1/gallery/delete",new JSONObject().put("id",id),token,cb); }
        catch(Exception e){ cb.onError("Invalid Gallery delete request"); }
    }
    public static void adminAds(String token,String boxKey,Callback cb) {
        try { get("/v1/admin/ads?box_key="+java.net.URLEncoder.encode(boxKey==null?"":boxKey,"UTF-8"),token,cb); }
        catch(Exception e){ cb.onError("Invalid ad folder"); }
    }
    public static void adminAdUpload(String token,java.io.InputStream input,String fileName,String mime,String boxKey,int slot,String caption,String targetUrl,int durationSec,Callback cb) {
        uploadMultipart(token,"/v1/admin/ad/upload",input,fileName,mime,new String[][]{{"boxKey",boxKey},{"slot",String.valueOf(slot)},{"caption",caption},{"targetUrl",targetUrl},{"durationSec",String.valueOf(durationSec)}},cb);
    }
    public static void adminAdUpdate(String token,long id,String caption,String targetUrl,boolean active,int durationSec,Callback cb) {
        try { request("PUT","/v1/admin/ad/update",new JSONObject().put("id",id).put("caption",caption).put("targetUrl",targetUrl).put("active",active).put("durationSec",durationSec),token,cb); }
        catch(Exception e){ cb.onError("Invalid ad update request"); }
    }
    public static void adminAdDelete(String token,long id,Callback cb) {
        try { post("/v1/admin/ad/delete",new JSONObject().put("id",id),token,cb); }
        catch(Exception e){ cb.onError("Invalid ad delete request"); }
    }

    public static void adminMediaUpload(String token, java.io.InputStream input, long length, String fileName, String mime, String folder, String title, String caption, int displayOrder, Callback cb) {
        IO.execute(() -> {
            HttpURLConnection c=null; String boundary="----MYSHOP"+System.currentTimeMillis();
            try {
                c=(HttpURLConnection)new URL(baseUrl()+"/v1/admin/media/upload").openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setDoOutput(true); c.setChunkedStreamingMode(8192); c.setRequestProperty("Accept","application/json"); c.setRequestProperty("Authorization","Bearer "+token); c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
                try(OutputStream os=c.getOutputStream()) {
                    writePart(os,boundary,"folder",folder,null,null); writePart(os,boundary,"title",title,null,null); writePart(os,boundary,"caption",caption,null,null); writePart(os,boundary,"displayOrder",String.valueOf(displayOrder),null,null);
                    String safe=fileName==null?"media":fileName.replace("\"","_");
                    os.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\"file\"; filename=\""+safe+"\"\r\nContent-Type: "+(mime==null?"application/octet-stream":mime)+"\r\n\r\n").getBytes(StandardCharsets.UTF_8));
                    byte[] buf=new byte[8192]; int n; while((n=input.read(buf))!=-1) os.write(buf,0,n); os.write("\r\n".getBytes(StandardCharsets.UTF_8)); os.write(("--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8));
                } finally { try { input.close(); } catch(Exception ignored){} }
                int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream(); StringBuilder outText=new StringBuilder(); if(in!=null){try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)outText.append(line);}}
                JSONObject out=outText.length()>0?new JSONObject(outText.toString()):new JSONObject(); MAIN.post(() -> {if(code>=200&&code<300)cb.onSuccess(out);else cb.onError(errorText(out,code));});
            } catch(Exception e){ MAIN.post(() -> cb.onError("Media upload failed: "+e.getMessage())); } finally {if(c!=null)c.disconnect();}
        });
    }
    private static void uploadMultipart(String token,String path,java.io.InputStream input,String fileName,String mime,String[][] fields,Callback cb){
        IO.execute(() -> { HttpURLConnection c=null; String boundary="----MYSHOP"+System.currentTimeMillis(); try {
            c=(HttpURLConnection)new URL(baseUrl()+path).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setDoOutput(true); c.setChunkedStreamingMode(8192); c.setRequestProperty("Accept","application/json"); c.setRequestProperty("Authorization","Bearer "+token); c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
            try(OutputStream os=c.getOutputStream()){ if(fields!=null)for(String[] f:fields)writePart(os,boundary,f[0],f[1],null,null); String safe=fileName==null?"media":fileName.replace("\"","_"); os.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\"file\"; filename=\""+safe+"\"\r\nContent-Type: "+(mime==null?"application/octet-stream":mime)+"\r\n\r\n").getBytes(StandardCharsets.UTF_8)); byte[] buf=new byte[8192];int n;while((n=input.read(buf))!=-1)os.write(buf,0,n);os.write("\r\n".getBytes(StandardCharsets.UTF_8));os.write(("--"+boundary+"--\r\n").getBytes(StandardCharsets.UTF_8)); } finally {try{input.close();}catch(Exception ignored){}}
            int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();StringBuilder st=new StringBuilder();if(in!=null){try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)st.append(line);}} JSONObject out=st.length()>0?new JSONObject(st.toString()):new JSONObject();MAIN.post(()->{if(code>=200&&code<300)cb.onSuccess(out);else cb.onError(errorText(out,code));});
        }catch(Exception e){MAIN.post(()->cb.onError("Upload failed: "+e.getMessage()));}finally{if(c!=null)c.disconnect();}});
    }

    private static void writePart(OutputStream os,String boundary,String name,String value,String ignored1,String ignored2) throws Exception { String v=value==null?"":value; os.write(("--"+boundary+"\r\nContent-Disposition: form-data; name=\""+name+"\"\r\n\r\n"+v+"\r\n").getBytes(StandardCharsets.UTF_8)); }

    private static void get(String path,String token,Callback cb) { request("GET",path,null,token,cb); }
    private static void post(String path,JSONObject body,String token,Callback cb) { request("POST",path,body,token,cb); }

    private static void request(String method,String path,JSONObject body,String token,Callback cb) {
        if(!configured()){ cb.onError("Backend URL is not configured yet."); return; }
        IO.execute(() -> {
            HttpURLConnection c=null;
            try {
                c=(HttpURLConnection)new URL(baseUrl()+path).openConnection(); c.setRequestMethod(method); c.setConnectTimeout(12000); c.setReadTimeout(15000); c.setRequestProperty("Accept","application/json");
                if(token!=null&&!token.isEmpty()) c.setRequestProperty("Authorization","Bearer "+token);
                if(body!=null){ c.setRequestProperty("Content-Type","application/json; charset=utf-8"); c.setDoOutput(true); try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));} }
                int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream(); StringBuilder s=new StringBuilder();
                if(in!=null){try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)s.append(line);}}
                JSONObject out=s.length()>0?new JSONObject(s.toString()):new JSONObject();
                MAIN.post(() -> { if(code>=200&&code<300) cb.onSuccess(out); else cb.onError(errorText(out,code)); });
            } catch(Exception e){ MAIN.post(() -> cb.onError("Backend connection failed. Check internet/Worker URL.")); }
            finally { if(c!=null)c.disconnect(); }
        });
    }
    private static String errorText(JSONObject o,int code){ String e=o.optString("error",""); String detail=o.optString("message",""); if("ACCOUNT_EXISTS".equals(e))return "এই Email/Mobile দিয়ে Account আগে থেকেই আছে।"; if("INVALID_CREDENTIALS".equals(e))return "Login ID অথবা Password ভুল।"; if("ANSWER_NOT_MATCHED".equals(e))return "সিকিউরিটি উত্তর সঠিক নয়।"; if("NO_ID_AVAILABLE".equals(e))return "নতুন User ID পাওয়া যাচ্ছে না।"; if("R2_NOT_CONFIGURED".equals(e))return "R2 storage is not configured on the Worker."; if("AVATAR_TOO_LARGE".equals(e))return "Profile photo is too large (max 5 MB)."; if("AVATAR_TYPE_MISMATCH".equals(e))return "Please select an image for the profile photo."; if("PROFILE_UPDATE_FAILED".equals(e))return "Profile could not be saved safely. Your account was not changed."; if("R2_WRITE_FAILED".equals(e))return "R2 upload failed: "+detail; if("R2_VERIFY_FAILED".equals(e))return "R2 upload verification failed: "+detail; if("AVATAR_MULTIPART_INVALID".equals(e))return "Profile photo upload format was rejected by the Worker: "+detail; if("MEDIA_TOO_LARGE".equals(e))return "Media file is too large (max 50 MB)."; if("MEDIA_TYPE_MISMATCH".equals(e))return "Selected file type does not match the selected Gallery folder."; if("GALLERY_DB_UPDATE_FAILED".equals(e))return "Gallery save failed safely; the selected media was not kept without a database record."; if("MEDIA_NOT_FOUND".equals(e))return "This Gallery item is no longer available."; if("INVALID_GALLERY_FOLDER".equals(e))return "Gallery folder is invalid."; if("AD_DB_UPDATE_FAILED".equals(e))return "Advertisement save failed safely; the old advertisement was kept."; if("AD_TOO_LARGE".equals(e))return "Advertisement image is too large (max 15 MB)."; if("AD_MUST_BE_IMAGE".equals(e))return "Please select an image for the advertisement."; if("D1_WRITE_READY_FAILED".equals(e))return "MY SHOP database write check failed: "+detail; if("NOTIFICATION_DB_WRITE_FAILED".equals(e))return "Notification database write failed: "+detail; if("NOTIFICATION_SCHEMA_FAILED".equals(e))return "Notification schema failed: "+detail; if("BANNER_DB_UPDATE_FAILED".equals(e))return "Banner save failed: "+detail; if("DAILY_POST_LIMIT".equals(e))return "আজকের ১টি পোস্ট ইতিমধ্যে করা হয়েছে। আগামীকাল আবার পোস্ট করতে পারবেন।"; if("USER_VIDEO_LOCKED".equals(e))return "User Video upload আপাতত Locked. Admin-এর জন্য Video খোলা আছে."; if("FILE_REQUIRED".equals(e))return "No media file was received. Please choose the photo again."; if("POST_MEDIA_TYPE_MISMATCH".equals(e))return "Selected file type is not allowed for this post."; if("POST_CAPTION_REQUIRED".equals(e))return "Please add a caption before publishing the post."; if("USER_POST_TOO_LARGE".equals(e))return "User post image is too large (max 5 MB). Please choose a smaller image."; if("POST_DB_UPDATE_FAILED".equals(e))return "Post save failed safely; the uploaded media was not kept without a database record."; if("POST_NOT_FOUND".equals(e))return "This post is no longer available."; if("MODERATOR_REQUIRED".equals(e))return "Moderator permission is required."; if("SERVER_ERROR".equals(e))return detail.isEmpty()?"Server error ("+code+")":"Server error: "+detail; return e.isEmpty()?"Server error ("+code+")":e; }
}
