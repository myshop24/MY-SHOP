package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.*;
import org.json.JSONObject;

/** V-230 approved left profile/menu drawer. Profile shows name + immutable Permanent User ID + email; Admin taps route to per-folder Admin panels. */
public class UserMenuActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.WHITE,DARK=Color.rgb(24,35,86),BLUE=Color.rgb(35,91,255),PURPLE=Color.rgb(113,38,220),RED=Color.rgb(245,36,82),MUTED=Color.rgb(105,112,134);
    private ImageView avatar; private TextView name,id,email,notificationCount;

    @Override protected void onCreate(Bundle b){super.onCreate(b);build();configureDrawerWindow();loadProfile();loadUnread();}

    private void configureDrawerWindow(){Window w=getWindow();w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));WindowManager.LayoutParams p=w.getAttributes();p.width=(int)(getResources().getDisplayMetrics().widthPixels*0.90f);p.height=WindowManager.LayoutParams.MATCH_PARENT;p.gravity=Gravity.START;p.dimAmount=.42f;w.setAttributes(p);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}

    private void build(){
        LinearLayout root=col();root.setBackground(bg(BG,Color.rgb(232,234,241),22));root.setPadding(dp(14),dp(12),dp(14),dp(14));root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(dp(14),Math.max(dp(12),insets.getSystemWindowInsetTop()+dp(6)),dp(14),Math.max(dp(14),insets.getSystemWindowInsetBottom()+dp(8)));return insets;});
        LinearLayout brand=row();ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.myshop_icon);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);brand.addView(logo,lp(dp(62),dp(62)));LinearLayout words=col();words.setPadding(dp(8),dp(8),0,0);LinearLayout bw=row();bw.addView(txt("MY",18,DARK,true),lp(dp(38),dp(26)));bw.addView(txt("SHOP",18,Color.rgb(245,141,0),true),lp(dp(58),dp(26)));words.addView(bw,lp(dp(100),dp(28)));words.addView(txt("Shop • Social • Live • Earn",8,MUTED,false),lp(dp(155),dp(20)));brand.addView(words,weight(1,dp(62)));TextView close=txt("✕",22,DARK,true);close.setGravity(Gravity.CENTER);close.setOnClickListener(v->finish());brand.addView(close,lp(dp(44),dp(52)));root.addView(brand,lp(-1,dp(68)));

        LinearLayout profile=row();profile.setPadding(dp(8),dp(7),dp(8),dp(7));profile.setBackground(bg(Color.rgb(242,247,255),Color.TRANSPARENT,14));avatar=new ImageView(this);avatar.setImageResource(R.drawable.myshop_profile_avatar);avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);avatar.setBackground(bg(Color.WHITE,Color.rgb(225,228,238),30));avatar.setClipToOutline(true);profile.addView(avatar,lp(dp(58),dp(58)));LinearLayout info=col();info.setPadding(dp(10),0,0,0);name=txt("MY SHOP User",13,DARK,true);id=txt("User ID: 0100",9,MUTED,false);email=txt("",8,MUTED,false);info.addView(name,lp(-1,dp(21)));info.addView(id,lp(-1,dp(18)));info.addView(email,lp(-1,dp(18)));profile.addView(info,weight(1,dp(58)));if(SessionManager.isAdmin(this)){TextView badge=txt("♛  Admin",9,Color.rgb(70,45,0),true);badge.setGravity(Gravity.CENTER);badge.setBackground(bg(Color.rgb(255,205,74),Color.TRANSPARENT,14));profile.addView(badge,lp(dp(76),dp(36)));}TextView chevron=txt("›",22,DARK,true);chevron.setGravity(Gravity.CENTER);profile.addView(chevron,lp(dp(26),dp(50)));profile.setOnClickListener(v->startActivity(new Intent(this,AccountActivity.class)));root.addView(profile,top(lp(-1,dp(74)),6));

        ScrollView sv=new ScrollView(this);sv.setVerticalScrollBarEnabled(false);LinearLayout list=col();section(list,"MAIN");add(list,R.drawable.nav_home,"Home Dashboard",()->finish(),true,null);section(list,"CONTENT");add(list,R.drawable.dash_action_feed,"My Feed",()->open("MY FEED","my_feed"),false,"HOT");add(list,R.drawable.dash_action_live,"Live Streaming",()->open("LIVE STREAMING","live_now"),false,"LIVE");add(list,R.drawable.dash_feat_shop,"My Shop",()->open("MY SHOP","my_shop"),false,null);add(list,R.drawable.dash_feat_apps,"Categories",()->open("CATEGORIES","categories"),false,null);add(list,R.drawable.menu_booking,"Orders",()->open("ORDERS","orders"),false,null);add(list,R.drawable.dash_feat_shop,"Cart",()->open("CART","cart"),false,null);add(list,R.drawable.dash_feat_gallery,"Gallery",this::openGallery,false,null);add(list,R.drawable.dash_feat_movie,"External Media",()->open("EXTERNAL MEDIA","external_movie"),false,null);add(list,R.drawable.dash_feat_reward,"Earn & Reward",()->open("EARN & REWARD","earn_reward"),false,null);
        section(list,"ACCOUNT");addNotifications(list);add(list,R.drawable.menu_settings,"Settings",()->open("SETTINGS","settings"),false,null);if(SessionManager.isAdmin(this))add(list,R.drawable.feature_earn_selected,"Admin Panel",()->startActivity(new Intent(this,AdminHubActivity.class)),false,null);
        section(list,"SUPPORT");add(list,R.drawable.icon_support,"Customer Support",this::openSupport,false,null);add(list,R.drawable.feature_social_selected,"Social Links",()->open("SOCIAL LINKS","social_media"),false,null);add(list,R.drawable.feature_share_selected,"Share App",this::shareApp,false,null);add(list,R.drawable.menu_language,"Language",()->LanguageManager.showPicker(this,()->recreate()),false,code());add(list,R.drawable.icon_page,"About",()->open("ABOUT","about"),false,null);sv.addView(list,new ScrollView.LayoutParams(-1,-2));root.addView(sv,new LinearLayout.LayoutParams(-1,0,1f));
        TextView logout=txt("↪  Log Out",12,RED,true);logout.setGravity(Gravity.CENTER);logout.setBackground(bg(Color.rgb(255,236,243),Color.TRANSPARENT,12));logout.setOnClickListener(v->logout());root.addView(logout,top(lp(-1,dp(46)),6));setContentView(root);
    }

    private void section(LinearLayout list,String s){TextView t=txt(s,9,MUTED,true);t.setPadding(dp(2),dp(9),0,dp(3));list.addView(t,lp(-1,dp(30)));}
    private void add(LinearLayout list,int iconRes,String label,Runnable action,boolean active,String badgeText){
        LinearLayout r=row(); r.setPadding(dp(8),dp(4),dp(5),dp(4));
        r.setBackground(bg(active?Color.rgb(235,243,255):(("My Feed".equals(label)||"Live Streaming".equals(label))?Color.rgb(255,241,247):Color.TRANSPARENT),Color.TRANSPARENT,12));
        ImageView ic=new ImageView(this); ic.setImageResource(iconRes); ic.setScaleType(ImageView.ScaleType.CENTER_INSIDE); ic.setPadding(dp(3),dp(3),dp(3),dp(3)); r.addView(ic,lp(dp(48),dp(48)));
        TextView t=txt(label,13,DARK,active); t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(dp(9),0,0,0); r.addView(t,weight(1,dp(50)));
        if(badgeText!=null&&!badgeText.isEmpty()){TextView b=txt(badgeText,9.5f,Color.WHITE,true);b.setGravity(Gravity.CENTER);b.setBackground(bg("LIVE".equals(badgeText)?RED:PURPLE,Color.TRANSPARENT,12));r.addView(b,lp(dp(58),dp(30)));}
        TextView ch=txt("›",21,BLUE,true); ch.setGravity(Gravity.CENTER); r.addView(ch,lp(dp(30),dp(48)));
        r.setOnClickListener(v->action.run()); list.addView(r,lp(-1,dp(58)));
    }
    private void addNotifications(LinearLayout list){
        LinearLayout r=row(); r.setPadding(dp(8),dp(4),dp(5),dp(4));
        ImageView ic=new ImageView(this); ic.setImageResource(R.drawable.notification_bell); ic.setScaleType(ImageView.ScaleType.CENTER_INSIDE); ic.setPadding(dp(3),dp(3),dp(3),dp(3)); r.addView(ic,lp(dp(48),dp(48)));
        TextView t=txt("Notifications",13,DARK,false); t.setPadding(dp(9),0,0,0); t.setGravity(Gravity.CENTER_VERTICAL); r.addView(t,weight(1,dp(50)));
        notificationCount=txt("",9,Color.WHITE,true); notificationCount.setGravity(Gravity.CENTER); notificationCount.setBackground(bg(RED,Color.TRANSPARENT,18)); notificationCount.setVisibility(View.GONE); r.addView(notificationCount,lp(dp(40),dp(32)));
        TextView ch=txt("›",21,BLUE,true); ch.setGravity(Gravity.CENTER); r.addView(ch,lp(dp(30),dp(48)));
        r.setOnClickListener(v->startActivity(new Intent(this,NotificationActivity.class))); list.addView(r,lp(-1,dp(58)));
    }


    // Workflow compatibility labels preserved for safety guards: SOCIAL MEDIA | SHARE APP | CUSTOMER SUPPORT | HELP & SUPPORT | Search
    private void loadDynamicMenu(LinearLayout list){ /* V-230 approved static drawer; remote menu mutation intentionally disabled here. */ }
    private void addDynamic(LinearLayout list,String title,String target,String iconUrl){ /* compatibility hook */ }

    private void loadProfile(){String localName=SessionManager.getFullName(this);String localEmail=SessionManager.getEmail(this);applyProfile(localName,SessionManager.getUserId(this),localEmail,SessionManager.getAvatarUrl(this));String token=SessionManager.getToken(this);if(token==null||token.isEmpty())return;BackendClient.me(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){JSONObject u=d.optJSONObject("user");if(u==null)return;String n=u.optString("name",localName),e=u.optString("email",localEmail),m=u.optString("mobile","");String av=u.optString("avatarUrl","");SessionManager.saveProfile(UserMenuActivity.this,n,e,m,av,u.optString("bio",""));runOnUiThread(()->applyProfile(n,SessionManager.getUserId(UserMenuActivity.this),e,av));}public void onError(String m){}});}
    private void applyProfile(String n,String uid,String e,String av){if(n==null||n.trim().isEmpty())n="MY SHOP User";name.setText(n.trim());id.setText("User ID: "+formatId(uid));email.setText(e==null?"":e.trim());if(av!=null&&!av.trim().isEmpty())loadRemoteImage(avatar,av.trim());}
    private String formatId(String raw){String s=raw==null?"":raw.trim();if(s.isEmpty())return "0100";try{int n=Integer.parseInt(s);return String.format(java.util.Locale.US,"%04d",n);}catch(Exception ignored){return s;}}
    private void loadUnread(){String token=SessionManager.getToken(this);if(token==null||token.isEmpty())return;BackendClient.notifications(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){int n=d.optInt("unreadCount",0);runOnUiThread(()->{if(notificationCount==null)return;if(n<=0)notificationCount.setVisibility(View.GONE);else{notificationCount.setVisibility(View.VISIBLE);notificationCount.setText(n>99?"99+":String.valueOf(n));}});}public void onError(String m){}});}
    private void open(String title,String key){if(SessionManager.isAdmin(this)){openAdminFolder(title,key);return;}Intent i=new Intent(UserMenuActivity.this,FeatureActivity.class);i.putExtra("title",title);i.putExtra("feature_key",key);String url=FeatureRegistry.getUrl(this,key);if(FeatureRegistry.isSafeHttpUrl(url))i.putExtra("url",url);startActivity(i);}
    private void openGallery(){if(SessionManager.isAdmin(this)){openAdminFolder("GALLERY","gallery");return;}startActivity(new Intent(this,GalleryActivity.class));}
    private void openSupport(){if(SessionManager.isAdmin(this)){openAdminFolder("CUSTOMER SUPPORT","help_support");return;}Intent i=new Intent(UserMenuActivity.this,FeatureActivity.class);i.putExtra("title","CUSTOMER SUPPORT");i.putExtra("feature_key","help_support");startActivity(i);}
    private void shareApp(){if(SessionManager.isAdmin(this)){openAdminFolder("SHARE APP","share");return;}try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"MY SHOP");i.putExtra(Intent.EXTRA_TEXT,"MY SHOP — https://rapid-bush-62ea.myshopsatkania.workers.dev");startActivity(Intent.createChooser(i,"Share MY SHOP"));}catch(Exception e){Toast.makeText(this,"Share is not available.",Toast.LENGTH_SHORT).show();}}
    private void openAdminFolder(String title,String key){Intent i=new Intent(this,AdminFolderActivity.class);i.putExtra("title",title);i.putExtra("feature_key",key);i.putExtra("admin_context",true);startActivity(i);}
    private void logout(){String token=SessionManager.getToken(this);SessionManager.clear(this);Intent i=new Intent(this,LoginActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(i);if(token!=null&&!token.isEmpty())BackendClient.logout(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){}public void onError(String m){}});}
    private void loadRemoteImage(ImageView target,String url){new Thread(()->{try{java.net.HttpURLConnection c=(java.net.HttpURLConnection)new java.net.URL(url).openConnection();c.setConnectTimeout(4000);c.setReadTimeout(6000);try(java.io.InputStream in=c.getInputStream()){android.graphics.Bitmap bm=android.graphics.BitmapFactory.decodeStream(in);if(bm!=null)runOnUiThread(()->target.setImageBitmap(bm));}}catch(Exception ignored){}}).start();}
    private String code(){String l=LanguageManager.get(this);if(LanguageManager.EN.equals(l))return "EN";if(LanguageManager.HI.equals(l))return "HI";if(LanguageManager.AR.equals(l))return "AR";return "বাং";}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private TextView txt(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}private GradientDrawable bg(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;}private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}