package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import android.view.View;
import android.graphics.drawable.GradientDrawable;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;

/** V-230 generic six-slot advertising folder manager. Every module has its own 6 rotating ads and separate ADD / EDIT / DELETE / SAVE controls. */
public class DashboardAdsAdminActivity extends androidx.appcompat.app.AppCompatActivity {
    private final String[] BOXES={"startup_ad","live_now","my_feed","go_live","live_tv","my_shop","external_movie","gallery","social_media","earn_reward","share","chat","more_apps"};
    private LinearLayout list; private String box="live_now"; private int slot=1; private boolean fixedBox=false; private static final int PICK=9301;
    private final int BG=Color.rgb(248,249,253),DARK=Color.rgb(18,32,75),PURPLE=Color.rgb(91,38,214),BLUE=Color.rgb(46,47,190),PINK=Color.rgb(235,36,168),RED=Color.rgb(238,35,52),GREEN=Color.rgb(24,169,98);
    @Override protected void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)){finish();return;}build();load();}
    private void build(){
        LinearLayout root=col(); fixedBox=getIntent().hasExtra("box_key"); String requested=getIntent().getStringExtra("box_key"); if(requested!=null&&!requested.trim().isEmpty())box=requested.trim(); root.setPadding(dp(12),dp(12),dp(12),dp(18));root.setBackgroundColor(BG);
        LinearLayout h=row();Button back=button("‹",DARK,28);back.setOnClickListener(v->finish());h.addView(back,lp(dp(42),dp(44)));String title=getIntent().getStringExtra("box_title");if(title==null||title.trim().isEmpty())title=box.replace('_',' ').toUpperCase();h.addView(txt(title+" • ADS",DARK,20,true),weight(1,dp(44)));root.addView(h,lp(-1,dp(48)));
        TextView info=txt("প্রতি ফোল্ডারে সর্বোচ্চ ৬টি বিজ্ঞাপন। User side-এ ১→২→৩→৪→৫→৬ auto-scroll হবে।",Color.DKGRAY,10,false);info.setPadding(dp(8),dp(8),dp(8),dp(8));root.addView(info,lp(-1,dp(54)));
        if(!fixedBox){Spinner sp=new Spinner(this);String[] labels={"STARTUP AD • APP OPEN","LIVE NOW","MY FEED","GO LIVE","LIVE TV","MY SHOP","EXTERNAL MOVIE","GALLERY","SOCIAL MEDIA","EARN & REWARD","SHARE","CHAT","MORE APPS"};sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,labels));sp.setSelection(0);sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){box=BOXES[pos];load();}});root.addView(sp,lp(-1,dp(52)));}
        list=col();ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(list);root.addView(sv,lp(-1,0,1));root.addView(action("BACK",DARK,()->finish()),lp(-1,dp(46)));setContentView(root);
    }
    private void load(){if(list==null)return;BackendClient.adminAds(SessionManager.getToken(this),box,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->render(d.optJSONArray("ads")));}public void onError(String m){runOnUiThread(()->{render(null);toast("Ad folder load failed: "+m);});}});}
    private void render(JSONArray a){list.removeAllViews();JSONObject[] slots=new JSONObject[6];if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null){int s=x.optInt("slot",0);if(s>=1&&s<=6)slots[s-1]=x;}}for(int i=0;i<6;i++)slotCard(i+1,slots[i]);}
    private void slotCard(int s,JSONObject x){
        boolean saved=x!=null;
        LinearLayout c=col();c.setPadding(dp(10),dp(10),dp(10),dp(10));c.setBackground(bg(Color.WHITE,Color.rgb(224,226,235),12));c.setElevation(dp(1));
        c.addView(txt("BANNER "+s+(saved?"  •  SAVED":"  •  EMPTY"),DARK,14,true),lp(-1,dp(28)));
        c.addView(txt(saved?"এই slot saved আছে। ADD/CHANGE, EDIT, DELETE, SAVE আলাদা control.":"এই slot খালি। + ADD দিয়ে banner/media বাছুন।",Color.DKGRAY,10,false),lp(-1,dp(36)));
        EditText cap=field("Caption",saved?x.optString("caption",""):"");c.addView(cap,lp(-1,dp(48)));
        EditText target=field("Optional target link",saved?x.optString("target_url",""):"");c.addView(target,lp(-1,dp(48)));
        EditText duration=field("Display seconds (1-60)",saved?String.valueOf(x.optInt("duration_sec",3)):"3");c.addView(duration,lp(-1,dp(48)));

        LinearLayout r1=row();
        TextView add=action(saved?"＋ ADD / CHANGE":"＋ ADD",PURPLE); add.setOnClickListener(v->{boxSlot=box;slot=s;pick();});r1.addView(add,wt(1));r1.addView(gap(),lp(dp(5),1));
        TextView edit=action("✎ EDIT",BLUE); edit.setOnClickListener(v->{if(!saved){toast("Add a banner first.");return;}editAd(x);});r1.addView(edit,wt(1));c.addView(r1,lp(-1,dp(44)));

        LinearLayout r2=row();
        TextView del=action("⌫ DELETE",RED); del.setAlpha(saved?1f:.45f);del.setOnClickListener(v->{if(!saved){toast("Already empty");return;}new AlertDialog.Builder(this).setTitle("Delete banner?").setMessage("Only this folder slot will be removed.").setPositiveButton("DELETE",(d,w)->BackendClient.adminAdDelete(SessionManager.getToken(this),x.optLong("id"),new BackendClient.Callback(){public void onSuccess(JSONObject d){toast("✓ Deleted");load();}public void onError(String m){toast(m);}})).setNegativeButton("CANCEL",null).show();});r2.addView(del,wt(1));r2.addView(gap(),lp(dp(5),1));
        TextView save=action("✓ SAVE",GREEN); save.setOnClickListener(v->{if(saved)BackendClient.adminAdUpdate(SessionManager.getToken(this),x.optLong("id"),cap.getText().toString().trim(),target.getText().toString().trim(),true,parseDuration(duration.getText().toString()),new BackendClient.Callback(){public void onSuccess(JSONObject d){toast("✓ Saved");load();}public void onError(String m){toast(m);}});else{boxSlot=box;slot=s;pick();}});r2.addView(save,wt(1));c.addView(r2,top(lp(-1,dp(44)),6));
        list.addView(c,lp(-1,-2));Space sp=new Space(this);list.addView(sp,lp(1,dp(8)));
    }

    private void editAd(JSONObject x){
        LinearLayout b=col(); EditText cap=field("Caption",x.optString("caption","")); EditText target=field("Optional target link",x.optString("target_url","")); EditText duration=field("Display seconds (1-60)",String.valueOf(x.optInt("duration_sec",3)));b.addView(cap,lp(-1,dp(48)));b.addView(target,lp(-1,dp(48)));b.addView(duration,lp(-1,dp(48)));
        new AlertDialog.Builder(this).setTitle("EDIT BANNER").setView(b).setPositiveButton("SAVE",(d,w)->BackendClient.adminAdUpdate(SessionManager.getToken(this),x.optLong("id"),cap.getText().toString().trim(),target.getText().toString().trim(),true,parseDuration(duration.getText().toString()),new BackendClient.Callback(){public void onSuccess(JSONObject d){toast("✓ Edited + saved");load();}public void onError(String m){toast("Edit failed: "+m);}})).setNegativeButton("CANCEL",null).show();
    }
    private String boxSlot="live_now";
    private void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","video/*"});i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r!=PICK||c!=RESULT_OK||d==null||d.getData()==null)return;Uri u=d.getData();try{InputStream in=getContentResolver().openInputStream(u);String mime=getContentResolver().getType(u);showUpload(u,in,mime==null?"application/octet-stream":mime);}catch(Exception e){toast("Cannot open image/video.");}}
    private void showUpload(Uri u,InputStream in,String mime){LinearLayout b=col();EditText cap=field("Caption");EditText target=field("Optional target link");EditText duration=field("Display seconds (1-60)","3");b.addView(cap,lp(-1,dp(48)));b.addView(target,lp(-1,dp(48)));b.addView(duration,lp(-1,dp(48)));new AlertDialog.Builder(this).setTitle("Upload Image / Video Ad • "+boxSlot+" • Slot "+slot).setView(b).setNegativeButton("CANCEL",null).setPositiveButton("UPLOAD",(d,w)->BackendClient.adminAdUpload(SessionManager.getToken(this),in,fileNameForMime(mime),mime,boxSlot,slot,cap.getText().toString().trim(),target.getText().toString().trim(),parseDuration(duration.getText().toString()),new BackendClient.Callback(){public void onSuccess(JSONObject x){toast("✓ Advertisement saved");load();}public void onError(String m){toast("Upload failed: "+m);}})).show();}
    private String fileNameForMime(String mime){String m=mime==null?"":mime.toLowerCase();if(m.contains("mp4"))return "startup-ad.mp4";if(m.contains("webm"))return "startup-ad.webm";if(m.contains("png"))return "startup-ad.png";if(m.contains("webp"))return "startup-ad.webp";return m.startsWith("video/")?"startup-ad.mp4":"startup-ad.jpg";}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private Button button(String s,int c,float z){Button b=new Button(this);b.setText(s);b.setTextColor(c);b.setTextSize(z);b.setBackgroundColor(Color.TRANSPARENT);b.setPadding(0,0,0,0);return b;}private TextView txt(String s,int c,float z,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}private TextView action(String s,int c,Runnable r){TextView t=txt(s,Color.WHITE,10,true);t.setGravity(Gravity.CENTER);t.setBackground(bg(c,c,7));t.setOnClickListener(v->r.run());return t;}private TextView action(String s,int c){TextView t=txt(s,Color.WHITE,10,true);t.setGravity(Gravity.CENTER);t.setBackground(bg(c,c,7));return t;}private EditText field(String h,String v){EditText e=field(h);e.setText(v);return e;}private EditText field(String h){EditText e=new EditText(this);e.setHint(h);e.setSingleLine(true);e.setTextSize(12);e.setPadding(dp(10),0,dp(10),0);e.setBackground(bg(Color.WHITE,Color.rgb(215,218,228),7));return e;}private LinearLayout card(){LinearLayout c=col();c.setPadding(dp(10),dp(8),dp(10),dp(8));return c;}private GradientDrawable bg(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams lp(int w,int h,float wt){return new LinearLayout.LayoutParams(w,h,wt);}private LinearLayout.LayoutParams wt(float w){return new LinearLayout.LayoutParams(0,dp(44),w);}private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}private View gap(){return new View(this);}private int parseDuration(String s){try{return Math.max(1,Math.min(60,Integer.parseInt(s.trim())));}catch(Exception e){return 3;}}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}
}
