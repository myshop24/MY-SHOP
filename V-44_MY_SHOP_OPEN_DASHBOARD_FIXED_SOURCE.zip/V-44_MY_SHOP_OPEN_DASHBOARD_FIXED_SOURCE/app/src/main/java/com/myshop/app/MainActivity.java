package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * V-44: stable, self-contained Home Dashboard.
 * The dashboard is built without optional remote/config dependencies so a startup
 * failure in a secondary feature cannot leave the user on a black screen.
 */
public class MainActivity extends AppCompatActivity {
    private static final int BLUE = Color.rgb(28, 48, 180);
    private static final int DARK = Color.rgb(10, 35, 90);
    private static final int WHITE = Color.WHITE;
    private static final int BG = Color.rgb(246, 247, 251);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(buildDashboard());
        } catch (Throwable t) {
            // Last-resort screen: never leave MainActivity blank/black.
            setContentView(buildSafeHome());
        }
    }

    private View buildDashboard() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(BG);

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(14, 14, 14, 90);

        // Top menu/search/notification row.
        LinearLayout top = row();
        Button menu = button("☰", 52, 52);
        EditText search = new EditText(this);
        search.setHint("Search for products, live, users, posts...");
        search.setSingleLine(true);
        Button notification = button("🔔", 52, 52);
        Button more = button("⋮", 52, 52);
        top.addView(menu, lp(52, 52));
        top.addView(search, weightLp(1, 52));
        top.addView(notification, lp(52, 52));
        top.addView(more, lp(52, 52));
        content.addView(top);

        // Advertisement strip.
        LinearLayout ads = row();
        ads.addView(card("MEGA SALE\nUP TO 50% OFF\nSHOP NOW", BLUE), weightLp(1, 175));
        ads.addView(card("FASHION\nNEW ARRIVAL\nSHOP NOW", Color.rgb(210, 80, 25)), weightLp(1, 175));
        content.addView(ads, lp(-1, 185));
        TextView dots = text("●   ○   ○   ○   ○", 18, BLUE, Gravity.CENTER);
        content.addView(dots, lp(-1, 35));

        content.addView(card("Welcome to MY SHOP\nসর্বকিছু এক অ্যাপেই ❤️", Color.rgb(35, 42, 210)), lp(-1, 145));

        LinearLayout offers = row();
        offers.addView(card("SUMMER COLLECTION\nNEW ARRIVAL", Color.rgb(25, 100, 225)), weightLp(1, 105));
        offers.addView(card("EXCLUSIVE DEAL\n25% OFF", Color.rgb(30, 155, 70)), weightLp(1, 105));
        offers.addView(card("BEAUTY CARE\n20% OFF", Color.rgb(220, 35, 125)), weightLp(1, 105));
        content.addView(offers, lp(-1, 115));

        content.addView(card("🔴  BREAKING NEWS   |   বাংলাদেশে আজ স্বর্ণের দাম আবার কমলো", WHITE, Color.DKGRAY), lp(-1, 60));
        TextView liveTitle = text("🔴 লাইভ এখন চলছে                              সব দেখুন ›", 17, Color.DKGRAY, Gravity.CENTER_VERTICAL);
        content.addView(liveTitle, lp(-1, 48));

        LinearLayout lives = row();
        lives.addView(liveCard("1\n🔴 LIVE\nCute Girl Live\n@user1"), weightLp(1, 150));
        lives.addView(liveCard("2\n🔴 LIVE\nMusic Live\n@user2"), weightLp(1, 150));
        lives.addView(liveCard("3\n🔴 LIVE\nGaming Live\n@user3"), weightLp(1, 150));
        lives.addView(liveCard("4\n🔴 LIVE\nTalk & Fun\n@user4"), weightLp(1, 150));
        content.addView(lives, lp(-1, 160));

        LinearLayout liveActions = row();
        Button live = button("📡 LIVE\nলাইভ দেখুন", 0, 100);
        Button goLive = button("🎥 GO LIVE\nনিজে লাইভ যান", 0, 100);
        Button feed = button("My Feed\nআপনার ফিড দেখুন", 0, 100);
        liveActions.addView(live, weightLp(1, 100));
        liveActions.addView(goLive, weightLp(1, 100));
        liveActions.addView(feed, weightLp(1, 100));
        content.addView(liveActions);

        LinearLayout grid1 = row();
        grid1.addView(feature("🛒", "MY SHOP\nঅনলাইনে শপিং করুন", "my_shop"), weightLp(1, 95));
        grid1.addView(feature("🖼️", "GALLERY\nফটো, অডিও, ভিডিও", "gallery"), weightLp(1, 95));
        grid1.addView(feature("🎬", "EXTERNAL MOVIE\nমুভি ও ভিডিও", "external_movie"), weightLp(1, 95));
        grid1.addView(feature("📺", "LIVE TV\nলাইভ টিভি দেখুন", "live_tv"), weightLp(1, 95));
        content.addView(grid1);

        LinearLayout grid2 = row();
        grid2.addView(feature("📱", "SOCIAL MEDIA\nসব সোশ্যাল মিডিয়া", "social_media"), weightLp(1, 95));
        grid2.addView(feature("🎁", "EARN & REWARD\nরিওয়ার্ড, গিফট", "earn_reward"), weightLp(1, 95));
        grid2.addView(feature("🔗", "SHARE\nশেয়ার করুন", "share"), weightLp(1, 95));
        grid2.addView(feature("▦", "MORE APPS\nআরও অ্যাপস দেখুন", "more_apps"), weightLp(1, 95));
        content.addView(grid2);

        scroll.addView(content);
        page.addView(scroll, lp(-1, 0, 1));

        LinearLayout nav = row();
        nav.setBackgroundColor(WHITE);
        Button home = button("🏠\nHome", 0, 72);
        Button store = button("🛍️\nStore", 0, 72);
        Button liveNav = button("🔴\nLive", 0, 72);
        Button chat = button("💬\nChat", 0, 72);
        Button profile = button("👤\nProfile", 0, 72);
        nav.addView(home, weightLp(1, 72));
        nav.addView(store, weightLp(1, 72));
        nav.addView(liveNav, weightLp(1, 72));
        nav.addView(chat, weightLp(1, 72));
        nav.addView(profile, weightLp(1, 72));
        page.addView(nav, lp(-1, 72));

        menu.setOnClickListener(v -> showMenu());
        more.setOnClickListener(v -> showMenu());
        notification.setOnClickListener(v -> android.widget.Toast.makeText(this, "No new notifications.", android.widget.Toast.LENGTH_SHORT).show());
        live.setOnClickListener(v -> openFeature("LIVE", "live_now"));
        goLive.setOnClickListener(v -> openFeature("GO LIVE", "go_live"));
        feed.setOnClickListener(v -> openFeature("MY FEED", "my_feed"));
        home.setOnClickListener(v -> scrollToTop(scroll));
        store.setOnClickListener(v -> openFeature("MY SHOP", "my_shop"));
        liveNav.setOnClickListener(v -> openFeature("LIVE", "live_now"));
        chat.setOnClickListener(v -> openFeature("CHAT", "chat"));
        profile.setOnClickListener(v -> startActivity(new Intent(this, AccountActivity.class)));
        return page;
    }

    private void scrollToTop(ScrollView s) { s.post(() -> s.fullScroll(View.FOCUS_UP)); }

    private Button feature(String icon, String label, String key) {
        Button b = button(icon + "\n" + label, 0, 95);
        b.setOnClickListener(v -> openFeature(label, key));
        return b;
    }

    private TextView liveCard(String value) { return card(value, DARK, WHITE); }

    private void openFeature(String title, String key) {
        Intent i = new Intent(this, FeatureActivity.class);
        i.putExtra("title", title);
        i.putExtra("feature_key", key);
        startActivity(i);
    }

    private void showMenu() {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("MY SHOP Menu")
                .setItems(new String[]{"👤 Profile", "⚙️ Settings", "🚪 Logout"}, (d, which) -> {
                    if (which == 0) startActivity(new Intent(this, AccountActivity.class));
                    else if (which == 2) { SessionManager.clear(this); startActivity(new Intent(this, LoginActivity.class)); finish(); }
                }).show();
    }

    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }

    private Button button(String s, int w, int h) { Button b = new Button(this); b.setText(s); b.setTextSize(14); b.setAllCaps(false); return b; }

    private TextView text(String s, float size, int color, int gravity) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(gravity); t.setTypeface(null, Typeface.BOLD); t.setPadding(8, 6, 8, 6); return t; }

    private TextView card(String s, int bg) { return card(s, bg, WHITE); }
    private TextView card(String s, int bg, int fg) { TextView t = text(s, 18, fg, Gravity.CENTER); t.setBackgroundColor(bg); t.setPadding(12, 12, 12, 12); return t; }

    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private LinearLayout.LayoutParams lp(int w, int h, float weight) { return new LinearLayout.LayoutParams(w, h, weight); }
    private LinearLayout.LayoutParams weightLp(float weight, int h) { return new LinearLayout.LayoutParams(0, h, weight); }

    private View buildSafeHome() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setBackgroundColor(WHITE);
        TextView t = text("MY SHOP\nHome Dashboard", 26, BLUE, Gravity.CENTER); root.addView(t, lp(-1, -2));
        Button retry = button("OPEN DASHBOARD", -1, 60); retry.setOnClickListener(v -> recreate()); root.addView(retry, lp(-1, 60));
        return root;
    }
}
