Current V627 / 2.9.627: scoped V626 Java overlay compiler fix. Read MY-SHOP-DEVELOPER-HANDOFF.md and GITHUB-UPLOAD-V627-BN.md first. No bundled APK; full Android/device acceptance pending. V626 unfinished feature work remains unfinished. Next changed delivery V628. Latest owner instructions override historical notes below.

V626 PARTIAL CHECKPOINT: read MY-SHOP-DEVELOPER-HANDOFF.md and GITHUB-UPLOAD-V626-BN.md first. Do not upload incomplete checkpoint to production main; historical deployment instructions below are not current release authorization.

# MY SHOP V-623 /2.9.623 — full source APK build package

Continue exact delivered V622 source; no restart. V623 adds the owner's Master Commission panel and repairs the V622 GiftPanel613 static-context build failure. Prior V622 features and its pending premium gift work are retained.

For https://github.com/myshop24/MY-SHOP upload ONLY the versioned ZIP at repository ROOT. Do not extract and replace the running root pipeline. Read GITHUB_UPLOAD.md, MY-SHOP-DEVELOPER-HANDOFF.md, DEVELOPER-POLICY-BN.md and SIGNING-SETUP.md.

Includes full source, assets/generation inputs, scripts, Gradle wrapper, direct-source workflow, tests and snapshots of the existing ZIP-based repository workflow/release script. Generated GIF/WAV assets restore through tools/prepare-build-assets.sh before every Android build. Never change the original signing identity/Secrets.

Run bash tools/v623_verify.sh for inherited plus current target QA; the new financial target guards also run in Gradle preBuild when the current root pipeline compiles the extracted ZIP. A source package does not itself prove a signed APK release or real-phone acceptance.
