# MY SHOP V627 / 2.9.627 — V626 Java build correction

Date: 2026-10-15. Continue this source. Next changed delivery V628.
Full project source package; NOT a completed 1–10 feature release. No APK is bundled.

## Fixed failure and exact scope
Owner supplied screenshots of failed Actions run #689 (38758545640), commit 36b67d2564a2056977ed8eefe9ff885d4c8d39f4. GitHub job metadata confirms failure in the deploy/build step and skipped artifact upload. Screenshot compiler diagnostic: AudioLiveRoomActivity.java:1816, incompatible types: View cannot be converted to FrameLayout.
`activeGiftOverlay` is assigned only the FrameLayout created by showGiftEffectNow. Change its declaration from View to FrameLayout, matching addGiftParticles. No unsafe cast, no removed particle call, no change to animation/UI/RTC behavior. The entire AudioLiveRoomActivity diff against the verified V626 archive is exactly this one declaration.
Android versionCode627/versionName2.9.627, SOURCE_BUILD_ID and Worker health identity agree. Original package/signing identity, backend bindings and all baseline assets retained. Existing V626 logic is retained; unfinished features are not silently declared finished.

## Tests / limits
- tests/v627-gift-overlay-compile.spec.py compiles/runs actual shipped field and dispatch with UI doubles: active combo count, 100+ particles, queued combo update, independent combo and null overlay. Negative control restores View and must reproduce the same compiler error.
- PreBuild runs this new guard plus existing V626 checks. Full results: verification/V627-RESULTS.md and V627-LOCAL-CHECKS.log.
- All V626 baseline entries and original assets retained; see V627-PRESERVATION.json.
- Full Android symbol build and signed APK are NOT verified here: no local Android SDK/cached Gradle8.11.1; Gradle distribution network request timed out. No GitHub build was started by this task. No APK from another version substituted.
- V626 local generated-avatar reproducibility issue remains an environment-specific open item; hash checks have NOT been weakened. See V627-ASSET-CHECK.log. The owner's run reached Java compilation, so that run's first shown fatal error is the overlay type failure.

## GitHub APK build and setup
Read GITHUB-UPLOAD-V627-BN.md. The included .github/workflows/my-shop-apk.yml is a build-only workflow with exact github.sha checkout, latest-source identity checks, original certificate verification, clean Gradle test/assemble/lint and one downloadable canonical APK artifact. It never deploys Worker/D1.
The currently observed repository main pipeline deploys Worker before APK. Uploading only a ZIP leaves that external workflow in charge. For build-only QA replace the root workflow with the included workflow BEFORE uploading/running V627, or use an isolated build repository with the same authorized original signing setup. This task made no remote changes or production deployment.
Use original my-shop-release-signing-v1 key/cache or MYSHOP_KEYSTORE_BASE64 / existing encrypted-key setup. Required original secrets: MYSHOP_KEYSTORE_PASSWORD, MYSHOP_KEY_ALIAS, MYSHOP_KEY_PASSWORD. Firebase MYSHOP_FIREBASE_* per SIGNING-SETUP.md. Never regenerate the release key or paste credentials into source/logs.
Build tools: JDK17, Node22+, Python3.12 with tools/requirements-build-assets.txt, ffmpeg/DejaVu, Android SDK/build-tools36, Gradle8.11.1. Run bash tools/ci-apk-build.sh in configured build-only environment.
After success download MY-SHOP-V-627-APK -> MY_SHOP_FINAL_RELEASE.apk. Verify exact run SHA, V627/2.9.627/package com.myshop.app, original certificate, provenance, timestamp, size and SHA256. Green build alone is insufficient.

## Remaining approved work
V626 tasks 1–10 remain partly implemented. Follow handoffs/MY-SHOP-V626-HANDOFF.md: general automatic5–8digit migration; Rare ID concurrency/suggestions; exact reference/My Level/badge/catalog/Join/GiftPanel phone QA; real RTC/audio/realtime/push/payment checks; generated asset toolchain reproduction; signed Android build/device acceptance. Prior levels preserved; office double cancelled; 100000Coin or1000Diamond shared point rule; lower Send unchanged. No unrelated cleanup/feature changes in V627.
