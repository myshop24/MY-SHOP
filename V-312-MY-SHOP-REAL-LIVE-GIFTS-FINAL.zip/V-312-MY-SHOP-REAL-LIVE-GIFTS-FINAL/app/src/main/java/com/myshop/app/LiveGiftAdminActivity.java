package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;

/** V-293 Admin-controlled Live Gift catalog. */
public class LiveGiftAdminActivity extends androidx.appcompat.app.AppCompatActivity {
    private static final int PICK_ANIM=9301, PICK_SOUND=9302, PICK_PREVIEW=9303;
    private EditText name,price,preview,animation,sound,volume,order;
    private Spinner currency,size;
    private CheckBox enabled,animOn,soundOn;
    private LinearLayout list;
    private TextView uploadState;
    private long editId=0;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        if(!SessionManager.isAdmin(this)){finish();return;}
        build(); load();
    }
    private void build(){
        ScrollView sv=new ScrollView(this); LinearLayout root=col();
        root.setPadding(dp(14),dp(14),dp(14),dp(30)); root.setBackgroundColor(Color.rgb(246,248,252));
        root.addView(txt("লাইভ গিফট ম্যানেজার",21,true));
        root.addView(txt("৫০ কয়েন + ৫০ গোল্ড কয়েন • যোগ/সম্পাদনা/মুছুন/সংরক্ষণ • প্রতিটি গিফটের অ্যানিমেশন/সাউন্ড/ভলিউম/সাইজ",10,false));
        name=e("গিফটের নাম"); price=e("গিফটের মূল্য"); preview=e("প্রিভিউ URL (ঐচ্ছিক)"); animation=e("অ্যানিমেশন URL"); sound=e("সাউন্ড URL"); volume=e("সাউন্ড ভলিউম ০–১০০"); volume.setText("70"); order=e("দেখানোর ক্রম"); order.setText("100");
        currency=new Spinner(this); currency.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"COIN","GOLD"}));
        size=new Spinner(this); size.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"SMALL","MEDIUM","LARGE","FULL_SCREEN"})); size.setSelection(1);
        root.addView(name);root.addView(currency);root.addView(price);root.addView(preview);root.addView(animation);root.addView(sound);root.addView(volume);root.addView(size);root.addView(order);
        enabled=check("গিফট চালু / প্রকাশিত",true); animOn=check("এনিমেশন চালু",true); soundOn=check("সাউন্ড চালু",true);root.addView(enabled);root.addView(animOn);root.addView(soundOn);
        LinearLayout up=row();Button ui=button("ছবি আপলোড");ui.setOnClickListener(v->pick(PICK_PREVIEW));Button ua=button("এনিমেশন আপলোড");ua.setOnClickListener(v->pick(PICK_ANIM));Button us=button("সাউন্ড আপলোড");us.setOnClickListener(v->pick(PICK_SOUND));up.addView(ui,wt());up.addView(ua,wt());up.addView(us,wt());root.addView(up);
        uploadState=txt("কোনো আপলোড চলছে না",9,false);root.addView(uploadState);
        Button save=button("💾 সংরক্ষণ / প্রকাশ");save.setOnClickListener(v->save());root.addView(save);
        Button fresh=button("➕ নতুন গিফট যোগ করুন");fresh.setOnClickListener(v->clear());root.addView(fresh);
        root.addView(txt("প্রকাশিত / খসড়া গিফট",16,true)); list=col();root.addView(list);sv.addView(root);setContentView(sv);
    }
    private void load(){BackendClient.adminLiveGifts(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->render(o.optJSONArray("gifts")));}public void onError(String m){toast(m);}});}
    private void render(JSONArray a){list.removeAllViews();if(a==null)return;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;LinearLayout c=col();c.setPadding(dp(8),dp(8),dp(8),dp(8));c.setBackgroundColor(Color.WHITE);c.addView(txt((x.optInt("enabled",1)==1?"● ":"○ ")+x.optString("name","Gift")+" • "+x.optString("currency")+" "+x.optInt("price",1),12,true));c.addView(txt("Animation "+(x.optInt("animation_enabled",1)==1?"ON":"OFF")+" • Sound "+(x.optInt("sound_enabled",1)==1?"ON":"OFF")+" • Vol "+x.optInt("sound_volume",70)+" • "+x.optString("size_mode","MEDIUM"),9,false));LinearLayout actions=row();Button ed=button("✏ সম্পাদনা");ed.setOnClickListener(v->fill(x));Button del=button("🗑 মুছুন");del.setBackgroundColor(Color.rgb(190,45,68));del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("গিফট মুছবেন?").setPositiveButton("মুছুন",(d,w)->BackendClient.adminLiveGiftDelete(SessionManager.getToken(this),x.optLong("id"),new BackendClient.Callback(){public void onSuccess(JSONObject o){load();}public void onError(String m){toast(m);}})).setNegativeButton("বাতিল",null).show());actions.addView(ed,wt());actions.addView(del,wt());c.addView(actions);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(7);list.addView(c,p);}}
    private void fill(JSONObject x){editId=x.optLong("id");name.setText(x.optString("name"));price.setText(String.valueOf(x.optInt("price",1)));preview.setText(x.optString("preview_url"));animation.setText(x.optString("animation_url"));sound.setText(x.optString("sound_url"));volume.setText(String.valueOf(x.optInt("sound_volume",70)));order.setText(String.valueOf(x.optInt("sort_order",100)));enabled.setChecked(x.optInt("enabled",1)==1);animOn.setChecked(x.optInt("animation_enabled",1)==1);soundOn.setChecked(x.optInt("sound_enabled",1)==1);select(currency,x.optString("currency","COIN"));select(size,x.optString("size_mode","MEDIUM"));}
    private void save(){try{JSONObject x=new JSONObject().put("id",editId).put("name",name.getText().toString()).put("currency",currency.getSelectedItem().toString()).put("price",num(price,1)).put("previewUrl",preview.getText().toString()).put("animationUrl",animation.getText().toString()).put("soundUrl",sound.getText().toString()).put("soundVolume",num(volume,70)).put("sizeMode",size.getSelectedItem().toString()).put("sortOrder",num(order,100)).put("enabled",enabled.isChecked()).put("animationEnabled",animOn.isChecked()).put("soundEnabled",soundOn.isChecked());BackendClient.adminLiveGiftSave(SessionManager.getToken(this),x,new BackendClient.Callback(){public void onSuccess(JSONObject o){editId=o.optLong("id",editId);toast("গিফট সংরক্ষণ হয়েছে");load();}public void onError(String m){toast(m);}});}catch(Exception e){toast("গিফটের ঘরগুলো যাচাই করুন");}}
    private void pick(int code){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,code);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(c!=RESULT_OK||d==null||d.getData()==null)return;Uri u=d.getData();try{String mime=getContentResolver().getType(u),fn="gift_asset";android.database.Cursor q=getContentResolver().query(u,null,null,null,null);if(q!=null){int n=q.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(q.moveToFirst()&&n>=0)fn=q.getString(n);q.close();}InputStream in=getContentResolver().openInputStream(u);uploadState.setText("আপলোড হচ্ছে…");final boolean snd=r==PICK_SOUND, prv=r==PICK_PREVIEW;BackendClient.adminLiveGiftAssetUpload(SessionManager.getToken(this),in,fn,mime,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{if(snd)sound.setText(o.optString("url"));else if(prv)preview.setText(o.optString("url"));else animation.setText(o.optString("url"));uploadState.setText("আপলোড হয়েছে • "+o.optString("mediaType"));});}public void onError(String m){toast(m);}});}catch(Exception e){toast("ফাইলটি পড়া যায়নি");}}
    private void clear(){editId=0;name.setText("");price.setText("");preview.setText("");animation.setText("");sound.setText("");volume.setText("70");order.setText("100");enabled.setChecked(true);animOn.setChecked(true);soundOn.setChecked(true);currency.setSelection(0);size.setSelection(1);}
    private void select(Spinner s,String v){for(int i=0;i<s.getCount();i++)if(v.equals(s.getItemAtPosition(i).toString()))s.setSelection(i);}private int num(EditText e,int d){try{return Integer.parseInt(e.getText().toString().trim());}catch(Exception x){return d;}}private CheckBox check(String s,boolean on){CheckBox c=new CheckBox(this);c.setText(s);c.setChecked(on);return c;}private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(Color.rgb(91,58,218));g.setCornerRadius(dp(14));b.setBackground(g);return b;}private EditText e(String h){EditText x=new EditText(this);x.setHint(h);x.setPadding(dp(8),0,dp(8),0);return x;}private TextView txt(String s,float z,boolean b){TextView x=new TextView(this);x.setText(s);x.setTextSize(z);x.setTextColor(Color.rgb(22,28,55));if(b)x.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);x.setPadding(0,dp(5),0,dp(5));return x;}private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}private LinearLayout.LayoutParams wt(){return new LinearLayout.LayoutParams(0,-2,1);}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}
}
