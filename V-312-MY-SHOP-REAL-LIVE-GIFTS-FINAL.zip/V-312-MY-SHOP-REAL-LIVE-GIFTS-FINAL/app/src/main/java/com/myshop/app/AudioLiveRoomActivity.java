package com.myshop.app;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.TimeZone;

/**
 * MY SHOP V-304 Premium Audio Live Room with light right-action spacing and bottom safe-area protection.
 * V-305 visual host separation: Host is rendered in the dedicated top Host area; the existing 12-seat 6+6 board is preserved unchanged.
 * The bundled Guitar Blue wallpaper is the safe default while Admin themes
 * can override it remotely without changing the Dashboard.
 */
public class AudioLiveRoomActivity extends AppCompatActivity {
    private final Handler handler = new Handler();
    private boolean host;
    private boolean hostStarted;
    private volatile boolean endLiveInProgress = false;
    private volatile boolean roomEnded = false;
    private boolean localMicOn = true;
    private boolean roomAdmin = false;
    private boolean listenOnly = false;
    private String hostId;
    private String specialGuestId = "";
    private String myRole = "AUDIENCE";
    private long startedAtMs = 0L;
    private String activeSessionId = "";
    private long serverElapsedSec = 0L;
    private long serverElapsedSyncMs = 0L;
    private boolean endedSummaryShown = false;
    private boolean commentSending = false;
    private final Map<String,String> pendingComments = new LinkedHashMap<>();
    private final Set<String> shownMilestones = new HashSet<>();
    private long lastEntryEventId = 0L;
    private int shareCount = 0;
    private long reactCount = 0L;
    private ImageView wallpaper;
    private LinearLayout hostArea, audienceRow, specialArea, seats, requests, commentsList;
    private TextView viewers, status, syncState, durationView, roomTitle, roomTopic, pinnedView, shareView, reactView, premiumStrip, welcomeView, productView, pkView;
    private Button sendButton;
    private String currentLiveName = "Host";
    private final Set<Integer> lockedSeats = new HashSet<>();
    private JSONArray currentViewerProfiles = new JSONArray();
    private JSONArray currentRequests = new JSONArray();
    private int currentViewerCount = 0;
    private String lastInviteNotice = "";
    private String lastRequestNotice = "";
    private boolean inviteDialogOpen = false;
    private boolean requestDialogOpen = false;
    private int highlightPrice = 1000;
    private boolean highlightSelected = false;
    private long lastHighlightId = 0L;
    private TextView micButton;
    private LinearLayout requestNoticeBar;
    private JSONObject cachedGiftCatalog;
    private AlertDialog giftLoadingDialog;
    private volatile boolean localSpeaking = false;
    private volatile boolean voiceMonitorRunning = false;
    private android.media.AudioRecord voiceRecorder;
    private Thread voiceThread;
    private long lastVoiceAboveMs = 0L;
    private boolean micPermissionAsked = false;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (roomEnded || endLiveInProgress) return;
            if (hostStarted || !host) {
                if (host) BackendClient.setLivePresence(token(), true, new Silent());
                else BackendClient.liveViewer(token(), hostId, true, new Silent());
                if (host || "SPEAKER".equals(myRole)) {
                    BackendClient.liveParticipantState(token(), hostId, localMicOn, localSpeaking, networkQuality(), new Silent());
                }
                refresh();
            }
            if (!roomEnded && !endLiveInProgress) handler.postDelayed(this, 1200);
        }
    };

    private final Runnable durationTick = new Runnable() {
        @Override public void run() {
            if (durationView != null && !activeSessionId.isEmpty()) {
                long sec = Math.max(0, serverElapsedSec + (System.currentTimeMillis() - serverElapsedSyncMs) / 1000L);
                durationView.setText(hhmmss(sec));
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        host = getIntent().getBooleanExtra("hostMode", false);
        hostId = host ? SessionManager.getUserId(this) : getIntent().getStringExtra("hostId");
        if (hostId == null || hostId.trim().isEmpty()) hostId = SessionManager.getUserId(this);
        build();
        renderLocalSkeleton();
        handler.post(durationTick);
        prefetchGiftCatalog();
        if (host) showHostSetup();
        else {
            BackendClient.liveViewer(token(), hostId, true, new Silent());
            handler.post(tick);
        }
    }

    private void showHostSetup() {
        final android.app.Dialog d=new android.app.Dialog(this);
        LinearLayout box=col();box.setPadding(dp(20),dp(18),dp(20),dp(18));box.setBackground(bg(Color.rgb(10,18,58),Color.rgb(170,69,255),24));
        TextView hd=t("🎙  START AUDIO LIVE",18,Color.WHITE,true);hd.setGravity(Gravity.CENTER);box.addView(hd,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView sub=t("Create your MY SHOP audio room",10.5f,Color.rgb(188,202,244),false);sub.setGravity(Gravity.CENTER);box.addView(sub,new LinearLayout.LayoutParams(-1,dp(30)));
        EditText title=new EditText(this);title.setHint("Live Name");title.setText(SessionManager.getFullName(this).isEmpty()?"My Live":SessionManager.getFullName(this));title.setTextColor(Color.WHITE);title.setHintTextColor(Color.rgb(155,166,205));title.setSingleLine(true);title.setPadding(dp(14),0,dp(14),0);title.setBackground(bg(Color.rgb(17,31,79),Color.rgb(94,110,225),16));LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(50));tp.topMargin=dp(10);box.addView(title,tp);
        EditText topic=new EditText(this);topic.setHint("Caption");topic.setText("");topic.setTextColor(Color.WHITE);topic.setHintTextColor(Color.rgb(155,166,205));topic.setSingleLine(true);topic.setPadding(dp(14),0,dp(14),0);topic.setBackground(bg(Color.rgb(17,31,79),Color.rgb(94,110,225),16));LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,dp(50));op.topMargin=dp(10);box.addView(topic,op);
        LinearLayout actions=row();Button cancel=small("Cancel");cancel.setBackground(bg(Color.rgb(27,38,83),Color.rgb(96,111,185),18));Button go=btn("GO LIVE");go.setBackground(bg(Color.rgb(126,43,218),Color.rgb(255,71,192),18));cancel.setOnClickListener(v->{d.dismiss();finish();});go.setOnClickListener(v->{String t=title.getText().toString().trim(),p=topic.getText().toString().trim();if(t.isEmpty())t=SessionManager.getFullName(AudioLiveRoomActivity.this);if(t==null||t.trim().isEmpty())t="My Live";d.dismiss();startHostLive(t,p);});LinearLayout.LayoutParams c=new LinearLayout.LayoutParams(0,dp(46),.38f);c.rightMargin=dp(8);actions.addView(cancel,c);actions.addView(go,new LinearLayout.LayoutParams(0,dp(46),.62f));LinearLayout.LayoutParams ax=new LinearLayout.LayoutParams(-1,dp(46));ax.topMargin=dp(16);box.addView(actions,ax);
        d.setContentView(box);d.setCancelable(false);d.setOnShowListener(x->{android.view.Window w=d.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.72f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.88f),-2);}});d.show();
    }

    private void startHostLive(String title, String topic) {
        BackendClient.setLivePresence(token(), true, new BackendClient.Callback() {
            @Override public void onSuccess(JSONObject data) {
                hostStarted = true;
                BackendClient.liveRoomConfig(token(), title, topic, null, null, new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(() -> { syncState.setText("● LIVE • Room connected"); refresh(); handler.post(tick); });}public void onError(String e){BackendClient.setLivePresence(token(),false,new Silent());hostStarted=false;runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_LONG).show();showHostSetup();});}});
            }
            @Override public void onError(String m) { runOnUiThread(() -> { syncState.setText("Could not start live"); Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show(); }); }
        });
    }

    private void build() {
        FrameLayout page = new FrameLayout(this);
        wallpaper = new ImageView(this);
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        wallpaper.setImageResource(R.drawable.live_guitar_wallpaper);
        page.addView(wallpaper, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout root = col(); root.setPadding(dp(10), dp(4), dp(10), dp(10));
        root.setBackgroundColor(Color.argb(170, 3, 8, 34));
        page.addView(root, new FrameLayout.LayoutParams(-1,-1));

        // V-292: preserve V-291 bottom safe-area and add only light spacing to right-side actions.
        // clearly above Android gesture/navigation controls on every device.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int navBottom = insets == null ? 0 : insets.getSystemWindowInsetBottom();
            root.setPadding(dp(10), dp(4), dp(10), Math.max(dp(8), navBottom + dp(6)));
            return insets;
        });
        root.post(root::requestApplyInsets);

        roomTitle = t("", 1, Color.TRANSPARENT, false);
        viewers = t("", 1, Color.TRANSPARENT, false); viewers.setVisibility(View.GONE);
        LinearLayout meta = row();
        status = t((host?"👑 Host":"🎧 Audience")+" • ID "+SessionManager.getUserId(this),11,Color.rgb(226,199,255),true);
        meta.addView(status,new LinearLayout.LayoutParams(0,dp(28),1));
        shareView=t("↗ 0",11,Color.rgb(226,199,255),true); shareView.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); meta.addView(shareView,new LinearLayout.LayoutParams(dp(70),dp(28)));
        meta.setVisibility(View.GONE); root.addView(meta,new LinearLayout.LayoutParams(1,1));
        syncState=t("",1,Color.TRANSPARENT,false); syncState.setVisibility(View.GONE); root.addView(syncState,new LinearLayout.LayoutParams(1,1));

        hostArea=row(); hostArea.setGravity(Gravity.CENTER_VERTICAL);
        audienceRow=row(); audienceRow.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(hostArea,new LinearLayout.LayoutParams(-1,dp(66)));
        roomTopic = t("Add caption",9.5f,Color.WHITE,true); roomTopic.setSingleLine(true); roomTopic.setEllipsize(android.text.TextUtils.TruncateAt.END); roomTopic.setGravity(Gravity.CENTER_VERTICAL); roomTopic.setPadding(dp(10),0,dp(10),0); roomTopic.setBackground(gradient(new int[]{Color.argb(215,54,31,126),Color.argb(215,174,45,151)},Color.rgb(255,206,91),13)); roomTopic.setOnClickListener(v->{if(host)editCaptionOnly();}); LinearLayout.LayoutParams ctp=new LinearLayout.LayoutParams(dp(220),dp(26)); ctp.topMargin=dp(1); ctp.bottomMargin=dp(2); root.addView(roomTopic,ctp);
        specialArea=col(); specialArea.setGravity(Gravity.CENTER_HORIZONTAL); LinearLayout.LayoutParams sgp=new LinearLayout.LayoutParams(-1,-2); sgp.topMargin=dp(2); root.addView(specialArea,sgp);

        seats=col(); seats.setPadding(dp(2),dp(2),dp(2),dp(2)); seats.setBackgroundColor(Color.TRANSPARENT); root.addView(seats,new LinearLayout.LayoutParams(-1,-2));

        if(host){
            requestNoticeBar=row();
            requestNoticeBar.setGravity(Gravity.CENTER_VERTICAL);
            requestNoticeBar.setPadding(dp(8),dp(3),dp(6),dp(3));
            requestNoticeBar.setVisibility(View.GONE);
            requestNoticeBar.setBackground(gradient(new int[]{Color.argb(235,28,46,112),Color.argb(235,91,42,151)},Color.rgb(84,214,255),14));
            LinearLayout.LayoutParams rnp=new LinearLayout.LayoutParams(-1,dp(44)); rnp.topMargin=dp(2); rnp.bottomMargin=dp(2); root.addView(requestNoticeBar,rnp);
            requests=col(); requests.setVisibility(View.GONE); root.addView(requests,new LinearLayout.LayoutParams(1,1)); requests.addView(t("No pending requests",11,Color.LTGRAY,false));
        }

        pinnedView=t("📌 No pinned announcement",11,Color.rgb(255,224,138),true); pinnedView.setPadding(dp(8),dp(7),dp(8),dp(6)); pinnedView.setBackground(bg(Color.argb(125,25,26,66),Color.rgb(131,96,235),12));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(28)); pp.topMargin=dp(3); root.addView(pinnedView,pp);

        premiumStrip=t("⚡ Live Room • Connecting…",9.3f,Color.WHITE,true);premiumStrip.setGravity(Gravity.CENTER_VERTICAL);premiumStrip.setSingleLine(true);premiumStrip.setEllipsize(android.text.TextUtils.TruncateAt.END);premiumStrip.setPadding(dp(8),0,dp(8),0);premiumStrip.setBackground(gradient(new int[]{Color.argb(165,21,56,122),Color.argb(165,91,42,151)},Color.argb(190,89,207,255),12));root.addView(premiumStrip,new LinearLayout.LayoutParams(-1,dp(25)));
        welcomeView=t("",9.4f,Color.rgb(255,231,166),true);welcomeView.setPadding(dp(8),0,dp(8),0);welcomeView.setGravity(Gravity.CENTER_VERTICAL);welcomeView.setVisibility(View.GONE);root.addView(welcomeView,new LinearLayout.LayoutParams(-1,dp(24)));
        productView=t("",9.5f,Color.WHITE,true);productView.setPadding(dp(8),0,dp(8),0);productView.setGravity(Gravity.CENTER_VERTICAL);productView.setBackground(bg(Color.argb(170,26,97,79),Color.rgb(80,234,165),11));productView.setVisibility(View.GONE);productView.setOnClickListener(v->startActivity(new Intent(this,StoreActivity.class)));root.addView(productView,new LinearLayout.LayoutParams(-1,dp(25)));
        pkView=t("",9.6f,Color.WHITE,true);pkView.setPadding(dp(8),0,dp(8),0);pkView.setGravity(Gravity.CENTER_VERTICAL);pkView.setBackground(gradient(new int[]{Color.argb(190,151,31,76),Color.argb(190,67,41,185)},Color.rgb(255,92,159),11));pkView.setVisibility(View.GONE);root.addView(pkView,new LinearLayout.LayoutParams(-1,dp(25)));

        TextView chatTitle=t("💬 LIVE COMMENTS",11,Color.WHITE,true); chatTitle.setPadding(0,dp(3),0,dp(2)); root.addView(chatTitle,new LinearLayout.LayoutParams(-1,dp(22)));
        FrameLayout commentStage=new FrameLayout(this);
        ScrollView commentScroll=new ScrollView(this); commentsList=col(); commentsList.setPadding(dp(5),dp(4),dp(5),dp(4)); commentsList.setBackgroundColor(Color.TRANSPARENT); commentScroll.setBackgroundColor(Color.TRANSPARENT); commentScroll.addView(commentsList);
        FrameLayout.LayoutParams csp=new FrameLayout.LayoutParams(-1,-1); csp.rightMargin=dp(48); commentStage.addView(commentScroll,csp);
        LinearLayout floating=col(); floating.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView request=t("✋",18,Color.WHITE,true); request.setGravity(Gravity.CENTER); request.setClickable(true); request.setFocusable(true); request.setElevation(dp(6)); request.setBackground(bg(Color.argb(220,18,49,118),Color.rgb(69,208,255),21)); request.setOnClickListener(v->{if(host)showJoinRequestsDialog();else BackendClient.liveSpeakRequest(token(),hostId,new ToastCb("Join request sent"));}); floating.addView(request,new LinearLayout.LayoutParams(dp(42),dp(42))); request.bringToFront();
        TextView gift=t("🎁",19,Color.WHITE,true); gift.setGravity(Gravity.CENTER); gift.setClickable(true); gift.setFocusable(true); gift.setElevation(dp(6)); gift.setBackground(bg(Color.argb(220,80,37,138),Color.rgb(255,195,72),21)); gift.setOnClickListener(v->showGiftPanel()); LinearLayout.LayoutParams gfp=new LinearLayout.LayoutParams(dp(42),dp(42)); gfp.topMargin=dp(8); floating.addView(gift,gfp); gift.bringToFront();
        reactView=t("❤️",16,Color.WHITE,true); reactView.setGravity(Gravity.CENTER); reactView.setBackground(bg(Color.argb(220,111,22,125),Color.rgb(255,74,189),21)); reactView.setOnClickListener(v->{BackendClient.liveReact(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{reactCount=d.optLong("reactCount",0);reactView.setText("❤️\n"+compact(reactCount));if(d.optInt("rewardCoin",0)>0&&host)Toast.makeText(AudioLiveRoomActivity.this,"React reward +"+d.optInt("rewardCoin")+" Coin",Toast.LENGTH_LONG).show();showReaction();});}public void onError(String e){runOnUiThread(()->showReaction());}});}); LinearLayout.LayoutParams frp=new LinearLayout.LayoutParams(dp(42),dp(42)); frp.topMargin=dp(8); floating.addView(reactView,frp);
        TextView share=t("↗",18,Color.WHITE,true); share.setGravity(Gravity.CENTER); share.setBackground(bg(Color.argb(220,15,59,118),Color.rgb(42,206,255),21)); share.setOnClickListener(v->shareRoom()); LinearLayout.LayoutParams sfp=new LinearLayout.LayoutParams(dp(42),dp(42)); sfp.topMargin=dp(8); floating.addView(share,sfp);
        FrameLayout.LayoutParams fap=new FrameLayout.LayoutParams(dp(42),dp(192),Gravity.RIGHT|Gravity.BOTTOM); fap.rightMargin=dp(1); fap.bottomMargin=dp(2); commentStage.addView(floating,fap);
        root.addView(commentStage,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout sendRow=row(); sendRow.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout commentBox=new FrameLayout(this);
        EditText commentInput=new EditText(this); commentInput.setHint("Write a comment…"); commentInput.setTextColor(Color.WHITE); commentInput.setHintTextColor(Color.rgb(155,165,195)); commentInput.setSingleLine(true); commentInput.setTextSize(11); commentInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_SHORT_MESSAGE); commentInput.setBackground(bg(Color.argb(170,10,24,61),Color.rgb(67,91,171),17)); commentInput.setPadding(dp(10),0,dp(38),0); commentBox.addView(commentInput,new FrameLayout.LayoutParams(-1,-1));
        TextView highlight=t("✨",15,Color.rgb(255,219,96),true); highlight.setGravity(Gravity.CENTER); FrameLayout.LayoutParams hlp=new FrameLayout.LayoutParams(dp(36),-1,Gravity.RIGHT); commentBox.addView(highlight,hlp);
        highlight.setOnClickListener(v->{highlightSelected=!highlightSelected;highlight.setBackground(highlightSelected?bg(Color.argb(170,112,48,170),Color.rgb(255,216,89),15):null);Toast.makeText(this,highlightSelected?"Highlight ON • "+highlightPrice+" Coin":"Highlight OFF",Toast.LENGTH_SHORT).show();});
        BackendClient.liveHighlightConfig(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{highlightPrice=d.optInt("coinPrice",1000);if(d.optBoolean("free",false))highlightPrice=0;});}public void onError(String e){}});
        sendButton=small("Send"); sendButton.setTextSize(9.5f); sendButton.setOnClickListener(v->sendLiveComment(commentInput,highlight));
        micButton=t("🎙",17,Color.WHITE,true); micButton.setGravity(Gravity.CENTER); micButton.setBackground(gradient(new int[]{Color.rgb(22,68,187),Color.rgb(67,42,214)},Color.rgb(42,232,255),18)); micButton.setOnClickListener(v->toggleMic()); updateLocalMicUi();
        TextView join=t(host?"End":"Join",11,Color.WHITE,true); join.setGravity(Gravity.CENTER); join.setBackground(gradient(new int[]{Color.rgb(110,37,224),Color.rgb(242,45,206)},Color.rgb(255,132,245),18)); join.setOnClickListener(v->{if(host)confirmEndLive();else if(listenOnly)Toast.makeText(this,"Muted • listen and gift only",Toast.LENGTH_SHORT).show();else BackendClient.liveSpeakRequest(token(),hostId,new ToastCb("Join request sent"));});
        LinearLayout.LayoutParams cip=new LinearLayout.LayoutParams(0,dp(38),1); cip.rightMargin=dp(4); sendRow.addView(commentBox,cip);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(58),dp(38)); sp.rightMargin=dp(4); sendRow.addView(sendButton,sp);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(dp(48),dp(38)); mp.rightMargin=dp(4); sendRow.addView(micButton,mp);
        sendRow.addView(join,new LinearLayout.LayoutParams(dp(70),dp(38)));
        LinearLayout.LayoutParams srp=new LinearLayout.LayoutParams(-1,dp(44)); srp.topMargin=dp(4); srp.bottomMargin=dp(2); root.addView(sendRow,srp);
        
        setContentView(page);
    }

    private void addControls(LinearLayout root){
        LinearLayout bottom=row(); bottom.setGravity(Gravity.CENTER_VERTICAL);
        String[] labels=host?new String[]{"🎙","➕","🪑","📌","↗","⚙"}:new String[]{"✋","➕","💬","📩","↗","⚙"};
        for(int i=0;i<labels.length;i++){final int idx=i;TextView v=t(labels[i],16,Color.WHITE,true);v.setGravity(Gravity.CENTER);v.setBackground(bg(Color.argb(185,12,27,72),Color.rgb(80,92,190),18));v.setOnClickListener(x->handleCompactControl(idx));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(40),1);lp.setMargins(dp(2),0,dp(2),0);bottom.addView(v,lp);}
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(42)); bp.topMargin=dp(3); root.addView(bottom,bp);
    }

    private void handleCompactControl(int i){
        if(host){if(i==0)toggleMic();else if(i==1)showAudienceList();else if(i==2)Toast.makeText(this,"Tap a sofa to lock/unlock or manage speaker",Toast.LENGTH_SHORT).show();else if(i==3)editPinned();else if(i==4)shareRoom();else if(i==5)showHostRoomMenu();}
        else{if(i==0)BackendClient.liveSpeakRequest(token(),hostId,new ToastCb("Request sent"));else if(i==1)BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));else if(i==2)Toast.makeText(this,"Live chat is above",Toast.LENGTH_SHORT).show();else if(i==3)Toast.makeText(this,"Open Inbox",Toast.LENGTH_SHORT).show();else if(i==4)shareRoom();else showLiveCommunityMenu();}
    }

    private void showHostRoomMenu(){String[] a={"Theme","Live Name / Caption","Pinned announcement","Welcome / Rules","Live Goal","Pin Shop Item","Top Supporters / Fan Club","Creator Center","Schedule Live","PK / Battle","End Live"};new AlertDialog.Builder(this).setTitle("Host Room Controls • V-304").setItems(a,(d,w)->{if(w==0)chooseTheme();else if(w==1)editRoomInfo();else if(w==2)editPinned();else if(w==3)editWelcome();else if(w==4)editGoal();else if(w==5)choosePinnedProduct();else if(w==6)showFanClub();else if(w==7)openCreatorCenter(hostId);else if(w==8)showScheduleDialog();else if(w==9)showPkDialog();else confirmEndLive();}).show();}

    private void handleControl(int i){
        if(host){
            if(i==0) toggleMic(); else if(i==2) Toast.makeText(this,"Tap any sofa to lock/unlock or manage speaker",Toast.LENGTH_SHORT).show();
            else if(i==3) editPinned(); else if(i==4) chooseTheme(); else if(i==5) shareRoom(); else if(i==6) showReaction(); else if(i==7) editRoomInfo();
            else Toast.makeText(this,"Host control ready",Toast.LENGTH_SHORT).show();
        } else {
            if(i==0) toggleMic(); else if(i==1) BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));
            else if(i==3) showReaction(); else if(i==5) shareRoom(); else Toast.makeText(this,"Live control",Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleMic(){
        localMicOn=!localMicOn;
        if(!localMicOn)localSpeaking=false;
        updateLocalMicUi();
        updateVoiceMonitor();
        BackendClient.liveParticipantState(token(),hostId,localMicOn,localSpeaking,networkQuality(),new ToastCb(localMicOn?"Mic on":"Mic muted"));
    }

    private void updateLocalMicUi(){
        if(micButton==null)return;
        if(localMicOn){
            micButton.setText("🎙");
            micButton.setTextColor(Color.WHITE);
            micButton.setBackground(gradient(new int[]{Color.rgb(22,68,187),Color.rgb(67,42,214)},Color.rgb(42,232,255),18));
        }else{
            micButton.setText("🎙✕");
            micButton.setTextColor(Color.rgb(255,92,92));
            micButton.setBackground(gradient(new int[]{Color.rgb(92,24,48),Color.rgb(132,28,55)},Color.rgb(255,76,92),18));
        }
    }

    private void updateVoiceMonitor(){
        boolean should=(host||"SPEAKER".equals(myRole))&&localMicOn&&!listenOnly;
        if(should)startVoiceMonitor(); else stopVoiceMonitor(true);
    }

    private void startVoiceMonitor(){
        if(voiceMonitorRunning)return;
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            if(!micPermissionAsked){micPermissionAsked=true;requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},9021);}
            return;
        }
        try{
            final int rate=16000;
            int min=android.media.AudioRecord.getMinBufferSize(rate,android.media.AudioFormat.CHANNEL_IN_MONO,android.media.AudioFormat.ENCODING_PCM_16BIT);
            if(min<=0)return;
            voiceRecorder=new android.media.AudioRecord(android.media.MediaRecorder.AudioSource.VOICE_RECOGNITION,rate,android.media.AudioFormat.CHANNEL_IN_MONO,android.media.AudioFormat.ENCODING_PCM_16BIT,Math.max(min,3200));
            voiceRecorder.startRecording();
            voiceMonitorRunning=true;
            voiceThread=new Thread(()->{
                short[] buf=new short[640];
                while(voiceMonitorRunning){
                    try{
                        int n=voiceRecorder==null?0:voiceRecorder.read(buf,0,buf.length);
                        if(n<=0)continue;
                        long sum=0;for(int i=0;i<n;i++)sum+=Math.abs((int)buf[i]);
                        long avg=sum/Math.max(1,n),now=System.currentTimeMillis();
                        if(avg>900)lastVoiceAboveMs=now;
                        boolean speaking=localMicOn&&(now-lastVoiceAboveMs<360);
                        if(speaking!=localSpeaking){
                            localSpeaking=speaking;
                            BackendClient.liveParticipantState(token(),hostId,localMicOn,localSpeaking,networkQuality(),new Silent());
                        }
                    }catch(Exception ignored){}
                }
            },"myshop-live-vad");
            voiceThread.start();
        }catch(Exception e){voiceMonitorRunning=false;localSpeaking=false;try{if(voiceRecorder!=null)voiceRecorder.release();}catch(Exception ignored){}voiceRecorder=null;}
    }

    private void stopVoiceMonitor(boolean publish){
        boolean wasSpeaking=localSpeaking;
        voiceMonitorRunning=false;localSpeaking=false;
        try{if(voiceRecorder!=null){voiceRecorder.stop();voiceRecorder.release();}}catch(Exception ignored){}
        voiceRecorder=null;voiceThread=null;
        if(publish&&wasSpeaking&&(host||"SPEAKER".equals(myRole)))BackendClient.liveParticipantState(token(),hostId,localMicOn,false,networkQuality(),new Silent());
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==9021 && grantResults.length>0 && grantResults[0]==android.content.pm.PackageManager.PERMISSION_GRANTED)updateVoiceMonitor();
    }

    private void editPinned(){EditText e=new EditText(this);e.setHint("Pinned announcement");new AlertDialog.Builder(this).setTitle("Pinned message").setView(e).setPositiveButton("Save",(d,w)->BackendClient.liveRoomConfig(token(),null,null,e.getText().toString().trim(),null,new ToastCb("Pinned message updated"))).setNegativeButton("Cancel",null).show();}
    private void editRoomInfo(){LinearLayout b=col();EditText t1=new EditText(this);t1.setHint("Live Name");t1.setText(currentLiveName);EditText t2=new EditText(this);t2.setHint("Caption");t2.setText(roomTopic.getText());b.addView(t1);b.addView(t2);TextView note=t("Live Name: 24 ঘণ্টায় ১বার ফ্রি • আগে বদলালে 5,000 Coin. ID কখনো বদলাবে না।",10,Color.DKGRAY,false);b.addView(note);new AlertDialog.Builder(this).setTitle("Live Name & Caption").setView(b).setPositiveButton("Save",(d,w)->BackendClient.liveRoomConfig(token(),t1.getText().toString(),t2.getText().toString(),null,null,new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,"Live info updated",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String e){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_LONG).show());}})).setNegativeButton("Cancel",null).show();}
    private void editCaptionOnly(){final EditText e=new EditText(this);e.setHint("Caption");e.setSingleLine(true);e.setText(roomTopic.getText());new AlertDialog.Builder(this).setTitle("Edit Caption").setView(e).setPositiveButton("Save",(d,w)->BackendClient.liveRoomConfig(token(),null,e.getText().toString(),null,null,new ToastCb("Caption updated"))).setNegativeButton("Cancel",null).show();}

    private void chooseTheme(){BackendClient.liveThemes(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("themes");if(a==null||a.length()==0){Toast.makeText(AudioLiveRoomActivity.this,"No enabled themes",Toast.LENGTH_SHORT).show();return;}String[] names=new String[a.length()];String[] keys=new String[a.length()];for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);names[i]=x==null?"Theme":x.optString("name","Theme");keys[i]=x==null?"GUITAR_BLUE":x.optString("theme_key","GUITAR_BLUE");}new AlertDialog.Builder(AudioLiveRoomActivity.this).setTitle("Live Theme").setItems(names,(q,which)->BackendClient.liveRoomConfig(token(),null,null,null,keys[which],new ToastCb("Theme changed"))).show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}

    private void shareRoom(){BackendClient.liveShare(token(),hostId,new Silent()); Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,"Join my MY SHOP Audio Live • Host ID "+hostId);startActivity(Intent.createChooser(send,"Share Live"));}

    private void showReaction(){
        if(commentsList==null)return;
        TextView r=t("❤️",28,Color.WHITE,true);
        r.setGravity(Gravity.CENTER);
        commentsList.addView(r,0,new LinearLayout.LayoutParams(-1,dp(42)));
        r.setAlpha(.2f);
        r.setTranslationY(dp(20));
        r.animate().alpha(1f).translationY(0).setDuration(220).withEndAction(() -> {
            r.animate().alpha(0f).translationY(-dp(20)).setDuration(650).withEndAction(() -> commentsList.removeView(r)).start();
        }).start();
    }

    private void showUserModeration(JSONObject u){
        String uid=u.optString("user_id","");if(uid.isEmpty()||uid.equals(hostId))return;
        String[] actions=host?new String[]{"📞 Invite to Call","Kick from Live","Mute • listen/gift only","Unmute","Block from this Live","Add as Room Admin","Remove Room Admin","⚑ Report / Block Account"}:new String[]{"Mute • listen/gift only","Unmute","⚑ Report / Block Account"};
        new AlertDialog.Builder(this).setTitle(u.optString("full_name","User")+" • ID "+uid).setItems(actions,(d,w)->{if(host&&w==0){inviteToCall(u);return;}if((host&&w==7)||(!host&&w==2)){SafetyActions.show(this,uid,"LIVE_USER",hostId);return;}int idx=host?w-1:w;String a=host?new String[]{"KICK","MUTE","UNMUTE","BLOCK","ADD_ROOM_ADMIN","REMOVE_ROOM_ADMIN"}[idx]:(idx==0?"MUTE":"UNMUTE");BackendClient.liveModeration(token(),hostId,uid,a,new ToastCb("Moderation updated"));}).setNegativeButton("Close",null).show();
    }

    private void prefetchGiftCatalog(){BackendClient.liveGifts(token(),new BackendClient.Callback(){public void onSuccess(JSONObject o){cachedGiftCatalog=o;}public void onError(String m){}});}

    private void showGiftPanel(){
        if(cachedGiftCatalog!=null){openGiftChart(cachedGiftCatalog);return;}
        if(giftLoadingDialog!=null&&giftLoadingDialog.isShowing())return;
        LinearLayout loading=col();loading.setPadding(dp(18),dp(14),dp(18),dp(14));
        TextView title=t("🎁 Gifts",16,Color.rgb(35,40,65),true);loading.addView(title,new LinearLayout.LayoutParams(-1,dp(34)));
        TextView msg=t("Loading gifts…",11.5f,Color.rgb(85,90,115),false);loading.addView(msg,new LinearLayout.LayoutParams(-1,dp(34)));
        giftLoadingDialog=new AlertDialog.Builder(this).setView(loading).setNegativeButton("Close",null).create();
        giftLoadingDialog.show();
        BackendClient.liveGifts(token(),new BackendClient.Callback(){
            public void onSuccess(JSONObject o){runOnUiThread(()->{cachedGiftCatalog=o;if(giftLoadingDialog!=null&&giftLoadingDialog.isShowing())giftLoadingDialog.dismiss();giftLoadingDialog=null;if(!isFinishing())openGiftChart(o);});}
            public void onError(String m){runOnUiThread(()->{if(giftLoadingDialog!=null&&giftLoadingDialog.isShowing())giftLoadingDialog.dismiss();giftLoadingDialog=null;Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show();});}
        });
    }
    private void openGiftChart(JSONObject o){
        final JSONArray gifts=o.optJSONArray("gifts")==null?new JSONArray():o.optJSONArray("gifts");
        LinearLayout box=col();box.setPadding(dp(10),dp(6),dp(10),dp(6));
        TextView balance=t("🪙 Coin  "+o.optLong("coinBalance",0)+"      🟡 Gold Coin  "+o.optLong("goldBalance",0),12,Color.rgb(35,40,65),true);box.addView(balance,new LinearLayout.LayoutParams(-1,dp(40)));
        LinearLayout tabs=row();Button coin=small("Coin Gifts"),gold=small("Gold Coin Gifts");tabs.addView(coin,new LinearLayout.LayoutParams(0,dp(42),1));tabs.addView(gold,new LinearLayout.LayoutParams(0,dp(42),1));box.addView(tabs);
        ScrollView sc=new ScrollView(this);LinearLayout list=col();sc.addView(list);box.addView(sc,new LinearLayout.LayoutParams(-1,dp(360)));
        final String[] selected={"COIN"};
        Runnable render=()->{
            list.removeAllViews();
            for(int i=0;i<gifts.length();i++){
                JSONObject g=gifts.optJSONObject(i);if(g==null||!selected[0].equals(g.optString("currency")))continue;
                LinearLayout card=row();card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(7),dp(6),dp(7),dp(6));
                card.setBackground(bg(Color.rgb(248,247,255),Color.rgb(217,207,255),14));
                ImageView icon=new ImageView(this);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                String preview=g.optString("preview_url","");if(preview.isEmpty())preview=g.optString("animation_url","");
                if(!preview.isEmpty())loadImage(icon,preview);else icon.setImageResource(android.R.drawable.btn_star_big_on);
                card.addView(icon,new LinearLayout.LayoutParams(dp(58),dp(58)));
                LinearLayout info=col();TextView nm=t(g.optString("name","Gift"),12.5f,Color.rgb(25,30,60),true);TextView pr=t(("GOLD".equals(selected[0])?"🟡 ":"🪙 ")+g.optInt("price",1),11.5f,Color.rgb(104,64,205),true);info.addView(nm);info.addView(pr);card.addView(info,new LinearLayout.LayoutParams(0,dp(62),1));
                Button send=small("Send");long id=g.optLong("id");final JSONObject gift=g;
                send.setOnClickListener(v->{send.setEnabled(false);BackendClient.liveGiftSend(token(),hostId,hostId,id,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{send.setEnabled(true);showGiftEffect(gift,d);cachedGiftCatalog=null;prefetchGiftCatalog();});}public void onError(String m){runOnUiThread(()->{send.setEnabled(true);Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show();});}});});
                card.addView(send,new LinearLayout.LayoutParams(dp(76),dp(44)));
                LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(72));cp.topMargin=dp(5);list.addView(card,cp);
            }
            if(list.getChildCount()==0){TextView empty=t("No published gifts yet. Admin can add and publish gifts from Live Gift Manager.",11,Color.rgb(90,90,115),false);empty.setGravity(Gravity.CENTER);list.addView(empty,new LinearLayout.LayoutParams(-1,dp(100)));}
        };
        coin.setOnClickListener(v->{selected[0]="COIN";render.run();});gold.setOnClickListener(v->{selected[0]="GOLD";render.run();});render.run();
        new AlertDialog.Builder(this).setTitle("🎁 Live Gift Store").setView(box).setNegativeButton("Close",null).show();
    }

    private void renderLocalSkeleton(){renderHost(null);renderAudience(null,0);renderSpecialGuest(null);renderSeats(null);}

    private void refresh(){if(roomEnded||endLiveInProgress)return;BackendClient.liveRoomState(token(),hostId,new BackendClient.Callback(){@Override public void onSuccess(JSONObject d){runOnUiThread(()->{if(roomEnded||endLiveInProgress)return;syncState.setText("● LIVE • Synced • "+networkQuality());render(d);});}@Override public void onError(String m){runOnUiThread(()->{if(roomEnded)return;if(endLiveInProgress){syncState.setText("Ending live…");return;}if(!host && m!=null && m.contains("LIVE_NOT_ACTIVE")){handler.removeCallbacks(tick);showAudienceEndSummary();return;}syncState.setText("● LIVE • Weak network • Reconnecting…");if(premiumStrip!=null)premiumStrip.setText("⚠ Reconnecting… • "+networkQuality());if(seats.getChildCount()==0)renderLocalSkeleton();});}});}

    private void render(JSONObject d){
        int vc=d.optInt("viewerCount",0),peak=d.optInt("peakViewers",0); currentViewerCount=vc; viewers.setText("");
        myRole=d.optString("myRole",host?"HOST":"AUDIENCE"); roomAdmin=d.optBoolean("myRoomAdmin",false); String sanction=d.optString("mySanction","NONE"); listenOnly="MUTED".equals(sanction); if("BLOCKED".equals(sanction)||"KICKED".equals(sanction)){Toast.makeText(this,"You were removed from this live",Toast.LENGTH_SHORT).show();finish();return;} status.setText((host?"👑 Host":(roomAdmin?"🛡 Admin":"🎧 "+myRole))+" • ID "+SessionManager.getUserId(this)+(listenOnly?" • Listen only":"")); updateVoiceMonitor(); updateLocalMicUi();
        specialGuestId=d.optString("specialGuestId",""); shareCount=d.optInt("shareCount",0); shareView.setText("↗ "+shareCount);
        currentLiveName=d.optString("title","Host"); roomTitle.setText("🎙 "+currentLiveName); String cap=d.optString("topic","").trim(); roomTopic.setText(cap.isEmpty()?"Add caption":cap); reactCount=d.optLong("reactCount",0); if(reactView!=null)reactView.setText("❤️\n"+compact(reactCount));
        String pin=d.optString("pinnedMessage",""); pinnedView.setText(pin.isEmpty()?"📌 No pinned announcement":"📌 "+pin);
        String sid=d.optString("sessionId","");long elapsed=Math.max(0,d.optLong("elapsedSeconds",0));long parsed=parseServerTime(d.optString("startedAt",""));
        if(!sid.equals(activeSessionId)){activeSessionId=sid;serverElapsedSec=elapsed;serverElapsedSyncMs=System.currentTimeMillis();startedAtMs=parsed;pendingComments.clear();shownMilestones.clear();lastEntryEventId=0L;}else{serverElapsedSec=elapsed;serverElapsedSyncMs=System.currentTimeMillis();if(parsed>0)startedAtMs=parsed;}
        renderPremiumState(d);
        lockedSeats.clear();JSONArray locks=d.optJSONArray("lockedSeats");if(locks!=null)for(int i=0;i<locks.length();i++)lockedSeats.add(locks.optInt(i));
        JSONArray a=d.optJSONArray("seats"); renderHost(findSeat(a,1));renderAudience(d.optJSONArray("viewerProfiles"),vc);renderSpecialGuest(findUser(a,specialGuestId));renderSeats(a);
        currentRequests=d.optJSONArray("requests")==null?new JSONArray():d.optJSONArray("requests");
        if(host&&requests!=null){renderRequests(currentRequests);notifyHostOfNewRequest(currentRequests);}
        JSONArray highlights=d.optJSONArray("highlightComments");renderComments(d.optJSONArray("comments"),d.optJSONArray("events"),highlights);renderHighlightComments(highlights);
        if(!host)showIncomingInvite(d.optJSONObject("incomingInvite"));
        JSONObject theme=d.optJSONObject("theme"); if(theme!=null){String bg=theme.optString("background_url","");if(!bg.trim().isEmpty())loadImage(wallpaper,bg);}
    }

    private void renderHost(JSONObject x){
        hostArea.removeAllViews();
        LinearLayout hostBlock=row(); hostBlock.setGravity(Gravity.CENTER_VERTICAL); hostBlock.setPadding(0,0,dp(3),0); hostBlock.setBackgroundColor(Color.TRANSPARENT);
        boolean speaking=x!=null&&x.optInt("speaking",0)==1;
        FrameLayout av=avatarWithMicState(x,dp(40),speaking);
        hostBlock.addView(av,new LinearLayout.LayoutParams(dp(40),dp(40)));
        String name=currentLiveName==null||currentLiveName.trim().isEmpty()?(x==null?"Host":x.optString("full_name","Host")):currentLiveName; String id=x==null?hostId:x.optString("user_id",hostId); int lv=x==null?0:x.optInt("level",0);
        long coin=x==null?0:x.optLong("coin_balance",0),gold=x==null?0:x.optLong("gold_balance",0);
        TextView info=t("👑 "+name+"\nID "+id+" • LV."+lv+"\n🪙 "+coin+"  🟡 "+gold,9.2f,Color.WHITE,true);
        info.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,dp(58),1); ip.leftMargin=dp(5); hostBlock.addView(info,ip);
        hostArea.addView(hostBlock,new LinearLayout.LayoutParams(dp(120),dp(62)));
        if(audienceRow.getParent()!=null)((android.view.ViewGroup)audienceRow.getParent()).removeView(audienceRow);
        hostArea.addView(audienceRow,new LinearLayout.LayoutParams(0,dp(62),1));
    }

    private void renderAudience(JSONArray a,int total){
        currentViewerProfiles=a==null?new JSONArray():a; currentViewerCount=total; audienceRow.removeAllViews(); audienceRow.setPadding(dp(2),0,0,0);
        int shown=0;
        for(int i=0;i<currentViewerProfiles.length()&&shown<6;i++){
            JSONObject u=currentViewerProfiles.optJSONObject(i); if(u==null)continue; shown++;
            LinearLayout cell=col(); cell.setGravity(Gravity.CENTER);
            FrameLayout av=circleAvatar(u.optString("avatar_url",""),dp(25),false); String uid=u.optString("user_id","");
            av.setOnClickListener(v->{if(host||roomAdmin)showUserModeration(u);else showMiniProfile(u);});
            cell.addView(av,new LinearLayout.LayoutParams(dp(25),dp(25)));
            String tag=u.optBoolean("roomAdmin",false)?"🛡 ":(u.optInt("supporterRank",0)>0&&u.optInt("supporterRank",0)<=3?"👑 ":"");TextView nm=t(tag+shortName(u.optString("full_name","User")),7.2f,Color.WHITE,true); nm.setGravity(Gravity.CENTER); cell.addView(nm,new LinearLayout.LayoutParams(-1,dp(14)));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(54),1); cp.setMargins(dp(1),0,dp(1),0); audienceRow.addView(cell,cp);
        }
        while(shown<6){
            LinearLayout blank=col(); blank.setGravity(Gravity.CENTER); TextView dot=t("",1,Color.TRANSPARENT,false); blank.addView(dot,new LinearLayout.LayoutParams(dp(25),dp(25))); audienceRow.addView(blank,new LinearLayout.LayoutParams(0,dp(54),1)); shown++;
        }
        LinearLayout moreCell=col(); moreCell.setGravity(Gravity.CENTER);
        TextView more=t(">",17,Color.WHITE,true); more.setGravity(Gravity.CENTER); more.setBackground(bg(Color.argb(165,20,30,82),Color.rgb(94,111,223),16)); more.setOnClickListener(v->showAudienceList());
        moreCell.addView(more,new LinearLayout.LayoutParams(dp(29),dp(29)));
        audienceRow.addView(moreCell,new LinearLayout.LayoutParams(dp(31),dp(54)));
    }

    private String compact(long n){if(n>=1000000)return (n%1000000==0?(n/1000000)+"M":String.format(Locale.US,"%.1fM",n/1000000f));if(n>=1000)return (n%1000==0?(n/1000)+"K":String.format(Locale.US,"%.1fK",n/1000f));return String.valueOf(n);}

    private String shortName(String n){ if(n==null||n.trim().isEmpty())return "User"; n=n.trim(); int sp=n.indexOf(' '); if(sp>0)n=n.substring(0,sp); return n.length()>7?n.substring(0,7):n; }

    private void showAudienceList(){
        int n=currentViewerProfiles==null?0:currentViewerProfiles.length();
        if(n==0){Toast.makeText(this,"No active users right now",Toast.LENGTH_SHORT).show();return;}
        String[] items=new String[n]; for(int i=0;i<n;i++){JSONObject u=currentViewerProfiles.optJSONObject(i); items[i]=u==null?"User":u.optString("full_name","User")+"  •  ID "+u.optString("user_id","")+"  •  LV."+u.optInt("level",0);}
        new AlertDialog.Builder(this).setTitle("Active Users • "+currentViewerCount).setItems(items,(d,w)->{JSONObject u=currentViewerProfiles.optJSONObject(w);if(u==null)return;if(host)showUserModeration(u);else showMiniProfile(u);}).setNegativeButton("Close",null).show();
    }

    private void inviteToCall(JSONObject u){
        if(!host||u==null)return;String uid=u.optString("user_id","");if(uid.isEmpty()||uid.equals(hostId))return;
        BackendClient.liveInvite(token(),uid,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,"Call invitation sent to "+u.optString("full_name","User"),Toast.LENGTH_SHORT).show());}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}});
    }

    private void showIncomingInvite(JSONObject inv){
        if(inv==null||host||inviteDialogOpen)return;String key=inv.optString("host_id",hostId)+"|"+inv.optString("session_id","")+"|"+inv.optString("created_at","");if(key.equals(lastInviteNotice))return;lastInviteNotice=key;inviteDialogOpen=true;
        String hostName=inv.optString("host_name","Host");
        new AlertDialog.Builder(this).setTitle("📞 Live Call Invitation").setMessage(hostName+" আপনাকে Live Call-এ speaker হিসেবে আমন্ত্রণ জানিয়েছে। Accept করলে available seat-এ উঠবেন।")
                .setPositiveButton("ACCEPT",(d,w)->{inviteDialogOpen=false;BackendClient.liveInviteAction(token(),hostId,true,new ToastCb("Invitation accepted • joining call"));})
                .setNegativeButton("DECLINE",(d,w)->{inviteDialogOpen=false;BackendClient.liveInviteAction(token(),hostId,false,new ToastCb("Invitation declined"));})
                .setOnCancelListener(d->inviteDialogOpen=false).show();
    }

    private void notifyHostOfNewRequest(JSONArray q){
        if(!host||requestNoticeBar==null)return;
        if(q==null||q.length()==0){requestNoticeBar.setVisibility(View.GONE);requestNoticeBar.removeAllViews();return;}
        JSONObject x=q.optJSONObject(0);if(x==null)return;
        String uid=x.optString("user_id","");String nm=x.optString("full_name","User");String key=uid+"|"+x.optString("created_at","");
        requestNoticeBar.removeAllViews();
        TextView who=t("✋ "+shortName(nm)+(q.length()>1?"  +"+(q.length()-1):""),10.5f,Color.WHITE,true);who.setSingleLine(true);who.setEllipsize(android.text.TextUtils.TruncateAt.END);requestNoticeBar.addView(who,new LinearLayout.LayoutParams(0,dp(36),1));
        Button ok=small("✓ Accept");ok.setTextSize(8.8f);ok.setBackground(bg(Color.rgb(28,120,92),Color.rgb(83,244,178),12));ok.setOnClickListener(v->BackendClient.liveRequestAction(token(),uid,true,new ToastCb("Speaker accepted")));
        Button no=small("✕");no.setTextSize(10);no.setTextColor(Color.rgb(255,210,215));no.setBackground(bg(Color.rgb(116,34,57),Color.rgb(255,91,116),12));no.setOnClickListener(v->BackendClient.liveRequestAction(token(),uid,false,new ToastCb("Request declined")));
        LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(dp(72),dp(34));op.rightMargin=dp(4);requestNoticeBar.addView(ok,op);requestNoticeBar.addView(no,new LinearLayout.LayoutParams(dp(38),dp(34)));
        requestNoticeBar.setVisibility(View.VISIBLE);
        if(!key.equals(lastRequestNotice)){lastRequestNotice=key;requestNoticeBar.setAlpha(.2f);requestNoticeBar.setTranslationY(-dp(8));requestNoticeBar.animate().alpha(1f).translationY(0).setDuration(180).start();}
    }

    private void showJoinRequestsDialog(){
        if(!host)return;if(currentRequests==null||currentRequests.length()==0){Toast.makeText(this,"No pending join requests",Toast.LENGTH_SHORT).show();return;}
        int n=currentRequests.length();String[] items=new String[n];for(int i=0;i<n;i++){JSONObject x=currentRequests.optJSONObject(i);items[i]=x==null?"User":x.optString("full_name","User")+" • ID "+x.optString("user_id","");}
        new AlertDialog.Builder(this).setTitle("Join Requests • "+n).setItems(items,(d,w)->{JSONObject x=currentRequests.optJSONObject(w);if(x==null)return;String uid=x.optString("user_id","");new AlertDialog.Builder(this).setTitle(items[w]).setItems(new String[]{"Accept to Call","Decline"},(dd,which)->BackendClient.liveRequestAction(token(),uid,which==0,new ToastCb(which==0?"Speaker accepted":"Request declined"))).show();}).setNegativeButton("Close",null).show();
    }

    private void renderSpecialGuest(JSONObject x){
        specialArea.removeAllViews();
        FrameLayout stage=new FrameLayout(this);
        long elapsed=!activeSessionId.isEmpty()?Math.max(0,serverElapsedSec+(System.currentTimeMillis()-serverElapsedSyncMs)/1000L):0;
        durationView=t(hhmmss(elapsed),9.5f,Color.rgb(255,220,244),true); durationView.setGravity(Gravity.CENTER); durationView.setBackground(bg(Color.argb(170,55,18,75),Color.rgb(236,73,179),13));
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(dp(72),dp(26),Gravity.LEFT|Gravity.TOP); tp.leftMargin=dp(2); tp.topMargin=dp(5); stage.addView(durationView,tp);
        boolean speaking=x!=null&&x.optInt("speaking",0)==1;
        FrameLayout guestFrame=new FrameLayout(this); GoldenGuestHalo halo=new GoldenGuestHalo(this); guestFrame.addView(halo,new FrameLayout.LayoutParams(-1,-1));
        FrameLayout av=avatarWithMicState(x,dp(70),speaking); FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(dp(70),dp(70),Gravity.CENTER); guestFrame.addView(av,ap);
        ObjectAnimator pulseX=ObjectAnimator.ofFloat(halo,"scaleX",1f,1.055f,1f); pulseX.setDuration(1650); pulseX.setRepeatCount(ValueAnimator.INFINITE); pulseX.start();
        ObjectAnimator pulseY=ObjectAnimator.ofFloat(halo,"scaleY",1f,1.055f,1f); pulseY.setDuration(1650); pulseY.setRepeatCount(ValueAnimator.INFINITE); pulseY.start();
        ObjectAnimator glow=ObjectAnimator.ofFloat(halo,"alpha",.78f,1f,.78f); glow.setDuration(1400); glow.setRepeatCount(ValueAnimator.INFINITE); glow.start();
        FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(dp(112),dp(94),Gravity.CENTER); stage.addView(guestFrame,gp);
        specialArea.addView(stage,new LinearLayout.LayoutParams(-1,dp(96)));
        if(host&&x!=null)guestFrame.setOnClickListener(v->clearSpecialGuest()); else guestFrame.setOnClickListener(null);
    }

    private void renderSeats(JSONArray a){
        seats.removeAllViews();
        int n=1; int[] counts={6,6};
        for(int rr=0;rr<counts.length;rr++){
            LinearLayout r=row();
            for(int c=0;c<counts[rr]&&n<=12;c++,n++){
                JSONObject found=findSeat(a,n);
                // Host must never be duplicated inside the 12-seat user/guest board.
                // We only filter the Host presentation here; seat numbering/layout/function remain untouched.
                if(found!=null&&hostId.equals(found.optString("user_id","")))found=null;
                boolean locked=n>1&&lockedSeats.contains(n);
                LinearLayout tile=seatTile(n,found,locked); final int seatNo=n; final JSONObject clicked=found;
                if(seatNo>1) tile.setOnClickListener(v->{if(host){if(clicked!=null)showSpeakerActions(clicked);else toggleSeatLock(seatNo,locked);}else if(clicked!=null)showMiniProfile(clicked);});
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(62),1);lp.setMargins(dp(1),dp(1),dp(1),dp(1));r.addView(tile,lp);
            }
            seats.addView(r,new LinearLayout.LayoutParams(-1,dp(64)));
        }
    }

    private LinearLayout seatTile(int seatNo,JSONObject x,boolean locked){
        LinearLayout v=col(); v.setGravity(Gravity.CENTER); v.setPadding(dp(1),dp(1),dp(1),dp(1)); v.setBackgroundColor(Color.TRANSPARENT);
        boolean occupied=x!=null,speaking=occupied&&x.optInt("speaking",0)==1;
        if(occupied){
            FrameLayout av=avatarWithMicState(x,dp(42),speaking); v.addView(av,new LinearLayout.LayoutParams(dp(42),dp(42)));
            String flair=x.optBoolean("roomAdmin",false)?"🛡 ":("ROYAL".equals(x.optString("tier"))?"♛ ":"");TextView nm=t(flair+shortName(x.optString("full_name","User")),7.5f,Color.WHITE,true); nm.setGravity(Gravity.CENTER); v.addView(nm,new LinearLayout.LayoutParams(-1,dp(14)));
        }else{
            FrameLayout stage=new FrameLayout(this); stage.addView(sofaIcon(locked),new FrameLayout.LayoutParams(dp(52),dp(44),Gravity.CENTER)); v.addView(stage,new LinearLayout.LayoutParams(dp(56),dp(55)));
        }
        return v;
    }

    private View sofaIcon(boolean locked){FrameLayout f=new FrameLayout(this);int gold=locked?Color.rgb(105,88,55):Color.rgb(235,166,32);int light=locked?Color.rgb(135,118,78):Color.rgb(255,221,91);View back=new View(this);back.setBackground(bg(gold,light,10));FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(44),dp(28),Gravity.TOP|Gravity.CENTER_HORIZONTAL);f.addView(back,bp);View left=new View(this);left.setBackground(bg(gold,light,8));FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(12),dp(28),Gravity.LEFT|Gravity.BOTTOM);f.addView(left,lp);View right=new View(this);right.setBackground(bg(gold,light,8));FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(dp(12),dp(28),Gravity.RIGHT|Gravity.BOTTOM);f.addView(right,rp);View base=new View(this);base.setBackground(bg(light,Color.rgb(255,235,130),8));FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(44),dp(15),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);f.addView(base,sp);return f;}

    private void toggleSeatLock(int seatNo,boolean locked){BackendClient.liveSeatLock(token(),seatNo,!locked,new ToastCb(!locked?"Seat locked":"Seat unlocked"));}


    private void renderHighlightComments(JSONArray arr){
        if(arr==null||arr.length()==0)return; JSONObject c=arr.optJSONObject(arr.length()-1); if(c==null)return; long hid=c.optLong("id",0); if(hid<=lastHighlightId)return; lastHighlightId=hid; final TextView banner=t("✨ "+c.optString("full_name","User")+": "+c.optString("message",""),11,Color.WHITE,true); banner.setPadding(dp(14),0,dp(14),0); banner.setGravity(Gravity.CENTER_VERTICAL); banner.setBackground(gradient(new int[]{Color.argb(235,76,34,145),Color.argb(235,184,54,156)},Color.rgb(255,209,92),18)); addContentView(banner,new android.view.ViewGroup.LayoutParams(dp(310),dp(42))); banner.setX(getResources().getDisplayMetrics().widthPixels); banner.setY(getResources().getDisplayMetrics().heightPixels*0.46f); banner.animate().translationX(-getResources().getDisplayMetrics().widthPixels-dp(340)).setDuration(6500).withEndAction(()->((android.view.ViewGroup)banner.getParent()).removeView(banner)).start();
    }

    private void renderRequests(JSONArray q){
        requests.removeAllViews();
        if(q==null||q.length()==0){requests.addView(t("No pending requests",11,Color.LTGRAY,false));return;}
        for(int i=0;i<q.length();i++){
            JSONObject x=q.optJSONObject(i);if(x==null)continue;
            LinearLayout rr=row();rr.setGravity(Gravity.CENTER_VERTICAL);
            String tier=x.optString("tier","STANDARD");long fan=x.optLong("fan_points",0);
            String badge="STANDARD".equals(tier)?"":(" • "+tier);
            TextView nm=t(x.optString("full_name","User")+badge+" • ID "+x.optString("user_id")+(fan>0?" • ⭐"+fan:""),10.5f,Color.WHITE,true);
            rr.addView(nm,new LinearLayout.LayoutParams(0,dp(36),1));
            Button ok=small("Accept"),no=small("Decline");String id=x.optString("user_id");
            ok.setOnClickListener(v->BackendClient.liveRequestAction(token(),id,true,new ToastCb("Speaker accepted")));
            no.setOnClickListener(v->BackendClient.liveRequestAction(token(),id,false,new ToastCb("Request declined")));
            rr.addView(ok,new LinearLayout.LayoutParams(dp(72),dp(38)));rr.addView(no,new LinearLayout.LayoutParams(dp(74),dp(38)));requests.addView(rr);
        }
    }

    private void renderComments(JSONArray comments,JSONArray events,JSONArray highlights){
        commentsList.removeAllViews();
        if(events!=null){int start=Math.max(0,events.length()-3);for(int i=start;i<events.length();i++){JSONObject e=events.optJSONObject(i);if(e==null)continue;TextView n=t("• "+e.optString("full_name","Someone")+" "+e.optString("message",""),10.5f,Color.rgb(181,202,250),false);n.setPadding(dp(8),dp(5),dp(8),dp(5));n.setBackground(bg(Color.argb(120,13,30,70),Color.argb(120,87,110,194),11));LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,-2);ep.bottomMargin=dp(4);commentsList.addView(n,ep);}}
        if(highlights!=null){for(int i=0;i<highlights.length();i++){JSONObject h=highlights.optJSONObject(i);if(h==null)continue;TextView hi=t("✨ "+h.optString("full_name","User")+" : "+h.optString("message",""),12.2f,Color.WHITE,true);hi.setPadding(dp(9),dp(6),dp(9),dp(6));hi.setBackground(gradient(new int[]{Color.argb(165,92,38,151),Color.argb(165,170,54,148)},Color.rgb(255,209,92),12));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.bottomMargin=dp(5);commentsList.addView(hi,hp);}}
        if((comments==null||comments.length()==0)&&pendingComments.isEmpty()){TextView empty=t("Comments will appear here",11.5f,Color.rgb(180,190,220),false);empty.setPadding(dp(8),dp(7),dp(8),dp(7));commentsList.addView(empty);return;}
        for(int i=0;i<comments.length();i++){
            JSONObject c=comments.optJSONObject(i);if(c==null)continue;
            String name=c.optString("full_name","User");int level=Math.max(0,c.optInt("level",0));String message=c.optString("message","");String tier=c.optString("tier","STANDARD");
            String prefix=("STANDARD".equals(tier)?"":tier+" • ")+name+"  LV."+level+" : ";
            android.text.SpannableStringBuilder line=new android.text.SpannableStringBuilder(prefix+message);
            line.setSpan(new android.text.style.StyleSpan(Typeface.BOLD),0,prefix.length(),android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            int prefixColor="ROYAL".equals(tier)?Color.rgb(255,214,78):"VVIP".equals(tier)?Color.rgb(229,121,255):"VIP".equals(tier)?Color.rgb(103,214,255):Color.rgb(109,221,255);line.setSpan(new android.text.style.ForegroundColorSpan(prefixColor),0,prefix.length(),android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            TextView row=t("",12.3f,Color.WHITE,false);row.setText(line);row.setLineSpacing(0,1.06f);row.setPadding(dp(9),dp(6),dp(9),dp(6));row.setBackground(bg(Color.argb(178,10,24,65),Color.argb(190,75,103,189),12));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(5);commentsList.addView(row,rp);
        }
        for(Map.Entry<String,String> e:pendingComments.entrySet()){TextView pr=t(SessionManager.getFullName(this)+"  LV.0 : "+e.getValue()+"   ⏳",12.3f,Color.WHITE,false);pr.setPadding(dp(9),dp(6),dp(9),dp(6));pr.setBackground(bg(Color.argb(185,36,42,91),Color.rgb(126,108,235),12));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(5);commentsList.addView(pr,rp);}
    }




    private void sendLiveComment(EditText input,TextView highlight){
        if(listenOnly){Toast.makeText(this,"Muted • listen and gift only",Toast.LENGTH_SHORT).show();return;}
        final String m=input.getText().toString().trim();if(m.isEmpty())return;
        final boolean hi=highlightSelected;final String nonce="c-"+SessionManager.getUserId(this)+"-"+UUID.randomUUID().toString();
        input.setText("");highlightSelected=false;highlight.setBackground(null);
        if(!hi){pendingComments.put(nonce,m);renderPendingOnly(nonce,m);}
        BackendClient.Callback cb=new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                pendingComments.remove(nonce);
                if(sendButton!=null){sendButton.setEnabled(true);sendButton.setText("Send");}
                if(!roomEnded&&!endLiveInProgress)refresh();
            });}
            public void onError(String e){runOnUiThread(()->{
                pendingComments.remove(nonce);
                if(sendButton!=null){sendButton.setEnabled(true);sendButton.setText("Send");}
                Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_SHORT).show();
                if(!roomEnded&&!endLiveInProgress)refresh();
            });}
        };
        if(hi)BackendClient.liveHighlightComment(token(),hostId,m,cb);else BackendClient.liveComment(token(),hostId,m,nonce,cb);
    }
    private void renderPendingOnly(String nonce,String message){
        if(commentsList==null)return;
        TextView pr=t(SessionManager.getFullName(this)+"  LV.0 : "+message,12.3f,Color.WHITE,false);
        pr.setTag("pending:"+nonce);pr.setPadding(dp(9),dp(6),dp(9),dp(6));
        pr.setBackground(bg(Color.argb(190,36,42,91),Color.rgb(126,108,235),12));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(5);commentsList.addView(pr,rp);
    }
    private void renderEntryEffects(JSONArray a){if(a==null||a.length()==0)return;JSONObject x=a.optJSONObject(a.length()-1);if(x==null)return;long id=x.optLong("id",0);if(id<=lastEntryEventId)return;lastEntryEventId=id;String tier=x.optString("tier","STANDARD");if("STANDARD".equals(tier))return;showFloatingBanner("✨ "+tier+" ENTRY • "+x.optString("full_name","Member"));}
    private void renderMilestones(JSONArray a){if(a==null)return;for(int i=0;i<a.length();i++){String k=a.optString(i,"");if(!k.isEmpty()&&shownMilestones.add(k))showFloatingBanner("🏆 "+k.replace('_',' '));}}
    private void showFloatingBanner(String text){final TextView b=t(text,12,Color.WHITE,true);b.setGravity(Gravity.CENTER);b.setBackground(gradient(new int[]{Color.argb(235,102,43,178),Color.argb(235,219,64,143)},Color.rgb(255,223,101),18));addContentView(b,new android.view.ViewGroup.LayoutParams(dp(300),dp(42)));b.setX((getResources().getDisplayMetrics().widthPixels-dp(300))/2f);b.setY(dp(110));b.setAlpha(0f);b.animate().alpha(1f).translationY(dp(10)).setDuration(220).withEndAction(()->handler.postDelayed(()->b.animate().alpha(0f).setDuration(350).withEndAction(()->{if(b.getParent()!=null)((android.view.ViewGroup)b.getParent()).removeView(b);}).start(),1800)).start();}
    private void showGiftEffect(JSONObject gift,JSONObject result){
        cachedGiftCatalog=null;
        final int combo=Math.max(1,result.optInt("combo",1));
        final String name=gift.optString("name","Gift"),sizeMode=gift.optString("size_mode","MEDIUM").toUpperCase(Locale.US);
        final int price=gift.optInt("price",0);
        final String receiver=result.optString("receiverId",hostId);
        final boolean rare="FULL_SCREEN".equals(sizeMode)||"LARGE".equals(sizeMode)||price>=1000;
        final String streak=combo>1?"  ×"+combo+" COMBO":"";
        if(rare){
            final FrameLayout overlay=new FrameLayout(this);overlay.setBackgroundColor(Color.argb(185,5,8,28));
            final LinearLayout card=col();card.setGravity(Gravity.CENTER);card.setPadding(dp(22),dp(22),dp(22),dp(22));card.setBackground(gradient(new int[]{Color.argb(245,71,37,154),Color.argb(245,210,52,142)},Color.rgb(255,220,96),26));
            ImageView art=new ImageView(this);art.setScaleType(ImageView.ScaleType.CENTER_INSIDE);String asset=gift.optString("animation_url","");if(asset.isEmpty())asset=gift.optString("preview_url","");if(!asset.isEmpty())AnimatedAssetLoader.load(art,asset);else art.setImageResource(android.R.drawable.ic_menu_gallery);
            card.addView(art,new LinearLayout.LayoutParams(dp(150),dp(150)));
            TextView title=t("🌟 "+name+streak,20,Color.WHITE,true);title.setGravity(Gravity.CENTER);card.addView(title,new LinearLayout.LayoutParams(-1,dp(48)));
            String target=receiver.equals(hostId)?currentLiveName:("ID "+receiver);TextView who=t(SessionManager.getFullName(this)+"  →  "+target,12,Color.rgb(255,233,159),true);who.setGravity(Gravity.CENTER);card.addView(who,new LinearLayout.LayoutParams(-1,dp(36)));
            FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(310),dp(270),Gravity.CENTER);overlay.addView(card,cp);
            addContentView(overlay,new android.view.ViewGroup.LayoutParams(-1,-1));overlay.setAlpha(0f);card.setScaleX(.82f);card.setScaleY(.82f);overlay.animate().alpha(1f).setDuration(180).start();card.animate().scaleX(1f).scaleY(1f).setDuration(260).start();
            handler.postDelayed(()->overlay.animate().alpha(0f).setDuration(320).withEndAction(()->{if(overlay.getParent()!=null)((android.view.ViewGroup)overlay.getParent()).removeView(overlay);}).start(),2200);
        }else showFloatingBanner("🎁 "+name+streak);
        prefetchGiftCatalog();refresh();
    }

    private void showMiniProfile(JSONObject u){String uid=u.optString("user_id",u.optString("userId",""));if(uid.isEmpty())return;String tier=u.optString("tier","STANDARD"),name=u.optString("full_name",u.optString("name","User"));String[] actions=uid.equals(hostId)?new String[]{"Open Creator Profile","Follow Host","Fan Club","⚑ Report / Block"}:new String[]{"Open Profile","Follow","Message","⚑ Report / Block"};new AlertDialog.Builder(this).setTitle(name+" • "+tier).setMessage("ID "+uid+"  •  LV."+u.optInt("level",0)+(u.optInt("fan_points",u.optInt("fanPoints",0))>0?"\n⭐ Fan Points "+u.optInt("fan_points",u.optInt("fanPoints",0)):"")).setItems(actions,(d,w)->{if(w==3){SafetyActions.show(this,uid,"LIVE_USER",hostId);return;}if(w==0){if(uid.equals(hostId))openCreatorCenter(uid);else{Intent i=new Intent(this,UserProfileActivity.class);i.putExtra("userId",uid);startActivity(i);}}else if(w==1){BackendClient.toggleFollow(token(),uid,new ToastCb("Follow updated"));}else if(uid.equals(hostId))showFanClub();else{Intent i=new Intent(this,ChatActivity.class);i.putExtra("userId",uid);i.putExtra("name",name);startActivity(i);}}).setNegativeButton("Close",null).show();}
    private void showLiveCommunityMenu(){new AlertDialog.Builder(this).setTitle("Live Community").setItems(new String[]{"Host Creator Profile","Fan Club / Supporters","Scheduled Lives","Follow Host"},(d,w)->{if(w==0)openCreatorCenter(hostId);else if(w==1)showFanClub();else if(w==2)showSchedules(hostId);else BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));}).show();}
    private void openCreatorCenter(String uid){Intent i=new Intent(this,CreatorCenterActivity.class);i.putExtra("userId",uid);startActivity(i);}
    private void showFanClub(){BackendClient.liveFanClub(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("members");StringBuilder z=new StringBuilder("Members: ").append(d.optInt("memberCount",0)).append("\nYour points: ").append(d.optLong("points",0)).append("\n\n");if(a!=null)for(int i=0;i<Math.min(8,a.length());i++){JSONObject x=a.optJSONObject(i);if(x!=null)z.append(i+1).append(". ").append(x.optString("full_name","User")).append(" • ").append(x.optLong("points",0)).append(" pts\n");}AlertDialog.Builder b=new AlertDialog.Builder(AudioLiveRoomActivity.this).setTitle("⭐ Fan Club").setMessage(z.toString()).setNegativeButton("Close",null);if(!host)b.setPositiveButton(d.optBoolean("joined",false)?"Leave Fan Club":"Join Fan Club",(q,w)->BackendClient.liveFanClubToggle(token(),hostId,new ToastCb("Fan Club updated")));b.show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}
    private void editWelcome(){EditText e=new EditText(this);e.setHint("Welcome message / room rules");new AlertDialog.Builder(this).setTitle("Room Welcome").setView(e).setPositiveButton("Save",(d,w)->BackendClient.livePremiumConfig(token(),e.getText().toString().trim(),null,-1,-1,new ToastCb("Welcome updated"))).setNegativeButton("Cancel",null).show();}
    private void editGoal(){String[] types={"COIN","SUPPORTERS","MINUTES","VIEWERS","NONE"};new AlertDialog.Builder(this).setTitle("Live Goal Type").setItems(types,(d,w)->{String type=types[w];if("NONE".equals(type)){BackendClient.livePremiumConfig(token(),null,"NONE",0,-1,new ToastCb("Goal cleared"));return;}EditText e=new EditText(this);e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);e.setHint("Target");new AlertDialog.Builder(this).setTitle(type+" target").setView(e).setPositiveButton("Save",(q,x)->{long target=0;try{target=Long.parseLong(e.getText().toString().trim());}catch(Exception ignored){}BackendClient.livePremiumConfig(token(),null,type,target,-1,new ToastCb("Live Goal updated"));}).setNegativeButton("Cancel",null).show();}).show();}
    private void choosePinnedProduct(){BackendClient.storeCatalog(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray raw=d.optJSONArray("products");if(raw==null)raw=d.optJSONArray("catalog");final JSONArray a=raw;if(a==null||a.length()==0){Toast.makeText(AudioLiveRoomActivity.this,"No enabled Shop items",Toast.LENGTH_SHORT).show();return;}String[] names=new String[a.length()+1];long[] ids=new long[a.length()+1];names[0]="Clear pinned product";ids[0]=0;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);names[i+1]=x==null?"Item":x.optString("title","Item")+" • "+x.optLong("coin_price",x.optLong("coinPrice",0))+" Coin";ids[i+1]=x==null?0:x.optLong("id",0);}new AlertDialog.Builder(AudioLiveRoomActivity.this).setTitle("🛍 Live Shop • Pin Item").setItems(names,(q,w)->BackendClient.livePremiumConfig(token(),null,null,-1,ids[w],new ToastCb(w==0?"Product pin cleared":"Product pinned"))).show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}
    private void showSchedules(String uid){BackendClient.liveSchedules(token(),uid,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("schedules");if(a==null||a.length()==0){Toast.makeText(AudioLiveRoomActivity.this,"No scheduled live",Toast.LENGTH_SHORT).show();return;}String[] x=new String[a.length()];for(int i=0;i<a.length();i++){JSONObject z=a.optJSONObject(i);x[i]=(z==null?"Scheduled Live":z.optString("title","Scheduled Live")+" • "+z.optString("scheduled_at",""));}new AlertDialog.Builder(AudioLiveRoomActivity.this).setTitle("🔔 Scheduled Lives").setItems(x,(q,w)->{JSONObject z=a.optJSONObject(w);if(z!=null&&!host)BackendClient.liveScheduleReminder(token(),z.optLong("id"),new ToastCb("Reminder updated"));}).setNegativeButton("Close",null).show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}
    private void showScheduleDialog(){LinearLayout box=col();EditText title=new EditText(this);title.setHint("Live title");EditText topic=new EditText(this);topic.setHint("Topic");EditText at=new EditText(this);at.setHint("YYYY-MM-DD HH:MM:SS");box.addView(title);box.addView(topic);box.addView(at);new AlertDialog.Builder(this).setTitle("🔔 Schedule Live").setView(box).setPositiveButton("Save",(d,w)->BackendClient.liveScheduleSave(token(),0,title.getText().toString().trim(),topic.getText().toString().trim(),at.getText().toString().trim(),new ToastCb("Live scheduled"))).setNeutralButton("View Schedules",(d,w)->showSchedules(hostId)).setNegativeButton("Cancel",null).show();}
    private void showPkDialog(){EditText e=new EditText(this);e.setHint("Other LIVE Host ID");e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);new AlertDialog.Builder(this).setTitle("⚔ Friendly PK / Battle").setMessage("Both hosts must already be live. V-304 foundation scores completed gifts during the PK.").setView(e).setPositiveButton("Invite",(d,w)->BackendClient.livePkStart(token(),e.getText().toString().trim(),new ToastCb("PK invitation sent"))).setNegativeButton("Cancel",null).show();}
    private void showIncomingPk(long id){new AlertDialog.Builder(this).setTitle("⚔ PK Invitation").setMessage("Another live host invited this room to a friendly PK.").setPositiveButton("Accept",(d,w)->BackendClient.livePkAction(token(),id,"ACCEPT",new ToastCb("PK started"))).setNegativeButton("Decline",(d,w)->BackendClient.livePkAction(token(),id,"DECLINE",new ToastCb("PK declined"))).show();}
    private void showAudienceEndSummary(){if(endedSummaryShown)return;endedSummaryShown=true;BackendClient.liveSummary(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONObject x=d.optJSONObject("summary");if(x!=null)showSummary(x);else{Toast.makeText(AudioLiveRoomActivity.this,"Live ended",Toast.LENGTH_SHORT).show();finish();}});}public void onError(String m){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,"Live ended",Toast.LENGTH_SHORT).show();finish();});}});}

    private void showSpeakerActions(JSONObject x){final String uid=x.optString("user_id","");final boolean special=uid.equals(specialGuestId);String[] actions=special?new String[]{"Remove from Special Guest","Remove Speaker from Seat"}:new String[]{"Make Special Guest","Remove Speaker from Seat"};new AlertDialog.Builder(this).setTitle(x.optString("full_name","Speaker")).setItems(actions,(d,which)->{if(which==0)BackendClient.liveSpecialGuest(token(),uid,special,new ToastCb(special?"Special Guest removed":"Special Guest selected"));else BackendClient.liveSpeakerRemove(token(),uid,new ToastCb("Speaker removed"));}).show();}
    private void clearSpecialGuest(){if(!host||specialGuestId.isEmpty())return;new AlertDialog.Builder(this).setTitle("Special Guest").setMessage("Return this guest to a normal speaker seat?").setPositiveButton("Remove Spotlight",(d,w)->BackendClient.liveSpecialGuest(token(),specialGuestId,true,new ToastCb("Spotlight cleared"))).setNegativeButton("Cancel",null).show();}

    private void confirmLeaveLive(){new AlertDialog.Builder(this).setTitle("Leave Live?").setMessage("Leave this live room?").setPositiveButton("Leave",(d,w)->finish()).setNegativeButton("Stay",null).show();}
    private void confirmEndLive(){
        if(endLiveInProgress||roomEnded)return;
        new AlertDialog.Builder(this).setTitle("End Live?").setMessage("This will end the room for everyone.")
                .setPositiveButton("End Live",(d,w)->endHostLive()).setNegativeButton("Cancel",null).show();
    }
    private void endHostLive(){
        if(endLiveInProgress||roomEnded)return;
        endLiveInProgress=true;hostStarted=false;
        handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);
        stopVoiceMonitor(false);
        syncState.setText("Ending live…");
        if(premiumStrip!=null)premiumStrip.setText("Ending live…");
        endHostLiveAttempt(1);
    }
    private void endHostLiveAttempt(final int attempt){
        if(roomEnded)return;
        BackendClient.endLive(token(),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                if(roomEnded)return;
                if(!d.optBoolean("closed",false)){
                    handler.postDelayed(()->endHostLiveAttempt(attempt+1),Math.min(3000L,500L+attempt*350L));
                    return;
                }
                roomEnded=true;endLiveInProgress=false;hostStarted=false;
                handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);pendingComments.clear();
                final JSONObject closeSummary=d.optJSONObject("summary");
                BackendClient.liveSummary(token(),hostId,new BackendClient.Callback(){
                    public void onSuccess(JSONObject ss){runOnUiThread(()->{JSONObject x=ss.optJSONObject("summary");if(x!=null)showSummary(x);else if(closeSummary!=null)showSummary(closeSummary);else showClosedWithoutSummary("The room is closed.");});}
                    public void onError(String m){runOnUiThread(()->{if(closeSummary!=null)showSummary(closeSummary);else showClosedWithoutSummary("The room is closed.");});}
                });
            });}
            public void onError(String m){
                if(roomEnded)return;
                // One tap is enough: keep retrying automatically. Do not return the room to LIVE/Reconnecting.
                handler.postDelayed(()->endHostLiveAttempt(attempt+1),Math.min(4000L,650L+attempt*450L));
            }
        });
    }
    private void endLiveFailed(String message){
        // V-311 compatibility method: never re-activate an End request.
        if(roomEnded)return;endLiveInProgress=true;hostStarted=false;syncState.setText("Ending live…");
        handler.postDelayed(()->endHostLiveAttempt(1),1200L);
    }
    private void showClosedWithoutSummary(String message){
        roomEnded=true;endLiveInProgress=false;syncState.setText("Live ended • server confirmed");hostStarted=false;
        handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);pendingComments.clear();
        new AlertDialog.Builder(this).setTitle("Live ended").setMessage(message).setPositiveButton("DONE",(d,w)->finish()).setCancelable(false).show();
    }

    private void showSummary(JSONObject x){
        if(x==null){showClosedWithoutSummary("The room is closed.");return;}
        long duration=Math.max(0,x.optLong("duration_seconds",x.optLong("elapsedSeconds",0)));
        long peak=Math.max(0,x.optLong("peak_viewers",x.optLong("peakViewers",0)));
        long listeners=Math.max(0,x.optLong("total_listeners",x.optLong("totalListeners",0)));
        long reactions=Math.max(0,x.optLong("react_count",x.optLong("reactCount",0)));
        String msg="Duration  "+hhmmss(duration)+"\nPeak viewers  "+peak+"\nListeners  "+listeners+"\nReactions  "+reactions;
        new AlertDialog.Builder(this).setTitle("Live ended").setMessage(msg).setPositiveButton("DONE",(d,w)->finish()).setCancelable(false).show();
    }

    private void renderPremiumState(JSONObject d){
        if(d==null||premiumStrip==null)return;
        String tier=d.optString("myTier",d.optString("membershipTier","")).trim();
        String role=d.optString("myRole",host?"HOST":"AUDIENCE");
        String net=networkQuality();
        StringBuilder line=new StringBuilder("✦ ").append(role).append(" • ").append(net);
        if(!tier.isEmpty()&&!"FREE".equalsIgnoreCase(tier))line.append(" • ").append(tier);
        premiumStrip.setText(line.toString());
    }

    private JSONObject findSeat(JSONArray a,int seatNo){if(a==null)return null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&x.optInt("seat_no")==seatNo)return x;}return null;}
    private JSONObject findUser(JSONArray a,String userId){if(a==null||userId==null||userId.isEmpty())return null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&userId.equals(x.optString("user_id")))return x;}return null;}

    private FrameLayout avatarWithMicState(JSONObject x,int size,boolean speaking){
        FrameLayout wrap=new FrameLayout(this);
        String url=x==null?"":x.optString("avatar_url","");
        String tier=x==null?"STANDARD":x.optString("tier","STANDARD");
        FrameLayout av=circleAvatar(url,size,speaking,tier);wrap.addView(av,new FrameLayout.LayoutParams(-1,-1));
        boolean muted=x!=null&&(x.optInt("mic_on",1)==0||x.optInt("muted",0)==1);
        if(muted){TextView m=t("🎙✕",Math.max(6.8f,size/7.0f),Color.rgb(255,82,94),true);m.setGravity(Gravity.CENTER);m.setBackground(bg(Color.argb(225,45,10,24),Color.rgb(255,70,84),9));FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(24),dp(16),Gravity.RIGHT|Gravity.BOTTOM);mp.rightMargin=-dp(2);mp.bottomMargin=-dp(1);wrap.addView(m,mp);}
        return wrap;
    }

    private FrameLayout circleAvatar(String url,int size,boolean speaking){return circleAvatar(url,size,speaking,"STANDARD");}
    private FrameLayout circleAvatar(String url,int size,boolean speaking,String tier){FrameLayout frame=new FrameLayout(this);int premiumStroke="ROYAL".equals(tier)?Color.rgb(255,203,69):"VVIP".equals(tier)?Color.rgb(221,91,255):"VIP".equals(tier)?Color.rgb(79,170,255):Color.rgb(163,93,255);int stroke=speaking?Color.rgb(48,244,255):premiumStroke;frame.setBackground(bg(Color.argb(210,25,33,82),stroke,size/2));ImageView v=new ImageView(this);v.setImageResource(android.R.drawable.sym_def_app_icon);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(bg(Color.rgb(34,45,105),stroke,size/2));v.setClipToOutline(true);int pad=dp(speaking?4:("STANDARD".equals(tier)?3:4));FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,-1);ip.setMargins(pad,pad,pad,pad);frame.addView(v,ip);if(url!=null&&!url.trim().isEmpty())loadImage(v,url);if(speaking){final ObjectAnimator sx=ObjectAnimator.ofFloat(frame,"scaleX",1f,1.12f);final ObjectAnimator sy=ObjectAnimator.ofFloat(frame,"scaleY",1f,1.12f);sx.setDuration(430);sy.setDuration(430);sx.setRepeatMode(ValueAnimator.REVERSE);sy.setRepeatMode(ValueAnimator.REVERSE);sx.setRepeatCount(ValueAnimator.INFINITE);sy.setRepeatCount(ValueAnimator.INFINITE);sx.start();sy.start();frame.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View v){}public void onViewDetachedFromWindow(View v){sx.cancel();sy.cancel();}});}return frame;}
    private void loadImage(ImageView v,String u){new Thread(()->{try{Bitmap b=BitmapFactory.decodeStream(new URL(u).openStream());if(b!=null)runOnUiThread(()->v.setImageBitmap(b));}catch(Exception ignored){}}).start();}

    private String networkQuality(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);NetworkInfo n=cm==null?null:cm.getActiveNetworkInfo();if(n==null||!n.isConnected())return "OFFLINE";return n.getType()==ConnectivityManager.TYPE_WIFI?"GOOD":"FAIR";}catch(Exception e){return "GOOD";}}
    private String signal(String q){q=q==null?"GOOD":q.toUpperCase();if("WEAK".equals(q)||"OFFLINE".equals(q))return "▂";if("FAIR".equals(q))return "▂▄";return "▂▄▆";}
    private long parseServerTime(String s){if(s==null||s.trim().isEmpty())return 0;String[] patterns={"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd'T'HH:mm:ss.SSS'Z'","yyyy-MM-dd'T'HH:mm:ss'Z'"};for(String p:patterns){try{SimpleDateFormat f=new SimpleDateFormat(p,Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));Date d=f.parse(s);if(d!=null)return d.getTime();}catch(Exception ignored){}}return 0;}
    private String summaryTime(String s){if(s==null||s.trim().isEmpty())return "—";String x=s.trim();return x.length()>=19?x.substring(11,19):x;}
    private String hhmm(long sec){long h=sec/3600,m=(sec%3600)/60;return String.format(Locale.US,"%02d:%02d",h,m);}
    private String hhmmss(long sec){long h=sec/3600,m=(sec%3600)/60,s=sec%60;return String.format(Locale.US,"%02d:%02d:%02d",h,m,s);}
    private String token(){return SessionManager.getToken(this);}

    @Override public void onBackPressed(){ if(host) confirmEndLive(); else confirmLeaveLive(); }
    @Override protected void onDestroy(){handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);activeSessionId="";serverElapsedSec=0;serverElapsedSyncMs=0;pendingComments.clear();stopVoiceMonitor(false);if(giftLoadingDialog!=null&&giftLoadingDialog.isShowing())giftLoadingDialog.dismiss();if(host){if(hostStarted||endLiveInProgress)BackendClient.setLivePresence(token(),false,new Silent());}else{BackendClient.liveLeaveSeat(token(),hostId,new Silent());BackendClient.liveViewer(token(),hostId,false,new Silent());}super.onDestroy();}


    private class GoldenGuestHalo extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF oval=new RectF();
        GoldenGuestHalo(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f;float r=Math.min(w,h)*.36f;
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2.2f));p.setColor(Color.rgb(255,194,47));p.setShadowLayer(dp(8),0,0,Color.rgb(255,139,22));c.drawCircle(cx,cy,r,p);p.clearShadowLayer();
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(255,190,42));
            for(int side=-1;side<=1;side+=2){for(int i=0;i<7;i++){float y=cy-r*.72f+i*r*.24f;float x=cx+side*(r+dp(5)+i*dp(.7f));c.save();c.rotate(side*(-32+i*5),x,y);oval.set(x-dp(5),y-dp(2.3f),x+dp(5),y+dp(2.3f));c.drawOval(oval,p);c.restore();}}
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));p.setColor(Color.rgb(255,221,97));oval.set(cx-r-dp(10),cy+r*.66f,cx+r+dp(10),cy+r+dp(12));c.drawArc(oval,188,164,false,p);
        }
    }

    class ToastCb implements BackendClient.Callback{String ok;ToastCb(String s){ok=s;}public void onSuccess(JSONObject d){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,ok,Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}}
    static class Silent implements BackendClient.Callback{public void onSuccess(JSONObject d){}public void onError(String m){}}

    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private Button btn(String s){Button b=new Button(this);b.setAllCaps(false);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setBackground(bg(Color.rgb(76,45,205),Color.rgb(217,46,255),18));return b;}
    private Button small(String s){Button b=btn(s);b.setTextSize(9.5f);b.setMinWidth(0);b.setMinimumWidth(0);return b;}
    private TextView t(String s,float z,int c,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private GradientDrawable bg(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private GradientDrawable gradient(int[] colors,int stroke,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private int dp(float x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
}
