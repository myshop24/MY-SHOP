# MY SHOP Developer Handoff — V-289

## NEXT START HERE
Use **V-289** as the current source. This version implements the owner's final approved Audio Live Room visual layout. Do not move the active-user strip, Special Guest timer/label, Gift/React stack, speaker grid, or bottom controls unless the owner explicitly requests a new change. The next major technical phase remains real Agora/equivalent Audio RTC integration after installed-device visual/behavior QA.

## Exact approved V-289 visual lock
1. Host profile/info is upper-left and has no surrounding card/border box.
2. Active users are on the **same horizontal line as the Host name/info**, directly to its right — never in a second row below.
3. Show up to **6 active user profiles** directly. Remaining users are accessed from exactly one `>` control on the far-right.
4. The active-user strip uses real backend `viewerProfiles`; never fabricate users to fill empty slots.
5. Special Guest is centered below the Host/user header line.
6. Small HH:MM timer is positioned to the **left side of the Guest profile icon**.
7. `✨ SPECIAL GUEST ✨` is placed **below** the Guest icon.
8. No helper/explanatory text below Special Guest.
9. Speaker stage = exactly **10 positions in 5 + 5**. Occupied position = circular speaker profile; empty position = golden sofa. No visible `Seat N` labels.
10. Gift/React are vertical on the right of comments: **Gift above, React below**. They sit immediately above/alongside the comment composer, not inside/clipped by bottom navigation.
11. Comment composer + Send remains compact.
12. Bottom controls remain one line and fully visible. No Live Room vertical scrolling.

## Completed in V-289
- Moved real active-user profile strip into the Host header line.
- Header supports 6 directly visible users + one `>` overflow control.
- Added full active-user list dialog from `>`.
- Removed separate audience row below Host.
- Removed Host card background/border box.
- Rebuilt Special Guest composition: timer-left / guest-center / label-below.
- Removed `Host can spotlight a speaker here` helper text.
- Occupied speaker positions now show profiles directly; empty positions show golden sofas.
- Preserved 10 speaker positions / backend seats 2–11.
- Moved Gift/React out of bottom-control container into right-side comment area; Gift is above React.
- Reduced bottom control container to a single compact row.
- Audience Request-to-Speak now uses the first bottom compact control, avoiding a separate full-width row.
- No fake/static viewers; backend remains authoritative.

## Preserved backend/API behavior
- `/v1/live/room` returns `viewerProfiles` from active `myshop_live_viewers` heartbeat rows.
- Host is authoritative seat 1; speaker positions remain 2–11.
- Seat locks, requests, special guest selection, comments, pinned message, theme configuration, share count, participant state and live summary remain preserved.
- Historical D1 migration `backend/worker/migrations/0009_v287_expand_live_speakers_to_10.sql` remains unchanged.

## Known limitations / testing
- Real Agora RTC media transport is NOT integrated yet. Mic/speaking/network values are state/control hooks only.
- This environment does not contain the full Android/Gradle dependency toolchain; do not claim APK compilation passed until GitHub/Android build compiles it.
- Installed-device QA is still required for different Android screen sizes, system navigation insets, avatar loading, 6-user header fit, `>` overflow list, comments, and bottom-control visibility.
- If GitHub Actions fails, inspect the exact failing step/log before creating another version.

## Primary references
- `docs/reference/V-289-APPROVED-LIVE-ROOM-REFERENCE.png` — owner's final approved visual direction from this conversation. Reference only; not packaged as an Android runtime drawable.
- `122024.mp4` — compact live-room behavior/layout reference (ideas only; do not copy proprietary UI/code).
- User example screenshots `122051.jpg` / `122052.jpg` — compact seat/profile placement reference.

## Version identity
- Build: MY SHOP V-289
- Android versionCode: 289
- Android versionName: 2.9.289
- Worker health: 2.9.289 / V-289
