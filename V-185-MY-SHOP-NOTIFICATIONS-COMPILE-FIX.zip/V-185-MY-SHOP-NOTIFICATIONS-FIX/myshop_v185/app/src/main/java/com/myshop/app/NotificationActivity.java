package com.myshop.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;

/** In-app notification inbox. Opening the inbox marks currently returned notifications as seen. */
public class NotificationActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(248,249,253), BLUE=Color.rgb(46,47,190), NAVY=Color.rgb(18,32,75), DARK=Color.rgb(35,38,52), MUTED=Color.rgb(105,110,125);
    private LinearLayout list;
    private TextView errorText;
    private final Handler handler=new Handler();
    private final Runnable refreshPoll=new Runnable(){
        @Override public void run(){
            load();
            handler.postDelayed(this,15000);
        }
    };

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(build());
        load();
    }

    private View build(){
        LinearLayout root=col(); root.setBackgroundColor(BG); root.setPadding(dp(12),dp(10),dp(12),dp(14));
        LinearLayout head=row();
        Button back=button("‹",NAVY,28,true); back.setOnClickListener(v->finish()); head.addView(back,lp(dp(44),dp(48)));
        TextView title=txt("Notifications",NAVY,19,true); title.setGravity(Gravity.CENTER_VERTICAL); head.addView(title,weight(1,dp(48)));
        TextView refresh=txt("Refresh",BLUE,10,true); refresh.setGravity(Gravity.CENTER); refresh.setBackground(round(Color.WHITE,Color.rgb(225,226,235),dp(16))); refresh.setOnClickListener(v->load()); head.addView(refresh,lp(dp(70),dp(36))); TextView mark=txt("Mark seen",BLUE,10,true); mark.setGravity(Gravity.CENTER); mark.setBackground(round(Color.WHITE,Color.rgb(225,226,235),dp(16))); mark.setOnClickListener(v->markRead()); head.addView(mark,lp(dp(82),dp(36)));
        root.addView(head);
        TextView sub=txt("নতুন আপডেটগুলো এখানে দেখা যাবে",MUTED,10,false); sub.setPadding(dp(6),0,dp(6),dp(4)); root.addView(sub,lp(-1,dp(24))); errorText=txt("",Color.rgb(185,40,50),10,false); errorText.setGravity(Gravity.CENTER); root.addView(errorText,lp(-1,dp(24)));
        ScrollView sv=new ScrollView(this); sv.setVerticalScrollBarEnabled(false); list=col(); sv.addView(list,new ScrollView.LayoutParams(-1,-2)); root.addView(sv,weight(1,0));
        return root;
    }

    private void load(){
        String token=SessionManager.getToken(this); if(token==null||token.isEmpty()){empty("লগইন করলে নোটিফিকেশন দেখা যাবে");return;}
        BackendClient.notifications(token,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){ runOnUiThread(()->{ errorText.setText(""); JSONArray ns=d.optJSONArray("notifications");
                    render(ns);
                    if((ns==null || ns.length()==0) && d.optInt("unreadCount",0)>0) empty("নতুন নোটিফিকেশন আছে, কিন্তু তালিকা লোড হয়নি — Retry চাপুন"); }); }
            public void onError(String m){ runOnUiThread(()->{ errorText.setText("Error: "+m+"   •   Retry"); errorText.setOnClickListener(v->load()); empty("নোটিফিকেশন এখন লোড করা যাচ্ছে না"); }); }
        });
    }


    private void render(JSONArray a){
        list.removeAllViews();
        if(a==null||a.length()==0){ empty("এখন কোনো নতুন নোটিফিকেশন নেই"); return; }
        for(int i=0;i<a.length();i++){
            JSONObject o=a.optJSONObject(i); if(o==null)continue;
            boolean unread=o.optInt("isRead",0)==0;
            LinearLayout card=col(); card.setPadding(dp(12),dp(10),dp(12),dp(10)); card.setBackground(round(unread?Color.WHITE:Color.rgb(243,244,248),Color.rgb(229,230,236),dp(14))); card.setElevation(dp(1));
            LinearLayout top=row(); TextView t=txt(o.optString("title","MY SHOP"),DARK,13,true); top.addView(t,weight(1,dp(28))); if(unread){TextView dot=txt("●",BLUE,11,true);dot.setGravity(Gravity.CENTER);top.addView(dot,lp(dp(22),dp(28)));} card.addView(top);
            TextView m=txt(o.optString("message",""),Color.rgb(70,74,88),11,false); m.setPadding(0,dp(2),0,dp(3)); card.addView(m,lp(-1,-2));
            String when=o.optString("createdAt",""); TextView d=txt(when,MUTED,8,false); card.addView(d,lp(-1,dp(18)));
            list.addView(card,lp(-1,-2)); if(i<a.length()-1)list.addView(space(),lp(1,dp(7)));
        }
    }

    @Override protected void onResume(){ super.onResume(); load(); handler.removeCallbacks(refreshPoll); handler.postDelayed(refreshPoll,15000); }
    @Override protected void onPause(){ super.onPause(); handler.removeCallbacks(refreshPoll); }

    private void markRead(){
        String token=SessionManager.getToken(this); if(token==null||token.isEmpty())return;
        BackendClient.markNotificationsRead(token,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){ runOnUiThread(()->{errorText.setText("✓ Seen");load();}); }
            public void onError(String m){ runOnUiThread(()->errorText.setText("Mark seen failed: "+m)); }
        });
    }

    private void empty(String s){ list.removeAllViews(); TextView t=txt(s,MUTED,12,false);t.setGravity(Gravity.CENTER);list.addView(t,lp(-1,dp(120))); }
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView txt(String s,int c,float z,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button button(String s,int c,float z,boolean b){Button v=new Button(this);v.setText(s);v.setTextColor(c);v.setTextSize(z);if(b)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setBackgroundColor(Color.TRANSPARENT);return v;}
    private GradientDrawable round(int fill,int stroke,int r){GradientDrawable g=new GradientDrawable();g.setColor(fill);if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);g.setCornerRadius(dp(r));return g;}
    private View space(){return new View(this);}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
