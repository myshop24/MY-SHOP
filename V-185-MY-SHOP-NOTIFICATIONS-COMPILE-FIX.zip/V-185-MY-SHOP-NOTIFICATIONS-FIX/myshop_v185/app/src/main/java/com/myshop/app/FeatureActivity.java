package com.myshop.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import org.json.JSONArray;
import org.json.JSONObject;
import androidx.appcompat.app.AppCompatActivity;

public class FeatureActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String title = getIntent().getStringExtra("title");
        if (title == null || title.trim().isEmpty()) title = "MY SHOP";

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 42, 28, 28);
        root.setBackgroundColor(getColor(R.color.myshop_bg));

        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextSize(27);
        heading.setTextColor(getColor(R.color.myshop_dark));
        heading.setGravity(Gravity.CENTER);
        root.addView(heading, new LinearLayout.LayoutParams(-1, 100));

        TextView status = new TextView(this);
        status.setText("MY SHOP module frame\n\nThis feature is ready for backend-driven content. Where supported, Admin changes can be delivered without rebuilding the APK.");
        status.setTextSize(17);
        status.setTextColor(getColor(R.color.text_muted));
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, 44));

        String featureKey=getIntent().getStringExtra("feature_key");
        if ("more_apps".equals(featureKey)) {
            renderMore(root,status);
        }
        if ("external_movie".equals(featureKey)) {
            status.setText("Loading External Movies…");
            BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->renderExternalMovies(root,status,d.optJSONArray("managedLinks")));}
                public void onError(String m){runOnUiThread(()->status.setText("External Movies unavailable: "+m));}
            });
        }
        if ("help_support".equals(featureKey)) {
            status.setText("Loading Customer Support…");
            BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->renderSupport(root,status,d.optJSONArray("managedLinks")));}
                public void onError(String m){runOnUiThread(()->status.setText("Customer support is not configured yet."));}
            });
        }

        if ("social_media".equals(featureKey)) {
            status.setText("Loading Social Media…");
            BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->renderSocial(root,status,d.optJSONArray("socialLinks")));}
                public void onError(String m){runOnUiThread(()->status.setText("Social links unavailable: "+m));}
            });
        }

        String url = getIntent().getStringExtra("url");
        if (FeatureRegistry.isSafeHttpUrl(url)) {
            Button open = new Button(this);
            open.setText("Open Link");
            open.setOnClickListener(v -> openUrl(url));
            root.addView(open, new LinearLayout.LayoutParams(-1, 58));
        }

        Button back = new Button(this);
        back.setText("Back");
        back.setOnClickListener(v -> finish());
        root.addView(back, new LinearLayout.LayoutParams(-1, 58));
        setContentView(root);
    }



    private int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private GradientDrawable roundedBg(int fill, int stroke, int radius){
        GradientDrawable g=new GradientDrawable(); g.setColor(fill); g.setCornerRadius(dp(radius));
        if(stroke!=0) g.setStroke(dp(1),stroke); return g;
    }
    private void applyRipple(View v){
        if(android.os.Build.VERSION.SDK_INT>=21){
            android.util.TypedValue tv=new android.util.TypedValue();
            getTheme().resolveAttribute(android.R.attr.colorControlHighlight,tv,true);
            android.graphics.drawable.Drawable base=v.getBackground();
            if(base!=null)v.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(Color.argb(42,30,55,120)),base,null));
        }
    }

    private void renderExternalMovies(LinearLayout root, TextView status, JSONArray a){
        status.setText(""); int count=0;
        if(a!=null) for(int i=0;i<a.length()&&count<6;i++){JSONObject x=a.optJSONObject(i);if(x==null||!"external_movie".equalsIgnoreCase(x.optString("category",""))||x.optInt("active",1)!=1)continue;String title=x.optString("title","External Movie").trim();String url=x.optString("url","").trim();if(url.isEmpty())continue;addMoreButton(root,title,"Open External Movie",v->openUrl(url));count++;}
        if(count==0)status.setText("No External Movie links have been configured yet.");
    }

    private void renderMore(LinearLayout root, TextView status){
        status.setVisibility(TextView.VISIBLE);
        status.setText("Loading…");
        LinearLayout content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(2),dp(4),dp(2),dp(14));

        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.addView(content,new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll,1,new LinearLayout.LayoutParams(-1,0,1));

        TextView hint=new TextView(this);
        hint.setText("Connect with MY SHOP"); hint.setTextSize(14); hint.setTextColor(Color.rgb(105,111,130));
        hint.setPadding(dp(4),dp(2),dp(4),dp(10));
        content.addView(hint,new LinearLayout.LayoutParams(-1,dp(30)));

        final String[] wanted={"Facebook","Page","YouTube","WhatsApp","imo","Instagram","Telegram"};
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                JSONArray social=d.optJSONArray("socialLinks");
                for(String w:wanted){
                    String target="";
                    if(social!=null) for(int i=0;i<social.length();i++){
                        JSONObject x=social.optJSONObject(i);
                        if(x!=null && w.equalsIgnoreCase(x.optString("platform","")) && x.optInt("active",1)==1){
                            String u=x.optString("url","").trim();
                            String normalized=normalizePlatformTarget(w,u); if(!normalized.isEmpty()){target=normalized;break;}
                        }
                    }
                    addPlatformButton(content,w,target);
                }
                addMoreButton(content,"CUSTOMER SUPPORT","Contact MY SHOP support",v->{
                    Intent i=new Intent(FeatureActivity.this,FeatureActivity.class);
                    i.putExtra("title","CUSTOMER SUPPORT"); i.putExtra("feature_key","help_support"); startActivity(i);
                });
                addMoreButton(content,"SHARE APP","Share MY SHOP with friends",v->shareApp());
            });}
            public void onError(String m){runOnUiThread(()->{
                for(String w:wanted) addPlatformButton(content,w,"");
                addMoreButton(content,"CUSTOMER SUPPORT","Contact MY SHOP support",v->{
                    Intent i=new Intent(FeatureActivity.this,FeatureActivity.class);
                    i.putExtra("title","CUSTOMER SUPPORT"); i.putExtra("feature_key","help_support"); startActivity(i);
                });
                addMoreButton(content,"SHARE APP","Share MY SHOP with friends",v->shareApp());
            });}
        });
    }

    private void addPlatformButton(LinearLayout root,String platform,String url){
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14),dp(6),dp(10),dp(6));
        card.setBackground(roundedBg(Color.WHITE,Color.rgb(232,234,240),16));
        card.setElevation(dp(3)); applyRipple(card);

        TextView icon=new TextView(this);
        icon.setText(platformIcon(platform)); icon.setTextSize(23); icon.setGravity(Gravity.CENTER);
        icon.setTextColor(Color.rgb(48,54,75));
        icon.setBackground(roundedBg(Color.rgb(242,244,248),0,14));
        card.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));

        LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); texts.setGravity(Gravity.CENTER_VERTICAL);
        TextView name=new TextView(this); name.setText(platform); name.setTextSize(16); name.setTextColor(Color.rgb(24,29,62)); name.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        TextView sub=new TextView(this); sub.setText(!url.isEmpty()?"Open":"Not configured"); sub.setTextSize(11); sub.setTextColor(!url.isEmpty()?Color.rgb(91,96,112):Color.rgb(160,164,175));
        texts.addView(name,new LinearLayout.LayoutParams(-1,dp(24))); texts.addView(sub,new LinearLayout.LayoutParams(-1,dp(18)));
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(58),1); tp.setMargins(dp(12),0,dp(6),0); card.addView(texts,tp);

        TextView go=new TextView(this); go.setText(!url.isEmpty()?"›":"—"); go.setTextSize(27); go.setTextColor(!url.isEmpty()?Color.rgb(83,32,180):Color.rgb(170,174,185)); go.setGravity(Gravity.CENTER);
        card.addView(go,new LinearLayout.LayoutParams(dp(30),dp(58)));
        if(!url.isEmpty()) card.setOnClickListener(v->openUrl(url)); else card.setAlpha(0.82f);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(72)); cp.setMargins(0,0,0,dp(10)); root.addView(card,cp);
    }

    private String platformIcon(String p){
        String s=p.toLowerCase();
        if(s.contains("facebook"))return "F";
        if(s.equals("page"))return "P";
        if(s.contains("youtube"))return "▶";
        if(s.contains("whatsapp"))return "◉";
        if(s.contains("imo"))return "i";
        if(s.contains("instagram"))return "◎";
        if(s.contains("telegram"))return "✈";
        return "•";
    }

    private void addMoreButton(LinearLayout root,String title,String desc,android.view.View.OnClickListener listener){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14),dp(6),dp(12),dp(6)); card.setBackground(roundedBg(Color.WHITE,Color.rgb(232,234,240),16)); card.setElevation(dp(3)); applyRipple(card);
        TextView icon=new TextView(this); icon.setText(title.contains("SUPPORT")?"?":"↗"); icon.setTextSize(22); icon.setGravity(Gravity.CENTER); icon.setTextColor(Color.rgb(83,32,180)); icon.setBackground(roundedBg(Color.rgb(242,244,248),0,14));
        card.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); texts.setGravity(Gravity.CENTER_VERTICAL);
        TextView t=new TextView(this); t.setText(title); t.setTextSize(16); t.setTextColor(Color.rgb(24,29,62)); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        TextView d=new TextView(this); d.setText(desc); d.setTextSize(11); d.setTextColor(Color.rgb(105,111,130));
        texts.addView(t,new LinearLayout.LayoutParams(-1,dp(24))); texts.addView(d,new LinearLayout.LayoutParams(-1,dp(18)));
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(58),1); tp.setMargins(dp(12),0,dp(6),0); card.addView(texts,tp);
        TextView go=new TextView(this); go.setText("›"); go.setTextSize(27); go.setTextColor(Color.rgb(83,32,180)); go.setGravity(Gravity.CENTER); card.addView(go,new LinearLayout.LayoutParams(dp(30),dp(58)));
        card.setOnClickListener(listener); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(72)); cp.setMargins(0,0,0,dp(10)); root.addView(card,cp);
    }

    private void shareApp(){
        try{ Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_SUBJECT,"MY SHOP"); i.putExtra(Intent.EXTRA_TEXT,"MY SHOP — https://rapid-bush-62ea.myshopsatkania.workers.dev"); startActivity(Intent.createChooser(i,"Share MY SHOP")); }
        catch(Exception e){ Toast.makeText(this,"Share is not available.",Toast.LENGTH_SHORT).show(); }
    }

    private void renderSupport(LinearLayout root,TextView status,JSONArray a){
        status.setText(""); int count=0;
        if(a!=null) for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String cat=x.optString("category","");String url=x.optString("url","").trim();String title=x.optString("title","Customer Support");if(!"help_support".equals(cat))continue;final String target=normalizeWhatsApp(url);if(target.isEmpty())continue;Button b=actionButton("💬  "+title,Color.rgb(24,169,98));b.setOnClickListener(v->openUrl(target));root.addView(b,new LinearLayout.LayoutParams(-1,dp(52)));count++;}
        if(count==0)status.setText("Customer support link has not been configured by Admin yet.");
    }

    private void renderSocial(LinearLayout root,TextView status,JSONArray a){
        status.setText("");
        int count=0;
        if(a!=null) for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String platform=x.optString("platform","").trim();String url=x.optString("url","").trim();if(platform.isEmpty()||!FeatureRegistry.isSafeHttpUrl(url))continue;LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(10,4,10,4);ImageView icon=new ImageView(this);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setImageResource(R.drawable.feature_social_selected);row.addView(icon,new LinearLayout.LayoutParams(48,48));LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);TextView name=new TextView(this);name.setText(platform);name.setTextSize(14);name.setTextColor(Color.rgb(24,29,62));name.setTypeface(Typeface.DEFAULT,Typeface.BOLD);TextView domain=new TextView(this);domain.setText(url);domain.setTextSize(9);domain.setTextColor(Color.rgb(105,111,130));box.addView(name);box.addView(domain);row.addView(box,new LinearLayout.LayoutParams(0,56,1));row.setOnClickListener(v->openUrl(url));icon.setContentDescription(platform+" icon");root.addView(row,new LinearLayout.LayoutParams(-1,64));count++;}
        if(count==0) status.setText("No social links have been saved by Admin yet.");
    }
    private String normalizePlatformTarget(String platform,String raw){
        String v=raw==null?"":raw.trim(); if(v.isEmpty())return "";
        if(v.startsWith("http://")||v.startsWith("https://"))return v;
        String digits=v.replaceAll("[^0-9]","");
        if(digits.length()<8)return "";
        if(platform.equalsIgnoreCase("WhatsApp"))return "https://wa.me/"+digits;
        if(platform.equalsIgnoreCase("imo"))return "tel:"+digits;
        return "";
    }
    private String normalizeWhatsApp(String raw){return normalizePlatformTarget("WhatsApp",raw);}
    private Button actionButton(String label,int color){Button b=new Button(this);b.setText(label);b.setTextSize(13);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setGravity(Gravity.CENTER);b.setPadding(dp(12),0,dp(12),0);b.setBackground(roundedBg(color,0,14));b.setElevation(dp(2));applyRipple(b);return b;}

    private void loadSocialIcon(ImageView target,String url,String platform){Executors.newSingleThreadExecutor().execute(()->{try{String host=new URL(url).getHost();if(host==null||host.isEmpty())throw new Exception("no host");String iconUrl="https://www.google.com/s2/favicons?sz=128&domain_url="+java.net.URLEncoder.encode("https://"+host,"UTF-8");HttpURLConnection c=(HttpURLConnection)new URL(iconUrl).openConnection();c.setConnectTimeout(6000);c.setReadTimeout(8000);c.setInstanceFollowRedirects(true);try(InputStream in=c.getInputStream()){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null)runOnUiThread(()->target.setImageBitmap(b));}}catch(Exception ignored){}});}
    private String socialIcon(String p){String s=p.toLowerCase();if(s.contains("facebook"))return "ⓕ";if(s.contains("youtube"))return "▶";if(s.contains("tiktok"))return "♪";if(s.contains("instagram"))return "◎";if(s.contains("whatsapp"))return "◉";if(s.contains("telegram"))return "✈";return "●";}

    private void openUrl(String value) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(value.trim())));
        } catch (Exception e) {
            Toast.makeText(this, "Unable to open link.", Toast.LENGTH_SHORT).show();
        }
    }
}
