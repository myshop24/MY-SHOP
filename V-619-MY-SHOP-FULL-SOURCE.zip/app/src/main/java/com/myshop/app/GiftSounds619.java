package com.myshop.app;
import android.content.Context;import android.media.MediaPlayer;
final class GiftSounds619 {
 static int resource(Context c,String url){if(url==null||!url.startsWith("myshop-sound619://"))return 0;String type=url.substring("myshop-sound619://".length());for(String allowed:GiftMesh619.TYPES)if(allowed.equals(type))return c.getResources().getIdentifier("gift619_"+type,"raw",c.getPackageName());return 0;}
 static void configure(Context c,MediaPlayer player,String url)throws Exception{if(url.startsWith("myshop-sound619://")){int id=resource(c,url);if(id==0)throw new IllegalArgumentException("Unknown sample sound");try(android.content.res.AssetFileDescriptor file=c.getResources().openRawResourceFd(id)){if(file==null)throw new IllegalArgumentException("Missing sample sound");player.setDataSource(file.getFileDescriptor(),file.getStartOffset(),file.getLength());}}else player.setDataSource(url);}
}
