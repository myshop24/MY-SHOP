from pathlib import Path
import json, re, zipfile
root=Path(__file__).resolve().parents[1]
build=(root/'app/build.gradle').read_text()
assert "versionCode 72" in build
assert "versionName '2.9.72'" in build
assert "applicationId 'com.myshop.app'" in build
login=(root/'app/src/main/java/com/myshop/app/LoginActivity.java').read_text()
reg=(root/'app/src/main/java/com/myshop/app/RegisterActivity.java').read_text()
store=(root/'app/src/main/java/com/myshop/app/AccountStore.java').read_text()
uid=(root/'app/src/main/java/com/myshop/app/UserIdManager.java').read_text()
admin=(root/'app/src/main/java/com/myshop/app/AdminIdentifiers.java').read_text()
layout=(root/'app/src/main/res/layout/activity_register.xml').read_text()
assert 'showPasswordResetBox' in login
assert 'resetPasswordWithTwoOfThree' in login
assert 'Security Question + 2-of-3 Password Reset' in layout
assert 'securityQuestion1' in layout and 'securityQuestion2' in layout and 'securityQuestion3' in layout
assert 'securityAnswer1' in layout and 'securityAnswer2' in layout and 'securityAnswer3' in layout
assert 'validSecuritySet' in store and 'matches < 2' in store
assert 'FIRST_ID = 100' in uid and '%04d' in uid
for ident in ['myshopsatkania@gmail.com','touhidsatkania@gmail.com','01860626700']:
    assert ident in admin
assert (root/'app/src/main/res/drawable/myshop_dashboard_reference.png').exists()
print('V-72 source validation PASSED')
