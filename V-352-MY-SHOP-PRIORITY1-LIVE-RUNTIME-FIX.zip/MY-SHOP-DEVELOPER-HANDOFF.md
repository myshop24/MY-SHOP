# MY SHOP — Developer Handoff

## V-352 — Priority-1 Live Runtime Stabilization

- **Version:** V-352
- **versionCode / versionName:** 352 / 2.9.352
- **Completed in source:** five Priority-1 Live runtime fixes below.
- **Pending:** GitHub Android CI + Cloudflare Worker deploy + two-device real-runtime acceptance.
- **Phase:** Core Live stabilization; no new feature/design work.
- **Last checkpoint:** source diff limited to RTC/realtime/gift-sound/backend integration plus version/docs; Worker syntax/TOML/static checks pending final package validation.
- **Next tasks:** upload the single V-352 ZIP, build APK, deploy V-352 Worker, then execute `V-352_PRIORITY1_RUNTIME_QA.md`.
- **Known issues:** runtime behavior cannot be certified until two physical devices pass all five checks; Worker deployment is mandatory for cross-device comments/invite fixes.

Targeted blockers only; preserve approved Live UI, 8 seats (2–9), Coin/Gold, Admin, Gift accounting, Join Request, End Live, Timer, Profile and Navigation.

1. **Cross-device audio**: Agora audio transport is now stateful/idempotent. Audience auto-subscribes to remote audio, recording/playout is explicitly enabled, role/media options are no longer rewritten on every 650ms room refresh, and disconnected/failed RTC states trigger a fresh token/rejoin attempt.
2. **Cross-device comments**: active-session Live comments/highlights are coordinated through `LiveRoomRealtime` Durable Object memory rather than per-Worker-isolate memory. No comment is persisted to D1, R2, or Durable Object storage.
3. **Voice latency**: removed continuous Agora role/media churn and added a lightweight 280ms realtime interaction poll.
4. **Host Invite visibility**: target audience receives `incomingInvite` through `/v1/live/realtime` instead of waiting on the large room-state path.
5. **Gift sound**: gift events ride the same fast realtime poll; built-in/custom gift sound uses Android media audio routing with built-in fallback.

**Backend deployment gate:** V-352 Worker must be deployed because blockers #2 and #4 depend on the new Durable Object binding + `/v1/live/realtime`. The Android APK alone cannot provide cross-device server synchronization.

**Runtime acceptance gate:** do not call Live final until two physical devices pass audio, comments, voice-delay, invite and gift-sound tests in the same room. Static/source checks are not a substitute for device QA.

---

# MY SHOP — DEVELOPER HANDOFF

## Current Release: V-351
- versionCode: 351
- versionName: 2.9.351
- Completed: GitHub highest-version source identity corrected; V-350 stabilization implementation preserved.
- Pending: GitHub CI build + installed-APK real-device acceptance.
- Phase: Stabilization / release verification.
- Last checkpoint: duplicate highest V-350 ZIP workflow guard identified.
- Next tasks: upload only V-351 ZIP, run CI, install APK, complete V-351_REGRESSION_QA.md.
- Known issue: push runtime still requires valid Firebase/FCM deployment configuration; real-device checks remain mandatory.

---

# MY SHOP DEVELOPER HANDOFF — V-349 STABILIZATION

Current version: V-349
Base: V-348 correct source branch (`v348_work`), not the older compact branch that produced the wrong Live runtime.
SOURCE_BUILD_ID: MY SHOP V-349
Android: versionCode 349 / versionName 2.9.349
Worker: version 2.9.349 / build V-349
Golden Live reference: `APPROVED-V349-LIVE-ROOM-FINAL-REFERENCE.png`
Locked scope: `V-349_LOCKED_STABILIZATION_SCOPE.md`

Completed in source: final 8-seat Live layout lock, Main Guest logo/crown, chair empty seats, red borderless Exit, Gift sound hardening, prominent sender Gift comments, Keystore-backed persistent login, system-push client/server diagnostics, obsolete seat asset cleanup, audio-only Agora SDK size stabilization.

Regression lock: do not redesign the approved Live UI or change Coin/Gold economy, Gift Admin/catalog/balance/ledger rules, D1/R2 contracts, Join Request/Host Invite, End Live, comments, PiP, Profile, Dashboard, Admin, Store or navigation unless explicitly requested.

Acceptance status: SOURCE/STATIC PASS; RUNTIME PENDING. A Green build is not Final. The CI-built APK must pass `V-349_REGRESSION_QA.md`. Real FCM push also requires the Firebase GitHub build values and Worker `FCM_SERVICE_ACCOUNT_JSON`; secrets are not included in source.

Last checkpoint: V-349 static validator passed all locked source checks; Worker syntax and Android resource integrity checks passed. Full Android compile/device acceptance is not available in this local environment.

Next: GitHub CI -> install APK -> compare Live screenshot to golden reference -> two-device Gift/audio/login/push/regression QA -> only then production acceptance.

---
# MY SHOP DEVELOPER HANDOFF — V-348

Current version: V-348
Base: V-347
Completed: Final locked Live Room seat/main-guest/exit visual implementation and Gift Sound playback hardening.
Pending acceptance: GitHub CI release build + real-device test of uploaded custom gift sound and RTC coexistence.
Golden UI reference: APPROVED-V348-LIVE-ROOM-FINAL-REFERENCE.png
Regression rule: do not redesign or move the approved Live Room UI while fixing functionality.

# MY SHOP Developer Handoff — V-347

Current version: V-347
SOURCE_BUILD_ID: MY SHOP V-347
Android: versionCode 347 / versionName 2.9.347
Worker health identity: version 2.9.347 / build V-347

Completed: V-346 AAPT resource failure fixed by replacing the mislabeled JPEG-as-PNG empty-seat asset with the user-approved MY SHOP MS image re-encoded as a true PNG. Empty Guest seats use the MS artwork, occupied Guest seats keep real profile photos, and Host rendering has a real-profile fallback. Existing V-346 Live mini/PiP, gift, audio, pin, Exit, Join/Leave, frameless seat and full-screen low-light theme behavior is preserved.

Regression lock: preserve all unrelated working modules/files, RTC token flow, existing seat allocation/count, Join Request/Host Invite, Coin/Gold Coin economy, Gift catalog/ledger/Admin controls, D1/R2 schema/bindings, ephemeral Live comments, Profile, Dashboard, Store, Admin and navigation behavior.

Pending acceptance: run the established GitHub Android CI compile/sign and complete two-device real Live tests before production release.

Last checkpoint: source/static validation passed and the V-346 AAPT root cause was confirmed (`live_empty_seat_myshop.png` contained JPEG/JFIF bytes). V-347 replacement is a valid 1536×1536 RGBA PNG.

Next tasks: GitHub CI build -> signed APK verification -> two-device Live QA -> final Google Play release audit.

Known issues: no known source-level V-347 blocker after the PNG correction; runtime/device acceptance remains required.
