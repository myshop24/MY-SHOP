# V-352 RELEASE NOTES — PRIORITY-1 LIVE RUNTIME

Version: **2.9.352**  
versionCode: **352**

## Locked scope — exactly five critical runtime blockers
1. Host/Speaker audio must be heard by audience.
2. Live comments must broadcast to all users, not sender-only.
3. Voice must avoid avoidable application-side delay.
4. Host Call Invite must reach the intended audience user promptly.
5. Gift sound must play for successful gift events.

## Implemented source changes
- Agora transport now keeps a stable channel/audio path and only updates publish/mic state when it actually changes.
- Audience `ChannelMediaOptions` explicitly enables auto audio subscription and audio playout.
- RTC disconnect/failure schedules token refresh/rejoin instead of waiting for a full Activity restart.
- Added `/v1/live/realtime` lightweight endpoint for comments, highlights, incoming invite and gift events.
- Added `LiveRoomRealtime` Durable Object as an **in-memory-only** active-session coordinator; no Live comment persistence in D1/R2/DO storage.
- Android polls the lightweight realtime endpoint ~280ms while an active session exists.
- Gift sound routes through `USAGE_MEDIA`/music content type, keeps Admin sound ON/OFF + volume/custom URL controls, and retains built-in fallback.

## Required deployment / QA
- Deploy `backend/worker` including the `LIVE_ROOM_REALTIME` Durable Object migration before runtime testing.
- Test with at least two physical phones in the same Live Room.
- A Green Android build proves compilation only; it does not prove these five runtime behaviors.
