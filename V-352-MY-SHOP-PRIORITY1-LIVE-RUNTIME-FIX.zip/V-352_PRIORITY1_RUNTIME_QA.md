# V-352 PRIORITY-1 LIVE RUNTIME QA

Use two physical Android phones/accounts in one Live Room.

- [ ] Host speaks; audience hears continuously.
- [ ] Speaker-seat user speaks; host and audience hear continuously.
- [ ] Audience comment appears on sender, host, and second audience in the same order.
- [ ] Noticeable application-side voice delay is not present under a normal stable network.
- [ ] Host invites target user; only the intended user gets the Accept/Decline dialog promptly; Accept moves user to a speaker seat.
- [ ] Coin gift produces sender-side and remote-device gift event and audible sound.
- [ ] Gold gift produces sender-side and remote-device gift event and audible sound.
- [ ] Admin Gift Sound OFF really mutes that gift.
- [ ] Admin Gift volume changes are audible; custom URL failure falls back to built-in sound when a built-in mapping exists.
- [ ] Join Request, mute/unmute, Leave Call, End Live, Coin/Gold accounting and Gift ledger remain unchanged.

**PASS rule:** all five core items must pass end-to-end. Otherwise V-352 is not runtime-final.
