package com.myshop.app;

import android.content.Context;
import io.agora.rtc2.ChannelMediaOptions;
import io.agora.rtc2.Constants;
import io.agora.rtc2.IRtcEngineEventHandler;
import io.agora.rtc2.RtcEngine;
import io.agora.rtc2.RtcEngineConfig;

/**
 * V-352 audio-only RTC transport.
 * Backend remains the room/seat/role authority; this class only owns Agora audio transport.
 * Important: SDK role/media options are changed only when state actually changes so the
 * 650ms room-state refresh cannot continuously tear down/reconfigure the audio path.
 */
public final class AgoraRtcManager {
    public interface Listener {
        void onJoined();
        void onRemoteUserJoined(int uid);
        void onRemoteAudioState(int uid,int state,int reason);
        void onLocalAudioState(int state,int error);
        void onConnectionState(int state,int reason);
        void onError(String message);
        void onTokenWillExpire();
        void onAudioLevel(boolean speaking);
        void onActiveSpeaker(int uid,int volume);
    }

    private RtcEngine engine;
    private boolean joined=false;
    private boolean joinPending=false;
    private boolean publishAudio=false;
    private boolean micEnabled=false;
    private String currentChannel="";
    private int currentUid=0;
    private final Listener listener;

    public AgoraRtcManager(Listener listener){this.listener=listener;}

    public void init(Context context) throws Exception {
        if(engine!=null)return;
        RtcEngineConfig c=new RtcEngineConfig();
        c.mContext=context.getApplicationContext();
        c.mAppId=BuildConfig.AGORA_APP_ID;
        c.mEventHandler=new IRtcEngineEventHandler(){
            @Override public void onJoinChannelSuccess(String ch,int uid,int elapsed){
                joined=true;joinPending=false;currentChannel=ch==null?"":ch;currentUid=uid;
                if(listener!=null)listener.onJoined();
            }
            @Override public void onConnectionStateChanged(int state,int reason){
                // Agora: 1=DISCONNECTED, 5=FAILED. Mark transport join state stale so caller
                // can obtain a fresh token and rejoin without requiring an Activity restart.
                if(state==1||state==5){joined=false;joinPending=false;}
                if(listener!=null)listener.onConnectionState(state,reason);
            }
            @Override public void onLocalAudioStateChanged(int state,int error){if(listener!=null)listener.onLocalAudioState(state,error);}
            @Override public void onError(int err){if(listener!=null)listener.onError("Agora RTC error "+err);}
            @Override public void onUserJoined(int uid,int elapsed){if(listener!=null)listener.onRemoteUserJoined(uid);}
            @Override public void onRemoteAudioStateChanged(int uid,int state,int reason,int elapsed){if(listener!=null)listener.onRemoteAudioState(uid,state,reason);}
            @Override public void onTokenPrivilegeWillExpire(String token){if(listener!=null)listener.onTokenWillExpire();}
            @Override public void onRequestToken(){if(listener!=null)listener.onTokenWillExpire();}
            @Override public void onAudioVolumeIndication(AudioVolumeInfo[] speakers,int totalVolume){
                if(listener==null||speakers==null)return;
                boolean speaking=false;int loudUid=-1,loudVolume=0;
                for(AudioVolumeInfo i:speakers){
                    if(i==null)continue;
                    if(i.uid==0&&i.volume>=12)speaking=true;
                    if(i.volume>=12&&i.volume>loudVolume){loudUid=i.uid;loudVolume=i.volume;}
                }
                listener.onAudioLevel(speaking);listener.onActiveSpeaker(loudUid,loudVolume);
            }
        };
        engine=RtcEngine.create(c);
        engine.setChannelProfile(Constants.CHANNEL_PROFILE_LIVE_BROADCASTING);
        engine.enableAudio();
        // Speech-first voice room tuning. Keep CHATROOM for natural voice while explicitly
        // opting into remote audio subscription in ChannelMediaOptions below.
        try{engine.setAudioProfile(Constants.AUDIO_PROFILE_SPEECH_STANDARD);engine.setAudioScenario(Constants.AUDIO_SCENARIO_CHATROOM);}catch(Exception ignored){}
        engine.setEnableSpeakerphone(true);
        engine.setDefaultAudioRoutetoSpeakerphone(true);
        engine.muteAllRemoteAudioStreams(false);
        engine.adjustPlaybackSignalVolume(125);
        engine.adjustRecordingSignalVolume(115);
        engine.enableAudioVolumeIndication(250,3,true);
    }

    private ChannelMediaOptions options(boolean publish){
        ChannelMediaOptions o=new ChannelMediaOptions();
        o.clientRoleType=publish?Constants.CLIENT_ROLE_BROADCASTER:Constants.CLIENT_ROLE_AUDIENCE;
        o.autoSubscribeAudio=true;
        o.publishMicrophoneTrack=publish;
        // Explicitly keep recording/playout active. For audience this is required for reliable
        // remote playout; for host/speaker it also enables microphone capture.
        o.enableAudioRecordingOrPlayout=true;
        return o;
    }

    private void applyRole(boolean publish){
        if(engine==null)return;
        engine.setClientRole(publish?Constants.CLIENT_ROLE_BROADCASTER:Constants.CLIENT_ROLE_AUDIENCE);
    }

    public int join(String token,String channelName,int uid,boolean publish){
        if(engine==null)return -10001;
        if(token==null||token.isEmpty()||channelName==null||channelName.isEmpty()||uid<=0)return -10002;

        // Same live channel: renew token and only update media options if role actually changed.
        if((joined||joinPending)&&channelName.equals(currentChannel)&&uid==currentUid){
            renewToken(token);
            setPublishAudio(publish);
            return 0;
        }

        // A stale/different channel must be left before joining the new live session.
        if(joined||joinPending){
            try{engine.leaveChannel();}catch(Exception ignored){}
            joined=false;joinPending=false;
        }

        this.publishAudio=publish;
        this.micEnabled=publish;
        this.currentChannel=channelName;
        this.currentUid=uid;
        applyRole(publish);
        engine.enableLocalAudio(publish);
        engine.muteLocalAudioStream(!publish);
        engine.muteAllRemoteAudioStreams(false);
        int rc=engine.joinChannel(token,channelName,uid,options(publish));
        joinPending=(rc==0);
        if(rc!=0&&listener!=null)listener.onError("Agora join return "+rc);
        return rc;
    }

    /** Change broadcaster/audience mode only when it actually changes. */
    public void setPublishAudio(boolean publish){
        if(engine==null)return;
        if(this.publishAudio==publish && (joined||joinPending)){
            // Still make sure remote audio is not accidentally muted, but do not churn role/media options.
            engine.muteAllRemoteAudioStreams(false);
            return;
        }
        this.publishAudio=publish;
        applyRole(publish);
        engine.enableLocalAudio(publish);
        if(!publish){this.micEnabled=false;engine.muteLocalAudioStream(true);}
        if(joined||joinPending)engine.updateChannelMediaOptions(options(publish));
        engine.muteAllRemoteAudioStreams(false);
    }

    /** Avoid repeatedly toggling Agora capture on every room-state refresh. */
    public void setMicEnabled(boolean enabled){
        boolean effective=enabled&&publishAudio;
        if(engine==null)return;
        if(this.micEnabled==effective)return;
        this.micEnabled=effective;
        engine.enableLocalAudio(publishAudio);
        engine.muteLocalAudioStream(!effective);
    }

    public boolean isJoined(){return joined;}
    public boolean isJoinPending(){return joinPending;}
    public void renewToken(String token){if(engine!=null&&token!=null&&!token.isEmpty())engine.renewToken(token);}
    public void leave(){
        if(engine!=null&&(joined||joinPending)){try{engine.leaveChannel();}catch(Exception ignored){}}
        joined=false;joinPending=false;publishAudio=false;micEnabled=false;currentChannel="";currentUid=0;
    }
    public void destroy(){leave();if(engine!=null){RtcEngine.destroy();engine=null;}}
}
