# V-352 Worker deployment required

V-352 fixes cross-device Live comments and Host Invite delivery with a new Cloudflare Worker realtime endpoint and Durable Object binding. Building/installing only the APK does not deploy those server changes.

Worker source: `backend/worker/`
Config: `backend/worker/wrangler.toml`
Binding: `LIVE_ROOM_REALTIME`
Durable Object class: `LiveRoomRealtime`
Migration tag: `v352-live-room-realtime`

The object intentionally uses memory only and does **not** call Durable Object storage, D1, or R2 for Live comments/highlights.
