# MY SHOP Developer Handoff

## Current checkpoint
- Version: **V-295**
- Version name: **2.9.295**
- Base: V-294

## Completed in V-295
- Live bottom control safe-area lift.
- Single Highlight ✨ composer control.
- Live Name + thin editable Caption.
- 24-hour Live Name lock with 5,000 Coin early-change fee to MY SHOP ledger.
- Aggregate live react counter + compact K/M UI + 1,000 Coin per 10K milestone.
- Main Admin Locker / recovery / one-unlock session gate.
- Premium Finance Overview + configurable VAT/service charge.
- User ID transaction/message investigation foundation and retained admin message archive.

## Deploy order
1. Apply `0012_v295_admin_gate_live_name_react_audit.sql`.
2. Deploy Worker V-295.
3. Install/build Android V-295.
4. As Main Admin, open Admin Panel and create the Admin Locker password/security question on first entry.

## Verification required before production
- Test first Admin Locker setup, unlock, wrong password, question recovery, and 2-of-3 owner-ID recovery.
- Test VAT changes and verify ledger math for transfer/gift/value paths.
- Test Live Name: first set free; changed before 24h requires exactly 5,000 Coin; changed after 24h free; ID never changes.
- Test react milestones at 9,999 → 10,000 → 20,000 and reconnect to confirm no duplicate reward.
- Test caption edit while live and one-line clipping/ellipsis on small screens.
- Test user message soft-delete and admin archive visibility.
- Real RTC/Agora production audio remains a separate pending item unless already supplied externally.
