package com.myshop.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;

/** V-285 admin-only Audio Live theme/background editor. */
public class LiveThemeAdminActivity extends AppCompatActivity {
    private EditText key,name,bg,accent,sort;
    private Switch enabled;
    @Override protected void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)){finish();return;}build();}
    private void build(){
        ScrollView sv=new ScrollView(this);LinearLayout root=col();root.setPadding(dp(16),dp(14),dp(16),dp(24));root.setBackgroundColor(Color.rgb(247,248,252));
        TextView title=t("AUDIO LIVE THEME / BACKGROUND",18,Color.rgb(25,31,61),true);root.addView(title);
        TextView note=t("Admin-only • Published themes become selectable by Host without an APK update.",11,Color.DKGRAY,false);note.setPadding(0,dp(4),0,dp(12));root.addView(note);
        key=input("Theme key, e.g. GUITAR_BLUE");name=input("Theme name");bg=input("Background image URL (optional)");accent=input("Accent color, e.g. #5B67FF");sort=input("Sort order");
        key.setText("GUITAR_BLUE");name.setText("Guitar Blue");accent.setText("#5B67FF");sort.setText("0");
        root.addView(key);root.addView(name);root.addView(bg);root.addView(accent);root.addView(sort);
        enabled=new Switch(this);enabled.setText("Enabled / Published");enabled.setChecked(true);root.addView(enabled,new LinearLayout.LayoutParams(-1,dp(54)));
        Button save=button("Save / Publish");save.setOnClickListener(v->submit("UPSERT"));root.addView(save,new LinearLayout.LayoutParams(-1,dp(50)));
        Button del=button("Delete Theme");del.setBackground(round(Color.rgb(173,40,61),Color.rgb(173,40,61),14));LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,50);dp.topMargin=10;del.setOnClickListener(v->submit("DELETE"));root.addView(del,new LinearLayout.LayoutParams(-1,dp(50)));
        Button back=button("Back");back.setOnClickListener(v->finish());LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(48));bp.topMargin=dp(10);root.addView(back,bp);
        sv.addView(root);setContentView(sv);
    }
    private void submit(String action){String k=key.getText().toString().trim().toUpperCase();if(k.length()<2){Toast.makeText(this,"Theme key required",Toast.LENGTH_SHORT).show();return;}int order=0;try{order=Integer.parseInt(sort.getText().toString().trim());}catch(Exception ignored){}BackendClient.adminLiveTheme(SessionManager.getToken(this),action,k,name.getText().toString().trim(),bg.getText().toString().trim(),accent.getText().toString().trim(),enabled.isChecked(),order,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->Toast.makeText(LiveThemeAdminActivity.this,"DELETE".equals(action)?"Theme deleted":"Theme saved / published",Toast.LENGTH_LONG).show());}public void onError(String m){runOnUiThread(()->Toast.makeText(LiveThemeAdminActivity.this,m,Toast.LENGTH_LONG).show());}});}
    private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setBackground(round(Color.WHITE,Color.rgb(215,220,235),12));e.setPadding(dp(12),0,dp(12),0);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52));p.bottomMargin=dp(8);e.setLayoutParams(p);return e;}
    private Button button(String s){Button b=new Button(this);b.setAllCaps(false);b.setText(s);b.setTextColor(Color.WHITE);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(round(Color.rgb(76,45,205),Color.rgb(140,83,240),14));return b;}
    private TextView t(String s,float z,int c,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private GradientDrawable round(int fill,int stroke,int r){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(r));g.setStroke(dp(1),stroke);return g;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
