package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

/**
 * MY SHOP V-243 Premium Profile polish.
 * Account identity stays backend-authoritative. User ID is read-only and is never edited here.
 */
public class AccountActivity extends AppCompatActivity {
    private static final int PICK_AVATAR=7001, PICK_COVER=7002;
    private final ExecutorService imageIo=Executors.newFixedThreadPool(2);
    private ImageView avatar,cover,activeBadgeAnimation; private TextView name,id,contact,bio,coins,gold,membershipStatus,membershipExpiry,profileVip,profileTierBadge,profileMemberLine,friendsCount,followersCount,followingCount;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        avatar=findViewById(R.id.profileAvatar); cover=findViewById(R.id.profileCover); activeBadgeAnimation=findViewById(R.id.activeBadgeAnimation); name=findViewById(R.id.profileName); id=findViewById(R.id.profileId);
        contact=findViewById(R.id.profileContact); bio=findViewById(R.id.profileBio); coins=findViewById(R.id.coinBalance); gold=findViewById(R.id.goldBalance); membershipStatus=findViewById(R.id.membershipStatus);
        membershipExpiry=findViewById(R.id.membershipExpiry); profileVip=findViewById(R.id.profileVip); profileTierBadge=findViewById(R.id.profileTierBadge); profileMemberLine=findViewById(R.id.profileMemberLine);
        friendsCount=findViewById(R.id.friendsCount); followersCount=findViewById(R.id.followersCount); followingCount=findViewById(R.id.followingCount);
        renderLocal(); loadMe(); loadCoins(); loadWallet(); loadSocialStats();

        findViewById(R.id.profileBack).setOnClickListener(v -> finish());
        findViewById(R.id.profileSettings).setOnClickListener(v -> Toast.makeText(this,"Profile settings",Toast.LENGTH_SHORT).show());
        findViewById(R.id.changeAvatarButton).setOnClickListener(v -> chooseAvatar());
        findViewById(R.id.changeCoverButton).setOnClickListener(v -> coverActions());
        findViewById(R.id.profileButton).setOnClickListener(v -> editProfile());
        findViewById(R.id.profileShareButton).setOnClickListener(v -> shareProfile());
        findViewById(R.id.buyCoinsButton).setOnClickListener(v -> startActivity(new Intent(this,StoreActivity.class)));
        findViewById(R.id.buyGoldButton).setOnClickListener(v -> startActivity(new Intent(this,StoreActivity.class)));
        findViewById(R.id.membershipButton).setOnClickListener(v -> startActivity(new Intent(this,StoreActivity.class)));
        findViewById(R.id.withdrawButton).setOnClickListener(v -> withdrawalDialog());
        findViewById(R.id.coinHistoryButton).setOnClickListener(v -> showCoinHistory());
        findViewById(R.id.giftHistoryButton).setOnClickListener(v -> showGiftHistory());
        findViewById(R.id.sendGiftButton).setOnClickListener(v -> Toast.makeText(this,"Live room খুলে Broadcast-এ Gift পাঠানো যাবে।",Toast.LENGTH_LONG).show());
        findViewById(R.id.myLiveButton).setOnClickListener(v -> startActivity(new Intent(this,MainActivity.class)));
        findViewById(R.id.passwordButton).setOnClickListener(v -> Toast.makeText(this,"Password reset/change is handled by secure backend authentication.",Toast.LENGTH_LONG).show());
        Switch notifications=findViewById(R.id.notificationSwitch);
        notifications.setChecked(getPreferences(MODE_PRIVATE).getBoolean("notifications",true));
        notifications.setOnCheckedChangeListener((button,checked)->getPreferences(MODE_PRIVATE).edit().putBoolean("notifications",checked).apply());
        findViewById(R.id.reportButton).setOnClickListener(v -> Toast.makeText(this,"Support and report tools can be connected to the backend without changing your account data.",Toast.LENGTH_LONG).show());
        findViewById(R.id.blockButton).setOnClickListener(v -> Toast.makeText(this,"Block List",Toast.LENGTH_SHORT).show());
        findViewById(R.id.historyButton).setOnClickListener(v -> Toast.makeText(this,"History",Toast.LENGTH_SHORT).show());
        findViewById(R.id.galleryButton).setOnClickListener(v -> startActivity(new Intent(this,GalleryActivity.class)));
        findViewById(R.id.logoutButton).setOnClickListener(v -> logout());
        smoothButtons(R.id.changeAvatarButton,R.id.changeCoverButton,R.id.profileButton,R.id.profileShareButton,R.id.buyCoinsButton,R.id.buyGoldButton,R.id.membershipButton,R.id.withdrawButton,R.id.coinHistoryButton,R.id.giftHistoryButton,R.id.sendGiftButton,R.id.myLiveButton,R.id.logoutButton);
    }

    @Override protected void onResume(){super.onResume();if(coins!=null){loadCoins();loadWallet();loadSocialStats();}}

    private void renderLocal(){
        String uid=SessionManager.getUserId(this); String n=getPrefs("full_name"); String e=getPrefs("email"); String m=getPrefs("mobile"); String b=SessionManager.getBio(this);
        name.setText(n.isEmpty()?"MY SHOP User":n); id.setText("MY SHOP ID  •  "+(uid.isEmpty()?"Not assigned":uid));
        contact.setText(!e.isEmpty()?e:(!m.isEmpty()?m:"")); bio.setText(b); bio.setVisibility(b.isEmpty()?View.GONE:View.VISIBLE);
        String av=SessionManager.getAvatarUrl(this); if(!av.isEmpty()) loadImage(av,avatar);
        String cv=SessionManager.getCoverUrl(this); if(!cv.isEmpty()) loadImage(cv,cover); else cover.setImageDrawable(null);
    }
    private String getPrefs(String key){return getSharedPreferences("myshop_session",MODE_PRIVATE).getString(key,"");}

    private void loadMe(){String token=SessionManager.getToken(this); if(token.isEmpty())return; BackendClient.me(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{try{JSONObject u=d.optJSONObject("user");if(u==null)return;SessionManager.saveProfile(AccountActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""),u.optString("avatarUrl",""),u.optString("coverUrl",SessionManager.getCoverUrl(AccountActivity.this)),u.optString("bio",""));renderLocal();}catch(Exception ignored){}});}public void onError(String m){}});}
    private void loadCoins(){String token=SessionManager.getToken(this); if(token.isEmpty()){coins.setText("0 Coins");return;} BackendClient.coins(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->coins.setText(String.format("%,d Coins",d.optLong("balance",0))));}public void onError(String m){runOnUiThread(()->coins.setText("0 Coins"));}});}

    private void editProfile(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(36,8,36,8);
        EditText n=input("Full Name",getPrefs("full_name")); EditText e=input("Email",getPrefs("email")); EditText m=input("Mobile",getPrefs("mobile")); EditText b=input("Bio",SessionManager.getBio(this));
        box.addView(n);box.addView(e);box.addView(m);box.addView(b);
        new AlertDialog.Builder(this).setTitle("Edit Profile").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Update",(d,w)->{
            String token=SessionManager.getToken(this); BackendClient.updateProfile(token,n.getText().toString(),e.getText().toString(),m.getText().toString(),b.getText().toString(),new BackendClient.Callback(){public void onSuccess(JSONObject x){try{JSONObject u=x.optJSONObject("user");SessionManager.saveProfile(AccountActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""),u.optString("avatarUrl",""),u.optString("coverUrl",SessionManager.getCoverUrl(AccountActivity.this)),u.optString("bio",""));renderLocal();Toast.makeText(AccountActivity.this,"Profile updated safely. User ID remains unchanged.",Toast.LENGTH_LONG).show();}catch(Exception ex){Toast.makeText(AccountActivity.this,"Profile response invalid.",Toast.LENGTH_SHORT).show();}}public void onError(String msg){Toast.makeText(AccountActivity.this,msg,Toast.LENGTH_LONG).show();}});
        }).show();
    }
    private EditText input(String hint,String value){EditText x=new EditText(this);x.setHint(hint);x.setSingleLine(false);x.setText(value);x.setPadding(8,10,8,10);return x;}

    private void chooseAvatar(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_AVATAR);}

    private void coverActions(){
        boolean has=!SessionManager.getCoverUrl(this).isEmpty();
        String[] actions=has?new String[]{"Choose new cover photo","Remove cover photo"}:new String[]{"Add cover photo"};
        new AlertDialog.Builder(this).setTitle("Cover Photo").setItems(actions,(d,which)->{
            if(has&&which==1){
                BackendClient.deleteCover(SessionManager.getToken(this),new BackendClient.Callback(){
                    public void onSuccess(JSONObject x){JSONObject u=x.optJSONObject("user"); if(u!=null){SessionManager.saveProfile(AccountActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""),u.optString("avatarUrl",""),u.optString("coverUrl",""),u.optString("bio","")); renderLocal();} Toast.makeText(AccountActivity.this,"Cover photo removed.",Toast.LENGTH_SHORT).show();}
                    public void onError(String m){Toast.makeText(AccountActivity.this,m,Toast.LENGTH_LONG).show();}
                });
            }else chooseCover();
        }).show();
    }

    private void chooseCover(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_COVER);}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if((requestCode!=PICK_AVATAR&&requestCode!=PICK_COVER)||resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        try{
            InputStream in=getContentResolver().openInputStream(uri); String mime=getContentResolver().getType(uri); String fileName=requestCode==PICK_COVER?"cover.jpg":"avatar.jpg"; if(mime!=null&&mime.contains("png"))fileName=requestCode==PICK_COVER?"cover.png":"avatar.png";
            BackendClient.Callback cb=new BackendClient.Callback(){
                public void onSuccess(JSONObject d){try{JSONObject u=d.optJSONObject("user"); if(u==null)throw new Exception("missing user"); SessionManager.saveProfile(AccountActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""),u.optString("avatarUrl",""),u.optString("coverUrl",SessionManager.getCoverUrl(AccountActivity.this)),u.optString("bio","")); renderLocal(); Toast.makeText(AccountActivity.this,requestCode==PICK_COVER?"Cover photo updated.":"Profile photo updated.",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(AccountActivity.this,"Photo response invalid.",Toast.LENGTH_SHORT).show();}}
                public void onError(String m){Toast.makeText(AccountActivity.this,m,Toast.LENGTH_LONG).show();}
            };
            if(requestCode==PICK_COVER)BackendClient.uploadCover(SessionManager.getToken(this),in,fileName,mime==null?"image/jpeg":mime,cb);
            else BackendClient.uploadAvatar(SessionManager.getToken(this),in,fileName,mime==null?"image/jpeg":mime,cb);
        }catch(Exception e){Toast.makeText(this,"Could not open selected photo.",Toast.LENGTH_SHORT).show();}
    }

    private void loadImage(String url,ImageView target){imageIo.execute(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(4000);c.setReadTimeout(6000);Bitmap b=BitmapFactory.decodeStream(c.getInputStream());if(b!=null)runOnUiThread(()->{target.setAlpha(.45f);target.setImageBitmap(b);target.animate().alpha(1f).setDuration(140).start();});}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}});}

    private void showCoinHistory(){
        BackendClient.coins(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                StringBuilder s=new StringBuilder(); s.append("Current balance: ").append(String.format("%,d",d.optLong("balance",0))).append(" Coins\n\n");
                org.json.JSONArray a=d.optJSONArray("transactions"); if(a==null||a.length()==0)s.append("No coin transactions yet."); else for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;s.append(x.optString("kind","Transaction")).append("  ").append(x.optInt("amount",0)>=0?"+":"").append(x.optInt("amount",0)).append(" coins\n").append(x.optString("created_at","")).append("\n\n");}
                new AlertDialog.Builder(AccountActivity.this).setTitle("🪙 Coin History").setMessage(s.toString()).setPositiveButton("CLOSE",null).show();
            }
            public void onError(String m){Toast.makeText(AccountActivity.this,m,Toast.LENGTH_LONG).show();}
        });
    }
    private void showGiftHistory(){
        BackendClient.giftHistory(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                StringBuilder s=new StringBuilder(); org.json.JSONArray a=d.optJSONArray("gifts"); if(a==null||a.length()==0)s.append("No gift transactions yet."); else for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;boolean sent=SessionManager.getUserId(AccountActivity.this).equals(x.optString("sender_user_id",""));s.append(sent?"Gift sent → ":"Gift received ← ").append(x.optInt("coins",0)).append(" coins\n").append(x.optString("gift_code","Gift")).append(" • ").append(x.optString("created_at","")).append("\n\n");}
                new AlertDialog.Builder(AccountActivity.this).setTitle("🎁 Gift History").setMessage(s.toString()).setPositiveButton("CLOSE",null).show();
            }
            public void onError(String m){Toast.makeText(AccountActivity.this,m,Toast.LENGTH_LONG).show();}
        });
    }

    private void buyCoinsDialog(){
        String[] packages={"120 Coins — ৳50","300 Coins — ৳100","650 Coins — ৳200","1,350 Coins — ৳400","2,750 Coins — ৳800","6,000 Coins — ৳1,600"};
        String[] methods={"bKash","Nagad","Bangla QR Code"};
        final int[] selected={2};
        new AlertDialog.Builder(this).setTitle("Buy Coins").setSingleChoiceItems(packages,selected[0],(d,w)->selected[0]=w).setPositiveButton("Choose Payment",(d,w)->{
            int[] coinVals={120,300,650,1350,2750,6000}; int[] amount={5000,10000,20000,40000,80000,160000};
            new AlertDialog.Builder(this).setTitle("Payment Method").setItems(methods,(dd,which)->{
                final String[] keys={"bkash","nagad","bangla_qr"};
                EditText ref=new EditText(this); ref.setHint("Payment reference (optional)");
                new AlertDialog.Builder(this).setTitle("Payment Reference").setView(ref).setMessage("Selected: "+methods[which]+"\nAmount: ৳"+(amount[selected[0]]/100)+"\nCoins: "+coinVals[selected[0]]+"\n\nPayment is recorded as Pending until server-side approval.").setNegativeButton("Cancel",null).setPositiveButton("Submit Request",(x,y)->BackendClient.requestCoinPurchase(SessionManager.getToken(this),coinVals[selected[0]],amount[selected[0]],keys[which],ref.getText().toString(),new BackendClient.Callback(){public void onSuccess(JSONObject q){Toast.makeText(AccountActivity.this,"Payment request submitted. Coins will be added only after approval.",Toast.LENGTH_LONG).show();}public void onError(String msg){Toast.makeText(AccountActivity.this,msg,Toast.LENGTH_LONG).show();}})).show();
            }).show();
        }).setNegativeButton("Cancel",null).show();
    }

    private void loadWallet(){
        String token=SessionManager.getToken(this); if(token.isEmpty())return;
        BackendClient.walletProfile(token,new BackendClient.Callback(){ public void onSuccess(JSONObject d){ runOnUiThread(()->{
            gold.setText(String.format("%,d Gold",d.optLong("goldBalance",0)));
            org.json.JSONArray badges=d.optJSONArray("badges");
            JSONObject active=(badges!=null&&badges.length()>0)?badges.optJSONObject(0):null;
            String code="FREE"; String expiry=""; String source="";
            if(active!=null){
                code=active.optString("badge_code",active.optString("badgeCode","FREE")).trim().toUpperCase();
                expiry=active.optString("expires_at",active.optString("expiresAt","")).trim();
                source=active.optString("source","").trim();
                String anim=active.optString("animation_url",active.optString("animationUrl","")).trim();
                String prev=active.optString("preview_url",active.optString("previewUrl","")).trim();
                if(activeBadgeAnimation!=null){ activeBadgeAnimation.setVisibility(View.VISIBLE); AnimatedAssetLoader.load(activeBadgeAnimation,!anim.isEmpty()?anim:prev); }
            } else if(activeBadgeAnimation!=null) activeBadgeAnimation.setVisibility(View.GONE);
            applyPremiumTier(code,expiry,source);
        }); } public void onError(String m){runOnUiThread(()->applyPremiumTier("FREE","",""));} });
    }

    private void loadSocialStats(){
        String token=SessionManager.getToken(this); if(token.isEmpty())return;
        BackendClient.socialStats(token,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{JSONObject st=d.optJSONObject("stats");if(st==null)return;animateCount(friendsCount,st.optInt("friends",0));animateCount(followersCount,st.optInt("followers",0));animateCount(followingCount,st.optInt("following",0));});}
            public void onError(String m){}
        });
    }

    private void animateCount(TextView target,int value){
        target.animate().alpha(.45f).setDuration(70).withEndAction(()->{target.setText(String.valueOf(value));target.animate().alpha(1f).setDuration(120).start();}).start();
    }

    private void applyPremiumTier(String code,String expiry,String source){
        if(code==null||code.trim().isEmpty())code="FREE"; code=code.trim().toUpperCase();
        String label; int start,end,text;
        switch(code){
            case "ROYAL": label="ROYAL"; start=Color.rgb(255,214,96); end=Color.rgb(202,130,16); text=Color.rgb(45,27,0); break;
            case "VVIP": label="VVIP"; start=Color.rgb(233,103,255); end=Color.rgb(126,58,255); text=Color.WHITE; break;
            case "VIP": label="VIP"; start=Color.rgb(255,205,87); end=Color.rgb(255,154,66); text=Color.rgb(42,25,0); break;
            case "BLUE": label="BLUE ✓"; start=Color.rgb(72,157,255); end=Color.rgb(50,92,238); text=Color.WHITE; break;
            default: label="FREE MEMBER"; start=Color.rgb(52,38,85); end=Color.rgb(38,43,73); text=Color.rgb(220,225,243); code="FREE";
        }
        profileMemberLine.setText(label);
        profileMemberLine.setTextColor(text); profileMemberLine.setBackground(tierBackground(start,end));
        membershipStatus.setText(code.equals("FREE")?"Free Member":label+" Membership");
        if(code.equals("FREE")){
            membershipExpiry.setText("Blue • VIP • VVIP • Royal");
            profileVip.setVisibility(View.GONE); profileTierBadge.setVisibility(View.GONE);
        }else{
            String exp=expiry.isEmpty()?"No expiry":("Valid until  "+prettyDate(expiry));
            if(!source.isEmpty())exp += "  •  "+source.replace('_',' ');
            membershipExpiry.setText(exp);
            profileVip.setText(label); profileTierBadge.setText(label);
            profileVip.setTextColor(text); profileTierBadge.setTextColor(text);
            profileVip.setBackground(tierBackground(start,end)); profileTierBadge.setBackground(tierBackground(start,end));
            profileVip.setVisibility(View.VISIBLE); profileTierBadge.setVisibility(View.VISIBLE);
            pulse(profileTierBadge);
        }
    }

    private GradientDrawable tierBackground(int start,int end){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{start,end});
        g.setCornerRadius(dp(14)); g.setStroke(dp(1),Color.argb(150,255,255,255)); return g;
    }
    private void pulse(View v){
        v.clearAnimation();
        ObjectAnimator a=ObjectAnimator.ofFloat(v,"alpha",0.78f,1f); a.setDuration(1250); a.setRepeatCount(ValueAnimator.INFINITE); a.setRepeatMode(ValueAnimator.REVERSE); a.start();
    }
    private String prettyDate(String s){
        if(s==null)return ""; s=s.trim(); if(s.length()>=10)return s.substring(0,10); return s;
    }
    private void smoothButtons(int... ids){
        for(int id:ids){View v=findViewById(id);if(v==null)continue;v.setOnTouchListener((x,e)->{if(e.getAction()==android.view.MotionEvent.ACTION_DOWN)x.animate().scaleX(.97f).scaleY(.97f).alpha(.9f).setDuration(70).start();else if(e.getAction()==android.view.MotionEvent.ACTION_UP||e.getAction()==android.view.MotionEvent.ACTION_CANCEL)x.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(110).start();return false;});}
    }

    @Override protected void onDestroy(){imageIo.shutdownNow();super.onDestroy();}

    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}

    private void buyGoldDialog(){
        final String[] methods={"bKash","Nagad","Bangla QR Code"};
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(36,8,36,8);
        EditText units=input("How many Gold Coins?",""); units.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        EditText amount=input("Amount paid (৳)",""); amount.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); box.addView(units);box.addView(amount);
        new AlertDialog.Builder(this).setTitle("Buy Gold Coin").setMessage("Gold purchase is submitted for secure server/admin verification.").setView(box).setPositiveButton("Continue",(d,w)->{
            int u=toInt(units.getText().toString()); int taka=toInt(amount.getText().toString()); if(u<=0||taka<=0){Toast.makeText(this,"Enter Gold amount and payment amount.",Toast.LENGTH_SHORT).show();return;}
            new AlertDialog.Builder(this).setTitle("Payment Method").setItems(methods,(x,which)->paymentReference("GOLD","gold",u,taka*100,methods[which],new String[]{"bkash","nagad","bangla_qr"}[which],"" )).show();
        }).setNegativeButton("Cancel",null).show();
    }

    private void membershipDialog(){
        final String[] plans={"Blue Badge — Monthly","Blue Badge — Yearly","VIP Membership","VVIP Membership","Royal Membership"};
        final String[] codes={"BLUE","BLUE","VIP","VVIP","ROYAL"}; final String[] duration={"MONTHLY","YEARLY","MONTHLY","MONTHLY","MONTHLY"};
        new AlertDialog.Builder(this).setTitle("Membership & Badge").setItems(plans,(d,which)->{
            LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(36,8,36,8); EditText amount=input("Payment amount (৳) — as announced by Admin","");amount.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);box.addView(amount);
            new AlertDialog.Builder(this).setTitle(plans[which]).setMessage("Choose the current Admin-announced price. Request activates only after backend/admin verification.").setView(box).setPositiveButton("Choose Payment",(x,w)->{int taka=toInt(amount.getText().toString());if(taka<=0){Toast.makeText(this,"Enter payment amount.",Toast.LENGTH_SHORT).show();return;}String[] methods={"bKash","Nagad","Bangla QR Code"};new AlertDialog.Builder(this).setTitle("Payment Method").setItems(methods,(q,m)->paymentReference("BADGE",codes[which],1,taka*100,methods[m],new String[]{"bkash","nagad","bangla_qr"}[m],duration[which])).show();}).setNegativeButton("Cancel",null).show();
        }).show();
    }

    private void paymentReference(String type,String code,int units,int amountMinor,String methodLabel,String methodKey,String duration){
        EditText ref=input("Transaction ID / Reference","");
        new AlertDialog.Builder(this).setTitle(methodLabel+" Payment").setMessage("Pay using the configured "+methodLabel+"/QR details, then submit the transaction reference. Status remains Pending until verified.").setView(ref).setPositiveButton("Submit",(d,w)->BackendClient.requestWalletPurchase(SessionManager.getToken(this),type,code,units,amountMinor,methodKey,ref.getText().toString(),duration,new BackendClient.Callback(){public void onSuccess(JSONObject x){Toast.makeText(AccountActivity.this,"Purchase request submitted for verification.",Toast.LENGTH_LONG).show();}public void onError(String m){Toast.makeText(AccountActivity.this,m,Toast.LENGTH_LONG).show();}})).setNegativeButton("Cancel",null).show();
    }

    private void withdrawalDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(36,8,36,8); EditText g=input("Gold Coin amount","");g.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); EditText a=input("bKash/Nagad account number",""); box.addView(g);box.addView(a);
        String[] methods={"bKash","Nagad"}; new AlertDialog.Builder(this).setTitle("Withdraw Gold Coin").setView(box).setSingleChoiceItems(methods,0,null).setPositiveButton("Submit",(d,w)->{int selected=((AlertDialog)d).getListView().getCheckedItemPosition();int amount=toInt(g.getText().toString());if(amount<=0||a.getText().toString().trim().isEmpty()){Toast.makeText(this,"Enter amount and account number.",Toast.LENGTH_SHORT).show();return;}BackendClient.requestGoldWithdrawal(SessionManager.getToken(this),amount,selected==1?"nagad":"bkash",a.getText().toString().trim(),"Profile withdrawal",new BackendClient.Callback(){public void onSuccess(JSONObject x){Toast.makeText(AccountActivity.this,"Withdrawal request submitted.",Toast.LENGTH_LONG).show();loadWallet();}public void onError(String m){Toast.makeText(AccountActivity.this,m,Toast.LENGTH_LONG).show();}});}).setNegativeButton("Cancel",null).show();
    }
    private int toInt(String s){try{return Integer.parseInt(s.trim());}catch(Exception e){return 0;}}

    private void shareProfile(){ try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"MY SHOP Profile");String uid=SessionManager.getUserId(this);String display=name==null?"MY SHOP User":name.getText().toString();i.putExtra(Intent.EXTRA_TEXT,display+" • MY SHOP ID "+uid+"\nMY SHOP — https://rapid-bush-62ea.myshopsatkania.workers.dev");startActivity(Intent.createChooser(i,"Share Profile"));}catch(Exception e){Toast.makeText(this,"Share is not available.",Toast.LENGTH_SHORT).show();}}

    private void logout(){String token=SessionManager.getToken(this);SessionManager.clear(this);Intent i=new Intent(this,LoginActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(i);if(!token.isEmpty())BackendClient.logout(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){}public void onError(String m){}});}
}
