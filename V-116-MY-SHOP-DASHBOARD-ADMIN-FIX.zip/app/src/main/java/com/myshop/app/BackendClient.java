package com.myshop.app;

import android.os.Handler;
import android.os.Looper;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

/** Small dependency-free HTTP client for the Cloudflare Worker backend. */
public final class BackendClient {
    private static final ExecutorService IO = Executors.newCachedThreadPool();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private BackendClient() {}

    public interface Callback { void onSuccess(JSONObject data); void onError(String message); }

    private static String baseUrl() { return BuildConfig.MYSHOP_BACKEND_URL == null ? "" : BuildConfig.MYSHOP_BACKEND_URL.trim().replaceAll("/$", ""); }
    public static boolean configured() { return !baseUrl().isEmpty() && !baseUrl().contains("YOUR-WORKER"); }

    public static void login(String identifier, String password, Callback cb) {
        try { JSONObject b=new JSONObject().put("identifier",identifier).put("password",password); post("/v1/auth/login",b,null,cb); }
        catch(Exception e){ cb.onError("Invalid login request"); }
    }

    public static void register(String name,String email,String mobile,String password,String question,String answer,Callback cb) {
        try {
            JSONObject b=new JSONObject().put("name",name).put("email",email).put("mobile",mobile).put("password",password).put("securityQuestion",question).put("securityAnswer",answer);
            post("/v1/auth/register",b,null,cb);
        } catch(Exception e){ cb.onError("Invalid registration request"); }
    }

    public static void resetPassword(String identifier,String answer,String newPassword,Callback cb) {
        try { JSONObject b=new JSONObject().put("identifier",identifier).put("answer",answer).put("newPassword",newPassword); post("/v1/auth/password/reset",b,null,cb); }
        catch(Exception e){ cb.onError("Invalid reset request"); }
    }

    public static void me(String token,Callback cb) { get("/v1/me",token,cb); }
    public static void securityQuestions(String identifier,Callback cb) {
        try { get("/v1/auth/password/questions?identifier=" + java.net.URLEncoder.encode(identifier,"UTF-8"), null, cb); }
        catch(Exception e){ cb.onError("Invalid identifier"); }
    }
    public static void dashboard(String token,Callback cb) { get("/v1/dashboard/config",token,cb); }
    public static void logout(String token,Callback cb) { post("/v1/auth/logout",new JSONObject(),token,cb); }
    public static void adminPermissions(String token, Callback cb) { get("/v1/admin/permissions", token, cb); }
    public static void adminDashboardPut(String token, String breakingNews, String myShopUrl, String liveTvUrl, String externalMovieUrl, String chatUrl, Callback cb) {
        try {
            JSONObject b = new JSONObject().put("breakingNews", breakingNews).put("myShopUrl", myShopUrl).put("liveTvUrl", liveTvUrl).put("externalMovieUrl", externalMovieUrl).put("chatUrl", chatUrl);
            request("PUT", "/v1/admin/dashboard/config", b, token, cb);
        } catch(Exception e) { cb.onError("Invalid admin settings"); }
    }
    public static void adminAction(String token, String userId, String action, Callback cb) {
        try {
            JSONObject b = new JSONObject().put("userId", userId).put("action", action);
            post("/v1/admin/actions", b, token, cb);
        } catch(Exception e) { cb.onError("Invalid admin action"); }
    }

    private static void get(String path,String token,Callback cb) { request("GET",path,null,token,cb); }
    private static void post(String path,JSONObject body,String token,Callback cb) { request("POST",path,body,token,cb); }

    private static void request(String method,String path,JSONObject body,String token,Callback cb) {
        if(!configured()){ cb.onError("Backend URL is not configured yet."); return; }
        IO.execute(() -> {
            HttpURLConnection c=null;
            try {
                c=(HttpURLConnection)new URL(baseUrl()+path).openConnection(); c.setRequestMethod(method); c.setConnectTimeout(12000); c.setReadTimeout(15000); c.setRequestProperty("Accept","application/json");
                if(token!=null&&!token.isEmpty()) c.setRequestProperty("Authorization","Bearer "+token);
                if(body!=null){ c.setRequestProperty("Content-Type","application/json; charset=utf-8"); c.setDoOutput(true); try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));} }
                int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream(); StringBuilder s=new StringBuilder();
                if(in!=null){try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)s.append(line);}}
                JSONObject out=s.length()>0?new JSONObject(s.toString()):new JSONObject();
                MAIN.post(() -> { if(code>=200&&code<300) cb.onSuccess(out); else cb.onError(errorText(out,code)); });
            } catch(Exception e){ MAIN.post(() -> cb.onError("Backend connection failed. Check internet/Worker URL.")); }
            finally { if(c!=null)c.disconnect(); }
        });
    }
    private static String errorText(JSONObject o,int code){ String e=o.optString("error",""); if("ACCOUNT_EXISTS".equals(e))return "এই Email/Mobile দিয়ে Account আগে থেকেই আছে।"; if("INVALID_CREDENTIALS".equals(e))return "Login ID অথবা Password ভুল।"; if("ANSWER_NOT_MATCHED".equals(e))return "সিকিউরিটি উত্তর সঠিক নয়।"; if("NO_ID_AVAILABLE".equals(e))return "নতুন User ID পাওয়া যাচ্ছে না।"; return e.isEmpty()?"Server error ("+code+")":e; }
}
