package com.myshop.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(248,249,253), BLUE=Color.rgb(73,43,190), NAVY=Color.rgb(18,32,75), DARK=Color.rgb(35,38,52), RED=Color.rgb(238,35,52);
    private final Handler handler=new Handler(); private int slide=0; private ImageView hero; private TextView dots,newsText; private EditText search;
    private final int[] heroImgs={R.drawable.banner_wide_1,R.drawable.banner_wide_2,R.drawable.banner_wide_3,R.drawable.banner_wide_4,R.drawable.banner_wide_5,R.drawable.banner_wide_6};
    private final int[] left={R.drawable.banner_top_left_1,R.drawable.banner_top_left_2,R.drawable.banner_top_left_3,R.drawable.banner_top_left_4,R.drawable.banner_top_left_5,R.drawable.banner_top_left_6};
    private final int[] right={R.drawable.banner_top_right_1,R.drawable.banner_top_right_2,R.drawable.banner_top_right_3,R.drawable.banner_top_right_4,R.drawable.banner_top_right_5,R.drawable.banner_top_right_6};
    private final int[] live={R.drawable.dash_live1,R.drawable.dash_live2,R.drawable.dash_live3,R.drawable.dash_live4};
    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(build());loadRemote();startCarousel();}
    private View build(){
        FrameLayout root=new FrameLayout(this);root.setBackgroundColor(BG);
        ScrollView sv=new ScrollView(this);sv.setVerticalScrollBarEnabled(false);LinearLayout page=col();page.setPadding(dp(14),dp(8),dp(14),dp(88));
        page.addView(header(),lp(-1,dp(70))); 
        hero=pic(heroImgs[0]);page.addView(hero,top(lp(-1,dp(155)),8));
        dots=text("●   ○   ○   ○   ○   ○",BLUE,11,true);dots.setGravity(Gravity.CENTER);page.addView(dots,lp(-1,dp(28)));
        page.addView(triplePromos(),top(lp(-1,dp(118)),2));
        page.addView(breaking(),top(lp(-1,dp(48)),8));
        page.addView(sectionTitle("🔴  LIVE NOW",true),top(lp(-1,dp(38)),7));page.addView(liveRow(),lp(-1,dp(170)));
        page.addView(actionRow(),top(lp(-1,dp(105)),10));page.addView(featureGrid(),top(lp(-1,-2),10));
        sv.addView(page,new ScrollView.LayoutParams(-1,-2));root.addView(sv,new FrameLayout.LayoutParams(-1,-1));root.addView(bottom(),new FrameLayout.LayoutParams(-1,dp(70),Gravity.BOTTOM));return root;
    }
    private View header(){
        LinearLayout h=row();h.setGravity(Gravity.CENTER_VERTICAL);h.setBackground(round(Color.WHITE,Color.rgb(226,228,236),dp(24)));h.setPadding(dp(5),0,dp(5),0);
        Button menu=icon("☰",NAVY,27);menu.setOnClickListener(v->{if(SessionManager.isAdmin(this))startActivity(new android.content.Intent(this,AdminManagementActivity.class));else startActivity(new android.content.Intent(this,AccountActivity.class));});h.addView(menu,lp(dp(48),dp(60)));
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.myshop_icon);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);h.addView(logo,lp(dp(52),dp(58)));
        TextView brand=text("MY SHOP\nসবকিছু এক অ্যাপেই ❤️",Color.rgb(24,28,70),18,true);h.addView(brand,weight(0.9f,dp(62)));
        search=new EditText(this);search.setSingleLine(true);search.setTextSize(12);search.setHint("খুঁজুন পণ্য, লাইভ, ইউজার...");search.setPadding(dp(12),0,dp(8),0);search.setBackground(round(Color.WHITE,Color.rgb(225,226,233),dp(26)));h.addView(search,weight(1.3f,dp(52)));
        Button bell=icon("♧",NAVY,25);bell.setOnClickListener(v->toast("Notifications"));h.addView(bell,lp(dp(46),dp(58)));
        ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setOnClickListener(v->startActivity(new android.content.Intent(this,AccountActivity.class)));h.addView(av,lp(dp(46),dp(46)));return h;
    }
    private View triplePromos(){LinearLayout r=row();ImageView a=pic(left[0]),b=pic(right[0]),c=pic(R.drawable.banner_wide_2);r.addView(a,weight(1,dp(112)));r.addView(space(),lp(dp(6),1));r.addView(b,weight(1,dp(112)));r.addView(space(),lp(dp(6),1));r.addView(c,weight(1,dp(112)));return r;}
    private View breaking(){LinearLayout b=row();b.setPadding(dp(5),dp(4),dp(5),dp(4));b.setBackground(round(Color.WHITE,Color.rgb(230,231,237),dp(14)));TextView l=text("●  BREAKING NEWS",Color.WHITE,10,true);l.setGravity(Gravity.CENTER);l.setBackground(round(RED,RED,dp(9)));b.addView(l,lp(dp(150),dp(34)));newsText=text("বাংলাদেশে আজ স্বর্ণের দাম কিছুটা কমেছে...",Color.rgb(20,45,110),12,true);newsText.setSingleLine(true);newsText.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);newsText.setSelected(true);b.addView(newsText,weight(1,dp(34)));b.addView(text("›",NAVY,25,true),lp(dp(32),dp(34)));return b;}
    private View sectionTitle(String title,boolean all){LinearLayout h=row();h.addView(text(title,DARK,14,true),weight(1,dp(38)));if(all)h.addView(text("সব দেখুন ›",BLUE,11,true),lp(dp(75),dp(38)));return h;}
    private View liveRow(){HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout r=row();for(int i=0;i<6;i++){ImageView v=pic(live[i%4]);final int idx=i;v.setOnClickListener(x->openFeature("LIVE "+(idx+1),"live_now"));r.addView(v,lp(dp(150),dp(165)));if(i<5)r.addView(space(),lp(dp(6),1));}hs.addView(r,new HorizontalScrollView.LayoutParams(-2,-1));return hs;}
    private View actionRow(){LinearLayout r=row();ImageView liveBtn=pic(R.drawable.dash_action_live),go=pic(R.drawable.dash_action_go),feed=pic(R.drawable.dash_action_feed);liveBtn.setOnClickListener(v->openFeature("LIVE","live_now"));go.setOnClickListener(v->openFeature("GO LIVE","go_live"));feed.setOnClickListener(v->openFeature("MY FEED","my_feed"));r.addView(liveBtn,weight(1,dp(100)));r.addView(space(),lp(dp(7),1));r.addView(go,weight(1,dp(100)));r.addView(space(),lp(dp(7),1));r.addView(feed,weight(1,dp(100)));return r;}
    private View featureGrid(){LinearLayout grid=row();LinearLayout l=col(),c=col(),r=col();l.addView(tile(R.drawable.dash_feat_shop,"MY SHOP","my_shop"),lp(-1,dp(76)));l.addView(tile(R.drawable.dash_feat_gallery,"GALLERY","gallery"),top(lp(-1,dp(76)),7));l.addView(tile(R.drawable.dash_feat_tv,"LIVE TV","live_tv"),top(lp(-1,dp(76)),7));c.addView(tile(R.drawable.dash_feat_reward,"EARN & REWARD","earn_reward"),lp(-1,dp(76)));c.addView(tile(R.drawable.dash_feat_movie,"EXTERNAL","external_movie"),top(lp(-1,dp(76)),7));c.addView(tile(R.drawable.dash_feat_social,"SOCIAL","social_media"),top(lp(-1,dp(76)),7));r.addView(tile(R.drawable.dash_feat_share,"SHARE","share"),lp(-1,dp(76)));r.addView(tile(R.drawable.dash_feat_apps,"MORE APPS","more"),top(lp(-1,dp(76)),7));r.addView(tile(R.drawable.dash_feat_reward,"CHAT","chat"),top(lp(-1,dp(76)),7));grid.addView(l,weight(1,dp(252)));grid.addView(space(),lp(dp(7),1));grid.addView(c,weight(1,dp(252)));grid.addView(space(),lp(dp(7),1));grid.addView(r,weight(1,dp(252)));return grid;}
    private View tile(int res,String title,String key){ImageView v=pic(res);v.setContentDescription(title);v.setOnClickListener(x->openFeature(title,key));return v;}
    private View bottom(){LinearLayout n=row();n.setBackground(round(Color.WHITE,Color.rgb(226,227,234),dp(20)));String[] labels={"⌂\nHOME","🛒\nSTORE","◉\nLIVE","💬\nCHAT","▦\nMORE"};for(int i=0;i<5;i++){Button b=icon(labels[i],i==0?BLUE:DARK,10);final int j=i;b.setOnClickListener(v->{if(j==1)openFeature("MY SHOP","my_shop");else if(j==2)openFeature("LIVE","live_now");else if(j==3)openFeature("CHAT","chat");else if(j==4)startActivity(new android.content.Intent(this,AccountActivity.class));});n.addView(b,weight(1,dp(66)));}return n;}
    private void loadRemote(){BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(org.json.JSONObject d){runOnUiThread(()->{org.json.JSONObject c=d.optJSONObject("config");if(c!=null){String n=c.optString("breaking_news","").trim();if(!n.isEmpty())newsText.setText(n);}});}public void onError(String m){}});}
    private void startCarousel(){handler.postDelayed(new Runnable(){public void run(){slide=(slide+1)%6;hero.setImageResource(heroImgs[slide]);StringBuilder s=new StringBuilder();for(int i=0;i<6;i++){s.append(i==slide?"●":"○");if(i<5)s.append("   ");}dots.setText(s.toString());handler.postDelayed(this,3500);}},3500);}
    private void openFeature(String title,String key){try{android.content.Intent i=new android.content.Intent(this,FeatureActivity.class);i.putExtra("title",title);i.putExtra("feature_key",key);String url=FeatureRegistry.getUrl(this,key);if(FeatureRegistry.isSafeHttpUrl(url))i.putExtra("url",url);startActivity(i);}catch(Throwable t){toast(title+" is ready.");}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private ImageView pic(int r){ImageView v=new ImageView(this);v.setImageResource(r);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(round(Color.WHITE,Color.rgb(228,229,235),dp(12)));v.setClipToOutline(true);return v;}
    private Button icon(String s,int c,float z){Button b=new Button(this);b.setText(s);b.setTextColor(c);b.setTextSize(z);b.setGravity(Gravity.CENTER);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setPadding(0,0,0,0);b.setBackgroundColor(Color.TRANSPARENT);return b;}
    private TextView text(String s,int c,float z,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private View space(){return new View(this);}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private GradientDrawable round(int fill,int stroke,int rad){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(rad));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}@Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
}
