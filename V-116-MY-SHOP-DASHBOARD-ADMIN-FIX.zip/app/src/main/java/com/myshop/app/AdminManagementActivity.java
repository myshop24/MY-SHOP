package com.myshop.app;

import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** Functional admin console. All writes are authorized by the Cloudflare Worker. */
public class AdminManagementActivity extends AppCompatActivity {
    private EditText news, shopUrl, tvUrl, movieUrl, chatUrl, modId;
    private LinearLayout root;
    private int purple = Color.rgb(83, 32, 180);
    private int dark = Color.rgb(20, 28, 60);

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!SessionManager.isAdmin(this)) { finish(); return; }
        buildUi();
        loadCurrentConfig();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(22,22,22,40); root.setBackgroundColor(Color.rgb(247,248,252));
        TextView title = text("MY SHOP ADMIN PANEL", 25, dark, true); title.setGravity(Gravity.CENTER); root.addView(title, lp(-1,70));
        TextView sub = text("Admin ID: " + SessionManager.getUserId(this) + "  •  Server-authorized", 14, Color.DKGRAY, false); sub.setGravity(Gravity.CENTER); root.addView(sub,lp(-1,40));
        root.addView(section("Dashboard Content"));
        news = field("Breaking News"); shopUrl = field("MY SHOP URL"); tvUrl = field("LIVE TV URL"); movieUrl = field("External Movie URL"); chatUrl = field("Chat URL");
        Button save = button("SAVE DASHBOARD SETTINGS"); save.setOnClickListener(v -> saveConfig()); root.addView(save,lp(-1,58));
        root.addView(section("Moderators (maximum 5)"));
        modId = field("4-digit User ID");
        LinearLayout mr = new LinearLayout(this); mr.setOrientation(LinearLayout.HORIZONTAL);
        Button add = button("ADD MODERATOR"); Button remove = button("REMOVE MODERATOR");
        add.setOnClickListener(v -> moderator("add_moderator")); remove.setOnClickListener(v -> moderator("remove_moderator"));
        mr.addView(add,weight(1)); mr.addView(remove,weight(1)); root.addView(mr);
        TextView note = text("Admin-only controls are hidden from normal users. Existing User IDs and database records are not reset by this panel.",13,Color.DKGRAY,false); note.setPadding(0,24,0,12); root.addView(note);
        Button back=button("BACK"); back.setOnClickListener(v->finish()); root.addView(back,lp(-1,54));
        scroll.addView(root); setContentView(scroll);
    }

    private void loadCurrentConfig(){
        BackendClient.dashboard(SessionManager.getToken(this), new BackendClient.Callback(){
            public void onSuccess(org.json.JSONObject d){ runOnUiThread(() -> { org.json.JSONObject c=d.optJSONObject("config"); if(c!=null){news.setText(c.optString("breaking_news","")); shopUrl.setText(c.optString("my_shop_url","")); tvUrl.setText(c.optString("live_tv_url","")); movieUrl.setText(c.optString("external_movie_url","")); chatUrl.setText(c.optString("chat_url",""));} }); }
            public void onError(String m){ runOnUiThread(() -> toast("Config load: "+m)); }
        });
    }
    private void saveConfig(){
        BackendClient.adminDashboardPut(SessionManager.getToken(this),news.getText().toString().trim(),shopUrl.getText().toString().trim(),tvUrl.getText().toString().trim(),movieUrl.getText().toString().trim(),chatUrl.getText().toString().trim(),new BackendClient.Callback(){
            public void onSuccess(org.json.JSONObject d){toast("Dashboard settings saved.");}
            public void onError(String m){toast("Save failed: "+m);}
        });
    }
    private void moderator(String action){
        String id=modId.getText().toString().trim(); if(!id.matches("\\d{4}")){toast("Enter a valid 4-digit User ID.");return;}
        BackendClient.adminAction(SessionManager.getToken(this),id,action,new BackendClient.Callback(){
            public void onSuccess(org.json.JSONObject d){toast(action.equals("add_moderator")?"Moderator added.":"Moderator removed.");}
            public void onError(String m){toast("Action failed: "+m);}
        });
    }
    private TextView section(String s){ TextView t=text(s,19,purple,true); t.setPadding(0,22,0,8); return t; }
    private EditText field(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setTextSize(15); e.setSingleLine(true); e.setPadding(16,0,16,0); root.addView(e,lp(-1,58)); return e; }
    private Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(13); b.setAllCaps(false); return b; }
    private TextView text(String s,float z,int c,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(z); t.setTextColor(c); if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD); return t; }
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams weight(float w){return new LinearLayout.LayoutParams(0,58,w);}
    private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
}
