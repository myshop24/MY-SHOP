# MY SHOP Developer Handoff — V-332

**Version:** V-332  
**Android:** versionCode 332 / versionName 2.9.332  
**Phase:** Focused completion / regression-safe correction

## Completed in source
- Premium dark Admin left navigation based on approved Catalog reference.
- Dead `Coin / Gold Coin Purchase Packages` Admin menu removed.
- Gift Coin / Gold Coin sidebar entries open the matching catalog currency.
- Message notification channel hardened for heads-up delivery.
- Dedicated Live Alerts high-importance channel + direct Audio Live Room deep-link.
- Worker LIVE_START now sends real FCM push to active registered Android tokens.
- Gift sound selection now clearly uses phone audio picker; sound URL remains hidden.
- Sound trim waveform enlarged and preview playback lifecycle/error handling hardened.

## Pending external verification
- GitHub CI compile/sign.
- Deploy Worker V-332 for LIVE_START push backend change.
- Device tests: app open/background/closed + lockscreen message/live heads-up.
- Device tests: audio picker, trim curve, Test/Preview sound, Save/upload, reload, live gift playback.
- Visual compare Admin sidebar/Catalog against approved reference image.

## Locked modules
- Main Home Dashboard approved design.
- Admin Give Coin / Gold flow.
- Live seat structure: Host separate + 12 guest/user seats (6+6).
- Economy/purchased-vs-earned rules.

## Next checkpoint
Do not start another large module until V-332 target is device/CI verified. Correct V-332 target issues first if any acceptance test fails.

## V-332 build correction
- Fixed missing `round(int fill, int stroke, int radius)` helper in `LiveGiftAdminActivity` that caused `cannot find symbol` at the trim waveform background line.
- Re-run GitHub Actions. Do not mark device/audio/notification behavior PASS until real-device verification.
