package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.Locale;

/** V-326 focused premium Gift Coin + Gold Coin catalog manager. */
public class LiveGiftAdminActivity extends androidx.appcompat.app.AppCompatActivity {
    private static final int PICK_PREVIEW=9301, PICK_ANIM=9302, PICK_SOUND=9303, PICK_QUICK=9304, PICK_CATALOG_ANIM=9305;
    private static final String[] CATALOG_TYPES={"AUTO","PULSE","BOUNCE","FLOAT","GLOW","SPARKLE","ROTATE","SLIDE"};

    private String selectedCurrency="COIN";
    private LinearLayout list,editor;
    private JSONArray currentGifts=new JSONArray();
    private TextView catalogTitle,editorTitle,uploadState,volumeValue,scaleValue,catalogSizeValue,catalogStrengthValue,catalogSpeedValue,catalogGlowValue,vatValue,globalVatValue,trimStartValue,trimEndValue,selectedSoundInfo;
    private Button addNewButton,coinTab,goldTab,deleteEditorButton;
    private EditText name,price,category,preview,animation,sound,order,catalogAnimation,effectDurationSec,soundDurationSec;
    private SeekBar volume,animationScale,catalogSize,catalogStrength,catalogSpeed,catalogGlow,vatPercent,globalVat,trimStart,trimEnd;
    private CheckBox enabled,animOn,soundOn,catalogEnabled,catalogLoop;
    private Spinner catalogType,boardPosition,boxSelector;
    private long editId=0;
    private TrimWaveformView trimWaveform;
    private JSONObject quickGift=null;
    private String quickKind="";
    private Uri pendingSoundUri=null;
    private String pendingSoundName="",pendingSoundMime="";
    private long pendingSoundDurationMs=0;
    private android.media.MediaPlayer previewPlayer=null;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        if(!SessionManager.isAdmin(this)){finish();return;}
        String startCurrency=getIntent().getStringExtra("currency");
        if("GOLD".equalsIgnoreCase(startCurrency))selectedCurrency="GOLD";
        build();styleTabs();load(selectedCurrency);
    }

    private void build(){
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);
        LinearLayout root=col();root.setPadding(dp(12),dp(12),dp(12),dp(34));
        root.setBackground(gradient(new int[]{Color.rgb(249,250,255),Color.rgb(244,247,255),Color.rgb(255,247,253)},Color.TRANSPARENT,0));

        LinearLayout hero=premiumCard("COIN",0);hero.setPadding(dp(14),dp(13),dp(14),dp(13));
        LinearLayout top=row();Button back=actionButton("‹",Color.rgb(67,82,225),Color.rgb(145,65,220));back.setOnClickListener(v->finish());top.addView(back,new LinearLayout.LayoutParams(dp(48),dp(46)));
        LinearLayout brand=col();brand.addView(txt("GIFT COIN & GOLD COIN CATALOG",18.5f,true,Color.rgb(27,30,68)));brand.addView(txt("গিফট কয়েন ও গোল্ড কয়েন ক্যাটালগ",11,true,Color.rgb(104,63,181)));brand.addView(txt("Price • Sound Trim • Effect • Box Position • VAT",9.3f,false,Color.rgb(101,104,135)));top.addView(brand,new LinearLayout.LayoutParams(0,dp(66),1));hero.addView(top);
        TextView garden=txt("✦  🌸  Animated Gift Garden • সহজ Admin Control  🌸  ✦",10.5f,true,Color.rgb(177,56,140));garden.setGravity(Gravity.CENTER);hero.addView(garden,new LinearLayout.LayoutParams(-1,dp(34)));root.addView(hero,top(-1,-2,0));

        LinearLayout tabs=row();coinTab=actionButton("1  🪙  GIFT COIN",Color.rgb(64,101,239),Color.rgb(113,69,226));goldTab=actionButton("2  👑  GOLD COIN",Color.rgb(224,153,38),Color.rgb(235,88,135));
        coinTab.setOnClickListener(v->{selectedCurrency="COIN";clearEditor(false);styleTabs();load("COIN");});
        goldTab.setOnClickListener(v->{selectedCurrency="GOLD";clearEditor(false);styleTabs();load("GOLD");});
        tabs.addView(coinTab,wt(1));tabs.addView(goldTab,wt(1));root.addView(tabs,top(-1,dp(54),10));styleTabs();

        LinearLayout global=premiumCard("COIN",7);global.addView(txt("GLOBAL VAT • সব Gift-এ একসাথে",12.5f,true,Color.rgb(65,45,128)));
        LinearLayout gv=row();globalVat=slider(10);globalVatValue=value("10%",Color.rgb(198,118,28));bindValue(globalVat,globalVatValue);gv.addView(globalVat,new LinearLayout.LayoutParams(0,dp(44),1));gv.addView(globalVatValue,new LinearLayout.LayoutParams(dp(58),dp(44)));global.addView(gv);
        Button applyVat=actionButton("APPLY VAT TO ALL GIFTS IN THIS CATALOG",Color.rgb(234,145,39),Color.rgb(205,70,148));applyVat.setOnClickListener(v->applyGlobalVat());global.addView(applyVat,new LinearLayout.LayoutParams(-1,dp(46)));root.addView(global,top(-1,-2,8));

        LinearLayout help=premiumCard("COIN",1);help.addView(txt("সহজ নিয়ম",12.5f,true,Color.rgb(45,43,86)));
        help.addView(txt("Gift card চাপুন = Edit  •  চেপে ধরে টানুন = ঘর বদল  •  Sound বাছুন = Trim + Test, Save-এর আগে upload হবে না।",9.5f,false,Color.rgb(92,94,126)));root.addView(help,top(-1,-2,8));

        addNewButton=actionButton("＋  ADD NEW GIFT COIN GIFT",Color.rgb(36,179,134),Color.rgb(55,110,226));
        addNewButton.setOnClickListener(v->{clearEditor(true);editor.setVisibility(View.VISIBLE);editorTitle.setText("＋ New "+("COIN".equals(selectedCurrency)?"Gift Coin":"Gold Coin")+" Gift");});root.addView(addNewButton,top(-1,dp(52),8));

        editor=premiumCard("COIN",2);editor.setVisibility(View.GONE);editorTitle=txt("New Gift",16,true,Color.rgb(49,43,98));editor.addView(editorTitle);
        name=input("Gift name");price=input("Price");price.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);category=input("Category e.g. LOVE / LUXURY / SPECIAL");category.setText("ALL");
        editor.addView(label("① Gift name + price"));editor.addView(name,h48());editor.addView(price,h48());editor.addView(category,h48());

        preview=input("Preview image URL");animation=input("Live Send animation GIF/WebP URL");sound=input("Saved sound URL");sound.setVisibility(View.GONE);catalogAnimation=input("Catalog animation GIF/WebP URL (optional)");
        editor.addView(label("② Gift assets • Sound ফোন থেকে বাছুন, আগে Trim/Test করুন"));editor.addView(preview,h48());editor.addView(animation,h48());editor.addView(catalogAnimation,h48());
        LinearLayout assetBtns=row();Button imageBtn=miniColor("🖼 Image",Color.rgb(65,116,235),Color.rgb(91,72,210)),animBtn=miniColor("✨ Live Anim",Color.rgb(171,67,212),Color.rgb(235,77,151)),soundBtn=miniColor("🎵 CHOOSE AUDIO FROM PHONE",Color.rgb(31,176,146),Color.rgb(61,123,226));imageBtn.setOnClickListener(v->pick(PICK_PREVIEW,"image",null));animBtn.setOnClickListener(v->pick(PICK_ANIM,"animation",null));soundBtn.setOnClickListener(v->pick(PICK_SOUND,"sound",null));assetBtns.addView(imageBtn,wt(1));assetBtns.addView(animBtn,wt(1));assetBtns.addView(soundBtn,wt(1));editor.addView(assetBtns,top(-1,dp(46),4));
        selectedSoundInfo=txt("🔊 Sound: এখনো নতুন file বাছা হয়নি",9.5f,true,Color.rgb(43,118,136));editor.addView(selectedSoundInfo,new LinearLayout.LayoutParams(-1,dp(38)));
        LinearLayout soundActions=row();Button testSound=miniColor("▶ TEST / PREVIEW",Color.rgb(36,166,140),Color.rgb(70,104,224)),removeSound=miniColor("✕ REMOVE SOUND",Color.rgb(215,82,104),Color.rgb(174,72,157));testSound.setOnClickListener(v->previewTrimmedSound());removeSound.setOnClickListener(v->{pendingSoundUri=null;pendingSoundName="";pendingSoundMime="";pendingSoundDurationMs=0;sound.setText("");soundOn.setChecked(false);selectedSoundInfo.setText("🔇 Sound removed • Save করলে কার্যকর হবে");updateTrimLabels();});soundActions.addView(testSound,wt(1));soundActions.addView(removeSound,wt(1));editor.addView(soundActions,new LinearLayout.LayoutParams(-1,dp(44)));
        LinearLayout catalogAssetBtns=row();Button catalogAnimBtn=miniColor("🌟 Add/Replace Catalog Animation",Color.rgb(233,102,67),Color.rgb(181,62,188)),catalogPreviewBtn=miniColor("▶ PREVIEW / TEST",Color.rgb(72,92,222),Color.rgb(164,64,204));catalogAnimBtn.setOnClickListener(v->pick(PICK_CATALOG_ANIM,"catalog_animation",null));catalogPreviewBtn.setOnClickListener(v->previewCatalogEditor());catalogAssetBtns.addView(catalogAnimBtn,new LinearLayout.LayoutParams(0,dp(46),.58f));catalogAssetBtns.addView(catalogPreviewBtn,new LinearLayout.LayoutParams(0,dp(46),.42f));editor.addView(catalogAssetBtns,top(-1,dp(46),4));
        uploadState=txt("No upload in progress",9,false,Color.rgb(99,102,132));editor.addView(uploadState);

        editor.addView(label("③ CATALOG ANIMATION • Gift Store-এ বসা অবস্থার motion"));
        catalogEnabled=check("Catalog Animation ON",true);catalogLoop=check("Loop ON",true);LinearLayout catalogChecks=row();catalogChecks.addView(catalogEnabled,wt(1));catalogChecks.addView(catalogLoop,wt(1));editor.addView(catalogChecks);
        catalogType=new Spinner(this);ArrayAdapter<String> typeAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,CATALOG_TYPES);catalogType.setAdapter(typeAdapter);editor.addView(txt("Animation Type",10,true,Color.rgb(78,80,112)));editor.addView(catalogType,new LinearLayout.LayoutParams(-1,dp(48)));
        catalogSize=slider(68);catalogSizeValue=value("68%",Color.rgb(229,91,93));editor.addView(sliderRow("Preview Size 0–100%",catalogSize,catalogSizeValue));
        catalogStrength=slider(42);catalogStrengthValue=value("42%",Color.rgb(164,65,196));editor.addView(sliderRow("Animation Strength 0–100%",catalogStrength,catalogStrengthValue));
        catalogSpeed=slider(45);catalogSpeedValue=value("45%",Color.rgb(69,105,220));editor.addView(sliderRow("Animation Speed 0–100%",catalogSpeed,catalogSpeedValue));
        catalogGlow=slider(35);catalogGlowValue=value("35%",Color.rgb(205,134,34));editor.addView(sliderRow("Glow / Particle 0–100%",catalogGlow,catalogGlowValue));
        bindValue(catalogSize,catalogSizeValue);bindValue(catalogStrength,catalogStrengthValue);bindValue(catalogSpeed,catalogSpeedValue);bindValue(catalogGlow,catalogGlowValue);

        editor.addView(label("④ LIVE SEND ANIMATION size 0–100% • Send-এর পর বড় effect"));LinearLayout scaleLine=row();animationScale=slider(72);scaleValue=value("72%",Color.rgb(183,55,156));bindValue(animationScale,scaleValue);scaleLine.addView(animationScale,new LinearLayout.LayoutParams(0,dp(46),1));scaleLine.addView(scaleValue,new LinearLayout.LayoutParams(dp(58),dp(46)));editor.addView(scaleLine);
        LinearLayout scalePreset=row();int[] sp={0,35,70,100};String[] sn={"Small","Medium","Large","Max"};for(int i=0;i<sn.length;i++){final int x=sp[i];Button q=mini(sn[i]);q.setOnClickListener(v->animationScale.setProgress(x));scalePreset.addView(q,wt(1));}editor.addView(scalePreset,top(-1,dp(39),2));
        editor.addView(txt("Board Position",10,true,Color.rgb(78,80,112)));boardPosition=new Spinner(this);String[] bp={"CENTER","TOP","BOTTOM","FULL_SCREEN"};boardPosition.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,bp));editor.addView(boardPosition,new LinearLayout.LayoutParams(-1,dp(48)));

        editor.addView(label("⑤ SOUND volume 0–100%"));LinearLayout volLine=row();volume=slider(85);volumeValue=value("85%",Color.rgb(75,52,180));bindValue(volume,volumeValue);volLine.addView(volume,new LinearLayout.LayoutParams(0,dp(46),1));volLine.addView(volumeValue,new LinearLayout.LayoutParams(dp(58),dp(46)));editor.addView(volLine);
        LinearLayout presets=row();int[] vals={0,35,70,90};String[] vs={"Mute","Low","Strong","High"};for(int i=0;i<vs.length;i++){final int x=vals[i];Button q=mini(vs[i]);q.setOnClickListener(v->volume.setProgress(x));presets.addView(q,wt(1));}editor.addView(presets,top(-1,dp(39),2));

        editor.addView(label("⑥ GIFT / SOUND DURATION • কতক্ষণ থাকবে"));
        LinearLayout durationRow=row();effectDurationSec=input("Gift effect seconds (0.5–15)");soundDurationSec=input("Sound seconds (0–15)");effectDurationSec.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);soundDurationSec.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);effectDurationSec.setText("2.8");soundDurationSec.setText("2.5");durationRow.addView(effectDurationSec,wt(1));durationRow.addView(soundDurationSec,wt(1));editor.addView(durationRow,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView durationHelp=txt("Gift Display Duration = Live board effect time  •  Sound Duration = selected audio clip play time",9,false,Color.rgb(108,91,143));editor.addView(durationHelp);

        editor.addView(label("⑦ SOUND TRIM / CROP • গানটির কোন অংশ বাজবে"));
        trimStart=slider(0);trimEnd=slider(100);trimStartValue=value("Start 0%",Color.rgb(44,142,131));trimEndValue=value("End 100%",Color.rgb(207,86,129));
        trimStart.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar x,int v,boolean f){if(v>=trimEnd.getProgress())x.setProgress(Math.max(0,trimEnd.getProgress()-1));updateTrimLabels();updateTrimWaveform();}public void onStartTrackingTouch(SeekBar x){}public void onStopTrackingTouch(SeekBar x){}});
        trimEnd.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar x,int v,boolean f){if(v<=trimStart.getProgress())x.setProgress(Math.min(100,trimStart.getProgress()+1));updateTrimLabels();updateTrimWaveform();}public void onStartTrackingTouch(SeekBar x){}public void onStopTrackingTouch(SeekBar x){}});
        LinearLayout ts=row();ts.addView(trimStart,new LinearLayout.LayoutParams(0,dp(44),1));ts.addView(trimStartValue,new LinearLayout.LayoutParams(dp(86),dp(44)));editor.addView(ts);
        LinearLayout te=row();te.addView(trimEnd,new LinearLayout.LayoutParams(0,dp(44),1));te.addView(trimEndValue,new LinearLayout.LayoutParams(dp(86),dp(44)));editor.addView(te);
        trimWaveform=new TrimWaveformView(this);trimWaveform.setBackground(round(Color.rgb(247,244,255),Color.rgb(185,174,236),14));editor.addView(trimWaveform,new LinearLayout.LayoutParams(-1,dp(96)));updateTrimWaveform();
        editor.addView(txt("Sound file Add/Replace করার পর Start/End slider দিয়ে যে অংশটি বাজবে সেটি বাছুন। মাঝের highlighted অংশটাই ব্যবহার হবে।",9,false,Color.rgb(93,96,127)));
        Button testTrim=miniColor("▶ TEST SELECTED SOUND PART",Color.rgb(35,164,143),Color.rgb(81,91,220));testTrim.setOnClickListener(v->previewTrimmedSound());editor.addView(testTrim,new LinearLayout.LayoutParams(-1,dp(44)));

        editor.addView(label("⑧ VAT 0–100% • এই Gift-এর platform VAT"));LinearLayout vatLine=row();vatPercent=slider(10);vatValue=value("10%",Color.rgb(197,117,27));bindValue(vatPercent,vatValue);vatLine.addView(vatPercent,new LinearLayout.LayoutParams(0,dp(44),1));vatLine.addView(vatValue,new LinearLayout.LayoutParams(dp(58),dp(44)));editor.addView(vatLine);

        editor.addView(label("⑨ CATALOG BOX / POSITION • কোন ঘরে Gift থাকবে"));
        boxSelector=new Spinner(this);refreshBoxSelector(1);boxSelector.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){if(order!=null)order.setText(String.valueOf(pos+1));}public void onNothingSelected(android.widget.AdapterView<?> a){}});
        editor.addView(boxSelector,new LinearLayout.LayoutParams(-1,dp(50)));
        order=input("Position number");order.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);order.setText("1");order.setVisibility(View.GONE);editor.addView(order,new LinearLayout.LayoutParams(1,1));
        editor.addView(txt("Tip: Gift card চেপে ধরে অন্য ঘরে Drag করেও position বদলাতে পারবেন।",9,false,Color.rgb(93,96,127)));
        enabled=check("Published / Enabled",true);animOn=check("Live Send Animation ON",true);soundOn=check("Sound ON",true);editor.addView(enabled);editor.addView(animOn);editor.addView(soundOn);

        Button livePreview=actionButton("👁 PREVIEW ON LIVE BOARD",Color.rgb(84,76,221),Color.rgb(201,63,176));livePreview.setOnClickListener(v->previewLiveBoard());editor.addView(livePreview,top(-1,dp(48),6));
        LinearLayout editActions=row();Button draft=actionButton("💾 SAVE DRAFT",Color.rgb(94,104,139),Color.rgb(116,83,164)),publish=actionButton("✓ SAVE / PUBLISH",Color.rgb(45,178,126),Color.rgb(70,91,222));draft.setOnClickListener(v->{enabled.setChecked(false);saveEditor();});publish.setOnClickListener(v->{enabled.setChecked(true);saveEditor();});editActions.addView(draft,wt(1));editActions.addView(publish,wt(1));editor.addView(editActions,top(-1,dp(50),6));
        LinearLayout dangerActions=row();deleteEditorButton=actionButton("🗑 DELETE GIFT",Color.rgb(218,68,91),Color.rgb(175,65,142));Button cancel=actionButton("CANCEL",Color.rgb(105,111,137),Color.rgb(128,102,152));deleteEditorButton.setOnClickListener(v->deleteCurrentGift());cancel.setOnClickListener(v->editor.setVisibility(View.GONE));dangerActions.addView(deleteEditorButton,wt(1));dangerActions.addView(cancel,wt(1));editor.addView(dangerActions,top(-1,dp(48),5));root.addView(editor,top(-1,-2,8));

        catalogTitle=txt("🪙 Gift Coin Catalog",16,true,Color.rgb(37,40,78));root.addView(catalogTitle,top(-1,dp(44),12));list=col();root.addView(list,new LinearLayout.LayoutParams(-1,-2));
        sv.addView(root);setContentView(sv);
    }

    private void styleTabs(){boolean c="COIN".equals(selectedCurrency);coinTab.setAlpha(c?1f:.52f);goldTab.setAlpha(c ? .52f : 1f);if(addNewButton!=null)addNewButton.setText("＋  ADD NEW "+(c?"GIFT COIN":"GOLD COIN")+" GIFT");}

    private void load(String currency){
        selectedCurrency=currency;styleTabs();catalogTitle.setText(("COIN".equals(currency)?"🪙 Gift Coin Catalog":"👑 Gold Coin Catalog")+"  •  সব Gift নিচে");
        list.removeAllViews();TextView wait=txt("Loading catalog…",11,false,Color.rgb(100,103,132));wait.setGravity(Gravity.CENTER);list.addView(wait,new LinearLayout.LayoutParams(-1,dp(80)));
        BackendClient.adminLiveGifts(SessionManager.getToken(this),currency,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->render(o.optJSONArray("gifts")));}public void onError(String m){runOnUiThread(()->{list.removeAllViews();list.addView(txt("Catalog load failed: "+m,11,false,Color.rgb(170,45,65)));});}});
    }

    private void render(JSONArray a){
        list.removeAllViews();currentGifts=a==null?new JSONArray():a;
        if(a==null||a.length()==0){TextView e=txt("No gifts yet • + ADD NEW GIFT চাপুন",11,false,Color.rgb(100,104,132));e.setGravity(Gravity.CENTER);list.addView(e,new LinearLayout.LayoutParams(-1,dp(90)));return;}
        TextView count=txt("মোট "+a.length()+" টি Gift • চাপুন Edit • চেপে ধরে টেনে ঘর বদলান",10.2f,true,Color.rgb(83,67,150));count.setGravity(Gravity.CENTER);list.addView(count,new LinearLayout.LayoutParams(-1,dp(42)));
        final GridLayout grid=new GridLayout(this);grid.setColumnCount(4);grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);grid.setUseDefaultMargins(false);
        int itemW=Math.max(dp(74),(getResources().getDisplayMetrics().widthPixels-dp(34))/4),itemH=dp(126);
        for(int i=0;i<a.length();i++){
            final JSONObject g=a.optJSONObject(i);if(g==null)continue;final int index=i;
            LinearLayout card=premiumCard(g.optString("currency","COIN"),i);card.setPadding(dp(5),dp(5),dp(5),dp(5));card.setGravity(Gravity.CENTER_HORIZONTAL);card.setClickable(true);card.setFocusable(true);card.setOnClickListener(v->fillEditor(g));
            ImageView art=new ImageView(this);art.setScaleType(ImageView.ScaleType.CENTER_INSIDE);String u=g.optString("preview_url","");if(u.isEmpty())u=g.optString("catalog_animation_url","");if(u.isEmpty())u=g.optString("animation_url","");if(!u.isEmpty())AnimatedAssetLoader.load(art,u);else art.setImageResource(builtInArt(g.optString("name","Gift")));card.addView(art,new LinearLayout.LayoutParams(dp(58),dp(58)));
            TextView nm=txt(g.optString("name","Gift"),9.1f,true,Color.rgb(31,33,66));nm.setSingleLine(true);nm.setEllipsize(android.text.TextUtils.TruncateAt.END);nm.setGravity(Gravity.CENTER);card.addView(nm,new LinearLayout.LayoutParams(-1,dp(25)));
            TextView pr=txt(("GOLD".equals(g.optString("currency"))?"👑 ":"🪙 ")+g.optInt("price",1),8.9f,true,Color.rgb(171,102,30));pr.setGravity(Gravity.CENTER);card.addView(pr,new LinearLayout.LayoutParams(-1,dp(22)));
            TextView slot=txt("ঘর "+(i+1),8.1f,true,Color.rgb(82,91,171));slot.setGravity(Gravity.CENTER);card.addView(slot,new LinearLayout.LayoutParams(-1,dp(20)));
            card.setOnLongClickListener(v->{android.content.ClipData data=android.content.ClipData.newPlainText("giftId",String.valueOf(g.optLong("id")));android.view.View.DragShadowBuilder shadow=new android.view.View.DragShadowBuilder(v);if(android.os.Build.VERSION.SDK_INT>=24)v.startDragAndDrop(data,shadow,index,0);else v.startDrag(data,shadow,index,0);v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);return true;});
            card.setOnDragListener((v,event)->{switch(event.getAction()){case android.view.DragEvent.ACTION_DRAG_ENTERED:v.setScaleX(1.06f);v.setScaleY(1.06f);v.setAlpha(.78f);return true;case android.view.DragEvent.ACTION_DRAG_EXITED:v.setScaleX(1f);v.setScaleY(1f);v.setAlpha(1f);return true;case android.view.DragEvent.ACTION_DROP:v.setScaleX(1f);v.setScaleY(1f);v.setAlpha(1f);Object local=event.getLocalState();if(local instanceof Integer){moveGift((Integer)local,index);}return true;case android.view.DragEvent.ACTION_DRAG_ENDED:v.setScaleX(1f);v.setScaleY(1f);v.setAlpha(1f);return true;default:return true;}});
            GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=itemW;gp.height=itemH;gp.setMargins(dp(2),dp(3),dp(2),dp(3));grid.addView(card,gp);
        }
        list.addView(grid,new LinearLayout.LayoutParams(-1,-2));
    }

    private void moveGift(int from,int to){
        if(from<0||to<0||from>=currentGifts.length()||to>=currentGifts.length()||from==to)return;
        try{java.util.ArrayList<JSONObject> items=new java.util.ArrayList<>();for(int i=0;i<currentGifts.length();i++)items.add(currentGifts.getJSONObject(i));JSONObject first=items.get(from),second=items.get(to);items.set(to,first);items.set(from,second);JSONArray next=new JSONArray(),ids=new JSONArray();for(int i=0;i<items.size();i++){JSONObject g=items.get(i);g.put("sort_order",i+1);next.put(g);ids.put(g.optLong("id"));}currentGifts=next;render(currentGifts);BackendClient.adminLiveGiftReorder(SessionManager.getToken(this),selectedCurrency,ids,new BackendClient.Callback(){public void onSuccess(JSONObject o){toast("Gift-এর ঘর Save হয়েছে • Live catalog-ও একই order");}public void onError(String m){toast("Order save failed: "+m);load(selectedCurrency);}});}catch(Exception e){toast("Gift move failed");}
    }

    private void quickSave(JSONObject g,EditText pr,EditText ord,SeekBar scale,SeekBar vb,CheckBox pub,CheckBox ao,CheckBox catalogOn,boolean soundEnabled,String overrideKey,String overrideValue){
        try{int sc=scale.getProgress();JSONObject x=fromGift(g).put("price",num(pr,g.optInt("price",1))).put("animationScale",sc).put("sizeMode",modeForScale(sc)).put("sortOrder",numZero(ord,g.optInt("sort_order",100))).put("soundVolume",vb.getProgress()).put("enabled",pub.isChecked()).put("animationEnabled",ao.isChecked()).put("catalogAnimationEnabled",catalogOn==null||catalogOn.isChecked()).put("soundEnabled",soundEnabled);if(overrideKey!=null)x.put(apiKey(overrideKey),overrideValue);BackendClient.adminLiveGiftSave(SessionManager.getToken(this),x,new BackendClient.Callback(){public void onSuccess(JSONObject o){toast("Saved • Live Gift Store auto-updated");load(selectedCurrency);}public void onError(String m){toast(m);}});}catch(Exception e){toast("Please check gift settings");}
    }

    private String apiKey(String db){if("sound_url".equals(db))return "soundUrl";if("preview_url".equals(db))return "previewUrl";if("animation_url".equals(db))return "animationUrl";if("catalog_animation_url".equals(db))return "catalogAnimationUrl";return db;}
    private JSONObject fromGift(JSONObject g)throws Exception{return new JSONObject().put("id",g.optLong("id")).put("name",g.optString("name","Gift")).put("currency",g.optString("currency",selectedCurrency)).put("price",g.optInt("price",1)).put("category",g.optString("category","ALL")).put("previewUrl",g.optString("preview_url","")).put("animationUrl",g.optString("animation_url","")).put("animationMime",g.optString("animation_mime","")).put("animationEnabled",g.optInt("animation_enabled",1)==1).put("soundUrl",g.optString("sound_url","")).put("soundEnabled",g.optInt("sound_enabled",1)==1).put("soundVolume",g.optInt("sound_volume",85)).put("effectDurationMs",g.optInt("effect_duration_ms",2800)).put("soundDurationMs",g.optInt("sound_duration_ms",2500)).put("soundTrimStartPct",g.optInt("sound_trim_start_pct",0)).put("soundTrimEndPct",g.optInt("sound_trim_end_pct",100)).put("vatPercent",g.optInt("vat_percent",10)).put("boardPosition",g.optString("board_position","CENTER")).put("animationScale",scaleOf(g)).put("sizeMode",modeForScale(scaleOf(g))).put("catalogAnimationEnabled",g.optInt("catalog_animation_enabled",1)==1).put("catalogAnimationType",g.optString("catalog_animation_type","AUTO")).put("catalogPreviewSize",g.optInt("catalog_preview_size",68)).put("catalogAnimationStrength",g.optInt("catalog_animation_strength",42)).put("catalogAnimationSpeed",g.optInt("catalog_animation_speed",45)).put("catalogGlowParticle",g.optInt("catalog_glow_particle",35)).put("catalogLoop",g.optInt("catalog_loop",1)==1).put("catalogAnimationUrl",g.optString("catalog_animation_url","")).put("sortOrder",g.optInt("sort_order",100)).put("enabled",g.optInt("enabled",1)==1);}

    private int scaleOf(JSONObject g){if(g.has("animation_scale"))return Math.max(0,Math.min(100,g.optInt("animation_scale",70)));String m=g.optString("size_mode","MEDIUM").toUpperCase(Locale.US);if("SMALL".equals(m))return 15;if("LARGE".equals(m))return 75;if("FULL_SCREEN".equals(m))return 100;return 48;}
    private String modeForScale(int s){if(s<=20)return "SMALL";if(s<=58)return "MEDIUM";if(s<=84)return "LARGE";return "FULL_SCREEN";}

    private void fillEditor(JSONObject g){pendingSoundUri=null;pendingSoundName="";pendingSoundMime="";pendingSoundDurationMs=0;editId=g.optLong("id");editor.setVisibility(View.VISIBLE);editorTitle.setText("✏ Edit • "+g.optString("name","Gift"));name.setText(g.optString("name"));price.setText(String.valueOf(g.optInt("price",1)));category.setText(g.optString("category","ALL"));preview.setText(g.optString("preview_url"));animation.setText(g.optString("animation_url"));sound.setText(g.optString("sound_url"));selectedSoundInfo.setText(g.optString("sound_url","").isEmpty()?"🔊 Sound: কোনো uploaded sound নেই":"🔊 Saved sound আছে • Replace করতে Sound চাপুন");catalogAnimation.setText(g.optString("catalog_animation_url"));volume.setProgress(g.optInt("sound_volume",85));effectDurationSec.setText(formatSeconds(g.optInt("effect_duration_ms",2800)));soundDurationSec.setText(formatSeconds(g.optInt("sound_duration_ms",2500)));trimStart.setProgress(g.optInt("sound_trim_start_pct",0));trimEnd.setProgress(g.optInt("sound_trim_end_pct",100));vatPercent.setProgress(g.optInt("vat_percent",10));selectBoardPosition(g.optString("board_position","CENTER"));animationScale.setProgress(scaleOf(g));catalogSize.setProgress(g.optInt("catalog_preview_size",68));catalogStrength.setProgress(g.optInt("catalog_animation_strength",42));catalogSpeed.setProgress(g.optInt("catalog_animation_speed",45));catalogGlow.setProgress(g.optInt("catalog_glow_particle",35));selectCatalogType(g.optString("catalog_animation_type","AUTO"));catalogEnabled.setChecked(g.optInt("catalog_animation_enabled",1)==1);catalogLoop.setChecked(g.optInt("catalog_loop",1)==1);int pos=Math.max(1,g.optInt("sort_order",1));refreshBoxSelector(Math.max(currentGifts.length(),1));boxSelector.setSelection(Math.min(Math.max(0,pos-1),boxSelector.getCount()-1));order.setText(String.valueOf(pos));enabled.setChecked(g.optInt("enabled",1)==1);animOn.setChecked(g.optInt("animation_enabled",1)==1);soundOn.setChecked(g.optInt("sound_enabled",1)==1);if(deleteEditorButton!=null)deleteEditorButton.setVisibility(View.VISIBLE);updateTrimWaveform();}
    private void clearEditor(boolean show){pendingSoundUri=null;pendingSoundName="";pendingSoundMime="";pendingSoundDurationMs=0;selectedSoundInfo.setText("🔊 Sound: এখনো নতুন file বাছা হয়নি");editId=0;name.setText("");price.setText("");category.setText("ALL");preview.setText("");animation.setText("");sound.setText("");catalogAnimation.setText("");volume.setProgress(85);effectDurationSec.setText("2.8");soundDurationSec.setText("2.5");trimStart.setProgress(0);trimEnd.setProgress(100);vatPercent.setProgress(10);boardPosition.setSelection(0);animationScale.setProgress(72);catalogSize.setProgress(68);catalogStrength.setProgress(42);catalogSpeed.setProgress(45);catalogGlow.setProgress(35);catalogType.setSelection(0);catalogEnabled.setChecked(true);catalogLoop.setChecked(true);int next=Math.min(50,Math.max(1,currentGifts.length()+1));refreshBoxSelector(next);boxSelector.setSelection(Math.max(0,next-1));order.setText(String.valueOf(next));enabled.setChecked(true);animOn.setChecked(true);soundOn.setChecked(true);if(deleteEditorButton!=null)deleteEditorButton.setVisibility(View.GONE);updateTrimWaveform();if(show)editor.setVisibility(View.VISIBLE);}
    private JSONObject editorPayload(String soundUrl)throws Exception{int sc=animationScale.getProgress();return new JSONObject().put("id",editId).put("name",name.getText().toString().trim()).put("currency",selectedCurrency).put("price",num(price,1)).put("category",category.getText().toString().trim()).put("previewUrl",preview.getText().toString().trim()).put("animationUrl",animation.getText().toString().trim()).put("soundUrl",soundUrl==null?"":soundUrl).put("soundVolume",volume.getProgress()).put("effectDurationMs",durationMs(effectDurationSec,2800,500)).put("soundDurationMs",durationMs(soundDurationSec,2500,0)).put("soundTrimStartPct",trimStart.getProgress()).put("soundTrimEndPct",trimEnd.getProgress()).put("vatPercent",vatPercent.getProgress()).put("boardPosition",String.valueOf(boardPosition.getSelectedItem())).put("animationScale",sc).put("sizeMode",modeForScale(sc)).put("catalogAnimationEnabled",catalogEnabled.isChecked()).put("catalogAnimationType",String.valueOf(catalogType.getSelectedItem())).put("catalogPreviewSize",catalogSize.getProgress()).put("catalogAnimationStrength",catalogStrength.getProgress()).put("catalogAnimationSpeed",catalogSpeed.getProgress()).put("catalogGlowParticle",catalogGlow.getProgress()).put("catalogLoop",catalogLoop.isChecked()).put("catalogAnimationUrl",catalogAnimation.getText().toString().trim()).put("sortOrder",numZero(order,100)).put("enabled",enabled.isChecked()).put("animationEnabled",animOn.isChecked()).put("soundEnabled",soundOn.isChecked());}
    private void saveEditor(){
        if(name.getText().toString().trim().isEmpty()){toast("Gift name দিন");return;}
        if(pendingSoundUri!=null){try{uploadState.setText("Saving sound… upload শুরু হয়েছে");InputStream in=getContentResolver().openInputStream(pendingSoundUri);BackendClient.adminLiveGiftAssetUpload(SessionManager.getToken(this),in,pendingSoundName.isEmpty()?"gift_sound":pendingSoundName,pendingSoundMime,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{String url=o.optString("url","");sound.setText(url);pendingSoundUri=null;saveGiftPayload(url);});}public void onError(String m){toast("Sound upload failed: "+m);}});}catch(Exception e){toast("Selected sound read করা যায়নি");}return;}
        saveGiftPayload(sound.getText().toString().trim());
    }
    private void saveGiftPayload(String soundUrl){try{JSONObject x=editorPayload(soundUrl);final int requestedBox=Math.max(1,numZero(order,Math.max(1,currentGifts.length()+1)));BackendClient.adminLiveGiftSave(SessionManager.getToken(this),x,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{long savedId=o.optLong("id",editId);uploadState.setText(enabled.isChecked()?"Published":"Draft saved");persistRequestedPosition(savedId,requestedBox);});}public void onError(String m){toast(m);}});}catch(Exception e){toast("Please check gift fields");}}


    private void refreshBoxSelector(int preferred){
        if(boxSelector==null)return;
        int max=Math.max(1,Math.min(50,Math.max(currentGifts.length()+(editId==0?1:0),preferred)));
        String[] boxes=new String[max];for(int i=0;i<max;i++)boxes[i]="Box "+(i+1)+"  •  ঘর "+(i+1);
        boxSelector.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,boxes));
    }

    private void persistRequestedPosition(long savedId,int requestedBox){
        try{
            java.util.ArrayList<Long> ids=new java.util.ArrayList<>();
            for(int i=0;i<currentGifts.length();i++){JSONObject g=currentGifts.optJSONObject(i);if(g!=null&&g.optLong("id")!=savedId)ids.add(g.optLong("id"));}
            int at=Math.max(0,Math.min(ids.size(),requestedBox-1));ids.add(at,savedId);
            JSONArray ordered=new JSONArray();for(Long id:ids)ordered.put(id);
            BackendClient.adminLiveGiftReorder(SessionManager.getToken(this),selectedCurrency,ordered,new BackendClient.Callback(){public void onSuccess(JSONObject q){runOnUiThread(()->{toast((enabled.isChecked()?"✓ Published":"✓ Draft saved")+" • Box "+(at+1));editor.setVisibility(View.GONE);load(selectedCurrency);});}public void onError(String m){runOnUiThread(()->{toast("Gift saved • position sync retry needed: "+m);editor.setVisibility(View.GONE);load(selectedCurrency);});}});
        }catch(Exception e){toast("Gift saved • position refresh needed");editor.setVisibility(View.GONE);load(selectedCurrency);}
    }

    private void deleteCurrentGift(){
        if(editId<=0)return;
        JSONObject g=null;for(int i=0;i<currentGifts.length();i++){JSONObject x=currentGifts.optJSONObject(i);if(x!=null&&x.optLong("id")==editId){g=x;break;}}
        if(g==null){toast("Gift not found");return;}confirmDelete(g);
    }

    private void updateTrimWaveform(){if(trimWaveform!=null&&trimStart!=null&&trimEnd!=null)trimWaveform.setSelection(trimStart.getProgress(),trimEnd.getProgress());}

    private void previewLiveBoard(){
        try{
            LinearLayout wrap=col();wrap.setPadding(dp(12),dp(12),dp(12),dp(12));wrap.setBackground(gradient(new int[]{Color.rgb(18,22,56),Color.rgb(48,30,91)},Color.rgb(114,95,224),22));
            TextView t=txt("LIVE BOARD PREVIEW • "+(name.getText().toString().trim().isEmpty()?"Gift":name.getText().toString().trim()),14,true,Color.WHITE);t.setGravity(Gravity.CENTER);wrap.addView(t,new LinearLayout.LayoutParams(-1,dp(42)));
            FrameLayout stage=new FrameLayout(this);stage.setBackground(gradient(new int[]{Color.rgb(11,15,39),Color.rgb(32,20,63)},Color.rgb(94,79,185),18));
            ImageView art=new ImageView(this);art.setScaleType(ImageView.ScaleType.CENTER_INSIDE);String u=animation.getText().toString().trim();if(u.isEmpty())u=preview.getText().toString().trim();if(!u.isEmpty())AnimatedAssetLoader.load(art,u,true);else art.setImageResource(builtInArt(name.getText().toString().trim()));
            int pct=Math.max(5,animationScale.getProgress()),side=Math.max(dp(54),Math.min(dp(290),dp(54)+(dp(236)*pct/100)));int gravity=Gravity.CENTER;String bp=String.valueOf(boardPosition.getSelectedItem());if("TOP".equals(bp))gravity=Gravity.TOP|Gravity.CENTER_HORIZONTAL;else if("BOTTOM".equals(bp))gravity=Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL;else if("FULL_SCREEN".equals(bp)){side=dp(300);gravity=Gravity.CENTER;}
            stage.addView(art,new FrameLayout.LayoutParams(side,side,gravity));TextView meta=txt("Size "+pct+"%  •  "+bp+"  •  "+formatSeconds(durationMs(effectDurationSec,2800,500))+" sec",10,true,Color.rgb(248,221,127));meta.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);stage.addView(meta,new FrameLayout.LayoutParams(-1,dp(38),Gravity.BOTTOM));wrap.addView(stage,new LinearLayout.LayoutParams(-1,dp(360)));
            new AlertDialog.Builder(this).setView(wrap).setPositiveButton("Looks Good",null).setNegativeButton("Close",null).show();
        }catch(Exception e){toast("Live preview could not start");}
    }

    private static final class TrimWaveformView extends View{
        private final android.graphics.Paint p=new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);private int start=0,end=100;
        TrimWaveformView(android.content.Context c){super(c);setMinimumHeight(70);}
        void setSelection(int s,int e){start=Math.max(0,Math.min(99,s));end=Math.max(start+1,Math.min(100,e));invalidate();}
        @Override protected void onDraw(android.graphics.Canvas c){super.onDraw(c);int w=getWidth(),h=getHeight(),mid=h/2;p.setStrokeWidth(Math.max(2,getResources().getDisplayMetrics().density));for(int i=0;i<48;i++){float x=(i+.5f)*w/48f;float amp=(float)(.18+.72*Math.abs(Math.sin(i*.73)+.35*Math.sin(i*1.91))*.74);boolean sel=(i*100/48)>=start&&(i*100/48)<=end;p.setColor(sel?Color.rgb(91,86,224):Color.rgb(205,208,226));c.drawLine(x,mid-h*amp*.42f,x,mid+h*amp*.42f,p);}p.setColor(Color.rgb(68,181,164));p.setStrokeWidth(5);c.drawLine(w*start/100f,4,w*start/100f,h-4,p);p.setColor(Color.rgb(221,83,130));c.drawLine(w*end/100f,4,w*end/100f,h-4,p);}
    }

    private void selectBoardPosition(String p){String[] a={"CENTER","TOP","BOTTOM","FULL_SCREEN"};for(int i=0;i<a.length;i++)if(a[i].equalsIgnoreCase(p)){boardPosition.setSelection(i);return;}boardPosition.setSelection(0);}

    private void previewTrimmedSound(){
        String url=sound.getText().toString().trim();String giftName=name.getText().toString().trim();int vol=volume.getProgress(),maxMs=durationMs(soundDurationSec,2500,0),startPct=trimStart.getProgress(),endPct=trimEnd.getProgress();
        stopPreviewPlayer();
        try{
            final android.media.MediaPlayer mp=new android.media.MediaPlayer();previewPlayer=mp;
            if(android.os.Build.VERSION.SDK_INT>=21)mp.setAudioAttributes(new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build());else mp.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);
            if(pendingSoundUri!=null){
                mp.setDataSource(this,pendingSoundUri);
            }else if(!url.isEmpty()){
                mp.setDataSource(url);
            }else{
                int res=builtInSound(giftName);if(res==0){previewPlayer=null;toast("আগে ফোন থেকে Sound বাছুন");return;}
                android.content.res.AssetFileDescriptor afd=getResources().openRawResourceFd(res);if(afd==null){previewPlayer=null;toast("Sound file open করা যায়নি");return;}
                mp.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());afd.close();
            }
            mp.setOnPreparedListener(x->{try{float vv=Math.max(0f,Math.min(1f,vol/100f));x.setVolume(vv,vv);int total=Math.max(1,x.getDuration());pendingSoundDurationMs=total;runOnUiThread(()->updateTrimLabels());int st=(int)((long)total*startPct/100L),en=(int)((long)total*endPct/100L);int clip=Math.max(100,en-st);int play=maxMs<=0?clip:Math.max(100,Math.min(maxMs,clip));x.seekTo(Math.max(0,st));x.start();uploadState.setText("▶ Playing selected sound • "+clock(st)+" → "+clock(st+play));new android.os.Handler(getMainLooper()).postDelayed(()->{if(previewPlayer==x)stopPreviewPlayer();},play);}catch(Exception e){stopPreviewPlayer();toast("Sound play failed");}});
            mp.setOnErrorListener((x,what,extra)->{stopPreviewPlayer();toast("Sound decode/play failed");return true;});
            mp.setOnCompletionListener(x->stopPreviewPlayer());
            mp.prepareAsync();
        }catch(Exception e){stopPreviewPlayer();toast("Sound preview failed: selected file support হচ্ছে না");}
    }
    private void stopPreviewPlayer(){android.media.MediaPlayer x=previewPlayer;previewPlayer=null;if(x!=null){try{if(x.isPlaying())x.stop();}catch(Exception ignored){}try{x.reset();}catch(Exception ignored){}try{x.release();}catch(Exception ignored){}}}
    private void updateTrimLabels(){long total=pendingSoundDurationMs;int a=trimStart==null?0:trimStart.getProgress(),b=trimEnd==null?100:trimEnd.getProgress();if(total>0){trimStartValue.setText("Start "+clock((long)(total*a/100d)));trimEndValue.setText("End "+clock((long)(total*b/100d)));}else{trimStartValue.setText("Start "+a+"%");trimEndValue.setText("End "+b+"%");}updateTrimWaveform();}
    private String clock(long ms){long sec=Math.max(0,ms/1000);return String.format(Locale.US,"%02d:%02d",sec/60,sec%60);}


    private void applyGlobalVat(){try{JSONObject x=new JSONObject().put("currency",selectedCurrency).put("vatPercent",globalVat.getProgress());BackendClient.adminLiveGiftBulkVat(SessionManager.getToken(this),x,new BackendClient.Callback(){public void onSuccess(JSONObject o){toast("VAT "+globalVat.getProgress()+"% applied to all "+selectedCurrency+" gifts");load(selectedCurrency);}public void onError(String m){toast(m);}});}catch(Exception e){toast("VAT update failed");}}

    private void previewCatalogEditor(){
        try{JSONObject g=new JSONObject().put("name",name.getText().toString().trim().isEmpty()?"Gift":name.getText().toString().trim()).put("catalog_animation_enabled",catalogEnabled.isChecked()?1:0).put("catalog_animation_type",String.valueOf(catalogType.getSelectedItem())).put("catalog_preview_size",catalogSize.getProgress()).put("catalog_animation_strength",catalogStrength.getProgress()).put("catalog_animation_speed",catalogSpeed.getProgress()).put("catalog_glow_particle",catalogGlow.getProgress()).put("catalog_loop",catalogLoop.isChecked()?1:0);
            LinearLayout box=col();box.setPadding(dp(18),dp(14),dp(18),dp(16));box.setBackground(gradient(new int[]{Color.rgb(35,25,86),Color.rgb(99,43,135)},Color.rgb(246,151,222),20));TextView title=txt("Catalog Preview • "+g.optString("name"),15,true,Color.WHITE);title.setGravity(Gravity.CENTER);box.addView(title);
            FrameLayout stage=new FrameLayout(this);ImageView art=new ImageView(this);art.setScaleType(ImageView.ScaleType.CENTER_INSIDE);TextView sparkle=txt("✦   ✧",18,true,Color.rgb(255,226,118));sparkle.setGravity(Gravity.CENTER);String url=catalogAnimation.getText().toString().trim();String pv=preview.getText().toString().trim();if(!url.isEmpty())AnimatedAssetLoader.load(art,url,true);else if(!pv.isEmpty())AnimatedAssetLoader.load(art,pv);else art.setImageResource(builtInArt(g.optString("name","Gift")));int d=CatalogGiftAnimator.iconDp(g);stage.addView(art,new FrameLayout.LayoutParams(dp(d),dp(d),Gravity.CENTER));stage.addView(sparkle,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));box.addView(stage,new LinearLayout.LayoutParams(-1,dp(180)));CatalogGiftAnimator.start(art,sparkle,g);
            AlertDialog dlg=new AlertDialog.Builder(this).setView(box).setPositiveButton("Looks Good",null).setNegativeButton("Close",null).create();dlg.setOnDismissListener(x->CatalogGiftAnimator.stop(art,sparkle));dlg.show();
        }catch(Exception e){toast("Preview could not start");}
    }

    private void selectCatalogType(String type){for(int i=0;i<CATALOG_TYPES.length;i++)if(CATALOG_TYPES[i].equalsIgnoreCase(type)){catalogType.setSelection(i);return;}catalogType.setSelection(0);}
    private void confirmDelete(JSONObject g){new AlertDialog.Builder(this).setTitle("Delete "+g.optString("name","Gift")+"?").setMessage("Gift catalog থেকে hide হবে; historical Live transactions ভাঙবে না।").setPositiveButton("DELETE",(d,w)->BackendClient.adminLiveGiftDelete(SessionManager.getToken(this),g.optLong("id"),new BackendClient.Callback(){public void onSuccess(JSONObject o){load(selectedCurrency);}public void onError(String m){toast(m);}})).setNegativeButton("Cancel",null).show();}

    private void pick(int request,String kind,JSONObject gift){quickKind=kind;quickGift=gift;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);if("sound".equals(kind)){i.setType("audio/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"audio/mpeg","audio/mp4","audio/x-m4a","audio/wav","audio/*"});startActivityForResult(Intent.createChooser(i,"Choose gift sound from phone"),request);return;}else if("catalog_animation".equals(kind)){i.setType("image/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/gif","image/webp","image/png","image/jpeg"});}else i.setType("image/*");startActivityForResult(i,request);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(c!=RESULT_OK||d==null||d.getData()==null)return;Uri u=d.getData();try{String mime=getContentResolver().getType(u),fn="gift_asset";android.database.Cursor q=getContentResolver().query(u,null,null,null,null);if(q!=null){int n=q.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(q.moveToFirst()&&n>=0)fn=q.getString(n);q.close();}if(r==PICK_SOUND||"sound".equals(quickKind)){pendingSoundUri=u;pendingSoundName=fn;pendingSoundMime=mime==null?"audio/*":mime;try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}pendingSoundDurationMs=readAudioDuration(u);soundOn.setChecked(true);selectedSoundInfo.setText("🎵 "+fn+"  •  "+(pendingSoundDurationMs>0?clock(pendingSoundDurationMs):"Ready")+"  •  Trim/Test করুন, Save-এর আগে upload হবে না");uploadState.setText("Sound selected locally • Preview ready");updateTrimLabels();quickGift=null;quickKind="";return;}InputStream in=getContentResolver().openInputStream(u);if(uploadState!=null)uploadState.setText("Uploading asset…");final String kind=quickKind;final JSONObject target=quickGift;BackendClient.adminLiveGiftAssetUpload(SessionManager.getToken(this),in,fn,mime,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{String url=o.optString("url","");if(r==PICK_QUICK&&target!=null){try{JSONObject x=fromGift(target);if("preview".equals(kind))x.put("previewUrl",url);else if("catalog_animation".equals(kind)){x.put("catalogAnimationUrl",url).put("catalogAnimationEnabled",true);}else{x.put("animationUrl",url).put("animationMime",o.optString("mediaType","")).put("animationEnabled",true);}BackendClient.adminLiveGiftSave(SessionManager.getToken(LiveGiftAdminActivity.this),x,new BackendClient.Callback(){public void onSuccess(JSONObject z){toast("Asset saved • Catalog/Live updated");load(selectedCurrency);}public void onError(String m){toast(m);}});}catch(Exception e){toast("Asset save failed");}}else{if("catalog_animation".equals(kind)){catalogAnimation.setText(url);catalogEnabled.setChecked(true);}else if("image".equals(kind)||"preview".equals(kind))preview.setText(url);else animation.setText(url);if(uploadState!=null)uploadState.setText("Uploaded • "+o.optString("mediaType"));}});}public void onError(String m){toast(m);}});}catch(Exception e){toast("Could not read selected file");}finally{if(r!=PICK_SOUND){quickGift=null;quickKind="";}}}
    private long readAudioDuration(Uri u){try{android.media.MediaMetadataRetriever mmr=new android.media.MediaMetadataRetriever();mmr.setDataSource(this,u);String d=mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION);mmr.release();return Math.max(0,Long.parseLong(d));}catch(Exception e){return 0;}}


    private void previewSound(String url,String giftName,int vol){try{final android.media.MediaPlayer mp;if(url==null||url.trim().isEmpty()){int res=builtInSound(giftName);if(res==0){toast("No sound assigned to this gift");return;}mp=android.media.MediaPlayer.create(this,res);}else{mp=new android.media.MediaPlayer();mp.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);mp.setDataSource(url);mp.setOnPreparedListener(x->{float v=Math.max(0f,Math.min(1f,vol/100f));x.setVolume(v,v);x.start();});mp.prepareAsync();}if(mp!=null){float v=Math.max(0f,Math.min(1f,vol/100f));mp.setVolume(v,v);mp.setOnCompletionListener(x->{try{x.release();}catch(Exception ignored){}});if(url==null||url.trim().isEmpty())mp.start();}}catch(Exception e){toast("Sound preview failed");}}

    private int builtInArt(String n){String x=String.valueOf(n).toLowerCase(Locale.US);if(x.contains("rose"))return R.drawable.gift_rose;if(x.contains("heart"))return R.drawable.gift_heart;if(x.contains("teddy"))return R.drawable.gift_teddy;if(x.contains("chocolate"))return R.drawable.gift_chocolate;if(x.contains("diamond"))return R.drawable.gift_diamond;if(x.contains("crown"))return R.drawable.gift_crown;if(x.contains("car"))return R.drawable.gift_car;if(x.contains("jet"))return R.drawable.gift_jet;if(x.contains("castle"))return R.drawable.gift_castle;return R.drawable.gift_star;}
    private int builtInSound(String n){String x=String.valueOf(n).toLowerCase(Locale.US);if(x.contains("rose"))return R.raw.gift_rose_sound;if(x.contains("heart"))return R.raw.gift_heart_sound;if(x.contains("teddy"))return R.raw.gift_teddy_sound;if(x.contains("chocolate"))return R.raw.gift_chocolate_sound;if(x.contains("diamond"))return R.raw.gift_diamond_sound;if(x.contains("crown"))return R.raw.gift_crown_sound;if(x.contains("car"))return R.raw.gift_car_sound;if(x.contains("jet"))return R.raw.gift_jet_sound;if(x.contains("castle"))return R.raw.gift_castle_sound;if(x.equals("star")||x.contains("super star"))return R.raw.gift_star_sound;return 0;}

    private int durationMs(EditText e,int fallback,int min){try{double sec=Double.parseDouble(e.getText().toString().trim());return Math.max(min,Math.min(15000,(int)Math.round(sec*1000d)));}catch(Exception ignored){return fallback;}}
    private String formatSeconds(int ms){double sec=Math.max(0,ms)/1000d;return Math.abs(sec-Math.rint(sec))<0.001?String.valueOf((int)Math.rint(sec)):String.format(Locale.US,"%.1f",sec);}

    private SeekBar slider(int p){SeekBar s=new SeekBar(this);s.setMax(100);s.setProgress(Math.max(0,Math.min(100,p)));return s;}
    private TextView value(String s,int color){TextView v=txt(s,11,true,color);v.setGravity(Gravity.CENTER);return v;}
    private void bindValue(SeekBar s,TextView v){s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar x,int p,boolean f){v.setText(p+"%");}public void onStartTrackingTouch(SeekBar x){}public void onStopTrackingTouch(SeekBar x){}});}
    private LinearLayout sliderRow(String title,SeekBar s,TextView v){LinearLayout wrap=col();wrap.addView(txt(title,9.6f,true,Color.rgb(78,80,112)),new LinearLayout.LayoutParams(-1,dp(30)));LinearLayout line=row();line.addView(s,new LinearLayout.LayoutParams(0,dp(44),1));line.addView(v,new LinearLayout.LayoutParams(dp(58),dp(44)));wrap.addView(line);return wrap;}
    private LinearLayout premiumCard(String currency,int index){LinearLayout x=col();x.setPadding(dp(12),dp(10),dp(12),dp(12));int[][] palettes="GOLD".equals(currency)?new int[][]{{255,251,237,255,241,222},{255,247,241,255,239,246},{250,247,255,255,247,230}}:new int[][]{{245,249,255,250,244,255},{249,245,255,255,244,250},{242,252,251,246,247,255}};int[] p=palettes[Math.abs(index)%palettes.length];android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(p[0],p[1],p[2]),Color.rgb(p[3],p[4],p[5])});g.setCornerRadius(dp(20));g.setStroke(dp(1),"GOLD".equals(currency)?Color.rgb(238,191,91):Color.rgb(197,194,239));x.setBackground(g);x.setElevation(dp(3));return x;}
    private android.graphics.drawable.GradientDrawable gradient(int[] colors,int stroke,int radius){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,colors);g.setCornerRadius(dp(radius));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    private android.graphics.drawable.GradientDrawable round(int fill,int stroke,int radius){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    private Button actionButton(String s,int a,int b){Button v=new Button(this);v.setText(s);v.setAllCaps(false);v.setTextColor(Color.WHITE);v.setTextSize(10.5f);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setPadding(dp(5),0,dp(5),0);android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,new int[]{a,b});g.setCornerRadius(dp(15));v.setBackground(g);v.setElevation(dp(2));return v;}
    private Button miniColor(String s,int a,int b){Button x=actionButton(s,a,b);x.setTextSize(8.3f);return x;}
    private Button mini(String s){return miniColor(s,Color.rgb(79,86,214),Color.rgb(156,65,207));}
    private EditText input(String h){EditText e=new EditText(this);e.setHint(h);e.setTextSize(12);e.setSingleLine(true);e.setPadding(dp(10),0,dp(10),0);return e;}
    private TextView label(String s){TextView t=txt(s,10,true,Color.rgb(78,80,112));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(32));p.topMargin=dp(5);t.setLayoutParams(p);return t;}
    private CheckBox check(String s,boolean on){CheckBox c=new CheckBox(this);c.setText(s);c.setTextSize(10);c.setChecked(on);return c;}
    private TextView txt(String s,float z,boolean bold,int color){TextView x=new TextView(this);x.setText(s);x.setTextSize(z);x.setTextColor(color);if(bold)x.setTypeface(Typeface.DEFAULT,Typeface.BOLD);x.setPadding(0,dp(4),0,dp(4));return x;}
    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private LinearLayout.LayoutParams wt(float w){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,w);p.setMargins(dp(2),0,dp(2),0);return p;}
    private LinearLayout.LayoutParams h48(){return new LinearLayout.LayoutParams(-1,dp(48));}private LinearLayout.LayoutParams h44(){return new LinearLayout.LayoutParams(-1,dp(44));}
    private LinearLayout.LayoutParams top(int w,int h,int m){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.topMargin=dp(m);return p;}
    private int num(EditText e,int d){try{return Math.max(1,Integer.parseInt(e.getText().toString().trim()));}catch(Exception x){return d;}}
    private int numZero(EditText e,int d){try{return Math.max(0,Integer.parseInt(e.getText().toString().trim()));}catch(Exception x){return d;}}

    @Override protected void onStop(){stopPreviewPlayer();super.onStop();}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}
}
