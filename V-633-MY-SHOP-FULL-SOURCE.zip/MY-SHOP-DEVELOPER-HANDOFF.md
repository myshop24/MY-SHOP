# MY SHOP V633 / 2.9.633

Base: delivered V632 full source. Owner authorized this correction group after collecting phone screenshots on 16 October 2026. Next changed delivery V634. Original package `com.myshop.app`, signing inputs, media and financial mutation rules retained. No remote deployment or production database inspection was performed.

## 1. One Admin entry

AdminCatalogActivity and SuperAdminActivity now redirect to the permission/gate-checked AdminHub. The actual old implementation source remains for compatibility; duplicate visible panel entrances are removed. Eight populated groups: accounting monitor, user controls, requests/support, commission settings, Home/banner design, Live controls, store/products, system/audit. Modules are normalized and deduplicated by destination. Sidebar no longer has separate duplicate Coin/Diamond/earnings links to the same old screen. All banners have one visible inventory. Existing underlying editors and data remain.

Admin monitor access: Admin → Live Accounting Monitor → Market Accounting Monitor, or the clearly labeled TV button. Requests/support have a dedicated folder. The old automatic long monitor no longer pushes Admin controls down or polls invisibly. Window insets added to the unified Admin root.

## 2. Read-only automatic currency inventory

New GET `/v1/admin/finance/monitor`, restricted server-side to fixed main Admins. No financial writes. Current Coin and Diamond wallet totals come from their respective wallet tables, not value-ledger turnover. Official/non-withdrawable source balance is clamped per wallet; remaining wallet balance is separate. Creator earnings are displayed separately with an explicit warning not to add them to wallet balances. Current HELD withdrawal units are separate.

Period movements: recorded external issuance (ADMIN_GRANT, PURCHASE_APPROVED, PAID_PURCHASE, STORE_GRANT and REACTION_REWARD positive credits), office grants including recognized admin catalog grant metadata, purchase approvals, reward issuance, office removals, platform commission, paid and pending Creator withdrawal requests. Gifts/transfers never count as fresh issuance. Existing commerce cash accounting is a separate explicit detail link; currency units are never presented as cash profit.

BN/English Admin labels; date filters use UTC and validated real YYYY-MM-DD calendar dates. Current stock does not change when dates filter movements. TV-style two-column screen refreshes while visible every 15 seconds and stops on pause. Last successful server timestamp, failure state, User-ID detail filter, transaction keyset pagination and wallet User-ID pagination are included. Official/other detail rows use the exact corresponding source expression rather than total-wallet values.

### Historical reconciliation limit — do not conceal

A recorded-movements diagnostic compares historical signed wallet transactions, less current source-convention gift/transfer wallet debits and recorded HELD/SETTLED withdrawal deductions, with current wallets. It reports a difference and requires review rather than adjusting balances. The production DB was not accessed: legacy opening balances, missing older transaction logs, old payout paths, account deletions and historical mutation conventions may cause differences. A zero diagnostic means these recorded movements match, not that every historical issuance has been independently proven. Recorded issuance is explicitly labeled recorded, not guaranteed complete lifetime money supply. No fabricated balancing row or financial data deletion was added. Pending amounts are requests, not money already paid.

Old AdminFinance remains as the detailed ledger/settings route. Its misleading combined Coin+Diamond income/Net cards are no longer displayed; a monitor link and turnover warning are added. Existing VAT and other needed controls remain accessible. Main accounting is the new single monitor.

## 3. Banner manager and independent placement

Admin → Home Design & Banners → Banner Manager contains Home advertising row1/Promo row2, Home Upcoming, Live-page ads/Upcoming, Shop rows, other ads and startup ads. Actual existing editors and storage are reused. Deleted media cannot be recovered without a retained copy; upload fresh product creatives in Promo slots as required.

Home preview is visibly linked under Home Design and Banner Manager/Banner Admin. HomeLayout632 retains its name for compatibility, now supports five semantic blocks: stories, composer, hero, promo, upcoming. Old four-block payloads and saved layouts migrate by adding enabled Upcoming before posts. Promo no longer contains Upcoming. GET also respects legacy Hero/Promo section switches when no layout had been published. Hidden Upcoming has its own outer wrapper so its asynchronous content visibility cannot override the layout switch.

Preview adds a dedicated blue drag handle above each block, avoiding banner swipe/click listeners consuming the gesture. Drop targets are highlighted, self-drop does not reposition, and edge dragging requests scroll movement. Before/after block and after-N-post placement persist using semantic anchors. Toolbar is in the scroll document, not overlaid on the Home header/status bar. Changes remain a private draft until Confirm; Cancel exits without publishing. Hidden content leaves no normal-user gap. Empty enabled ad rows require actual uploaded/published content.

## 4. Story avatar

Story/Reels small profile pictures now use a circular outline, center crop, inset and blue rim. Large story card proportions unchanged.

## 5. Shared header/navigation corrections

Language uses the same ordinary AppCompatTextView on all pages instead of LiveHome-only custom Canvas text. Current language code is visible and clickable. Saved Home-header appearance can now apply to the shared Live Home header as well; AudioLiveRoom remains excluded and all other Live scopes stay protected. A language visibility/contrast guard prevents published style opacity/tiny text/color from hiding the control. Live/Shop top and bottom insets match Home's breathing space and bottom six-dp inset adjustment. Side nav art is preserved against theme recoloring; central AnimatedLiveIconView unchanged. These are source corrections; real-phone screenshot comparison remains required.

## 6. Verification and delivery

See verification/V633-RESULTS.md and logs. New real SQLite accounting/layout tests, retained V632 functionality, broad root tests, inherited V629/V626 checks, Java parser/Context checks, resource/import and unchanged generated asset verification pass locally. Full Android compile was attempted but stopped before compilation while downloading Gradle8.11.1: Network is unreachable. No APK, Android type-compile success, signing/provenance/APK-size check, phone visual/drag acceptance, production D1 reconciliation or RTC test is claimed.

V633-specific tests adapt only the legacy four-block migration expectation and release-metadata normalization. No fixture financial expected values or production ledger balances are altered to force passing.

Upload `V-633-MY-SHOP-FULL-SOURCE.zip` unchanged to existing myshop24/MY-SHOP root/main. Keep the installed MY SHOP PERMANENT RELEASE PIPELINE and original Secrets/signing. It selects the newest ZIP, deploys matching Worker, verifies health V633, then builds the original signed APK. Expected successful installed-pipeline artifact: MY-SHOP-FINAL-V-633 / MY_SHOP_FINAL_RELEASE.apk. GitHub Pages success is unrelated. No APK is inside this source ZIP. Do not replace repository workflows merely because this project contains its own historical compatible workflow.

## Next acceptance

On actual APK verify En and identical header/footer on Home/Live/Shop; blue round story avatar; all five drag handles including Promo after fresh product upload; independent Upcoming enable with Promo disabled; preview/Cancel/Confirm and two-device published layout. Inspect production monitor records and investigate any reconciliation differences before treating recorded issuance as complete lifetime supply. Previously pending cinematic media, exhaustive localization and phone/RTC tests remain pending as documented in V632. Do not claim all older project requirements complete.
