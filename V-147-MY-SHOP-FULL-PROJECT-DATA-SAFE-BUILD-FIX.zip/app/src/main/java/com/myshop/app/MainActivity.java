package com.myshop.app;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

/** MY SHOP V-147 Home: longer breaking ticker, feed/gallery access, social icons, POWER AD branding. */
public class MainActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(248,249,253), BLUE=Color.rgb(46,47,190), NAVY=Color.rgb(18,32,75), DARK=Color.rgb(35,38,52), RED=Color.rgb(238,35,52), GREEN=Color.rgb(24,169,98), PURPLE=Color.rgb(91,38,214), MUTED=Color.rgb(105,111,130);
    private final Handler handler=new Handler();
    private int slide=0;
    private ImageView hero;
    private ImageView[] promoViews=new ImageView[2];
    private String[] remoteHeroUrls=new String[6];
    private String[] remotePromoUrls=new String[3];
    private TextView dots,newsText,notificationBadge,feedStatus,postLimit;
    private LinearLayout feedList;
    private ScrollView scroll;
    private LinearLayout liveAdBox;
    private TextView powerAdTitle, powerAdByline;
    private long feedBefore=0;
    private boolean feedLoading=false,feedHasMore=true;
    private static final int PICK_POST=9421;
    private Uri pendingPostUri;
    private String pendingPostMime="image/jpeg";
    private int unreadNotificationCount=0;
    private ImageView liveAdImage; private TextView liveAdCaption; private View liveAdStripView; private final ArrayList<JSONObject> liveAds=new ArrayList<>(); private int liveAdIndex=0;
    private final int[] heroImgs={R.drawable.banner_wide_1,R.drawable.banner_wide_2,R.drawable.banner_wide_3,R.drawable.banner_wide_4,R.drawable.banner_wide_5,R.drawable.banner_wide_6};
    private final int[] left={R.drawable.banner_top_left_1,R.drawable.banner_top_left_2,R.drawable.banner_top_left_3,R.drawable.banner_top_left_4,R.drawable.banner_top_left_5,R.drawable.banner_top_left_6};
    private final int[] right={R.drawable.banner_top_right_1,R.drawable.banner_top_right_2,R.drawable.banner_top_right_3,R.drawable.banner_top_right_4,R.drawable.banner_top_right_5,R.drawable.banner_top_right_6};
    private final int[] live={R.drawable.dash_live1,R.drawable.dash_live2,R.drawable.dash_live3,R.drawable.dash_live4};
    private final String[] mainKeys={"my_shop","gallery","external_movie","earn_reward","more_apps"};
    private final String[] mainTitles={"MY SHOP","GALLERY","EXTERNAL MOVIE","EARN & REWARD","MORE"};
    private final int[] mainIcons={R.drawable.dash_feat_shop,R.drawable.dash_feat_gallery,R.drawable.dash_feat_movie,R.drawable.dash_feat_reward,R.drawable.dash_feat_apps};
    private final FrameLayout[] mainCards=new FrameLayout[5];
    private final TextView[] mainLabels=new TextView[5];
    private final ImageView[] mainIconViews=new ImageView[5];
    private final String[] mainRemoteUrls=new String[5];

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(build());
        loadRemote(); loadNotificationCount(); loadFeed(true);
        startCarousel(); startLiveAdCarousel();
    }

    private View build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(BG);
        LinearLayout fixedTop=col(); fixedTop.setPadding(dp(12),dp(8),dp(12),0);
        fixedTop.addView(header(),lp(-1,dp(62)));
        fixedTop.addView(breaking(),top(lp(-1,dp(36)),5));
        FrameLayout.LayoutParams fixedLp=new FrameLayout.LayoutParams(-1,dp(114),Gravity.TOP); root.addView(fixedTop,fixedLp);
        scroll=new ScrollView(this); scroll.setVerticalScrollBarEnabled(false); scroll.setFillViewport(true);
        scroll.setOnScrollChangeListener((v, sx, sy, osx, osy)->{
            View child=scroll.getChildAt(0);
            if(child!=null && sy+scroll.getHeight()>=child.getHeight()-dp(420)) loadFeed(false);
        });
        LinearLayout page=col(); page.setPadding(dp(12),dp(6),dp(12),dp(92));
        hero=pic(heroImgs[0]); page.addView(hero,top(lp(-1,dp(126)),0));
        dots=text("●   ○   ○   ○   ○   ○",BLUE,10,true); dots.setGravity(Gravity.CENTER); page.addView(dots,lp(-1,dp(18)));
        page.addView(doublePromos(),top(lp(-1,dp(76)),1));
        page.addView(liveActions(),top(lp(-1,dp(44)),6));
        page.addView(liveRow(),top(lp(-1,dp(96)),6));
        page.addView(mainFeatureGrid(),top(lp(-1,dp(88)),7));
        page.addView(liveAdStrip(),top(lp(-1,dp(96)),6));
        page.addView(feedSection(),top(lp(-1,-2),10));
        scroll.addView(page,new ScrollView.LayoutParams(-1,-2)); FrameLayout.LayoutParams scrollLp=new FrameLayout.LayoutParams(-1,-1); scrollLp.topMargin=dp(114); root.addView(scroll,scrollLp);
        FrameLayout.LayoutParams navLp=new FrameLayout.LayoutParams(-1,dp(64),Gravity.BOTTOM); navLp.setMargins(dp(8),0,dp(8),dp(10)); root.addView(bottom(),navLp);
        return root;
    }

    private View header(){
        LinearLayout h=row(); h.setGravity(Gravity.CENTER_VERTICAL); h.setPadding(dp(2),0,dp(2),0); h.setBackground(round(Color.WHITE,Color.TRANSPARENT,22));
        Button menu=icon("☰",NAVY,24); menu.setOnClickListener(v->resolveMenuDestination()); h.addView(menu,lp(dp(42),dp(58)));
        LinearLayout brandBox=row(); brandBox.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.myshop_icon); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); brandBox.addView(logo,lp(dp(44),dp(52)));
        LinearLayout words=col(); words.setGravity(Gravity.CENTER_VERTICAL); TextView my=text("MY",Color.rgb(24,28,70),15,true); TextView shop=text("SHOP",Color.rgb(245,141,0),15,true); words.addView(my,lp(-1,dp(20))); words.addView(shop,lp(-1,dp(20))); brandBox.addView(words,lp(dp(54),dp(46))); h.addView(brandBox,lp(dp(102),dp(58)));
        EditText search=new EditText(this); search.setSingleLine(true); search.setTextSize(11); search.setHint(LanguageManager.t(this,"search")); search.setPadding(dp(10),0,dp(6),0); search.setBackground(round(Color.WHITE,Color.rgb(228,229,235),24)); h.addView(search,weight(1.0f,dp(42)));
        TextView lang=text("🌐  "+languageCode(),BLUE,9,true); lang.setGravity(Gravity.CENTER); lang.setSingleLine(true); lang.setBackground(round(Color.rgb(245,246,255),Color.TRANSPARENT,12)); lang.setOnClickListener(v->LanguageManager.showPicker(this,()->recreate())); h.addView(lang,lp(dp(58),dp(40)));
        FrameLayout bellBox=new FrameLayout(this); Button bell=icon("🔔",NAVY,22); bell.setOnClickListener(v->startActivity(new Intent(this,NotificationActivity.class))); bellBox.addView(bell,new FrameLayout.LayoutParams(-1,-1));
        notificationBadge=text("",Color.WHITE,8,true); notificationBadge.setGravity(Gravity.CENTER); notificationBadge.setBackground(round(RED,RED,9)); FrameLayout.LayoutParams badgeLp=new FrameLayout.LayoutParams(dp(18),dp(18),Gravity.TOP|Gravity.END); badgeLp.setMargins(0,dp(4),dp(1),0); bellBox.addView(notificationBadge,badgeLp); h.addView(bellBox,lp(dp(40),dp(50))); updateNotificationBadge();
        ImageView av=new ImageView(this); av.setImageResource(R.drawable.myshop_profile_avatar); av.setScaleType(ImageView.ScaleType.CENTER_CROP); av.setBackground(round(Color.WHITE,Color.TRANSPARENT,20)); av.setClipToOutline(true); String avatarUrl=SessionManager.getAvatarUrl(this); if(avatarUrl!=null&&!avatarUrl.isEmpty())loadRemoteImage(av,avatarUrl); av.setOnClickListener(v->startActivity(new Intent(this,AccountActivity.class))); h.addView(av,lp(dp(40),dp(40)));
        return h;
    }

    private View breaking(){
        LinearLayout b=row(); b.setPadding(dp(1),dp(1),dp(1),dp(1)); b.setBackground(round(Color.WHITE,Color.rgb(238,239,244),11));
        TextView l=text("BREAKING",Color.WHITE,7.4f,true); l.setGravity(Gravity.CENTER); l.setSingleLine(true); l.setBackground(round(RED,RED,7)); b.addView(l,lp(dp(70),dp(32)));
        TextView speaker=text("🔊",RED,13,true); speaker.setGravity(Gravity.CENTER); b.addView(speaker,lp(dp(26),dp(32)));
        newsText=text("বাংলাদেশে আজ স্বর্ণের দাম কিছুটা কমেছে... আন্তর্জাতিক বাজারে তেলের দাম বাড়ছে...",Color.rgb(20,35,80),18f,true); newsText.setGravity(Gravity.CENTER_VERTICAL); newsText.setSingleLine(true); newsText.setEllipsize(TextUtils.TruncateAt.MARQUEE); newsText.setMarqueeRepeatLimit(-1); newsText.setSelected(true); newsText.setHorizontallyScrolling(true); newsText.setPadding(dp(6),0,dp(8),0); b.addView(newsText,weight(1,dp(32)));
        return b;
    }

    private View doublePromos(){
        LinearLayout r=row(); ImageView a=pic(left[0]),b=pic(right[0]); promoViews[0]=a; promoViews[1]=b;
        r.addView(a,weight(1,dp(74))); r.addView(space(),lp(dp(6),1)); r.addView(b,weight(1,dp(74))); return r;
    }

    private View sectionTitle(String title,boolean all){
        LinearLayout h=row(); h.addView(text(title,DARK,13,true),weight(1,dp(28))); if(all){TextView a=text("View All",BLUE,9.5f,true);a.setGravity(Gravity.CENTER);a.setOnClickListener(v->openFeature("LIVE","live_now"));h.addView(a,lp(dp(58),dp(28)));} return h;
    }

    private View liveRow(){
        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); LinearLayout r=row();
        for(int i=0;i<5;i++){
            LinearLayout wrap=col(); wrap.setGravity(Gravity.CENTER_HORIZONTAL); FrameLayout card=new FrameLayout(this); card.setBackground(round(Color.WHITE,Color.rgb(232,233,238),40));
            ImageView v=pic(live[i%live.length]); v.setScaleType(ImageView.ScaleType.CENTER_CROP); v.setBackground(round(Color.WHITE,Color.TRANSPARENT,40)); v.setClipToOutline(true); card.addView(v,new FrameLayout.LayoutParams(dp(66),dp(66)));
            TextView badge=text("LIVE  👁 "+(i==0?"1.2K":i==1?"956":i==2?"743":i==3?"2.1K":"1.8K"),Color.WHITE,6.5f,true); badge.setGravity(Gravity.CENTER); badge.setBackground(round(RED,Color.TRANSPARENT,8)); FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(58),dp(18),Gravity.BOTTOM|Gravity.START);bp.setMargins(0,0,0,dp(1));card.addView(badge,bp);
            TextView title=text(new String[]{"Shopping Live","Gadget Live","Fashion Live","Gaming Live","Beauty Live"}[i],DARK,7.5f,true); title.setGravity(Gravity.CENTER); title.setSingleLine(true); wrap.addView(card,lp(dp(76),dp(70))); wrap.addView(title,lp(dp(82),dp(20)));
            final int idx=i; View.OnClickListener click=x->openFeature("JOIN LIVE","live_now"); wrap.setOnClickListener(click); r.addView(wrap,lp(dp(88),dp(94))); if(i<4)r.addView(space(),lp(dp(4),1));
        }
        LinearLayout all=col();all.setGravity(Gravity.CENTER);TextView ic=text("▣",PURPLE,24,true);ic.setGravity(Gravity.CENTER);all.addView(ic,lp(dp(64),dp(60)));TextView tx=text("View All",PURPLE,7.5f,true);tx.setGravity(Gravity.CENTER);all.addView(tx,lp(dp(64),dp(20)));all.setOnClickListener(v->openFeature("LIVE","live_now"));r.addView(all,lp(dp(72),dp(94)));
        hs.addView(r,new HorizontalScrollView.LayoutParams(-2,-1)); return hs;
    }

    private View liveActions(){
        LinearLayout r=row(); TextView go=action("▣  GO LIVE",RED); TextView join=action("▶  JOIN LIVE",PURPLE); go.setTextSize(13); join.setTextSize(13); go.setOnClickListener(v->openFeature("GO LIVE","go_live")); join.setOnClickListener(v->openFeature("JOIN LIVE","live_now")); r.addView(go,weight(1,dp(44))); r.addView(space(),lp(dp(6),1)); r.addView(join,weight(1,dp(44))); return r;
    }

    private View liveAdStrip(){
        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); hs.setFillViewport(false);
        liveAdStripView=hs; liveAdBox=row(); liveAdBox.setPadding(dp(4),dp(4),dp(4),dp(4)); liveAdBox.setBackground(round(Color.WHITE,Color.rgb(232,233,238),16));
        renderPowerAds();
        hs.addView(liveAdBox,new HorizontalScrollView.LayoutParams(-2,dp(92))); return hs;
    }

    private void renderPowerAds(){
        if(liveAdBox==null)return;
        liveAdBox.removeAllViews();
        LinearLayout label=col(); label.setGravity(Gravity.CENTER); label.setPadding(dp(6),dp(5),dp(6),dp(5)); label.setBackground(gradient(Color.rgb(35,20,70),Color.rgb(118,20,95),16));
        TextView bolt=text("⚡",Color.WHITE,18,true); bolt.setGravity(Gravity.CENTER); label.addView(bolt,lp(dp(104),dp(22)));
        powerAdTitle=text("POWER AD",Color.WHITE,10.5f,true); powerAdTitle.setGravity(Gravity.CENTER); powerAdTitle.setSingleLine(true); powerAdTitle.setEllipsize(TextUtils.TruncateAt.END); label.addView(powerAdTitle,lp(dp(104),dp(24)));
        powerAdByline=text("by Touhid  •  OFFICIAL",Color.rgb(245,210,255),7.2f,true); powerAdByline.setGravity(Gravity.CENTER); powerAdByline.setSingleLine(true); label.addView(powerAdByline,lp(dp(104),dp(18)));
        liveAdBox.addView(label,lp(dp(112),dp(84)));
        if(!liveAds.isEmpty()){
            int n=liveAds.size(); int start=liveAdIndex%n; int shown=Math.min(4,n);
            for(int i=0;i<shown;i++){ JSONObject a=liveAds.get((start+i)%n); ImageView ad=pic(R.drawable.banner_top_left_3); ad.setBackground(round(Color.rgb(242,243,248),Color.TRANSPARENT,10)); String u=a.optString("image_url",""); if(!u.isEmpty())loadRemoteImage(ad,u); final JSONObject obj=a; ad.setOnClickListener(v->{String target=obj.optString("target_url","");if(FeatureRegistry.isSafeHttpUrl(target)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception ignored){}}}); liveAdBox.addView(ad,lp(dp(92),dp(76))); if(i<shown-1)liveAdBox.addView(space(),lp(dp(5),1)); }
        } else {
            int[] fallback={R.drawable.banner_top_left_3,R.drawable.banner_top_right_3,R.drawable.banner_top_left_4,R.drawable.banner_top_right_4};
            for(int i=0;i<fallback.length;i++){ImageView ad=pic(fallback[i]); ad.setBackground(round(Color.rgb(242,243,248),Color.TRANSPARENT,10)); liveAdBox.addView(ad,lp(dp(92),dp(76))); if(i<fallback.length-1)liveAdBox.addView(space(),lp(dp(5),1));}
        }
    }

    private View mainFeatureGrid(){
        LinearLayout grid=row(); grid.setGravity(Gravity.CENTER);
        for(int i=0;i<5;i++){View v=mainFeatureCard(i);grid.addView(v,weight(1,dp(84)));if(i<4)grid.addView(space(),lp(dp(3),1));}
        return grid;
    }

    private View mainFeatureCard(final int idx){
        FrameLayout card=new FrameLayout(this); mainCards[idx]=card; card.setBackground(round(Color.WHITE,Color.rgb(232,233,238),15)); card.setElevation(dp(2));
        LinearLayout c=col(); c.setGravity(Gravity.CENTER); c.setPadding(dp(2),dp(5),dp(2),dp(3));
        TextView iv=featureIcon(idx); mainIconViews[idx]=null; c.addView(iv,lp(dp(46),dp(46)));
        TextView t=text(mainTitles[idx],DARK,8.2f,true); t.setGravity(Gravity.CENTER); t.setSingleLine(true); t.setEllipsize(TextUtils.TruncateAt.END); mainLabels[idx]=t; c.addView(t,lp(-1,dp(20)));
        card.addView(c,new FrameLayout.LayoutParams(-1,-1));
        card.setOnClickListener(v->{String key=mainKeys[idx]; if("more_apps".equals(key)){startActivity(new Intent(this,UserMenuActivity.class));return;} if("gallery".equals(key)){startActivity(new Intent(this,GalleryActivity.class));return;} openFeature(mainTitles[idx],key);}); return card;
    }

    private TextView featureIcon(int idx){
        String[] icons={"🛒","▧","▶","🎁","▦"};
        int[][] colors={{255,145,0,255,76,0},{126,35,225,245,62,165},{30,105,235,15,180,255},{112,190,35,35,150,80},{225,40,160,120,20,210}};
        TextView v=text(icons[idx],Color.WHITE,23,true); v.setGravity(Gravity.CENTER); v.setBackground(gradient(Color.rgb(colors[idx][0],colors[idx][1],colors[idx][2]),Color.rgb(colors[idx][3],colors[idx][4],colors[idx][5]),13)); return v;
    }

    private View feedSection(){
        LinearLayout box=col(); LinearLayout title=row(); TextView t=text("MY FEED",DARK,15,true); title.addView(t,weight(1,dp(30))); TextView filter=text("⌕  Filter ⌄",MUTED,8.5f,true); filter.setGravity(Gravity.CENTER); filter.setBackground(round(Color.WHITE,Color.rgb(228,230,238),12)); title.addView(filter,lp(dp(86),dp(30))); postLimit=text("",MUTED,7.5f,false);postLimit.setVisibility(View.GONE);box.addView(title);
        LinearLayout composer=col(); composer.setPadding(dp(10),dp(8),dp(10),dp(8)); composer.setBackground(round(Color.WHITE,Color.rgb(228,230,238),14));
        LinearLayout top=row(); ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setBackground(round(Color.rgb(238,240,248),Color.TRANSPARENT,20));av.setClipToOutline(true);String avatarUrl=SessionManager.getAvatarUrl(this);if(avatarUrl!=null&&!avatarUrl.isEmpty())loadRemoteImage(av,avatarUrl);top.addView(av,lp(dp(42),dp(42))); TextView hint=text("  What's on your mind?  Write text or add a photo + caption...",MUTED,10,false);hint.setGravity(Gravity.CENTER_VERTICAL);top.addView(hint,weight(1,dp(42)));composer.addView(top); 
        LinearLayout acts=row(); TextView textPost=action("✎  TEXT",BLUE); TextView gallery=action("▧  GALLERY",PURPLE); TextView post=action("➤  POST",PURPLE); acts.addView(textPost,weight(1,dp(38))); acts.addView(space(),lp(dp(6),1)); acts.addView(gallery,weight(1,dp(38))); acts.addView(space(),lp(dp(6),1)); acts.addView(post,lp(dp(78),dp(38))); composer.addView(acts,top(lp(-1,dp(38)),7)); box.addView(composer,top(lp(-1,-2),6));
        textPost.setOnClickListener(v->showTextPostDialog()); gallery.setOnClickListener(v->pickPost("image")); top.setOnClickListener(v->showTextPostDialog()); post.setOnClickListener(v->{if(pendingPostUri!=null)showPostCaptionDialog();else pickPost("image");});
        feedStatus=text("Loading Feed...",MUTED,9,false);feedStatus.setGravity(Gravity.CENTER);box.addView(feedStatus,top(lp(-1,dp(34)),5)); feedList=col();box.addView(feedList,lp(-1,-2)); return box;
    }

    private void loadFeed(boolean reset){
        if(feedLoading || (!feedHasMore && !reset)) return; String token=SessionManager.getToken(this); if(token==null||token.isEmpty()){if(feedStatus!=null)feedStatus.setText("Login to see MY FEED");return;}
        feedLoading=true; if(reset){feedBefore=0;feedHasMore=true;if(feedList!=null)feedList.removeAllViews();if(feedStatus!=null)feedStatus.setText("Loading Feed...");}
        final long before=feedBefore; BackendClient.feedList(token,5,before,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("posts");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)renderPost(x);}feedBefore=d.optLong("nextBefore",0);if(feedBefore==0)feedHasMore=false;else feedHasMore=d.optBoolean("hasMore",false);int today=d.optInt("postsToday",0);boolean can=d.optBoolean("canPost",false);if(postLimit!=null)postLimit.setText(can?"Post today: "+today+"/1":"আজকের পোস্ট সম্পন্ন");if(feedStatus!=null)feedStatus.setText(feedHasMore?"Scroll down for more posts":"— End of Feed —");feedLoading=false;});}public void onError(String m){runOnUiThread(()->{if(feedStatus!=null)feedStatus.setText("Feed unavailable: "+m);feedLoading=false;});}});
    }

    private void renderPost(JSONObject x){
        long id=x.optLong("id",0);String uid=x.optString("userId","");String name=x.optString("name","MY SHOP User");String avatar=x.optString("avatarUrl","");String cap=x.optString("caption","");String url=x.optString("mediaUrl","");String type=x.optString("mediaType","image");
        LinearLayout card=col();card.setPadding(dp(10),dp(9),dp(10),dp(9));card.setBackground(round(Color.WHITE,Color.rgb(228,230,238),14));card.setElevation(dp(1));
        LinearLayout head=row();ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setBackground(round(Color.rgb(238,240,248),Color.TRANSPARENT,20));av.setClipToOutline(true);if(!avatar.isEmpty())loadRemoteImage(av,avatar);head.addView(av,lp(dp(40),dp(40)));LinearLayout who=col();who.setPadding(dp(9),0,dp(5),0);TextView nm=text(name,Color.rgb(25,30,55),11,true);who.addView(nm,lp(-1,dp(22)));who.addView(text("ID "+uid+" • "+x.optString("createdAt",""),MUTED,7.5f,false),lp(-1,dp(16)));head.addView(who,weight(1,dp(40)));card.addView(head,lp(-1,dp(42)));
        if(!cap.isEmpty()){TextView c=text(cap,Color.rgb(35,38,52),10.5f,false);c.setPadding(dp(2),dp(7),dp(2),dp(7));c.setMaxLines(8);c.setEllipsize(TextUtils.TruncateAt.END);card.addView(c,lp(-1,-2));}
        if(!url.isEmpty()){if("video".equalsIgnoreCase(type)){TextView play=action("▶  PLAY VIDEO",PURPLE);play.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}});card.addView(play,top(lp(-1,dp(52)),4));}else{ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setBackground(round(Color.rgb(242,243,248),Color.TRANSPARENT,10));card.addView(im,top(lp(-1,dp(260)),4));loadRemoteImage(im,url);}}
        LinearLayout actions=row();TextView like=action("♡  Like",MUTED);TextView comment=action("💬  Comment",MUTED);TextView share=action("↗  Share",MUTED);actions.addView(like,weight(1,dp(34)));actions.addView(comment,weight(1,dp(34)));actions.addView(share,weight(1,dp(34)));
        if(SessionManager.getUserId(this).equals(uid)||SessionManager.isAdmin(this)||SessionManager.isModerator(this)){TextView del=action("🗑",RED);del.setOnClickListener(v->deletePost(id));actions.addView(del,lp(dp(44),dp(34)));}
        card.addView(actions,top(lp(-1,dp(34)),6));feedList.addView(card,lp(-1,-2));feedList.addView(space(),lp(1,dp(9)));
    }

    private void deletePost(long id){new AlertDialog.Builder(this).setTitle("Delete this post?").setMessage("The post will be removed. User account and Permanent ID will not be affected.").setNegativeButton("CANCEL",null).setPositiveButton("DELETE",(d,w)->{BackendClient.Callback cb=new BackendClient.Callback(){public void onSuccess(JSONObject x){toast("✓ Post removed");loadFeed(true);}public void onError(String m){toast("Delete failed: "+m);}};if(SessionManager.isAdmin(this)||SessionManager.isModerator(this))BackendClient.moderatorFeedDelete(SessionManager.getToken(this),id,"Removed from Feed",cb);else BackendClient.feedDelete(SessionManager.getToken(this),id,cb);}).show();}

    private void pickPost(String type){if(SessionManager.getToken(this)==null||SessionManager.getToken(this).isEmpty()){startActivity(new Intent(this,AccountActivity.class));return;}Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);i.setType("video".equals(type)?"video/*":"image/*");pendingPostMime="video".equals(type)?"video/mp4":"image/jpeg";startActivityForResult(i,PICK_POST);}

    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r!=PICK_POST||c!=RESULT_OK||data==null||data.getData()==null)return;pendingPostUri=data.getData();try{if((data.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION)!=0)getContentResolver().takePersistableUriPermission(pendingPostUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}showPostCaptionDialog();}
    private void showPostCaptionDialog(){EditText cap=new EditText(this);cap.setHint("Write a caption...");cap.setMinLines(3);new AlertDialog.Builder(this).setTitle("Create Post").setMessage("User: 1 photo + caption per day. Video is Admin-only for now.").setView(cap).setNegativeButton("CANCEL",null).setPositiveButton("POST",(d,w)->uploadPost(cap.getText().toString().trim())).show();}
    private void showTextPostDialog(){
        final EditText cap=new EditText(this);
        cap.setHint("Write your post...");
        cap.setMinLines(4);
        cap.setGravity(Gravity.TOP|Gravity.START);
        cap.setPadding(dp(10),dp(8),dp(10),dp(8));
        new AlertDialog.Builder(this)
                .setTitle("Create Text Post")
                .setMessage("Write a text-only post. No photo is required.")
                .setView(cap)
                .setNegativeButton("CANCEL",null)
                .setPositiveButton("POST",(d,w)->uploadTextPost(cap.getText().toString().trim()))
                .show();
    }

    private void uploadTextPost(String caption){
        if(caption.isEmpty()){toast("Please write something first.");return;}
        String token=SessionManager.getToken(this);
        if(token==null||token.isEmpty()){startActivity(new Intent(this,AccountActivity.class));return;}
        BackendClient.feedText(token,caption,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{toast("✓ Post published");loadFeed(true);});}
            public void onError(String m){runOnUiThread(()->toast("Post failed: "+m));}
        });
    }
    private void uploadPost(String caption){if(pendingPostUri==null)return;try{InputStream in=getContentResolver().openInputStream(pendingPostUri);String mime=getContentResolver().getType(pendingPostUri);String name=queryName(pendingPostUri);String mediaType=(mime!=null&&mime.startsWith("video/"))?"video":"image";BackendClient.feedUpload(SessionManager.getToken(this),in,name,mime==null?pendingPostMime:mime,mediaType,caption,new BackendClient.Callback(){public void onSuccess(JSONObject d){toast("✓ Post published");pendingPostUri=null;loadFeed(true);}public void onError(String m){toast("Post failed: "+m);}});}catch(Exception e){toast("Could not open selected media.");}}
    private String queryName(Uri u){try(android.database.Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}catch(Exception ignored){}return "myshop-post";}

    private View bottom(){LinearLayout n=row();n.setPadding(dp(4),dp(2),dp(4),dp(2));n.setBackground(round(Color.WHITE,Color.rgb(231,232,238),18));n.setElevation(dp(7));n.addView(navItem("⌂",LanguageManager.t(this,"home"),true,"home"),weight(1,dp(52)));n.addView(navItem("◉",LanguageManager.t(this,"live"),false,"live"),weight(1,dp(52)));FrameLayout store=new FrameLayout(this);store.setPadding(dp(4),0,dp(4),0);LinearLayout bubble=col();bubble.setGravity(Gravity.CENTER);bubble.setBackground(gradient(Color.rgb(74,43,230),Color.rgb(117,20,220),28));TextView si=text("▢",Color.WHITE,20,true);si.setGravity(Gravity.CENTER);bubble.addView(si,lp(-1,dp(27)));TextView st=text(LanguageManager.t(this,"store"),Color.WHITE,7.5f,true);st.setGravity(Gravity.CENTER);bubble.addView(st,lp(-1,dp(17)));bubble.setOnClickListener(v->openFeature("MY SHOP","my_shop"));store.addView(bubble,new FrameLayout.LayoutParams(dp(58),dp(58),Gravity.CENTER));n.addView(store,weight(1,dp(52)));n.addView(navItem("💬",LanguageManager.t(this,"chat"),false,"chat"),weight(1,dp(52)));n.addView(navItem("▦",LanguageManager.t(this,"more"),false,"more"),weight(1,dp(52)));return n;}
    private View navItem(String glyph,String label,boolean active,String key){LinearLayout item=col();item.setGravity(Gravity.CENTER);TextView g=text(glyph,active?BLUE:Color.rgb(55,57,68),18,true);g.setGravity(Gravity.CENTER);item.addView(g,lp(-1,dp(27)));TextView t=text(label,active?BLUE:Color.rgb(55,57,68),7.5f,active);t.setGravity(Gravity.CENTER);item.addView(t,lp(-1,dp(17)));if(active){TextView line=text("━━━━",BLUE,5.5f,true);line.setGravity(Gravity.CENTER);item.addView(line,lp(-1,dp(6)));}item.setOnClickListener(v->{if("live".equals(key))openFeature("LIVE","live_now");else if("chat".equals(key))openFeature("CHAT","chat");else if("more".equals(key))startActivity(new Intent(this,UserMenuActivity.class));});return item;}

    private void resolveMenuDestination(){String token=SessionManager.getToken(this);String uid=SessionManager.getUserId(this);if(AdminIdentifiers.isAdminIdentifier(uid)){SessionManager.setRemoteSession(this,token,Role.ADMIN,AdminIdentifiers.adminIdFor(uid));startActivity(new Intent(this,AdminHubActivity.class));return;}if(token==null||token.isEmpty()){startActivity(new Intent(this,AccountActivity.class));return;}if(SessionManager.isAdmin(this)){startActivity(new Intent(this,AdminHubActivity.class));return;}if(SessionManager.isModerator(this)){startActivity(new Intent(this,FeedModerationActivity.class));return;}BackendClient.me(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{try{JSONObject u=d.optJSONObject("user");String role=u==null?"USER":u.optString("role","USER");if("ADMIN".equalsIgnoreCase(role)){SessionManager.setRemoteSession(MainActivity.this,token,Role.ADMIN,u.optString("userId",uid));startActivity(new Intent(MainActivity.this,AdminHubActivity.class));}else if("MODERATOR".equalsIgnoreCase(role)){SessionManager.setRemoteSession(MainActivity.this,token,Role.MODERATOR,u.optString("userId",uid));startActivity(new Intent(MainActivity.this,FeedModerationActivity.class));}else startActivity(new Intent(MainActivity.this,UserMenuActivity.class));}catch(Exception e){startActivity(new Intent(MainActivity.this,UserMenuActivity.class));}});}public void onError(String m){runOnUiThread(()->startActivity(new Intent(MainActivity.this,UserMenuActivity.class)));}});}

    private void loadRemote(){BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->applyRemote(d));}public void onError(String m){}});}
    private void applyRemote(JSONObject d){try{JSONObject c=d.optJSONObject("config");if(c!=null){String n=c.optString("breaking_news","").trim();if(!n.isEmpty()&&newsText!=null)newsText.setText(n);saveRemoteUrl("my_shop",c.optString("my_shop_url",""));saveRemoteUrl("live_tv",c.optString("live_tv_url",""));saveRemoteUrl("external_movie",c.optString("external_movie_url",""));saveRemoteUrl("chat",c.optString("chat_url",""));if(powerAdTitle!=null){powerAdTitle.setText(c.optString("power_ad_title","POWER AD").trim().isEmpty()?"POWER AD":c.optString("power_ad_title","POWER AD").trim());powerAdByline.setText(c.optString("power_ad_byline","by Touhid").trim().isEmpty()?"by Touhid":c.optString("power_ad_byline","by Touhid").trim());}}JSONArray banners=d.optJSONArray("banners");if(banners!=null){for(int i=0;i<banners.length();i++){JSONObject o=banners.optJSONObject(i);if(o==null)continue;String folder=o.optString("folder","");int slot=o.optInt("slot",0);String url=o.optString("image_url","").trim();if(url.isEmpty())continue;if("hero".equalsIgnoreCase(folder)&&slot>=1&&slot<=6){remoteHeroUrls[slot-1]=url;if(slot==slide+1)loadRemoteImage(hero,url);}else if("promo".equalsIgnoreCase(folder)&&slot>=1&&slot<=3){remotePromoUrls[slot-1]=url;if(slot<=2)loadRemoteImage(promoViews[slot-1],url);}}}JSONArray ads=d.optJSONArray("dashboardAds");liveAds.clear();if(ads!=null){for(int i=0;i<ads.length();i++){JSONObject o=ads.optJSONObject(i);if(o!=null&&"live_now".equalsIgnoreCase(o.optString("box_key","")))liveAds.add(o);}}if(liveAdStripView!=null)liveAdStripView.setVisibility(View.VISIBLE); renderPowerAds();JSONArray features=d.optJSONArray("featureButtons");if(features!=null){for(int i=0;i<features.length();i++){JSONObject f=features.optJSONObject(i);if(f==null)continue;String key=f.optString("key","");for(int j=0;j<mainKeys.length;j++)if(mainKeys[j].equals(key)){mainRemoteUrls[j]=f.optString("target_url","");}}}}catch(Exception ignored){}}
    private void saveRemoteUrl(String key,String url){if(url!=null&&!url.trim().isEmpty())getSharedPreferences("myshop_remote_config",MODE_PRIVATE).edit().putString("url_"+key,url.trim()).apply();}
    private String featureRemoteUrl(String key){for(int i=0;i<mainKeys.length;i++)if(mainKeys[i].equals(key))return mainRemoteUrls[i]==null?"":mainRemoteUrls[i].trim();return getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("url_"+key,"");}
    private void openFeature(String title,String key){try{if("gallery".equals(key)){startActivity(new Intent(this,GalleryActivity.class));return;}if("more_apps".equals(key)){startActivity(new Intent(this,UserMenuActivity.class));return;}Intent i=new Intent(this,FeatureActivity.class);i.putExtra("title",title);i.putExtra("feature_key",key);String url=featureRemoteUrl(key);if("my_shop".equals(key))url=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("url_my_shop",url);if("external_movie".equals(key))url=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("url_external_movie",url);if(FeatureRegistry.isSafeHttpUrl(url))i.putExtra("url",url);else{String fallback=FeatureRegistry.getUrl(this,key);if(FeatureRegistry.isSafeHttpUrl(fallback))i.putExtra("url",fallback);}startActivity(i);}catch(Throwable t){toast(title+" is ready.");}}
    private void applyLiveAd(int index){if(liveAdImage==null||liveAds.isEmpty())return;JSONObject a=liveAds.get(index%liveAds.size());String u=a.optString("image_url","");String cap=a.optString("caption","");if(!u.isEmpty())loadRemoteImage(liveAdImage,u);liveAdCaption.setText(cap.isEmpty()?"Advertisement":cap);liveAdImage.setOnClickListener(v->{String target=a.optString("target_url","");if(FeatureRegistry.isSafeHttpUrl(target)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception ignored){}}});}
    private void startLiveAdCarousel(){handler.postDelayed(new Runnable(){public void run(){if(!liveAds.isEmpty()){liveAdIndex=(liveAdIndex+1)%liveAds.size();renderPowerAds();}handler.postDelayed(this,5000);}},5000);}
    private void startCarousel(){handler.postDelayed(new Runnable(){public void run(){slide=(slide+1)%6;if(remoteHeroUrls[slide]!=null&&!remoteHeroUrls[slide].isEmpty())loadRemoteImage(hero,remoteHeroUrls[slide]);else hero.setImageResource(heroImgs[slide]);StringBuilder s=new StringBuilder();for(int i=0;i<6;i++){s.append(i==slide?"●":"○");if(i<5)s.append("   ");}dots.setText(s.toString());handler.postDelayed(this,3500);}},3500);}
    private void loadNotificationCount(){String token=SessionManager.getToken(this);if(token==null||token.isEmpty()){unreadNotificationCount=0;updateNotificationBadge();return;}BackendClient.notifications(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){unreadNotificationCount=Math.max(0,d.optInt("unreadCount",0));runOnUiThread(()->updateNotificationBadge());}public void onError(String m){}});}
    private void updateNotificationBadge(){if(notificationBadge==null)return;if(unreadNotificationCount<=0)notificationBadge.setVisibility(View.GONE);else{notificationBadge.setVisibility(View.VISIBLE);notificationBadge.setText(unreadNotificationCount>99?"99+":String.valueOf(unreadNotificationCount));}}
    private String languageCode(){String l=LanguageManager.get(this);if(LanguageManager.EN.equals(l))return "EN";if(LanguageManager.HI.equals(l))return "HI";if(LanguageManager.AR.equals(l))return "AR";return "বাং";}
    @Override protected void onResume(){super.onResume();loadNotificationCount();if(feedList!=null&&!feedLoading)loadFeed(true);}
    private void loadRemoteImage(ImageView target,String url){Executors.newSingleThreadExecutor().execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(10000);c.setInstanceFollowRedirects(true);try(InputStream in=c.getInputStream()){Bitmap bm=BitmapFactory.decodeStream(in);if(bm!=null)runOnUiThread(()->target.setImageBitmap(bm));}}catch(Exception ignored){}});}
    private TextView action(String s,int c){TextView t=text(s,Color.WHITE,9.5f,true);t.setGravity(Gravity.CENTER);t.setBackground(round(c,Color.TRANSPARENT,10));return t;}
    private ImageView pic(int r){ImageView v=new ImageView(this);v.setImageResource(r);v.setScaleType(ImageView.ScaleType.FIT_XY);return v;}
    private Button icon(String s,int c,float z){Button b=new Button(this);b.setText(s);b.setTextColor(c);b.setTextSize(z);b.setGravity(Gravity.CENTER);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setPadding(0,0,0,0);b.setBackgroundColor(Color.TRANSPARENT);return b;}
    private TextView text(String s,int c,float z,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;} private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;} private View space(){return new View(this);} private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);} private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;} private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);} private GradientDrawable round(int fill,int stroke,int rad){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(rad));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;} private GradientDrawable gradient(int a,int b,int rad){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});g.setCornerRadius(dp(rad));return g;} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
}
