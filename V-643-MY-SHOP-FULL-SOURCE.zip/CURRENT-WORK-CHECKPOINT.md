V-641 /2.9.641 source checkpoint. Read MY-SHOP-DEVELOPER-HANDOFF.md for exact changes, tests and remaining acceptance. No APK; Gradle download network blocked. Next new deliveryV642.
