Current V643 build repair; next V644. Read current handoff.
