package com.myshop.app;

import android.view.WindowManager;
import android.view.Window;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.net.Uri;
import android.os.Bundle;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.os.Handler;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

/**
 * V-390 Live Streaming Home (Page 2).
 * Approved structure: premium banner -> Go Live / Join Live -> Live Categories ->
 * Today's Live Challenge -> People You May Like -> Weekly Live Stars.
 * Active rooms stay inside JOIN LIVE; no duplicate Top Live block on this page.
 * Shared navigation identity: Home | Store | Video | My Feed | More.
 */
public class LiveHomeActivity extends AppCompatActivity {
    private static final String BANNER_CACHE_PREFS="myshop_live_home_banner_cache";
    private static final String BANNER_CACHE_KEY="active_banners_v430";
    private static final String BANNER_SECTION_KEY="live_home_banner_section_enabled";
    private static final long BANNER_FIRST_TICK_MS=900L;
    private static final long BANNER_INTERVAL_MS=4500L;
    private final int BG=Color.rgb(255,249,252), SURFACE=Color.rgb(255,255,255), SURFACE_2=Color.rgb(246,240,255);
    private final int WHITE=Color.WHITE, NAVY=Color.rgb(23,35,75), MUTED=Color.rgb(91,101,137), BLUE=Color.rgb(45,114,246), CYAN=Color.rgb(41,203,255), PINK=Color.rgb(240,43,183), PURPLE=Color.rgb(123,63,242), GOLD=Color.rgb(255,202,72), RED=Color.rgb(255,45,95);
    private final Handler handler=new Handler();
    private final ArrayList<JSONObject> bannerData=new ArrayList<>();
    private final ArrayList<JSONObject> discoverConfigs=new ArrayList<>();
    private final ArrayList<JSONObject> peopleData=new ArrayList<>();
    private final ArrayList<JSONObject> starData=new ArrayList<>();
    private final ArrayList<JSONObject> liveNowData=new ArrayList<>();
    private String renderedLanguage;
    private UpcomingCarousel upcomingCarousel;
    private PeekBannerCarousel bannerCarousel;
    private TextView bannerEmpty;private FrameLayout bannerHero;
    private TextView bannerDots,bannerCounter;
    private LinearLayout peopleRow,starsRow,categoryTrack,liveNowRow,promoTrack,premiumTrack;
    private Home2Metrics metrics;
    private final ArrayList<JSONObject>[] promoItems=new ArrayList[]{new ArrayList<>(),new ArrayList<>(),new ArrayList<>(),new ArrayList<>()};
    private final String[] promoNames={"Hot Deals","Discount Zone","New Arrivals","Special Offer"};
    private final int[] promoOrder={1,2,3,4};
    private final boolean[] promoEnabled={true,true,true,true};
    private final String[] live2Keys={"live2_music","live2_chat","live2_talent","live2_friendship","live2_gaming","live2_shopping","live2_pk","live2_more","live2_custom_09","live2_custom_10","live2_custom_11","live2_custom_12","live2_custom_13","live2_custom_14","live2_custom_15","live2_custom_16"};
    private final String[] live2Icons={"🎵","💬","🎤","🤝","🎮","🛍","⚔","✦","✦","✦","✦","✦","✦","✦","✦","✦"};
    private final String[] live2Labels={"Music","Chat & Talk","Talent","Friendship","Gaming","Shopping","PK Battle","More","Custom 9","Custom 10","Custom 11","Custom 12","Custom 13","Custom 14","Custom 15","Custom 16"};
    private final String[] live2IconUrls=new String[16];
    private final String[] live2Targets={"LIVE_NOW","TALK_ROOM","TRENDING","FRIENDS","LIVE_NOW","SHOP_LIVE","TRENDING","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW"};
    private final int[] live2Order={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
    private final boolean[] live2Active={true,true,true,true,true,true,true,true,false,false,false,false,false,false,false,false};
    private TextView peopleState,starsState,notificationBadge,messageBadge;
    private int bannerIndex=0;
    private int unreadNotificationCount=0,unreadMessageCount=0;
    private float bannerDownX=0f;
    private boolean bannerLoadInFlight=false,bannerSectionEnabled=true;
    private boolean firstLiveResume=true;
    private boolean liveHomeVisible=false;
    private boolean liveHomeDestroyed=false;
    private final ExecutorService imageIo=Executors.newFixedThreadPool(2);
    private final LiveDirectoryWatch621 directoryWatch621=new LiveDirectoryWatch621(()->loadLiveNow());
    private final Runnable liveRefreshTick=new Runnable(){@Override public void run(){if(!liveHomeVisible||liveHomeDestroyed)return;loadLiveNow();handler.postDelayed(this,15000L);}};

    // V-366: bannerTick is the single recurring scheduler. It advances once, then posts
    // exactly one next tick. render/resume/swipe may reset that one timer, but no code path
    // can multiply callbacks. This also keeps rotation alive after network refreshes.
    private final Runnable bannerTick=new Runnable(){@Override public void run(){
        if(!liveHomeVisible||liveHomeDestroyed)return;
        try{if(bannerData.size()>1)showBannerInternal((bannerIndex+1)%bannerData.size(),true);}catch(Throwable ignored){}
        scheduleBanner(false);
    }};

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        bannerSectionEnabled=getSharedPreferences(BANNER_CACHE_PREFS,MODE_PRIVATE).getBoolean(BANNER_SECTION_KEY,true);
        WatchHistoryActivity.record(this,"LIVE HUB","Live Hub","live-hub");
        setContentView(build());
        MiniAdOverlay.install(this,"live");
        MiniHeadlineOverlay.install(this,"live");
        renderBanners();
        loadBanners();
        loadPage2IconConfig();
        loadLiveNow();
        loadHeaderCounts();
    }

    private View build(){
        metrics=new Home2Metrics(getResources().getConfiguration().screenWidthDp);
        LinearLayout page=col();page.setBackground(new Home2BackgroundDrawable());Appearance.board(page);
        page.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(0,Math.max(0,i.getSystemWindowInsetTop())+dp(8),0,Math.max(0,i.getSystemWindowInsetBottom()-dp(6)));return i;});
        View header=homeStyleHeader();LinearLayout.LayoutParams hp=lp(-1,dp(58));hp.setMargins(0,0,0,0);page.addView(header,hp);
        page.addView(liveTopMenu(),lp(-1,dp(52)));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);
        LinearLayout body=col();body.setPadding(0,dp(4),0,dp(14));body.setBackground(new Home2BackgroundDrawable());Appearance.board(body);
        FrameLayout hero=new FrameLayout(this);bannerHero=hero;hero.setBackgroundColor(Color.TRANSPARENT);hero.setClipToOutline(true);
        bannerCarousel=new PeekBannerCarousel(this);bannerCarousel.setListener(new PeekBannerCarousel.Listener(){
            public void onIndexChanged(int idx){bannerIndex=idx;updateBannerIndicators();}
            public void onTap(int idx){bannerIndex=idx;openCurrentBannerTarget();}
            public void onHold(){if(SessionManager.isAdmin(LiveHomeActivity.this))openBannerAdmin("live_home","Main Advertising Banners");}
            public void onTouching(boolean active){if(active)handler.removeCallbacks(bannerTick);else scheduleBanner(false);}
        });hero.addView(bannerCarousel,new FrameLayout.LayoutParams(-1,-1));
        bannerEmpty=t(SessionManager.isAdmin(this)?"ADVERTISEMENT · Tap to manage up to 20 banners":"myshop · Advertising",11,0xff692894,true);bannerEmpty.setGravity(Gravity.CENTER);bannerEmpty.setVisibility(View.GONE);if(SessionManager.isAdmin(this))bannerEmpty.setOnClickListener(v->openBannerAdmin("live_home","Main Advertising Banners"));hero.addView(bannerEmpty,new FrameLayout.LayoutParams(-1,-1));
        bannerDots=t("",8,WHITE,true);bannerDots.setGravity(Gravity.CENTER);FrameLayout.LayoutParams dots=new FrameLayout.LayoutParams(-1,dp(16),Gravity.BOTTOM);hero.addView(bannerDots,dots);
        bannerCounter=t("0/0",7.5f,WHITE,true);bannerCounter.setGravity(Gravity.CENTER);bannerCounter.setBackground(round(0xB032124A,Color.TRANSPARENT,9));FrameLayout.LayoutParams count=new FrameLayout.LayoutParams(dp(38),dp(20),Gravity.RIGHT|Gravity.BOTTOM);count.rightMargin=dp(5);count.bottomMargin=dp(5);hero.addView(bannerCounter,count);
        hero.setContentDescription("Live Streaming advertising banner");
        body.addView(hero,lp(-1,Math.round(getResources().getDisplayMetrics().widthPixels*.84f*5f/12f)));
        upcomingCarousel=new UpcomingCarousel(this,"live");body.addView(upcomingCarousel,lp(-1,-2));
        // V-526 locked Page-2 tabs: LIVE NOW | Following | New | Explore.
        // Same font size, no emoji, no border/ring/box. LIVE NOW is red with a subtle glow.
        LinearLayout filters=row();filters.setGravity(Gravity.CENTER_VERTICAL);filters.setPadding(dp(8),0,dp(8),0);
        String[] filterNames={"LIVE NOW","Following","New"};
        for(int i=0;i<filterNames.length;i++){
            final int n=i;TextView label=t(UiStrings.label(this,filterNames[i]),10.2f,i==0?0xffff174e:NAVY,true);
            label.setGravity(Gravity.CENTER);label.setSingleLine(true);label.setBackgroundColor(Color.TRANSPARENT);
            if(i==0) label.setShadowLayer(dp(4),0,0,0x66ff174e);
            label.setOnClickListener(v->{if(n==0)openList();else if(n==1)openLiveCategory("FOLLOWING");else if(n==2)openLiveCategory("NEW");else openExplore("CATEGORIES");});
            filters.addView(label,new LinearLayout.LayoutParams(0,dp(40),1f));
            if(i<filterNames.length-1){View sep=new View(this);sep.setBackgroundColor(0xffaeb7c9);filters.addView(sep,new LinearLayout.LayoutParams(dp(1),dp(22)));}
        }
        body.addView(filters,top(lp(-1,dp(40)),6));
        liveNowRow=col();body.addView(liveNowRow,lp(-1,-2));renderLiveNow();
        scroll.addView(body,new ScrollView.LayoutParams(-1,-2));page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));page.addView(bottomNav(),lp(-1,dp(78)));page.post(page::requestApplyInsets);return page;
    }

    private View homeStyleHeader(){SharedPageHeader h=new SharedPageHeader(this);notificationBadge=h.notificationBadge;messageBadge=h.messageBadge;return h;}
    private String languageCode(){ String code=LanguageManager.get(this); if(code==null||code.isEmpty()) return "BN"; return code.toUpperCase(Locale.US); }
    private FrameLayout headerAction(int iconRes,String desc){FrameLayout b=new FrameLayout(this);ImageView i=new ImageView(this);i.setImageResource(iconRes);i.setScaleType(ImageView.ScaleType.CENTER_INSIDE);i.setPadding(dp(5),dp(5),dp(5),dp(5));i.setImageTintList(ColorStateList.valueOf(Color.WHITE));i.setContentDescription(desc);b.addView(i,new FrameLayout.LayoutParams(-1,-1));return b;}
    private FrameLayout headerMessageAction(){FrameLayout b=new FrameLayout(this);ImageView i=new ImageView(this);i.setImageResource(R.drawable.ui_message_hd);i.setScaleType(ImageView.ScaleType.CENTER_INSIDE);i.setPadding(dp(3),dp(3),dp(3),dp(3));b.addView(i,new FrameLayout.LayoutParams(-1,-1));return b;}
    private View liveTopMenu(){
        // Page-2 must visually belong to the same premium menu family as the main dashboard.
        LinearLayout bar=row();Appearance.board(bar);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(dp(4),dp(1),dp(4),dp(1));
        bar.setBackground(gradient(new int[]{0xff11174a,0xff28165f,0xff171042},0));bar.setElevation(dp(2));
        ImageView menu=new ImageView(this);menu.setImageResource(R.drawable.ic_hamburger_blue);menu.setImageTintList(ColorStateList.valueOf(AppThemePalette.current(this).text));menu.setScaleType(ImageView.ScaleType.CENTER_INSIDE);menu.setPadding(dp(12),dp(12),dp(12),dp(12));menu.setContentDescription("Menu");menu.setOnClickListener(v->showDiscoverMenu());bar.addView(menu,lp(dp(58),dp(52)));
        String[] labels={"Store","Games"};int[] icons={R.drawable.live609_store,R.drawable.premium438_game,R.drawable.premium438_coins};int[] colors={0xffffd66b,0xffd8c5ff,0xff8dffd3};String[] keys={"membership","games","earn"};
        for(int i=0;i<labels.length;i++){final int n=i;LinearLayout cell=col();cell.setGravity(Gravity.CENTER);cell.setPadding(dp(2),dp(3),dp(2),dp(3));ImageView iv=new ImageView(this);iv.setImageResource(icons[i]);iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);iv.setElevation(dp(4));cell.addView(iv,lp(dp(27),dp(27)));TextView x=t(UiStrings.label(this,labels[i]),9.1f,Color.WHITE,true);x.setGravity(Gravity.CENTER_VERTICAL);x.setSingleLine(true);LinearLayout.LayoutParams xp=lp(-2,dp(34));xp.leftMargin=0;xp.height=dp(18);cell.addView(x,xp);cell.setOnClickListener(v->{if("membership".equals(keys[n])){WatchHistoryActivity.record(this,"MEMBERSHIP","Membership","Open MY SHOP Membership","membership","","View Membership");startActivity(new Intent(this,StoreActivity.class));}else if("games".equals(keys[n]))startActivity(new Intent(this,GamesComingSoonActivity.class));else openDiscoverItem("earn","Earn");});bar.addView(cell,weight(1,dp(52)));}
        return bar;
    }
    private void loadDiscoverConfig(){
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){JSONArray arr=d.optJSONArray("managedLinks");discoverConfigs.clear();if(arr!=null){for(int k=0;k<arr.length();k++){JSONObject x=arr.optJSONObject(k);if(x!=null&&x.optString("category","").toLowerCase(Locale.US).startsWith("discover_")){discoverConfigs.add(x);}}}java.util.Collections.sort(discoverConfigs,(left,right)->Integer.compare(Math.max(1,left.optInt("display_order",999)),Math.max(1,right.optInt("display_order",999))));}
            public void onError(String m){}
        });
    }
    private void showDiscoverMenu(){
        AppThemePalette palette=AppThemePalette.current(this);
        LinearLayout outer=col();outer.setPadding(dp(14),dp(10),dp(14),dp(12));outer.setBackground(round(palette.card,palette.border,22));
        LinearLayout head=row();head.addView(t("LIVE MENU",16,palette.text,true),wt(1,dp(36)));
        TextView close=t("✕",18,palette.text,true);close.setGravity(Gravity.CENTER);head.addView(close,lp(dp(42),dp(36)));outer.addView(head);
        LinearLayout items=row();String[] titles={"Agent","Support","Share App"};int[] icons={R.drawable.premium438_people,R.drawable.premium438_headphones,R.drawable.premium438_share};
        for(int n=0;n<3;n++){final int action=n;LinearLayout item=col();item.setGravity(Gravity.CENTER);ImageView im=new ImageView(this);PremiumArt.apply(im,icons[n]);im.setScaleType(ImageView.ScaleType.CENTER_INSIDE);item.addView(im,lp(dp(48),dp(48)));TextView label=t(titles[n],11,palette.text,true);label.setGravity(Gravity.CENTER);item.addView(label,lp(-1,dp(30)));item.setOnClickListener(v->{if(action==0)startActivity(new Intent(this,AgentActivity.class));else if(action==1)startActivity(new Intent(this,HelpCenterActivity.class));else {Intent share=new Intent(Intent.ACTION_SEND);share.setType("text/plain");share.putExtra(Intent.EXTRA_TEXT,"MY SHOP — https://play.google.com/store/apps/details?id="+getPackageName());startActivity(Intent.createChooser(share,"Share App"));}});items.addView(item,wt(1,dp(88)));}
        outer.addView(items);PanelDesign.adminButton(this,outer,"live_discover");PanelDesign.apply(this,outer,"live_discover");
        AlertDialog dialog=new MyShopDialogBuilder(this).setView(outer).create();close.setOnClickListener(v->dialog.dismiss());dialog.setCanceledOnTouchOutside(true);dialog.show();
    }

    private JSONObject findDiscover(ArrayList<JSONObject> list,String key){if(list==null)return null;for(JSONObject x:list)if(x!=null&&key.equalsIgnoreCase(x.optString("category","").replaceFirst("^discover_","")))return x;return null;}
    private void openDiscoverItem(String key,String title){
        if(SessionManager.isAdmin(this)){startActivity(new Intent(this,AdminSectionActivity.class).putExtra("section","feature_card").putExtra("managed_category","discover_"+key).putExtra("managed_title",title).putExtra("admin_context",true));return;}
        try{if("discover".equals(key)){openExplore("DISCOVER");}else if("events".equals(key)){openExplore("EVENTS");}else if("live_ranking".equals(key)){openLiveCategory("TRENDING");}else if("rewards".equals(key)){startActivity(new Intent(this,FeatureActivity.class).putExtra("title",title).putExtra("feature_key","discover_rewards"));}else if("achievements".equals(key)){startActivity(new Intent(this,FeatureActivity.class).putExtra("title",title).putExtra("feature_key","discover_achievements"));}else if("spotlight".equals(key)){openExplore("SPOTLIGHT");}else if("deal_zone".equals(key)){startActivity(new Intent(this,PhysicalStoreActivity.class).putExtra("folder",1));}else if("experiences".equals(key)){openExplore("EXPERIENCES");}else if("ai_studio".equals(key)){startActivity(new Intent(this,FeatureActivity.class).putExtra("title",title).putExtra("feature_key","discover_ai_studio"));}else{startActivity(new Intent(this,HelpCenterActivity.class));}}catch(Exception e){Toast.makeText(this,title+" is not configured yet.",Toast.LENGTH_SHORT).show();}
    }

    private void renderPremiumBar(){
        if(premiumTrack==null)return;premiumTrack.removeAllViews();
        String[] labels={"Membership","Entry Rider","Wallpaper","Avatar Frame","Comment Box","My Items"};
        int[] icons={R.drawable.premium438_crown,R.drawable.premium438_trophy,R.drawable.premium438_gallery,R.drawable.premium438_people,R.drawable.premium438_chat,R.drawable.premium438_bag};
        for(int i=0;i<labels.length;i++){final int n=i;LinearLayout c=col();c.setGravity(Gravity.CENTER);c.setPadding(dp(2),dp(3),dp(2),dp(2));ImageView iv=new ImageView(this);iv.setImageResource(icons[i]);iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);c.addView(iv,lp(dp(24),dp(27)));TextView tx=t(UiStrings.label(this,labels[i]),6.9f,0xff42237e,true);tx.setGravity(Gravity.CENTER);tx.setMaxLines(2);c.addView(tx,lp(-1,dp(25)));PremiumUi.premiumButton(c,i==0?new int[]{0xffffe78b,0xffffb63b}:new int[]{0xffffffff,0xfff1ecff},11,0xffd8c5ff,3);c.setOnClickListener(v->{switch(n){case 0:startActivity(new Intent(this,StoreActivity.class).putExtra("category","MEMBER"));break;case 1:startActivity(new Intent(this,EntryRideCatalogActivity.class));break;case 2:startActivity(new Intent(this,StoreActivity.class).putExtra("category","THEME"));break;case 3:startActivity(new Intent(this,StoreActivity.class).putExtra("category","FRAME"));break;case 4:startActivity(new Intent(this,StoreActivity.class).putExtra("category","COMMENT"));break;default:startActivity(new Intent(this,MyItemsActivity.class));break;}});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(62),1);if(i>0)p.leftMargin=dp(3);premiumTrack.addView(c,p);}
    }
    private HorizontalScrollView horizontal(LinearLayout track,int height){HorizontalScrollView h=new HorizontalScrollView(this);h.setHorizontalScrollBarEnabled(false);h.setOverScrollMode(View.OVER_SCROLL_NEVER);h.addView(track,new HorizontalScrollView.LayoutParams(-2,dp(height)));return h;}
    private LinearLayout.LayoutParams rowWidth(int visible,int gap,int position,int height){int width=Math.max(1,(getResources().getDisplayMetrics().widthPixels-dp(24)-dp(gap)*(visible-1))/visible);LinearLayout.LayoutParams p=lp(width,dp(height));p.rightMargin=position==visible-1?0:dp(gap);return p;}
    private View compactHeader(String label,Runnable action){LinearLayout h=row();TextView title=t(label,12,0xFF101A48,true);title.setSingleLine(true);h.addView(title,wt(1,dp(22)));TextView all=t("See All ›",9,0xFF204CC5,true);all.setGravity(Gravity.CENTER);all.setOnClickListener(v->action.run());h.addView(all,lp(dp(60),dp(22)));return h;}
    private View discoveryCard(String icon,String name,String action,int[] colors,Runnable run){LinearLayout card=col();card.setPadding(dp(4),dp(3),dp(4),dp(3));card.setBackground(gradient(colors,10));TextView title=t(icon+" "+name,8.5f,WHITE,true);title.setMaxLines(2);card.addView(title,lp(-1,dp(26)));TextView cta=t(action+" ›",8.3f,WHITE,true);cta.setGravity(Gravity.CENTER);card.addView(cta,lp(-1,dp(15)));card.setOnClickListener(v->run.run());return card;}
    private void renderPromos(){if(promoTrack==null)return;promoTrack.removeAllViews();ArrayList<Integer> order=new ArrayList<>();for(int i=0;i<4;i++)if(promoEnabled[i])order.add(i);Collections.sort(order,(a,b)->Integer.compare(promoOrder[a],promoOrder[b]));int[][] colors={{0xFFFFD673,0xFFFFF6C8},{0xFF9CF3AA,0xFFE8FFE8},{0xFF80D7FF,0xFFEEF8FF},{0xFFF197ED,0xFFFFE7FF}};int[] icons={R.drawable.premium438_fire,R.drawable.premium438_tag,R.drawable.premium438_gift,R.drawable.premium438_crown};int pos=0;for(int index:order){final int n=index;LinearLayout card=col();card.setPadding(dp(4),dp(3),dp(4),dp(2));card.setBackground(gradient(colors[n],11));TextView name=t(promoNames[n],9,0xFF17234B,true);name.setSingleLine(true);name.setEllipsize(android.text.TextUtils.TruncateAt.END);card.addView(name,lp(-1,dp(15)));ImageView preview=new ImageView(this);preview.setScaleType(ImageView.ScaleType.FIT_CENTER);preview.setImageResource(icons[n]);if(!promoItems[n].isEmpty())loadImage(preview,promoItems[n].get(0).optString("image_url",""),280);card.addView(preview,lp(-1,dp(32)));TextView count=t(promoItems[n].size()+" items · View All ›",8,0xFF17234B,true);count.setGravity(Gravity.CENTER);card.addView(count,lp(-1,dp(16)));card.setOnClickListener(v->startActivity(new Intent(this,PhysicalStoreActivity.class).putExtra("folder",n+1)));if(SessionManager.isAdmin(this))card.setOnLongClickListener(v->{managePromo(n);return true;});promoTrack.addView(card,rowWidth(4,4,pos++,70));}}
    private void applyPromos(JSONObject data){JSONArray f=data.optJSONArray("featureButtons");if(f!=null)for(int k=0;k<f.length();k++){JSONObject x=f.optJSONObject(k);if(x==null)continue;for(int n=0;n<4;n++)if(("live2_promo_folder_"+(n+1)).equals(x.optString("key"))){promoNames[n]=x.optString("title",promoNames[n]);promoOrder[n]=x.optInt("display_order",n+1);promoEnabled[n]=x.optInt("active",1)==1;}}renderPromos();loadStorePromos();}
    private void loadStorePromos(){BackendClient.commerce("promos",null,SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject x){for(ArrayList<JSONObject> a:promoItems)a.clear();JSONArray items=x.optJSONArray("promos");if(items!=null)for(int i=0;i<items.length();i++){JSONObject p=items.optJSONObject(i);if(p!=null&&p.optInt("folder")>=1&&p.optInt("folder")<=4)promoItems[p.optInt("folder")-1].add(p);}renderPromos();}public void onError(String m){}});}
    private void legacyApplyPromos(JSONObject data){for(ArrayList<JSONObject> a:promoItems)a.clear();JSONArray b=data.optJSONArray("banners");if(b!=null)for(int k=0;k<b.length();k++){JSONObject x=b.optJSONObject(k);if(x==null||x.optInt("active",1)!=1)continue;for(int n=0;n<4;n++)if(("live2_promo_"+(n+1)).equals(x.optString("folder"))&&x.optInt("slot",0)>=1&&x.optInt("slot",0)<=20)promoItems[n].add(x);}for(ArrayList<JSONObject> a:promoItems)Collections.sort(a,(x,y)->Integer.compare(x.optInt("slot"),y.optInt("slot")));JSONArray f=data.optJSONArray("featureButtons");if(f!=null)for(int k=0;k<f.length();k++){JSONObject x=f.optJSONObject(k);if(x==null)continue;for(int n=0;n<4;n++)if(("live2_promo_folder_"+(n+1)).equals(x.optString("key"))){promoNames[n]=x.optString("title",promoNames[n]);promoOrder[n]=x.optInt("display_order",n+1);promoEnabled[n]=x.optInt("active",1)==1;}}renderPromos();}
    private void showPromoFolder(int index){if(promoItems[index].isEmpty()){if(SessionManager.isAdmin(this))managePromo(index);else Toast.makeText(this,"এই ফোল্ডারে এখন কোনো published offer নেই।",Toast.LENGTH_SHORT).show();return;}LinearLayout content=col();content.setPadding(dp(8),dp(8),dp(8),dp(8));LinearLayout track=row();for(JSONObject x:promoItems[index]){LinearLayout card=col();ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_CENTER);loadImage(image,x.optString("image_url",""),900);card.addView(image,lp(-1,dp(150)));TextView caption=t(x.optString("caption","Product offer"),13,0xFF17234B,true);caption.setMaxLines(2);card.addView(caption,lp(-1,dp(36)));TextView open=t("OPEN PRODUCT ›",12,BLUE,true);open.setGravity(Gravity.CENTER);card.addView(open,lp(-1,dp(44)));card.setOnClickListener(v->openTarget(x.optString("target_url","")));LinearLayout.LayoutParams q=lp(Math.max(dp(210),getResources().getDisplayMetrics().widthPixels-dp(90)),dp(236));q.rightMargin=dp(8);track.addView(card,q);}content.addView(horizontal(track,236));new MyShopDialogBuilder(this).setTitle(promoNames[index]+" · "+promoItems[index].size()+" / 6").setView(content).setNegativeButton("CLOSE",null).show();}
    private void openTarget(String target){if(FeatureRegistry.isSafeHttpUrl(target)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception e){Toast.makeText(this,"Product link could not open",Toast.LENGTH_SHORT).show();}}else Toast.makeText(this,"Admin has not added a product link yet",Toast.LENGTH_SHORT).show();}
    private void openBannerAdmin(String folder,String title){startActivity(new Intent(this,LiveHomeAdminActivity.class).putExtra("folder",folder).putExtra("folderTitle",title).putExtra("admin_context",true));}
    private void managePromo(int n){new MyShopDialogBuilder(this).setTitle(promoNames[n]+" • Admin").setItems(new String[]{"PRODUCTS / PRICES / FOUR OFFER SLOTS","FOLDER NAME / POSITION / VISIBILITY"},(d,w)->{if(w==0)startActivity(new Intent(this,PhysicalStoreActivity.class).putExtra("admin",true));else editPromoFolder(n);}).setNegativeButton("CLOSE",null).show();}
    private void legacyManagePromo(int n){new MyShopDialogBuilder(this).setTitle(promoNames[n]+" • Admin").setItems(new String[]{"ADD / EDIT UP TO 6 PRODUCT BANNERS","FOLDER NAME / POSITION / VISIBILITY"},(d,w)->{if(w==0)openBannerAdmin("live2_promo_"+(n+1),promoNames[n]);else editPromoFolder(n);}).setNegativeButton("CLOSE",null).show();}
    private void editPromoFolder(int n){LinearLayout form=col();form.setPadding(dp(16),0,dp(16),0);EditText name=new EditText(this);name.setText(promoNames[n]);name.setHint("Folder name");form.addView(name);EditText order=new EditText(this);order.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);order.setText(String.valueOf(promoOrder[n]));order.setHint("Position 1–4");form.addView(order);CheckBox enabled=new CheckBox(this);enabled.setText("Published");enabled.setChecked(promoEnabled[n]);form.addView(enabled);new MyShopDialogBuilder(this).setTitle("Folder Settings").setView(form).setPositiveButton("SAVE",(d,w)->{try{String title=name.getText().toString().trim();int slot=Integer.parseInt(order.getText().toString().trim());if(title.isEmpty()||slot<1||slot>4)throw new IllegalArgumentException();ArrayList<Integer> ids=new ArrayList<>();for(int i=0;i<4;i++)ids.add(i);Collections.sort(ids,(a,b)->Integer.compare(promoOrder[a],promoOrder[b]));ids.remove(Integer.valueOf(n));ids.add(slot-1,n);JSONArray all=new JSONArray();for(int i=0;i<ids.size();i++){int id=ids.get(i);all.put(new JSONObject().put("key","live2_promo_folder_"+(id+1)).put("title",id==n?title:promoNames[id]).put("active",id==n?enabled.isChecked():promoEnabled[id]).put("displayOrder",i+1));}BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("featureButtons",all),new BackendClient.Callback(){public void onSuccess(JSONObject x){loadPage2IconConfig();}public void onError(String m){Toast.makeText(LiveHomeActivity.this,m,Toast.LENGTH_LONG).show();}});}catch(Exception e){Toast.makeText(this,"Name and position 1–4 required",Toast.LENGTH_SHORT).show();}}).setNegativeButton("CANCEL",null).show();}
    private void renderLiveNow(){if(LiveDirectoryCard.touching636(this)){handler.postDelayed(()->{if(!liveHomeDestroyed)renderLiveNow();},400);return;}
        if(liveNowRow==null)return;
        liveNowRow.removeAllViews();
        if(liveNowData.isEmpty()){
            LinearLayout empty=col();empty.setGravity(Gravity.CENTER);empty.setPadding(dp(12),dp(18),dp(12),dp(18));
            empty.setBackground(gradient(new int[]{0xfff7f9ff,0xfffff4fb},16));
            TextView title=t(UiStrings.label(LiveHomeActivity.this,"No one is live right now"),11.5f,0xff17234b,true);title.setGravity(Gravity.CENTER);empty.addView(title,lp(-1,dp(28)));
            TextView sub=t(UiStrings.label(LiveHomeActivity.this,"Live rooms will appear here automatically when a host goes live."),8.8f,MUTED,false);sub.setGravity(Gravity.CENTER);empty.addView(sub,lp(-1,dp(34)));
            liveNowRow.addView(empty,top(lp(-1,dp(88)),6));
            return;
        }
        int shown=Math.min(12,liveNowData.size());
        for(int i=0;i<shown;i++){JSONObject x=liveNowData.get(i);liveNowRow.addView(new LiveDirectoryCard(this,x,()->joinRoom(x),i),lp(-1,Math.round(getResources().getDisplayMetrics().widthPixels*585f/1536f)));if(SessionManager.isAdmin(this)||SessionManager.isModerator(this)){Button close=new Button(this);close.setText("Close Live");close.setOnClickListener(v->new MyShopDialogBuilder(this).setTitle("Close Live?").setPositiveButton("Close Live",(d,w)->{close.setEnabled(false);BackendClient.staffClose625(SessionManager.getToken(this),x.optString("userId"),new BackendClient.Callback(){public void onSuccess(JSONObject result){runOnUiThread(()->loadLiveNow());}public void onError(String error){runOnUiThread(()->{close.setEnabled(true);Toast.makeText(LiveHomeActivity.this,error,Toast.LENGTH_LONG).show();});}});}).setNegativeButton(UiStrings.ui636("Cancel"),null).show());liveNowRow.addView(close,lp(-1,-2));}}
    }
    private View noLivePanel(String title,String subtitle,boolean primary){
        LinearLayout card=col();card.setGravity(Gravity.CENTER);card.setPadding(dp(12),dp(7),dp(12),dp(8));
        card.setBackground(gradient(primary?new int[]{0xffffe8f1,0xfff2e6ff}:new int[]{0xfff4edff,0xffe9f5ff},17));card.setElevation(dp(2));
        FrameLayout wrap=new FrameLayout(this);
        GradientDrawable glow=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.argb(primary?190:145,255,20,155),Color.argb(90,255,90,220),Color.TRANSPARENT});glow.setShape(GradientDrawable.OVAL);
        View halo=new View(this);halo.setBackground(glow);wrap.addView(halo,new FrameLayout.LayoutParams(dp(primary?78:66),dp(primary?78:66),Gravity.CENTER));
        ImageView icon=new ImageView(this);icon.setImageResource(R.drawable.nav_live);icon.setImageTintList(ColorStateList.valueOf(primary?Color.rgb(238,25,139):Color.rgb(245,44,154)));icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setPadding(dp(4),dp(4),dp(4),dp(4));wrap.addView(icon,new FrameLayout.LayoutParams(dp(primary?62:52),dp(primary?62:52),Gravity.CENTER));
        card.addView(wrap,lp(-1,dp(primary?70:58)));
        TextView titleView=t(title,primary?11.5f:10.8f,0xff17234b,true);titleView.setGravity(Gravity.CENTER);card.addView(titleView,lp(-1,dp(24)));
        TextView sub=t(subtitle,8.5f,MUTED,false);sub.setGravity(Gravity.CENTER);sub.setMaxLines(2);card.addView(sub,lp(-1,dp(primary?30:26)));
        LinearLayout start=row();start.setGravity(Gravity.CENTER);start.setBackground(PremiumUi.gradient(this,primary?new int[]{0xffff5b28,0xffff159f,0xff2d8cff}:new int[]{0xffff3b5e,0xffc53cff,0xff3c8cff},12,0xffffc7dd,1));
        ImageView cam=new ImageView(this);cam.setImageResource(R.drawable.ic_go_live_camera);cam.setScaleType(ImageView.ScaleType.CENTER_INSIDE);start.addView(cam,lp(dp(24),dp(24)));TextView go=t("Go Live  →",9.6f,Color.WHITE,true);go.setGravity(Gravity.CENTER_VERTICAL);start.addView(go,lp(-2,dp(34)));start.setOnClickListener(v->{Intent i=new Intent(this,AudioLiveRoomActivity.class);i.putExtra("hostMode",true);startActivity(i);});card.addView(start,top(lp(dp(primary?170:166),dp(36)),4));return card;
    }
    private View liveCard(JSONObject x){return new LiveDirectoryCard(this,x,()->joinRoom(x));}
    private int[] tierColors(String tier){if("KING".equals(tier)||"QUEEN".equals(tier))return new int[]{0xffff9f1a,0xffffd86a};if("VVIP".equals(tier))return new int[]{0xff8f3dff,0xffd46cff};if("VIP".equals(tier))return new int[]{0xffec3b91,0xffff78bd};return new int[]{0xff317bf4,0xff6c9dfc};}
    private void renderPeople(){if(peopleRow==null)return;peopleRow.removeAllViews();if(peopleData.isEmpty()){TextView empty=t("No one to suggest yet · Discover people ›",10,MUTED,true);empty.setGravity(Gravity.CENTER);empty.setOnClickListener(v->startActivity(new Intent(this,NewPeopleActivity.class)));peopleRow.addView(empty,lp(dp(metrics.widthDp),dp(76)));return;}for(int i=0;i<Math.min(12,peopleData.size());i++){JSONObject p=peopleData.get(i);LinearLayout card=col();card.setPadding(dp(3),dp(2),dp(3),dp(2));card.setGravity(Gravity.CENTER);FrameLayout photo=new FrameLayout(this);ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setBackground(round(Color.WHITE,Color.TRANSPARENT,30));av.setClipToOutline(true);loadImage(av,p.optString("avatarUrl",""),160);photo.addView(av,new FrameLayout.LayoutParams(dp(32),dp(32),Gravity.CENTER));if(p.optBoolean("online",false)){View dot=new View(this);dot.setBackground(round(0xFF19C978,Color.WHITE,10));FrameLayout.LayoutParams dl=new FrameLayout.LayoutParams(dp(9),dp(9),Gravity.BOTTOM|Gravity.RIGHT);dl.setMargins(0,0,dp(3),dp(2));photo.addView(dot,dl);}card.addView(photo,lp(-1,dp(34)));TextView name=t(shortName(p.optString("name","User")),8.2f,0xFF17234B,true);name.setGravity(Gravity.CENTER);name.setSingleLine(true);card.addView(name,lp(-1,dp(13)));TextView id=t(p.optBoolean("online",false)?"Active now":"ID "+p.optString("userId",""),7.2f,p.optBoolean("online",false)?0xFF15945B:MUTED,false);id.setGravity(Gravity.CENTER);card.addView(id,lp(-1,dp(12)));String state=p.optString("state","NONE");TextView add=t("FRIEND".equals(state)?"✓ Friends":"REQUESTED".equals(state)?"Requested":"+ Add Friend",7.2f,WHITE,true);add.setGravity(Gravity.CENTER);add.setBackground(gradient("FRIEND".equals(state)?new int[]{0xFF17B776,0xFF50D39B}:"REQUESTED".equals(state)?new int[]{0xFF8B95AA,0xFFADB4C2}:new int[]{0xFF4A78FF,0xFF9C42EC},8));add.setOnClickListener(v->{if(!"NONE".equals(p.optString("state","NONE")))return;v.setEnabled(false);BackendClient.sendFriendRequest(SessionManager.getToken(this),p.optString("userId",""),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{try{p.put("state","REQUESTED");}catch(Exception ignored){}add.setText("Requested");});}public void onError(String m){runOnUiThread(()->{v.setEnabled(true);Toast.makeText(LiveHomeActivity.this,m,Toast.LENGTH_SHORT).show();});}});});card.addView(add,lp(-1,dp(18)));card.setOnClickListener(v->startActivity(new Intent(this,UserProfileActivity.class).putExtra("userId",p.optString("userId",""))));peopleRow.addView(card,rowWidth(5,4,i%5,76));}}


    /** V-507: restored shared page-2 configuration loaders that were accidentally omitted. */
    private void loadPage2IconConfig(){
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                runOnUiThread(()->{
                    if(liveHomeDestroyed)return;UiStrings.cache(LiveHomeActivity.this,d.optJSONArray("translations"));
                    JSONArray links=d.optJSONArray("managedLinks");
                    discoverConfigs.clear();
                    if(links!=null){
                        for(int i=0;i<links.length();i++){
                            JSONObject x=links.optJSONObject(i);
                            if(x!=null && x.optString("category","").toLowerCase(Locale.US).startsWith("discover_")) discoverConfigs.add(x);
                        }
                    }
                    Collections.sort(discoverConfigs,(a,b)->Integer.compare(Math.max(1,a.optInt("display_order",999)),Math.max(1,b.optInt("display_order",999))));
                    JSONArray features=d.optJSONArray("featureButtons");
                    if(features!=null)applyPromos(d);
                    renderPremiumBar();
                });
            }
            public void onError(String m){ runOnUiThread(()->{ if(!liveHomeDestroyed)renderPremiumBar(); }); }
        });
    }

    /** V-507: safe realtime badge loader for notification and message counts. */
    private void loadHeaderCounts(){
        final String token=SessionManager.getToken(this);
        BackendClient.notifications(token,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                int count=d.optInt("unreadCount",d.optInt("unread_count",-1));
                if(count<0){
                    JSONArray a=d.optJSONArray("notifications"); count=0;
                    if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&!x.optBoolean("read",false)&&!x.optBoolean("isRead",false))count++;}
                }
                final int c=Math.max(0,count);runOnUiThread(()->{unreadNotificationCount=c;if(notificationBadge!=null){notificationBadge.setText(c>0?String.valueOf(Math.min(c,99)):"");notificationBadge.setVisibility(c>0?View.VISIBLE:View.GONE);}});
            }
            public void onError(String m){}
        });
        BackendClient.messageUnread(token,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                int count=d.optInt("unreadCount",d.optInt("unread_count",0));
                final int c=Math.max(0,count);runOnUiThread(()->{unreadMessageCount=c;if(messageBadge!=null){messageBadge.setText(c>0?String.valueOf(Math.min(c,99)):"");messageBadge.setVisibility(c>0?View.VISIBLE:View.GONE);}});
            }
            public void onError(String m){}
        });
    }

    private void loadPeople(){
        BackendClient.newPeople(SessionManager.getToken(this),20,0,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{peopleData.clear();JSONArray a=d.optJSONArray("people");if(a!=null)for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p!=null&&!SessionManager.getUserId(LiveHomeActivity.this).equals(p.optString("userId","")))peopleData.add(p);}renderPeople();});}public void onError(String m){runOnUiThread(()->renderPeople());}});
    }

    private boolean liveListInFlight=false;
    private void loadLiveNow(){
        if(liveListInFlight||liveHomeDestroyed)return;liveListInFlight=true;
        BackendClient.liveDiscover(SessionManager.getToken(this),"LIVE_NOW",100,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{liveListInFlight=false;if(liveHomeDestroyed)return;liveNowData.clear();JSONArray a=d.optJSONArray("rooms");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)liveNowData.add(x);}renderLiveNow();});}
            public void onError(String m){runOnUiThread(()->{liveListInFlight=false;if(!liveHomeDestroyed)renderLiveNow();});}
        });
    }

    private void loadWeeklyStars(){
        BackendClient.liveDiscover(SessionManager.getToken(this),"TRENDING",12,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{starData.clear();JSONArray a=d.optJSONArray("rooms");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)starData.add(x);}renderStars();renderLiveNow();});}public void onError(String m){runOnUiThread(()->{renderStars();renderLiveNow();});}});
    }

    private void renderStars(){if(starsRow==null)return;starsRow.removeAllViews();String[] roles={"👑 Top Host","♥ Most Loved","★ Rising Star"};int[][] colors={{0xFFFFBC34,0xFFFFE48A},{0xFFFF4AA5,0xFFFFAFE3},{0xFF297EFF,0xFF7BCDFF}};for(int i=0;i<3;i++){JSONObject x=i<starData.size()?starData.get(i):null;LinearLayout c=col();c.setPadding(dp(5),dp(3),dp(5),dp(3));c.setBackground(gradient(colors[i],11));TextView role=t(roles[i],8.5f,WHITE,true);role.setSingleLine(true);c.addView(role,lp(-1,dp(17)));TextView name=t(x==null?"No current entry":shortName(x.optString("name","Creator")),9,WHITE,true);name.setSingleLine(true);c.addView(name,lp(-1,dp(17)));TextView stat=t(x==null?"View community ›":"ID "+x.optString("userId","")+" · View Live ›",7.4f,WHITE,false);stat.setSingleLine(true);c.addView(stat,lp(-1,dp(16)));c.setOnClickListener(v->{if(x==null)openLiveCategory("TRENDING");else joinRoom(x);});starsRow.addView(c,rowWidth(3,4,i,58));}}


    private void openExplore(String type){Intent i=new Intent(this,LiveHomeExploreActivity.class);i.putExtra("section",type);startActivity(i);}
    private void openLiveCategory(String category){Intent i=new Intent(this,LiveListActivity.class);i.putExtra("category",category);startActivity(i);}

    private void addNav(LinearLayout parent,View child){ parent.addView(child,new LinearLayout.LayoutParams(0,dp(76),1)); }
    private View navItem(int iconRes,String label,boolean active,int color,View.OnClickListener click){String key=iconRes==R.drawable.nav_home?"home":iconRes==R.drawable.nav_store?"store":iconRes==R.drawable.nav_live?"live":iconRes==R.drawable.nav_support?"video":"profile";return SharedPageNav.item(this,iconRes,"store".equals(key)?"myshop":label,active,key,color,click);}

    private View bottomNav(){
        LinearLayout nav=row();nav.setClipChildren(false);nav.setClipToPadding(false);nav.setPadding(dp(4),dp(2),dp(4),dp(1));nav.setBackgroundColor(Color.WHITE);nav.setElevation(dp(7));addNav(nav,navItem(R.drawable.nav_home,"Home",false,Color.rgb(20,112,247),v->{Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);finish();}));addNav(nav,navItem(R.drawable.nav_store,"My Shop",false,Color.rgb(255,154,25),v->startActivity(new Intent(this,PhysicalStoreActivity.class))));addNav(nav,navItem(R.drawable.nav_live,"Go Live",true,Color.rgb(255,23,89),v->{Intent i=new Intent(this,AudioLiveRoomActivity.class);i.putExtra("hostMode",true);startActivity(i);}));addNav(nav,navItem(R.drawable.nav_support,"Video",false,0xff101934,v->startActivity(new Intent(this,ShortVideoActivity.class))));addNav(nav,navItem(R.drawable.nav_more540,"Profile",false,0xff101934,v->startActivity(new Intent(this,UserMenuActivity.class).putExtra("profile_context",true))));return nav;
    }
    private LinearLayout sectionHeader(String title,String subtitle,Runnable all){LinearLayout h=row();LinearLayout copy=col();copy.addView(t(title,15.5f,WHITE,true),lp(-1,dp(26)));copy.addView(t(subtitle,8.4f,MUTED,false),lp(-1,dp(18)));h.addView(copy,wt(1,dp(46)));if(all!=null){TextView see=t("See All  ›",10,CYAN,true);see.setGravity(Gravity.CENTER);see.setBackground(round(Color.argb(70,29,100,170),Color.argb(160,55,202,255),14));PremiumUi.press(see);see.setOnClickListener(v->all.run());h.addView(see,lp(dp(88),dp(38)));}return h;}
    private TextView action(String s,int[] colors){TextView v=t(s,10.5f,WHITE,true);v.setGravity(Gravity.CENTER);v.setLines(2);v.setPadding(dp(8),0,dp(8),0);v.setLetterSpacing(.012f);PremiumUi.premiumButton(v,colors,20,Color.argb(165,255,255,255),7);return v;}

    private void loadBanners(){if(bannerLoadInFlight)return;bannerLoadInFlight=true;BackendClient.liveHomeBanners(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){ArrayList<JSONObject> active=parseBannerPayload(d,true);boolean enabled=d.optBoolean("sectionEnabled",true);runOnUiThread(()->{if(liveHomeDestroyed)return;bannerLoadInFlight=false;bannerSectionEnabled=enabled;getSharedPreferences(BANNER_CACHE_PREFS,MODE_PRIVATE).edit().putBoolean(BANNER_SECTION_KEY,enabled).apply();bannerData.clear();bannerData.addAll(active);cacheCurrentBanners();renderBanners(true);});}public void onError(String m){runOnUiThread(()->{bannerLoadInFlight=false;if(!liveHomeDestroyed)renderBanners(false);});}});}


    private ArrayList<JSONObject> parseBannerPayload(JSONObject d,boolean mixedFolders){
        java.util.LinkedHashMap<Integer,JSONObject> slots=new java.util.LinkedHashMap<>();JSONArray a=d==null?null:d.optJSONArray("banners");
        if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;if(!"live_home".equalsIgnoreCase(x.optString("folder","")))continue;int sl=x.optInt("slot",0);String url=x.optString("image_url","").trim();if(sl>=1&&sl<=20&&!url.isEmpty()&&x.optInt("active",1)==1)slots.put(sl,x);}
        ArrayList<JSONObject> tmp=new ArrayList<>(slots.values());Collections.sort(tmp,Comparator.comparingInt(x->x.optInt("slot",99)));return tmp;
    }
    private void restoreBannerCache(){
        try{String raw=getSharedPreferences(BANNER_CACHE_PREFS,MODE_PRIVATE).getString(BANNER_CACHE_KEY,"");if(raw==null||raw.trim().isEmpty())return;JSONArray a=new JSONArray(raw);ArrayList<JSONObject> cached=new ArrayList<>();for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;int sl=x.optInt("slot",0);String url=x.optString("image_url","").trim();if(sl>=1&&sl<=20&&!url.isEmpty())cached.add(x);}Collections.sort(cached,Comparator.comparingInt(x->x.optInt("slot",99)));if(!cached.isEmpty()){bannerData.clear();bannerData.addAll(cached);renderBanners(true);}}catch(Exception ignored){}
    }
    private void cacheCurrentBanners(){
        try{JSONArray a=new JSONArray();for(JSONObject x:bannerData){if(x!=null&&!x.optBoolean("fallback",false)&&!x.optString("image_url","").trim().isEmpty())a.put(new JSONObject(x.toString()));}getSharedPreferences(BANNER_CACHE_PREFS,MODE_PRIVATE).edit().putString(BANNER_CACHE_KEY,a.toString()).apply();}catch(Exception ignored){}
    }
    private void renderBanners(){renderBanners(false);}
    private void renderBanners(boolean quickStart){
        handler.removeCallbacks(bannerTick);bannerIndex=0;
        if(!bannerSectionEnabled){if(bannerHero!=null)bannerHero.setVisibility(View.GONE);if(bannerDots!=null)bannerDots.setVisibility(View.GONE);if(bannerCounter!=null)bannerCounter.setVisibility(View.GONE);if(bannerCarousel!=null)bannerCarousel.setData(0,0,(v,i)->{});return;}
        if(bannerHero!=null)bannerHero.setVisibility(View.VISIBLE);if(bannerDots!=null)bannerDots.setVisibility(View.VISIBLE);if(bannerCounter!=null)bannerCounter.setVisibility(View.VISIBLE);
        if(bannerData.isEmpty()){
            if(bannerHero!=null){android.view.ViewGroup.LayoutParams p=bannerHero.getLayoutParams();p.height=SessionManager.isAdmin(this)?dp(44):0;bannerHero.setLayoutParams(p);}
            if(bannerCarousel!=null)bannerCarousel.setData(0,0,(v,i)->{});
            if(bannerEmpty!=null)bannerEmpty.setVisibility(View.VISIBLE);
            bannerCounter.setText("0/6");bannerDots.setText("");return;
        }
        if(bannerHero!=null){android.view.ViewGroup.LayoutParams p=bannerHero.getLayoutParams();p.height=Math.round(getResources().getDisplayMetrics().widthPixels*.84f*5f/12f);bannerHero.setLayoutParams(p);}
        if(bannerEmpty!=null)bannerEmpty.setVisibility(View.GONE);
        if(bannerCarousel!=null)bannerCarousel.setData(bannerData.size(),bannerIndex,(view,index)->bindBannerFrame(view,index));
        updateBannerIndicators();scheduleBanner(quickStart);
    }
    private void bindBannerFrame(ImageView target,int dataIndex){
        if(target==null)return;
        if(dataIndex<0||dataIndex>=bannerData.size())return;
        String url=bannerData.get(dataIndex).optString("image_url","").trim();
        BannerImages.load(target,url);
    }
    private void showBanner(int next,boolean forward){showBannerInternal(next,forward);scheduleBanner(false);}
    private void showBannerInternal(int next,boolean forward){
        if(bannerData.size()<=1){bannerIndex=0;updateBannerIndicators();return;}
        next=(next+bannerData.size())%bannerData.size();if(next==bannerIndex)return;
        if(bannerCarousel!=null){bannerCarousel.animateTo(next,forward);}else{bannerIndex=next;updateBannerIndicators();}
    }
    private void updateBannerIndicators(){int n=bannerData.size();if(n<=0){bannerDots.setText("");bannerCounter.setText("0/6");return;}StringBuilder d=new StringBuilder();for(int i=0;i<n;i++){d.append(i==bannerIndex?"●":"○");if(i<n-1)d.append("   ");}bannerDots.setText(d.toString());bannerCounter.setText((bannerIndex+1)+"/"+n);}
    private void scheduleBanner(boolean quickStart){handler.removeCallbacks(bannerTick);if(liveHomeVisible&&!liveHomeDestroyed&&bannerSectionEnabled&&bannerData.size()>1)handler.postDelayed(bannerTick,quickStart?BANNER_FIRST_TICK_MS:currentBannerIntervalMs());}
    private long currentBannerIntervalMs(){if(bannerData.isEmpty())return BANNER_INTERVAL_MS;int seconds=Math.max(1,Math.min(30,bannerData.get(Math.min(bannerIndex,bannerData.size()-1)).optInt("display_seconds",4)));return seconds*1000L;}
    private void openCurrentBannerTarget(){if(SessionManager.isAdmin(this)){openBannerAdmin("live_home","Main Advertising Banners");return;}if(bannerData.isEmpty())return;String target=bannerData.get(Math.min(bannerIndex,bannerData.size()-1)).optString("target_url",bannerData.get(Math.min(bannerIndex,bannerData.size()-1)).optString("targetUrl","")).trim();if(FeatureRegistry.isSafeHttpUrl(target)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception ignored){}}}

    private void openList(){Intent i=new Intent(this,LiveListActivity.class);i.putExtra("category","LIVE_NOW");startActivity(i);}
    private void joinRoom(JSONObject x){String uid=x.optString("userId","");if(uid.isEmpty())return;WatchHistoryActivity.record(this,"LIVE",x.optString("profileName",x.optString("name","myshop Live")),x.optString("topic",x.optString("title","Live session")),"live:"+uid,x.optString("avatarUrl",""),"Watch Live");Intent i=new Intent(this,AudioLiveRoomActivity.class);i.putExtra("hostMode",false);i.putExtra("hostId",uid);i.putExtra("hostName",x.optString("name","myshop User"));startActivity(i);}

    @Override protected void onResume(){super.onResume();if(renderedLanguage!=null&&!renderedLanguage.equals(LanguageManager.get(this))){recreate();return;}renderedLanguage=LanguageManager.get(this);if(upcomingCarousel!=null)upcomingCarousel.resume();liveHomeVisible=true;if(firstLiveResume)firstLiveResume=false;else{loadBanners();loadPage2IconConfig();}loadLiveNow();loadHeaderCounts();scheduleBanner(true);handler.removeCallbacks(liveRefreshTick);directoryWatch621.start();}
    @Override protected void onPause(){if(upcomingCarousel!=null)upcomingCarousel.pause();liveHomeVisible=false;directoryWatch621.stop();handler.removeCallbacks(bannerTick);handler.removeCallbacks(liveRefreshTick);super.onPause();}
    @Override protected void onDestroy(){if(upcomingCarousel!=null)upcomingCarousel.destroy();liveHomeDestroyed=true;liveHomeVisible=false;handler.removeCallbacksAndMessages(null);imageIo.shutdownNow();super.onDestroy();}

    /**
     * Crash guard for remote Live Home artwork. V-355 could decode up to six large R2
     * banners at full resolution at once. A single 4K/8K image can expand to tens of MB
     * in memory; concurrent full-size decodes could terminate the app with OOM.
     * Decode bounds first, sample to the actual UI need, use RGB_565, cap concurrency,
     * and treat OOM as a failed image rather than a process crash.
     */
    private void loadImage(ImageView target,String rawUrl,int maxPx){
        if(rawUrl==null||rawUrl.trim().isEmpty())return;
        final String url=rawUrl.trim();
        target.setTag(url);
        if(liveHomeDestroyed||imageIo.isShutdown()||imageIo.isTerminated())return;
        try{imageIo.execute(()->{
            Bitmap bitmap=null;
            try{
                BitmapFactory.Options bounds=new BitmapFactory.Options();
                bounds.inJustDecodeBounds=true;
                decodeRemote(url,bounds);
                if(bounds.outWidth<=0||bounds.outHeight<=0)return;

                int sample=1;
                int largest=Math.max(bounds.outWidth,bounds.outHeight);
                while(largest/sample>Math.max(160,maxPx))sample*=2;

                BitmapFactory.Options opts=new BitmapFactory.Options();
                opts.inSampleSize=Math.max(1,sample);
                opts.inPreferredConfig=Bitmap.Config.RGB_565;
                opts.inDither=true;
                bitmap=decodeRemote(url,opts);
            }catch(OutOfMemoryError oom){
                bitmap=null;
                System.gc();
            }catch(Exception ignored){
                bitmap=null;
            }
            final Bitmap safe=bitmap;
            if(safe!=null&&!liveHomeDestroyed&&!isFinishing()&&!isDestroyed())runOnUiThread(()->{
                if(!liveHomeDestroyed&&!isFinishing()&&!isDestroyed()&&url.equals(target.getTag()))target.setImageBitmap(safe);
            });
        });}catch(java.util.concurrent.RejectedExecutionException ignored){}
    }

    private Bitmap decodeRemote(String url,BitmapFactory.Options opts) throws Exception{
        HttpURLConnection c=null;
        try{
            c=(HttpURLConnection)new URL(url).openConnection();
            c.setConnectTimeout(5000);
            c.setReadTimeout(7000);
            c.setInstanceFollowRedirects(true);
            c.setUseCaches(true);
            c.setRequestProperty("User-Agent","MY-SHOP/2.9.524");
            int code=c.getResponseCode();
            if(code<200||code>=300)throw new java.io.IOException("HTTP "+code);
            try(InputStream in=c.getInputStream()){return BitmapFactory.decodeStream(in,null,opts);}
        }finally{if(c!=null)c.disconnect();}
    }
    private String shortName(String n){if(n==null||n.trim().isEmpty())return "User";n=n.trim();return n.length()>12?n.substring(0,12):n;}
    private String compact(long n){if(n>=1000000)return String.format(java.util.Locale.US,"%.1fM",n/1000000f);if(n>=1000)return String.format(java.util.Locale.US,"%.1fK",n/1000f);return String.valueOf(n);}
    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private TextView t(String s,float z,int c,boolean bold){TextView v=new TextView(this);v.setText(DisplayIds611.format(s));v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    private GradientDrawable gradient(int[] colors,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(radius));return g;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);} private LinearLayout.LayoutParams wt(float w,int h){return new LinearLayout.LayoutParams(0,h,w);} private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;} private int dp(float x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
}
