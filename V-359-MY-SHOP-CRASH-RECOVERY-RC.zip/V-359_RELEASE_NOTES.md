# MY SHOP V-359 — Crash Recovery / Dashboard Memory Hardening

Android: `versionCode 359` / `versionName 2.9.359`  
Source identity: `MY SHOP V-359`

## Scoped fix
- Rebased on the V-358 recovery source without redesigning or removing existing working features.
- Hardened Dashboard remote-image loading against memory exhaustion from oversized banners/avatars/media.
- Remote Dashboard images are now bounded by encoded-size guard, decoded with sampling, and use a lower-memory bitmap format for display.
- Reduced concurrent Dashboard bitmap decode workers from 3 to 2 to lower peak RAM pressure.
- Added explicit `OutOfMemoryError` fallback for Dashboard remote-image decode.
- Prevented late image callbacks from updating a destroyed/finishing Activity.
- Dashboard bitmap cache is released on Activity destruction.

## Preserved / not changed
Live, Gift, Coin/Gold Coin, Profile, Admin controls, backend contracts, navigation, Google Play safeguards, and other existing business logic were not intentionally redesigned or removed.

## Runtime note
This change directly mitigates the strongest source-level crash candidate found from the supplied V-358 source and recording. Real-device runtime testing remains required because a screen recording alone cannot provide an Android `FATAL EXCEPTION` stack trace.
