# MY SHOP Developer Handoff — V-358

## Version
- SOURCE_BUILD_ID: MY SHOP V-358
- Android versionCode: 358
- Android versionName: 2.9.358

## Completed
- Restored supplied V-355 source as the recovery/golden baseline after V-356 runtime-close report.
- Preserved all V-355 functional source files and backend contracts.
- Updated release identity only to V-358.

## Pending / Required QA
- Build APK/AAB in the normal Android build environment.
- Install on the affected device and verify cold start, dashboard, Live Home, Live Room, navigation, background/foreground resume.
- If any close/crash remains, capture the FATAL EXCEPTION/logcat and repair only the exact failing component.
- Complete normal Google Play compliance/release checks before production upload.

## Regression lock
Do not redesign or alter working Live, Gift, Coin/Gold Coin, profile, dashboard, admin, backend, D1/R2, or navigation modules while diagnosing the crash.

---
## V-359 Crash Recovery Update
- Source/build identity: MY SHOP V-359 / Android 2.9.359 (versionCode 359).
- Target: Dashboard runtime crash candidate caused by unbounded remote bitmap decoding.
- Change: bounded/sampled Dashboard image decoding, lower concurrent decode pressure, OOM-safe fallback, lifecycle-safe callbacks, cache cleanup.
- Locked/unaffected: Live, Gifts, Coin/Gold Coin, Profile, Admin controls, backend/data contracts and established navigation.
- Next checkpoint: build with permanent GitHub workflow and run real-device Dashboard soak test. If any crash persists, collect Android FATAL EXCEPTION/logcat before broader edits.
