import agoraRtcTokenPkg from 'agora-token/src/RtcTokenBuilder2.js';
const { RtcTokenBuilder: AgoraRtcTokenBuilder, Role: AgoraRtcRole } = agoraRtcTokenPkg;
const json = (data, status = 200, extra = {}) => new Response(JSON.stringify(data), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", ...extra }
});

// V-311 Live comments are strictly ephemeral. They live only in Worker isolate memory
// for the active room/session and are never written to D1 or R2.
const liveEphemeralComments = new Map();
const liveEphemeralHighlights = new Map();
let liveEphemeralSeq = 1;
function liveEphemeralKey(hostId,sessionId){ return `${hostId}:${sessionId}`; }
function liveEphemeralPrune(map,key,maxItems=80,maxAgeMs=60*60*1000){
  const now=Date.now(), src=Array.isArray(map.get(key))?map.get(key):[];
  const kept=src.filter(x=>now-Number(x._ts||0)<=maxAgeMs).slice(-maxItems);
  if(kept.length) map.set(key,kept); else map.delete(key);
  return kept;
}
function liveEphemeralPush(map,key,item,maxItems=80,maxAgeMs=60*60*1000){
  const a=liveEphemeralPrune(map,key,maxItems,maxAgeMs); a.push(item);
  while(a.length>maxItems)a.shift(); map.set(key,a); return item;
}
function liveEphemeralClear(hostId,sessionId){
  const key=liveEphemeralKey(hostId,sessionId); liveEphemeralComments.delete(key); liveEphemeralHighlights.delete(key);
}


// V-352: one Durable Object per host keeps active-room realtime events coherent
// across Worker isolates without writing Live comments to D1/R2.
function liveHubStub(env,hostId){
  if(!env?.LIVE_ROOM_HUB||!isFourDigit(hostId))return null;
  const id=env.LIVE_ROOM_HUB.idFromName(String(hostId));
  return env.LIVE_ROOM_HUB.get(id);
}
function bearerRaw(request){
  const auth=String(request.headers.get('authorization')||'');
  return auth.toLowerCase().startsWith('bearer ')?auth.slice(7).trim():'';
}
async function liveHubRegister(request,env,hostId,sessionId,userId){
  const stub=liveHubStub(env,hostId),raw=bearerRaw(request);
  if(!stub||!raw||!sessionId)return null;
  const tokenHash=await sha256(raw);
  const r=await stub.fetch('https://live-hub/register',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({sessionId:String(sessionId),userId:String(userId),tokenHash,expiresAt:Date.now()+30000})});
  return r.ok?await r.json():null;
}
async function liveHubPush(env,hostId,sessionId,kind,payload){
  const stub=liveHubStub(env,hostId);if(!stub||!sessionId)return null;
  const r=await stub.fetch('https://live-hub/push',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({sessionId:String(sessionId),kind:String(kind||'DIRTY'),payload:payload||{}})});
  return r.ok?await r.json():null;
}
async function liveHubDirty(env,hostId,sessionId,reason='STATE'){
  try{return await liveHubPush(env,hostId,sessionId,'DIRTY',{reason:String(reason||'STATE')});}catch(e){return null;}
}
async function liveHubDirtyForHost(env,hostId,reason='STATE'){
  try{
    const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();
    const sessionId=String(meta?.session_id||'');
    if(sessionId)return await liveHubDirty(env,hostId,sessionId,reason);
  }catch(e){}
  return null;
}
async function liveHubClear(env,hostId,sessionId){
  const stub=liveHubStub(env,hostId);if(!stub)return null;
  try{const r=await stub.fetch('https://live-hub/clear',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({sessionId:String(sessionId||'')})});return r.ok;}catch(e){return false;}
}
async function liveRealtime(request,env){
  const u=new URL(request.url),hostId=String(u.searchParams.get('hostId')||'').trim(),sessionId=String(u.searchParams.get('sessionId')||'').trim();
  const afterComment=Math.max(0,Math.floor(Number(u.searchParams.get('afterComment')||0))),afterHighlight=Math.max(0,Math.floor(Number(u.searchParams.get('afterHighlight')||0))),afterGift=Math.max(0,Math.floor(Number(u.searchParams.get('afterGift')||0))),knownRevision=Math.max(0,Math.floor(Number(u.searchParams.get('revision')||0)));
  if(!isFourDigit(hostId)||!sessionId)return json({error:'INVALID_REALTIME_ROOM'},400,cors);
  const raw=bearerRaw(request);if(!raw)return json({error:'UNAUTHORIZED'},401,cors);
  const stub=liveHubStub(env,hostId);if(!stub)return json({error:'REALTIME_HUB_NOT_CONFIGURED'},503,cors);
  const tokenHash=await sha256(raw);
  const q=new URL('https://live-hub/events');q.searchParams.set('sessionId',sessionId);q.searchParams.set('tokenHash',tokenHash);q.searchParams.set('afterComment',String(afterComment));q.searchParams.set('afterHighlight',String(afterHighlight));q.searchParams.set('afterGift',String(afterGift));q.searchParams.set('revision',String(knownRevision));
  const r=await stub.fetch(q.toString());let data={};try{data=await r.json();}catch(e){data={error:'REALTIME_HUB_ERROR'};}
  return json(data,r.status,cors);
}

const cors = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET,POST,PUT,DELETE,OPTIONS",
  "access-control-allow-headers": "Content-Type, Authorization, X-MYSHOP-HEALTH-KEY"
};

function normalizeEmail(v) { return String(v || '').trim().toLowerCase(); }
function normalizeMobile(v) { return String(v || '').trim().replace(/[\s()-]/g, ''); }
function normalizeAnswer(v) { return String(v || '').trim().toLowerCase(); }
function isFourDigit(v) { return /^\d{4}$/.test(String(v || '')); }

function bytesToHex(bytes) { return [...new Uint8Array(bytes)].map(b => b.toString(16).padStart(2,'0')).join(''); }
function hexToBytes(hex) { const out = new Uint8Array(hex.length / 2); for (let i=0;i<out.length;i++) out[i]=parseInt(hex.slice(i*2,i*2+2),16); return out; }

async function sha256(text) {
  return bytesToHex(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)));
}

// V-297: compare owner identifiers by hash only. Raw recovery/admin identifiers are not embedded.
async function ownerAdminIdForIdentifier(value) {
  const v=String(value||'').trim().toLowerCase(); if(!v)return '';
  const h=await sha256(v);
  const map={
    '2488f46e89a2ff3d2e5ea9f43ee610d8c74135f931692269d077a73551f8495d':'0001',
    '6d8859a91a72a6ab10acda29c21709493fe5f0f3efcee83e480a609f9abf8969':'0002',
    'b2d53ac69843f7f30f81a770adc18107f230317670eaa701d3135e53731e6b28':'0003'
  };
  return map[h]||'';
}

const PBKDF2_ITERATIONS = 100000;

async function pbkdf2(password, saltHex, iterations = PBKDF2_ITERATIONS) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({name:'PBKDF2', salt:hexToBytes(saltHex), iterations, hash:'SHA-256'}, key, 256);
  return bytesToHex(bits);
}

function randomHex(bytes = 16) {
  const a = new Uint8Array(bytes); crypto.getRandomValues(a); return bytesToHex(a);
}

function guessContentType(file) {
  const raw=String(file?.type||'').toLowerCase().trim();
  if(raw) return raw;
  const name=String(file?.name||'').toLowerCase();
  const ext=name.includes('.')?name.split('.').pop():'';
  const map={jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webp:'image/webp',gif:'image/gif',bmp:'image/bmp',heic:'image/heic',heif:'image/heif',mp3:'audio/mpeg',wav:'audio/wav',m4a:'audio/mp4',aac:'audio/aac',ogg:'audio/ogg',mp4:'video/mp4',webm:'video/webm',mov:'video/quicktime',mkv:'video/x-matroska'};
  return map[ext]||'application/octet-stream';
}

async function hashPassword(password) {
  const salt = randomHex(16);
  const iterations = PBKDF2_ITERATIONS;
  const digest = await pbkdf2(password, salt, iterations);
  return `pbkdf2_sha256$${iterations}$${salt}$${digest}`;
}

async function verifyPassword(password, stored) {
  const p = String(stored || '').split('$');
  if (p.length !== 4 || p[0] !== 'pbkdf2_sha256') return false;
  const digest = await pbkdf2(password, p[2], Number(p[1]));
  return digest === p[3];
}

async function ensureAuthSchema(env) {
  // Additive-only and fault-tolerant. Existing user/auth data is never dropped or cleared.
  const statements = [
    `CREATE TABLE IF NOT EXISTS myshop_auth_users_v108 (user_id TEXT PRIMARY KEY CHECK(length(user_id)=4),full_name TEXT NOT NULL,email TEXT UNIQUE,mobile TEXT UNIQUE,password_hash TEXT NOT NULL,security_q1 TEXT NOT NULL,security_a1_hash TEXT NOT NULL,security_q2 TEXT NOT NULL,security_a2_hash TEXT NOT NULL,security_q3 TEXT NOT NULL,security_a3_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'USER' CHECK(role IN ('USER','ADMIN','MODERATOR')),active INTEGER NOT NULL DEFAULT 1,avatar_url TEXT NOT NULL DEFAULT '',avatar_object_key TEXT NOT NULL DEFAULT '',cover_url TEXT NOT NULL DEFAULT '',cover_object_key TEXT NOT NULL DEFAULT '',bio TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_myshop_auth_email ON myshop_auth_users_v108(email) WHERE email IS NOT NULL AND email <> ''`,
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_myshop_auth_mobile ON myshop_auth_users_v108(mobile) WHERE mobile IS NOT NULL AND mobile <> ''`,
    `CREATE TABLE IF NOT EXISTS myshop_auth_sessions_v108 (token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id) ON DELETE CASCADE,expires_at INTEGER NOT NULL,created_at INTEGER NOT NULL)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_auth_sessions_v108_user ON myshop_auth_sessions_v108(user_id)`,
    `CREATE TABLE IF NOT EXISTS myshop_moderators_v108 (user_id TEXT PRIMARY KEY REFERENCES myshop_auth_users_v108(user_id) ON DELETE CASCADE,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`
  ];
  for (const sql of statements) { try { await env.DB.prepare(sql).run(); } catch (_) {} }
  // Additive migration for databases created by an older MY SHOP release.
  // Never drop/recreate the auth table: existing IDs, users and sessions stay intact.
  try {
    const cols = (await env.DB.prepare(`PRAGMA table_info(myshop_auth_users_v108)`).all()).results || [];
    const names = new Set(cols.map(x => String(x.name || '')));
    if (!names.has('avatar_url')) await env.DB.prepare(`ALTER TABLE myshop_auth_users_v108 ADD COLUMN avatar_url TEXT NOT NULL DEFAULT ''`).run();
    if (!names.has('avatar_object_key')) await env.DB.prepare(`ALTER TABLE myshop_auth_users_v108 ADD COLUMN avatar_object_key TEXT NOT NULL DEFAULT ''`).run();
    if (!names.has('cover_url')) await env.DB.prepare(`ALTER TABLE myshop_auth_users_v108 ADD COLUMN cover_url TEXT NOT NULL DEFAULT ''`).run();
    if (!names.has('cover_object_key')) await env.DB.prepare(`ALTER TABLE myshop_auth_users_v108 ADD COLUMN cover_object_key TEXT NOT NULL DEFAULT ''`).run();
    if (!names.has('bio')) await env.DB.prepare(`ALTER TABLE myshop_auth_users_v108 ADD COLUMN bio TEXT NOT NULL DEFAULT ''`).run();
    if (!names.has('gender')) await env.DB.prepare(`ALTER TABLE myshop_auth_users_v108 ADD COLUMN gender TEXT NOT NULL DEFAULT 'UNSPECIFIED'`).run();
  } catch (_) {}
  try { await migratePreviousAuthIfPresent(env); } catch (_) {}
}

async function migratePreviousAuthIfPresent(env) {
  // V-107 may have created the old auth table before a deployment failed.
  // Copy compatible rows forward; never delete or modify the old table.
  try {
    await env.DB.prepare(`INSERT OR IGNORE INTO myshop_auth_users_v108
      (user_id,full_name,email,mobile,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role,active,created_at,updated_at)
      SELECT user_id,full_name,email,mobile,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role,active,created_at,updated_at
      FROM myshop_auth_users`).run();
  } catch (_) {
    // Old table may not exist or may have an incompatible schema. Leave it untouched.
  }
}

async function createSession(env, userId) {
  const raw = `${crypto.randomUUID()}-${randomHex(16)}`;
  const hash = await sha256(raw);
  const days = Math.max(1, Number(env.SESSION_DAYS || 30));
  const expires = Date.now() + days * 86400000;
  await env.DB.prepare('INSERT INTO myshop_auth_sessions_v108(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)')
    .bind(hash, userId, expires, Date.now()).run();
  return raw;
}

async function getUser(request, env) {
  const auth = request.headers.get('authorization') || '';
  if (!auth.toLowerCase().startsWith('bearer ')) return null;
  const raw = auth.slice(7).trim();
  if (!raw) return null;
  const hash = await sha256(raw);
  const row = await env.DB.prepare(`SELECT u.* FROM myshop_auth_sessions_v108 s JOIN myshop_auth_users_v108 u ON u.user_id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.active=1`).bind(hash, Date.now()).first();
  return row || null;
}

function publicUser(u) {
  return { userId:u.user_id, name:u.full_name, email:u.email || '', mobile:u.mobile || '', role:u.role, avatarUrl:u.avatar_url || '', coverUrl:u.cover_url || '', bio:u.bio || '', gender:u.gender || 'UNSPECIFIED' };
}

async function body(request) {
  try { return await request.json(); } catch { return {}; }
}

async function findAuthUser(env, identifier) {
  const id = String(identifier || '').trim();
  let user = null;
  if (isFourDigit(id)) user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(id).first();
  if (!user && id.includes('@')) user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE email=? AND active=1').bind(normalizeEmail(id)).first();
  if (!user) user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE mobile=? AND active=1').bind(normalizeMobile(id)).first();
  return user;
}

async function register(request, env) {
  const b = await body(request);
  const name = String(b.name || '').trim();
  const email = normalizeEmail(b.email);
  const mobile = normalizeMobile(b.mobile);
  const password = String(b.password || '');
  const securityQuestion = String(b.securityQuestion || (Array.isArray(b.securityQuestions) ? b.securityQuestions[0] : '') || '').trim();
  const securityAnswer = String(b.securityAnswer || (Array.isArray(b.securityAnswers) ? b.securityAnswers[0] : '') || '').trim();
  if (!name || (!email && !mobile) || password.length < 6 || !securityQuestion || !securityAnswer) return json({error:'INVALID_INPUT'},400,cors);
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({error:'INVALID_EMAIL'},400,cors);

  const duplicate = await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE (?<>'' AND email=?) OR (?<>'' AND mobile=?) LIMIT 1`)
    .bind(email,email,mobile,mobile).first();
  if (duplicate) return json({error:'ACCOUNT_EXISTS'},409,cors);

  // Keep legacy users untouched, but block duplicate identifiers that already exist there.
  try {
    const legacy = await env.DB.prepare(`SELECT id FROM users WHERE (?<>'' AND lower(email)=?) OR (?<>'' AND mobile=?) LIMIT 1`)
      .bind(email,email,mobile,mobile).first();
    if (legacy) return json({error:'ACCOUNT_EXISTS'},409,cors);
  } catch (_) { /* legacy table may not exist on a fresh database */ }

  const adminId = await ownerAdminIdForIdentifier(email || mobile);
  const role = adminId ? 'ADMIN' : 'USER';
  let userId = adminId;
  if (!userId) {
    const next = await env.DB.prepare(`SELECT COALESCE(MAX(CAST(user_id AS INTEGER))+1,100) AS n FROM myshop_auth_users_v108 WHERE CAST(user_id AS INTEGER) >= 100`).first();
    const n = Number(next?.n || 100);
    if (n > 9999) return json({error:'NO_ID_AVAILABLE'},409,cors);
    userId = String(n).padStart(4,'0');
  } else {
    const occupied = await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=?').bind(userId).first();
    if (occupied) return json({error:'ACCOUNT_EXISTS'},409,cors);
  }

  const ph = await hashPassword(password);
  const answerHash = await sha256(normalizeAnswer(securityAnswer));
  // Keep the existing 3-question columns for backward compatibility. New accounts use only q1/a1.
  await env.DB.prepare(`INSERT INTO myshop_auth_users_v108(user_id,full_name,email,mobile,password_hash,security_q1,security_a1_hash,security_q2,security_a2_hash,security_q3,security_a3_hash,role)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).bind(userId,name,email||null,mobile||null,ph,securityQuestion,answerHash,'','', '','',role).run();

  const user = await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=?').bind(userId).first();
  const token = await createSession(env, userId);
  return json({ok:true,user:publicUser(user),token},201,cors);
}

async function login(request, env) {
  const b = await body(request);
  const id = String(b.identifier || '').trim();
  const password = String(b.password || '');
  if (!id || !password) return json({error:'INVALID_INPUT'},400,cors);
  const user = await findAuthUser(env,id);
  if (!user || !(await verifyPassword(password,user.password_hash))) return json({error:'INVALID_CREDENTIALS'},401,cors);
  const mappedAdminId = (await ownerAdminIdForIdentifier(normalizeEmail(id) || normalizeMobile(id))) || (isFourDigit(id) && ['0001','0002','0003'].includes(id) ? id : '');
  if (mappedAdminId && user.user_id === mappedAdminId && user.role !== 'ADMIN') {
    await env.DB.prepare("UPDATE myshop_auth_users_v108 SET role='ADMIN', updated_at=CURRENT_TIMESTAMP WHERE user_id=?").bind(mappedAdminId).run();
    user.role = 'ADMIN';
  }
  const token = await createSession(env,user.user_id);
  return json({ok:true,user:publicUser(user),token},200,cors);
}

async function me(request, env) {
  const user = await getUser(request,env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  return json({ok:true,user:publicUser(user)},200,cors);
}

async function logout(request, env) {
  const auth = request.headers.get('authorization') || '';
  if (auth.toLowerCase().startsWith('bearer ')) await env.DB.prepare('DELETE FROM myshop_auth_sessions_v108 WHERE token_hash=?').bind(await sha256(auth.slice(7).trim())).run();
  return json({ok:true},200,cors);
}

async function securityQuestions(request, env) {
  const id = String(new URL(request.url).searchParams.get('identifier') || '').trim();
  const user = await findAuthUser(env,id);
  if (!user) return json({error:'NOT_FOUND'},404,cors);
  return json({ok:true,question:user.security_q1},200,cors);
}

async function resetPassword(request, env) {
  const b = await body(request);
  const id = String(b.identifier || '').trim();
  const answer = String(b.answer || (Array.isArray(b.answers) ? b.answers[0] : '') || '').trim();
  const newPassword = String(b.newPassword || '');
  if (!id || !answer || newPassword.length < 6) return json({error:'INVALID_INPUT'},400,cors);
  const user = await findAuthUser(env,id);
  if (!user) return json({error:'NOT_FOUND'},404,cors);
  const answerHash = await sha256(normalizeAnswer(answer));
  if (!user.security_a1_hash || user.security_a1_hash !== answerHash) return json({error:'ANSWER_NOT_MATCHED'},403,cors);
  const ph = await hashPassword(newPassword);
  await env.DB.prepare('UPDATE myshop_auth_users_v108 SET password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(ph,user.user_id).run();
  await env.DB.prepare('DELETE FROM myshop_auth_sessions_v108 WHERE user_id=?').bind(user.user_id).run();
  return json({ok:true,userId:user.user_id},200,cors);
}

async function changePassword(request, env) {
  const user = await getUser(request,env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  const b = await body(request);
  const currentPassword = String(b.currentPassword || '');
  const newPassword = String(b.newPassword || '');
  if (!currentPassword || newPassword.length < 6) return json({error:'INVALID_INPUT'},400,cors);
  if (!(await verifyPassword(currentPassword,user.password_hash))) return json({error:'CURRENT_PASSWORD_INCORRECT'},403,cors);
  if (currentPassword === newPassword) return json({error:'PASSWORD_UNCHANGED'},400,cors);
  const ph = await hashPassword(newPassword);
  await env.DB.prepare('UPDATE myshop_auth_users_v108 SET password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(ph,user.user_id).run();
  // Security rule: a password change invalidates every existing session for this account.
  await env.DB.prepare('DELETE FROM myshop_auth_sessions_v108 WHERE user_id=?').bind(user.user_id).run();
  return json({ok:true,userId:user.user_id,sessionInvalidated:true},200,cors);
}


async function ensureContentSchema(env) {
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  // Additive, backward-compatible schema bootstrap. Never silently swallow a D1 schema error.
  const statements = [
    `CREATE TABLE IF NOT EXISTS gallery_items (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL DEFAULT '',media_url TEXT NOT NULL DEFAULT '',media_type TEXT NOT NULL DEFAULT 'image',active INTEGER NOT NULL DEFAULT 1,display_order INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_gallery_active_order ON gallery_items(active,display_order)`,
    `CREATE TABLE IF NOT EXISTS feature_buttons (key TEXT PRIMARY KEY,title TEXT NOT NULL DEFAULT '',icon_url TEXT NOT NULL DEFAULT '',target_url TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,display_order INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_feature_buttons_active_order ON feature_buttons(active,display_order)`,
    `CREATE TABLE IF NOT EXISTS gallery_media (id INTEGER PRIMARY KEY AUTOINCREMENT,folder TEXT NOT NULL,title TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',media_url TEXT NOT NULL DEFAULT '',object_key TEXT NOT NULL DEFAULT '',media_type TEXT NOT NULL DEFAULT 'image',active INTEGER NOT NULL DEFAULT 1,display_order INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_gallery_media_folder_order ON gallery_media(folder,active,display_order,id)`,
    `CREATE TABLE IF NOT EXISTS dashboard_ads (id INTEGER PRIMARY KEY AUTOINCREMENT,box_key TEXT NOT NULL,slot INTEGER NOT NULL,image_url TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',target_url TEXT NOT NULL DEFAULT '',object_key TEXT NOT NULL DEFAULT '',media_type TEXT NOT NULL DEFAULT 'image',active INTEGER NOT NULL DEFAULT 1,duration_sec INTEGER NOT NULL DEFAULT 3,display_mode TEXT NOT NULL DEFAULT 'FULL_IMAGE',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(box_key,slot))`,
    `CREATE INDEX IF NOT EXISTS idx_dashboard_ads_box ON dashboard_ads(box_key,active,slot,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_posts (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id),caption TEXT NOT NULL DEFAULT '',media_url TEXT NOT NULL DEFAULT '',object_key TEXT NOT NULL DEFAULT '',media_type TEXT NOT NULL DEFAULT 'image',status TEXT NOT NULL DEFAULT 'ACTIVE',moderated_by TEXT NOT NULL DEFAULT '',moderated_at TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_posts_feed ON myshop_posts(status,created_at DESC,id DESC)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_posts_user_day ON myshop_posts(user_id,created_at DESC,id DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_post_likes (post_id INTEGER NOT NULL,user_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(post_id,user_id))`,
    `CREATE TABLE IF NOT EXISTS myshop_post_comments (id INTEGER PRIMARY KEY AUTOINCREMENT,post_id INTEGER NOT NULL,user_id TEXT NOT NULL,comment TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS managed_links (id INTEGER PRIMARY KEY AUTOINCREMENT,category TEXT NOT NULL,title TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',url TEXT NOT NULL DEFAULT '',icon_url TEXT NOT NULL DEFAULT '',image_url TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,display_order INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_managed_links_category_order ON managed_links(category,active,display_order,id)`,
    `CREATE TABLE IF NOT EXISTS banner_media (id INTEGER PRIMARY KEY AUTOINCREMENT,folder TEXT NOT NULL,slot INTEGER NOT NULL,object_key TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(folder,slot))`,
    `CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL DEFAULT 'MY SHOP',message TEXT NOT NULL DEFAULT '',audience TEXT NOT NULL DEFAULT 'ALL',user_id TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at DESC,id DESC)`,
    `CREATE INDEX IF NOT EXISTS idx_notifications_audience_user ON notifications(audience,user_id,created_at DESC)`,
    `CREATE TABLE IF NOT EXISTS notification_reads (notification_id INTEGER NOT NULL,user_id TEXT NOT NULL,read_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(notification_id,user_id))`,
    `CREATE INDEX IF NOT EXISTS idx_notification_reads_user ON notification_reads(user_id,read_at DESC)`,
    `CREATE TABLE IF NOT EXISTS dashboard_config (id INTEGER PRIMARY KEY CHECK(id=1),breaking_news TEXT NOT NULL DEFAULT '',my_shop_url TEXT NOT NULL DEFAULT '',live_tv_url TEXT NOT NULL DEFAULT '',external_movie_url TEXT NOT NULL DEFAULT '',chat_url TEXT NOT NULL DEFAULT '',power_ad_title TEXT NOT NULL DEFAULT 'POWER AD',power_ad_byline TEXT NOT NULL DEFAULT 'by Touhid',dashboard_bg_color TEXT NOT NULL DEFAULT '#07122F',dashboard_blue_color TEXT NOT NULL DEFAULT '#2D72F6',dashboard_purple_color TEXT NOT NULL DEFAULT '#7B3FF2',dashboard_pink_color TEXT NOT NULL DEFAULT '#F02BB7',breaking_news_text_size REAL NOT NULL DEFAULT 13.0,breaking_news_bg_color TEXT NOT NULL DEFAULT '#FFEFF7',breaking_news_text_color TEXT NOT NULL DEFAULT '#414662',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS banners (id INTEGER PRIMARY KEY AUTOINCREMENT,folder TEXT NOT NULL DEFAULT '',slot INTEGER NOT NULL DEFAULT 0,image_url TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',target_url TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(folder,slot))`,
    `CREATE TABLE IF NOT EXISTS social_links (id INTEGER PRIMARY KEY AUTOINCREMENT,platform TEXT NOT NULL UNIQUE,url TEXT NOT NULL DEFAULT '',icon_key TEXT NOT NULL DEFAULT '',icon_url TEXT NOT NULL DEFAULT '',image_url TEXT NOT NULL DEFAULT '',caption TEXT NOT NULL DEFAULT '',active INTEGER NOT NULL DEFAULT 1)`,
    `CREATE TABLE IF NOT EXISTS myshop_coin_wallets (user_id TEXT PRIMARY KEY REFERENCES myshop_auth_users_v108(user_id),balance INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_coin_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id),kind TEXT NOT NULL,amount INTEGER NOT NULL,reference TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'COMPLETED',metadata TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_coin_transactions_user ON myshop_coin_transactions(user_id,created_at,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_coin_purchase_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL REFERENCES myshop_auth_users_v108(user_id),package_coins INTEGER NOT NULL,amount_minor INTEGER NOT NULL,payment_method TEXT NOT NULL,reference TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_coin_purchase_user ON myshop_coin_purchase_requests(user_id,created_at,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_gift_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT,sender_user_id TEXT NOT NULL,receiver_user_id TEXT NOT NULL,coins INTEGER NOT NULL,gift_code TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_gold_wallets (user_id TEXT PRIMARY KEY REFERENCES myshop_auth_users_v108(user_id),balance INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_creator_earnings (user_id TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('COIN','GOLD')),balance INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,currency))`,
    `CREATE TABLE IF NOT EXISTS myshop_creator_withdraw_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('COIN','GOLD')),gross_units INTEGER NOT NULL,service_fee_percent REAL NOT NULL DEFAULT 10,service_fee_units INTEGER NOT NULL,net_units INTEGER NOT NULL,cash_minor INTEGER NOT NULL DEFAULT 0,payment_method TEXT NOT NULL,account TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_creator_withdraw_user ON myshop_creator_withdraw_requests(user_id,currency,status,created_at)`,

    `CREATE TABLE IF NOT EXISTS myshop_gold_transactions (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,kind TEXT NOT NULL,amount INTEGER NOT NULL,reference TEXT NOT NULL DEFAULT '',metadata TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_user_badges (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,badge_code TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'ACTIVE',source TEXT NOT NULL DEFAULT 'ADMIN',starts_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,expires_at TEXT,note TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_user_badges_user ON myshop_user_badges(user_id,status,expires_at,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_wallet_purchase_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,item_type TEXT NOT NULL,item_code TEXT NOT NULL,units INTEGER NOT NULL DEFAULT 1,amount_minor INTEGER NOT NULL DEFAULT 0,payment_method TEXT NOT NULL,reference TEXT NOT NULL DEFAULT '',duration TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_withdraw_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,gold_amount INTEGER NOT NULL,payment_method TEXT NOT NULL,account TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_coin_withdraw_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,coin_amount INTEGER NOT NULL,payment_method TEXT NOT NULL,account TEXT NOT NULL,note TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_owned_items (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,catalog_id INTEGER NOT NULL,item_type TEXT NOT NULL,item_code TEXT NOT NULL,equipped INTEGER NOT NULL DEFAULT 0,expires_at TEXT,source TEXT NOT NULL DEFAULT 'PURCHASE',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,UNIQUE(user_id,catalog_id))`,
    `CREATE INDEX IF NOT EXISTS idx_owned_items_user ON myshop_owned_items(user_id,item_type,equipped,created_at)`,
    `CREATE TABLE IF NOT EXISTS myshop_admin_wallet_grants (id INTEGER PRIMARY KEY AUTOINCREMENT,admin_user_id TEXT NOT NULL,target_user_id TEXT NOT NULL,item_type TEXT NOT NULL,item_code TEXT NOT NULL,units INTEGER NOT NULL,days INTEGER NOT NULL DEFAULT 0,note TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_store_catalog (id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT NOT NULL UNIQUE,title TEXT NOT NULL,item_type TEXT NOT NULL,units INTEGER NOT NULL DEFAULT 1,price_minor INTEGER NOT NULL DEFAULT 0,coin_price INTEGER NOT NULL DEFAULT 0,duration_days INTEGER NOT NULL DEFAULT 0,preview_url TEXT NOT NULL DEFAULT '',animation_url TEXT NOT NULL DEFAULT '',animation_mime TEXT NOT NULL DEFAULT '',benefits TEXT NOT NULL DEFAULT '',priority INTEGER NOT NULL DEFAULT 100,limited_edition INTEGER NOT NULL DEFAULT 0,enabled INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_safety_reports (id INTEGER PRIMARY KEY AUTOINCREMENT,reporter_id TEXT NOT NULL,target_user_id TEXT NOT NULL DEFAULT '',content_type TEXT NOT NULL,content_id TEXT NOT NULL DEFAULT '',reason TEXT NOT NULL,details TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'OPEN',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_safety_reports_status ON myshop_safety_reports(status,created_at DESC,id DESC)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_safety_reports_target ON myshop_safety_reports(target_user_id,created_at DESC,id DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_account_deletion_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL DEFAULT '',identifier TEXT NOT NULL DEFAULT '',contact TEXT NOT NULL DEFAULT '',reason TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'OPEN',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_account_deletion_requests_status ON myshop_account_deletion_requests(status,created_at DESC,id DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_play_purchases (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,catalog_id INTEGER NOT NULL,play_product_id TEXT NOT NULL,purchase_token_hash TEXT NOT NULL UNIQUE,order_id TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'VERIFIED',google_payload TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_play_purchases_user ON myshop_play_purchases(user_id,created_at DESC,id DESC)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_store_catalog_order ON myshop_store_catalog(enabled,item_type,priority,id)`,
    `CREATE TABLE IF NOT EXISTS myshop_store_audit (id INTEGER PRIMARY KEY AUTOINCREMENT,admin_user_id TEXT NOT NULL,action TEXT NOT NULL,catalog_id INTEGER,item_code TEXT NOT NULL DEFAULT '',details TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_friend_requests (sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(sender_id,receiver_id),CHECK(sender_id<>receiver_id))`,
    `CREATE INDEX IF NOT EXISTS idx_friend_requests_receiver ON myshop_friend_requests(receiver_id,status,created_at DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_follows (follower_id TEXT NOT NULL,following_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(follower_id,following_id),CHECK(follower_id<>following_id))`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_follows_following ON myshop_follows(following_id,created_at DESC)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_follows_follower ON myshop_follows(follower_id,created_at DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_live_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,viewer_count INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_live_active ON myshop_live_presence(active,last_seen DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_live_seats (host_id TEXT NOT NULL,seat_no INTEGER NOT NULL,user_id TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'SPEAKER',muted INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,seat_no),UNIQUE(host_id,user_id),CHECK(seat_no BETWEEN 1 AND 12))`,
    `CREATE TABLE IF NOT EXISTS myshop_live_requests (host_id TEXT NOT NULL,user_id TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,user_id))`,
    `CREATE TABLE IF NOT EXISTS myshop_app_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE INDEX IF NOT EXISTS idx_myshop_app_presence_active ON myshop_app_presence(active,last_seen DESC)`,
    `CREATE TABLE IF NOT EXISTS myshop_profile_privacy (user_id TEXT PRIMARY KEY,posts_visibility TEXT NOT NULL DEFAULT 'PUBLIC',media_visibility TEXT NOT NULL DEFAULT 'PUBLIC',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`,
    `CREATE TABLE IF NOT EXISTS myshop_user_blocks (blocker_id TEXT NOT NULL,blocked_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(blocker_id,blocked_id),CHECK(blocker_id<>blocked_id))`,
    `CREATE TABLE IF NOT EXISTS myshop_schema_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`
  ];
  // V-239 feature-isolated bootstrap: one optional schema failure must never take Feed/Dashboard down.
  for (const sql of statements) {
    try { await env.DB.prepare(sql).run(); }
    catch(e) { console.error('SCHEMA_STATEMENT_FAILED',String(e?.message||e),String(sql).slice(0,96)); }
  }
  try { await ensureMessageSchema(env); } catch(e) { console.error('MESSAGE_SCHEMA_FAILED',String(e?.message||e)); }
  try { await ensureFriendSchema(env); } catch(e) { console.error('FRIEND_SCHEMA_FAILED',String(e?.message||e)); }
  try { await env.DB.prepare("ALTER TABLE myshop_user_badges ADD COLUMN catalog_id INTEGER").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_user_badges ADD COLUMN is_displayed INTEGER NOT NULL DEFAULT 0").run(); } catch(_) {}
  try { await env.DB.prepare("ALTER TABLE myshop_store_catalog ADD COLUMN play_product_id TEXT NOT NULL DEFAULT ''").run(); } catch(_) {}
  try { await env.DB.prepare(`INSERT OR IGNORE INTO dashboard_config(id) VALUES(1)`).run(); } catch(e) { console.error('DASHBOARD_SCHEMA_INIT_FAILED',String(e?.message||e)); }
  try { await repairContentSchema(env); } catch(e) { console.error('CONTENT_SCHEMA_REPAIR_FAILED',String(e?.message||e)); }
  try { const bc=(await env.DB.prepare('PRAGMA table_info(banners)').all()).results||[]; if(!bc.some(x=>String(x.name)==='target_url')) await env.DB.prepare("ALTER TABLE banners ADD COLUMN target_url TEXT NOT NULL DEFAULT ''").run(); } catch(e) { console.error('BANNER_TARGET_SCHEMA_FAILED',String(e?.message||e)); }
  try { await env.DB.prepare(`INSERT INTO myshop_schema_meta(key,value,updated_at) VALUES('content_schema','239',CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=CURRENT_TIMESTAMP`).run(); } catch(e) { console.error('SCHEMA_META_FAILED',String(e?.message||e)); }
}

async function ensureFriendSchema(env){
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_friend_requests (sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(sender_id,receiver_id),CHECK(sender_id<>receiver_id))`).run();
  const info=(await env.DB.prepare('PRAGMA table_info(myshop_friend_requests)').all()).results||[];
  const cols=new Set(info.map(x=>String(x.name||'')));
  if(!cols.has('status')) await env.DB.prepare("ALTER TABLE myshop_friend_requests ADD COLUMN status TEXT NOT NULL DEFAULT 'PENDING'").run();
  if(!cols.has('created_at')) { await env.DB.prepare("ALTER TABLE myshop_friend_requests ADD COLUMN created_at TEXT NOT NULL DEFAULT ''").run(); await env.DB.prepare("UPDATE myshop_friend_requests SET created_at=CURRENT_TIMESTAMP WHERE created_at=''").run(); }
  if(!cols.has('updated_at')) { await env.DB.prepare("ALTER TABLE myshop_friend_requests ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''").run(); await env.DB.prepare("UPDATE myshop_friend_requests SET updated_at=CURRENT_TIMESTAMP WHERE updated_at=''").run(); }
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_friend_requests_receiver ON myshop_friend_requests(receiver_id,status,created_at DESC)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_user_blocks (blocker_id TEXT NOT NULL,blocked_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(blocker_id,blocked_id),CHECK(blocker_id<>blocked_id))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_follows (follower_id TEXT NOT NULL,following_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(follower_id,following_id),CHECK(follower_id<>following_id))`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_myshop_follows_following ON myshop_follows(following_id,created_at DESC)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_myshop_follows_follower ON myshop_follows(follower_id,created_at DESC)`).run();
}

async function ensureMessageSchema(env){
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_messages (id INTEGER PRIMARY KEY AUTOINCREMENT,sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL,message TEXT NOT NULL DEFAULT '',read_at TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,CHECK(sender_id<>receiver_id))`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_myshop_messages_pair ON myshop_messages(sender_id,receiver_id,id DESC)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_myshop_messages_receiver_unread ON myshop_messages(receiver_id,read_at,id DESC)`).run();
  for(const sql of [`ALTER TABLE myshop_messages ADD COLUMN hidden_from_sender INTEGER NOT NULL DEFAULT 0`,`ALTER TABLE myshop_messages ADD COLUMN hidden_from_receiver INTEGER NOT NULL DEFAULT 0`]){try{await env.DB.prepare(sql).run();}catch(e){}}
}

const schemaInitByEnv = new WeakMap();

async function ensureSchemasOnce(env){
  let p=schemaInitByEnv.get(env);
  if(!p){
    p=(async()=>{
      await ensureAuthSchema(env);
      await ensureContentSchema(env);
    })().catch(e=>{ schemaInitByEnv.delete(env); throw e; });
    schemaInitByEnv.set(env,p);
  }
  return p;
}

async function ensureNotificationSchema(env){
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS notifications (id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL DEFAULT 'MY SHOP',message TEXT NOT NULL DEFAULT '',audience TEXT NOT NULL DEFAULT 'ALL',user_id TEXT NOT NULL DEFAULT '',type TEXT NOT NULL DEFAULT '',actor_user_id TEXT NOT NULL DEFAULT '',target_id TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  const info=(await env.DB.prepare('PRAGMA table_info(notifications)').all()).results||[];
  const cols=new Set(info.map(x=>String(x.name||'')));
  if(!cols.has('type')) await env.DB.prepare("ALTER TABLE notifications ADD COLUMN type TEXT NOT NULL DEFAULT ''").run();
  if(!cols.has('actor_user_id')) await env.DB.prepare("ALTER TABLE notifications ADD COLUMN actor_user_id TEXT NOT NULL DEFAULT ''").run();
  if(!cols.has('target_id')) await env.DB.prepare("ALTER TABLE notifications ADD COLUMN target_id TEXT NOT NULL DEFAULT ''").run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at DESC,id DESC)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_notifications_audience_user ON notifications(audience,user_id,created_at DESC)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS notification_reads (notification_id INTEGER NOT NULL,user_id TEXT NOT NULL,read_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(notification_id,user_id))`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_notification_reads_user ON notification_reads(user_id,read_at DESC)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_push_tokens (user_id TEXT NOT NULL,token TEXT NOT NULL,platform TEXT NOT NULL DEFAULT 'ANDROID',active INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(user_id,token))`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_push_tokens_user ON myshop_push_tokens(user_id,active,updated_at DESC)`).run();
}

let fcmAccessCache={token:'',expiresAt:0};
function fcmB64urlBytes(bytes){let s='';for(const b of bytes)s+=String.fromCharCode(b);return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function fcmB64urlText(s){return fcmB64urlBytes(new TextEncoder().encode(s));}
function fcmPemPkcs8(pem){const raw=String(pem||'').replace(/-----BEGIN PRIVATE KEY-----|-----END PRIVATE KEY-----|\s+/g,'');const bin=atob(raw);const a=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);return a.buffer;}
async function fcmAccessToken(env){
  const raw=String(env.FCM_SERVICE_ACCOUNT_JSON||'').trim();if(!raw)return null;if(fcmAccessCache.token&&Date.now()<fcmAccessCache.expiresAt-60000)return fcmAccessCache.token;
  let sa;try{sa=JSON.parse(raw);}catch(e){console.error('FCM_SERVICE_ACCOUNT_JSON_INVALID');return null;}if(!sa.client_email||!sa.private_key||!sa.project_id)return null;
  const now=Math.floor(Date.now()/1000),header=fcmB64urlText(JSON.stringify({alg:'RS256',typ:'JWT'})),payload=fcmB64urlText(JSON.stringify({iss:sa.client_email,scope:'https://www.googleapis.com/auth/firebase.messaging',aud:'https://oauth2.googleapis.com/token',iat:now,exp:now+3300}));
  const key=await crypto.subtle.importKey('pkcs8',fcmPemPkcs8(sa.private_key),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['sign']);
  const sig=new Uint8Array(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',key,new TextEncoder().encode(header+'.'+payload)));const assertion=header+'.'+payload+'.'+fcmB64urlBytes(sig);
  const r=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion})});if(!r.ok){console.error('FCM_OAUTH_FAILED',r.status);return null;}const j=await r.json();fcmAccessCache={token:String(j.access_token||''),expiresAt:Date.now()+Number(j.expires_in||3000)*1000};return fcmAccessCache.token||null;
}
async function sendPushToUser(env,userId,title,message,type='',actorUserId='',targetId=''){
  try{
    const access=await fcmAccessToken(env);if(!access)return false;let sa;try{sa=JSON.parse(String(env.FCM_SERVICE_ACCOUNT_JSON||''));}catch(e){return false;}
    const rows=(await env.DB.prepare(`SELECT token FROM myshop_push_tokens WHERE user_id=? AND active=1 ORDER BY datetime(updated_at) DESC LIMIT 8`).bind(String(userId)).all()).results||[];if(!rows.length)return false;
    let actorName='',actorAvatarUrl='';if(String(actorUserId||'')){const a=await env.DB.prepare(`SELECT COALESCE(full_name,'') full_name,COALESCE(avatar_url,'') avatar_url FROM myshop_auth_users_v108 WHERE user_id=?`).bind(String(actorUserId)).first();actorName=String(a?.full_name||'');actorAvatarUrl=String(a?.avatar_url||'');}
    const displayTitle=String(type)==='MESSAGE'?(actorName||'MY SHOP'):String(title||'MY SHOP');const bodyText=String(type)==='MESSAGE'?String(message||''):String(message||'');
    for(const row of rows){
      const payload={message:{token:String(row.token),data:{title:displayTitle,body:bodyText,type:String(type||''),actorUserId:String(actorUserId||''),targetId:String(targetId||''),actorAvatarUrl,channel:String(type)==='MESSAGE'?'myshop_messages':'myshop_general'},android:{priority:'high',ttl:'86400s'}}};
      const r=await fetch(`https://fcm.googleapis.com/v1/projects/${encodeURIComponent(sa.project_id)}/messages:send`,{method:'POST',headers:{authorization:'Bearer '+access,'content-type':'application/json'},body:JSON.stringify(payload)});
      if(!r.ok){const tx=await r.text();if(r.status===404||tx.includes('UNREGISTERED'))await env.DB.prepare(`UPDATE myshop_push_tokens SET active=0,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND token=?`).bind(String(userId),String(row.token)).run();console.error('FCM_SEND_FAILED',r.status,tx.slice(0,180));}
    }
    return true;
  }catch(e){console.error('FCM_PUSH_FAILED',String(e?.message||e));return false;}
}
async function pushTokenRegister(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureNotificationSchema(env);const b=await body(request),token=String(b.token||'').trim().slice(0,4096);if(token.length<20)return json({error:'INVALID_PUSH_TOKEN'},400,cors);
  await env.DB.prepare(`INSERT INTO myshop_push_tokens(user_id,token,platform,active,updated_at) VALUES(?,?,'ANDROID',1,CURRENT_TIMESTAMP) ON CONFLICT(user_id,token) DO UPDATE SET active=1,updated_at=CURRENT_TIMESTAMP`).bind(me.user_id,token).run();return json({ok:true},200,cors);
}

async function createUserNotification(env,userId,title,message,type='',actorUserId='',targetId='',ctx=null){
  const uid=String(userId||'').trim();
  if(!uid) return false;
  const t=String(title||'MY SHOP'), m=String(message||''), kind=String(type||'').slice(0,40), actor=String(actorUserId||'').slice(0,40), target=String(targetId||'').slice(0,120);
  for(let attempt=1;attempt<=2;attempt++){
    try {
      await ensureNotificationSchema(env);
      const r=await env.DB.prepare(`INSERT INTO notifications(title,message,audience,user_id,type,actor_user_id,target_id,created_at) VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)`).bind(t,m,'USER',uid,kind,actor,target).run();
      const id=r.meta?.last_row_id;
      if(id){ const v=await env.DB.prepare('SELECT id FROM notifications WHERE id=? AND user_id=?').bind(id,uid).first(); if(v?.id){const push=sendPushToUser(env,uid,t,m,kind,actor,target);if(ctx&&ctx.waitUntil)ctx.waitUntil(push);else await push;return true;} }
      const v=await env.DB.prepare("SELECT id FROM notifications WHERE title=? AND message=? AND audience='USER' AND user_id=? ORDER BY id DESC LIMIT 1").bind(t,m,uid).first();
      if(v?.id){const push=sendPushToUser(env,uid,t,m,kind,actor,target);if(ctx&&ctx.waitUntil)ctx.waitUntil(push);else await push;return true;}
    } catch (e) {
      console.error('NOTIFICATION_DB_WRITE_FAILED',JSON.stringify({attempt,message:String(e?.message||e)}));
    }
  }
  return false;
}

async function createBroadcastNotification(env,title,message){
  const t=String(title||'MY SHOP'), m=String(message||'');
  for(let attempt=1;attempt<=2;attempt++){
    try {
      await ensureNotificationSchema(env);
      const r=await env.DB.prepare(`INSERT INTO notifications(title,message,audience,user_id,created_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)`).bind(t,m,'ALL','').run();
      const id=r.meta?.last_row_id;
      if(id){ const v=await env.DB.prepare("SELECT id FROM notifications WHERE id=? AND audience='ALL'").bind(id).first(); if(v?.id) return true; }
    } catch (e) {
      console.error('NOTIFICATION_DB_WRITE_FAILED',JSON.stringify({attempt,message:String(e?.message||e)}));
    }
  }
  return false;
}

async function ensureReleaseNotification(env){
  const key='release_notice_v242';
  try {
    await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_schema_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
    const sent=await env.DB.prepare('SELECT value FROM myshop_schema_meta WHERE key=?').bind(key).first();
    if(String(sent?.value||'')==='sent') return;
    const ok=await createBroadcastNotification(env,'MY SHOP Update','V-249 is available: live Friends/Followers/Following profile counts, Follow/Unfollow, Facebook-style cover photos, and smoother profile actions.');
    if(ok) await env.DB.prepare(`INSERT INTO myshop_schema_meta(key,value,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=CURRENT_TIMESTAMP`).bind(key,'sent').run();
  } catch(e) { console.error('RELEASE_NOTICE_FAILED',String(e?.message||e)); }
}

async function notificationsList(request,env){
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  try { await ensureNotificationSchema(env); await ensureFriendSchema(env); } catch (e) { return json({error:'NOTIFICATION_SCHEMA_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
  const allowed="('LIKE','COMMENT','FRIEND_REQUEST','FRIEND_ACCEPT','FRIEND_UPDATE','LIVE_START')";
  const rows=await env.DB.prepare(`SELECT n.id,n.title,n.message,n.type,n.actor_user_id,n.target_id,n.created_at,CASE WHEN r.notification_id IS NULL THEN 0 ELSE 1 END AS is_read,COALESCE(a.avatar_url,'') AS actor_avatar_url,COALESCE(p.media_url,'') AS thumbnail_url,COALESCE(fr.status,'') AS friend_status FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? LEFT JOIN myshop_auth_users_v108 a ON a.user_id=n.actor_user_id LEFT JOIN myshop_posts p ON CAST(p.id AS TEXT)=n.target_id LEFT JOIN myshop_friend_requests fr ON n.type='FRIEND_REQUEST' AND fr.sender_id=n.actor_user_id AND fr.receiver_id=n.user_id WHERE n.audience='USER' AND n.user_id=? AND n.type IN ${allowed} ORDER BY n.id DESC LIMIT 80`).bind(user.user_id,user.user_id).all();
  const unread=await env.DB.prepare(`SELECT COUNT(*) AS c FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? WHERE n.audience='USER' AND n.user_id=? AND n.type IN ${allowed} AND r.notification_id IS NULL`).bind(user.user_id,user.user_id).first();
  return json({ok:true,unreadCount:Number(unread?.c||0),notifications:(rows.results||[]).map(x=>({id:x.id,title:x.title,message:x.message,type:x.type||'',actorUserId:x.actor_user_id||'',targetId:x.target_id||'',createdAt:x.created_at,isRead:Number(x.is_read||0),actorAvatarUrl:x.actor_avatar_url||'',thumbnailUrl:x.thumbnail_url||'',friendRequestState:x.type==='FRIEND_REQUEST'?(x.friend_status||'CANCELLED'):''}))},200,cors);
}

async function notificationReadOne(request,env){
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors); const b=await body(request); const id=Number(b.id||0); if(!id)return json({error:'INVALID_NOTIFICATION_ID'},400,cors);
  try{await ensureNotificationSchema(env);const n=await env.DB.prepare("SELECT id FROM notifications WHERE id=? AND audience='USER' AND user_id=? AND type IN ('LIKE','COMMENT','FRIEND_REQUEST','FRIEND_ACCEPT','FRIEND_UPDATE','LIVE_START')").bind(id,user.user_id).first();if(!n)return json({error:'NOT_FOUND'},404,cors);await env.DB.prepare('INSERT OR IGNORE INTO notification_reads(notification_id,user_id,read_at) VALUES(?,?,CURRENT_TIMESTAMP)').bind(id,user.user_id).run();const u=await env.DB.prepare(`SELECT COUNT(*) AS c FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? WHERE n.audience='USER' AND n.user_id=? AND n.type IN ('LIKE','COMMENT','FRIEND_REQUEST','FRIEND_ACCEPT','FRIEND_UPDATE','LIVE_START') AND r.notification_id IS NULL`).bind(user.user_id,user.user_id).first();return json({ok:true,unreadCount:Number(u?.c||0)},200,cors);}catch(e){return json({error:'NOTIFICATION_DB_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);}
}

async function notificationsReadAll(request,env){
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  try { await ensureNotificationSchema(env); await env.DB.prepare(`INSERT OR IGNORE INTO notification_reads(notification_id,user_id,read_at) SELECT n.id,?,CURRENT_TIMESTAMP FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? WHERE n.audience='USER' AND n.user_id=? AND n.type IN ('LIKE','COMMENT','FRIEND_REQUEST','FRIEND_ACCEPT','FRIEND_UPDATE','LIVE_START') AND r.notification_id IS NULL`).bind(user.user_id,user.user_id,user.user_id).run(); return json({ok:true,unreadCount:0},200,cors); }
  catch(e){ return json({error:'NOTIFICATION_DB_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
}



const REQUIRED_CONTENT_COLUMNS = {
  dashboard_config:['id','breaking_news','my_shop_url','live_tv_url','external_movie_url','chat_url','power_ad_title','power_ad_byline','dashboard_bg_color','dashboard_blue_color','dashboard_purple_color','dashboard_pink_color','breaking_news_text_size','breaking_news_bg_color','breaking_news_text_color','updated_at'],
  banners:['id','folder','slot','image_url','caption','target_url','active','updated_at'],
  banner_media:['id','folder','slot','object_key','updated_at'],
  gallery_media:['id','folder','title','caption','media_url','object_key','media_type','active','display_order','updated_at'],
  gallery_items:['id','title','media_url','media_type','active','display_order','updated_at'],
  feature_buttons:['key','title','icon_url','target_url','active','display_order','updated_at'],
  social_links:['id','platform','url','icon_key','icon_url','image_url','caption','active'],
  managed_links:['id','category','title','caption','url','icon_url','image_url','active','display_order','updated_at'],
  dashboard_ads:['id','box_key','slot','image_url','caption','target_url','object_key','media_type','active','duration_sec','updated_at'],
  notifications:['id','title','message','audience','user_id','created_at'],
  notification_reads:['notification_id','user_id','read_at'],
  myshop_posts:['id','user_id','caption','media_url','object_key','media_type','status','moderated_by','moderated_at','created_at','updated_at'],
  myshop_post_likes:['post_id','user_id','created_at'],
  myshop_post_comments:['id','post_id','user_id','comment','created_at']
};

async function assertContentSchema(env){
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  const missing=[];
  for(const [table,cols] of Object.entries(REQUIRED_CONTENT_COLUMNS)){
    let rows=[];
    try{ rows=(await env.DB.prepare(`PRAGMA table_info(${table})`).all()).results||[]; }
    catch(e){ throw new Error(`D1_SCHEMA_READ_FAILED:${table}:${String(e?.message||e).slice(0,160)}`); }
    if(!rows.length){ missing.push(`${table}:(table missing)`); continue; }
    const names=new Set(rows.map(r=>String(r.name||'')));
    for(const col of cols) if(!names.has(col)) missing.push(`${table}.${col}`);
  }
  if(missing.length) throw new Error('D1_SCHEMA_INCOMPLETE:'+missing.slice(0,20).join(','));
  const cfg=await env.DB.prepare('SELECT id FROM dashboard_config WHERE id=1').first();
  if(!cfg) throw new Error('D1_SCHEMA_INCOMPLETE:dashboard_config.id=1 row missing');
  return true;
}

async function d1WriteProbe(env){
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_health_probe (probe_id TEXT PRIMARY KEY,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  const id=crypto.randomUUID();
  await env.DB.prepare('INSERT INTO myshop_health_probe(probe_id) VALUES(?)').bind(id).run();
  const row=await env.DB.prepare('SELECT probe_id FROM myshop_health_probe WHERE probe_id=?').bind(id).first();
  if(!row?.probe_id) throw new Error('D1_WRITE_VERIFY_FAILED');
  await env.DB.prepare('DELETE FROM myshop_health_probe WHERE probe_id=?').bind(id).run();
  return true;
}

async function r2WriteProbe(env){
  if(!env?.MEDIA) throw new Error('R2_NOT_CONFIGURED');
  const key=`_health/myshop-${crypto.randomUUID()}.txt`;
  const data=new TextEncoder().encode('MY SHOP R2 health probe');
  try{
    await env.MEDIA.put(key,data,{httpMetadata:{contentType:'text/plain',cacheControl:'no-store'}});
    const head=await env.MEDIA.head(key);
    if(!head) throw new Error('R2_WRITE_VERIFY_FAILED');
  } finally {
    try{ await env.MEDIA.delete(key); }catch(_){}
  }
  return true;
}

async function assertWriteReady(env){
  await ensureSchemasOnce(env);
  await assertContentSchema(env);
  return true;
}

async function ensureColumn(env, table, column, definition) {
  if(!env?.DB) throw new Error('D1_NOT_CONFIGURED');
  const info = await env.DB.prepare(`PRAGMA table_info(${table})`).all();
  const rows=info.results||[];
  if(!rows.length) throw new Error(`D1_SCHEMA_TABLE_MISSING:${table}`);
  const found = rows.some(r => String(r.name || '') === column);
  if(!found){
    try { await env.DB.prepare(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`).run(); }
    catch(e){ throw new Error(`D1_SCHEMA_REPAIR_FAILED:${table}.${column}:${String(e?.message||e).slice(0,180)}`); }
  }
}

async function repairContentSchema(env) {
  // Existing production databases may use older column names. Repair is additive only.
  await ensureColumn(env,'myshop_auth_users_v108','avatar_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'myshop_auth_users_v108','avatar_object_key',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'myshop_auth_users_v108','bio',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'myshop_auth_users_v108','updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`);

  for (const [c,d] of [
    ['breaking_news',`TEXT NOT NULL DEFAULT ''`],['my_shop_url',`TEXT NOT NULL DEFAULT ''`],['live_tv_url',`TEXT NOT NULL DEFAULT ''`],
    ['external_movie_url',`TEXT NOT NULL DEFAULT ''`],['chat_url',`TEXT NOT NULL DEFAULT ''`],['power_ad_title',`TEXT NOT NULL DEFAULT 'POWER AD'`],
    ['power_ad_byline',`TEXT NOT NULL DEFAULT 'by Touhid'`],['dashboard_bg_color',`TEXT NOT NULL DEFAULT '#07122F'`],
    ['dashboard_blue_color',`TEXT NOT NULL DEFAULT '#2D72F6'`],['dashboard_purple_color',`TEXT NOT NULL DEFAULT '#7B3FF2'`],
    ['dashboard_pink_color',`TEXT NOT NULL DEFAULT '#F02BB7'`],['breaking_news_text_size',`REAL NOT NULL DEFAULT 13.0`],['breaking_news_bg_color',`TEXT NOT NULL DEFAULT '#FFEFF7'`],['breaking_news_text_color',`TEXT NOT NULL DEFAULT '#414662'`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
  ]) await ensureColumn(env,'dashboard_config',c,d);

  // V-355 palette migration: only legacy default values move to the approved dark navy/blue/purple/pink family. Admin custom colors stay untouched.
  await env.DB.prepare(`UPDATE dashboard_config SET dashboard_bg_color=CASE WHEN upper(dashboard_bg_color)='#F8F9FD' THEN '#07122F' ELSE dashboard_bg_color END,dashboard_blue_color=CASE WHEN upper(dashboard_blue_color)='#2E2FBE' THEN '#2D72F6' ELSE dashboard_blue_color END,dashboard_purple_color=CASE WHEN upper(dashboard_purple_color)='#5B26D6' THEN '#7B3FF2' ELSE dashboard_purple_color END,dashboard_pink_color=CASE WHEN upper(dashboard_pink_color)='#EB24A8' THEN '#F02BB7' ELSE dashboard_pink_color END WHERE id=1`).run();

  // V-192 permanent legacy-banner repair: older D1 used section/position/is_active.
  await ensureColumn(env,'banners','folder',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'banners','slot',`INTEGER NOT NULL DEFAULT 0`);
  await ensureColumn(env,'banners','image_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'banners','caption',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'banners','active',`INTEGER NOT NULL DEFAULT 1`);
  await ensureColumn(env,'banners','updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`);
  const bannerCols=(await env.DB.prepare('PRAGMA table_info(banners)').all()).results||[];
  const bn=new Set(bannerCols.map(r=>String(r.name||'')));
  if(bn.has('section')) await env.DB.prepare(`UPDATE banners SET folder=CASE WHEN lower(trim(COALESCE(section,''))) IN ('hero','promo') THEN lower(trim(section)) ELSE CASE WHEN lower(trim(COALESCE(folder,''))) IN ('hero','promo') THEN lower(trim(folder)) ELSE 'hero' END END WHERE trim(COALESCE(folder,''))=''`).run();
  if(bn.has('position')) await env.DB.prepare(`UPDATE banners SET slot=CASE WHEN CAST(COALESCE(position,0) AS INTEGER)>0 THEN CAST(position AS INTEGER) ELSE CASE WHEN slot>0 THEN slot ELSE 1 END END WHERE COALESCE(slot,0)<=0`).run();
  await env.DB.prepare(`UPDATE banners SET folder='hero' WHERE trim(COALESCE(folder,''))=''`).run();
  await env.DB.prepare(`UPDATE banners SET slot=1 WHERE COALESCE(slot,0)<=0`).run();

  for (const [c,d] of [['caption',`TEXT NOT NULL DEFAULT ''`],['object_key',`TEXT NOT NULL DEFAULT ''`],['media_url',`TEXT NOT NULL DEFAULT ''`],['media_type',`TEXT NOT NULL DEFAULT 'image'`],['active',`INTEGER NOT NULL DEFAULT 1`],['display_order',`INTEGER NOT NULL DEFAULT 1`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`],['owner_user_id',`TEXT`]]) await ensureColumn(env,'gallery_media',c,d);
  await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_gallery_media_owner ON gallery_media(owner_user_id,folder,active,updated_at)').run();

  await ensureColumn(env,'dashboard_ads','duration_sec',`INTEGER NOT NULL DEFAULT 3`);
  await ensureColumn(env,'dashboard_ads','display_mode',`TEXT NOT NULL DEFAULT 'FULL_IMAGE'`);
  await ensureColumn(env,'dashboard_ads','media_type',`TEXT NOT NULL DEFAULT 'image'`);
  await env.DB.prepare('CREATE INDEX IF NOT EXISTS idx_dashboard_ads_box ON dashboard_ads(box_key,active,slot,id)').run();
  await ensureColumn(env,'banner_media','object_key',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'banner_media','updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`);
  for (const [c,d] of [['caption',`TEXT NOT NULL DEFAULT ''`],['icon_url',`TEXT NOT NULL DEFAULT ''`],['image_url',`TEXT NOT NULL DEFAULT ''`],['active',`INTEGER NOT NULL DEFAULT 1`],['display_order',`INTEGER NOT NULL DEFAULT 1`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]]) await ensureColumn(env,'managed_links',c,d);
  await ensureColumn(env,'social_links','icon_key',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'social_links','icon_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'social_links','image_url',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'social_links','caption',`TEXT NOT NULL DEFAULT ''`);
  await ensureColumn(env,'social_links','active',`INTEGER NOT NULL DEFAULT 1`);

  // Full required-column repair audit (additive only). Existing rows are preserved.
  // Primary-key columns are intentionally not ALTERed; their tables are created above when absent.
  const requiredRepairs = {
    gallery_media:[
      ['folder',`TEXT NOT NULL DEFAULT ''`],['title',`TEXT NOT NULL DEFAULT ''`]
    ],
    gallery_items:[
      ['title',`TEXT NOT NULL DEFAULT ''`],['media_url',`TEXT NOT NULL DEFAULT ''`],['media_type',`TEXT NOT NULL DEFAULT 'image'`],
      ['active',`INTEGER NOT NULL DEFAULT 1`],['display_order',`INTEGER NOT NULL DEFAULT 1`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    feature_buttons:[
      ['title',`TEXT NOT NULL DEFAULT ''`],['icon_url',`TEXT NOT NULL DEFAULT ''`],['target_url',`TEXT NOT NULL DEFAULT ''`],
      ['active',`INTEGER NOT NULL DEFAULT 1`],['display_order',`INTEGER NOT NULL DEFAULT 1`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    banner_media:[
      ['folder',`TEXT NOT NULL DEFAULT ''`],['slot',`INTEGER NOT NULL DEFAULT 0`]
    ],
    notifications:[
      ['title',`TEXT NOT NULL DEFAULT 'MY SHOP'`],['message',`TEXT NOT NULL DEFAULT ''`],['audience',`TEXT NOT NULL DEFAULT 'ALL'`],
      ['user_id',`TEXT NOT NULL DEFAULT ''`],['created_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    notification_reads:[
      ['notification_id',`INTEGER`],['user_id',`TEXT`],['read_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    myshop_posts:[
      ['user_id',`TEXT NOT NULL DEFAULT ''`],['caption',`TEXT NOT NULL DEFAULT ''`],['media_url',`TEXT NOT NULL DEFAULT ''`],
      ['object_key',`TEXT NOT NULL DEFAULT ''`],['media_type',`TEXT NOT NULL DEFAULT 'image'`],['status',`TEXT NOT NULL DEFAULT 'ACTIVE'`],
      ['moderated_by',`TEXT NOT NULL DEFAULT ''`],['moderated_at',`TEXT`],['created_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`],
      ['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    myshop_post_likes:[
      ['post_id',`INTEGER`],['user_id',`TEXT`],['created_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    myshop_post_comments:[
      ['post_id',`INTEGER`],['user_id',`TEXT`],['comment',`TEXT NOT NULL DEFAULT ''`],['created_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ],
    managed_links:[
      ['category',`TEXT NOT NULL DEFAULT ''`],['title',`TEXT NOT NULL DEFAULT ''`],['url',`TEXT NOT NULL DEFAULT ''`],['image_url',`TEXT NOT NULL DEFAULT ''`]
    ],
    dashboard_ads:[
      ['box_key',`TEXT NOT NULL DEFAULT ''`],['slot',`INTEGER NOT NULL DEFAULT 0`],['image_url',`TEXT NOT NULL DEFAULT ''`],
      ['caption',`TEXT NOT NULL DEFAULT ''`],['target_url',`TEXT NOT NULL DEFAULT ''`],['object_key',`TEXT NOT NULL DEFAULT ''`],['media_type',`TEXT NOT NULL DEFAULT 'image'`],
      ['active',`INTEGER NOT NULL DEFAULT 1`],['duration_sec',`INTEGER NOT NULL DEFAULT 3`],['updated_at',`TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP`]
    ]
  };
  for (const [table, columns] of Object.entries(requiredRepairs)) {
    for (const [column, definition] of columns) await ensureColumn(env,table,column,definition);
  }
}

async function ensureDashboardConfigSchema(env) {
  await ensureContentSchema(env);
}

async function deepHealth(env) {
  const result={ok:true,service:'my-shop-api',database:'unknown',d1Write:'unknown',r2:'unknown',r2Write:'unknown',schema:'unknown',playBilling:env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON?'configured':'missing',time:new Date().toISOString()};
  try {
    await env.DB.prepare('SELECT 1').first();
    result.database='ok';
    await ensureSchemasOnce(env);
    await assertContentSchema(env);
    result.schema='ok';
    await d1WriteProbe(env);
    result.d1Write='ok';
  } catch (e) {
    result.ok=false;
    result.database=result.database==='ok'?'ok':'error';
    result.schema=result.schema==='ok'?'ok':'error';
    result.d1Write='error';
    result.databaseMessage=String(e?.message||e).slice(0,220);
  }
  try {
    if (!env.MEDIA) throw new Error('R2 binding MEDIA is missing');
    await env.MEDIA.list({limit:1});
    result.r2='ok';
    await r2WriteProbe(env);
    result.r2Write='ok';
  } catch (e) {
    result.ok=false;
    result.r2=result.r2==='ok'?'ok':'error';
    result.r2Write='error';
    result.r2Message=String(e?.message||e).slice(0,220);
  }
  return result;
}

async function insertBannerCompat(env,{folder,slot,imageUrl,caption,active=1}) {
  const cols=(await env.DB.prepare('PRAGMA table_info(banners)').all()).results||[];
  const names=new Set(cols.map(r=>String(r.name||'')));
  const fields=['folder','slot','image_url','caption','active'];
  const values=[folder,slot,imageUrl,caption,active];
  if(names.has('section')) { fields.push('section'); values.push(folder); }
  if(names.has('position')) { fields.push('position'); values.push(slot); }
  if(names.has('is_active')) { fields.push('is_active'); values.push(active); }
  fields.push('updated_at');
  const placeholders=[...values.map(()=>'?'),'CURRENT_TIMESTAMP'];
  await env.DB.prepare(`INSERT INTO banners(${fields.join(',')}) VALUES(${placeholders.join(',')})`).bind(...values).run();
}

async function contentWriteSuite(request,env){
  const expected=String(env.MYSHOP_HEALTH_PROBE_KEY||'').trim();
  const supplied=String(request.headers.get('X-MYSHOP-HEALTH-KEY')||'').trim();
  if(!expected || !supplied || supplied!==expected) return json({error:'HEALTH_PROBE_FORBIDDEN'},403,cors);
  const marker=`__health_${crypto.randomUUID().replace(/-/g,'')}`;
  const checks={};
  const created={
    bannerId:null,bannerMediaId:null,galleryItemId:null,galleryMediaId:null,
    socialId:null,featureKey:null,managedLinkId:null,adId:null,notificationId:null,
    notificationReadUserId:null
  };
  let bannerFolder=''; let bannerSlot=0;
  try{
    await ensureSchemasOnce(env);
    await assertContentSchema(env);
    checks.schema='ok';

    await r2WriteProbe(env);
    checks.r2='ok';

    // Banners are constrained in production to hero 1-6 / promo 1-3.
    // Select a free valid slot first; never overwrite a real banner.
    for(const [folder,maxSlot] of [['hero',6],['promo',3]]){
      if(bannerSlot) break;
      for(let slot=1;slot<=maxSlot;slot++){
        const row=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=? LIMIT 1').bind(folder,slot).first();
        if(!row?.id){ bannerFolder=folder; bannerSlot=slot; break; }
      }
    }
    // If all normal slots are occupied, use a temporary folder. Current/legacy
    // schema constrains slot, not folder; this avoids touching existing banners.
    if(!bannerSlot){ bannerFolder=marker; bannerSlot=1; }

    await insertBannerCompat(env,{folder:bannerFolder,slot:bannerSlot,imageUrl:'health://probe',caption:'',active:1});
    const br=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=? ORDER BY id DESC LIMIT 1').bind(bannerFolder,bannerSlot).first();
    created.bannerId=Number(br?.id||0)||null;
    const b=br;
    if(!b?.id) throw new Error('BANNER_WRITE_VERIFY_FAILED');
    created.bannerId=Number(b.id); checks.banners='ok';

    // banner_media has a legacy UNIQUE(folder,slot). Never collide with an orphaned row.
    let mediaFolder=bannerFolder, mediaSlot=bannerSlot;
    for(let i=0;i<20;i++){
      const existing=await env.DB.prepare('SELECT id FROM banner_media WHERE folder=? AND slot=? LIMIT 1').bind(mediaFolder,mediaSlot).first();
      if(!existing?.id) break;
      mediaSlot++;
      if(mediaSlot>6){ mediaFolder=`${marker}_media`; mediaSlot=1; }
    }
    const bmr=await env.DB.prepare('INSERT INTO banner_media(folder,slot,object_key,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP)').bind(mediaFolder,mediaSlot,marker).run();
    created.bannerMediaId=Number(bmr?.meta?.last_row_id||0)||null;
    const bm=await env.DB.prepare('SELECT id FROM banner_media WHERE object_key=?').bind(marker).first();
    if(!bm?.id) throw new Error('BANNER_MEDIA_WRITE_VERIFY_FAILED');
    created.bannerMediaId=Number(bm.id); checks.banner_media='ok';

    const giTitle=`Health Probe ${marker}`;
    const gir=await env.DB.prepare('INSERT INTO gallery_items(title,media_url,media_type,active,display_order,updated_at) VALUES(?,?,?,?,1,CURRENT_TIMESTAMP)').bind(giTitle,'health://probe','image',1).run();
    created.galleryItemId=Number(gir?.meta?.last_row_id||0)||null;
    const gi=await env.DB.prepare('SELECT id FROM gallery_items WHERE id=?').bind(created.galleryItemId).first();
    if(!gi?.id) throw new Error('GALLERY_ITEM_WRITE_VERIFY_FAILED');
    checks.gallery_items='ok';

    const gm=await env.DB.prepare('INSERT INTO gallery_media(folder,title,caption,media_url,object_key,media_type,active,display_order,updated_at) VALUES(?,?,?,?,?,?,1,1,CURRENT_TIMESTAMP)').bind(marker,'Health Probe','', 'health://probe', marker, 'image').run();
    created.galleryMediaId=Number(gm?.meta?.last_row_id||0)||null;
    const gmv=await env.DB.prepare('SELECT id FROM gallery_media WHERE id=?').bind(created.galleryMediaId).first();
    if(!gmv?.id) throw new Error('GALLERY_MEDIA_WRITE_VERIFY_FAILED');
    checks.gallery_media='ok';

    const sl=await env.DB.prepare('INSERT INTO social_links(platform,url,icon_key,caption,active) VALUES(?,?,?,?,1)').bind(marker,'https://example.invalid',marker,'').run();
    created.socialId=Number(sl?.meta?.last_row_id||0)||null;
    const slv=await env.DB.prepare('SELECT id FROM social_links WHERE id=?').bind(created.socialId).first();
    if(!slv?.id) throw new Error('SOCIAL_WRITE_VERIFY_FAILED');
    checks.social_links='ok';

    await env.DB.prepare('INSERT INTO feature_buttons(key,title,icon_url,target_url,active,display_order,updated_at) VALUES(?,?,?,?,1,1,CURRENT_TIMESTAMP)').bind(marker,'Health Probe','','').run();
    const fb=await env.DB.prepare('SELECT key FROM feature_buttons WHERE key=?').bind(marker).first();
    if(!fb?.key) throw new Error('FEATURE_WRITE_VERIFY_FAILED');
    created.featureKey=marker; checks.feature_buttons='ok';

    const ml=await env.DB.prepare('INSERT INTO managed_links(category,title,url,icon_url,active,display_order,updated_at) VALUES(?,?,?,?,1,1,CURRENT_TIMESTAMP)').bind(marker,'Health Probe','','').run();
    created.managedLinkId=Number(ml?.meta?.last_row_id||0)||null;
    const mlv=await env.DB.prepare('SELECT id FROM managed_links WHERE id=?').bind(created.managedLinkId).first();
    if(!mlv?.id) throw new Error('MANAGED_LINK_WRITE_VERIFY_FAILED');
    checks.managed_links='ok';

    // Dashboard ads are constrained by the application to slots 1-6.
    const da=await env.DB.prepare('INSERT INTO dashboard_ads(box_key,slot,image_url,caption,target_url,object_key,active,duration_sec,updated_at) VALUES(?,?,?,?,?,?,1,3,CURRENT_TIMESTAMP)').bind(marker,1,'health://probe','','',marker).run();
    created.adId=Number(da?.meta?.last_row_id||0)||null;
    const dav=await env.DB.prepare('SELECT id FROM dashboard_ads WHERE id=?').bind(created.adId).first();
    if(!dav?.id) throw new Error('DASHBOARD_AD_WRITE_VERIFY_FAILED');
    checks.dashboard_ads='ok';

    const no=await env.DB.prepare('INSERT INTO notifications(title,message,audience,user_id,created_at) VALUES(?,?,?,?,CURRENT_TIMESTAMP)').bind('MY SHOP Health Probe',marker,'ALL','').run();
    created.notificationId=Number(no?.meta?.last_row_id||0)||null;
    const nov=await env.DB.prepare('SELECT id FROM notifications WHERE id=?').bind(created.notificationId).first();
    if(!nov?.id) throw new Error('NOTIFICATION_WRITE_VERIFY_FAILED');
    checks.notifications='ok';

    // Prove a dashboard write without changing user-visible values.
    const cfg=await env.DB.prepare('SELECT id FROM dashboard_config WHERE id=1').first();
    if(!cfg?.id) throw new Error('DASHBOARD_CONFIG_READ_VERIFY_FAILED');
    await env.DB.prepare('UPDATE dashboard_config SET updated_at=updated_at WHERE id=1').run();
    const cfg2=await env.DB.prepare('SELECT id FROM dashboard_config WHERE id=1').first();
    if(!cfg2?.id) throw new Error('DASHBOARD_CONFIG_WRITE_VERIFY_FAILED');
    checks.dashboard_config='ok';

    // If the legacy table has a foreign-key/check constraint on user_id, use a real
    // existing account rather than inventing an identity value. No identity row is changed.
    const userRow=await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 ORDER BY user_id LIMIT 1').first();
    const readUserId=String(userRow?.user_id||'0100');
    await env.DB.prepare('INSERT INTO notification_reads(notification_id,user_id,read_at) VALUES(?,?,CURRENT_TIMESTAMP)').bind(created.notificationId,readUserId).run();
    created.notificationReadUserId=readUserId;
    const nr=await env.DB.prepare('SELECT notification_id FROM notification_reads WHERE notification_id=? AND user_id=?').bind(created.notificationId,readUserId).first();
    if(!nr?.notification_id) throw new Error('NOTIFICATION_READ_WRITE_VERIFY_FAILED');
    checks.notification_reads='ok';

    return json({ok:true,checks},200,cors);
  } catch(e){
    return json({ok:false,checks,error:'CONTENT_WRITE_SUITE_FAILED',message:String(e?.message||e).slice(0,240)},503,cors);
  } finally {
    const cleanup=[
      created.notificationReadUserId && created.notificationId
        ? ['DELETE FROM notification_reads WHERE notification_id=? AND user_id=?',[created.notificationId,created.notificationReadUserId]] : null,
      created.notificationId ? ['DELETE FROM notifications WHERE id=?',[created.notificationId]] : null,
      created.adId ? ['DELETE FROM dashboard_ads WHERE id=?',[created.adId]] : null,
      created.managedLinkId ? ['DELETE FROM managed_links WHERE id=?',[created.managedLinkId]] : null,
      created.featureKey ? ['DELETE FROM feature_buttons WHERE key=?',[created.featureKey]] : null,
      created.socialId ? ['DELETE FROM social_links WHERE id=?',[created.socialId]] : null,
      created.galleryMediaId ? ['DELETE FROM gallery_media WHERE id=?',[created.galleryMediaId]] : null,
      created.galleryItemId ? ['DELETE FROM gallery_items WHERE id=?',[created.galleryItemId]] : null,
      created.bannerMediaId ? ['DELETE FROM banner_media WHERE id=?',[created.bannerMediaId]] : null,
      created.bannerId ? ['DELETE FROM banners WHERE id=?',[created.bannerId]] : null
    ].filter(Boolean);
    for(const [sql,args] of cleanup){ try{await env.DB.prepare(sql).bind(...args).run();}catch(_){} }
  }
}

async function adminSystemHealth(request,env){
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const h=await deepHealth(env);
  const counts={};
  const tables=['banners','banner_media','gallery_media','dashboard_ads','social_links','feature_buttons','managed_links','notifications','notification_reads'];
  for(const t of tables){
    try { const r=await env.DB.prepare(`SELECT COUNT(*) AS c FROM ${t}`).first(); counts[t]=Number(r?.c||0); }
    catch(e){ counts[t]={error:String(e?.message||e).slice(0,180)}; }
  }
  let schemaMeta={}; try { schemaMeta=(await env.DB.prepare("SELECT key,value,updated_at FROM myshop_schema_meta WHERE key='content_schema'").first())||{}; } catch(e) { schemaMeta={error:String(e?.message||e).slice(0,180)}; }
  let activePushTokens=0;try{await ensureNotificationSchema(env);const pr=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_push_tokens WHERE active=1`).first();activePushTokens=Number(pr?.c||0);}catch(e){}
  const push={fcmServerConfigured:!!String(env.FCM_SERVICE_ACCOUNT_JSON||'').trim(),activePushTokens};
  return json({ok:h.ok,worker:{version:'2.9.359',build:'V-359'},health:h,push,schemaMeta,counts,time:new Date().toISOString()},h.ok?200:503,cors);
}

async function dashboardConfig(request, env) {
  let config={}; let banners=[]; let socialLinks=[]; let gallery=[]; let featureButtons=[]; let managedLinks=[]; let media=[];
  try { config=(await env.DB.prepare('SELECT * FROM dashboard_config WHERE id=1').first())||{}; } catch (_) {}
  try { banners=(await env.DB.prepare('SELECT id,folder,slot,image_url,caption,target_url,active,updated_at FROM banners WHERE active=1 ORDER BY folder,slot').all()).results||[]; } catch (_) {}
  try { socialLinks=(await env.DB.prepare('SELECT platform,url,active,icon_key,icon_url,image_url,caption FROM social_links WHERE active=1 ORDER BY platform').all()).results||[]; } catch (_) {}
  try { gallery=(await env.DB.prepare('SELECT id,title,media_url,media_type,active,display_order FROM gallery_items WHERE active=1 ORDER BY display_order,id').all()).results||[]; } catch (_) {}
  try { featureButtons=(await env.DB.prepare('SELECT key,title,icon_url,target_url,active,display_order FROM feature_buttons ORDER BY display_order,key').all()).results||[]; } catch (_) {}
  try { managedLinks=(await env.DB.prepare('SELECT id,category,title,caption,url,icon_url,image_url,active,display_order FROM managed_links ORDER BY category,display_order,id').all()).results||[]; } catch (_) {}
  try { media=(await env.DB.prepare('SELECT id,folder,title,caption,media_url,object_key,media_type,active,display_order FROM gallery_media WHERE active=1 ORDER BY folder,display_order,id').all()).results||[]; } catch (_) {}
  let dashboardAds=[];
  try { dashboardAds=(await env.DB.prepare('SELECT id,box_key,slot,image_url,caption,target_url,media_type,active,duration_sec,display_mode,updated_at FROM dashboard_ads WHERE active=1 ORDER BY box_key,slot').all()).results||[]; } catch (_) {}
  return json({ok:true,config,banners,socialLinks,gallery,featureButtons,managedLinks,media,dashboardAds},200,cors);
}

async function adminOnly(request, env) {
  const user = await getUser(request,env);
  if (!user) return {error:json({error:'ADMIN_REQUIRED'},403,cors)};
  const fixedAdmin = ['0001','0002','0003'].includes(String(user.user_id));
  if (fixedAdmin && user.role !== 'ADMIN') {
    await env.DB.prepare("UPDATE myshop_auth_users_v108 SET role='ADMIN', updated_at=CURRENT_TIMESTAMP WHERE user_id=?").bind(user.user_id).run();
    user.role = 'ADMIN';
  }
  if (user.role !== 'ADMIN') return {error:json({error:'ADMIN_REQUIRED'},403,cors)};
  return {user};
}

function safeDashboardHex(value){
  const s=String(value||'').trim().toUpperCase(); return /^#[0-9A-F]{6}$/.test(s)?s:'';
}

async function adminDashboardPut(request, env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const b = await body(request);
  await env.DB.prepare(`UPDATE dashboard_config SET breaking_news=?,my_shop_url=?,live_tv_url=?,external_movie_url=?,chat_url=?,power_ad_title=?,power_ad_byline=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`)
    .bind(String(b.breakingNews||''),String(b.myShopUrl||''),String(b.liveTvUrl||''),String(b.externalMovieUrl||''),String(b.chatUrl||''),String(b.powerAdTitle||'POWER AD').trim().slice(0,60)||'POWER AD',String(b.powerAdByline||'by Touhid').trim().slice(0,60)||'by Touhid').run();
  if(Object.prototype.hasOwnProperty.call(b,'breakingNewsTextSize')){
    const size=Math.max(10,Math.min(24,Number(b.breakingNewsTextSize)||13.0));
    await env.DB.prepare(`UPDATE dashboard_config SET breaking_news_text_size=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`).bind(size).run();
  }
  const bg=safeDashboardHex(b.dashboardBgColor),blue=safeDashboardHex(b.dashboardBlueColor),purple=safeDashboardHex(b.dashboardPurpleColor),pink=safeDashboardHex(b.dashboardPinkColor);
  if(bg&&blue&&purple&&pink){
    await env.DB.prepare(`UPDATE dashboard_config SET dashboard_bg_color=?,dashboard_blue_color=?,dashboard_purple_color=?,dashboard_pink_color=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`).bind(bg,blue,purple,pink).run();
  }
  const breakingBg=safeDashboardHex(b.breakingNewsBgColor),breakingText=safeDashboardHex(b.breakingNewsTextColor);
  if(breakingBg&&breakingText){
    await env.DB.prepare(`UPDATE dashboard_config SET breaking_news_bg_color=?,breaking_news_text_color=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`).bind(breakingBg,breakingText).run();
  }
  await createBroadcastNotification(env,'MY SHOP আপডেট','ড্যাশবোর্ডের কনটেন্ট আপডেট করা হয়েছে।');
  return json({ok:true},200,cors);
}

async function adminContentPut(request, env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const b = await body(request);

  const banners = Array.isArray(b.banners) ? b.banners : [];
  for (const x of banners) {
    const folder=String(x.folder||'').trim().toLowerCase(); const slot=Number(x.slot||0);
    if (!['hero','promo'].includes(folder) || !Number.isInteger(slot) || slot<1 || slot>(folder==='hero'?6:3)) continue;
    const imageUrl=String(x.imageUrl||x.image_url||'').trim(); const caption=String(x.caption||'').trim(); const active=x.active===false?0:1;
    if(!imageUrl){ await env.DB.prepare('DELETE FROM banners WHERE folder=? AND slot=?').bind(folder,slot).run(); continue; }
    const existingBanner=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=? LIMIT 1').bind(folder,slot).first();
    if(existingBanner?.id){ await env.DB.prepare('UPDATE banners SET image_url=?,caption=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(imageUrl,caption,active,existingBanner.id).run(); }
    else { await insertBannerCompat(env,{folder,slot,imageUrl,caption,active}); }
  }

  const social = Array.isArray(b.socialLinks) ? b.socialLinks : [];
  for (const x of social) {
    const platform=String(x.platform||'').trim(); if(!platform) continue;
    const url=String(x.url||'').trim(); const active=x.active===false?0:(url?1:0); const iconKey=String(x.iconKey||x.icon_key||platform).trim().toLowerCase().slice(0,40); const caption=String(x.caption||'').trim().slice(0,160);
    if(!url){ await env.DB.prepare('DELETE FROM social_links WHERE lower(platform)=lower(?)').bind(platform).run(); continue; }
    const existingSocial=await env.DB.prepare('SELECT id FROM social_links WHERE lower(platform)=lower(?) ORDER BY id LIMIT 1').bind(platform).first();
    if(existingSocial?.id){
      await env.DB.prepare('UPDATE social_links SET platform=?,url=?,icon_key=?,icon_url=?,image_url=?,caption=?,active=? WHERE id=?').bind(platform,url,iconKey,iconUrl,imageUrl,caption,active,existingSocial.id).run();
    } else {
      await env.DB.prepare('INSERT INTO social_links(platform,url,icon_key,icon_url,image_url,caption,active) VALUES(?,?,?,?,?,?,?)').bind(platform,url,iconKey,iconUrl,imageUrl,caption,active).run();
    }
  }

  const gallery = Array.isArray(b.gallery) ? b.gallery : [];
  for (const x of gallery) {
    const title=String(x.title||'').trim(); const mediaUrl=String(x.mediaUrl||x.media_url||'').trim(); if(!mediaUrl) continue;
    const mediaType=String(x.mediaType||x.media_type||'image').trim()||'image'; const active=x.active===false?0:1; const order=Math.max(1,Number(x.displayOrder||1));
    const existing=await env.DB.prepare('SELECT id FROM gallery_items WHERE display_order=? LIMIT 1').bind(order).first();
    if(existing) await env.DB.prepare('UPDATE gallery_items SET title=?,media_url=?,media_type=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(title,mediaUrl,mediaType,active,existing.id).run();
    else await env.DB.prepare('INSERT INTO gallery_items(title,media_url,media_type,active,display_order) VALUES(?,?,?,?,?)').bind(title,mediaUrl,mediaType,active,order).run();
  }

  const features = Array.isArray(b.featureButtons) ? b.featureButtons : [];
  for (const x of features) {
    const key=String(x.key||'').trim(); if(!key) continue;
    const title=String(x.title||'').trim(); const iconUrl=String(x.iconUrl||x.icon_url||'').trim(); const targetUrl=String(x.targetUrl||x.target_url||'').trim(); const active=x.active===false?0:1; const order=Math.max(1,Number(x.displayOrder||1));
    const existingFeature=await env.DB.prepare('SELECT key FROM feature_buttons WHERE key=? LIMIT 1').bind(key).first();
    if(existingFeature?.key){
      await env.DB.prepare('UPDATE feature_buttons SET title=?,icon_url=?,target_url=?,active=?,display_order=?,updated_at=CURRENT_TIMESTAMP WHERE key=?').bind(title,iconUrl,targetUrl,active,order,key).run();
    } else {
      await env.DB.prepare('INSERT INTO feature_buttons(key,title,icon_url,target_url,active,display_order,updated_at) VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)').bind(key,title,iconUrl,targetUrl,active,order).run();
    }
  }

  // Explicit deletes for content records. User/auth tables are never touched.
  for (const x of (Array.isArray(b.deleteBanners)?b.deleteBanners:[])) {
    const folder=String(x.folder||'').trim().toLowerCase(); const slot=Number(x.slot||0);
    if(['hero','promo'].includes(folder) && Number.isInteger(slot)) await env.DB.prepare('DELETE FROM banners WHERE folder=? AND slot=?').bind(folder,slot).run();
  }
  for (const platform of (Array.isArray(b.deleteSocialPlatforms)?b.deleteSocialPlatforms:[])) {
    await env.DB.prepare('DELETE FROM social_links WHERE platform=?').bind(String(platform||'').trim()).run();
  }
  for (const key of (Array.isArray(b.deleteFeatureKeys)?b.deleteFeatureKeys:[])) {
    await env.DB.prepare('UPDATE feature_buttons SET active=0,updated_at=CURRENT_TIMESTAMP WHERE key=?').bind(String(key||'').trim()).run();
  }
  const links = Array.isArray(b.managedLinks) ? b.managedLinks : [];
  for (const x of links) {
    const id=Number(x.id||0); const category=String(x.category||'').trim().toLowerCase(); const title=String(x.title||'').trim(); const caption=String(x.caption||'').trim(); const url=String(x.url||'').trim(); const iconUrl=String(x.iconUrl||x.icon_url||'').trim(); const imageUrl=String(x.imageUrl||x.image_url||'').trim(); const active=x.active===false?0:1; const order=Math.max(1,Number(x.displayOrder||1));
    if(!category) continue;
    if(id>0) await env.DB.prepare('UPDATE managed_links SET category=?,title=?,caption=?,url=?,icon_url=?,image_url=?,active=?,display_order=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(category,title,caption,url,iconUrl,imageUrl,active,order,id).run();
    else await env.DB.prepare('INSERT INTO managed_links(category,title,caption,url,icon_url,image_url,active,display_order,updated_at) VALUES(?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)').bind(category,title,caption,url,iconUrl,imageUrl,active,order).run();
  }
  for (const id of (Array.isArray(b.deleteManagedLinkIds)?b.deleteManagedLinkIds:[])) await env.DB.prepare('DELETE FROM managed_links WHERE id=?').bind(Number(id)).run();

  await createBroadcastNotification(env,'MY SHOP আপডেট','ব্যানার, সোশ্যাল বা ফিচার কনটেন্টে নতুন পরিবর্তন এসেছে।');
  return json({ok:true},200,cors);
}

async function adminBannerUpload(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  if(!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(); const folder=String(form.get('folder')||'').trim().toLowerCase(); const slot=Number(form.get('slot')||0); const file=form.get('file'); const caption=String(form.get('caption')||'').trim(); const targetUrl=String(form.get('targetUrl')||'').trim().slice(0,1000);
  const bannerMax=folder==='promo'?3:6; if(!['hero','promo','live_home'].includes(folder) || !Number.isInteger(slot) || slot<1 || slot>bannerMax || !(file instanceof File)) return json({error:'INVALID_BANNER'},400,cors);
  const bannerType=guessContentType(file);
  if(!bannerType.startsWith('image/')) return json({error:'BANNER_MUST_BE_IMAGE'},400,cors);
  if(file.size>15*1024*1024) return json({error:'BANNER_TOO_LARGE'},413,cors);
  const old=await env.DB.prepare('SELECT id,object_key FROM banner_media WHERE folder=? AND slot=? LIMIT 1').bind(folder,slot).first();
  // Safety: never delete the currently working banner until the new object and D1 rows are committed.
  const oldKey=old?.object_key||'';
  const ext=(String(file.name||'jpg').split('.').pop()||'jpg').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'jpg';
  const key=`banners/${folder}/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  try {
    await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:bannerType||'application/octet-stream',cacheControl:'public, max-age=31536000'}});
  } catch (e) {
    return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);
  }
  const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  try {
    // Backward-compatible write path: some existing D1 databases may have been created
    // before the UNIQUE(folder,slot) constraint existed. Do not depend on ON CONFLICT.
    const existingBanner=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=? LIMIT 1').bind(folder,slot).first();
    if(existingBanner?.id){
      await env.DB.prepare('UPDATE banners SET image_url=?,caption=?,target_url=?,active=1,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(url,caption,targetUrl,existingBanner.id).run();
    } else {
      await insertBannerCompat(env,{folder,slot,imageUrl:url,caption,active:1}); await env.DB.prepare('UPDATE banners SET target_url=? WHERE folder=? AND slot=?').bind(targetUrl,folder,slot).run();
    }
    const existingMedia=await env.DB.prepare('SELECT id FROM banner_media WHERE folder=? AND slot=? LIMIT 1').bind(folder,slot).first();
    if(existingMedia?.id){
      await env.DB.prepare('UPDATE banner_media SET object_key=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(key,existingMedia.id).run();
    } else {
      await env.DB.prepare('INSERT INTO banner_media(folder,slot,object_key,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP)').bind(folder,slot,key).run();
    }
  } catch(e) {
    try { await env.MEDIA.delete(key); } catch(_) {}
    return json({error:'BANNER_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors);
  }
  if(oldKey && oldKey!==key){ try { await env.MEDIA.delete(oldKey); } catch(_) {} }
  await createBroadcastNotification(env,'নতুন ব্যানার','MY SHOP-এ নতুন ব্যানার আপডেট হয়েছে।');
  return json({ok:true,folder,slot,image_url:url,caption,targetUrl},201,cors);
}

async function adminBannerUpdate(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const b=await body(request); const folder=String(b.folder||'').trim().toLowerCase(); const slot=Number(b.slot||0); const caption=String(b.caption||'').trim(); const targetUrl=String(b.targetUrl||'').trim().slice(0,1000); const hasActive=Object.prototype.hasOwnProperty.call(b,'active'); const active=hasActive?(b.active===false?0:1):null;
  const bannerMax=folder==='promo'?3:6; if(!['hero','promo','live_home'].includes(folder)||!Number.isInteger(slot)||slot<1||slot>bannerMax) return json({error:'INVALID_BANNER'},400,cors);
  const row=await env.DB.prepare('SELECT id FROM banners WHERE folder=? AND slot=?').bind(folder,slot).first();
  if(!row) return json({error:'BANNER_NOT_FOUND'},404,cors);
  if(hasActive) await env.DB.prepare('UPDATE banners SET caption=?,target_url=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE folder=? AND slot=?').bind(caption,targetUrl,active,folder,slot).run(); else await env.DB.prepare('UPDATE banners SET caption=?,target_url=?,updated_at=CURRENT_TIMESTAMP WHERE folder=? AND slot=?').bind(caption,targetUrl,folder,slot).run();
  await createBroadcastNotification(env,'ব্যানার আপডেট','একটি ব্যানারের ক্যাপশন আপডেট হয়েছে।');
  return json({ok:true,folder,slot,caption,targetUrl},200,cors);
}

async function adminBannerDelete(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error; const b=await body(request); const folder=String(b.folder||'').trim().toLowerCase(); const slot=Number(b.slot||0); const bannerMax=folder==='promo'?3:6; if(!['hero','promo','live_home'].includes(folder)||!Number.isInteger(slot)||slot<1||slot>bannerMax) return json({error:'INVALID_BANNER'},400,cors);
  const old=await env.DB.prepare('SELECT object_key FROM banner_media WHERE folder=? AND slot=?').bind(folder,slot).first(); if(old?.object_key&&env.MEDIA) await env.MEDIA.delete(old.object_key);
  await env.DB.prepare('DELETE FROM banner_media WHERE folder=? AND slot=?').bind(folder,slot).run(); await env.DB.prepare('DELETE FROM banners WHERE folder=? AND slot=?').bind(folder,slot).run(); await createBroadcastNotification(env,'ব্যানার আপডেট','একটি ব্যানার সরানো হয়েছে।'); return json({ok:true},200,cors);
}


async function adminLiveHomeBanners(request,env){
  try { await ensureSchemasOnce(env); } catch (_) {}
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const rows=(await env.DB.prepare(`SELECT id,folder,slot,image_url,caption,target_url,active,updated_at FROM banners WHERE folder='live_home' AND slot BETWEEN 1 AND 6 ORDER BY slot`).all()).results||[];
  return json({ok:true,banners:rows},200,cors);
}

async function adminMediaList(request,env) {
  try { await ensureSchemasOnce(env); } catch (_) {}
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const folder=safeMediaFolder(new URL(request.url).searchParams.get('folder')||'');
  const sql=folder
    ? 'SELECT id,folder,title,caption,media_url,object_key,media_type,active,display_order FROM gallery_media WHERE folder=? ORDER BY display_order,id'
    : 'SELECT id,folder,title,caption,media_url,object_key,media_type,active,display_order FROM gallery_media ORDER BY folder,display_order,id';
  const rows=folder ? await env.DB.prepare(sql).bind(folder).all() : await env.DB.prepare(sql).all();
  return json({ok:true,folder:folder||'all',media:rows.results||[]},200,cors);
}

function safeMediaFolder(v){ const f=String(v||'').trim().toLowerCase(); return ['photo','audio','video'].includes(f)?f:''; }
function safeKeyPart(v){ return String(v||'').replace(/[^a-zA-Z0-9._-]/g,'_').slice(0,120); }

async function adminMediaUpload(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  if(!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(); const file=form.get('file'); const folder=safeMediaFolder(form.get('folder'));
  if(!(file instanceof File) || !folder) return json({error:'INVALID_MEDIA'},400,cors);
  const contentType=guessContentType(file);
  const allowed=folder==='photo'?contentType.startsWith('image/'):folder==='audio'?contentType.startsWith('audio/'):contentType.startsWith('video/');
  if(!allowed) return json({error:'MEDIA_TYPE_MISMATCH'},400,cors);
  if(file.size>50*1024*1024) return json({error:'MEDIA_TOO_LARGE'},413,cors);
  const title=String(form.get('title')||'').trim(); const caption=String(form.get('caption')||'').trim(); const targetUrl=String(form.get('targetUrl')||'').trim().slice(0,1000); const order=Math.max(1,Number(form.get('displayOrder')||1));
  const ext=(String(file.name||'bin').split('.').pop()||'bin').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'bin';
  const key=`gallery/${folder}/${Date.now()}-${crypto.randomUUID().slice(0,8)}-${safeKeyPart(file.name||'media')}.${ext}`;
  try {
    await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType,cacheControl:'public, max-age=31536000'}});
  } catch (e) {
    return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);
  }
  const mediaUrl=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  let r;
  try { r=await env.DB.prepare('INSERT INTO gallery_media(folder,title,caption,media_url,object_key,media_type,active,display_order) VALUES(?,?,?,?,?,?,1,?)').bind(folder,title,caption,mediaUrl,key,contentType,order).run(); }
  catch(e){ try{await env.MEDIA.delete(key);}catch(_){} return json({error:'GALLERY_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,220)},500,cors); }
  await createBroadcastNotification(env,'গ্যালারি আপডেট','গ্যালারিতে নতুন মিডিয়া যোগ হয়েছে।');
  return json({ok:true,id:r.meta?.last_row_id||null,folder,title,caption,media_url:mediaUrl,object_key:key,media_type:contentType,display_order:order},201,cors);
}

async function adminMediaUpdate(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const b=await body(request); const id=Number(b.id||0); const title=String(b.title||'').trim(); const caption=String(b.caption||'').trim();
  if(!id) return json({error:'INVALID_MEDIA_ID'},400,cors);
  const row=await env.DB.prepare('SELECT id FROM gallery_media WHERE id=?').bind(id).first();
  if(!row) return json({error:'MEDIA_NOT_FOUND'},404,cors);
  await env.DB.prepare('UPDATE gallery_media SET title=?,caption=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(title,caption,id).run();
  await createBroadcastNotification(env,'গ্যালারি আপডেট','গ্যালারির একটি আইটেম সম্পাদনা করা হয়েছে।');
  return json({ok:true,id,title,caption},200,cors);
}

async function adminMediaDelete(request,env) {
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error) return auth.error;
  const b=await body(request); const id=Number(b.id||0); if(!id) return json({error:'INVALID_MEDIA_ID'},400,cors);
  const row=await env.DB.prepare('SELECT object_key FROM gallery_media WHERE id=?').bind(id).first(); if(!row) return json({error:'MEDIA_NOT_FOUND'},404,cors);
  if(env.MEDIA && row.object_key) await env.MEDIA.delete(row.object_key);
  await env.DB.prepare('DELETE FROM gallery_media WHERE id=?').bind(id).run();
  await createBroadcastNotification(env,'গ্যালারি আপডেট','গ্যালারি থেকে একটি মিডিয়া সরানো হয়েছে।');
  return json({ok:true},200,cors);
}



async function userGalleryList(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  const folder=safeMediaFolder(new URL(request.url).searchParams.get('folder')||'');
  if (!folder) return json({error:'INVALID_GALLERY_FOLDER'},400,cors);
  const rows=(await env.DB.prepare(`SELECT id,folder,title,caption,media_url,object_key,media_type,active,display_order,owner_user_id,updated_at FROM gallery_media WHERE active=1 AND folder=? AND (owner_user_id IS NULL OR owner_user_id=?) ORDER BY id DESC`).bind(folder,user.user_id).all()).results||[];
  return json({ok:true,folder,media:rows},200,cors);
}

async function userGalleryUpload(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!isAdminUser(user)) return json({error:'GALLERY_ADMIN_ONLY'},403,cors);
  if (!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(); const file=form.get('file'); const folder=safeMediaFolder(form.get('folder'));
  if (!(file instanceof File) || !folder) return json({error:'INVALID_MEDIA'},400,cors);
  const contentType=guessContentType(file);
  const allowed=folder==='photo'?contentType.startsWith('image/'):folder==='audio'?contentType.startsWith('audio/'):contentType.startsWith('video/');
  if(!allowed) return json({error:'MEDIA_TYPE_MISMATCH'},400,cors);
  // No item-count cap. Each individual object is limited to 50 MB; R2/account quota still applies.
  if(Number(file.size||0)>50*1024*1024) return json({error:'MEDIA_TOO_LARGE'},413,cors);
  const title=String(form.get('title')||'').trim().slice(0,160);
  const caption=String(form.get('caption')||'').trim().slice(0,1000);
  const ext=(String(file.name||'media').split('.').pop()||'bin').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'bin';
  const key=`gallery/users/${user.user_id}/${folder}/${Date.now()}-${crypto.randomUUID().slice(0,8)}-${safeKeyPart(file.name||'media')}.${ext}`;
  try { await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType,cacheControl:'public, max-age=31536000'}}); }
  catch(e){ return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
  const mediaUrl=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  try {
    const r=await env.DB.prepare(`INSERT INTO gallery_media(folder,title,caption,media_url,object_key,media_type,active,display_order,owner_user_id) VALUES(?,?,?,?,?,?,1,?,?)`).bind(folder,title,caption,mediaUrl,key,contentType,1,user.user_id).run();
    await createBroadcastNotification(env,'গ্যালারি আপডেট','একটি নতুন ইউজার গ্যালারি মিডিয়া যোগ হয়েছে।');
    return json({ok:true,id:r.meta?.last_row_id||null,folder,title,caption,media_url:mediaUrl,object_key:key,media_type:contentType,owner_user_id:user.user_id},201,cors);
  } catch(e){ try{await env.MEDIA.delete(key);}catch(_){} return json({error:'GALLERY_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors); }
}

async function userGalleryUpdate(request, env) {
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!isAdminUser(user)) return json({error:'GALLERY_ADMIN_ONLY'},403,cors);
  const b=await body(request); const id=Number(b.id||0); const title=String(b.title||'').trim().slice(0,160); const caption=String(b.caption||'').trim().slice(0,1000);
  if(!id) return json({error:'INVALID_MEDIA_ID'},400,cors);
  const row=await env.DB.prepare('SELECT id FROM gallery_media WHERE id=? AND owner_user_id=?').bind(id,user.user_id).first();
  if(!row) return json({error:'MEDIA_NOT_FOUND'},404,cors);
  await env.DB.prepare('UPDATE gallery_media SET title=?,caption=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND owner_user_id=?').bind(title,caption,id,user.user_id).run();
  return json({ok:true,id,title,caption},200,cors);
}

async function userGalleryDelete(request, env) {
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!isAdminUser(user)) return json({error:'GALLERY_ADMIN_ONLY'},403,cors);
  const b=await body(request); const id=Number(b.id||0); if(!id) return json({error:'INVALID_MEDIA_ID'},400,cors);
  const row=await env.DB.prepare('SELECT object_key FROM gallery_media WHERE id=? AND owner_user_id=?').bind(id,user.user_id).first();
  if(!row) return json({error:'MEDIA_NOT_FOUND'},404,cors);
  if(env.MEDIA && row.object_key) { try{await env.MEDIA.delete(row.object_key);}catch(_){} }
  await env.DB.prepare('DELETE FROM gallery_media WHERE id=? AND owner_user_id=?').bind(id,user.user_id).run();
  return json({ok:true},200,cors);
}


function isAdminUser(user) { return !!user && String(user.role || '').toUpperCase() === 'ADMIN'; }
function isModeratorUser(user) { return !!user && ['MODERATOR','ADMIN'].includes(String(user.role || '').toUpperCase()); }

async function feedList(request, env) {
  await ensureLevelSchema(env);
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  const url = new URL(request.url);
  const limit = Math.min(10, Math.max(1, Number(url.searchParams.get('limit') || 5)));
  const before = Math.max(0, Number(url.searchParams.get('before') || 0));
  const sql = before > 0
    ? `SELECT p.id,p.user_id,p.caption,p.media_url,p.object_key,p.media_type,p.created_at,u.full_name,u.avatar_url,
          (CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=p.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=p.user_id),0)) AS level,
          (SELECT COUNT(*) FROM myshop_post_likes l WHERE l.post_id=p.id AND datetime(l.created_at)>=datetime('now','-24 hours')) AS like_count,
          (SELECT COUNT(*) FROM myshop_post_comments c WHERE c.post_id=p.id) AS comment_count,
          EXISTS(SELECT 1 FROM myshop_post_likes ml WHERE ml.post_id=p.id AND ml.user_id=?) AS liked
       FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id
       WHERE p.status='ACTIVE' AND p.id<? AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=p.user_id) OR (b.blocker_id=p.user_id AND b.blocked_id=?)) ORDER BY p.id DESC LIMIT ?`
    : `SELECT p.id,p.user_id,p.caption,p.media_url,p.object_key,p.media_type,p.created_at,u.full_name,u.avatar_url,
          (CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=p.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=p.user_id),0)) AS level,
          (SELECT COUNT(*) FROM myshop_post_likes l WHERE l.post_id=p.id AND datetime(l.created_at)>=datetime('now','-24 hours')) AS like_count,
          (SELECT COUNT(*) FROM myshop_post_comments c WHERE c.post_id=p.id) AS comment_count,
          EXISTS(SELECT 1 FROM myshop_post_likes ml WHERE ml.post_id=p.id AND ml.user_id=?) AS liked
       FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id
       WHERE p.status='ACTIVE' AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=p.user_id) OR (b.blocker_id=p.user_id AND b.blocked_id=?)) ORDER BY p.id DESC LIMIT ?`;
  const rows = before > 0
    ? (await env.DB.prepare(sql).bind(user.user_id,before,user.user_id,user.user_id,limit).all()).results || []
    : (await env.DB.prepare(sql).bind(user.user_id,user.user_id,user.user_id,limit).all()).results || [];
  const today = await env.DB.prepare(`SELECT COUNT(*) AS c FROM myshop_posts WHERE user_id=? AND date(created_at)=date('now')`).bind(user.user_id).first();
  const canPost = isAdminUser(user) || Number(today?.c || 0) < 1;
  return json({ok:true,posts:rows.map(x=>({id:x.id,userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',level:Math.max(0,Number(x.level||0)),caption:x.caption||'',mediaUrl:x.media_url||'',mediaType:x.media_type||'image',createdAt:x.created_at||'',likeCount:Number(x.like_count||0),commentCount:Number(x.comment_count||0),liked:Boolean(x.liked)})),nextBefore:rows.length?Number(rows[rows.length-1].id):null,hasMore:rows.length===limit,canPost,role:user.role,postsToday:Number(today?.c||0)},200,cors);
}

async function feedPost(request, env) {
  await ensureLevelSchema(env);
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const id=Number(new URL(request.url).searchParams.get('id')||0); if(!Number.isInteger(id)||id<=0)return json({error:'INVALID_POST_ID'},400,cors);
  const x=await env.DB.prepare(`SELECT p.id,p.user_id,p.caption,p.media_url,p.object_key,p.media_type,p.created_at,u.full_name,u.avatar_url,
      (CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=p.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=p.user_id),0)) AS level,
      (SELECT COUNT(*) FROM myshop_post_likes l WHERE l.post_id=p.id AND datetime(l.created_at)>=datetime('now','-24 hours')) AS like_count,
      (SELECT COUNT(*) FROM myshop_post_comments c WHERE c.post_id=p.id) AS comment_count,
      EXISTS(SELECT 1 FROM myshop_post_likes ml WHERE ml.post_id=p.id AND ml.user_id=?) AS liked
    FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id WHERE p.status='ACTIVE' AND p.id=? AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=p.user_id) OR (b.blocker_id=p.user_id AND b.blocked_id=?)) LIMIT 1`).bind(user.user_id,id,user.user_id,user.user_id).first();
  if(!x)return json({error:'POST_NOT_FOUND'},404,cors);
  return json({ok:true,post:{id:x.id,userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',level:Math.max(0,Number(x.level||0)),caption:x.caption||'',mediaUrl:x.media_url||'',mediaType:x.media_type||'image',createdAt:x.created_at||'',likeCount:Number(x.like_count||0),commentCount:Number(x.comment_count||0),liked:Boolean(x.liked)}},200,cors);
}

async function videoList(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const url=new URL(request.url),limit=Math.max(1,Math.min(30,Number(url.searchParams.get('limit')||15))),before=Math.max(0,Number(url.searchParams.get('before')||0));
  const sql=before>0
    ? `SELECT p.id,p.user_id,p.caption,p.media_url,p.created_at,u.full_name,u.avatar_url,
        (SELECT COUNT(*) FROM myshop_post_likes l WHERE l.post_id=p.id AND datetime(l.created_at)>=datetime('now','-24 hours')) like_count,
        (SELECT COUNT(*) FROM myshop_post_comments c WHERE c.post_id=p.id) comment_count,
        EXISTS(SELECT 1 FROM myshop_post_likes ml WHERE ml.post_id=p.id AND ml.user_id=?) liked
       FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id WHERE p.status='ACTIVE' AND p.media_type='video' AND p.id<? AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=p.user_id) OR (b.blocker_id=p.user_id AND b.blocked_id=?)) ORDER BY p.id DESC LIMIT ?`
    : `SELECT p.id,p.user_id,p.caption,p.media_url,p.created_at,u.full_name,u.avatar_url,
        (SELECT COUNT(*) FROM myshop_post_likes l WHERE l.post_id=p.id AND datetime(l.created_at)>=datetime('now','-24 hours')) like_count,
        (SELECT COUNT(*) FROM myshop_post_comments c WHERE c.post_id=p.id) comment_count,
        EXISTS(SELECT 1 FROM myshop_post_likes ml WHERE ml.post_id=p.id AND ml.user_id=?) liked
       FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id WHERE p.status='ACTIVE' AND p.media_type='video' AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=p.user_id) OR (b.blocker_id=p.user_id AND b.blocked_id=?)) ORDER BY p.id DESC LIMIT ?`;
  const rows=before>0?(await env.DB.prepare(sql).bind(user.user_id,before,user.user_id,user.user_id,limit).all()).results||[]:(await env.DB.prepare(sql).bind(user.user_id,user.user_id,user.user_id,limit).all()).results||[];
  return json({ok:true,videos:rows.map(x=>({id:x.id,userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',caption:x.caption||'',mediaUrl:x.media_url||'',mediaType:'video',createdAt:x.created_at||'',likeCount:Number(x.like_count||0),commentCount:Number(x.comment_count||0),liked:Boolean(x.liked)})),nextBefore:rows.length?Number(rows[rows.length-1].id):0,hasMore:rows.length===limit},200,cors);
}

async function feedUpload(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  try { await ensureSchemasOnce(env); } catch (_) {}
  if (!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const isAdmin = isAdminUser(user);
  const form = await request.formData();
  const file = form.get('file');
  if (!(file instanceof File)) return json({error:'FILE_REQUIRED'},400,cors);
  const contentType = guessContentType(file);
  if (!contentType || contentType === 'application/octet-stream') { return json({error:'POST_MEDIA_TYPE_MISMATCH',message:'The selected file type could not be identified as image/video.'},400,cors); }
  const requestedType = String(form.get('mediaType') || '').trim().toLowerCase();
  const mediaType = requestedType || (contentType.startsWith('video/') ? 'video' : 'image');
  const allowed = mediaType === 'image' ? contentType.startsWith('image/') : mediaType === 'video' ? contentType.startsWith('video/') : false;
  if (!allowed) return json({error:'POST_MEDIA_TYPE_MISMATCH'},400,cors);
  const maxBytes = isAdmin ? 50*1024*1024 : (mediaType==='video' ? 20*1024*1024 : 5*1024*1024);
  if (Number(file.size||0) > maxBytes) return json({error:isAdmin?'POST_MEDIA_TOO_LARGE':'USER_POST_TOO_LARGE'},413,cors);
  const caption = String(form.get('caption') || '').trim().slice(0,1000);
  if (!isAdmin && !caption) return json({error:'POST_CAPTION_REQUIRED'},400,cors);
  if (!isAdmin) {
    const today = await env.DB.prepare(`SELECT COUNT(*) AS c FROM myshop_posts WHERE user_id=? AND date(created_at)=date('now')`).bind(user.user_id).first();
    if (Number(today?.c||0) >= 1) return json({error:'DAILY_POST_LIMIT',message:'সাধারণ User প্রতিদিন সর্বোচ্চ ১টি পোস্ট করতে পারবে।'},429,cors);
  }
  const ext=(String(file.name||'media').split('.').pop()||'bin').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'bin';
  const key=`posts/${user.user_id}/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  try { await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType,cacheControl:'public, max-age=86400'}}); }
  catch(e) { return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
  const mediaUrl=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  try {
    const r=await env.DB.prepare(`INSERT INTO myshop_posts(user_id,caption,media_url,object_key,media_type,status) VALUES(?,?,?,?,?,'ACTIVE')`).bind(user.user_id,caption,mediaUrl,key,mediaType).run();
    await createBroadcastNotification(env,'MY SHOP Feed','নতুন একটি পোস্ট Feed-এ যোগ হয়েছে।');
    return json({ok:true,id:r.meta?.last_row_id||null,post:{id:r.meta?.last_row_id||null,userId:user.user_id,name:user.full_name||'',avatarUrl:user.avatar_url||'',caption,mediaUrl,mediaType}},201,cors);
  } catch(e) { try { await env.MEDIA.delete(key); } catch (_) {} return json({error:'POST_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors); }
}

async function feedText(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  try { await ensureSchemasOnce(env); } catch (_) {}
  const b=await body(request); const caption=String(b.caption||'').trim().slice(0,1000);
  if(!caption) return json({error:'POST_CAPTION_REQUIRED'},400,cors);
  const isAdmin=isAdminUser(user);
  if(!isAdmin){
    const today=await env.DB.prepare(`SELECT COUNT(*) AS c FROM myshop_posts WHERE user_id=? AND date(created_at)=date('now')`).bind(user.user_id).first();
    if(Number(today?.c||0)>=1)return json({error:'DAILY_POST_LIMIT',message:'সাধারণ User প্রতিদিন সর্বোচ্চ ১টি পোস্ট করতে পারবে।'},429,cors);
  }
  try{
    const r=await env.DB.prepare(`INSERT INTO myshop_posts(user_id,caption,media_url,object_key,media_type,status) VALUES(?,?,'','','text','ACTIVE')`).bind(user.user_id,caption).run();
    await createBroadcastNotification(env,'MY SHOP Feed','নতুন একটি text post Feed-এ যোগ হয়েছে।');
    return json({ok:true,id:r.meta?.last_row_id||null,post:{id:r.meta?.last_row_id||null,userId:user.user_id,name:user.full_name||'',avatarUrl:user.avatar_url||'',caption,mediaUrl:'',mediaType:'text'}},201,cors);
  }catch(e){return json({error:'POST_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,180)},500,cors);}
}

async function feedLike(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request); const id=Number(b.postId||0); if(!Number.isInteger(id)||id<=0)return json({error:'INVALID_POST_ID'},400,cors);
  const post=await env.DB.prepare(`SELECT id,user_id,caption FROM myshop_posts WHERE id=? AND status='ACTIVE'`).bind(id).first(); if(!post)return json({error:'POST_NOT_FOUND'},404,cors); if(post.user_id!==user.user_id && await safetyIsBlocked(env,user.user_id,post.user_id))return json({error:'BLOCKED_USER'},403,cors);
  const exists=await env.DB.prepare('SELECT post_id FROM myshop_post_likes WHERE post_id=? AND user_id=?').bind(id,user.user_id).first();
  if(exists){await env.DB.prepare('DELETE FROM myshop_post_likes WHERE post_id=? AND user_id=?').bind(id,user.user_id).run(); const c=await env.DB.prepare(`SELECT COUNT(*) AS c FROM myshop_post_likes WHERE post_id=? AND datetime(created_at)>=datetime('now','-24 hours')`).bind(id).first(); return json({ok:true,liked:false,likeCount:Number(c?.c||0)},200,cors);}
  await env.DB.prepare('INSERT OR IGNORE INTO myshop_post_likes(post_id,user_id) VALUES(?,?)').bind(id,user.user_id).run();
  if(post.user_id!==user.user_id){const actor=await env.DB.prepare('SELECT full_name FROM myshop_auth_users_v108 WHERE user_id=? LIMIT 1').bind(user.user_id).first();const actorName=String(actor?.full_name||('User ID '+user.user_id));await createUserNotification(env,post.user_id,'❤️ New Like',actorName+' liked your post'+(post.caption?': '+String(post.caption).slice(0,90):'.'),'LIKE',user.user_id,String(id));}
  const c=await env.DB.prepare(`SELECT COUNT(*) AS c FROM myshop_post_likes WHERE post_id=? AND datetime(created_at)>=datetime('now','-24 hours')`).bind(id).first(); return json({ok:true,liked:true,likeCount:Number(c?.c||0)},200,cors);
}

async function feedComments(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const postId=Number(new URL(request.url).searchParams.get('postId')||0); if(!Number.isInteger(postId)||postId<=0)return json({error:'INVALID_POST_ID'},400,cors);
  const post=await env.DB.prepare(`SELECT id,user_id FROM myshop_posts WHERE id=? AND status='ACTIVE'`).bind(postId).first(); if(!post)return json({error:'POST_NOT_FOUND'},404,cors); if(post.user_id!==user.user_id && await safetyIsBlocked(env,user.user_id,post.user_id))return json({error:'BLOCKED_USER'},403,cors);
  const rows=(await env.DB.prepare(`SELECT c.id,c.user_id,c.comment,c.created_at,u.full_name,u.avatar_url FROM myshop_post_comments c LEFT JOIN myshop_auth_users_v108 u ON u.user_id=c.user_id WHERE c.post_id=? AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=c.user_id) OR (b.blocker_id=c.user_id AND b.blocked_id=?)) ORDER BY c.id ASC LIMIT 200`).bind(postId,user.user_id,user.user_id).all()).results||[];
  return json({ok:true,comments:rows.map(x=>({id:x.id,userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',comment:x.comment||'',createdAt:x.created_at||''})),commentCount:rows.length},200,cors);
}

async function feedComment(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  try { await ensureSchemasOnce(env); } catch (_) {}
  const b=await body(request); const id=Number(b.postId||0); const comment=String(b.comment||'').trim().slice(0,1000);
  if(!Number.isInteger(id)||id<=0||!comment)return json({error:'INVALID_COMMENT'},400,cors);
  try {
    const post=await env.DB.prepare(`SELECT id,user_id FROM myshop_posts WHERE id=? AND status='ACTIVE'`).bind(id).first(); if(!post)return json({error:'POST_NOT_FOUND'},404,cors); if(post.user_id!==user.user_id && await safetyIsBlocked(env,user.user_id,post.user_id))return json({error:'BLOCKED_USER'},403,cors);
    await env.DB.prepare('INSERT INTO myshop_post_comments(post_id,user_id,comment) VALUES(?,?,?)').bind(id,user.user_id,comment).run();
    if(post.user_id!==user.user_id){const actor=await env.DB.prepare('SELECT full_name FROM myshop_auth_users_v108 WHERE user_id=? LIMIT 1').bind(user.user_id).first();const actorName=String(actor?.full_name||('User ID '+user.user_id));await createUserNotification(env,post.user_id,'💬 New Comment',actorName+' commented on your post: '+comment.slice(0,120),'COMMENT',user.user_id,String(id));}
    const c=await env.DB.prepare('SELECT COUNT(*) AS c FROM myshop_post_comments WHERE post_id=?').bind(id).first(); return json({ok:true,commentCount:Number(c?.c||0)},201,cors);
  } catch(e) { console.error('FEED_COMMENT_FAILED',String(e?.message||e)); return json({error:'COMMENT_SERVER_ERROR',message:'Comment could not be saved. Please retry.'},503,cors); }
}

async function feedDeleteOwn(request, env) {
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request); const id=Number(b.id||0); if(!id)return json({error:'INVALID_POST_ID'},400,cors);
  const row=await env.DB.prepare(`SELECT object_key FROM myshop_posts WHERE id=? AND user_id=? AND status='ACTIVE'`).bind(id,user.user_id).first();
  if(!row)return json({error:'POST_NOT_FOUND'},404,cors);
  if(env.MEDIA&&row.object_key){try{await env.MEDIA.delete(row.object_key);}catch(_){} }
  await env.DB.prepare(`UPDATE myshop_posts SET status='REMOVED',moderated_by=?,moderated_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=?`).bind(user.user_id,id,user.user_id).run();
  return json({ok:true},200,cors);
}

async function adminFeedList(request,env) {
  const auth=await adminOnly(request,env); if(auth.error)return auth.error;
  try{await ensureSchemasOnce(env);}catch(_){ }
  const rows=(await env.DB.prepare(`SELECT p.id,p.user_id,p.caption,p.media_url,p.media_type,p.status,p.created_at,p.moderated_by,p.moderated_at,u.full_name,u.avatar_url FROM myshop_posts p JOIN myshop_auth_users_v108 u ON u.user_id=p.user_id ORDER BY p.id DESC LIMIT 100`).all()).results||[];
  return json({ok:true,posts:rows},200,cors);
}

async function moderatorFeedDelete(request,env) {
  const user=await getUser(request,env);
  if(!user || !isModeratorUser(user)) return json({error:'MODERATOR_REQUIRED'},403,cors);
  try{await ensureSchemasOnce(env);}catch(_){ }
  const b=await body(request); const id=Number(b.id||0); const reason=String(b.reason||'').trim().slice(0,300);
  if(!id)return json({error:'INVALID_POST_ID'},400,cors);
  const row=await env.DB.prepare(`SELECT object_key,status FROM myshop_posts WHERE id=?`).bind(id).first();
  if(!row)return json({error:'POST_NOT_FOUND'},404,cors);
  if(env.MEDIA&&row.object_key){try{await env.MEDIA.delete(row.object_key);}catch(_){} }
  await env.DB.prepare(`UPDATE myshop_posts SET status='REMOVED',moderated_by=?,moderated_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(user.user_id,id).run();
  return json({ok:true,removedBy:user.user_id,reason},200,cors);
}

async function adminAdsList(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error;
  const box=String(new URL(request.url).searchParams.get('box_key')||'').trim().toLowerCase();
  const rows=box?await env.DB.prepare('SELECT id,box_key,slot,image_url,caption,target_url,object_key,media_type,active,duration_sec,display_mode,updated_at FROM dashboard_ads WHERE box_key=? ORDER BY slot').bind(box).all():await env.DB.prepare('SELECT id,box_key,slot,image_url,caption,target_url,object_key,media_type,active,duration_sec,display_mode,updated_at FROM dashboard_ads ORDER BY box_key,slot').all();
  return json({ok:true,ads:rows.results||[]},200,cors);
}

async function adminAdUpload(request,env){
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error)return auth.error;
  if(!env.MEDIA)return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(); const file=form.get('file'); const box=String(form.get('boxKey')||'').trim().toLowerCase().replace(/[^a-z0-9_-]/g,'_').slice(0,60); const slot=Number(form.get('slot')||0); const caption=String(form.get('caption')||'').trim().slice(0,300); const target=String(form.get('targetUrl')||'').trim().slice(0,500); const active=String(form.get('active')||'true').toLowerCase()!=='false'?1:0; const requestedDuration=Number(form.get('durationSec')||3); const duration=box==='startup_ad'?Math.max(1,Math.min(4,requestedDuration)):Math.max(1,Math.min(60,requestedDuration)); const dm=String(form.get('displayMode')||'FULL_IMAGE').toUpperCase(); const displayMode=(dm==='FILL_SCREEN'?'FILL_SCREEN':'FULL_IMAGE');
  if(!(file instanceof File)||!box||!Number.isInteger(slot)||slot<1||slot>6)return json({error:'INVALID_AD'},400,cors);
  const mime=String(file.type||'').toLowerCase(); const mediaType=mime.startsWith('video/')?'video':(mime.startsWith('image/')?'image':'');
  if(!mediaType)return json({error:'AD_MUST_BE_IMAGE_OR_VIDEO'},400,cors);
  const maxBytes=mediaType==='video'?60*1024*1024:15*1024*1024; if(file.size>maxBytes)return json({error:'AD_TOO_LARGE'},413,cors);
  const old=await env.DB.prepare('SELECT object_key FROM dashboard_ads WHERE box_key=? AND slot=?').bind(box,slot).first(); const oldKey=old?.object_key||'';
  const ext=(String(file.name||'jpg').split('.').pop()||'jpg').toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,8)||'jpg'; const key=`dashboard-ads/${box}/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  try{await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:String(file.type||'image/jpeg'),cacheControl:'public, max-age=31536000'}});}catch(e){return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);}
  const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  try{
    const existing=await env.DB.prepare('SELECT id FROM dashboard_ads WHERE box_key=? AND slot=? LIMIT 1').bind(box,slot).first();
    if(existing?.id){
      await env.DB.prepare('UPDATE dashboard_ads SET image_url=?,caption=?,target_url=?,object_key=?,media_type=?,active=?,duration_sec=?,display_mode=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(url,caption,target,key,mediaType,active,duration,displayMode,existing.id).run();
    } else {
      await env.DB.prepare('INSERT INTO dashboard_ads(box_key,slot,image_url,caption,target_url,object_key,media_type,active,duration_sec,display_mode,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)').bind(box,slot,url,caption,target,key,mediaType,active,duration,displayMode).run();
    }
  }catch(e){try{await env.MEDIA.delete(key);}catch(_){}return json({error:'AD_DB_UPDATE_FAILED',message:String(e?.message||e).slice(0,220)},500,cors);}
  if(oldKey&&oldKey!==key){try{await env.MEDIA.delete(oldKey);}catch(_){} }
  return json({ok:true,box_key:box,slot,image_url:url,media_type:mediaType,caption,target_url:target,active,duration_sec:duration,display_mode:displayMode},201,cors);
}

async function adminAdUpdate(request,env){
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; const b=await body(request); const id=Number(b.id||0); if(!id)return json({error:'INVALID_AD_ID'},400,cors);
  const row=await env.DB.prepare('SELECT id FROM dashboard_ads WHERE id=?').bind(id).first(); if(!row)return json({error:'AD_NOT_FOUND'},404,cors);
  const adBox=await env.DB.prepare('SELECT box_key FROM dashboard_ads WHERE id=?').bind(id).first(); const requestedDuration=Number(b.durationSec||3); const duration=adBox?.box_key==='startup_ad'?Math.max(1,Math.min(4,requestedDuration)):Math.max(1,Math.min(60,requestedDuration)); const dm=String(b.displayMode||'FULL_IMAGE').toUpperCase(); const displayMode=(dm==='FILL_SCREEN'?'FILL_SCREEN':'FULL_IMAGE');
  await env.DB.prepare('UPDATE dashboard_ads SET caption=?,target_url=?,active=?,duration_sec=?,display_mode=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(String(b.caption||'').trim().slice(0,300),String(b.targetUrl||'').trim().slice(0,500),b.active===false?0:1,duration,displayMode,id).run(); return json({ok:true,display_mode:displayMode},200,cors);
}

async function adminAdDelete(request,env){
  try { await assertWriteReady(env); } catch (e) { return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors); }
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; const b=await body(request); const id=Number(b.id||0); if(!id)return json({error:'INVALID_AD_ID'},400,cors); const row=await env.DB.prepare('SELECT object_key FROM dashboard_ads WHERE id=?').bind(id).first(); if(!row)return json({error:'AD_NOT_FOUND'},404,cors); if(env.MEDIA&&row.object_key){try{await env.MEDIA.delete(row.object_key);}catch(_){} } await env.DB.prepare('DELETE FROM dashboard_ads WHERE id=?').bind(id).run(); return json({ok:true},200,cors);
}

async function profileUpdate(request, env) {
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  const b = await body(request);
  const name = String(b.name ?? user.full_name).trim();
  const email = normalizeEmail(b.email ?? user.email ?? '');
  const mobile = normalizeMobile(b.mobile ?? user.mobile ?? '');
  const bio = String(b.bio ?? user.bio ?? '').trim().slice(0,500);
  const rawGender=String(b.gender ?? user.gender ?? 'UNSPECIFIED').toUpperCase(); const gender=['MALE','FEMALE','UNSPECIFIED'].includes(rawGender)?rawGender:'UNSPECIFIED';
  if (!name || (!email && !mobile)) return json({error:'INVALID_PROFILE'},400,cors);
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({error:'INVALID_EMAIL'},400,cors);
  const duplicate = await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE user_id<>? AND ((?<>'' AND email=?) OR (?<>'' AND mobile=?)) LIMIT 1`).bind(user.user_id,email,email,mobile,mobile).first();
  if (duplicate) return json({error:'ACCOUNT_EXISTS'},409,cors);
  await env.DB.prepare(`UPDATE myshop_auth_users_v108 SET full_name=?,email=?,mobile=?,bio=?,gender=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(name,email||null,mobile||null,bio,gender,user.user_id).run();
  const fresh=await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(user.user_id).first();
  return json({ok:true,user:publicUser(fresh)},200,cors);
}

async function profileAvatarUpload(request, env) {
  try { await ensureAuthSchema(env); } catch (_) {}
  const user = await getUser(request, env);
  if (!user) return json({error:'UNAUTHORIZED'},401,cors);
  if (!env.MEDIA) return json({error:'R2_NOT_CONFIGURED'},503,cors);
  let form;
  try { form = await request.formData(); } catch (e) { return json({error:'AVATAR_MULTIPART_INVALID',message:String(e?.message||e).slice(0,180)},400,cors); }
  const file = form.get('file');
  if (!file || typeof file.arrayBuffer !== 'function') return json({error:'FILE_REQUIRED'},400,cors);
  const rawType=String(file.type||'').toLowerCase();
  const fileName=String(file.name||'').toLowerCase();
  const extName=fileName.includes('.')?fileName.split('.').pop():'';
  const guessedType=extName==='png'?'image/png':extName==='webp'?'image/webp':extName==='gif'?'image/gif':(extName==='jpg'||extName==='jpeg')?'image/jpeg':'';
  const type=rawType.startsWith('image/')?rawType:(guessedType||'');
  if (!type.startsWith('image/')) return json({error:'AVATAR_TYPE_MISMATCH'},400,cors);
  if (Number(file.size||0)>5*1024*1024) return json({error:'AVATAR_TOO_LARGE'},413,cors);
  const ext=(extName||type.split('/')[1]||'jpg').replace(/[^a-z0-9]/g,'').slice(0,8)||'jpg';
  const key=`profiles/${user.user_id}/avatar-${Date.now()}-${randomHex(8)}.${ext}`;
  try { await env.MEDIA.put(key,await file.arrayBuffer(),{httpMetadata:{contentType:type,cacheControl:'public, max-age=3600'}}); }
  catch(e){ return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors); }
  try {
    const saved=await env.MEDIA.head(key);
    if(!saved) throw new Error('R2 object verification failed');
  } catch(e) {
    try { await env.MEDIA.delete(key); } catch(_) {}
    return json({error:'R2_VERIFY_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);
  }
  const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();
  const oldKey=user.avatar_object_key||'';
  try {
    await env.DB.prepare('UPDATE myshop_auth_users_v108 SET avatar_url=?,avatar_object_key=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(url,key,user.user_id).run();
  } catch(e) {
    try { await env.MEDIA.delete(key); } catch(_) {}
    return json({error:'PROFILE_UPDATE_FAILED'},500,cors);
  }
  if(oldKey && oldKey!==key){ try { await env.MEDIA.delete(oldKey); } catch(_) {} }
  const fresh=await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(user.user_id).first();
  return json({ok:true,user:publicUser(fresh)},200,cors);
}


async function profileCoverUpload(request, env) {
  try { await ensureAuthSchema(env); } catch (_) {}
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  if(!env.MEDIA)return json({error:'R2_NOT_CONFIGURED'},503,cors);
  let form; try{form=await request.formData();}catch(e){return json({error:'COVER_MULTIPART_INVALID',message:String(e?.message||e).slice(0,180)},400,cors);}
  const file=form.get('file'); if(!file||typeof file.arrayBuffer!=='function')return json({error:'FILE_REQUIRED'},400,cors);
  const rawType=String(file.type||'').toLowerCase(),fileName=String(file.name||'').toLowerCase(),extName=fileName.includes('.')?fileName.split('.').pop():'';
  const guessedType=extName==='png'?'image/png':extName==='webp'?'image/webp':extName==='gif'?'image/gif':(extName==='jpg'||extName==='jpeg')?'image/jpeg':'';
  const type=rawType.startsWith('image/')?rawType:(guessedType||''); if(!type.startsWith('image/'))return json({error:'COVER_TYPE_MISMATCH'},400,cors);
  if(Number(file.size||0)>8*1024*1024)return json({error:'COVER_TOO_LARGE'},413,cors);
  const ext=(extName||type.split('/')[1]||'jpg').replace(/[^a-z0-9]/g,'').slice(0,8)||'jpg';
  const key=`profiles/${user.user_id}/cover-${Date.now()}-${randomHex(8)}.${ext}`;
  try{await env.MEDIA.put(key,await file.arrayBuffer(),{httpMetadata:{contentType:type,cacheControl:'public, max-age=3600'}});}catch(e){return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);}
  try{if(!await env.MEDIA.head(key))throw new Error('R2 object verification failed');}catch(e){try{await env.MEDIA.delete(key);}catch(_){}return json({error:'R2_VERIFY_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);}
  const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString(),oldKey=user.cover_object_key||'';
  try{await env.DB.prepare('UPDATE myshop_auth_users_v108 SET cover_url=?,cover_object_key=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(url,key,user.user_id).run();}catch(e){try{await env.MEDIA.delete(key);}catch(_){}return json({error:'PROFILE_UPDATE_FAILED'},500,cors);}
  if(oldKey&&oldKey!==key){try{await env.MEDIA.delete(oldKey);}catch(_){} }
  const fresh=await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(user.user_id).first();
  return json({ok:true,user:publicUser(fresh)},200,cors);
}

async function profileCoverDelete(request,env){
  try{await ensureAuthSchema(env);}catch(_){}
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const oldKey=user.cover_object_key||'';
  await env.DB.prepare("UPDATE myshop_auth_users_v108 SET cover_url='',cover_object_key='',updated_at=CURRENT_TIMESTAMP WHERE user_id=?").bind(user.user_id).run();
  if(oldKey&&env.MEDIA){try{await env.MEDIA.delete(oldKey);}catch(_){} }
  const fresh=await env.DB.prepare('SELECT * FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(user.user_id).first();
  return json({ok:true,user:publicUser(fresh)},200,cors);
}

async function socialStatsFor(env,userId){
  await ensureFriendSchema(env);
  const friends=await env.DB.prepare("SELECT COUNT(*) c FROM myshop_friend_requests WHERE status='ACCEPTED' AND (sender_id=? OR receiver_id=?)").bind(userId,userId).first();
  const followers=await env.DB.prepare('SELECT COUNT(*) c FROM myshop_follows WHERE following_id=?').bind(userId).first();
  const following=await env.DB.prepare('SELECT COUNT(*) c FROM myshop_follows WHERE follower_id=?').bind(userId).first();
  const likes=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_post_likes l JOIN myshop_posts p ON p.id=l.post_id WHERE p.user_id=? AND p.status='ACTIVE'`).bind(userId).first();
  return {friends:Number(friends?.c||0),followers:Number(followers?.c||0),following:Number(following?.c||0),likes:Number(likes?.c||0)};
}

async function mySocialStats(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  return json({ok:true,stats:await socialStatsFor(env,user.user_id)},200,cors);
}

async function followToggle(request,env){
  await ensureFriendSchema(env);
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request),target=String(b.userId||'').trim();if(!isFourDigit(target)||target===user.user_id)return json({error:'INVALID_USER'},400,cors);
  const found=await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(target).first();if(!found)return json({error:'USER_NOT_FOUND'},404,cors);
  const blocked=await env.DB.prepare(`SELECT 1 ok FROM myshop_user_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1`).bind(user.user_id,target,target,user.user_id).first();if(blocked)return json({error:'NOT_AVAILABLE'},409,cors);
  const row=await env.DB.prepare('SELECT 1 ok FROM myshop_follows WHERE follower_id=? AND following_id=?').bind(user.user_id,target).first();
  let following=false;
  if(row){await env.DB.prepare('DELETE FROM myshop_follows WHERE follower_id=? AND following_id=?').bind(user.user_id,target).run();}
  else{await env.DB.prepare('INSERT OR IGNORE INTO myshop_follows(follower_id,following_id,created_at) VALUES(?,?,CURRENT_TIMESTAMP)').bind(user.user_id,target).run();following=true;try{await createUserNotification(env,target,'New Follower',(user.full_name||'A MY SHOP user')+' started following you.','FOLLOW',user.user_id,user.user_id);}catch(_){} }
  return json({ok:true,following,stats:await socialStatsFor(env,target),myStats:await socialStatsFor(env,user.user_id)},200,cors);
}

async function friendCancel(request,env){
  await ensureFriendSchema(env);
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request),target=String(b.userId||'').trim();if(!isFourDigit(target)||target===user.user_id)return json({error:'INVALID_USER'},400,cors);
  const r=await env.DB.prepare("DELETE FROM myshop_friend_requests WHERE sender_id=? AND receiver_id=? AND status='PENDING'").bind(user.user_id,target).run();
  return json({ok:true,cancelled:Number(r?.meta?.changes||0)>0,status:'NONE',stats:await socialStatsFor(env,user.user_id),peerStats:await socialStatsFor(env,target)},200,cors);
}

async function friendRemove(request,env){
  await ensureFriendSchema(env);
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request),target=String(b.userId||'').trim();if(!isFourDigit(target)||target===user.user_id)return json({error:'INVALID_USER'},400,cors);
  const r=await env.DB.prepare("DELETE FROM myshop_friend_requests WHERE status='ACCEPTED' AND ((sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?))").bind(user.user_id,target,target,user.user_id).run();
  return json({ok:true,removed:Number(r?.meta?.changes||0)>0,stats:await socialStatsFor(env,user.user_id),peerStats:await socialStatsFor(env,target)},200,cors);
}


async function ensureLevelSchema(env){
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_user_progress (user_id TEXT PRIMARY KEY,stars INTEGER NOT NULL DEFAULT 0,level INTEGER NOT NULL DEFAULT 0,normal_coin_units INTEGER NOT NULL DEFAULT 0,normal_gold_units INTEGER NOT NULL DEFAULT 0,official_coin_units INTEGER NOT NULL DEFAULT 0,official_gold_units INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_star_level_ledger (id INTEGER PRIMARY KEY AUTOINCREMENT,tx_type TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('COIN','GOLD')),sender_id TEXT NOT NULL DEFAULT '',receiver_id TEXT NOT NULL,units INTEGER NOT NULL DEFAULT 0,stars INTEGER NOT NULL DEFAULT 0,level_added INTEGER NOT NULL DEFAULT 0,official INTEGER NOT NULL DEFAULT 0,reference TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  for(const sql of [
    `ALTER TABLE myshop_user_progress ADD COLUMN normal_coin_units INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_user_progress ADD COLUMN normal_gold_units INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_user_progress ADD COLUMN official_coin_units INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_user_progress ADD COLUMN official_gold_units INTEGER NOT NULL DEFAULT 0`
  ]){try{await env.DB.prepare(sql).run();}catch(e){}}
}

async function reconcileLevelProgress(env,userId){
  await ensureLevelSchema(env);
  // V-317 one-time legacy backfill. This repairs users who received Coin/Gold from Admin
  // before the Star/Level progress table existed (for example 100,000 official Coin => LV.2).
  // A progress row acts as the migration marker, so current transactions are never counted twice.
  let row=await env.DB.prepare(`SELECT stars,level,normal_coin_units,normal_gold_units,official_coin_units,official_gold_units FROM myshop_user_progress WHERE user_id=?`).bind(userId).first();
  if(!row){
    let history={normal_coin_units:0,normal_gold_units:0,official_coin_units:0,official_gold_units:0};
    try{
      history=await env.DB.prepare(`SELECT
        COALESCE(SUM(CASE WHEN currency='COIN' AND tx_type IN ('GIFT','TRANSFER') AND sender_id NOT IN ('0001','0002','0003') THEN gross_amount ELSE 0 END),0) normal_coin_units,
        COALESCE(SUM(CASE WHEN currency='GOLD' AND tx_type IN ('GIFT','TRANSFER') AND sender_id NOT IN ('0001','0002','0003') THEN gross_amount ELSE 0 END),0) normal_gold_units,
        COALESCE(SUM(CASE WHEN currency='COIN' AND (tx_type='ADMIN_GRANT' OR (tx_type IN ('GIFT','TRANSFER') AND sender_id IN ('0001','0002','0003'))) THEN gross_amount ELSE 0 END),0) official_coin_units,
        COALESCE(SUM(CASE WHEN currency='GOLD' AND (tx_type='ADMIN_GRANT' OR (tx_type IN ('GIFT','TRANSFER') AND sender_id IN ('0001','0002','0003'))) THEN gross_amount ELSE 0 END),0) official_gold_units
        FROM myshop_value_ledger WHERE receiver_id=? AND status='COMPLETED'`).bind(userId).first()||history;
    }catch(e){}
    let oldAdminCoin=0,oldAdminGold=0;
    try{const x=await env.DB.prepare(`SELECT COALESCE(SUM(CASE WHEN amount>0 AND kind='ADMIN_GRANT' AND status='COMPLETED' THEN amount ELSE 0 END),0) total FROM myshop_coin_transactions WHERE user_id=?`).bind(userId).first();oldAdminCoin=Math.max(0,Number(x?.total||0));}catch(e){}
    try{const x=await env.DB.prepare(`SELECT COALESCE(SUM(CASE WHEN amount>0 AND kind='ADMIN_GRANT' THEN amount ELSE 0 END),0) total FROM myshop_gold_transactions WHERE user_id=?`).bind(userId).first();oldAdminGold=Math.max(0,Number(x?.total||0));}catch(e){}
    const nc=Math.max(0,Number(history?.normal_coin_units||0)),ng=Math.max(0,Number(history?.normal_gold_units||0));
    const oc=Math.max(oldAdminCoin,Math.max(0,Number(history?.official_coin_units||0))),og=Math.max(oldAdminGold,Math.max(0,Number(history?.official_gold_units||0)));
    const normalStars=Math.floor(nc/100000)+Math.floor(ng/1000),officialStars=Math.floor(oc/100000)+Math.floor(og/1000);
    await env.DB.prepare(`INSERT OR IGNORE INTO myshop_user_progress(user_id,stars,level,normal_coin_units,normal_gold_units,official_coin_units,official_gold_units,updated_at) VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)`).bind(userId,normalStars+officialStars,normalStars+(officialStars*2),nc,ng,oc,og).run();
    row=await env.DB.prepare(`SELECT stars,level,normal_coin_units,normal_gold_units,official_coin_units,official_gold_units FROM myshop_user_progress WHERE user_id=?`).bind(userId).first();
  }
  const led=await env.DB.prepare(`SELECT COALESCE(SUM(stars),0) stars,COALESCE(SUM(level_added),0) level,
    COALESCE(SUM(CASE WHEN official=0 AND currency='COIN' THEN units ELSE 0 END),0) normal_coin_units,
    COALESCE(SUM(CASE WHEN official=0 AND currency='GOLD' THEN units ELSE 0 END),0) normal_gold_units,
    COALESCE(SUM(CASE WHEN official=1 AND currency='COIN' THEN units ELSE 0 END),0) official_coin_units,
    COALESCE(SUM(CASE WHEN official=1 AND currency='GOLD' THEN units ELSE 0 END),0) official_gold_units
    FROM myshop_star_level_ledger WHERE receiver_id=?`).bind(userId).first();
  const ledgerStars=Math.max(0,Number(led?.stars||0)),ledgerLevel=Math.max(0,Number(led?.level||0));
  const currentStars=Math.max(0,Number(row?.stars||0)),currentLevel=Math.max(0,Number(row?.level||0));
  const nc=Math.max(Number(row?.normal_coin_units||0),Number(led?.normal_coin_units||0));
  const ng=Math.max(Number(row?.normal_gold_units||0),Number(led?.normal_gold_units||0));
  const oc=Math.max(Number(row?.official_coin_units||0),Number(led?.official_coin_units||0));
  const og=Math.max(Number(row?.official_gold_units||0),Number(led?.official_gold_units||0));
  const cumulativeNormalStars=Math.floor(nc/100000)+Math.floor(ng/1000);
  const cumulativeOfficialStars=Math.floor(oc/100000)+Math.floor(og/1000);
  const reconciledStars=Math.max(currentStars,ledgerStars,cumulativeNormalStars+cumulativeOfficialStars);
  const reconciledLevel=Math.max(currentLevel,ledgerLevel,cumulativeNormalStars+(cumulativeOfficialStars*2));
  if(reconciledStars!==currentStars||reconciledLevel!==currentLevel||nc!==Number(row?.normal_coin_units||0)||ng!==Number(row?.normal_gold_units||0)||oc!==Number(row?.official_coin_units||0)||og!==Number(row?.official_gold_units||0)){
    await env.DB.prepare(`UPDATE myshop_user_progress SET stars=?,level=?,normal_coin_units=?,normal_gold_units=?,official_coin_units=?,official_gold_units=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(reconciledStars,reconciledLevel,nc,ng,oc,og,userId).run();
  }
  return await env.DB.prepare(`SELECT stars,level,normal_coin_units,normal_gold_units,official_coin_units,official_gold_units FROM myshop_user_progress WHERE user_id=?`).bind(userId).first();
}

async function coinLevelFor(env,userId){
  await env.DB.prepare('INSERT OR IGNORE INTO myshop_coin_wallets(user_id,balance) VALUES(?,0)').bind(userId).run();
  const r=await env.DB.prepare(`SELECT COALESCE(SUM(CASE WHEN amount>0 AND status='COMPLETED' AND kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN amount ELSE 0 END),0) AS purchased FROM myshop_coin_transactions WHERE user_id=?`).bind(userId).first();
  const purchased=Math.max(0,Number(r?.purchased||0));
  const legacyPurchaseLevel=Math.max(0,Math.floor(purchased/100000));
  const pr=await reconcileLevelProgress(env,userId);
  const earnedLevel=Math.max(0,Number(pr?.level||0));
  const level=legacyPurchaseLevel+earnedLevel;
  const currentLevelStart=legacyPurchaseLevel*100000;
  const nextLevelAt=(legacyPurchaseLevel+1)*100000;
  const progress=Math.max(0,Math.min(100,Math.floor(((purchased-currentLevelStart)/100000)*100)));
  return {level,earnedLevel,stars:Math.max(0,Number(pr?.stars||0)),totalPurchasedCoins:purchased,nextLevelAt,progress};
}

async function coinBalance(request, env) {
  const user=await getUser(request,env); if(!user) return json({error:'UNAUTHORIZED'},401,cors);
  await env.DB.prepare('INSERT OR IGNORE INTO myshop_coin_wallets(user_id,balance) VALUES(?,0)').bind(user.user_id).run();
  const wallet=await env.DB.prepare('SELECT user_id,balance,updated_at FROM myshop_coin_wallets WHERE user_id=?').bind(user.user_id).first();
  const tx=(await env.DB.prepare('SELECT id,kind,amount,reference,status,metadata,created_at FROM myshop_coin_transactions WHERE user_id=? ORDER BY id DESC LIMIT 50').bind(user.user_id).all()).results||[];
  const levelInfo=await coinLevelFor(env,user.user_id);
  return json({ok:true,balance:Number(wallet?.balance||0),transactions:tx,level:levelInfo.level,totalPurchasedCoins:levelInfo.totalPurchasedCoins,nextLevelAt:levelInfo.nextLevelAt,levelProgress:levelInfo.progress},200,cors);
}

async function giftHistory(request,env){
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const rows=(await env.DB.prepare(`SELECT id,sender_user_id,receiver_user_id,coins,gift_code,created_at FROM myshop_gift_transactions WHERE sender_user_id=? OR receiver_user_id=? ORDER BY id DESC LIMIT 100`).bind(user.user_id,user.user_id).all()).results||[];
  return json({ok:true,gifts:rows},200,cors);
}

async function coinPurchaseRequest(request,env){
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  return json({error:'DIRECT_DIGITAL_PAYMENT_DISABLED',message:'Coin purchases must use Google Play Billing.'},409,cors);
}



async function storeCatalog(request,env){
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors); await ensureLiveRoomSchema(env);
  const rows=(await env.DB.prepare("SELECT id,code,title,item_type,units,price_minor,coin_price,duration_days,preview_url,animation_url,animation_mime,benefits,priority,limited_edition,play_product_id FROM myshop_store_catalog WHERE enabled=1 ORDER BY CASE code WHEN 'ROYAL' THEN 1 WHEN 'VVIP' THEN 2 WHEN 'VIP' THEN 3 ELSE priority END,priority,id").all()).results||[];
  const cfg=await financeConfig(env);
  return json({ok:true,catalog:rows,platformFeePercent:cfg.feePercent},200,cors);
}
async function adminStoreCatalog(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error;
  const rows=(await env.DB.prepare("SELECT * FROM myshop_store_catalog ORDER BY enabled DESC,CASE code WHEN 'ROYAL' THEN 1 WHEN 'VVIP' THEN 2 WHEN 'VIP' THEN 3 ELSE priority END,priority,id").all()).results||[];
  return json({ok:true,catalog:rows},200,cors);
}
async function adminStoreCatalogSave(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; const b=await body(request);
  const id=Math.max(0,Math.floor(Number(b.id||0))), code=String(b.code||'').trim().toUpperCase().replace(/[^A-Z0-9_-]/g,'').slice(0,40), title=String(b.title||'').trim().slice(0,80), type=String(b.itemType||'').trim().toUpperCase();
  const units=Math.max(1,Math.floor(Number(b.units||1))), price=Math.max(0,Math.floor(Number(b.priceMinor||0))), coinPrice=Math.max(0,Math.floor(Number(b.coinPrice||0))), days=Math.max(0,Math.floor(Number(b.durationDays||0))), priority=Math.max(1,Math.floor(Number(b.priority||100)));
  const preview=String(b.previewUrl||'').trim().slice(0,1200), animation=String(b.animationUrl||'').trim().slice(0,1200), mime=String(b.animationMime||'').trim().slice(0,80), benefits=String(b.benefits||'').trim().slice(0,1000), limited=b.limitedEdition?1:0, enabled=b.enabled===false?0:1;
  const playProductId=String(b.playProductId||'').trim().toLowerCase().replace(/[^a-z0-9._]/g,'').slice(0,80);
  if(!code||!title||!['COIN','GOLD','BADGE','MEMBERSHIP','FRAME','AVATAR_FRAME','THEME','LIVE_THEME','WALLPAPER','GIFT','LIVE_GIFT'].includes(type)||(price<=0&&coinPrice<=0))return json({error:'INVALID_CATALOG_ITEM'},400,cors);
  if(price>0&&!playProductId)return json({error:'PLAY_PRODUCT_ID_REQUIRED',message:'Money-priced digital items require a Google Play product ID.'},400,cors);
  let r;
  if(id){r=await env.DB.prepare("UPDATE myshop_store_catalog SET code=?,title=?,item_type=?,units=?,price_minor=?,coin_price=?,duration_days=?,preview_url=?,animation_url=?,animation_mime=?,benefits=?,priority=?,limited_edition=?,enabled=?,play_product_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(code,title,type,units,price,coinPrice,days,preview,animation,mime,benefits,priority,limited,enabled,playProductId,id).run();}
  else{r=await env.DB.prepare("INSERT INTO myshop_store_catalog(code,title,item_type,units,price_minor,coin_price,duration_days,preview_url,animation_url,animation_mime,benefits,priority,limited_edition,enabled,play_product_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)").bind(code,title,type,units,price,coinPrice,days,preview,animation,mime,benefits,priority,limited,enabled,playProductId).run();}
  const cid=id||r.meta?.last_row_id||0; await env.DB.prepare("INSERT INTO myshop_store_audit(admin_user_id,action,catalog_id,item_code,details) VALUES(?,?,?,?,?)").bind(auth.user.user_id,id?'UPDATE':'CREATE',cid,code,JSON.stringify({title,type,units,price,coinPrice,days,priority,limited,enabled,playProductId})).run();
  return json({ok:true,id:cid,code},200,cors);
}
async function adminStoreCatalogToggle(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; const b=await body(request); const id=Math.floor(Number(b.id||0)),enabled=b.enabled?1:0; if(!id)return json({error:'INVALID_CATALOG_ID'},400,cors);
  const row=await env.DB.prepare('SELECT code FROM myshop_store_catalog WHERE id=?').bind(id).first(); if(!row)return json({error:'CATALOG_NOT_FOUND'},404,cors);
  await env.DB.prepare('UPDATE myshop_store_catalog SET enabled=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(enabled,id).run(); await env.DB.prepare("INSERT INTO myshop_store_audit(admin_user_id,action,catalog_id,item_code,details) VALUES(?,?,?,?,?)").bind(auth.user.user_id,enabled?'ENABLE':'DISABLE',id,row.code,'').run(); return json({ok:true,id,enabled},200,cors);
}
async function adminStoreCatalogDelete(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; const b=await body(request); const id=Math.floor(Number(b.id||0)); if(!id)return json({error:'INVALID_CATALOG_ID'},400,cors);
  const row=await env.DB.prepare('SELECT code,title FROM myshop_store_catalog WHERE id=?').bind(id).first(); if(!row)return json({error:'CATALOG_NOT_FOUND'},404,cors);
  // Keep previously granted entitlements/history intact; only remove future Store availability.
  await env.DB.prepare('UPDATE myshop_store_catalog SET enabled=0,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(id).run();
  await env.DB.prepare("INSERT INTO myshop_store_audit(admin_user_id,action,catalog_id,item_code,details) VALUES(?,?,?,?,?)").bind(auth.user.user_id,'DELETE',id,row.code,JSON.stringify({title:row.title,softDelete:true})).run();
  return json({ok:true,id,deleted:true,softDelete:true},200,cors);
}
async function adminAssetUpload(request,env){
  try{await assertWriteReady(env);}catch(e){return json({error:'D1_WRITE_READY_FAILED',message:String(e?.message||e).slice(0,220)},503,cors);}
  const auth=await adminOnly(request,env);if(auth.error)return auth.error;if(!env.MEDIA)return json({error:'R2_NOT_CONFIGURED'},503,cors);
  let form;try{form=await request.formData();}catch(e){return json({error:'ASSET_MULTIPART_INVALID'},400,cors);}const file=form.get('file');if(!file||typeof file.arrayBuffer!=='function')return json({error:'FILE_REQUIRED'},400,cors);
  const type=String(file.type||'').toLowerCase();if(!type.startsWith('image/'))return json({error:'IMAGE_REQUIRED'},400,cors);if(Number(file.size||0)>8*1024*1024)return json({error:'IMAGE_TOO_LARGE'},413,cors);
  const purpose=String(form.get('purpose')||'asset').toLowerCase().replace(/[^a-z0-9_-]/g,'_').slice(0,60)||'asset';const name=String(file.name||'image.jpg').toLowerCase();const ext=(name.includes('.')?name.split('.').pop():'jpg').replace(/[^a-z0-9]/g,'').slice(0,8)||'jpg';const key=`managed-assets/${purpose}/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  try{await env.MEDIA.put(key,await file.arrayBuffer(),{httpMetadata:{contentType:type,cacheControl:'public, max-age=31536000'}});const h=await env.MEDIA.head(key);if(!h)throw new Error('R2_VERIFY_FAILED');}catch(e){try{await env.MEDIA.delete(key);}catch(_){}return json({error:'R2_WRITE_FAILED',message:String(e?.message||e).slice(0,180)},503,cors);}const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();return json({ok:true,image_url:url,object_key:key},201,cors);
}

async function adminStoreAssetUpload(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; if(!env.MEDIA)return json({error:'R2_NOT_CONFIGURED'},503,cors);
  const form=await request.formData(),file=form.get('file'); if(!(file instanceof File))return json({error:'FILE_REQUIRED'},400,cors); if(file.size>8*1024*1024)return json({error:'BADGE_ASSET_TOO_LARGE'},413,cors);
  const ct=guessContentType(file); if(!['image/webp','image/gif','image/png','image/jpeg','application/json'].includes(ct))return json({error:'BADGE_ASSET_TYPE_MISMATCH'},400,cors);
  const ext=(String(file.name||'asset').split('.').pop()||'bin').replace(/[^a-zA-Z0-9]/g,'').slice(0,8)||'bin'; const key=`store/badges/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;
  await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:ct,cacheControl:'public, max-age=31536000'}}); const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString(); return json({ok:true,url,mediaType:ct,objectKey:key},201,cors);
}
async function grantCatalogItem(env,uid,item,source,note){
  const type=String(item.item_type||'').toUpperCase(), code=String(item.code||'').toUpperCase(), units=Math.max(1,Number(item.units||1)), days=Math.max(0,Number(item.duration_days||0));
  if(type==='COIN'){await env.DB.prepare('INSERT OR IGNORE INTO myshop_coin_wallets(user_id,balance) VALUES(?,0)').bind(uid).run();await env.DB.prepare('UPDATE myshop_coin_wallets SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(units,uid).run();await env.DB.prepare("INSERT INTO myshop_coin_transactions(user_id,kind,amount,reference,status,metadata) VALUES(?,'STORE_GRANT',?,'CATALOG','COMPLETED',?)").bind(uid,units,JSON.stringify({catalogId:item.id,source,note})).run();}
  else if(type==='GOLD'){await env.DB.prepare('INSERT OR IGNORE INTO myshop_gold_wallets(user_id,balance) VALUES(?,0)').bind(uid).run();await env.DB.prepare('UPDATE myshop_gold_wallets SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(units,uid).run();await env.DB.prepare("INSERT INTO myshop_gold_transactions(user_id,kind,amount,reference,metadata) VALUES(?,'STORE_GRANT',?,'CATALOG',?)").bind(uid,units,JSON.stringify({catalogId:item.id,source,note})).run();}
  else if(['FRAME','AVATAR_FRAME','THEME','LIVE_THEME','WALLPAPER','GIFT'].includes(type)){const exp=days>0?new Date(Date.now()+days*86400000).toISOString():null;await env.DB.prepare(`INSERT INTO myshop_owned_items(user_id,catalog_id,item_type,item_code,equipped,expires_at,source) VALUES(?,?,?,?,0,?,?) ON CONFLICT(user_id,catalog_id) DO UPDATE SET expires_at=excluded.expires_at,source=excluded.source`).bind(uid,item.id,type,code,exp,source).run();}
  else{const exp=days>0?new Date(Date.now()+days*86400000).toISOString():null;await env.DB.prepare("UPDATE myshop_user_badges SET is_displayed=0 WHERE user_id=?").bind(uid).run();await env.DB.prepare("INSERT INTO myshop_user_badges(user_id,badge_code,status,source,expires_at,note,catalog_id,is_displayed) VALUES(?,?,'ACTIVE',?,?,?,?,1)").bind(uid,code,source,exp,note,item.id).run();}
}
async function storePurchaseRequest(request,env){
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors); await ensureLiveRoomSchema(env); const b=await body(request),id=Math.floor(Number(b.productId||0)),mode=String(b.paymentMode||'MONEY').toUpperCase(),method=String(b.paymentMethod||'').toLowerCase(),ref=String(b.reference||'').trim().slice(0,120);
  const item=await env.DB.prepare('SELECT * FROM myshop_store_catalog WHERE id=? AND enabled=1').bind(id).first(); if(!item)return json({error:'CATALOG_NOT_FOUND'},404,cors); const cfg=await financeConfig(env);
  if(mode==='COIN'){const base=Number(item.coin_price||0);if(base<=0)return json({error:'COIN_PRICE_NOT_AVAILABLE'},409,cors);const fee=Math.max(0,Math.round(base*cfg.feePercent/100)),total=base+fee;await env.DB.prepare('INSERT OR IGNORE INTO myshop_coin_wallets(user_id,balance) VALUES(?,0)').bind(user.user_id).run();const w=await env.DB.prepare('SELECT balance FROM myshop_coin_wallets WHERE user_id=?').bind(user.user_id).first();if(Number(w?.balance||0)<total)return json({error:'INSUFFICIENT_COIN_BALANCE',baseAmount:base,feeAmount:fee,totalAmount:total},409,cors);await env.DB.prepare('UPDATE myshop_coin_wallets SET balance=balance-?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(total,user.user_id).run();await env.DB.prepare("INSERT INTO myshop_coin_transactions(user_id,kind,amount,reference,status,metadata) VALUES(?,'STORE_PURCHASE',?,'CATALOG','COMPLETED',?)").bind(user.user_id,-total,JSON.stringify({productId:id,code:item.code,base,fee,total,feePercent:cfg.feePercent})).run();await env.DB.prepare(`INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,gross_amount,fee_percent,fee_amount,net_amount,platform_amount,reference,metadata) VALUES('STORE_PURCHASE','COIN',?,'MY_SHOP',?,?,?,?,?,'CATALOG',?)`).bind(user.user_id,total,cfg.feePercent,fee,base,fee,JSON.stringify({productId:id,code:item.code})).run();await grantCatalogItem(env,user.user_id,item,'COIN_PURCHASE','Catalog coin purchase');return json({ok:true,status:'COMPLETED',productId:id,baseAmount:base,feePercent:cfg.feePercent,feeAmount:fee,totalAmount:total},200,cors);}
  return json({error:'DIRECT_DIGITAL_PAYMENT_DISABLED',message:'Google Play Billing is required for real-money digital purchases in the Play Store build.'},409,cors);
}
async function adminStoreGrant(request,env){
  const auth=await adminOnly(request,env);if(auth.error)return auth.error;const b=await body(request),uid=String(b.userId||'').trim(),id=Math.floor(Number(b.productId||0)),note=String(b.note||'').trim().slice(0,180);if(!isFourDigit(uid)||!id)return json({error:'INVALID_GRANT'},400,cors);const target=await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(uid).first();if(!target)return json({error:'USER_NOT_FOUND'},404,cors);const item=await env.DB.prepare('SELECT * FROM myshop_store_catalog WHERE id=?').bind(id).first();if(!item)return json({error:'CATALOG_NOT_FOUND'},404,cors);await grantCatalogItem(env,uid,item,'ADMIN',note);await env.DB.prepare('INSERT INTO myshop_admin_wallet_grants(admin_user_id,target_user_id,item_type,item_code,units,days,note) VALUES(?,?,?,?,?,?,?)').bind(auth.user.user_id,uid,item.item_type,item.code,item.units,item.duration_days,note).run();try{await createUserNotification(env,uid,'MY SHOP Premium',`${item.title} has been activated on your profile.`)}catch(_){}return json({ok:true,userId:uid,productId:id,code:item.code},200,cors);
}
async function setActiveBadge(request,env){
 const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);const b=await body(request),badgeId=Math.floor(Number(b.badgeId||0));const row=await env.DB.prepare("SELECT id FROM myshop_user_badges WHERE id=? AND user_id=? AND status='ACTIVE' AND (expires_at IS NULL OR datetime(expires_at)>datetime('now'))").bind(badgeId,user.user_id).first();if(!row)return json({error:'BADGE_NOT_AVAILABLE'},404,cors);await env.DB.prepare('UPDATE myshop_user_badges SET is_displayed=0 WHERE user_id=?').bind(user.user_id).run();await env.DB.prepare('UPDATE myshop_user_badges SET is_displayed=1 WHERE id=?').bind(badgeId).run();return json({ok:true,badgeId},200,cors);
}

async function walletProfile(request,env){
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  await env.DB.prepare('INSERT OR IGNORE INTO myshop_gold_wallets(user_id,balance) VALUES(?,0)').bind(user.user_id).run();
  const g=await env.DB.prepare('SELECT balance FROM myshop_gold_wallets WHERE user_id=?').bind(user.user_id).first();
  const badges=(await env.DB.prepare("SELECT b.id,b.badge_code,b.status,b.starts_at,b.expires_at,b.source,b.note,b.is_displayed,b.catalog_id,c.title,c.preview_url,c.animation_url,c.animation_mime,c.benefits,c.duration_days FROM myshop_user_badges b LEFT JOIN myshop_store_catalog c ON c.id=b.catalog_id WHERE b.user_id=? AND b.status='ACTIVE' AND (b.expires_at IS NULL OR datetime(b.expires_at)>datetime('now')) ORDER BY b.is_displayed DESC,CASE b.badge_code WHEN 'ROYAL' THEN 1 WHEN 'VVIP' THEN 2 WHEN 'VIP' THEN 3 WHEN 'BLUE' THEN 4 ELSE 9 END,b.id DESC").bind(user.user_id).all()).results||[];
  const withdrawals=(await env.DB.prepare('SELECT id,gold_amount,payment_method,account,status,created_at FROM myshop_withdraw_requests WHERE user_id=? ORDER BY id DESC LIMIT 30').bind(user.user_id).all()).results||[];
  const levelInfo=await coinLevelFor(env,user.user_id);
  return json({ok:true,goldBalance:Number(g?.balance||0),badges,withdrawals,level:levelInfo.level,totalPurchasedCoins:levelInfo.totalPurchasedCoins,nextLevelAt:levelInfo.nextLevelAt,levelProgress:levelInfo.progress},200,cors);
}

async function walletPurchaseRequest(request,env){
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  return json({error:'DIRECT_DIGITAL_PAYMENT_DISABLED',message:'Use Google Play Billing for Coin, Gold, Badge and Membership purchases.'},409,cors);
}

async function creatorEarningsWithdraw(request,env,currency){
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors); await ensureContentSchema(env); const b=await body(request);
  const raw=currency==='GOLD'?b.gold:b.coin, gross=Math.floor(Number(raw||0)),method=String(b.paymentMethod||'').trim().toLowerCase(),account=String(b.account||'').trim().slice(0,80),note=String(b.note||'').trim().slice(0,180);
  if(gross<=0||!['bkash','nagad'].includes(method)||!account)return json({error:'INVALID_WITHDRAW_REQUEST'},400,cors);
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_creator_earnings(user_id,currency,balance) VALUES(?,?,0)`).bind(user.user_id,currency).run();
  const w=await env.DB.prepare(`SELECT balance FROM myshop_creator_earnings WHERE user_id=? AND currency=?`).bind(user.user_id,currency).first();
  const pending=await env.DB.prepare(`SELECT COALESCE(SUM(gross_units),0) total FROM myshop_creator_withdraw_requests WHERE user_id=? AND currency=? AND status='PENDING'`).bind(user.user_id,currency).first();
  if(Number(w?.balance||0)-Number(pending?.total||0)<gross)return json({error:'INSUFFICIENT_CREATOR_EARNINGS',message:'Only eligible Creator Earnings can be withdrawn. Bonus/spendable Coin and Gold Coin are not cash-withdrawable.'},409,cors);
  const cfg=await financeConfig(env),split=splitPlatformFee(gross,cfg.feePercent);
  const cashMinor=Math.max(0,Math.floor((split.net/Math.max(1,cfg.unitsPer600Taka))*60000)); // poisha
  const r=await env.DB.prepare(`INSERT INTO myshop_creator_withdraw_requests(user_id,currency,gross_units,service_fee_percent,service_fee_units,net_units,cash_minor,payment_method,account,note,status) VALUES(?,?,?,?,?,?,?,?,?,?,'PENDING')`).bind(user.user_id,currency,split.gross,cfg.feePercent,split.fee,split.net,cashMinor,method,account,note).run();
  await env.DB.prepare(`INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,gross_amount,fee_percent,fee_amount,net_amount,platform_amount,status,reference,metadata) VALUES('CREATOR_WITHDRAW_REQUEST',?,?,?,?,?,?,?,?, 'PENDING','MYSHOP_PAYOUT',?)`).bind(currency,user.user_id,'WITHDRAWAL',split.gross,cfg.feePercent,split.fee,split.net,split.fee,JSON.stringify({cashMinor,method})).run();
  return json({ok:true,requestId:r.meta?.last_row_id||null,status:'PENDING',currency,grossAmount:split.gross,serviceFeePercent:cfg.feePercent,serviceFeeAmount:split.fee,netAmount:split.net,cashMinor},201,cors);
}
async function goldWithdrawRequest(request,env){ return creatorEarningsWithdraw(request,env,'GOLD'); }
async function coinWithdrawRequest(request,env){ return creatorEarningsWithdraw(request,env,'COIN'); }

async function myOwnedItems(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);await ensureContentSchema(env);
  const rows=(await env.DB.prepare(`SELECT o.id,o.catalog_id,o.item_type,o.item_code,o.equipped,o.expires_at,o.source,o.created_at,c.title,c.preview_url,c.animation_url,c.animation_mime,c.benefits,c.duration_days FROM myshop_owned_items o LEFT JOIN myshop_store_catalog c ON c.id=o.catalog_id WHERE o.user_id=? AND (o.expires_at IS NULL OR datetime(o.expires_at)>datetime('now')) ORDER BY o.item_type,o.equipped DESC,o.id DESC`).bind(user.user_id).all()).results||[];
  return json({ok:true,items:rows},200,cors);
}
async function equipOwnedItem(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);await ensureContentSchema(env);const b=await body(request),id=Number(b.id||0);const row=await env.DB.prepare(`SELECT id,item_type FROM myshop_owned_items WHERE id=? AND user_id=? AND (expires_at IS NULL OR datetime(expires_at)>datetime('now'))`).bind(id,user.user_id).first();if(!row)return json({error:'ITEM_NOT_OWNED'},404,cors);const type=String(row.item_type||'');await env.DB.prepare(`UPDATE myshop_owned_items SET equipped=0 WHERE user_id=? AND item_type=?`).bind(user.user_id,type).run();await env.DB.prepare(`UPDATE myshop_owned_items SET equipped=1 WHERE id=?`).bind(id).run();return json({ok:true,id,itemType:type},200,cors);
}

async function adminWalletPreview(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error;
  const uid=String(new URL(request.url).searchParams.get('userId')||'').trim(); if(!isFourDigit(uid))return json({error:'INVALID_USER_ID'},400,cors);
  const u=await env.DB.prepare(`SELECT user_id,full_name,avatar_url,active FROM myshop_auth_users_v108 WHERE user_id=?`).bind(uid).first(); if(!u||Number(u.active||0)!==1)return json({error:'USER_NOT_FOUND'},404,cors);
  const cw=await env.DB.prepare(`SELECT balance FROM myshop_coin_wallets WHERE user_id=?`).bind(uid).first();
  const gw=await env.DB.prepare(`SELECT balance FROM myshop_gold_wallets WHERE user_id=?`).bind(uid).first();
  const levelInfo=await coinLevelFor(env,uid);
  return json({ok:true,user:{userId:u.user_id,name:u.full_name||'MY SHOP User',avatarUrl:u.avatar_url||''},coinBalance:Number(cw?.balance||0),goldBalance:Number(gw?.balance||0),stars:Number(levelInfo.stars||0),level:Number(levelInfo.level||0)},200,cors);
}

async function adminWalletGrant(request,env){
  const auth=await adminOnly(request,env); if(auth.error)return auth.error; const b=await body(request); const uid=String(b.userId||'').trim(),type=String(b.itemType||'').trim().toUpperCase(),code=String(b.itemCode||'').trim().toUpperCase(); const units=Math.floor(Number(b.units||1)),days=Math.max(0,Math.floor(Number(b.days||0))),note=String(b.note||'').trim().slice(0,180);
  if(!isFourDigit(uid)||!['COIN','GOLD','BADGE'].includes(type)||units<=0)return json({error:'INVALID_GRANT'},400,cors); const target=await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(uid).first(); if(!target)return json({error:'USER_NOT_FOUND'},404,cors);
  if(type==='COIN'||type==='GOLD')await reconcileLevelProgress(env,uid);
  if(type==='COIN'){ await env.DB.prepare('INSERT OR IGNORE INTO myshop_coin_wallets(user_id,balance) VALUES(?,0)').bind(uid).run(); await env.DB.prepare('UPDATE myshop_coin_wallets SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(units,uid).run(); await env.DB.prepare("INSERT INTO myshop_coin_transactions(user_id,kind,amount,reference,status,metadata) VALUES(?,'ADMIN_GRANT',?,'ADMIN','COMPLETED',?)").bind(uid,units,JSON.stringify({admin:auth.user.user_id,note})).run(); }
  else if(type==='GOLD'){ await env.DB.prepare('INSERT OR IGNORE INTO myshop_gold_wallets(user_id,balance) VALUES(?,0)').bind(uid).run(); await env.DB.prepare('UPDATE myshop_gold_wallets SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(units,uid).run(); await env.DB.prepare("INSERT INTO myshop_gold_transactions(user_id,kind,amount,reference,metadata) VALUES(?,'ADMIN_GRANT',?,'ADMIN',?)").bind(uid,units,JSON.stringify({admin:auth.user.user_id,note})).run(); }
  else { if(!code)return json({error:'INVALID_BADGE'},400,cors); const exp=days>0?new Date(Date.now()+days*86400000).toISOString():null; await env.DB.prepare("UPDATE myshop_user_badges SET is_displayed=0 WHERE user_id=?").bind(uid).run(); await env.DB.prepare("INSERT INTO myshop_user_badges(user_id,badge_code,status,source,expires_at,note,is_displayed) VALUES(?,?,'ACTIVE','ADMIN',?,?,1)").bind(uid,code,exp,note).run(); }
  await env.DB.prepare('INSERT INTO myshop_admin_wallet_grants(admin_user_id,target_user_id,item_type,item_code,units,days,note) VALUES(?,?,?,?,?,?,?)').bind(auth.user.user_id,uid,type,code,units,days,note).run();
  let progress={stars:0,levelAdded:0};
  if(type==='COIN'||type==='GOLD'){await env.DB.prepare(`INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,gross_amount,fee_percent,fee_amount,net_amount,platform_amount,reference,metadata) VALUES('ADMIN_GRANT',?,?,?, ?,0,0,?,0,'OFFICIAL_ADMIN_GRANT',?)`).bind(type,auth.user.user_id,uid,units,units,JSON.stringify({note})).run();progress=await applyStarsAndLevels(env,{txType:'ADMIN_GRANT',currency:type,senderId:auth.user.user_id,receiverId:uid,units,official:true,reference:'OFFICIAL_ADMIN_GRANT'});}
  try{await createUserNotification(env,uid,'MY SHOP Wallet Update',type==='BADGE'?`${code} badge/membership added to your profile.`:`${units} ${type==='COIN'?'Coin':'Gold Coin'} added by Admin.`);}catch(_){}
  const cw=await env.DB.prepare(`SELECT balance FROM myshop_coin_wallets WHERE user_id=?`).bind(uid).first(); const gw=await env.DB.prepare(`SELECT balance FROM myshop_gold_wallets WHERE user_id=?`).bind(uid).first(); const levelInfo=await coinLevelFor(env,uid);
  return json({ok:true,reference:'OFFICIAL_ADMIN_GRANT',userId:uid,itemType:type,itemCode:code,units,days,serviceFeePercent:0,starsAdded:Number(progress.stars||0),levelsAdded:Number(progress.levelAdded||0),coinBalance:Number(cw?.balance||0),goldBalance:Number(gw?.balance||0),stars:Number(levelInfo.stars||0),level:Number(levelInfo.level||0)},200,cors);
}


async function publicUserProfile(request,env){
  await ensureFriendSchema(env);await ensureLevelSchema(env);
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const peer=String(new URL(request.url).searchParams.get('userId')||'').trim(); if(!isFourDigit(peer))return json({error:'INVALID_USER_ID'},400,cors);
  const p=await env.DB.prepare('SELECT user_id,full_name,avatar_url,cover_url,bio,gender,created_at FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(peer).first(); if(!p)return json({error:'USER_NOT_FOUND'},404,cors);
  if(peer!==user.user_id && await safetyIsBlocked(env,user.user_id,peer))return json({error:'BLOCKED_USER'},403,cors);
  let state=peer===user.user_id?'SELF':'NONE';
  if(state!=='SELF'){
    const f=await env.DB.prepare(`SELECT sender_id,receiver_id,status FROM myshop_friend_requests WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) LIMIT 1`).bind(user.user_id,peer,peer,user.user_id).first();
    if(f){ if(f.status==='ACCEPTED')state='FRIEND'; else if(f.status==='PENDING')state=f.sender_id===user.user_id?'REQUESTED':'INCOMING'; }
  }
  const follow=peer===user.user_id?false:!!(await env.DB.prepare('SELECT 1 ok FROM myshop_follows WHERE follower_id=? AND following_id=?').bind(user.user_id,peer).first());
  const badges=(await env.DB.prepare("SELECT b.id,b.badge_code,b.expires_at,b.is_displayed,c.title,c.preview_url,c.animation_url,c.animation_mime FROM myshop_user_badges b LEFT JOIN myshop_store_catalog c ON c.id=b.catalog_id WHERE b.user_id=? AND b.status='ACTIVE' AND (b.expires_at IS NULL OR datetime(b.expires_at)>datetime('now')) ORDER BY b.is_displayed DESC,CASE b.badge_code WHEN 'ROYAL' THEN 1 WHEN 'VVIP' THEN 2 WHEN 'VIP' THEN 3 WHEN 'BLUE' THEN 4 ELSE 9 END,b.id DESC LIMIT 4").bind(peer).all()).results||[];
  const levelInfo=await coinLevelFor(env,peer);
  return json({ok:true,profile:{userId:p.user_id,name:p.full_name||'MY SHOP User',avatarUrl:p.avatar_url||'',coverUrl:p.cover_url||'',bio:p.bio||'',gender:p.gender||'UNSPECIFIED',joinedAt:p.created_at||'',state,isFollowing:follow,stats:await socialStatsFor(env,peer),badges,level:levelInfo.level,totalPurchasedCoins:levelInfo.totalPurchasedCoins}},200,cors);
}

async function newPeople(request,env) {
  await ensureFriendSchema(env);await ensureLevelSchema(env);
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_app_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`UPDATE myshop_app_presence SET active=0 WHERE active=1 AND datetime(last_seen)<datetime('now','-90 seconds')`).run();
  const u=new URL(request.url),limit=Math.max(1,Math.min(500,Number(u.searchParams.get('limit')||20))),offset=Math.max(0,Number(u.searchParams.get('offset')||0));
  const rows=(await env.DB.prepare(`SELECT a.user_id,a.full_name,a.avatar_url,a.created_at,
    (CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=a.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=a.user_id),0)) AS level,
    CASE WHEN EXISTS(SELECT 1 FROM myshop_app_presence ap WHERE ap.user_id=a.user_id AND ap.active=1 AND datetime(ap.last_seen)>=datetime('now','-90 seconds')) THEN 1 ELSE 0 END AS online,
    CASE
      WHEN EXISTS(SELECT 1 FROM myshop_friend_requests f WHERE f.sender_id=? AND f.receiver_id=a.user_id AND f.status='PENDING') THEN 'REQUESTED'
      WHEN EXISTS(SELECT 1 FROM myshop_friend_requests f WHERE f.sender_id=a.user_id AND f.receiver_id=? AND f.status='PENDING') THEN 'INCOMING'
      WHEN EXISTS(SELECT 1 FROM myshop_friend_requests f WHERE f.status='ACCEPTED' AND ((f.sender_id=? AND f.receiver_id=a.user_id) OR (f.sender_id=a.user_id AND f.receiver_id=?))) THEN 'FRIEND'
      ELSE 'NONE'
    END AS relation_state
    FROM myshop_auth_users_v108 a
    WHERE a.active=1 AND a.user_id<>?
      AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=a.user_id) OR (b.blocker_id=a.user_id AND b.blocked_id=?))
    ORDER BY datetime(a.created_at) DESC,a.user_id DESC LIMIT ? OFFSET ?`).bind(user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,limit,offset).all()).results||[];
  return json({ok:true,people:rows.map(x=>({userId:x.user_id,name:x.full_name||'New Member',avatarUrl:x.avatar_url||'',joinedAt:x.created_at||'',state:x.relation_state||'NONE',level:Math.max(0,Number(x.level||0)),online:Number(x.online||0)===1})),hasMore:rows.length===limit,nextOffset:offset+rows.length},200,cors);
}

async function friendRequest(request,env) {
  await ensureFriendSchema(env);
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request),target=String(b.userId||'').trim(); if(!target||target===user.user_id)return json({error:'INVALID_USER'},400,cors);
  const found=await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1`).bind(target).first(); if(!found)return json({error:'USER_NOT_FOUND'},404,cors);
  const blocked=await env.DB.prepare(`SELECT 1 ok FROM myshop_user_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1`).bind(user.user_id,target,target,user.user_id).first(); if(blocked)return json({error:'NOT_AVAILABLE'},409,cors);
  const existing=await env.DB.prepare(`SELECT sender_id,receiver_id,status FROM myshop_friend_requests WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) LIMIT 1`).bind(user.user_id,target,target,user.user_id).first();
  if(existing){
    if(existing.status==='ACCEPTED') return json({error:'ALREADY_FRIENDS'},409,cors);
    if(existing.status==='PENDING') return json({error:'REQUEST_PENDING'},409,cors);
    if(existing.status==='DECLINED') await env.DB.prepare('DELETE FROM myshop_friend_requests WHERE sender_id=? AND receiver_id=?').bind(existing.sender_id,existing.receiver_id).run();
  }
  await env.DB.prepare(`INSERT INTO myshop_friend_requests(sender_id,receiver_id,status,created_at,updated_at) VALUES(?,?,'PENDING',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)`).bind(user.user_id,target).run();
  await createUserNotification(env,target,'Friend Request',(user.full_name||'A MY SHOP user')+' sent you a friend request.','FRIEND_REQUEST',user.user_id,user.user_id);
  return json({ok:true,status:'REQUESTED'},201,cors);
}

async function friendRequestsList(request,env){
  await ensureFriendSchema(env);
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const incoming=(await env.DB.prepare(`SELECT f.sender_id AS user_id,u.full_name,u.avatar_url,f.created_at FROM myshop_friend_requests f JOIN myshop_auth_users_v108 u ON u.user_id=f.sender_id WHERE f.receiver_id=? AND f.status='PENDING' AND u.active=1 ORDER BY datetime(f.created_at) DESC`).bind(user.user_id).all()).results||[];
  const outgoing=(await env.DB.prepare(`SELECT f.receiver_id AS user_id,u.full_name,u.avatar_url,f.created_at FROM myshop_friend_requests f JOIN myshop_auth_users_v108 u ON u.user_id=f.receiver_id WHERE f.sender_id=? AND f.status='PENDING' AND u.active=1 ORDER BY datetime(f.created_at) DESC`).bind(user.user_id).all()).results||[];
  const friends=(await env.DB.prepare(`SELECT CASE WHEN f.sender_id=? THEN f.receiver_id ELSE f.sender_id END AS user_id,u.full_name,u.avatar_url,f.updated_at FROM myshop_friend_requests f JOIN myshop_auth_users_v108 u ON u.user_id=CASE WHEN f.sender_id=? THEN f.receiver_id ELSE f.sender_id END WHERE (f.sender_id=? OR f.receiver_id=?) AND f.status='ACCEPTED' AND u.active=1 ORDER BY datetime(f.updated_at) DESC`).bind(user.user_id,user.user_id,user.user_id,user.user_id).all()).results||[];
  return json({ok:true,incoming:incoming.map(x=>({userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',createdAt:x.created_at||''})),outgoing:outgoing.map(x=>({userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',createdAt:x.created_at||''})),friends:friends.map(x=>({userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||''})),stats:await socialStatsFor(env,user.user_id)},200,cors);
}

async function friendRespond(request,env){
  await ensureFriendSchema(env);
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request),sender=String(b.userId||'').trim(),action=String(b.action||'').trim().toUpperCase();if(!sender||!['ACCEPT','DECLINE'].includes(action))return json({error:'INVALID_REQUEST'},400,cors);
  const row=await env.DB.prepare(`SELECT status FROM myshop_friend_requests WHERE sender_id=? AND receiver_id=?`).bind(sender,user.user_id).first();
  if(!row)return json({error:'REQUEST_NOT_FOUND'},404,cors);
  if(row.status==='ACCEPTED'&&action==='ACCEPT') return json({ok:true,status:'ACCEPTED',already:true,stats:await socialStatsFor(env,user.user_id),peerStats:await socialStatsFor(env,sender)},200,cors);
  if(row.status!=='PENDING')return json({error:'REQUEST_NOT_PENDING',status:row.status},409,cors);
  const status=action==='ACCEPT'?'ACCEPTED':'DECLINED';
  const changed=await env.DB.prepare(`UPDATE myshop_friend_requests SET status=?,updated_at=CURRENT_TIMESTAMP WHERE sender_id=? AND receiver_id=? AND status='PENDING'`).bind(status,sender,user.user_id).run();
  if(Number(changed?.meta?.changes||0)<1)return json({error:'FRIEND_UPDATE_FAILED'},409,cors);
  await createUserNotification(env,sender,action==='ACCEPT'?'Friend Request Accepted':'Friend Request Update',(user.full_name||'A MY SHOP user')+(action==='ACCEPT'?' accepted your friend request.':' declined your friend request.'),action==='ACCEPT'?'FRIEND_ACCEPT':'FRIEND_UPDATE',user.user_id,user.user_id);
  return json({ok:true,status,stats:await socialStatsFor(env,user.user_id),peerStats:await socialStatsFor(env,sender)},200,cors);
}


async function appPresence(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_app_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  const b=await body(request),active=b.active===false?0:1;
  await env.DB.prepare(`INSERT INTO myshop_app_presence(user_id,active,last_seen) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET active=excluded.active,last_seen=CURRENT_TIMESTAMP`).bind(user.user_id,active).run();
  return json({ok:true,active:!!active},200,cors);
}

async function livePresence(request,env){
  await ensureFriendSchema(env); const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,viewer_count INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await ensureLiveRoomSchema(env);
  const b=await body(request),active=b.active===false?0:1;
  const prev=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(user.user_id).first();
  await env.DB.prepare(`INSERT INTO myshop_live_presence(user_id,active,viewer_count,last_seen) VALUES(?,?,0,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET active=excluded.active,last_seen=CURRENT_TIMESTAMP`).bind(user.user_id,active).run();
  if(active && Number(prev?.active||0)!==1){
    const sessionId=crypto.randomUUID();
    await env.DB.prepare(`INSERT OR REPLACE INTO myshop_live_room_meta(host_id,special_guest_id,locked,title,topic,started_at,peak_viewers,share_count,pinned_message,theme_key,react_count,react_reward_milestone,session_id,welcome_message,goal_type,goal_target,pinned_product_id,updated_at) VALUES(?,NULL,0,?,'',CURRENT_TIMESTAMP,0,0,'','GUITAR_BLUE',0,0,?,'','NONE',0,0,CURRENT_TIMESTAMP)`).bind(user.user_id,(user.full_name||('Live '+user.user_id)).slice(0,40),sessionId).run();
    // Activate the nearest scheduled live and notify only users who explicitly requested a reminder.
    try{
      const sch=await env.DB.prepare(`SELECT id,title FROM myshop_live_schedules WHERE host_id=? AND status='SCHEDULED' AND datetime(scheduled_at)>=datetime('now','-12 hours') ORDER BY ABS(strftime('%s',scheduled_at)-strftime('%s','now')) LIMIT 1`).bind(user.user_id).first();
      if(sch){
        await env.DB.prepare(`UPDATE myshop_live_schedules SET status='LIVE',updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(sch.id).run();
        const reminders=(await env.DB.prepare(`SELECT user_id FROM myshop_live_reminders WHERE schedule_id=?`).bind(sch.id).all()).results||[];
        for(const r of reminders){try{await createUserNotification(env,String(r.user_id),'Scheduled Live Started',(user.full_name||'Host')+' is live now.','LIVE_SCHEDULE_START',user.user_id,user.user_id);}catch(e){}}
      }
    }catch(e){console.error('LIVE_SCHEDULE_ACTIVATE_FAILED',String(e?.message||e));}
  }
  if(!active){
    const m=await env.DB.prepare(`SELECT title,topic,started_at,peak_viewers,share_count,COALESCE(react_count,0) react_count,COALESCE(react_reward_milestone,0) react_reward_milestone,COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(user.user_id).first();
    if(m?.started_at){
      const seen=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_listener_seen WHERE host_id=? AND started_at=?`).bind(user.user_id,m.started_at).first();
      await env.DB.prepare(`INSERT INTO myshop_live_history(host_id,title,topic,started_at,ended_at,duration_seconds,peak_viewers,total_listeners,share_count,react_count,react_reward_coin,session_id) VALUES(?,?,?,?,CURRENT_TIMESTAMP,MAX(0,CAST((julianday('now')-julianday(?))*86400 AS INTEGER)),?,?,?,?,?,?)`).bind(user.user_id,m.title||'',m.topic||'',m.started_at,m.started_at,Number(m.peak_viewers||0),Number(seen?.c||0),Number(m.share_count||0),Number(m.react_count||0),Number(m.react_reward_milestone||0)*1000,String(m.session_id||'')).run();
      // V-304: Live comments are a transient session buffer only. They are never retained as history.
      await env.DB.prepare(`DELETE FROM myshop_live_comments WHERE host_id=? AND session_id=?`).bind(user.user_id,String(m.session_id||'')).run();
      await env.DB.prepare(`DELETE FROM myshop_live_highlight_comments WHERE host_id=? AND session_id=?`).bind(user.user_id,String(m.session_id||'')).run();
      liveEphemeralClear(user.user_id,String(m.session_id||''));
      try{await liveHubClear(env,user.user_id,String(m.session_id||''));}catch(e){}
      try{await env.DB.prepare(`UPDATE myshop_live_schedules SET status='ENDED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND status='LIVE'`).bind(user.user_id).run();}catch(e){}
      try{await env.DB.prepare(`UPDATE myshop_live_pk_rounds SET status='ENDED',ended_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE status='ACTIVE' AND (host_a=? OR host_b=?)`).bind(user.user_id,user.user_id).run();}catch(e){}
    }
    await env.DB.prepare(`DELETE FROM myshop_live_seats WHERE host_id=?`).bind(user.user_id).run();
    await env.DB.prepare(`DELETE FROM myshop_live_requests WHERE host_id=?`).bind(user.user_id).run();
    await env.DB.prepare(`DELETE FROM myshop_live_invites WHERE host_id=?`).bind(user.user_id).run();
    await env.DB.prepare(`DELETE FROM myshop_live_viewers WHERE host_id=?`).bind(user.user_id).run();
    await env.DB.prepare(`DELETE FROM myshop_live_seat_locks WHERE host_id=?`).bind(user.user_id).run();
    await env.DB.prepare(`DELETE FROM myshop_live_room_meta WHERE host_id=?`).bind(user.user_id).run();
    await env.DB.prepare(`UPDATE myshop_live_presence SET viewer_count=0 WHERE user_id=?`).bind(user.user_id).run();
  }
  if(active && Number(prev?.active||0)!==1){
    try{
      await ensureNotificationSchema(env);
      const liveTitle='🔴 Live Now';
      const liveBody=(user.full_name||'A MY SHOP user')+' is live now. Tap to join.';
      await env.DB.prepare(`INSERT INTO notifications(title,message,audience,user_id,type,actor_user_id,target_id,created_at)
        SELECT ?,?,'USER',f.follower_id,'LIVE_START',?, ?,CURRENT_TIMESTAMP FROM myshop_follows f JOIN myshop_auth_users_v108 u ON u.user_id=f.follower_id WHERE f.following_id=? AND u.active=1`).bind(liveTitle,liveBody,user.user_id,user.user_id,user.user_id).run();
      // V-340: real Android heads-up push only to users who follow this host and registered an active FCM token.
      const targets=(await env.DB.prepare(`SELECT DISTINCT p.user_id FROM myshop_push_tokens p JOIN myshop_follows f ON f.follower_id=p.user_id WHERE p.active=1 AND f.following_id=? LIMIT 5000`).bind(user.user_id).all()).results||[];
      for(let i=0;i<targets.length;i+=40){const batch=targets.slice(i,i+40);await Promise.all(batch.map(r=>sendPushToUser(env,String(r.user_id),liveTitle,liveBody,'LIVE_START',user.user_id,user.user_id)));}
    }catch(e){console.error('LIVE_NOTIFICATION_FAILED',String(e?.message||e));}
  }
  return json({ok:true,active:!!active},200,cors);
}

// V-307: server-confirmed, idempotent host End Live endpoint.
async function liveEnd(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  await ensureLiveRoomSchema(env);
  const row=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(user.user_id).first();
  if(row && Number(row.active)===1){
    const endReq=new Request(request.url,{method:'POST',headers:request.headers,body:JSON.stringify({active:false})});
    const ended=await livePresence(endReq,env);
    if(!ended.ok)return ended;
  }
  const check=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(user.user_id).first();
  const closed=!check || Number(check.active)!==1;
  if(!closed)return json({error:'LIVE_END_NOT_CONFIRMED'},409,cors);
  const latest=await env.DB.prepare(`SELECT id,title,topic,started_at,ended_at,duration_seconds,peak_viewers,total_listeners,share_count,COALESCE(react_count,0) react_count,COALESCE(react_reward_coin,0) react_reward_coin,COALESCE(session_id,'') session_id FROM myshop_live_history WHERE host_id=? ORDER BY id DESC LIMIT 1`).bind(user.user_id).first();
  return json({ok:true,closed:true,summary:latest||null},200,cors);
}

async function liveViewer(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const b=await body(request),hostId=String(b.hostId||'').trim(),joined=b.joined===false?0:1;
  if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,viewer_count INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await ensureLiveRoomSchema(env);
  const row=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();
  if(!row||Number(row.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  const sanction=await liveSanctionFor(env,hostId,user.user_id);if(joined&&sanction==='BLOCKED')return json({error:'LIVE_BLOCKED'},403,cors);if(joined&&sanction==='KICKED')await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state='KICKED'`).bind(hostId,user.user_id).run();
  const currentMeta=await env.DB.prepare(`SELECT COALESCE(started_at,'') started_at,COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();
  const currentSessionId=String(currentMeta?.session_id||'');
  if(user.user_id!==hostId){
    if(joined){
      const was=await env.DB.prepare(`SELECT 1 x FROM myshop_live_viewers WHERE host_id=? AND user_id=?`).bind(hostId,user.user_id).first();
      await env.DB.prepare(`INSERT INTO myshop_live_viewers(host_id,user_id,last_seen,joined_at) VALUES(?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id) DO UPDATE SET last_seen=CURRENT_TIMESTAMP,joined_at=CASE WHEN COALESCE(myshop_live_viewers.joined_at,'')='' THEN CURRENT_TIMESTAMP ELSE myshop_live_viewers.joined_at END`).bind(hostId,user.user_id).run();
      const started=String(currentMeta?.started_at||'');
      if(started)await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_listener_seen(host_id,started_at,user_id) VALUES(?,?,?)`).bind(hostId,started,user.user_id).run();
      if(!was){
        await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'JOIN','joined the live')`).bind(hostId,user.user_id,currentSessionId).run();
        if(currentSessionId)await liveHubDirty(env,hostId,currentSessionId,'VIEWER_JOINED');
        try{
          const tier=await currentTier(env,user.user_id);
          await env.DB.prepare(`INSERT INTO myshop_live_entry_events(host_id,user_id,tier) VALUES(?,?,?)`).bind(hostId,user.user_id,tier).run();
          await env.DB.prepare(`UPDATE myshop_live_fan_club SET points=points+1,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND active=1`).bind(hostId,user.user_id).run();
        }catch(e){}
      }
    }else{
      const was=await env.DB.prepare(`SELECT 1 x FROM myshop_live_viewers WHERE host_id=? AND user_id=?`).bind(hostId,user.user_id).first();
      await env.DB.prepare(`DELETE FROM myshop_live_viewers WHERE host_id=? AND user_id=?`).bind(hostId,user.user_id).run();
      if(was){await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'LEAVE','left the live')`).bind(hostId,user.user_id,currentSessionId).run();if(currentSessionId)await liveHubDirty(env,hostId,currentSessionId,'VIEWER_LEFT');}
    }
  }
  await env.DB.prepare(`DELETE FROM myshop_live_viewers WHERE host_id=? AND datetime(last_seen)<datetime('now','-25 seconds')`).bind(hostId).run();
  const c=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_viewers WHERE host_id=?`).bind(hostId).first();
  const next=Math.max(0,Number(c?.c||0));
  await env.DB.prepare(`UPDATE myshop_live_presence SET viewer_count=? WHERE user_id=?`).bind(next,hostId).run();
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET peak_viewers=MAX(COALESCE(peak_viewers,0),?),updated_at=CURRENT_TIMESTAMP WHERE host_id=?`).bind(next,hostId).run();
  return json({ok:true,viewerCount:next},200,cors);
}

async function ensureLiveRoomSchemaImpl(env){
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_seats (host_id TEXT NOT NULL,seat_no INTEGER NOT NULL,user_id TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'SPEAKER',muted INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,seat_no),UNIQUE(host_id,user_id),CHECK(seat_no BETWEEN 1 AND 12))`).run();
  for(const sql of [
    `ALTER TABLE myshop_live_seats ADD COLUMN mic_on INTEGER NOT NULL DEFAULT 1`,
    `ALTER TABLE myshop_live_seats ADD COLUMN speaking INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_seats ADD COLUMN network_quality TEXT NOT NULL DEFAULT 'GOOD'`
  ]){try{await env.DB.prepare(sql).run();}catch(e){}}
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_requests (host_id TEXT NOT NULL,user_id TEXT NOT NULL,session_id TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,user_id))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_invites (host_id TEXT NOT NULL,user_id TEXT NOT NULL,session_id TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',expires_at TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,user_id,session_id))`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_invites_user ON myshop_live_invites(user_id,status,expires_at)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_viewers (host_id TEXT NOT NULL,user_id TEXT NOT NULL,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,user_id))`).run();
  try{await env.DB.prepare(`ALTER TABLE myshop_live_viewers ADD COLUMN joined_at TEXT NOT NULL DEFAULT ''`).run();}catch(e){}
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_room_meta (host_id TEXT PRIMARY KEY,special_guest_id TEXT,locked INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  for(const sql of [
    `ALTER TABLE myshop_live_room_meta ADD COLUMN title TEXT NOT NULL DEFAULT 'Let''s Talk Together'`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN topic TEXT NOT NULL DEFAULT 'Audio Live'`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN started_at TEXT`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN peak_viewers INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN share_count INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN pinned_message TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN theme_key TEXT NOT NULL DEFAULT 'GUITAR_BLUE'`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN welcome_message TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN goal_type TEXT NOT NULL DEFAULT 'NONE'`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN goal_target INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN pinned_product_id INTEGER NOT NULL DEFAULT 0`
  ]){try{await env.DB.prepare(sql).run();}catch(e){}}
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_seat_locks (host_id TEXT NOT NULL,seat_no INTEGER NOT NULL,locked INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,seat_no))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_events (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,user_id TEXT,event_type TEXT NOT NULL,message TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  try{await env.DB.prepare(`ALTER TABLE myshop_live_events ADD COLUMN session_id TEXT NOT NULL DEFAULT ''`).run();}catch(e){}
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_events_session ON myshop_live_events(host_id,session_id,id DESC)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_comments (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,user_id TEXT NOT NULL,message TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_comment_ui (id INTEGER PRIMARY KEY CHECK(id=1),font_size INTEGER NOT NULL DEFAULT 15,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_comment_ui(id,font_size) VALUES(1,15)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_comment_global (id INTEGER PRIMARY KEY CHECK(id=1),style_json TEXT NOT NULL DEFAULT '{}',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_comment_global(id,style_json) VALUES(1,'{}')`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_comment_presets (preset_key TEXT PRIMARY KEY,badge TEXT NOT NULL,gender TEXT NOT NULL,preset_no INTEGER NOT NULL,style_json TEXT NOT NULL DEFAULT '{}',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_comment_assignments (user_id TEXT PRIMARY KEY,preset_key TEXT NOT NULL DEFAULT '',custom_style_json TEXT NOT NULL DEFAULT '{}',is_custom INTEGER NOT NULL DEFAULT 0,enabled INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  const commentPresetSeeds=[
    ['VIP','MALE',['#3A237A','#243A88','#1F5C78','#5A2A79','#78411E']],['VIP','FEMALE',['#7E2A72','#8A2D64','#683A86','#A02F67','#744083']],
    ['VVIP','MALE',['#53206F','#3C286F','#6B224B','#332C83','#71334A']],['VVIP','FEMALE',['#8E145F','#A51A6D','#7D2788','#A62E73','#853379']],
    ['ROYAL','MALE',['#74510F','#67460B','#70591E','#5B4611','#805A13']],['ROYAL','FEMALE',['#8C5D26','#91612F','#7D5730','#9D6A34','#8B6335']],
    ['KING','MALE',['#083A8C','#0B4B8F','#173D78','#0F5689','#254A82']],['QUEEN','FEMALE',['#9C145F','#A51F70','#8B2A7D','#A13372','#903B82']]
  ];
  for(const [badge,gender,colors] of commentPresetSeeds){for(let i=0;i<5;i++){const key=`${badge}-${gender}-${i+1}`,bg=colors[i],accent=badge==='ROYAL'?'#FFD45A':badge==='KING'?'#42A5FF':badge==='QUEEN'?'#FF63C4':gender==='FEMALE'?'#FF5DB1':'#A855F7';const st={backgroundColor:bg,textColor:'#FFFFFF',nameColor:'#FFD54F',levelColor:'#40D9FF',borderColor:accent,fontSize:17,fontWeight:'BOLD',borderWidth:2,cornerRadius:16,opacity:100,borderGlow:true,borderGlowColor:accent,borderGlowIntensity:60,backgroundGlow:false,animation:true,animationType:'PULSE',animationSpeed:55,boxAnimation:true,boxAnimationType:'PULSE',borderAnimation:true,borderAnimationType:'GLOW BORDER',textAnimation:false,textAnimationType:'FADE TEXT',nameAnimation:false,nameAnimationType:'SOFT GLOW',levelAnimation:false,levelAnimationType:'SOFT GLOW'};await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_comment_presets(preset_key,badge,gender,preset_no,style_json) VALUES(?,?,?,?,?)`).bind(key,badge,gender,i+1,JSON.stringify(st)).run();}}
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_listener_seen (host_id TEXT NOT NULL,started_at TEXT NOT NULL,user_id TEXT NOT NULL,PRIMARY KEY(host_id,started_at,user_id))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_history (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,title TEXT,topic TEXT,started_at TEXT,ended_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,duration_seconds INTEGER NOT NULL DEFAULT 0,peak_viewers INTEGER NOT NULL DEFAULT 0,total_listeners INTEGER NOT NULL DEFAULT 0,share_count INTEGER NOT NULL DEFAULT 0,react_count INTEGER NOT NULL DEFAULT 0,react_reward_coin INTEGER NOT NULL DEFAULT 0)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_themes (theme_key TEXT PRIMARY KEY,name TEXT NOT NULL,background_url TEXT NOT NULL DEFAULT '',accent TEXT NOT NULL DEFAULT '#8A2BE2',coin_price INTEGER NOT NULL DEFAULT 0,enabled INTEGER NOT NULL DEFAULT 1,sort_order INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  // V-300 recovery: migrate old production D1 safely BEFORE touching new theme columns.
  for(const sql of [
    `ALTER TABLE myshop_live_themes ADD COLUMN name TEXT NOT NULL DEFAULT 'Theme'`,
    `ALTER TABLE myshop_live_themes ADD COLUMN background_url TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_themes ADD COLUMN accent TEXT NOT NULL DEFAULT '#8A2BE2'`,
    `ALTER TABLE myshop_live_themes ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1`,
    `ALTER TABLE myshop_live_themes ADD COLUMN sort_order INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_themes ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_themes ADD COLUMN coin_price INTEGER NOT NULL DEFAULT 0`
  ]){try{await env.DB.prepare(sql).run();}catch(e){}}
  try{await env.DB.prepare(`UPDATE myshop_live_themes SET name=COALESCE(NULLIF(name,''),theme_key),background_url=COALESCE(background_url,''),accent=COALESCE(NULLIF(accent,''),'#8A2BE2'),coin_price=COALESCE(coin_price,0),enabled=COALESCE(enabled,1),sort_order=COALESCE(sort_order,0)`).run();}catch(e){}
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_themes(theme_key,name,background_url,accent,coin_price,enabled,sort_order) VALUES('GUITAR_BLUE','Guitar Blue','','#5B67FF',0,1,0)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_room_admins (host_id TEXT NOT NULL,user_id TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,user_id))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_sanctions (host_id TEXT NOT NULL,user_id TEXT NOT NULL,state TEXT NOT NULL DEFAULT 'NONE',reason TEXT NOT NULL DEFAULT '',updated_by TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,user_id))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_gifts (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('COIN','GOLD')),price INTEGER NOT NULL DEFAULT 1,category TEXT NOT NULL DEFAULT 'ALL',preview_url TEXT NOT NULL DEFAULT '',animation_url TEXT NOT NULL DEFAULT '',animation_mime TEXT NOT NULL DEFAULT '',animation_enabled INTEGER NOT NULL DEFAULT 1,sound_url TEXT NOT NULL DEFAULT '',sound_enabled INTEGER NOT NULL DEFAULT 1,sound_volume INTEGER NOT NULL DEFAULT 85,effect_duration_ms INTEGER NOT NULL DEFAULT 2800,sound_duration_ms INTEGER NOT NULL DEFAULT 2500,sound_trim_start_pct INTEGER NOT NULL DEFAULT 0,sound_trim_end_pct INTEGER NOT NULL DEFAULT 100,vat_percent INTEGER NOT NULL DEFAULT 10,board_position TEXT NOT NULL DEFAULT 'CENTER',animation_scale INTEGER NOT NULL DEFAULT 70,size_mode TEXT NOT NULL DEFAULT 'MEDIUM',catalog_animation_enabled INTEGER NOT NULL DEFAULT 1,catalog_animation_type TEXT NOT NULL DEFAULT 'AUTO',catalog_preview_size INTEGER NOT NULL DEFAULT 68,catalog_animation_strength INTEGER NOT NULL DEFAULT 42,catalog_animation_speed INTEGER NOT NULL DEFAULT 45,catalog_glow_particle INTEGER NOT NULL DEFAULT 35,catalog_loop INTEGER NOT NULL DEFAULT 1,catalog_animation_url TEXT NOT NULL DEFAULT '',sort_order INTEGER NOT NULL DEFAULT 100,enabled INTEGER NOT NULL DEFAULT 1,deleted INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_gift_events (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL,gift_id INTEGER NOT NULL,currency TEXT NOT NULL,price INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'COMPLETED',client_nonce TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  for(const sql of [
    `ALTER TABLE myshop_live_gifts ADD COLUMN category TEXT NOT NULL DEFAULT 'ALL'`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN animation_scale INTEGER NOT NULL DEFAULT 70`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN effect_duration_ms INTEGER NOT NULL DEFAULT 2800`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN sound_duration_ms INTEGER NOT NULL DEFAULT 2500`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN sound_trim_start_pct INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN sound_trim_end_pct INTEGER NOT NULL DEFAULT 100`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN vat_percent INTEGER NOT NULL DEFAULT 10`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN board_position TEXT NOT NULL DEFAULT 'CENTER'`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN catalog_animation_enabled INTEGER NOT NULL DEFAULT 1`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN catalog_animation_type TEXT NOT NULL DEFAULT 'AUTO'`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN catalog_preview_size INTEGER NOT NULL DEFAULT 68`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN catalog_animation_strength INTEGER NOT NULL DEFAULT 42`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN catalog_animation_speed INTEGER NOT NULL DEFAULT 45`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN catalog_glow_particle INTEGER NOT NULL DEFAULT 35`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN catalog_loop INTEGER NOT NULL DEFAULT 1`,
    `ALTER TABLE myshop_live_gifts ADD COLUMN catalog_animation_url TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_gift_events ADD COLUMN client_nonce TEXT NOT NULL DEFAULT ''`
  ]){try{await env.DB.prepare(sql).run();}catch(e){}}
  try{await env.DB.prepare(`CREATE UNIQUE INDEX IF NOT EXISTS idx_live_gift_nonce ON myshop_live_gift_events(host_id,session_id,sender_id,client_nonce) WHERE client_nonce<>''`).run();}catch(e){}
  // V-317 starter catalog: a clean 5 Coin + 5 Gold Coin set on a fresh database.
  // Existing production/Admin-created gifts are preserved. A starter gift that Admin deleted is not resurrected.
  const starterGifts=[
    ['Rose','COIN',10,'SMALL',10],['Heart','COIN',20,'SMALL',20],['Teddy','COIN',50,'MEDIUM',30],['Chocolate Gift','COIN',100,'MEDIUM',40],['Star','COIN',200,'LARGE',50],
    ['Diamond','GOLD',1000,'LARGE',10],['Royal Crown','GOLD',2000,'LARGE',20],['Sports Car','GOLD',5000,'FULL_SCREEN',30],['Private Jet','GOLD',10000,'FULL_SCREEN',40],['Royal Castle','GOLD',20000,'FULL_SCREEN',50]
  ];
  const giftCount=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_gifts`).first();
  if(Number(giftCount?.c||0)===0){
    for(const [name,currency,price,size,sort] of starterGifts) await env.DB.prepare(`INSERT INTO myshop_live_gifts(name,currency,price,size_mode,sort_order,enabled,animation_enabled,sound_enabled,sound_volume,animation_scale,deleted) VALUES(?,?,?,?,?,1,1,1,85,70,0)`).bind(name,currency,price,size,sort).run();
  } else {
    // Upgrade path: add a missing starter only if no historical row with that stable name/currency exists.
    for(const [name,currency,price,size,sort] of starterGifts){
      const ex=await env.DB.prepare(`SELECT id FROM myshop_live_gifts WHERE name=? AND currency=? ORDER BY id LIMIT 1`).bind(name,currency).first();
      if(!ex) await env.DB.prepare(`INSERT INTO myshop_live_gifts(name,currency,price,size_mode,sort_order,enabled,animation_enabled,sound_enabled,sound_volume,animation_scale,deleted) VALUES(?,?,?,?,?,1,1,1,85,70,0)`).bind(name,currency,price,size,sort).run();
    }
  }

  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_global_bans (user_id TEXT PRIMARY KEY,reason TEXT NOT NULL DEFAULT '',permanent INTEGER NOT NULL DEFAULT 1,banned_by TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_finance_config (id INTEGER PRIMARY KEY CHECK(id=1),platform_fee_percent REAL NOT NULL DEFAULT 10.0,highlight_comment_coin_price INTEGER NOT NULL DEFAULT 1000,coin_units_per_600_taka INTEGER NOT NULL DEFAULT 100000,updated_by TEXT NOT NULL DEFAULT '0001',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  // V-317 production-safe finance migration: old D1 databases may predate coin_units_per_600_taka.
  for(const sql of [
    `ALTER TABLE myshop_finance_config ADD COLUMN platform_fee_percent REAL NOT NULL DEFAULT 10.0`,
    `ALTER TABLE myshop_finance_config ADD COLUMN highlight_comment_coin_price INTEGER NOT NULL DEFAULT 1000`,
    `ALTER TABLE myshop_finance_config ADD COLUMN coin_units_per_600_taka INTEGER NOT NULL DEFAULT 100000`,
    `ALTER TABLE myshop_finance_config ADD COLUMN updated_by TEXT NOT NULL DEFAULT '0001'`,
    `ALTER TABLE myshop_finance_config ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''`
  ]){try{await env.DB.prepare(sql).run();}catch(e){}}
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_finance_config(id,platform_fee_percent,highlight_comment_coin_price,coin_units_per_600_taka,updated_by) VALUES(1,10.0,1000,100000,'0001')`).run();
  try{await env.DB.prepare(`UPDATE myshop_finance_config SET coin_units_per_600_taka=COALESCE(coin_units_per_600_taka,100000),platform_fee_percent=COALESCE(platform_fee_percent,10.0),highlight_comment_coin_price=COALESCE(highlight_comment_coin_price,1000) WHERE id=1`).run();}catch(e){}
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_name_policy (user_id TEXT PRIMARY KEY,live_name TEXT NOT NULL,changed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_value_ledger (id INTEGER PRIMARY KEY AUTOINCREMENT,tx_type TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('COIN','GOLD')),sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL DEFAULT '',host_id TEXT NOT NULL DEFAULT '',gift_id INTEGER NOT NULL DEFAULT 0,gross_amount INTEGER NOT NULL,fee_percent REAL NOT NULL DEFAULT 0,fee_amount INTEGER NOT NULL DEFAULT 0,net_amount INTEGER NOT NULL DEFAULT 0,platform_amount INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'COMPLETED',reference TEXT NOT NULL DEFAULT '',metadata TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await ensureLevelSchema(env);
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_value_ledger_sender ON myshop_value_ledger(sender_id,created_at,id)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_value_ledger_receiver ON myshop_value_ledger(receiver_id,created_at,id)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_value_ledger_host ON myshop_value_ledger(host_id,created_at,id)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_highlight_comments (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,user_id TEXT NOT NULL,message TEXT NOT NULL,coin_cost INTEGER NOT NULL DEFAULT 0,free_privilege INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'QUEUED',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_moderation_audit (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,actor_id TEXT NOT NULL,target_id TEXT NOT NULL,action TEXT NOT NULL,reason TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_entry_events (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,user_id TEXT NOT NULL,tier TEXT NOT NULL DEFAULT 'STANDARD',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  for(const sql of [
    `ALTER TABLE myshop_live_room_meta ADD COLUMN slow_mode_seconds INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN entry_effects_enabled INTEGER NOT NULL DEFAULT 1`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN gift_combo_enabled INTEGER NOT NULL DEFAULT 1`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN react_count INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN react_reward_milestone INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_room_meta ADD COLUMN session_id TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_requests ADD COLUMN session_id TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_comments ADD COLUMN session_id TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_comments ADD COLUMN client_nonce TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_highlight_comments ADD COLUMN session_id TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_themes ADD COLUMN coin_price INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_history ADD COLUMN react_count INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_history ADD COLUMN react_reward_coin INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE myshop_live_history ADD COLUMN session_id TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE myshop_live_gift_events ADD COLUMN session_id TEXT NOT NULL DEFAULT ''`
  ]){try{await env.DB.prepare(sql).run();}catch(e){}}
  try{await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_comments_session ON myshop_live_comments(host_id,session_id,id)`).run();}catch(e){}
  try{await env.DB.prepare(`CREATE UNIQUE INDEX IF NOT EXISTS idx_live_comments_nonce ON myshop_live_comments(host_id,session_id,user_id,client_nonce) WHERE client_nonce<>''`).run();}catch(e){}
  try{await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_highlights_session ON myshop_live_highlight_comments(host_id,session_id,id)`).run();}catch(e){}
  try{await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_gifts_session ON myshop_live_gift_events(host_id,session_id,id)`).run();}catch(e){}
  try{await env.DB.prepare(`CREATE UNIQUE INDEX IF NOT EXISTS idx_live_gift_nonce ON myshop_live_gift_events(host_id,session_id,sender_id,client_nonce) WHERE client_nonce<>''`).run();}catch(e){}
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_fan_club (host_id TEXT NOT NULL,user_id TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,points INTEGER NOT NULL DEFAULT 0,joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,user_id))`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_fan_club_host ON myshop_live_fan_club(host_id,active,points)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_schedules (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,title TEXT NOT NULL,topic TEXT NOT NULL DEFAULT '',scheduled_at TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'SCHEDULED',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_schedules_host ON myshop_live_schedules(host_id,status,scheduled_at)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_reminders (schedule_id INTEGER NOT NULL,user_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(schedule_id,user_id))`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_pk_rounds (id INTEGER PRIMARY KEY AUTOINCREMENT,host_a TEXT NOT NULL,host_b TEXT NOT NULL,session_a TEXT NOT NULL DEFAULT '',session_b TEXT NOT NULL DEFAULT '',status TEXT NOT NULL DEFAULT 'PENDING',started_at TEXT,ended_at TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE INDEX IF NOT EXISTS idx_live_pk_hosts ON myshop_live_pk_rounds(host_a,host_b,status,created_at)`).run();
}
const liveSchemaInitByEnv = new WeakMap();
async function ensureLiveRoomSchema(env){
  let p=liveSchemaInitByEnv.get(env);
  if(!p){
    p=ensureLiveRoomSchemaImpl(env).catch(e=>{ liveSchemaInitByEnv.delete(env); throw e; });
    liveSchemaInitByEnv.set(env,p);
  }
  return p;
}
async function liveSanctionFor(env,hostId,userId){
  const r=await env.DB.prepare(`SELECT state FROM myshop_live_sanctions WHERE host_id=? AND user_id=?`).bind(hostId,userId).first();
  return String(r?.state||'NONE').toUpperCase();
}
async function isRoomAdmin(env,hostId,userId){
  if(hostId===userId)return true;
  const r=await env.DB.prepare(`SELECT active FROM myshop_live_room_admins WHERE host_id=? AND user_id=?`).bind(hostId,userId).first();
  return Number(r?.active||0)===1;
}
async function liveModerationAction(request,env){
  const actor=await getUser(request,env); if(!actor)return json({error:'UNAUTHORIZED'},401,cors); await ensureLiveRoomSchema(env);
  const b=await body(request),hostId=String(b.hostId||'').trim(),uid=String(b.userId||'').trim(),action=String(b.action||'').toUpperCase();
  if(!isFourDigit(hostId)||!isFourDigit(uid)||uid===hostId)return json({error:'INVALID_TARGET'},400,cors);
  const hostActor=actor.user_id===hostId, roomAdmin=await isRoomAdmin(env,hostId,actor.user_id), globalAdmin=isAdminUser(actor), globalModerator=String(actor.role||'').toUpperCase()==='MODERATOR';
  if(['MUTE','UNMUTE'].includes(action)){
    if(!(hostActor||roomAdmin||globalAdmin||globalModerator))return json({error:'FORBIDDEN'},403,cors);
    if(action==='MUTE'){
      await env.DB.prepare(`INSERT INTO myshop_live_sanctions(host_id,user_id,state,updated_by,updated_at) VALUES(?,?,'MUTED',?,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id) DO UPDATE SET state='MUTED',updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP`).bind(hostId,uid,actor.user_id).run();
      await env.DB.prepare(`DELETE FROM myshop_live_requests WHERE host_id=? AND user_id=?`).bind(hostId,uid).run();
      await env.DB.prepare(`DELETE FROM myshop_live_seats WHERE host_id=? AND user_id=? AND seat_no>1`).bind(hostId,uid).run();
    } else await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state='MUTED'`).bind(hostId,uid).run();
    await recordModerationAudit(env,hostId,actor.user_id,uid,action); await liveHubDirtyForHost(env,hostId,'MODERATION_'+action); return json({ok:true,state:action==='MUTE'?'MUTED':'NONE'},200,cors);
  }
  if(roomAdmin&&!hostActor&&!globalAdmin&&!globalModerator)return json({error:'ROOM_ADMIN_MUTE_ONLY'},403,cors);
  if(action==='KICK'){
    if(!(hostActor||globalAdmin||globalModerator))return json({error:'FORBIDDEN'},403,cors);
    await env.DB.prepare(`INSERT INTO myshop_live_sanctions(host_id,user_id,state,updated_by,updated_at) VALUES(?,?,'KICKED',?,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id) DO UPDATE SET state='KICKED',updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP`).bind(hostId,uid,actor.user_id).run();
    await env.DB.prepare(`DELETE FROM myshop_live_viewers WHERE host_id=? AND user_id=?`).bind(hostId,uid).run(); await env.DB.prepare(`DELETE FROM myshop_live_seats WHERE host_id=? AND user_id=? AND seat_no>1`).bind(hostId,uid).run();
    await recordModerationAudit(env,hostId,actor.user_id,uid,'KICK'); await liveHubDirtyForHost(env,hostId,'MODERATION_KICK'); return json({ok:true,state:'KICKED'},200,cors);
  }
  if(['BLOCK','UNBLOCK'].includes(action)){
    if(!(hostActor||globalAdmin))return json({error:'FORBIDDEN'},403,cors);
    if(action==='BLOCK'){
      await env.DB.prepare(`INSERT INTO myshop_live_sanctions(host_id,user_id,state,updated_by,updated_at) VALUES(?,?,'BLOCKED',?,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id) DO UPDATE SET state='BLOCKED',updated_by=excluded.updated_by,updated_at=CURRENT_TIMESTAMP`).bind(hostId,uid,actor.user_id).run();
      await env.DB.prepare(`DELETE FROM myshop_live_viewers WHERE host_id=? AND user_id=?`).bind(hostId,uid).run(); await env.DB.prepare(`DELETE FROM myshop_live_seats WHERE host_id=? AND user_id=? AND seat_no>1`).bind(hostId,uid).run();
    } else await env.DB.prepare(`DELETE FROM myshop_live_sanctions WHERE host_id=? AND user_id=? AND state='BLOCKED'`).bind(hostId,uid).run();
    await recordModerationAudit(env,hostId,actor.user_id,uid,action); await liveHubDirtyForHost(env,hostId,'MODERATION_'+action); return json({ok:true,state:action==='BLOCK'?'BLOCKED':'NONE'},200,cors);
  }
  if(['ADD_ROOM_ADMIN','REMOVE_ROOM_ADMIN'].includes(action)){
    if(!hostActor)return json({error:'HOST_ONLY'},403,cors);
    if(action==='ADD_ROOM_ADMIN'){
      const c=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_room_admins WHERE host_id=? AND active=1`).bind(hostId).first(); if(Number(c?.c||0)>=5)return json({error:'ROOM_ADMIN_LIMIT'},409,cors);
      await env.DB.prepare(`INSERT INTO myshop_live_room_admins(host_id,user_id,active) VALUES(?,?,1) ON CONFLICT(host_id,user_id) DO UPDATE SET active=1`).bind(hostId,uid).run();
    } else await env.DB.prepare(`UPDATE myshop_live_room_admins SET active=0 WHERE host_id=? AND user_id=?`).bind(hostId,uid).run();
    await recordModerationAudit(env,hostId,actor.user_id,uid,action); await liveHubDirtyForHost(env,hostId,'ROOM_ADMIN_'+action); return json({ok:true},200,cors);
  }
  if(action==='PERMANENT_BAN'){
    if(!(await isFixedMainAdminId(actor.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);
    await env.DB.prepare(`INSERT INTO myshop_global_bans(user_id,banned_by) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET banned_by=excluded.banned_by,created_at=CURRENT_TIMESTAMP`).bind(uid,actor.user_id).run();
    await env.DB.prepare(`UPDATE myshop_auth_users_v108 SET active=0 WHERE user_id=? AND user_id NOT IN ('0001','0002','0003')`).bind(uid).run();
    await recordModerationAudit(env,hostId,actor.user_id,uid,'PERMANENT_BAN'); await liveHubDirtyForHost(env,hostId,'PERMANENT_BAN'); return json({ok:true,permanent:true},200,cors);
  }
  return json({error:'UNSUPPORTED_ACTION'},400,cors);
}
async function isFixedMainAdminId(userId){return ['0001','0002','0003'].includes(String(userId||''));}
async function isAssignedModerator(env,userId){
  const r=await env.DB.prepare(`SELECT active FROM myshop_moderators_v108 WHERE user_id=?`).bind(String(userId||'')).first();
  return Number(r?.active||0)===1;
}
async function financeConfig(env){
  await ensureLiveRoomSchema(env);
  const r=await env.DB.prepare(`SELECT platform_fee_percent,highlight_comment_coin_price,coin_units_per_600_taka FROM myshop_finance_config WHERE id=1`).first();
  return {feePercent:Math.max(0,Math.min(100,Number(r?.platform_fee_percent||0))),highlightPrice:Math.max(0,Number(r?.highlight_comment_coin_price||1000)),unitsPer600Taka:Math.max(10000,Number(r?.coin_units_per_600_taka||100000)),liveNameEarlyChangePrice:5000};
}
function splitPlatformFee(gross,pct){const g=Math.max(0,Math.floor(Number(gross||0)));const fee=Math.max(0,Math.min(g,Math.round(g*Number(pct||0)/100)));return {gross:g,fee,net:g-fee};}
function starCountFor(currency,units){const divisor=String(currency).toUpperCase()==='GOLD'?1000:100000;return Math.max(0,Math.floor(Number(units||0)/divisor));}
async function applyStarsAndLevels(env,{txType,currency,senderId='',receiverId,units=0,official=false,reference=''}){
  await ensureLevelSchema(env);
  const cur=String(currency||'COIN').toUpperCase()==='GOLD'?'GOLD':'COIN', amount=Math.max(0,Math.floor(Number(units||0)));
  if(!receiverId||amount<=0)return {stars:0,levelAdded:0};
  const col=official?(cur==='GOLD'?'official_gold_units':'official_coin_units'):(cur==='GOLD'?'normal_gold_units':'normal_coin_units');
  const threshold=cur==='GOLD'?1000:100000;
  const beforeRow=await env.DB.prepare(`SELECT ${col} units FROM myshop_user_progress WHERE user_id=?`).bind(receiverId).first();
  const before=Math.max(0,Number(beforeRow?.units||0)),after=before+amount;
  const stars=Math.max(0,Math.floor(after/threshold)-Math.floor(before/threshold));
  const levelAdded=stars*(official?2:1);
  await env.DB.prepare(`UPDATE myshop_user_progress SET ${col}=?,stars=stars+?,level=level+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(after,stars,levelAdded,receiverId).run();
  await env.DB.prepare(`INSERT INTO myshop_star_level_ledger(tx_type,currency,sender_id,receiver_id,units,stars,level_added,official,reference) VALUES(?,?,?,?,?,?,?,?,?)`).bind(txType,cur,senderId,receiverId,amount,stars,levelAdded,official?1:0,reference).run();
  return {stars,levelAdded};
}
async function currentTier(env,userId){
  const r=await env.DB.prepare(`SELECT badge_code FROM myshop_user_badges WHERE user_id=? AND status='ACTIVE' AND (expires_at IS NULL OR datetime(expires_at)>datetime('now')) AND badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP') ORDER BY CASE badge_code WHEN 'KING' THEN 1 WHEN 'QUEEN' THEN 1 WHEN 'ROYAL' THEN 2 WHEN 'VVIP' THEN 3 WHEN 'VIP' THEN 4 ELSE 9 END LIMIT 1`).bind(userId).first();
  return String(r?.badge_code||'STANDARD');
}
async function recordModerationAudit(env,hostId,actorId,targetId,action,reason=''){
  await env.DB.prepare(`INSERT INTO myshop_live_moderation_audit(host_id,actor_id,target_id,action,reason) VALUES(?,?,?,?,?)`).bind(hostId,actorId,targetId,action,String(reason||'').slice(0,180)).run();
}
async function liveHighlightConfig(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);const c=await financeConfig(env);const free=(await isFixedMainAdminId(me.user_id))||(await isAssignedModerator(env,me.user_id));return json({ok:true,coinPrice:c.highlightPrice,free},200,cors);
}
async function liveHighlightComment(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||'').trim(),message=String(b.message||'').trim().slice(0,180);if(!isFourDigit(hostId)||!message)return json({error:'INVALID_HIGHLIGHT_COMMENT'},400,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  const sanction=await liveSanctionFor(env,hostId,me.user_id);if(['MUTED','BLOCKED','KICKED'].includes(sanction))return json({error:sanction==='MUTED'?'LIVE_MUTED_LISTEN_ONLY':'LIVE_NOT_ALLOWED'},403,cors);
  const cfg=await financeConfig(env),free=(await isFixedMainAdminId(me.user_id))||(await isAssignedModerator(env,me.user_id));let cost=free?0:cfg.highlightPrice;
  if(cost>0){
    await env.DB.prepare(`INSERT OR IGNORE INTO myshop_coin_wallets(user_id,balance) VALUES(?,0)`).bind(me.user_id).run();
    const wallet=await env.DB.prepare(`SELECT balance FROM myshop_coin_wallets WHERE user_id=?`).bind(me.user_id).first();if(Number(wallet?.balance||0)<cost)return json({error:'INSUFFICIENT_COIN_BALANCE',required:cost},409,cors);
    await env.DB.prepare(`UPDATE myshop_coin_wallets SET balance=balance-?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(cost,me.user_id).run();
    await env.DB.prepare(`INSERT INTO myshop_coin_transactions(user_id,kind,amount,reference,status,metadata) VALUES(?,'HIGHLIGHT_COMMENT',?,'LIVE','COMPLETED',?)`).bind(me.user_id,-cost,JSON.stringify({hostId,ephemeral:true})).run();
    await env.DB.prepare(`INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,host_id,gross_amount,fee_percent,fee_amount,net_amount,platform_amount,reference) VALUES('HIGHLIGHT_COMMENT','COIN',?,?,?, ?,100,?,0,?,'LIVE_HIGHLIGHT')`).bind(me.user_id,'MYSHOP',hostId,cost,cost,cost).run();
  }
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first(),sessionId=String(meta?.session_id||'');
  if(!sessionId)return json({error:'LIVE_SESSION_NOT_READY'},409,cors);
  const baseItem={user_id:me.user_id,message,coin_cost:cost,free_privilege:free?1:0,created_at:new Date().toISOString(),full_name:me.full_name||me.user_id,avatar_url:me.avatar_url||'',gender:me.gender||'UNSPECIFIED'};
  let item=null;try{const pushed=await liveHubPush(env,hostId,sessionId,'HIGHLIGHT',baseItem);if(pushed?.item)item=pushed.item;}catch(e){}
  if(item)liveEphemeralPush(liveEphemeralHighlights,liveEphemeralKey(hostId,sessionId),{...item,_ts:Date.now()},20,12000);
  else{item={...baseItem,id:liveEphemeralSeq++,_ts:Date.now()};liveEphemeralPush(liveEphemeralHighlights,liveEphemeralKey(hostId,sessionId),item,20,12000);}
  return json({ok:true,id:Number(item.id||0),coinCost:cost,free,ephemeral:true,realtime:true,sessionId,comment:item,animation:{direction:'RIGHT_TO_LEFT',placement:'MIDDLE',queue:true}},201,cors);
}
async function liveGiftSummary(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const u=new URL(request.url),hostId=String(u.searchParams.get('hostId')||'').trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();let sessionId=String(meta?.session_id||'');if(!sessionId){const h=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_history WHERE host_id=? ORDER BY id DESC LIMIT 1`).bind(hostId).first();sessionId=String(h?.session_id||'');}
  const recent=(await env.DB.prepare(`SELECT e.id,e.sender_id,e.receiver_id,e.currency,e.price,e.created_at,g.name gift_name,u.full_name FROM myshop_live_gift_events e LEFT JOIN myshop_live_gifts g ON g.id=e.gift_id LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id WHERE e.host_id=? AND e.status='COMPLETED' AND (?='' OR e.session_id=?) ORDER BY e.id DESC LIMIT 50`).bind(hostId,sessionId,sessionId).all()).results||[];
  const top=(await env.DB.prepare(`SELECT e.sender_id,u.full_name,u.avatar_url,SUM(e.price) total_value,COUNT(*) gift_count FROM myshop_live_gift_events e LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id WHERE e.host_id=? AND e.status='COMPLETED' AND (?='' OR e.session_id=?) GROUP BY e.sender_id ORDER BY total_value DESC,gift_count DESC LIMIT 20`).bind(hostId,sessionId,sessionId).all()).results||[];
  return json({ok:true,sessionId,recent,topSupporters:top.map((x,i)=>({...x,rank:i+1}))},200,cors);
}
async function userValueHistory(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const rows=(await env.DB.prepare(`SELECT id,tx_type,currency,sender_id,receiver_id,host_id,gift_id,gross_amount,fee_percent,fee_amount,net_amount,status,reference,created_at FROM myshop_value_ledger WHERE sender_id=? OR receiver_id=? ORDER BY id DESC LIMIT 200`).bind(me.user_id,me.user_id).all()).results||[];return json({ok:true,transactions:rows},200,cors);
}
async function adminFinanceSummary(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);await ensureLiveRoomSchema(env);const totals=await env.DB.prepare(`SELECT COALESCE(SUM(gross_amount),0) gross,COALESCE(SUM(fee_amount),0) fees,COALESCE(SUM(net_amount),0) net,COUNT(*) tx_count FROM myshop_value_ledger WHERE status='COMPLETED'`).first();const sold=await env.DB.prepare(`SELECT COALESCE(SUM(CASE WHEN amount>0 AND status='COMPLETED' AND kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN amount ELSE 0 END),0) coin_sold FROM myshop_coin_transactions`).first();const recent=(await env.DB.prepare(`SELECT * FROM myshop_value_ledger ORDER BY id DESC LIMIT 300`).all()).results||[];const starLevel=(await env.DB.prepare(`SELECT * FROM myshop_star_level_ledger ORDER BY id DESC LIMIT 300`).all()).results||[];const cfg=await financeConfig(env);return json({ok:true,config:cfg,starLevel,totals:{gross:Number(totals?.gross||0),fees:Number(totals?.fees||0),net:Number(totals?.net||0),transactions:Number(totals?.tx_count||0),coinSold:Number(sold?.coin_sold||0)},recent},200,cors);
}
async function adminFinanceConfig(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);await ensureLiveRoomSchema(env);if(request.method==='GET'){return json({ok:true,...await financeConfig(env)},200,cors);}const b=await body(request),fee=Math.max(0,Math.min(100,Number(b.platformFeePercent??10))),price=Math.max(0,Math.floor(Number(b.highlightCommentCoinPrice??1000)));await env.DB.prepare(`UPDATE myshop_finance_config SET platform_fee_percent=?,highlight_comment_coin_price=?,updated_by=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`).bind(fee,price,me.user_id).run();return json({ok:true,platformFeePercent:fee,highlightCommentCoinPrice:price},200,cors);
}
async function liveValueTransfer(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),to=String(b.receiverId||'').trim(),currency=String(b.currency||'COIN').toUpperCase(),gross=Math.max(1,Math.floor(Number(b.amount||0)));if(!isFourDigit(to)||to===me.user_id||!['COIN','GOLD'].includes(currency))return json({error:'INVALID_TRANSFER'},400,cors);const exists=await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1`).bind(to).first();if(!exists)return json({error:'USER_NOT_FOUND'},404,cors);await reconcileLevelProgress(env,to);const cfg=await financeConfig(env),adminSender=await isFixedMainAdminId(me.user_id),split=adminSender?{gross,fee:0,net:gross}:splitPlatformFee(gross,cfg.feePercent),wallet=currency==='COIN'?'myshop_coin_wallets':'myshop_gold_wallets';await env.DB.prepare(`INSERT OR IGNORE INTO ${wallet}(user_id,balance) VALUES(?,0)`).bind(me.user_id).run();await env.DB.prepare(`INSERT OR IGNORE INTO ${wallet}(user_id,balance) VALUES(?,0)`).bind(to).run();const w=await env.DB.prepare(`SELECT balance FROM ${wallet} WHERE user_id=?`).bind(me.user_id).first();if(Number(w?.balance||0)<gross)return json({error:'INSUFFICIENT_BALANCE'},409,cors);await env.DB.prepare(`UPDATE ${wallet} SET balance=balance-?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(gross,me.user_id).run();await env.DB.prepare(`UPDATE ${wallet} SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(split.net,to).run();const r=await env.DB.prepare(`INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,gross_amount,fee_percent,fee_amount,net_amount,platform_amount,reference) VALUES('TRANSFER',?,?,?,?,?,?,?,?, 'USER_TRANSFER')`).bind(currency,me.user_id,to,split.gross,adminSender?0:cfg.feePercent,split.fee,split.net,split.fee).run();const progress=await applyStarsAndLevels(env,{txType:'TRANSFER',currency,senderId:me.user_id,receiverId:to,units:split.gross,official:adminSender,reference:'USER_TRANSFER'});return json({ok:true,id:r.meta?.last_row_id||0,gross:split.gross,feePercent:adminSender?0:cfg.feePercent,feeAmount:split.fee,netAmount:split.net,stars:progress.stars,levelAdded:progress.levelAdded},201,cors);
}
async function liveModerationAudit(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);await ensureLiveRoomSchema(env);const hostId=String(new URL(request.url).searchParams.get('hostId')||'').trim();const rows=(await env.DB.prepare(`SELECT * FROM myshop_live_moderation_audit WHERE (?='' OR host_id=?) ORDER BY id DESC LIMIT 300`).bind(hostId,hostId).all()).results||[];return json({ok:true,audit:rows},200,cors);
}

async function liveGiftCatalog(request,env){
  const me=await getUser(request,env); if(!me)return json({error:'UNAUTHORIZED'},401,cors); await ensureLiveRoomSchema(env);
  const c=await env.DB.prepare(`SELECT balance FROM myshop_coin_wallets WHERE user_id=?`).bind(me.user_id).first(),g=await env.DB.prepare(`SELECT balance FROM myshop_gold_wallets WHERE user_id=?`).bind(me.user_id).first();
  const rows=(await env.DB.prepare(`SELECT * FROM myshop_live_gifts WHERE enabled=1 AND COALESCE(deleted,0)=0 ORDER BY currency,sort_order,id LIMIT 100`).all()).results||[];
  return json({ok:true,coinBalance:Number(c?.balance||0),goldBalance:Number(g?.balance||0),gifts:rows},200,cors);
}
async function liveGiftSend(request,env,ctx){
  const me=await getUser(request,env); if(!me)return json({error:'UNAUTHORIZED'},401,cors); await ensureLiveRoomSchema(env);
  const b=await body(request),hostId=String(b.hostId||'').trim(),receiverId=String(b.receiverId||hostId).trim(),giftId=Math.max(0,Math.floor(Number(b.giftId||0))),clientNonce=String(b.clientNonce||'').trim().slice(0,80);
  if(!isFourDigit(hostId)||!isFourDigit(receiverId)||giftId<=0)return json({error:'INVALID_GIFT_TARGET'},400,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  const sanction=await liveSanctionFor(env,hostId,me.user_id);if(sanction==='BLOCKED'||sanction==='KICKED')return json({error:'LIVE_NOT_ALLOWED'},403,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();const sessionId=String(meta?.session_id||'');if(!sessionId)return json({error:'LIVE_SESSION_NOT_READY'},409,cors);
  if(clientNonce){
    const old=await env.DB.prepare(`SELECT e.id AS event_id,e.receiver_id,e.currency,e.price,g.*,u.full_name sender_name,u.avatar_url sender_avatar FROM myshop_live_gift_events e JOIN myshop_live_gifts g ON g.id=e.gift_id LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id WHERE e.host_id=? AND e.session_id=? AND e.sender_id=? AND e.client_nonce=? LIMIT 1`).bind(hostId,sessionId,me.user_id,clientNonce).first();
    if(old){const balTbl=String(old.currency)==='COIN'?'myshop_coin_wallets':'myshop_gold_wallets';const bal=await env.DB.prepare(`SELECT balance FROM ${balTbl} WHERE user_id=?`).bind(me.user_id).first();return json({ok:true,duplicateSuppressed:true,eventId:Number(old.event_id||0),gift:old,receiverId:String(old.receiver_id||receiverId),grossAmount:Number(old.price||0),combo:1,animationQueue:true,sessionId,balance:Number(bal?.balance||0),senderName:String(old.sender_name||me.full_name||me.user_id),senderAvatar:String(old.sender_avatar||me.avatar_url||''),senderLevel:Number((await env.DB.prepare(`SELECT COALESCE(level,0) level FROM myshop_user_progress WHERE user_id=?`).bind(me.user_id).first())?.level||0)},200,cors);}
  }
  const gift=await env.DB.prepare(`SELECT * FROM myshop_live_gifts WHERE id=? AND enabled=1 AND COALESCE(deleted,0)=0`).bind(giftId).first(); if(!gift)return json({error:'GIFT_NOT_AVAILABLE'},404,cors);
  const price=Math.max(1,Math.floor(Number(gift.price||1)));const cfg=await financeConfig(env),adminSender=await isFixedMainAdminId(me.user_id),giftVat=Math.max(0,Math.min(100,Math.floor(Number(gift.vat_percent??cfg.feePercent)))),split=adminSender?{gross:price,fee:0,net:price}:splitPlatformFee(price,giftVat),wallet=gift.currency==='COIN'?'myshop_coin_wallets':'myshop_gold_wallets';
  await env.DB.prepare(`INSERT OR IGNORE INTO ${wallet}(user_id,balance) VALUES(?,0)`).bind(me.user_id).run();
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_creator_earnings(user_id,currency,balance) VALUES(?,?,0)`).bind(receiverId,gift.currency).run();
  const w=await env.DB.prepare(`SELECT balance FROM ${wallet} WHERE user_id=?`).bind(me.user_id).first();if(Number(w?.balance||0)<price)return json({error:gift.currency==='COIN'?'INSUFFICIENT_COIN_BALANCE':'INSUFFICIENT_GOLD_BALANCE',required:price},409,cors);
  let eventId=0;
  try{
    const batch=await env.DB.batch([
      env.DB.prepare(`UPDATE ${wallet} SET balance=balance-?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(price,me.user_id),
      env.DB.prepare(`UPDATE myshop_creator_earnings SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND currency=?`).bind(split.net,receiverId,gift.currency),
      env.DB.prepare(`INSERT INTO myshop_live_gift_events(host_id,sender_id,receiver_id,gift_id,currency,price,session_id,client_nonce) VALUES(?,?,?,?,?,?,?,?)`).bind(hostId,me.user_id,receiverId,giftId,gift.currency,price,sessionId,clientNonce),
      env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'GIFT',?)`).bind(hostId,me.user_id,sessionId,'sent '+String(gift.name||'Gift')),
      env.DB.prepare(`INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,host_id,gift_id,gross_amount,fee_percent,fee_amount,net_amount,platform_amount,reference,metadata) VALUES('GIFT',?,?,?,?,?,?,?,?,?,?, 'LIVE_GIFT',?)`).bind(gift.currency,me.user_id,receiverId,hostId,giftId,split.gross,adminSender?0:giftVat,split.fee,split.net,split.fee,JSON.stringify({clientNonce,sessionId}))
    ]);
    eventId=Number(batch?.[2]?.meta?.last_row_id||0);
  }catch(e){
    if(clientNonce){const old=await env.DB.prepare(`SELECT id FROM myshop_live_gift_events WHERE host_id=? AND session_id=? AND sender_id=? AND client_nonce=? LIMIT 1`).bind(hostId,sessionId,me.user_id,clientNonce).first();if(old){eventId=Number(old.id||0);}else return json({error:'GIFT_SEND_FAILED',message:'Gift was not completed. Your balance was not charged.'},500,cors);}
    else return json({error:'GIFT_SEND_FAILED',message:'Gift was not completed. Your balance was not charged.'},500,cors);
  }
  const newBalance=Math.max(0,Number(w?.balance||0)-price);
  const afterSend=async()=>{
    try{await reconcileLevelProgress(env,receiverId);}catch(e){}
    try{await applyStarsAndLevels(env,{txType:'GIFT',currency:gift.currency,senderId:me.user_id,receiverId,units:split.gross,official:adminSender,reference:'LIVE_GIFT#'+eventId});}catch(e){}
    try{await env.DB.prepare(`UPDATE myshop_live_fan_club SET points=points+?,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND active=1`).bind(Math.max(1,Math.floor(price/10)),hostId,me.user_id).run();}catch(e){}
  };
  if(ctx&&ctx.waitUntil)ctx.waitUntil(afterSend()); else afterSend().catch(()=>{});
  const senderLevelRow=await env.DB.prepare(`SELECT (CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=?),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=?),0)) AS level`).bind(me.user_id,me.user_id).first();
  const senderLevel=Number(senderLevelRow?.level||0);
  try{await liveHubPush(env,hostId,sessionId,'GIFT',{id:eventId,sender_id:me.user_id,receiver_id:receiverId,currency:String(gift.currency||'COIN'),price,created_at:new Date().toISOString(),name:String(gift.name||'Gift'),preview_url:String(gift.preview_url||''),animation_url:String(gift.animation_url||''),animation_mime:String(gift.animation_mime||''),animation_enabled:Number(gift.animation_enabled??1),sound_url:String(gift.sound_url||''),sound_enabled:Number(gift.sound_enabled??1),sound_volume:Number(gift.sound_volume??85),effect_duration_ms:Number(gift.effect_duration_ms??2800),sound_duration_ms:Number(gift.sound_duration_ms??2500),sound_trim_start_pct:Number(gift.sound_trim_start_pct??0),sound_trim_end_pct:Number(gift.sound_trim_end_pct??100),vat_percent:Number(gift.vat_percent??giftVat),board_position:String(gift.board_position||'CENTER'),animation_scale:Number(gift.animation_scale??70),size_mode:String(gift.size_mode||'MEDIUM'),sender_name:String(me.full_name||me.user_id),sender_avatar:String(me.avatar_url||''),sender_level:senderLevel,combo:1});}catch(e){}
  return json({ok:true,eventId,gift,receiverId,grossAmount:split.gross,feePercent:adminSender?0:giftVat,feeAmount:split.fee,netAmount:split.net,combo:1,animationQueue:true,sessionId,balance:newBalance,fastAck:true,senderName:String(me.full_name||me.user_id),senderAvatar:String(me.avatar_url||''),senderLevel},201,cors);
}

async function liveGiftEvents(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const u=new URL(request.url),hostId=String(u.searchParams.get('hostId')||'').trim(),after=Math.max(0,Math.floor(Number(u.searchParams.get('after')||0)));if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first(),sessionId=String(meta?.session_id||'');
  const vr=me.user_id===hostId?null:await env.DB.prepare(`SELECT joined_at FROM myshop_live_viewers WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).first();
  const cutoff=me.user_id===hostId?'1970-01-01 00:00:00':String(vr?.joined_at||new Date().toISOString().slice(0,19).replace('T',' '));
  const events=(await env.DB.prepare(`SELECT e.id,e.sender_id,e.receiver_id,e.currency,e.price,e.created_at,g.name,g.preview_url,g.animation_url,g.animation_mime,g.animation_enabled,g.sound_url,g.sound_enabled,g.sound_volume,g.effect_duration_ms,g.sound_duration_ms,g.sound_trim_start_pct,g.sound_trim_end_pct,g.vat_percent,g.board_position,g.animation_scale,g.size_mode,u.full_name sender_name,u.avatar_url sender_avatar,(CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=e.sender_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=e.sender_id),0)) AS sender_level,ru.full_name receiver_name FROM myshop_live_gift_events e JOIN myshop_live_gifts g ON g.id=e.gift_id LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id LEFT JOIN myshop_auth_users_v108 ru ON ru.user_id=e.receiver_id WHERE e.host_id=? AND e.session_id=? AND e.status='COMPLETED' AND e.id>? AND datetime(e.created_at)>=datetime(?) AND (? > 0 OR datetime(e.created_at)>=datetime('now','-4 seconds')) ORDER BY e.id ASC LIMIT 20`).bind(hostId,sessionId,after,cutoff,after).all()).results||[];
  return json({ok:true,sessionId,events,lastEventId:events.length?Number(events[events.length-1].id):after},200,cors);
}
async function adminLiveGifts(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;await ensureLiveRoomSchema(env);
  const cur=String(new URL(request.url).searchParams.get('currency')||'').toUpperCase();
  const filtered=cur==='COIN'||cur==='GOLD';
  const stmt=filtered?env.DB.prepare(`SELECT * FROM myshop_live_gifts WHERE COALESCE(deleted,0)=0 AND currency=? ORDER BY sort_order,id`).bind(cur):env.DB.prepare(`SELECT * FROM myshop_live_gifts WHERE COALESCE(deleted,0)=0 ORDER BY currency,sort_order,id`);
  const rows=(await stmt.all()).results||[];
  return json({ok:true,gifts:rows,currency:cur||'ALL'},200,cors);
}
async function adminLiveGiftSave(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;await ensureLiveRoomSchema(env);const b=await body(request),id=Math.max(0,Math.floor(Number(b.id||0))),currency=String(b.currency||'COIN').toUpperCase(),scale=Math.max(0,Math.min(100,Math.floor(Number(b.animationScale??70)))),size=scale<=20?'SMALL':scale<=58?'MEDIUM':scale<=84?'LARGE':'FULL_SCREEN';
  if(!['COIN','GOLD'].includes(currency)||!['SMALL','MEDIUM','LARGE','FULL_SCREEN'].includes(size))return json({error:'INVALID_GIFT_CONFIG'},400,cors);
  const giftName=String(b.name||'Gift').trim().slice(0,60)||'Gift',price=Math.max(1,Math.floor(Number(b.price||1))),category=String(b.category||'ALL').trim().toUpperCase().replace(/[^A-Z0-9_-]/g,'').slice(0,32)||'ALL';
  const preview=String(b.previewUrl||'').trim().slice(0,1400),animation=String(b.animationUrl||'').trim().slice(0,1400),animationMime=String(b.animationMime||'').trim().slice(0,100),sound=String(b.soundUrl||'').trim().slice(0,1400),catalogAnimationUrl=String(b.catalogAnimationUrl||'').trim().slice(0,1400);
  let boardPosition=String(b.boardPosition||'CENTER').trim().toUpperCase();if(!['CENTER','TOP','BOTTOM','FULL_SCREEN'].includes(boardPosition))boardPosition='CENTER';
  const animationEnabled=b.animationEnabled===false?0:1,soundEnabled=b.soundEnabled===false?0:1,soundVolume=Math.max(0,Math.min(100,Math.floor(Number(b.soundVolume??85)))),effectDurationMs=Math.max(500,Math.min(15000,Math.floor(Number(b.effectDurationMs??2800)))),soundDurationMs=Math.max(0,Math.min(15000,Math.floor(Number(b.soundDurationMs??2500)))),soundTrimStartPct=Math.max(0,Math.min(99,Math.floor(Number(b.soundTrimStartPct??0)))),soundTrimEndRaw=Math.max(1,Math.min(100,Math.floor(Number(b.soundTrimEndPct??100)))),soundTrimEndPct=Math.max(soundTrimStartPct+1,soundTrimEndRaw),vatPercent=Math.max(0,Math.min(100,Math.floor(Number(b.vatPercent??10)))),sortOrder=Math.max(0,Math.floor(Number(b.sortOrder||100))),enabled=b.enabled===false?0:1;
  const catalogAnimationEnabled=b.catalogAnimationEnabled===false?0:1,catalogLoop=b.catalogLoop===false?0:1,catalogPreviewSize=Math.max(0,Math.min(100,Math.floor(Number(b.catalogPreviewSize??68)))),catalogAnimationStrength=Math.max(0,Math.min(100,Math.floor(Number(b.catalogAnimationStrength??42)))),catalogAnimationSpeed=Math.max(0,Math.min(100,Math.floor(Number(b.catalogAnimationSpeed??45)))),catalogGlowParticle=Math.max(0,Math.min(100,Math.floor(Number(b.catalogGlowParticle??35))));
  const allowedCatalogTypes=['AUTO','PULSE','BOUNCE','FLOAT','GLOW','SPARKLE','ROTATE','SLIDE'];let catalogAnimationType=String(b.catalogAnimationType||'AUTO').trim().toUpperCase();if(!allowedCatalogTypes.includes(catalogAnimationType))catalogAnimationType='AUTO';
  if(!id){
    const c=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_gifts WHERE currency=? AND COALESCE(deleted,0)=0`).bind(currency).first();if(Number(c?.c||0)>=50)return json({error:'GIFT_LIMIT_50'},409,cors);
    const r=await env.DB.prepare(`INSERT INTO myshop_live_gifts(name,currency,price,category,preview_url,animation_url,animation_mime,animation_enabled,sound_url,sound_enabled,sound_volume,effect_duration_ms,sound_duration_ms,sound_trim_start_pct,sound_trim_end_pct,vat_percent,board_position,animation_scale,size_mode,catalog_animation_enabled,catalog_animation_type,catalog_preview_size,catalog_animation_strength,catalog_animation_speed,catalog_glow_particle,catalog_loop,catalog_animation_url,sort_order,enabled,deleted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)`).bind(giftName,currency,price,category,preview,animation,animationMime,animationEnabled,sound,soundEnabled,soundVolume,effectDurationMs,soundDurationMs,soundTrimStartPct,soundTrimEndPct,vatPercent,boardPosition,scale,size,catalogAnimationEnabled,catalogAnimationType,catalogPreviewSize,catalogAnimationStrength,catalogAnimationSpeed,catalogGlowParticle,catalogLoop,catalogAnimationUrl,sortOrder,enabled).run();
    return json({ok:true,id:r.meta?.last_row_id||0,currency,price,soundVolume,effectDurationMs,soundDurationMs,soundTrimStartPct,soundTrimEndPct,vatPercent,boardPosition,animationScale:scale,catalogAnimationEnabled:!!catalogAnimationEnabled,catalogAnimationType,catalogPreviewSize,catalogAnimationStrength,catalogAnimationSpeed,catalogGlowParticle,catalogLoop:!!catalogLoop,sizeMode:size,updated:true},201,cors);
  }
  const exists=await env.DB.prepare(`SELECT id,currency FROM myshop_live_gifts WHERE id=? AND COALESCE(deleted,0)=0`).bind(id).first();if(!exists)return json({error:'GIFT_NOT_FOUND'},404,cors);
  if(String(exists.currency||'').toUpperCase()!==currency)return json({error:'GIFT_CURRENCY_LOCKED',message:'Coin and Gold Coin gifts are managed in separate catalogs. Delete and add a new gift to change currency.'},409,cors);
  await env.DB.prepare(`UPDATE myshop_live_gifts SET name=?,price=?,category=?,preview_url=?,animation_url=?,animation_mime=?,animation_enabled=?,sound_url=?,sound_enabled=?,sound_volume=?,effect_duration_ms=?,sound_duration_ms=?,sound_trim_start_pct=?,sound_trim_end_pct=?,vat_percent=?,board_position=?,animation_scale=?,size_mode=?,catalog_animation_enabled=?,catalog_animation_type=?,catalog_preview_size=?,catalog_animation_strength=?,catalog_animation_speed=?,catalog_glow_particle=?,catalog_loop=?,catalog_animation_url=?,sort_order=?,enabled=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(giftName,price,category,preview,animation,animationMime,animationEnabled,sound,soundEnabled,soundVolume,effectDurationMs,soundDurationMs,soundTrimStartPct,soundTrimEndPct,vatPercent,boardPosition,scale,size,catalogAnimationEnabled,catalogAnimationType,catalogPreviewSize,catalogAnimationStrength,catalogAnimationSpeed,catalogGlowParticle,catalogLoop,catalogAnimationUrl,sortOrder,enabled,id).run();
  return json({ok:true,id,currency,price,soundVolume,effectDurationMs,soundDurationMs,soundTrimStartPct,soundTrimEndPct,vatPercent,boardPosition,animationScale:scale,catalogAnimationEnabled:!!catalogAnimationEnabled,catalogAnimationType,catalogPreviewSize,catalogAnimationStrength,catalogAnimationSpeed,catalogGlowParticle,catalogLoop:!!catalogLoop,sizeMode:size,updated:true},200,cors);
}
async function adminLiveGiftBulkVat(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;await ensureLiveRoomSchema(env);const b=await body(request);const currency=String(b.currency||'').toUpperCase(),vatPercent=Math.max(0,Math.min(100,Math.floor(Number(b.vatPercent??10))));
  if(!['COIN','GOLD'].includes(currency))return json({error:'INVALID_CURRENCY'},400,cors);
  const r=await env.DB.prepare(`UPDATE myshop_live_gifts SET vat_percent=?,updated_at=CURRENT_TIMESTAMP WHERE currency=? AND COALESCE(deleted,0)=0`).bind(vatPercent,currency).run();
  return json({ok:true,currency,vatPercent,updated:Number(r.meta?.changes||0)},200,cors);
}
async function adminLiveGiftReorder(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;await ensureLiveRoomSchema(env);const b=await body(request),currency=String(b.currency||'').toUpperCase(),ids=Array.isArray(b.ids)?b.ids.map(x=>Math.max(0,Math.floor(Number(x||0)))).filter(Boolean):[];
  if(!['COIN','GOLD'].includes(currency)||!ids.length||ids.length>50)return json({error:'INVALID_GIFT_ORDER'},400,cors);
  const unique=[...new Set(ids)];if(unique.length!==ids.length)return json({error:'DUPLICATE_GIFT_ID'},400,cors);
  const qs=unique.map(()=>'?').join(',');const rows=(await env.DB.prepare(`SELECT id FROM myshop_live_gifts WHERE currency=? AND COALESCE(deleted,0)=0 AND id IN (${qs})`).bind(currency,...unique).all()).results||[];
  if(rows.length!==unique.length)return json({error:'GIFT_ORDER_CURRENCY_MISMATCH'},409,cors);
  const stmts=unique.map((id,i)=>env.DB.prepare(`UPDATE myshop_live_gifts SET sort_order=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND currency=? AND COALESCE(deleted,0)=0`).bind(i+1,id,currency));if(typeof env.DB.batch==='function')await env.DB.batch(stmts);else for(const q of stmts)await q.run();
  return json({ok:true,currency,updated:unique.length},200,cors);
}
async function adminLiveGiftDelete(request,env){const a=await adminOnly(request,env);if(a.error)return a.error;await ensureLiveRoomSchema(env);const b=await body(request),id=Math.max(0,Math.floor(Number(b.id||0)));if(!id)return json({error:'INVALID_GIFT_ID'},400,cors);await env.DB.prepare(`UPDATE myshop_live_gifts SET deleted=1,enabled=0,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(id).run();return json({ok:true,id,deleted:true},200,cors);}
async function adminLiveGiftAssetUpload(request,env){const a=await adminOnly(request,env);if(a.error)return a.error;if(!env.MEDIA)return json({error:'R2_NOT_CONFIGURED'},503,cors);const form=await request.formData(),file=form.get('file');if(!(file instanceof File))return json({error:'FILE_REQUIRED'},400,cors);if(file.size>12*1024*1024)return json({error:'GIFT_ASSET_TOO_LARGE'},413,cors);const ct=guessContentType(file);const ok=ct.startsWith('image/')||ct.startsWith('audio/')||ct==='application/json'||ct==='video/webm';if(!ok)return json({error:'GIFT_ASSET_TYPE_MISMATCH'},400,cors);const ext=(String(file.name||'asset').split('.').pop()||'bin').replace(/[^a-zA-Z0-9]/g,'').slice(0,8)||'bin';const key=`live/gifts/${Date.now()}-${crypto.randomUUID().slice(0,8)}.${ext}`;await env.MEDIA.put(key,file.stream(),{httpMetadata:{contentType:ct,cacheControl:'public, max-age=31536000'}});const url=new URL('/v1/media/'+encodeURIComponent(key),request.url).toString();return json({ok:true,url,mediaType:ct,objectKey:key},201,cors);}


async function adminGateStatus(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);
  await ensureLiveRoomSchema(env);const cfg=await env.DB.prepare(`SELECT security_question FROM myshop_admin_gate WHERE id=1`).first();
  let unlocked=false;if(cfg){const auth=String(request.headers.get('Authorization')||'');const raw=auth.toLowerCase().startsWith('bearer ')?auth.slice(7).trim():'';if(raw){const h=await sha256(raw);const r=await env.DB.prepare(`SELECT 1 ok FROM myshop_admin_gate_sessions WHERE token_hash=? AND datetime(expires_at)>datetime('now')`).bind(h).first();unlocked=!!r;}}
  return json({ok:true,configured:!!cfg,unlocked,securityQuestion:String(cfg?.security_question||'')},200,cors);
}
async function adminGateSetup(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);await ensureLiveRoomSchema(env);
  const existing=await env.DB.prepare(`SELECT id FROM myshop_admin_gate WHERE id=1`).first();if(existing)return json({error:'ADMIN_GATE_ALREADY_CONFIGURED'},409,cors);
  const b=await body(request),password=String(b.password||''),q=String(b.securityQuestion||'').trim().slice(0,160),a=normalizeAnswer(b.securityAnswer||'');
  if(password.length<6||!q||a.length<2)return json({error:'ADMIN_GATE_SETUP_INVALID'},400,cors);
  await env.DB.prepare(`INSERT INTO myshop_admin_gate(id,password_hash,security_question,security_answer_hash,updated_by) VALUES(1,?,?,?,?)`).bind(await hashPassword(password),q,await sha256(a),me.user_id).run();
  return json({ok:true},201,cors);
}
async function adminGateUnlock(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);await ensureLiveRoomSchema(env);const b=await body(request),password=String(b.password||'');
  const cfg=await env.DB.prepare(`SELECT password_hash FROM myshop_admin_gate WHERE id=1`).first();if(!cfg)return json({error:'ADMIN_GATE_NOT_CONFIGURED'},409,cors);if(!(await verifyPassword(password,cfg.password_hash)))return json({error:'ADMIN_GATE_PASSWORD_INCORRECT'},403,cors);
  const auth=String(request.headers.get('Authorization')||'');const raw=auth.toLowerCase().startsWith('bearer ')?auth.slice(7).trim():'';if(!raw)return json({error:'UNAUTHORIZED'},401,cors);const h=await sha256(raw);
  await env.DB.prepare(`INSERT INTO myshop_admin_gate_sessions(token_hash,user_id,expires_at,unlocked_at) VALUES(?,?,datetime('now','+8 hours'),CURRENT_TIMESTAMP) ON CONFLICT(token_hash) DO UPDATE SET user_id=excluded.user_id,expires_at=excluded.expires_at,unlocked_at=CURRENT_TIMESTAMP`).bind(h,me.user_id).run();
  return json({ok:true,expiresInSeconds:28800},200,cors);
}
async function adminGateRecover(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);
  await ensureLiveRoomSchema(env);const b=await body(request),mode=String(b.mode||'QUESTION').toUpperCase(),newPassword=String(b.newPassword||'');if(newPassword.length<6)return json({error:'NEW_PASSWORD_TOO_SHORT'},400,cors);const cfg=await env.DB.prepare(`SELECT security_answer_hash FROM myshop_admin_gate WHERE id=1`).first();if(!cfg)return json({error:'ADMIN_GATE_NOT_CONFIGURED'},409,cors);
  let ok=false;if(mode==='QUESTION'){ok=(await sha256(normalizeAnswer(b.securityAnswer||'')))===cfg.security_answer_hash;}
  else if(mode==='OWNER_IDS'){const raw=[b.id1,b.id2,b.id3].map(x=>String(x||'').trim().toLowerCase()).filter(Boolean);const allowedHashes=new Set(['2488f46e89a2ff3d2e5ea9f43ee610d8c74135f931692269d077a73551f8495d','6d8859a91a72a6ab10acda29c21709493fe5f0f3efcee83e480a609f9abf8969','b2d53ac69843f7f30f81a770adc18107f230317670eaa701d3135e53731e6b28']);const matched=new Set();for(const x of raw){const h=await sha256(x);if(allowedHashes.has(h))matched.add(h);}ok=matched.size>=2;}
  if(!ok)return json({error:'RECOVERY_NOT_MATCHED'},403,cors);await env.DB.prepare(`UPDATE myshop_admin_gate SET password_hash=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`).bind(await hashPassword(newPassword)).run();await env.DB.prepare(`DELETE FROM myshop_admin_gate_sessions`).run();return json({ok:true,reset:true},200,cors);
}
async function adminGateIsUnlocked(request,env){
  const auth=String(request.headers.get('Authorization')||'');const raw=auth.toLowerCase().startsWith('bearer ')?auth.slice(7).trim():'';if(!raw)return false;const h=await sha256(raw);const r=await env.DB.prepare(`SELECT 1 ok FROM myshop_admin_gate_sessions WHERE token_hash=? AND datetime(expires_at)>datetime('now')`).bind(h).first();return !!r;
}
async function applyLiveNamePolicy(env,userId,newName){
  const name=String(newName||'').trim().slice(0,40);if(!name)return {ok:false,error:'LIVE_NAME_REQUIRED'};const old=await env.DB.prepare(`SELECT live_name,changed_at FROM myshop_live_name_policy WHERE user_id=?`).bind(userId).first();if(!old){await env.DB.prepare(`INSERT INTO myshop_live_name_policy(user_id,live_name,changed_at) VALUES(?,?,CURRENT_TIMESTAMP)`).bind(userId,name).run();return {ok:true,name,cost:0,remainingSeconds:0};}if(String(old.live_name)===name)return {ok:true,name,cost:0,remainingSeconds:0};
  const age=(Date.now()-Date.parse(String(old.changed_at).replace(' ','T')+'Z'))/1000;const remain=Math.max(0,Math.ceil(86400-(Number.isFinite(age)?age:86400)));let cost=0;if(remain>0){cost=5000;await env.DB.prepare(`INSERT OR IGNORE INTO myshop_coin_wallets(user_id,balance) VALUES(?,0)`).bind(userId).run();const w=await env.DB.prepare(`SELECT balance FROM myshop_coin_wallets WHERE user_id=?`).bind(userId).first();if(Number(w?.balance||0)<cost)return {ok:false,error:'LIVE_NAME_CHANGE_REQUIRES_5000_COINS',remainingSeconds:remain,cost};await env.DB.prepare(`UPDATE myshop_coin_wallets SET balance=balance-?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(cost,userId).run();await env.DB.prepare(`INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,gross_amount,fee_percent,fee_amount,net_amount,platform_amount,reference) VALUES('LIVE_NAME_CHANGE','COIN',?,'MY_SHOP',?,0,0,0,?,'EARLY_24H_CHANGE')`).bind(userId,cost,cost).run();}
  await env.DB.prepare(`UPDATE myshop_live_name_policy SET live_name=?,changed_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(name,userId).run();return {ok:true,name,cost,remainingSeconds:0};
}
async function liveReact(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||'').trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET react_count=COALESCE(react_count,0)+1,updated_at=CURRENT_TIMESTAMP WHERE host_id=?`).bind(hostId).run();const r=await env.DB.prepare(`SELECT react_count,react_reward_milestone FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();const count=Number(r?.react_count||0),mile=Math.floor(count/10000),prev=Number(r?.react_reward_milestone||0);let reward=0;if(mile>prev){reward=(mile-prev)*1000;await env.DB.prepare(`INSERT OR IGNORE INTO myshop_coin_wallets(user_id,balance) VALUES(?,0)`).bind(hostId).run();await env.DB.prepare(`UPDATE myshop_coin_wallets SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(reward,hostId).run();await env.DB.prepare(`UPDATE myshop_live_room_meta SET react_reward_milestone=? WHERE host_id=?`).bind(mile,hostId).run();await env.DB.prepare(`INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,host_id,gross_amount,fee_percent,fee_amount,net_amount,platform_amount,reference) VALUES('LIVE_REACT_REWARD','COIN','MY_SHOP',?,?,?,0,0,?,0,?)`).bind(hostId,hostId,reward,reward,`${mile*10}K_REACT`).run();}
  return json({ok:true,reactCount:count,rewardCoin:reward,nextMilestone:(mile+1)*10000},200,cors);
}
async function adminUserAudit(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);await ensureLiveRoomSchema(env);await ensureMessageSchema(env);const uid=String(new URL(request.url).searchParams.get('userId')||'').trim();if(!isFourDigit(uid))return json({error:'INVALID_USER_ID'},400,cors);const u=await env.DB.prepare(`SELECT user_id,full_name,email,mobile,active,created_at FROM myshop_auth_users_v108 WHERE user_id=?`).bind(uid).first();if(!u)return json({error:'USER_NOT_FOUND'},404,cors);
  const ledger=(await env.DB.prepare(`SELECT * FROM myshop_value_ledger WHERE sender_id=? OR receiver_id=? OR host_id=? ORDER BY id DESC LIMIT 500`).bind(uid,uid,uid).all()).results||[];const msgs=(await env.DB.prepare(`SELECT id,sender_id,receiver_id,message,created_at,hidden_from_sender,hidden_from_receiver FROM myshop_messages WHERE sender_id=? OR receiver_id=? ORDER BY id DESC LIMIT 500`).bind(uid,uid).all()).results||[];const sums=await env.DB.prepare(`SELECT COALESCE(SUM(CASE WHEN receiver_id=? THEN net_amount ELSE 0 END),0) incoming,COALESCE(SUM(CASE WHEN sender_id=? THEN gross_amount ELSE 0 END),0) outgoing,COALESCE(SUM(CASE WHEN sender_id=? THEN fee_amount ELSE 0 END),0) fees FROM myshop_value_ledger WHERE status='COMPLETED' AND (sender_id=? OR receiver_id=? OR host_id=?)`).bind(uid,uid,uid,uid,uid,uid).first();return json({ok:true,user:u,summary:{incoming:Number(sums?.incoming||0),outgoing:Number(sums?.outgoing||0),fees:Number(sums?.fees||0),transactions:ledger.length,messages:msgs.length},transactions:ledger,messages:msgs},200,cors);
}
async function adminFinanceOverview(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!(await isFixedMainAdminId(me.user_id)))return json({error:'MAIN_ADMIN_ONLY'},403,cors);
  await ensureLiveRoomSchema(env);
  const agg=async where=>await env.DB.prepare(`SELECT COALESCE(SUM(gross_amount),0) gross,COALESCE(SUM(fee_amount),0) fees,COALESCE(SUM(platform_amount),0) platform,COALESCE(SUM(net_amount),0) net,COUNT(*) tx FROM myshop_value_ledger WHERE status='COMPLETED' ${where}`).first();
  const today=await agg(`AND date(created_at)=date('now')`),all=await agg('');
  const currencyRows=(await env.DB.prepare(`SELECT UPPER(COALESCE(currency,'COIN')) currency, COUNT(*) tx_count, COALESCE(SUM(CASE WHEN date(created_at)=date('now') THEN gross_amount ELSE 0 END),0) today_gross, COALESCE(SUM(CASE WHEN date(created_at)=date('now') THEN platform_amount ELSE 0 END),0) today_platform, COALESCE(SUM(CASE WHEN date(created_at)=date('now') THEN net_amount ELSE 0 END),0) today_net, COALESCE(SUM(gross_amount),0) all_gross, COALESCE(SUM(platform_amount),0) all_platform, COALESCE(SUM(net_amount),0) all_net FROM myshop_value_ledger WHERE status='COMPLETED' GROUP BY UPPER(COALESCE(currency,'COIN'))`).all()).results||[];
  const currencySummary={COIN:{txCount:0,todayGross:0,todayPlatform:0,todayNet:0,allGross:0,allPlatform:0,allNet:0},GOLD:{txCount:0,todayGross:0,todayPlatform:0,todayNet:0,allGross:0,allPlatform:0,allNet:0}};
  for(const r of currencyRows){const k=(r.currency==='GOLD'||r.currency==='GOLD_COIN')?'GOLD':'COIN';currencySummary[k]={txCount:Number(r.tx_count||0),todayGross:Number(r.today_gross||0),todayPlatform:Number(r.today_platform||0),todayNet:Number(r.today_net||0),allGross:Number(r.all_gross||0),allPlatform:Number(r.all_platform||0),allNet:Number(r.all_net||0)};}
  const cats=(await env.DB.prepare(`SELECT tx_type,currency,COUNT(*) tx_count,COALESCE(SUM(gross_amount),0) gross,COALESCE(SUM(platform_amount),0) platform,COALESCE(SUM(net_amount),0) net FROM myshop_value_ledger WHERE status='COMPLETED' GROUP BY tx_type,currency ORDER BY gross DESC`).all()).results||[];
  const recent=(await env.DB.prepare(`SELECT * FROM myshop_value_ledger ORDER BY id DESC LIMIT 200`).all()).results||[];
  return json({ok:true,today,allTime:all,currencySummary,categories:cats,recent,config:await financeConfig(env)},200,cors);
}
async function liveRtcToken(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);
  const body=await request.json().catch(()=>({}));const hostId=String(body.hostId||'').trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  const seat=await env.DB.prepare(`SELECT role FROM myshop_live_seats WHERE host_id=? AND user_id=? LIMIT 1`).bind(hostId,me.user_id).first();
  const role=(me.user_id===hostId||String(seat?.role||'').toUpperCase()==='SPEAKER')?'PUBLISHER':'AUDIENCE';
  // App Certificate is server-only. It must be a Cloudflare Worker Secret and is never returned to clients.
  const appId=String(env.AGORA_APP_ID||'d6bc66d261fe41a296af1b2bf45f48a8').trim();
  const appCertificate=String(env.AGORA_APP_CERTIFICATE||'').trim();
  if(!appId||!appCertificate)return json({error:'AGORA_RTC_NOT_CONFIGURED',message:'AGORA_APP_CERTIFICATE Worker secret is required.'},503,cors);
  const channel=`myshop_live_${hostId}`;
  const uid=Number.parseInt(String(me.user_id),10);
  if(!Number.isInteger(uid)||uid<=0)return json({error:'INVALID_RTC_UID'},400,cors);
  const expiresIn=3600;
  const agoraRole=role==='PUBLISHER'?AgoraRtcRole.PUBLISHER:AgoraRtcRole.SUBSCRIBER;
  let rtcToken='';
  try{rtcToken=AgoraRtcTokenBuilder.buildTokenWithUid(appId,appCertificate,channel,uid,agoraRole,expiresIn,expiresIn);}catch(e){return json({error:'RTC_TOKEN_SIGN_FAILED'},500,cors);}
  if(!rtcToken)return json({error:'RTC_TOKEN_SIGN_FAILED'},500,cors);
  return json({ok:true,appId,token:rtcToken,channel,uid,role,expiresIn,expiresAt:Date.now()+expiresIn*1000},200,cors);
}
async function liveRoomState(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
  const hostId=String(new URL(request.url).searchParams.get('hostId')||'').trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const live=await env.DB.prepare(`SELECT active,viewer_count FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  // Reconcile real viewers on every room-state refresh so the host UI and peak count cannot drift.
  await env.DB.prepare(`DELETE FROM myshop_live_viewers WHERE host_id=? AND datetime(last_seen)<datetime('now','-25 seconds')`).bind(hostId).run();
  const viewerRow=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_viewers WHERE host_id=?`).bind(hostId).first();
  const viewerNow=Math.max(0,Number(viewerRow?.c||0));
  await env.DB.prepare(`UPDATE myshop_live_presence SET viewer_count=? WHERE user_id=?`).bind(viewerNow,hostId).run();
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET peak_viewers=MAX(COALESCE(peak_viewers,0),?),updated_at=CURRENT_TIMESTAMP WHERE host_id=?`).bind(viewerNow,hostId).run();
  live.viewer_count=viewerNow;
  await env.DB.prepare(`DELETE FROM myshop_live_seats WHERE host_id=? AND seat_no>9`).bind(hostId).run();
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_seats(host_id,seat_no,user_id,role,mic_on,speaking,network_quality) VALUES(?,1,?,'HOST',1,0,'GOOD')`).bind(hostId,hostId).run();
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_room_meta(host_id,special_guest_id,locked,started_at) VALUES(?,NULL,0,CURRENT_TIMESTAMP)`).bind(hostId).run();
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET started_at=COALESCE(started_at,CURRENT_TIMESTAMP) WHERE host_id=?`).bind(hostId).run();
  const seats=(await env.DB.prepare(`SELECT s.seat_no,s.user_id,s.role,s.muted,COALESCE(s.mic_on,1) mic_on,COALESCE(s.speaking,0) speaking,COALESCE(s.network_quality,'GOOD') network_quality,u.full_name,u.avatar_url,COALESCE(u.gender,'UNSPECIFIED') gender,
      COALESCE(cw.balance,0) coin_balance,COALESCE(gw.balance,0) gold_balance,
      (CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=s.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=s.user_id),0)) AS level,
      COALESCE((SELECT b.badge_code FROM myshop_user_badges b WHERE b.user_id=s.user_id AND b.status='ACTIVE' AND (b.expires_at IS NULL OR datetime(b.expires_at)>datetime('now')) AND b.badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP') ORDER BY CASE b.badge_code WHEN 'KING' THEN 1 WHEN 'QUEEN' THEN 1 WHEN 'ROYAL' THEN 2 WHEN 'VVIP' THEN 3 WHEN 'VIP' THEN 4 ELSE 9 END LIMIT 1),'STANDARD') AS tier,
      CASE WHEN EXISTS(SELECT 1 FROM myshop_live_room_admins ra WHERE ra.host_id=s.host_id AND ra.user_id=s.user_id AND ra.active=1) THEN 1 ELSE 0 END AS room_admin,
      COALESCE((SELECT fc.points FROM myshop_live_fan_club fc WHERE fc.host_id=s.host_id AND fc.user_id=s.user_id AND fc.active=1),0) AS fan_points
      FROM myshop_live_seats s
      LEFT JOIN myshop_auth_users_v108 u ON u.user_id=s.user_id
      LEFT JOIN myshop_coin_wallets cw ON cw.user_id=s.user_id
      LEFT JOIN myshop_gold_wallets gw ON gw.user_id=s.user_id
      WHERE s.host_id=? AND s.seat_no<=9 ORDER BY s.seat_no`).bind(hostId).all()).results||[];
  const reqMeta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();const requestSession=String(reqMeta?.session_id||'');const requests=me.user_id===hostId?((await env.DB.prepare(`SELECT r.user_id,r.status,r.created_at,u.full_name,u.avatar_url,COALESCE(fc.points,0) fan_points,CASE WHEN b.badge_code IN ('KING','QUEEN') THEN 5 WHEN b.badge_code='ROYAL' THEN 4 WHEN b.badge_code='VVIP' THEN 3 WHEN b.badge_code='VIP' THEN 2 ELSE 0 END tier_priority,COALESCE(b.badge_code,'STANDARD') tier FROM myshop_live_requests r LEFT JOIN myshop_auth_users_v108 u ON u.user_id=r.user_id LEFT JOIN myshop_live_fan_club fc ON fc.host_id=r.host_id AND fc.user_id=r.user_id AND fc.active=1 LEFT JOIN myshop_user_badges b ON b.user_id=r.user_id AND b.status='ACTIVE' AND (b.expires_at IS NULL OR datetime(b.expires_at)>datetime('now')) AND b.badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP') WHERE r.host_id=? AND r.status='PENDING' AND r.session_id=? GROUP BY r.user_id ORDER BY tier_priority DESC,fan_points DESC,r.created_at`).bind(hostId,requestSession).all()).results||[]):[];
  const inviteMeta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();
  await env.DB.prepare(`UPDATE myshop_live_invites SET status='EXPIRED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND status='PENDING' AND datetime(expires_at)<=datetime('now')`).bind(hostId).run();
  const incomingInvite=me.user_id===hostId?null:await env.DB.prepare(`SELECT i.host_id,i.user_id,i.session_id,i.status,i.expires_at,i.created_at,u.full_name host_name FROM myshop_live_invites i LEFT JOIN myshop_auth_users_v108 u ON u.user_id=i.host_id WHERE i.host_id=? AND i.user_id=? AND i.session_id=? AND i.status='PENDING' AND datetime(i.expires_at)>datetime('now') LIMIT 1`).bind(hostId,me.user_id,String(inviteMeta?.session_id||'')).first();
  const outgoingInvites=me.user_id===hostId?((await env.DB.prepare(`SELECT i.user_id,i.status,i.expires_at,i.created_at,u.full_name,u.avatar_url FROM myshop_live_invites i LEFT JOIN myshop_auth_users_v108 u ON u.user_id=i.user_id WHERE i.host_id=? AND i.session_id=? AND i.status='PENDING' AND datetime(i.expires_at)>datetime('now') ORDER BY i.created_at DESC`).bind(hostId,String(inviteMeta?.session_id||'')).all()).results||[]):[];
  const meta=await env.DB.prepare(`SELECT special_guest_id,locked,title,topic,started_at,peak_viewers,share_count,pinned_message,theme_key,COALESCE(react_count,0) react_count,COALESCE(react_reward_milestone,0) react_reward_milestone,COALESCE(session_id,'') session_id,COALESCE(welcome_message,'') welcome_message,COALESCE(goal_type,'NONE') goal_type,COALESCE(goal_target,0) goal_target,COALESCE(pinned_product_id,0) pinned_product_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();
  const lockedRows=(await env.DB.prepare(`SELECT seat_no FROM myshop_live_seat_locks WHERE host_id=? AND locked=1 AND seat_no BETWEEN 2 AND 9 ORDER BY seat_no`).bind(hostId).all()).results||[];
  const events=(await env.DB.prepare(`SELECT e.id,e.event_type,e.message,e.created_at,u.full_name FROM myshop_live_events e LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.user_id WHERE e.host_id=? AND e.session_id=? ORDER BY e.id DESC LIMIT 8`).bind(hostId,String(meta?.session_id||'')).all()).results||[];
  const ephKey=liveEphemeralKey(hostId,String(meta?.session_id||''));
  const myViewerJoin=me.user_id===hostId?null:await env.DB.prepare(`SELECT joined_at FROM myshop_live_viewers WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).first();
  const joinRaw=String(myViewerJoin?.joined_at||'');const joinParsed=joinRaw?Date.parse(joinRaw.includes('T')?joinRaw:(joinRaw.replace(' ','T')+'Z')):Date.now();const visibleSinceMs=me.user_id===hostId?0:Math.max(0,joinParsed||Date.now());
  const comments=liveEphemeralPrune(liveEphemeralComments,ephKey,80,60*60*1000).filter(x=>Number(x._ts||0)>=visibleSinceMs).slice(-80).map(x=>{const y={...x};delete y._ts;return y;});
  const theme=await env.DB.prepare(`SELECT theme_key,name,background_url,accent FROM myshop_live_themes WHERE theme_key=? AND enabled=1`).bind(String(meta?.theme_key||'GUITAR_BLUE')).first();
  const seen=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_listener_seen WHERE host_id=? AND started_at=?`).bind(hostId,String(meta?.started_at||'')).first();
  const viewerProfiles=(await env.DB.prepare(`SELECT v.user_id,u.full_name,u.avatar_url,COALESCE(u.gender,'UNSPECIFIED') gender,COALESCE(cw.balance,0) coin_balance,(CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=v.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=v.user_id),0)) AS level,COALESCE((SELECT b.badge_code FROM myshop_user_badges b WHERE b.user_id=v.user_id AND b.status='ACTIVE' AND (b.expires_at IS NULL OR datetime(b.expires_at)>datetime('now')) AND b.badge_code IN ('KING','QUEEN','ROYAL','VVIP','VIP') ORDER BY CASE b.badge_code WHEN 'KING' THEN 1 WHEN 'QUEEN' THEN 1 WHEN 'ROYAL' THEN 2 WHEN 'VVIP' THEN 3 WHEN 'VIP' THEN 4 ELSE 9 END LIMIT 1),'STANDARD') AS tier,CASE WHEN EXISTS(SELECT 1 FROM myshop_live_room_admins ra WHERE ra.host_id=v.host_id AND ra.user_id=v.user_id AND ra.active=1) THEN 1 ELSE 0 END AS room_admin,COALESCE((SELECT fc.points FROM myshop_live_fan_club fc WHERE fc.host_id=v.host_id AND fc.user_id=v.user_id AND fc.active=1),0) AS fan_points FROM myshop_live_viewers v LEFT JOIN myshop_auth_users_v108 u ON u.user_id=v.user_id LEFT JOIN myshop_coin_wallets cw ON cw.user_id=v.user_id WHERE v.host_id=? AND datetime(v.last_seen)>=datetime('now','-25 seconds') ORDER BY datetime(v.last_seen) DESC LIMIT 100`).bind(hostId).all()).results||[];
  const mySanction=await liveSanctionFor(env,hostId,me.user_id);const myRoomAdmin=await isRoomAdmin(env,hostId,me.user_id);
  const liveStart=String(meta?.started_at||''),sessionId=String(meta?.session_id||'');
  try{await liveHubRegister(request,env,hostId,sessionId,me.user_id);}catch(e){}
  const topSupporters=(await env.DB.prepare(`SELECT e.sender_id,u.full_name,u.avatar_url,SUM(CASE WHEN e.currency='COIN' THEN e.price ELSE 0 END) coin_value,SUM(CASE WHEN e.currency='GOLD' THEN e.price ELSE 0 END) gold_value,SUM(CASE WHEN e.currency='GOLD' THEN e.price*100 ELSE e.price END) total_value,COUNT(*) gift_count FROM myshop_live_gift_events e LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id WHERE e.host_id=? AND e.status='COMPLETED' AND ((?<>'' AND e.session_id=?) OR (?='' AND (?='' OR datetime(e.created_at)>=datetime(?)))) GROUP BY e.sender_id ORDER BY total_value DESC,gift_count DESC LIMIT 20`).bind(hostId,sessionId,sessionId,sessionId,liveStart,liveStart).all()).results||[];
  const hourlyTop=(await env.DB.prepare(`SELECT e.sender_id,u.full_name,u.avatar_url,SUM(e.price) total_value,COUNT(*) gift_count FROM myshop_live_gift_events e LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id WHERE e.host_id=? AND e.status='COMPLETED' AND datetime(e.created_at)>=datetime('now','-1 hour') AND (?='' OR e.session_id=?) GROUP BY e.sender_id ORDER BY total_value DESC,gift_count DESC LIMIT 10`).bind(hostId,sessionId,sessionId).all()).results||[];
  const rankMap=new Map(topSupporters.map((x,i)=>[String(x.sender_id),i+1]));
  for(const v of viewerProfiles){v.supporterRank=rankMap.get(String(v.user_id))||0;v.roomAdmin=Number(v.room_admin||0)===1;v.fanPoints=Number(v.fan_points||0);delete v.room_admin;delete v.fan_points;}
  for(const seat of seats){seat.roomAdmin=Number(seat.room_admin||0)===1;seat.fanPoints=Number(seat.fan_points||0);delete seat.room_admin;delete seat.fan_points;}
  const tierRank={KING:1,QUEEN:1,ROYAL:2,VVIP:3,VIP:4,STANDARD:9};viewerProfiles.sort((a,b)=>{const ar=Number(a.supporterRank||0),br=Number(b.supporterRank||0),at=ar>=1&&ar<=3,bt=br>=1&&br<=3;if(at&&bt)return ar-br;if(at)return -1;if(bt)return 1;const tr=(tierRank[String(a.tier||'STANDARD').toUpperCase()]||9)-(tierRank[String(b.tier||'STANDARD').toUpperCase()]||9);if(tr!==0)return tr;const coin=Number(b.coin_balance||0)-Number(a.coin_balance||0);if(coin!==0)return coin;return Number(b.level||0)-Number(a.level||0);});
  const highlights=liveEphemeralPrune(liveEphemeralHighlights,ephKey,20,12000).filter(x=>Number(x._ts||0)>=visibleSinceMs).slice(-10).reverse().map(x=>{const y={...x};delete y._ts;return y;});
  const myTier=await currentTier(env,me.user_id);const myLevelInfo=await coinLevelFor(env,me.user_id);
  const startedMs=liveStart?Date.parse(liveStart.replace(' ','T')+'Z'):0;const elapsedSeconds=startedMs&&Number.isFinite(startedMs)?Math.max(0,Math.floor((Date.now()-startedMs)/1000)):0;
  const giftAgg=await env.DB.prepare(`SELECT COALESCE(SUM(price),0) total,COUNT(DISTINCT sender_id) supporters FROM myshop_live_gift_events WHERE host_id=? AND status='COMPLETED' AND ((?<>'' AND session_id=?) OR (?='' AND (?='' OR datetime(created_at)>=datetime(?))))`).bind(hostId,sessionId,sessionId,sessionId,liveStart,liveStart).first();
  const goalType=String(meta?.goal_type||'NONE').toUpperCase(),goalTarget=Math.max(0,Number(meta?.goal_target||0));let goalCurrent=0;if(goalType==='COIN')goalCurrent=Number(giftAgg?.total||0);else if(goalType==='SUPPORTERS')goalCurrent=Number(giftAgg?.supporters||0);else if(goalType==='MINUTES')goalCurrent=Math.floor(elapsedSeconds/60);else if(goalType==='VIEWERS')goalCurrent=Number(live.viewer_count||0);
  const fan=await env.DB.prepare(`SELECT active,points FROM myshop_live_fan_club WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).first();const fanCountRow=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_fan_club WHERE host_id=? AND active=1`).bind(hostId).first();
  const hist=await env.DB.prepare(`SELECT COUNT(*) live_count,COALESCE(SUM(duration_seconds),0) total_duration,COALESCE(MAX(peak_viewers),0) best_peak FROM myshop_live_history WHERE host_id=?`).bind(hostId).first();const allGifts=await env.DB.prepare(`SELECT COALESCE(SUM(price),0) total FROM myshop_live_gift_events WHERE host_id=? AND status='COMPLETED'`).bind(hostId).first();
  const hostLiveLevel=Math.min(99,Math.max(1,1+Math.floor((Number(hist?.live_count||0)*2+Number(hist?.total_duration||0)/1800+Number(allGifts?.total||0)/5000)/5)));const roomLevel=Math.min(99,Math.max(1,1+Math.floor((Number(live.viewer_count||0)+Number(meta?.react_count||0)/100+Number(giftAgg?.total||0)/500)/10)));
  const entryEvents=(await env.DB.prepare(`SELECT e.id,e.user_id,e.tier,e.created_at,u.full_name,u.avatar_url FROM myshop_live_entry_events e LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.user_id WHERE e.host_id=? AND datetime(e.created_at)>=datetime('now','-9 seconds') AND (?='' OR datetime(e.created_at)>=datetime(?)) ORDER BY e.id DESC LIMIT 8`).bind(hostId,liveStart,liveStart).all()).results||[];
  const viewerCutoffSql=me.user_id===hostId?'1970-01-01 00:00:00':String(myViewerJoin?.joined_at||new Date().toISOString().slice(0,19).replace('T',' '));
  const giftEvents=(await env.DB.prepare(`SELECT e.id,e.sender_id,e.receiver_id,e.currency,e.price,e.created_at,g.name,g.preview_url,g.animation_url,g.animation_mime,g.animation_enabled,g.sound_url,g.sound_enabled,g.sound_volume,g.effect_duration_ms,g.sound_duration_ms,g.sound_trim_start_pct,g.sound_trim_end_pct,g.vat_percent,g.board_position,g.animation_scale,g.size_mode,u.full_name sender_name,u.avatar_url sender_avatar,(CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=e.sender_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=e.sender_id),0)) AS sender_level,ru.full_name receiver_name FROM myshop_live_gift_events e JOIN myshop_live_gifts g ON g.id=e.gift_id LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id LEFT JOIN myshop_auth_users_v108 ru ON ru.user_id=e.receiver_id WHERE e.host_id=? AND e.status='COMPLETED' AND datetime(e.created_at)>=datetime('now','-12 seconds') AND datetime(e.created_at)>=datetime(?) AND (?='' OR e.session_id=?) ORDER BY e.id ASC LIMIT 12`).bind(hostId,viewerCutoffSql,sessionId,sessionId).all()).results||[];
  const hostWallet=await env.DB.prepare(`SELECT COALESCE(cw.balance,0) coin_balance,COALESCE(gw.balance,0) gold_balance,COALESCE(up.stars,0) stars FROM myshop_auth_users_v108 u LEFT JOIN myshop_coin_wallets cw ON cw.user_id=u.user_id LEFT JOIN myshop_gold_wallets gw ON gw.user_id=u.user_id LEFT JOIN myshop_user_progress up ON up.user_id=u.user_id WHERE u.user_id=?`).bind(hostId).first();
  const giftTotal=await env.DB.prepare(`SELECT COUNT(*) total FROM myshop_live_gift_events WHERE host_id=? AND status='COMPLETED' AND (?='' OR session_id=?)`).bind(hostId,sessionId,sessionId).first();
  const hostStats={totalGift:Number(giftTotal?.total||0),coinBalance:Number(hostWallet?.coin_balance||0),goldBalance:Number(hostWallet?.gold_balance||0),stars:Number(hostWallet?.stars||0)};
  let pinnedProduct=null;if(Number(meta?.pinned_product_id||0)>0)pinnedProduct=await env.DB.prepare(`SELECT id,code,title,item_type,price_minor,coin_price,preview_url FROM myshop_store_catalog WHERE id=? AND enabled=1`).bind(Number(meta.pinned_product_id)).first();
  let pk=null;const pkRow=await env.DB.prepare(`SELECT * FROM myshop_live_pk_rounds WHERE (host_a=? OR host_b=?) AND status IN ('PENDING','ACTIVE') ORDER BY id DESC LIMIT 1`).bind(hostId,hostId).first();if(pkRow){let scoreA=0,scoreB=0;if(String(pkRow.status)==='ACTIVE'){const sa=await env.DB.prepare(`SELECT COALESCE(SUM(price),0) s FROM myshop_live_gift_events WHERE host_id=? AND status='COMPLETED' AND (?='' OR session_id=?) AND datetime(created_at)>=datetime(?)`).bind(pkRow.host_a,String(pkRow.session_a||''),String(pkRow.session_a||''),String(pkRow.started_at||'1970-01-01')).first();const sb=await env.DB.prepare(`SELECT COALESCE(SUM(price),0) s FROM myshop_live_gift_events WHERE host_id=? AND status='COMPLETED' AND (?='' OR session_id=?) AND datetime(created_at)>=datetime(?)`).bind(pkRow.host_b,String(pkRow.session_b||''),String(pkRow.session_b||''),String(pkRow.started_at||'1970-01-01')).first();scoreA=Number(sa?.s||0);scoreB=Number(sb?.s||0);}pk={id:Number(pkRow.id),hostA:String(pkRow.host_a),hostB:String(pkRow.host_b),status:String(pkRow.status),incoming:me.user_id===hostId&&String(pkRow.status)==='PENDING'&&String(pkRow.host_b)===hostId,scoreA,scoreB};}
  const milestones=[];const vcNow=Number(live.viewer_count||0);for(const x of [10,50,100,500,1000])if(vcNow>=x)milestones.push('VIEWERS_'+x);if(goalTarget>0&&goalCurrent>=goalTarget)milestones.push('GOAL_COMPLETE');if(Number(meta?.react_count||0)>=10000)milestones.push('REACT_10K');
  return json({ok:true,hostId,viewerCount:Number(live.viewer_count||0),seats,requests,incomingInvite:incomingInvite||null,outgoingInvites,specialGuestId:String(meta?.special_guest_id||''),locked:Number(meta?.locked||0)===1,lockedSeats:lockedRows.map(x=>Number(x.seat_no)),title:String(meta?.title||"Let's Talk Together"),topic:String(meta?.topic||'Audio Live'),startedAt:String(meta?.started_at||''),elapsedSeconds,peakViewers:Number(meta?.peak_viewers||0),totalListeners:Number(seen?.c||0),shareCount:Number(meta?.share_count||0),reactCount:Number(meta?.react_count||0),reactRewardMilestone:Number(meta?.react_reward_milestone||0),sessionId,pinnedMessage:String(meta?.pinned_message||''),welcomeMessage:String(meta?.welcome_message||''),goal:{type:goalType,target:goalTarget,current:goalCurrent,completed:goalTarget>0&&goalCurrent>=goalTarget},pinnedProduct:pinnedProduct||null,hostLiveLevel,roomLevel,fanClub:{joined:Number(fan?.active||0)===1,points:Number(fan?.points||0),memberCount:Number(fanCountRow?.c||0)},pk,milestones,theme:theme||{theme_key:'GUITAR_BLUE',name:'Guitar Blue',background_url:'',accent:'#5B67FF'},viewerProfiles,topSupporters:topSupporters.map((x,i)=>({...x,rank:i+1})),hourlyTop:hourlyTop.map((x,i)=>({...x,rank:i+1})),highlightComments:highlights.reverse(),highlightDirection:'RIGHT_TO_LEFT',entryTier:myTier,myLevel:Number(myLevelInfo.level||0),entryEvents,giftEvents,hostStats,events:events.reverse(),comments:comments,myRole:me.user_id===hostId?'HOST':(seats.some(x=>x.user_id===me.user_id)?'SPEAKER':'AUDIENCE'),mySanction,myRoomAdmin,canPinComments:(me.user_id===hostId||myRoomAdmin||isAdminUser(me)||String(me.role||'').toUpperCase()==='MODERATOR')},200,cors);
}
async function liveSpeakRequest(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||'').trim();if(!isFourDigit(hostId)||hostId===me.user_id)return json({error:'INVALID_REQUEST'},400,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  const sanction=await liveSanctionFor(env,hostId,me.user_id);if(sanction==='MUTED')return json({error:'LIVE_MUTED_LISTEN_ONLY'},403,cors);if(sanction==='BLOCKED'||sanction==='KICKED')return json({error:'LIVE_BLOCKED'},403,cors);
  const seated=await env.DB.prepare(`SELECT 1 x FROM myshop_live_seats WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).first();if(seated)return json({error:'ALREADY_SPEAKER'},409,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();const sessionId=String(meta?.session_id||'');if(!sessionId)return json({error:'LIVE_SESSION_NOT_READY'},409,cors);
  const existing=await env.DB.prepare(`SELECT status,COALESCE(session_id,'') session_id FROM myshop_live_requests WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).first();
  if(existing&&String(existing.status)==='PENDING'&&String(existing.session_id||'')===sessionId)return json({ok:true,status:'PENDING',duplicateSuppressed:true},200,cors);
  await env.DB.prepare(`INSERT INTO myshop_live_requests(host_id,user_id,session_id,status,created_at,updated_at) VALUES(?,?,?,'PENDING',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id) DO UPDATE SET session_id=excluded.session_id,status='PENDING',created_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP`).bind(hostId,me.user_id,sessionId).run();
  await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'JOIN_REQUEST','requested to join the call')`).bind(hostId,me.user_id,sessionId).run();
  await createUserNotification(env,hostId,'Live Join Request',(me.full_name||'A user')+' wants to join your live call.','LIVE_JOIN_REQUEST',me.user_id,hostId);
  await liveHubDirty(env,hostId,sessionId,'JOIN_REQUEST');
  return json({ok:true,status:'PENDING'},200,cors);
}
async function liveRequestAction(request,env){
  const host=await getUser(request,env);if(!host)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),rid=String(b.requesterId||'').trim(),action=String(b.action||'').toUpperCase();
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(host.user_id).first();if(!live||Number(live.active)!==1)return json({error:'HOST_NOT_LIVE'},403,cors);if(!isFourDigit(rid)||!['ACCEPT','REJECT'].includes(action))return json({error:'INVALID_REQUEST'},400,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(host.user_id).first();const sessionId=String(meta?.session_id||'');const req=await env.DB.prepare(`SELECT status,COALESCE(session_id,'') session_id FROM myshop_live_requests WHERE host_id=? AND user_id=?`).bind(host.user_id,rid).first();if(!req||String(req.status)!=='PENDING'||(String(req.session_id||'')!==''&&String(req.session_id||'')!==sessionId))return json({error:'REQUEST_NOT_PENDING'},409,cors);if(String(req.session_id||'')==='')await env.DB.prepare(`UPDATE myshop_live_requests SET session_id=?,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=?`).bind(sessionId,host.user_id,rid).run();
  if(action==='REJECT'){
    await env.DB.prepare(`UPDATE myshop_live_requests SET status='REJECTED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=?`).bind(host.user_id,rid,sessionId).run();
    await createUserNotification(env,rid,'Live Request Update',(host.full_name||'Host')+' declined your join request.','LIVE_JOIN_REJECTED',host.user_id,host.user_id);
    await liveHubDirty(env,host.user_id,sessionId,'JOIN_REQUEST_REJECTED');
    return json({ok:true,status:'REJECTED'},200,cors);
  }
  const free=await env.DB.prepare(`WITH RECURSIVE n(x) AS (SELECT 2 UNION ALL SELECT x+1 FROM n WHERE x<9) SELECT x seat_no FROM n WHERE x NOT IN (SELECT seat_no FROM myshop_live_seats WHERE host_id=?) AND x NOT IN (SELECT seat_no FROM myshop_live_seat_locks WHERE host_id=? AND locked=1) ORDER BY x LIMIT 1`).bind(host.user_id,host.user_id).first();if(!free)return json({error:'NO_FREE_SEAT'},409,cors);
  const already=await env.DB.prepare(`SELECT seat_no FROM myshop_live_seats WHERE host_id=? AND user_id=?`).bind(host.user_id,rid).first();if(already)return json({ok:true,status:'ACCEPTED',seatNo:Number(already.seat_no),alreadySeated:true},200,cors);
  await env.DB.prepare(`INSERT INTO myshop_live_seats(host_id,seat_no,user_id,role,muted,updated_at) VALUES(?,?,?,'SPEAKER',0,CURRENT_TIMESTAMP)`).bind(host.user_id,free.seat_no,rid).run();
  await env.DB.prepare(`UPDATE myshop_live_requests SET status='ACCEPTED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=?`).bind(host.user_id,rid,sessionId).run();
  await env.DB.prepare(`UPDATE myshop_live_invites SET status='CANCELLED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND status='PENDING'`).bind(host.user_id,rid).run();
  await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'SPEAKER_JOIN','joined the call after host accepted request')`).bind(host.user_id,rid,sessionId).run();
  await createUserNotification(env,rid,'Join Request Accepted',(host.full_name||'Host')+' accepted you into the live call.','LIVE_JOIN_ACCEPTED',host.user_id,host.user_id);
  await liveHubDirty(env,host.user_id,sessionId,'SPEAKER_ACCEPTED');
  return json({ok:true,status:'ACCEPTED',seatNo:Number(free.seat_no)},200,cors);
}
async function liveInvite(request,env){
  const host=await getUser(request,env);if(!host)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),uid=String(b.userId||'').trim();if(!isFourDigit(uid)||uid===host.user_id)return json({error:'INVALID_INVITE_TARGET'},400,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(host.user_id).first();if(!live||Number(live.active)!==1)return json({error:'HOST_NOT_LIVE'},403,cors);
  const viewer=await env.DB.prepare(`SELECT 1 x FROM myshop_live_viewers WHERE host_id=? AND user_id=? AND datetime(last_seen)>=datetime('now','-25 seconds')`).bind(host.user_id,uid).first();if(!viewer)return json({error:'USER_NOT_IN_LIVE'},409,cors);
  const seated=await env.DB.prepare(`SELECT seat_no FROM myshop_live_seats WHERE host_id=? AND user_id=?`).bind(host.user_id,uid).first();if(seated)return json({error:'ALREADY_SPEAKER'},409,cors);
  const sanction=await liveSanctionFor(env,host.user_id,uid);if(['MUTED','BLOCKED','KICKED'].includes(sanction))return json({error:'USER_NOT_ELIGIBLE_FOR_CALL'},403,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(host.user_id).first();const sessionId=String(meta?.session_id||'');if(!sessionId)return json({error:'LIVE_SESSION_NOT_READY'},409,cors);
  const openInvite=await env.DB.prepare(`SELECT status,expires_at FROM myshop_live_invites WHERE host_id=? AND user_id=? AND session_id=?`).bind(host.user_id,uid,sessionId).first();
  if(openInvite&&String(openInvite.status)==='PENDING'&&Date.parse(String(openInvite.expires_at).replace(' ','T')+'Z')>Date.now())return json({ok:true,status:'PENDING',duplicateSuppressed:true,expiresInSeconds:90},200,cors);
  await env.DB.prepare(`INSERT INTO myshop_live_invites(host_id,user_id,session_id,status,expires_at,created_at,updated_at) VALUES(?,?,?,'PENDING',datetime('now','+90 seconds'),CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id,session_id) DO UPDATE SET status='PENDING',expires_at=datetime('now','+90 seconds'),updated_at=CURRENT_TIMESTAMP`).bind(host.user_id,uid,sessionId).run();
  await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'CALL_INVITE','was invited to join the call')`).bind(host.user_id,uid,sessionId).run();
  await createUserNotification(env,uid,'Live Call Invitation',(host.full_name||'Host')+' invited you to join the live call.','LIVE_CALL_INVITE',host.user_id,host.user_id);
  await liveHubDirty(env,host.user_id,sessionId,'CALL_INVITE');
  return json({ok:true,status:'PENDING',expiresInSeconds:90},200,cors);
}
async function liveInviteAction(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||'').trim(),action=String(b.action||'').toUpperCase();if(!isFourDigit(hostId)||!['ACCEPT','DECLINE'].includes(action))return json({error:'INVALID_INVITE_ACTION'},400,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();const sessionId=String(meta?.session_id||'');
  const inv=await env.DB.prepare(`SELECT status,expires_at FROM myshop_live_invites WHERE host_id=? AND user_id=? AND session_id=?`).bind(hostId,me.user_id,sessionId).first();if(!inv||String(inv.status)!=='PENDING')return json({error:'INVITE_NOT_PENDING'},409,cors);if(Date.parse(String(inv.expires_at).replace(' ','T')+'Z')<=Date.now()){await env.DB.prepare(`UPDATE myshop_live_invites SET status='EXPIRED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=?`).bind(hostId,me.user_id,sessionId).run();await liveHubDirty(env,hostId,sessionId,'CALL_INVITE_EXPIRED');return json({error:'INVITE_EXPIRED'},409,cors);}
  if(action==='DECLINE'){await env.DB.prepare(`UPDATE myshop_live_invites SET status='DECLINED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=?`).bind(hostId,me.user_id,sessionId).run();await createUserNotification(env,hostId,'Call Invitation Update',(me.full_name||'A user')+' declined your live call invitation.','LIVE_CALL_INVITE_DECLINED',me.user_id,hostId);await liveHubDirty(env,hostId,sessionId,'CALL_INVITE_DECLINED');return json({ok:true,status:'DECLINED'},200,cors);}
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  const viewer=await env.DB.prepare(`SELECT 1 x FROM myshop_live_viewers WHERE host_id=? AND user_id=? AND datetime(last_seen)>=datetime('now','-25 seconds')`).bind(hostId,me.user_id).first();if(!viewer)return json({error:'NOT_IN_LIVE'},409,cors);
  const sanction=await liveSanctionFor(env,hostId,me.user_id);if(['MUTED','BLOCKED','KICKED'].includes(sanction))return json({error:'NOT_ELIGIBLE_FOR_CALL'},403,cors);
  const already=await env.DB.prepare(`SELECT seat_no FROM myshop_live_seats WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).first();if(already){await env.DB.prepare(`UPDATE myshop_live_invites SET status='ACCEPTED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=?`).bind(hostId,me.user_id,sessionId).run();await liveHubDirty(env,hostId,sessionId,'SPEAKER_ALREADY_SEATED');return json({ok:true,status:'ACCEPTED',seatNo:Number(already.seat_no),alreadySeated:true},200,cors);}
  const free=await env.DB.prepare(`WITH RECURSIVE n(x) AS (SELECT 2 UNION ALL SELECT x+1 FROM n WHERE x<9) SELECT x seat_no FROM n WHERE x NOT IN (SELECT seat_no FROM myshop_live_seats WHERE host_id=?) AND x NOT IN (SELECT seat_no FROM myshop_live_seat_locks WHERE host_id=? AND locked=1) ORDER BY x LIMIT 1`).bind(hostId,hostId).first();if(!free)return json({error:'NO_FREE_SEAT'},409,cors);
  await env.DB.prepare(`INSERT INTO myshop_live_seats(host_id,seat_no,user_id,role,muted,updated_at) VALUES(?,?,?,'SPEAKER',0,CURRENT_TIMESTAMP)`).bind(hostId,free.seat_no,me.user_id).run();
  await env.DB.prepare(`UPDATE myshop_live_invites SET status='ACCEPTED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=?`).bind(hostId,me.user_id,sessionId).run();
  await env.DB.prepare(`UPDATE myshop_live_requests SET status='ACCEPTED',updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=? AND session_id=? AND status='PENDING'`).bind(hostId,me.user_id,sessionId).run();
  await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'SPEAKER_JOIN','joined the call after accepting host invitation')`).bind(hostId,me.user_id,sessionId).run();
  await createUserNotification(env,hostId,'Call Invitation Accepted',(me.full_name||'A user')+' accepted your invitation and joined the call.','LIVE_CALL_INVITE_ACCEPTED',me.user_id,hostId);
  await liveHubDirty(env,hostId,sessionId,'SPEAKER_INVITE_ACCEPTED');
  return json({ok:true,status:'ACCEPTED',seatNo:Number(free.seat_no)},200,cors);
}
async function liveLeaveSeat(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||'').trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const existing=await env.DB.prepare(`SELECT seat_no FROM myshop_live_seats WHERE host_id=? AND user_id=? AND seat_no>1 LIMIT 1`).bind(hostId,me.user_id).first();
  await env.DB.prepare(`DELETE FROM myshop_live_seats WHERE host_id=? AND user_id=? AND seat_no>1`).bind(hostId,me.user_id).run();
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET special_guest_id=NULL,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND special_guest_id=?`).bind(hostId,me.user_id).run();
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();
  if(existing&&String(meta?.session_id||''))await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'SPEAKER_LEAVE','left the call')`).bind(hostId,me.user_id,String(meta.session_id)).run();
  if(existing&&String(meta?.session_id||''))await liveHubDirty(env,hostId,String(meta.session_id),'SPEAKER_LEFT');
  return json({ok:true,role:'AUDIENCE',wasSpeaker:!!existing},200,cors);
}

async function liveSeatAssign(request,env){
  const actor=await getUser(request,env);if(!actor)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
  const b=await body(request),seatNo=Math.floor(Number(b.seatNo||0));if(seatNo<2||seatNo>9)return json({error:'INVALID_SEAT_ASSIGNMENT'},400,cors);
  const requestedHostId=String(b.hostId||'').trim();
  const selfMove=isFourDigit(requestedHostId)&&requestedHostId!==actor.user_id;
  const hostId=selfMove?requestedHostId:actor.user_id;
  const uid=selfMove?actor.user_id:String(b.userId||'').trim();
  if(!isFourDigit(hostId)||!isFourDigit(uid)||uid===hostId)return json({error:'INVALID_SEAT_ASSIGNMENT'},400,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'HOST_NOT_LIVE'},403,cors);
  if(!selfMove && hostId!==actor.user_id)return json({error:'HOST_ONLY'},403,cors);
  const speaker=await env.DB.prepare(`SELECT seat_no FROM myshop_live_seats WHERE host_id=? AND user_id=?`).bind(hostId,uid).first();if(!speaker)return json({error:'USER_NOT_SPEAKER'},409,cors);
  const locked=await env.DB.prepare(`SELECT locked FROM myshop_live_seat_locks WHERE host_id=? AND seat_no=?`).bind(hostId,seatNo).first();if(Number(locked?.locked||0)===1)return json({error:'SEAT_LOCKED'},409,cors);
  const occupied=await env.DB.prepare(`SELECT user_id FROM myshop_live_seats WHERE host_id=? AND seat_no=?`).bind(hostId,seatNo).first();if(occupied&&String(occupied.user_id)!==uid)return json({error:'SEAT_OCCUPIED'},409,cors);
  await env.DB.prepare(`UPDATE myshop_live_seats SET seat_no=?,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=?`).bind(seatNo,hostId,uid).run();
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET special_guest_id=NULL,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND special_guest_id=?`).bind(hostId,uid).run();
  const meta=await env.DB.prepare(`SELECT COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();
  await env.DB.prepare(`INSERT INTO myshop_live_events(host_id,user_id,session_id,event_type,message) VALUES(?,?,?,'SEAT_MOVE',?)`).bind(hostId,uid,String(meta?.session_id||''),'moved to guest seat '+seatNo).run();
  if(String(meta?.session_id||''))await liveHubDirty(env,hostId,String(meta.session_id),'SEAT_MOVED');
  return json({ok:true,userId:uid,seatNo,selfMove},200,cors);
}

async function liveSpecialGuest(request,env){
  const host=await getUser(request,env);if(!host)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
  const b=await body(request),uid=String(b.userId||'').trim(),clear=b.clear===true;
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(host.user_id).first();if(!live||Number(live.active)!==1)return json({error:'HOST_NOT_LIVE'},403,cors);
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_room_meta(host_id,special_guest_id,locked) VALUES(?,NULL,0)`).bind(host.user_id).run();
  if(clear){await env.DB.prepare(`UPDATE myshop_live_room_meta SET special_guest_id=NULL,updated_at=CURRENT_TIMESTAMP WHERE host_id=?`).bind(host.user_id).run();await liveHubDirtyForHost(env,host.user_id,'SPECIAL_GUEST_CLEARED');return json({ok:true,specialGuestId:''},200,cors);}
  if(!isFourDigit(uid)||uid===host.user_id)return json({error:'INVALID_SPECIAL_GUEST'},400,cors);
  const seated=await env.DB.prepare(`SELECT seat_no FROM myshop_live_seats WHERE host_id=? AND user_id=? AND seat_no>1`).bind(host.user_id,uid).first();
  if(!seated)return json({error:'USER_NOT_ON_SPEAKER_SEAT'},409,cors);
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET special_guest_id=?,updated_at=CURRENT_TIMESTAMP WHERE host_id=?`).bind(uid,host.user_id).run();
  await liveHubDirtyForHost(env,host.user_id,'SPECIAL_GUEST_SET');
  return json({ok:true,specialGuestId:uid,seatNo:Number(seated.seat_no)},200,cors);
}
async function liveSpeakerRemove(request,env){
  const host=await getUser(request,env);if(!host)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),uid=String(b.userId||'').trim();
  if(!isFourDigit(uid)||uid===host.user_id)return json({error:'INVALID_SPEAKER'},400,cors);
  await env.DB.prepare(`DELETE FROM myshop_live_seats WHERE host_id=? AND user_id=? AND seat_no>1`).bind(host.user_id,uid).run();
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET special_guest_id=NULL,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND special_guest_id=?`).bind(host.user_id,uid).run();
  await liveHubDirtyForHost(env,host.user_id,'SPEAKER_REMOVED');
  return json({ok:true},200,cors);
}


async function liveCommentUiConfig(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);await ensureLevelSchema(env);
  const legacy=await env.DB.prepare(`SELECT font_size FROM myshop_live_comment_ui WHERE id=1`).first();
  const grow=await env.DB.prepare(`SELECT style_json FROM myshop_live_comment_global WHERE id=1`).first();
  let globalStyle={};try{globalStyle=JSON.parse(String(grow?.style_json||'{}'));}catch(e){}
  if(!globalStyle.fontSize)globalStyle={backgroundColor:'#0A1841',textColor:'#FFFFFF',nameColor:'#FFFFFF',levelColor:'#FFD54F',borderColor:'#4B67BD',fontSize:Number(legacy?.font_size||15),fontWeight:'NORMAL',borderWidth:1,cornerRadius:14,opacity:92,borderGlow:false,borderGlowColor:'#A855F7',borderGlowIntensity:55,backgroundGlow:false,animation:false,animationType:'PULSE',animationSpeed:55};
  const pr=(await env.DB.prepare(`SELECT preset_key,badge,gender,preset_no,style_json FROM myshop_live_comment_presets ORDER BY badge,gender,preset_no`).all()).results||[];
  const presets=pr.map(r=>{let o={};try{o=JSON.parse(String(r.style_json||'{}'));}catch(e){}return {...o,presetKey:r.preset_key,badge:r.badge,gender:r.gender,presetNo:Number(r.preset_no||1)};});
  const ar=(await env.DB.prepare(`SELECT a.user_id,a.preset_key,a.custom_style_json,a.is_custom,a.enabled,u.full_name AS name,COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=a.user_id),0) AS level FROM myshop_live_comment_assignments a LEFT JOIN myshop_auth_users_v108 u ON u.user_id=a.user_id WHERE a.enabled=1`).all()).results||[];
  const assignments=ar.map(r=>{let c={};try{c=JSON.parse(String(r.custom_style_json||'{}'));}catch(e){}return {userId:r.user_id,presetKey:r.preset_key||'',customStyle:c,isCustom:Number(r.is_custom||0)===1,enabled:Number(r.enabled||0)===1,name:r.name||'',level:Number(r.level||0)};});
  return json({ok:true,globalStyle,presets,assignments},200,cors);
}
function cleanCommentStyle(input){
  const s=(input&&typeof input==='object')?input:{};const hex=(v,d)=>/^#[0-9A-Fa-f]{6}$/.test(String(v||''))?String(v).toUpperCase():d;
  const pick=(v,allowed,d)=>allowed.includes(String(v||d).toUpperCase())?String(v||d).toUpperCase():d;
  return {backgroundColor:hex(s.backgroundColor,'#0A1841'),textColor:hex(s.textColor,'#FFFFFF'),nameColor:hex(s.nameColor,'#FFFFFF'),levelColor:hex(s.levelColor,'#FFD54F'),borderColor:hex(s.borderColor,'#4B67BD'),fontSize:Math.max(12,Math.min(28,Math.floor(Number(s.fontSize||15)))),fontWeight:String(s.fontWeight||'NORMAL').toUpperCase()==='BOLD'?'BOLD':'NORMAL',borderWidth:Math.max(1,Math.min(6,Math.floor(Number(s.borderWidth||1)))),cornerRadius:Math.max(4,Math.min(30,Math.floor(Number(s.cornerRadius||14)))),opacity:Math.max(30,Math.min(100,Math.floor(Number(s.opacity||92)))),borderGlow:s.borderGlow===true,borderGlowColor:hex(s.borderGlowColor,'#A855F7'),borderGlowIntensity:Math.max(0,Math.min(100,Math.floor(Number(s.borderGlowIntensity||55)))),backgroundGlow:s.backgroundGlow===true,animation:s.animation===true,animationType:pick(s.animationType,['PULSE','SOFT FADE','FADE','POP','NONE'],'PULSE'),animationSpeed:Math.max(10,Math.min(100,Math.floor(Number(s.animationSpeed||55)))),boxAnimation:s.boxAnimation===true,boxAnimationType:pick(s.boxAnimationType,['FADE','PULSE','POP','NONE'],'FADE'),borderAnimation:s.borderAnimation===true,borderAnimationType:pick(s.borderAnimationType,['GLOW BORDER','PULSE BORDER','SOFT FLASH','NONE'],'GLOW BORDER'),textAnimation:s.textAnimation===true,textAnimationType:pick(s.textAnimationType,['FADE TEXT','PULSE TEXT','NONE'],'FADE TEXT'),nameAnimation:s.nameAnimation===true,nameAnimationType:pick(s.nameAnimationType,['SOFT GLOW','FADE','NONE'],'SOFT GLOW'),levelAnimation:s.levelAnimation===true,levelAnimationType:pick(s.levelAnimationType,['SOFT GLOW','FADE','NONE'],'SOFT GLOW')};
}
async function adminLiveCommentGlobalSave(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!isAdminUser(me))return json({error:'FORBIDDEN'},403,cors);await ensureLiveRoomSchema(env);const b=await body(request),style=cleanCommentStyle(b.style);
  await env.DB.prepare(`INSERT INTO myshop_live_comment_global(id,style_json,updated_at) VALUES(1,?,CURRENT_TIMESTAMP) ON CONFLICT(id) DO UPDATE SET style_json=excluded.style_json,updated_at=CURRENT_TIMESTAMP`).bind(JSON.stringify(style)).run();
  await env.DB.prepare(`UPDATE myshop_live_comment_ui SET font_size=?,updated_at=CURRENT_TIMESTAMP WHERE id=1`).bind(style.fontSize).run();
  return json({ok:true,style},200,cors);
}
async function adminLiveCommentPresetSave(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!isAdminUser(me))return json({error:'FORBIDDEN'},403,cors);await ensureLiveRoomSchema(env);const b=await body(request);
  const badge=String(b.badge||'').trim().toUpperCase(),gender=String(b.gender||'').trim().toUpperCase(),presetNo=Math.max(1,Math.min(5,Math.floor(Number(b.presetNo||1))));
  if(!['VIP','VVIP','ROYAL','KING','QUEEN'].includes(badge))return json({error:'INVALID_BADGE'},400,cors);if(!['MALE','FEMALE'].includes(gender))return json({error:'INVALID_GENDER'},400,cors);if(badge==='KING'&&gender!=='MALE')return json({error:'KING_MALE_ONLY'},400,cors);if(badge==='QUEEN'&&gender!=='FEMALE')return json({error:'QUEEN_FEMALE_ONLY'},400,cors);
  const key=`${badge}-${gender}-${presetNo}`,style=cleanCommentStyle(b);
  await env.DB.prepare(`INSERT INTO myshop_live_comment_presets(preset_key,badge,gender,preset_no,style_json,updated_at) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(preset_key) DO UPDATE SET badge=excluded.badge,gender=excluded.gender,preset_no=excluded.preset_no,style_json=excluded.style_json,updated_at=CURRENT_TIMESTAMP`).bind(key,badge,gender,presetNo,JSON.stringify(style)).run();
  return json({ok:true,presetKey:key,style},200,cors);
}
async function adminLiveCommentAssignmentSave(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!isAdminUser(me))return json({error:'FORBIDDEN'},403,cors);await ensureLiveRoomSchema(env);await ensureLevelSchema(env);const b=await body(request),uid=String(b.userId||'').trim();
  if(!isFourDigit(uid))return json({error:'INVALID_USER_ID'},400,cors);const u=await env.DB.prepare(`SELECT user_id,full_name AS name,COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=myshop_auth_users_v108.user_id),0) AS level FROM myshop_auth_users_v108 WHERE user_id=?`).bind(uid).first();if(!u)return json({error:'USER_NOT_FOUND'},404,cors);
  const isCustom=b.custom===true,presetKey=isCustom?'':String(b.presetKey||'').trim().toUpperCase(),enabled=b.enabled===false?0:1;let custom={};
  if(!enabled){
    await env.DB.prepare(`INSERT INTO myshop_live_comment_assignments(user_id,preset_key,custom_style_json,is_custom,enabled,updated_at) VALUES(?,?,?,?,0,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET preset_key='',custom_style_json='{}',is_custom=0,enabled=0,updated_at=CURRENT_TIMESTAMP`).bind(uid,'','{}',0).run();
    return json({ok:true,userId:uid,name:u.name||'',level:Number(u.level||0),presetKey:'',isCustom:false,enabled:false},200,cors);
  }
  if(isCustom)custom=cleanCommentStyle(b.customStyle);else{if(!presetKey)return json({error:'PRESET_REQUIRED'},400,cors);const p=await env.DB.prepare(`SELECT preset_key FROM myshop_live_comment_presets WHERE preset_key=?`).bind(presetKey).first();if(!p)return json({error:'SAVE_PRESET_FIRST'},409,cors);}
  await env.DB.prepare(`INSERT INTO myshop_live_comment_assignments(user_id,preset_key,custom_style_json,is_custom,enabled,updated_at) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(user_id) DO UPDATE SET preset_key=excluded.preset_key,custom_style_json=excluded.custom_style_json,is_custom=excluded.is_custom,enabled=excluded.enabled,updated_at=CURRENT_TIMESTAMP`).bind(uid,presetKey,JSON.stringify(custom),isCustom?1:0,enabled).run();
  return json({ok:true,userId:uid,name:u.name||'',level:Number(u.level||0),presetKey,isCustom},200,cors);
}
async function liveRoomConfig(request,env){
  const actor=await getUser(request,env);if(!actor)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request);
  const targetHostId=String(b.hostId||actor.user_id).trim();if(!isFourDigit(targetHostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const hostActor=actor.user_id===targetHostId,roomAdmin=await isRoomAdmin(env,targetHostId,actor.user_id),globalAdmin=isAdminUser(actor),globalModerator=String(actor.role||'').toUpperCase()==='MODERATOR';
  const onlyPin=Object.prototype.hasOwnProperty.call(b,'pinnedMessage')&&!Object.prototype.hasOwnProperty.call(b,'title')&&!Object.prototype.hasOwnProperty.call(b,'topic')&&!Object.prototype.hasOwnProperty.call(b,'themeKey')&&!Object.prototype.hasOwnProperty.call(b,'slowModeSeconds')&&!Object.prototype.hasOwnProperty.call(b,'entryEffectsEnabled')&&!Object.prototype.hasOwnProperty.call(b,'giftComboEnabled');
  if(onlyPin){if(!(hostActor||roomAdmin||globalAdmin||globalModerator))return json({error:'FORBIDDEN'},403,cors);}else if(!hostActor)return json({error:'HOST_ONLY_SETTINGS'},403,cors);
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_room_meta(host_id,started_at) VALUES(?,CURRENT_TIMESTAMP)`).bind(targetHostId).run();
  const host=actor,fields=[],vals=[];
  if(Object.prototype.hasOwnProperty.call(b,'title')){const policy=await applyLiveNamePolicy(env,host.user_id,String(b.title||''));if(!policy.ok)return json({error:policy.error,remainingSeconds:policy.remainingSeconds||0,cost:policy.cost||0},409,cors);fields.push('title=?');vals.push(policy.name);}
  if(Object.prototype.hasOwnProperty.call(b,'topic')){fields.push('topic=?');vals.push(String(b.topic||'').trim().slice(0,120)||'Audio Live');}
  if(Object.prototype.hasOwnProperty.call(b,'pinnedMessage')){fields.push('pinned_message=?');vals.push(String(b.pinnedMessage||'').trim().slice(0,180));}
  if(Object.prototype.hasOwnProperty.call(b,'themeKey')){const k=String(b.themeKey||'').trim();const ok=await env.DB.prepare(`SELECT 1 x FROM myshop_live_themes WHERE theme_key=? AND enabled=1`).bind(k).first();if(!ok)return json({error:'THEME_NOT_AVAILABLE'},409,cors);fields.push('theme_key=?');vals.push(k);}
  if(Object.prototype.hasOwnProperty.call(b,'slowModeSeconds')){fields.push('slow_mode_seconds=?');vals.push(Math.max(0,Math.min(60,Number(b.slowModeSeconds||0))));}
  if(Object.prototype.hasOwnProperty.call(b,'entryEffectsEnabled')){fields.push('entry_effects_enabled=?');vals.push(b.entryEffectsEnabled===false?0:1);}
  if(Object.prototype.hasOwnProperty.call(b,'giftComboEnabled')){fields.push('gift_combo_enabled=?');vals.push(b.giftComboEnabled===false?0:1);}
  if(fields.length){vals.push(targetHostId);await env.DB.prepare(`UPDATE myshop_live_room_meta SET ${fields.join(',')},updated_at=CURRENT_TIMESTAMP WHERE host_id=?`).bind(...vals).run();await liveHubDirtyForHost(env,targetHostId,'ROOM_CONFIG');}
  return json({ok:true},200,cors);
}
async function liveSeatLock(request,env){
  const host=await getUser(request,env);if(!host)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),seatNo=Number(b.seatNo||0),locked=b.locked!==false;
  if(seatNo<2||seatNo>9)return json({error:'INVALID_SEAT'},400,cors);const occupied=await env.DB.prepare(`SELECT 1 x FROM myshop_live_seats WHERE host_id=? AND seat_no=?`).bind(host.user_id,seatNo).first();if(occupied&&locked)return json({error:'SEAT_OCCUPIED'},409,cors);
  if(locked)await env.DB.prepare(`INSERT INTO myshop_live_seat_locks(host_id,seat_no,locked,updated_at) VALUES(?,?,1,CURRENT_TIMESTAMP) ON CONFLICT(host_id,seat_no) DO UPDATE SET locked=1,updated_at=CURRENT_TIMESTAMP`).bind(host.user_id,seatNo).run();
  else await env.DB.prepare(`DELETE FROM myshop_live_seat_locks WHERE host_id=? AND seat_no=?`).bind(host.user_id,seatNo).run();
  await liveHubDirtyForHost(env,host.user_id,locked?'SEAT_LOCKED':'SEAT_UNLOCKED');
  return json({ok:true,seatNo,locked},200,cors);
}
async function liveParticipantState(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||'').trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const micOn=b.micOn===false?0:1,speaking=b.speaking===true?1:0;let nq=String(b.networkQuality||'GOOD').toUpperCase();if(!['GOOD','FAIR','WEAK','OFFLINE'].includes(nq))nq='GOOD';
  await env.DB.prepare(`UPDATE myshop_live_seats SET mic_on=?,speaking=?,network_quality=?,updated_at=CURRENT_TIMESTAMP WHERE host_id=? AND user_id=?`).bind(micOn,speaking,nq,hostId,me.user_id).run();return json({ok:true},200,cors);
}
async function liveShare(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||'').trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET share_count=COALESCE(share_count,0)+1,updated_at=CURRENT_TIMESTAMP WHERE host_id=?`).bind(hostId).run();const r=await env.DB.prepare(`SELECT share_count FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();return json({ok:true,shareCount:Number(r?.share_count||0)},200,cors);
}
async function liveComment(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
  const b=await body(request),hostId=String(b.hostId||'').trim(),message=String(b.message||'').trim().slice(0,240),clientNonce=String(b.clientNonce||'').trim().slice(0,80);
  if(!isFourDigit(hostId)||!message)return json({error:'INVALID_COMMENT'},400,cors);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(hostId).first();if(!live||Number(live.active)!==1)return json({error:'LIVE_NOT_ACTIVE'},404,cors);
  const sanction=await liveSanctionFor(env,hostId,me.user_id);if(sanction==='MUTED')return json({error:'LIVE_MUTED_LISTEN_ONLY'},403,cors);if(sanction==='BLOCKED'||sanction==='KICKED')return json({error:'LIVE_BLOCKED'},403,cors);
  const meta=await env.DB.prepare(`SELECT COALESCE(slow_mode_seconds,0) slow_mode_seconds,COALESCE(session_id,'') session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(hostId).first();
  const sessionId=String(meta?.session_id||'');if(!sessionId)return json({error:'LIVE_SESSION_NOT_READY'},409,cors);
  const key=liveEphemeralKey(hostId,sessionId),list=liveEphemeralPrune(liveEphemeralComments,key,80,60*60*1000);
  const slow=Math.max(0,Math.min(60,Number(meta?.slow_mode_seconds||0)));
  if(slow>0&&!await isFixedMainAdminId(me.user_id)&&!(await isAssignedModerator(env,me.user_id))){
    const last=[...list].reverse().find(x=>String(x.user_id)===String(me.user_id));
    if(last){const age=(Date.now()-Number(last._ts||0))/1000;if(age<slow)return json({error:'SLOW_MODE',retryAfter:Math.ceil(slow-age)},429,cors);}
  }
  if(clientNonce){const old=list.find(x=>String(x.user_id)===String(me.user_id)&&String(x.client_nonce||'')===clientNonce);if(old){const c={...old};delete c._ts;return json({ok:true,duplicateSuppressed:true,sessionId,comment:c},200,cors);}}
  const dup=[...list].reverse().find(x=>String(x.user_id)===String(me.user_id)&&String(x.message)===message&&Date.now()-Number(x._ts||0)<=2000);
  if(dup){const c={...dup};delete c._ts;return json({ok:true,duplicateSuppressed:true,sessionId,comment:c},200,cors);}
  const commentLevel=await coinLevelFor(env,me.user_id);const comment={user_id:me.user_id,message,client_nonce:clientNonce,created_at:new Date().toISOString(),full_name:me.full_name||me.user_id,avatar_url:me.avatar_url||'',gender:me.gender||'UNSPECIFIED',level:Number(commentLevel.level||0),tier:await currentTier(env,me.user_id)};
  let out=null;
  try{const pushed=await liveHubPush(env,hostId,sessionId,'COMMENT',comment);if(pushed?.item)out=pushed.item;}catch(e){}
  if(out){if(!list.some(x=>Number(x.id||0)===Number(out.id||0)))liveEphemeralPush(liveEphemeralComments,key,{...out,_ts:Date.now()},80,60*60*1000);}
  else{const fallback={...comment,id:liveEphemeralSeq++,_ts:Date.now()};liveEphemeralPush(liveEphemeralComments,key,fallback,80,60*60*1000);out={...fallback};delete out._ts;}
  return json({ok:true,ephemeral:true,realtime:true,sessionId,comment:out},201,cors);
}
async function liveThemes(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const rows=(await env.DB.prepare(`SELECT theme_key,name,background_url,accent,COALESCE(coin_price,0) coin_price,sort_order FROM myshop_live_themes WHERE enabled=1 ORDER BY sort_order,name`).all()).results||[];return json({ok:true,themes:rows},200,cors);
}
async function adminLiveTheme(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);if(!isAdminUser(me))return json({error:'FORBIDDEN'},403,cors);await ensureLiveRoomSchema(env);const b=await body(request),action=String(b.action||'UPSERT').toUpperCase(),key=String(b.themeKey||'').trim().toUpperCase();if(!/^[A-Z0-9_-]{2,40}$/.test(key))return json({error:'INVALID_THEME_KEY'},400,cors);
  if(action==='DELETE'){if(key==='GUITAR_BLUE')return json({error:'DEFAULT_THEME_PROTECTED'},409,cors);await env.DB.prepare(`DELETE FROM myshop_live_themes WHERE theme_key=?`).bind(key).run();return json({ok:true},200,cors);}
  const name=String(b.name||key).trim().slice(0,60),bg=String(b.backgroundUrl||'').trim().slice(0,500),accent=String(b.accent||'#5B67FF').trim().slice(0,16),coinPrice=Math.max(0,Math.floor(Number(b.coinPrice||0))),enabled=b.enabled===false?0:1,sort=Number(b.sortOrder||0);
  await env.DB.prepare(`INSERT INTO myshop_live_themes(theme_key,name,background_url,accent,coin_price,enabled,sort_order,updated_at) VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(theme_key) DO UPDATE SET name=excluded.name,background_url=excluded.background_url,accent=excluded.accent,coin_price=excluded.coin_price,enabled=excluded.enabled,sort_order=excluded.sort_order,updated_at=CURRENT_TIMESTAMP`).bind(key,name,bg,accent,coinPrice,enabled,sort).run();return json({ok:true,coinPrice},200,cors);
}
async function liveSummary(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const hostId=String(new URL(request.url).searchParams.get('hostId')||me.user_id).trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const r=await env.DB.prepare(`SELECT title,topic,started_at,ended_at,duration_seconds,peak_viewers,total_listeners,share_count,COALESCE(react_count,0) react_count,COALESCE(react_reward_coin,0) react_reward_coin,COALESCE(session_id,'') session_id FROM myshop_live_history WHERE host_id=? ORDER BY id DESC LIMIT 1`).bind(hostId).first();if(!r)return json({ok:true,summary:null},200,cors);const sid=String(r.session_id||'');
  const gifts=await env.DB.prepare(`SELECT COALESCE(SUM(price),0) total_gift_value,COUNT(*) gift_count,COUNT(DISTINCT sender_id) supporter_count FROM myshop_live_gift_events WHERE host_id=? AND status='COMPLETED' AND ((?<>'' AND session_id=?) OR (?='' AND datetime(created_at)>=datetime(?)))`).bind(hostId,sid,sid,sid,String(r.started_at||'')).first();
  const top=(await env.DB.prepare(`SELECT e.sender_id,u.full_name,u.avatar_url,SUM(e.price) total,COUNT(*) gift_count FROM myshop_live_gift_events e LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id WHERE e.host_id=? AND e.status='COMPLETED' AND ((?<>'' AND e.session_id=?) OR (?='' AND datetime(e.created_at)>=datetime(?))) GROUP BY e.sender_id ORDER BY total DESC LIMIT 20`).bind(hostId,sid,sid,sid,String(r.started_at||'')).all()).results||[];
  const beforeFollowers=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_follows WHERE following_id=? AND datetime(created_at)>=datetime(?) AND datetime(created_at)<=datetime(?)`).bind(hostId,String(r.started_at||''),String(r.ended_at||'')).first();
  return json({ok:true,summary:{...r,totalGiftValue:Number(gifts?.total_gift_value||0),giftCount:Number(gifts?.gift_count||0),supporterCount:Number(gifts?.supporter_count||0),commentCount:0,newFollowers:Number(beforeFollowers?.c||0),topSupporters:top.map((x,i)=>({...x,rank:i+1}))}},200,cors);
}

// MY SHOP V-304 premium live ecosystem endpoints. All mutations remain scoped to the authenticated user/host.
async function livePremiumConfig(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);
  const live=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(me.user_id).first();if(!live||Number(live.active)!==1)return json({error:'HOST_NOT_LIVE'},409,cors);
  const b=await body(request);const sets=[],vals=[];
  if(Object.prototype.hasOwnProperty.call(b,'welcomeMessage')){sets.push('welcome_message=?');vals.push(String(b.welcomeMessage||'').trim().slice(0,180));}
  if(Object.prototype.hasOwnProperty.call(b,'goalType')){let gt=String(b.goalType||'NONE').trim().toUpperCase();if(!['NONE','COIN','SUPPORTERS','MINUTES','VIEWERS'].includes(gt))return json({error:'INVALID_GOAL_TYPE'},400,cors);sets.push('goal_type=?');vals.push(gt);}
  if(Object.prototype.hasOwnProperty.call(b,'goalTarget')){const n=Math.max(0,Math.min(100000000,Math.floor(Number(b.goalTarget||0))));sets.push('goal_target=?');vals.push(n);}
  if(Object.prototype.hasOwnProperty.call(b,'pinnedProductId')){const id=Math.max(0,Math.floor(Number(b.pinnedProductId||0)));if(id>0){const item=await env.DB.prepare(`SELECT id FROM myshop_store_catalog WHERE id=? AND enabled=1`).bind(id).first();if(!item)return json({error:'PRODUCT_NOT_FOUND'},404,cors);}sets.push('pinned_product_id=?');vals.push(id);}
  if(!sets.length)return json({error:'NO_CHANGES'},400,cors);sets.push('updated_at=CURRENT_TIMESTAMP');vals.push(me.user_id);
  await env.DB.prepare(`UPDATE myshop_live_room_meta SET ${sets.join(',')} WHERE host_id=?`).bind(...vals).run();
  return json({ok:true},200,cors);
}
async function liveFanClub(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const hostId=String(new URL(request.url).searchParams.get('hostId')||me.user_id).trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const mine=await env.DB.prepare(`SELECT active,points,joined_at FROM myshop_live_fan_club WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).first();const count=await env.DB.prepare(`SELECT COUNT(*) c FROM myshop_live_fan_club WHERE host_id=? AND active=1`).bind(hostId).first();
  const top=(await env.DB.prepare(`SELECT f.user_id,f.points,f.joined_at,u.full_name,u.avatar_url FROM myshop_live_fan_club f LEFT JOIN myshop_auth_users_v108 u ON u.user_id=f.user_id WHERE f.host_id=? AND f.active=1 ORDER BY f.points DESC,datetime(f.joined_at) ASC LIMIT 50`).bind(hostId).all()).results||[];
  return json({ok:true,hostId,joined:Number(mine?.active||0)===1,points:Number(mine?.points||0),memberCount:Number(count?.c||0),members:top.map((x,i)=>({...x,rank:i+1}))},200,cors);
}
async function liveFanClubToggle(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),hostId=String(b.hostId||'').trim();if(!isFourDigit(hostId)||hostId===me.user_id)return json({error:'INVALID_HOST_ID'},400,cors);
  const host=await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1`).bind(hostId).first();if(!host)return json({error:'HOST_NOT_FOUND'},404,cors);const old=await env.DB.prepare(`SELECT active FROM myshop_live_fan_club WHERE host_id=? AND user_id=?`).bind(hostId,me.user_id).first();const active=old&&Number(old.active)===1?0:1;
  await env.DB.prepare(`INSERT INTO myshop_live_fan_club(host_id,user_id,active,points,joined_at,updated_at) VALUES(?,?,?,0,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP) ON CONFLICT(host_id,user_id) DO UPDATE SET active=excluded.active,updated_at=CURRENT_TIMESTAMP`).bind(hostId,me.user_id,active).run();
  if(active){try{await createUserNotification(env,hostId,'New Fan Club Member',(me.full_name||'A user')+' joined your Fan Club.','LIVE_FAN_JOIN',me.user_id,hostId);}catch(e){}}
  return json({ok:true,joined:active===1},200,cors);
}
async function liveCreatorCenter(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const hostId=String(new URL(request.url).searchParams.get('hostId')||me.user_id).trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const profile=await env.DB.prepare(`SELECT user_id,full_name,avatar_url FROM myshop_auth_users_v108 WHERE user_id=? AND active=1`).bind(hostId).first();if(!profile)return json({error:'USER_NOT_FOUND'},404,cors);
  const agg=await env.DB.prepare(`SELECT COUNT(*) live_count,COALESCE(SUM(duration_seconds),0) total_seconds,COALESCE(MAX(peak_viewers),0) best_peak,COALESCE(SUM(total_listeners),0) total_listeners,COALESCE(SUM(share_count),0) shares,COALESCE(SUM(react_count),0) reacts FROM myshop_live_history WHERE host_id=?`).bind(hostId).first();
  const gifts=await env.DB.prepare(`SELECT COALESCE(SUM(price),0) gift_value,COUNT(*) gift_count,COUNT(DISTINCT sender_id) supporters FROM myshop_live_gift_events WHERE host_id=? AND status='COMPLETED'`).bind(hostId).first();
  const fans=await env.DB.prepare(`SELECT COUNT(*) c,COALESCE(SUM(points),0) points FROM myshop_live_fan_club WHERE host_id=? AND active=1`).bind(hostId).first();const social=await socialStatsFor(env,hostId);
  const history=(await env.DB.prepare(`SELECT id,title,topic,started_at,ended_at,duration_seconds,peak_viewers,total_listeners,share_count,react_count,session_id FROM myshop_live_history WHERE host_id=? ORDER BY id DESC LIMIT 30`).bind(hostId).all()).results||[];
  const top=(await env.DB.prepare(`SELECT e.sender_id,u.full_name,u.avatar_url,SUM(e.price) total_value,COUNT(*) gift_count FROM myshop_live_gift_events e LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id WHERE e.host_id=? AND e.status='COMPLETED' GROUP BY e.sender_id ORDER BY total_value DESC LIMIT 20`).bind(hostId).all()).results||[];
  const liveLevel=Math.min(99,Math.max(1,1+Math.floor((Number(agg?.live_count||0)*2+Number(agg?.total_seconds||0)/1800+Number(gifts?.gift_value||0)/5000)/5)));
  const achievements=[];if(Number(agg?.live_count||0)>=1)achievements.push('FIRST_LIVE');if(Number(agg?.live_count||0)>=10)achievements.push('10_LIVES');if(Number(agg?.best_peak||0)>=100)achievements.push('100_PEAK');if(Number(gifts?.supporters||0)>=10)achievements.push('10_SUPPORTERS');if(Number(fans?.c||0)>=50)achievements.push('50_FANS');
  return json({ok:true,creator:{...profile,liveLevel,liveCount:Number(agg?.live_count||0),totalLiveSeconds:Number(agg?.total_seconds||0),bestPeak:Number(agg?.best_peak||0),totalListeners:Number(agg?.total_listeners||0),shares:Number(agg?.shares||0),reacts:Number(agg?.reacts||0),giftValue:Number(gifts?.gift_value||0),giftCount:Number(gifts?.gift_count||0),supporterCount:Number(gifts?.supporters||0),fanCount:Number(fans?.c||0),fanPoints:Number(fans?.points||0),social,achievements,history,topSupporters:top.map((x,i)=>({...x,rank:i+1}))}},200,cors);
}
async function liveDiscover(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureFriendSchema(env);await ensureLiveRoomSchema(env);const url=new URL(request.url),category=String(url.searchParams.get('category')||'LIVE_NOW').toUpperCase(),limit=Math.max(1,Math.min(100,Number(url.searchParams.get('limit')||50)));
  await env.DB.prepare(`UPDATE myshop_live_presence SET active=0 WHERE active=1 AND datetime(last_seen)<datetime('now','-2 minutes')`).run();
  let extra='',order=`l.viewer_count DESC,datetime(l.last_seen) DESC`;const binds=[];
  if(category==='FRIENDS')extra=` AND EXISTS(SELECT 1 FROM myshop_friend_requests f WHERE f.status='ACCEPTED' AND ((f.sender_id=? AND f.receiver_id=l.user_id) OR (f.receiver_id=? AND f.sender_id=l.user_id)))`,binds.push(me.user_id,me.user_id);
  else if(category==='FOLLOWING')extra=` AND EXISTS(SELECT 1 FROM myshop_follows f WHERE f.follower_id=? AND f.following_id=l.user_id)`,binds.push(me.user_id);
  else if(category==='NEW_HOST')order=`COALESCE((SELECT COUNT(*) FROM myshop_live_history h WHERE h.host_id=l.user_id),0) ASC,datetime(l.last_seen) DESC`;
  else if(category==='TRENDING')order=`(l.viewer_count*10+COALESCE(m.react_count,0)/50+COALESCE((SELECT SUM(g.price) FROM myshop_live_gift_events g WHERE g.host_id=l.user_id AND g.status='COMPLETED' AND g.session_id=m.session_id),0)/20) DESC`;
  else if(category==='SHOP_LIVE')extra=` AND COALESCE(m.pinned_product_id,0)>0`;
  else if(category==='TALK_ROOM')extra=` AND COALESCE(m.pinned_product_id,0)=0`;
  const rows=(await env.DB.prepare(`SELECT l.user_id,l.viewer_count,l.last_seen,u.full_name,u.avatar_url,COALESCE(m.title,'Live') title,COALESCE(m.topic,'Audio Live') topic,COALESCE(m.pinned_product_id,0) pinned_product_id,COALESCE(m.react_count,0) react_count,(CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=l.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=l.user_id),0)) level FROM myshop_live_presence l JOIN myshop_auth_users_v108 u ON u.user_id=l.user_id LEFT JOIN myshop_live_room_meta m ON m.host_id=l.user_id WHERE l.active=1 AND u.active=1 ${extra} ORDER BY ${order} LIMIT ?`).bind(...binds,limit).all()).results||[];
  let topSupporters=[];if(category==='TOP_SUPPORTERS')topSupporters=(await env.DB.prepare(`SELECT e.sender_id user_id,u.full_name,u.avatar_url,SUM(e.price) total_value,COUNT(*) gift_count FROM myshop_live_gift_events e LEFT JOIN myshop_auth_users_v108 u ON u.user_id=e.sender_id WHERE e.status='COMPLETED' GROUP BY e.sender_id ORDER BY total_value DESC LIMIT ?`).bind(limit).all()).results||[];
  return json({ok:true,category,rooms:rows.map(x=>({userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',viewerCount:Number(x.viewer_count||0),level:Number(x.level||0),title:x.title||'Live',topic:x.topic||'',shopLive:Number(x.pinned_product_id||0)>0,reactCount:Number(x.react_count||0)})),topSupporters:topSupporters.map((x,i)=>({...x,rank:i+1}))},200,cors);
}
async function liveScheduleList(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const hostId=String(new URL(request.url).searchParams.get('hostId')||me.user_id).trim();if(!isFourDigit(hostId))return json({error:'INVALID_HOST_ID'},400,cors);
  const rows=(await env.DB.prepare(`SELECT s.id,s.host_id,s.title,s.topic,s.scheduled_at,s.status,s.created_at,CASE WHEN EXISTS(SELECT 1 FROM myshop_live_reminders r WHERE r.schedule_id=s.id AND r.user_id=?) THEN 1 ELSE 0 END reminded,(SELECT COUNT(*) FROM myshop_live_reminders r WHERE r.schedule_id=s.id) reminder_count FROM myshop_live_schedules s WHERE s.host_id=? AND s.status IN ('SCHEDULED','LIVE') ORDER BY datetime(s.scheduled_at) ASC LIMIT 50`).bind(me.user_id,hostId).all()).results||[];return json({ok:true,schedules:rows},200,cors);
}
async function liveScheduleSave(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),title=String(b.title||'Scheduled Live').trim().slice(0,80),topic=String(b.topic||'').trim().slice(0,120),at=String(b.scheduledAt||'').trim();if(!at||!Number.isFinite(Date.parse(at.replace(' ','T'))))return json({error:'INVALID_SCHEDULE_TIME'},400,cors);if(Date.parse(at.replace(' ','T'))<Date.now()-60000)return json({error:'SCHEDULE_IN_PAST'},400,cors);const id=Math.max(0,Math.floor(Number(b.id||0)));
  if(id){const own=await env.DB.prepare(`SELECT id FROM myshop_live_schedules WHERE id=? AND host_id=? AND status='SCHEDULED'`).bind(id,me.user_id).first();if(!own)return json({error:'SCHEDULE_NOT_EDITABLE'},404,cors);await env.DB.prepare(`UPDATE myshop_live_schedules SET title=?,topic=?,scheduled_at=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(title,topic,at,id).run();return json({ok:true,id},200,cors);}
  const r=await env.DB.prepare(`INSERT INTO myshop_live_schedules(host_id,title,topic,scheduled_at,status) VALUES(?,?,?,?,'SCHEDULED')`).bind(me.user_id,title,topic,at).run();return json({ok:true,id:r.meta?.last_row_id||0},201,cors);
}
async function liveScheduleCancel(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),id=Math.max(0,Math.floor(Number(b.id||0)));const r=await env.DB.prepare(`UPDATE myshop_live_schedules SET status='CANCELLED',updated_at=CURRENT_TIMESTAMP WHERE id=? AND host_id=? AND status='SCHEDULED'`).bind(id,me.user_id).run();if(Number(r?.meta?.changes||0)<1)return json({error:'SCHEDULE_NOT_FOUND'},404,cors);return json({ok:true},200,cors);
}
async function liveScheduleReminder(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),id=Math.max(0,Math.floor(Number(b.scheduleId||0)));const s=await env.DB.prepare(`SELECT host_id,status FROM myshop_live_schedules WHERE id=?`).bind(id).first();if(!s||String(s.status)!=='SCHEDULED')return json({error:'SCHEDULE_NOT_FOUND'},404,cors);const old=await env.DB.prepare(`SELECT 1 x FROM myshop_live_reminders WHERE schedule_id=? AND user_id=?`).bind(id,me.user_id).first();if(old){await env.DB.prepare(`DELETE FROM myshop_live_reminders WHERE schedule_id=? AND user_id=?`).bind(id,me.user_id).run();return json({ok:true,reminded:false},200,cors);}await env.DB.prepare(`INSERT OR IGNORE INTO myshop_live_reminders(schedule_id,user_id) VALUES(?,?)`).bind(id,me.user_id).run();return json({ok:true,reminded:true},200,cors);
}
async function livePkStart(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),peer=String(b.hostId||'').trim();if(!isFourDigit(peer)||peer===me.user_id)return json({error:'INVALID_PK_HOST'},400,cors);const a=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(me.user_id).first(),z=await env.DB.prepare(`SELECT active FROM myshop_live_presence WHERE user_id=?`).bind(peer).first();if(Number(a?.active||0)!==1||Number(z?.active||0)!==1)return json({error:'BOTH_HOSTS_MUST_BE_LIVE'},409,cors);const ma=await env.DB.prepare(`SELECT session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(me.user_id).first(),mb=await env.DB.prepare(`SELECT session_id FROM myshop_live_room_meta WHERE host_id=?`).bind(peer).first();const open=await env.DB.prepare(`SELECT id FROM myshop_live_pk_rounds WHERE status IN ('PENDING','ACTIVE') AND (host_a=? OR host_b=?) LIMIT 1`).bind(me.user_id,me.user_id).first();if(open)return json({error:'PK_ALREADY_OPEN'},409,cors);const r=await env.DB.prepare(`INSERT INTO myshop_live_pk_rounds(host_a,host_b,session_a,session_b,status) VALUES(?,?,?,?,'PENDING')`).bind(me.user_id,peer,String(ma?.session_id||''),String(mb?.session_id||'')).run();try{await createUserNotification(env,peer,'Live PK Invitation',(me.full_name||'Host')+' invited you to a friendly Live PK.','LIVE_PK_INVITE',me.user_id,me.user_id);}catch(e){}return json({ok:true,id:r.meta?.last_row_id||0,status:'PENDING'},201,cors);
}
async function livePkAction(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);await ensureLiveRoomSchema(env);const b=await body(request),id=Math.max(0,Math.floor(Number(b.id||0))),action=String(b.action||'').toUpperCase();const r=await env.DB.prepare(`SELECT * FROM myshop_live_pk_rounds WHERE id=?`).bind(id).first();if(!r)return json({error:'PK_NOT_FOUND'},404,cors);
  if(action==='ACCEPT'&&String(r.host_b)===me.user_id&&String(r.status)==='PENDING'){await env.DB.prepare(`UPDATE myshop_live_pk_rounds SET status='ACTIVE',started_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(id).run();return json({ok:true,status:'ACTIVE'},200,cors);}if(action==='DECLINE'&&String(r.host_b)===me.user_id&&String(r.status)==='PENDING'){await env.DB.prepare(`UPDATE myshop_live_pk_rounds SET status='DECLINED',ended_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(id).run();return json({ok:true,status:'DECLINED'},200,cors);}if(action==='END'&&(String(r.host_a)===me.user_id||String(r.host_b)===me.user_id)&&String(r.status)==='ACTIVE'){await env.DB.prepare(`UPDATE myshop_live_pk_rounds SET status='ENDED',ended_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(id).run();return json({ok:true,status:'ENDED'},200,cors);}return json({error:'PK_ACTION_NOT_ALLOWED'},403,cors);
}

async function liveProfiles(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_live_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,viewer_count INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_app_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`UPDATE myshop_app_presence SET active=0 WHERE active=1 AND datetime(last_seen)<datetime('now','-90 seconds')`).run();
  const limit=Math.max(1,Math.min(100,Number(new URL(request.url).searchParams.get('limit')||4)));
  await env.DB.prepare(`UPDATE myshop_live_presence SET active=0 WHERE active=1 AND datetime(last_seen)<datetime('now','-2 minutes')`).run();
  const liveRows=(await env.DB.prepare(`SELECT l.user_id,l.viewer_count,l.last_seen,u.full_name,u.avatar_url,(CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=l.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=l.user_id),0)) AS level,CASE WHEN EXISTS(SELECT 1 FROM myshop_app_presence ap WHERE ap.user_id=l.user_id AND ap.active=1 AND datetime(ap.last_seen)>=datetime('now','-90 seconds')) THEN 1 ELSE 0 END AS online FROM myshop_live_presence l JOIN myshop_auth_users_v108 u ON u.user_id=l.user_id WHERE l.active=1 AND u.active=1 ORDER BY datetime(l.last_seen) DESC LIMIT ?`).bind(limit).all()).results||[];
  const profiles=liveRows.map(x=>({userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',viewerCount:Number(x.viewer_count||0),lastSeen:x.last_seen,live:true,level:Math.max(0,Number(x.level||0)),online:Number(x.online||0)===1}));
  if(profiles.length<limit){
    const need=limit-profiles.length;
    const recent=(await env.DB.prepare(`SELECT a.user_id,a.full_name,a.avatar_url,a.created_at,
      (CAST(COALESCE((SELECT SUM(CASE WHEN t.amount>0 AND t.status='COMPLETED' AND t.kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') THEN t.amount ELSE 0 END) FROM myshop_coin_transactions t WHERE t.user_id=a.user_id),0)/100000 AS INTEGER)+COALESCE((SELECT up.level FROM myshop_user_progress up WHERE up.user_id=a.user_id),0)) AS level,
      CASE WHEN EXISTS(SELECT 1 FROM myshop_app_presence ap WHERE ap.user_id=a.user_id AND ap.active=1 AND datetime(ap.last_seen)>=datetime('now','-90 seconds')) THEN 1 ELSE 0 END AS online,
      CASE WHEN EXISTS(SELECT 1 FROM myshop_friend_requests f WHERE f.sender_id=? AND f.receiver_id=a.user_id AND f.status='PENDING') THEN 'REQUESTED'
           WHEN EXISTS(SELECT 1 FROM myshop_friend_requests f WHERE f.sender_id=a.user_id AND f.receiver_id=? AND f.status='PENDING') THEN 'INCOMING'
           WHEN EXISTS(SELECT 1 FROM myshop_friend_requests f WHERE f.status='ACCEPTED' AND ((f.sender_id=? AND f.receiver_id=a.user_id) OR (f.sender_id=a.user_id AND f.receiver_id=?))) THEN 'FRIEND'
           ELSE 'NONE' END AS relation_state
      FROM myshop_auth_users_v108 a WHERE a.active=1 AND a.user_id<>? AND NOT EXISTS(SELECT 1 FROM myshop_live_presence l WHERE l.user_id=a.user_id AND l.active=1) ORDER BY datetime(a.created_at) DESC,a.user_id DESC LIMIT ?`).bind(user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,need).all()).results||[];
    for(const x of recent)profiles.push({userId:x.user_id,name:x.full_name||'New Member',avatarUrl:x.avatar_url||'',viewerCount:0,lastSeen:'',joinedAt:x.created_at||'',live:false,state:x.relation_state||'NONE',level:Math.max(0,Number(x.level||0)),online:Number(x.online||0)===1});
  }
  return json({ok:true,profiles,liveCount:liveRows.length,fillMode:liveRows.length>=limit?'LIVE_ONLY':(liveRows.length>0?'LIVE_THEN_NEW':'NEWEST_USERS')},200,cors);
}
async function getProfilePrivacy(env,userId){
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_profile_privacy (user_id TEXT PRIMARY KEY,posts_visibility TEXT NOT NULL DEFAULT 'PUBLIC',media_visibility TEXT NOT NULL DEFAULT 'PUBLIC',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await env.DB.prepare(`INSERT OR IGNORE INTO myshop_profile_privacy(user_id) VALUES(?)`).bind(userId).run();
  return await env.DB.prepare(`SELECT posts_visibility,media_visibility FROM myshop_profile_privacy WHERE user_id=?`).bind(userId).first();
}
async function myPrivacy(request,env){const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);return json({ok:true,privacy:await getProfilePrivacy(env,user.user_id)},200,cors);}
async function updateMyPrivacy(request,env){
  const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);const b=await body(request);const allowed=['PUBLIC','FRIENDS','PRIVATE'];const posts=String(b.postsVisibility||'PUBLIC').toUpperCase(),media=String(b.mediaVisibility||'PUBLIC').toUpperCase();if(!allowed.includes(posts)||!allowed.includes(media))return json({error:'INVALID_VISIBILITY'},400,cors);
  await getProfilePrivacy(env,user.user_id);await env.DB.prepare(`UPDATE myshop_profile_privacy SET posts_visibility=?,media_visibility=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(posts,media,user.user_id).run();return json({ok:true,privacy:{posts_visibility:posts,media_visibility:media}},200,cors);
}
async function canViewProfileContent(env,viewer,target,kind){if(viewer===target)return true;const p=await getProfilePrivacy(env,target),v=String(kind==='media'?p?.media_visibility:p?.posts_visibility||'PUBLIC').toUpperCase();if(v==='PUBLIC')return true;if(v==='PRIVATE')return false;const f=await env.DB.prepare(`SELECT 1 ok FROM myshop_friend_requests WHERE status='ACCEPTED' AND ((sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)) LIMIT 1`).bind(viewer,target,target,viewer).first();return !!f;}
async function userPosts(request,env){
  await ensureFriendSchema(env);const user=await getUser(request,env);if(!user)return json({error:'UNAUTHORIZED'},401,cors);const u=new URL(request.url),target=String(u.searchParams.get('userId')||'').trim(),media=String(u.searchParams.get('media')||'all').toLowerCase();if(!isFourDigit(target))return json({error:'INVALID_USER_ID'},400,cors);const kind=media==='all'?'posts':'media';if(!(await canViewProfileContent(env,user.user_id,target,kind)))return json({ok:true,visible:false,posts:[]},200,cors);
  let where=`p.user_id=? AND p.status='ACTIVE'`,binds=[target];if(media==='media')where+=` AND p.media_type IN ('image','video')`;else if(media==='photo')where+=` AND p.media_type='image'`;else if(media==='video')where+=` AND p.media_type='video'`;else if(media==='reels')where+=` AND p.media_type IN ('reel','short','video')`;
  const rows=(await env.DB.prepare(`SELECT p.id,p.caption,p.media_url,p.media_type,p.created_at,(SELECT COUNT(*) FROM myshop_post_likes l WHERE l.post_id=p.id AND datetime(l.created_at)>=datetime('now','-24 hours')) like_count,(SELECT COUNT(*) FROM myshop_post_comments c WHERE c.post_id=p.id) comment_count FROM myshop_posts p WHERE ${where} ORDER BY p.id DESC LIMIT 100`).bind(...binds).all()).results||[];return json({ok:true,visible:true,posts:rows.map(x=>({id:x.id,caption:x.caption||'',mediaUrl:x.media_url||'',mediaType:x.media_type||'text',createdAt:x.created_at,likeCount:Number(x.like_count||0),commentCount:Number(x.comment_count||0)}))},200,cors);
}


async function safetyIsBlocked(env,a,b){
  if(!isFourDigit(a)||!isFourDigit(b))return false;
  try{await ensureFriendSchema(env);const row=await env.DB.prepare(`SELECT 1 ok FROM myshop_user_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1`).bind(a,b,b,a).first();return !!row;}catch(_){return false;}
}

async function safetyBlock(request,env){
  await ensureFriendSchema(env);const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);const b=await body(request),target=String(b.userId||'').trim(),blocked=b.blocked!==false;
  if(!isFourDigit(target)||target===me.user_id)return json({error:'INVALID_USER_ID'},400,cors);const u=await env.DB.prepare(`SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1`).bind(target).first();if(!u)return json({error:'USER_NOT_FOUND'},404,cors);
  if(blocked){
    await env.DB.prepare(`INSERT OR IGNORE INTO myshop_user_blocks(blocker_id,blocked_id) VALUES(?,?)`).bind(me.user_id,target).run();
    await env.DB.prepare(`DELETE FROM myshop_friend_requests WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)`).bind(me.user_id,target,target,me.user_id).run();
    await env.DB.prepare(`DELETE FROM myshop_follows WHERE (follower_id=? AND following_id=?) OR (follower_id=? AND following_id=?)`).bind(me.user_id,target,target,me.user_id).run();
  }else await env.DB.prepare(`DELETE FROM myshop_user_blocks WHERE blocker_id=? AND blocked_id=?`).bind(me.user_id,target).run();
  return json({ok:true,userId:target,blocked},200,cors);
}

async function safetyBlocks(request,env){
  await ensureFriendSchema(env);const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);
  const rows=(await env.DB.prepare(`SELECT b.blocked_id user_id,u.full_name,u.avatar_url,b.created_at FROM myshop_user_blocks b LEFT JOIN myshop_auth_users_v108 u ON u.user_id=b.blocked_id WHERE b.blocker_id=? ORDER BY datetime(b.created_at) DESC`).bind(me.user_id).all()).results||[];
  return json({ok:true,blocks:rows.map(x=>({userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',createdAt:x.created_at||''}))},200,cors);
}

async function safetyReport(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);const b=await body(request);
  const target=String(b.targetUserId||'').trim(),type=String(b.contentType||'USER').trim().toUpperCase().replace(/[^A-Z0-9_]/g,'').slice(0,40),contentId=String(b.contentId||'').trim().slice(0,80),reason=String(b.reason||'OTHER').trim().toUpperCase().replace(/[^A-Z0-9_]/g,'').slice(0,40),details=String(b.details||'').trim().slice(0,800);
  if(target&&(!isFourDigit(target)||target===me.user_id))return json({error:'INVALID_REPORT_TARGET'},400,cors);if(!type||!reason)return json({error:'INVALID_REPORT'},400,cors);
  const r=await env.DB.prepare(`INSERT INTO myshop_safety_reports(reporter_id,target_user_id,content_type,content_id,reason,details) VALUES(?,?,?,?,?,?)`).bind(me.user_id,target,type,contentId,reason,details).run();
  return json({ok:true,reportId:r.meta?.last_row_id||0,status:'OPEN'},201,cors);
}

function legalShell(title,bodyHtml){return new Response(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title} • MY SHOP</title><style>body{font-family:system-ui,-apple-system,sans-serif;background:#f7f8fc;color:#18213c;margin:0}.wrap{max-width:760px;margin:auto;padding:28px 18px 60px}.card{background:white;border:1px solid #e3e6f0;border-radius:18px;padding:22px;box-shadow:0 8px 24px #1d2b5012}h1{color:#293fba}a{color:#4939d7}input,textarea{width:100%;box-sizing:border-box;padding:12px;margin:7px 0;border:1px solid #cfd4e5;border-radius:10px}button{background:#4939d7;color:white;border:0;border-radius:10px;padding:12px 18px;font-weight:700}.muted{color:#66708d;font-size:.92rem}</style></head><body><div class="wrap"><div class="card">${bodyHtml}</div></div></body></html>`,{status:200,headers:{...cors,'content-type':'text/html; charset=utf-8','cache-control':'public, max-age=300'}});}

function privacyPage(){return legalShell('Privacy Policy',`<h1>MY SHOP Privacy Policy</h1><p>MY SHOP may process account details, profile information, posts and media, private messages, Live-room participation, purchase and entitlement records, and limited technical data needed to operate and secure the service.</p><p>Microphone access is requested only for Audio Live features that need it. MY SHOP does not require location access for its core service.</p><p>Users can report or block other users. Reports may be retained for safety and moderation.</p><h2>Account deletion</h2><p>Users can delete their account from <b>Settings &amp; Privacy → Delete My Account</b>, or use the web deletion request page. Personal profile data, sessions, private messages and user-created content are deleted or anonymized as part of the deletion process. A non-public immutable MY SHOP ID and minimal security, fraud-prevention, transaction, payout or legally required records may be retained where necessary and are not reassigned to another person.</p><h2>Privacy contact</h2><p>For privacy or account-data requests, use the in-app <b>Settings &amp; Privacy</b> support/deletion controls or the account-deletion request page linked by MY SHOP. The verified account owner contact used for Google Play publication must also be maintained in the Play Console and public app listing.</p>`);}
function termsPage(){return legalShell('Terms & Conditions',`<h1>MY SHOP Terms &amp; Conditions</h1><p>Use MY SHOP respectfully and lawfully. Do not impersonate others, abuse Live or messaging features, post prohibited content, harass users, manipulate payments, or interfere with the service.</p><p>Digital products sold in the Google Play build use Google Play Billing. Admin grants are owner-controlled entitlements and do not replace Play checkout for user-paid digital purchases.</p><p>MY SHOP may moderate reported content or accounts when needed for safety, integrity or legal compliance.</p>`);}
function accountDeletionPage(){return legalShell('Delete Account',`<h1>Delete your MY SHOP account</h1><p>The fastest verified method is inside the app: <b>Settings &amp; Privacy → Delete My Account</b>. You will confirm your password before deletion.</p><p>If you cannot sign in, submit a deletion request below. The request does not bypass identity verification; support must verify ownership before deleting the account.</p><form id="f"><input id="identifier" placeholder="MY SHOP ID / registered email or mobile" required><input id="contact" placeholder="Contact email or mobile for verification" required><textarea id="reason" placeholder="Optional reason"></textarea><button>Submit deletion request</button></form><p id="out" class="muted"></p><script>document.getElementById('f').onsubmit=async(e)=>{e.preventDefault();const out=document.getElementById('out');out.textContent='Submitting…';try{const r=await fetch('/v1/account/deletion-request',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({identifier:identifier.value,contact:contact.value,reason:reason.value})});const j=await r.json();out.textContent=r.ok?'Request received. Keep the request number: '+j.requestId:'Could not submit: '+(j.error||r.status);}catch(x){out.textContent='Network error. Please try again.';}};</script>`);}

async function accountDeletionRequest(request,env){
  const b=await body(request),identifier=String(b.identifier||'').trim().slice(0,160),contact=String(b.contact||'').trim().slice(0,160),reason=String(b.reason||'').trim().slice(0,600);if(identifier.length<2||contact.length<3)return json({error:'INVALID_DELETE_REQUEST'},400,cors);
  let uid='';try{const u=await findAuthUser(env,identifier);uid=u?.user_id||'';}catch(_){}
  const r=await env.DB.prepare(`INSERT INTO myshop_account_deletion_requests(user_id,identifier,contact,reason) VALUES(?,?,?,?)`).bind(uid,identifier,contact,reason).run();return json({ok:true,requestId:r.meta?.last_row_id||0,status:'OPEN'},201,cors);
}

async function dbRunQuiet(env,sql,...binds){try{return await env.DB.prepare(sql).bind(...binds).run();}catch(e){console.error('DELETE_CLEANUP_WARN',String(e?.message||e),sql.slice(0,80));return null;}}
async function accountDelete(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);const b=await body(request),password=String(b.password||'');if(!password||!(await verifyPassword(password,me.password_hash)))return json({error:'INVALID_DELETE_PASSWORD'},403,cors);const uid=me.user_id;
  // Delete user-owned R2 media first where keys are known. Failures do not reactivate the account.
  if(env.MEDIA){try{for(const k of [me.avatar_object_key,me.cover_object_key].filter(Boolean))await env.MEDIA.delete(k);}catch(_){}try{const pr=(await env.DB.prepare(`SELECT object_key FROM myshop_posts WHERE user_id=? AND object_key<>''`).bind(uid).all()).results||[];for(const x of pr)try{await env.MEDIA.delete(String(x.object_key||''));}catch(_){} }catch(_){}try{const gr=(await env.DB.prepare(`SELECT object_key FROM gallery_media WHERE owner_user_id=? AND object_key<>''`).bind(uid).all()).results||[];for(const x of gr)try{await env.MEDIA.delete(String(x.object_key||''));}catch(_){} }catch(_){} }
  await dbRunQuiet(env,`DELETE FROM myshop_auth_sessions_v108 WHERE user_id=?`,uid);
  await dbRunQuiet(env,`DELETE FROM myshop_post_likes WHERE user_id=? OR post_id IN (SELECT id FROM myshop_posts WHERE user_id=?)`,uid,uid);
  await dbRunQuiet(env,`DELETE FROM myshop_post_comments WHERE user_id=? OR post_id IN (SELECT id FROM myshop_posts WHERE user_id=?)`,uid,uid);
  await dbRunQuiet(env,`DELETE FROM myshop_posts WHERE user_id=?`,uid);
  await dbRunQuiet(env,`DELETE FROM gallery_media WHERE owner_user_id=?`,uid);
  await dbRunQuiet(env,`DELETE FROM myshop_messages WHERE sender_id=? OR receiver_id=?`,uid,uid);
  await dbRunQuiet(env,`DELETE FROM myshop_friend_requests WHERE sender_id=? OR receiver_id=?`,uid,uid);
  await dbRunQuiet(env,`DELETE FROM myshop_follows WHERE follower_id=? OR following_id=?`,uid,uid);
  await dbRunQuiet(env,`DELETE FROM myshop_user_blocks WHERE blocker_id=? OR blocked_id=?`,uid,uid);
  await dbRunQuiet(env,`DELETE FROM myshop_profile_privacy WHERE user_id=?`,uid);
  await dbRunQuiet(env,`DELETE FROM myshop_app_presence WHERE user_id=?`,uid);
  await dbRunQuiet(env,`DELETE FROM myshop_live_presence WHERE user_id=?`,uid);
  await dbRunQuiet(env,`DELETE FROM myshop_live_viewers WHERE user_id=?`,uid);
  await dbRunQuiet(env,`DELETE FROM myshop_live_requests WHERE user_id=? OR host_id=?`,uid,uid);
  await dbRunQuiet(env,`DELETE FROM myshop_live_invites WHERE user_id=? OR host_id=?`,uid,uid);
  await dbRunQuiet(env,`DELETE FROM myshop_live_seats WHERE user_id=? OR host_id=?`,uid,uid);
  await dbRunQuiet(env,`DELETE FROM notification_reads WHERE user_id=?`,uid);
  await dbRunQuiet(env,`DELETE FROM notifications WHERE user_id=? OR actor_user_id=?`,uid,uid);
  await dbRunQuiet(env,`UPDATE myshop_safety_reports SET reporter_id=CASE WHEN reporter_id=? THEN '' ELSE reporter_id END,target_user_id=CASE WHEN target_user_id=? THEN '' ELSE target_user_id END,updated_at=CURRENT_TIMESTAMP WHERE reporter_id=? OR target_user_id=?`,uid,uid,uid,uid);
  await dbRunQuiet(env,`UPDATE myshop_account_deletion_requests SET identifier='',contact='',reason='',status='COMPLETED',updated_at=CURRENT_TIMESTAMP WHERE user_id=?`,uid);
  // Transaction/payout records may need minimal retention for accounting/security. Permanent ID is never reassigned.
  const tomb='deleted$'+randomHex(24);
  await env.DB.prepare(`UPDATE myshop_auth_users_v108 SET full_name='Deleted User',email=NULL,mobile=NULL,password_hash=?,security_q1='',security_a1_hash='',security_q2='',security_a2_hash='',security_q3='',security_a3_hash='',role='USER',active=0,avatar_url='',avatar_object_key='',cover_url='',cover_object_key='',bio='',gender='UNSPECIFIED',updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(tomb,uid).run();
  return json({ok:true,deleted:true,userIdRetainedForSecurity:true},200,cors);
}

function b64urlBytes(bytes){let s='';for(const b of new Uint8Array(bytes))s+=String.fromCharCode(b);return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function b64urlText(x){return b64urlBytes(new TextEncoder().encode(x));}
function pemPkcs8(pem){const b64=String(pem||'').replace(/-----BEGIN PRIVATE KEY-----/g,'').replace(/-----END PRIVATE KEY-----/g,'').replace(/\s+/g,'');const raw=atob(b64);const out=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)out[i]=raw.charCodeAt(i);return out.buffer;}
async function googlePublisherAccessToken(env){
  if(!env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON)throw new Error('PLAY_SERVICE_ACCOUNT_MISSING');const sa=JSON.parse(env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON);if(!sa.client_email||!sa.private_key)throw new Error('PLAY_SERVICE_ACCOUNT_INVALID');const now=Math.floor(Date.now()/1000);
  const unsigned=b64urlText(JSON.stringify({alg:'RS256',typ:'JWT'}))+'.'+b64urlText(JSON.stringify({iss:sa.client_email,scope:'https://www.googleapis.com/auth/androidpublisher',aud:'https://oauth2.googleapis.com/token',iat:now,exp:now+3600}));
  const key=await crypto.subtle.importKey('pkcs8',pemPkcs8(sa.private_key),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['sign']);const sig=await crypto.subtle.sign('RSASSA-PKCS1-v1_5',key,new TextEncoder().encode(unsigned));const assertion=unsigned+'.'+b64urlBytes(sig);
  const form=new URLSearchParams({grant_type:'urn:ietf:params:oauth:grant-type:jwt-bearer',assertion});const r=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:form.toString()});const j=await r.json();if(!r.ok||!j.access_token)throw new Error('PLAY_OAUTH_FAILED:'+String(j.error_description||j.error||r.status));return j.access_token;
}
async function playBillingReady(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);const u=new URL(request.url),catalogId=Math.floor(Number(u.searchParams.get('catalogId')||0)),productId=String(u.searchParams.get('productId')||'').trim().toLowerCase();const row=await env.DB.prepare(`SELECT id,play_product_id,enabled,price_minor FROM myshop_store_catalog WHERE id=?`).bind(catalogId).first();if(!row||Number(row.enabled)!==1)return json({error:'CATALOG_NOT_FOUND'},404,cors);if(!productId||productId!==String(row.play_product_id||''))return json({error:'PLAY_PRODUCT_MISMATCH'},409,cors);if(!env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON)return json({error:'PLAY_BILLING_NOT_CONFIGURED',message:'Worker secret GOOGLE_PLAY_SERVICE_ACCOUNT_JSON is missing.'},503,cors);return json({ok:true,catalogId,productId},200,cors);
}
async function playGrantAtomic(env,uid,item,productId,tokenHash,orderId,payload){
  const type=String(item.item_type||'').toUpperCase(),code=String(item.code||'').toUpperCase(),units=Math.max(1,Number(item.units||1)),days=Math.max(0,Number(item.duration_days||0)),exp=days>0?new Date(Date.now()+days*86400000).toISOString():null;
  const purchase=env.DB.prepare(`INSERT INTO myshop_play_purchases(user_id,catalog_id,play_product_id,purchase_token_hash,order_id,status,google_payload) VALUES(?,?,?,?,?,'VERIFIED',?)`).bind(uid,item.id,productId,tokenHash,orderId,payload);
  let q=[];
  if(type==='COIN') q=[env.DB.prepare('INSERT OR IGNORE INTO myshop_coin_wallets(user_id,balance) VALUES(?,0)').bind(uid),env.DB.prepare('UPDATE myshop_coin_wallets SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(units,uid),env.DB.prepare("INSERT INTO myshop_coin_transactions(user_id,kind,amount,reference,status,metadata) VALUES(?,'STORE_GRANT',?,'GOOGLE_PLAY','COMPLETED',?)").bind(uid,units,JSON.stringify({catalogId:item.id,source:'GOOGLE_PLAY',orderId})),purchase];
  else if(type==='GOLD') q=[env.DB.prepare('INSERT OR IGNORE INTO myshop_gold_wallets(user_id,balance) VALUES(?,0)').bind(uid),env.DB.prepare('UPDATE myshop_gold_wallets SET balance=balance+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').bind(units,uid),env.DB.prepare("INSERT INTO myshop_gold_transactions(user_id,kind,amount,reference,metadata) VALUES(?,'STORE_GRANT',?,'GOOGLE_PLAY',?)").bind(uid,units,JSON.stringify({catalogId:item.id,source:'GOOGLE_PLAY',orderId})),purchase];
  else if(['FRAME','AVATAR_FRAME','THEME','LIVE_THEME','WALLPAPER','GIFT'].includes(type)) q=[env.DB.prepare(`INSERT INTO myshop_owned_items(user_id,catalog_id,item_type,item_code,equipped,expires_at,source) VALUES(?,?,?,?,0,?,'GOOGLE_PLAY') ON CONFLICT(user_id,catalog_id) DO UPDATE SET expires_at=excluded.expires_at,source=excluded.source`).bind(uid,item.id,type,code,exp),purchase];
  else q=[env.DB.prepare('UPDATE myshop_user_badges SET is_displayed=0 WHERE user_id=?').bind(uid),env.DB.prepare("INSERT INTO myshop_user_badges(user_id,badge_code,status,source,expires_at,note,catalog_id,is_displayed) VALUES(?,?,'ACTIVE','GOOGLE_PLAY',?,'Verified Google Play purchase',?,1)").bind(uid,code,exp,item.id),purchase];
  await env.DB.batch(q);
}
async function playPurchaseVerify(request,env){
  const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);const b=await body(request),catalogId=Math.max(0,Math.floor(Number(b.catalogId||0))),productId=String(b.productId||'').trim().toLowerCase(),token=String(b.purchaseToken||'').trim();if(!productId||token.length<20)return json({error:'INVALID_PLAY_PURCHASE'},400,cors);
  const item=catalogId>0?await env.DB.prepare(`SELECT * FROM myshop_store_catalog WHERE id=? AND enabled=1`).bind(catalogId).first():await env.DB.prepare(`SELECT * FROM myshop_store_catalog WHERE play_product_id=? AND enabled=1`).bind(productId).first();if(!item)return json({error:'CATALOG_NOT_FOUND'},404,cors);if(String(item.play_product_id||'')!==productId)return json({error:'PLAY_PRODUCT_MISMATCH'},409,cors);
  const th=await sha256(token);let prior=await env.DB.prepare(`SELECT user_id,catalog_id,status FROM myshop_play_purchases WHERE purchase_token_hash=?`).bind(th).first();if(prior){if(prior.user_id!==me.user_id)return json({error:'PLAY_TOKEN_ALREADY_USED'},409,cors);return json({ok:true,verified:String(prior.status)==='VERIFIED',alreadyProcessed:true,catalogId:Number(prior.catalog_id)},200,cors);}
  let access;try{access=await googlePublisherAccessToken(env);}catch(e){return json({error:'PLAY_BILLING_NOT_CONFIGURED',message:String(e?.message||e).slice(0,220)},503,cors);}const pkg=String(env.GOOGLE_PLAY_PACKAGE_NAME||'com.myshop.app').trim();const endpoint=`https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${encodeURIComponent(pkg)}/purchases/productsv2/tokens/${encodeURIComponent(token)}`;const gr=await fetch(endpoint,{headers:{authorization:'Bearer '+access}});const gj=await gr.json();if(!gr.ok)return json({error:'PLAY_VERIFICATION_FAILED',message:String(gj?.error?.message||gr.status).slice(0,220)},409,cors);
  const state=String(gj?.purchaseStateContext?.purchaseState||'');const lines=Array.isArray(gj?.productLineItem)?gj.productLineItem:[];if(state!=='PURCHASED')return json({error:'PURCHASE_NOT_COMPLETED',purchaseState:state},409,cors);if(!lines.some(x=>String(x?.productId||'')===productId))return json({error:'PLAY_PRODUCT_MISMATCH'},409,cors);
  const orderId=String(gj?.orderId||'').slice(0,160),payload=JSON.stringify(gj).slice(0,12000);try{await playGrantAtomic(env,me.user_id,item,productId,th,orderId,payload);}catch(e){prior=await env.DB.prepare(`SELECT user_id,catalog_id,status FROM myshop_play_purchases WHERE purchase_token_hash=?`).bind(th).first();if(prior&&prior.user_id===me.user_id&&String(prior.status)==='VERIFIED')return json({ok:true,verified:true,alreadyProcessed:true,catalogId:Number(prior.catalog_id)},200,cors);console.error('PLAY_ATOMIC_GRANT_FAILED',String(e?.message||e));return json({error:'PLAY_GRANT_FAILED',message:'Verified purchase could not be activated. Please retry; the entitlement was not partially applied.'},503,cors);}return json({ok:true,verified:true,catalogId:item.id,productId},200,cors);
}

async function messageInbox(request,env){
  await ensureMessageSchema(env);
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const rows=(await env.DB.prepare(`SELECT u.user_id,u.full_name,u.avatar_url,
    (SELECT m.message FROM myshop_messages m WHERE (((m.sender_id=? AND m.receiver_id=u.user_id) AND COALESCE(m.hidden_from_sender,0)=0) OR ((m.sender_id=u.user_id AND m.receiver_id=?) AND COALESCE(m.hidden_from_receiver,0)=0)) ORDER BY m.id DESC LIMIT 1) last_message,
    (SELECT m.created_at FROM myshop_messages m WHERE (((m.sender_id=? AND m.receiver_id=u.user_id) AND COALESCE(m.hidden_from_sender,0)=0) OR ((m.sender_id=u.user_id AND m.receiver_id=?) AND COALESCE(m.hidden_from_receiver,0)=0)) ORDER BY m.id DESC LIMIT 1) last_at,
    (SELECT COUNT(*) FROM myshop_messages m WHERE m.sender_id=u.user_id AND m.receiver_id=? AND m.read_at IS NULL) unread
    FROM myshop_auth_users_v108 u WHERE u.active=1 AND u.user_id<>? AND NOT EXISTS(SELECT 1 FROM myshop_user_blocks b WHERE (b.blocker_id=? AND b.blocked_id=u.user_id) OR (b.blocker_id=u.user_id AND b.blocked_id=?)) AND EXISTS(SELECT 1 FROM myshop_messages mm WHERE (mm.sender_id=? AND mm.receiver_id=u.user_id) OR (mm.sender_id=u.user_id AND mm.receiver_id=?))
    ORDER BY datetime(last_at) DESC LIMIT 100`).bind(user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,user.user_id,user.user_id).all()).results||[];
  const total=rows.reduce((n,x)=>n+Number(x.unread||0),0);
  return json({ok:true,unreadCount:total,conversations:rows.map(x=>({userId:x.user_id,name:x.full_name||'MY SHOP User',avatarUrl:x.avatar_url||'',lastMessage:x.last_message||'',lastAt:x.last_at||'',unread:Number(x.unread||0)}))},200,cors);
}

async function messageThread(request,env){
  await ensureMessageSchema(env);
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors);
  const peer=String(new URL(request.url).searchParams.get('userId')||'').trim(); if(!isFourDigit(peer)||peer===user.user_id)return json({error:'INVALID_USER_ID'},400,cors);
  const p=await env.DB.prepare('SELECT user_id,full_name,avatar_url FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(peer).first(); if(!p)return json({error:'USER_NOT_FOUND'},404,cors);
  if(await safetyIsBlocked(env,user.user_id,peer))return json({error:'BLOCKED_USER'},403,cors);
  await env.DB.prepare('UPDATE myshop_messages SET read_at=CURRENT_TIMESTAMP WHERE sender_id=? AND receiver_id=? AND read_at IS NULL').bind(peer,user.user_id).run();
  try { await ensureNotificationSchema(env); await env.DB.prepare(`INSERT OR IGNORE INTO notification_reads(notification_id,user_id,read_at) SELECT n.id,?,CURRENT_TIMESTAMP FROM notifications n LEFT JOIN notification_reads r ON r.notification_id=n.id AND r.user_id=? WHERE n.audience='USER' AND n.user_id=? AND n.type='MESSAGE' AND n.actor_user_id=? AND r.notification_id IS NULL`).bind(user.user_id,user.user_id,user.user_id,peer).run(); } catch(e) { console.error('MESSAGE_NOTIFICATION_READ_SYNC_FAILED',String(e?.message||e)); }
  const rows=(await env.DB.prepare(`SELECT id,sender_id,receiver_id,message,read_at,created_at FROM myshop_messages WHERE ((sender_id=? AND receiver_id=? AND COALESCE(hidden_from_sender,0)=0) OR (sender_id=? AND receiver_id=? AND COALESCE(hidden_from_receiver,0)=0)) ORDER BY id DESC LIMIT 100`).bind(user.user_id,peer,peer,user.user_id).all()).results||[];
  rows.reverse(); return json({ok:true,peer:{userId:p.user_id,name:p.full_name||'MY SHOP User',avatarUrl:p.avatar_url||''},messages:rows.map(x=>({id:x.id,senderId:x.sender_id,receiverId:x.receiver_id,message:x.message,readAt:x.read_at||'',createdAt:x.created_at}))},200,cors);
}

async function messageSend(request,env,ctx){
  await ensureMessageSchema(env);
  const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors); const b=await body(request); const peer=String(b.userId||'').trim(); const msg=String(b.message||'').trim().slice(0,4000);
  if(!isFourDigit(peer)||peer===user.user_id||!msg)return json({error:'INVALID_MESSAGE'},400,cors);
  const p=await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(peer).first(); if(!p)return json({error:'USER_NOT_FOUND'},404,cors);
  if(await safetyIsBlocked(env,user.user_id,peer))return json({error:'BLOCKED_USER'},403,cors);
  const r=await env.DB.prepare('INSERT INTO myshop_messages(sender_id,receiver_id,message) VALUES(?,?,?)').bind(user.user_id,peer,msg).run();
  await createUserNotification(env,peer,(user.full_name||('User '+user.user_id)),msg.slice(0,160),'MESSAGE',user.user_id,user.user_id,ctx);
  return json({ok:true,id:r.meta?.last_row_id||null},201,cors);
}

async function messageDeleteForMe(request,env){
  await ensureMessageSchema(env);const me=await getUser(request,env);if(!me)return json({error:'UNAUTHORIZED'},401,cors);const b=await body(request),id=Number(b.messageId||0);const m=await env.DB.prepare(`SELECT sender_id,receiver_id FROM myshop_messages WHERE id=?`).bind(id).first();if(!m||![m.sender_id,m.receiver_id].includes(me.user_id))return json({error:'MESSAGE_NOT_FOUND'},404,cors);if(m.sender_id===me.user_id)await env.DB.prepare(`UPDATE myshop_messages SET hidden_from_sender=1 WHERE id=?`).bind(id).run();else await env.DB.prepare(`UPDATE myshop_messages SET hidden_from_receiver=1 WHERE id=?`).bind(id).run();return json({ok:true,hiddenForUser:true,adminArchiveRetained:true},200,cors);
}
async function messageUnread(request,env){
  await ensureMessageSchema(env); const user=await getUser(request,env); if(!user)return json({error:'UNAUTHORIZED'},401,cors); const r=await env.DB.prepare('SELECT COUNT(*) AS c FROM myshop_messages WHERE receiver_id=? AND read_at IS NULL').bind(user.user_id).first(); return json({ok:true,unreadCount:Number(r?.c||0)},200,cors); }

async function mediaGet(request,env,key) {
  if(!env.MEDIA) return new Response('R2 not configured',{status:503,headers:cors});
  const head=await env.MEDIA.head(key); if(!head) return new Response('Not found',{status:404,headers:cors});
  const headers=new Headers(cors); head.writeHttpMetadata(headers); headers.set('etag',head.httpEtag); headers.set('Accept-Ranges','bytes');
  const range=String(request.headers.get('Range')||request.headers.get('range')||'').trim();
  if(range){
    const m=/^bytes=(\d*)-(\d*)$/i.exec(range); if(!m)return new Response('Invalid range',{status:416,headers});
    const size=Number(head.size||0); let start=m[1]?Number(m[1]):NaN,end=m[2]?Number(m[2]):NaN;
    if(Number.isNaN(start)){const suffix=Math.max(1,Number(end||0));start=Math.max(0,size-suffix);end=size-1;}else if(Number.isNaN(end)){end=size-1;}
    start=Math.max(0,start);end=Math.min(size-1,end);if(start>end||start>=size){headers.set('Content-Range',`bytes */${size}`);return new Response(null,{status:416,headers});}
    const length=end-start+1;const object=await env.MEDIA.get(key,{range:{offset:start,length}});if(!object)return new Response('Not found',{status:404,headers});
    headers.set('Content-Range',`bytes ${start}-${end}/${size}`);headers.set('Content-Length',String(length));
    return new Response(object.body,{status:206,headers});
  }
  const object=await env.MEDIA.get(key); if(!object)return new Response('Not found',{status:404,headers});headers.set('Content-Length',String(head.size||0));return new Response(object.body,{status:200,headers});
}

async function adminSafetyReports(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;const u=new URL(request.url),status=String(u.searchParams.get('status')||'OPEN').toUpperCase();const rows=(await env.DB.prepare(`SELECT r.id,r.reporter_id,r.target_user_id,r.content_type,r.content_id,r.reason,r.details,r.status,r.created_at,ru.full_name reporter_name,tu.full_name target_name FROM myshop_safety_reports r LEFT JOIN myshop_auth_users_v108 ru ON ru.user_id=r.reporter_id LEFT JOIN myshop_auth_users_v108 tu ON tu.user_id=r.target_user_id WHERE (?='ALL' OR r.status=?) ORDER BY CASE r.status WHEN 'OPEN' THEN 0 ELSE 1 END,datetime(r.created_at) DESC,r.id DESC LIMIT 200`).bind(status,status).all()).results||[];return json({ok:true,reports:rows},200,cors);
}
async function adminSafetyReportAction(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;const b=await body(request),id=Math.floor(Number(b.id||0)),status=String(b.status||'').toUpperCase();if(!id||!['RESOLVED','DISMISSED','OPEN'].includes(status))return json({error:'INVALID_REPORT_ACTION'},400,cors);const r=await env.DB.prepare(`UPDATE myshop_safety_reports SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(status,id).run();if(!Number(r.meta?.changes||0))return json({error:'REPORT_NOT_FOUND'},404,cors);return json({ok:true,id,status},200,cors);
}
async function adminDeletionRequests(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;const u=new URL(request.url),status=String(u.searchParams.get('status')||'OPEN').toUpperCase();const rows=(await env.DB.prepare(`SELECT id,user_id,identifier,contact,reason,status,created_at,updated_at FROM myshop_account_deletion_requests WHERE (?='ALL' OR status=?) ORDER BY CASE status WHEN 'OPEN' THEN 0 ELSE 1 END,datetime(created_at) DESC,id DESC LIMIT 200`).bind(status,status).all()).results||[];return json({ok:true,requests:rows},200,cors);
}
async function adminDeletionRequestAction(request,env){
  const a=await adminOnly(request,env);if(a.error)return a.error;const b=await body(request),id=Math.floor(Number(b.id||0)),status=String(b.status||'').toUpperCase();if(!id||!['VERIFIED','COMPLETED','DISMISSED','OPEN'].includes(status))return json({error:'INVALID_DELETE_REQUEST_ACTION'},400,cors);const row=await env.DB.prepare(`SELECT id,user_id FROM myshop_account_deletion_requests WHERE id=?`).bind(id).first();if(!row)return json({error:'DELETE_REQUEST_NOT_FOUND'},404,cors);await env.DB.prepare(`UPDATE myshop_account_deletion_requests SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).bind(status,id).run();return json({ok:true,id,userId:row.user_id||'',status,note:status==='VERIFIED'?'Identity verified. Complete deletion through the authenticated in-app Delete My Account flow or owner-controlled deletion process, then mark COMPLETED.':''},200,cors);
}

async function adminPermissions(request,env) {
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const user = auth.user;
  const mods = await env.DB.prepare('SELECT user_id,active FROM myshop_moderators_v108 ORDER BY user_id LIMIT 5').all();
  return json({ok:true,role:user.role,admin:true,moderators:mods.results||[]},200,cors);
}

async function adminAction(request,env) {
  const auth = await adminOnly(request,env); if (auth.error) return auth.error;
  const b = await body(request);
  const uid = String(b.userId||'').trim();
  const action = String(b.action||'').toLowerCase();
  if (!isFourDigit(uid)) return json({error:'INVALID_USER_ID'},400,cors);
  if (action==='add_moderator') {
    const target = await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? AND active=1').bind(uid).first();
    if (!target) return json({error:'USER_NOT_FOUND'},404,cors);
    const count = await env.DB.prepare('SELECT COUNT(*) AS c FROM myshop_moderators_v108 WHERE active=1').first();
    if (Number(count?.c||0)>=5) return json({error:'MODERATOR_LIMIT'},409,cors);
    await env.DB.prepare('INSERT INTO myshop_moderators_v108(user_id) VALUES(?) ON CONFLICT(user_id) DO UPDATE SET active=1').bind(uid).run();
    await env.DB.prepare("UPDATE myshop_auth_users_v108 SET role='MODERATOR' WHERE user_id=? AND user_id NOT IN ('0001','0002','0003')").bind(uid).run();
  } else if (action==='remove_moderator') {
    await env.DB.prepare('UPDATE myshop_moderators_v108 SET active=0 WHERE user_id=?').bind(uid).run();
    await env.DB.prepare("UPDATE myshop_auth_users_v108 SET role=CASE WHEN role='MODERATOR' THEN 'USER' ELSE role END WHERE user_id=?").bind(uid).run();
  } else return json({error:'UNSUPPORTED_ACTION'},400,cors);
  return json({ok:true},200,cors);
}


export class LiveRoomHub {
  constructor(state,env){this.state=state;this.env=env;}
  async resetForSession(sessionId){
    const current=String((await this.state.storage.get('sessionId'))||'');
    if(current===String(sessionId))return false;
    await this.state.storage.deleteAll();
    await this.state.storage.put({sessionId:String(sessionId),stateRevision:0,commentSeq:0,highlightSeq:0,comments:[],highlights:[],gifts:[]});
    return true;
  }
  async bumpState(){
    const revision=Math.max(0,Number((await this.state.storage.get('stateRevision'))||0))+1;
    await this.state.storage.put('stateRevision',revision);return revision;
  }
  async fetch(request){
    const u=new URL(request.url),p=u.pathname;
    if(p==='/register'&&request.method==='POST'){
      const b=await request.json(),sessionId=String(b.sessionId||''),tokenHash=String(b.tokenHash||''),userId=String(b.userId||'');
      if(!sessionId||!tokenHash||!userId)return json({error:'INVALID_REGISTER'},400);
      await this.resetForSession(sessionId);
      const ticketKey='participant:'+tokenHash,previous=await this.state.storage.get(ticketKey),now=Date.now();
      const registeredAt=previous&&String(previous.userId||'')===userId?Math.max(0,Number(previous.registeredAt||now)):now;
      await this.state.storage.put(ticketKey,{userId,registeredAt,expiresAt:Math.max(now+5000,Number(b.expiresAt||0))});
      try{await this.state.storage.setAlarm(Date.now()+2*60*60*1000);}catch(e){}
      return json({ok:true,sessionId},200);
    }
    if(p==='/push'&&request.method==='POST'){
      const b=await request.json(),sessionId=String(b.sessionId||''),kind=String(b.kind||'DIRTY').toUpperCase(),payload=(b.payload&&typeof b.payload==='object')?b.payload:{};
      if(!sessionId)return json({error:'INVALID_SESSION'},400);
      await this.resetForSession(sessionId);
      let item=null;
      if(kind==='COMMENT'){
        const now=Date.now();let a=Array.isArray(await this.state.storage.get('comments'))?await this.state.storage.get('comments'):[];
        a=a.filter(x=>now-Number(x._ts||0)<=60*60*1000).slice(-79);
        const nonce=String(payload.client_nonce||''),uid=String(payload.user_id||''),message=String(payload.message||'');
        const duplicate=[...a].reverse().find(x=>String(x.user_id||'')===uid&&((nonce&&String(x.client_nonce||'')===nonce)||(!nonce&&String(x.message||'')===message&&now-Number(x._ts||0)<=2000)));
        if(duplicate)item=duplicate;
        else{
          const seq=Math.max(0,Number((await this.state.storage.get('commentSeq'))||0))+1;
          item={...payload,id:seq,_ts:now};a.push(item);
          await this.state.storage.put({commentSeq:seq,comments:a});
        }
      }else if(kind==='HIGHLIGHT'){
        const seq=Math.max(0,Number((await this.state.storage.get('highlightSeq'))||0))+1;
        item={...payload,id:seq,_ts:Date.now()};let a=Array.isArray(await this.state.storage.get('highlights'))?await this.state.storage.get('highlights'):[];
        a=a.filter(x=>Date.now()-Number(x._ts||0)<=20000).slice(-19);a.push(item);
        await this.state.storage.put({highlightSeq:seq,highlights:a});
      }else if(kind==='GIFT'){
        item={...payload,_ts:Date.now()};let a=Array.isArray(await this.state.storage.get('gifts'))?await this.state.storage.get('gifts'):[];
        const eid=Math.max(0,Number(item.id||0));a=a.filter(x=>Date.now()-Number(x._ts||0)<=5*60*1000&&Number(x.id||0)!==eid).slice(-39);a.push(item);
        await this.state.storage.put('gifts',a);
      }
      const revision=kind==='DIRTY'?await this.bumpState():Math.max(0,Number((await this.state.storage.get('stateRevision'))||0));
      const out=item?{...item}:null;if(out)delete out._ts;
      return json({ok:true,revision,item:out},200);
    }
    if(p==='/events'&&request.method==='GET'){
      const sessionId=String(u.searchParams.get('sessionId')||''),tokenHash=String(u.searchParams.get('tokenHash')||'');
      const current=String((await this.state.storage.get('sessionId'))||'');
      if(!sessionId||sessionId!==current)return json({error:'REALTIME_SESSION_MISMATCH'},409);
      const participant=await this.state.storage.get('participant:'+tokenHash);
      if(!participant||Number(participant.expiresAt||0)<Date.now())return json({error:'REALTIME_TICKET_EXPIRED'},401);
      const afterComment=Math.max(0,Number(u.searchParams.get('afterComment')||0)),afterHighlight=Math.max(0,Number(u.searchParams.get('afterHighlight')||0)),afterGift=Math.max(0,Number(u.searchParams.get('afterGift')||0)),knownRevision=Math.max(0,Number(u.searchParams.get('revision')||0));
      const revision=Math.max(0,Number((await this.state.storage.get('stateRevision'))||0)),visibleSince=Math.max(0,Number(participant.registeredAt||0));
      const comments=(Array.isArray(await this.state.storage.get('comments'))?await this.state.storage.get('comments'):[]).filter(x=>Number(x.id||0)>afterComment&&Number(x._ts||0)>=visibleSince).map(x=>{const y={...x};delete y._ts;return y;});
      const highlights=(Array.isArray(await this.state.storage.get('highlights'))?await this.state.storage.get('highlights'):[]).filter(x=>Number(x.id||0)>afterHighlight&&Number(x._ts||0)>=visibleSince).map(x=>{const y={...x};delete y._ts;return y;});
      const gifts=(Array.isArray(await this.state.storage.get('gifts'))?await this.state.storage.get('gifts'):[]).filter(x=>Number(x.id||0)>afterGift&&Number(x._ts||0)>=visibleSince).map(x=>{const y={...x};delete y._ts;return y;});
      return json({ok:true,sessionId,revision,changed:revision>knownRevision,comments,highlights,gifts},200);
    }
    if(p==='/clear'&&request.method==='POST'){await this.state.storage.deleteAll();return json({ok:true},200);}
    return json({error:'NOT_FOUND'},404);
  }
  async alarm(){await this.state.storage.deleteAll();}
}


export default {
  async fetch(request, env, ctx) {
    if (request.method === 'OPTIONS') return new Response(null,{status:204,headers:cors});
    const url = new URL(request.url); const p=url.pathname;
    try {
      if (request.method==='GET' && p==='/health') return json({ok:true,service:'my-shop-api',version:'2.9.359',build:'V-359',database:'my-shop-db',r2:'MEDIA',time:new Date().toISOString()},200,cors);
      if (request.method==='GET' && p==='/health/deep') {
        try { await ensureAuthSchema(env); } catch (_) {}
        try { await ensureSchemasOnce(env); } catch (_) {}
        const h=await deepHealth(env);
        return json(h,h.ok?200:503,cors);
      }
      if (request.method==='GET' && p==='/privacy') return privacyPage();
      if (request.method==='GET' && p==='/terms') return termsPage();
      if (request.method==='GET' && p==='/account-deletion') return accountDeletionPage();
      // V-352 realtime path intentionally bypasses D1/schema bootstrap after a room ticket
      // has been registered by the authenticated room-state request.
      if (request.method==='GET' && p==='/v1/live/realtime') return await liveRealtime(request,env);
      if (request.method==='POST' && p==='/v1/account/deletion-request') { await ensureSchemasOnce(env); return await accountDeletionRequest(request,env); }
      // Dashboard config is public read data. Do not let an unrelated auth/content schema
      // initialization failure turn a simple config read into SERVER_ERROR.
      if (request.method==='GET' && p==='/v1/dashboard/config') {
        try { await ensureSchemasOnce(env); } catch (_) {}
        return await dashboardConfig(request,env);
      }
      await ensureSchemasOnce(env);
      // V-300: the second Admin Locker is app-local only. Backend authorization remains ADMIN role/identity based.
      if (request.method==='GET' && p==='/v1/admin/gate/status') return json({ok:true,localOnly:true},200,cors);
      if (p==='/v1/admin/gate/setup' || p==='/v1/admin/gate/unlock' || p==='/v1/admin/gate/recover') return json({ok:true,localOnly:true},200,cors);
      if (request.method==='POST' && p==='/v1/auth/register') return await register(request,env);
      if (request.method==='POST' && p==='/v1/auth/login') return await login(request,env);
      if (request.method==='POST' && p==='/v1/auth/logout') return await logout(request,env);
      if (request.method==='GET' && p==='/v1/auth/password/questions') return await securityQuestions(request,env);
      if (request.method==='POST' && p==='/v1/auth/password/reset') return await resetPassword(request,env);
      if (request.method==='POST' && p==='/v1/auth/password/change') return await changePassword(request,env);
      if (request.method==='GET' && p==='/v1/me') return await me(request,env);
      if (request.method==='POST' && p==='/v1/account/delete') return await accountDelete(request,env);
      if (request.method==='POST' && p==='/v1/safety/block') return await safetyBlock(request,env);
      if (request.method==='GET' && p==='/v1/safety/blocks') return await safetyBlocks(request,env);
      if (request.method==='POST' && p==='/v1/safety/report') return await safetyReport(request,env);
      if (request.method==='GET' && p==='/v1/play/billing-ready') return await playBillingReady(request,env);
      if (request.method==='POST' && p==='/v1/play/purchase/verify') return await playPurchaseVerify(request,env);
      if (request.method==='GET' && p==='/v1/people/new') return await newPeople(request,env);
      if (request.method==='GET' && p==='/v1/users/profile') return await publicUserProfile(request,env);
      if (request.method==='POST' && p==='/v1/friends/request') return await friendRequest(request,env);
      if (request.method==='GET' && p==='/v1/friends') return await friendRequestsList(request,env);
      if (request.method==='POST' && p==='/v1/friends/respond') return await friendRespond(request,env);
      if (request.method==='POST' && p==='/v1/friends/cancel') return await friendCancel(request,env);
      if (request.method==='POST' && p==='/v1/friends/remove') return await friendRemove(request,env);
      if (request.method==='POST' && p==='/v1/follow/toggle') return await followToggle(request,env);
      if (request.method==='GET' && p==='/v1/live/profiles') return await liveProfiles(request,env);
      if (request.method==='POST' && p==='/v1/push/token') return await pushTokenRegister(request,env);
      if (request.method==='POST' && p==='/v1/app/presence') return await appPresence(request,env);
      if (request.method==='POST' && p==='/v1/live/presence') return await livePresence(request,env);
      if (request.method==='POST' && p==='/v1/live/end') return await liveEnd(request,env);
      if (request.method==='POST' && p==='/v1/live/viewer') return await liveViewer(request,env);
      if (request.method==='GET' && p==='/v1/live/room') return await liveRoomState(request,env);
      if (request.method==='POST' && p==='/v1/live/rtc/token') return await liveRtcToken(request,env);
      if (request.method==='POST' && p==='/v1/live/request') return await liveSpeakRequest(request,env);
      if (request.method==='POST' && p==='/v1/live/request/action') return await liveRequestAction(request,env);
      if (request.method==='POST' && p==='/v1/live/invite') return await liveInvite(request,env);
      if (request.method==='POST' && p==='/v1/live/invite/action') return await liveInviteAction(request,env);
      if (request.method==='POST' && p==='/v1/live/seat/leave') return await liveLeaveSeat(request,env);
      if (request.method==='POST' && p==='/v1/live/seat/assign') return await liveSeatAssign(request,env);
      if (request.method==='POST' && p==='/v1/live/special-guest') return await liveSpecialGuest(request,env);
      if (request.method==='POST' && p==='/v1/live/speaker/remove') return await liveSpeakerRemove(request,env);
      if ((request.method==='GET'||request.method==='POST') && p==='/v1/live/comment-ui') return await liveCommentUiConfig(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/comment-global/save') return await adminLiveCommentGlobalSave(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/comment-preset/save') return await adminLiveCommentPresetSave(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/comment-assignment/save') return await adminLiveCommentAssignmentSave(request,env);
      if (request.method==='POST' && p==='/v1/live/room/config') return await liveRoomConfig(request,env);
      if (request.method==='POST' && p==='/v1/live/room/premium') return await livePremiumConfig(request,env);
      if (request.method==='GET' && p==='/v1/live/fan-club') return await liveFanClub(request,env);
      if (request.method==='POST' && p==='/v1/live/fan-club/toggle') return await liveFanClubToggle(request,env);
      if (request.method==='GET' && p==='/v1/live/creator-center') return await liveCreatorCenter(request,env);
      if (request.method==='GET' && p==='/v1/live/discover') return await liveDiscover(request,env);
      if (request.method==='GET' && p==='/v1/live/schedules') return await liveScheduleList(request,env);
      if (request.method==='POST' && p==='/v1/live/schedules/save') return await liveScheduleSave(request,env);
      if (request.method==='POST' && p==='/v1/live/schedules/cancel') return await liveScheduleCancel(request,env);
      if (request.method==='POST' && p==='/v1/live/schedules/reminder') return await liveScheduleReminder(request,env);
      if (request.method==='POST' && p==='/v1/live/pk/start') return await livePkStart(request,env);
      if (request.method==='POST' && p==='/v1/live/pk/action') return await livePkAction(request,env);
      if (request.method==='POST' && p==='/v1/live/seat/lock') return await liveSeatLock(request,env);
      if (request.method==='POST' && p==='/v1/live/participant/state') return await liveParticipantState(request,env);
      if (request.method==='POST' && p==='/v1/live/share') return await liveShare(request,env);
      if (request.method==='POST' && p==='/v1/live/comment') return await liveComment(request,env);
      if (request.method==='POST' && p==='/v1/live/react') return await liveReact(request,env);
      if (request.method==='GET' && p==='/v1/live/highlight/config') return await liveHighlightConfig(request,env);
      if (request.method==='POST' && p==='/v1/live/highlight/comment') return await liveHighlightComment(request,env);
      if (request.method==='GET' && p==='/v1/live/gifts/summary') return await liveGiftSummary(request,env);
      if (request.method==='POST' && p==='/v1/wallet/transfer') return await liveValueTransfer(request,env);
      if (request.method==='GET' && p==='/v1/wallet/value-history') return await userValueHistory(request,env);
      if (request.method==='POST' && p==='/v1/live/moderation') return await liveModerationAction(request,env);
      if (request.method==='GET' && p==='/v1/live/gifts') return await liveGiftCatalog(request,env);
      if (request.method==='GET' && p==='/v1/live/gifts/events') return await liveGiftEvents(request,env);
      if (request.method==='POST' && p==='/v1/live/gifts/send') return await liveGiftSend(request,env,ctx);
      if (request.method==='GET' && p==='/v1/admin/live/gifts') return await adminLiveGifts(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/gifts/save') return await adminLiveGiftSave(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/gifts/bulk-vat') return await adminLiveGiftBulkVat(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/gifts/reorder') return await adminLiveGiftReorder(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/gifts/delete') return await adminLiveGiftDelete(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/gifts/asset/upload') return await adminLiveGiftAssetUpload(request,env);
      if (request.method==='GET' && p==='/v1/admin/finance/overview') return await adminFinanceOverview(request,env);
      if (request.method==='GET' && p==='/v1/admin/user-audit') return await adminUserAudit(request,env);
      if ((request.method==='GET'||request.method==='POST') && p==='/v1/admin/finance/config') return await adminFinanceConfig(request,env);
      if (request.method==='GET' && p==='/v1/admin/finance/summary') return await adminFinanceSummary(request,env);
      if (request.method==='GET' && p==='/v1/admin/live/moderation/audit') return await liveModerationAudit(request,env);
      if (request.method==='GET' && p==='/v1/live/themes') return await liveThemes(request,env);
      if (request.method==='POST' && p==='/v1/admin/live/themes') return await adminLiveTheme(request,env);
      if (request.method==='GET' && p==='/v1/live/summary') return await liveSummary(request,env);
      if (request.method==='GET' && p==='/v1/users/posts') return await userPosts(request,env);
      if (request.method==='GET' && p==='/v1/me/privacy') return await myPrivacy(request,env);
      if (request.method==='PUT' && p==='/v1/me/privacy') return await updateMyPrivacy(request,env);
      if (request.method==='GET' && p==='/v1/me/social-stats') return await mySocialStats(request,env);
      if (request.method==='GET' && p==='/v1/messages/inbox') return await messageInbox(request,env);
      if (request.method==='GET' && p==='/v1/messages/thread') return await messageThread(request,env);
      if (request.method==='POST' && p==='/v1/messages/send') return await messageSend(request,env,ctx);
      if (request.method==='POST' && p==='/v1/messages/delete-for-me') return await messageDeleteForMe(request,env);
      if (request.method==='GET' && p==='/v1/messages/unread') return await messageUnread(request,env);
      if (request.method==='PUT' && p==='/v1/me/profile') return await profileUpdate(request,env);
      if (request.method==='POST' && p==='/v1/me/avatar/upload') return await profileAvatarUpload(request,env);
      if (request.method==='POST' && p==='/v1/me/cover/upload') return await profileCoverUpload(request,env);
      if (request.method==='POST' && p==='/v1/me/cover/delete') return await profileCoverDelete(request,env);
      if (request.method==='GET' && p==='/v1/gallery') return await userGalleryList(request,env);
      if (request.method==='POST' && p==='/v1/gallery/upload') return await userGalleryUpload(request,env);
      if (request.method==='PUT' && p==='/v1/gallery/update') return await userGalleryUpdate(request,env);
      if (request.method==='POST' && p==='/v1/gallery/delete') return await userGalleryDelete(request,env);
      if (request.method==='GET' && p==='/v1/feed') return await feedList(request,env);
      if (request.method==='GET' && p==='/v1/feed/post') return await feedPost(request,env);
      if (request.method==='GET' && p==='/v1/videos') return await videoList(request,env);
      if (request.method==='POST' && p==='/v1/feed/upload') return await feedUpload(request,env);
       if (request.method==='POST' && p==='/v1/feed/text') return await feedText(request,env);
      if (request.method==='POST' && p==='/v1/feed/delete') return await feedDeleteOwn(request,env);
      if (request.method==='POST' && p==='/v1/feed/like') return await feedLike(request,env);
      if (request.method==='GET' && p==='/v1/feed/comments') return await feedComments(request,env);
      if (request.method==='POST' && p==='/v1/feed/comment') return await feedComment(request,env);
      if (request.method==='GET' && p==='/v1/admin/feed') return await adminFeedList(request,env);
      if (request.method==='POST' && p==='/v1/admin/feed/delete') return await moderatorFeedDelete(request,env);
      if (request.method==='GET' && p==='/v1/admin/safety/reports') return await adminSafetyReports(request,env);
      if (request.method==='POST' && p==='/v1/admin/safety/report/action') return await adminSafetyReportAction(request,env);
      if (request.method==='GET' && p==='/v1/admin/account-deletion-requests') return await adminDeletionRequests(request,env);
      if (request.method==='POST' && p==='/v1/admin/account-deletion-request/action') return await adminDeletionRequestAction(request,env);
      if (request.method==='GET' && p==='/v1/coins') return await coinBalance(request,env);
      if (request.method==='GET' && p==='/v1/gifts/history') return await giftHistory(request,env);
      if (request.method==='POST' && p==='/v1/coins/purchase-request') return await coinPurchaseRequest(request,env);
      if (request.method==='GET' && p==='/v1/store/catalog') return await storeCatalog(request,env);
      if (request.method==='POST' && p==='/v1/store/purchase-request') return await storePurchaseRequest(request,env);
      if (request.method==='POST' && p==='/v1/badges/active') return await setActiveBadge(request,env);
      if (request.method==='GET' && p==='/v1/admin/store/catalog') return await adminStoreCatalog(request,env);
      if (request.method==='POST' && p==='/v1/admin/store/catalog/save') return await adminStoreCatalogSave(request,env);
      if (request.method==='POST' && p==='/v1/admin/store/catalog/toggle') return await adminStoreCatalogToggle(request,env);
      if (request.method==='POST' && p==='/v1/admin/store/catalog/delete') return await adminStoreCatalogDelete(request,env);
      if (request.method==='POST' && p==='/v1/admin/asset/upload') return await adminAssetUpload(request,env);
      if (request.method==='POST' && p==='/v1/admin/store/asset/upload') return await adminStoreAssetUpload(request,env);
      if (request.method==='POST' && p==='/v1/admin/store/grant') return await adminStoreGrant(request,env);
      if (request.method==='GET' && p==='/v1/wallet/profile') return await walletProfile(request,env);
      if (request.method==='POST' && p==='/v1/wallet/purchase-request') return await walletPurchaseRequest(request,env);
      if (request.method==='POST' && p==='/v1/wallet/withdraw-request') return await goldWithdrawRequest(request,env);
      if (request.method==='POST' && p==='/v1/wallet/coin-withdraw-request') return await coinWithdrawRequest(request,env);
      if (request.method==='GET' && p==='/v1/wallet/owned-items') return await myOwnedItems(request,env);
      if (request.method==='POST' && p==='/v1/wallet/owned-items/equip') return await equipOwnedItem(request,env);
      if (request.method==='GET' && p==='/v1/admin/wallet/preview') return await adminWalletPreview(request,env);
      if (request.method==='POST' && p==='/v1/admin/wallet/grant') return await adminWalletGrant(request,env);
      if (request.method==='GET' && p==='/v1/notifications') { try { await ensureSchemasOnce(env); } catch (_) {} return await notificationsList(request,env); }
      if (request.method==='POST' && p==='/v1/notifications/read') { try { await ensureSchemasOnce(env); } catch (_) {} return await notificationReadOne(request,env); }
      if (request.method==='POST' && p==='/v1/notifications/read-all') { try { await ensureSchemasOnce(env); } catch (_) {} return await notificationsReadAll(request,env); }
      if (request.method==='GET' && p==='/health/content-write-suite') return await contentWriteSuite(request,env);
      if (request.method==='GET' && p==='/v1/admin/system/health') return await adminSystemHealth(request,env);
      if (request.method==='GET' && p==='/v1/admin/permissions') return await adminPermissions(request,env);
      if (request.method==='PUT' && p==='/v1/admin/dashboard/config') return await adminDashboardPut(request,env);
      if (request.method==='PUT' && p==='/v1/admin/content') return await adminContentPut(request,env);
      if (request.method==='GET' && p==='/v1/admin/media') return await adminMediaList(request,env);
      if (request.method==='POST' && p==='/v1/admin/media/upload') return await adminMediaUpload(request,env);
      if (request.method==='GET' && p==='/v1/admin/ads') return await adminAdsList(request,env);
      if (request.method==='POST' && p==='/v1/admin/ad/upload') return await adminAdUpload(request,env);
      if (request.method==='PUT' && p==='/v1/admin/ad/update') return await adminAdUpdate(request,env);
      if (request.method==='POST' && p==='/v1/admin/ad/delete') return await adminAdDelete(request,env);
      if (request.method==='GET' && p==='/v1/admin/live-home/banners') return await adminLiveHomeBanners(request,env);
      if (request.method==='POST' && p==='/v1/admin/banner/upload') return await adminBannerUpload(request,env);
      if (request.method==='POST' && p==='/v1/admin/banner/delete') return await adminBannerDelete(request,env);
      if (request.method==='PUT' && p==='/v1/admin/banner/update') return await adminBannerUpdate(request,env);
      if (request.method==='PUT' && p==='/v1/admin/media/update') return await adminMediaUpdate(request,env);
      if (request.method==='POST' && p==='/v1/admin/media/delete') return await adminMediaDelete(request,env);
      if (request.method==='GET' && p.startsWith('/v1/media/')) return await mediaGet(request,env,decodeURIComponent(p.slice('/v1/media/'.length)));
      if (request.method==='POST' && p==='/v1/admin/actions') return await adminAction(request,env);
      return json({error:'NOT_FOUND'},404,cors);
    } catch (e) {
      return json({error:'SERVER_ERROR',message:String(e?.message||e)},500,cors);
    }
  }
};
