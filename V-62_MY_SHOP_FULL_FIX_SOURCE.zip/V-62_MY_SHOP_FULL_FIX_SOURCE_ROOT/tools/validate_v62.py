from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
build=(root/'app/build.gradle').read_text(encoding='utf-8')
assert re.search(r'versionCode\s+62\b', build), 'versionCode 62 missing'
assert re.search(r'versionName\s+[\'\"]2\.9\.62[\'\"]', build), 'versionName 2.9.62 missing'
assert 'applicationId' in build and 'com.myshop.app' in build
reg=(root/'app/src/main/java/com/myshop/app/RegisterActivity.java').read_text(encoding='utf-8')
assert 'আপনার প্রিয় মানুষের নাম কি?' in reg
assert 'Email অথবা Mobile Number যেকোনো একটি দিন।' in reg
assert 'QUESTIONS[0]' in reg and 'QUESTIONS[1]' in reg and 'QUESTIONS[2]' in reg
store=(root/'app/src/main/java/com/myshop/app/AccountStore.java').read_text(encoding='utf-8')
assert 'if (correct < 2) return false;' in store
login=(root/'app/src/main/java/com/myshop/app/LoginActivity.java').read_text(encoding='utf-8')
assert 'sessionMatchesCurrentUi' in login
main=(root/'app/src/main/java/com/myshop/app/MainActivity.java').read_text(encoding='utf-8')
for token in ['MAX_BANNERS_PER_FOLDER = 6','feature_my_feed_selected','feature_my_shop_selected','feature_gallery_selected','feature_external_selected','feature_social_selected','feature_live_tv_selected']:
    assert token in main, token+' missing'
print('V-62 source audit PASSED')
