package com.myshop.app;

import android.content.Context;
import android.content.SharedPreferences;

/** Local session shell. Production authentication/roles must be supplied by the backend. */
public final class SessionManager {
    private static final String PREF = "myshop_session";
    private static final String ROLE = "role";
    private static final String USER_ID = "user_id";
    private static final String UI_VERSION = "ui_version";
    public static final String CURRENT_UI_VERSION = "2.9.62";

    private SessionManager() {}

    public static void setSession(Context c, Role role, String userId) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString(ROLE, role.name())
                .putString(USER_ID, userId == null ? "" : userId)
                .putBoolean("logged_in", role != Role.GUEST)
                .putString(UI_VERSION, CURRENT_UI_VERSION)
                .apply();
    }

    public static Role getRole(Context c) {
        String value = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getString(ROLE, Role.GUEST.name());
        try { return Role.valueOf(value); } catch (Exception ignored) { return Role.GUEST; }
    }

    public static String getUserId(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(USER_ID, "");
    }

    public static boolean isLoggedIn(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("logged_in", false); }

    public static boolean isAdmin(Context c) { return getRole(c) == Role.ADMIN; }
    public static boolean isModerator(Context c) { return getRole(c) == Role.MODERATOR; }


    public static boolean sessionMatchesCurrentUi(Context c) {
        return CURRENT_UI_VERSION.equals(c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(UI_VERSION, ""));
    }

    public static void forceLoginAfterUiChange(Context c) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putBoolean("logged_in", false)
                .remove(ROLE)
                .remove(UI_VERSION)
                .apply();
    }

    public static void saveProfile(Context c, String name, String email, String mobile) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("full_name", name == null ? "" : name)
                .putString("email", email == null ? "" : email)
                .putString("mobile", mobile == null ? "" : mobile)
                .apply();
    }

    public static void clear(Context c) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply();
    }
}
