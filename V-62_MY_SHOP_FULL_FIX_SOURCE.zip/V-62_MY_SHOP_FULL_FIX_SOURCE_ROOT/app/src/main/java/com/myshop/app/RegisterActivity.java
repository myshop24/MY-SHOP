package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** Final MY SHOP account creation UI: one contact method is enough; no OTP. */
public class RegisterActivity extends AppCompatActivity {
    private static final String[] QUESTIONS = {
            "প্রশ্ন ১: আপনার প্রিয় মানুষের নাম কি?",
            "প্রশ্ন ২: আপনার শৈশবের প্রিয় ডাকনাম কী?",
            "প্রশ্ন ৩: আপনার প্রথম পছন্দের খাবার কী?"
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        setupQuestion((Spinner) findViewById(R.id.question1), 0);
        setupQuestion((Spinner) findViewById(R.id.question2), 1);
        setupQuestion((Spinner) findViewById(R.id.question3), 2);

        findViewById(R.id.backLoginButton).setOnClickListener(v -> finish());
        findViewById(R.id.createButton).setOnClickListener(v -> createAccount());
    }

    private void setupQuestion(Spinner spinner, int questionIndex) {
        java.util.ArrayList<String> only = new java.util.ArrayList<>();
        only.add(QUESTIONS[questionIndex]);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, only) {
            @Override public View getView(int position, android.view.View convertView, android.view.ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                if (v instanceof android.widget.TextView) {
                    ((android.widget.TextView) v).setTextSize(15);
                    ((android.widget.TextView) v).setTextColor(0xFF30384A);
                }
                return v;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    private void createAccount() {
        EditText name = findViewById(R.id.fullName);
        EditText email = findViewById(R.id.email);
        EditText mobile = findViewById(R.id.mobile);
        EditText pass = findViewById(R.id.password);
        EditText confirm = findViewById(R.id.confirmPassword);
        EditText answer1 = findViewById(R.id.answer1);
        EditText answer2 = findViewById(R.id.answer2);
        EditText answer3 = findViewById(R.id.answer3);
        Spinner question1 = findViewById(R.id.question1);
        Spinner question2 = findViewById(R.id.question2);
        Spinner question3 = findViewById(R.id.question3);
        CheckBox terms = findViewById(R.id.terms);

        String nameValue = name.getText().toString().trim();
        String emailValue = email.getText().toString().trim();
        String mobileValue = mobile.getText().toString().trim();
        String password = pass.getText().toString();

        if (nameValue.isEmpty()) {
            Toast.makeText(this, "Full Name is required.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (emailValue.isEmpty() && mobileValue.isEmpty()) {
            Toast.makeText(this, "Email অথবা Mobile Number যেকোনো একটি দিন।", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!emailValue.isEmpty() && !Patterns.EMAIL_ADDRESS.matcher(emailValue).matches()) {
            Toast.makeText(this, "Enter a valid email address.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (password.length() < 6 || !password.equals(confirm.getText().toString())) {
            Toast.makeText(this, "Use 6+ characters and make both passwords match.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (answer1.getText().toString().trim().isEmpty() || answer2.getText().toString().trim().isEmpty() || answer3.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "৩টি Security Question ও উত্তর পূরণ করুন।", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!terms.isChecked()) {
            Toast.makeText(this, "Please accept the Terms & Conditions.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!AccountStore.canCreate(this, emailValue, mobileValue)) {
            Toast.makeText(this, "এই Email/Mobile দিয়ে Account আগে থেকেই আছে।", Toast.LENGTH_LONG).show();
            return;
        }

        String id;
        try {
            id = UserIdManager.peekNextLocalId(this);
        } catch (Throwable t) {
            Toast.makeText(this, "নতুন User ID তৈরি করা যাচ্ছে না।", Toast.LENGTH_LONG).show();
            return;
        }

        boolean created = AccountStore.createWithSecurity(this, id, nameValue, emailValue, mobileValue, password,
                QUESTIONS[0], answer1.getText().toString(),
                QUESTIONS[1], answer2.getText().toString(),
                QUESTIONS[2], answer3.getText().toString());
        if (!created) {
            Toast.makeText(this, "এই Email/Mobile দিয়ে Account আগে থেকেই আছে।", Toast.LENGTH_LONG).show();
            return;
        }

        UserIdManager.commitLocalAllocation(this, id);
        SessionManager.setSession(this, Role.USER, id);
        SessionManager.saveProfile(this, nameValue, emailValue, mobileValue);

        Toast.makeText(this, "Account created. Your permanent User ID: " + id, Toast.LENGTH_LONG).show();
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }
}
