# MY SHOP V-204 — Content Write Diagnostic Root Fix

V-204 is a diagnostic/root-fix release for the GitHub Actions Cloudflare content-write gate.

## What changed
- Android versionCode: 204
- Android versionName: 2.9.204
- Worker `/health`: V-204 / 2.9.204
- The content-write gate now captures the HTTP status and prints the Worker JSON response body instead of hiding a 503 behind `curl -f` exit code 22.
- APK build remains blocked unless the content-write suite returns HTTP 200 with `ok:true`.
- The diagnostic response is saved as `release/cloudflare/content-write-suite.json` when available.

## Data safety
- No auth/user/admin rows are deleted or replaced.
- Existing D1/R2 bindings remain unchanged.
- Existing V-numbered backups are not removed.
- The content-write probe only cleans its own temporary marker rows.
