from pathlib import Path
import re
root=Path(__file__).resolve().parent
assert (root/'SOURCE_BUILD_ID.txt').read_text().strip()=='MY SHOP V-204'
g=(root/'app'/'build.gradle').read_text(); assert re.search(r'\bversionCode\s+204\b',g); assert re.search(r"versionName\s+'2\.9\.204'",g)
js=(root/'backend/worker/src/index.js').read_text(); assert "worker:{version:'2.9.204',build:'V-204'}" in js; assert "version:'2.9.204',build:'V-204'" in js
w=(root/'.github/workflows/my-shop-apk.yml').read_text()
for x in ['Verify ACTIVE production Worker before APK build','Verify ACTIVE Worker content write suite before APK build','LIVE CONTENT WRITE SUITE PASSED','D1/R2 READ+WRITE deep health failed','Content-write attempt','-o "$BODY" -w \'%{http_code}\'']:
    assert x in w, x
assert 'Run ACTIVE Worker content write diagnostics (non-blocking)' not in w
print('V-204 SOURCE VERIFICATION PASSED')
