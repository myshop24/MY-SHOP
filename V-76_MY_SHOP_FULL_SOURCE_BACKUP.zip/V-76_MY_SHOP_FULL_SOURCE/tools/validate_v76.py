from pathlib import Path

root = Path(__file__).resolve().parents[1]
build = (root / 'app/build.gradle').read_text(encoding='utf-8')
assert "versionCode 76" in build
assert "versionName '2.9.76'" in build
assert "applicationId 'com.myshop.app'" in build

main = (root / 'app/src/main/java/com/myshop/app/MainActivity.java').read_text(encoding='utf-8')
assert 'enableFullscreen()' in main
assert 'fitDashboardToScreen' in main
assert 'DESIGN_WIDTH_DP = 480' in main
assert 'new ScrollView' not in main
assert 'dashboard.addView(nav' in main

login = (root / 'app/src/main/java/com/myshop/app/LoginActivity.java').read_text(encoding='utf-8')
reg = (root / 'app/src/main/java/com/myshop/app/RegisterActivity.java').read_text(encoding='utf-8')
store = (root / 'app/src/main/java/com/myshop/app/AccountStore.java').read_text(encoding='utf-8')
uid = (root / 'app/src/main/java/com/myshop/app/UserIdManager.java').read_text(encoding='utf-8')
assert 'showPasswordResetBox' in login
assert 'resetPasswordWithTwoOfThree' in login
assert 'securityQuestion1' in reg and 'securityQuestion2' in reg and 'securityQuestion3' in reg
assert 'validSecuritySet' in store and 'matches < 2' in store
assert 'FIRST_ID = 100' in uid and '%04d' in uid
assert (root / 'app/src/main/res/drawable/myshop_dashboard_reference.png').exists()
print('V-76 source validation PASSED')
