package com.myshop.app;

import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** Account/settings shell. Sensitive authentication and server-side permissions remain backend-owned. */
public class AccountActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        TextView id = findViewById(R.id.accountId);
        TextView role = findViewById(R.id.accountRole);
        String userId = SessionManager.getUserId(this);
        String name = getSharedPreferences("myshop_session", MODE_PRIVATE).getString("full_name", "");
        String email = getSharedPreferences("myshop_session", MODE_PRIVATE).getString("email", "");
        String mobile = getSharedPreferences("myshop_session", MODE_PRIVATE).getString("mobile", "");
        id.setText("Profile ID: " + (userId.isEmpty() ? "Not assigned" : userId)
                + "\nName: " + (name.isEmpty() ? "Not set" : name)
                + "\nEmail/Mobile: " + (!email.isEmpty() ? email : (mobile.isEmpty() ? "Not set" : mobile)));
        role.setText("Role: " + SessionManager.getRole(this).name());

        Switch notifications = findViewById(R.id.notificationSwitch);
        notifications.setChecked(getPreferences(MODE_PRIVATE).getBoolean("notifications", true));
        notifications.setOnCheckedChangeListener((button, checked) ->
                getPreferences(MODE_PRIVATE).edit().putBoolean("notifications", checked).apply());

        findViewById(R.id.profileButton).setOnClickListener(v ->
                Toast.makeText(this, "Profile editing will sync with the backend.", Toast.LENGTH_SHORT).show());
        findViewById(R.id.passwordButton).setOnClickListener(v ->
                Toast.makeText(this, "Password reset/change is handled by secure backend authentication.", Toast.LENGTH_LONG).show());
        findViewById(R.id.reportButton).setOnClickListener(v ->
                Toast.makeText(this, "Report system is ready for backend integration.", Toast.LENGTH_SHORT).show());
        findViewById(R.id.blockButton).setOnClickListener(v ->
                Toast.makeText(this, "Block list is ready for backend integration.", Toast.LENGTH_SHORT).show());
        findViewById(R.id.logoutButton).setOnClickListener(v -> {
            String token = SessionManager.getToken(this);
            SessionManager.clear(this);
            Intent intent = new Intent(this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            if (token != null && !token.isEmpty()) BackendClient.logout(token, new BackendClient.Callback() { public void onSuccess(org.json.JSONObject d) {} public void onError(String m) {} });
        });
    }
}
