V-85 MY SHOP - FULL ANDROID PROJECT

This ZIP is the FULL Android project itself.
It is NOT a ZIP containing another source ZIP.

GitHub upload:
1. Extract this ZIP.
2. Upload ALL extracted files/folders to the repository root.
3. Keep the .github/workflows/my-shop-v85.yml file.
4. Push to main or run the V-85 workflow manually.

The project contains settings.gradle, build.gradle, app/, AndroidManifest.xml,
and the V-85 GitHub Actions workflow at .github/workflows/my-shop-v85.yml.
