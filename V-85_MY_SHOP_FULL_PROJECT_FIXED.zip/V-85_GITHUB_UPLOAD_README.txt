V-85 MY SHOP — FULL PROJECT UPLOAD

This archive is the FULL Android project itself.
It is NOT a ZIP containing another source ZIP.

Upload the extracted project contents to the repository root.
Keep .github/workflows/my-shop-apk.yml.
Remove/disable the old V-81 workflow before running V-85.

Expected build:
Package: com.myshop.app
VersionCode: 85
VersionName: 2.9.85
Launcher: com.myshop.app.LoginActivity
Exactly ONE release APK.
