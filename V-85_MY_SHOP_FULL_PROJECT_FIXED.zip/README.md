# MY SHOP V-76

V-76 is the next full Android source package derived from the verified V-73 source.

## V-76 scope
- Corrected dashboard presentation for phone screens: immersive full-screen mode.
- Removed the dashboard vertical ScrollView so the approved dashboard is treated as one complete screen.
- Added responsive uniform fitting so the complete dashboard scales down to the available phone display instead of requiring unnecessary vertical scrolling.
- Preserved the existing login/register/dashboard assets and clickable feature structure.
- Version: `2.9.76`, source versionCode baseline `76`.
- Exactly one release APK is required by the V-76 GitHub Actions workflow.
- SHA-256 checksum is produced beside the final APK.

## Important backend status
The source contains backend contracts and a remote-config foundation, but the Android client still uses local account/session storage for authentication and ID allocation. The V-76 package does not invent or replace a production Cloudflare Worker endpoint. The actual Worker API URL must be confirmed before production backend integration is claimed complete.

## Build
The V-76 workflow uses Java 17, Android SDK 35, Build Tools 35.0.0 and Gradle 8.11.1 through GitHub Actions. The source ZIP does not require `gradlew` because the workflow provisions Gradle directly.
