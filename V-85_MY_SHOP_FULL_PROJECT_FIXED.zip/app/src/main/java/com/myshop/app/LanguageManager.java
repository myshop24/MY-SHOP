package com.myshop.app;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.HashMap;
import java.util.Map;

public final class LanguageManager {
    public static final String BN = "bn";
    public static final String EN = "en";
    public static final String HI = "hi";
    public static final String AR = "ar";

    private static final String PREFS = "myshop_settings";
    private static final String KEY_LANGUAGE = "language";
    private static final String[] CODES = {BN, EN, HI, AR};
    private static final String[] LABELS = {"বাংলা", "English", "हिन्दी", "العربية"};
    private static final Map<String, Map<String, String>> TEXT = new HashMap<>();

    static {
        Map<String, String> en = new HashMap<>();
        en.put("search", "Search for products, live, users, posts...");
        en.put("breaking", "BREAKING NEWS"); en.put("liveNow", "LIVE NOW"); en.put("seeAll", "See all");
        en.put("live", "LIVE"); en.put("goLive", "GO LIVE"); en.put("feed", "MY FEED"); en.put("shop", "MY SHOP");
        en.put("gallery", "GALLERY"); en.put("movie", "EXTERNAL MOVIE"); en.put("tv", "LIVE TV");
        en.put("social", "SOCIAL MEDIA"); en.put("reward", "EARN & REWARD"); en.put("share", "SHARE");
        en.put("apps", "MORE APPS"); en.put("chat", "Chat"); en.put("home", "Home"); en.put("store", "Store");
        en.put("more", "More"); en.put("language", "Language"); en.put("login", "LOGIN"); en.put("register", "CREATE ACCOUNT");
        en.put("forgot", "Forgot Password?"); en.put("welcome", "Welcome Back!"); en.put("remember", "Remember me");
        en.put("or", "OR"); en.put("fullName", "Full Name"); en.put("email", "Email Address (optional)");
        en.put("mobile", "Mobile Number (optional)"); en.put("password", "Create Password"); en.put("confirm", "Confirm Password");
        en.put("security", "Security Question + 2-of-3 Password Reset");
        en.put("securityHint", "Set 3 different questions and answers. Any 2 correct answers can reset the password.");
        en.put("terms", "I agree to the Terms & Conditions and Privacy Policy"); en.put("noOtp", "No OTP / verification code required");
        TEXT.put(EN, en);

        Map<String, String> bn = new HashMap<>();
        bn.put("search", "পণ্য, লাইভ, ইউজার, পোস্ট খুঁজুন..."); bn.put("breaking", "ব্রেকিং নিউজ"); bn.put("liveNow", "লাইভ এখন চলছে");
        bn.put("seeAll", "সব দেখুন"); bn.put("live", "লাইভ"); bn.put("goLive", "লাইভ যান"); bn.put("feed", "MY FEED"); bn.put("shop", "MY SHOP");
        bn.put("gallery", "গ্যালারি"); bn.put("movie", "এক্সটার্নাল মুভি"); bn.put("tv", "লাইভ টিভি"); bn.put("social", "সোশ্যাল মিডিয়া");
        bn.put("reward", "আয় ও পুরস্কার"); bn.put("share", "শেয়ার"); bn.put("apps", "আরও অ্যাপস"); bn.put("chat", "চ্যাট");
        bn.put("home", "হোম"); bn.put("store", "স্টোর"); bn.put("more", "আরও"); bn.put("language", "ভাষা"); bn.put("login", "লগইন");
        bn.put("register", "অ্যাকাউন্ট খুলুন"); bn.put("forgot", "পাসওয়ার্ড ভুলে গেছেন?"); bn.put("welcome", "স্বাগতম আবার!");
        bn.put("remember", "আমাকে মনে রাখুন"); bn.put("or", "অথবা"); bn.put("fullName", "পূর্ণ নাম"); bn.put("email", "ইমেইল (ঐচ্ছিক)");
        bn.put("mobile", "মোবাইল নম্বর (ঐচ্ছিক)"); bn.put("password", "পাসওয়ার্ড তৈরি করুন"); bn.put("confirm", "পাসওয়ার্ড নিশ্চিত করুন");
        bn.put("security", "সিকিউরিটি প্রশ্ন + ২-এর-৩ পাসওয়ার্ড রিসেট");
        bn.put("securityHint", "৩টি আলাদা প্রশ্ন ও উত্তর দিন। যেকোনো ২টি সঠিক হলে পাসওয়ার্ড রিসেট হবে।");
        bn.put("terms", "আমি Terms & Conditions এবং Privacy Policy মেনে নিচ্ছি"); bn.put("noOtp", "কোনো OTP / ভেরিফিকেশন কোড লাগবে না");
        TEXT.put(BN, bn);

        Map<String, String> hi = new HashMap<>();
        hi.put("search", "प्रोडक्ट, लाइव, यूज़र, पोस्ट खोजें..."); hi.put("breaking", "ब्रेकिंग न्यूज़"); hi.put("liveNow", "अभी लाइव"); hi.put("seeAll", "सब देखें");
        hi.put("live", "लाइव"); hi.put("goLive", "लाइव जाएँ"); hi.put("feed", "MY FEED"); hi.put("shop", "MY SHOP"); hi.put("gallery", "गैलरी");
        hi.put("movie", "एक्सटर्नल मूवी"); hi.put("tv", "लाइव टीवी"); hi.put("social", "सोशल मीडिया"); hi.put("reward", "कमाएँ और रिवॉर्ड");
        hi.put("share", "शेयर"); hi.put("apps", "और ऐप्स"); hi.put("chat", "चैट"); hi.put("home", "होम"); hi.put("store", "स्टोर"); hi.put("more", "और");
        hi.put("language", "भाषा"); hi.put("login", "लॉगिन"); hi.put("register", "अकाउंट बनाएँ"); hi.put("forgot", "पासवर्ड भूल गए?");
        hi.put("welcome", "वापसी पर स्वागत है!"); hi.put("remember", "मुझे याद रखें"); hi.put("or", "या"); hi.put("fullName", "पूरा नाम");
        hi.put("email", "ईमेल (वैकल्पिक)"); hi.put("mobile", "मोबाइल नंबर (वैकल्पिक)"); hi.put("password", "पासवर्ड बनाएँ"); hi.put("confirm", "पासवर्ड की पुष्टि करें");
        hi.put("security", "सिक्योरिटी प्रश्न + 2-of-3 पासवर्ड रीसेट"); hi.put("securityHint", "3 अलग प्रश्न और उत्तर दें। किसी भी 2 सही उत्तर से पासवर्ड रीसेट होगा।");
        hi.put("terms", "मैं Terms & Conditions और Privacy Policy से सहमत हूँ"); hi.put("noOtp", "OTP / verification code की जरूरत नहीं"); TEXT.put(HI, hi);

        Map<String, String> ar = new HashMap<>();
        ar.put("search", "ابحث عن المنتجات والبث والمستخدمين والمنشورات..."); ar.put("breaking", "أخبار عاجلة"); ar.put("liveNow", "مباشر الآن"); ar.put("seeAll", "عرض الكل");
        ar.put("live", "مباشر"); ar.put("goLive", "ابدأ البث"); ar.put("feed", "MY FEED"); ar.put("shop", "MY SHOP"); ar.put("gallery", "المعرض");
        ar.put("movie", "فيلم خارجي"); ar.put("tv", "تلفزيون مباشر"); ar.put("social", "التواصل الاجتماعي"); ar.put("reward", "اربح ومكافآت");
        ar.put("share", "مشاركة"); ar.put("apps", "المزيد من التطبيقات"); ar.put("chat", "دردشة"); ar.put("home", "الرئيسية"); ar.put("store", "المتجر"); ar.put("more", "المزيد");
        ar.put("language", "اللغة"); ar.put("login", "تسجيل الدخول"); ar.put("register", "إنشاء حساب"); ar.put("forgot", "هل نسيت كلمة المرور؟");
        ar.put("welcome", "مرحباً بعودتك!"); ar.put("remember", "تذكرني"); ar.put("or", "أو"); ar.put("fullName", "الاسم الكامل");
        ar.put("email", "البريد الإلكتروني (اختياري)"); ar.put("mobile", "رقم الهاتف (اختياري)"); ar.put("password", "إنشاء كلمة المرور"); ar.put("confirm", "تأكيد كلمة المرور");
        ar.put("security", "سؤال الأمان + إعادة تعيين 2 من 3"); ar.put("securityHint", "ضع 3 أسئلة وأجوبة مختلفة. يكفي تطابق أي إجابتين لإعادة التعيين.");
        ar.put("terms", "أوافق على الشروط وسياسة الخصوصية"); ar.put("noOtp", "لا حاجة إلى رمز OTP / التحقق"); TEXT.put(AR, ar);
    }

    private LanguageManager() {}

    public static String get(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LANGUAGE, BN);
    }

    public static void set(Context context, String language) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_LANGUAGE, language).apply();
    }

    public static String t(Context context, String key) {
        Map<String, String> map = TEXT.get(get(context));
        if (map == null) map = TEXT.get(BN);
        String value = map.get(key);
        return value == null ? key : value;
    }

    public static void showPicker(Context context, Runnable onChanged) {
        final String[] shown = LABELS.clone();
        AlertDialog dialog = new AlertDialog.Builder(context)
                .setTitle("🌐  " + t(context, "language"))
                .setItems(shown, (d, which) -> {
                    set(context, CODES[which]);
                    if (onChanged != null) onChanged.run();
                }).create();
        dialog.show();
    }
}
