package com.myshop.app;

/** Identifier allow-list only. Passwords and authorization remain backend responsibilities. */
public final class AdminIdentifiers {
    private AdminIdentifiers() {}
    public static boolean isAdminIdentifier(String value) {
        if (value == null) return false;
        String v = value.trim().toLowerCase(java.util.Locale.US);
        return v.equals("myshopsatkania@gmail.com") || v.equals("touhidsatkania@gmail.com") || v.equals("01860626700");
    }
}
