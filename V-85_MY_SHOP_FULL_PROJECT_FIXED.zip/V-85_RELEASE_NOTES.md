# V-85 MY SHOP — FULL PROJECT

This ZIP contains the **complete Android project itself**. It is **not** a ZIP containing another project ZIP.

- Version code: **85**
- Version name: **2.9.85**
- Package: **com.myshop.app**
- Launcher: **com.myshop.app.LoginActivity**
- Exactly one Android project (`settings.gradle`)
- GitHub Actions workflow: `.github/workflows/my-shop-apk.yml`

## GitHub upload
1. Extract this ZIP.
2. Upload **all extracted files and folders** to the repository root.
3. Keep `.github/workflows/my-shop-apk.yml`.
4. Remove/disable the old V-81 workflow before running V-85, so V-81 cannot start again.
5. Push to `main` or run the V-85 workflow manually.

## Important
The workflow does not use V-79/V-80/V-81 source ZIPs. It builds this V-85 project directly.
