# V-350 GitHub Upload

Upload the compact source ZIP `V-350-MY-SHOP-STABILIZATION-GITHUB-FINAL.zip` to the repository root using the same permanent MY SHOP workflow.

Expected source identity:
- SOURCE_BUILD_ID: MY SHOP V-350
- Android versionCode: 350
- Android versionName: 2.9.350
- Worker: 2.9.350 / V-350

The root `.github/workflows/my-shop-apk.yml` is repository-owned and is not replaced by this source package. Keep signing secrets/Firebase secrets in GitHub/Worker secret storage, never inside this ZIP.

After Green, install the produced APK and complete `V-350_REGRESSION_QA.md`; Green alone is not runtime-final.
