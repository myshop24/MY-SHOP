# MY SHOP DEVELOPER HANDOFF — V-350 STABILIZATION

Current version: V-350
SOURCE_BUILD_ID: MY SHOP V-350
Android: versionCode 350 / versionName 2.9.350
Worker: version 2.9.350 / build V-350

Locked scope: `V-350_LOCKED_STABILIZATION_SCOPE.md`
Release notes: `V-350_RELEASE_NOTES.md`
Regression/device gate: `V-350_REGRESSION_QA.md`
Push runtime requirements: `V-350_PUSH_RUNTIME_REQUIREMENTS.md`

## Last checkpoint
V-350 is based on the V-349 stabilization source and keeps V-349 persistent-login and FCM plumbing. Static validation: 28/28 PASS; Worker JavaScript syntax PASS; Android PNG/XML resource integrity PASS; no Java parser syntax-pattern error found. Full Android compile/device acceptance remains pending GitHub CI + installed APK. This pass targets the user-recorded runtime defects: missing Gift sound, comment stream visibility/order, oversized/obscuring feedback, seat visual mismatch, and Join button animation.

## Golden references
- `APPROVED-V350-LIVE-ROOM-FINAL-REFERENCE.png`
- `APPROVED-V350-SEAT-REFERENCE.png`
- `V-350-COMMENT-DEFECT-REFERENCE.jpg` documents the pre-fix problem only; it is not a desired design.

## Completion rule
Do not call the APK runtime-final just because CI is Green. Install the built APK and complete `V-350_REGRESSION_QA.md`. Preserve all working Coin/Gold/Admin/RTC/backend contracts.
