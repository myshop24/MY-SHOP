# MY SHOP — Permanent Stabilization + Premium UI Master Plan

Baseline: V-369  
Foundation release: V-370  
Status: ACTIVE / MANDATORY FOR ALL FUTURE VERSIONS

## 1. Permanent release rule
A version number is not proof that the intended code reached the installed APK. Every release must prove one chain:

`Golden Source -> Git commit -> Android build -> APK/AAB -> deployed Worker -> installed app`

No release may be called complete only because files were edited or a ZIP was produced.

## 2. Single Golden Source
- The immediately previous accepted version is the only starting source for the next version.
- Never merge an old full Activity/Worker file over a newer one just to recover one feature.
- Keep the previous accepted ZIP untouched as rollback source.
- `SOURCE_BUILD_ID.txt` and `SOURCE_VERSION_NAME.txt` are the release identity source of truth.
- V-370 Android `versionCode/versionName` are derived from those files, removing manual version drift.

## 3. GitHub -> APK identity proof
Every Android build must expose:
- MY SHOP Build ID (example V-370)
- versionName
- versionCode
- Git commit SHA when built on GitHub
- expected backend version

The app's About page shows this identity and checks `/health` against the expected backend version. A MISMATCH means the installed app and deployed Worker are from different releases and runtime QA must stop until fixed.

## 4. Build guard
Android `preBuild` depends on `verifyMyShopReleaseIdentity`.
The build must fail if:
- SOURCE_BUILD_ID is malformed;
- build number and versionName suffix differ;
- Worker `/health` source metadata does not match the Android release identity.

This makes “version increased but old/mixed source built” much harder to ship silently.

## 5. Protected module / regression rule
Before each edit:
1. Name the target module(s).
2. Mark every other working module protected.
3. Hash baseline protected files.
4. Make minimal scoped edits.
5. Compare before/after file list and hashes.
6. Stop release if an unrelated protected file changed unexpectedly.

Permanent high-risk protected modules include:
- authentication/session/user ID;
- Coin, Gold Coin, Star, Level and finance ledgers;
- purchased-vs-earned withdrawal separation;
- Gifts and gift catalog/admin pricing;
- Agora RTC token/channel architecture;
- Live comments ephemeral storage rule;
- Live End first-tap behavior;
- Profile/social counts and timeline;
- Admin CRUD permissions;
- banner management and carousel;
- Google Play Billing/compliance safeguards;
- D1/R2 bindings and existing backend contracts.

## 6. Acceptance gates
A release needs four independent PASS states:
- SOURCE PASS: intended source changes are present and protected files are clean.
- BUILD PASS: Gradle identity guard passes and APK/AAB is built from the expected Git SHA.
- BACKEND PASS: `/health` build/version matches the app's expected backend identity.
- DEVICE PASS: required real-device behaviors are tested.

If device testing is not available, release notes must say `RUNTIME QA PENDING`; never say fully fixed.

## 7. Premium UI Design System — MY SHOP standard
Premium look comes from consistency, not from adding more glow.

### Color roles
- Primary: vivid MY SHOP blue.
- Secondary: purple.
- Accent: pink/cyan/gold only for important states.
- Live background: low-light navy/purple.
- Light app background: clean near-white.
- Error/destructive: red only for destructive/error states.

### Radius
- Small chips: 10dp.
- Standard controls: 14dp.
- Cards/dialog surfaces: 18dp.
- Hero/feature surfaces: 24dp.

### Height / touch
- Minimum touch target: 44dp.
- Standard control: 48dp.
- Primary CTA: 52dp or larger only where the layout explicitly calls for it.

### Spacing system
Use only the shared scale where practical: 4 / 8 / 12 / 16 / 24dp. Avoid random one-off spacing unless layout constraints require it.

### Typography
- One primary sans family.
- Strong hierarchy: title > section title > body > metadata.
- Avoid too many font sizes on one screen.
- IDs, timers, counts and metadata should be visually quieter than primary actions.

### Buttons
Every button must define:
- normal state;
- pressed state;
- disabled state when relevant;
- loading state only when the action truly waits;
- minimum touch size;
- consistent icon/text alignment.

### Motion
- Press in about 70ms.
- Release about 145ms.
- Normal screen/component transitions should generally feel within about 150–250ms.
- No jumping emoji/buttons, repeated heavy pulse, or uncontrolled animation.

### Shadows/glow
- Use depth to separate layers, not decorate everything.
- One focal glow is better than multiple competing glows.
- Live speaking state may animate; static controls should remain visually stable.

## 8. Premium rollout sequence
Do not redesign the whole app in one version.
1. Foundation (V-370): identity, regression gates, design tokens.
2. Live Room visual polish using locked functionality.
3. Live Home polish.
4. Main dashboard polish.
5. Profile/social polish.
6. Wallet/Gift/Admin polish.
7. Remaining utility screens.

Each batch must preserve behavior first, then improve visuals.

## 9. Reference implementation rule
For a reference image/video:
1. Capture the exact target area.
2. Measure relative widths/heights/spacing.
3. Map it to shared MY SHOP tokens/components.
4. Implement only that target area.
5. Compare a real-device screenshot to the reference.
6. Iterate only on visual mismatch, not unrelated business logic.

## 10. Release evidence required in every future handoff
- Base version and exact target scope.
- Changed-file list.
- Protected-file integrity result.
- versionCode/versionName/build ID.
- Git SHA from actual build when available.
- Backend `/health` identity.
- Static/build QA result.
- Real-device acceptance result or explicit pending status.
- Play compliance status.
- Known issues / next tasks.

## 11. Stop conditions
Stop the release instead of producing another ZIP if:
- an unrelated locked module changed;
- app and Worker versions differ;
- a required backend schema/binding would be broken;
- the APK cannot prove its source/build identity;
- a claimed critical fix has not been validated at the required acceptance level.

This plan is permanent. Future feature work must follow it rather than replacing it.
