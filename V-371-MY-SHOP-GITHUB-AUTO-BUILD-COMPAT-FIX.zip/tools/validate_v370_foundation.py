from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
errors=[]
build=(root/'SOURCE_BUILD_ID.txt').read_text().strip()
ver=(root/'SOURCE_VERSION_NAME.txt').read_text().strip()
m=re.search(r'V-(\d+)',build)
if not m: errors.append('invalid SOURCE_BUILD_ID')
else:
    code=int(m.group(1))
    try: tail=int(ver.split('.')[-1])
    except: tail=-1
    if code!=tail: errors.append(f'build/version mismatch: {build} vs {ver}')
gradle=(root/'app/build.gradle').read_text()
backend=(root/'backend/worker/src/index.js').read_text()
feature=(root/'app/src/main/java/com/myshop/app/FeatureActivity.java').read_text()
premium=(root/'app/src/main/java/com/myshop/app/PremiumUi.java').read_text()
checks={
 'gradle derives versionCode':'versionCode myshopVersionCode' in gradle,
 'gradle derives versionName':'versionName myshopVersionName' in gradle,
 'preBuild identity guard':"task.dependsOn('verifyMyShopReleaseIdentity')" in gradle,
 'git sha BuildConfig':"MYSHOP_GIT_SHA" in gradle,
 'backend health version':f"version:'{ver}'" in backend,
 'backend health build':f"build:'V-{code if m else 0}'" in backend,
 'About build identity':'MY SHOP Build Identity' in feature,
 'About backend MATCH':'Backend check: MATCH' in feature,
 'premium radius tokens':'RADIUS_CARD_DP' in premium,
 'premium spacing tokens':'SPACE_MD_DP' in premium,
}
for k,v in checks.items():
    if not v: errors.append(k)
if errors:
    print('V-370 FOUNDATION VALIDATION: FAIL')
    for e in errors: print(' -',e)
    sys.exit(1)
print('V-370 FOUNDATION VALIDATION: PASS')
print(build, ver)
for k in checks: print(' PASS',k)
