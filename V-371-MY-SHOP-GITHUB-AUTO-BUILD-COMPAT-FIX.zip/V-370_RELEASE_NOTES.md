# V-370 RELEASE NOTES — Stabilization + Premium UI Foundation

Base: V-369
Version: 2.9.370 / versionCode 370

## Purpose
V-370 intentionally does not add another large product feature. It establishes the permanent release-integrity and UI-consistency foundation requested after repeated cases where version numbers increased but installed behavior regressed or looked unchanged.

## Completed
- SOURCE_BUILD_ID / SOURCE_VERSION_NAME are now the Android version source of truth.
- Android versionCode/versionName are derived automatically from release identity files.
- Added BuildConfig identity: MYSHOP_BUILD_ID, MYSHOP_GIT_SHA, expected backend version.
- Added Gradle `verifyMyShopReleaseIdentity`; Android preBuild depends on it.
- Guard verifies source build/version consistency and Worker source health identity.
- About screen now exposes installed build/versionCode/Git SHA and performs a runtime backend `/health` MATCH/MISMATCH check.
- Worker health metadata moved to V-370 / 2.9.370 without changing business logic.
- PremiumUi now owns canonical radius, control height, touch, spacing and press-duration tokens.
- Added permanent Stabilization + Premium UI Master Plan.

## Deliberately not changed
- Live participant logic from V-369.
- Coin/Gold/Gift economy.
- Agora RTC business flow.
- Dashboard feature structure.
- Profile/social behavior.
- Admin module behavior.
- D1/R2 schema/bindings.

## Runtime acceptance
The About screen should show V-370 / 2.9.370 / versionCode 370. On a GitHub-built APK it should show the Git SHA. After the V-370 Worker is deployed, Backend check must show MATCH. If it shows MISMATCH, do not run feature acceptance on that APK/backend pair.
