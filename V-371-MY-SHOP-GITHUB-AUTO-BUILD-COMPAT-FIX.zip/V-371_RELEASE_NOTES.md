# MY SHOP V-371 — GitHub Auto-Build Compatibility Fix

## Fixed
- Permanent GitHub auto-build was stopping at **Locate Android project and verify version** with `ERROR: versionCode must equal 370`.
- Root cause: V-370 used Gradle variable `versionCode myshopVersionCode`; the existing GitHub safety guard intentionally parses a literal `versionCode <V-number>` before Android tooling starts.
- V-371 restores workflow-compatible literal Android identity:
  - `versionCode 371`
  - `versionName "2.9.371"`
- SOURCE_BUILD_ID / SOURCE_VERSION_NAME and backend `/health` identity remain cross-checked by the Gradle verification task.

## Regression scope
No Live Room, Coin, Gift, Profile, Dashboard, backend business logic, permissions, or UI behavior was intentionally changed beyond release identity/build verification compatibility.
