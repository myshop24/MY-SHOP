package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** V-96 account creation: one security section, choose 3 unique questions from the 6 owner-specified questions; no OTP. */
public class RegisterActivity extends AppCompatActivity {
    /** Six owner-specified questions. The account stores three selected questions;
     * password recovery succeeds when any two of those three answers match. */
    private static final String[] QUESTIONS = {
            "Select a security question",
            "What is the name of your favorite person?",
            "Which district is your birthplace?",
            "What is your favorite color?",
            "What is your favorite teacher's name?",
            "What is your birth year?",
            "What is your favorite sport?"
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        findViewById(R.id.backLoginButton).setOnClickListener(v -> finish());
        findViewById(R.id.languageButton).setOnClickListener(v -> LanguageManager.showPicker(this, this::applyLanguage));
        setupQuestionSpinner(R.id.securityQuestion1);
        setupQuestionSpinner(R.id.securityQuestion2);
        setupQuestionSpinner(R.id.securityQuestion3);
        findViewById(R.id.createButton).setOnClickListener(v -> createAccount());
        applyLanguage();
    }

    private void applyLanguage() {
        android.widget.Button lang = findViewById(R.id.languageButton);
        String l = LanguageManager.get(this);
        String label = LanguageManager.BN.equals(l) ? "বাংলা" : LanguageManager.EN.equals(l) ? "English" : LanguageManager.HI.equals(l) ? "हिन्दी" : "العربية";
        lang.setText("🌐  " + label);
    }

    private void setupQuestionSpinner(int id) {
        Spinner spinner = findViewById(id);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, QUESTIONS);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    private void createAccount() {
        EditText name = findViewById(R.id.fullName);
        EditText email = findViewById(R.id.email);
        EditText mobile = findViewById(R.id.mobile);
        EditText pass = findViewById(R.id.password);
        EditText confirm = findViewById(R.id.confirmPassword);
        CheckBox terms = findViewById(R.id.terms);

        String nameValue = name.getText().toString().trim();
        String emailValue = email.getText().toString().trim();
        String mobileValue = mobile.getText().toString().trim();
        String password = pass.getText().toString();
        String[] questions = {
                ((Spinner)findViewById(R.id.securityQuestion1)).getSelectedItem().toString(),
                ((Spinner)findViewById(R.id.securityQuestion2)).getSelectedItem().toString(),
                ((Spinner)findViewById(R.id.securityQuestion3)).getSelectedItem().toString()
        };
        String[] answers = {
                ((EditText)findViewById(R.id.securityAnswer1)).getText().toString().trim(),
                ((EditText)findViewById(R.id.securityAnswer2)).getText().toString().trim(),
                ((EditText)findViewById(R.id.securityAnswer3)).getText().toString().trim()
        };

        if (nameValue.isEmpty()) { Toast.makeText(this, "Full Name is required.", Toast.LENGTH_SHORT).show(); return; }
        if (emailValue.isEmpty() && mobileValue.isEmpty()) { Toast.makeText(this, "Email অথবা Mobile Number যেকোনো একটি দিন।", Toast.LENGTH_SHORT).show(); return; }
        if (!emailValue.isEmpty() && !Patterns.EMAIL_ADDRESS.matcher(emailValue).matches()) { Toast.makeText(this, "Enter a valid email address.", Toast.LENGTH_SHORT).show(); return; }
        if (password.length() < 6 || !password.equals(confirm.getText().toString())) { Toast.makeText(this, "Use 6+ characters and make both passwords match.", Toast.LENGTH_SHORT).show(); return; }
        if (!terms.isChecked()) { Toast.makeText(this, "Please accept the Terms & Conditions.", Toast.LENGTH_SHORT).show(); return; }
        if (questions[0].equals(QUESTIONS[0]) || questions[1].equals(QUESTIONS[0]) || questions[2].equals(QUESTIONS[0])) { Toast.makeText(this, "সব ৩টি Security Question নির্বাচন করুন।", Toast.LENGTH_SHORT).show(); return; }
        if (questions[0].equals(questions[1]) || questions[0].equals(questions[2]) || questions[1].equals(questions[2])) { Toast.makeText(this, "৩টি Security Question আলাদা হতে হবে।", Toast.LENGTH_SHORT).show(); return; }
        for (String a : answers) if (a.isEmpty()) { Toast.makeText(this, "৩টি Security Answer-ই দিতে হবে।", Toast.LENGTH_SHORT).show(); return; }

        if (!BackendClient.configured()) { Toast.makeText(this, "Backend URL এখনো সেট করা হয়নি।", Toast.LENGTH_LONG).show(); return; }
        findViewById(R.id.createButton).setEnabled(false);
        BackendClient.register(nameValue,emailValue,mobileValue,password,questions,answers,new BackendClient.Callback(){
            public void onSuccess(org.json.JSONObject data){
                try {
                    org.json.JSONObject u=data.getJSONObject("user");
                    String id=u.optString("userId","");
                    Role role=Role.valueOf(u.optString("role","USER"));
                    SessionManager.setRemoteSession(RegisterActivity.this,data.optString("token",""),role,id);
                    SessionManager.saveProfile(RegisterActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""));
                    Toast.makeText(RegisterActivity.this,"Account created. Your permanent User ID: "+id,Toast.LENGTH_LONG).show();
                    Intent intent=new Intent(RegisterActivity.this,MainActivity.class); intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP); startActivity(intent); finish();
                } catch(Exception e){ Toast.makeText(RegisterActivity.this,"Server response invalid.",Toast.LENGTH_LONG).show(); findViewById(R.id.createButton).setEnabled(true); }
            }
            public void onError(String message){ Toast.makeText(RegisterActivity.this,message,Toast.LENGTH_LONG).show(); findViewById(R.id.createButton).setEnabled(true); }
        });
    }
}
