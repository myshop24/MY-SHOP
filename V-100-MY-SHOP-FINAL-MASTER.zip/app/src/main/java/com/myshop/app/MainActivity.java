package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * V-100 MAIN DASHBOARD
 * Mobile-first layout based on the approved MY SHOP dashboard reference.
 * Existing feature keys/actions are preserved.
 */
public class MainActivity extends AppCompatActivity {
    private static final int DESIGN_WIDTH_DP = 480;
    private static final int BG = Color.rgb(249, 250, 253);
    private static final int TEXT = Color.rgb(30, 32, 44);
    private static final int PURPLE = Color.rgb(91, 35, 214);
    private static final int BLUE = Color.rgb(30, 91, 210);
    private static final int RED = Color.rgb(235, 32, 53);
    private static final long SLIDE_MS = 3500L;

    private final Handler handler = new Handler();
    private int bannerIndex = 0;
    private ImageView hero, ad1, ad2, ad3;
    private TextView dots;

    private final int[] heroSlides = {
            R.drawable.dash_wide, R.drawable.dash_wide, R.drawable.dash_wide,
            R.drawable.dash_wide, R.drawable.dash_wide, R.drawable.dash_wide
    };
    private final int[] ad1Slides = {
            R.drawable.dash_ad1, R.drawable.dash_ad2, R.drawable.dash_ad3,
            R.drawable.dash_ad4, R.drawable.dash_ad5, R.drawable.dash_ad1
    };
    private final int[] ad2Slides = {
            R.drawable.dash_ad2, R.drawable.dash_ad3, R.drawable.dash_ad4,
            R.drawable.dash_ad5, R.drawable.dash_ad1, R.drawable.dash_ad2
    };
    private final int[] ad3Slides = {
            R.drawable.dash_ad3, R.drawable.dash_ad4, R.drawable.dash_ad5,
            R.drawable.dash_ad1, R.drawable.dash_ad2, R.drawable.dash_ad3
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        enableFullscreen();
        try {
            View dashboard = buildDashboard();
            setContentView(dashboard);
            fitDashboardToScreen(dashboard);
            startCarousel();
        } catch (Throwable error) {
            setContentView(buildSafeHome());
        }
    }

    private void enableFullscreen() {
        Window window = getWindow();
        View decor = window.getDecorView();
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.setStatusBarColor(Color.TRANSPARENT);
            window.setNavigationBarColor(Color.TRANSPARENT);
            WindowInsetsController c = window.getInsetsController();
            if (c != null) {
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
            }
        } else {
            decor.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }

    @Override public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) enableFullscreen();
    }

    private void fitDashboardToScreen(final View dashboard) {
        dashboard.post(() -> {
            View parent = dashboard.getParent() instanceof View ? (View) dashboard.getParent() : null;
            if (parent == null || parent.getWidth() <= 0 || parent.getHeight() <= 0) return;
            if (dashboard.getWidth() <= 0 || dashboard.getHeight() <= 0) return;
            float scale = Math.min(parent.getWidth() / (float) dashboard.getWidth(),
                    parent.getHeight() / (float) dashboard.getHeight());
            scale = Math.max(0.55f, Math.min(scale, 1f));
            dashboard.setPivotX(dashboard.getWidth() / 2f);
            dashboard.setPivotY(dashboard.getHeight() / 2f);
            dashboard.setScaleX(scale);
            dashboard.setScaleY(scale);
            dashboard.setTranslationX((parent.getWidth() - dashboard.getWidth() * scale) / 2f);
            dashboard.setTranslationY((parent.getHeight() - dashboard.getHeight() * scale) / 2f);
        });
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private LinearLayout.LayoutParams weight(float w, int h) { return new LinearLayout.LayoutParams(0, h, w); }

    private View buildDashboard() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(10), dp(6), dp(10), dp(5));
        page.setBackgroundColor(BG);

        // Header: menu + MS logo + MY SHOP + search + notification + avatar.
        LinearLayout header = row();
        header.setBackground(round(Color.WHITE, Color.rgb(230, 231, 237), dp(20)));
        Button menu = iconButton("☰", TEXT, 25);
        menu.setBackgroundColor(Color.TRANSPARENT);
        menu.setOnClickListener(v -> startActivity(new Intent(this, AccountActivity.class)));
        header.addView(menu, lp(dp(48), dp(54)));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.myshop_icon);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        header.addView(logo, lp(dp(48), dp(54)));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text("MY SHOP", TEXT, 19, true);
        TextView tagline = text("সবকিছু এক অ্যাপেই ❤️", Color.DKGRAY, 8, false);
        brand.addView(name, lp(-1, dp(27)));
        brand.addView(tagline, lp(-1, dp(17)));
        header.addView(brand, weight(1, dp(54)));

        Button search = iconButton("⌕", TEXT, 28);
        search.setBackgroundColor(Color.TRANSPARENT);
        header.addView(search, lp(dp(42), dp(54)));
        Button bell = iconButton("♧", TEXT, 25);
        bell.setBackgroundColor(Color.TRANSPARENT);
        header.addView(bell, lp(dp(42), dp(54)));
        TextView badge = text("3", Color.WHITE, 8, true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(round(RED, RED, dp(10)));
        FrameLayout bellWrap = new FrameLayout(this);
        bellWrap.addView(badge, new FrameLayout.LayoutParams(dp(17), dp(17), Gravity.TOP | Gravity.END));
        pageHeaderBadge(bellWrap);
        // Keep the actual bell in the header; badge is intentionally small.
        ImageView avatar = new ImageView(this);
        avatar.setImageResource(R.drawable.myshop_icon);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatar.setBackground(round(Color.WHITE, Color.LTGRAY, dp(22)));
        header.addView(avatar, lp(dp(42), dp(42)));
        page.addView(header, lp(-1, dp(60)));

        // Main hero first, exactly as approved reference.
        hero = image(R.drawable.dash_wide);
        page.addView(hero, topMargin(lp(-1, dp(116)), dp(7)));
        dots = text("●   ○   ○   ○   ○   ○", PURPLE, 11, true);
        dots.setGravity(Gravity.CENTER);
        page.addView(dots, lp(-1, dp(22)));

        // Three compact ad cards.
        LinearLayout ads = row();
        ad1 = image(R.drawable.dash_ad1);
        ad2 = image(R.drawable.dash_ad2);
        ad3 = image(R.drawable.dash_ad3);
        ads.addView(ad1, weight(1, dp(86)));
        ads.addView(space(), lp(dp(6), dp(1)));
        ads.addView(ad2, weight(1, dp(86)));
        ads.addView(space(), lp(dp(6), dp(1)));
        ads.addView(ad3, weight(1, dp(86)));
        page.addView(ads, lp(-1, dp(86)));

        // Breaking news.
        TextView breaking = card("🔴  BREAKING NEWS    |    " + breakingText() + "   ☀️   ›", Color.WHITE, TEXT, 11);
        breaking.setSingleLine(true);
        page.addView(breaking, topMargin(lp(-1, dp(45)), dp(7)));

        // Live now heading.
        LinearLayout liveHead = row();
        TextView liveTitle = text("🔴  " + LanguageManager.t(this, "liveNow"), TEXT, 14, true);
        liveHead.addView(liveTitle, weight(1, dp(36)));
        TextView all = text(LanguageManager.t(this, "seeAll") + "  ›", TEXT, 11, true);
        all.setGravity(Gravity.CENTER);
        liveHead.addView(all, lp(dp(70), dp(36)));
        page.addView(liveHead, lp(-1, dp(38)));

        HorizontalScrollView liveScroll = new HorizontalScrollView(this);
        liveScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout liveRow = row();
        int[] liveImages = {R.drawable.dash_live1, R.drawable.dash_live2, R.drawable.dash_live3, R.drawable.dash_live4};
        for (int i = 0; i < 4; i++) {
            ImageView live = image(liveImages[i]);
            live.setOnClickListener(v -> openFeature("LIVE", "live_now"));
            liveRow.addView(live, lp(dp(108), dp(136)));
            if (i < 3) liveRow.addView(space(), lp(dp(6), dp(1)));
        }
        liveScroll.addView(liveRow);
        page.addView(liveScroll, lp(-1, dp(140)));

        // Live / Go Live / My Feed.
        LinearLayout actions = row();
        ImageView liveAction = image(R.drawable.dash_action_live);
        liveAction.setOnClickListener(v -> openFeature("LIVE", "live_now"));
        actions.addView(liveAction, weight(1, dp(78)));
        ImageView go = image(R.drawable.dash_action_go);
        go.setOnClickListener(v -> openFeature("GO LIVE", "go_live"));
        actions.addView(go, lp(dp(122), dp(88)));
        ImageView feed = image(R.drawable.dash_action_feed);
        feed.setOnClickListener(v -> openFeature("MY FEED", "my_feed"));
        actions.addView(feed, weight(1, dp(78)));
        page.addView(actions, lp(-1, dp(94)));

        // Eight feature tiles, 4 x 2.
        addFeatureRow(page, R.drawable.dash_feat_shop, "shop", "my_shop",
                R.drawable.dash_feat_gallery, "gallery", "gallery",
                R.drawable.dash_feat_tv, "tv", "live_tv",
                R.drawable.dash_feat_movie, "movie", "external_movie");
        addFeatureRow(page, R.drawable.dash_feat_social, "social", "social_media",
                R.drawable.dash_feat_reward, "reward", "earn_reward",
                R.drawable.dash_feat_share, "share", "share",
                R.drawable.dash_feat_apps, "apps", "more_apps");

        // Bottom navigation.
        LinearLayout nav = row();
        nav.setBackground(round(Color.WHITE, Color.rgb(229, 230, 236), dp(16)));
        Button home = navButton("⌂\n" + LanguageManager.t(this, "home"), PURPLE);
        Button live = navButton("◉\n" + LanguageManager.t(this, "live"), TEXT);
        Button store = navButton("🛒\n" + LanguageManager.t(this, "store"), PURPLE);
        Button chat = navButton("💬\n" + LanguageManager.t(this, "chat"), TEXT);
        Button more = navButton("▦\n" + LanguageManager.t(this, "more"), TEXT);
        nav.addView(home, weight(1, dp(62)));
        nav.addView(live, weight(1, dp(62)));
        nav.addView(store, weight(1, dp(62)));
        nav.addView(chat, weight(1, dp(62)));
        nav.addView(more, weight(1, dp(62)));
        live.setOnClickListener(v -> openFeature("LIVE", "live_now"));
        store.setOnClickListener(v -> openFeature("MY SHOP", "my_shop"));
        chat.setOnClickListener(v -> openFeature("CHAT", "chat"));
        more.setOnClickListener(v -> startActivity(new Intent(this, AccountActivity.class)));
        page.addView(nav, topMargin(lp(-1, dp(64)), dp(4)));

        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(dp(DESIGN_WIDTH_DP), -2, Gravity.CENTER);
        root.addView(page, fp);
        return root;
    }

    private void pageHeaderBadge(FrameLayout unused) { /* visual badge reserved for future notification overlay */ }

    private LinearLayout.LayoutParams topMargin(LinearLayout.LayoutParams p, int margin) { p.topMargin = margin; return p; }
    private void addFeatureRow(LinearLayout parent, int r1, String d1, String k1, int r2, String d2, String k2,
                               int r3, String d3, String k3, int r4, String d4, String k4) {
        LinearLayout r = row();
        r.addView(tile(r1, d1, k1), weight(1, dp(75)));
        r.addView(space(), lp(dp(5), dp(1)));
        r.addView(tile(r2, d2, k2), weight(1, dp(75)));
        r.addView(space(), lp(dp(5), dp(1)));
        r.addView(tile(r3, d3, k3), weight(1, dp(75)));
        r.addView(space(), lp(dp(5), dp(1)));
        r.addView(tile(r4, d4, k4), weight(1, dp(75)));
        parent.addView(r, lp(-1, dp(80)));
    }

    private ImageView tile(int res, String description, String key) {
        ImageView v = image(res);
        v.setContentDescription(description);
        v.setOnClickListener(x -> openFeature(description, key));
        return v;
    }

    private ImageView image(int res) {
        ImageView v = new ImageView(this);
        v.setImageResource(res);
        v.setScaleType(ImageView.ScaleType.CENTER_CROP);
        v.setBackground(round(Color.WHITE, Color.rgb(231, 232, 238), dp(12)));
        v.setClipToOutline(true);
        return v;
    }

    private View space() { return new View(this); }
    private Button navButton(String label, int color) { return plainButton(label, color, 10); }
    private Button iconButton(String label, int color, float size) { return plainButton(label, color, size); }
    private Button plainButton(String label, int color, float size) {
        Button b = new Button(this);
        b.setText(label); b.setAllCaps(false); b.setGravity(Gravity.CENTER);
        b.setTextColor(color); b.setTextSize(size);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(0, 0, 0, 0);
        b.setBackground(round(Color.WHITE, Color.TRANSPARENT, dp(12)));
        return b;
    }

    private TextView card(String label, int bg, int fg, float size) {
        TextView v = text(label, fg, size, true);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(dp(8), dp(4), dp(8), dp(4));
        v.setBackground(round(bg, Color.rgb(238, 228, 233), dp(13)));
        return v;
    }

    private TextView text(String s, int c, float size, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextColor(c); v.setTextSize(size);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private GradientDrawable round(int fill, int stroke, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill); g.setCornerRadius(radius);
        if (stroke != Color.TRANSPARENT) g.setStroke(dp(1), stroke);
        return g;
    }

    private String breakingText() {
        return LanguageManager.BN.equals(LanguageManager.get(this))
                ? "বাংলাদেশে আজ স্বর্ণের দাম আবার কমলো"
                : "Welcome to MY SHOP";
    }

    private void startCarousel() {
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                bannerIndex = (bannerIndex + 1) % 6;
                hero.setImageResource(heroSlides[bannerIndex]);
                ad1.setImageResource(ad1Slides[bannerIndex]);
                ad2.setImageResource(ad2Slides[bannerIndex]);
                ad3.setImageResource(ad3Slides[bannerIndex]);
                if (dots != null) {
                    StringBuilder s = new StringBuilder();
                    for (int i = 0; i < 6; i++) s.append(i == bannerIndex ? "●" : "○").append(i == 5 ? "" : "  ");
                    dots.setText(s.toString());
                }
                handler.postDelayed(this, SLIDE_MS);
            }
        }, SLIDE_MS);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private void openFeature(String title, String key) {
        try {
            Intent i = new Intent(this, FeatureActivity.class);
            i.putExtra("title", title);
            i.putExtra("feature_key", key);
            startActivity(i);
        } catch (Throwable x) {
            Toast.makeText(this, title + " is ready.", Toast.LENGTH_SHORT).show();
        }
    }

    private View buildSafeHome() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL); r.setGravity(Gravity.CENTER); r.setBackgroundColor(BG);
        TextView t = text("MY SHOP\nHome Dashboard", PURPLE, 26, true); t.setGravity(Gravity.CENTER);
        r.addView(t, lp(-1, -2));
        Button retry = plainButton("OPEN DASHBOARD", BLUE, 15);
        retry.setOnClickListener(v -> recreate());
        r.addView(retry, lp(-1, dp(64)));
        return r;
    }
}
