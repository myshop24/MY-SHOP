# MY SHOP V-636 / 2.9.636 — developer handoff

Continue this source. Base: immutable delivered V-635. Source implementation checkpoint; full Android build, phone visuals and production deployment are not verified. Next changed delivery V-637. Latest owner instructions override historical AGENTS entries.

## Numbered phase 2 implementation
1. V635 source and runtime asset preservation; historical nonbuild logs only excluded per verification/V636-CLEANUP.json.
2. Story owner edit/delete, server drafts/reopen/publish/delete, revision conflict guard and separate Admin deletion. Blue top action ➤ Post stays above preview; Save Changes for existing published story; upload failures restore action and never show false success. Rail refresh60sec, opened story state refresh10sec; backend confirms permissions/expiry/deletion. Edit preserves original published expiry. A rendered image's burned-in text is not a non-destructive editable layer after reopening. Draft listing currently capped100.
3. Admin IDs0001/0002/0003 live first.
4. Session-bound Admin pins then membership: King=Queen > Royal > VVIP > VIP > Normal. Within equal rank, current host Coin descending, fresh unique viewers descending, started time ascending and UID deterministic fallback.
5. Inactive hosts/stale pins/expired memberships excluded; touch guard delays list movement. RTC/audio routes retained.
6. Alternating visible pink/cyan ring brightness with fixed black center and camera; reduced-animation static fallback.
7. Shared existing header/nav on Store/Help/Inbox plus existing shared screens; scroll down hides bottom/up shows. Individual chat composer/RTC layout not replaced. Device acceptance pending.
8. Larger aligned Myshop shared title.
9. Colored separated Admin dashboard sections1–7, readable cards, fixed Admin header/search.
10. Clear pending counts vs unread badges, route to canonical request folders; server mutations update revision.
11. Home previews capped3 transactions and3 Admin actions; full history available in reports.
12. Existing authorized persisted VisualDesign editor extended to dashboard; background/text/style controls and cached repaint across refresh.
13. BN/EN labels expanded across app and Admin. Exhaustive whole-app localization NOT proven; see V636-localization.json. Do not label full language acceptance complete.
14. Separate Coin/Diamond receipts/commissions/store redemption and market/Admin wallet balances; store redemption not double counted as commission. Authoritative net profit and office stock remain UNVERIFIED where expense/source accounting is missing. Legacy physical-product accounting remains explicitly scoped BDT; no invented conversion or zero net-profit claim.
15. User/activity/live lists with pagination, observed last-active and365-day absence; missing activity history listed unknown, never fabricated inactive365.
16. Own active sessions localized; owner-only revoke preserved.
17. Change-triggered presence revision, covering read indexes and60sec full-dashboard fallback. Production D1 cost reduction not measured.
18.488 asset/design files audited; no unproven runtime image deletions. Cleanup manifest documents excluded historical logs.
19. Original Agent/My Links/What's New/Safety & Privacy/Share menu restored via existing routes.
20. Full versioned source ZIP with original workflow/signing configuration and additional source checks. No APK bundled; GitHub Android build must succeed before APK availability.

## Evidence and limitations
86 inherited root regression tests passed. Focused SQLite Story/priority/activity/finance and baseline V634 behavior, lock and exact V635 compiler regression pass. Java source parsing/callback/lambda-scope checks pass; these are not Android typechecking. Relevant Live behavior suites pass separately. See verification logs. Local assembleRelease blocked downloading Gradle8.11.1 (Network unreachable); no signed APK, phone reference parity, live deployment, or global localization/profit acceptance claimed.

## Deferred V637 discussion
New Home/Profile/menu redesign, consolidated shortcuts, merged Reels UI, comprehensive Moon/heading exemption and scheduled physical removal of expired Stories remain deferred. Manual delete in V636 queues safe media cleanup;24h visibility expiry preserved. Do not mix proposed redesign into this delivery.

## GitHub
Read GITHUB-UPLOAD-V636-BN.md. Preserve existing root permanent pipeline, Cloudflare target, signing keys and Secrets. Upload ZIP unchanged; inspect selected version and exact commit. No new signing key or automatic production deployment performed by this editing session.
