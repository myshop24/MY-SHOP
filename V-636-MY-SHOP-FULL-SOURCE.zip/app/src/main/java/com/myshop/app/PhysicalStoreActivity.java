package com.myshop.app;

import android.view.Gravity;
import android.view.View;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.Intent;
import android.widget.*;
import org.json.*;
import java.util.UUID;

/** Physical goods only: BDT and COD. Premium remains in StoreActivity. */
public class PhysicalStoreActivity extends androidx.appcompat.app.AppCompatActivity {
 private AdminImagePicker imagePicker;
 private PeekBannerCarousel shopCarousel,shopPromoCarousel;private FrameLayout shopBannerBox,shopPromoBox;private TextView shopBannerEmpty,shopPromoEmpty;private final java.util.ArrayList<JSONObject> shopBanners=new java.util.ArrayList<>(),shopPromoBanners=new java.util.ArrayList<>();private final android.os.Handler bannerHandler=new android.os.Handler(android.os.Looper.getMainLooper());private boolean bannerVisible=false;
 private final Runnable shopTick=new Runnable(){public void run(){if(!bannerVisible)return;if(shopCarousel!=null&&shopBanners.size()>1)shopCarousel.move(true);bannerHandler.postDelayed(this,5000);}};
 private final Runnable shopPromoTick=new Runnable(){public void run(){if(!bannerVisible)return;if(shopPromoCarousel!=null&&shopPromoBanners.size()>1)shopPromoCarousel.move(true);bannerHandler.postDelayed(this,5000);}};

 private LinearLayout root,content,designBody; private EditText search; private JSONArray products=new JSONArray();
 private long minimum=0,maximum=Long.MAX_VALUE;private boolean inStock=false;private long cartTotal=0;
 private boolean admin=false; private String requestKey="",query=""; private int folder=0;
 private interface Result {void done(JSONObject x);}
 private JSONObject obj(Object... pairs){JSONObject o=new JSONObject();try{for(int i=0;i<pairs.length;i+=2)o.put(String.valueOf(pairs[i]),pairs[i+1]);}catch(Exception e){throw new IllegalArgumentException(e);}return o;}
 private void api(String path,JSONObject data,Result done){BackendClient.commerce(path,data,SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject x){if(!isFinishing()){done.done(x);refreshDesign();}}public void onError(String m){if(!isFinishing())new MyShopDialogBuilder(PhysicalStoreActivity.this).setTitle("Store request failed").setMessage(m).setPositiveButton("OK",null).show();}});}
 private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
 private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
 private TextView text(String s,float size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(0xff172347);t.setPadding(dp(6),dp(5),dp(6),dp(5));return t;}
 private void button(LinearLayout box,String s,Runnable run){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->run.run());box.addView(b);}
 private EditText field(LinearLayout box,String hint,String value,boolean numeric){EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setTextColor(0xff172347);if(numeric)e.setInputType(8194);box.addView(e);return e;}
 private String money(long p){return String.format(java.util.Locale.US,"৳%.2f",p/100.0);}
 private TextView t(String s,float size,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
 private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
 private LinearLayout.LayoutParams wt(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}
 private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}
 @Override protected void onCreate(Bundle state){
  super.onCreate(state);
  requestKey=getSharedPreferences("store_checkout_"+SessionManager.getUserId(this),MODE_PRIVATE).getString("key","");
  folder=getIntent().getIntExtra("folder",0);
  if(getIntent().getData()==null)WatchHistoryActivity.record(this,"SHOP","MY SHOP Store","Physical products • Cash on Delivery","shop:main","","Visit Shop");
  admin=SessionManager.isAdmin(this)&&getIntent().getBooleanExtra("admin",false);
  root=col();
  root.setBackgroundColor(0xfff5f8ff);
  root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop()+dp(8),insets.getSystemWindowInsetRight(),Math.max(0,insets.getSystemWindowInsetBottom()-dp(6)));return insets;});
  root.addView(storeHeader(),new LinearLayout.LayoutParams(-1,dp(58)));
  ScrollView scrollView=new ScrollView(this);
  scrollView.setFillViewport(true);
  scrollView.setVerticalScrollBarEnabled(false);
  LinearLayout body=col();
  body.setPadding(dp(9),dp(8),dp(9),dp(24));
  body.setBackgroundColor(0xfff5f8ff);
  body.addView(storeHero(),lp(-1,Math.round((getResources().getDisplayMetrics().widthPixels-dp(28))*.84f*5f/12f)));
  body.addView(storePromoHero(),top(lp(-1,dp(104)),6));
  body.addView(storeSearch(),top(lp(-1,dp(42)),7));
  body.addView(serviceStrip(),top(lp(-1,dp(38)),6));
  body.addView(storeQuickActions(),top(lp(-1,dp(70)),6));
  body.addView(voucherStrip(),top(lp(-1,dp(58)),7));
  HorizontalScrollView toolsScroll=new HorizontalScrollView(this);
  toolsScroll.setHorizontalScrollBarEnabled(false);
  LinearLayout tools=row();
  addToolChip(tools,"Products",()->{admin=false;folder=0;load();});
  addToolChip(tools,"Cart",this::cart);
  addToolChip(tools,"Orders",this::orders);
  addToolChip(tools,"Wishlist",this::saved);
  addToolChip(tools,"Updates",this::notices);
  addToolChip(tools,"Filters",this::filters);
  addToolChip(tools,"Premium",()->startActivity(new Intent(this,StoreActivity.class)));
  if(SessionManager.isAdmin(this)){
    addToolChip(tools,"Admin",()->{admin=true;folder=0;load();});
  }
  toolsScroll.addView(tools);
  body.addView(toolsScroll,top(lp(-1,dp(40)),7));
  TextView heading=text("Featured Products",18);
  heading.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
  heading.setTextColor(0xff162b62);
  body.addView(heading,top(lp(-1,dp(28)),5));
  content=col();
  body.addView(content,lp(-1,-2));
  scrollView.addView(body,new ScrollView.LayoutParams(-1,-2));
  root.addView(scrollView,new LinearLayout.LayoutParams(-1,0,1));
  root.addView(storeBottom(),lp(-1,dp(78)));
  designBody=body;PanelDesign.apply(this,body,"shop");PanelDesign.adminButton(this,body,"shop");setContentView(root);
        MiniAdOverlay.install(this,"shop");
        MiniHeadlineOverlay.install(this,"shop");
  root.requestApplyInsets();
  load();
 }
 private View storeHeader(){return new SharedPageHeader(this);}
 private View storeHero(){
  shopBannerBox=new FrameLayout(this);shopBannerBox.setClipChildren(true);shopCarousel=new PeekBannerCarousel(this);shopCarousel.setListener(new PeekBannerCarousel.Listener(){public void onIndexChanged(int i){}public void onTap(int i){if(SessionManager.isAdmin(PhysicalStoreActivity.this)){manageShopBanners();return;}if(i<shopBanners.size()){String url=shopBanners.get(i).optString("target_url","");if(FeatureRegistry.isSafeHttpUrl(url))startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url)));}}public void onHold(){if(SessionManager.isAdmin(PhysicalStoreActivity.this))manageShopBanners();}public void onTouching(boolean active){bannerHandler.removeCallbacks(shopTick);if(!active&&bannerVisible)bannerHandler.postDelayed(shopTick,5000);}});shopBannerBox.addView(shopCarousel,new FrameLayout.LayoutParams(-1,-1));shopBannerEmpty=t("Advertising · Tap to manage",11,0xff667087,false);shopBannerEmpty.setGravity(Gravity.CENTER);shopBannerEmpty.setVisibility(View.GONE);shopBannerEmpty.setOnClickListener(v->{if(SessionManager.isAdmin(this))manageShopBanners();});shopBannerBox.addView(shopBannerEmpty,new FrameLayout.LayoutParams(-1,-1));return shopBannerBox;
 }
 private View storePromoHero(){
  shopPromoBox=new FrameLayout(this);shopPromoBox.setClipChildren(true);shopPromoCarousel=new PeekBannerCarousel(this);shopPromoCarousel.setListener(new PeekBannerCarousel.Listener(){public void onIndexChanged(int i){}public void onTap(int i){if(SessionManager.isAdmin(PhysicalStoreActivity.this)){manageShopPromoBanners();return;}if(i<shopPromoBanners.size()){String url=shopPromoBanners.get(i).optString("target_url","");if(FeatureRegistry.isSafeHttpUrl(url))startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(url)));}}public void onHold(){if(SessionManager.isAdmin(PhysicalStoreActivity.this))manageShopPromoBanners();}public void onTouching(boolean active){bannerHandler.removeCallbacks(shopPromoTick);if(!active&&bannerVisible)bannerHandler.postDelayed(shopPromoTick,5000);}});shopPromoBox.addView(shopPromoCarousel,new FrameLayout.LayoutParams(-1,-1));shopPromoEmpty=t("Shop promotions · Tap to manage",10,0xff667087,false);shopPromoEmpty.setGravity(Gravity.CENTER);shopPromoEmpty.setVisibility(View.GONE);shopPromoEmpty.setOnClickListener(v->{if(SessionManager.isAdmin(PhysicalStoreActivity.this))manageShopPromoBanners();});shopPromoBox.addView(shopPromoEmpty,new FrameLayout.LayoutParams(-1,-1));return shopPromoBox;
 }
 private void manageShopPromoBanners(){startActivity(new Intent(this,LiveHomeAdminActivity.class).putExtra("folder","shop_promo").putExtra("folderTitle","Shop Promotion Banners"));}
 private void loadShopPromoBanners(){BackendClient.bannerFolder(SessionManager.getToken(this),"shop_promo",new BackendClient.Callback(){public void onSuccess(JSONObject data){runOnUiThread(()->{if(isFinishing())return;shopPromoBanners.clear();JSONArray a=data.optJSONArray("banners");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&x.optInt("active",1)==1&&!x.optString("image_url","").isEmpty())shopPromoBanners.add(x);}shopPromoCarousel.setData(shopPromoBanners.size(),0,(view,index)->SafeImageLoader.load(view,shopPromoBanners.get(index).optString("image_url","")));boolean enabled=data.optBoolean("sectionEnabled",true);shopPromoEmpty.setVisibility(enabled&&shopPromoBanners.isEmpty()&&SessionManager.isAdmin(PhysicalStoreActivity.this)?View.VISIBLE:View.GONE);android.view.ViewGroup.LayoutParams lp=shopPromoBox.getLayoutParams();lp.height=!enabled?0:shopPromoBanners.isEmpty()?(SessionManager.isAdmin(PhysicalStoreActivity.this)?dp(38):0):dp(104);shopPromoBox.setLayoutParams(lp);});}public void onError(String e){runOnUiThread(()->{if(shopPromoBanners.isEmpty()&&SessionManager.isAdmin(PhysicalStoreActivity.this)){shopPromoEmpty.setVisibility(View.VISIBLE);shopPromoEmpty.setText("Promotion banners unavailable · Tap to retry");shopPromoEmpty.setOnClickListener(v->loadShopPromoBanners());}});}});}
 private void manageShopBanners(){startActivity(new Intent(this,LiveHomeAdminActivity.class).putExtra("folder","shop_home").putExtra("folderTitle","Shop Advertising Banners"));}
 private void loadShopBanners(){BackendClient.bannerFolder(SessionManager.getToken(this),"shop_home",new BackendClient.Callback(){public void onSuccess(JSONObject data){runOnUiThread(()->{if(isFinishing())return;shopBannerEmpty.setText("Advertising · Tap to manage");shopBannerEmpty.setOnClickListener(v->{if(SessionManager.isAdmin(PhysicalStoreActivity.this))manageShopBanners();});shopBanners.clear();JSONArray a=data.optJSONArray("banners");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&x.optInt("active",1)==1&&!x.optString("image_url","").isEmpty())shopBanners.add(x);}shopCarousel.setData(shopBanners.size(),0,(view,index)->SafeImageLoader.load(view,shopBanners.get(index).optString("image_url","")));boolean enabled=data.optBoolean("sectionEnabled",true);shopBannerEmpty.setVisibility(enabled&&shopBanners.isEmpty()&&SessionManager.isAdmin(PhysicalStoreActivity.this)?View.VISIBLE:View.GONE);android.view.ViewGroup.LayoutParams lp=shopBannerBox.getLayoutParams();lp.height=!enabled?0:shopBanners.isEmpty()?(SessionManager.isAdmin(PhysicalStoreActivity.this)?dp(44):0):dp(128);shopBannerBox.setLayoutParams(lp);});}public void onError(String m){runOnUiThread(()->{if(shopBanners.isEmpty()){shopBannerEmpty.setText("Banner unavailable · Tap to retry");shopBannerEmpty.setVisibility(View.VISIBLE);shopBannerEmpty.setOnClickListener(v->loadShopBanners());}});}});}
 private View storeBottom(){LinearLayout nav=row();nav.setClipChildren(false);nav.setBackgroundColor(Color.WHITE);String[] keys={"home","store","live","support","more"},labels={"Home","myshop","Live","Support","More Apps"};int[] icons={R.drawable.nav_home,R.drawable.nav_store,R.drawable.nav_live,R.drawable.nav_support,R.drawable.nav_more540},colors={0xff1470f7,0xffc99516,0xffda145b,0xff07b991,0xff7e25ee};for(int i=0;i<5;i++){final int item=i;nav.addView(SharedPageNav.item(this,icons[i],labels[i],i==1,keys[i],colors[i],v->{if(item==0){startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));finish();}else if(item==1){folder=0;admin=false;load();}else if(item==2)startActivity(new Intent(this,LiveHomeActivity.class));else if(item==3)startActivity(new Intent(this,HelpCenterActivity.class));else startActivity(new Intent(this,MainActivity.class).putExtra("openMoreApps",true).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));}),wt(1,dp(76)));}return nav;}
 @Override protected void onResume(){super.onResume();bannerVisible=true;if(shopCarousel!=null)loadShopBanners();if(shopPromoCarousel!=null)loadShopPromoBanners();bannerHandler.removeCallbacks(shopTick);bannerHandler.removeCallbacks(shopPromoTick);bannerHandler.postDelayed(shopTick,5000);bannerHandler.postDelayed(shopPromoTick,5000);}
 @Override protected void onPause(){bannerVisible=false;bannerHandler.removeCallbacks(shopTick);bannerHandler.removeCallbacks(shopPromoTick);super.onPause();}

 private View storeSearch(){
  search=new EditText(this);search.setSingleLine(true);search.setTextSize(10.2f);search.setTextColor(0xff17316f);search.setHintTextColor(0xff7c8baa);search.setHint("Search products, brands & shops...");search.setPadding(dp(13),0,dp(10),0);search.setBackground(PremiumUi.solid(this,Color.WHITE,14,0xff91e9ff,1));search.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);search.setOnEditorActionListener((v,a,e)->{query=search.getText().toString().trim().toLowerCase(java.util.Locale.ROOT);renderProducts();return true;});return search;
 }
 private View serviceStrip(){
  LinearLayout r=row();String[] labels={"🚚  Free Shipping","🛡  Secure Payment","↻  Easy Return","✓  Buyer Protection"};
  for(int i=0;i<labels.length;i++){TextView x=t(labels[i],7.2f,0xff16366f,true);x.setGravity(Gravity.CENTER);x.setSingleLine(true);x.setBackground(PremiumUi.solid(this,0xffe0faff,9,0xffb9efff,1));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(36),1);if(i>0)p.leftMargin=dp(4);r.addView(x,p);}return r;
 }
 private View storeQuickActions(){
  LinearLayout r=row();String[] labels={"Coupons","Flash Sale","Premium Shop","Live Shopping","Rewards","Categories"};int[] icons={R.drawable.premium438_tag,R.drawable.premium438_fire,R.drawable.premium438_crown,R.drawable.premium438_live,R.drawable.premium438_gift,R.drawable.premium438_more};
  for(int i=0;i<labels.length;i++){final int n=i;LinearLayout c=col();c.setGravity(Gravity.CENTER);c.setPadding(dp(2),dp(3),dp(2),dp(2));ImageView iv=new ImageView(this);PremiumArt.apply(iv,icons[i]);iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);c.addView(iv,lp(dp(24),dp(28)));TextView tx=t(labels[i],7.1f,0xff263a7a,true);tx.setGravity(Gravity.CENTER);tx.setSingleLine(false);tx.setMaxLines(2);c.addView(tx,lp(-1,dp(25)));PremiumUi.premiumButton(c,new int[]{0xffffffff,0xfff2f5ff},12,0xffd3dcf6,3);c.setOnClickListener(v->{switch(n){case 0:showCoupons();break;case 1:folder=1;admin=false;load();break;case 2:startActivity(new Intent(this,StoreActivity.class));break;case 3:startActivity(new Intent(this,LiveHomeActivity.class));break;case 4:{Intent i4=new Intent(this,FeatureActivity.class);i4.putExtra("title","EARN & REWARD");i4.putExtra("feature_key","earn_reward");startActivity(i4);break;}case 5:showCategories();break;}});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(68),1);if(i>0)p.leftMargin=dp(4);r.addView(c,p);}return r;
 }
 private View voucherStrip(){
  LinearLayout r=row();String[] labels={"Daily Voucher","Shop Voucher","Free Delivery","Limited Offer"};int[] fills={0xffffefbe,0xffdcffe5,0xffd9f5ff,0xffffdff5};
  for(int i=0;i<labels.length;i++){final int n=i;LinearLayout c=col();c.setPadding(dp(7),dp(5),dp(5),dp(4));c.setBackground(PremiumUi.solid(this,fills[i],10,0xffffffff,1));TextView title=t(labels[i],7.3f,0xff173166,true);c.addView(title,lp(-1,dp(17)));TextView act=t("View offers  ›",6.8f,0xff245ee7,true);act.setSingleLine(true);c.addView(act,lp(-1,dp(16)));c.setOnClickListener(v->{folder=n+1;admin=false;load();});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(54),1);if(i>0)p.leftMargin=dp(4);r.addView(c,p);}return r;
 }
 private void addToolChip(LinearLayout tools,String label,Runnable run){TextView x=t(label,8.1f,0xff214184,true);x.setGravity(Gravity.CENTER);x.setSingleLine(true);x.setPadding(dp(10),0,dp(10),0);x.setBackground(PremiumUi.solid(this,Color.WHITE,14,0xffd6def4,1));x.setOnClickListener(v->run.run());LinearLayout.LayoutParams p=lp(-2,dp(36));p.rightMargin=dp(5);tools.addView(x,p);}
 private void load(){api(admin?"admin/products":"products",null,x->{products=x.optJSONArray("products");if(products==null)products=new JSONArray();if(folder>0&&!admin)loadFolder();else renderProducts();String catalog=getIntent().getStringExtra("catalog_folder");if(catalog!=null){getIntent().removeExtra("catalog_folder");if(catalog.equals("categories")){showCategories();return;}if(catalog.equals("offers")){promo();return;}if(catalog.equals("stock")||catalog.equals("approval")){inventoryPanel(catalog.equals("approval"));return;}}if(getIntent().getBooleanExtra("openOrders",false)){getIntent().removeExtra("openOrders");orders();return;}if(getIntent().getData()!=null){String id=getIntent().getData().getLastPathSegment();for(int i=0;i<products.length();i++){JSONObject p=products.optJSONObject(i);if(p!=null&&String.valueOf(p.optLong("id")).equals(id)){details(p);break;}}getIntent().setData(null);}});}
 private void loadFolder(){api("promos",null,x->{content.removeAllViews();LinearLayout track=new LinearLayout(this);HorizontalScrollView hs=new HorizontalScrollView(this);hs.addView(track);content.addView(hs);JSONArray a=x.optJSONArray("promos");int count=0;if(a!=null)for(int i=0;i<a.length();i++){JSONObject promo=a.optJSONObject(i);if(promo==null||promo.optInt("folder")!=folder)continue;for(int j=0;j<products.length();j++){JSONObject p=products.optJSONObject(j);if(p==null||p.optLong("id")!=promo.optLong("product_id"))continue;count++;LinearLayout c=col();ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.FIT_CENTER);AnimatedAssetLoader.load(im,p.optString("image_url"),false);c.addView(im,new LinearLayout.LayoutParams(-1,dp(140)));c.addView(text(p.optString("title")+" · "+money(p.optLong("effective_price")),17));button(c,"View product",()->details(p));track.addView(c,new LinearLayout.LayoutParams(dp(220),-2));}}content.addView(text(count+" / 4 products",14));if(admin)button(content,"Manage promotions",()->promo());});}
 private void refreshDesign(){if(designBody!=null)PanelDesign.paint(designBody,PanelDesign.cached(this,"shop"));}
 private void renderProducts(){
  if(content!=null)content.post(this::refreshDesign);
  content.removeAllViews();
  if(admin){
    LinearLayout adminBar=row();
    TextView add=t("＋ Add Product",8.3f,Color.WHITE,true);add.setGravity(Gravity.CENTER);add.setBackground(PremiumUi.gradient(this,new int[]{0xff1f6cf1,0xff7c3de9},12,0xffd9eeff,1));add.setOnClickListener(v->edit(new JSONObject()));adminBar.addView(add,wt(1,dp(36)));
    TextView ord=t("Orders",8.3f,0xff24427f,true);ord.setGravity(Gravity.CENTER);ord.setBackground(PremiumUi.solid(this,Color.WHITE,12,0xffd5def3,1));ord.setOnClickListener(v->orders());adminBar.addView(ord,lp(dp(78),dp(36)));
    TextView ana=t("Analytics",8.3f,0xff24427f,true);ana.setGravity(Gravity.CENTER);ana.setBackground(PremiumUi.solid(this,Color.WHITE,12,0xffd5def3,1));ana.setOnClickListener(v->analytics());LinearLayout.LayoutParams ap=lp(dp(78),dp(36));ap.leftMargin=dp(5);adminBar.addView(ana,ap);
    content.addView(adminBar);
  }
  if(products.length()==0){TextView empty=text("No published products yet",14);empty.setGravity(Gravity.CENTER);content.addView(empty,top(lp(-1,dp(100)),12));return;}
  LinearLayout row=null;int shown=0;
  for(int i=0;i<products.length();i++){JSONObject p=products.optJSONObject(i);if(p==null)continue;long value=p.optLong("effective_price",p.optLong("price"));if(value<minimum||value>maximum||(inStock&&p.optInt("stock")==0))continue;if(!query.isEmpty()&&!(p.optString("title")+" "+p.optString("category")+" "+p.optString("description")).toLowerCase(java.util.Locale.ROOT).contains(query))continue;
    if(shown%2==0){row=row();content.addView(row,top(lp(-1,-2),shown==0?3:7));}
    row.addView(storeProductCard(p),wt(1,dp(258)));if(shown%2==0){LinearLayout.LayoutParams rp=(LinearLayout.LayoutParams)row.getChildAt(row.getChildCount()-1).getLayoutParams();}shown++;
  }
  if(row!=null&&shown%2==1)row.addView(new Space(this),wt(1,dp(250)));
  if(shown==0){TextView empty=text("No products match your search or filters.",13);empty.setGravity(Gravity.CENTER);content.addView(empty,top(lp(-1,dp(90)),12));}
 }
 private View storeProductCard(JSONObject p){
  LinearLayout card=col();card.setPadding(dp(6),dp(7),dp(6),dp(7));card.setBackground(PremiumUi.solid(this,Color.WHITE,16,0xffdce4f8,1));PremiumUi.premiumElevation(card,2);
  FrameLayout imageBox=new FrameLayout(this);imageBox.setBackground(PremiumUi.gradient(this,new int[]{0xffeef5ff,0xfffff0fb},13,0xffdbe6f9,1));ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.CENTER_CROP);if(!p.optString("image_url").isEmpty())AnimatedAssetLoader.load(image,p.optString("image_url"),false);else image.setImageResource(R.drawable.myshop_profile_avatar);imageBox.addView(image,new FrameLayout.LayoutParams(-1,-1));
  TextView sale=t(p.optInt("offer_end")>System.currentTimeMillis()?"SALE":"",7,Color.WHITE,true);sale.setGravity(Gravity.CENTER);sale.setBackground(PremiumUi.solid(this,0xffff3d75,7,0xffffffff,1));FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(38),dp(17),Gravity.TOP|Gravity.RIGHT);sp.rightMargin=dp(4);sp.topMargin=dp(4);imageBox.addView(sale,sp);card.addView(imageBox,lp(-1,dp(132)));
  TextView nm=text(p.optString("title","Product"),10.2f);nm.setTypeface(Typeface.DEFAULT,Typeface.BOLD);nm.setTextColor(0xff162b62);nm.setMaxLines(2);card.addView(nm,top(lp(-1,dp(34)),5));
  TextView price=text(money(p.optLong("effective_price",p.optLong("price"))),12.5f);price.setTypeface(Typeface.DEFAULT,Typeface.BOLD);price.setTextColor(0xffec2f62);price.setSingleLine(true);card.addView(price,lp(-1,dp(22)));
  TextView meta=text("★ 4.8  •  "+(p.optInt("stock")>0?p.optInt("stock")+" in stock":"Sold out"),7.4f);meta.setTextColor(0xff6e7e9d);meta.setSingleLine(true);card.addView(meta,lp(-1,dp(17)));
  TextView buy=t("Details / Buy Now",8.1f,Color.WHITE,true);buy.setGravity(Gravity.CENTER);buy.setBackground(PremiumUi.gradient(this,new int[]{0xfff33b67,0xffff8c2d},10,0xffffd9c7,1));buy.setOnClickListener(v->details(p));card.addView(buy,top(lp(-1,dp(30)),5));
  if(!admin){TextView watch=t("♡ Watch price",7.1f,0xff315ca9,true);watch.setGravity(Gravity.CENTER);watch.setOnClickListener(v->api("saved",obj("product_id",p.optLong("id"),"kind","PRICE"),x->Toast.makeText(this,"Price-drop alert enabled",Toast.LENGTH_SHORT).show()));card.addView(watch,lp(-1,dp(18)));}
  else {TextView edit=t("Edit / Delete",7.1f,0xff6b3ad8,true);edit.setGravity(Gravity.CENTER);edit.setOnClickListener(v->edit(p));card.addView(edit,lp(-1,dp(18)));}
  return card;
 }
 private void showCoupons(){
  api("promos",null,x->{JSONArray a=x.optJSONArray("promos");LinearLayout box=col();box.setPadding(dp(8),dp(8),dp(8),dp(8));int count=0;if(a!=null)for(int i=0;i<a.length();i++){JSONObject q=a.optJSONObject(i);if(q==null)continue;count++;TextView c=t("🎟  OFFER · Folder "+q.optInt("folder")+" · Slot "+q.optInt("slot"),10,0xff173166,true);c.setPadding(dp(8),dp(8),dp(8),dp(8));c.setBackground(PremiumUi.solid(this,0xfffff3cf,10,0xffffd66b,1));box.addView(c,top(lp(-1,dp(36)),4));}if(count==0)box.addView(text("No published coupons/offers yet.",12),lp(-1,dp(50)));ScrollView sv=new ScrollView(this);sv.addView(box);new MyShopDialogBuilder(this).setTitle("Coupons & Offers").setView(sv).setNegativeButton(UiStrings.label(PhysicalStoreActivity.this,"Close"),null).show();});
 }
 private void showCategories(){
  java.util.LinkedHashSet<String> set=new java.util.LinkedHashSet<>();for(int i=0;i<products.length();i++){JSONObject p=products.optJSONObject(i);if(p!=null&&!p.optString("category").trim().isEmpty())set.add(p.optString("category").trim());}
  String[] cats=set.toArray(new String[0]);if(cats.length==0){new MyShopDialogBuilder(this).setTitle("Categories").setMessage("No product categories published yet.").setPositiveButton("OK",null).show();return;}
  new MyShopDialogBuilder(this).setTitle("Categories").setItems(cats,(d,w)->{query=cats[w].toLowerCase(java.util.Locale.ROOT);if(search!=null)search.setText(cats[w]);renderProducts();}).show();
 }
 private void details(JSONObject p){WatchHistoryActivity.record(this,"PRODUCT",p.optString("title","Product"),money(p.optLong("effective_price",p.optLong("price")))+" • MY SHOP Store","product:"+p.optLong("id"),p.optString("image_url",""),"View Product");api("click",obj("product_id",p.optLong("id"),"folder",folder),r->{});LinearLayout b=col();b.addView(text(p.optString("description"),15));b.addView(text("Price: "+money(p.optLong("effective_price",p.optLong("price")))+"\nPayment: Cash on Delivery\nDelivery charge: ৳0",16));button(b,"Add to Cart",()->api("cart",obj("product_id",p.optLong("id"),"qty",1),x->Toast.makeText(this,"Added to cart",Toast.LENGTH_SHORT).show()));button(b,"Save to Wishlist",()->api("saved",obj("product_id",p.optLong("id"),"kind","WISH"),x->Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show()));if(p.optLong("offer_end")>System.currentTimeMillis()){TextView timer=text("",14);b.addView(timer);android.os.CountDownTimer clock=new android.os.CountDownTimer(p.optLong("offer_end")-System.currentTimeMillis(),1000){public void onTick(long ms){timer.setText("Offer ends in "+(ms/3600000)+"h "+((ms/60000)%60)+"m "+((ms/1000)%60)+"s");}public void onFinish(){timer.setText("Offer ended · refresh price");}};timer.addOnAttachStateChangeListener(new android.view.View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(android.view.View v){clock.start();}public void onViewDetachedFromWindow(android.view.View v){clock.cancel();}});}button(b,"Verified buyer reviews",()->reviews(p));button(b,"Share product",()->{Intent share=new Intent(Intent.ACTION_SEND);share.setType("text/plain");share.putExtra(Intent.EXTRA_TEXT,p.optString("title")+" · "+money(p.optLong("effective_price",p.optLong("price")))+"\n"+BuildConfig.MYSHOP_BACKEND_URL+"/shop/product/"+p.optLong("id"));startActivity(Intent.createChooser(share,"Share product"));});if(p.optInt("stock")==0)button(b,"Notify when back in stock",()->api("saved",obj("product_id",p.optLong("id"),"kind","STOCK"),r->Toast.makeText(this,"Watch saved · check Store Updates",Toast.LENGTH_SHORT).show()));new MyShopDialogBuilder(this).setTitle(p.optString("title")).setView(b).setNegativeButton(UiStrings.label(PhysicalStoreActivity.this,"Close"),null).show();}
 private void cart(){admin=false;api("cart",null,x->{content.removeAllViews();JSONArray a=x.optJSONArray("items");long total=0;if(a!=null)for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p==null)continue;total+=p.optLong("effective_price")*p.optInt("qty");content.addView(text(p.optString("title")+" × "+p.optInt("qty")+" · "+money(p.optLong("effective_price")*p.optInt("qty")),17));button(content,"Change quantity / remove",()->{EditText q=new EditText(this);q.setInputType(2);q.setText(""+p.optInt("qty"));new MyShopDialogBuilder(this).setTitle("Quantity (0 = remove)").setView(q).setPositiveButton(UiStrings.label(PhysicalStoreActivity.this,"Save"),(d,w)->{try{api("cart",obj("product_id",p.optLong("id"),"qty",Integer.parseInt(q.getText().toString())),r->cart());}catch(Exception e){Toast.makeText(this,"Enter 0–99",Toast.LENGTH_SHORT).show();}}).setNegativeButton(UiStrings.label(PhysicalStoreActivity.this,"Cancel"),null).show();});}cartTotal=total;content.addView(text("Total: "+money(total)+" · Delivery: ৳0",20));if(a!=null&&a.length()>0)button(content,"Checkout · COD",()->checkout());});}
 private void checkout(){LinearLayout b=col();b.addView(text("Confirm total: "+money(cartTotal),20));EditText name=field(b,"Recipient name","",false),phone=field(b,"Phone","",false),address=field(b,"Full delivery address","",false);b.addView(text("Cash on Delivery. Delivery charge ৳0. Pay the order total on delivery.",14));new MyShopDialogBuilder(this).setTitle("Confirm order").setView(b).setNegativeButton(UiStrings.label(PhysicalStoreActivity.this,"Cancel"),null).setPositiveButton("Place order",(d,w)->{if(requestKey.isEmpty()){requestKey=UUID.randomUUID().toString();getSharedPreferences("store_checkout_"+SessionManager.getUserId(this),MODE_PRIVATE).edit().putString("key",requestKey).apply();}api("checkout",obj("request_key",requestKey,"expected_total",cartTotal,"address",obj("name",name.getText().toString(),"phone",phone.getText().toString(),"address",address.getText().toString())),x->{requestKey="";getSharedPreferences("store_checkout_"+SessionManager.getUserId(this),MODE_PRIVATE).edit().remove("key").apply();orders();});}).show();}
 private void inventoryPanel(boolean approval){content.removeAllViews();content.addView(text(approval?"পণ্য অনুমোদন • Publish / Unpublish":"স্টক ব্যবস্থাপনা",20));content.addView(text("পণ্য চাপলে তার বর্তমান স্টক, মূল্য ও প্রকাশের অবস্থা সম্পাদনা করতে পারবেন।",13));for(int n=0;n<products.length();n++){JSONObject product=products.optJSONObject(n);if(product==null)continue;content.addView(text(product.optString("title")+" • স্টক "+product.optInt("stock")+" • "+(product.optInt("enabled",1)==1?"প্রকাশিত":"বন্ধ"),16));button(content,"সম্পাদনা / অনুমোদন",()->edit(product));}}
 private void orders(){api(admin?"admin/orders":"orders",null,x->{content.removeAllViews();JSONArray a=x.optJSONArray("orders");if(a==null||a.length()==0)content.addView(text("No orders yet",17));if(a!=null)for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;content.addView(text("Order "+o.optString("id")+"\n"+o.optString("status")+" · "+money(o.optLong("total"))+" · COD",17));content.addView(text(o.optString("address"),13));JSONArray items=o.optJSONArray("items");if(items!=null)for(int j=0;j<items.length();j++){JSONObject it=items.optJSONObject(j);if(it!=null)content.addView(text(it.optString("title")+" × "+it.optInt("qty"),14));}JSONArray ev=o.optJSONArray("events");if(ev!=null)for(int j=0;j<ev.length();j++){JSONObject e=ev.optJSONObject(j);if(e!=null)content.addView(text(e.optString("status")+" · "+e.optString("created_at")+" UTC",12));}if(admin)button(content,"Update status",()->{String[] states={"CONFIRMED","SHIPPED","DELIVERED","CANCELLED"};new MyShopDialogBuilder(this).setTitle("Order status").setItems(states,(d,w)->new MyShopDialogBuilder(this).setMessage("Confirm "+states[w]+"?").setPositiveButton(UiStrings.ui636("Confirm"),(d2,w2)->api("admin/status",obj("id",o.optString("id"),"status",states[w]),r->orders())).setNegativeButton(UiStrings.label(PhysicalStoreActivity.this,"Cancel"),null).show()).show();});}});}
 private void saved(){api("saved",null,x->{content.removeAllViews();JSONArray a=x.optJSONArray("items");if(a!=null)for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p==null)continue;content.addView(text(p.optString("title"),17));button(content,"Remove from Wishlist",()->api("saved",obj("product_id",p.optLong("product_id"),"kind","WISH","remove",true),r->saved()));}button(content,"Browse products",()->load());});}
 private long paisa(EditText e){return new java.math.BigDecimal(e.getText().toString().trim()).movePointRight(2).longValueExact();}
 private void edit(JSONObject p){
  LinearLayout form=col();form.setPadding(dp(12),dp(8),dp(12),dp(8));
  EditText title=field(form,"Product name",p.optString("title"),false),desc=field(form,"Description",p.optString("description"),false),cat=field(form,"Category",p.optString("category"),false);
  EditText image=field(form,"HTTPS image URL",p.optString("image_url"),false);
  ImageView thumbnail=new ImageView(this);thumbnail.setScaleType(ImageView.ScaleType.FIT_CENTER);form.addView(thumbnail,new LinearLayout.LayoutParams(-1,dp(130)));
  if(!p.optString("image_url").isEmpty())AnimatedAssetLoader.load(thumbnail,p.optString("image_url"),false);
  TextView uploadState=text("লিংক দিন অথবা গ্যালারি থেকে ছবি আপলোড করুন।",13);form.addView(uploadState);
  if(imagePicker==null)imagePicker=new AdminImagePicker(this);
  button(form,"গ্যালারি থেকে ছবি বাছাই / Upload",()->imagePicker.choose(false,new AdminImagePicker.Listener(){
   public void progress(String status){uploadState.setText(status);}
   public void ready(JSONObject asset){image.setText(asset.optString("url"));AnimatedAssetLoader.load(thumbnail,asset.optString("url"),false);uploadState.setText("ছবি আপলোড হয়েছে। পণ্যটি Save করুন।");}
   public void failed(String reason){uploadState.setText(reason);}
  }));
  EditText price=field(form,"Price (৳)",String.format(java.util.Locale.US,"%.2f",p.optLong("price")/100.0),true),stock=field(form,"Stock",""+p.optInt("stock"),true);
  EditText cost=field(form,"কেনার খরচ / unit (৳); অজানা হলে ফাঁকা",p.isNull("unit_cost")?"":String.format(java.util.Locale.US,"%.2f",p.optLong("unit_cost")/100.0),true);
  CheckBox enabled=new CheckBox(this);enabled.setText("Published / enabled");enabled.setChecked(p.optInt("enabled",1)==1);form.addView(enabled);
  ScrollView sc=new ScrollView(this);sc.addView(form);
  AlertDialog dialog=new MyShopDialogBuilder(this).setTitle("Product editor").setView(sc).setPositiveButton(UiStrings.label(PhysicalStoreActivity.this,"Save"),null).setNegativeButton(UiStrings.label(PhysicalStoreActivity.this,"Cancel"),null).create();
  if(p.optLong("id")>0)button(form,"Delete product",()->new MyShopDialogBuilder(this).setMessage("Remove product from sale? Existing orders are preserved.").setPositiveButton(UiStrings.label(PhysicalStoreActivity.this,"Delete"),(d,w)->api("admin/delete",obj("id",p.optLong("id")),x->{dialog.dismiss();load();})).setNegativeButton(UiStrings.label(PhysicalStoreActivity.this,"Cancel"),null).show());
  dialog.setOnDismissListener(d->imagePicker.cancel());
  dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
   if(imagePicker.isBusy()){uploadState.setText("ছবি আপলোড শেষ হলে Save করুন।");return;}
   try{
    JSONObject body=obj("id",p.optLong("id"),"title",title.getText().toString(),"description",desc.getText().toString(),"category",cat.getText().toString(),"image_url",image.getText().toString().trim(),"price",paisa(price),"stock",Integer.parseInt(stock.getText().toString()),"expected_stock",p.optInt("stock"),"enabled",enabled.isChecked());
    body.put("unit_cost",cost.getText().toString().trim().isEmpty()?JSONObject.NULL:paisa(cost));
    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
    BackendClient.commerce("admin/product",body,SessionManager.getToken(this),new BackendClient.Callback(){
     public void onSuccess(JSONObject data){dialog.dismiss();load();}
     public void onError(String reason){dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);uploadState.setText(reason);}
    });
   }catch(Exception e){uploadState.setText("পণ্যের মূল্য ও স্টক সঠিকভাবে লিখুন।");}
  }));dialog.show();
 }
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(imagePicker!=null)imagePicker.handle(request,result,data);}
 @Override protected void onDestroy(){if(imagePicker!=null)imagePicker.cancel();super.onDestroy();}

 private void filters(){LinearLayout b=col();EditText min=field(b,"Minimum price (৳)","0",true),max=field(b,"Maximum price (৳), blank = any","",true);CheckBox stock=new CheckBox(this);stock.setText("In stock only");stock.setChecked(inStock);b.addView(stock);new MyShopDialogBuilder(this).setTitle("Price / stock filters").setView(b).setPositiveButton(UiStrings.ui636("Apply"),(d,w)->{try{minimum=paisa(min);maximum=max.getText().toString().trim().isEmpty()?Long.MAX_VALUE:paisa(max);inStock=stock.isChecked();renderProducts();}catch(Exception e){Toast.makeText(this,"Invalid price",Toast.LENGTH_SHORT).show();}}).setNegativeButton(UiStrings.label(PhysicalStoreActivity.this,"Cancel"),null).show();}
 private void notices(){api("notices",null,x->{content.removeAllViews();JSONArray a=x.optJSONArray("notices");if(a==null||a.length()==0)content.addView(text("No Store updates yet",16));if(a!=null)for(int i=0;i<a.length();i++)content.addView(text(a.optJSONObject(i).optString("message"),15));});}
 private void analytics(){api("admin/analytics",null,x->{content.removeAllViews();content.addView(text("Delivered revenue only. Clicks: unique per user/product/folder/day. Not banner attribution.",14));JSONArray a=x.optJSONArray("products");if(a!=null)for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);content.addView(text(p.optString("title")+"\nClicks: "+p.optInt("daily_unique_clicks")+" · Delivered units: "+p.optInt("delivered_units")+"\nRevenue: "+money(p.optLong("delivered_revenue")),16));}});}
 private void reviews(JSONObject p){api("reviews?product_id="+p.optLong("id"),null,x->{LinearLayout b=col();JSONArray a=x.optJSONArray("reviews");if(a!=null)for(int i=0;i<a.length();i++){JSONObject r=a.optJSONObject(i);b.addView(text(r.optInt("rating")+" / 5 · Verified buyer\n"+r.optString("review"),14));if(!r.optString("image_url").isEmpty()){ImageView im=new ImageView(this);AnimatedAssetLoader.load(im,r.optString("image_url"),false);b.addView(im,new LinearLayout.LayoutParams(-1,dp(120)));}}button(b,"Write / edit review",()->{LinearLayout f=col();EditText rating=field(f,"Rating 1–5","5",true),review=field(f,"Review","",false),photo=field(f,"Optional HTTPS photo URL","",false);new MyShopDialogBuilder(this).setTitle("Delivered buyers only").setView(f).setPositiveButton(UiStrings.label(PhysicalStoreActivity.this,"Save"),(d,w)->{try{api("review",obj("product_id",p.optLong("id"),"rating",Integer.parseInt(rating.getText().toString()),"review",review.getText().toString(),"image_url",photo.getText().toString()),r->Toast.makeText(this,"Review saved",Toast.LENGTH_SHORT).show());}catch(Exception e){Toast.makeText(this,"Rating must be 1–5",Toast.LENGTH_SHORT).show();}}).setNegativeButton(UiStrings.label(PhysicalStoreActivity.this,"Cancel"),null).show();});ScrollView sv=new ScrollView(this);sv.addView(b);new MyShopDialogBuilder(this).setTitle("Verified reviews").setView(sv).setNegativeButton(UiStrings.label(PhysicalStoreActivity.this,"Close"),null).show();});}
 private void promo(){String[] names={"Hot Deals","Discount Zone","New Arrivals","Special Offer"};new MyShopDialogBuilder(this).setTitle("Choose folder").setItems(names,(d,w)->{final int f=w+1;new MyShopDialogBuilder(this).setTitle("Position 1–4").setItems(new String[]{"1","2","3","4"},(d2,slot)->{String[] titles=new String[products.length()+1];titles[0]="Remove placement (keep product)";for(int i=0;i<products.length();i++)titles[i+1]=products.optJSONObject(i).optString("title");new MyShopDialogBuilder(this).setTitle("Select Store product").setItems(titles,(d3,pick)->{if(pick==0){api("admin/promo",obj("folder",f,"slot",slot+1,"remove",true),r->load());return;}JSONObject p=products.optJSONObject(pick-1);LinearLayout form=col();EditText price=field(form,"Offer price (৳)",""+(p.optLong("price")/100.0),true),days=field(form,"Offer duration (days)","7",true);new MyShopDialogBuilder(this).setTitle(p.optString("title")).setView(form).setPositiveButton(UiStrings.ui636("Publish"),(d4,v)->{try{api("admin/promo",obj("folder",f,"slot",slot+1,"product_id",p.optLong("id"),"offer_price",paisa(price),"ends_at",System.currentTimeMillis()+Long.parseLong(days.getText().toString())*86400000L),r->load());}catch(Exception e){Toast.makeText(this,"Invalid price or duration",Toast.LENGTH_SHORT).show();}}).setNegativeButton(UiStrings.label(PhysicalStoreActivity.this,"Cancel"),null).show();}).show();}).show();}).show();}
}
