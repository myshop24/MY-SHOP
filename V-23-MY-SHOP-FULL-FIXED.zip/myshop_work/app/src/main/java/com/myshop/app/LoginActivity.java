package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (SessionManager.isLoggedIn(this)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }
        setContentView(R.layout.activity_login);
        findViewById(R.id.createAccountButton).setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
        findViewById(R.id.loginButton).setOnClickListener(v -> login());
        findViewById(R.id.forgotButton).setOnClickListener(v ->
                Toast.makeText(this, "Password reset will use the secure backend when connected.", Toast.LENGTH_LONG).show());
    }

    private void login() {
        EditText idField = findViewById(R.id.loginId);
        EditText passwordField = findViewById(R.id.loginPassword);
        String identifier = idField.getText().toString().trim();
        String password = passwordField.getText().toString();

        if (identifier.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Email or mobile number and password are required.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Development fallback: the three owner identifiers are role-recognized locally.
        // No admin password is embedded in the APK. Production must replace this with backend auth.
        if (AuthStore.isAdminIdentifier(this, identifier)) {
            String userId = ensureProfileId(identifier);
            SessionManager.setSession(this, Role.ADMIN, userId, identifier);
            Toast.makeText(this, "Admin detected. Full Admin Controls unlocked.", Toast.LENGTH_SHORT).show();
            openDashboard();
            return;
        }

        String userId = AuthStore.findUserId(this, identifier);
        if (userId.isEmpty() || !AuthStore.passwordMatches(this, userId, password)) {
            Toast.makeText(this, "Login failed. Check your email/mobile and password.", Toast.LENGTH_LONG).show();
            return;
        }

        SessionManager.setSession(this, Role.USER, userId, identifier);
        openDashboard();
    }

    private String ensureProfileId(String identifier) {
        String key = "admin_profile_" + identifier.trim().toLowerCase();
        String existing = getSharedPreferences("myshop_admin_local", MODE_PRIVATE).getString(key, "");
        if (!existing.isEmpty()) return existing;
        String id = UserIdManager.allocateLocalId(this);
        getSharedPreferences("myshop_admin_local", MODE_PRIVATE).edit().putString(key, id).apply();
        return id;
    }

    private void openDashboard() {
        startActivity(new Intent(this, MainActivity.class));
        finishAffinity();
    }
}
