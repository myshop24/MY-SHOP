package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        findViewById(R.id.backLoginButton).setOnClickListener(v -> finish());
        findViewById(R.id.createButton).setOnClickListener(v -> createAccount());
    }

    private void createAccount() {
        EditText name = findViewById(R.id.fullName);
        EditText email = findViewById(R.id.email);
        EditText mobile = findViewById(R.id.mobile);
        EditText pass = findViewById(R.id.password);
        EditText confirm = findViewById(R.id.confirmPassword);
        CheckBox terms = findViewById(R.id.terms);

        String n = name.getText().toString().trim();
        String e = email.getText().toString().trim();
        String m = mobile.getText().toString().trim();
        String p = pass.getText().toString();

        if (n.isEmpty()) { Toast.makeText(this, "Full Name is required.", Toast.LENGTH_SHORT).show(); return; }
        if (e.isEmpty() && m.isEmpty()) { Toast.makeText(this, "Email OR Mobile is required. Both are not mandatory.", Toast.LENGTH_LONG).show(); return; }
        if (!e.isEmpty() && !AuthStore.validEmail(e)) { Toast.makeText(this, "Enter a valid email address.", Toast.LENGTH_SHORT).show(); return; }
        if (!m.isEmpty() && !AuthStore.validMobile(m)) { Toast.makeText(this, "Enter a valid mobile number.", Toast.LENGTH_SHORT).show(); return; }
        if (p.length() < 6 || !p.equals(confirm.getText().toString())) { Toast.makeText(this, "Use 6+ characters and make both passwords match.", Toast.LENGTH_SHORT).show(); return; }
        if (!terms.isChecked()) { Toast.makeText(this, "Please accept the Terms & Conditions.", Toast.LENGTH_SHORT).show(); return; }

        if ((!e.isEmpty() && AuthStore.isAdminIdentifier(this, e)) || (!m.isEmpty() && AuthStore.isAdminIdentifier(this, m))) {
            Toast.makeText(this, "That identifier is reserved for MY SHOP Admin.", Toast.LENGTH_LONG).show();
            return;
        }

        String id = UserIdManager.allocateLocalId(this);
        AuthStore.saveUser(this, n, e, m, p, id);
        SessionManager.setSession(this, Role.USER, id, !e.isEmpty() ? e : m);
        Toast.makeText(this, "Account created successfully. Profile ID: " + id, Toast.LENGTH_LONG).show();
        startActivity(new Intent(this, MainActivity.class));
        finishAffinity();
    }
}
