package com.myshop.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

/** Main dashboard. The supplied dashboard artwork is the visual reference; hotspots provide real actions. */
public class MainActivity extends AppCompatActivity {
    private DashboardReferenceView dashboard;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!SessionManager.isLoggedIn(this)) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }
        setContentView(R.layout.activity_main);
        dashboard = findViewById(R.id.dashboardReference);
        wireDashboard();
    }

    private void wireDashboard() {
        // Header
        add(18, 12, 92, 84, "Menu", this::showMenu);
        add(110, 10, 830, 86, "Search", this::showSearch);
        add(842, 10, 920, 88, "Notifications", this::showNotifications);
        add(930, 10, 1005, 88, "More", this::showMore);

        // Hero / banner areas
        add(18, 96, 500, 315, "Banner 1", () -> openFeature("MY SHOP", "my_shop"));
        add(515, 96, 1004, 315, "Banner 2", () -> openFeature("MY SHOP", "my_shop"));
        add(18, 360, 1004, 600, "MY SHOP Banner", () -> openFeature("MY SHOP", "my_shop"));
        add(18, 620, 325, 780, "Collection", () -> openFeature("MY SHOP", "my_shop"));
        add(335, 620, 670, 780, "Deal", () -> openFeature("MY SHOP", "my_shop"));
        add(680, 620, 1004, 780, "Beauty", () -> openFeature("MY SHOP", "my_shop"));

        // Breaking news + live section
        add(18, 795, 1004, 856, "Breaking News", () -> openFeature("BREAKING NEWS", "breaking_news"));
        add(18, 862, 1004, 910, "Live Now", () -> openFeature("LIVE NOW", "live_now"));
        add(18, 910, 258, 1140, "Live Room 1", () -> openFeature("LIVE ROOM 1", "live_now"));
        add(265, 910, 510, 1140, "Live Room 2", () -> openFeature("LIVE ROOM 2", "live_now"));
        add(515, 910, 760, 1140, "Live Room 3", () -> openFeature("LIVE ROOM 3", "live_now"));
        add(765, 910, 1004, 1140, "Live Room 4", () -> openFeature("LIVE ROOM 4", "live_now"));

        // Primary feature row
        add(18, 1140, 335, 1280, "LIVE", () -> openFeature("LIVE", "live_now"));
        add(335, 1135, 675, 1285, "GO LIVE", () -> openFeature("GO LIVE", "go_live"));
        add(690, 1140, 1004, 1280, "MY FEED", () -> openFeature("MY FEED", "my_feed"));

        // Feature grid
        add(18, 1280, 260, 1405, "MY SHOP", () -> openFeature("MY SHOP", "my_shop"));
        add(270, 1280, 500, 1405, "Gallery", () -> openFeature("GALLERY", "gallery"));
        add(505, 1280, 755, 1405, "External Movie", () -> openFeature("EXTERNAL MOVIE", "external_movie"));
        add(760, 1280, 1004, 1405, "Live TV", () -> openFeature("LIVE TV", "live_tv"));
        add(18, 1405, 260, 1500, "Social Media", () -> openFeature("SOCIAL MEDIA", "social_media"));
        add(270, 1405, 500, 1500, "Earn and Reward", () -> openFeature("EARN & REWARD", "earn_reward"));
        add(505, 1405, 755, 1500, "Share", this::shareApp);
        add(760, 1405, 1004, 1500, "More Apps", () -> openFeature("MORE APPS", "more_apps"));

        // Bottom navigation
        add(18, 1490, 215, 1536, "Home", () -> dashboard.getParent().requestDisallowInterceptTouchEvent(false));
        add(215, 1490, 410, 1536, "Live", () -> openFeature("LIVE", "live_now"));
        add(410, 1490, 610, 1536, "Store", () -> openFeature("MY SHOP", "my_shop"));
        add(610, 1490, 810, 1536, "Chat", () -> openFeature("CHAT", "chat"));
        add(810, 1490, 1022, 1536, "More", this::showMore);
    }

    private void add(int l, int t, int r, int b, String description, DashboardReferenceView.Action action) {
        dashboard.addHotspot(l, t, r, b, description, action);
    }

    private void showSearch() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("Product, live, user, post...");
        new AlertDialog.Builder(this)
                .setTitle("Search MY SHOP")
                .setView(input)
                .setPositiveButton("SEARCH", (d, w) -> {
                    String q = input.getText().toString().trim();
                    if (q.isEmpty()) return;
                    openFeature("SEARCH: " + q, "search");
                })
                .setNegativeButton("CANCEL", null)
                .show();
    }

    private void showNotifications() {
        new AlertDialog.Builder(this)
                .setTitle("🔔 Notifications")
                .setMessage("3 notifications\n\n• Welcome to MY SHOP\n• Your dashboard is ready\n• New live features are available")
                .setPositiveButton("Mark as seen", null)
                .show();
    }

    private void showMenu() {
        String[] items;
        if (SessionManager.isAdmin(this)) {
            items = new String[]{"👤 Account & Profile", "👑 Admin Controls", "🌐 Language", "🚪 Logout"};
        } else if (SessionManager.isModerator(this)) {
            items = new String[]{"👤 Account & Profile", "🛡️ Moderator Controls", "🌐 Language", "🚪 Logout"};
        } else {
            items = new String[]{"👤 Account & Profile", "🌐 Language", "🚪 Logout"};
        }
        new AlertDialog.Builder(this).setTitle("MY SHOP").setItems(items, (d, which) -> {
            String item = items[which];
            if (item.contains("Account")) startActivity(new Intent(this, AccountActivity.class));
            else if (item.contains("Admin Controls")) startActivity(new Intent(this, AdminManagementActivity.class));
            else if (item.contains("Moderator Controls")) startActivity(new Intent(this, AdminManagementActivity.class).putExtra("moderator_only", true));
            else if (item.contains("Language")) showLanguagePicker();
            else logout();
        }).show();
    }

    private void showMore() {
        if (SessionManager.isAdmin(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("👑 Admin detected")
                    .setMessage("Admin ID: " + SessionManager.getLoginIdentifier(this) + "\nProfile ID: " + SessionManager.getUserId(this))
                    .setItems(new String[]{"Open Admin Controls", "Account & Profile", "Language", "Logout"}, (d, which) -> {
                        if (which == 0) startActivity(new Intent(this, AdminManagementActivity.class));
                        else if (which == 1) startActivity(new Intent(this, AccountActivity.class));
                        else if (which == 2) showLanguagePicker();
                        else logout();
                    }).show();
        } else if (SessionManager.isModerator(this)) {
            startActivity(new Intent(this, AdminManagementActivity.class).putExtra("moderator_only", true));
        } else {
            new AlertDialog.Builder(this).setTitle("More")
                    .setItems(new String[]{"Account & Profile", "Language", "Logout"}, (d, which) -> {
                        if (which == 0) startActivity(new Intent(this, AccountActivity.class));
                        else if (which == 1) showLanguagePicker();
                        else logout();
                    }).show();
        }
    }

    private void showLanguagePicker() {
        String[] labels = {"বাংলা", "English", "हिन्दी", "العربية"};
        String[] codes = {LanguageManager.BN, LanguageManager.EN, LanguageManager.HI, LanguageManager.AR};
        String current = LanguageManager.get(this);
        int checked = 0;
        for (int i = 0; i < codes.length; i++) if (codes[i].equals(current)) checked = i;
        final int[] selected = {checked};
        new AlertDialog.Builder(this).setTitle("Language")
                .setSingleChoiceItems(labels, checked, (d, w) -> selected[0] = w)
                .setPositiveButton("OK", (d, w) -> { LanguageManager.set(this, codes[selected[0]]); recreate(); })
                .setNegativeButton("Cancel", null).show();
    }

    private void openFeature(String title, String key) {
        Intent intent = new Intent(this, FeatureActivity.class).putExtra("title", title).putExtra("key", key);
        String configuredUrl = FeatureRegistry.getUrl(this, key);
        if (FeatureRegistry.isSafeHttpUrl(configuredUrl)) intent.putExtra("url", configuredUrl);
        startActivity(intent);
    }

    private void shareApp() {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, "MY SHOP — Shop Smart, Live Better");
        startActivity(Intent.createChooser(send, "Share MY SHOP"));
    }

    private void logout() {
        SessionManager.clear(this);
        startActivity(new Intent(this, LoginActivity.class));
        finishAffinity();
    }

    @Override protected void onResume() {
        super.onResume();
        if (!SessionManager.isLoggedIn(this)) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        }
    }
}
