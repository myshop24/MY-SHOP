package com.myshop.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ScrollView;

import java.util.ArrayList;
import java.util.List;

/**
 * Pixel-positioned interaction layer over the supplied MY SHOP dashboard reference.
 * The artwork stays visually identical while every important visible control has
 * a real Android click target. The layout scales with the phone width.
 */
public class DashboardReferenceView extends ViewGroup {
    private static final int SRC_W = 1022;
    private static final int SRC_H = 1536;
    private final ImageView artwork;
    private final List<Hotspot> hotspots = new ArrayList<>();
    private float scale = 1f;

    public interface Action { void run(); }

    private static final class Hotspot {
        final View view;
        final int l, t, r, b;
        Hotspot(View view, int l, int t, int r, int b) {
            this.view = view; this.l = l; this.t = t; this.r = r; this.b = b;
        }
    }

    public DashboardReferenceView(Context context) { this(context, null); }
    public DashboardReferenceView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setWillNotDraw(false);
        artwork = new ImageView(context);
        artwork.setImageResource(R.drawable.dashboard_reference);
        artwork.setScaleType(ImageView.ScaleType.FIT_XY);
        artwork.setClickable(false);
        addView(artwork);
        setBackgroundColor(Color.WHITE);
    }

    public void addHotspot(int l, int t, int r, int b, String description, Action action) {
        View v = new View(getContext());
        v.setBackground(new ColorDrawable(Color.TRANSPARENT));
        v.setContentDescription(description);
        v.setClickable(true);
        v.setFocusable(true);
        v.setOnClickListener(view -> action.run());
        addView(v);
        hotspots.add(new Hotspot(v, l, t, r, b));
        requestLayout();
    }

    @Override protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = MeasureSpec.getSize(widthMeasureSpec);
        if (width <= 0) width = getSuggestedMinimumWidth();
        int height = Math.round(width * (SRC_H / (float) SRC_W));
        setMeasuredDimension(width, height);
        artwork.measure(MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY));
        scale = width / (float) SRC_W;
        for (Hotspot h : hotspots) {
            h.view.measure(MeasureSpec.makeMeasureSpec(Math.max(1, Math.round((h.r-h.l)*scale)), MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(Math.max(1, Math.round((h.b-h.t)*scale)), MeasureSpec.EXACTLY));
        }
    }

    @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
        artwork.layout(0, 0, getWidth(), getHeight());
        for (Hotspot h : hotspots) {
            int left = Math.round(h.l * scale);
            int top = Math.round(h.t * scale);
            int right = Math.round(h.r * scale);
            int bottom = Math.round(h.b * scale);
            h.view.layout(left, top, right, bottom);
        }
    }
}
