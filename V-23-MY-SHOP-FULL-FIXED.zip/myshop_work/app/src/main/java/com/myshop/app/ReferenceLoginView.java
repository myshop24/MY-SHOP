package com.myshop.app;

import android.content.Context;
import android.graphics.Color;
import android.text.InputType;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

/** Exact visual login reference with functional transparent input/click layers. */
public class ReferenceLoginView extends ViewGroup {
    private static final int SRC_W=709, SRC_H=1536;
    private final ImageView artwork;
    private float scale=1f;
    public ReferenceLoginView(Context c){this(c,null);}
    public ReferenceLoginView(Context c, AttributeSet a){super(c,a); artwork=new ImageView(c); artwork.setImageResource(R.drawable.login_reference); artwork.setScaleType(ImageView.ScaleType.FIT_XY); addView(artwork); build(c);}
    private void build(Context c){
        EditText login=new EditText(c); login.setId(R.id.loginId); login.setSingleLine(true); login.setBackgroundColor(Color.TRANSPARENT); login.setPadding(0,0,0,0); login.setTextSize(16); login.setTextColor(Color.rgb(40,40,40)); addView(login);
        EditText pass=new EditText(c); pass.setId(R.id.loginPassword); pass.setSingleLine(true); pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD); pass.setBackgroundColor(Color.TRANSPARENT); pass.setPadding(0,0,0,0); pass.setTextSize(16); pass.setTextColor(Color.rgb(40,40,40)); addView(pass);
        Button loginBtn=transparentButton(c,R.id.loginButton,"Login"); loginBtn.setOnClickListener(v->{}); addView(loginBtn);
        Button create=transparentButton(c,R.id.createAccountButton,"Create Account"); addView(create);
        Button forgot=transparentButton(c,R.id.forgotButton,"Forgot Password"); addView(forgot);
        Button eye=transparentButton(c,0,"Show password"); eye.setOnClickListener(v->pass.setInputType(pass.getInputType()==(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD)?InputType.TYPE_CLASS_TEXT:InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD)); addView(eye);
    }
    private Button transparentButton(Context c,int id,String desc){Button b=new Button(c); if(id!=0)b.setId(id); b.setText(""); b.setBackgroundColor(Color.TRANSPARENT); b.setContentDescription(desc); b.setPadding(0,0,0,0); return b;}
    @Override protected void onMeasure(int wSpec,int hSpec){int w=MeasureSpec.getSize(wSpec); if(w<=0)w=SRC_W; int h=Math.round(w*(SRC_H/(float)SRC_W)); setMeasuredDimension(w,h); scale=w/(float)SRC_W; artwork.measure(MeasureSpec.makeMeasureSpec(w,MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(h,MeasureSpec.EXACTLY)); measureAt(R.id.loginId,110,844,650,945); measureAt(R.id.loginPassword,110,972,650,1070); measureAt(R.id.loginButton,48,1188,662,1300); measureAt(R.id.createAccountButton,400,1408,660,1470); measureAt(R.id.forgotButton,455,1080,670,1150); View eye=findViewById(0); if(eye!=null)eye.measure(MeasureSpec.makeMeasureSpec(s(565),MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(s(90),MeasureSpec.EXACTLY));}
    private int s(int x){return Math.max(1,Math.round(x*scale));}
    private void measureAt(int id,int l,int t,int r,int b){View v=findViewById(id); if(v!=null){v.measure(MeasureSpec.makeMeasureSpec(s(r-l),MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(s(b-t),MeasureSpec.EXACTLY));}}
    @Override protected void onLayout(boolean ch,int l,int t,int r,int b){artwork.layout(0,0,getWidth(),getHeight()); layoutAt(R.id.loginId,110,844,650,945); layoutAt(R.id.loginPassword,110,972,650,1070); layoutAt(R.id.loginButton,48,1188,662,1300); layoutAt(R.id.createAccountButton,400,1408,660,1470); layoutAt(R.id.forgotButton,455,1080,670,1150); View eye=findViewById(0); if(eye!=null)eye.layout(s(565),s(975),s(655),s(1065));}
    private void layoutAt(int id,int l,int t,int r,int b){View v=findViewById(id); if(v!=null)v.layout(s(l),s(t),s(r),s(b));}
}
