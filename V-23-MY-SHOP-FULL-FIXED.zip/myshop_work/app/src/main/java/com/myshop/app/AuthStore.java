package com.myshop.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Patterns;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** Local development auth store. Production authentication/roles must be server-authoritative. */
public final class AuthStore {
    private static final String PREF = "myshop_auth_store";
    private AuthStore() {}

    public static boolean isAdminIdentifier(Context context, String value) {
        if (value == null) return false;
        String v = value.trim().toLowerCase();
        try (InputStream in = context.getAssets().open("admin_identifiers.json")) {
            byte[] data = new byte[in.available()];
            int read = in.read(data);
            if (read <= 0) return false;
            JSONObject root = new JSONObject(new String(data, 0, read, StandardCharsets.UTF_8));
            JSONArray admins = root.optJSONArray("admins");
            if (admins == null) return false;
            for (int i = 0; i < admins.length(); i++) {
                if (v.equals(admins.optString(i, "").trim().toLowerCase())) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    public static boolean validEmail(String email) {
        return email != null && !email.trim().isEmpty() && Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches();
    }

    public static boolean validMobile(String mobile) {
        if (mobile == null) return false;
        String digits = mobile.replaceAll("[^0-9+]", "");
        return digits.length() >= 8;
    }

    public static void saveUser(Context c, String name, String email, String mobile, String password, String userId) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String emailKey = normalize(email);
        String mobileKey = normalize(mobile);
        String hash = hash(password);
        p.edit()
                .putString("name_" + userId, name == null ? "" : name.trim())
                .putString("email_" + userId, emailKey)
                .putString("mobile_" + userId, mobileKey)
                .putString("pass_" + userId, hash)
                .putString("user_for_email_" + emailKey, userId)
                .putString("user_for_mobile_" + mobileKey, userId)
                .apply();
    }

    public static String findUserId(Context c, String identifier) {
        String key = normalize(identifier);
        if (key.isEmpty()) return "";
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String byEmail = p.getString("user_for_email_" + key, "");
        if (!byEmail.isEmpty()) return byEmail;
        return p.getString("user_for_mobile_" + key, "");
    }

    public static boolean passwordMatches(Context c, String userId, String password) {
        if (userId == null || userId.isEmpty()) return false;
        String saved = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("pass_" + userId, "");
        return !saved.isEmpty() && saved.equals(hash(password));
    }

    public static String getName(Context c, String userId) { return get(c, "name_" + userId); }
    public static String getEmail(Context c, String userId) { return get(c, "email_" + userId); }
    public static String getMobile(Context c, String userId) { return get(c, "mobile_" + userId); }

    private static String get(Context c, String key) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(key, "");
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase();
    }

    private static String hash(String value) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest((value == null ? "" : value).getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder();
            for (byte b : bytes) out.append(String.format("%02x", b));
            return out.toString();
        } catch (Exception e) {
            throw new IllegalStateException("Hash unavailable", e);
        }
    }
}
