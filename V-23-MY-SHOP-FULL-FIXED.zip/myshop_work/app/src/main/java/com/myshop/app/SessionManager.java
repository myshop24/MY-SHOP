package com.myshop.app;

import android.content.Context;

/** Session data. Production authentication and roles remain backend-authoritative. */
public final class SessionManager {
    private static final String PREF = "myshop_session";
    private SessionManager() {}

    public static void setSession(Context c, Role role, String userId, String identifier) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString("role", role.name())
                .putString("user_id", userId == null ? "" : userId)
                .putString("login_identifier", identifier == null ? "" : identifier.trim())
                .putBoolean("logged_in", role != Role.GUEST)
                .apply();
    }

    public static Role getRole(Context c) {
        String value = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("role", Role.GUEST.name());
        try { return Role.valueOf(value); } catch (Exception ignored) { return Role.GUEST; }
    }
    public static String getUserId(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("user_id", ""); }
    public static String getLoginIdentifier(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("login_identifier", ""); }
    public static boolean isLoggedIn(Context c) { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("logged_in", false); }
    public static boolean isAdmin(Context c) { return getRole(c) == Role.ADMIN; }
    public static boolean isModerator(Context c) { return getRole(c) == Role.MODERATOR; }
    public static void clear(Context c) { c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply(); }
}
