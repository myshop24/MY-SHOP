package com.myshop.app;

import android.content.Context;
import android.graphics.Color;
import android.text.InputType;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;

/** Exact visual register reference with functional input/click layers. */
public class ReferenceRegisterView extends ViewGroup {
    private static final int SRC_W=711, SRC_H=1536;
    private final ImageView artwork; private float scale;
    public ReferenceRegisterView(Context c){this(c,null);}
    public ReferenceRegisterView(Context c, AttributeSet a){super(c,a); artwork=new ImageView(c); artwork.setImageResource(R.drawable.register_reference); artwork.setScaleType(ImageView.ScaleType.FIT_XY); addView(artwork); build(c);}
    private void build(Context c){
        edit(c,R.id.fullName,110,690,650,770,InputType.TYPE_CLASS_TEXT);
        edit(c,R.id.email,110,790,650,870,InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        edit(c,R.id.mobile,110,890,650,970,InputType.TYPE_CLASS_PHONE);
        edit(c,R.id.password,110,995,650,1075,InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        edit(c,R.id.confirmPassword,110,1095,650,1175,InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        CheckBox terms=new CheckBox(c); terms.setId(R.id.terms); terms.setButtonTintList(android.content.res.ColorStateList.valueOf(Color.TRANSPARENT)); terms.setTextColor(Color.TRANSPARENT); terms.setBackgroundColor(Color.TRANSPARENT); terms.setChecked(true); addView(terms);
        Button create=button(c,R.id.createButton,"Create Account"); addView(create);
        Button back=button(c,R.id.backLoginButton,"Login"); addView(back);
        Button eye1=button(c,0,"Show password"); eye1.setOnClickListener(v->{EditText p=findViewById(R.id.password); p.setInputType(p.getInputType()==(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD)?InputType.TYPE_CLASS_TEXT:InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);}); addView(eye1);
        Button eye2=button(c,0,"Show confirm password"); eye2.setOnClickListener(v->{EditText p=findViewById(R.id.confirmPassword); p.setInputType(p.getInputType()==(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD)?InputType.TYPE_CLASS_TEXT:InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);}); addView(eye2);
    }
    private void edit(Context c,int id,int l,int t,int r,int b,int type){EditText e=new EditText(c); e.setId(id); e.setSingleLine(true); e.setInputType(type); e.setBackgroundColor(Color.TRANSPARENT); e.setPadding(0,0,0,0); e.setTextSize(16); e.setTextColor(Color.rgb(40,40,40)); addView(e);}
    private Button button(Context c,int id,String d){Button b=new Button(c); b.setId(id); b.setText(""); b.setBackgroundColor(Color.TRANSPARENT); b.setContentDescription(d); b.setPadding(0,0,0,0); return b;}
    @Override protected void onMeasure(int ws,int hs){int w=MeasureSpec.getSize(ws);if(w<=0)w=SRC_W;int h=Math.round(w*(SRC_H/(float)SRC_W));setMeasuredDimension(w,h);scale=w/(float)SRC_W;artwork.measure(MeasureSpec.makeMeasureSpec(w,MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(h,MeasureSpec.EXACTLY)); at(R.id.fullName,110,690,650,770);at(R.id.email,110,790,650,870);at(R.id.mobile,110,890,650,970);at(R.id.password,110,995,650,1075);at(R.id.confirmPassword,110,1095,650,1175);at(R.id.terms,45,1205,665,1265);at(R.id.createButton,48,1275,662,1380);at(R.id.backLoginButton,180,1440,540,1510);}
    private int s(int x){return Math.max(1,Math.round(x*scale));}
    private void at(int id,int l,int t,int r,int b){View v=findViewById(id);if(v!=null)v.measure(MeasureSpec.makeMeasureSpec(s(r-l),MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(s(b-t),MeasureSpec.EXACTLY));}
    @Override protected void onLayout(boolean ch,int l,int t,int r,int b){artwork.layout(0,0,getWidth(),getHeight());atLayout(R.id.fullName,110,690,650,770);atLayout(R.id.email,110,790,650,870);atLayout(R.id.mobile,110,890,650,970);atLayout(R.id.password,110,995,650,1075);atLayout(R.id.confirmPassword,110,1095,650,1175);atLayout(R.id.terms,45,1205,665,1265);atLayout(R.id.createButton,48,1275,662,1380);atLayout(R.id.backLoginButton,180,1440,540,1510);}
    private void atLayout(int id,int l,int t,int r,int b){View v=findViewById(id);if(v!=null)v.layout(s(l),s(t),s(r),s(b));}
}
