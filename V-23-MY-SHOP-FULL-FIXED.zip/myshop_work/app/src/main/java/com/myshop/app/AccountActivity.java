package com.myshop.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class AccountActivity extends AppCompatActivity {
    private ImageView profilePhoto;
    private static final int PICK_PHOTO = 401;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        String id = SessionManager.getUserId(this);
        ((TextView)findViewById(R.id.accountName)).setText("Name: " + AuthStore.getName(this, id));
        ((TextView)findViewById(R.id.accountId)).setText("Profile ID: " + (id.isEmpty() ? "Not assigned" : id));
        ((TextView)findViewById(R.id.accountEmail)).setText("Email: " + safePrivate(AuthStore.getEmail(this, id)));
        ((TextView)findViewById(R.id.accountMobile)).setText("Mobile: " + safePrivate(AuthStore.getMobile(this, id)));
        ((TextView)findViewById(R.id.accountRole)).setText("Role: " + SessionManager.getRole(this).name());

        profilePhoto = findViewById(R.id.profilePhoto);
        loadPhoto();
        findViewById(R.id.changePhotoButton).setOnClickListener(v -> pickPhoto());
        findViewById(R.id.profileButton).setOnClickListener(v -> Toast.makeText(this, "Your own profile can be edited here; public users do not see your mobile number.", Toast.LENGTH_LONG).show());
        findViewById(R.id.passwordButton).setOnClickListener(v -> Toast.makeText(this, "Password change/reset is ready for secure backend connection.", Toast.LENGTH_LONG).show());
        findViewById(R.id.reportButton).setOnClickListener(v -> Toast.makeText(this, "Report action recorded for backend integration.", Toast.LENGTH_SHORT).show());
        findViewById(R.id.blockButton).setOnClickListener(v -> Toast.makeText(this, "Blocked-user list is ready for backend integration.", Toast.LENGTH_SHORT).show());
        Switch notifications = findViewById(R.id.notificationSwitch);
        notifications.setChecked(getPreferences(MODE_PRIVATE).getBoolean("notifications", true));
        notifications.setOnCheckedChangeListener((button, checked) -> getPreferences(MODE_PRIVATE).edit().putBoolean("notifications", checked).apply());
        findViewById(R.id.logoutButton).setOnClickListener(v -> logout());
    }

    private String safePrivate(String value) { return value == null || value.isEmpty() ? "Not provided" : value; }

    private void pickPhoto() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, PICK_PHOTO);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_PHOTO || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
        getSharedPreferences("myshop_profile", MODE_PRIVATE).edit().putString("photo_uri_" + SessionManager.getUserId(this), uri.toString()).apply();
        profilePhoto.setImageURI(uri);
    }

    private void loadPhoto() {
        String value = getSharedPreferences("myshop_profile", MODE_PRIVATE).getString("photo_uri_" + SessionManager.getUserId(this), "");
        if (!value.isEmpty()) {
            try { profilePhoto.setImageURI(Uri.parse(value)); } catch (Exception ignored) {}
        }
    }

    private void logout() {
        SessionManager.clear(this);
        startActivity(new Intent(this, LoginActivity.class));
        finishAffinity();
    }
}
