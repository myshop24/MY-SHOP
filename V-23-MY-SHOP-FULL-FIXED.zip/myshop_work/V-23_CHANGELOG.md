# MY SHOP V-23 — Dashboard + Login/Auth Fix

## Included
- Login screen now opens first when the app launches.
- Create Account flow accepts Email OR Mobile; both are not mandatory.
- Automatic four-digit local Profile ID allocation for new accounts.
- Email/mobile login for registered users.
- Three owner identifiers are recognized for local development Admin role detection:
  - myshopsatkania@gmail.com
  - Touhidsatkania@gmail.com
  - 01860626700
- Same Main Dashboard is used for Admin/User; Admin Controls appear only for Admin role.
- Dashboard visual uses the supplied dashboard reference image and scales to the full phone width.
- Real clickable hotspots added for header, banners, live cards, feature buttons and bottom navigation.
- Profile photo can be set/changed per account.
- User mobile is shown only in that user's own Account screen.
- Logout returns to Login.
- New single-repository GitHub Actions workflow builds the project directly; no nested source ZIP is required.

## Important
The local Admin role recognition is a development fallback so the current APK can be tested without a live authentication server. Production Admin passwords, role authority, user ID allocation and shared content must remain backend-controlled.
