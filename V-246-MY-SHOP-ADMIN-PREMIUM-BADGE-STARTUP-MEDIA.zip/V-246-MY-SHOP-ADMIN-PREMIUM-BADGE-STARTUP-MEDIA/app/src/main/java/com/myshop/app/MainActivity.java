package com.myshop.app;

import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.text.TextUtils;
import android.provider.MediaStore;
import android.media.MediaScannerConnection;
import android.media.MediaMetadataRetriever;
import android.text.style.ForegroundColorSpan;
import android.text.Spanned;
import android.text.SpannableString;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.content.res.ColorStateList;
import android.util.LruCache;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

/** MY SHOP V-241: reliable home video, comments, friend flow, saveable feed images and clearer animated Live UI. */
public class MainActivity extends androidx.appcompat.app.AppCompatActivity {
    private int BG=Color.rgb(248,249,253), BLUE=Color.rgb(46,47,190), PURPLE=Color.rgb(91,38,214), PINK=Color.rgb(235,36,168);
    private final int NAVY=Color.rgb(18,32,75), DARK=Color.rgb(35,38,52), RED=Color.rgb(238,35,52), GREEN=Color.rgb(24,169,98), MUTED=Color.rgb(105,111,130);
    private final Handler handler=new Handler();
    private final java.util.concurrent.ExecutorService imagePool=Executors.newFixedThreadPool(3);
    private final LruCache<String,Bitmap> imageCache=new LruCache<String,Bitmap>(8*1024*1024){
        @Override protected int sizeOf(String key,Bitmap value){return value.getByteCount();}
    };
    private long lastFeedLoadAt=0L;
    private final Runnable notificationPoll = new Runnable() {
        @Override public void run() {
            loadNotificationCount(); loadMessageCount();
            handler.postDelayed(this,12000);
        }
    };
    private int slide=0;
    private int promoSlide=0;
    private ImageView hero;
    private ImageView[] promoViews=new ImageView[2];
    private String[] remoteHeroUrls=new String[6];
    private String[] remoteHeroTargets=new String[6];
    private String[] remotePromoUrls=new String[3];
    private String[] remotePromoTargets=new String[3];
    private TextView dots,newsText,notificationBadge,messageBadge,feedStatus,postLimit;
    private ImageView headerAvatar,composerAvatar;
    private LinearLayout feedList;
    private LinearLayout newPeopleRow; private View newPeopleSection; private HorizontalScrollView newPeopleScroll; private final ArrayList<JSONObject> newPeopleData=new ArrayList<>(); private int newPeopleStep=0;
    private ScrollView scroll;
    private LinearLayout liveAdBox;
    private TextView powerAdTitle, powerAdByline; private LinearLayout dynamicFolderBox;
    private long feedBefore=0;
    private boolean feedLoading=false,feedHasMore=true;
    private static final int PICK_POST=9421;
    private Uri pendingPostUri;
    private String pendingPostMime="image/jpeg";
    private int unreadNotificationCount=0, unreadMessageCount=0;
    private final java.util.HashSet<Long> renderedPostIds=new java.util.HashSet<>();
    private final ArrayList<VideoView> inlineVideos=new ArrayList<>();
    private VideoView activeInlineVideo=null;
    private final java.util.HashMap<Long,View> postViews=new java.util.HashMap<>();
    private long pendingFocusPostId=0;
    private float newsTextSizeSp=12.5f;
    private ImageView liveAdImage; private TextView liveAdCaption; private View liveAdStripView; private final ArrayList<JSONObject> liveAds=new ArrayList<>(); private int liveAdIndex=0;
    private final int[] heroImgs={R.drawable.banner_wide_1,R.drawable.banner_wide_2,R.drawable.banner_wide_3,R.drawable.banner_wide_4,R.drawable.banner_wide_5,R.drawable.banner_wide_6};
    private final int[] left={R.drawable.banner_top_left_1,R.drawable.banner_top_left_2,R.drawable.banner_top_left_3,R.drawable.banner_top_left_4,R.drawable.banner_top_left_5,R.drawable.banner_top_left_6};
    private final int[] right={R.drawable.banner_top_right_1,R.drawable.banner_top_right_2,R.drawable.banner_top_right_3,R.drawable.banner_top_right_4,R.drawable.banner_top_right_5,R.drawable.banner_top_right_6};
    private final int[] live={R.drawable.dash_live1,R.drawable.dash_live2,R.drawable.dash_live3,R.drawable.dash_live4};
    private final String[] mainKeys={"my_shop","gallery","external_movie","earn_reward","more_apps"};
    private final String[] mainTitles={"MY SHOP","GALLERY","EXTERNAL MEDIA","EARN & REWARD","MORE"};
    private final int[] mainIcons={R.drawable.dash_feat_shop,R.drawable.dash_feat_gallery,R.drawable.dash_feat_movie,R.drawable.dash_feat_reward,R.drawable.dash_feat_apps};
    private final FrameLayout[] mainCards=new FrameLayout[5];
    private final TextView[] mainLabels=new TextView[5];
    private final ImageView[] mainIconViews=new ImageView[5];
    private final String[] mainRemoteUrls=new String[5];

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        loadCachedTheme();
        pendingFocusPostId=getIntent().getLongExtra("focusPostId",0);
        setContentView(build());
        loadCurrentProfile(); loadRemote(); loadNotificationCount(); loadMessageCount(); loadNewPeople(); loadFeed(true);
        startCarousel(); startLiveAdCarousel();
    }

    private void loadCachedTheme(){BG=ThemeConfig.bg(this);BLUE=ThemeConfig.blue(this);PURPLE=ThemeConfig.purple(this);PINK=ThemeConfig.pink(this);}


    private View build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(BG);
        final LinearLayout fixed=col(); fixed.setPadding(dp(4),dp(8),dp(4),0); fixed.setBackgroundColor(BG);
        fixed.addView(header(),lp(-1,dp(58)));
        fixed.addView(breaking(),top(lp(-1,dp(42)),5));
        fixed.addView(liveStreamingSection(),top(lp(-1,dp(174)),5));
        scroll=new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);

        LinearLayout page=col();
        page.setPadding(0,dp(4),0,dp(92));
        page.setBackgroundColor(BG);

        // Android edge-to-edge safe area: keep top controls comfortably tappable.
        page.setOnApplyWindowInsetsListener((v,insets)->{
            int topInset=Math.max(0,insets.getSystemWindowInsetTop());
            int bottomInset=Math.max(0,insets.getSystemWindowInsetBottom());
            v.setPadding(0,dp(4),0,dp(92)+bottomInset);
            return insets;
        });

        hero=pic(heroImgs[0]);
        hero.setBackground(round(Color.WHITE,Color.rgb(225,228,240),16));
        hero.setClipToOutline(true);
        hero.setOnClickListener(v->{if(SessionManager.isAdmin(this)){openAdminFolder("DASHBOARD BANNERS","dashboard_banner");return;}String t=(slide>=0&&slide<remoteHeroTargets.length)?remoteHeroTargets[slide]:"";if(FeatureRegistry.isSafeHttpUrl(t)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(t)));}catch(Exception ignored){}}});
        page.addView(hero,top(lp(-1,dp(118)),6));

        dots=text("●   ○   ○   ○   ○   ○",BLUE,9,true);
        dots.setGravity(Gravity.CENTER);
        page.addView(dots,lp(-1,dp(17)));

        newPeopleSection=newPeopleSection(); newPeopleSection.setVisibility(View.GONE); page.addView(newPeopleSection,top(lp(-1,dp(126)),4));

        page.addView(feedComposerSection(),top(lp(-1,-2),6));

        feedStatus=text(LanguageManager.t(this,"loadingFeed"),MUTED,8.8f,false);
        feedStatus.setGravity(Gravity.CENTER);
        page.addView(feedStatus,top(lp(-1,dp(32)),7));

        feedList=col();
        page.addView(feedList,lp(-1,-2));

        scroll.addView(page,new ScrollView.LayoutParams(-1,-2));
        scroll.setOnScrollChangeListener((v,sx,sy,osx,osy)->{
            View child=scroll.getChildAt(0);
            if(child!=null && sy+scroll.getHeight()>=child.getHeight()-dp(420)) loadFeed(false);
            updateInlineVideoPlayback();
        });

        FrameLayout.LayoutParams scrollLp=new FrameLayout.LayoutParams(-1,-1); scrollLp.topMargin=dp(284); root.addView(scroll,scrollLp);
        root.addView(fixed,new FrameLayout.LayoutParams(-1,dp(284),Gravity.TOP));

        FrameLayout.LayoutParams navLp=new FrameLayout.LayoutParams(-1,dp(70),Gravity.BOTTOM);
        navLp.setMargins(dp(8),0,dp(8),dp(3));
        root.addView(bottom(),navLp);

        root.setOnApplyWindowInsetsListener((v,insets)->{int ti=Math.max(0,insets.getSystemWindowInsetTop()); fixed.setPadding(dp(4),ti+dp(8),dp(4),0); FrameLayout.LayoutParams fp=(FrameLayout.LayoutParams)fixed.getLayoutParams();fp.height=ti+dp(284);fixed.setLayoutParams(fp);FrameLayout.LayoutParams sp=(FrameLayout.LayoutParams)scroll.getLayoutParams();sp.topMargin=ti+dp(284);scroll.setLayoutParams(sp);return insets;});
        root.post(root::requestApplyInsets);
        return root;
    }


    private View header(){
        LinearLayout h=row();
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(dp(1),dp(2),dp(1),dp(1));
        h.setBackground(round(Color.WHITE,Color.TRANSPARENT,18));

        ImageView av=new ImageView(this); headerAvatar=av;
        av.setImageResource(R.drawable.myshop_profile_avatar);
        av.setScaleType(ImageView.ScaleType.CENTER_CROP);
        av.setBackground(round(Color.WHITE,Color.rgb(224,228,239),24));
        av.setClipToOutline(true);
        av.setContentDescription("Profile menu");
        String avatarUrl=SessionManager.getAvatarUrl(this);
        if(avatarUrl!=null&&!avatarUrl.isEmpty())loadRemoteImage(av,avatarUrl);
        av.setOnClickListener(v->startActivity(new Intent(this,UserMenuActivity.class)));
        h.addView(av,lp(dp(45),dp(45)));

        LinearLayout brandBox=row(); brandBox.setGravity(Gravity.CENTER_VERTICAL); brandBox.setPadding(dp(4),0,0,0);
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.myshop_icon); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); brandBox.addView(logo,lp(dp(34),dp(39)));
        LinearLayout words=col(); words.setGravity(Gravity.CENTER_VERTICAL); words.setPadding(dp(4),0,0,0);
        LinearLayout brandWords=row();
        brandWords.addView(text("MY",Color.rgb(24,28,70),12,true),lp(dp(25),dp(18)));
        brandWords.addView(text("SHOP",Color.rgb(245,141,0),12,true),lp(dp(42),dp(18)));
        words.addView(brandWords,lp(dp(70),dp(19)));
        words.addView(text("Shop • Social • Live • Earn",MUTED,6.5f,false),lp(dp(100),dp(14)));
        brandBox.addView(words,lp(dp(102),dp(36)));
        h.addView(brandBox,lp(dp(139),dp(45)));
        h.addView(space(),weight(1,1));

        TextView lang=text("🌐 "+languageCode()+"⌄",BLUE,8.7f,true);
        lang.setGravity(Gravity.CENTER);
        lang.setSingleLine(true);
        lang.setMinWidth(dp(58)); lang.setMinHeight(dp(44));
        lang.setBackground(round(Color.rgb(245,247,255),Color.rgb(232,235,246),12));
        lang.setOnClickListener(v->LanguageManager.showPicker(this,()->recreate()));
        h.addView(lang,lp(dp(58),dp(44)));

        FrameLayout bellBox=new FrameLayout(this);
        bellBox.setMinimumWidth(dp(44)); bellBox.setMinimumHeight(dp(48));
        ImageView bell=new ImageView(this);
        bell.setImageResource(R.drawable.notification_bell);
        bell.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        bell.setContentDescription("Notifications");
        bell.setPadding(dp(5),dp(5),dp(5),dp(5));
        bellBox.addView(bell,new FrameLayout.LayoutParams(-1,-1));
        notificationBadge=text("",Color.WHITE,7.5f,true);
        notificationBadge.setGravity(Gravity.CENTER);
        notificationBadge.setBackground(round(RED,RED,9));
        FrameLayout.LayoutParams badgeLp=new FrameLayout.LayoutParams(dp(18),dp(18),Gravity.TOP|Gravity.END);
        bellBox.addView(notificationBadge,badgeLp);
        View.OnClickListener openNotifications=v->startActivity(new Intent(this,NotificationActivity.class));
        bellBox.setOnClickListener(openNotifications); bell.setOnClickListener(openNotifications); notificationBadge.setOnClickListener(openNotifications);
        h.addView(bellBox,lp(dp(44),dp(48)));
        updateNotificationBadge();

        FrameLayout chatBox=new FrameLayout(this);
        ImageView chat=new ImageView(this);
        chat.setImageResource(R.drawable.myshop_chat_icon_v236);
        chat.setScaleType(ImageView.ScaleType.CENTER_CROP);
        chat.setPadding(dp(4),dp(4),dp(4),dp(4));
        chat.setBackground(round(Color.rgb(245,247,255),Color.rgb(232,235,246),13));
        chat.setContentDescription("Messages");
        chatBox.addView(chat,new FrameLayout.LayoutParams(-1,-1));
        messageBadge=text("",Color.WHITE,7.5f,true); messageBadge.setGravity(Gravity.CENTER); messageBadge.setBackground(round(RED,RED,9));
        FrameLayout.LayoutParams mb=new FrameLayout.LayoutParams(dp(18),dp(18),Gravity.TOP|Gravity.END); chatBox.addView(messageBadge,mb);
        View.OnClickListener openMessages=v->startActivity(new Intent(this,InboxActivity.class));
        chatBox.setOnClickListener(openMessages);chat.setOnClickListener(openMessages);messageBadge.setOnClickListener(openMessages);
        h.addView(chatBox,lp(dp(45),dp(45))); updateMessageBadge();
        return h;
    }

    private View threeLineMenu(){
        LinearLayout box=col(); box.setGravity(Gravity.CENTER); box.setPadding(dp(5),dp(6),dp(5),dp(6)); box.setBackground(round(Color.TRANSPARENT,Color.TRANSPARENT,12));
        int[] colors={Color.rgb(31,64,180),Color.rgb(245,141,0),Color.rgb(27,163,105)};
        for(int i=0;i<colors.length;i++){ View line=new View(this); line.setBackground(round(colors[i],Color.TRANSPARENT,3)); LinearLayout.LayoutParams q=lp(dp(30),dp(5)); if(i>0)q.topMargin=dp(4); box.addView(line,q); }
        return box;
    }


    private View breaking(){
        LinearLayout b=row();
        b.setPadding(dp(5),dp(1),dp(5),dp(1));
        b.setBackground(round(Color.rgb(255,239,247),Color.rgb(255,214,232),11));

        TextView megaphone=text("📣",PINK,17,true);
        megaphone.setGravity(Gravity.CENTER);
        megaphone.setContentDescription("Breaking news");
        b.addView(megaphone,lp(dp(34),dp(36)));

        ObjectAnimator sx=ObjectAnimator.ofFloat(megaphone,"scaleX",1f,1.13f,1f);
        ObjectAnimator sy=ObjectAnimator.ofFloat(megaphone,"scaleY",1f,1.13f,1f);
        ObjectAnimator al=ObjectAnimator.ofFloat(megaphone,"alpha",1f,.72f,1f);
        sx.setRepeatCount(ValueAnimator.INFINITE); sy.setRepeatCount(ValueAnimator.INFINITE); al.setRepeatCount(ValueAnimator.INFINITE);
        sx.setDuration(1250); sy.setDuration(1250); al.setDuration(1250);
        AnimatorSet glow=new AnimatorSet(); glow.playTogether(sx,sy,al); glow.start();

        newsTextSizeSp=Math.max(newsTextSizeSp,12.5f);
        newsText=text("আপনার উন্নয়ন ও নতুন ফিচার যুক্ত করার খবর এখানে দেখাবে",Color.rgb(65,70,98),newsTextSizeSp,true);
        newsText.setGravity(Gravity.CENTER_VERTICAL);
        newsText.setSingleLine(true);
        newsText.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        newsText.setMarqueeRepeatLimit(-1);
        newsText.setSelected(true);
        newsText.setHorizontallyScrolling(true);
        newsText.setPadding(dp(5),0,dp(5),0);
        b.addView(newsText,weight(1,dp(36)));

        b.setOnClickListener(v->{if(SessionManager.isAdmin(this)){Intent i=new Intent(this,AdminSectionActivity.class);i.putExtra("section","dashboard");i.putExtra("admin_context",true);startActivity(i);}});
        applyRipple(b);
        return b;
    }

    private View doublePromos(){
        LinearLayout r=row(); ImageView a=pic(left[0]),b=pic(right[0]); promoViews[0]=a; promoViews[1]=b;
        if(SessionManager.isAdmin(this)){View.OnClickListener admin=v->startActivity(new Intent(this,BannerAdminActivity.class).putExtra("admin_context",true)); a.setOnClickListener(admin); b.setOnClickListener(admin);}else{a.setOnClickListener(v->openPromoTarget(0));b.setOnClickListener(v->openPromoTarget(1));} r.addView(a,weight(1,dp(74))); r.addView(space(),lp(dp(6),1)); r.addView(b,weight(1,dp(74))); return r;
    }

    private View sectionTitle(String title,boolean all){
        LinearLayout h=row(); h.addView(text(title,DARK,13,true),weight(1,dp(28))); if(all){TextView a=text("View All",BLUE,9.5f,true);a.setGravity(Gravity.CENTER);a.setOnClickListener(v->openFeature("LIVE","live_now"));h.addView(a,lp(dp(58),dp(28)));} return h;
    }

    private View liveRow(){
        dynamicFolderBox=row(); dynamicFolderBox.setGravity(Gravity.CENTER_VERTICAL); dynamicFolderBox.setPadding(dp(1),0,dp(1),0);
        renderDynamicFolders(null);
        return dynamicFolderBox;
    }

    /** V-230: dynamic dashboard content remains INSIDE the existing small circular/live row.
     * No second placeholder row is created. Each slot has its own Admin editor. */
    private void renderDynamicFolders(JSONArray a){
        if(dynamicFolderBox==null)return;
        dynamicFolderBox.removeAllViews();
        JSONObject[] slots=new JSONObject[6];
        if(a!=null){
            for(int i=0;i<a.length();i++){
                JSONObject x=a.optJSONObject(i); if(x==null)continue;
                String cat=x.optString("category","").trim().toLowerCase();
                if(cat.startsWith("dashboard_slot_")){
                    try{int n=Integer.parseInt(cat.substring("dashboard_slot_".length()));if(n>=1&&n<=6&&slots[n-1]==null)slots[n-1]=x;}catch(Exception ignored){}
                }
            }
        }
        String[] defaults={"Shopping Live","Gadget Live","Fashion Live","Gaming Live","Beauty Live","AD"};
        String[] viewers={"1.2K","956","743","2.1K","1.8K",""};
        for(int i=0;i<6;i++){
            JSONObject cfg=slots[i];
            boolean slotActive=cfg==null || cfg.optInt("active",1)==1;
            boolean adminMode=SessionManager.isAdmin(this);
            if(!slotActive && !adminMode) continue; // hidden for normal users; Admin can still tap to restore
            LinearLayout wrap=col(); wrap.setGravity(Gravity.CENTER_HORIZONTAL); wrap.setPadding(dp(1),0,dp(1),0); wrap.setAlpha(slotActive?1f:0.48f);
            String title=cfg==null?defaults[i]:cfg.optString("title",defaults[i]).trim(); if(title.isEmpty())title=defaults[i]; if(!slotActive&&adminMode)title=title+" • HIDDEN";
            String caption=cfg==null?"":cfg.optString("caption","").trim();
            String url=cfg==null?"":cfg.optString("url","").trim();
            String image=cfg==null?"":cfg.optString("image_url","").trim();
            String iconUrl=cfg==null?"":cfg.optString("icon_url","").trim();
            FrameLayout card=new FrameLayout(this); card.setBackground(round(Color.WHITE,Color.rgb(255,72,182),40));
            ImageView im=new ImageView(this); im.setScaleType(ImageView.ScaleType.CENTER_CROP); im.setBackground(round(Color.WHITE,Color.TRANSPARENT,40)); im.setClipToOutline(true);
            if(i==5) im.setTag("live_folder_ad");
            if(!image.isEmpty())loadRemoteImage(im,image); else if(!iconUrl.isEmpty())loadRemoteImage(im,iconUrl); else im.setImageResource(i==5?R.drawable.banner_top_left_3:live[i%live.length]);
            card.addView(im,new FrameLayout.LayoutParams(dp(52),dp(52),Gravity.CENTER));
            TextView badge=text("● LIVE",Color.WHITE,6.3f,true); badge.setGravity(Gravity.CENTER); badge.setBackground(round(RED,Color.TRANSPARENT,8)); FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(50),dp(16),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL); card.addView(badge,bp);
            wrap.addView(card,lp(dp(56),dp(58)));
            final int slot=i+1; final String target=url; final String slotTitle=title;
            wrap.setOnClickListener(v->{
                if(SessionManager.isAdmin(this)){openFeatureCardAdmin("dashboard_slot_"+slot,"DASHBOARD SLOT "+slot);return;}
                if(FeatureRegistry.isSafeHttpUrl(target)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception ignored){}}
                else if(slot<=5)openFeature(slotTitle,"live_now");
            });
            dynamicFolderBox.addView(wrap,weight(1,dp(64)));
        }
    }

    private View liveStreamingSection(){
        LinearLayout box=col();
        box.setPadding(dp(8),dp(3),dp(8),dp(3));
        box.setBackground(gradient(Color.rgb(27,15,105),Color.rgb(66,24,183),18));

        LinearLayout titleRow=row();
        TextView signal=text("◉",Color.rgb(255,41,105),18f,true); signal.setGravity(Gravity.CENTER);
        TextView title=text("LIVE STREAMING",Color.WHITE,16f,true); title.setGravity(Gravity.CENTER_VERTICAL);
        TextView crown=text("♛  Live Your Moment  →",Color.rgb(255,225,106),7.6f,true); crown.setGravity(Gravity.CENTER); crown.setBackground(round(Color.rgb(24,30,92),Color.rgb(255,196,56),12));
        titleRow.addView(signal,lp(dp(30),dp(28))); titleRow.addView(title,weight(1,dp(28))); titleRow.addView(crown,lp(dp(112),dp(26)));
        box.addView(titleRow,lp(-1,dp(30)));

        LinearLayout actions=row(); actions.setPadding(0,dp(1),0,dp(2)); actions.setClipChildren(false); actions.setClipToPadding(false); box.setClipChildren(false);
        TextView go=text("▣  Go Live\nStart Audio Live",Color.WHITE,10.0f,true); go.setGravity(Gravity.CENTER); go.setLines(2); go.setBackground(gradient(Color.rgb(255,39,115),Color.rgb(220,25,207),22)); applyRipple(go); go.setOnClickListener(v->openFeature("GO LIVE","go_live"));
        TextView join=text("●●●  Join Live\nExplore Live Rooms     →",Color.WHITE,12.2f,true); join.setGravity(Gravity.CENTER); join.setLines(2); join.setBackground(gradient(Color.rgb(0,198,244),Color.rgb(64,52,236),22)); applyRipple(join); join.setOnClickListener(v->openFeature("JOIN LIVE","live_now"));
        ObjectAnimator goX=ObjectAnimator.ofFloat(go,"scaleX",1f,1.018f,1f), goY=ObjectAnimator.ofFloat(go,"scaleY",1f,1.018f,1f), goA=ObjectAnimator.ofFloat(go,"alpha",.88f,1f,.88f);
        goX.setRepeatCount(ValueAnimator.INFINITE);goY.setRepeatCount(ValueAnimator.INFINITE);goA.setRepeatCount(ValueAnimator.INFINITE);
        AnimatorSet goPulse=new AnimatorSet(); goPulse.playTogether(goX,goY,goA); goPulse.setDuration(1500); goPulse.start();
        ObjectAnimator joinX=ObjectAnimator.ofFloat(join,"scaleX",1f,1.032f,1f), joinY=ObjectAnimator.ofFloat(join,"scaleY",1f,1.032f,1f), joinA=ObjectAnimator.ofFloat(join,"alpha",.86f,1f,.86f);
        joinX.setRepeatCount(ValueAnimator.INFINITE);joinY.setRepeatCount(ValueAnimator.INFINITE);joinA.setRepeatCount(ValueAnimator.INFINITE);
        AnimatorSet joinPulse=new AnimatorSet(); joinPulse.playTogether(joinX,joinY,joinA); joinPulse.setDuration(1150); joinPulse.start();
        LinearLayout.LayoutParams glp=weight(34,dp(48)); glp.setMargins(0,0,dp(5),0); actions.addView(go,glp); actions.addView(join,weight(66,dp(48))); box.addView(actions,lp(-1,dp(51)));

        LinearLayout tabs=row();
        TextView liveNow=text("●  Live Now",Color.WHITE,8.8f,true); liveNow.setGravity(Gravity.CENTER); liveNow.setBackground(round(Color.rgb(65,24,147),Color.rgb(255,44,170),11));
        TextView popular=text("★  Popular",Color.rgb(226,229,255),8.2f,true); popular.setGravity(Gravity.CENTER);
        TextView following=text("●  Following",Color.rgb(226,229,255),8.2f,true); following.setGravity(Gravity.CENTER);
        TextView nearby=text("◷  Nearby",Color.rgb(226,229,255),8.2f,true); nearby.setGravity(Gravity.CENTER);
        TextView see=text("See All  →",Color.WHITE,8.6f,true); see.setGravity(Gravity.CENTER); see.setOnClickListener(v->openFeature("LIVE STREAMING","live_now"));
        liveNow.setOnClickListener(v->openFeature("LIVE NOW","live_now")); popular.setOnClickListener(v->openFeature("POPULAR LIVE","live_now")); following.setOnClickListener(v->openFeature("FOLLOWING LIVE","live_now")); nearby.setOnClickListener(v->openFeature("NEARBY LIVE","live_now"));
        tabs.addView(liveNow,lp(dp(76),dp(24))); tabs.addView(popular,weight(1,dp(24))); tabs.addView(following,weight(1,dp(24))); tabs.addView(nearby,weight(1,dp(24))); tabs.addView(see,lp(dp(70),dp(24))); box.addView(tabs,lp(-1,dp(26)));

        box.addView(liveRow(),lp(-1,dp(64)));
        return box;
    }

    private View newPeopleSection(){
        LinearLayout box=col(); box.setPadding(dp(6),dp(4),dp(6),dp(4)); box.setBackground(round(Color.WHITE,Color.rgb(229,231,240),14));
        LinearLayout head=row(); TextView title=text("New People",NAVY,10.5f,true); head.addView(title,weight(1,dp(24))); TextView see=text("See All  →",BLUE,8.5f,true); see.setGravity(Gravity.CENTER); see.setOnClickListener(v->showAllNewPeople()); head.addView(see,lp(dp(76),dp(24))); box.addView(head,lp(-1,dp(24)));
        newPeopleScroll=new HorizontalScrollView(this); newPeopleScroll.setHorizontalScrollBarEnabled(false); newPeopleScroll.setFillViewport(false); newPeopleRow=row(); newPeopleScroll.addView(newPeopleRow,new HorizontalScrollView.LayoutParams(-2,dp(90))); box.addView(newPeopleScroll,lp(-1,dp(90))); return box;
    }

    private void loadNewPeople(){
        String token=SessionManager.getToken(this);if(token==null||token.isEmpty())return;
        renderCachedNewPeople();
        BackendClient.newPeople(token,20,0,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                getSharedPreferences("myshop_people",MODE_PRIVATE).edit().putString("latest",d.toString()).apply();
                applyNewPeoplePayload(d);
            }
            public void onError(String m){ }
        });
    }
    private boolean renderCachedNewPeople(){try{String raw=getSharedPreferences("myshop_people",MODE_PRIVATE).getString("latest","");if(raw.isEmpty())return false;applyNewPeoplePayload(new JSONObject(raw));return true;}catch(Exception e){return false;}}
    private void applyNewPeoplePayload(JSONObject d){JSONArray a=d.optJSONArray("people");newPeopleData.clear();if(a!=null)for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p!=null&&!SessionManager.getUserId(this).equals(p.optString("userId","")))newPeopleData.add(p);}runOnUiThread(this::renderNewPeople);}
    private void renderNewPeople(){
        if(newPeopleSection==null||newPeopleRow==null)return;newPeopleRow.removeAllViews();
        if(newPeopleData.isEmpty()){newPeopleSection.setVisibility(View.GONE);return;}
        newPeopleSection.setVisibility(View.VISIBLE);int visible=Math.min(5,newPeopleData.size());int cardWidth=Math.max(dp(66),(getResources().getDisplayMetrics().widthPixels-dp(18))/5);
        for(int i=0;i<visible;i++)newPeopleRow.addView(newPersonCard(newPeopleData.get(i)),lp(cardWidth,dp(88)));
    }
    private View newPersonCard(JSONObject p){
        LinearLayout c=col();c.setGravity(Gravity.CENTER_HORIZONTAL);c.setPadding(dp(2),0,dp(2),0);c.setOnClickListener(v->{Intent q=new Intent(this,UserProfileActivity.class);q.putExtra("userId",p.optString("userId",""));startActivity(q);});
        ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setBackground(round(Color.rgb(239,241,248),Color.rgb(223,226,237),24));av.setClipToOutline(true);String url=p.optString("avatarUrl","");if(!url.isEmpty())loadRemoteImage(av,url);c.addView(av,lp(dp(42),dp(42)));
        TextView name=text(p.optString("name","New Member"),DARK,7.2f,true);name.setGravity(Gravity.CENTER);name.setSingleLine(true);name.setEllipsize(TextUtils.TruncateAt.END);c.addView(name,lp(-1,dp(18)));
        String state=p.optString("state","NONE");TextView add=text("REQUESTED".equals(state)?"Requested":"INCOMING".equals(state)?"Respond":"+ Add Friend",Color.WHITE,6.7f,true);add.setGravity(Gravity.CENTER);add.setBackground(round("REQUESTED".equals(state)?MUTED:BLUE,Color.TRANSPARENT,10));applyRipple(add);
        if("REQUESTED".equals(state)){add.setEnabled(false);add.setAlpha(.72f);}else if("INCOMING".equals(state)){add.setOnClickListener(v->startActivity(new Intent(this,FriendRequestsActivity.class)));}else add.setOnClickListener(v->sendFriendRequest(p,add));
        c.addView(add,lp(dp(68),dp(23)));return c;
    }
    private void sendFriendRequest(JSONObject person,TextView button){String id=person.optString("userId","");String token=SessionManager.getToken(this);if(token==null||token.isEmpty()||id.isEmpty())return;button.setEnabled(false);BackendClient.sendFriendRequest(token,id,new BackendClient.Callback(){public void onSuccess(JSONObject d){try{person.put("state","REQUESTED");}catch(Exception ignored){}button.setText("Requested");button.setAlpha(.7f);}public void onError(String m){button.setEnabled(true);if(m!=null&&m.toLowerCase().contains("pending")){button.setText("Requested");button.setAlpha(.7f);}else toast(m);}});}
    private void showAllNewPeople(){startActivity(new Intent(this,NewPeopleActivity.class));}

    private View liveActions(){ return liveStreamingSection(); }

    private View liveAdStrip(){
        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); hs.setFillViewport(false);
        liveAdStripView=hs; liveAdBox=row(); liveAdBox.setPadding(dp(4),dp(4),dp(4),dp(4)); liveAdBox.setBackground(round(Color.WHITE,Color.rgb(232,233,238),16));
        renderPowerAds();
        hs.addView(liveAdBox,new HorizontalScrollView.LayoutParams(-2,dp(92))); return hs;
    }

    private void renderPowerAds(){
        if(liveAdBox!=null){ liveAdBox.removeAllViews(); liveAdBox.setVisibility(View.GONE); }
        if(liveAds.isEmpty()) return;
        int n=Math.min(6,liveAds.size()); JSONObject a=liveAds.get(liveAdIndex%n);
        final ImageView target=findLiveFolderAd(); if(target==null)return;
        String u=a.optString("image_url",""); if(!u.isEmpty())loadRemoteImage(target,u);
        target.setOnClickListener(v->{if(SessionManager.isAdmin(this)){startActivity(new Intent(this,DashboardAdsAdminActivity.class).putExtra("admin_context",true).putExtra("box_key","live_now"));return;}String t=a.optString("target_url","");if(FeatureRegistry.isSafeHttpUrl(t)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(t)));}catch(Exception ignored){}}});
    }
    private ImageView findLiveFolderAd(){ if(scroll==null)return null; return findImageByTag(scroll,"live_folder_ad"); }
    private ImageView findImageByTag(View v,String tag){ if(v instanceof ViewGroup){ ViewGroup g=(ViewGroup)v; for(int i=0;i<g.getChildCount();i++){View c=g.getChildAt(i);if(tag.equals(c.getTag())&&c instanceof ImageView)return (ImageView)c; ImageView r=findImageByTag(c,tag);if(r!=null)return r;}} return null; }

    private View mainFeatureGrid(){
        LinearLayout grid=row(); grid.setGravity(Gravity.CENTER);
        for(int i=0;i<5;i++){View v=mainFeatureCard(i);grid.addView(v,weight(1,dp(84)));if(i<4)grid.addView(space(),lp(dp(3),1));}
        return grid;
    }

    private View mainFeatureCard(final int idx){
        FrameLayout card=new FrameLayout(this); mainCards[idx]=card; card.setBackground(round(Color.WHITE,Color.rgb(232,233,238),15)); card.setElevation(dp(2));
        LinearLayout c=col(); c.setGravity(Gravity.CENTER); c.setPadding(dp(2),dp(5),dp(2),dp(3));
        ImageView iv=new ImageView(this); mainIconViews[idx]=iv; iv.setImageResource(mainIcons[idx]); iv.setScaleType(ImageView.ScaleType.CENTER_CROP); iv.setBackground(round(Color.rgb(245,246,252),Color.TRANSPARENT,13)); iv.setClipToOutline(true); c.addView(iv,lp(dp(46),dp(46)));
        TextView t=text(mainTitles[idx],DARK,8.2f,true); t.setGravity(Gravity.CENTER); t.setSingleLine(true); t.setEllipsize(TextUtils.TruncateAt.END); mainLabels[idx]=t; c.addView(t,lp(-1,dp(20)));
        card.addView(c,new FrameLayout.LayoutParams(-1,-1));
        card.setOnClickListener(v->{if(idx==4)showMoreQuickActions();else openFeature(mainLabels[idx].getText().toString(),mainKeys[idx]);}); return card;
    }

    private View feedComposerSection(){
        LinearLayout box=col(); box.setPadding(dp(8),dp(6),dp(8),dp(6)); box.setBackground(round(Color.WHITE,Color.rgb(226,229,238),14)); box.setElevation(dp(1));
        LinearLayout title=row(); ImageView feedIcon=new ImageView(this); feedIcon.setImageResource(R.drawable.dash_action_feed); feedIcon.setScaleType(ImageView.ScaleType.FIT_CENTER); feedIcon.setAdjustViewBounds(true); feedIcon.setBackground(round(Color.rgb(235,242,255),Color.TRANSPARENT,18)); title.addView(feedIcon,lp(dp(76),dp(34)));
        View.OnClickListener feedFolderTap=v->{if(SessionManager.isAdmin(this))openAdminFolder("MY FEED","my_feed");}; feedIcon.setOnClickListener(feedFolderTap);
        TextView power=text(powerAdText(),PURPLE,8.5f,true);applyPowerAdColors(power);power.setGravity(Gravity.CENTER_VERTICAL);power.setOnClickListener(feedFolderTap);title.addView(power,weight(1,dp(34)));
        TextView see=text("See All  →",BLUE,8,true); see.setGravity(Gravity.CENTER); see.setOnClickListener(v->{if(SessionManager.isAdmin(this)){openAdminFolder("MY FEED","my_feed");return;}if(scroll!=null)scroll.smoothScrollTo(0,0);}); title.addView(see,lp(dp(72),dp(30))); box.addView(title,lp(-1,dp(35)));

        LinearLayout compose=row(); ImageView av=new ImageView(this); composerAvatar=av; av.setImageResource(R.drawable.myshop_profile_avatar); av.setScaleType(ImageView.ScaleType.CENTER_CROP); av.setBackground(round(Color.rgb(238,240,248),Color.TRANSPARENT,20)); av.setClipToOutline(true); String avatarUrl=SessionManager.getAvatarUrl(this); if(avatarUrl!=null&&!avatarUrl.isEmpty())loadRemoteImage(av,avatarUrl); compose.addView(av,lp(dp(36),dp(36)));
        TextView hint=text("What's on your mind?",MUTED,9.5f,false); hint.setGravity(Gravity.CENTER_VERTICAL); hint.setPadding(dp(12),0,dp(8),0); hint.setBackground(round(Color.rgb(244,246,250),Color.rgb(231,233,240),15)); hint.setOnClickListener(v->showTextPostDialog()); compose.addView(hint,weight(1,dp(36))); box.addView(compose,top(lp(-1,dp(36)),3));

        LinearLayout acts=row(); TextView photo=miniFeedAction("▣  Photo",GREEN); TextView video=miniFeedAction("●  Video",RED); TextView post=miniFeedAction("➤  Post",PURPLE); photo.setOnClickListener(v->pickPost("image")); video.setOnClickListener(v->pickPost("video")); post.setOnClickListener(v->showTextPostDialog()); acts.addView(photo,weight(1,dp(28))); acts.addView(video,weight(1,dp(28))); acts.addView(post,weight(1,dp(28))); box.addView(acts,top(lp(-1,dp(28)),3));
        postLimit=text("",MUTED,7,false); postLimit.setVisibility(View.GONE); return box;
    }

    private TextView miniFeedAction(String label,int color){TextView t=text(label,color,8.3f,true);t.setGravity(Gravity.CENTER);t.setSingleLine(true);return t;}

    private View feedSection(){ return feedComposerSection(); }

    private void showFeedFilter(){
        new AlertDialog.Builder(this).setTitle(LanguageManager.t(this,"filter"))
                .setItems(new String[]{LanguageManager.t(this,"textPost"),LanguageManager.t(this,"galleryAction")},(d,w)->{if(w==0)showTextPostDialog();else pickPost("image");}).show();
    }

    private boolean renderCachedFeed(){
        try{String raw=getSharedPreferences("myshop_feed_cache",MODE_PRIVATE).getString("first_page","");if(raw.isEmpty())return false;JSONObject d=new JSONObject(raw);JSONArray a=d.optJSONArray("posts");if(a==null||a.length()==0)return false;feedList.removeAllViews();renderedPostIds.clear();postViews.clear();inlineVideos.clear();activeInlineVideo=null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)renderPost(x);}feedBefore=d.optLong("nextBefore",0);feedHasMore=d.optBoolean("hasMore",feedBefore>0);if(feedStatus!=null)feedStatus.setText("Updating Feed…");return true;}catch(Exception e){return false;}
    }
    private void loadFeed(boolean reset){
        lastFeedLoadAt=System.currentTimeMillis();
        if(feedLoading || (!feedHasMore && !reset)) return; String token=SessionManager.getToken(this); if(token==null||token.isEmpty()){if(feedStatus!=null)feedStatus.setText(LanguageManager.t(this,"loginFeed"));return;}
        feedLoading=true; boolean hadCache=false;
        if(reset){feedBefore=0;feedHasMore=true;hadCache=renderCachedFeed();if(!hadCache){if(feedList!=null){feedList.removeAllViews();renderedPostIds.clear();postViews.clear();showFeedSkeleton();}if(feedStatus!=null)feedStatus.setText("Loading latest posts…");}}
        final boolean cachedVisible=hadCache; final long before=reset?0:feedBefore;
        BackendClient.feedList(token,5,before,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{
            if(reset){pauseInlineVideos();feedList.removeAllViews();renderedPostIds.clear();postViews.clear();inlineVideos.clear();activeInlineVideo=null;getSharedPreferences("myshop_feed_cache",MODE_PRIVATE).edit().putString("first_page",d.toString()).apply();}
            JSONArray a=d.optJSONArray("posts");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)renderPost(x);}
            feedBefore=d.optLong("nextBefore",0);feedHasMore=feedBefore>0&&d.optBoolean("hasMore",false);int today=d.optInt("postsToday",0);boolean can=d.optBoolean("canPost",false);if(postLimit!=null)postLimit.setText(can?"Post today: "+today+"/1":"আজকের পোস্ট সম্পন্ন");if(feedStatus!=null)feedStatus.setText(feedHasMore?"Scroll down for more posts":LanguageManager.t(MainActivity.this,"feedEnd"));feedLoading=false;loadFocusedPostIfNeeded();
        });}public void onError(String m){runOnUiThread(()->{if(feedStatus!=null)feedStatus.setText(cachedVisible?"Saved posts shown • tap/scroll to retry":LanguageManager.t(MainActivity.this,"feedUnavailable")+m);feedLoading=false;});}});
    }
    private void showFeedSkeleton(){if(feedList==null)return;for(int i=0;i<2;i++){LinearLayout sk=col();sk.setPadding(dp(10),dp(10),dp(10),dp(10));sk.setBackground(round(Color.WHITE,Color.rgb(233,235,241),14));TextView a=text("",MUTED,1,false);a.setBackground(round(Color.rgb(236,238,244),Color.TRANSPARENT,12));sk.addView(a,lp(-1,dp(42)));TextView b=text("",MUTED,1,false);b.setBackground(round(Color.rgb(241,242,246),Color.TRANSPARENT,10));sk.addView(b,top(lp(-1,dp(110)),7));feedList.addView(sk,lp(-1,-2));feedList.addView(space(),lp(1,dp(8)));}}
    private void loadFocusedPostIfNeeded(){final long id=pendingFocusPostId;if(id<=0)return;View found=postViews.get(id);if(found!=null){scrollToPost(id);pendingFocusPostId=0;return;}BackendClient.feedPost(SessionManager.getToken(this),id,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONObject post=d.optJSONObject("post");if(post!=null)renderPostAtTop(post);scrollToPost(id);pendingFocusPostId=0;});}public void onError(String m){pendingFocusPostId=0;}});}
    private void scrollToPost(long id){View v=postViews.get(id);if(v==null||scroll==null)return;scroll.postDelayed(()->scroll.smoothScrollTo(0,Math.max(0,feedList.getTop()+v.getTop()-dp(12))),120);}

    private void renderPostAtTop(JSONObject x){ if(feedList==null||x==null)return; LinearLayout old=feedList; LinearLayout temp=old; renderPost(x); if(temp.getChildCount()>=2){ View card=temp.getChildAt(temp.getChildCount()-2); View gap=temp.getChildAt(temp.getChildCount()-1); temp.removeViewAt(temp.getChildCount()-1); temp.removeViewAt(temp.getChildCount()-1); temp.addView(card,0); temp.addView(gap,1);} }

    private void renderPost(JSONObject x){
        long id=x.optLong("id",0);if(id>0&&renderedPostIds.contains(id))return;if(id>0)renderedPostIds.add(id);String uid=x.optString("userId","");String name=x.optString("name","MY SHOP User");String avatar=x.optString("avatarUrl","");String cap=x.optString("caption","");String url=x.optString("mediaUrl","");String type=x.optString("mediaType","image"); final int likeCount=x.optInt("likeCount",0);
        LinearLayout card=col();card.setPadding(dp(10),dp(9),dp(10),dp(9));card.setBackground(round(Color.WHITE,Color.rgb(228,230,238),14));card.setElevation(dp(1));
        LinearLayout head=row();head.setOnClickListener(v->{Intent q=new Intent(this,UserProfileActivity.class);q.putExtra("userId",uid);startActivity(q);});ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setBackground(round(Color.rgb(238,240,248),Color.TRANSPARENT,20));av.setClipToOutline(true);if(!avatar.isEmpty())loadRemoteImage(av,avatar);head.addView(av,lp(dp(40),dp(40)));LinearLayout who=col();who.setPadding(dp(9),0,dp(5),0);TextView nm=text(name,Color.rgb(25,30,55),11,true);who.addView(nm,lp(-1,dp(22)));who.addView(text("ID "+uid+" • "+x.optString("createdAt",""),MUTED,7.5f,false),lp(-1,dp(16)));head.addView(who,weight(1,dp(40)));card.addView(head,lp(-1,dp(42)));
        if(!cap.isEmpty()){TextView c=text(cap,Color.rgb(35,38,52),14,false);c.setPadding(dp(2),dp(7),dp(2),dp(7));c.setMaxLines(8);c.setEllipsize(TextUtils.TruncateAt.END);card.addView(c,lp(-1,-2));}
        if(!url.isEmpty()){
            if("video".equalsIgnoreCase(type)){
                FrameLayout media=new FrameLayout(this); media.setBackground(round(Color.BLACK,Color.rgb(226,228,236),12)); media.setClipToOutline(true);
                ImageView thumb=new ImageView(this); thumb.setScaleType(ImageView.ScaleType.CENTER_CROP); thumb.setBackgroundColor(Color.BLACK); media.addView(thumb,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER)); loadVideoThumbnail(thumb,url);
                VideoView vv=new VideoView(this); vv.setBackgroundColor(Color.TRANSPARENT); vv.setVideoURI(Uri.parse(url)); vv.setTag(url);
                FrameLayout.LayoutParams vp=new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER); media.addView(vv,vp);
                TextView play=text("▶",Color.WHITE,22f,true); play.setGravity(Gravity.CENTER); play.setBackground(round(Color.argb(150,30,30,35),Color.TRANSPARENT,28)); FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(56),dp(56),Gravity.CENTER); media.addView(play,pp);
                TextView expand=text("⛶",Color.WHITE,15f,true); expand.setGravity(Gravity.CENTER); expand.setBackground(round(Color.argb(145,20,20,25),Color.TRANSPARENT,10)); FrameLayout.LayoutParams ep=new FrameLayout.LayoutParams(dp(40),dp(36),Gravity.TOP|Gravity.END); ep.setMargins(0,dp(8),dp(8),0); media.addView(expand,ep);
                final boolean[] prepared={false}; final android.media.MediaPlayer[] player={null};
                vv.setOnPreparedListener(mp->{try{prepared[0]=true;player[0]=mp;mp.setVolume(0f,0f);mp.setLooping(false);vv.seekTo(10);play.setVisibility(View.VISIBLE);}catch(Exception ignored){}});
                vv.setOnErrorListener((mp,what,extra)->{play.setText("↻");play.setVisibility(View.VISIBLE);return true;});
                View.OnClickListener toggle=v->{try{if(vv.isPlaying()){vv.pause();play.setText("▶");play.setVisibility(View.VISIBLE);}else{pauseInlineVideosExcept(vv);if(!prepared[0])vv.setVideoURI(Uri.parse(url));if(player[0]!=null)player[0].setVolume(1f,1f);vv.start();activeInlineVideo=vv;play.setText("▶");play.setVisibility(View.GONE);}}catch(Exception e){play.setText("↻");play.setVisibility(View.VISIBLE);}};
                vv.setOnClickListener(toggle); play.setOnClickListener(toggle); vv.setOnCompletionListener(mp->{play.setText("▶");play.setVisibility(View.VISIBLE);});
                expand.setOnClickListener(v->openFeedVideo(url));
                inlineVideos.add(vv); card.addView(media,top(lp(-1,dp(250)),4));
            }else{
                ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setBackground(round(Color.rgb(242,243,248),Color.TRANSPARENT,10));applyRipple(im);im.setOnClickListener(v->openFeedImage(url));card.addView(im,top(lp(-1,dp(260)),4));loadRemoteImage(im,url);
            }
        }
        LinearLayout actions=row(); actions.setPadding(0,0,0,0); final boolean initiallyLiked=x.optBoolean("liked",false); final int commentCount=x.optInt("commentCount",0);
        TextView like=text((initiallyLiked?"♥  Liked":"♡  Like")+"  "+likeCount,Color.rgb(45,48,70),8.5f,true); like.setGravity(Gravity.CENTER); like.setMinHeight(dp(30)); like.setPadding(dp(4),0,dp(4),0); like.setBackground(round(Color.WHITE,Color.rgb(220,223,232),10)); like.setElevation(dp(1)); applyRipple(like);
        TextView comment=text("▢  Comment  "+commentCount,Color.rgb(45,48,70),8.5f,true); comment.setGravity(Gravity.CENTER); comment.setMinHeight(dp(30)); comment.setPadding(dp(4),0,dp(4),0); comment.setBackground(round(Color.WHITE,Color.rgb(220,223,232),10)); comment.setElevation(dp(1)); applyRipple(comment);
        LinearLayout.LayoutParams ap1=lp(dp(78),dp(30)); ap1.setMargins(0,0,dp(4),0); LinearLayout.LayoutParams ap2=lp(dp(94),dp(30)); ap2.setMargins(0,0,dp(4),0); actions.addView(like,ap1); actions.addView(comment,ap2); TextView share=text("↗  Share",Color.rgb(45,48,70),8.5f,true); share.setGravity(Gravity.CENTER); share.setBackground(round(Color.WHITE,Color.rgb(220,223,232),10)); applyRipple(share); share.setOnClickListener(v->shareFeedPost(name,cap,url)); actions.addView(share,lp(dp(72),dp(30))); final long postId=id; final String ownerUid=uid; like.setOnClickListener(v->BackendClient.feedLike(SessionManager.getToken(this),postId,new BackendClient.Callback(){public void onSuccess(JSONObject d){like.setText((d.optBoolean("liked",false)?"♥  Liked":"♡  Like")+"  "+d.optInt("likeCount",0)); loadNotificationCount();}public void onError(String m){toast("Like failed: "+m);}})); comment.setOnClickListener(v->showCommentDialog(postId,comment));
        if(SessionManager.getUserId(this).equals(uid)||SessionManager.isAdmin(this)||SessionManager.isModerator(this)){TextView del=action("🗑",RED);del.setOnClickListener(v->deletePost(id));actions.addView(del,lp(dp(44),dp(34)));}
        card.addView(actions,top(lp(-1,dp(34)),6));if(id>0)postViews.put(id,card);feedList.addView(card,lp(-1,-2));feedList.addView(space(),lp(1,dp(9)));
    }

    private void pauseInlineVideos(){for(VideoView v:inlineVideos){try{if(v!=null&&v.isPlaying())v.pause();}catch(Exception ignored){}}activeInlineVideo=null;}
    private void pauseInlineVideosExcept(VideoView keep){for(VideoView v:inlineVideos){if(v==keep)continue;try{if(v!=null&&v.isPlaying())v.pause();}catch(Exception ignored){}}}
    private void updateInlineVideoPlayback(){
        if(inlineVideos.isEmpty()||scroll==null)return;
        android.graphics.Rect viewport=new android.graphics.Rect(); scroll.getGlobalVisibleRect(viewport);
        VideoView best=null; int bestArea=0;
        for(VideoView v:inlineVideos){if(v==null||!v.isShown())continue; android.graphics.Rect r=new android.graphics.Rect(); if(!v.getGlobalVisibleRect(r))continue; int area=Math.max(0,r.width())*Math.max(0,r.height()); if(area>bestArea){bestArea=area;best=v;}}
        int threshold=Math.max(1,scroll.getWidth()*dp(110));
        if(best!=null&&bestArea>threshold){ if(activeInlineVideo!=best){pauseInlineVideosExcept(best); try{best.start();activeInlineVideo=best;}catch(Exception ignored){}} }
        else if(activeInlineVideo!=null){try{activeInlineVideo.pause();}catch(Exception ignored){}activeInlineVideo=null;}
    }

    private void shareFeedPost(String name,String caption,String mediaUrl){try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");StringBuilder b=new StringBuilder();if(name!=null&&!name.isEmpty())b.append(name).append(" on MY SHOP\n");if(caption!=null&&!caption.isEmpty())b.append(caption).append("\n");if(mediaUrl!=null&&!mediaUrl.isEmpty())b.append(mediaUrl);i.putExtra(Intent.EXTRA_TEXT,b.toString().trim());startActivity(Intent.createChooser(i,"Share post"));}catch(Exception e){toast("Share is not available.");}}

    private void showCommentDialog(long postId, final TextView commentButton){
        LinearLayout wrap=col(); wrap.setPadding(dp(10),dp(4),dp(10),dp(4));
        TextView loading=text("Loading comments…",MUTED,9.5f,false); wrap.addView(loading,lp(-1,dp(28)));
        ScrollView sv=new ScrollView(this); sv.setVerticalScrollBarEnabled(false); LinearLayout comments=col(); sv.addView(comments,new ScrollView.LayoutParams(-1,-2)); wrap.addView(sv,lp(-1,dp(270)));
        EditText input=new EditText(this); input.setHint("Write a comment…"); input.setTextSize(11); input.setMinLines(2); input.setMaxLines(4); input.setBackground(round(Color.rgb(246,247,251),Color.rgb(222,225,234),12)); wrap.addView(input,top(lp(-1,dp(64)),6));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Comments").setView(wrap).setNegativeButton(LanguageManager.t(this,"cancel"),null).setPositiveButton("POST",null).create();
        dlg.setOnShowListener(x->{
            loadCommentsInto(postId,comments,loading);
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String text=input.getText().toString().trim();if(text.isEmpty())return;dlg.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);BackendClient.feedComment(SessionManager.getToken(this),postId,text,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{input.setText("");commentButton.setText("▢  Comment  "+d.optInt("commentCount",0));dlg.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);loadCommentsInto(postId,comments,loading);loadNotificationCount();});}public void onError(String m){runOnUiThread(()->{dlg.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);toast("Comment failed: "+m);});}});});
        });
        dlg.show();
    }
    private void loadCommentsInto(long postId,LinearLayout list,TextView status){status.setText("Loading comments…");BackendClient.feedComments(SessionManager.getToken(this),postId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{list.removeAllViews();JSONArray a=d.optJSONArray("comments");if(a==null||a.length()==0){status.setText("No comments yet");return;}status.setText(a.length()+" comment"+(a.length()==1?"":"s"));for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;LinearLayout row=row();row.setPadding(dp(4),dp(5),dp(4),dp(5));ImageView av=new ImageView(MainActivity.this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setClipToOutline(true);av.setBackground(round(Color.rgb(238,240,248),Color.TRANSPARENT,18));String au=c.optString("avatarUrl","");if(!au.isEmpty())loadRemoteImage(av,au);row.addView(av,lp(dp(36),dp(36)));LinearLayout body=col();body.setPadding(dp(8),0,0,0);body.addView(text(c.optString("name","MY SHOP User"),DARK,9.5f,true),lp(-1,dp(19)));body.addView(text(c.optString("comment",""),Color.rgb(45,48,64),10.5f,false),lp(-1,-2));body.addView(text(c.optString("createdAt",""),MUTED,7.5f,false),lp(-1,dp(17)));row.addView(body,weight(1,-2));list.addView(row,lp(-1,-2));}});}public void onError(String m){runOnUiThread(()->status.setText("Comments unavailable: "+m));}});}

    private void loadVideoThumbnail(ImageView view,String url){imagePool.execute(()->{MediaMetadataRetriever r=new MediaMetadataRetriever();try{r.setDataSource(url,new java.util.HashMap<String,String>());Bitmap b=r.getFrameAtTime(0,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);if(b!=null)runOnUiThread(()->view.setImageBitmap(b));}catch(Exception ignored){}finally{try{r.release();}catch(Exception ignored){}}});}

    private void openFeedVideo(String url){LinearLayout box=col();box.setPadding(dp(8),dp(8),dp(8),dp(8));box.setBackgroundColor(Color.BLACK);VideoView v=new VideoView(this);box.addView(v,lp(-1,dp(520)));LinearLayout actions=row();TextView close=action("CLOSE",Color.rgb(70,73,86));TextView down=action("DOWNLOAD VIDEO",BLUE);actions.addView(close,weight(1,dp(46)));actions.addView(space(),lp(dp(8),1));actions.addView(down,weight(1,dp(46)));box.addView(actions,top(lp(-1,dp(46)),8));AlertDialog dlg=new AlertDialog.Builder(this).setView(box).create();close.setOnClickListener(q->{try{v.stopPlayback();}catch(Exception ignored){}dlg.dismiss();});down.setOnClickListener(q->downloadVideo(url));dlg.setOnDismissListener(q->{try{v.stopPlayback();}catch(Exception ignored){}});dlg.show();if(dlg.getWindow()!=null){dlg.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);dlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.BLACK));}v.setVideoURI(Uri.parse(url));v.setOnPreparedListener(mp->{mp.setLooping(false);v.start();});}

    private void downloadVideo(String url){try{DownloadManager dm=(DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE);DownloadManager.Request r=new DownloadManager.Request(Uri.parse(url));r.setTitle("MY SHOP Video");r.setDescription("Downloading video");r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);r.setMimeType("video/mp4");r.setDestinationInExternalPublicDir(Environment.DIRECTORY_MOVIES,"MY SHOP/MY_SHOP_"+System.currentTimeMillis()+".mp4");dm.enqueue(r);toast("✓ Video download started");}catch(Exception e){toast("Video download failed. Please try again.");}}

    private void openFeedImage(String url){
        final AlertDialog[] holder=new AlertDialog[1]; LinearLayout box=col();box.setPadding(dp(8),dp(8),dp(8),dp(8));box.setBackgroundColor(Color.BLACK);
        ImageView full=new ImageView(this);full.setScaleType(ImageView.ScaleType.FIT_CENTER);full.setBackgroundColor(Color.BLACK);box.addView(full,lp(-1,dp(520)));loadRemoteImage(full,url);
        LinearLayout actions=row();TextView close=action("CLOSE",Color.rgb(70,73,86));TextView save=action("SAVE PHOTO",BLUE);actions.addView(close,weight(1,dp(46)));actions.addView(space(),lp(dp(8),1));actions.addView(save,weight(1,dp(46)));box.addView(actions,top(lp(-1,dp(46)),8));
        AlertDialog dlg=new AlertDialog.Builder(this).setView(box).create();holder[0]=dlg;close.setOnClickListener(v->dlg.dismiss());save.setOnClickListener(v->{save.setEnabled(false);save.setText("SAVING…");saveImageToGallery(url,ok->runOnUiThread(()->{save.setEnabled(true);save.setText("SAVE PHOTO");toast(ok?"✓ Photo saved to gallery":"Save failed. Please try again.");}));});dlg.show();
        if(dlg.getWindow()!=null){dlg.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);dlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.BLACK));}
    }
    private interface SaveResult{void done(boolean ok);}
    private void saveImageToGallery(String url,SaveResult result){imagePool.execute(()->{boolean ok=false;try{Bitmap bm=imageCache.get(url);if(bm==null){HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(12000);c.setRequestProperty("User-Agent","MY-SHOP/2.9.241");try(InputStream in=c.getInputStream()){bm=BitmapFactory.decodeStream(in);}c.disconnect();}if(bm==null)throw new Exception("decode failed");String name="MY_SHOP_"+System.currentTimeMillis()+".jpg";if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/MY SHOP");v.put(MediaStore.Images.Media.IS_PENDING,1);Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(u==null)throw new Exception("insert failed");try(OutputStream out=getContentResolver().openOutputStream(u)){if(out==null||!bm.compress(Bitmap.CompressFormat.JPEG,95,out))throw new Exception("write failed");}v.clear();v.put(MediaStore.Images.Media.IS_PENDING,0);getContentResolver().update(u,v,null,null);ok=true;}else{File dir=new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES),"MY SHOP");if(!dir.exists())dir.mkdirs();File f=new File(dir,name);try(OutputStream out=new FileOutputStream(f)){if(!bm.compress(Bitmap.CompressFormat.JPEG,95,out))throw new Exception("write failed");}MediaScannerConnection.scanFile(MainActivity.this,new String[]{f.getAbsolutePath()},new String[]{"image/jpeg"},null);ok=true;}}catch(Exception ignored){}result.done(ok);});}

    private void deletePost(long id){new AlertDialog.Builder(this).setTitle("Delete this post?").setMessage("The post will be removed. User account and Permanent ID will not be affected.").setNegativeButton(LanguageManager.t(this,"cancel"),null).setPositiveButton("DELETE",(d,w)->{BackendClient.Callback cb=new BackendClient.Callback(){public void onSuccess(JSONObject x){toast("✓ Post removed");loadFeed(true);}public void onError(String m){toast("Delete failed: "+m);}};if(SessionManager.isAdmin(this)||SessionManager.isModerator(this))BackendClient.moderatorFeedDelete(SessionManager.getToken(this),id,"Removed from Feed",cb);else BackendClient.feedDelete(SessionManager.getToken(this),id,cb);}).show();}

    private void pickPost(String type){
        if(SessionManager.getToken(this)==null||SessionManager.getToken(this).isEmpty()){startActivity(new Intent(this,AccountActivity.class));return;}
        Intent i=new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);
        i.setType("video".equals(type)?"video/*":"image/*");
        pendingPostMime="video".equals(type)?"video/mp4":"image/jpeg";
        startActivityForResult(i,PICK_POST);
    }

    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r!=PICK_POST||c!=RESULT_OK||data==null||data.getData()==null)return;pendingPostUri=data.getData();showPostCaptionDialog();}
    private void showPostCaptionDialog(){EditText cap=new EditText(this);cap.setHint(LanguageManager.t(this,"caption"));cap.setMinLines(3);new AlertDialog.Builder(this).setTitle(LanguageManager.t(this,"createPost")).setMessage("User: 1 photo/video + caption per day. Public videos automatically appear in Videos.").setView(cap).setNegativeButton(LanguageManager.t(this,"cancel"),null).setPositiveButton(LanguageManager.t(this,"post"),(d,w)->uploadPost(cap.getText().toString().trim())).show();}
    private void showTextPostDialog(){
        final EditText cap=new EditText(this);
        cap.setHint(LanguageManager.t(this,"writePost"));
        cap.setMinLines(4);
        cap.setGravity(Gravity.TOP|Gravity.START);
        cap.setPadding(dp(10),dp(8),dp(10),dp(8));
        new AlertDialog.Builder(this)
                .setTitle(LanguageManager.t(this,"textPost"))
                .setMessage("Write a text-only post. No photo is required.")
                .setView(cap)
                .setNegativeButton(LanguageManager.t(this,"cancel"),null)
                .setPositiveButton(LanguageManager.t(this,"post"),(d,w)->uploadTextPost(cap.getText().toString().trim()))
                .show();
    }

    private void uploadTextPost(String caption){
        if(caption.isEmpty()){toast("Please write something first.");return;}
        String token=SessionManager.getToken(this);
        if(token==null||token.isEmpty()){startActivity(new Intent(this,AccountActivity.class));return;}
        BackendClient.feedText(token,caption,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{toast("✓ Post published");JSONObject post=d.optJSONObject("post");if(post!=null&&feedList!=null){renderPostAtTop(post);}else{loadFeed(true);}});}
            public void onError(String m){runOnUiThread(()->toast("Post failed: "+m));}
        });
    }
    private void uploadPost(String caption){
        if(pendingPostUri==null){toast("Please select a photo first.");return;}
        try{
            InputStream in=getContentResolver().openInputStream(pendingPostUri);
            if(in==null){toast("Selected media could not be opened. Please choose it again.");return;}
            String mime=getContentResolver().getType(pendingPostUri);
            if(mime==null||mime.trim().isEmpty())mime=pendingPostMime;
            String name=queryName(pendingPostUri);
            String mediaType=mime.toLowerCase().startsWith("video/")?"video":"image";
            BackendClient.feedUpload(SessionManager.getToken(this),in,name,mime,mediaType,caption,new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->{toast("✓ Post published");pendingPostUri=null;JSONObject post=d.optJSONObject("post");if(post!=null&&feedList!=null)renderPostAtTop(post);else loadFeed(true);});}
                public void onError(String m){runOnUiThread(()->toast("Post failed: "+m));}
            });
        }catch(Exception e){toast("Could not open selected media. Please choose the file again.");}
    }
    private String queryName(Uri u){try(android.database.Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}catch(Exception ignored){}return "myshop-post";}

    private View bottom(){
        LinearLayout n=row(); n.setPadding(dp(3),dp(2),dp(3),dp(2)); n.setBackground(round(Color.WHITE,Color.rgb(225,227,236),20)); n.setElevation(dp(7));
        n.addView(navItem(R.drawable.nav_home,LanguageManager.t(this,"home"),true,"home",Color.rgb(36,82,190)),weight(1,dp(62)));
        n.addView(navItem(R.drawable.nav_store,LanguageManager.t(this,"store"),false,"store",Color.rgb(245,139,0)),weight(1,dp(62)));
        n.addView(navItem(R.drawable.nav_video,"Video",false,"video",Color.rgb(123,45,221)),weight(1,dp(62)));
        n.addView(navItem(R.drawable.nav_support,LanguageManager.t(this,"support"),false,"support",Color.rgb(0,154,205)),weight(1,dp(62)));
        n.addView(navItem(R.drawable.nav_more,LanguageManager.t(this,"more"),false,"more",Color.rgb(113,38,220)),weight(1,dp(62))); return n;
    }

    private View navItem(int iconRes,String label,boolean active,String key,int color){
        LinearLayout item=col(); item.setGravity(Gravity.CENTER_HORIZONTAL); item.setPadding(dp(2),dp(2),dp(2),0);
        ImageView g=new ImageView(this); g.setImageResource(iconRes); g.setScaleType(ImageView.ScaleType.CENTER_INSIDE); g.setContentDescription(label);
        g.setImageTintList(ColorStateList.valueOf(color)); g.setAlpha(1f); item.addView(g,lp(-1,dp(31)));
        TextView t=text(label,color,8.8f,true); t.setGravity(Gravity.CENTER); t.setSingleLine(true); item.addView(t,lp(-1,dp(18)));
        Space spacer=new Space(this); item.addView(spacer,new LinearLayout.LayoutParams(-1,0,1f));
        TextView line=text("",color,1,true); line.setBackground(round(color,Color.TRANSPARENT,2)); line.setVisibility(active?View.VISIBLE:View.INVISIBLE); item.addView(line,lp(dp(29),dp(3)));
        item.setBackground(round(active?Color.rgb(235,241,255):Color.TRANSPARENT,Color.TRANSPARENT,12)); applyRipple(item);
        item.setOnClickListener(v->{
            if("home".equals(key)){if(scroll!=null)scroll.smoothScrollTo(0,0);return;}
            if("video".equals(key))startActivity(new Intent(this,ShortVideoActivity.class));
            else if("store".equals(key))openFeature("MY SHOP","my_shop");
            else if("support".equals(key))openSupport();
            else if("more".equals(key))showMoreQuickActions();
        }); return item;
    }

    private void showMoreQuickActions(){
        final PopupWindow[] holder=new PopupWindow[1];
        LinearLayout sheet=col(); sheet.setPadding(dp(12),dp(9),dp(12),dp(12)); sheet.setBackground(round(Color.WHITE,Color.rgb(226,229,238),22));
        LinearLayout head=row(); head.addView(text("More",Color.rgb(22,34,86),15,true),weight(1,dp(34))); TextView close=text("✕",MUTED,15,true); close.setGravity(Gravity.CENTER); head.addView(close,lp(dp(38),dp(34))); sheet.addView(head,lp(-1,dp(36)));
        sheet.addView(text("Shop • Media • Orders • Support • Settings",MUTED,8,false),lp(-1,dp(22)));
        String[] labels=SessionManager.isAdmin(this)
                ?new String[]{"My Shop","Gallery","Videos","Messages","External Media","Earn & Reward","Categories","Orders","Cart","Social Links","Customer Support","Settings","Share App","Admin Panel"}
                :new String[]{"My Shop","Gallery","Videos","Messages","External Media","Earn & Reward","Categories","Orders","Cart","Social Links","Customer Support","Settings","Share App"};
        int[] icons=SessionManager.isAdmin(this)
                ?new int[]{R.drawable.ui_shop_hd,R.drawable.ui_gallery_hd,R.drawable.ui_video_hd,R.drawable.ui_message_hd,R.drawable.ui_movie_hd,R.drawable.ui_reward_hd,R.drawable.ui_categories_hd,R.drawable.ui_orders_hd,R.drawable.ui_cart_hd,R.drawable.ui_social_hd,R.drawable.ui_support_hd,R.drawable.ui_settings_hd,R.drawable.ui_share_hd,R.drawable.ui_admin_hd}
                :new int[]{R.drawable.ui_shop_hd,R.drawable.ui_gallery_hd,R.drawable.ui_video_hd,R.drawable.ui_message_hd,R.drawable.ui_movie_hd,R.drawable.ui_reward_hd,R.drawable.ui_categories_hd,R.drawable.ui_orders_hd,R.drawable.ui_cart_hd,R.drawable.ui_social_hd,R.drawable.ui_support_hd,R.drawable.ui_settings_hd,R.drawable.ui_share_hd};
        int cols=4; int index=0;
        while(index<labels.length){LinearLayout r=row();for(int c=0;c<cols;c++){if(index<labels.length){final String lab=labels[index];LinearLayout cell=quickCell(icons[index],lab);cell.setOnClickListener(v->{if(holder[0]!=null)holder[0].dismiss();runQuickAction(lab);});r.addView(cell,weight(1,dp(118)));index++;}else r.addView(space(),weight(1,dp(118)));}sheet.addView(r,top(lp(-1,dp(118)),4));}
        PopupWindow pop=new PopupWindow(sheet,ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT,true); holder[0]=pop; pop.setBackgroundDrawable(round(Color.WHITE,Color.TRANSPARENT,22)); pop.setOutsideTouchable(true); pop.setElevation(dp(12)); close.setOnClickListener(v->pop.dismiss()); pop.showAtLocation(getWindow().getDecorView(),Gravity.BOTTOM,0,dp(70));
        sheet.setTranslationY(dp(24)); sheet.setAlpha(0f); sheet.animate().translationY(0f).alpha(1f).setDuration(180).start();
    }
    private LinearLayout quickCell(int iconRes,String label){
        LinearLayout c=col(); c.setGravity(Gravity.CENTER); c.setPadding(dp(3),dp(5),dp(3),dp(4));
        ImageView i=new ImageView(this); i.setImageResource(iconRes); i.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        i.setPadding(dp(1),dp(1),dp(1),dp(1)); i.setBackground(round(Color.WHITE,Color.rgb(218,223,239),18)); i.setElevation(dp(2));
        c.addView(i,lp(dp(76),dp(76)));
        TextView t=text(label,DARK,10.8f,true); t.setGravity(Gravity.CENTER); t.setMaxLines(2); t.setMinHeight(dp(30));
        c.addView(t,lp(-1,dp(34))); c.setBackground(round(Color.rgb(252,253,255),Color.rgb(235,237,244),14)); applyRipple(c); return c;
    }
    private void runQuickAction(String label){
        if("My Shop".equals(label))openFeature("MY SHOP","my_shop");
        else if("Gallery".equals(label)){if(SessionManager.isAdmin(this))openAdminFolder("GALLERY","gallery");else startActivity(new Intent(this,GalleryActivity.class));}
        else if("Videos".equals(label))startActivity(new Intent(this,ShortVideoActivity.class));
        else if("Messages".equals(label))startActivity(new Intent(this,InboxActivity.class));
        else if("External Media".equals(label))openFeature("EXTERNAL MEDIA","external_movie");
        else if("Earn & Reward".equals(label))openFeature("EARN & REWARD","earn_reward");
        else if("Categories".equals(label))openDirectFeature("CATEGORIES","categories");
        else if("Orders".equals(label))openDirectFeature("ORDERS","orders");
        else if("Cart".equals(label))openDirectFeature("CART","cart");
        else if("Social Links".equals(label))openDirectFeature("SOCIAL LINKS","social_media");
        else if("Customer Support".equals(label))openSupport();
        else if("Settings".equals(label))openDirectFeature("SETTINGS","settings");
        else if("Share App".equals(label)){if(SessionManager.isAdmin(this))openAdminFolder("SHARE APP","share");else shareAppFromDashboard();}
        else if("Admin Panel".equals(label)){if(SessionManager.isAdmin(this))startActivity(new Intent(this,AdminHubActivity.class));}
    }
    private void openDirectFeature(String title,String key){try{if("chat".equals(key)){startActivity(new Intent(this,InboxActivity.class));return;}if(SessionManager.isAdmin(this)){openAdminFolder(title,key);return;}Intent i=new Intent(MainActivity.this,FeatureActivity.class);i.putExtra("title",title);i.putExtra("feature_key",key);String u=featureRemoteUrl(key);if(FeatureRegistry.isSafeHttpUrl(u))i.putExtra("url",u);startActivity(i);}catch(Throwable t){toast(title+" is ready.");}}
    private void openAdminFolder(String title,String key){Intent i=new Intent(this,AdminFolderActivity.class);i.putExtra("title",title);i.putExtra("feature_key",key);i.putExtra("admin_context",true);startActivity(i);}
    private void shareAppFromDashboard(){try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"MY SHOP");i.putExtra(Intent.EXTRA_TEXT,"MY SHOP — https://rapid-bush-62ea.myshopsatkania.workers.dev");startActivity(Intent.createChooser(i,"Share MY SHOP"));}catch(Exception e){toast("Share is not available.");}}

    private void openSupport(){ if(SessionManager.isAdmin(this)){openAdminFolder("CUSTOMER SUPPORT","help_support");return;} Intent i=new Intent(MainActivity.this,FeatureActivity.class); i.putExtra("title","CUSTOMER SUPPORT"); i.putExtra("feature_key","help_support"); startActivity(i); }
    private String powerAdText(){ String l=LanguageManager.get(this); if(LanguageManager.BN.equals(l))return "⚡  পাওয়ার অ্যাড বাই তৌহিদ"; if(LanguageManager.HI.equals(l))return "⚡  पावर ऐड द्वारा तौहिद"; if(LanguageManager.AR.equals(l))return "⚡  إعلان قوي بواسطة توحيد"; return "⚡  POWER AD by Touhid"; }
    private void applyPowerAdColors(TextView v){ String s=v.getText().toString(); SpannableString sp=new SpannableString(s); if(s.length()>0)sp.setSpan(new ForegroundColorSpan(Color.rgb(245,145,0)),0,1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); int mid=Math.min(s.length(),Math.max(1,s.length()/2)); sp.setSpan(new ForegroundColorSpan(Color.rgb(91,38,214)),1,mid,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); if(mid<s.length())sp.setSpan(new ForegroundColorSpan(Color.rgb(235,45,100)),mid,s.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); v.setText(sp); }

    private void loadCurrentProfile(){String token=SessionManager.getToken(this);if(token==null||token.isEmpty())return;BackendClient.me(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){JSONObject u=d.optJSONObject("user");if(u!=null){String avatar=u.optString("avatarUrl","").trim();SessionManager.saveProfile(MainActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""),avatar,u.optString("bio",""));runOnUiThread(()->{if(!avatar.isEmpty()){if(headerAvatar!=null)loadRemoteImage(headerAvatar,avatar);if(composerAvatar!=null)loadRemoteImage(composerAvatar,avatar);}});}}public void onError(String m){}});}
    private void loadRemote(){BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{applyRemote(d);if(newsText!=null&&newsText.getTextSize()/getResources().getDisplayMetrics().scaledDensity<11.5f)newsText.setTextSize(11.5f);});}public void onError(String m){}});}
    private void applyRemote(JSONObject d){try{JSONObject c=d.optJSONObject("config");if(c!=null){String n=c.optString("breaking_news","").trim();if(!n.isEmpty()&&newsText!=null)newsText.setText(n);newsTextSizeSp=(float)Math.max(7.0,Math.min(16.0,c.optDouble("breaking_news_text_size",8.6)));if(newsText!=null)newsText.setTextSize(newsTextSizeSp);saveRemoteUrl("my_shop",c.optString("my_shop_url",""));saveRemoteUrl("live_tv",c.optString("live_tv_url",""));saveRemoteUrl("external_movie",c.optString("external_movie_url",""));saveRemoteUrl("chat",c.optString("chat_url",""));if(powerAdTitle!=null){powerAdTitle.setText(c.optString("power_ad_title","POWER AD").trim().isEmpty()?"POWER AD":c.optString("power_ad_title","POWER AD").trim());powerAdByline.setText(c.optString("power_ad_byline","by Touhid").trim().isEmpty()?"by Touhid":c.optString("power_ad_byline","by Touhid").trim());}if(ThemeConfig.cacheFromConfig(this,c)){handler.postDelayed(this::recreate,80);}}for(int z=0;z<remoteHeroUrls.length;z++){remoteHeroUrls[z]="";remoteHeroTargets[z]="";}for(int z=0;z<remotePromoUrls.length;z++){remotePromoUrls[z]="";remotePromoTargets[z]="";}JSONArray banners=d.optJSONArray("banners");if(banners!=null){for(int i=0;i<banners.length();i++){JSONObject o=banners.optJSONObject(i);if(o==null)continue;String folder=o.optString("folder","");int slot=o.optInt("slot",0);String url=o.optString("image_url","").trim();String target=o.optString("target_url","").trim();String updated=o.optString("updated_at","").trim();if(!updated.isEmpty()&&!url.contains("?"))url=url+"?v="+Uri.encode(updated);if(url.isEmpty())continue;if("hero".equalsIgnoreCase(folder)&&slot>=1&&slot<=6){remoteHeroUrls[slot-1]=url;remoteHeroTargets[slot-1]=target;}else if("promo".equalsIgnoreCase(folder)&&slot>=1&&slot<=3){remotePromoUrls[slot-1]=url;remotePromoTargets[slot-1]=target;}}}showFirstRemoteHeroIfAvailable();applyPromoSlide();JSONArray managedLinks=d.optJSONArray("managedLinks");renderDynamicFolders(managedLinks);applyManagedFeatureCards(managedLinks);JSONArray ads=d.optJSONArray("dashboardAds");liveAds.clear();if(ads!=null){for(int i=0;i<ads.length();i++){JSONObject o=ads.optJSONObject(i);if(o!=null&&"live_now".equalsIgnoreCase(o.optString("box_key","")))liveAds.add(o);}}if(liveAdStripView!=null)liveAdStripView.setVisibility(View.VISIBLE); renderPowerAds();JSONArray features=d.optJSONArray("featureButtons");if(features!=null){for(int i=0;i<features.length();i++){JSONObject f=features.optJSONObject(i);if(f==null)continue;String key=f.optString("key","");for(int j=0;j<mainKeys.length;j++)if(mainKeys[j].equals(key)){mainRemoteUrls[j]=f.optString("target_url","");}}}}catch(Exception ignored){}}
    private void saveRemoteUrl(String key,String url){if(url!=null&&!url.trim().isEmpty())getSharedPreferences("myshop_remote_config",MODE_PRIVATE).edit().putString("url_"+key,url.trim()).apply();}
    private void openFeatureCardAdmin(String category,String title){Intent a=new Intent(this,AdminSectionActivity.class);a.putExtra("section","feature_card");a.putExtra("managed_category",category);a.putExtra("managed_title",title);a.putExtra("admin_context",true);startActivity(a);}
    private void applyManagedFeatureCards(JSONArray links){
        android.content.SharedPreferences sp=getSharedPreferences("myshop_remote_config",MODE_PRIVATE); android.content.SharedPreferences.Editor ed=sp.edit();
        for(int j=0;j<mainKeys.length;j++){if(mainCards[j]!=null){mainCards[j].setVisibility(View.VISIBLE);mainCards[j].setAlpha(1f);}if(mainLabels[j]!=null)mainLabels[j].setText(mainTitles[j]);if(mainIconViews[j]!=null)mainIconViews[j].setImageResource(mainIcons[j]);ed.remove("managed_url_"+mainKeys[j]);ed.remove("managed_title_"+mainKeys[j]);}
        String[] clearKeys={"go_live","live_now","live_tv","external_movie","my_feed","social_media","earn_reward","more_apps","gallery","my_shop"}; for(String k:clearKeys)ed.remove("managed_url_"+k);
        if(links!=null)for(int i=0;i<links.length();i++){JSONObject x=links.optJSONObject(i);if(x==null)continue;String cat=x.optString("category","").trim();if(!cat.startsWith("feature_"))continue;String key=cat.substring(8);int active=x.optInt("active",1);String title=x.optString("title","").trim();String url=x.optString("url","").trim();String image=x.optString("image_url","").trim();String icon=x.optString("icon_url","").trim();ed.putInt("managed_active_"+key,active);ed.putString("managed_url_"+key,url);ed.putString("managed_title_"+key,title);for(int j=0;j<mainKeys.length;j++)if(mainKeys[j].equals(key)){boolean adminMode=SessionManager.isAdmin(this);if(mainCards[j]!=null){mainCards[j].setVisibility(active==1||adminMode?View.VISIBLE:View.GONE);mainCards[j].setAlpha(active==1?1f:0.48f);}if(mainLabels[j]!=null){if(active==1&&!title.isEmpty())mainLabels[j].setText(title);else if(active!=1&&adminMode)mainLabels[j].setText((title.isEmpty()?mainTitles[j]:title)+" • HIDDEN");}if(mainIconViews[j]!=null&&(active==1||adminMode)){mainIconViews[j].setImageResource(mainIcons[j]);if(!image.isEmpty())loadRemoteImage(mainIconViews[j],image);else if(!icon.isEmpty())loadRemoteImage(mainIconViews[j],icon);}}}
        ed.apply();
    }
    private String featureRemoteUrl(String key){String managed=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("managed_url_"+key,"").trim();if(!managed.isEmpty())return managed;for(int i=0;i<mainKeys.length;i++)if(mainKeys[i].equals(key))return mainRemoteUrls[i]==null?"":mainRemoteUrls[i].trim();return getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("url_"+key,"");}
    private void openFeature(String title,String key){try{
        if("more_apps".equals(key)){showMoreQuickActions();return;}
        if("chat".equals(key)){openDirectFeature(title,key);return;}
        if(SessionManager.isAdmin(this)){openAdminFolder(title,key);return;}
        if("gallery".equals(key)){startActivity(new Intent(this,GalleryActivity.class));return;}
        Intent i=new Intent(MainActivity.this,FeatureActivity.class);String managedTitle=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("managed_title_"+key,"").trim();i.putExtra("title",managedTitle.isEmpty()?title:managedTitle);i.putExtra("feature_key",key);String url=featureRemoteUrl(key);if("my_shop".equals(key)&&url.isEmpty())url=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("url_my_shop",url);if("external_movie".equals(key)&&url.isEmpty())url=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("url_external_movie",url);if(FeatureRegistry.isSafeHttpUrl(url))i.putExtra("url",url);else{String fallback=FeatureRegistry.getUrl(this,key);if(FeatureRegistry.isSafeHttpUrl(fallback))i.putExtra("url",fallback);}startActivity(i);}catch(Throwable t){toast(title+" is ready.");}}
    private void applyLiveAd(int index){if(liveAdImage==null||liveAds.isEmpty())return;JSONObject a=liveAds.get(index%liveAds.size());String u=a.optString("image_url","");String cap=a.optString("caption","");if(!u.isEmpty())loadRemoteImage(liveAdImage,u);liveAdCaption.setText(cap.isEmpty()?"Advertisement":cap);liveAdImage.setOnClickListener(v->{String target=a.optString("target_url","");if(FeatureRegistry.isSafeHttpUrl(target)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception ignored){}}});}
    private void startLiveAdCarousel(){handler.postDelayed(new Runnable(){public void run(){if(!liveAds.isEmpty()){liveAdIndex=(liveAdIndex+1)%liveAds.size();renderPowerAds();}handler.postDelayed(this,5000);}},5000);}
    private void openPromoTarget(int visibleIndex){int idx=(promoSlide+visibleIndex)%3;String t=remotePromoTargets[idx];if(FeatureRegistry.isSafeHttpUrl(t)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(t)));}catch(Exception ignored){}}}

    private void applyPromoSlide(){if(promoViews==null||promoViews.length<2)return;int idx=promoSlide%3;for(int i=0;i<2;i++){final int slotIndex=i;final int slideIndex=(idx+i)%3;final String u=remotePromoUrls[slideIndex];final ImageView v=promoViews[i];if(v==null)continue;v.animate().alpha(0.35f).setDuration(180).withEndAction(()->{if(u!=null&&!u.isEmpty())loadRemoteImage(v,u);else v.setImageResource(slotIndex==0?left[slideIndex%left.length]:right[slideIndex%right.length]);v.animate().alpha(1f).setDuration(260).start();}).start();}}
    private void startPromoCarousel(){handler.postDelayed(new Runnable(){public void run(){promoSlide=(promoSlide+1)%3;applyPromoSlide();handler.postDelayed(this,4000);}},4000);}

    private int nextHeroSlide(int current){
        boolean any=false; for(String u:remoteHeroUrls) if(u!=null&&!u.isEmpty()){any=true;break;}
        if(any){for(int step=1;step<=6;step++){int idx=(current+step)%6;if(remoteHeroUrls[idx]!=null&&!remoteHeroUrls[idx].isEmpty())return idx;}}
        return (current+1)%6;
    }
    private void showHeroSlide(int idx){
        slide=Math.max(0,Math.min(5,idx)); String u=remoteHeroUrls[slide];
        if(u!=null&&!u.isEmpty())loadRemoteImage(hero,u);else hero.setImageResource(heroImgs[slide]);
        StringBuilder b=new StringBuilder();for(int i=0;i<6;i++){b.append(i==slide?"●":"○");if(i<5)b.append("   ");}if(dots!=null)dots.setText(b.toString());
    }
    private void showFirstRemoteHeroIfAvailable(){
        for(int i=0;i<remoteHeroUrls.length;i++){if(remoteHeroUrls[i]!=null&&!remoteHeroUrls[i].isEmpty()){showHeroSlide(i);return;}}
        showHeroSlide(slide);
    }
    private void startCarousel(){handler.postDelayed(new Runnable(){public void run(){showHeroSlide(nextHeroSlide(slide));handler.postDelayed(this,3500);}},3500);}
    private void loadNotificationCount(){String token=SessionManager.getToken(this);if(token==null||token.isEmpty()){unreadNotificationCount=0;updateNotificationBadge();return;}BackendClient.notifications(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){unreadNotificationCount=Math.max(0,d.optInt("unreadCount",0));getSharedPreferences("myshop_notifications",MODE_PRIVATE).edit().putString("last_payload",d.toString()).apply();runOnUiThread(()->updateNotificationBadge());}public void onError(String m){}});}
    private void updateNotificationBadge(){if(notificationBadge==null)return;if(unreadNotificationCount<=0)notificationBadge.setVisibility(View.GONE);else{notificationBadge.setVisibility(View.VISIBLE);notificationBadge.setText(unreadNotificationCount>99?"99+":String.valueOf(unreadNotificationCount));}}
    private void loadMessageCount(){String token=SessionManager.getToken(this);if(token==null||token.isEmpty()){unreadMessageCount=0;updateMessageBadge();return;}BackendClient.messageUnread(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){unreadMessageCount=Math.max(0,d.optInt("unreadCount",0));runOnUiThread(()->updateMessageBadge());}public void onError(String m){}});}
    private void updateMessageBadge(){if(messageBadge==null)return;if(unreadMessageCount<=0)messageBadge.setVisibility(View.GONE);else{messageBadge.setVisibility(View.VISIBLE);messageBadge.setText(unreadMessageCount>99?"99+":String.valueOf(unreadMessageCount));}}
    private String languageCode(){String l=LanguageManager.get(this);if(LanguageManager.EN.equals(l))return "EN";if(LanguageManager.HI.equals(l))return "HI";if(LanguageManager.AR.equals(l))return "AR";return "বাং";}
    @Override protected void onResume(){super.onResume();loadCurrentProfile();loadRemote();loadNotificationCount();loadMessageCount();loadNewPeople();handler.removeCallbacks(notificationPoll);handler.postDelayed(notificationPoll,12000);if(feedList!=null&&!feedLoading&&(System.currentTimeMillis()-lastFeedLoadAt>30000))loadFeed(true);}
    @Override protected void onPause(){super.onPause();handler.removeCallbacks(notificationPoll);pauseInlineVideos();}
    private void loadRemoteImage(ImageView target,String url){
        if(target==null||url==null||url.trim().isEmpty())return; final String key=url.trim(); Bitmap cached=imageCache.get(key); if(cached!=null){target.setImageBitmap(cached);return;}
        target.setTag(key); imagePool.execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(key).openConnection();c.setConnectTimeout(6000);c.setReadTimeout(8000);c.setInstanceFollowRedirects(true);c.setUseCaches(true);try(InputStream in=c.getInputStream()){Bitmap bm=BitmapFactory.decodeStream(in);if(bm!=null){imageCache.put(key,bm);runOnUiThread(()->{if(key.equals(target.getTag()))target.setImageBitmap(bm);});}}c.disconnect();}catch(Exception ignored){}});
    }
    private void applyRipple(View v){
        if(android.os.Build.VERSION.SDK_INT>=21){
            android.graphics.drawable.Drawable base=v.getBackground();
            if(base==null)return;
            v.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.argb(42,30,55,120)),base,null));
        }
    }
    private TextView action(String s,int c){TextView t=text(s,Color.WHITE,9.5f,true);t.setGravity(Gravity.CENTER);t.setMinHeight(dp(44));t.setPadding(dp(10),0,dp(10),0);t.setBackground(gradient(c,Color.rgb(Math.max(0,Color.red(c)-18),Math.max(0,Color.green(c)-18),Math.max(0,Color.blue(c)-18)),12));t.setElevation(dp(2));applyRipple(t);return t;}
    private ImageView pic(int r){ImageView v=new ImageView(this);v.setImageResource(r);v.setScaleType(ImageView.ScaleType.FIT_XY);return v;}
    private Button icon(String s,int c,float z){Button b=new Button(this);b.setText(s);b.setTextColor(c);b.setTextSize(z);b.setGravity(Gravity.CENTER);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setPadding(0,0,0,0);b.setBackgroundColor(Color.TRANSPARENT);return b;}
    private TextView text(String s,int c,float z,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;} private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;} private View space(){return new View(this);} private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);} private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;} private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);} private GradientDrawable round(int fill,int stroke,int rad){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(rad));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;} private GradientDrawable gradient(int a,int b,int rad){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});g.setCornerRadius(dp(rad));return g;} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);pauseInlineVideos();imagePool.shutdownNow();super.onDestroy();}
}
