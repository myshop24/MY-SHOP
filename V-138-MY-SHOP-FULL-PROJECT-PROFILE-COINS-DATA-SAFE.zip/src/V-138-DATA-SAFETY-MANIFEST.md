# V-138 Data Safety Manifest

Protected baseline: V-137-MY-SHOP-FULL-PROJECT-BACKEND-R2-GALLERY-FIX.zip

Rules enforced in V-138:
1. Never reset or recreate production D1.
2. Never delete or regenerate permanent User IDs during an update.
3. Only additive schema changes are permitted.
4. New APK must point to the same Worker URL and existing D1/R2 bindings.
5. Release is not considered verified until Worker deep health reports database, schema, and R2 as OK.
6. Exactly one APK must exist in the final release directory.
