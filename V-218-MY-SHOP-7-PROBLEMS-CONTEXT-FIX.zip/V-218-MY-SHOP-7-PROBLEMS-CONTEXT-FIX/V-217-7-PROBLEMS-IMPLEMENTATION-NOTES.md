# MY SHOP V-217 — 7 Problems Implementation

Baseline: V-216 (successful build). V-216 is preserved; V-217 is a new source version.

Implemented in this source:
1. Customer Support: dedicated scrollable content area, real support icon, clean layout, clickable WhatsApp/HTTP target.
2. 3-line Menu: frontend reloads menu configuration from backend; configured title/icon/link/active state is applied; custom items remain supported; Admin Save/Edit/Delete controls retained.
3. Dashboard promo banners: backend returns updated_at; Android clears stale remote slots, cache-busts updated banner URLs, and uses smooth fade rotation across promo slots.
4. Notifications: Like/Comment notifications now include actor display name and post/comment context; existing unread/read system retained.
5. Dashboard dynamic folders: frontend renders backend-managed LIVE/ADVERTISEMENT/SOCIAL MEDIA/CAPTION entries with icon/image/title/caption/link.
6. Dynamic content Admin: new Admin folder with per-category Add/Edit/Save/Delete and Icon/Name/Image/Caption/Link fields; managed_links now stores caption with additive migration.
7. External links: Admin supports separate Name, Caption, URL, Icon URL, Image URL; frontend displays all and opens the URL on tap.

Safety:
- V-216 source remains untouched.
- Worker health marker updated to V-217.
- Existing permanent D1/R2 bindings retained.
- Existing V-212 workflow retained, including 100% Worker promotion.
- This file is not considered PASS until GitHub Actions builds the APK successfully and the APK is manually checked against Problems 1–7.

Important limitation:
- True automatic "who is live now" requires a live-room/broadcaster backend event source. V-217's Dashboard dynamic LIVE folder is ready to consume managed live entries, but it does not invent a live session or falsely report someone as live.
