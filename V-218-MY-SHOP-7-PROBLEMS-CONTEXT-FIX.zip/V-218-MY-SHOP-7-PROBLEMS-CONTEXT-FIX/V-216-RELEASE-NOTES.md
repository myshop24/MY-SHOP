# V-216 — MY SHOP 7-Problem Fix

Based on successful V-214 baseline. V-214 is preserved.

Implemented/fixed:
1. Customer Support layout and dedicated icon.
2. Page icon path retained/verified and TikTok added to More/Social list.
3. Added dedicated 3-line Menu management folder with SAVE/EDIT/DELETE controls.
4. Dashboard promo banners now rotate between configured promo slots instead of remaining static.
5. Like/Comment user notifications now contain actionable detail instead of generic text.
6. Dashboard content foundation extended with dynamic feature/managed-link fields; live broadcaster auto-feed remains dependent on the live-stream backend source.
7. External items now support name/caption, website URL and image URL; clicking opens the configured site.

Safety: V-214 was copied first; no V-214 files are overwritten.
