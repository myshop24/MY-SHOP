# V-214 MY SHOP — Social Save + Worker Promotion Fix

- Preserved the V-213 Social Save feature work.
- Fixed the Java checked `JSONException` compile error in `socialPayloadItem`.
- Fixed Worker promotion so the selected V-214 version is explicitly deployed at 100% traffic instead of leaving an older gradual deployment active.
- Bumped SOURCE_BUILD_ID, Android versionCode/versionName, and Worker health markers to V-214.
- V-211 remains a preserved working baseline.
