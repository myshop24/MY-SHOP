# MY SHOP V-218

- Fixed the GitHub Actions release-build failure in `UserMenuActivity.loadDynamicMenu`.
- Inside the anonymous `BackendClient.Callback`, `LanguageManager.showPicker(this, ...)` incorrectly passed the callback object as an Android `Context`.
- Changed it to `LanguageManager.showPicker(UserMenuActivity.this, ...)`.
- Added a workflow preflight guard so this exact callback-context mistake is caught before Gradle compilation in future versions.
- V-217 source/features remain the base; no old baseline version is overwritten.
