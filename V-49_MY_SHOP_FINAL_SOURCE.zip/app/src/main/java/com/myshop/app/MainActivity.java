package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** V-49 locked MY SHOP dashboard. Approved upper layout is preserved. */
public class MainActivity extends AppCompatActivity {
    private static final int WHITE = Color.WHITE, TEXT = Color.rgb(35,40,55), BLUE = Color.rgb(22,100,220), PURPLE = Color.rgb(105,54,220), PINK = Color.rgb(225,52,135), RED = Color.rgb(225,35,48), ORANGE = Color.rgb(244,135,20), CYAN = Color.rgb(25,150,180);
    private static final int MAX_BANNERS_PER_FOLDER = 6;
    private static final long SLIDE_MS = 3500L;
    private final Handler sliderHandler = new Handler();
    private int leftBanner=1,rightBanner=1,wideBanner=1,adBanner=1;
    private TextView leftBannerView,rightBannerView,wideBannerView;
    private final TextView[] liveSlots = new TextView[6];
    @Override protected void onCreate(Bundle b){super.onCreate(b);try{setContentView(buildDashboard());startCarousel();}catch(Throwable t){setContentView(buildSafeHome());}}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}
    private View buildDashboard(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(WHITE);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(10),dp(8),dp(10),dp(12));
        LinearLayout header=row();
        TextView profile=card("◉\nMY SHOP\nID: 0100",TEXT,WHITE);profile.setTextSize(13);header.addView(profile,weight(1,dp(68)));
        TextView brand=card("MY SHOP  •  LIVE",BLUE,WHITE);brand.setTextSize(17);header.addView(brand,weight(2,dp(68)));
        Button menu=button("☰\nMENU");menu.setTextColor(PURPLE);menu.setTextSize(12);header.addView(menu,lp(dp(70),dp(68)));menu.setOnClickListener(v->startActivity(new Intent(this,AccountActivity.class)));content.addView(header,lp(-1,dp(72)));
        LinearLayout top=row();leftBannerView=banner("LEFT BANNER 1 / 6",PURPLE);rightBannerView=banner("RIGHT BANNER 1 / 6",PINK);top.addView(leftBannerView,weight(1,dp(142)));top.addView(rightBannerView,weight(1,dp(142)));content.addView(top,lp(-1,dp(148)));
        wideBannerView=banner("FULL WIDTH BANNER 1 / 6",BLUE);LinearLayout.LayoutParams wlp=lp(-1,dp(132));wlp.topMargin=dp(7);content.addView(wideBannerView,wlp);
        TextView breaking=card("🔴  BREAKING NEWS   |   Admin can add unlimited headlines",TEXT,WHITE);breaking.setTextSize(14);LinearLayout.LayoutParams blp=lp(-1,dp(52));blp.topMargin=dp(7);content.addView(breaking,blp);
        LinearLayout approved=row();Button feed=feature("✨  MY FEED","my_feed",PURPLE);feed.setTextSize(15);Button shop=feature("🛍️  MY SHOP","my_shop",PINK);shop.setTextSize(15);approved.addView(feed,weight(1,dp(68)));approved.addView(shop,weight(1,dp(68)));content.addView(approved,lp(-1,dp(74)));
        TextView liveTitle=title("🔴 LIVE NOW    •    6 SMART SLOTS");liveTitle.setTextSize(16);content.addView(liveTitle,lp(-1,dp(46)));
        LinearLayout liveGrid=new LinearLayout(this);liveGrid.setOrientation(LinearLayout.VERTICAL);
        for(int r=0;r<3;r++){LinearLayout line=row();for(int c=0;c<2;c++){int i=r*2+c;liveSlots[i]=liveSlot(i+1);line.addView(liveSlots[i],weight(1,dp(104)));}liveGrid.addView(line,lp(-1,dp(110)));}content.addView(liveGrid,lp(-1,dp(330)));
        LinearLayout row1=row();row1.addView(feature("🖼️\nGALLERY","gallery",PURPLE),weight(1,dp(82)));row1.addView(feature("🎬\nEXTERNAL","external_movie",BLUE),weight(1,dp(82)));row1.addView(feature("📺\nLIVE TV","live_tv",RED),weight(1,dp(82)));content.addView(row1,lp(-1,dp(88)));
        LinearLayout row2=row();row2.addView(feature("📱\nSOCIAL","social_media",CYAN),weight(1,dp(82)));row2.addView(feature("🎁\nEARN","earn_reward",ORANGE),weight(1,dp(82)));row2.addView(feature("🔗\nSHARE","share",PURPLE),weight(1,dp(82)));content.addView(row2,lp(-1,dp(88)));
        Button goLive=feature("🎥  GO LIVE","go_live",RED);goLive.setTextSize(17);LinearLayout.LayoutParams glp=lp(dp(220),dp(62));glp.gravity=Gravity.CENTER;glp.topMargin=dp(6);glp.bottomMargin=dp(8);content.addView(goLive,glp);
        scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=row();nav.setPadding(dp(4),dp(4),dp(4),dp(4));nav.setBackgroundColor(WHITE);nav.addView(navButton("🏠\nHome",PURPLE),weight(1,dp(62)));Button store=navButton("🛍️\nStore",PINK);nav.addView(store,weight(1,dp(62)));Button live=navButton("🔴\nLive",RED);nav.addView(live,weight(1,dp(62)));nav.addView(navButton("💬\nChat",BLUE),weight(1,dp(62)));Button more=navButton("⋮\nMore",TEXT);nav.addView(more,weight(1,dp(62)));root.addView(nav,lp(-1,dp(70)));
        store.setOnClickListener(v->openFeature("MY SHOP","my_shop"));live.setOnClickListener(v->openFeature("LIVE","live_now"));more.setOnClickListener(v->startActivity(new Intent(this,AccountActivity.class)));return root;
    }
    private TextView banner(String t,int c){TextView v=card(t,WHITE,c);v.setTextSize(15);return v;}
    private TextView liveSlot(int n){TextView v=card("ADVERTISEMENT\nAd "+n+" / 6\nAdmin-controlled",TEXT,WHITE);v.setTextSize(12);return v;}
    private void startCarousel(){sliderHandler.postDelayed(new Runnable(){public void run(){leftBanner=leftBanner%6+1;rightBanner=rightBanner%6+1;wideBanner=wideBanner%6+1;adBanner=adBanner%6+1;if(leftBannerView!=null)leftBannerView.setText("LEFT BANNER "+leftBanner+" / 6");if(rightBannerView!=null)rightBannerView.setText("RIGHT BANNER "+rightBanner+" / 6");if(wideBannerView!=null)wideBannerView.setText("FULL WIDTH BANNER "+wideBanner+" / 6");for(int i=0;i<6;i++)liveSlots[i].setText("ADVERTISEMENT\nAd "+(((adBanner+i-1)%6)+1)+" / 6\nAdmin-controlled");sliderHandler.postDelayed(this,SLIDE_MS);}},SLIDE_MS);}
    @Override protected void onDestroy(){sliderHandler.removeCallbacksAndMessages(null);super.onDestroy();}
    private Button navButton(String l,int c){Button b=button(l);b.setTextColor(c);b.setTextSize(13);return b;}
    private Button feature(String l,String k,int c){Button b=button(l);b.setTextColor(c);b.setTextSize(12);b.setOnClickListener(v->openFeature(l,k));return b;}
    private Button button(String t){Button b=new Button(this);b.setText(t);b.setAllCaps(false);b.setGravity(Gravity.CENTER);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackgroundResource(R.drawable.bg_card);return b;}
    private TextView title(String t){return card(t,TEXT,WHITE);}
    private TextView card(String t,int fg,int bg){TextView v=new TextView(this);v.setText(t);v.setTextColor(fg);v.setTextSize(14);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setGravity(Gravity.CENTER);v.setPadding(dp(6),dp(6),dp(6),dp(6));v.setBackgroundColor(bg);return v;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER);return l;}
    private void openFeature(String t,String k){try{Intent i=new Intent(this,FeatureActivity.class);i.putExtra("title",t);i.putExtra("feature_key",k);startActivity(i);}catch(Throwable x){Toast.makeText(this,t+" is ready.",Toast.LENGTH_SHORT).show();}}
    private View buildSafeHome(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setGravity(Gravity.CENTER);r.setBackgroundColor(WHITE);TextView t=new TextView(this);t.setText("MY SHOP + LIVE\nHome Dashboard");t.setTextSize(26);t.setTextColor(PURPLE);t.setGravity(Gravity.CENTER);r.addView(t,lp(-1,-2));Button retry=button("OPEN DASHBOARD");retry.setOnClickListener(v->recreate());r.addView(retry,lp(-1,dp(64)));return r;}
}
