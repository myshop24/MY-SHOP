package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** V-46: Login screen aligned to the approved MY SHOP login reference. */
public class LoginActivity extends AppCompatActivity {
    private static final String BRAND = "MY SHOP + LIVE";
    private EditText loginId;
    private EditText loginPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // V-47: preserve the existing account/session across normal app updates.
        // This only works when Android performs an in-place update with the same signing key.
        String existingId = SessionManager.getUserId(this);
        if (SessionManager.isLoggedIn(this) && !existingId.isEmpty() && AccountStore.exists(this, existingId)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        loginId = findViewById(R.id.loginId);
        loginPassword = findViewById(R.id.loginPassword);
        Button login = findViewById(R.id.loginButton);
        TextView create = findViewById(R.id.createAccountButton);
        TextView forgot = findViewById(R.id.forgotButton);
        ImageButton toggle = findViewById(R.id.passwordToggle);

        create.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
        login.setOnClickListener(v -> login());
        forgot.setOnClickListener(v -> Toast.makeText(this, "Password reset will be connected to the secure backend.", Toast.LENGTH_LONG).show());
        toggle.setOnClickListener(v -> {
            int pos = loginPassword.getSelectionStart();
            boolean hidden = (loginPassword.getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) != 0;
            loginPassword.setInputType(InputType.TYPE_CLASS_TEXT | (hidden ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            loginPassword.setSelection(Math.max(0, pos));
        });
    }

    private void login() {
        String identifier = loginId.getText().toString().trim();
        String pass = loginPassword.getText().toString();
        if (identifier.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Email/Mobile and Password are required.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            AccountStore.Account account = AccountStore.authenticate(this, identifier, pass);
            if (account == null) {
                Toast.makeText(this, "Login failed. Check your Email/Mobile and Password.", Toast.LENGTH_LONG).show();
                return;
            }
            SessionManager.setSession(this, Role.USER, account.userId);
            SessionManager.saveProfile(this, account.name, account.email, account.mobile);
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        } catch (Throwable t) {
            Toast.makeText(this, "Login failed safely. Your account data was not changed.", Toast.LENGTH_LONG).show();
        }
    }
}
