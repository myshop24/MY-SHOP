package com.myshop.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Locale;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Local account cache/prototype only. The production source of truth must be the backend.
 * A single account can be found by either its email or mobile alias, while one permanent
 * User ID remains attached to that account. Passwords are stored as salted PBKDF2 hashes;
 * legacy SHA-256 records are accepted once and transparently upgraded on successful login.
 */
public final class AccountStore {
    private static final String PREFS = "myshop_accounts_v2";
    private static final String PREFIX = "acct_";
    private static final String HASH_PREFIX = "pbkdf2$";
    private static final SecureRandom RNG = new SecureRandom();

    private AccountStore() {}

    public static boolean create(Context context, String userId, String name,
                                 String email, String mobile, String password) {
        String emailKey = canonicalEmail(email);
        String mobileKey = canonicalMobile(mobile);
        if (emailKey.isEmpty() && mobileKey.isEmpty()) return false;
        if (password == null || password.length() < 6) return false;

        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if ((!emailKey.isEmpty() && p.contains(PREFIX + "email_" + emailKey))
                || (!mobileKey.isEmpty() && p.contains(PREFIX + "mobile_" + mobileKey))) {
            return false;
        }

        String record = PREFIX + "uid_" + userId;
        String hash = hashPassword(password);
        SharedPreferences.Editor e = p.edit()
                .putString(record + "_user_id", userId == null ? "" : userId)
                .putString(record + "_name", name == null ? "" : name)
                .putString(record + "_email", email == null ? "" : email)
                .putString(record + "_mobile", mobile == null ? "" : mobile)
                .putString(record + "_password_hash", hash);
        if (!emailKey.isEmpty()) e.putString(PREFIX + "email_" + emailKey, userId);
        if (!mobileKey.isEmpty()) e.putString(PREFIX + "mobile_" + mobileKey, userId);
        e.apply();
        return true;
    }

    public static Account authenticate(Context context, String identifier, String password) {
        String value = identifier == null ? "" : identifier.trim();
        if (value.isEmpty() || password == null) return null;
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String userId = value.contains("@")
                ? p.getString(PREFIX + "email_" + canonicalEmail(value), "")
                : p.getString(PREFIX + "mobile_" + canonicalMobile(value), "");

        // Backward compatibility with the older V-24 key layout.
        if (userId.isEmpty()) {
            String oldBase = PREFIX + (value.contains("@") ? canonicalEmail(value) : canonicalMobile(value));
            userId = p.getString(oldBase + "_user_id", "");
            if (!userId.isEmpty()) migrateLegacyRecord(p, oldBase, userId);
        }
        if (userId.isEmpty()) return null;

        String record = PREFIX + "uid_" + userId;
        String stored = p.getString(record + "_password_hash", "");
        if (!verifyPassword(password, stored)) return null;
        if (stored.startsWith("sha256:")) {
            p.edit().putString(record + "_password_hash", hashPassword(password)).apply();
        }
        return new Account(userId,
                p.getString(record + "_name", ""),
                p.getString(record + "_email", ""),
                p.getString(record + "_mobile", ""));
    }

    private static void migrateLegacyRecord(SharedPreferences p, String oldBase, String userId) {
        String record = PREFIX + "uid_" + userId;
        SharedPreferences.Editor e = p.edit()
                .putString(record + "_user_id", userId)
                .putString(record + "_name", p.getString(oldBase + "_name", ""))
                .putString(record + "_email", p.getString(oldBase + "_email", ""))
                .putString(record + "_mobile", p.getString(oldBase + "_mobile", ""))
                .putString(record + "_password_hash", p.getString(oldBase + "_password_hash", ""));
        String email = p.getString(record + "_email", "");
        String mobile = p.getString(record + "_mobile", "");
        if (!email.isEmpty()) e.putString(PREFIX + "email_" + canonicalEmail(email), userId);
        if (!mobile.isEmpty()) e.putString(PREFIX + "mobile_" + canonicalMobile(mobile), userId);
        e.apply();
    }

    private static String canonicalEmail(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.US);
    }

    private static String canonicalMobile(String value) {
        return value == null ? "" : value.replaceAll("[^0-9+]", "");
    }

    private static String hashPassword(String password) {
        try {
            byte[] salt = new byte[16];
            RNG.nextBytes(salt);
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 120000, 256);
            byte[] derived = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            return HASH_PREFIX + hex(salt) + "$" + hex(derived);
        } catch (Exception e) {
            throw new IllegalStateException("Secure password hashing unavailable", e);
        }
    }

    private static boolean verifyPassword(String password, String stored) {
        try {
            if (stored.startsWith(HASH_PREFIX)) {
                String[] parts = stored.split("\\$", -1);
                if (parts.length != 3) return false;
                byte[] salt = unhex(parts[1]);
                byte[] expected = unhex(parts[2]);
                PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 120000, expected.length * 8);
                byte[] actual = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
                return MessageDigest.isEqual(expected, actual);
            }
            if (stored.startsWith("sha256:")) {
                return stored.equals("sha256:" + sha256(password));
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private static String sha256(String value) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return hex(md.digest((value == null ? "" : value).getBytes(StandardCharsets.UTF_8)));
    }

    private static String hex(byte[] data) {
        StringBuilder out = new StringBuilder(data.length * 2);
        for (byte b : data) out.append(String.format(Locale.US, "%02x", b));
        return out.toString();
    }

    private static byte[] unhex(String s) {
        byte[] out = new byte[s.length() / 2];
        for (int i = 0; i < out.length; i++) out[i] = (byte) Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16);
        return out;
    }

    public static final class Account {
        public final String userId;
        public final String name;
        public final String email;
        public final String mobile;
        Account(String userId, String name, String email, String mobile) {
            this.userId = userId; this.name = name; this.email = email; this.mobile = mobile;
        }
    }
}
