@echo off
setlocal
set GRADLE_VERSION=8.9
set DIST_URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip
set BASE=%USERPROFILE%\.gradle
set DIST_DIR=%BASE%\wrapper\dists\gradle-%GRADLE_VERSION%-bin
set ZIP=%DIST_DIR%\gradle-%GRADLE_VERSION%-bin.zip
set INSTALL=%DIST_DIR%\gradle-%GRADLE_VERSION%
if not exist "%INSTALL%\bin\gradle.bat" (
  if not exist "%DIST_DIR%" mkdir "%DIST_DIR%"
  if not exist "%ZIP%" powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing '%DIST_URL%' -OutFile '%ZIP%'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%DIST_DIR%'"
)
call "%INSTALL%\bin\gradle.bat" %*
endlocal
