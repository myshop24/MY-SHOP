# MY SHOP V-60 CHANGELOG

Baseline: V-59 full source. No previous source files intentionally removed.

Fixed:
1. Admin Management was previously UI-only and every action stopped at a toast. V-60 adds working Admin-only local CRUD for banners, breaking news, gallery, social links and live TV, including media picker and delete.
2. Dashboard header fixed for narrow mobile widths by reducing fixed header dimensions while preserving the same header elements.
3. LIVE NOW no longer labels empty slots as advertisements; empty slots now clearly indicate that no live stream is currently available.
4. Permanent user/profile IDs are not modified by V-60 changes.
5. App version is 2.9.60 / versionCode 60.

Important: The backend API contract remains the authority for shared multi-device content. This V-60 UI provides functional local persistence; a production shared backend adapter must be connected to make admin changes visible across devices.
