# MY SHOP V-59 — GitHub Upload

1. Extract this ZIP into the repository root, or upload the extracted Android project files to the `main` branch.
2. Keep the `.github/workflows/MY_SHOP_V59_FINAL_BUILD.yml` workflow in the repository root under `.github/workflows/`.
3. This source package is a real Android project with `settings.gradle`, root `build.gradle`, and `app/build.gradle`.
4. The build workflow uses Gradle 8.9 directly, so a `gradlew` file is not required.
5. The source version is `versionCode 59`, `versionName 2.9.59`; the workflow changes it to a unique build version for every run.
6. Do not add older source ZIPs into the root repository when using the direct-source workflow.
