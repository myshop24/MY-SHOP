# MY SHOP V-57 — Corrected Source-to-APK Build

This package is intentionally a **root Android project**. GitHub Actions builds the files checked into the repository directly.

## Critical fixes
- No nested source ZIP is used by the workflow.
- Every new workflow run gets a new versionCode using GitHub Actions `run_number`.
- versionName is generated automatically as `2.9.<versionCode>`.
- Re-running the same workflow run is blocked.
- APK version/package are verified after build.
- Old `2.9.45` APK identity causes build failure.
- Exactly one APK artifact is uploaded.
- Existing V-55 source is not overwritten by this package.

## User ID
The app's current offline fallback allocates sequential 4-digit IDs starting at 0100. A true cross-device/server-permanent ID still requires the backend allocator; the source marks that requirement explicitly rather than falsely claiming local storage is permanent.
