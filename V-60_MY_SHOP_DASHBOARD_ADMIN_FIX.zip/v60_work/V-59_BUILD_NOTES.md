# MY SHOP V-59

This is the complete MY SHOP Android project based directly on the V-58 verified source backup.

## V-59 corrections
- No source ZIP is required inside the repository.
- No source ZIP is placed inside the GitHub Actions artifact.
- The workflow builds the Android project directly from the repository root.
- Java setup uses `actions/setup-java@v5`.
- The workflow creates a V-59 version (`5.9.x`) automatically.
- The workflow builds a debug-signed installable APK.
- APK signature, package metadata, version metadata, and ZIP integrity are verified.
- The final GitHub Actions artifact contains exactly one APK and no other file.
- Previous V-58 source is preserved as the basis; V-58 is not overwritten by this package.

## Important installation note
The V-58 artifact shown previously was a release APK without a usable signing certificate. V-59 intentionally uses the Android debug signing configuration so the produced APK is installable. If V-58 is installed with a different signing key, Android may require uninstalling V-58 before installing V-59.

## Repository structure
Extract this ZIP into the MY SHOP repository root so `.github/`, `app/`, `gradle/`, `settings.gradle`, and the other project files are at the repository root.
