package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

/** V-60: functional Admin management UI. Admin-only CRUD is persisted by stable content IDs. */
public class AdminManagementActivity extends AppCompatActivity {
    private boolean moderatorOnly;
    private LinearLayout listBox;
    private String activeType = "banners";
    private static final int PICK_MEDIA = 7001;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        moderatorOnly=getIntent().getBooleanExtra("moderator_only",false);
        if (moderatorOnly ? !SessionManager.isModerator(this) : !SessionManager.isAdmin(this)) { finish(); return; }
        buildUi();
    }

    private void buildUi() {
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(20,24,20,20);
        root.setBackgroundColor(getColor(R.color.myshop_bg));
        TextView title=new TextView(this); title.setText(moderatorOnly?"Moderator Controls":"Admin Controls"); title.setTextSize(25); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,70));
        if(moderatorOnly){ addAction(root,"Ban User ID",()->toast("Ban action is restricted to the connected backend.")); addAction(root,"Kick User",()->toast("Kick action is restricted to the connected backend.")); addAction(root,"Close Live",()->toast("Close Live action is restricted to the connected backend.")); }
        else {
            LinearLayout tabs=new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL);
            String[] names={"Banners","Breaking News","Gallery","Social","Live TV"}; String[] types={"banners","breaking_news","gallery","social_links","live_tv"};
            for(int i=0;i<names.length;i++){ final String t=types[i]; Button b=new Button(this); b.setText(names[i]); b.setAllCaps(false); b.setOnClickListener(v->{activeType=t; refreshList();}); tabs.addView(b,new LinearLayout.LayoutParams(0,58,1)); }
            root.addView(tabs);
            LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
            Button add=new Button(this); add.setText("＋ Add / Upload"); add.setAllCaps(false); add.setOnClickListener(v->addItem());
            Button refresh=new Button(this); refresh.setText("Refresh"); refresh.setOnClickListener(v->refreshList());
            actions.addView(add,new LinearLayout.LayoutParams(0,60,1)); actions.addView(refresh,new LinearLayout.LayoutParams(0,60,1)); root.addView(actions);
            ScrollView scroll=new ScrollView(this); listBox=new LinearLayout(this); listBox.setOrientation(LinearLayout.VERTICAL); scroll.addView(listBox); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
            Button back=new Button(this); back.setText("Back"); back.setOnClickListener(v->finish()); root.addView(back,new LinearLayout.LayoutParams(-1,60)); refreshList();
        }
        if(moderatorOnly){ Button back=new Button(this); back.setText("Back"); back.setOnClickListener(v->finish()); root.addView(back,new LinearLayout.LayoutParams(-1,60)); }
        setContentView(root);
    }

    private void addAction(LinearLayout root,String label,final Runnable r){ Button b=new Button(this); b.setText(label); b.setAllCaps(false); b.setOnClickListener(v->r.run()); root.addView(b,new LinearLayout.LayoutParams(-1,60)); }

    private void addItem(){
        if(!AdminContentStore.canUse(this)){toast("Admin permission required.");return;}
        if("gallery".equals(activeType) || "banners".equals(activeType)){
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_MEDIA); return;
        }
        final EditText input=new EditText(this); input.setHint("Enter content");
        new AlertDialog.Builder(this).setTitle("Add " + activeType).setView(input).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String s=input.getText().toString().trim(); if(!s.isEmpty()){AdminContentStore.add(this,activeType,s,s);refreshList();toast("Saved successfully");}}).show();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==PICK_MEDIA && resultCode==RESULT_OK && data!=null && data.getData()!=null){ Uri uri=data.getData(); try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){} AdminContentStore.add(this,activeType,uri.toString(),uri.toString()); refreshList(); toast("Uploaded successfully"); }}

    private void refreshList(){ if(listBox==null)return; listBox.removeAllViews(); List<AdminContentStore.Item> items=AdminContentStore.list(this,activeType); if(items.isEmpty()){TextView e=new TextView(this);e.setText("No items yet. Use Add / Upload.");e.setPadding(12,30,12,30);listBox.addView(e);return;} for(AdminContentStore.Item item:items){ LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); TextView t=new TextView(this); t.setText(item.title); t.setTextSize(15); t.setPadding(10,8,10,8); Button del=new Button(this);del.setText("Delete");del.setOnClickListener(v->{if(AdminContentStore.delete(this,activeType,item.id)){refreshList();toast("Deleted successfully");}}); row.addView(t,new LinearLayout.LayoutParams(0,70,1));row.addView(del,new LinearLayout.LayoutParams(100,60));listBox.addView(row); }}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
