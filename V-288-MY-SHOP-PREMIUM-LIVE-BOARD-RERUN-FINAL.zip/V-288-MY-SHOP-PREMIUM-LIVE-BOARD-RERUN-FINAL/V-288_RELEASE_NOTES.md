# V-288 Release Notes

## Purpose
Clean higher-version re-release of the approved V-287 Premium Live Board source so GitHub Actions can select and run a fresh V-numbered source ZIP.

## Preserved Live UI
- 10 golden speaker sofas in an even 5 + 5 layout.
- No seat-number/Seat text labels.
- Occupied sofas show user profile state.
- Compact audience/user row in the upper Live area.
- Gift above React on the lower-right side.
- Compact HH:MM Live timer beside Special Guest; no seconds.
- Red power-style Leave/End control at the upper-right.
- Premium Choose Live Type and Start Audio Live setup UI.
- No-scroll compact Live Room direction remains locked.

## Version Identity
- SOURCE_BUILD_ID: MY SHOP V-288
- SOURCE_VERSION_NAME: 2.9.288
- Android versionCode: 288
- Android versionName: 2.9.288
- Worker health identity: 2.9.288 / V-288

## Backend / Schema
No new schema migration was added in V-288. Existing V-287 migration `0009_v287_expand_live_speakers_to_10.sql` remains historical and must not be renamed after deployment.

## Build Note
V-288 is intended to force a clean newer-source selection in the permanent GitHub Actions workflow. If the new workflow run fails, use the exact red step/error log to diagnose the real build/deploy problem before making another version.
