package com.myshop.app;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

/**
 * MY SHOP V-288 Premium Audio Live Room.
 * 11-seat authoritative layout: Seat 1 Host + Seats 2-11 Speakers (10 golden sofas, 5 + 5).
 * The bundled Guitar Blue wallpaper is the safe default while Admin themes
 * can override it remotely without changing the Dashboard.
 */
public class AudioLiveRoomActivity extends AppCompatActivity {
    private final Handler handler = new Handler();
    private boolean host;
    private boolean hostStarted;
    private boolean localMicOn = true;
    private String hostId;
    private String specialGuestId = "";
    private String myRole = "AUDIENCE";
    private long startedAtMs = 0L;
    private int shareCount = 0;
    private ImageView wallpaper;
    private LinearLayout hostArea, audienceRow, specialArea, seats, requests, commentsList;
    private TextView viewers, status, syncState, durationView, roomTitle, roomTopic, pinnedView, shareView;
    private final Set<Integer> lockedSeats = new HashSet<>();

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (hostStarted || !host) {
                if (host) BackendClient.setLivePresence(token(), true, new Silent());
                else BackendClient.liveViewer(token(), hostId, true, new Silent());
                if (host || "SPEAKER".equals(myRole)) {
                    BackendClient.liveParticipantState(token(), hostId, localMicOn, false, networkQuality(), new Silent());
                }
                refresh();
            }
            handler.postDelayed(this, 5000);
        }
    };

    private final Runnable durationTick = new Runnable() {
        @Override public void run() {
            if (startedAtMs > 0 && durationView != null) {
                long sec = Math.max(0, (System.currentTimeMillis() - startedAtMs) / 1000L);
                durationView.setText(hhmm(sec));
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        host = getIntent().getBooleanExtra("hostMode", false);
        hostId = host ? SessionManager.getUserId(this) : getIntent().getStringExtra("hostId");
        if (hostId == null || hostId.trim().isEmpty()) hostId = SessionManager.getUserId(this);
        build();
        renderLocalSkeleton();
        handler.post(durationTick);
        if (host) showHostSetup();
        else {
            BackendClient.liveViewer(token(), hostId, true, new Silent());
            handler.post(tick);
        }
    }

    private void showHostSetup() {
        final android.app.Dialog d=new android.app.Dialog(this);
        LinearLayout box=col();box.setPadding(dp(20),dp(18),dp(20),dp(18));box.setBackground(bg(Color.rgb(10,18,58),Color.rgb(170,69,255),24));
        TextView hd=t("🎙  START AUDIO LIVE",18,Color.WHITE,true);hd.setGravity(Gravity.CENTER);box.addView(hd,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView sub=t("Create your MY SHOP audio room",10.5f,Color.rgb(188,202,244),false);sub.setGravity(Gravity.CENTER);box.addView(sub,new LinearLayout.LayoutParams(-1,dp(30)));
        EditText title=new EditText(this);title.setHint("Room title");title.setText("Let's Talk Together");title.setTextColor(Color.WHITE);title.setHintTextColor(Color.rgb(155,166,205));title.setSingleLine(true);title.setPadding(dp(14),0,dp(14),0);title.setBackground(bg(Color.rgb(17,31,79),Color.rgb(94,110,225),16));LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(50));tp.topMargin=dp(10);box.addView(title,tp);
        EditText topic=new EditText(this);topic.setHint("Topic");topic.setText("Audio Live");topic.setTextColor(Color.WHITE);topic.setHintTextColor(Color.rgb(155,166,205));topic.setSingleLine(true);topic.setPadding(dp(14),0,dp(14),0);topic.setBackground(bg(Color.rgb(17,31,79),Color.rgb(94,110,225),16));LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,dp(50));op.topMargin=dp(10);box.addView(topic,op);
        LinearLayout actions=row();Button cancel=small("Cancel");cancel.setBackground(bg(Color.rgb(27,38,83),Color.rgb(96,111,185),18));Button go=btn("GO LIVE");go.setBackground(bg(Color.rgb(126,43,218),Color.rgb(255,71,192),18));cancel.setOnClickListener(v->{d.dismiss();finish();});go.setOnClickListener(v->{String t=title.getText().toString().trim(),p=topic.getText().toString().trim();if(t.isEmpty())t="Let's Talk Together";if(p.isEmpty())p="Audio Live";d.dismiss();startHostLive(t,p);});LinearLayout.LayoutParams c=new LinearLayout.LayoutParams(0,dp(46),.38f);c.rightMargin=dp(8);actions.addView(cancel,c);actions.addView(go,new LinearLayout.LayoutParams(0,dp(46),.62f));LinearLayout.LayoutParams ax=new LinearLayout.LayoutParams(-1,dp(46));ax.topMargin=dp(16);box.addView(actions,ax);
        d.setContentView(box);d.setCancelable(false);d.setOnShowListener(x->{android.view.Window w=d.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.72f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.88f),-2);}});d.show();
    }

    private void startHostLive(String title, String topic) {
        BackendClient.setLivePresence(token(), true, new BackendClient.Callback() {
            @Override public void onSuccess(JSONObject data) {
                hostStarted = true;
                BackendClient.liveRoomConfig(token(), title, topic, null, null, new Silent());
                runOnUiThread(() -> { syncState.setText("● LIVE • Room connected"); refresh(); handler.post(tick); });
            }
            @Override public void onError(String m) { runOnUiThread(() -> { syncState.setText("Could not start live"); Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show(); }); }
        });
    }

    private void build() {
        FrameLayout page = new FrameLayout(this);
        wallpaper = new ImageView(this);
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        wallpaper.setImageResource(R.drawable.live_guitar_wallpaper);
        page.addView(wallpaper, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout root = col(); root.setPadding(dp(10), dp(4), dp(10), dp(6));
        root.setBackgroundColor(Color.argb(170, 3, 8, 34));
        page.addView(root, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout top = row(); top.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        TextView power = t("⏻", 21, Color.WHITE, true); power.setGravity(Gravity.CENTER);
        power.setBackground(bg(Color.rgb(190,25,45),Color.rgb(255,92,108),20));
        power.setOnClickListener(v -> { if(host) confirmEndLive(); else confirmLeaveLive(); });
        top.addView(power,new LinearLayout.LayoutParams(dp(38),dp(38)));
        root.addView(top,new LinearLayout.LayoutParams(-1,dp(40)));

        roomTitle = t("", 1, Color.TRANSPARENT, false); roomTopic = t("", 1, Color.TRANSPARENT, false);
        viewers = t("👁 0", 10, Color.rgb(210,225,255), true); viewers.setGravity(Gravity.RIGHT); root.addView(viewers,new LinearLayout.LayoutParams(-1,dp(18)));
        LinearLayout meta = row();
        status = t((host?"👑 Host":"🎧 Audience")+" • ID "+SessionManager.getUserId(this),11,Color.rgb(226,199,255),true);
        meta.addView(status,new LinearLayout.LayoutParams(0,dp(28),1));
        shareView=t("↗ 0",11,Color.rgb(226,199,255),true); shareView.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); meta.addView(shareView,new LinearLayout.LayoutParams(dp(70),dp(28)));
        meta.setVisibility(View.GONE); root.addView(meta,new LinearLayout.LayoutParams(1,1));
        syncState=t("",1,Color.TRANSPARENT,false); syncState.setVisibility(View.GONE); root.addView(syncState,new LinearLayout.LayoutParams(1,1));

        hostArea=col(); root.addView(hostArea,new LinearLayout.LayoutParams(-1,-2));
        audienceRow=row(); audienceRow.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); root.addView(audienceRow,new LinearLayout.LayoutParams(-1,dp(34)));
        specialArea=col(); specialArea.setGravity(Gravity.CENTER_HORIZONTAL); LinearLayout.LayoutParams sgp=new LinearLayout.LayoutParams(-1,-2); sgp.topMargin=dp(5); root.addView(specialArea,sgp);

        
        seats=col(); seats.setPadding(dp(4),dp(4),dp(4),dp(4)); seats.setBackground(bg(Color.argb(135,8,20,66),Color.rgb(88,71,218),18)); root.addView(seats,new LinearLayout.LayoutParams(-1,-2));

        if(host){
            requests=col(); requests.setVisibility(View.GONE); root.addView(requests,new LinearLayout.LayoutParams(1,1)); requests.addView(t("No pending requests",11,Color.LTGRAY,false));
        } else {
            Button req=btn("🎤 Request to Speak"); req.setOnClickListener(v->BackendClient.liveSpeakRequest(token(),hostId,new ToastCb("Request sent")));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(34)); rp.topMargin=dp(3); root.addView(req,rp);
        }

        pinnedView=t("📌 No pinned announcement",11,Color.rgb(255,224,138),true); pinnedView.setPadding(dp(8),dp(7),dp(8),dp(6)); pinnedView.setBackground(bg(Color.argb(125,25,26,66),Color.rgb(131,96,235),12));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(28)); pp.topMargin=dp(3); root.addView(pinnedView,pp);

        TextView chatTitle=t("💬 LIVE COMMENTS",11,Color.WHITE,true); chatTitle.setPadding(0,dp(3),0,dp(2)); root.addView(chatTitle,new LinearLayout.LayoutParams(-1,dp(22)));
        ScrollView commentScroll=new ScrollView(this); commentsList=col(); commentsList.setPadding(dp(8),dp(6),dp(8),dp(6)); commentsList.setBackground(bg(Color.argb(150,7,16,52),Color.rgb(65,82,157),14)); commentScroll.addView(commentsList);
        root.addView(commentScroll,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout sendRow=row(); EditText commentInput=new EditText(this); commentInput.setHint("Write a comment…"); commentInput.setTextColor(Color.WHITE); commentInput.setHintTextColor(Color.rgb(155,165,195)); commentInput.setSingleLine(true); commentInput.setBackground(bg(Color.argb(170,10,24,61),Color.rgb(67,91,171),16)); commentInput.setPadding(dp(12),0,dp(8),0);
        Button send=small("Send"); send.setOnClickListener(v->{String m=commentInput.getText().toString().trim(); if(m.isEmpty())return; BackendClient.liveComment(token(),hostId,m,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{commentInput.setText("");refresh();});}public void onError(String e){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_SHORT).show());}});});
        LinearLayout.LayoutParams cip=new LinearLayout.LayoutParams(0,dp(36),1); cip.rightMargin=dp(5); sendRow.addView(commentInput,cip); sendRow.addView(send,new LinearLayout.LayoutParams(dp(64),dp(36))); root.addView(sendRow);

        addControls(root);
        
        setContentView(page);
    }

    private void addControls(LinearLayout root){
        FrameLayout actions=new FrameLayout(this);
        LinearLayout bottom=row();
        String[] labels=host?new String[]{"🎙","➕","🪑","📌","↗","⚙"}:new String[]{"🎤","➕","💬","📩","↗","⚙"};
        for(int i=0;i<labels.length;i++){final int idx=i;TextView v=t(labels[i],17,Color.WHITE,true);v.setGravity(Gravity.CENTER);v.setBackground(bg(Color.argb(185,12,27,72),Color.rgb(80,92,190),18));v.setOnClickListener(x->handleCompactControl(idx));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(42),1);lp.setMargins(dp(2),0,dp(2),0);bottom.addView(v,lp);}
        actions.addView(bottom,new FrameLayout.LayoutParams(-1,dp(42),Gravity.BOTTOM));
        LinearLayout floating=col();
        TextView gift=t("🎁",20,Color.WHITE,true);gift.setGravity(Gravity.CENTER);gift.setBackground(bg(Color.argb(215,40,64,160),Color.rgb(94,210,255),22));gift.setOnClickListener(v->Toast.makeText(this,"Gift panel • next monetization phase",Toast.LENGTH_SHORT).show());floating.addView(gift,new LinearLayout.LayoutParams(dp(42),dp(42)));
        TextView react=t("❤️",20,Color.WHITE,true);react.setGravity(Gravity.CENTER);react.setBackground(bg(Color.argb(215,102,28,135),Color.rgb(255,88,196),22));react.setOnClickListener(v->showReaction());LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(dp(42),dp(42));rp.topMargin=dp(4);floating.addView(react,rp);
        FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(dp(42),dp(88),Gravity.RIGHT|Gravity.TOP);fp.rightMargin=dp(2);actions.addView(floating,fp);
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(88));ap.topMargin=dp(3);root.addView(actions,ap);
    }

    private void handleCompactControl(int i){
        if(host){if(i==0)toggleMic();else if(i==1)Toast.makeText(this,"Invite speaker",Toast.LENGTH_SHORT).show();else if(i==2)Toast.makeText(this,"Tap a sofa to lock/unlock or manage speaker",Toast.LENGTH_SHORT).show();else if(i==3)editPinned();else if(i==4)shareRoom();else if(i==5)showHostRoomMenu();}
        else{if(i==0)toggleMic();else if(i==1)BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));else if(i==2)Toast.makeText(this,"Live chat is above",Toast.LENGTH_SHORT).show();else if(i==3)Toast.makeText(this,"Open Inbox",Toast.LENGTH_SHORT).show();else if(i==4)shareRoom();else Toast.makeText(this,"More",Toast.LENGTH_SHORT).show();}
    }

    private void showHostRoomMenu(){new AlertDialog.Builder(this).setTitle("Host Room Controls").setItems(new String[]{"Theme","Room title / topic","Pinned announcement","End Live"},(d,w)->{if(w==0)chooseTheme();else if(w==1)editRoomInfo();else if(w==2)editPinned();else confirmEndLive();}).show();}

    private void handleControl(int i){
        if(host){
            if(i==0) toggleMic(); else if(i==2) Toast.makeText(this,"Tap any sofa to lock/unlock or manage speaker",Toast.LENGTH_SHORT).show();
            else if(i==3) editPinned(); else if(i==4) chooseTheme(); else if(i==5) shareRoom(); else if(i==6) showReaction(); else if(i==7) editRoomInfo();
            else Toast.makeText(this,"Host control ready",Toast.LENGTH_SHORT).show();
        } else {
            if(i==0) toggleMic(); else if(i==1) BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));
            else if(i==3) showReaction(); else if(i==5) shareRoom(); else Toast.makeText(this,"Live control",Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleMic(){localMicOn=!localMicOn;BackendClient.liveParticipantState(token(),hostId,localMicOn,false,networkQuality(),new ToastCb(localMicOn?"Mic on":"Mic muted"));}

    private void editPinned(){EditText e=new EditText(this);e.setHint("Pinned announcement");new AlertDialog.Builder(this).setTitle("Pinned message").setView(e).setPositiveButton("Save",(d,w)->BackendClient.liveRoomConfig(token(),null,null,e.getText().toString().trim(),null,new ToastCb("Pinned message updated"))).setNegativeButton("Cancel",null).show();}
    private void editRoomInfo(){LinearLayout b=col();EditText t1=new EditText(this);t1.setHint("Room title");EditText t2=new EditText(this);t2.setHint("Topic");b.addView(t1);b.addView(t2);new AlertDialog.Builder(this).setTitle("Room info").setView(b).setPositiveButton("Save",(d,w)->BackendClient.liveRoomConfig(token(),t1.getText().toString(),t2.getText().toString(),null,null,new ToastCb("Room info updated"))).setNegativeButton("Cancel",null).show();}

    private void chooseTheme(){BackendClient.liveThemes(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("themes");if(a==null||a.length()==0){Toast.makeText(AudioLiveRoomActivity.this,"No enabled themes",Toast.LENGTH_SHORT).show();return;}String[] names=new String[a.length()];String[] keys=new String[a.length()];for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);names[i]=x==null?"Theme":x.optString("name","Theme");keys[i]=x==null?"GUITAR_BLUE":x.optString("theme_key","GUITAR_BLUE");}new AlertDialog.Builder(AudioLiveRoomActivity.this).setTitle("Live Theme").setItems(names,(q,which)->BackendClient.liveRoomConfig(token(),null,null,null,keys[which],new ToastCb("Theme changed"))).show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}

    private void shareRoom(){BackendClient.liveShare(token(),hostId,new Silent()); Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,"Join my MY SHOP Audio Live • Host ID "+hostId);startActivity(Intent.createChooser(send,"Share Live"));}

    private void showReaction(){
        if(commentsList==null)return;
        TextView r=t("❤️",28,Color.WHITE,true);
        r.setGravity(Gravity.CENTER);
        commentsList.addView(r,0,new LinearLayout.LayoutParams(-1,dp(42)));
        r.setAlpha(.2f);
        r.setTranslationY(dp(20));
        r.animate().alpha(1f).translationY(0).setDuration(220).withEndAction(() -> {
            r.animate().alpha(0f).translationY(-dp(20)).setDuration(650).withEndAction(() -> commentsList.removeView(r)).start();
        }).start();
    }

    private void renderLocalSkeleton(){renderHost(null);renderSpecialGuest(null);renderSeats(null);}

    private void refresh(){BackendClient.liveRoomState(token(),hostId,new BackendClient.Callback(){@Override public void onSuccess(JSONObject d){runOnUiThread(()->{syncState.setText("● LIVE • Synced • "+networkQuality());render(d);});}@Override public void onError(String m){runOnUiThread(()->{syncState.setText("● LIVE • Weak network • Reconnecting…");if(seats.getChildCount()==0)renderLocalSkeleton();});}});}

    private void render(JSONObject d){
        int vc=d.optInt("viewerCount",0),peak=d.optInt("peakViewers",0); viewers.setText("👁 "+vc+" Listeners  •  Peak "+peak+"  •  Total "+d.optInt("totalListeners",0));
        myRole=d.optString("myRole",host?"HOST":"AUDIENCE"); status.setText((host?"👑 Host":"🎧 "+myRole)+" • ID "+SessionManager.getUserId(this));
        specialGuestId=d.optString("specialGuestId",""); shareCount=d.optInt("shareCount",0); shareView.setText("↗ "+shareCount);
        roomTitle.setText("🎙 "+d.optString("title","Let's Talk Together")); roomTopic.setText(d.optString("topic","Audio Live"));
        String pin=d.optString("pinnedMessage",""); pinnedView.setText(pin.isEmpty()?"📌 No pinned announcement":"📌 "+pin);
        long parsed=parseServerTime(d.optString("startedAt","")); if(parsed>0)startedAtMs=parsed;
        lockedSeats.clear();JSONArray locks=d.optJSONArray("lockedSeats");if(locks!=null)for(int i=0;i<locks.length();i++)lockedSeats.add(locks.optInt(i));
        JSONArray a=d.optJSONArray("seats"); renderHost(findSeat(a,1));renderAudience(d.optJSONArray("viewerProfiles"),vc);renderSpecialGuest(findUser(a,specialGuestId));renderSeats(a);
        if(host&&requests!=null)renderRequests(d.optJSONArray("requests"));renderComments(d.optJSONArray("comments"),d.optJSONArray("events"));
        JSONObject theme=d.optJSONObject("theme"); if(theme!=null){String bg=theme.optString("background_url","");if(!bg.trim().isEmpty())loadImage(wallpaper,bg);}
    }

    private void renderHost(JSONObject x){hostArea.removeAllViews();LinearLayout card=row();card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(5),dp(5),dp(7),dp(5));boolean speaking=x!=null&&x.optInt("speaking",0)==1;card.setBackground(bg(Color.argb(160,15,24,69),speaking?Color.rgb(45,226,255):Color.rgb(118,76,225),18));FrameLayout av=circleAvatar(x==null?"":x.optString("avatar_url",""),dp(52),speaking);card.addView(av,new LinearLayout.LayoutParams(dp(52),dp(52)));String name=x==null?"Host":x.optString("full_name","Host");String id=x==null?hostId:x.optString("user_id",hostId);int lv=x==null?0:x.optInt("level",0);long coin=x==null?0:x.optLong("coin_balance",0),gold=x==null?0:x.optLong("gold_balance",0);String nq=x==null?"GOOD":x.optString("network_quality","GOOD");TextView info=t("👑 "+name+"\nID "+id+" • LV."+lv+"   "+signal(nq)+"\n🪙 "+coin+"   🟡 "+gold+(speaking?"   ≋ Speaking":""),11,Color.WHITE,true);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,-2,1);ip.leftMargin=dp(9);card.addView(info,ip);hostArea.addView(card,new LinearLayout.LayoutParams(-1,-2));}

    private void renderAudience(JSONArray a,int total){audienceRow.removeAllViews();TextView eye=t("👁 "+total,9.5f,Color.rgb(220,228,255),true);audienceRow.addView(eye,new LinearLayout.LayoutParams(dp(46),dp(30)));int shown=0;if(a!=null){for(int i=0;i<a.length()&&shown<7;i++,shown++){JSONObject u=a.optJSONObject(i);if(u==null)continue;FrameLayout av=circleAvatar(u.optString("avatar_url",""),dp(28),false);String uid=u.optString("user_id","");av.setOnClickListener(v->Toast.makeText(this,u.optString("full_name","User")+" • ID "+uid+" • LV."+u.optInt("level",0),Toast.LENGTH_SHORT).show());LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(28),dp(28));ap.leftMargin=dp(3);audienceRow.addView(av,ap);}}if(total>shown){TextView more=t("+"+(total-shown),9,Color.WHITE,true);more.setGravity(Gravity.CENTER);more.setBackground(bg(Color.argb(170,39,46,100),Color.rgb(118,91,230),14));LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(dp(32),dp(28));mp.leftMargin=dp(3);audienceRow.addView(more,mp);}}

    private void renderSpecialGuest(JSONObject x){specialArea.removeAllViews();LinearLayout hdr=row();hdr.setGravity(Gravity.CENTER);durationView=t("00:00",9.5f,Color.rgb(255,210,235),true);durationView.setGravity(Gravity.CENTER);durationView.setBackground(bg(Color.argb(150,55,18,75),Color.rgb(236,73,179),12));hdr.addView(durationView,new LinearLayout.LayoutParams(dp(48),dp(24)));TextView label=t("  ✨ SPECIAL GUEST",10.5f,Color.rgb(255,188,244),true);hdr.addView(label,new LinearLayout.LayoutParams(-2,dp(24)));specialArea.addView(hdr);if(x==null){FrameLayout av=circleAvatar("",dp(62),false);specialArea.addView(av,new LinearLayout.LayoutParams(dp(62),dp(62)));TextView e=t("Host can spotlight a speaker here",10,Color.rgb(195,205,245),true);e.setGravity(Gravity.CENTER);specialArea.addView(e);return;}boolean speaking=x.optInt("speaking",0)==1;FrameLayout av=circleAvatar(x.optString("avatar_url",""),dp(86),speaking);specialArea.addView(av,new LinearLayout.LayoutParams(dp(86),dp(86)));TextView info=t(x.optString("full_name","Special Guest")+"  •  ID "+x.optString("user_id")+" • LV."+x.optInt("level",0)+(speaking?"  ≋ Speaking":""),10.5f,Color.WHITE,true);info.setGravity(Gravity.CENTER);specialArea.addView(info);if(host)specialArea.setOnClickListener(v->clearSpecialGuest());}

    private void renderSeats(JSONArray a){seats.removeAllViews();int n=2;for(int rr=0;rr<2;rr++){LinearLayout r=row();for(int c=0;c<5;c++,n++){JSONObject found=findSeat(a,n);boolean locked=lockedSeats.contains(n);LinearLayout tile=seatTile(n,found,locked);final int seatNo=n;final JSONObject clicked=found;tile.setOnClickListener(v->{if(host){if(clicked!=null)showSpeakerActions(clicked);else toggleSeatLock(seatNo,locked);}});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(62),1);lp.setMargins(dp(2),dp(1),dp(2),dp(1));r.addView(tile,lp);}seats.addView(r,new LinearLayout.LayoutParams(-1,dp(64)));}}

    private LinearLayout seatTile(int seatNo,JSONObject x,boolean locked){LinearLayout v=col();v.setGravity(Gravity.CENTER);v.setPadding(dp(1),dp(2),dp(1),dp(2));boolean occupied=x!=null,speaking=occupied&&x.optInt("speaking",0)==1;v.setBackgroundColor(Color.TRANSPARENT);FrameLayout stage=new FrameLayout(this);stage.addView(sofaIcon(locked),new FrameLayout.LayoutParams(dp(54),dp(45),Gravity.CENTER));if(occupied){FrameLayout av=circleAvatar(x.optString("avatar_url",""),dp(32),speaking);FrameLayout.LayoutParams avp=new FrameLayout.LayoutParams(dp(32),dp(32),Gravity.CENTER);avp.topMargin=-dp(5);stage.addView(av,avp);}v.addView(stage,new LinearLayout.LayoutParams(dp(58),dp(48)));return v;}

    private View sofaIcon(boolean locked){FrameLayout f=new FrameLayout(this);int gold=locked?Color.rgb(105,88,55):Color.rgb(235,166,32);int light=locked?Color.rgb(135,118,78):Color.rgb(255,221,91);View back=new View(this);back.setBackground(bg(gold,light,10));FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(44),dp(28),Gravity.TOP|Gravity.CENTER_HORIZONTAL);f.addView(back,bp);View left=new View(this);left.setBackground(bg(gold,light,8));FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(12),dp(28),Gravity.LEFT|Gravity.BOTTOM);f.addView(left,lp);View right=new View(this);right.setBackground(bg(gold,light,8));FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(dp(12),dp(28),Gravity.RIGHT|Gravity.BOTTOM);f.addView(right,rp);View base=new View(this);base.setBackground(bg(light,Color.rgb(255,235,130),8));FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(44),dp(15),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);f.addView(base,sp);return f;}

    private void toggleSeatLock(int seatNo,boolean locked){BackendClient.liveSeatLock(token(),seatNo,!locked,new ToastCb(!locked?"Seat locked":"Seat unlocked"));}

    private void renderRequests(JSONArray q){requests.removeAllViews();if(q==null||q.length()==0){requests.addView(t("No pending requests",11,Color.LTGRAY,false));return;}for(int i=0;i<q.length();i++){JSONObject x=q.optJSONObject(i);if(x==null)continue;LinearLayout rr=row();rr.setGravity(Gravity.CENTER_VERTICAL);TextView nm=t(x.optString("full_name","User")+" • ID "+x.optString("user_id"),10.5f,Color.WHITE,true);rr.addView(nm,new LinearLayout.LayoutParams(0,dp(36),1));Button ok=small("Accept"),no=small("Decline");String id=x.optString("user_id");ok.setOnClickListener(v->BackendClient.liveRequestAction(token(),id,true,new ToastCb("Speaker accepted")));no.setOnClickListener(v->BackendClient.liveRequestAction(token(),id,false,new ToastCb("Request declined")));rr.addView(ok,new LinearLayout.LayoutParams(dp(72),dp(38)));rr.addView(no,new LinearLayout.LayoutParams(dp(74),dp(38)));requests.addView(rr);}}

    private void renderComments(JSONArray comments,JSONArray events){commentsList.removeAllViews();if(events!=null){int start=Math.max(0,events.length()-4);for(int i=start;i<events.length();i++){JSONObject e=events.optJSONObject(i);if(e==null)continue;String who=e.optString("full_name","Someone");TextView n=t("• "+who+" "+e.optString("message",""),9.5f,Color.rgb(167,190,244),false);commentsList.addView(n);}}if(comments==null||comments.length()==0){commentsList.addView(t("Comments will appear here",10.5f,Color.rgb(170,178,205),false));return;}for(int i=0;i<comments.length();i++){JSONObject c=comments.optJSONObject(i);if(c==null)continue;TextView msg=t(c.optString("full_name","User")+": "+c.optString("message",""),10.5f,Color.WHITE,false);msg.setPadding(0,dp(2),0,dp(2));commentsList.addView(msg);}}

    private void showSpeakerActions(JSONObject x){final String uid=x.optString("user_id","");final boolean special=uid.equals(specialGuestId);String[] actions=special?new String[]{"Remove from Special Guest","Remove Speaker from Seat"}:new String[]{"Make Special Guest","Remove Speaker from Seat"};new AlertDialog.Builder(this).setTitle(x.optString("full_name","Speaker")).setItems(actions,(d,which)->{if(which==0)BackendClient.liveSpecialGuest(token(),uid,special,new ToastCb(special?"Special Guest removed":"Special Guest selected"));else BackendClient.liveSpeakerRemove(token(),uid,new ToastCb("Speaker removed"));}).show();}
    private void clearSpecialGuest(){if(!host||specialGuestId.isEmpty())return;new AlertDialog.Builder(this).setTitle("Special Guest").setMessage("Return this guest to a normal speaker seat?").setPositiveButton("Remove Spotlight",(d,w)->BackendClient.liveSpecialGuest(token(),specialGuestId,true,new ToastCb("Spotlight cleared"))).setNegativeButton("Cancel",null).show();}

    private void confirmLeaveLive(){new AlertDialog.Builder(this).setTitle("Leave Live?").setMessage("Leave this live room?").setPositiveButton("Leave",(d,w)->finish()).setNegativeButton("Stay",null).show();}
    private void confirmEndLive(){new AlertDialog.Builder(this).setTitle("End Live?").setMessage("This will end the room for everyone.").setPositiveButton("End Live",(d,w)->endHostLive()).setNegativeButton("Cancel",null).show();}
    private void endHostLive(){BackendClient.setLivePresence(token(),false,new BackendClient.Callback(){public void onSuccess(JSONObject d){hostStarted=false;BackendClient.liveSummary(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject s){runOnUiThread(()->showSummary(s.optJSONObject("summary")));}public void onError(String m){runOnUiThread(()->finish());}});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}});}
    private void showSummary(JSONObject s){if(s==null){finish();return;}long dur=s.optLong("duration_seconds",0);new AlertDialog.Builder(this).setTitle("Live Summary").setMessage("Duration  "+hhmmss(dur)+"\nPeak viewers  "+s.optInt("peak_viewers",0)+"\nTotal listeners  "+s.optInt("total_listeners",0)+"\nShares  "+s.optInt("share_count",0)).setPositiveButton("Done",(d,w)->finish()).setCancelable(false).show();}

    private JSONObject findSeat(JSONArray a,int seatNo){if(a==null)return null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&x.optInt("seat_no")==seatNo)return x;}return null;}
    private JSONObject findUser(JSONArray a,String userId){if(a==null||userId==null||userId.isEmpty())return null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&userId.equals(x.optString("user_id")))return x;}return null;}

    private FrameLayout circleAvatar(String url,int size,boolean speaking){FrameLayout frame=new FrameLayout(this);int stroke=speaking?Color.rgb(42,235,255):Color.rgb(163,93,255);frame.setBackground(bg(Color.argb(190,25,33,82),stroke,size/2));ImageView v=new ImageView(this);v.setImageResource(android.R.drawable.sym_def_app_icon);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(bg(Color.rgb(34,45,105),stroke,size/2));v.setClipToOutline(true);int pad=dp(3);FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,-1);ip.setMargins(pad,pad,pad,pad);frame.addView(v,ip);if(url!=null&&!url.trim().isEmpty())loadImage(v,url);if(speaking){ObjectAnimator a=ObjectAnimator.ofFloat(frame,"alpha",1f,.72f,1f);a.setDuration(850);a.setRepeatCount(ValueAnimator.INFINITE);a.start();}return frame;}
    private void loadImage(ImageView v,String u){new Thread(()->{try{Bitmap b=BitmapFactory.decodeStream(new URL(u).openStream());if(b!=null)runOnUiThread(()->v.setImageBitmap(b));}catch(Exception ignored){}}).start();}

    private String networkQuality(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);NetworkInfo n=cm==null?null:cm.getActiveNetworkInfo();if(n==null||!n.isConnected())return "OFFLINE";return n.getType()==ConnectivityManager.TYPE_WIFI?"GOOD":"FAIR";}catch(Exception e){return "GOOD";}}
    private String signal(String q){q=q==null?"GOOD":q.toUpperCase();if("WEAK".equals(q)||"OFFLINE".equals(q))return "▂";if("FAIR".equals(q))return "▂▄";return "▂▄▆";}
    private long parseServerTime(String s){if(s==null||s.trim().isEmpty())return 0;String[] patterns={"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd'T'HH:mm:ss.SSS'Z'","yyyy-MM-dd'T'HH:mm:ss'Z'"};for(String p:patterns){try{SimpleDateFormat f=new SimpleDateFormat(p,Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));Date d=f.parse(s);if(d!=null)return d.getTime();}catch(Exception ignored){}}return 0;}
    private String hhmm(long sec){long h=sec/3600,m=(sec%3600)/60;return String.format(Locale.US,"%02d:%02d",h,m);}
    private String hhmmss(long sec){long h=sec/3600,m=(sec%3600)/60,s=sec%60;return String.format(Locale.US,"%02d:%02d:%02d",h,m,s);}
    private String token(){return SessionManager.getToken(this);}

    @Override protected void onDestroy(){handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);if(host){if(hostStarted)BackendClient.setLivePresence(token(),false,new Silent());}else{BackendClient.liveLeaveSeat(token(),hostId,new Silent());BackendClient.liveViewer(token(),hostId,false,new Silent());}super.onDestroy();}

    class ToastCb implements BackendClient.Callback{String ok;ToastCb(String s){ok=s;}public void onSuccess(JSONObject d){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,ok,Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}}
    static class Silent implements BackendClient.Callback{public void onSuccess(JSONObject d){}public void onError(String m){}}

    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private Button btn(String s){Button b=new Button(this);b.setAllCaps(false);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setBackground(bg(Color.rgb(76,45,205),Color.rgb(217,46,255),18));return b;}
    private Button small(String s){Button b=btn(s);b.setTextSize(9.5f);b.setMinWidth(0);b.setMinimumWidth(0);return b;}
    private TextView t(String s,float z,int c,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private GradientDrawable bg(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private int dp(float x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
}
