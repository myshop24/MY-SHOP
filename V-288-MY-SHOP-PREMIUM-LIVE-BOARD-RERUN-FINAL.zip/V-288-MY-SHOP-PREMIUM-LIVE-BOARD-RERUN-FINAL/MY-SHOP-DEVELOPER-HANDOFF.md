# MY SHOP Developer Handoff — V-288

## NEXT START HERE
- Use V-288 as the current source. It preserves V-287 Live UI/features but has a fresh version identity for a clean GitHub Actions rerun.
- If the GitHub run still fails, inspect the failing Actions step/log rather than incrementing versions again.
V-288 is a clean identity-bumped re-release of the approved premium Audio Live visual correction checkpoint from V-287, created so GitHub Actions selects a fresh higher V-number source. Start the next phase from this source. Do not redesign the Dashboard or revert these Live Room rules. The next major technical phase remains real Agora Audio RTC integration after owner visual/behavior QA.

## Completed / preserved in V-288
- Live Room remains no-scroll / single-screen.
- Red power-style leave/end control at top-right; host and audience get confirmation.
- Large LIVE seconds timer removed. Small HH:MM timer is beside SPECIAL GUEST.
- Host card preserved.
- Added compact real-time audience profile row from active live-viewer heartbeat data, with +N overflow and mini user info on tap.
- Speaker capacity is now 10 golden sofa positions, arranged exactly 5 + 5. Host remains separate (seat 1); speaker seats are backend positions 2-11.
- Removed visible Seat N / seat-number labels. Empty seats are clearly golden sofa visuals. Occupied sofas overlay the speaker avatar.
- Gift is above React on the lower-right floating stack.
- Bottom controls remain one compact row. Theme remains host-only through Host Room Controls.
- Start Audio Live setup changed from default white Android AlertDialog to a MY SHOP dark navy/purple premium dialog with rounded fields and prominent GO LIVE.
- Premium Choose Live Type launcher from V-286 preserved; Video Live remains Coming Soon.
- Guitar Blue wallpaper preserved.

## Backend/API changes
- /v1/live/room now returns viewerProfiles from active myshop_live_viewers heartbeat rows.
- Live speaker seat range expanded to 2-11 for ten speaker sofas.
- Seat cleanup, locks and auto assignment updated through seat 11.

## Locked behavior/design rules
- No Live Room vertical scrolling.
- 10 golden speaker sofas = 5 top + 5 bottom, evenly aligned. No seat number/text.
- Audience avatars visible near the top and update from backend viewer heartbeat.
- Gift above React on right.
- Red power control top-right.
- Timer only HH:MM beside SPECIAL GUEST; no seconds.
- Theme is not an audience control.
- Host End Live and audience Leave semantics remain separate.
- Audio Live first; Video Live disabled/Coming Soon until explicitly approved.

## Known limitation / testing
- Real Agora RTC media transport is NOT integrated yet. Current mic/speaking/network fields are control/state hooks, not production RTC voice.
- This environment does not contain the Gradle wrapper/system Gradle, so do not claim APK compilation passed until GitHub/Android build actually compiles it.
- Deploy the V-288 Worker/schema-compatible backend before expecting viewerProfiles and seat 11 behavior from an installed app.

## References
- 122024.mp4: primary compact Live Room behavior/layout reference (ideas only, no proprietary copying).
- 122040.png: approved latest board direction.
- 122036.jpg: old default Start Audio Live dialog that V-287/V-288 replaces.
- Guitar Blue wallpaper remains the default theme.

## Version identity
- Build: MY SHOP V-288
- Android versionCode: 287
- Android versionName: 2.9.288
- Worker health: 2.9.288 / V-288
