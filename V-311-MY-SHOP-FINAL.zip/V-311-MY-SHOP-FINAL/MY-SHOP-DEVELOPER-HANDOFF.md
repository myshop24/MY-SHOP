# MY SHOP DEVELOPER HANDOFF — V-311

Current version: V-311
Phase: Final integration / CI build

Completed:
- V-310 Play-safe Coin/Gold Coin + Creator Earnings system preserved.
- End Live: one confirmed tap initiates teardown, disables heartbeat/reconnect, and auto-retries server close without a second tap.
- Live comments: immediate optimistic render.
- Live comments: new comment text is ephemeral only; no new D1/R2 storage.
- Startup Ad: Full Image default, optional Fill Screen, 1080x2400 recommendation, soft background fill.
- SOURCE_BUILD_ID exact value: MY SHOP V-311.

QA required before Play release:
- CI/GitHub Android compile and signed APK/AAB build.
- Real-device host End Live test under normal/weak network.
- Two-device Live comment propagation test.
- Verify D1/R2 receive no new Live comment text.
- Startup ad Full Image and Fill Screen on multiple aspect ratios.
- Google Play compliance gate #1 remains mandatory.
