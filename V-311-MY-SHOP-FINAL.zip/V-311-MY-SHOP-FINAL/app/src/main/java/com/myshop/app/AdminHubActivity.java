package com.myshop.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;

/** V-129 admin-only folder menu. Each folder opens its own focused detail board. */
public class AdminHubActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(246,248,252), DARK=Color.rgb(22,28,55), MUTED=Color.rgb(100,106,122);
    private final int[] COLORS={Color.rgb(83,32,180),Color.rgb(31,73,210),Color.rgb(17,139,88),Color.rgb(220,92,38),Color.rgb(180,35,105),Color.rgb(32,125,145),Color.rgb(110,73,185),Color.rgb(210,45,55),Color.rgb(55,95,170),Color.rgb(25,130,95)};

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        String uid=SessionManager.getUserId(this);
        if(AdminIdentifiers.isAdminIdentifier(uid)) SessionManager.setRemoteSession(this,SessionManager.getToken(this),Role.ADMIN,AdminIdentifiers.adminIdFor(uid));
        if(!SessionManager.isAdmin(this)){finish();return;}
        if(!getIntent().getBooleanExtra("gate_passed",false) && !SessionManager.isAdminGateUnlocked()){startActivity(new android.content.Intent(this,AdminGateActivity.class));finish();return;}
        build();
    }

    private void build(){
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true);
        LinearLayout root=col(); root.setBackgroundColor(BG); root.setPadding(dp(12),dp(10),dp(12),dp(20));

        LinearLayout head=row(); head.setPadding(dp(4),dp(4),dp(4),dp(6));
        Button back=button("‹",DARK,28); back.setOnClickListener(v->finish()); head.addView(back,lp(dp(42),dp(46)));
        LinearLayout hb=col(); hb.addView(txt("MY SHOP",20,DARK,true),lp(-1,dp(24))); hb.addView(txt("এডমিন কন্ট্রোল সেন্টার",9,MUTED,true),lp(-1,dp(18))); head.addView(hb,weight(1));
        TextView profile=txt("প্রোফাইল • এডমিন",8,Color.WHITE,true); profile.setGravity(Gravity.CENTER); profile.setSingleLine(true); profile.setBackground(round(DARK,Color.TRANSPARENT,12)); profile.setOnClickListener(v->startActivity(new android.content.Intent(this,AccountActivity.class))); head.addView(profile,lp(dp(104),dp(34)));
        TextView logout=txt("লগআউট",8,Color.WHITE,true); logout.setGravity(Gravity.CENTER); logout.setSingleLine(true); logout.setBackground(round(Color.rgb(210,45,55),Color.TRANSPARENT,12)); logout.setOnClickListener(v->logout()); head.addView(logout,lp(dp(68),dp(34))); root.addView(head,lp(-1,dp(54)));

        LinearLayout info=card(); info.addView(txt("🔐  শুধু এডমিন",11,Color.WHITE,true),lp(-1,dp(24))); info.addView(txt("এই তালিকার কোনো অ্যাডমিন অপশন সাধারণ ইউজারের মেনুতে দেখানো হয় না। একটি ফোল্ডারে চাপলে শুধু সেই কাজের বিস্তারিত বোর্ড খুলবে।",11,Color.WHITE,false),lp(-1,-2)); info.setBackground(round(DARK,DARK,12)); root.addView(info,lp(-1,-2));
        LinearLayout strip=row(); strip.setPadding(dp(8),dp(6),dp(8),dp(6));
        strip.addView(statusChip("নিরাপদ এডমিন",COLORS[0]),weight(1));
        strip.addView(statusChip("৬টি হিরো",COLORS[1]),weight(1));
        strip.addView(statusChip("প্রতি ফোল্ডারে ৬ বিজ্ঞাপন",COLORS[3]),weight(1));
        root.addView(strip,lp(-1,dp(48)));
        LinearLayout guide=card();guide.addView(txt("কাজ করার সহজ নিয়ম",12,DARK,true),lp(-1,dp(24)));guide.addView(txt("➕ নতুন যোগ   →   ✏ সম্পাদনা   →   👁 প্রিভিউ   →   💾 সংরক্ষণ/প্রকাশ   →   🗑 মুছুন",10,MUTED,true),lp(-1,dp(28)));guide.addView(txt("প্রতিটি ফোল্ডারে শুধু সেই ফিচারের দরকারি নিয়ন্ত্রণ থাকবে—অপ্রয়োজনীয় টেকনিক্যাল ঘর থাকবে না।",9,MUTED,false),lp(-1,dp(28)));root.addView(guide,lp(-1,-2));
        addFolder(root,"00","লেনদেন • আয়/ব্যয় • ইউজার তদন্ত","আজকের হিসাব • সর্বমোট • খাতভিত্তিক • ইউজার আইডি খোঁজ • মেসেজ আর্কাইভ",0,"finance_center");
        TextView label=txt("প্রধান বিভাগসমূহ",15,DARK,true); label.setPadding(dp(4),dp(16),dp(4),dp(8)); root.addView(label,lp(-1,dp(40)));

        addFolder(root,"01","ব্যানার ম্যানেজমেন্ট","হিরো ৬টি • প্রতিটি ফোল্ডারে সর্বোচ্চ ৬টি বিজ্ঞাপন • আপলোড • সম্পাদনা • সংরক্ষণ • মুছুন",0,"banner");
        addFolder(root,"02","গ্যালারি ম্যানেজমেন্ট","ছবি • অডিও • ভিডিও • ফোনের গ্যালারি থেকে আপলোড • ক্যাপশন • সম্পাদনা • সংরক্ষণ • মুছুন",1,"gallery");
        addFolder(root,"03","ড্যাশবোর্ড বিজ্ঞাপন","প্রতিটি ফোল্ডারের ১–৬ বিজ্ঞাপন • ছবি/ভিডিও • লিংক • যোগ/সম্পাদনা/সংরক্ষণ/মুছুন",2,"ads");
        addFolder(root,"04","ড্যাশবোর্ড / ব্রেকিং নিউজ","শিরোনাম • ড্যাশবোর্ড URL • ব্রেকিং নিউজ • সংরক্ষণ / সম্পাদনা",2,"dashboard");
        addFolder(root,"05","ফিচার ম্যানেজমেন্ট","প্রতিটি ফিচারের নাম • আইকন • লিংক • দেখান / লুকান • সংরক্ষণ",3,"features");
        addFolder(root,"05A","ড্যাশবোর্ড ছোট ফিচার স্লট","বর্তমান গোল/লাইভ সারি • স্লট ১–৬ • নাম • ছবি • ক্যাপশন • লিংক • যোগ/সম্পাদনা/সংরক্ষণ/মুছুন",3,"dynamic_content");
        addFolder(root,"06","সোশ্যাল লিংক","Facebook • YouTube • TikTok • Instagram • WhatsApp ইত্যাদি",4,"social");
        addFolder(root,"07","লাইভ টিভি","চ্যানেলের নাম • লিংক • আইকন • দেখান / লুকান • সংরক্ষণ / মুছুন",5,"live_tv");
        addFolder(root,"08","এক্সটার্নাল মুভি","মুভির নাম • লিংক • আইকন • দেখান / লুকান • সংরক্ষণ / মুছুন",6,"external_movie");
        addFolder(root,"09","আরও অ্যাপ","অ্যাপের নাম • লিংক • আইকন • দেখান / লুকান • সংরক্ষণ / মুছুন",7,"more_apps");
        addFolder(root,"10","পেমেন্ট পদ্ধতি","পেমেন্টের নাম • লিংক / মান • দেখান / লুকান • সংরক্ষণ / মুছুন",8,"payment_methods");
        addFolder(root,"11","মডারেটর / এডমিন","মডারেটর আইডি • যোগ / সরান • অ্যাডমিন নিরাপত্তা",9,"moderators");
        addFolder(root,"12","মাই ফিড মডারেশন","কুরুচিপূর্ণ পোস্ট দেখা • মুছুন • মডারেশন রেকর্ড",1,"feed_moderation");
        addFolder(root,"13","কাস্টমার সাপোর্ট","WhatsApp • imo • Facebook • ওয়েবসাইট • ছবি/আইকন • যোগ/সম্পাদনা/সংরক্ষণ/মুছুন",5,"help_support");
        addFolder(root,"14","সিস্টেম স্বাস্থ্য / পরীক্ষা","সক্রিয় Worker • D1 স্কিমা/লেখা • R2 পড়া/লেখা • সঠিক ত্রুটি",0,"system_health");
        addFolder(root,"15","এনিমেটেড ব্যাজ • ইউজার আইডি গ্রান্ট","অ্যানিমেশন আপলোড • প্রিভিউ • মূল্য/মেয়াদ • প্রকাশ • ইউজার আইডিতে প্রদান • প্রোফাইলে স্বয়ংক্রিয় প্রদর্শন",6,"wallet_badge");
        addFolder(root,"16","ROYAL • VVIP • VIP মেম্বারশিপ","আলাদা প্রিমিয়াম পেজ • প্রতীক • মূল্য • মেয়াদ • সুবিধা • কিনুন/অনুরোধ",5,"wallet_badge");
        addFolder(root,"17","কয়েন • গোল্ড কয়েন ক্যাটালগ","অ্যাডমিন প্যাকেজ ইউনিট • টাকার মূল্য • কয়েনের মূল্য • চালু/বন্ধ নির্ধারণ করবেন",3,"wallet_badge");
        addFolder(root,"18","অ্যাপ ওপেন ছবি / ভিডিও বিজ্ঞাপন","যোগ/সম্পাদনা/মুছুন/সংরক্ষণ • চালু/বন্ধ • ছবি/ভিডিও • ১/২/৩/৪ সেকেন্ড • লিংক",2,"startup_ads");
        addFolder(root,"19","অডিও লাইভ থিম / ব্যাকগ্রাউন্ড","যোগ/সম্পাদনা/মুছুন/সংরক্ষণ • চালু/বন্ধ • থিম কী • ব্যাকগ্রাউন্ড • অ্যাকসেন্ট • APK আপডেট ছাড়াই প্রকাশ",6,"live_themes");
        addFolder(root,"20","লাইভ গিফট ম্যানেজার","৫০ কয়েন + ৫০ গোল্ড কয়েন • অ্যানিমেশন/সাউন্ড/ভলিউম/সাইজ • যোগ/সম্পাদনা/মুছুন/প্রকাশ",4,"live_gifts");
        addFolder(root,"21","Safety Reports • Account Deletion","User রিপোর্ট review • Resolve/Dismiss • Block/abuse audit • Web account deletion request verification",7,"safety_reports");

        TextView safe=txt("✓ ইউজার ডেটা, লগইন রেকর্ড এবং স্থায়ী ইউজার আইডি এই প্যানেল থেকে রিসেট/মুছা হয় না।",10,MUTED,false); safe.setPadding(dp(5),dp(14),dp(5),dp(4)); root.addView(safe,lp(-1,dp(48)));
        root.addView(actionBar("লগআউট • লগইনে ফিরে যান",Color.rgb(210,45,55),()->logout()),lp(-1,dp(44)));
        sv.addView(root); setContentView(sv);
    }

    private TextView actionBar(String text,int color,Runnable r){ TextView t=txt(text,10,Color.WHITE,true); t.setGravity(Gravity.CENTER); t.setBackground(round(color,color,10)); t.setOnClickListener(v->r.run()); return t; }

    private void logout(){ String token=SessionManager.getToken(this); SessionManager.clear(this); android.content.Intent i=new android.content.Intent(this,LoginActivity.class); i.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP|android.content.Intent.FLAG_ACTIVITY_NEW_TASK|android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK); startActivity(i); if(token!=null&&!token.isEmpty()) BackendClient.logout(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){} public void onError(String m){}}); }

    private TextView statusChip(String text,int color){ TextView t=txt(text,9,Color.WHITE,true); t.setGravity(Gravity.CENTER); t.setBackground(round(color,color,12)); return t; }

    private void addFolder(LinearLayout root,String no,String title,String desc,int ci,String mode){
        LinearLayout c=card();
        LinearLayout r=row(); TextView num=txt(no,12,Color.WHITE,true); num.setGravity(Gravity.CENTER); num.setBackground(round(COLORS[ci],COLORS[ci],14)); r.addView(num,lp(dp(42),dp(42)));
        LinearLayout b=col(); b.setPadding(dp(10),dp(2),dp(5),dp(2)); b.addView(txt(title,13.5f,DARK,true),lp(-1,dp(27))); TextView d=txt(desc,9.5f,MUTED,false); d.setMaxLines(3); d.setLineSpacing(dp(2),1.05f); b.addView(d,lp(-1,dp(43))); r.addView(b,weight(1));
        TextView go=txt("খুলুন  ›",10.5f,COLORS[ci],true); go.setGravity(Gravity.CENTER); r.addView(go,lp(dp(68),dp(46))); c.addView(r,lp(-1,dp(72)));
        c.setOnClickListener(v->open(mode)); c.setOnTouchListener((v,e)->{if(e.getAction()==android.view.MotionEvent.ACTION_DOWN)v.animate().scaleX(.985f).scaleY(.985f).alpha(.92f).setDuration(60).start();else if(e.getAction()==android.view.MotionEvent.ACTION_UP||e.getAction()==android.view.MotionEvent.ACTION_CANCEL)v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(100).start();return false;}); root.addView(c,lp(-1,-2));
    }

    private void open(String mode){
        if("finance_center".equals(mode)){startActivity(new android.content.Intent(this,AdminFinanceActivity.class));return;}
        if("banner".equals(mode)){startActivity(new android.content.Intent(this,BannerAdminActivity.class));return;}
        if("gallery".equals(mode)){startActivity(new android.content.Intent(this,GalleryAdminActivity.class));return;}
        if("ads".equals(mode)){startActivity(new android.content.Intent(this,DashboardAdsAdminActivity.class));return;}
        if("startup_ads".equals(mode)){android.content.Intent i=new android.content.Intent(this,DashboardAdsAdminActivity.class);i.putExtra("box_key","startup_ad");i.putExtra("box_title","অ্যাপ ওপেন ছবি / ভিডিও বিজ্ঞাপন");startActivity(i);return;}
        if("feed_moderation".equals(mode)){startActivity(new android.content.Intent(this,FeedModerationActivity.class));return;}
        if("system_health".equals(mode)){startActivity(new android.content.Intent(this,AdminSystemHealthActivity.class));return;}
        if("wallet_badge".equals(mode)){startActivity(new android.content.Intent(this,AdminStoreActivity.class));return;}
        if("live_themes".equals(mode)){startActivity(new android.content.Intent(this,LiveThemeAdminActivity.class));return;}
        if("live_gifts".equals(mode)){startActivity(new android.content.Intent(this,LiveGiftAdminActivity.class));return;}
        if("safety_reports".equals(mode)){startActivity(new android.content.Intent(this,AdminSafetyActivity.class));return;}
        android.content.Intent i=new android.content.Intent(this,AdminSectionActivity.class); i.putExtra("section",mode); i.putExtra("admin_context",true); startActivity(i);
    }

    private LinearLayout card(){LinearLayout c=col();c.setPadding(dp(10),dp(8),dp(10),dp(8));c.setBackground(round(Color.WHITE,Color.rgb(224,226,235),12));c.setElevation(dp(1));LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(7);c.setLayoutParams(p);return c;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;} private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private Button button(String s,int c,float z){Button b=new Button(this);b.setText(s);b.setTextColor(c);b.setTextSize(z);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackgroundColor(Color.TRANSPARENT);b.setPadding(0,0,0,0);return b;}
    private TextView txt(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private GradientDrawable round(int fill,int stroke,int r){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(r));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams weight(float w){return new LinearLayout.LayoutParams(0,dp(52),w);} private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
