package com.myshop.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;

/** V-307 dedicated Live Home. Dashboard remains unchanged outside its LIVE entry strip. */
public class LiveHomeActivity extends AppCompatActivity {
    private final int BG=Color.rgb(5,12,38), CARD=Color.rgb(15,27,70), MUTED=Color.rgb(180,193,235);
    private final Handler handler=new Handler();
    private LinearLayout content,tabs;
    private TextView state;
    private String category="LIVE_NOW";
    private final String[][] cats={{"All","LIVE_NOW"},{"Following","FOLLOWING"},{"Popular","TRENDING"},{"New","NEW_HOST"}};
    private final Runnable refreshTick=()->load(false);

    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(build());load(true);}

    private View build(){
        LinearLayout root=col();root.setPadding(dp(14),dp(10),dp(14),dp(16));root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(dp(14),Math.max(dp(10),i.getSystemWindowInsetTop()+dp(4)),dp(14),Math.max(dp(16),i.getSystemWindowInsetBottom()+dp(8)));return i;});
        LinearLayout top=row();TextView back=t("‹",32,Color.WHITE,true);back.setGravity(Gravity.CENTER);back.setOnClickListener(v->finish());top.addView(back,lp(dp(46),dp(48)));TextView title=t("LIVE STREAMING",22,Color.WHITE,true);top.addView(title,wt(1,dp(48)));TextView history=t("◷",23,Color.WHITE,true);history.setGravity(Gravity.CENTER);history.setOnClickListener(v->startActivity(new Intent(this,CreatorCenterActivity.class)));top.addView(history,lp(dp(46),dp(48)));root.addView(top);

        LinearLayout hero=col();hero.setPadding(dp(16),dp(14),dp(16),dp(14));hero.setBackground(grad(new int[]{Color.rgb(98,28,187),Color.rgb(11,94,203),Color.rgb(5,180,219)},22));
        hero.addView(t("📡  LIVE NOW",23,Color.WHITE,true));TextView hs=t("Join live rooms • listen • chat • connect",11.5f,Color.rgb(235,240,255),false);hs.setPadding(0,dp(4),0,0);hero.addView(hs);root.addView(hero,top(lp(-1,dp(92)),6));

        LinearLayout actions=row();TextView go=button("🎙  Go Live\nStart your room",Color.rgb(195,42,213),Color.rgb(111,41,218));TextView join=button("👥  Join Live\nExplore active rooms",Color.rgb(0,170,247),Color.rgb(45,72,228));go.setOnClickListener(v->{Intent i=new Intent(this,AudioLiveRoomActivity.class);i.putExtra("hostMode",true);startActivity(i);});join.setOnClickListener(v->{Intent i=new Intent(this,LiveListActivity.class);i.putExtra("category",category);startActivity(i);});LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(0,dp(74),.38f);gp.rightMargin=dp(8);actions.addView(go,gp);actions.addView(join,new LinearLayout.LayoutParams(0,dp(74),.62f));root.addView(actions,top(lp(-1,dp(74)),10));

        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setHorizontalScrollBarEnabled(false);tabs=row();for(String[] c:cats){String key=c[1];TextView chip=t(c[0],11,Color.WHITE,true);chip.setGravity(Gravity.CENTER);chip.setPadding(dp(17),0,dp(17),0);chip.setOnClickListener(v->{category=key;styleTabs();load(false);});tabs.addView(chip,lp(-2,dp(42)));}hsv.addView(tabs);root.addView(hsv,top(lp(-1,dp(48)),9));styleTabs();

        state=t("Loading live rooms…",11,MUTED,false);state.setGravity(Gravity.CENTER_VERTICAL);state.setOnClickListener(v->load(false));root.addView(state,lp(-1,dp(36)));
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setVerticalScrollBarEnabled(false);content=col();sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));root.post(root::requestApplyInsets);return root;
    }

    private void styleTabs(){for(int i=0;i<tabs.getChildCount();i++){TextView v=(TextView)tabs.getChildAt(i);boolean on=cats[i][1].equals(category);v.setBackground(round(on?Color.rgb(99,55,226):Color.rgb(21,35,78),on?Color.rgb(198,75,255):Color.rgb(55,77,137),16));LinearLayout.LayoutParams p=(LinearLayout.LayoutParams)v.getLayoutParams();p.setMargins(dp(3),dp(3),dp(3),dp(3));v.setLayoutParams(p);}}

    private void load(boolean first){if(first)renderCached();state.setText(content.getChildCount()>0?"Updating live rooms…":"Loading live rooms…");BackendClient.liveDiscover(SessionManager.getToken(this),category,12,new BackendClient.Callback(){public void onSuccess(JSONObject d){getSharedPreferences("myshop_live_home",MODE_PRIVATE).edit().putString(category,d.toString()).putLong(category+"_ts",System.currentTimeMillis()).apply();runOnUiThread(()->renderRooms(d.optJSONArray("rooms")));}public void onError(String m){runOnUiThread(()->{state.setText(content.getChildCount()>0?"Saved live rooms shown • tap to retry":"Live rooms unavailable • tap to retry");if(content.getChildCount()==0)loadSuggestedPeople();});}});}
    private void renderCached(){try{android.content.SharedPreferences p=getSharedPreferences("myshop_live_home",MODE_PRIVATE);long age=System.currentTimeMillis()-p.getLong(category+"_ts",0);if(age<0||age>30000)return;String raw=p.getString(category,"");if(!raw.isEmpty())renderRooms(new JSONObject(raw).optJSONArray("rooms"));}catch(Exception ignored){}}
    private void renderRooms(JSONArray a){content.removeAllViews();int n=a==null?0:a.length();if(n==0){state.setText("No live rooms right now");TextView empty=t("🎙  No live rooms right now\nNew people are shown below until someone goes live.",13,Color.WHITE,true);empty.setGravity(Gravity.CENTER);empty.setPadding(dp(14),dp(18),dp(14),dp(18));empty.setBackground(round(CARD,Color.rgb(54,82,151),18));content.addView(empty,lp(-1,dp(104)));loadSuggestedPeople();return;}state.setText(n+" active live room"+(n==1?"":"s"));for(int i=0;i<n;i++){JSONObject x=a.optJSONObject(i);if(x!=null)content.addView(roomCard(x),top(lp(-1,dp(92)),8));}}

    private View roomCard(JSONObject x){LinearLayout c=row();c.setPadding(dp(11),dp(10),dp(11),dp(10));c.setBackground(round(CARD,Color.rgb(91,72,210),18));ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setClipToOutline(true);av.setBackground(round(Color.rgb(27,40,91),Color.rgb(36,198,255),30));String avatar=x.optString("avatarUrl","");if(!avatar.isEmpty())loadImage(av,avatar);c.addView(av,lp(dp(62),dp(62)));LinearLayout info=col();info.setPadding(dp(10),0,dp(5),0);String name=x.optString("name","MY SHOP User");info.addView(t("🔴 LIVE  "+name,14,Color.WHITE,true),lp(-1,dp(26)));TextView meta=t(x.optString("title","Audio Live")+"\n👁 "+x.optInt("viewerCount",0)+"  •  ID "+x.optString("userId","")+"  •  LV."+x.optInt("level",0),10.3f,MUTED,false);info.addView(meta,lp(-1,dp(38)));c.addView(info,wt(1,dp(64)));TextView join=t("Join",11,Color.WHITE,true);join.setGravity(Gravity.CENTER);join.setBackground(grad(new int[]{Color.rgb(0,172,245),Color.rgb(182,45,234)},15));c.addView(join,lp(dp(68),dp(42)));String uid=x.optString("userId","");c.setOnClickListener(v->{if(uid.isEmpty())return;Intent i=new Intent(this,AudioLiveRoomActivity.class);i.putExtra("hostMode",false);i.putExtra("hostId",uid);i.putExtra("hostName",name);startActivity(i);});return c;}

    private void loadSuggestedPeople(){BackendClient.newPeople(SessionManager.getToken(this),8,0,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->renderSuggested(d.optJSONArray("people")));}public void onError(String m){runOnUiThread(()->{TextView v=t("No suggestions available right now.",11,MUTED,false);v.setGravity(Gravity.CENTER);content.addView(v,top(lp(-1,dp(70)),8));});}});}
    private void renderSuggested(JSONArray a){if(a==null||a.length()==0)return;TextView h=t("NEW PEOPLE",13,Color.WHITE,true);h.setPadding(dp(2),dp(16),0,dp(8));content.addView(h);for(int i=0;i<Math.min(6,a.length());i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String uid=x.optString("userId","");if(uid.equals(SessionManager.getUserId(this)))continue;LinearLayout c=row();c.setPadding(dp(10),dp(8),dp(10),dp(8));c.setBackground(round(Color.rgb(12,24,59),Color.rgb(45,65,118),16));ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setClipToOutline(true);String u=x.optString("avatarUrl","");if(!u.isEmpty())loadImage(av,u);c.addView(av,lp(dp(50),dp(50)));LinearLayout info=col();info.setPadding(dp(10),0,0,0);info.addView(t(x.optString("name","MY SHOP User"),12.5f,Color.WHITE,true));info.addView(t("ID "+uid+"  •  LV."+x.optInt("level",0),9.5f,MUTED,false));c.addView(info,wt(1,dp(50)));TextView open=t("Profile ›",10,Color.rgb(100,210,255),true);open.setGravity(Gravity.CENTER);c.addView(open,lp(dp(76),dp(38)));c.setOnClickListener(v->{Intent q=new Intent(this,UserProfileActivity.class);q.putExtra("userId",uid);startActivity(q);});content.addView(c,top(lp(-1,dp(66)),7));}}

    @Override protected void onResume(){super.onResume();handler.removeCallbacks(refreshTick);handler.postDelayed(refreshTick,7000);}
    @Override protected void onPause(){handler.removeCallbacks(refreshTick);super.onPause();}
    @Override protected void onDestroy(){handler.removeCallbacks(refreshTick);super.onDestroy();}

    private void loadImage(ImageView v,String u){new Thread(()->{try{Bitmap b=BitmapFactory.decodeStream(new URL(u).openStream());if(b!=null)runOnUiThread(()->v.setImageBitmap(b));}catch(Exception ignored){}}).start();}
    private TextView button(String s,int a,int b){TextView v=t(s,12,Color.WHITE,true);v.setGravity(Gravity.CENTER);v.setLines(2);v.setBackground(grad(new int[]{a,b},18));return v;}
    private GradientDrawable grad(int[] c,int r){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,c);g.setCornerRadius(dp(r));return g;}
    private GradientDrawable round(int c,int st,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));g.setStroke(dp(1),st);return g;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView t(String s,float z,int c,boolean b){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(b)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams wt(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int n){p.topMargin=dp(n);return p;}private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
