# MY SHOP Developer Handoff — V-336

## Version identity
- Version: V-336
- Android versionCode: 336
- Android versionName: 2.9.336
- SOURCE_BUILD_ID: MY SHOP V-336

## Completed in this version
- Approved visual-first Live Comment Style Designer finalized.
- Admin color selection is swatch-based; no visible HEX/code input.
- Global All Users default style editor.
- 40 membership ready-made slots: VIP/VVIP/ROYAL Male+Female 5 each, KING Male 5, QUEEN Female 5.
- Box / Border / Text-Font / Name / Level animation controls.
- Border/background glow, opacity, typography, border radius/width and live preview.
- User ID search + Ready-made/Custom assignment.
- Existing assignment is loaded on search.
- Remove / Default returns user to Global style without deleting user/account data.
- Priority: User Custom > Assigned Preset > Global.

## Backend
- Uses existing D1 tables `myshop_live_comment_global`, `myshop_live_comment_presets`, `myshop_live_comment_assignments`.
- Assignment save endpoint now supports disabling an assignment cleanly so a user falls back to Global.
- Deploy Worker before device verification.

## Locked / untouched architecture
- Host remains separate at top.
- 12 user/guest seats remain 6 + 6.
- Existing Coin/Gold, Gift, Dashboard and unrelated working modules must not be redesigned during this verification cycle.

## Next checkpoint
1. GitHub CI compile V-336.
2. Deploy Worker.
3. On device: save Global style, save one preset, search two users, assign ready-made/custom, remove one assignment, reopen Admin, verify persistence.
4. Open Live Room with two accounts and verify priority + color/glow/animation rendering.

## Known verification limits
- Local environment does not contain a complete Gradle wrapper executable/JAR, so Android compile was not claimed locally.
- Real device and deployed D1 runtime remain required before marking feature PASS.
