# MY SHOP Developer Handoff — V-300

## Current checkpoint
- Current source: V-300
- Android: versionCode 300 / versionName 2.9.300
- Worker: V-300 / 2.9.300
- Phase: Recovery / Stability
- Base: V-299 (which carries the V-297 32-point implementation scope)

## V-300 completed changes
- Admin Locker converted to local-only PBKDF2 credential gate. No Cloudflare/D1/R2 locker setup is required; backend role/identity still controls actual admin authorization.
- Normal Login/Register flow preserved.
- Profile top safe-area / Settings touch target corrected.
- Own profile inline Timeline added and refreshed immediately after own text/photo/video post.
- Live seat layout balanced to exactly 12 authoritative seats in two rows: 6 + 6; Seat 1 is Host.
- Non-destructive legacy D1 compatibility for `myshop_live_themes` is executed before default theme insert/select to stop widespread missing-column failures.
- Live End Summary restored with server-backed stats and local fallback.
- Main dashboard bottom navigation lowered to the proper bottom safe-area.
- Existing D1/R2 bindings and data-safety constraints preserved; no destructive user-data migration added.

## Validation completed before delivery
- Worker JS syntax: PASS.
- XML parse: PASS.
- D1 legacy theme migration simulation: PASS.
- Source/build identity: PASS (V-300 / 2.9.300 / code 300).
- Java parser-level syntax scan: no syntax-pattern errors found.

## Pending / device checks
1. Run existing GitHub Actions workflow and confirm Worker deploy + Android release compile/sign/upload are green.
2. Confirm the live-theme compatibility migration runs on production D1 automatically via Worker deployment and the old D1 error no longer appears.
3. Verify Admin Locker setup/unlock/recovery on device; confirm no cloud setup screen/action is required.
4. Verify Settings gear position on gesture-navigation and 3-button devices.
5. Post text/photo/video from own profile and confirm it appears immediately in inline Timeline and MY FEED.
6. Verify 6+6 Live seats and speaker allocation (Host seat 1, guests 2–12).
7. End a Live and verify summary details persist and display.
8. Verify bottom nav sits naturally above Android navigation controls and does not overlap feed.
9. Agora real RTC audio transport remains pending until an Agora project/account and secure token integration are configured.

## Safety / ownership
- Do not delete or reassign permanent user IDs.
- Do not reset D1/R2 or rename production bindings.
- Keep signing/recovery secrets under owner control.
- Preserve SOURCE_BUILD_ID safety guard and permanent signing key workflow.
