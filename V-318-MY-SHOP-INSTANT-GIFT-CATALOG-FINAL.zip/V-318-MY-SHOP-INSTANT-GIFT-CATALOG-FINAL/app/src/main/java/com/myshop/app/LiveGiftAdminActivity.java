package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.Locale;

/** V-318 premium Gift Coin + Gold Coin catalog manager. */
public class LiveGiftAdminActivity extends androidx.appcompat.app.AppCompatActivity {
    private static final int PICK_PREVIEW=9301, PICK_ANIM=9302, PICK_SOUND=9303, PICK_QUICK=9304;
    private String selectedCurrency="COIN";
    private LinearLayout list,editor;
    private TextView catalogTitle,editorTitle,uploadState,volumeValue,scaleValue;
    private Button addNewButton,coinTab,goldTab;
    private EditText name,price,category,preview,animation,sound,order;
    private SeekBar volume,animationScale;
    private CheckBox enabled,animOn,soundOn;
    private long editId=0;
    private JSONObject quickGift=null;
    private String quickKind="";

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        if(!SessionManager.isAdmin(this)){finish();return;}
        build();load("COIN");
    }

    private void build(){
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);
        LinearLayout root=col();root.setPadding(dp(12),dp(12),dp(12),dp(34));
        root.setBackground(gradient(new int[]{Color.rgb(249,250,255),Color.rgb(244,247,255),Color.rgb(255,247,253)},Color.TRANSPARENT,0));

        LinearLayout hero=premiumCard("COIN",0);hero.setPadding(dp(14),dp(13),dp(14),dp(13));
        LinearLayout top=row();Button back=actionButton("‹",Color.rgb(67,82,225),Color.rgb(145,65,220));back.setOnClickListener(v->finish());top.addView(back,new LinearLayout.LayoutParams(dp(48),dp(46)));
        LinearLayout brand=col();TextView h=txt("GIFT COIN & GOLD COIN CATALOG",18.5f,true,Color.rgb(27,30,68));brand.addView(h);brand.addView(txt("গিফট কয়েন ও গোল্ড কয়েন ক্যাটালগ",11,true,Color.rgb(104,63,181)));brand.addView(txt("Price • Sound • Volume • Animation • Order • Publish",9.3f,false,Color.rgb(101,104,135)));top.addView(brand,new LinearLayout.LayoutParams(0,dp(66),1));hero.addView(top);
        TextView garden=txt("✦  🌸  সহজ • সুন্দর • Live-এ সরাসরি Sync  🌸  ✦",10.5f,true,Color.rgb(177,56,140));garden.setGravity(Gravity.CENTER);hero.addView(garden,new LinearLayout.LayoutParams(-1,dp(34)));root.addView(hero,top(-1,-2,0));

        LinearLayout tabs=row();coinTab=actionButton("1  🪙  GIFT COIN",Color.rgb(64,101,239),Color.rgb(113,69,226));goldTab=actionButton("2  👑  GOLD COIN",Color.rgb(224,153,38),Color.rgb(235,88,135));
        coinTab.setOnClickListener(v->{selectedCurrency="COIN";clearEditor(false);styleTabs();load("COIN");});
        goldTab.setOnClickListener(v->{selectedCurrency="GOLD";clearEditor(false);styleTabs();load("GOLD");});
        tabs.addView(coinTab,wt(1));tabs.addView(goldTab,wt(1));root.addView(tabs,top(-1,dp(54),10));styleTabs();

        LinearLayout help=premiumCard("COIN",1);help.addView(txt("Admin Save = Live Catalog Update",13,true,Color.rgb(45,43,86)));
        help.addView(txt("দাম, সাউন্ড, ভলিউম, অ্যানিমেশন সাইজ, অর্ডার বা Publish বদলে Save করলে Live Gift Store একই backend value ব্যবহার করবে। সাধারণ catalog change-এর জন্য APK update লাগবে না।",10,false,Color.rgb(92,94,126)));root.addView(help,top(-1,-2,8));

        addNewButton=actionButton("＋  ADD NEW GIFT COIN GIFT",Color.rgb(36,179,134),Color.rgb(55,110,226));
        addNewButton.setOnClickListener(v->{clearEditor(true);editor.setVisibility(View.VISIBLE);editorTitle.setText("＋ New "+("COIN".equals(selectedCurrency)?"Gift Coin":"Gold Coin")+" Gift");});root.addView(addNewButton,top(-1,dp(52),8));

        editor=premiumCard("COIN",2);editor.setVisibility(View.GONE);editorTitle=txt("New Gift",16,true,Color.rgb(49,43,98));editor.addView(editorTitle);
        name=input("Gift name");price=input("Price");price.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);category=input("Category e.g. LOVE / LUXURY / SPECIAL");category.setText("ALL");
        editor.addView(label("① Gift name + price"));editor.addView(name,h48());editor.addView(price,h48());editor.addView(category,h48());
        preview=input("Preview image URL");animation=input("Animation GIF/WebP URL");sound=input("Sound URL");editor.addView(label("② Gift image / animation / sound"));editor.addView(preview,h48());editor.addView(animation,h48());editor.addView(sound,h48());
        LinearLayout assetBtns=row();Button imageBtn=miniColor("🖼 Image",Color.rgb(65,116,235),Color.rgb(91,72,210)),animBtn=miniColor("✨ Animation",Color.rgb(171,67,212),Color.rgb(235,77,151)),soundBtn=miniColor("🔊 Sound",Color.rgb(31,176,146),Color.rgb(61,123,226));imageBtn.setOnClickListener(v->pick(PICK_PREVIEW,"image",null));animBtn.setOnClickListener(v->pick(PICK_ANIM,"animation",null));soundBtn.setOnClickListener(v->pick(PICK_SOUND,"sound",null));assetBtns.addView(imageBtn,wt(1));assetBtns.addView(animBtn,wt(1));assetBtns.addView(soundBtn,wt(1));editor.addView(assetBtns,top(-1,dp(46),4));
        uploadState=txt("No upload in progress",9,false,Color.rgb(99,102,132));editor.addView(uploadState);

        editor.addView(label("③ Animation size 0–100% • 0% = small, 100% = biggest"));LinearLayout scaleLine=row();animationScale=new SeekBar(this);animationScale.setMax(100);animationScale.setProgress(72);scaleValue=txt("72%",12,true,Color.rgb(183,55,156));animationScale.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){scaleValue.setText(p+"%");}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});scaleLine.addView(animationScale,new LinearLayout.LayoutParams(0,dp(46),1));scaleLine.addView(scaleValue,new LinearLayout.LayoutParams(dp(58),dp(46)));editor.addView(scaleLine);
        LinearLayout scalePreset=row();int[] sp={0,35,70,100};String[] sn={"Small","Medium","Large","Max"};for(int i=0;i<sn.length;i++){final int x=sp[i];Button q=mini(sn[i]);q.setOnClickListener(v->animationScale.setProgress(x));scalePreset.addView(q,wt(1));}editor.addView(scalePreset,top(-1,dp(39),2));

        editor.addView(label("④ Sound volume 0–100%"));LinearLayout volLine=row();volume=new SeekBar(this);volume.setMax(100);volume.setProgress(85);volumeValue=txt("85%",12,true,Color.rgb(75,52,180));volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){volumeValue.setText(p+"%");}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});volLine.addView(volume,new LinearLayout.LayoutParams(0,dp(46),1));volLine.addView(volumeValue,new LinearLayout.LayoutParams(dp(58),dp(46)));editor.addView(volLine);
        LinearLayout presets=row();int[] vals={0,35,70,90};String[] vs={"Mute","Low","Strong","High"};for(int i=0;i<vs.length;i++){final int x=vals[i];Button q=mini(vs[i]);q.setOnClickListener(v->volume.setProgress(x));presets.addView(q,wt(1));}editor.addView(presets,top(-1,dp(39),2));

        editor.addView(label("⑤ Catalog position / order number"));order=input("Position e.g. 1, 2, 3");order.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);order.setText("100");editor.addView(order,h48());
        enabled=check("Published / Enabled",true);animOn=check("Animation ON",true);soundOn=check("Sound ON",true);editor.addView(enabled);editor.addView(animOn);editor.addView(soundOn);
        LinearLayout editActions=row();Button save=actionButton("💾 SAVE / PUBLISH",Color.rgb(45,178,126),Color.rgb(70,91,222)),cancel=actionButton("Cancel",Color.rgb(105,111,137),Color.rgb(128,102,152));save.setOnClickListener(v->saveEditor());cancel.setOnClickListener(v->editor.setVisibility(View.GONE));editActions.addView(save,new LinearLayout.LayoutParams(0,dp(50),.68f));editActions.addView(cancel,new LinearLayout.LayoutParams(0,dp(50),.32f));editor.addView(editActions,top(-1,dp(50),6));root.addView(editor,top(-1,-2,8));

        catalogTitle=txt("🪙 Gift Coin Catalog",16,true,Color.rgb(37,40,78));root.addView(catalogTitle,top(-1,dp(44),12));list=col();root.addView(list,new LinearLayout.LayoutParams(-1,-2));
        sv.addView(root);setContentView(sv);
    }

    private void styleTabs(){boolean c="COIN".equals(selectedCurrency);coinTab.setAlpha(c?1f:.52f);goldTab.setAlpha(c ? .52f : 1f);if(addNewButton!=null)addNewButton.setText("＋  ADD NEW "+(c?"GIFT COIN":"GOLD COIN")+" GIFT");}

    private void load(String currency){
        selectedCurrency=currency;styleTabs();catalogTitle.setText(("COIN".equals(currency)?"🪙 Gift Coin Catalog":"👑 Gold Coin Catalog")+"  •  সব Gift নিচে");
        list.removeAllViews();TextView wait=txt("Loading catalog…",11,false,Color.rgb(100,103,132));wait.setGravity(Gravity.CENTER);list.addView(wait,new LinearLayout.LayoutParams(-1,dp(80)));
        BackendClient.adminLiveGifts(SessionManager.getToken(this),currency,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->render(o.optJSONArray("gifts")));}public void onError(String m){runOnUiThread(()->{list.removeAllViews();list.addView(txt("Catalog load failed: "+m,11,false,Color.rgb(170,45,65)));});}});
    }

    private void render(JSONArray a){
        list.removeAllViews();if(a==null||a.length()==0){TextView e=txt("No gifts yet. Tap ADD NEW GIFT.",11,false,Color.rgb(100,104,132));e.setGravity(Gravity.CENTER);list.addView(e,new LinearLayout.LayoutParams(-1,dp(90)));return;}
        for(int i=0;i<a.length();i++){
            final JSONObject g=a.optJSONObject(i);if(g==null)continue;final int idx=i;
            LinearLayout c=premiumCard(g.optString("currency","COIN"),idx);
            LinearLayout head=row();ImageView art=new ImageView(this);art.setScaleType(ImageView.ScaleType.CENTER_INSIDE);String u=g.optString("preview_url","");if(u.isEmpty())u=g.optString("animation_url","");if(!u.isEmpty())AnimatedAssetLoader.load(art,u);else art.setImageResource(builtInArt(g.optString("name","Gift")));head.addView(art,new LinearLayout.LayoutParams(dp(82),dp(82)));
            LinearLayout info=col();info.addView(txt("#"+g.optInt("sort_order",100)+"  •  "+g.optString("name","Gift"),14.5f,true,Color.rgb(29,31,62)));info.addView(txt(("GOLD".equals(g.optString("currency"))?"👑 Gold Coin":"🪙 Gift Coin")+" • "+(g.optInt("enabled",1)==1?"PUBLISHED":"OFF"),9.5f,true,Color.rgb(96,62,174)));info.addView(txt("Animation "+(g.optInt("animation_enabled",1)==1?"ON":"OFF")+" • Sound "+(g.optInt("sound_enabled",1)==1?"ON":"OFF"),9,false,Color.rgb(87,77,150)));head.addView(info,new LinearLayout.LayoutParams(0,dp(82),1));c.addView(head);

            c.addView(label("মূল্য • Save করলে Live-এ এই দামই ব্যবহার হবে"));LinearLayout priceLine=row();EditText pr=input("Price");pr.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);pr.setText(String.valueOf(g.optInt("price",1)));priceLine.addView(pr,new LinearLayout.LayoutParams(0,dp(48),1));TextView unit=txt("GOLD".equals(g.optString("currency"))?"Gold Coin":"Coin",10,true,Color.rgb(82,62,175));unit.setGravity(Gravity.CENTER);priceLine.addView(unit,new LinearLayout.LayoutParams(dp(92),dp(48)));c.addView(priceLine);

            c.addView(label("কোন নাম্বারে বসবে • Catalog position/order"));EditText ord=input("Position");ord.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);ord.setText(String.valueOf(g.optInt("sort_order",100)));c.addView(ord,h44());

            c.addView(label("Animation size 0–100% • ছোট → বড়"));LinearLayout scl=row();SeekBar sb=new SeekBar(this);sb.setMax(100);sb.setProgress(scaleOf(g));TextView sv=txt(sb.getProgress()+"%",11,true,Color.rgb(185,54,150));sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){sv.setText(p+"%");}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});scl.addView(sb,new LinearLayout.LayoutParams(0,dp(44),1));scl.addView(sv,new LinearLayout.LayoutParams(dp(56),dp(44)));c.addView(scl);

            c.addView(label("Sound volume 0–100%"));LinearLayout vol=row();SeekBar vb=new SeekBar(this);vb.setMax(100);vb.setProgress(g.optInt("sound_volume",85));TextView vv=txt(vb.getProgress()+"%",11,true,Color.rgb(78,56,180));vb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){vv.setText(p+"%");}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});vol.addView(vb,new LinearLayout.LayoutParams(0,dp(44),1));vol.addView(vv,new LinearLayout.LayoutParams(dp(56),dp(44)));c.addView(vol);
            LinearLayout preset=row();int[] val={0,35,70,90};String[] nam={"Mute","Low","Strong","High"};for(int k=0;k<nam.length;k++){final int qv=val[k];Button q=mini(nam[k]);q.setOnClickListener(v->vb.setProgress(qv));preset.addView(q,wt(1));}c.addView(preset,top(-1,dp(38),2));

            CheckBox pub=check("Publish",g.optInt("enabled",1)==1),ao=check("Animation",g.optInt("animation_enabled",1)==1),so=check("Sound",g.optInt("sound_enabled",1)==1);LinearLayout toggles=row();toggles.addView(pub,wt(1));toggles.addView(ao,wt(1));toggles.addView(so,wt(1));c.addView(toggles);

            LinearLayout soundActions=row();Button addSound=miniColor(g.optString("sound_url","").isEmpty()?"🔊 Add Sound":"🔁 Replace",Color.rgb(28,166,144),Color.rgb(64,113,226)),previewSound=miniColor("▶ Preview",Color.rgb(78,88,218),Color.rgb(159,68,215)),removeSound=miniColor("✕ Delete Sound",Color.rgb(230,83,105),Color.rgb(199,63,153));addSound.setOnClickListener(v->pick(PICK_QUICK,"sound",g));previewSound.setOnClickListener(v->previewSound(g.optString("sound_url",""),g.optString("name","Gift"),vb.getProgress()));removeSound.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Delete sound?").setMessage("Gift থাকবে, শুধু এই Gift-এর custom sound সরানো হবে।").setPositiveButton("Delete Sound",(d,w)->quickSave(g,pr,ord,sb,vb,pub,ao,false,"sound_url","")).setNegativeButton("Cancel",null).show());soundActions.addView(addSound,wt(1));soundActions.addView(previewSound,wt(1));soundActions.addView(removeSound,wt(1));c.addView(soundActions,top(-1,dp(42),4));

            LinearLayout assetActions=row();Button image=miniColor("🖼 Image",Color.rgb(65,116,235),Color.rgb(91,72,210)),anim=miniColor("✨ Animation",Color.rgb(171,67,212),Color.rgb(235,77,151)),edit=miniColor("✏ Edit",Color.rgb(228,145,38),Color.rgb(226,78,128));image.setOnClickListener(v->pick(PICK_QUICK,"preview",g));anim.setOnClickListener(v->pick(PICK_QUICK,"animation",g));edit.setOnClickListener(v->fillEditor(g));assetActions.addView(image,wt(1));assetActions.addView(anim,wt(1));assetActions.addView(edit,wt(1));c.addView(assetActions,top(-1,dp(42),4));

            LinearLayout finalActions=row();Button save=actionButton("💾 SAVE",Color.rgb(39,175,126),Color.rgb(67,105,224)),del=actionButton("🗑 DELETE",Color.rgb(232,79,96),Color.rgb(192,61,147));save.setOnClickListener(v->quickSave(g,pr,ord,sb,vb,pub,ao,so.isChecked(),null,null));del.setOnClickListener(v->confirmDelete(g));finalActions.addView(save,new LinearLayout.LayoutParams(0,dp(48),.68f));finalActions.addView(del,new LinearLayout.LayoutParams(0,dp(48),.32f));c.addView(finalActions,top(-1,dp(48),6));
            list.addView(c,top(-1,-2,8));
        }
    }

    private void quickSave(JSONObject g,EditText pr,EditText ord,SeekBar scale,SeekBar vb,CheckBox pub,CheckBox ao,boolean soundEnabled,String overrideKey,String overrideValue){
        try{int sc=scale.getProgress();JSONObject x=fromGift(g).put("price",num(pr,g.optInt("price",1))).put("animationScale",sc).put("sizeMode",modeForScale(sc)).put("sortOrder",numZero(ord,g.optInt("sort_order",100))).put("soundVolume",vb.getProgress()).put("enabled",pub.isChecked()).put("animationEnabled",ao.isChecked()).put("soundEnabled",soundEnabled);if(overrideKey!=null)x.put(apiKey(overrideKey),overrideValue);BackendClient.adminLiveGiftSave(SessionManager.getToken(this),x,new BackendClient.Callback(){public void onSuccess(JSONObject o){toast("Saved • Live Gift Store auto-updated");load(selectedCurrency);}public void onError(String m){toast(m);}});}catch(Exception e){toast("Please check gift settings");}
    }
    private String apiKey(String db){if("sound_url".equals(db))return "soundUrl";if("preview_url".equals(db))return "previewUrl";if("animation_url".equals(db))return "animationUrl";return db;}
    private JSONObject fromGift(JSONObject g)throws Exception{return new JSONObject().put("id",g.optLong("id")).put("name",g.optString("name","Gift")).put("currency",g.optString("currency",selectedCurrency)).put("price",g.optInt("price",1)).put("category",g.optString("category","ALL")).put("previewUrl",g.optString("preview_url","")).put("animationUrl",g.optString("animation_url","")).put("animationMime",g.optString("animation_mime","")).put("animationEnabled",g.optInt("animation_enabled",1)==1).put("soundUrl",g.optString("sound_url","")).put("soundEnabled",g.optInt("sound_enabled",1)==1).put("soundVolume",g.optInt("sound_volume",85)).put("animationScale",scaleOf(g)).put("sizeMode",modeForScale(scaleOf(g))).put("sortOrder",g.optInt("sort_order",100)).put("enabled",g.optInt("enabled",1)==1);}

    private int scaleOf(JSONObject g){if(g.has("animation_scale"))return Math.max(0,Math.min(100,g.optInt("animation_scale",70)));String m=g.optString("size_mode","MEDIUM").toUpperCase(Locale.US);if("SMALL".equals(m))return 15;if("LARGE".equals(m))return 75;if("FULL_SCREEN".equals(m))return 100;return 48;}
    private String modeForScale(int s){if(s<=20)return "SMALL";if(s<=58)return "MEDIUM";if(s<=84)return "LARGE";return "FULL_SCREEN";}

    private void fillEditor(JSONObject g){editId=g.optLong("id");editor.setVisibility(View.VISIBLE);editorTitle.setText("✏ Edit • "+g.optString("name","Gift"));name.setText(g.optString("name"));price.setText(String.valueOf(g.optInt("price",1)));category.setText(g.optString("category","ALL"));preview.setText(g.optString("preview_url"));animation.setText(g.optString("animation_url"));sound.setText(g.optString("sound_url"));volume.setProgress(g.optInt("sound_volume",85));animationScale.setProgress(scaleOf(g));order.setText(String.valueOf(g.optInt("sort_order",100)));enabled.setChecked(g.optInt("enabled",1)==1);animOn.setChecked(g.optInt("animation_enabled",1)==1);soundOn.setChecked(g.optInt("sound_enabled",1)==1);}
    private void clearEditor(boolean show){editId=0;name.setText("");price.setText("");category.setText("ALL");preview.setText("");animation.setText("");sound.setText("");volume.setProgress(85);animationScale.setProgress(72);order.setText("100");enabled.setChecked(true);animOn.setChecked(true);soundOn.setChecked(true);if(show)editor.setVisibility(View.VISIBLE);}
    private void saveEditor(){try{int sc=animationScale.getProgress();JSONObject x=new JSONObject().put("id",editId).put("name",name.getText().toString().trim()).put("currency",selectedCurrency).put("price",num(price,1)).put("category",category.getText().toString().trim()).put("previewUrl",preview.getText().toString().trim()).put("animationUrl",animation.getText().toString().trim()).put("soundUrl",sound.getText().toString().trim()).put("soundVolume",volume.getProgress()).put("animationScale",sc).put("sizeMode",modeForScale(sc)).put("sortOrder",numZero(order,100)).put("enabled",enabled.isChecked()).put("animationEnabled",animOn.isChecked()).put("soundEnabled",soundOn.isChecked());BackendClient.adminLiveGiftSave(SessionManager.getToken(this),x,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{toast("Gift saved • Live price/settings updated");editor.setVisibility(View.GONE);load(selectedCurrency);});}public void onError(String m){toast(m);}});}catch(Exception e){toast("Please check gift fields");}}

    private void confirmDelete(JSONObject g){new AlertDialog.Builder(this).setTitle("Delete "+g.optString("name","Gift")+"?").setMessage("Gift catalog থেকে hide হবে; historical Live transactions ভাঙবে না।").setPositiveButton("DELETE",(d,w)->BackendClient.adminLiveGiftDelete(SessionManager.getToken(this),g.optLong("id"),new BackendClient.Callback(){public void onSuccess(JSONObject o){load(selectedCurrency);}public void onError(String m){toast(m);}})).setNegativeButton("Cancel",null).show();}

    private void pick(int request,String kind,JSONObject gift){quickKind=kind;quickGift=gift;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);if("sound".equals(kind))i.setType("audio/*");else i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,request);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(c!=RESULT_OK||d==null||d.getData()==null)return;Uri u=d.getData();try{String mime=getContentResolver().getType(u),fn="gift_asset";android.database.Cursor q=getContentResolver().query(u,null,null,null,null);if(q!=null){int n=q.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(q.moveToFirst()&&n>=0)fn=q.getString(n);q.close();}InputStream in=getContentResolver().openInputStream(u);if(uploadState!=null)uploadState.setText("Uploading…");final String kind=quickKind;final JSONObject target=quickGift;BackendClient.adminLiveGiftAssetUpload(SessionManager.getToken(this),in,fn,mime,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{String url=o.optString("url","");if(r==PICK_QUICK&&target!=null){try{JSONObject x=fromGift(target);if("sound".equals(kind)){x.put("soundUrl",url).put("soundEnabled",true);}else if("preview".equals(kind))x.put("previewUrl",url);else{x.put("animationUrl",url).put("animationMime",o.optString("mediaType","")).put("animationEnabled",true);}BackendClient.adminLiveGiftSave(SessionManager.getToken(LiveGiftAdminActivity.this),x,new BackendClient.Callback(){public void onSuccess(JSONObject z){toast("Asset saved • Live updated");load(selectedCurrency);}public void onError(String m){toast(m);}});}catch(Exception e){toast("Asset save failed");}}else{if("sound".equals(kind)){sound.setText(url);if(soundOn!=null)soundOn.setChecked(true);}else if("image".equals(kind)||"preview".equals(kind))preview.setText(url);else animation.setText(url);if(uploadState!=null)uploadState.setText("Uploaded • "+o.optString("mediaType"));}});}public void onError(String m){toast(m);}});}catch(Exception e){toast("Could not read selected file");}finally{quickGift=null;quickKind="";}}

    private void previewSound(String url,String giftName,int vol){try{final android.media.MediaPlayer mp;if(url==null||url.trim().isEmpty()){int res=builtInSound(giftName);if(res==0){toast("No sound assigned to this gift");return;}mp=android.media.MediaPlayer.create(this,res);}else{mp=new android.media.MediaPlayer();mp.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);mp.setDataSource(url);mp.setOnPreparedListener(x->{float v=Math.max(0f,Math.min(1f,vol/100f));x.setVolume(v,v);x.start();});mp.prepareAsync();}if(mp!=null){float v=Math.max(0f,Math.min(1f,vol/100f));mp.setVolume(v,v);mp.setOnCompletionListener(x->{try{x.release();}catch(Exception ignored){}});if(url==null||url.trim().isEmpty())mp.start();}}catch(Exception e){toast("Sound preview failed");}}

    private int builtInArt(String n){String x=String.valueOf(n).toLowerCase(Locale.US);if(x.contains("rose"))return R.drawable.gift_rose;if(x.contains("heart"))return R.drawable.gift_heart;if(x.contains("teddy"))return R.drawable.gift_teddy;if(x.contains("chocolate"))return R.drawable.gift_chocolate;if(x.contains("diamond"))return R.drawable.gift_diamond;if(x.contains("crown"))return R.drawable.gift_crown;if(x.contains("car"))return R.drawable.gift_car;if(x.contains("jet"))return R.drawable.gift_jet;if(x.contains("castle"))return R.drawable.gift_castle;return R.drawable.gift_star;}
    private int builtInSound(String n){String x=String.valueOf(n).toLowerCase(Locale.US);if(x.contains("rose"))return R.raw.gift_rose_sound;if(x.contains("heart"))return R.raw.gift_heart_sound;if(x.contains("teddy"))return R.raw.gift_teddy_sound;if(x.contains("chocolate"))return R.raw.gift_chocolate_sound;if(x.contains("diamond"))return R.raw.gift_diamond_sound;if(x.contains("crown"))return R.raw.gift_crown_sound;if(x.contains("car"))return R.raw.gift_car_sound;if(x.contains("jet"))return R.raw.gift_jet_sound;if(x.contains("castle"))return R.raw.gift_castle_sound;if(x.equals("star")||x.contains("super star"))return R.raw.gift_star_sound;return 0;}

    private LinearLayout premiumCard(String currency,int index){LinearLayout x=col();x.setPadding(dp(12),dp(10),dp(12),dp(12));int[][] palettes="GOLD".equals(currency)?new int[][]{{255,251,237,255,241,222},{255,247,241,255,239,246},{250,247,255,255,247,230}}:new int[][]{{245,249,255,250,244,255},{249,245,255,255,244,250},{242,252,251,246,247,255}};int[] p=palettes[Math.abs(index)%palettes.length];android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(p[0],p[1],p[2]),Color.rgb(p[3],p[4],p[5])});g.setCornerRadius(dp(20));g.setStroke(dp(1),"GOLD".equals(currency)?Color.rgb(238,191,91):Color.rgb(197,194,239));x.setBackground(g);x.setElevation(dp(3));return x;}
    private android.graphics.drawable.GradientDrawable gradient(int[] colors,int stroke,int radius){android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,colors);g.setCornerRadius(dp(radius));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    private Button actionButton(String s,int a,int b){Button v=new Button(this);v.setText(s);v.setAllCaps(false);v.setTextColor(Color.WHITE);v.setTextSize(10.5f);v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setPadding(dp(5),0,dp(5),0);android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,new int[]{a,b});g.setCornerRadius(dp(15));v.setBackground(g);v.setElevation(dp(2));return v;}
    private Button miniColor(String s,int a,int b){Button x=actionButton(s,a,b);x.setTextSize(8.3f);return x;}
    private Button mini(String s){return miniColor(s,Color.rgb(79,86,214),Color.rgb(156,65,207));}
    private EditText input(String h){EditText e=new EditText(this);e.setHint(h);e.setTextSize(12);e.setSingleLine(true);e.setPadding(dp(10),0,dp(10),0);return e;}
    private TextView label(String s){TextView t=txt(s,10,true,Color.rgb(78,80,112));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(32));p.topMargin=dp(5);t.setLayoutParams(p);return t;}
    private CheckBox check(String s,boolean on){CheckBox c=new CheckBox(this);c.setText(s);c.setTextSize(10);c.setChecked(on);return c;}
    private TextView txt(String s,float z,boolean bold,int color){TextView x=new TextView(this);x.setText(s);x.setTextSize(z);x.setTextColor(color);if(bold)x.setTypeface(Typeface.DEFAULT,Typeface.BOLD);x.setPadding(0,dp(4),0,dp(4));return x;}
    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private LinearLayout.LayoutParams wt(float w){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,w);p.setMargins(dp(2),0,dp(2),0);return p;}
    private LinearLayout.LayoutParams h48(){return new LinearLayout.LayoutParams(-1,dp(48));}private LinearLayout.LayoutParams h44(){return new LinearLayout.LayoutParams(-1,dp(44));}
    private LinearLayout.LayoutParams top(int w,int h,int m){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.topMargin=dp(m);return p;}
    private int num(EditText e,int d){try{return Math.max(1,Integer.parseInt(e.getText().toString().trim()));}catch(Exception x){return d;}}
    private int numZero(EditText e,int d){try{return Math.max(0,Integer.parseInt(e.getText().toString().trim()));}catch(Exception x){return d;}}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}
}
