# Current Release — MY SHOP V-318

Current work is based on V-317 and implements the reference-video Live Gift send flow plus the premium **Gift Coin & Gold Coin Catalog** Admin system.

Read:
- `V-318_RELEASE_NOTES.md`
- `V-318_VALIDATION_REPORT.txt`
- `V-318_PLAY_COMPLIANCE_QA.md`
- `MY-SHOP-DEVELOPER-HANDOFF.md`

Build identity: `MY SHOP V-318` / Android `2.9.318` / versionCode `318`.
