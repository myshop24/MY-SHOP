package com.myshop.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

/** V-125 admin-only hub. Keeps the admin console completely separate from the user menu. */
public class AdminHubActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(246,248,252), DARK=Color.rgb(20,28,60), PURPLE=Color.rgb(83,32,180), BLUE=Color.rgb(31,73,210), GREEN=Color.rgb(17,139,88), RED=Color.rgb(210,45,55);
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        String uid=SessionManager.getUserId(this);
        if(AdminIdentifiers.isAdminIdentifier(uid)) SessionManager.setRemoteSession(this,SessionManager.getToken(this),Role.ADMIN,AdminIdentifiers.adminIdFor(uid));
        if(!SessionManager.isAdmin(this)){finish();return;}
        build();
    }
    private void build(){
        LinearLayout root=col(); root.setBackgroundColor(BG); root.setPadding(dp(14),dp(14),dp(14),dp(18));
        TextView h=txt("MY SHOP  •  ADMIN PANEL",22,DARK,true); h.setGravity(Gravity.CENTER); root.addView(h,lp(-1,48));
        TextView sub=txt("Admin ID  "+SessionManager.getUserId(this)+"  •  Server authorized",11,Color.DKGRAY,false); sub.setGravity(Gravity.CENTER); root.addView(sub,lp(-1,26));

        LinearLayout status=card(); status.addView(txt("CONTROL CENTER",13,PURPLE,true),lp(-1,26));
        status.addView(txt("Only ADMIN accounts can see this panel. User menu and admin controls are kept separate.",11,DARK,false),lp(-1,42));
        root.addView(status,lp(-1,-2));

        root.addView(section("CONTENT MANAGEMENT"));
        root.addView(tile("01  BANNER MANAGEMENT","6 Hero + 3 Promo • phone gallery upload • edit • save • delete",PURPLE,()->startActivity(new android.content.Intent(this,BannerAdminActivity.class))));
        root.addView(tile("02  GALLERY MANAGEMENT","Photo • Audio • Video • R2 upload • caption • edit • save • delete",BLUE,()->startActivity(new android.content.Intent(this,GalleryAdminActivity.class))));
        root.addView(tile("03  DASHBOARD / FEATURES","Breaking News • feature buttons • URLs • icons • enable/disable",GREEN,()->startActivity(new android.content.Intent(this,AdminManagementActivity.class))));
        root.addView(tile("04  SOCIAL + OTHER LINKS","Social links • Live TV • Movie • More Apps • Payment links",PURPLE,()->startActivity(new android.content.Intent(this,AdminManagementActivity.class))));
        root.addView(tile("05  MODERATORS + ADMIN SETTINGS","Permanent IDs protected • moderator add/remove • all changes server-authorized",BLUE,()->startActivity(new android.content.Intent(this,AdminManagementActivity.class))));

        root.addView(section("SAFE OPERATIONS"));
        LinearLayout safe=card();
        safe.addView(action("OPEN FULL SETTINGS",DARK,()->startActivity(new android.content.Intent(this,AdminManagementActivity.class))),lp(-1,44));
        safe.addView(space(6),lp(1,6));
        safe.addView(action("BACK TO DASHBOARD",GREEN,()->finish()),lp(-1,44));
        root.addView(safe,lp(-1,-2));
        TextView note=txt("No user/auth table is reset by these controls. Existing permanent User IDs remain unchanged.",10,Color.DKGRAY,false);note.setPadding(dp(4),dp(12),dp(4),0);root.addView(note,lp(-1,46));
        setContentView(root);
    }
    private TextView section(String s){TextView t=txt(s,13,PURPLE,true);t.setPadding(dp(3),dp(14),0,dp(7));return t;}
    private LinearLayout tile(String title,String desc,int color,Runnable r){
        LinearLayout c=card(); LinearLayout row=row(); TextView badge=txt("●",color,18,true);badge.setGravity(Gravity.CENTER);row.addView(badge,lp(dp(28),dp(42)));
        LinearLayout body=col();body.addView(txt(title,13,DARK,true),lp(-1,24));body.addView(txt(desc,10,Color.DKGRAY,false),lp(-1,34));row.addView(body,weight(1));
        TextView go=txt("OPEN  ›",color,10,true);go.setGravity(Gravity.CENTER);row.addView(go,lp(dp(64),dp(42)));c.addView(row,lp(-1,-2));c.setOnClickListener(v->r.run());return c;
    }
    private LinearLayout card(){LinearLayout c=col();c.setPadding(dp(11),dp(9),dp(11),dp(9));c.setBackground(bg(Color.WHITE,Color.rgb(225,227,235),10));c.setElevation(dp(2));LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(7);c.setLayoutParams(p);return c;}
    private TextView action(String s,int c,Runnable r){TextView t=txt(s,11,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setBackground(bg(c,c,8));t.setOnClickListener(v->r.run());return t;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;} private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;} private View space(int h){return new View(this);} private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams weight(float w){return new LinearLayout.LayoutParams(0,54,w);} private GradientDrawable bg(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;} private TextView txt(String s,float z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;} private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
