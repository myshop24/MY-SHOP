package com.myshop.app;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * MY SHOP V-124 — polished, server-authorized admin console.
 * All content operations are additive/targeted; auth users, permanent IDs and D1 user data are untouched.
 */
public class AdminManagementActivity extends AppCompatActivity {
    private EditText news, shopUrl, tvUrl, movieUrl, chatUrl, modId;
    private final EditText[] heroUrls=new EditText[6], promoUrls=new EditText[3];
    private final EditText[] socialPlatforms=new EditText[6], socialUrls=new EditText[6];
    private final EditText[] galleryTitles=new EditText[3], galleryUrls=new EditText[3];
    private final EditText[] featureTitles=new EditText[8], featureUrls=new EditText[8], featureIcons=new EditText[8];
    private final CheckBox[] featureActive=new CheckBox[8];
    private final EditText[][] managedTitles=new EditText[4][3], managedUrls=new EditText[4][3], managedIcons=new EditText[4][3];
    private final CheckBox[][] managedActive=new CheckBox[4][3];
    private final long[][] managedIds=new long[4][3];
    private LinearLayout root;
    private final String[] managedCats={"live_tv","external_movie","more_apps","payment_methods"};
    private final String[] managedNames={"LIVE TV","EXTERNAL MOVIE","MORE APPS","PAYMENT METHODS"};
    private final String[] featureKeys={"my_feed","live_now","go_live","live_tv","my_shop","external_movie","gallery","social_media"};
    private final String[] featureNames={"MY FEED","LIVE","GO LIVE","LIVE TV","MY SHOP","EXTERNAL MOVIE","GALLERY","SOCIAL MEDIA"};
    private final int PURPLE=Color.rgb(83,32,180), BLUE=Color.rgb(31,73,210), DARK=Color.rgb(20,28,60), BG=Color.rgb(246,248,252), GREEN=Color.rgb(17,139,88), RED=Color.rgb(210,45,55);

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        String uid=SessionManager.getUserId(this);
        if(AdminIdentifiers.isAdminIdentifier(uid)) SessionManager.setRemoteSession(this,SessionManager.getToken(this),Role.ADMIN,AdminIdentifiers.adminIdFor(uid));
        if(!SessionManager.isAdmin(this)){verifyAdminThenOpen();return;}
        buildUi(); loadCurrentConfig();
    }

    private void verifyAdminThenOpen(){
        String token=SessionManager.getToken(this);
        if(token==null||token.isEmpty()){toast("Admin login required.");finish();return;}
        BackendClient.me(token,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{try{
                JSONObject u=d.optJSONObject("user");
                if(u!=null&&"ADMIN".equalsIgnoreCase(u.optString("role","USER"))){
                    String uid=u.optString("userId",SessionManager.getUserId(AdminManagementActivity.this));
                    SessionManager.setRemoteSession(AdminManagementActivity.this,token,Role.ADMIN,uid);
                    SessionManager.saveProfile(AdminManagementActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""));
                    buildUi();loadCurrentConfig();
                }else{toast("Admin access required.");finish();}
            }catch(Exception e){toast("Admin verification failed.");finish();}});}
            public void onError(String m){runOnUiThread(()->{toast("Admin server check failed: "+m);finish();});}
        });
    }

    private void buildUi(){
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        root=col(); root.setPadding(dp(12),dp(12),dp(12),dp(24)); root.setBackgroundColor(BG);
        TextView title=txt("MY SHOP  •  CONTENT SETTINGS",22,DARK,true); title.setGravity(Gravity.CENTER); root.addView(title,lp(-1,48));
        TextView sub=txt("ID "+SessionManager.getUserId(this)+"  •  Server authorized  •  R2 + D1",11,Color.DKGRAY,false); sub.setGravity(Gravity.CENTER); root.addView(sub,lp(-1,28));
        LinearLayout top=actionBar(); top.addView(action("SAVE ALL",GREEN,()->saveAll()),wt(1)); top.addView(gap(6)); top.addView(action("RELOAD",BLUE,()->loadCurrentConfig()),wt(1)); root.addView(top,lp(-1,46));
        LinearLayout quick=actionBar(); quick.addView(action("BANNERS",PURPLE,()->startActivity(new android.content.Intent(this,BannerAdminActivity.class))),wt(1)); quick.addView(gap(5)); quick.addView(action("GALLERY",BLUE,()->startActivity(new android.content.Intent(this,GalleryAdminActivity.class))),wt(1)); root.addView(quick,lp(-1,46));

        sectionCard("01  DASHBOARD / HEADLINE",()->{
            news=field("Breaking News headline");shopUrl=field("MY SHOP URL");tvUrl=field("LIVE TV URL");movieUrl=field("External Movie URL");chatUrl=field("Chat URL");
            root.addView(news);root.addView(shopUrl);root.addView(tvUrl);root.addView(movieUrl);root.addView(chatUrl);
            root.addView(actionBarWith(action("SAVE",GREEN,()->saveAll()),action("CLEAR",RED,()->{news.setText("");shopUrl.setText("");tvUrl.setText("");movieUrl.setText("");chatUrl.setText("");})));
        });

        sectionCard("02  HERO BANNERS  •  6 SLOTS",()->{
            for(int i=0;i<6;i++) heroUrls[i]=field("Hero Banner "+(i+1)+" URL (optional)");
            root.addView(actionBarWith(action("ADD / UPLOAD",PURPLE,()->startActivity(new android.content.Intent(this,BannerAdminActivity.class))),action("SAVE",GREEN,()->saveAll()),action("DELETE EMPTY",RED,()->clearEmptyBanners())));
        });
        sectionCard("PROMO BANNERS  •  3 SLOTS",()->{for(int i=0;i<3;i++) promoUrls[i]=field("Promo Banner "+(i+1)+" URL (optional)");});

        sectionCard("03  DASHBOARD FEATURES  •  EDIT / SAVE / DELETE",()->{for(int i=0;i<8;i++)addFeatureEditor(i);});
        sectionCard("04  SOCIAL LINKS  •  ADD / SAVE / DELETE",()->{for(int i=0;i<6;i++)addSocialEditor(i);});
        sectionCard("05  GALLERY CONTENT  •  QUICK LINKS",()->{
            for(int i=0;i<3;i++){galleryTitles[i]=field("Gallery item "+(i+1)+" title");galleryUrls[i]=field("Media URL (optional)");}
            root.addView(actionBarWith(action("ADD / UPLOAD",PURPLE,()->startActivity(new android.content.Intent(this,GalleryAdminActivity.class))),action("SAVE",GREEN,()->saveAll()),action("CLEAR",RED,()->clearGalleryFields())));
        });
        sectionCard("06  OTHER RESOURCES  •  ADD / EDIT / SAVE / DELETE",()->{for(int c=0;c<managedCats.length;c++)addManagedSection(c);});

        root.addView(sectionTitle("07  MODERATORS  •  MAX 5"));
        modId=field("4-digit User ID"); root.addView(modId);
        root.addView(actionBarWith(action("ADD MODERATOR",GREEN,()->moderator("add_moderator")),action("REMOVE",RED,()->moderator("remove_moderator"))));
        TextView note=txt("Admin controls stay hidden from normal users. Permanent User IDs and existing user/auth records are never reset by this console.",11,Color.DKGRAY,false);note.setPadding(dp(4),dp(10),dp(4),dp(10));root.addView(note);
        TextView back=action("BACK",DARK,()->finish());root.addView(back,lp(-1,44));
        scroll.addView(root);setContentView(scroll);
    }

    private void addFeatureEditor(int i){
        LinearLayout card=innerCard(); TextView name=txt(featureNames[i]+"  •  "+featureKeys[i],14,DARK,true);card.addView(name,lp(-1,30));
        featureTitles[i]=field("Display title");featureUrls[i]=field("Target URL");featureIcons[i]=field("Icon URL (optional)");card.addView(featureTitles[i]);card.addView(featureUrls[i]);card.addView(featureIcons[i]);
        featureActive[i]=new CheckBox(this);featureActive[i].setText("Show on dashboard");featureActive[i].setChecked(true);featureActive[i].setTextSize(12);card.addView(featureActive[i],lp(-1,38));
        final int idx=i;
        card.addView(actionBarWith(action("SAVE",GREEN,()->saveAll()),action("DELETE / HIDE",RED,()->{featureTitles[idx].setText("");featureUrls[idx].setText("");featureIcons[idx].setText("");featureActive[idx].setChecked(false);})));
        root.addView(card,lp(-1,-2));
    }

    private void addSocialEditor(int i){
        LinearLayout card=innerCard();card.addView(txt("SOCIAL "+(i+1),13,DARK,true),lp(-1,26));
        socialPlatforms[i]=field("Platform name (Facebook / YouTube / TikTok...)");socialUrls[i]=field("Social URL");card.addView(socialPlatforms[i]);card.addView(socialUrls[i]);
        final int idx=i;card.addView(actionBarWith(action("SAVE",GREEN,()->saveAll()),action("DELETE",RED,()->{socialPlatforms[idx].setText("");socialUrls[idx].setText("");})));root.addView(card,lp(-1,-2));
    }

    private void addManagedSection(int c){
        root.addView(sectionTitle(managedNames[c]));
        for(int i=0;i<3;i++){
            LinearLayout card=innerCard();card.addView(txt("ITEM "+(i+1),12,DARK,true),lp(-1,24));
            managedTitles[c][i]=field("Title / name");managedUrls[c][i]=field("URL");managedIcons[c][i]=field("Icon URL (optional)");
            card.addView(managedTitles[c][i]);card.addView(managedUrls[c][i]);card.addView(managedIcons[c][i]);
            managedActive[c][i]=new CheckBox(this);managedActive[c][i].setText("Show / enable");managedActive[c][i].setChecked(true);managedActive[c][i].setTextSize(12);card.addView(managedActive[c][i],lp(-1,34));
            final int cc=c,ii=i;card.addView(actionBarWith(action("SAVE",GREEN,()->saveAll()),action("DELETE",RED,()->{managedIds[cc][ii]=0;managedTitles[cc][ii].setText("");managedUrls[cc][ii].setText("");managedIcons[cc][ii].setText("");managedActive[cc][ii].setChecked(false);})));root.addView(card,lp(-1,-2));
        }
    }

    private void loadCurrentConfig(){
        String token=SessionManager.getToken(this); if(token==null||token.isEmpty())return;
        BackendClient.dashboard(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{try{
            JSONObject c=d.optJSONObject("config");if(c!=null){news.setText(c.optString("breaking_news",""));shopUrl.setText(c.optString("my_shop_url",""));tvUrl.setText(c.optString("live_tv_url",""));movieUrl.setText(c.optString("external_movie_url",""));chatUrl.setText(c.optString("chat_url",""));}
            JSONArray bs=d.optJSONArray("banners");if(bs!=null)for(int i=0;i<bs.length();i++){JSONObject x=bs.optJSONObject(i);if(x==null)continue;int sl=x.optInt("slot",0);String f=x.optString("folder","");if("hero".equalsIgnoreCase(f)&&sl>=1&&sl<=6)heroUrls[sl-1].setText(x.optString("image_url",""));if("promo".equalsIgnoreCase(f)&&sl>=1&&sl<=3)promoUrls[sl-1].setText(x.optString("image_url",""));}
            JSONArray ss=d.optJSONArray("socialLinks");if(ss!=null)for(int i=0;i<Math.min(6,ss.length());i++){JSONObject x=ss.optJSONObject(i);if(x!=null){socialPlatforms[i].setText(x.optString("platform",""));socialUrls[i].setText(x.optString("url",""));}}
            JSONArray gg=d.optJSONArray("gallery");if(gg!=null)for(int i=0;i<Math.min(3,gg.length());i++){JSONObject x=gg.optJSONObject(i);if(x!=null){galleryTitles[i].setText(x.optString("title",""));galleryUrls[i].setText(x.optString("media_url",""));}}
            JSONArray ff=d.optJSONArray("featureButtons");if(ff!=null)for(int i=0;i<ff.length();i++){JSONObject x=ff.optJSONObject(i);if(x==null)continue;String key=x.optString("key","");for(int j=0;j<featureKeys.length;j++)if(featureKeys[j].equals(key)){featureTitles[j].setText(x.optString("title",featureNames[j]));featureUrls[j].setText(x.optString("target_url",""));featureIcons[j].setText(x.optString("icon_url",""));featureActive[j].setChecked(x.optInt("active",1)==1);}}
            JSONArray ml=d.optJSONArray("managedLinks");if(ml!=null)for(int i=0;i<ml.length();i++){JSONObject x=ml.optJSONObject(i);if(x==null)continue;String cat=x.optString("category","");for(int catIndex=0;catIndex<managedCats.length;catIndex++)if(managedCats[catIndex].equals(cat)){int o=x.optInt("display_order",1)-1;if(o>=0&&o<3){managedIds[catIndex][o]=x.optLong("id",0);managedTitles[catIndex][o].setText(x.optString("title",""));managedUrls[catIndex][o].setText(x.optString("url",""));managedIcons[catIndex][o].setText(x.optString("icon_url",""));managedActive[catIndex][o].setChecked(x.optInt("active",1)==1);}}}
        }catch(Exception e){toast("Config read error");}});}public void onError(String m){runOnUiThread(()->toast("Config load failed: "+m));}});
    }

    private void saveAll(){
        try{
            BackendClient.adminDashboardPut(SessionManager.getToken(this),news.getText().toString().trim(),shopUrl.getText().toString().trim(),tvUrl.getText().toString().trim(),movieUrl.getText().toString().trim(),chatUrl.getText().toString().trim(),new BackendClient.Callback(){public void onSuccess(JSONObject d){saveRemoteContent();}public void onError(String m){toast("Dashboard save failed: "+m);}});
        }catch(Exception e){toast("Invalid dashboard content");}
    }

    private void saveRemoteContent(){try{
        JSONObject p=new JSONObject();JSONArray bs=new JSONArray(),delB=new JSONArray();
        for(int i=0;i<6;i++){String u=heroUrls[i].getText().toString().trim();bs.put(new JSONObject().put("folder","hero").put("slot",i+1).put("imageUrl",u).put("caption","Hero "+(i+1)).put("active",!u.isEmpty()));if(u.isEmpty())delB.put(new JSONObject().put("folder","hero").put("slot",i+1));}
        for(int i=0;i<3;i++){String u=promoUrls[i].getText().toString().trim();bs.put(new JSONObject().put("folder","promo").put("slot",i+1).put("imageUrl",u).put("caption","Promo "+(i+1)).put("active",!u.isEmpty()));if(u.isEmpty())delB.put(new JSONObject().put("folder","promo").put("slot",i+1));}
        p.put("banners",bs).put("deleteBanners",delB);
        JSONArray ss=new JSONArray(),delS=new JSONArray();for(int i=0;i<6;i++){String platform=socialPlatforms[i].getText().toString().trim(),url=socialUrls[i].getText().toString().trim();if(!platform.isEmpty()&&!url.isEmpty())ss.put(new JSONObject().put("platform",platform).put("url",url).put("active",true));else if(!platform.isEmpty())delS.put(platform);}p.put("socialLinks",ss).put("deleteSocialPlatforms",delS);
        JSONArray gg=new JSONArray();for(int i=0;i<3;i++){String title=galleryTitles[i].getText().toString().trim(),url=galleryUrls[i].getText().toString().trim();if(!url.isEmpty())gg.put(new JSONObject().put("title",title).put("mediaUrl",url).put("mediaType","image").put("active",true).put("displayOrder",i+1));}p.put("gallery",gg);
        JSONArray ff=new JSONArray();for(int i=0;i<8;i++)ff.put(new JSONObject().put("key",featureKeys[i]).put("title",featureTitles[i].getText().toString().trim()).put("iconUrl",featureIcons[i].getText().toString().trim()).put("targetUrl",featureUrls[i].getText().toString().trim()).put("active",featureActive[i].isChecked()).put("displayOrder",i+1));p.put("featureButtons",ff);
        JSONArray ml=new JSONArray(),delML=new JSONArray();for(int c=0;c<managedCats.length;c++)for(int i=0;i<3;i++){String title=managedTitles[c][i].getText().toString().trim(),url=managedUrls[c][i].getText().toString().trim(),icon=managedIcons[c][i].getText().toString().trim();long id=managedIds[c][i];if(!title.isEmpty()||!url.isEmpty()||!icon.isEmpty())ml.put(new JSONObject().put("id",id).put("category",managedCats[c]).put("title",title).put("url",url).put("iconUrl",icon).put("active",managedActive[c][i].isChecked()).put("displayOrder",i+1));else if(id>0)delML.put(id);}p.put("managedLinks",ml).put("deleteManagedLinkIds",delML);
        BackendClient.adminContentPut(SessionManager.getToken(this),p,new BackendClient.Callback(){public void onSuccess(JSONObject d){toast("✓ Saved successfully");}public void onError(String m){toast("Save failed: "+m);}});
    }catch(Exception e){toast("Invalid remote content");}}

    private void clearEmptyBanners(){for(EditText e:heroUrls)if(e.getText().toString().trim().isEmpty())e.setText("");for(EditText e:promoUrls)if(e.getText().toString().trim().isEmpty())e.setText("");saveAll();}
    private void clearGalleryFields(){for(EditText e:galleryTitles)e.setText("");for(EditText e:galleryUrls)e.setText("");saveAll();}
    private void moderator(String action){String id=modId.getText().toString().trim();if(!id.matches("\\d{4}")){toast("Enter a valid 4-digit User ID.");return;}BackendClient.adminAction(SessionManager.getToken(this),id,action,new BackendClient.Callback(){public void onSuccess(JSONObject d){toast(action.equals("add_moderator")?"✓ Moderator added":"✓ Moderator removed");}public void onError(String m){toast("Action failed: "+m);}});}

    private void sectionCard(String title,Runnable body){root.addView(sectionTitle(title));int start=root.getChildCount();body.run();}
    private TextView sectionTitle(String s){TextView t=txt(s,14,PURPLE,true);t.setPadding(dp(4),dp(14),dp(4),dp(6));return t;}
    private LinearLayout innerCard(){LinearLayout c=col();c.setPadding(dp(10),dp(8),dp(10),dp(8));c.setBackground(bg(Color.WHITE,Color.rgb(225,227,235),8));c.setElevation(dp(1));return c;}
    private LinearLayout actionBar(){LinearLayout r=row();r.setPadding(0,dp(3),0,dp(3));return r;}
    private LinearLayout actionBarWith(View... vs){LinearLayout r=actionBar();for(int i=0;i<vs.length;i++){if(i>0)r.addView(gap(5));r.addView(vs[i],wt(1));}return r;}
    private TextView action(String s,int color,Runnable run){TextView t=txt(s,11,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setBackground(bg(color,color,7));t.setOnClickListener(v->run.run());return t;}
    private EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(13);e.setSingleLine(true);e.setPadding(dp(12),0,dp(12),0);e.setTextColor(DARK);e.setHintTextColor(Color.rgb(145,148,160));e.setBackground(bg(Color.WHITE,Color.rgb(215,218,228),7));LinearLayout.LayoutParams p=lp(-1,46);p.bottomMargin=dp(6);e.setLayoutParams(p);return e;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private View gap(int d){View v=new View(this);return v;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams wt(float w){return new LinearLayout.LayoutParams(0,42,w);}
    private GradientDrawable bg(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    private TextView txt(String s,float z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
}
