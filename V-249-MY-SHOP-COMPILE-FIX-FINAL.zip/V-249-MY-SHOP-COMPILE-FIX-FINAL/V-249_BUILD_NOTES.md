# MY SHOP V-249 Build Notes

- Base: V-248 full project (preserved).
- Android: versionCode 249 / versionName 2.9.249.
- Worker target identity: V-249 / 2.9.249.
- Direct fix: corrected `FeatureActivity.addPlatformButton(...)` fallback call argument count that caused `compileReleaseJavaWithJavac` to fail.
- Functional scope otherwise unchanged from V-248.
- Full GitHub Actions build is the release acceptance gate.
