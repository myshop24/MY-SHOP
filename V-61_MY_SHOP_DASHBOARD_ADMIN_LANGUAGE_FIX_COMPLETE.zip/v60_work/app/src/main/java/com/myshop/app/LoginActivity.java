package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.app.AlertDialog;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** V-54: MY SHOP + LIVE login; backend role check is authoritative. */
public class LoginActivity extends AppCompatActivity {
    private static final String BRAND = "MY SHOP";
    private EditText loginId;
    private EditText loginPassword;
    private TextView emailTab, mobileTab, loginPrefix, languageBn, languageEn;
    private boolean mobileMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // V-47: preserve the existing account/session across normal app updates.
        // This only works when Android performs an in-place update with the same signing key.
        String existingId = SessionManager.getUserId(this);
        if (SessionManager.isLoggedIn(this) && !existingId.isEmpty() && AccountStore.exists(this, existingId)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
            return;
        }

        loginId = findViewById(R.id.loginId);
        loginPassword = findViewById(R.id.loginPassword);
        Button login = findViewById(R.id.loginButton);
        TextView create = findViewById(R.id.createAccountButton);
        TextView forgot = findViewById(R.id.forgotButton);
        ImageButton toggle = findViewById(R.id.passwordToggle);
        emailTab = findViewById(R.id.emailTab);
        mobileTab = findViewById(R.id.mobileTab);
        loginPrefix = findViewById(R.id.loginPrefix);
        languageBn = findViewById(R.id.languageBn);
        languageEn = findViewById(R.id.languageEn);
        languageBn.setOnClickListener(v -> { LanguageManager.set(this, LanguageManager.BN); applyLanguage(); });
        languageEn.setOnClickListener(v -> { LanguageManager.set(this, LanguageManager.EN); applyLanguage(); });
        emailTab.setOnClickListener(v -> setLoginMode(false));
        mobileTab.setOnClickListener(v -> setLoginMode(true));
        setLoginMode(false);
        applyLanguage();

        create.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
        login.setOnClickListener(v -> login());
        forgot.setOnClickListener(v -> showForgotPassword());
        toggle.setOnClickListener(v -> {
            int pos = loginPassword.getSelectionStart();
            boolean hidden = (loginPassword.getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) != 0;
            loginPassword.setInputType(InputType.TYPE_CLASS_TEXT | (hidden ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            loginPassword.setSelection(Math.max(0, pos));
        });
    }


    private void applyLanguage() {
        boolean bn = LanguageManager.BN.equals(LanguageManager.get(this));
        emailTab.setText(bn ? "✉  ইমেইল লগইন" : "✉  Email Login");
        mobileTab.setText(bn ? "▣  মোবাইল লগইন" : "▣  Mobile Login");
        loginPassword.setHint(bn ? "আপনার পাসওয়ার্ড লিখুন" : "Enter your password");
        loginId.setHint(bn ? (mobileMode ? "1XXXXXXXXX" : "আপনার ইমেইল লিখুন") : (mobileMode ? "1XXXXXXXXX" : "Enter your email"));
        ((Button)findViewById(R.id.loginButton)).setText(bn ? "লগইন  →" : "LOGIN  →");
        ((TextView)findViewById(R.id.createAccountButton)).setText(bn ? "＋  অ্যাকাউন্ট খুলুন" : "＋  CREATE ACCOUNT");
        ((TextView)findViewById(R.id.forgotButton)).setText(bn ? "পাসওয়ার্ড ভুলে গেছেন?" : "Forgot Password?");
        languageBn.setBackgroundColor(bn ? 0xFF6224E1 : 0xFFE8EAF0); languageBn.setTextColor(bn ? 0xFFFFFFFF : 0xFF30384A);
        languageEn.setBackgroundColor(bn ? 0xFFE8EAF0 : 0xFF6224E1); languageEn.setTextColor(bn ? 0xFF30384A : 0xFFFFFFFF);
    }

    private void setLoginMode(boolean mobile) {
        mobileMode = mobile;
        if (mobile) {
            loginId.setHint("1XXXXXXXXX");
            loginId.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
            loginPrefix.setText("+880  ▾");
            loginPrefix.setVisibility(TextView.VISIBLE);
            mobileTab.setTextColor(android.graphics.Color.WHITE);
            mobileTab.setBackgroundResource(com.myshop.app.R.drawable.bg_mobile_active);
            emailTab.setTextColor(android.graphics.Color.DKGRAY);
            emailTab.setBackgroundResource(com.myshop.app.R.drawable.bg_email_inactive);
        } else {
            loginId.setHint("enter@example.com");
            loginId.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
            loginPrefix.setText("");
            loginPrefix.setVisibility(TextView.GONE);
            emailTab.setTextColor(android.graphics.Color.WHITE);
            emailTab.setBackgroundResource(com.myshop.app.R.drawable.bg_email_tab);
            mobileTab.setTextColor(android.graphics.Color.DKGRAY);
            mobileTab.setBackgroundResource(com.myshop.app.R.drawable.bg_mobile_tab);
        }
    }


    private void showForgotPassword() {
        final EditText identifierInput = new EditText(this);
        identifierInput.setSingleLine(true);
        identifierInput.setHint("Email / Mobile / User ID");
        new AlertDialog.Builder(this)
                .setTitle("Forgot Password?")
                .setMessage("OTP নেই। আপনার ৩টি Security Question দিয়ে Password reset করুন।")
                .setView(identifierInput)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Continue", (d, which) -> verifySecurity(identifierInput.getText().toString().trim()))
                .show();
    }

    private void verifySecurity(String identifier) {
        if (identifier.isEmpty()) { Toast.makeText(this, "Identifier দিন।", Toast.LENGTH_SHORT).show(); return; }
        String[] q = AccountStore.getSecurityQuestions(this, identifier);
        if (q.length != 3 || q[0].isEmpty() || q[1].isEmpty() || q[2].isEmpty()) {
            Toast.makeText(this, "এই Account-এর Security Questions পাওয়া যায়নি।", Toast.LENGTH_LONG).show();
            return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int)(16 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, 0, pad, 0);
        EditText a1 = answerField(q[0]); box.addView(a1);
        EditText a2 = answerField(q[1]); box.addView(a2);
        EditText a3 = answerField(q[2]); box.addView(a3);
        EditText np = answerField("নতুন Password (কমপক্ষে ৬ অক্ষর)"); np.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD); box.addView(np);
        new AlertDialog.Builder(this)
                .setTitle("Security Verification")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("RESET PASSWORD", (d, which) -> {
                    boolean ok = AccountStore.resetPasswordWithSecurity(this, identifier, a1.getText().toString(), a2.getText().toString(), a3.getText().toString(), np.getText().toString());
                    Toast.makeText(this, ok ? "Password reset successful." : "Security answers or new password are incorrect.", Toast.LENGTH_LONG).show();
                })
                .show();
    }

    private EditText answerField(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextSize(15);
        return e;
    }

    private void login() {
        String identifier = loginId.getText().toString().trim();
        String pass = loginPassword.getText().toString();
        if (identifier.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Email/Mobile and Password are required.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            AccountStore.Account account = AccountStore.authenticate(this, identifier, pass);
            if (account == null && mobileMode && !identifier.startsWith("+880")) {
                account = AccountStore.authenticate(this, "+880" + identifier, pass);
            }
            if (account == null) {
                Toast.makeText(this, "Login failed. Check your Email/Mobile and Password.", Toast.LENGTH_LONG).show();
                return;
            }
            Role role = AdminIdentifiers.isAdminIdentifier(identifier) || AdminIdentifiers.isAdminAccount(account.email, account.mobile) ? Role.ADMIN : Role.USER;
            SessionManager.setSession(this, role, account.userId);
            SessionManager.saveProfile(this, account.name, account.email, account.mobile);
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        } catch (Throwable t) {
            Toast.makeText(this, "Login failed safely. Your account data was not changed.", Toast.LENGTH_LONG).show();
        }
    }
}
