# MY SHOP V-19 — Final Consolidated Foundation

V-19 incorporates the remaining pre-build foundations: account/settings, profile/password/reset hooks, report/block hooks, notification preference, final feature inventory, admin action contract, backup/restore contract, activity-log/statistics contract, and release/build validation.

## Configuration without APK update
Content/configuration such as banners (up to 6 per section), breaking news, button labels/icons/links, social links, MY SHOP URL, Live TV channels, external movie URL, payment-method descriptions, and More Apps should be server-controlled.

## Security
Admin authentication, role detection, password changes, moderator permissions, bans, reports and audit logs must be enforced by the backend. The APK contains no admin password.

## User IDs
New accounts receive a unique four-digit ID from the backend using an atomic/transaction-safe allocator. The local allocator is only a development fallback.

## Live
The app contains the dashboard/feature architecture for Live Now and Go Live. Actual real-time streaming, chat, multi-guest and moderation require a media/backend service.

## Payments
Payment method display/configuration is supported. Actual money movement requires a compliant payment provider/backend and must not be implemented as client-only logic.

## Release
GitHub Actions installs JDK 17, Android SDK 35 and Gradle 8.9, validates the project, runs lint, builds debug and unsigned release APKs, verifies the APKs, and uploads checksums. Signing is optional via GitHub Secrets.
