# MY SHOP V-19 — GitHub-ready project

This folder is the repository root. Upload the **contents of this folder** to the root of the GitHub repository `MY-SHOP` (do not upload the outer ZIP as the only repository file).

GitHub Actions workflow: `.github/workflows/android-apk.yml`

The workflow installs JDK 17, Android SDK 35 and Gradle 8.9, validates configuration, runs lint, builds debug/release APKs, verifies APK integrity, and uploads the APK artifacts.
