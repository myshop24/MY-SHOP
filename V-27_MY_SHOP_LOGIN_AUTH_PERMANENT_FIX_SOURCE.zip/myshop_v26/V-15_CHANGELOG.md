# MY SHOP V-15 CHANGELOG

V-15 is a stability and release-readiness consolidation built on V-14.

## Improvements
- Versioned build metadata moved to V-15 / 2.4.0.
- CI workflow names and APK artifact names updated to V-15.
- Added a backend-only admin identity configuration template so admin identifiers are not embedded in the APK.
- Added a release-readiness checklist covering authentication, role detection, server-side User ID allocation, remote configuration, and feature isolation.
- Added CI checks to prevent accidental inclusion of admin identifiers/passwords in Android source/resources.
- Preserved the V-14 project as an immutable prior-version backup; this package is a new version.

## Important
Authentication, Admin role detection, four-digit serial User ID allocation, and remote content management must be enforced by the backend in production. The Android client is intentionally not a security authority.
