# V-20 MY SHOP RELEASE NOTES

V-20 is the next test build after the successful V-19 CI build.

Android identity:
- applicationId: com.myshop.app
- versionCode: 20
- versionName: 2.9.0

The V-19 runtime hardening is retained. The `.debug` package suffix is removed so the APK has the same applicationId as the normal MY SHOP application.

Important: an APK signed with a different signing key cannot update an already-installed APK. If the phone still has the older V-19 `.debug` package, uninstall that old package once before installing V-20. Future update compatibility also depends on using the same signing key.
