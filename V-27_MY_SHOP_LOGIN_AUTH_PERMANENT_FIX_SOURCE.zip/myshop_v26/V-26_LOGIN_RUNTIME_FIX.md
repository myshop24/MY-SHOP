# MY SHOP V-26 — Login Runtime Fix

## Root cause found from device video + Build #38
The Build #38 screenshot reports Source ZIP `V-25_MY_SHOP_DEVELOPMENT_BASE.zip`, not the audited V-25 source package. Therefore the tested APK was not built from the audited source that contained the login/runtime hardening.

## V-26 changes
- New source package identity: V-26_MY_SHOP_LOGIN_RUNTIME_FIXED_SOURCE.zip
- Android versionCode: 26
- Android versionName: 2.14.1
- Login/Register no longer clear the entire task before MainActivity is confirmed reachable.
- Workflow verifies the exact V-26 ZIP and exact APK package/version metadata.
- Previous V-25/V-24/V-23 sources remain separate backups.

## Data integrity
APK update must not clear SharedPreferences/account records or generate a new User ID for an existing account.
