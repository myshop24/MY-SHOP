# V-15 BUILD NOTES

## CI build
GitHub Actions uses JDK 17 and Gradle 8.9, validates the project, then builds Debug and unsigned Release APKs.

## Production security
- Admin identities and passwords are backend-only.
- Admin role detection is backend-authoritative.
- Four-digit user IDs must be allocated atomically by the backend to prevent duplicates.
- Remote feature/content permissions must be checked server-side.
- APK UI checks are not a security boundary.

## Release checklist
- [ ] Run GitHub Actions workflow successfully.
- [ ] Install Debug APK on a real Android device.
- [ ] Test Dashboard, Login/Register, language switching, banners, feature routing and share.
- [ ] Connect production authentication/backend.
- [ ] Verify three admins and six-moderator limit server-side.
- [ ] Verify no admin secrets/identifiers are shipped in APK.
- [ ] Run regression tests after every feature change.
