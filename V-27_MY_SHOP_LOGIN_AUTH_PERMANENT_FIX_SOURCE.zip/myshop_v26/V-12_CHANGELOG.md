# V-12 MY SHOP

## Focus
Backend contract hardening and build-safety foundation.

## Added
- Backend authentication response contract for automatic Admin/Moderator/User role detection.
- Backend content-management contract for remotely editable dashboard features.
- Endpoint contract for authentication, identity, moderator management and dashboard content.
- Validation script for JSON, critical files and the six-banner limit.
- CI runs the same validation before Android build.

## Preserved
- V-11 dashboard and feature structure.
- Bangla, English, Hindi and Arabic foundation.
- Six-banner auto-slider architecture.
- Same-dashboard Admin model.
- Maximum six moderators with restricted permissions.
- Previous versions are not modified.

## Build note
APK compilation is intended to be verified on the GitHub Actions runner with Android SDK/Gradle. This environment does not claim a local APK build.
