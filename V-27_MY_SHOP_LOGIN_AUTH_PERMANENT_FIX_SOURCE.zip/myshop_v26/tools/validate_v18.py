from pathlib import Path
import json, re, zipfile

ROOT = Path(__file__).resolve().parents[1]
required = [
    'settings.gradle','build.gradle','gradle.properties','app/build.gradle',
    'app/src/main/AndroidManifest.xml',
    'app/src/main/java/com/myshop/app/MainActivity.java',
    'app/src/main/java/com/myshop/app/LoginActivity.java',
    'app/src/main/java/com/myshop/app/RegisterActivity.java',
    'app/src/main/assets/feature_config.json',
    'backend/contracts/ADMIN_AUTH_CONTRACT.json',
    'backend/roles/ROLE_CONTRACT.json',
    'backend/remote-config/BANNER_SCHEMA.json',
    '.github/workflows/android-apk.yml'
]
for item in required:
    assert (ROOT/item).is_file(), f'Missing required file: {item}'

for p in ROOT.rglob('*.json'):
    if 'build' not in p.parts:
        with p.open(encoding='utf-8') as f: json.load(f)

app = (ROOT/'app/build.gradle').read_text(encoding='utf-8')
assert re.search(r'versionCode\s+18\b', app)
assert "versionName '2.7.0'" in app
assert re.search(r"compileSdk\s+35", app)
assert re.search(r"targetSdk\s+35", app)

root_gradle=(ROOT/'build.gradle').read_text(encoding='utf-8')
assert "com.android.application" in root_gradle
assert "8.7.3" in root_gradle

cfg=json.loads((ROOT/'app/src/main/assets/feature_config.json').read_text(encoding='utf-8'))
max_banners=int(cfg.get('maxBannersPerSection',6))
assert 1 <= max_banners <= 6
assert int(cfg.get('sliderIntervalMs',3500)) >= 1000

for p in ROOT.rglob('*'):
    if p.suffix in {'.java','.kt','.xml','.gradle','.json'} and 'build' not in p.parts and '.git' not in p.parts and 'backend' not in p.parts:
        text=p.read_text(encoding='utf-8',errors='ignore').lower()
        for secret in ('myshopsatkania@gmail.com','touhidsatkania@gmail.com','01860626700'):
            assert secret not in text, f'Credential literal found in {p}'

wf=(ROOT/'.github/workflows/android-apk.yml').read_text(encoding='utf-8')
for needle in ['android-actions/setup-android@v3','platforms;android-35','build-tools;35.0.0','gradle-version: \'8.9\'',':app:lintDebug',':app:assembleDebug',':app:assembleRelease','unzip -t','actions/upload-artifact@v4']:
    assert needle in wf, f'Missing CI safeguard: {needle}'

print('V-18 validation OK')
