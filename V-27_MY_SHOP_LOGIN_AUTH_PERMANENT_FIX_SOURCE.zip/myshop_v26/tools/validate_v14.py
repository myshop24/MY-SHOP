import json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
required=[
 'settings.gradle','build.gradle','gradle.properties','app/build.gradle',
 'app/src/main/AndroidManifest.xml','app/src/main/assets/feature_config.json',
 'backend/contracts/ADMIN_AUTH_CONTRACT.json','backend/contracts/ADMIN_ACTION_REGISTRY.json',
 'backend/contracts/AUTH_RESPONSE_CONTRACT.json','backend/roles/ROLE_CONTRACT.json',
 'backend/schema/banner-defaults.json','backend/schema/permissions.json',
 'backend/schema/remote_config.schema.json'
]
missing=[p for p in required if not (ROOT/p).is_file()]
if missing: raise SystemExit('Missing: '+', '.join(missing))
for p in ROOT.rglob('*.json'):
    json.loads(p.read_text(encoding='utf-8'))
# banner count must be <= 6 where represented
for p in ROOT.rglob('*.json'):
    obj=json.loads(p.read_text(encoding='utf-8'))
    if isinstance(obj,dict) and 'maxBannersPerSection' in obj and obj['maxBannersPerSection']>6:
        raise SystemExit(f'Banner limit exceeded: {p}')
# no obvious plaintext password values in Java/XML/assets
bad=[]
for p in list((ROOT/'app/src').rglob('*.java'))+list((ROOT/'app/src').rglob('*.xml')):
    s=p.read_text(encoding='utf-8', errors='ignore').lower()
    if 'mypassword=' in s or 'password="' in s and 'hint=' not in s:
        bad.append(str(p.relative_to(ROOT)))
if bad: raise SystemExit('Possible hard-coded password: '+', '.join(bad))
# balanced braces for Java
for p in (ROOT/'app/src/main/java').rglob('*.java'):
    s=p.read_text(encoding='utf-8');
    if s.count('{') != s.count('}'):
        raise SystemExit(f'Unbalanced braces: {p}')
print('V-14 validation OK')
