from pathlib import Path
import json, re, sys, zipfile
ROOT=Path(__file__).resolve().parents[1]
errors=[]
required=[ROOT/"app/build.gradle", ROOT/"app/src/main/AndroidManifest.xml", ROOT/"app/src/main/assets/feature_config.json", ROOT/"app/src/main/assets/final_feature_inventory.json", ROOT/"V-19_FINAL_CONSOLIDATED_SPEC.md"]
for p in required:
    if not p.exists(): errors.append(f"Missing: {p}")
for p in ROOT.rglob("*.json"):
    if ".git" in p.parts or "build" in p.parts: continue
    try: json.loads(p.read_text(encoding="utf-8"))
    except Exception as e: errors.append(f"Invalid JSON {p}: {e}")
text="\n".join(p.read_text(encoding="utf-8",errors="ignore") for p in ROOT.rglob("*.java"))
for bad in ["myshopsatkania@gmail.com","Touhidsatkania@gmail.com","01860626700"]:
    if bad in text: errors.append(f"Admin identifier embedded in Java: {bad}")
b=ROOT/"app/build.gradle"; bs=b.read_text();
if "versionCode 19" not in bs or "versionName '2.8.0'" not in bs: errors.append("Version is not 19/2.8.0")
inv=json.loads((ROOT/"app/src/main/assets/final_feature_inventory.json").read_text())
if inv.get("version")!=19: errors.append("Inventory version mismatch")
if errors:
    print("VALIDATION FAILED")
    print("\n".join(errors)); sys.exit(1)
print("V-19 validation OK")
