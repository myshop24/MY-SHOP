import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]

# JSON validation
for p in root.rglob('*.json'):
    with p.open(encoding='utf-8') as f:
        json.load(f)

# Required project files
required = [
    'settings.gradle', 'build.gradle', 'app/build.gradle',
    'app/src/main/AndroidManifest.xml',
    'app/src/main/java/com/myshop/app/MainActivity.java',
    'app/src/main/java/com/myshop/app/LoginActivity.java',
    'backend/roles/ADMIN_IDENTIFIERS.template.json',
]
for rel in required:
    assert (root / rel).is_file(), f'Missing: {rel}'

# Do not allow real admin identifiers/passwords in Android client source/resources.
for p in list((root/'app').rglob('*.java')) + list((root/'app').rglob('*.xml')) + list((root/'app').rglob('*.json')):
    text = p.read_text(encoding='utf-8', errors='ignore').lower()
    forbidden = ['myshopsatkania@gmail.com', 'touhidsatkania@gmail.com', '01860626700']
    assert not any(x in text for x in forbidden), f'Admin identifier leaked into APK tree: {p}'
    assert 'admin_password' not in text and 'adminpassword' not in text, f'Admin password field leaked into APK tree: {p}'

cfg = json.loads((root/'app/src/main/assets/feature_config.json').read_text(encoding='utf-8'))
assert 1 <= int(cfg.get('maxBannersPerSection', 0)) <= 6
assert int(cfg.get('sliderIntervalMs', 0)) >= 1000

print('V-15 validation OK')
