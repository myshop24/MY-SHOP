# MY SHOP — Developer Rules

1. Never overwrite a previous version.
2. Deliver only one complete ZIP at the end of each milestone.
3. File naming must begin with the version number: `V-2 MY SHOP`, then `V-3 MY SHOP`, etc.
4. Prefer backend-driven configuration for every feature that can safely be changed without an APK update.
5. Do not hardcode Admin passwords or secret backend keys in the APK.
6. Keep features isolated so fixing one module does not break another.
7. After every major change: validate XML/resources, inspect Java source, verify manifest references, check workflow/artifact names, and run available build/static checks.
8. A real APK must never be claimed as built unless the Android build actually succeeds.
9. Production User IDs must be allocated atomically by the backend.
10. The three Admin accounts and Moderator permissions are backend data, not hardcoded app credentials.

## V-13 additional rule
- Remote configuration must be validated before replacing the last-known-good cache.
- Banner sections must never accept more than 6 active banners.
- Remote slider timing must stay between 1 and 60 seconds.
- Never hard-code Admin credentials in APK source/resources.
