# V-13 MY SHOP

V-13 strengthens the remote-config foundation without changing the main dashboard concept.

- Added a validated `RemoteConfigSnapshot` model.
- Banner count is capped at 6 and slider timing is remotely configurable within a safe range.
- Banner image/link URLs are accepted only as HTTP(S) URLs.
- Main dashboard reads the last known-good remote configuration for banner timing/count.
- Kept User/Admin/Moderator permission boundaries unchanged.
- Kept the single-dashboard Admin experience unchanged.
- Updated Android versionCode to 13 and versionName to 2.2.0.
- Updated CI artifact names and validation to V-13.
