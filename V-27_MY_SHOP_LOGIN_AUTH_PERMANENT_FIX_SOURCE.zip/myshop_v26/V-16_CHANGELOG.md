# V-16 MY SHOP — Changelog

## Release hardening
- Version Code: 16
- Version Name: 2.5.0
- Strengthened CI validation before Android build.
- Builds Debug and unsigned Release APKs automatically.
- Verifies APK ZIP integrity before artifact upload.
- Produces SHA-256 checksums for APK artifacts.
- Added optional signed-release flow using GitHub Actions Secrets; no signing key is stored in the project.
- Added V-16 project validator and required-file checks.
- Preserved V-15 functionality and structure; no prior version is overwritten.
