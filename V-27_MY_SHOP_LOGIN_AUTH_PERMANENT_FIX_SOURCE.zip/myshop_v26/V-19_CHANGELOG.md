# V-19 MY SHOP CHANGELOG

- Consolidated remaining pre-build features into one final foundation.
- Added Account & Settings screen.
- Added profile/password/reset/report/block integration hooks.
- Added final feature inventory and backend contract.
- Added final validation script.
- Updated CI workflow and artifacts to V-19.
- Preserved previous V-18 source as the starting point; V-18 was not overwritten.
