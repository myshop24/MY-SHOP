# MY SHOP V-11 — Change Log

V-11 is a foundation hardening release. It does not claim that backend services are already deployed.

## Added
- Validated `RemoteConfigManager` foundation with last-known-good cache.
- Remote configuration endpoint can be supplied without hard-coding credentials.
- Downloaded configuration is rejected unless it passes JSON/schema safety checks.
- Central `ADMIN_ACTION_REGISTRY.json` documents the intended Add/Edit/Delete/Hide/Show/Reorder/Enable/Disable controls for each feature.
- Backend authorization remains mandatory; the APK must never be treated as the source of truth for admin permissions.
- Version code 11 / version name 2.0.0.

## Preserved
- Main Dashboard remains the single home/dashboard.
- Four languages: Bangla, English, Hindi, Arabic.
- Six-banner maximum and auto-rotation foundation.
- Three full-admin accounts are represented only as backend identifiers; passwords are never embedded in the APK.
- Maximum six moderators with limited permissions.
- V-10 remains a separate backup and is not overwritten.

## Verification policy
Static JSON/XML/source checks are performed before packaging. Actual Android compilation is performed by the GitHub Actions workflow because this working environment does not contain the Android SDK/Gradle installation.
