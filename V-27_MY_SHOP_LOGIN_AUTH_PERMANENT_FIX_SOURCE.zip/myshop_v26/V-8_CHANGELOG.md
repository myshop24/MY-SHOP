# MY SHOP V-8

V-8 strengthens the foundation without replacing the V-7 design direction.

## Included
- Central FeatureRegistry for backend/remote-config-ready URLs.
- Safe HTTP/HTTPS URL validation before external navigation.
- Local feature catalog reader for the existing feature_config.json.
- INTERNET permission for future backend connectivity.
- Main dashboard remains the same single-dashboard model.
- User/Admin/Moderator architecture remains unchanged.
- Version bumped to 8 / 1.7.0.
- CI artifact names updated to V-8.

## Verification note
This environment does not contain the Android SDK/Gradle installation, so a local APK compile is not claimed here. The GitHub Actions workflow is the build verification path.
