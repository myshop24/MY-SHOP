# MY SHOP — V-15 FINAL CONSOLIDATED SPECIFICATION

This package consolidates the MY SHOP Android foundation and the agreed product rules.

## Core
- App name: MY SHOP
- Same Main Dashboard for users and admins; admin controls appear by backend role.
- Login/Register available; no OTP/verification code in the first release.
- Server-generated unique 4-digit sequential User ID.
- Three full admins: two email identifiers and one mobile identifier; passwords are backend-managed and changeable.
- Up to six moderators; moderator permissions are limited to moderation actions only.
- Four UI languages: Bangla, English, Hindi, Arabic.

## Dashboard
Menu, Search, Notifications, More, Banner, Breaking News, Live Now, Go Live, MY FEED, MY SHOP, Gallery, External Movie, Live TV, Social Media, Earn & Reward, Share, Chat, More Apps.

## Remote administration
Where technically possible, all content/configuration is backend-controlled so Admin can Add/Edit/Delete/Hide/Show/Reorder/Enable/Disable without an APK update. Native capability changes may still require an APK update.

## Banner
Maximum 6 banners per section; automatic slider; Admin controls image, text, link, order, timing, visibility.

## Social/content
MY FEED supports text/photo/video post architecture. Gallery has Photo/Audio/Video sections. External Movie, Live TV, Social links, MY SHOP website URL, Payment Methods and More Apps are remote-configurable.

## Live
Live Now and Go Live foundation is included. Production live streaming requires a real-time media backend/service and will be integrated without redesigning the dashboard.

## Security
Roles and authorization must be enforced server-side. Never trust client-side admin flags. Never hard-code admin passwords/secrets in the APK.

## Build
Every milestone is kept as a separate archive. V-15 is a consolidated milestone. CI must validate configuration, build debug and unsigned release APKs, verify output files and upload artifacts.
