# MY SHOP V-17 — Release Candidate Notes

This version focuses on making the APK build process reproducible and failure-resistant on GitHub Actions.

Build order:
1. Checkout
2. JDK 17
3. Android SDK setup
4. Android 35 + Build Tools 35.0.0
5. Project/config validation
6. JSON validation
7. Android lint
8. Debug APK build
9. Unsigned Release APK build
10. APK ZIP integrity + SHA-256
11. Optional signed APK using GitHub Secrets

The project still requires the backend for production authentication, role authorization, remote content management, live streaming, chat, payments, and other server-backed features.
