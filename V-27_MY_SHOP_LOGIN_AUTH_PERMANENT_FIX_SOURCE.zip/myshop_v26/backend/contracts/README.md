# MY SHOP V-5 Backend Contracts

These JSON files define the server-side contracts that the Android client expects.
They are specifications, not a substitute for real authentication or a production database.

## Security rule
Admin credentials must be verified by the backend. Never place admin passwords, API secrets,
or service credentials in the APK.

## Remote update rule
Use these contracts so banners, news, links, payment methods, social links, gallery items,
and other editable content can change without an APK release wherever technically possible.
