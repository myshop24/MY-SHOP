# MY SHOP Remote Configuration Contract

The mobile app should consume these values from an authenticated backend endpoint in production.
Do not store admin passwords, private keys, or authoritative roles in the APK.
Changes to editable content should be reflected remotely without rebuilding the APK.
