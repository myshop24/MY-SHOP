# MY SHOP Backend Contract — V-2

This document defines the remote-data boundary required to keep configurable features updateable without an APK update.

## Remote-configurable resources
- `app_settings`: language defaults, branding, feature visibility
- `banners`: up to 6 active items per banner section, order + timing + link + image + text
- `breaking_news`: text, order, active state
- `external_links`: MY SHOP, movie, TV, social platforms
- `more_apps`: name, icon, description, link, order, active state
- `payment_methods`: name, type, image/QR, instructions, active state
- `notifications`: message, audience, read state/history
- `moderators`: user_id, active state, permission set (max 6)
- `users`: profile + immutable four-digit public ID

## Security boundary
Admin authentication, password hashing, sessions/tokens, role checks and moderator authorization MUST be server-side. Never put Admin passwords or secret API keys in the Android source.

## Four-digit ID rule
The production API must allocate IDs atomically and enforce a unique constraint. The Android local allocator in V-2 is only a prototype and must not be used as the production source of truth.

## Versioning
Changing data in these resources should not require an APK update. Changing native Android capability or application code may require a new APK.
