# MY SHOP V-12 Backend Endpoint Contract

The Android app is a client. The backend remains the authority for authentication, roles, IDs and shared admin-managed content.

## Authentication
- POST `/v1/auth/login`
- POST `/v1/auth/register`
- POST `/v1/auth/logout`
- POST `/v1/auth/password/change`
- POST `/v1/auth/password/reset`

## Session / identity
- GET `/v1/me`
- GET `/v1/users/{userId}`
- Registration allocates a unique four-digit serial ID atomically on the server.

## Admin / moderator
- GET `/v1/admin/permissions`
- POST `/v1/admin/moderators`
- DELETE `/v1/admin/moderators/{userId}`
- POST `/v1/admin/actions`

## Shared dashboard content
- GET `/v1/dashboard/config`
- PUT `/v1/admin/dashboard/config`
- GET `/v1/banners`
- GET `/v1/breaking-news`
- GET `/v1/live/now`
- GET `/v1/gallery`
- GET `/v1/payment-methods`
- GET `/v1/social-links`
- GET `/v1/more-apps`

All write endpoints require a valid backend session token and server-side role authorization. Hidden UI is not a security boundary.
