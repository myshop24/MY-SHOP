# Admin identity storage

The three MY SHOP admin login identifiers supplied by the project owner belong in the production authentication provider/database, not inside the APK.

Required production behavior:
1. Authenticate email/mobile + password on the backend.
2. Resolve the account role on the backend.
3. Return a short-lived authenticated session/token and role claims.
4. Never return admin passwords to the client.
5. Allow each admin to change their own password through the backend.
6. Keep an audit log for privileged actions.

The template file in this folder contains placeholders only and is not an Android runtime configuration.
