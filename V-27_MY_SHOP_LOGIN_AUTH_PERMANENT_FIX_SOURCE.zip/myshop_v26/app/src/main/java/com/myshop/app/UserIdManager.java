package com.myshop.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * Offline fallback only. Production must allocate the 4-digit ID atomically on the backend.
 */
public final class UserIdManager {
    private static final String PREFS = "myshop_users";
    private static final String KEY_USED = "used_ids";
    private static final Random RANDOM = new Random();

    private UserIdManager() {}

    public static synchronized String allocateLocalId(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> used = new HashSet<>(p.getStringSet(KEY_USED, new HashSet<>()));
        if (used.size() >= 9000) throw new IllegalStateException("No free four-digit User ID available in local fallback.");

        String id;
        do {
            id = String.format("%04d", RANDOM.nextInt(10000));
        } while (used.contains(id));

        used.add(id);
        p.edit().putStringSet(KEY_USED, used).apply();
        return id;
    }
}
