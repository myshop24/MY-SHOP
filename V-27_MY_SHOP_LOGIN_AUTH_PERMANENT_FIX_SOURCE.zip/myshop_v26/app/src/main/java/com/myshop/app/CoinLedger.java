package com.myshop.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Locale;

/**
 * Local cache/ledger shell. Production coin balances MUST be server-authoritative.
 * No user-facing API in this class can restore or arbitrarily credit a balance.
 */
public final class CoinLedger {
    private static final String PREF = "myshop_coin_cache_v1";
    private CoinLedger() {}

    public static long getCachedBalance(Context c, String userId) {
        if (userId == null || userId.trim().isEmpty()) return 0L;
        return Math.max(0L, c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getLong("balance_" + userId, 0L));
    }

    /** Only for trusted synchronization from an authorized server response. */
    public static void applyServerBalance(Context c, String userId, long serverBalance) {
        if (userId == null || userId.trim().isEmpty() || serverBalance < 0L) return;
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putLong("balance_" + userId, serverBalance).apply();
    }
}
