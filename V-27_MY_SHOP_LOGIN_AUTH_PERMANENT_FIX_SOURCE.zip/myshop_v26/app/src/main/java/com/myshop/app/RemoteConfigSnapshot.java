package com.myshop.app;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Immutable, validated view of remote configuration used by the UI. */
public final class RemoteConfigSnapshot {
    public final int schemaVersion;
    public final int maxBannersPerSection;
    public final long sliderIntervalMs;
    public final List<Banner> banners;

    private RemoteConfigSnapshot(int schemaVersion, int maxBannersPerSection,
                                 long sliderIntervalMs, List<Banner> banners) {
        this.schemaVersion = schemaVersion;
        this.maxBannersPerSection = maxBannersPerSection;
        this.sliderIntervalMs = sliderIntervalMs;
        this.banners = Collections.unmodifiableList(banners);
    }

    public static RemoteConfigSnapshot parse(String json) {
        try {
            JSONObject root = new JSONObject(json == null ? "{}" : json);
            int schema = Math.max(1, root.optInt("schemaVersion", 1));
            int max = root.optInt("maxBannersPerSection", root.optInt("maxBanners", 6));
            if (max < 1 || max > 6) max = 6;
            long interval = root.optLong("sliderIntervalMs", 3500L);
            if (interval < 1000L || interval > 60000L) interval = 3500L;

            List<Banner> list = new ArrayList<>();
            JSONArray array = root.optJSONArray("banners");
            if (array != null) {
                for (int i = 0; i < array.length() && list.size() < max; i++) {
                    JSONObject item = array.optJSONObject(i);
                    if (item == null || !item.optBoolean("enabled", true)) continue;
                    String id = item.optString("id", "banner_" + (list.size() + 1)).trim();
                    String title = item.optString("title", "MY SHOP").trim();
                    String imageUrl = item.optString("imageUrl", "").trim();
                    String linkUrl = item.optString("linkUrl", "").trim();
                    if (!imageUrl.isEmpty() && !FeatureRegistry.isSafeHttpUrl(imageUrl)) imageUrl = "";
                    if (!linkUrl.isEmpty() && !FeatureRegistry.isSafeHttpUrl(linkUrl)) linkUrl = "";
                    list.add(new Banner(id, title, imageUrl, linkUrl));
                }
            }
            return new RemoteConfigSnapshot(schema, max, interval, list);
        } catch (Exception ignored) {
            return new RemoteConfigSnapshot(1, 6, 3500L, new ArrayList<>());
        }
    }

    public static final class Banner {
        public final String id, title, imageUrl, linkUrl;
        Banner(String id, String title, String imageUrl, String linkUrl) {
            this.id = id; this.title = title; this.imageUrl = imageUrl; this.linkUrl = linkUrl;
        }
    }
}
