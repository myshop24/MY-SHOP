package com.myshop.app;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Central feature/config reader. Remote storage can later populate the same keys. */
public final class FeatureRegistry {
    private static final String PREFS = "myshop_remote_config";
    private FeatureRegistry() {}
    public static String getUrl(Context context, String key) {
        String value = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("url_" + key, "");
        return isSafeHttpUrl(value) ? value.trim() : "";
    }
    public static boolean isSafeHttpUrl(String value) {
        if (value == null) return false;
        String v = value.trim().toLowerCase();
        return v.startsWith("https://") || v.startsWith("http://");
    }
    public static List<FeatureItem> loadLocalFeatures(Context context) {
        List<FeatureItem> result = new ArrayList<>();
        try (InputStream in = context.getAssets().open("feature_config.json")) {
            byte[] data = new byte[in.available()]; int read = in.read(data); if (read <= 0) return result;
            JSONObject root = new JSONObject(new String(data, 0, read, StandardCharsets.UTF_8));
            JSONArray items = root.optJSONArray("features"); if (items == null) return result;
            for (int i = 0; i < items.length(); i++) {
                Object raw = items.opt(i);
                if (raw instanceof JSONObject) {
                    JSONObject o = (JSONObject) raw; String id=o.optString("id","").trim(); String name=o.optString("name","").trim();
                    if (!id.isEmpty() && !name.isEmpty()) result.add(new FeatureItem(id,name));
                } else if (raw instanceof String) {
                    String id=((String)raw).trim(); if (!id.isEmpty()) result.add(new FeatureItem(id,id));
                }
            }
        } catch (Exception ignored) {}
        return result;
    }
    public static final class FeatureItem { public final String id; public final String name; public FeatureItem(String id,String name){this.id=id;this.name=name;} }
}
