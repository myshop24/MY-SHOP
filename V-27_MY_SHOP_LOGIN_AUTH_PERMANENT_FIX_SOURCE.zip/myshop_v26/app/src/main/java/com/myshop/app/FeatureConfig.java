package com.myshop.app;

import android.content.Context;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/** Reads the safe local fallback config. A future backend adapter can replace the source without changing UI contracts. */
public final class FeatureConfig {
    private FeatureConfig() {}

    public static String load(Context context) {
        try (InputStream in = context.getAssets().open("feature_config.json")) {
            byte[] data = new byte[in.available()];
            int read = in.read(data);
            return new String(data, 0, read, StandardCharsets.UTF_8);
        } catch (Exception ignored) {
            return "{}";
        }
    }
}
