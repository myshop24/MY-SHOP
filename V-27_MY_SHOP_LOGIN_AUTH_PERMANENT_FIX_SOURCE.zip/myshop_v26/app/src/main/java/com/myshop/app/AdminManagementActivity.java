package com.myshop.app;

import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * Management screen opened from the normal dashboard. It is not a second home/dashboard.
 * Production writes must be authorized and persisted by the backend.
 */
public class AdminManagementActivity extends AppCompatActivity {
    private boolean moderatorOnly;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        moderatorOnly = getIntent().getBooleanExtra("moderator_only", false);
        if (moderatorOnly && !SessionManager.isModerator(this)) {
            finish();
            return;
        }
        if (!moderatorOnly && !SessionManager.isAdmin(this)) {
            finish();
            return;
        }
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 30, 24, 24);
        root.setBackgroundColor(getColor(R.color.myshop_bg));

        TextView title = new TextView(this);
        title.setText(moderatorOnly ? "Moderator Controls" : "Admin Controls");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, 80));

        String[] actions = moderatorOnly
                ? new String[]{"Ban User ID", "Kick User", "Close Live", "Back"}
                : new String[]{"Banner Management", "Breaking News", "User Management", "Moderator Management",
                                "Payment Methods", "Remote Links", "Feature Buttons", "Back"};

        for (String action : actions) {
            Button b = new Button(this);
            b.setText(action);
            b.setOnClickListener(v -> {
                if ("Back".equals(action)) { finish(); return; }
                Toast.makeText(this, action + " — backend authorization/storage required", Toast.LENGTH_LONG).show();
            });
            root.addView(b, new LinearLayout.LayoutParams(-1, 58));
        }
        setContentView(root);
    }
}
