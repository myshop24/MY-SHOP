package com.myshop.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Safe remote-config foundation. The backend endpoint is configured outside the UI.
 * Downloaded JSON is validated before replacing the cached configuration.
 * UI continues using the last known good config if the network is unavailable.
 */
public final class RemoteConfigManager {
    private static final String PREFS = "myshop_remote_config_v11";
    private static final String KEY_JSON = "validated_json";
    private static final String KEY_ENDPOINT = "endpoint";
    private static final int TIMEOUT_MS = 8000;
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    private RemoteConfigManager() {}

    public interface Callback { void onComplete(boolean success); }

    public static void setEndpoint(Context context, String endpoint) {
        if (endpoint == null || !FeatureRegistry.isSafeHttpUrl(endpoint)) return;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY_ENDPOINT, endpoint.trim()).apply();
    }

    public static String getEndpoint(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_ENDPOINT, "");
    }

    public static String getCachedConfig(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_JSON, "{}");
    }

    public static void refresh(Context context, Callback callback) {
        final Context app = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            boolean success = false;
            String endpoint = getEndpoint(app);
            if (FeatureRegistry.isSafeHttpUrl(endpoint)) {
                HttpURLConnection connection = null;
                try {
                    connection = (HttpURLConnection) new URL(endpoint).openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(TIMEOUT_MS);
                    connection.setReadTimeout(TIMEOUT_MS);
                    connection.setRequestProperty("Accept", "application/json");
                    if (connection.getResponseCode() >= 200 && connection.getResponseCode() < 300) {
                        try (InputStream in = connection.getInputStream()) {
                            byte[] bytes = readAll(in);
                            String json = new String(bytes, StandardCharsets.UTF_8);
                            if (validateConfig(json)) {
                                app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                                        .edit().putString(KEY_JSON, json).apply();
                                success = true;
                            }
                        }
                    }
                } catch (Exception ignored) {
                    // Keep the last known-good cache.
                } finally {
                    if (connection != null) connection.disconnect();
                }
            }
            final boolean result = success;
            if (callback != null) new android.os.Handler(app.getMainLooper()).post(() -> callback.onComplete(result));
        });
    }

    public static boolean validateConfig(String json) {
        if (json == null || json.trim().isEmpty()) return false;
        try {
            JSONObject root = new JSONObject(json);
            if (root.has("schemaVersion") && root.optInt("schemaVersion", 0) < 1) return false;
            if (root.has("maxBannersPerSection") && root.optInt("maxBannersPerSection", 0) > 6) return false;
            JSONArray features = root.optJSONArray("features");
            if (features != null) {
                for (int i = 0; i < features.length(); i++) {
                    JSONObject item = features.optJSONObject(i);
                    if (item == null || item.optString("id", item.optString("key", "")).trim().isEmpty()) return false;
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        int n;
        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        return out.toByteArray();
    }
}
