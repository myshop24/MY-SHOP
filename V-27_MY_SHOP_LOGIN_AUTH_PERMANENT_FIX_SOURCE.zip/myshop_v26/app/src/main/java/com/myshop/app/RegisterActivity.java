package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** Shared account creation shell. Backend must perform the real registration + ID allocation. */
public class RegisterActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        findViewById(R.id.backLoginButton).setOnClickListener(v -> finish());
        findViewById(R.id.createButton).setOnClickListener(v -> createAccount());
    }

    private void createAccount() {
        EditText name = findViewById(R.id.fullName);
        EditText email = findViewById(R.id.email);
        EditText mobile = findViewById(R.id.mobile);
        EditText pass = findViewById(R.id.password);
        EditText confirm = findViewById(R.id.confirmPassword);
        CheckBox terms = findViewById(R.id.terms);

        String nameValue = name.getText().toString().trim();
        String emailValue = email.getText().toString().trim();
        String mobileValue = mobile.getText().toString().trim();
        String password = pass.getText().toString();

        if (nameValue.isEmpty()) {
            Toast.makeText(this, "Full Name is required.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (emailValue.isEmpty() && mobileValue.isEmpty()) {
            Toast.makeText(this, "Email অথবা Mobile Number যেকোনো একটি দিন।", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!emailValue.isEmpty() && !Patterns.EMAIL_ADDRESS.matcher(emailValue).matches()) {
            Toast.makeText(this, "Enter a valid email address.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (password.length() < 6 || !password.equals(confirm.getText().toString())) {
            Toast.makeText(this, "Use 6+ characters and make both passwords match.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!terms.isChecked()) {
            Toast.makeText(this, "Please accept the Terms & Conditions.", Toast.LENGTH_SHORT).show();
            return;
        }

        String id = UserIdManager.allocateLocalId(this);
        boolean created = AccountStore.create(this, id, nameValue, emailValue, mobileValue, password);
        if (!created) {
            Toast.makeText(this, "এই Email/Mobile দিয়ে Account আগে থেকেই আছে।", Toast.LENGTH_LONG).show();
            return;
        }

        SessionManager.setSession(this, Role.USER, id);
        SessionManager.saveProfile(this, nameValue, emailValue, mobileValue);

        Toast.makeText(this, "Account created. Your User ID: " + id, Toast.LENGTH_LONG).show();
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }
}
