package com.myshop.app;

public enum Role {
    GUEST,
    USER,
    MODERATOR,
    ADMIN
}
