# MY SHOP V-18 Change Log

- Version code: 18
- Version name: 2.7.0
- Kept the V-17 feature architecture intact.
- Added a CI toolchain verification step before Android lint/build.
- Updated CI artifact names and validation to V-18.
- Added stricter V-18 project/version/SDK/security checks.
- Preserved backend-authoritative roles and remote configuration architecture.
- No admin credentials are embedded in the Android source.
