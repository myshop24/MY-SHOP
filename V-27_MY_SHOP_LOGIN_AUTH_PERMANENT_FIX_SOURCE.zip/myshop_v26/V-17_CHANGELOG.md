# V-17 MY SHOP — Release Candidate Build Hardening

- Version Code: 17
- Version Name: 2.6.0
- Renamed the project package folder to the V-17 project name.
- Added explicit Android SDK setup to CI.
- CI installs Android 35 platform and Build Tools 35.0.0 before building.
- Added `lintDebug` before APK compilation to catch resource/code issues early.
- Kept Debug and unsigned Release APK builds.
- Kept APK ZIP-integrity and SHA-256 checks.
- Kept optional signed-release flow using GitHub Secrets only.
- Added V-17 validation with version consistency and credential-leak checks.
- Preserved V-16 functionality; V-16 is not overwritten.
