# MY SHOP V-10 Changelog

## Focus
Feature-button wiring and configuration integrity.

## Changes
- Fixed the local feature configuration schema so every feature has an explicit stable `id` and display `name`.
- Made `FeatureRegistry` compatible with both object-style and legacy string-style feature lists.
- Replaced title-derived URL keys with explicit stable feature keys so renamed UI labels do not break remote links.
- Kept remote URL validation restricted to HTTP/HTTPS.
- Preserved the same Main Dashboard and role-based Admin/Moderator controls.
- Updated Android version to `10 / 1.9.0`.
- Updated CI artifact/build labels to V-10.

## Verification note
This environment does not contain the Android SDK/Gradle installation required for a local APK compile. Static JSON/XML/Java checks and archive integrity checks are performed here; GitHub Actions remains the authoritative APK build check.
