# MY SHOP V-25 Development Notes

Base: V-24 Login Crash Fix, preserving all earlier version artifacts.

Priority order:
1. App must not close on Login failure.
2. Login success must transition safely to Main Dashboard.
3. Account identity/User ID must persist across updates.
4. Email and mobile must both resolve to the same account when both are registered.
5. Coin/balance must remain server-authoritative; user cannot restore or self-credit.
6. Backup/restore is Main Admin only.
7. Do not delete or overwrite earlier version source.
8. Build/test must verify the entire package, not just one changed screen.
