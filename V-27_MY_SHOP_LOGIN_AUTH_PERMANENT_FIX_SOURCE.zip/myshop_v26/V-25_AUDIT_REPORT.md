# MY SHOP V-25 — Audit & Integrity Report

## Verified in source package
- Login crash path hardened; Login errors are caught and shown instead of silently terminating.
- Email OR Mobile authentication is supported.
- A single account keeps one permanent 4-digit User ID locally; email/mobile aliases point to the same ID.
- Password storage upgraded to salted PBKDF2-HMAC-SHA256 with legacy SHA-256 migration on successful login.
- Existing V-24 account records have a migration path; they are not intentionally recreated with a new ID.
- MainActivity already has startup fallback protection.
- Admin/Moderator management screens are permission-gated by role state.
- Coin cache is server-response-only; there is no user-facing arbitrary credit/restore API in the app source.
- Backup/restore guard is Admin-only.
- Backend contract/schema files are preserved.
- GitHub Actions workflow was corrected to build the V-25 source/version instead of expecting V-22/version 22.
- Old V-22/V-23/V-24 source files and changelogs remain in the archive as historical references; they are not deleted.

## Not falsely marked complete
The following require a real backend/server and therefore are NOT claimed as fully production-ready by this ZIP:
- Server-authoritative authentication and role assignment.
- Real Main Admin account provisioning.
- Maximum-five Moderator database and permission persistence.
- Authoritative coin ledger, purchase, reward and cash-out processing.
- Admin-only encrypted backup snapshots and server restore.
- Real social feed, live streaming, chat, gallery uploads, TV feeds and content management.
- Persistent cloud media storage.

These are represented by the preserved backend contracts and security boundaries so they can be implemented without replacing the account identity model.

## Critical integrity rule
Never reset/reseed the user database during an APK update. Never generate a replacement User ID for an existing account. Never restore a user-controlled backup into authoritative financial data.
