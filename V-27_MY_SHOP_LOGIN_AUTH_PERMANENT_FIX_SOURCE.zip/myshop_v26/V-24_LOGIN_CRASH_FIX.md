# MY SHOP V-24 — Login Crash & Account Persistence Fix

Base: V-23_MY_SHOP_DEVELOPMENT_BASE

Changes:
- Login now authenticates against the locally created prototype account record instead of accepting any credentials.
- Password is stored only as a SHA-256 hash in the prototype account store; production must move authoritative authentication to the backend.
- Registration stores a stable account record keyed by Email or Mobile and keeps the allocated 4-digit User ID.
- Login/startup flow is guarded so malformed input or local errors do not silently terminate the app.
- MainActivity launch uses a clean task transition to prevent Activity-stack loops.
- Session profile data is stored consistently through SessionManager.
- No Admin privilege is granted by local email/phone matching; server-side role resolution remains required.
- Existing V-23 source is preserved separately as the prior checkpoint.

Validation limitation: this environment has no Gradle executable, so APK compilation could not be performed here.
