# MY SHOP V-18 Release Notes

V-18 is a build-readiness/stability increment over V-17. It does not replace V-17.

The CI pipeline installs Android SDK 35, uses JDK 17 and Gradle 8.9, runs validation and lint, builds debug and unsigned release APKs, verifies the APK archives, and publishes checksums/artifacts.

A signed release remains optional and requires GitHub Secrets; private signing material is not stored in this repository.
