# MY SHOP V-23 Development Notes

Base: V-22_MY_SHOP_RUNTIME_FIXED_SOURCE

Implemented in this milestone:
- LoginActivity is the launcher, so the app opens at Login as specified.
- Existing logged-in sessions can route to Main Dashboard.
- Registration now requires Full Name and Email OR Mobile (not both).
- Offline fallback User ID allocation uses unique random 4-digit IDs; production allocation remains backend-owned.
- Main Dashboard bottom navigation is exactly Home / Store / Live / Chat / Profile.
- Three-line menu shows Profile & Settings, Logout, and Language for logged-in users.
- Account screen shows saved profile identifier/contact and returns to Login on logout.
- No admin credentials are embedded in the APK.

Still backend-dependent and intentionally not faked:
- Real authentication
- Server-generated 4-digit ID
- Server-side Admin role detection for the three designated accounts
- Moderator assignment/permissions
- Persistent content management, coin/cashout, live, feed, chat, TV, gallery, links
- Real-time live streaming

Validation note: this environment has no Gradle executable, so APK compilation was not performed here. The source was structurally edited only after preserving the V-22 base.
