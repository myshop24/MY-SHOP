# V-21 MY SHOP RELEASE NOTES

V-21 is the runtime-corrected test build after V-20 installed successfully but closed immediately on launch.

Android identity:
- applicationId: com.myshop.app
- versionCode: 21
- versionName: 2.10.0

Runtime fix:
- MainActivity extends AppCompatActivity.
- The application theme now correctly inherits from Theme.AppCompat.Light.NoActionBar.
- This fixes the startup crash caused by using a platform Theme.Material.Light.NoActionBar with AppCompatActivity.

V-20 is preserved separately.
