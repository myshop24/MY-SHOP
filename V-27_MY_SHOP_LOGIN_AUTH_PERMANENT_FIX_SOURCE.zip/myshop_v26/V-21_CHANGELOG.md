# V-21 MY SHOP CHANGELOG

- Promoted V-20 to V-21 as the runtime-corrected release.
- Fixed the launch crash caused by MainActivity extending AppCompatActivity while the application used a platform Android theme.
- Changed the application theme parent to Theme.AppCompat.Light.NoActionBar.
- Changed Android versionCode from 20 to 21.
- Changed Android versionName from 2.9.0 to 2.10.0.
- Preserved the V-20 SearchBox fix, runtime hardening, package ID, features, assets, and project structure.
- Added a GitHub Actions static check that prevents a non-AppCompat theme from reaching the build.
- V-20 remains preserved as a backup and is not overwritten.
