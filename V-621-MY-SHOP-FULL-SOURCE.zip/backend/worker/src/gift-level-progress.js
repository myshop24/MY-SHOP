// These statements belong to the SAME transaction as the gift debit/event.
export function giftProgressStatements(DB,{currency,receiverId,senderId,units,official,reference,txType='GIFT'}) {
 if(!['GIFT','TRANSFER'].includes(txType))throw Error('INVALID_PROGRESS_TYPE');
 if(txType==='GIFT'){
  if(!Number.isSafeInteger(units)||units<=0)return [];
  const cur=currency==='GOLD'?'GOLD':'COIN',threshold=cur==='GOLD'?1000:100000,office=official?1:0,delta=`(CAST((units+?)/${threshold} AS INTEGER)-CAST(units/${threshold} AS INTEGER))`;
  return [DB.prepare(`INSERT OR IGNORE INTO myshop_gift_star_units621(user_id,currency,official,units) SELECT ?,?,?,COALESCE(SUM(units),0) FROM myshop_star_level_ledger WHERE receiver_id=? AND currency=? AND official=? AND tx_type='GIFT'`).bind(receiverId,cur,office,receiverId,cur,office),
  DB.prepare(`INSERT INTO myshop_star_level_ledger(tx_type,currency,sender_id,receiver_id,units,stars,level_added,official,reference) SELECT 'GIFT',?,?,user_id,?,${delta},0,official,? FROM myshop_gift_star_units621 WHERE user_id=? AND currency=? AND official=?`).bind(cur,senderId,units,units,reference,receiverId,cur,office),
  DB.prepare(`UPDATE myshop_user_progress SET stars=stars+COALESCE((SELECT ${delta} FROM myshop_gift_star_units621 WHERE user_id=? AND currency=? AND official=?),0),updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(units,receiverId,cur,office,receiverId),
  DB.prepare(`UPDATE myshop_gift_star_units621 SET units=units+? WHERE user_id=? AND currency=? AND official=?`).bind(units,receiverId,cur,office)];
 } // Gift Stars remain supported, but recharge Level/counters never change.

 official=['0001','0002','0003'].includes(String(senderId));
 if(!Number.isSafeInteger(units)||units<=0)return [];
 const cur=currency==='GOLD'?'GOLD':'COIN';
 const col=official?(cur==='GOLD'?'official_gold_units':'official_coin_units'):(cur==='GOLD'?'normal_gold_units':'normal_coin_units');
 const threshold=cur==='GOLD'?1000:100000;
 const delta=`(CAST((${col}+?)/${threshold} AS INTEGER)-CAST(${col}/${threshold} AS INTEGER))`;
 const multiplier=['0001','0002','0003'].includes(String(receiverId))?0:official?2:1;
 return [DB.prepare(`INSERT INTO myshop_star_level_ledger(tx_type,currency,sender_id,receiver_id,units,stars,level_added,official,reference) SELECT ?,?,?,user_id,?,${delta},${delta}*?, ?,? FROM myshop_user_progress WHERE user_id=?`).bind(txType,cur,senderId,units,units,units,multiplier,official?1:0,reference,receiverId),
 DB.prepare(`UPDATE myshop_user_progress SET stars=stars+${delta},level=level+${delta}*?,${col}=${col}+?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?`).bind(units,units,multiplier,units,receiverId)];
}
