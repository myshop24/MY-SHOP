import {schemaOnce} from './schema-once.js';
export function rechargeSchema621(env){return schemaOnce(env.DB,'recharge_policy621',()=>env.DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_recharge_policy621(user_id TEXT PRIMARY KEY,previous_progress TEXT NOT NULL,applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run());}
// One-time derived progress repair. Wallets, immutable account IDs and original ledgers are never altered.
export async function reconcileRecharge621(env,userId){
 await rechargeSchema621(env);
 const row=await env.DB.prepare('SELECT * FROM myshop_user_progress WHERE user_id=?').bind(userId).first();
 const done=await env.DB.prepare('SELECT 1 done FROM myshop_recharge_policy621 WHERE user_id=?').bind(userId).first();
 if(done)return row;
 let totals={normal_coin_units:0,normal_gold_units:0,official_coin_units:0,official_gold_units:0};
 for(const [currency,table] of [['COIN','myshop_coin_transactions'],['GOLD','myshop_gold_transactions']]){
  const r=await env.DB.prepare(`SELECT COALESCE(SUM(CASE WHEN amount>0 AND kind IN ('PURCHASE_APPROVED','PAID_PURCHASE') ${currency==='COIN'?"AND status='COMPLETED'":''} THEN amount WHEN amount>0 AND kind='STORE_GRANT' AND json_valid(metadata) AND COALESCE(json_extract(metadata,'$.source'),'') NOT IN ('ADMIN','ADMIN_GRANT') THEN amount ELSE 0 END),0) normal,COALESCE(SUM(CASE WHEN amount>0 AND kind='ADMIN_GRANT' THEN amount ELSE 0 END),0) admin,COALESCE(SUM(CASE WHEN amount>0 AND kind='STORE_GRANT' AND json_valid(metadata) AND json_extract(metadata,'$.source') IN ('ADMIN','ADMIN_GRANT') THEN amount ELSE 0 END),0) storeOffice FROM ${table} WHERE user_id=?`).bind(userId).first();
  const v=await env.DB.prepare(`SELECT COALESCE(SUM(CASE WHEN tx_type='TRANSFER' AND sender_id NOT IN ('0001','0002','0003') THEN gross_amount ELSE 0 END),0) normal,COALESCE(SUM(CASE WHEN tx_type='ADMIN_GRANT' THEN gross_amount ELSE 0 END),0) admin,COALESCE(SUM(CASE WHEN tx_type='TRANSFER' AND sender_id IN ('0001','0002','0003') THEN gross_amount ELSE 0 END),0) officeTransfer FROM myshop_value_ledger WHERE receiver_id=? AND currency=? AND status='COMPLETED'`).bind(userId,currency).first();
  const suffix=currency==='GOLD'?'gold_units':'coin_units';totals['normal_'+suffix]=Math.max(0,Number(r?.normal||0))+Math.max(0,Number(v?.normal||0));totals['official_'+suffix]=Math.max(Number(r?.admin||0),Number(v?.admin||0))+Math.max(0,Number(r?.storeOffice||0))+Math.max(0,Number(v?.officeTransfer||0));
 }
 const nc=totals.normal_coin_units,ng=totals.normal_gold_units,oc=totals.official_coin_units,og=totals.official_gold_units;
 const stars=Math.max(Number(row?.stars||0),Math.floor(nc/100000)+Math.floor(ng/1000)+Math.floor(oc/100000)+Math.floor(og/1000)),level=['0001','0002','0003'].includes(userId)?0:Math.floor(nc/100000)+Math.floor(ng/1000)+2*Math.floor(oc/100000)+2*Math.floor(og/1000);
 // Update guarded by the marker being absent; insert marker LAST in same transaction.
 await env.DB.batch([
 env.DB.prepare(`INSERT OR IGNORE INTO myshop_user_progress(user_id) VALUES(?)`).bind(userId),
 env.DB.prepare(`UPDATE myshop_user_progress SET stars=?,level=?,normal_coin_units=?,normal_gold_units=?,official_coin_units=?,official_gold_units=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND NOT EXISTS(SELECT 1 FROM myshop_recharge_policy621 WHERE user_id=?)`).bind(stars,level,nc,ng,oc,og,userId,userId),
 env.DB.prepare(`INSERT OR IGNORE INTO myshop_recharge_policy621(user_id,previous_progress) VALUES(?,?)`).bind(userId,JSON.stringify(row||{}))]);
 return env.DB.prepare('SELECT * FROM myshop_user_progress WHERE user_id=?').bind(userId).first();
}
export function remaining621(pr){const nc=Number(pr?.normal_coin_units||0),ng=Number(pr?.normal_gold_units||0),oc=Number(pr?.official_coin_units||0),og=Number(pr?.official_gold_units||0);return {level:Number(pr?.level||0),coinRemaining:100000-nc%100000,goldRemaining:1000-ng%1000,officeCoinRemaining:100000-oc%100000,officeGoldRemaining:1000-og%1000,officeMultiplier:2};}
