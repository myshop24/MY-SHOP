package com.myshop.app;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.media.MediaPlayer;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Build;
import android.app.PictureInPictureParams;
import android.app.Dialog;
import android.util.Rational;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.HorizontalScrollView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.TimeZone;

/**
 * myshop V-350 Premium Audio Live Room with light right-action spacing and bottom safe-area protection.
 * V-447 visual host separation: Host and Main Guest are separate; 10 normal guest seats are always shown as 5 + 5.
 * The bundled Guitar Blue wallpaper is the safe default while Admin themes
 * can override it remotely without changing the Dashboard.
 */
public class AudioLiveRoomActivity extends AppCompatActivity {
    private final java.util.HashSet<String> shownPremiumEntrances=new java.util.HashSet<>();
    private final Handler handler = new Handler();
    private boolean host;
    private boolean hostStarted;
    private volatile boolean endLiveInProgress = false;
    private volatile boolean roomEnded = false;
    private boolean localMicOn = true;
    private boolean audienceAudioOn = true;
    private boolean roomAdmin = false;
    private JSONObject livePermissions=new JSONObject();
    private boolean livePower(String key){if(host||SessionManager.isAdmin(this))return true;return livePermissions.optBoolean(key,false);}
    private boolean canSuggestCall = false;
    private boolean canPinComments = false;
    private boolean listenOnly = false;
    private String hostId;
    private String specialGuestId = "";
    private String myRole = "AUDIENCE";
    private long startedAtMs = 0L;
    private String activeSessionId = "";
    private long serverElapsedSec = 0L;
    private long serverElapsedSyncMs = 0L;
    private boolean endedSummaryShown = false;
    private boolean commentSending = false;
    private String highlightRequestId="",highlightRequestText="";
    private float liveCommentFontSize=15.2f; private JSONObject globalCommentStyle=new JSONObject(); private final java.util.HashMap<String,JSONObject> commentPresets=new java.util.HashMap<>(); private final java.util.HashMap<String,JSONObject> commentAssignments=new java.util.HashMap<>();
    private final Map<String,String> pendingComments = new LinkedHashMap<>();
    private final Set<String> shownMilestones = new HashSet<>();
    private long lastEntryEventId = 0L;
    private long lastGiftEventId = 0L;
    private final Set<Long> renderedGiftEventIds = new HashSet<>();private final Set<Long> renderedGiftEffectIds=new HashSet<>();
    private final Set<Long> renderedCommentIds = new HashSet<>();
    private final Set<Long> renderedRoomEventIds = new HashSet<>();
    private final Set<Long> renderedHighlightCommentIds = new HashSet<>();
    private int shareCount = 0;
    private long reactCount = 0L;
    private long reactionAckAt=0L;
    private long voteCount = 0L;
    private ImageView wallpaper;
    private LinearLayout hostArea, audienceRow, specialArea, seats, requests, commentsList;
    private ScrollView commentScroll;
    private TextView viewers, status, syncState, durationView, roomTitle, roomTopic, pinnedView, shareView, reactView, reactCountLabel, micMutedMark, premiumStrip, welcomeView, productView, pkView, topStatsView;
    private FrameLayout micControl;
    private final long roomAnimationEpoch=System.currentTimeMillis();
    private Button sendButton;
    private android.app.Dialog commentComposerDialog;
    private String liveCommentDraft="";
    private EditText activeCommentInput;
    private TextView activeCommentHighlight;
    private String currentLiveName = "Host";
    private final Set<Integer> lockedSeats = new HashSet<>();
    private JSONArray currentViewerProfiles = new JSONArray();
    private JSONArray currentTopSupporters = new JSONArray();
    private long currentPollId=0L,lastPromptedPollId=0L;
    private JSONObject currentHostStats = new JSONObject();
    private JSONObject cachedHostProfile = new JSONObject();
    private HorizontalScrollView audienceScroll;
    private String audienceVisualSignature="";
    private TextView onlineCountView, topGiftView, topCoinView, topGoldView, topStarView;
    private JSONArray currentSeats = new JSONArray();
    private int currentSeatNo = 0;
    private final Map<String,Bitmap> avatarCache = new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.Set<String> avatarLoading=java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final Map<String,java.util.List<java.lang.ref.WeakReference<ImageView>>> avatarTargets=new java.util.HashMap<>();
    private final Map<String,Long> avatarRetryAfter=new java.util.concurrent.ConcurrentHashMap<>();
    private final java.util.concurrent.ExecutorService avatarPool=java.util.concurrent.Executors.newFixedThreadPool(3);
    private boolean avatarReady(String url){if(url==null||url.trim().isEmpty())return true;if(avatarCache.containsKey(url))return true;fetchAvatar(url);return false;}
    private void fetchAvatar(String url){if(isFinishing()||isDestroyed()||avatarRetryAfter.getOrDefault(url,0L)>System.currentTimeMillis()||!avatarLoading.add(url))return;avatarPool.execute(()->{Bitmap result=null;java.net.HttpURLConnection conn=null;try{conn=(java.net.HttpURLConnection)new URL(url).openConnection();conn.setConnectTimeout(5000);conn.setReadTimeout(7000);try(java.io.InputStream in=conn.getInputStream()){BitmapFactory.Options options=new BitmapFactory.Options();options.inSampleSize=2;result=BitmapFactory.decodeStream(in,null,options);}}catch(Exception ignored){}finally{if(conn!=null)conn.disconnect();}if(result!=null){avatarCache.put(url,result);avatarRetryAfter.remove(url);if(avatarCache.size()>100){String first=avatarCache.keySet().iterator().next();if(!first.equals(url))avatarCache.remove(first);}}else avatarRetryAfter.put(url,System.currentTimeMillis()+15000);avatarLoading.remove(url);runOnUiThread(()->{java.util.List<java.lang.ref.WeakReference<ImageView>> targets=avatarTargets.remove(url);Bitmap bm=avatarCache.get(url);if(bm!=null&&targets!=null)for(java.lang.ref.WeakReference<ImageView> ref:targets){ImageView target=ref.get();if(target!=null&&url.equals(target.getTag()))target.setImageBitmap(bm);}});});}

    private JSONArray currentRequests = new JSONArray();
    private JSONArray currentCallSuggestions = new JSONArray();
    private int currentViewerCount = 0;
    private int currentPeakViewers = 0;
    private int currentTotalListeners = 0;
    private String lastInviteNotice = "";
    private String lastRequestNotice = "";
    private boolean inviteDialogOpen = false;
    private boolean requestDialogOpen = false;
    private String lastCommentsSignature = "";
    private int highlightPrice = 1000;
    
    private boolean highlightSelected = false;
    private long lastHighlightId = 0L;
    private TextView micButton, musicButton, speakerActionButton;
    private boolean hostFollowing=false,musicPlaying=false,musicPaused=false;
    private float joinFontSize=18.0f;
    private int joinTextColor=Color.WHITE;
    private ObjectAnimator joinPulseAlpha, joinPulseX, joinPulseY;
    private LinearLayout requestNoticeBar;
    private JSONObject cachedGiftCatalog;
    private long cachedGiftCatalogAt = 0L;
    private volatile boolean giftCatalogFetchInFlight = false;
    private AlertDialog giftLoadingDialog;
    private Runnable giftCatalogChanged;
    private AlertDialog giftStoreDialog;
    private String giftReceiverId="",giftReceiverName="";
    private volatile boolean giftPollInFlight = false;
    private volatile boolean refreshInFlight = false;
    private boolean visitReady=false;
    private volatile boolean realtimeInFlight = false;
    private int realtimeFailures = 0;
    private int realtimeRevision = 0;
    private long lastRealtimeCommentId = 0L;
    private long lastRealtimeHighlightId = 0L;
    private long lastRealtimeFallbackMs = 0L;
    private long lastGiftRecoveryPollMs = 0L;
    private String myRequestStatus = "NONE";
    private boolean joinRequestInFlight=false;
    private int pendingRequestCount = 0;
    private int myLevel = 0;
    private volatile boolean localSpeaking = false;
    private volatile boolean voiceMonitorRunning = false;
    private android.media.AudioRecord voiceRecorder;
    private Thread voiceThread;
    private long lastVoiceAboveMs = 0L;
    private boolean micPermissionAsked = false;
    private AgoraRtcManager rtcManager;
    private volatile String rtcDiagnosticStatus="RTC waiting";
    private volatile int activeRtcSpeakerUid=-1;private volatile String rtcNetworkQuality="GOOD";
    private volatile long activeRtcSpeakerAt=0L;
    private boolean rtcJoinRequested=false;
    private boolean rtcJoined=false;
    private long lastRtcAudioUiAt=0L;
    private String rtcRole="";
    private String lastAdminInviteKey="";
    private boolean adminInviteDialogOpen=false;
    private final java.util.ArrayDeque<JSONObject[]> giftEffectQueue=new java.util.ArrayDeque<>();
    private boolean giftEffectPlaying=false;
    private View activeGiftOverlay;

    // V-352: expensive full D1 room snapshots are no longer polled sub-second.
    // Realtime comments/gifts/control-dirty signals use the Durable Object hub.
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (roomEnded || endLiveInProgress) return;
            if (hostStarted || !host) refresh();
            // V-392 safety snapshot: realtime remains primary, but a short full-state fallback
            // prevents seats/requests/gifts from staying stale if a hub signal is missed.
            if (!roomEnded && !endLiveInProgress) handler.postDelayed(this, realtimeFailures > 0 ? 5000L : 15000L);
        }
    };

    private final Runnable presenceTick = new Runnable() {
        @Override public void run() {
            if (roomEnded || endLiveInProgress) return;
            if (hostStarted || !host) {
                if(!rtcJoined&&!rtcJoinRequested)requestRtcToken(false);
                if (host) BackendClient.liveHostHeartbeat(token(), activeSessionId, new Silent());
                else BackendClient.liveViewer(token(), hostId, true, new Silent());
            }
            if (!roomEnded && !endLiveInProgress) handler.postDelayed(this, 6500L);
        }
    };

    private String lastParticipantState="";
    private long lastParticipantSentAt=0L;
    private boolean participantStateInFlight=false;
    private final Runnable participantTick = new Runnable() {
        @Override public void run() {
            if (roomEnded || endLiveInProgress) return;
            if (hostStarted || !host) {
                if (host || "SPEAKER".equals(myRole)) {
                    final String state=activeSessionId+":"+myRole+":"+localMicOn+":"+localSpeaking+":"+networkQuality();
                    long now=System.currentTimeMillis();
                    if(!participantStateInFlight && (!state.equals(lastParticipantState)||now-lastParticipantSentAt>=15000L)){
                        participantStateInFlight=true;
                        BackendClient.liveParticipantState(token(),hostId,localMicOn,localSpeaking,networkQuality(),new BackendClient.Callback(){
                            public void onSuccess(JSONObject d){runOnUiThread(()->{participantStateInFlight=false;lastParticipantState=state;lastParticipantSentAt=System.currentTimeMillis();});}
                            public void onError(String m){runOnUiThread(()->{participantStateInFlight=false;});}
                        });
                    }
                }
            }
            if (!roomEnded && !endLiveInProgress) handler.postDelayed(this, 1500L);
        }
    };

    private final Runnable durationTick = new Runnable() {
        @Override public void run() {
            if (durationView != null && !activeSessionId.isEmpty()) {
                long sec = Math.max(0, serverElapsedSec + (System.currentTimeMillis() - serverElapsedSyncMs) / 1000L);
                durationView.setText("● "+hhmmss(sec));
            }
            handler.postDelayed(this, 1000);
        }
    };

    private final Runnable realtimeTick = new Runnable() {
        @Override public void run() {
            if (roomEnded || endLiveInProgress) return;
            if ((host||visitReady) && !activeSessionId.isEmpty() && !realtimeInFlight) {
                realtimeInFlight = true;
                final String expectedSession = activeSessionId;
                final int knownRevision = realtimeRevision;
                BackendClient.liveRealtime(token(), hostId, expectedSession, lastRealtimeCommentId, lastRealtimeHighlightId, lastGiftEventId, knownRevision, new BackendClient.Callback(){
                    public void onSuccess(JSONObject d){runOnUiThread(()->{
                        realtimeInFlight=false;
                        if(roomEnded||!expectedSession.equals(activeSessionId))return;
                        realtimeFailures=0;
                        String sid=d.optString("sessionId","");
                        if(!sid.isEmpty()&&!sid.equals(activeSessionId))return;
                        JSONArray cs=d.optJSONArray("comments"),hs=d.optJSONArray("highlights"),gs=d.optJSONArray("gifts");
                        if(cs!=null){for(int i=0;i<cs.length();i++){JSONObject c=cs.optJSONObject(i);if(c!=null)lastRealtimeCommentId=Math.max(lastRealtimeCommentId,c.optLong("id",0));}}
                        if(hs!=null){for(int i=0;i<hs.length();i++){JSONObject h=hs.optJSONObject(i);if(h!=null)lastRealtimeHighlightId=Math.max(lastRealtimeHighlightId,h.optLong("id",0));}}
                        renderComments(cs,null,hs);
                        renderGiftEvents(gs);
                        int revision=Math.max(0,d.optInt("revision",knownRevision));
                        boolean stateDirty=d.optBoolean("changed",false)&&revision>realtimeRevision;
                        realtimeRevision=revision;
                        if(stateDirty && System.currentTimeMillis()-lastRealtimeFallbackMs>250L){
                            lastRealtimeFallbackMs=System.currentTimeMillis();
                            refresh();
                        }
                    });}
                    public void onError(String m){runOnUiThread(()->{
                        realtimeInFlight=false;
                        realtimeFailures++;
                        long now=System.currentTimeMillis();
                        // V-392: recover on the first realtime miss. A room-state refresh renews the
                        // hub ticket and the gift poll recovers any event delivered while realtime was down.
                        if(realtimeFailures>=1 && now-lastRealtimeFallbackMs>5000L){
                            lastRealtimeFallbackMs=now;
                            refresh();
                            if(!giftPollInFlight){
                                giftPollInFlight=true;
                                BackendClient.liveGiftEvents(token(),hostId,lastGiftEventId,new BackendClient.Callback(){
                                    public void onSuccess(JSONObject x){runOnUiThread(()->{giftPollInFlight=false;renderGiftEvents(x.optJSONArray("events"));});}
                                    public void onError(String e){giftPollInFlight=false;}
                                });
                            }
                        }
                    });}
                });
            }
            long now=System.currentTimeMillis();
            // V-394: realtime hub is primary, but every participant also performs a tiny
            // event-id based recovery poll. This removes the sender-only gift failure mode
            // when a realtime signal is missed without duplicating effects.
            if((host||visitReady) && !activeSessionId.isEmpty() && !giftPollInFlight && now-lastGiftRecoveryPollMs >= (realtimeFailures>0?5000L:30000L)){
                lastGiftRecoveryPollMs=now;giftPollInFlight=true;
                BackendClient.liveGiftEvents(token(),hostId,lastGiftEventId,new BackendClient.Callback(){
                    public void onSuccess(JSONObject x){runOnUiThread(()->{giftPollInFlight=false;renderGiftEvents(x.optJSONArray("events"));});}
                    public void onError(String e){giftPollInFlight=false;}
                });
            }
            if (now-cachedGiftCatalogAt>60000L) prefetchGiftCatalog();
            handler.postDelayed(this, 300L);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        // V-353: Live voice and gift effects share the audible media output path.
        setVolumeControlStream(android.media.AudioManager.STREAM_MUSIC);
        host = getIntent().getBooleanExtra("hostMode", false);
        hostId = host ? SessionManager.getUserId(this) : getIntent().getStringExtra("hostId");
        if (hostId == null || hostId.trim().isEmpty()) hostId = SessionManager.getUserId(this);
        build();
        loadLiveUiSettings();
        rtcManager=new AgoraRtcManager(new AgoraRtcManager.Listener(){
            public void onJoined(){rtcJoined=true;rtcDiagnosticStatus="RTC connected";runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);updateLiveStatusLine();});}
            public void onRemoteUserJoined(int uid){rtcDiagnosticStatus="RTC peer "+uid+" connected";if(rtcManager!=null){rtcManager.recoverPlayback();rtcManager.setRemoteAudioEnabled(true);}runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);updateLiveStatusLine();});}
            public void onRemoteAudioState(int uid,int state,int reason){rtcDiagnosticStatus="RTC remote audio uid="+uid+" state="+state+" reason="+reason;runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);updateLiveStatusLine();});}
            public void onLocalAudioState(int state,int error){rtcDiagnosticStatus="RTC local audio state="+state+" error="+error;runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);updateLiveStatusLine();});}
            public void onConnectionState(int state,int reason){if(state==3)rtcJoined=true;else if(state==5)rtcJoined=false;rtcDiagnosticStatus=state==3?"Joined":state==2?"Connecting…":state==4?"Reconnecting…":state==5?"Connection failed • tap to retry":"Ready";runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);updateLiveStatusLine();});}
            public void onError(String m){rtcDiagnosticStatus=m;runOnUiThread(()->{if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);updateLiveStatusLine();});}
            public void onTokenWillExpire(){rtcDiagnosticStatus="RTC token renewing";runOnUiThread(()->requestRtcToken(true));}
            public void onAudioLevel(boolean speaking){if(localSpeaking!=speaking){localSpeaking=speaking;runOnUiThread(()->{updateLiveStatusLine();refreshSpeakingAvatars();});}}
            public void onNetworkQuality(int uid,int tx,int rx){if(uid==0){int q=Math.max(tx,rx);rtcNetworkQuality=q>=4?"WEAK":q==3?"FAIR":"GOOD";}}
            public void onActiveSpeaker(int uid,int volume){int previous=activeRtcSpeakerUid;activeRtcSpeakerUid=uid;activeRtcSpeakerAt=System.currentTimeMillis();if(uid!=previous||System.currentTimeMillis()-lastRtcAudioUiAt>650){lastRtcAudioUiAt=System.currentTimeMillis();runOnUiThread(()->{updateLiveStatusLine();refreshSpeakingAvatars();});}}
        });
        try{rtcManager.init(this);}catch(Exception e){Toast.makeText(this,"RTC init failed",Toast.LENGTH_LONG).show();}
        loadCommentUi();
        renderLocalSkeleton();
        BackendClient.userProfile(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject d){JSONObject p=d.optJSONObject("profile");if(p==null)return;runOnUiThread(()->{if(isFinishing()||roomEnded)return;try{cachedHostProfile.put("user_id",hostId);cachedHostProfile.put("full_name",p.optString("name",""));cachedHostProfile.put("avatar_url",p.optString("avatarUrl",""));}catch(Exception ignored){}renderHost(findSeat(currentSeats,1));});}public void onError(String e){}});
        handler.post(durationTick);
        handler.post(realtimeTick);
        handler.post(presenceTick);
        handler.post(participantTick);
        prefetchGiftCatalog();
        if(AccountPreferences.get(this,"live_options").getBoolean("keep_screen",false))getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if(syncState!=null)syncState.setOnClickListener(v->{if(!roomEnded&&!endLiveInProgress)requestRtcToken(true);});
        if (host) showHostSetup();
        else {
            // A screen entry is different from a heartbeat: it starts a clean viewer visit.
            beginViewerVisit();
            requestRtcToken(false);
            handler.post(tick);
        }
    }

    private void beginViewerVisit(){BackendClient.liveViewer(token(),hostId,true,true,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{if(roomEnded||isFinishing())return;visitReady=true;refresh();});}public void onError(String message){runOnUiThread(()->{if(roomEnded||isFinishing())return;showFloatingBanner(message);handler.postDelayed(()->beginViewerVisit(),5000);});}});}
    private void showHostSetup() {
        final android.app.Dialog d=new android.app.Dialog(this);
        LinearLayout box=col();box.setPadding(dp(16),dp(12),dp(16),dp(16));box.setBackground(gradient(new int[]{Color.rgb(7,28,82),Color.rgb(8,19,61),Color.rgb(18,23,73)},Color.rgb(56,117,255),24));

        LinearLayout titleRow=row();titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView start=t("Start Audio Live",19,Color.WHITE,true);titleRow.addView(start,new LinearLayout.LayoutParams(0,dp(40),1));
        TextView close=t("×",24,Color.WHITE,false);close.setGravity(Gravity.CENTER);close.setOnClickListener(v->{d.dismiss();finish();});titleRow.addView(close,new LinearLayout.LayoutParams(dp(40),dp(40)));box.addView(titleRow);
        LinearLayout identity=row();identity.setGravity(Gravity.CENTER_VERTICAL);identity.addView(circleAvatar(SessionManager.getAvatarUrl(this),48,false),new LinearLayout.LayoutParams(dp(48),dp(48)));
        TextView who=t(SessionManager.getFullName(this)+"\nID "+SessionManager.getUserId(this),13,Color.WHITE,true);who.setPadding(dp(12),0,0,0);identity.addView(who,new LinearLayout.LayoutParams(0,dp(56),1));box.addView(identity);

        EditText title=new EditText(this);title.setHint("Live Name");title.setText(AccountPreferences.get(this,"live_setup").getString("title",SessionManager.getFullName(this).isEmpty()?"My Live":SessionManager.getFullName(this)));title.setTextColor(Color.WHITE);title.setHintTextColor(Color.rgb(155,166,205));title.setSingleLine(true);title.setTextSize(15);title.setGravity(Gravity.CENTER);title.setPadding(dp(12),0,dp(12),0);title.setBackground(gradient(new int[]{Color.rgb(17,46,112),Color.rgb(20,41,92)},Color.rgb(57,119,242),16));LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(50));tp.topMargin=dp(8);box.addView(title,tp);
        final String initialCachedName=title.getText().toString();
        BackendClient.me(token(),new BackendClient.Callback(){
            public void onSuccess(JSONObject data){
                JSONObject u=data==null?null:data.optJSONObject("user");if(u==null)return;
                String latest=u.optString("name","").trim();if(latest.isEmpty())return;
                runOnUiThread(()->{
                    String now=title.getText().toString();
                    // Only replace the stale cached value if the host has not started typing.
                    if(now.equals(initialCachedName)||now.trim().isEmpty())title.setText(latest);
                    SessionManager.saveProfile(AudioLiveRoomActivity.this,latest,u.optString("email",""),u.optString("mobile",""),u.optString("avatarUrl",""),u.optString("coverUrl",""),u.optString("bio",""));
                });
            }
            public void onError(String ignored){}
        });

        title.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence t,int a,int c,int n){}public void onTextChanged(CharSequence t,int a,int b,int c){AccountPreferences.get(AudioLiveRoomActivity.this,"live_setup").edit().putString("title",title.getText().toString()).apply();}public void afterTextChanged(android.text.Editable e){}});
        Button go=btn("GO LIVE");go.setTextColor(Color.WHITE);go.setBackground(gradient(new int[]{0xff2386ff,0xff873aef},Color.TRANSPARENT,16));
        go.setOnClickListener(v->{go.setEnabled(false);String name=title.getText().toString().trim();if(name.isEmpty())name=SessionManager.getFullName(this);if(name==null||name.trim().isEmpty())name="My Live";d.dismiss();startHostLive(name,"");});
        LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,dp(48));gp.topMargin=dp(14);box.addView(go,gp);
        TextView cancel=t(UiStrings.label(AudioLiveRoomActivity.this,"Cancel"),13,0xffc7d3ef,false);cancel.setGravity(Gravity.CENTER);cancel.setOnClickListener(v->{d.dismiss();finish();});box.addView(cancel,new LinearLayout.LayoutParams(-1,dp(40)));

        d.setContentView(box);d.setCancelable(false);d.setOnShowListener(x->{android.view.Window w=d.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.76f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.92f),-2);}});d.show();
    }

    private void startHostLive(String title, String topic) {
        // V-394: the value the host just entered is authoritative immediately. Never render
        // a cached SessionManager/profile name while the start request is in flight.
        currentLiveName=(title==null||title.trim().isEmpty())?"My Live":title.trim();
        if(roomTitle!=null)roomTitle.setText("🎙 "+currentLiveName);
        // Atomic Live start: create the session with the selected Live Name/Caption
        // in one backend operation, so nobody can discover the room under an old cached name.
        BackendClient.setLivePresence(token(), true, title, topic, new BackendClient.Callback() {
            @Override public void onSuccess(JSONObject data) {
                hostStarted = true;
                currentLiveName=data.optString("title",title);
                runOnUiThread(() -> { activeSessionId=data.optString("sessionId","");serverElapsedSec=0;serverElapsedSyncMs=System.currentTimeMillis();JSONObject startStats=data.optJSONObject("hostStats");if(startStats!=null)currentHostStats=startStats;renderHost(null);syncState.setText("● LIVE • Room connected"); requestRtcToken(false); refresh(); handler.post(tick); });
            }
            @Override public void onError(String m) {runOnUiThread(()->checkHostStart(title,m));}
        });
    }

    private void checkHostStart(String title,String failure){
        if(isFinishing()||roomEnded)return;syncState.setText("Checking Live connection…");
        BackendClient.liveRoomState(token(),SessionManager.getUserId(this),new BackendClient.Callback(){public void onSuccess(JSONObject state){runOnUiThread(()->{if(isFinishing()||roomEnded)return;String session=state.optString("sessionId","");if(!session.isEmpty()&&title.equals(state.optString("title"))&&state.optLong("elapsedSeconds",Long.MAX_VALUE)<90){hostStarted=true;activeSessionId=session;serverElapsedSec=state.optLong("elapsedSeconds");serverElapsedSyncMs=System.currentTimeMillis();requestRtcToken(false);refresh();handler.removeCallbacks(tick);handler.post(tick);}else{Toast.makeText(AudioLiveRoomActivity.this,failure,Toast.LENGTH_LONG).show();showHostSetup();}});}public void onError(String checkError){runOnUiThread(()->{if(isFinishing()||roomEnded)return;new MyShopCompatDialogBuilder(AudioLiveRoomActivity.this).setTitle("Live connection uncertain").setMessage("The server has not confirmed whether your Live started. Reconnect before starting again.").setPositiveButton("Check again",(d,w)->checkHostStart(title,failure)).setNegativeButton("Close",(d,w)->finish()).show();});}});
    }

    private LinearLayout railAction(View icon,String label,String description){LinearLayout item=col();item.setGravity(Gravity.CENTER);item.setContentDescription(description);icon.setLayoutParams(new LinearLayout.LayoutParams(dp(40),dp(40)));item.addView(icon);if(label!=null){TextView caption=t(label,9.4f,Color.WHITE,true);caption.setGravity(Gravity.CENTER);caption.setSingleLine(true);item.addView(caption,new LinearLayout.LayoutParams(-1,dp(16)));}return item;}
    private void addRailItem(LinearLayout rail,View item){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(5);rail.addView(item,lp);}

    private void build() {
        FrameLayout page = new FrameLayout(this);
        wallpaper = new ImageView(this);
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        wallpaper.setImageResource(R.drawable.live_room_default_wallpaper);
        page.addView(wallpaper, new FrameLayout.LayoutParams(-1,-1));

        // V-320 premium depth layer: visual polish only; guest-seat structure/logic remains untouched.
        View ambience=new View(this);
        ambience.setBackground(gradient(new int[]{Color.argb(178,7,15,54),Color.argb(148,28,18,76),Color.argb(178,7,15,54)},Color.TRANSPARENT,0));
        page.addView(ambience,new FrameLayout.LayoutParams(-1,-1));

        LinearLayout root = col(); root.setPadding(dp(10), dp(4), dp(10), dp(10));
        root.setBackgroundColor(Color.TRANSPARENT);
        page.addView(root, new FrameLayout.LayoutParams(-1,-1));

        // V-292: preserve V-291 bottom safe-area and add only light spacing to right-side actions.
        // clearly above Android gesture/navigation controls on every device.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int navBottom = insets == null ? 0 : insets.getSystemWindowInsetBottom();
            root.setPadding(dp(10), dp(4), dp(10), Math.max(dp(8), navBottom + dp(6)));
            return insets;
        });
        root.post(root::requestApplyInsets);

        roomTitle = t("", 1, Color.TRANSPARENT, false);
        viewers = t("", 1, Color.TRANSPARENT, false); viewers.setVisibility(View.GONE);
        LinearLayout meta = row();
        status = t((host?"Host":"🎧 Audience")+" • ID "+SessionManager.getUserId(this),11,Color.rgb(226,199,255),true);
        meta.addView(status,new LinearLayout.LayoutParams(0,dp(28),1));
        shareView=t("↗ 0",11,Color.rgb(226,199,255),true); shareView.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); meta.addView(shareView,new LinearLayout.LayoutParams(dp(70),dp(28)));
        meta.setVisibility(View.GONE); root.addView(meta,new LinearLayout.LayoutParams(1,1));
        syncState=t("",1,Color.TRANSPARENT,false); syncState.setVisibility(View.GONE); root.addView(syncState,new LinearLayout.LayoutParams(1,1));

        hostArea=col(); hostArea.setPadding(dp(7),dp(10),dp(7),dp(2)); hostArea.setBackgroundColor(Color.TRANSPARENT);
        audienceRow=row(); audienceRow.setGravity(Gravity.CENTER_VERTICAL);
        audienceScroll=new HorizontalScrollView(this); audienceScroll.setHorizontalScrollBarEnabled(false); audienceScroll.setFillViewport(false); audienceRow.setGravity(Gravity.CENTER_VERTICAL);audienceScroll.addView(audienceRow,new HorizontalScrollView.LayoutParams(-2,dp(58)));
        root.addView(hostArea,new LinearLayout.LayoutParams(-1,dp(110)));
        roomTopic = t("",1,Color.TRANSPARENT,false); roomTopic.setVisibility(View.GONE); root.addView(roomTopic,new LinearLayout.LayoutParams(1,1));
        specialArea=col(); specialArea.setGravity(Gravity.CENTER_HORIZONTAL); LinearLayout.LayoutParams sgp=new LinearLayout.LayoutParams(-1,-2); sgp.topMargin=dp(2); root.addView(specialArea,sgp);

        seats=col(); seats.setPadding(dp(2),dp(2),dp(2),dp(2)); seats.setBackgroundColor(Color.TRANSPARENT); root.addView(seats,new LinearLayout.LayoutParams(-1,-2));

        if(host){
            requestNoticeBar=row();
            requestNoticeBar.setGravity(Gravity.CENTER_VERTICAL);
            requestNoticeBar.setPadding(dp(8),dp(3),dp(6),dp(3));
            requestNoticeBar.setVisibility(View.GONE);
            requestNoticeBar.setBackground(gradient(new int[]{Color.argb(235,28,46,112),Color.argb(235,91,42,151)},Color.rgb(84,214,255),14));
            LinearLayout.LayoutParams rnp=new LinearLayout.LayoutParams(-1,dp(62)); rnp.topMargin=dp(2); rnp.bottomMargin=dp(2); root.addView(requestNoticeBar,rnp);
            requests=col(); requests.setVisibility(View.GONE); root.addView(requests,new LinearLayout.LayoutParams(1,1)); requests.addView(t("No pending requests",11,Color.LTGRAY,false));
        }

        pinnedView=t("",13.2f,Color.rgb(255,230,158),true); pinnedView.setOnLongClickListener(v->{if(canPinComments&&pinnedView.getVisibility()==View.VISIBLE){unpinComment();return true;}return false;}); pinnedView.setPadding(dp(10),dp(6),dp(10),dp(6)); pinnedView.setBackground(gradient(new int[]{Color.argb(192,32,27,91),Color.argb(192,47,23,103)},Color.rgb(255,199,80),14)); pinnedView.setVisibility(View.GONE);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2); pp.topMargin=dp(2); pp.rightMargin=dp(54); pinnedView.setMaxLines(3); root.addView(pinnedView,pp);

        // V-367: no separate LIVE AUDIO strip below pinned comments. Speaking state is shown on avatars instead.
        premiumStrip=t("",1,Color.TRANSPARENT,false); premiumStrip.setVisibility(View.GONE); root.addView(premiumStrip,new LinearLayout.LayoutParams(1,1));
        welcomeView=t("",9.4f,Color.rgb(255,231,166),true);welcomeView.setPadding(dp(8),0,dp(8),0);welcomeView.setGravity(Gravity.CENTER_VERTICAL);welcomeView.setVisibility(View.GONE);root.addView(welcomeView,new LinearLayout.LayoutParams(-1,dp(21)));
        productView=t("",10.5f,Color.WHITE,true);productView.setPadding(dp(10),0,dp(10),0);productView.setGravity(Gravity.CENTER_VERTICAL);productView.setBackground(bg(Color.argb(220,20,91,72),Color.rgb(80,234,165),11));productView.setVisibility(View.GONE);root.addView(productView,new LinearLayout.LayoutParams(-1,dp(34)));
        pkView=t("",9.6f,Color.WHITE,true);pkView.setPadding(dp(8),0,dp(8),0);pkView.setGravity(Gravity.CENTER_VERTICAL);pkView.setBackground(gradient(new int[]{Color.argb(190,151,31,76),Color.argb(190,67,41,185)},Color.rgb(255,92,159),11));pkView.setVisibility(View.GONE);root.addView(pkView,new LinearLayout.LayoutParams(-1,dp(22)));

        TextView chatTitle=t("",1,Color.TRANSPARENT,false); chatTitle.setVisibility(View.GONE); root.addView(chatTitle,new LinearLayout.LayoutParams(1,1));
        // V-537: comments draw over the room from the first seat line down to the composer.
        // The weighted spacer preserves the existing vertical layout while the transparent
        // overlay follows the measured seat/composer bounds on every screen size.
        FrameLayout commentStage=new FrameLayout(this); commentStage.setBackgroundColor(Color.TRANSPARENT); commentStage.setMinimumHeight(dp(80)); commentStage.setClickable(false);
        commentScroll=new ScrollView(this); commentScroll.setVerticalScrollBarEnabled(false); commentScroll.setFillViewport(false); commentsList=col(); commentsList.setPadding(dp(5),dp(4),dp(5),dp(4)); commentsList.setBackgroundColor(Color.TRANSPARENT); commentScroll.setBackgroundColor(Color.TRANSPARENT); commentScroll.addView(commentsList);
        FrameLayout.LayoutParams csp=new FrameLayout.LayoutParams(-1,-1); csp.rightMargin=dp(48); commentStage.addView(commentScroll,csp); commentScroll.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout floating=col(); floating.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.CENTER_VERTICAL);
        // Approved room rail: Love -> Vote -> Gift -> animated Join.
        final int railSize=dp(40);
        reactView=t("",1,Color.WHITE,true);reactView.setGravity(Gravity.CENTER);reactView.setBackgroundResource(R.drawable.live_ref_love);reactView.setContentDescription("Send Love reaction");reactView.setOnClickListener(v->{BackendClient.liveReact(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{reactionAckAt=android.os.SystemClock.elapsedRealtime();reactCount=d.optLong("reactCount",reactCount+1);if(reactCountLabel!=null)reactCountLabel.setText(compact(reactCount));renderHost(findSeat(currentSeats,1));showReaction();});}public void onError(String e){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_SHORT).show());}});});
        LinearLayout loveAction=railAction(reactView,compact(reactCount),"Love count");reactCountLabel=(TextView)loveAction.getChildAt(1);addRailItem(floating,loveAction);
        TextView vote=t("",1,Color.WHITE,true);vote.setGravity(Gravity.CENTER);vote.setBackgroundResource(R.drawable.live_ref_vote);vote.setContentDescription("Vote for host");vote.setOnClickListener(v->BackendClient.liveVote(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{voteCount=d.optLong("voteCount",voteCount);renderHost(findSeat(currentSeats,1));Toast.makeText(AudioLiveRoomActivity.this,"Vote added",Toast.LENGTH_SHORT).show();});}public void onError(String e){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_SHORT).show());}}));addRailItem(floating,railAction(vote,"Vote","Vote"));
        ImageView gift=new ImageView(this);gift.setImageResource(R.drawable.live_ref_gift);gift.setScaleType(ImageView.ScaleType.CENTER_INSIDE);gift.setContentDescription("Send a gift");gift.setOnClickListener(v->{giftReceiverId=hostId;showGiftPanel();});addRailItem(floating,railAction(gift,null,"Gift"));
        JoinLinkView joinRail=new JoinLinkView(this);joinRail.setContentDescription("Join");joinRail.setOnClickListener(v->handleJoinAction());addRailItem(floating,railAction(joinRail,"Join","Join"));
        FrameLayout.LayoutParams fap=new FrameLayout.LayoutParams(dp(50),FrameLayout.LayoutParams.WRAP_CONTENT,Gravity.RIGHT|Gravity.BOTTOM);fap.rightMargin=dp(2);fap.bottomMargin=dp(8);page.addView(floating,fap);
        sendRailAnchor(floating,commentStage);
        LinearLayout.LayoutParams commentSafeLp=new LinearLayout.LayoutParams(-1,0,1);commentSafeLp.topMargin=dp(4);commentSafeLp.bottomMargin=dp(2);root.addView(commentStage,commentSafeLp);

        LinearLayout sendRow=row(); sendRow.setGravity(Gravity.CENTER_VERTICAL); sendRow.setPadding(dp(4),dp(3),dp(4),dp(3)); sendRow.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout commentBox=new FrameLayout(this);
        EditText commentInput=new EditText(this); commentInput.setHint(UiStrings.label(AudioLiveRoomActivity.this,"Write a comment…")); commentInput.setTextColor(Color.WHITE); commentInput.setHintTextColor(Color.rgb(178,190,222)); commentInput.setSingleLine(true); commentInput.setTextSize(12.8f); commentInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_SHORT_MESSAGE); commentInput.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEND); commentInput.setFocusable(false); commentInput.setClickable(true); commentInput.setBackground(bg(Color.argb(215,15,24,52),Color.TRANSPARENT,24)); commentInput.setPadding(dp(14),0,dp(10),0); commentBox.addView(commentInput,new FrameLayout.LayoutParams(-1,-1));commentInput.setOnClickListener(v->showCommentComposer());commentBox.setOnClickListener(v->showCommentComposer());
        commentInput.addOnLayoutChangeListener((v,l,top,right,bottom,ol,ot,or,ob)->{String full=UiStrings.label(AudioLiveRoomActivity.this,"Write a comment…");int available=Math.max(0,right-l-commentInput.getPaddingLeft()-commentInput.getPaddingRight());String hint=commentInput.getPaint().measureText(full)<=available?full:UiStrings.label(AudioLiveRoomActivity.this,"Comment")+"…";if(!hint.contentEquals(commentInput.getHint()))commentInput.setHint(hint);});
        TextView highlight=t("🚀\n1,000",8.5f,Color.rgb(255,219,96),true); highlight.setGravity(Gravity.CENTER); highlight.setLineSpacing(-dp(3),1f); highlight.setContentDescription("Highlight comment • 1,000 Coins"); FrameLayout.LayoutParams hlp=new FrameLayout.LayoutParams(dp(54),-1,Gravity.LEFT); commentBox.addView(highlight,hlp);highlight.setVisibility(View.GONE);
        updateHighlightControl(highlight);
        highlight.setEnabled(false);highlight.setOnClickListener(v->{highlightSelected=!highlightSelected;updateHighlightControl(highlight);});
        BackendClient.liveHighlightConfig(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{highlightPrice=d.optBoolean("free",false)?0:d.optInt("coinPrice",1000);highlight.setEnabled(true);updateHighlightControl(highlight);});}public void onError(String e){}});
        sendButton=small(UiStrings.label(AudioLiveRoomActivity.this,"Send")); sendButton.setTextColor(Color.rgb(91,220,255));sendButton.setAllCaps(false); sendButton.setTextSize(12.0f);sendButton.setPadding(0,0,0,0);sendButton.setMinWidth(0);sendButton.setMinimumWidth(0);sendButton.setMinHeight(0);sendButton.setMinimumHeight(0); sendButton.setContentDescription("Send comment"); sendButton.setBackgroundColor(Color.TRANSPARENT); sendButton.setVisibility(View.GONE);
        sendButton.setEnabled(false);sendButton.setAlpha(.45f);
        commentInput.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){boolean ready=s.toString().trim().length()>0&&!commentSending;sendButton.setEnabled(ready);sendButton.setAlpha(ready?1f:.45f);sendButton.setShadowLayer(ready?dp(4):0,0,0,Color.rgb(88,210,255));}public void afterTextChanged(android.text.Editable e){}});
        micButton=t("",1,Color.WHITE,true);micButton.setGravity(Gravity.CENTER);micButton.setContentDescription(host||"SPEAKER".equals(myRole)?"Microphone":"Room audio");micButton.setBackgroundResource(R.drawable.live_ref_mic);micButton.setOnClickListener(v->toggleMic());PremiumUi.press(micButton);micControl=new FrameLayout(this);micControl.addView(micButton,new FrameLayout.LayoutParams(-1,-1));micMutedMark=t("╱",25,0xffff405d,true);micMutedMark.setGravity(Gravity.CENTER);micMutedMark.setShadowLayer(dp(3),0,0,Color.BLACK);micMutedMark.setVisibility(View.GONE);micControl.addView(micMutedMark,new FrameLayout.LayoutParams(-1,-1));updateLocalMicUi();
        FrameLayout liveMessageButton=new FrameLayout(this); liveMessageButton.setContentDescription("Messages"); liveMessageButton.setClickable(true); liveMessageButton.setFocusable(true); ImageView liveMessageIcon=new ImageView(this); liveMessageIcon.setImageResource(R.drawable.live_ref_message); liveMessageIcon.setScaleType(ImageView.ScaleType.CENTER_INSIDE); liveMessageIcon.setPadding(0,0,0,0); liveMessageButton.addView(liveMessageIcon,new FrameLayout.LayoutParams(-1,-1)); liveMessageButton.setOnClickListener(v->openLiveInbox()); PremiumUi.press(liveMessageButton);
        speakerActionButton=t("JOIN",Math.max(15f,Math.min(joinFontSize,17.0f)),joinTextColor,true);speakerActionButton.setGravity(Gravity.CENTER);speakerActionButton.setSingleLine(true);speakerActionButton.setBackground(gradient(new int[]{Color.rgb(255,67,96),Color.rgb(237,22,102),Color.rgb(204,20,112)},Color.rgb(255,122,158),17));speakerActionButton.setOnClickListener(v->{if(host){showFloatingBanner("Host is already Live • use ❌ to end Live");return;}if("SPEAKER".equals(myRole)){confirmLeaveSeat();return;}if("PENDING".equalsIgnoreCase(myRequestStatus)){confirmCancelJoinRequest();return;}if(listenOnly){showFloatingBanner("🔇 Listen-only mode");return;}requestJoinToCall();});
        LinearLayout.LayoutParams cip=new LinearLayout.LayoutParams(0,dp(40),1); cip.rightMargin=dp(5); sendRow.addView(commentBox,cip);
        ImageView gameButton=new ImageView(this);gameButton.setImageResource(R.drawable.premium438_game);gameButton.setScaleType(ImageView.ScaleType.CENTER_INSIDE);gameButton.setContentDescription("Games • Coming Soon");gameButton.setOnClickListener(v->Toast.makeText(this,"Coming Soon",Toast.LENGTH_SHORT).show());LinearLayout.LayoutParams gameLp=new LinearLayout.LayoutParams(dp(36),dp(40));gameLp.rightMargin=dp(4);sendRow.addView(gameButton,gameLp);
        LinearLayout.LayoutParams micp=new LinearLayout.LayoutParams(dp(36),dp(40));micp.rightMargin=dp(4);sendRow.addView(micControl,micp);
        ImageView moreButton=new ImageView(this);moreButton.setImageResource(R.drawable.premium438_more);moreButton.setScaleType(ImageView.ScaleType.CENTER_INSIDE);moreButton.setContentDescription("More live controls");moreButton.setOnClickListener(v->showLiveMoreMenu());sendRow.addView(moreButton,new LinearLayout.LayoutParams(dp(36),dp(40)));
        speakerActionButton.setVisibility(View.GONE);
        LinearLayout.LayoutParams srp=new LinearLayout.LayoutParams(-1,dp(52)); srp.topMargin=dp(4); srp.bottomMargin=dp(2); root.addView(sendRow,srp);
        setContentView(page);
        MiniAdOverlay.install(this,"live_room");
        MiniHeadlineOverlay.install(this,"live_room");
    }

    private void sendRailAnchor(LinearLayout rail,View stage){
        rail.getViewTreeObserver().addOnGlobalLayoutListener(()->{if(stage.getHeight()<=0)return;android.graphics.Rect bounds=new android.graphics.Rect();stage.getDrawingRect(bounds);FrameLayout canvas=(FrameLayout)rail.getParent();canvas.offsetDescendantRectToMyCoords(stage,bounds);FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)rail.getLayoutParams();int bottom=Math.max(dp(52),canvas.getHeight()-bounds.bottom+dp(8));if(p.bottomMargin!=bottom){p.bottomMargin=bottom;rail.setLayoutParams(p);} });
    }
    private void showLiveMoreMenu(){
        final android.app.Dialog dialog=new android.app.Dialog(this);
        LinearLayout box=col();box.setPadding(dp(14),dp(12),dp(14),dp(14));box.setBackground(gradient(new int[]{0xff101a3a,0xff1c2450},Color.TRANSPARENT,20));
        TextView title=t("More Live Controls",16,Color.WHITE,true);title.setGravity(Gravity.CENTER);box.addView(title,new LinearLayout.LayoutParams(-1,dp(36)));
        LinearLayout grid=row();grid.setGravity(Gravity.CENTER);
        String[] names={"Share","Music","Messages"};int[] images={R.drawable.live_ref_share,R.drawable.live_ref_music,R.drawable.live_ref_message};
        for(int n=0;n<names.length;n++){
            final int action=n;LinearLayout tile=col();tile.setGravity(Gravity.CENTER);tile.setPadding(dp(4),dp(8),dp(4),dp(6));
            ImageView icon=new ImageView(this);icon.setImageResource(images[n]);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);tile.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
            TextView label=t(names[n],12,Color.WHITE,true);label.setGravity(Gravity.CENTER);label.setSingleLine(true);tile.addView(label,new LinearLayout.LayoutParams(-1,dp(26)));
            tile.setContentDescription(names[n]);tile.setClickable(true);tile.setFocusable(true);PremiumUi.press(tile);tile.setOnClickListener(v->{dialog.dismiss();if(action==0)shareRoom();else if(action==1)showMusicLibrary();else openLiveInbox();});
            grid.addView(tile,new LinearLayout.LayoutParams(0,dp(88),1));
        }
        box.addView(grid,new LinearLayout.LayoutParams(-1,dp(92)));
        LinearLayout extraGrid=row();String[] extraNames={"Audio","Favourite","Settings"},extraIcons={"🔊","⭐","⚙"};for(int n=0;n<3;n++){final int action=n;LinearLayout tile=col();tile.setGravity(Gravity.CENTER);TextView icon=t(extraIcons[n],28,Color.WHITE,true);icon.setGravity(Gravity.CENTER);tile.addView(icon,new LinearLayout.LayoutParams(-1,dp(48)));TextView label=t(extraNames[n],12,Color.WHITE,true);label.setGravity(Gravity.CENTER);tile.addView(label,new LinearLayout.LayoutParams(-1,dp(26)));tile.setOnClickListener(v->{dialog.dismiss();if(action==0)showAudioControls();else if(action==1)LiveFavorites.toggle(this,hostId,currentLiveName);else showRoomSettings552();});extraGrid.addView(tile,new LinearLayout.LayoutParams(0,dp(88),1));}box.addView(extraGrid,new LinearLayout.LayoutParams(-1,dp(92)));
        TextView close=t(UiStrings.label(AudioLiveRoomActivity.this,"Close"),13,0xffb7caf5,true);close.setGravity(Gravity.CENTER);close.setOnClickListener(v->dialog.dismiss());box.addView(close,new LinearLayout.LayoutParams(-1,dp(36)));
        dialog.setContentView(box);dialog.show();android.view.Window window=dialog.getWindow();if(window!=null){window.setBackgroundDrawableResource(android.R.color.transparent);window.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.88f),-2);window.setDimAmount(.35f);window.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);}
    }
    private void showAudioControls(){
        LinearLayout box=col();box.setPadding(dp(14),dp(8),dp(14),dp(8));box.setBackground(bg(0xff152147,0xff7865e6,18));
        Switch screen=new Switch(this);screen.setText("Keep screen on");screen.setTextColor(Color.WHITE);screen.setChecked(AccountPreferences.get(this,"live_options").getBoolean("keep_screen",false));screen.setOnCheckedChangeListener((b,on)->{AccountPreferences.get(this,"live_options").edit().putBoolean("keep_screen",on).apply();if(on)getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);});box.addView(screen,new LinearLayout.LayoutParams(-1,dp(48)));
        Button route=btn("🔊 Audio output");route.setOnClickListener(v->new MyShopCompatDialogBuilder(this).setTitle("Audio output").setItems(new String[]{"Speaker","Earpiece","Bluetooth","Wired / USB headset","Automatic"},(d,n)->{if(n==2&&Build.VERSION.SDK_INT>=31&&checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT)!=android.content.pm.PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{android.Manifest.permission.BLUETOOTH_CONNECT},552);Toast.makeText(this,"Allow Bluetooth, then choose the headset",android.widget.Toast.LENGTH_SHORT).show();return;}if(rtcManager==null||!rtcManager.selectRoute(n==4?-1:n))Toast.makeText(this,"Audio device unavailable",android.widget.Toast.LENGTH_SHORT).show();}).show());box.addView(route,new LinearLayout.LayoutParams(-1,dp(48)));
        if(host){Button volume=btn("🎚 Guest listening volume");volume.setOnClickListener(v->{java.util.ArrayList<JSONObject> users=new java.util.ArrayList<>();for(int i=0;i<currentSeats.length();i++){JSONObject user=currentSeats.optJSONObject(i);if(user!=null&&!hostId.equals(user.optString("user_id")))users.add(user);}String[] names=new String[users.size()];for(int i=0;i<users.size();i++)names[i]=users.get(i).optString("full_name","Guest");new MyShopCompatDialogBuilder(this).setTitle("Only changes what you hear").setItems(names,(d,n)->showLocalGuestVolume(users.get(n).optString("user_id"))).show();});box.addView(volume,new LinearLayout.LayoutParams(-1,dp(48)));}
        TextView connection=t(rtcJoined?"✓ Joined":rtcJoinRequested?"Connecting…":"Connection pending • tap Retry",12,0xffb9ceff,true);box.addView(connection,new LinearLayout.LayoutParams(-1,dp(40)));Button retry=btn("Retry audio connection");retry.setOnClickListener(v->{if(!roomEnded&&!endLiveInProgress){rtcJoined=false;requestRtcToken(false);}});box.addView(retry,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView mic=t(localMicOn?(localSpeaking?"🎙 Voice detected":"🎙 Microphone ready • speak to see the wave"):"🎙 Microphone muted",12,0xff86e8bc,true);box.addView(mic,new LinearLayout.LayoutParams(-1,dp(48)));
        new MyShopCompatDialogBuilder(this).setTitle("Live audio & screen").setView(box).setNegativeButton("Close",null).show();
    }
    private void showLocalGuestVolume(String uid){SeekBar seek=new SeekBar(this);seek.setMax(100);seek.setProgress(AccountPreferences.get(this,"guest_volume").getInt(uid,100));seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int n,boolean user){if(user&&rtcManager!=null)try{rtcManager.setUserVolume(Integer.parseInt(uid),n);AccountPreferences.get(AudioLiveRoomActivity.this,"guest_volume").edit().putInt(uid,n).apply();}catch(Exception ignored){}}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});new MyShopCompatDialogBuilder(this).setTitle("Your listening volume").setView(seek).setNegativeButton("Close",null).show();}
    private void showRoomSettings552(){
        if(!canModerateSeat()){NotificationOptions.show(this);return;}
        LinearLayout box=col();box.setPadding(dp(12),dp(8),dp(12),dp(8));EditText slow=new EditText(this);slow.setHint("Comment interval seconds (0–60)");slow.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);slow.setText("0");box.addView(slow);
        Switch giftSound=new Switch(this);giftSound.setText(UiStrings.label(giftSound.getContext(),"Gift Sound • animation stays on"));giftSound.setChecked(giftSoundEnabled613);giftSound.setEnabled(host);giftSound.setOnCheckedChangeListener((button,on)->{if(!host||on==giftSoundEnabled613)return;giftSound.setEnabled(false);BackendClient.giftSound613(token(),hostId,on,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{giftSoundEnabled613=d.optBoolean("enabled",true);if(!giftSoundEnabled613)stopGiftSounds613();giftSound.setChecked(giftSoundEnabled613);giftSound.setEnabled(host);});}public void onError(String m){runOnUiThread(()->{giftSound.setChecked(giftSoundEnabled613);giftSound.setEnabled(host);Toast.makeText(AudioLiveRoomActivity.this,m,1).show();});}});});box.addView(giftSound);Switch effects=new Switch(this);effects.setText("Gift combo animation");effects.setChecked(true);box.addView(effects);TextView note=t("Preview before Save. Restore loads the previous saved settings.",11,0xffb4ceff,false);box.addView(note);
        BackendClient.liveBatchSettings(token(),hostId,null,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{slow.setText(String.valueOf(d.optInt("slowModeSeconds",0)));effects.setChecked(d.optBoolean("giftComboEnabled",true));});}public void onError(String e){}});
        new MyShopCompatDialogBuilder(this).setTitle("Room settings").setView(box).setPositiveButton("Preview",(d,w)->{int seconds;try{seconds=Integer.parseInt(slow.getText().toString());}catch(Exception e){Toast.makeText(this,"Enter 0–60 seconds",android.widget.Toast.LENGTH_SHORT).show();return;}if(seconds<0||seconds>60){Toast.makeText(this,"Enter 0–60 seconds",android.widget.Toast.LENGTH_SHORT).show();return;}final JSONObject values=new JSONObject();try{values.put("slowModeSeconds",seconds).put("giftComboEnabled",effects.isChecked());}catch(Exception ignored){}new MyShopCompatDialogBuilder(this).setTitle("Preview settings").setMessage("Comment interval: "+seconds+"s\nGift combos: "+(effects.isChecked()?"Enabled":"Disabled")).setPositiveButton("Save",(dd,ww)->BackendClient.liveBatchSettings(token(),hostId,values,new ToastCb("Settings saved"))).setNegativeButton("Cancel",null).show();}).setNeutralButton("Restore",(d,w)->{JSONObject restore=new JSONObject();try{restore.put("restore",true);}catch(Exception ignored){}BackendClient.liveBatchSettings(token(),hostId,restore,new ToastCb("Previous settings restored"));}).setNegativeButton("Close",null).show();
    }

    private void handleJoinAction(){if(host){showFloatingBanner("Host is already Live");return;}if("SPEAKER".equals(myRole)){confirmLeaveSeat();return;}if("PENDING".equalsIgnoreCase(myRequestStatus)){confirmCancelJoinRequest();return;}if(listenOnly){showFloatingBanner("🔇 Listen-only mode");return;}requestJoinToCall();}
    private void showCommentComposer(){
        if(commentComposerDialog!=null&&commentComposerDialog.isShowing())return;
        LinearLayout box=col();box.setPadding(dp(12),dp(9),dp(12),dp(6));box.setBackground(gradient(new int[]{0xff111c3b,0xff182451},0xff354a87,18));
        LinearLayout row=row();row.setGravity(Gravity.CENTER_VERTICAL);TextView rocket=t("🚀",23,Color.WHITE,true);rocket.setGravity(Gravity.CENTER);rocket.setContentDescription("Optional rocket highlight");row.addView(rocket,new LinearLayout.LayoutParams(dp(42),dp(46)));
        EditText input=new EditText(this);input.setSingleLine(true);input.setTextSize(15);input.setTextColor(Color.WHITE);input.setHintTextColor(0xffa9b5d4);input.setHint("Write a comment…");input.setFilters(new android.text.InputFilter[]{new LiveCommentLimit()});input.setPadding(dp(12),0,dp(12),0);input.setBackground(bg(0xff202d51,0xff53699f,24));input.setText(liveCommentDraft);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,dp(46),1);ip.leftMargin=dp(6);ip.rightMargin=dp(7);row.addView(input,ip);
        TextView send=t("➤",22,0xff22d6f3,true);send.setContentDescription("Send comment");send.setGravity(Gravity.CENTER);row.addView(send,new LinearLayout.LayoutParams(dp(48),dp(44)));box.addView(row,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView fee=t("Rocket highlight • "+(highlightPrice<=0?"Free":compact(highlightPrice)+" coins"),10.5f,0xffb4c3e5,false);fee.setPadding(dp(44),0,0,0);box.addView(fee,new LinearLayout.LayoutParams(-1,dp(18)));
        send.setEnabled(!liveCommentDraft.trim().isEmpty());send.setAlpha(send.isEnabled()?1f:.45f);
        input.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence a,int st,int count,int after){}public void onTextChanged(CharSequence a,int st,int before,int count){send.setEnabled(!commentSending&&a.toString().trim().length()>0);send.setAlpha(send.isEnabled()?1f:.45f);}public void afterTextChanged(android.text.Editable e){}});
        rocket.setAlpha(highlightSelected?1f:.72f);activeCommentInput=input;activeCommentHighlight=rocket;rocket.setOnClickListener(v->{highlightSelected=!highlightSelected;rocket.setAlpha(highlightSelected?1f:.72f);rocket.setTextColor(highlightSelected?0xffffc34f:Color.WHITE);});send.setOnClickListener(v->{liveCommentDraft=input.getText().toString();sendLiveComment(input,rocket);});
        commentComposerDialog=new android.app.Dialog(this);commentComposerDialog.setContentView(box);commentComposerDialog.setCancelable(true);commentComposerDialog.setOnDismissListener(d->{if(activeCommentInput!=null)liveCommentDraft=activeCommentInput.getText().toString();activeCommentInput=null;activeCommentHighlight=null;});commentComposerDialog.show();android.view.Window w=commentComposerDialog.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setGravity(Gravity.BOTTOM);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.96f),-2);w.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE|android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);android.view.WindowManager.LayoutParams a=w.getAttributes();a.dimAmount=0f;w.setAttributes(a);}
        input.requestFocus();input.postDelayed(()->{android.view.inputmethod.InputMethodManager imm=(android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);if(imm!=null)imm.showSoftInput(input,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);},180);
    }

    // Framework TextView intentionally retained: preserve the approved ticker drawing.
    @android.annotation.SuppressLint("AppCompatCustomView")
    private final class LeftToRightTicker extends TextView {
        LeftToRightTicker(Context c){super(c);setGravity(Gravity.CENTER_VERTICAL);setSingleLine(true);}
        @Override protected void onDraw(Canvas canvas){CharSequence value=getText();if(value==null||value.length()==0)return;Paint p=getPaint();p.setColor(Color.WHITE);float tw=android.text.Layout.getDesiredWidth(value,getPaint()),w=getWidth();if(tw<=0||w<=0)return;if(tw<=w){super.onDraw(canvas);return;}float travel=w+tw+dp(24);float offset=(android.os.SystemClock.elapsedRealtime()%9000L)/9000f*travel;float x=-tw+offset;canvas.save();canvas.clipRect(0,0,w,getHeight());android.text.StaticLayout layout=android.text.StaticLayout.Builder.obtain(value,0,value.length(),getPaint(),Math.max(1,(int)Math.ceil(android.text.Layout.getDesiredWidth(value,getPaint())))).setIncludePad(false).setMaxLines(1).build();canvas.translate(x,(getHeight()-layout.getHeight())/2f);layout.draw(canvas);canvas.restore();postInvalidateDelayed(40);}
    }
    private final class MainGuestLogoView extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);MainGuestLogoView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float cx=getWidth()/2f,cy=getHeight()/2f;float bw=dp(94),bh=dp(92);RectF bag=new RectF(cx-bw/2,cy-bh/2+dp(16),cx+bw/2,cy+bh/2+dp(17));p.setStyle(Paint.Style.FILL);p.setColor(0xff061c55);p.setShadowLayer(dp(12),0,0,0xff145fff);canvas.drawRoundRect(bag,dp(14),dp(14),p);p.clearShadowLayer();p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(3));p.setColor(0xff35bcff);canvas.drawRoundRect(bag,dp(14),dp(14),p);RectF handle=new RectF(cx-dp(24),cy-dp(55),cx+dp(24),cy+dp(2));p.setStrokeWidth(dp(5));p.setColor(0xffffc64b);canvas.drawArc(handle,180,180,false,p);p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.create("sans-serif-black",Typeface.BOLD));p.setTextSize(dp(48));p.setTextAlign(Paint.Align.CENTER);p.setColor(0xffffc331);canvas.drawText("M",cx-dp(9),cy+dp(44),p);p.setColor(Color.WHITE);canvas.drawText("S",cx+dp(20),cy+dp(44),p);p.setColor(0xff26dfff);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(3));for(int i=0;i<3;i++)canvas.drawArc(new RectF(cx+dp(35+i*5),cy-dp(48-i*5),cx+dp(67+i*5),cy-dp(16+i*5)),220,80,false,p);p.setStyle(Paint.Style.FILL);p.setColor(0xffff4b47);Path play=new Path();play.moveTo(cx+dp(43),cy-dp(14));play.lineTo(cx+dp(43),cy+dp(2));play.lineTo(cx+dp(57),cy-dp(6));play.close();canvas.drawPath(play,p);}
    }
    private final class JoinLinkView extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);private float phase=0f;private ValueAnimator animator;JoinLinkView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onAttachedToWindow(){super.onAttachedToWindow();if(animator==null){animator=ValueAnimator.ofFloat(0f,360f);animator.setDuration(3200);animator.setRepeatCount(ValueAnimator.INFINITE);animator.addUpdateListener(a->{phase=(float)a.getAnimatedValue();invalidate();});}animator.start();}
        @Override protected void onDetachedFromWindow(){if(animator!=null)animator.cancel();super.onDetachedFromWindow();}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);float cx=getWidth()/2f,cy=getHeight()/2f;SweepGradient sweep=new SweepGradient(cx,cy,new int[]{0xff25d9ff,0xff5a49ff,0xffed46dc,0xffff73ad,0xff25d9ff},null);android.graphics.Matrix matrix=new android.graphics.Matrix();matrix.setRotate(phase,cx,cy);sweep.setLocalMatrix(matrix);paint.setShader(sweep);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(4.7f));paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);paint.setShadowLayer(dp(7),0,0,0xff935cff);canvas.save();canvas.rotate(-38,cx-dp(4),cy);canvas.drawRoundRect(cx-dp(15),cy-dp(6),cx+dp(2),cy+dp(6),dp(6),dp(6),paint);canvas.restore();canvas.save();canvas.rotate(38,cx+dp(4),cy);canvas.drawRoundRect(cx-dp(2),cy-dp(6),cx+dp(15),cy+dp(6),dp(6),dp(6),paint);canvas.restore();paint.clearShadowLayer();paint.setShader(null);}
    }

    private void addControls(LinearLayout root){
        LinearLayout bottom=row(); bottom.setGravity(Gravity.CENTER_VERTICAL);
        String[] labels=host?new String[]{"🎙","➕","🪑","📌","↗","⚙"}:new String[]{"✋","➕","💬","📩","↗","⚙"};
        for(int i=0;i<labels.length;i++){final int idx=i;TextView v=t(labels[i],16,Color.WHITE,true);v.setGravity(Gravity.CENTER);PremiumUi.premiumButton(v,new int[]{Color.rgb(17,42,103),Color.rgb(65,46,143)},18,Color.argb(150,106,207,255),4);v.setOnClickListener(x->handleCompactControl(idx));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(40),1);lp.setMargins(dp(2),0,dp(2),0);bottom.addView(v,lp);}
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(42)); bp.topMargin=dp(3); root.addView(bottom,bp);
    }

    private void handleCompactControl(int i){
        if(host){if(i==0)toggleMic();else if(i==1)showAudienceList();else if(i==2)Toast.makeText(this,"Tap a sofa to lock/unlock or manage speaker",Toast.LENGTH_SHORT).show();else if(i==3)editPinned();else if(i==4)shareRoom();else if(i==5)showHostRoomMenu();}
        else{if(i==0)requestJoinToCall();else if(i==1)BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));else if(i==2)Toast.makeText(this,"Live chat is above",Toast.LENGTH_SHORT).show();else if(i==3)Toast.makeText(this,"Open Inbox",Toast.LENGTH_SHORT).show();else if(i==4)shareRoom();else showLiveCommunityMenu();}
    }

    private void showHostRoomMenu(){String[] a={"Live Summary","Theme","Live Name / Caption","Pinned announcement","Welcome / Rules","Live Goal","Pin Shop Item","Live Poll","Top Supporters / Fan Club","Creator Center","Schedule Live","PK / Battle","End Live"};new MyShopCompatDialogBuilder(this).setTitle("Host Room Controls").setItems(a,(d,w)->{if(w==0)showRunningLiveSummary();else if(w==1)chooseTheme();else if(w==2)editRoomInfo();else if(w==3)editPinned();else if(w==4)editWelcome();else if(w==5)editGoal();else if(w==6)choosePinnedProduct();else if(w==7)showPollComposer();else if(w==8)showFanClub();else if(w==9)openCreatorCenter(hostId);else if(w==10)showScheduleDialog();else if(w==11)showPkDialog();else confirmEndLive();}).show();}

    private void handleControl(int i){
        if(host){
            if(i==0) toggleMic(); else if(i==2) Toast.makeText(this,"Tap any sofa to lock/unlock or manage speaker",Toast.LENGTH_SHORT).show();
            else if(i==3) editPinned(); else if(i==4) chooseTheme(); else if(i==5) shareRoom(); else if(i==6) showReaction(); else if(i==7) editRoomInfo();
            else Toast.makeText(this,"Host control ready",Toast.LENGTH_SHORT).show();
        } else {
            if(i==0) toggleMic(); else if(i==1) BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));
            else if(i==3) showReaction(); else if(i==5) shareRoom(); else Toast.makeText(this,"Live control",Toast.LENGTH_SHORT).show();
        }
    }

    private void showMusicLibrary(){
        if(!(host||roomAdmin||SessionManager.isAdmin(this)||SessionManager.isModerator(this))){Toast.makeText(this,"Only Host, Room Admin, Main Admin or Moderator can control Live music",Toast.LENGTH_SHORT).show();return;}
        LinearLayout box=col();box.setPadding(dp(14),dp(12),dp(14),dp(12));box.setBackground(gradient(new int[]{Color.rgb(7,20,59),Color.rgb(42,24,103),Color.rgb(8,66,100)},Color.rgb(83,222,255),22));
        TextView title=t("♫  myshop LIVE MUSIC",17,Color.WHITE,true);title.setGravity(Gravity.CENTER);box.addView(title,new LinearLayout.LayoutParams(-1,dp(40)));
        TextView state=t(musicPlaying?(musicPaused?"Paused":"Music On") : "Select an Admin-approved track",10.5f,Color.rgb(188,231,255),true);state.setGravity(Gravity.CENTER);box.addView(state,new LinearLayout.LayoutParams(-1,dp(30)));
        LinearLayout actions=row();Button pause=small(musicPaused?"RESUME":"PAUSE"),stop=small("STOP");pause.setEnabled(musicPlaying);stop.setEnabled(musicPlaying);actions.addView(pause,new LinearLayout.LayoutParams(0,dp(42),1));actions.addView(stop,new LinearLayout.LayoutParams(0,dp(42),1));box.addView(actions,new LinearLayout.LayoutParams(-1,dp(46)));
        TextView volumeLabel=t("Music volume 70%",10,Color.WHITE,true);box.addView(volumeLabel,new LinearLayout.LayoutParams(-1,dp(28)));android.widget.SeekBar volume=new android.widget.SeekBar(this);volume.setMax(100);volume.setProgress(70);box.addView(volume,new LinearLayout.LayoutParams(-1,dp(38)));volume.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(android.widget.SeekBar s,int p,boolean f){volumeLabel.setText("Music volume "+p+"%");if(rtcManager!=null)rtcManager.setMusicVolume(p);}public void onStartTrackingTouch(android.widget.SeekBar s){}public void onStopTrackingTouch(android.widget.SeekBar s){}});
        ScrollView scroll=new ScrollView(this);LinearLayout list=col();TextView loading=t("Loading albums and songs…",11,Color.rgb(207,215,242),false);loading.setGravity(Gravity.CENTER);list.addView(loading,new LinearLayout.LayoutParams(-1,dp(70)));scroll.addView(list);box.addView(scroll,new LinearLayout.LayoutParams(-1,dp(330)));
        final AlertDialog dialog=new MyShopCompatDialogBuilder(this).setView(box).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Close"),null).create();
        pause.setOnClickListener(v->{if(rtcManager==null)return;if(musicPaused){rtcManager.resumeMusic();musicPaused=false;pause.setText("PAUSE");state.setText("Music On");}else{rtcManager.pauseMusic();musicPaused=true;pause.setText("RESUME");state.setText("Paused");}});
        stop.setOnClickListener(v->{if(rtcManager!=null)rtcManager.stopMusic();musicPlaying=false;musicPaused=false;state.setText("Music stopped");pause.setEnabled(false);stop.setEnabled(false);updateMusicButtonState();});
        BackendClient.liveMusic(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{list.removeAllViews();JSONArray albums=d.optJSONArray("albums"),songs=d.optJSONArray("songs");if(albums==null)albums=new JSONArray();if(songs==null)songs=new JSONArray();if(songs.length()==0){TextView empty=t("Admin Music Library is empty",11,Color.rgb(210,218,244),true);empty.setGravity(Gravity.CENTER);list.addView(empty,new LinearLayout.LayoutParams(-1,dp(80)));return;}for(int ai=0;ai<albums.length();ai++){JSONObject album=albums.optJSONObject(ai);if(album==null)continue;long albumId=album.optLong("id");TextView ah=t(album.optString("name","Album"),12.5f,Color.rgb(255,219,112),true);ah.setPadding(dp(6),dp(8),dp(6),0);list.addView(ah,new LinearLayout.LayoutParams(-1,dp(40)));for(int si=0;si<songs.length();si++){JSONObject song=songs.optJSONObject(si);if(song==null||song.optLong("album_id")!=albumId)continue;LinearLayout row=row();row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(9),dp(4),dp(7),dp(4));row.setBackground(bg(Color.argb(125,21,45,99),Color.argb(80,90,210,255),13));LinearLayout meta=col();TextView nm=t(song.optString("title","Track"),10.8f,Color.WHITE,true);nm.setSingleLine(true);meta.addView(nm,new LinearLayout.LayoutParams(-1,dp(23)));TextView ar=t(song.optString("artist","myshop Music"),8.7f,Color.rgb(184,211,245),false);ar.setSingleLine(true);meta.addView(ar,new LinearLayout.LayoutParams(-1,dp(20)));row.addView(meta,new LinearLayout.LayoutParams(0,dp(45),1));Button play=small("PLAY");play.setBackground(gradient(new int[]{Color.rgb(25,142,235),Color.rgb(116,45,226)},Color.rgb(118,235,255),15));row.addView(play,new LinearLayout.LayoutParams(dp(72),dp(40)));play.setOnClickListener(v->{if(rtcManager==null){Toast.makeText(AudioLiveRoomActivity.this,"Live audio is still connecting",Toast.LENGTH_SHORT).show();return;}int rc=rtcManager.startMusic(song.optString("audio_url",""));if(rc==0){musicPlaying=true;musicPaused=false;rtcManager.setMusicVolume(volume.getProgress());state.setText("Music On • "+song.optString("title","Track"));pause.setText("PAUSE");pause.setEnabled(true);stop.setEnabled(true);updateMusicButtonState();}else Toast.makeText(AudioLiveRoomActivity.this,"Music could not start ("+rc+")",Toast.LENGTH_LONG).show();});LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(52));rp.bottomMargin=dp(5);list.addView(row,rp);}}});}public void onError(String m){runOnUiThread(()->{list.removeAllViews();TextView e=t("Music Library unavailable\n"+m,10.5f,Color.rgb(255,151,170),true);e.setGravity(Gravity.CENTER);list.addView(e,new LinearLayout.LayoutParams(-1,dp(90)));});}});
        dialog.setOnShowListener(d->{android.view.Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.94f),-2);}});dialog.show();
    }

    private void updateMusicButtonState(){
        if(musicButton==null)return;musicButton.setText("");musicButton.setBackgroundResource(R.drawable.live_ref_music);musicButton.setAlpha(musicPlaying&&!musicPaused?1f:.94f);
    }

    private void toggleMic(){
        boolean canTalk=host||"SPEAKER".equals(myRole);
        if(!canTalk){
            audienceAudioOn=!audienceAudioOn;
            if(rtcManager!=null)rtcManager.setRemoteAudioEnabled(audienceAudioOn);
            updateLocalMicUi();
            Toast.makeText(this,audienceAudioOn?"Live audio on":"Live audio muted",Toast.LENGTH_SHORT).show();
            return;
        }
        localMicOn=!localMicOn;
        if(!localMicOn)localSpeaking=false;
        try{JSONObject meSeat=findUser(currentSeats,SessionManager.getUserId(this));if(meSeat!=null){meSeat.put("mic_on",localMicOn?1:0);meSeat.put("muted",localMicOn?0:1);}}catch(Exception ignored){}
        updateLocalMicUi();refreshSpeakingAvatars();
        updateVoiceMonitor();
        if(rtcManager!=null)rtcManager.setMicEnabled(localMicOn&&!listenOnly);
        BackendClient.liveParticipantState(token(),hostId,localMicOn,localSpeaking,networkQuality(),true,new ToastCb(localMicOn?"Mic on":"Mic muted"));
    }

    private void updateLocalMicUi(){
        if(micButton==null)return;
        boolean uiOn=(host||"SPEAKER".equals(myRole))?localMicOn:audienceAudioOn;
        micButton.setText("");
        micButton.setCompoundDrawablesWithIntrinsicBounds(0,0,0,0);
        micButton.setBackgroundResource(R.drawable.live_ref_mic);
        micButton.setAlpha(1f);
        if(micMutedMark!=null)micMutedMark.setVisibility(uiOn?View.GONE:View.VISIBLE);
        micButton.setContentDescription(uiOn?((host||"SPEAKER".equals(myRole))?"Microphone on":"Room audio on"):((host||"SPEAKER".equals(myRole))?"Microphone muted":"Room audio muted"));
    }

    private String rtcAudioIndicator(){
        boolean publish=(host||"SPEAKER".equals(myRole))&&!listenOnly;
        long age=System.currentTimeMillis()-activeRtcSpeakerAt;
        if(activeRtcSpeakerUid>0&&age>=0&&age<1800L)return "🔊 Voice receiving";
        if(publish&&localSpeaking)return "🎤 Mic sending";
        if(rtcJoined)return publish?(localMicOn?"🎤 Mic connected":"🎤 Mic muted"):"🔊 Listening";
        return "Audio connecting";
    }
    private void updateLiveStatusLine(){
        String roleText=host?"HOST":(roomAdmin?"ADMIN":myRole);
        if(status!=null)status.setText((host?"Host":(roomAdmin?"🛡 Admin":"🎧 "+myRole))+" • ID "+SessionManager.getUserId(this)+(listenOnly?" • Listen only":"")+" • "+rtcAudioIndicator());
        // V-367: audio state is represented by avatar speaking glow/mic badge, not a separate comment-area strip.
    }

    private void updateVoiceMonitor(){
        boolean publish=(host||"SPEAKER".equals(myRole))&&!listenOnly;
        stopVoiceMonitor(false); // Agora owns microphone capture; never open a competing AudioRecord.
        if(rtcManager!=null){rtcManager.setPublishAudio(publish);rtcManager.setMicEnabled(publish&&localMicOn);}
        if(!publish)localSpeaking=false;
    }

    private void startVoiceMonitor(){ updateVoiceMonitor(); }
    private void stopVoiceMonitor(boolean publish){
        voiceMonitorRunning=false;localSpeaking=false;
        try{if(voiceRecorder!=null){voiceRecorder.stop();voiceRecorder.release();}}catch(Exception ignored){}
        voiceRecorder=null;voiceThread=null;
    }

    private boolean ensureRtcMicPermission(){
        boolean publish=(host||"SPEAKER".equals(myRole))&&!listenOnly;
        if(!publish)return true;
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},9021);
            if(syncState!=null)syncState.setText("● LIVE • Allow microphone to connect audio");
            return false;
        }
        return true;
    }

    private void requestRtcToken(boolean renew){
        if(roomEnded||endLiveInProgress||hostId==null||hostId.isEmpty()||rtcManager==null)return;
        if(!ensureRtcMicPermission())return;
        if(rtcJoinRequested&&!renew)return;
        rtcJoinRequested=true;
        BackendClient.agoraRtcToken(token(),hostId,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                if(roomEnded||endLiveInProgress||isFinishing()||rtcManager==null)return;rtcJoinRequested=false;String t=d.optString("token","");String ch=d.optString("channel","");int uid=d.optInt("uid",0);String role=d.optString("role","AUDIENCE");
                String serverLiveName=d.optString("liveName","").trim();if(!serverLiveName.isEmpty()){currentLiveName=serverLiveName;if(roomTitle!=null)roomTitle.setText("🎙 "+currentLiveName);}
                boolean publish="PUBLISHER".equals(role)&&!listenOnly;rtcRole=role;
                if(renew&&rtcJoined){rtcManager.renewToken(t);rtcManager.setPublishAudio(publish);rtcDiagnosticStatus="Joined";}else{int rc=rtcManager.join(t,ch,uid,publish);rtcDiagnosticStatus=(rc==0?"Connecting…":"Connection failed • retry");}
                // V-392: a user promoted from audience to speaker must switch transport role
                // immediately; token renewal alone is not enough to start microphone publishing.
                rtcManager.setPublishAudio(publish);rtcManager.setMicEnabled(publish&&localMicOn);updateLiveStatusLine();
            });}
            public void onError(String m){rtcJoinRequested=false;runOnUiThread(()->{rtcJoined=false;rtcDiagnosticStatus="RTC token unavailable: "+m;if(syncState!=null)syncState.setText("● LIVE • "+rtcDiagnosticStatus);updateLiveStatusLine();});}
        });
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==9021 && grantResults.length>0 && grantResults[0]==android.content.pm.PackageManager.PERMISSION_GRANTED){updateVoiceMonitor();requestRtcToken(false);}
        else if(requestCode==9021){Toast.makeText(this,"Microphone permission is required to speak in Live",Toast.LENGTH_LONG).show();}
    }

    private void loadLiveUiSettings(){BackendClient.liveUiSettings(token(),new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{joinFontSize=(float)Math.max(14,Math.min(26,o.optDouble("joinFontSize",18)));try{joinTextColor=Color.parseColor(o.optString("joinTextColor","#FFFFFF"));}catch(Exception e){joinTextColor=Color.WHITE;}if(speakerActionButton!=null&&!host){speakerActionButton.setTextSize(Math.max(14f,Math.min(joinFontSize,17f)));speakerActionButton.setTextColor(joinTextColor);}});}public void onError(String m){}});}

    private void loadCommentUi(){BackendClient.liveCommentUi(token(),new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{globalCommentStyle=o.optJSONObject("globalStyle");if(globalCommentStyle==null)globalCommentStyle=new JSONObject();liveCommentFontSize=(float)Math.max(12,Math.min(28,globalCommentStyle.optInt("fontSize",15)));commentPresets.clear();JSONArray p=o.optJSONArray("presets");if(p!=null)for(int i=0;i<p.length();i++){JSONObject x=p.optJSONObject(i);if(x!=null&&!x.optString("presetKey","").isEmpty())commentPresets.put(x.optString("presetKey"),x);}commentAssignments.clear();JSONArray a=o.optJSONArray("assignments");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&x.optBoolean("enabled",true)&&!x.optString("userId","").isEmpty())commentAssignments.put(x.optString("userId"),x);}});}public void onError(String m){}});}
    private JSONObject commentStyleFor(String userId){JSONObject a=commentAssignments.get(userId);if(a!=null){if(a.optBoolean("isCustom",false)){JSONObject c=a.optJSONObject("customStyle");if(c!=null)return c;}String key=a.optString("presetKey","");JSONObject p=commentPresets.get(key);if(p!=null)return p;}return globalCommentStyle==null?new JSONObject():globalCommentStyle;}
    private int commentColor(JSONObject s,String k,int fallback){try{return Color.parseColor(s.optString(k,""));}catch(Exception e){return fallback;}}
    private android.graphics.drawable.Drawable commentStyleDrawable(JSONObject s){int fill=Color.rgb(7,14,38),stroke=Color.TRANSPARENT;int op=Math.max(30,Math.min(100,s.optInt("opacity",92)));fill=Color.argb((int)(255*(op/100f)),Color.red(fill),Color.green(fill),Color.blue(fill));int radius=Math.max(10,Math.min(30,s.optInt("cornerRadius",18))),width=0;android.graphics.drawable.GradientDrawable inner=new android.graphics.drawable.GradientDrawable();inner.setColor(fill);inner.setCornerRadius(dp(radius));if(width>0)inner.setStroke(dp(width),stroke);if(!s.optBoolean("borderGlow",false))return inner;int gc=commentColor(s,"borderGlowColor",Color.rgb(168,85,247)),gi=Math.max(0,Math.min(100,s.optInt("borderGlowIntensity",55)));gc=Color.argb(Math.max(30,(int)(255*(gi/100f))),Color.red(gc),Color.green(gc),Color.blue(gc));android.graphics.drawable.GradientDrawable outer=new android.graphics.drawable.GradientDrawable();outer.setColor(Color.TRANSPARENT);outer.setCornerRadius(dp(radius+3));outer.setStroke(dp(Math.max(2,width+2)),gc);android.graphics.drawable.LayerDrawable layers=new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{outer,inner});layers.setLayerInset(1,dp(3),dp(3),dp(3),dp(3));return layers;}
    private void applyCommentStyle(TextView row,String userId){JSONObject s=commentStyleFor(userId);row.setTextSize((float)Math.max(12,Math.min(28,s.optInt("fontSize",15))));row.setTextColor(commentColor(s,"textColor",Color.WHITE));row.setTypeface(Typeface.DEFAULT,"BOLD".equalsIgnoreCase(s.optString("fontWeight","NORMAL"))?Typeface.BOLD:Typeface.NORMAL);row.setBackground(commentStyleDrawable(s));row.setElevation(dp(s.optBoolean("backgroundGlow",false)?5:1));boolean any=s.optBoolean("animation",false)||s.optBoolean("boxAnimation",false)||s.optBoolean("borderAnimation",false)||s.optBoolean("textAnimation",false)||s.optBoolean("nameAnimation",false)||s.optBoolean("levelAnimation",false);if(any){long d=Math.max(220,1200-(Math.max(10,Math.min(100,s.optInt("animationSpeed",55)))*8L));String type=s.optBoolean("boxAnimation",false)?s.optString("boxAnimationType",s.optString("animationType","FADE")):s.optString("animationType","FADE");android.view.animation.Animation a;if("POP".equalsIgnoreCase(type)){a=new android.view.animation.ScaleAnimation(.92f,1f,.92f,1f,android.view.animation.Animation.RELATIVE_TO_SELF,.5f,android.view.animation.Animation.RELATIVE_TO_SELF,.5f);}else{a=new android.view.animation.AlphaAnimation(.62f,1f);}a.setDuration(d);a.setRepeatMode(android.view.animation.Animation.REVERSE);a.setRepeatCount(1);row.startAnimation(a);if(s.optBoolean("borderAnimation",false))row.animate().translationZ(dp(4)).setDuration(d/2).withEndAction(()->row.animate().translationZ(0).setDuration(d/2).start()).start();}}

    private void showLiveCommentActions(JSONObject comment,String text){String uid=comment.optString("user_id","");java.util.ArrayList<String> actions=new java.util.ArrayList<>();if(canPinComments)actions.add("Pin comment");actions.add("Report comment");new MyShopCompatDialogBuilder(this).setTitle("Comment").setItems(actions.toArray(new String[0]),(d,n)->{if(actions.get(n).equals("Pin comment"))pinCommentText(text);else SafetyActions.show(this,uid,"LIVE_COMMENT",hostId+"/"+activeSessionId+"/"+comment.optLong("id"));}).setNegativeButton("Close",null).show();}
    private void pinCommentText(String text){if(!canPinComments)return;AlertDialog.Builder b=new MyShopCompatDialogBuilder(this).setTitle("📌 Comment options").setMessage(text).setPositiveButton("PIN",(d,w)->BackendClient.livePinnedMessage(token(),hostId,text,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,"Comment pinned",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}})).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Cancel"),null);if(pinnedView!=null&&pinnedView.getVisibility()==View.VISIBLE)b.setNeutralButton("UNPIN",(d,w)->unpinComment());b.show();}
    private void unpinComment(){if(!canPinComments)return;BackendClient.livePinnedMessage(token(),hostId,"",new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{pinnedView.setText("");pinnedView.setVisibility(View.GONE);Toast.makeText(AudioLiveRoomActivity.this,"Comment unpinned",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}});}

    private void editPinned(){LinearLayout form=col();EditText text=new EditText(this);text.setHint("Pinned announcement");EditText minutes=new EditText(this);minutes.setHint("Minutes (0 = until unpinned)");minutes.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);minutes.setText("5");form.addView(text);form.addView(minutes);new MyShopCompatDialogBuilder(this).setTitle("Announcement").setView(form).setPositiveButton("Preview",(d,w)->{int life;try{life=Integer.parseInt(minutes.getText().toString());}catch(Exception e){return;}if(life<0||life>1440){Toast.makeText(this,"Enter 0–1440 minutes",android.widget.Toast.LENGTH_SHORT).show();return;}JSONObject values=new JSONObject();try{values.put("pinnedMessage",text.getText().toString().trim()).put("pinnedMinutes",life);}catch(Exception ignored){}new MyShopCompatDialogBuilder(this).setTitle("Preview announcement").setMessage(text.getText().toString()).setPositiveButton("Publish",(dd,ww)->BackendClient.liveBatchSettings(token(),hostId,values,new ToastCb("Announcement published"))).setNegativeButton("Cancel",null).show();}).setNegativeButton("Close",null).show();}
    private void editRoomInfo(){LinearLayout b=col();EditText t1=new EditText(this);t1.setHint("Live Name");t1.setText(currentLiveName);EditText t2=new EditText(this);t2.setHint("Caption");t2.setText(roomTopic.getText());b.addView(t1);b.addView(t2);TextView note=t("Live Name যেকোনো সময় পরিবর্তন করা যাবে • ID পরিবর্তন হবে না।",10,Color.DKGRAY,false);b.addView(note);new MyShopCompatDialogBuilder(this).setTitle("Live Name & Caption").setView(b).setPositiveButton(UiStrings.label(AudioLiveRoomActivity.this,"Save"),(d,w)->BackendClient.liveRoomConfig(token(),t1.getText().toString(),t2.getText().toString(),null,null,new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,"Live info updated",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String e){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_LONG).show());}})).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Cancel"),null).show();}
    private void editCaptionOnly(){final EditText e=new EditText(this);e.setHint("Caption");e.setSingleLine(true);e.setText(roomTopic.getText());new MyShopCompatDialogBuilder(this).setTitle("Edit Caption").setView(e).setPositiveButton(UiStrings.label(AudioLiveRoomActivity.this,"Save"),(d,w)->BackendClient.liveRoomConfig(token(),null,e.getText().toString(),null,null,new ToastCb("Caption updated"))).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Cancel"),null).show();}

    private void chooseTheme(){BackendClient.liveThemes(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("themes");if(a==null||a.length()==0){Toast.makeText(AudioLiveRoomActivity.this,"No enabled themes",Toast.LENGTH_SHORT).show();return;}String[] names=new String[a.length()];String[] keys=new String[a.length()];for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);names[i]=x==null?"Theme":x.optString("name","Theme");keys[i]=x==null?"GUITAR_BLUE":x.optString("theme_key","GUITAR_BLUE");}new MyShopCompatDialogBuilder(AudioLiveRoomActivity.this).setTitle("Live Theme").setItems(names,(q,which)->BackendClient.liveRoomConfig(token(),null,null,null,keys[which],new ToastCb("Theme changed"))).show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}

    private void shareRoom(){BackendClient.liveShare(token(),hostId,new Silent()); Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,"Join my myshop Audio Live\nhttps://rapid-bush-62ea.myshopsatkania.workers.dev/live?hostId="+android.net.Uri.encode(hostId)+"&sessionId="+android.net.Uri.encode(activeSessionId));startActivity(Intent.createChooser(send,"Share Live"));}

    private void openLiveInbox(){
        Intent i=new Intent(this,InboxActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);startActivity(i);
    }

    private void showReaction(){
        // V-390: reactions are visual overlays only. Never insert a heart into commentsList.
        ViewGroup content=findViewById(android.R.id.content);if(content==null)return;
        final TextView r=t("❤️",30,Color.WHITE,true);r.setGravity(Gravity.CENTER);r.setAlpha(.18f);r.setScaleX(.72f);r.setScaleY(.72f);
        FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(dp(54),dp(54),Gravity.RIGHT|Gravity.BOTTOM);rp.rightMargin=dp(62);rp.bottomMargin=dp(128);content.addView(r,rp);
        r.animate().alpha(1f).scaleX(1.12f).scaleY(1.12f).translationY(-dp(38)).setDuration(280).withEndAction(()->
            r.animate().alpha(0f).scaleX(.92f).scaleY(.92f).translationY(-dp(96)).setDuration(700).withEndAction(()->{try{content.removeView(r);}catch(Exception ignored){}}).start()
        ).start();
    }

    private void showUserModeration(JSONObject u){
        String uid=u.optString("user_id",u.optString("userId",""));if(uid.isEmpty()||uid.equals(hostId))return;
        final boolean canInvite=livePower("invite");
        final boolean canKick=livePower("kick");
        final boolean canBlock=livePower("block");
        final boolean canRoomAdmin=livePower("room_admin");
        java.util.ArrayList<String> actions=new java.util.ArrayList<>();
        if(canInvite)actions.add("📞 Call / Invite to Seat");
        actions.add("🎁 Send Gift");
        actions.add("Open Profile");
        JSONObject seat=findUser(currentSeats,uid);boolean currentlyMuted=u.optInt("muted",0)==1||(seat!=null&&seat.optInt("muted",0)==1);
        if(currentlyMuted&&livePower("unmute"))actions.add("🎙 Unmute");else if(seat!=null&&livePower("mute"))actions.add("🔇 Mute");
        if(canKick)actions.add("Kick from Live");
        if(canBlock)actions.add("Block from this Live");
        if(canRoomAdmin){actions.add("Add as Room Admin");actions.add("Remove Room Admin");}
        actions.add("⚑ Report / Block Account");
        String name=u.optString("full_name","User");
        String info="ID "+uid+"  •  "+(AuthorityBadge.isAuthority(uid)?"Verified":"🏅LV."+u.optInt("level",0))+"\n🪙 Coin  "+compact(u.optLong("coin_balance",0))+"   •   💎 Diamond  "+compact(u.optLong("gold_balance",0));
        new MyShopCompatDialogBuilder(this).setTitle(name).setMessage(info).setItems(actions.toArray(new String[0]),(d,w)->{
            String a=actions.get(w);
            if(a.equals("Open Profile")){openUserProfile(u);return;}
            if(a.startsWith("🎁")){giftReceiverId=uid;giftReceiverName=name;showGiftPanel();return;}
            if(a.startsWith("📞")){inviteToCall(u);return;}
            if(a.startsWith("🎙")){BackendClient.liveModeration(token(),hostId,uid,"UNMUTE",new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,"Mute cleared • speaking restored",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}});return;}
            if(a.startsWith("🔇")){BackendClient.liveModeration(token(),hostId,uid,"MUTE",new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,"Audio muted • comments and call invites stay available",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}});return;}
            if(a.equals("Kick from Live")){BackendClient.liveModeration(token(),hostId,uid,"KICK",new ToastCb("User kicked out"));return;}
            if(a.equals("Block from this Live")){BackendClient.liveModeration(token(),hostId,uid,"BLOCK",new ToastCb("User blocked from Live"));return;}
            if(a.equals("Add as Room Admin")){BackendClient.liveModeration(token(),hostId,uid,"ADD_ROOM_ADMIN",new ToastCb("Live Admin invitation sent"));return;}
            if(a.equals("Remove Room Admin")){BackendClient.liveModeration(token(),hostId,uid,"REMOVE_ROOM_ADMIN",new ToastCb("Room Admin removed"));return;}
            SafetyActions.show(this,uid,"LIVE_USER",hostId);
        }).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Close"),null).show();
    }

    private void prefetchGiftCatalog(){
        if(giftCatalogFetchInFlight)return;giftCatalogFetchInFlight=true;
        BackendClient.liveGifts(token(),new BackendClient.Callback(){
            public void onSuccess(JSONObject o){runOnUiThread(()->{cachedGiftCatalog=o;cachedGiftCatalogAt=System.currentTimeMillis();giftCatalogFetchInFlight=false;if(giftCatalogChanged!=null)giftCatalogChanged.run();});}
            public void onError(String m){runOnUiThread(()->{giftCatalogFetchInFlight=false;if(cachedGiftCatalog==null&&giftCatalogChanged!=null){Toast.makeText(AudioLiveRoomActivity.this,UiStrings.label(AudioLiveRoomActivity.this,"Could not load gifts. Tap to retry."),Toast.LENGTH_LONG).show();}});}
        });
    }
    private Dialog giftDialog613;
    private boolean giftPanelBusy613;
    private void showGiftPanel(){if(giftPanelBusy613||giftDialog613!=null&&giftDialog613.isShowing())return;giftPanelBusy613=true;BackendClient.liveGifts(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{giftPanelBusy613=false;if(isFinishing()||isDestroyed())return;cachedGiftCatalog=d;try{d.put("sessionId",activeSessionId);d.put("selectedRecipient",giftReceiverId);d.put("hostProfile",new JSONObject(cachedHostProfile.toString()));}catch(Exception ignored){}giftDialog613=GiftPanel613.show(AudioLiveRoomActivity.this,hostId,d,currentSeats,currentViewerProfiles,(gift,result)->giftSent613(gift,result));});}public void onError(String m){runOnUiThread(()->{giftPanelBusy613=false;Toast.makeText(AudioLiveRoomActivity.this,m,1).show();});}});}
    private void giftSent613(JSONObject gift,JSONObject d){JSONObject event=new JSONObject();try{JSONObject serverGift=d.optJSONObject("gift");if(serverGift!=null)gift=serverGift;java.util.Iterator<String> keys=gift.keys();while(keys.hasNext()){String key=keys.next();event.put(key,gift.opt(key));}event.put("id",d.optLong("eventId")).put("sender_id",SessionManager.getUserId(this)).put("sender_name",d.optString("senderName",SessionManager.getFullName(this))).put("sender_avatar",d.optString("senderAvatar",SessionManager.getAvatarUrl(this))).put("receiver_id",d.optString("receiverId",hostId)).put("receiver_name",d.optJSONArray("receiverIds")==null?"Host":d.optJSONArray("receiverIds").length()+" recipients").put("quantity",d.optInt("quantity",1)).put("combo",d.optInt("combo",1)).put("price",d.optLong("grossAmount"));JSONArray ids=d.optJSONArray("eventIds");if(ids!=null)for(int i=0;i<ids.length();i++){renderedGiftEventIds.add(ids.optLong(i));renderedGiftEffectIds.add(ids.optLong(i));}showGiftEffect(gift,event);renderGiftActivityComment(event);prefetchGiftCatalog();}catch(Exception e){android.util.Log.w("MYSHOP_GIFT","Display refresh pending");}}
    private void openGiftChart(JSONObject o){
        if(giftStoreDialog!=null&&giftStoreDialog.isShowing())giftStoreDialog.dismiss();
        final JSONArray gifts=new JSONArray();JSONArray initial=o.optJSONArray("gifts");if(initial!=null)for(int i=0;i<initial.length();i++)gifts.put(initial.opt(i));
        final Runnable[] chargePreview={()->{}};
        LinearLayout box=col();box.setPadding(dp(10),dp(8),dp(10),dp(10));box.setBackground(gradient(new int[]{Color.rgb(10,12,34),Color.rgb(31,20,71),Color.rgb(16,18,52)},Color.rgb(121,78,236),22));
        LinearLayout giftHead=row();giftHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=t(UiStrings.label(AudioLiveRoomActivity.this,"🎁  SEND A GIFT"),17,Color.WHITE,true);title.setGravity(Gravity.CENTER);giftHead.addView(title,new LinearLayout.LayoutParams(0,dp(40),1));
        TextView closeGift=t("✕",17,Color.rgb(235,229,255),true);closeGift.setGravity(Gravity.CENTER);closeGift.setBackground(bg(Color.argb(120,79,57,145),Color.argb(180,150,119,240),17));giftHead.addView(closeGift,new LinearLayout.LayoutParams(dp(38),dp(38)));
        box.addView(giftHead,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView sub=t(UiStrings.label(AudioLiveRoomActivity.this,"Choose recipients and quantity"),10,Color.rgb(207,207,239),false);sub.setGravity(Gravity.CENTER);box.addView(sub,new LinearLayout.LayoutParams(-1,dp(21)));
        TextView balance=t("🪙 Coin  "+o.optLong("coinBalance",0)+"      💎 Diamond  "+o.optLong("goldBalance",0),12,Color.WHITE,true);balance.setGravity(Gravity.CENTER);balance.setBackground(bg(Color.argb(130,58,44,130),Color.argb(190,135,92,235),14));box.addView(balance,new LinearLayout.LayoutParams(-1,dp(42)));
        final java.util.LinkedHashSet<String> selectedRecipients=new java.util.LinkedHashSet<>();if(!giftReceiverId.isEmpty()&&!giftReceiverId.equals(SessionManager.getUserId(this)))selectedRecipients.add(giftReceiverId);
        final int[] quantity={1};final String[] pendingNonce={""},pendingSignature={""};
        final TextView receiver=t("🎯 "+giftReceiverName+"  •  Select recipients",11.5f,Color.WHITE,true);receiver.setGravity(Gravity.CENTER);receiver.setBackground(bg(0xff124756,0xff46dcff,12));
        receiver.setOnClickListener(v->{
            java.util.ArrayList<JSONObject> choices=new java.util.ArrayList<>();JSONObject hu=findSeat(currentSeats,1);if(hu!=null&&!hostId.equals(SessionManager.getUserId(this)))choices.add(hu);
            for(int seat=2;seat<=99;seat++){JSONObject user=findSeat(currentSeats,seat);if(user!=null&&!SessionManager.getUserId(this).equals(user.optString("user_id")))choices.add(user);}
            if(choices.isEmpty()){Toast.makeText(this,"No eligible recipient",android.widget.Toast.LENGTH_SHORT).show();return;}
            LinearLayout targetBox=col();targetBox.setPadding(dp(12),dp(8),dp(12),dp(8));java.util.ArrayList<CheckBox> checks=new java.util.ArrayList<>();
            CheckBox all=new CheckBox(this);all.setText("Select all");all.setTextColor(Color.WHITE);targetBox.addView(all);
            for(JSONObject user:choices){CheckBox cb=new CheckBox(this);cb.setText(user.optString("full_name","User")+" • "+user.optString("user_id"));cb.setTextColor(Color.WHITE);cb.setMinHeight(dp(48));cb.setChecked(selectedRecipients.contains(user.optString("user_id")));checks.add(cb);targetBox.addView(cb);}
            all.setOnCheckedChangeListener((button,on)->{for(CheckBox cb:checks)cb.setChecked(on);});ScrollView targets=new ScrollView(this);targets.addView(targetBox);
            new MyShopCompatDialogBuilder(this).setTitle("Gift recipients").setView(targets).setPositiveButton("Select",(d,w)->{java.util.LinkedHashSet<String> next=new java.util.LinkedHashSet<>();for(int i=0;i<checks.size();i++)if(checks.get(i).isChecked())next.add(choices.get(i).optString("user_id"));if(!next.isEmpty()){selectedRecipients.clear();selectedRecipients.addAll(next);giftReceiverId=next.iterator().next();receiver.setText("🎯 "+next.size()+" recipient"+(next.size()>1?"s":"")+" • Change");}}).setNegativeButton("Cancel",null).show();
        });box.addView(receiver,new LinearLayout.LayoutParams(-1,dp(44)));
        TextView qty=t("Quantity  ×1",12.5f,0xffffdd79,true);qty.setGravity(Gravity.CENTER);qty.setBackground(bg(0xff362151,0xffb66dff,12));qty.setContentDescription("Gift quantity per recipient");
        qty.setOnClickListener(v->{String[] numbers={"1","5","6","10","15","20","50","100"};new MyShopCompatDialogBuilder(this).setTitle("Quantity per recipient").setItems(numbers,(d,n)->{quantity[0]=Integer.parseInt(numbers[n]);qty.setText("Quantity  ×"+quantity[0]+(quantity[0]>=5?"  •  COMBO":""));chargePreview[0].run();}).show();});box.addView(qty,new LinearLayout.LayoutParams(-1,dp(44)));

        LinearLayout tabs=row();Button coin=small("🪙 Gift Coin"),gold=small("💎 Diamond");coin.setBackground(bg(Color.rgb(93,53,202),Color.rgb(176,101,255),16));gold.setBackground(bg(Color.rgb(135,89,30),Color.rgb(245,179,60),16));tabs.addView(coin,new LinearLayout.LayoutParams(0,dp(44),1));tabs.addView(gold,new LinearLayout.LayoutParams(0,dp(44),1));box.addView(tabs);

        HorizontalScrollView sc=new HorizontalScrollView(this);sc.setHorizontalScrollBarEnabled(false);sc.setFillViewport(false);final GridLayout grid=new GridLayout(this);grid.setRowCount(2);grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);grid.setPadding(dp(3),dp(7),dp(3),dp(7));sc.addView(grid,new HorizontalScrollView.LayoutParams(-2,-1));box.addView(sc,new LinearLayout.LayoutParams(-1,dp(226)));
        TextView swipeHint=t("←  Swipe left / right for more gifts  →",9.3f,Color.rgb(191,194,231),false);swipeHint.setGravity(Gravity.CENTER);box.addView(swipeHint,new LinearLayout.LayoutParams(-1,dp(24)));
        final Map<ImageView,JSONObject> catalogAnimConfigs=new LinkedHashMap<>();
        final Map<ImageView,TextView> catalogSparkles=new LinkedHashMap<>();

        LinearLayout selectedBar=row();selectedBar.setPadding(dp(10),dp(6),dp(10),dp(6));selectedBar.setBackground(bg(Color.argb(200,30,27,78),Color.rgb(109,79,210),16));
        final TextView selectedText=t(UiStrings.label(AudioLiveRoomActivity.this,"Select a gift"),11.5f,Color.WHITE,true);selectedText.setGravity(Gravity.CENTER_VERTICAL);selectedBar.addView(selectedText,new LinearLayout.LayoutParams(0,dp(52),1));
        final Button sendButton=small(UiStrings.label(AudioLiveRoomActivity.this,"SEND"));sendButton.setEnabled(false);sendButton.setAlpha(.48f);sendButton.setTextSize(12);sendButton.setBackground(gradient(new int[]{Color.rgb(238,63,153),Color.rgb(116,75,239)},Color.rgb(255,180,225),18));selectedBar.addView(sendButton,new LinearLayout.LayoutParams(dp(104),dp(48)));box.addView(selectedBar,new LinearLayout.LayoutParams(-1,dp(60)));

        final boolean[] favoritesOnly={false};final String[] currency={"COIN"};final JSONObject[] chosen={null};final View[] chosenTile={null};
        chargePreview[0]=()->{JSONObject gift=chosen[0];if(gift==null)return;boolean goldCurrency="GOLD".equals(currency[0]);JSONObject config=cachedGiftCatalog==null?o:cachedGiftCatalog;long perRecipient=Math.max(1,gift.optLong("price",1))*quantity[0],base=perRecipient*selectedRecipients.size(),official=config.optBoolean("authority")?base:config.optLong(goldCurrency?"officialGoldBalance":"officialCoinBalance",0),commission=0;double rate=config.optDouble(goldCurrency?"goldCommissionPercent":"coinCommissionPercent",goldCurrency?5:10);for(String recipient:selectedRecipients){long covered=Math.min(perRecipient,official);official-=covered;commission+=Math.round((perRecipient-covered)*rate/100d);}selectedText.setText("Gift "+base+" + Commission "+commission+"\nTotal "+(base+commission)+" "+currency[0]);};

        final Runnable[] renderHolder=new Runnable[1];
        renderHolder[0]=()->{
            for(ImageView oldArt:catalogAnimConfigs.keySet())CatalogGiftAnimator.stop(oldArt,catalogSparkles.get(oldArt));
            catalogAnimConfigs.clear();catalogSparkles.clear();grid.removeAllViews();chosen[0]=null;chosenTile[0]=null;sendButton.setEnabled(false);sendButton.setAlpha(.48f);sendButton.setText(UiStrings.label(AudioLiveRoomActivity.this,"SEND"));selectedText.setText(UiStrings.label(AudioLiveRoomActivity.this,"Select a gift"));
            boolean isCoin="COIN".equals(currency[0]);coin.setAlpha(isCoin?1f:.55f);gold.setAlpha(isCoin ? .55f : 1f);
            int count=0;
            for(int i=0;i<gifts.length();i++){
                final JSONObject g=gifts.optJSONObject(i);if(g==null||!currency[0].equals(g.optString("currency"))||(favoritesOnly[0]&&!AccountPreferences.get(this,"favorite_gifts").getBoolean(String.valueOf(g.optLong("id")),false)))continue;count++;
                final LinearLayout tile=col();tile.setGravity(Gravity.CENTER);tile.setPadding(dp(5),dp(5),dp(5),dp(5));tile.setBackground(giftTileBg(false,"GOLD".equals(currency[0])));tile.setElevation(dp(1));
                FrameLayout iconBox=new FrameLayout(this);iconBox.setClipChildren(false);tile.setClipChildren(false);ImageView icon=new ImageView(this);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                String catalogAsset=g.optString("catalog_animation_url","").trim();String preview=g.optString("preview_url","").trim();if(preview.isEmpty())preview=g.optString("animation_url","").trim();
                if(!catalogAsset.isEmpty())AnimatedAssetLoader.load(icon,catalogAsset,false);else if(!preview.isEmpty())loadImage(icon,preview);else icon.setImageResource(builtInGiftArt(g.optString("name","Gift")));
                int previewDp=CatalogGiftAnimator.iconDp(g);FrameLayout.LayoutParams iconLp=new FrameLayout.LayoutParams(dp(previewDp),dp(previewDp),Gravity.CENTER);iconBox.addView(icon,iconLp);
                TextView sparkle=t("✦   ✧",12,Color.rgb(255,226,118),true);sparkle.setGravity(Gravity.CENTER);sparkle.setAlpha(.12f);iconBox.addView(sparkle,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));tile.addView(iconBox,new LinearLayout.LayoutParams(-1,dp(54)));
                catalogAnimConfigs.put(icon,g);catalogSparkles.put(icon,sparkle);
                TextView nm=t(g.optString("name","Gift"),9.6f,Color.WHITE,true);nm.setGravity(Gravity.CENTER);nm.setMaxLines(1);tile.addView(nm,new LinearLayout.LayoutParams(-1,dp(22)));
                TextView pr=t(("GOLD".equals(currency[0])?"👑 ":"🪙 ")+g.optInt("price",1),10.0f,Color.rgb(255,219,91),true);pr.setGravity(Gravity.CENTER);tile.addView(pr,new LinearLayout.LayoutParams(-1,dp(21)));
                tile.setOnLongClickListener(v->{String key=String.valueOf(g.optLong("id"));boolean on=!AccountPreferences.get(this,"favorite_gifts").getBoolean(key,false);AccountPreferences.get(this,"favorite_gifts").edit().putBoolean(key,on).apply();Toast.makeText(this,on?"Gift saved to favourites":"Gift removed from favourites",android.widget.Toast.LENGTH_SHORT).show();return true;});
                tile.setOnClickListener(v->{
                    if(chosenTile[0]!=null)chosenTile[0].setBackground(giftTileBg(false,"GOLD".equals(currency[0])));
                    chosen[0]=g;chosenTile[0]=tile;tile.setBackground(giftTileBg(true,"GOLD".equals(currency[0])));tile.animate().scaleX(1.045f).scaleY(1.045f).setDuration(100).withEndAction(()->tile.animate().scaleX(1f).scaleY(1f).setDuration(100).start()).start();
                    chargePreview[0].run();sendButton.setEnabled(true);sendButton.setAlpha(1f);sendButton.setText(UiStrings.label(AudioLiveRoomActivity.this,"SEND"));
                });
                int slot=count-1;GridLayout.LayoutParams gp=new GridLayout.LayoutParams();gp.width=dp(94);gp.height=dp(102);gp.rowSpec=GridLayout.spec(slot%2);gp.columnSpec=GridLayout.spec(slot/2);gp.setMargins(dp(3),dp(3),dp(3),dp(3));grid.addView(tile,gp);
            }
            if(count==0){TextView empty=t(cachedGiftCatalog==null?UiStrings.label(AudioLiveRoomActivity.this,"Loading gifts…"):UiStrings.label(AudioLiveRoomActivity.this,"No published gifts in this catalog."),11,Color.rgb(200,202,229),false);empty.setGravity(Gravity.CENTER);empty.setOnClickListener(v->prefetchGiftCatalog());grid.addView(empty,new GridLayout.LayoutParams(GridLayout.spec(0),GridLayout.spec(0,3)));}
            sc.post(()->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles));
            sc.postDelayed(()->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles),650L);
        };
        Button favorites=small("⭐ Favourites");tabs.addView(favorites,new LinearLayout.LayoutParams(0,dp(44),1));favorites.setOnClickListener(v->{favoritesOnly[0]=!favoritesOnly[0];favorites.setText(favoritesOnly[0]?"⭐ Show all":"⭐ Favourites");renderHolder[0].run();});
        sc.setOnScrollChangeListener((v,sx,sy,ox,oy)->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles));
        coin.setOnClickListener(v->{currency[0]="COIN";renderHolder[0].run();});gold.setOnClickListener(v->{currency[0]="GOLD";renderHolder[0].run();});
        sendButton.setOnClickListener(v->{
            chargePreview[0].run();final JSONObject gift=chosen[0];if(gift==null)return;if(selectedRecipients.isEmpty()){Toast.makeText(this,UiStrings.label(AudioLiveRoomActivity.this,"Select recipients"),Toast.LENGTH_SHORT).show();return;}sendButton.setEnabled(false);sendButton.setText("SENDING…");
            final long giftId=gift.optLong("id");final String signature=giftId+"/"+quantity[0]+"/"+selectedRecipients.toString();if(!signature.equals(pendingSignature[0])){pendingSignature[0]=signature;pendingNonce[0]="gift-"+UUID.randomUUID();}final String nonce=pendingNonce[0];
            final String receiverId=giftReceiverId; final String receiverName=giftReceiverName; final JSONObject localGift=gift; BackendClient.liveGiftSend(token(),hostId,new JSONArray(selectedRecipients),giftId,quantity[0],nonce,new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->{
                    if(giftStoreDialog!=null&&giftStoreDialog.isShowing())giftStoreDialog.dismiss();giftStoreDialog=null;
                    long sentEventId=d.optLong("eventId",0);JSONObject serverGift=d.optJSONObject("gift");final JSONObject effectGift=serverGift==null?gift:serverGift;
                    JSONObject localGiftEvent=new JSONObject();try{
                        localGiftEvent.put("id",sentEventId).put("sender_id",SessionManager.getUserId(AudioLiveRoomActivity.this)).put("sender_name",d.optString("senderName",SessionManager.getFullName(AudioLiveRoomActivity.this))).put("sender_avatar",d.optString("senderAvatar",SessionManager.getAvatarUrl(AudioLiveRoomActivity.this))).put("sender_level",d.optInt("senderLevel",myLevel)).put("receiver_id",d.optString("receiverId",hostId)).put("receiver_name",receiverName==null||receiverName.trim().isEmpty()?currentLiveName:receiverName).put("name",effectGift.optString("name","Gift")).put("currency",effectGift.optString("currency","COIN")).put("price",effectGift.optInt("price",d.optInt("grossAmount",1))).put("combo",Math.max(1,d.optInt("combo",1))).put("preview_url",effectGift.optString("preview_url","")).put("animation_url",effectGift.optString("animation_url",""));
                    }catch(Exception ignored){}
                    try{localGiftEvent.put("quantity",d.optInt("quantity",1));}catch(Exception ignored){}
                    if(!d.optBoolean("duplicateSuppressed",false))showGiftEffect(effectGift,localGiftEvent);
                    renderGiftActivityComment(localGiftEvent);
                    if(sentEventId>0){renderedGiftEventIds.add(sentEventId);renderedGiftEffectIds.add(sentEventId);}
                    if(giftStoreDialog!=null&&giftStoreDialog.isShowing())giftStoreDialog.dismiss();giftStoreDialog=null;
                    prefetchGiftCatalog();
                });}
                public void onError(String m){runOnUiThread(()->{sendButton.setEnabled(true);sendButton.setAlpha(1f);sendButton.setText(UiStrings.label(AudioLiveRoomActivity.this,"SEND"));Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show();});}
            });
        });
        giftCatalogChanged=()->{if(cachedGiftCatalog==null)return;JSONArray fresh=cachedGiftCatalog.optJSONArray("gifts");while(gifts.length()>0)gifts.remove(gifts.length()-1);if(fresh!=null)for(int i=0;i<fresh.length();i++)gifts.put(fresh.opt(i));balance.setText("🪙 Coin  "+cachedGiftCatalog.optLong("coinBalance",0)+"      💎 Diamond  "+cachedGiftCatalog.optLong("goldBalance",0));renderHolder[0].run();};
        renderHolder[0].run();
        giftStoreDialog=new MyShopCompatDialogBuilder(this).setView(box).create();
        closeGift.setOnClickListener(v->{if(giftStoreDialog!=null&&giftStoreDialog.isShowing())giftStoreDialog.dismiss();});
        giftStoreDialog.setOnDismissListener(d->{for(ImageView art:catalogAnimConfigs.keySet())CatalogGiftAnimator.stop(art,catalogSparkles.get(art));catalogAnimConfigs.clear();catalogSparkles.clear();giftCatalogChanged=null;giftStoreDialog=null;});
        giftStoreDialog.setOnShowListener(d->{android.view.Window w=giftStoreDialog.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(0f);w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.94f),-2);}});
        giftStoreDialog.show();
        sc.postDelayed(()->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles),150L);
        sc.postDelayed(()->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles),1300L);
        sc.postDelayed(()->updateCatalogPreviewAnimations(sc,catalogAnimConfigs,catalogSparkles),3200L);
    }

    private void updateCatalogPreviewAnimations(View sc,Map<ImageView,JSONObject> configs,Map<ImageView,TextView> sparkles){
        if(sc==null||configs==null)return;Rect scrollRect=new Rect();boolean scrollVisible=sc.getGlobalVisibleRect(scrollRect);
        for(Map.Entry<ImageView,JSONObject> e:configs.entrySet()){
            ImageView art=e.getKey();if(art==null)continue;Rect artRect=new Rect();boolean visible=scrollVisible&&art.getGlobalVisibleRect(artRect)&&Rect.intersects(scrollRect,artRect);
            if(visible)CatalogGiftAnimator.start(art,sparkles.get(art),e.getValue());else CatalogGiftAnimator.stop(art,sparkles.get(art));
        }
    }

    private android.graphics.drawable.GradientDrawable giftTileBg(boolean selected,boolean gold){
        int[] colors=gold?new int[]{Color.rgb(58,39,76),Color.rgb(95,59,45)}:new int[]{Color.rgb(31,29,78),Color.rgb(63,38,110)};
        int stroke=selected?(gold?Color.rgb(255,213,89):Color.rgb(255,102,214)):(gold?Color.rgb(181,132,65):Color.rgb(101,83,191));
        return gradient(colors,stroke,16);
    }

    private void renderLocalSkeleton(){renderHost(null);renderAudience(null,0);renderSpecialGuest(null);renderSeats(null);}

    private boolean composerKeyboardOpen=false;
    private int inactiveRoomResponses=0;
    private void refresh(){if(isFinishing()||isDestroyed()||roomEnded||endLiveInProgress||refreshInFlight)return;refreshInFlight=true;BackendClient.liveRoomState(token(),hostId,new BackendClient.Callback(){@Override public void onSuccess(JSONObject d){runOnUiThread(()->{refreshInFlight=false;inactiveRoomResponses=0;if(roomEnded||endLiveInProgress)return;syncState.setText("● LIVE • "+rtcDiagnosticStatus+" • "+networkQuality());render(d);});}@Override public void onError(String m){runOnUiThread(()->{refreshInFlight=false;if(roomEnded)return;if(endLiveInProgress){syncState.setText("Ending live…");return;}if(!host && m!=null && m.contains("LIVE_NOT_ACTIVE")){if(getIntent().getBooleanExtra("fromNotification",false)&&activeSessionId.isEmpty()){roomEnded=true;new MyShopCompatDialogBuilder(AudioLiveRoomActivity.this).setTitle("Live ended").setMessage("This room is no longer Live.").setPositiveButton("Close",(dd,ww)->finish()).setOnDismissListener(dd->{if(!isFinishing())finish();}).show();return;}if(++inactiveRoomResponses<2){syncState.setText("Checking room status…");return;}handler.removeCallbacks(tick);handler.removeCallbacks(realtimeTick);handler.removeCallbacks(presenceTick);handler.removeCallbacks(participantTick);showAudienceEndSummary();return;}syncState.setText("● LIVE • Weak network • Reconnecting…");if(seats.getChildCount()==0)renderLocalSkeleton();});}});}

    private void render(JSONObject d){
        if(!host&&!visitReady)return;
        String shared=getIntent().getStringExtra("sharedSessionId");JSONObject sharedMeta=d.optJSONObject("meta");String actual=d.optString("sessionId",sharedMeta==null?"":sharedMeta.optString("session_id",""));if(shared!=null&&!shared.equals(actual)){roomEnded=true;new MyShopCompatDialogBuilder(this).setTitle("লাইভ শেষ হয়েছে").setMessage("শেয়ার করা এই লাইভটি শেষ হয়েছে।").setPositiveButton("বন্ধ করুন",(dialog,w)->finish()).setOnDismissListener(dialog->finish()).show();return;}

        int vc=d.optInt("viewerCount",0),peak=d.optInt("peakViewers",0); currentViewerCount=vc; currentPeakViewers=peak; currentTotalListeners=d.optInt("totalListeners",0); viewers.setText("");
        giftSoundEnabled613=d.optBoolean("giftSoundEnabled",true);if(!giftSoundEnabled613)stopGiftSounds613();String previousRtcRole=myRole; myRole=d.optString("myRole",host?"HOST":"AUDIENCE"); if(!myRole.equals(previousRtcRole))requestRtcToken(true); myLevel=Math.max(0,d.optInt("myLevel",myLevel)); roomAdmin=d.optBoolean("myRoomAdmin",false); livePermissions=d.optJSONObject("livePermissions");if(livePermissions==null)livePermissions=new JSONObject(); canSuggestCall=d.optBoolean("canSuggestCall",host||roomAdmin||SessionManager.isAdmin(this)||SessionManager.isModerator(this)); canPinComments=d.optBoolean("canPinComments",false); String sanction=d.optString("mySanction","NONE"); listenOnly="MUTED".equals(sanction); if(musicButton!=null)musicButton.setVisibility((host||roomAdmin||SessionManager.isAdmin(this)||SessionManager.isModerator(this))?View.VISIBLE:View.INVISIBLE); if("BLOCKED".equals(sanction)||"KICKED".equals(sanction)){Toast.makeText(this,"You were removed from this live",Toast.LENGTH_SHORT).show();leaveAudienceLive();return;} updateVoiceMonitor(); updateLiveStatusLine(); updateLocalMicUi();
        specialGuestId=d.optString("specialGuestId",""); shareCount=d.optInt("shareCount",0); shareView.setText("↗ "+shareCount);
        currentLiveName=d.optString("title","Host"); roomTitle.setText(currentLiveName); String cap=d.optString("topic","").trim(); roomTopic.setText(cap.isEmpty()?"Add caption":cap); reactCount=android.os.SystemClock.elapsedRealtime()-reactionAckAt<4000?Math.max(reactCount,d.optLong("reactCount",0)):d.optLong("reactCount",0); voteCount=d.optLong("voteCount",0);
        String welcome=d.optString("welcomeMessage","").trim();String ruleKey=hostId+"/"+activeSessionId;if(!welcome.isEmpty()&&!AccountPreferences.get(this,"room_rules").getBoolean(ruleKey,false)){AccountPreferences.get(this,"room_rules").edit().putBoolean(ruleKey,true).apply();showFloatingBanner("📋 "+welcome);}
        String pin=d.optString("pinnedMessage","").trim(); if(pin.isEmpty()){pinnedView.setText("");pinnedView.setVisibility(View.GONE);}else{pinnedView.setText("📌  "+pin);pinnedView.setVisibility(View.VISIBLE);}
        String sid=d.optString("sessionId","");long elapsed=Math.max(0,d.optLong("elapsedSeconds",0));long parsed=parseServerTime(d.optString("startedAt",""));
        if(!sid.equals(activeSessionId)){clearSessionEffects();activeSessionId=sid;serverElapsedSec=elapsed;serverElapsedSyncMs=System.currentTimeMillis();startedAtMs=parsed;pendingComments.clear();shownMilestones.clear();entryQueue.clear();lastEntryEventId=0L;lastGiftEventId=0L;lastRealtimeCommentId=0L;lastRealtimeHighlightId=0L;realtimeRevision=0;realtimeFailures=0;renderedGiftEventIds.clear();renderedGiftEffectIds.clear();renderedCommentIds.clear();renderedRoomEventIds.clear();renderedHighlightCommentIds.clear();shownPremiumEntrances.clear();commentsList.removeAllViews();giftPollInFlight=false;}else{serverElapsedSec=elapsed;serverElapsedSyncMs=System.currentTimeMillis();if(parsed>0)startedAtMs=parsed;}
        checkCelebrations(d);renderPremiumState(d);renderPinnedProduct(d.optJSONObject("pinnedProduct"));
        renderLivePoll(d.optJSONObject("poll"));
        lockedSeats.clear();JSONArray locks=d.optJSONArray("lockedSeats");if(locks!=null)for(int i=0;i<locks.length();i++)lockedSeats.add(locks.optInt(i));
        hostFollowing=d.optBoolean("hostFollowing",hostFollowing);
        String previousTop1=top1Id();
        currentHostStats=d.optJSONObject("hostStats"); if(currentHostStats==null)currentHostStats=new JSONObject(); currentTopSupporters=d.optJSONArray("topSupporters"); if(currentTopSupporters==null)currentTopSupporters=new JSONArray(); if(!previousTop1.equals(top1Id()))refreshMembershipComments();
        JSONArray a=d.optJSONArray("seats"); currentSeats=a==null?new JSONArray():a; currentSeatNo=0; JSONObject meSeat=findUser(currentSeats,SessionManager.getUserId(this)); if(meSeat!=null){currentSeatNo=meSeat.optInt("seat_no",0);if(!host&&"SPEAKER".equals(myRole)){boolean serverMicOn=meSeat.optInt("mic_on",1)==1&&meSeat.optInt("muted",0)!=1;if(localMicOn!=serverMicOn){localMicOn=serverMicOn;if(!localMicOn)localSpeaking=false;if(rtcManager!=null)rtcManager.setMicEnabled(localMicOn&&!listenOnly);updateLocalMicUi();}}} updateSpeakerControls(); renderHost(findSeat(a,1));renderAudience(d.optJSONArray("viewerProfiles"),vc);renderSpecialGuest(findUser(a,specialGuestId));renderSeats(a);
        currentRequests=d.optJSONArray("requests")==null?new JSONArray():d.optJSONArray("requests");currentCallSuggestions=d.optJSONArray("callSuggestions")==null?new JSONArray():d.optJSONArray("callSuggestions");
        pendingRequestCount=Math.max(0,d.optInt("requestCount",currentRequests.length()));
        String serverRequestStatus=d.optString("myRequestStatus","NONE");if(!joinRequestInFlight||!"NONE".equalsIgnoreCase(serverRequestStatus))myRequestStatus=serverRequestStatus;
        if(host&&requests!=null){renderRequests(currentRequests);notifyHostOfNewRequest(currentRequests);if((currentRequests==null||currentRequests.length()==0)&&currentCallSuggestions.length()>0)notifyHostOfCallSuggestion(currentCallSuggestions);}
        updateSpeakerControls();
        JSONArray highlights=d.optJSONArray("highlightComments");JSONArray giftEvents=d.optJSONArray("giftEvents");renderComments(d.optJSONArray("comments"),d.optJSONArray("events"),highlights);renderGiftActivityEventsOnly(giftEvents);renderHighlightComments(highlights);renderGiftEffectsOnly(giftEvents);
        if(!host){showIncomingInvite(d.optJSONObject("incomingInvite"));showIncomingAdminInvite(d.optJSONObject("incomingAdminInvite"));}
        JSONObject theme=d.optJSONObject("theme"); if(theme!=null){String mode=theme.optString("fit_mode","CENTER_CROP");if("FIT".equalsIgnoreCase(mode))wallpaper.setScaleType(ImageView.ScaleType.FIT_CENTER);else if("FILL".equalsIgnoreCase(mode))wallpaper.setScaleType(ImageView.ScaleType.FIT_XY);else wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);String bg=theme.optString("background_url",""),themeKey=theme.optString("theme_key","");if(!bg.trim().isEmpty())loadImage(wallpaper,bg);else if(themeKey.toUpperCase(Locale.US).startsWith("WALLPAPER_"))wallpaper.setImageDrawable(new PremiumWallpaperDrawable(themeKey+"|"+theme.optString("name","myshop")));else wallpaper.setImageResource(R.drawable.live_room_default_wallpaper);}
    }

    private String hostVisualKey="",seatVisualKey="",specialVisualKey="";
    private String portraitKey(JSONObject x){if(x==null)return "empty";return x.optString("user_id","")+":"+x.optString("full_name","")+":"+x.optString("avatar_url","")+":"+identityTier(x)+":"+x.optString("membership_frame_url","")+":"+x.optString("frame_url","")+":"+x.optInt("level",0)+":"+x.optInt("mic_on",1)+":"+x.optInt("muted",0);}
    private void renderHost(JSONObject x){
        if(x!=null){try{if(!x.optString("user_id","").isEmpty())cachedHostProfile.put("user_id",x.optString("user_id"));if(!x.optString("full_name","").isEmpty())cachedHostProfile.put("full_name",x.optString("full_name"));if(!x.optString("avatar_url","").isEmpty())cachedHostProfile.put("avatar_url",x.optString("avatar_url"));for(String k:new String[]{"mic_on","muted","speaking","level","coin_balance","gold_balance","stars","tier","frame_url","membership_frame_url"})if(x.has(k))cachedHostProfile.put(k,x.opt(k));}catch(Exception ignored){}}
        JSONObject hostDisplay=cachedHostProfile.length()>0?cachedHostProfile:x;
        if(hostDisplay==null&&host){hostDisplay=new JSONObject();try{hostDisplay.put("user_id",SessionManager.getUserId(this));hostDisplay.put("full_name",SessionManager.getFullName(this));hostDisplay.put("avatar_url",SessionManager.getAvatarUrl(this));hostDisplay.put("mic_on",localMicOn?1:0);cachedHostProfile=hostDisplay;}catch(Exception ignored){}}
        String visual=activeSessionId+portraitKey(hostDisplay)+currentLiveName+hostFollowing+currentHostStats.optLong("coinBalance",0)+":"+currentHostStats.optLong("goldBalance",0)+":"+voteCount;if(visual.equals(hostVisualKey)&&hostArea.getChildCount()>0){refreshSpeakingAvatars();return;}hostVisualKey=visual;hostArea.removeAllViews();LinearLayout top=row();top.setGravity(Gravity.CENTER_VERTICAL);
        boolean speaking=hostDisplay!=null&&hostDisplay.optInt("speaking",0)==1;speaking=speaking||isRtcSpeaking(hostDisplay,true);
        FrameLayout av=avatarWithMicState(hostDisplay,dp(56),speaking);top.addView(av,new LinearLayout.LayoutParams(dp(56),dp(56)));
        String id=hostDisplay==null?hostId:hostDisplay.optString("user_id",hostId);
        String liveName=currentLiveName==null||currentLiveName.trim().isEmpty()?(hostDisplay==null?"Host":hostDisplay.optString("full_name","Host")):currentLiveName;
        String hostName=liveName;
        if(hostName==null||hostName.trim().isEmpty())hostName=SessionManager.getFullName(this);
        if(hostName==null||hostName.trim().isEmpty())hostName="myshop User";
        LinearLayout hostIdentity=col();hostIdentity.setPadding(dp(6),0,dp(2),0);
        LeftToRightTicker hostNameView=new LeftToRightTicker(this);hostNameView.setText(hostName);hostNameView.setTextSize(11.8f);hostNameView.setTextColor(Color.WHITE);hostNameView.setTypeface(Typeface.DEFAULT,Typeface.BOLD);hostNameView.setSingleLine(true);hostNameView.setContentDescription("Host name: "+hostName);hostIdentity.addView(hostNameView,new LinearLayout.LayoutParams(-1,dp(25)));
        LinearLayout idLine=row();idLine.setGravity(Gravity.CENTER_VERTICAL);TextView idView=t("LV."+(hostDisplay==null?0:hostDisplay.optInt("level",0)),10.2f,Color.rgb(231,235,255),true);if(AuthorityBadge.isAuthority(hostId))idView.setText("ID "+hostId);AuthorityBadge.decorate(hostNameView,hostId);idView.setSingleLine(true);idView.setEllipsize(android.text.TextUtils.TruncateAt.END);idLine.addView(idView,new LinearLayout.LayoutParams(0,dp(24),1));
        if(!SessionManager.getUserId(this).equals(id)){TextView followPlus=t(hostFollowing?"✓":"+",14.8f,Color.WHITE,true);followPlus.setGravity(Gravity.CENTER);followPlus.setContentDescription(hostFollowing?"Following host":"Follow host");followPlus.setBackground(gradient(hostFollowing?new int[]{Color.rgb(8,145,111),Color.rgb(22,201,160)}:new int[]{Color.rgb(124,44,244),Color.rgb(39,132,255),Color.rgb(18,214,228)},hostFollowing?Color.rgb(137,255,218):Color.rgb(149,236,255),12));followPlus.setElevation(dp(4));followPlus.setOnClickListener(v->{followPlus.setEnabled(false);BackendClient.toggleFollow(token(),id,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{hostFollowing=d.optBoolean("following",!hostFollowing);followPlus.setText(hostFollowing?"✓":"+");followPlus.setContentDescription(hostFollowing?"Following host":"Follow host");followPlus.setEnabled(true);refresh();});}public void onError(String m){runOnUiThread(()->{followPlus.setEnabled(true);Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show();});}});});LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(dp(28),dp(24));fp.leftMargin=dp(6);idLine.addView(followPlus,fp);}
        hostIdentity.addView(idLine,new LinearLayout.LayoutParams(-1,dp(29)));
        View.OnClickListener hostSummaryClick=v->showRunningLiveSummary();av.setClickable(true);av.setFocusable(true);av.setOnClickListener(hostSummaryClick);PremiumUi.press(av);hostIdentity.setClickable(true);hostIdentity.setFocusable(true);hostIdentity.setOnClickListener(hostSummaryClick);PremiumUi.press(hostIdentity);
        top.addView(hostIdentity,new LinearLayout.LayoutParams(dp(88),dp(52)));
        if(audienceScroll.getParent()!=null)((android.view.ViewGroup)audienceScroll.getParent()).removeView(audienceScroll);top.addView(audienceScroll,new LinearLayout.LayoutParams(0,dp(58),1));
        onlineCountView=t("✕",22f,Color.WHITE,true);onlineCountView.setGravity(Gravity.CENTER);onlineCountView.setBackgroundColor(Color.TRANSPARENT);onlineCountView.setContentDescription(host?"End Live":"Leave Live");onlineCountView.setOnClickListener(v->{if(host)confirmEndLive();else leaveAudienceLive();});top.addView(onlineCountView,new LinearLayout.LayoutParams(dp(48),dp(48)));
        hostArea.addView(top,new LinearLayout.LayoutParams(-1,dp(62)));
        long coin=currentHostStats.optLong("coinBalance",hostDisplay==null?0:hostDisplay.optLong("coin_balance",0)),gold=currentHostStats.optLong("goldBalance",hostDisplay==null?0:hostDisplay.optLong("gold_balance",0));
        LinearLayout stats=row();stats.setGravity(Gravity.CENTER_VERTICAL);stats.setPadding(dp(8),0,dp(8),0);
        int[] statIcons={R.drawable.premium438_coins,R.drawable.live_stat_gold,R.drawable.live_stat_vote};
        String[] statValues={compact(coin),compact(gold),compact(voteCount)};
        for(int i=0;i<statValues.length;i++){
            LinearLayout item=row();item.setGravity(Gravity.CENTER);ImageView icon=new ImageView(this);icon.setImageResource(statIcons[i]);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);int iconSize=i==2?dp(19):dp(25);item.addView(icon,new LinearLayout.LayoutParams(iconSize,iconSize));
            TextView number=t(statValues[i],12.1f,i==2?0xffffd85a:Color.WHITE,true);number.setGravity(Gravity.CENTER_VERTICAL);number.setSingleLine(true);item.addView(number,new LinearLayout.LayoutParams(-2,dp(30)));stats.addView(item,new LinearLayout.LayoutParams(-2,dp(34)));View gap=new View(this);stats.addView(gap,new LinearLayout.LayoutParams(0,1,1));
        }
        long elapsedNow=!activeSessionId.isEmpty()?Math.max(0,serverElapsedSec+(System.currentTimeMillis()-serverElapsedSyncMs)/1000L):0;
        durationView=t("● "+hhmmss(elapsedNow),10.2f,Color.rgb(255,62,93),true);durationView.setGravity(Gravity.CENTER);durationView.setSingleLine(true);durationView.setContentDescription("Live duration");if(host)durationView.setOnClickListener(v->showRunningLiveSummary());
        stats.addView(durationView,new LinearLayout.LayoutParams(-2,dp(34)));
        hostArea.addView(stats,new LinearLayout.LayoutParams(-1,dp(36)));
        if(reactCountLabel!=null)reactCountLabel.setText(compact(reactCount));
    }

    private LinearLayout.LayoutParams statLp(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(45),1);p.setMargins(dp(1),0,dp(1),0);return p;}
    private TextView statPill(String label,String value,int accent){TextView v=t(label+"\n"+value,10.8f,Color.WHITE,true);v.setGravity(Gravity.CENTER);v.setBackgroundColor(Color.TRANSPARENT);return v;}

    private void renderAudience(JSONArray a,int total){
        currentViewerProfiles=a==null?new JSONArray():a; currentViewerCount=total;
        StringBuilder signature=new StringBuilder().append(total).append(':').append(host).append(roomAdmin).append(canSuggestCall);
        for(int i=0;i<currentViewerProfiles.length();i++){JSONObject u=currentViewerProfiles.optJSONObject(i);if(u!=null)signature.append('|').append(u.optString("user_id",u.optString("userId",""))).append(':').append(identityTier(u)).append(':').append(u.optString("avatar_url","")).append(':').append(u.optString("membership_frame_url","")).append(':').append(u.optString("frame_url","")).append(':').append(u.optInt("supporterRank",0)).append(':').append(u.optString("full_name",""));}
        if(signature.toString().equals(audienceVisualSignature)&&audienceRow.getChildCount()>0)return;
        audienceVisualSignature=signature.toString();audienceRow.removeAllViews(); audienceRow.setGravity(Gravity.CENTER_VERTICAL); audienceRow.setPadding(0,0,0,0);
        java.util.Set<String> present=new java.util.HashSet<>();for(int i=0;i<currentViewerProfiles.length();i++){JSONObject u=currentViewerProfiles.optJSONObject(i);if(u!=null)present.add(u.optString("user_id",u.optString("userId","")));}
        shownPremiumEntrances.removeIf(key->!present.contains(key.substring(key.indexOf(':')+1)));
        int maxAvatars=20;
        int visible=0;
        for(int i=0;i<currentViewerProfiles.length()&&visible<maxAvatars;i++){
            JSONObject u=currentViewerProfiles.optJSONObject(i); if(u==null)continue;
            // Missing photos still render a fallback avatar; never hide active viewers.
            String viewerTier=identityTier(u);
            FrameLayout av=circleAvatar(u.optString("avatar_url",""),dp(56),false,viewerTier,MembershipUi.isTier(viewerTier)?u.optString("membership_frame_url",""):u.optString("frame_url",""));
            String premiumUid=u.optString("user_id",u.optString("userId",""));if(!"STANDARD".equalsIgnoreCase(viewerTier)&&!premiumUid.isEmpty()&&shownPremiumEntrances.add(viewerTier+":"+premiumUid)){
                if("TOP1".equals(viewerTier)){try{JSONObject welcome=new JSONObject(u.toString());welcome.put("tier","TOP1").put("effect_duration_ms",3500);entryQueue.addLast(welcome);playNextEntry();}catch(Exception ignored){}}
                else showFloatingBanner("✨ "+viewerTier+" • "+shortName(u.optString("full_name","User"))+" joined");
            }
            int topRank=u.optInt("supporterRank",0);if(topRank>=1&&topRank<=3){TextView medal=t(String.valueOf(topRank),8,0xff112044,true);medal.setGravity(Gravity.CENTER);medal.setBackground(bg(topRank==1?0xffffcc55:topRank==2?0xffccd9ed:0xffe4a181,Color.TRANSPARENT,7));av.addView(medal,new FrameLayout.LayoutParams(dp(13),dp(13),Gravity.TOP|Gravity.END));}
            av.setClipChildren(true);av.setClipToPadding(true);av.setClickable(true);av.setFocusable(true);PremiumUi.press(av);
            final String viewerUid=u.optString("user_id",u.optString("userId",""));
            final boolean audienceCallAllowed=!viewerUid.isEmpty()&&!viewerUid.equals(hostId)&&(host||roomAdmin||canSuggestCall||SessionManager.isAdmin(this)||SessionManager.isModerator(this));
            av.setOnClickListener(v->showMiniProfile(u));
            // Keep call invitation accessible without covering the avatar.
            if(audienceCallAllowed)av.setOnLongClickListener(v->{showViewerCallCard(u);return true;});
            LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(56),dp(56));ap.leftMargin=dp(4);ap.rightMargin=dp(4);audienceRow.addView(av,ap);visible++;
        }
        int knownTotal=Math.max(Math.max(0,total),currentViewerProfiles.length());int overflow=Math.max(0,knownTotal-visible);
        if(overflow>0){String moreCount=overflow>99?"+99":"+"+overflow;TextView more=t(moreCount,9.5f,Color.WHITE,true);more.setGravity(Gravity.CENTER);more.setBackground(bg(Color.argb(220,42,56,110),Color.rgb(115,177,255),24));more.setContentDescription(overflow+" more viewers. Open viewer list");more.setClickable(true);more.setFocusable(true);more.setOnClickListener(v->showAudienceList());LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(dp(32),dp(32));op.leftMargin=dp(1);op.rightMargin=dp(1);audienceRow.addView(more,op);}
        if(currentViewerProfiles.length()==0){TextView empty=t("",1,Color.TRANSPARENT,false);audienceRow.addView(empty,new LinearLayout.LayoutParams(dp(4),dp(50)));}
    }

    private void showGiftSummary(){
        LinearLayout wrap=col();wrap.setPadding(dp(8),dp(4),dp(8),dp(6));
        TextView note=t("All-time • Top 20 gifters",10,Color.rgb(183,196,232),false);note.setGravity(Gravity.CENTER);wrap.addView(note,new LinearLayout.LayoutParams(-1,dp(32)));
        ScrollView scroll=new ScrollView(this);LinearLayout rows=col();scroll.addView(rows,new ScrollView.LayoutParams(-1,-2));
        int n=currentTopSupporters==null?0:Math.min(20,currentTopSupporters.length());
        if(n==0){TextView empty=t("No gifts in this Live yet",12,Color.rgb(190,200,225),true);empty.setGravity(Gravity.CENTER);rows.addView(empty,new LinearLayout.LayoutParams(-1,dp(100)));}
        for(int i=0;i<n;i++){
            JSONObject x=currentTopSupporters.optJSONObject(i);if(x==null)continue;final int rank=i+1;final String uid=x.optString("sender_id","");
            LinearLayout r=row();r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(7),dp(6),dp(7),dp(6));r.setBackground(bg(rank<=3?Color.argb(235,55,38,84):Color.argb(225,15,29,72),rank==1?Color.rgb(255,208,72):rank==2?Color.rgb(199,211,231):rank==3?Color.rgb(222,151,91):Color.rgb(68,91,160),13));
            TextView rr=t(rank==1?"Top 1":rank==2?"Top 2":rank==3?"Top 3":"#"+rank,rank<=3?8.6f:11,rank<=3?Color.rgb(255,224,145):Color.WHITE,true);rr.setGravity(Gravity.CENTER);r.addView(rr,new LinearLayout.LayoutParams(dp(42),dp(46)));
            FrameLayout av=circleAvatar(x.optString("avatar_url",""),dp(42),false);r.addView(av,new LinearLayout.LayoutParams(dp(42),dp(42)));
            LinearLayout meta=col();meta.setPadding(dp(8),0,dp(3),0);TextView nm=t(x.optString("full_name","Supporter")+"  •  ID "+uid,10,Color.WHITE,true);nm.setSingleLine(true);meta.addView(nm,new LinearLayout.LayoutParams(-1,dp(22)));long gifts=x.optLong("gift_count",0),coins=x.optLong("coin_value",0),gold=x.optLong("gold_value",0);TextView vals=t("🎁 "+gifts+"   •   🪙 "+compact(coins)+" Coin   •   🟡 "+compact(gold)+" Diamond",8.6f,Color.rgb(219,226,255),false);vals.setSingleLine(true);meta.addView(vals,new LinearLayout.LayoutParams(-1,dp(21)));r.addView(meta,new LinearLayout.LayoutParams(0,dp(46),1));
            if(!uid.isEmpty()){r.setOnClickListener(v->{Intent q=new Intent(this,UserProfileActivity.class);q.putExtra("userId",uid);startActivity(q);});PremiumUi.press(r);}LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(68));rp.bottomMargin=dp(5);rows.addView(r,rp);
        }
        wrap.addView(scroll,new LinearLayout.LayoutParams(-1,dp(430)));
        new MyShopCompatDialogBuilder(this).setTitle("🎁 Live Gift Summary • Top 20").setView(wrap).setNeutralButton("Host Profile",(d,w)->{Intent q=new Intent(this,UserProfileActivity.class);q.putExtra("userId",hostId);startActivity(q);}).setPositiveButton(UiStrings.label(AudioLiveRoomActivity.this,"Close"),null).show();
    }

    private void showRunningLiveSummary(){
        long elapsed=!activeSessionId.isEmpty()?Math.max(0,serverElapsedSec+(System.currentTimeMillis()-serverElapsedSyncMs)/1000L):0;
        long coin=0,gold=0,count=0;if(currentTopSupporters!=null)for(int i=0;i<currentTopSupporters.length();i++){JSONObject g=currentTopSupporters.optJSONObject(i);if(g!=null){coin+=g.optLong("coin_value",0);gold+=g.optLong("gold_value",0);count+=g.optLong("gift_count",0);}}
        JSONObject x=new JSONObject();try{x.put("duration_seconds",elapsed).put("peak_viewers",currentPeakViewers).put("total_listeners",currentTotalListeners).put("react_count",reactCount).put("totalCoinGift",coin).put("totalGoldGift",gold).put("giftCount",count).put("topSupporters",currentTopSupporters);}catch(Exception ignored){}
        showPremiumSummaryDialog(x,false);
    }

    private String compact(long n){if(n>=1000000)return (n%1000000==0?(n/1000000)+"M":String.format(Locale.US,"%.1fM",n/1000000f));if(n>=1000)return (n%1000==0?(n/1000)+"K":String.format(Locale.US,"%.1fK",n/1000f));return String.valueOf(n);}

    private String shortName(String n){ if(n==null||n.trim().isEmpty())return "User"; n=n.trim(); int sp=n.indexOf(' '); if(sp>0)n=n.substring(0,sp); return n.length()>7?n.substring(0,7):n; }

    private void showViewerCallCard(JSONObject u){
        if(u==null)return;
        String uid=u.optString("user_id",u.optString("userId",""));if(uid.isEmpty()||uid.equals(hostId)){showMiniProfile(u);return;}
        String name=u.optString("full_name",u.optString("name","User"));
        LinearLayout box=col();box.setPadding(dp(16),dp(14),dp(16),dp(14));box.setBackground(gradient(new int[]{Color.rgb(12,27,73),Color.rgb(48,30,108)},Color.rgb(94,222,255),22));
        LinearLayout top=row();top.setGravity(Gravity.CENTER_VERTICAL);FrameLayout av=circleAvatar(u.optString("avatar_url",""),dp(52),false,identityTier(u));top.addView(av,new LinearLayout.LayoutParams(dp(52),dp(52)));
        LinearLayout meta=col();meta.setPadding(dp(10),0,0,0);TextView nm=t(name,12.4f,Color.WHITE,true);nm.setSingleLine(true);meta.addView(nm,new LinearLayout.LayoutParams(-1,dp(27)));String tier=identityTier(u);TextView sub=t("ID "+uid+"  •  LV."+u.optInt("level",0)+("STANDARD".equalsIgnoreCase(tier)?"":"  •  "+tier),9.2f,Color.rgb(203,229,255),false);AuthorityBadge.decorate(nm,uid);sub.setSingleLine(true);meta.addView(sub,new LinearLayout.LayoutParams(-1,dp(23)));top.addView(meta,new LinearLayout.LayoutParams(0,dp(52),1));box.addView(top,new LinearLayout.LayoutParams(-1,dp(56)));
        TextView balances=t("🪙 "+compact(u.optLong("coin_balance",0))+" Coin    •    🟡 "+compact(u.optLong("gold_balance",0))+" Diamond    •    ⭐ "+compact(u.optLong("stars",0)),10.2f,Color.rgb(255,226,139),true);balances.setGravity(Gravity.CENTER);balances.setBackground(bg(Color.argb(120,13,20,58),Color.rgb(98,113,205),12));box.addView(balances,new LinearLayout.LayoutParams(-1,dp(38)));
        TextView hint=t("Invite this viewer to join the live speaker seat.",9.4f,Color.rgb(211,220,246),false);hint.setGravity(Gravity.CENTER);box.addView(hint,new LinearLayout.LayoutParams(-1,dp(30)));
        LinearLayout actions=row();Button call=small("☎  INVITE TO CALL");call.setTextSize(9.4f);call.setTextColor(Color.WHITE);call.setBackground(gradient(new int[]{Color.rgb(17,172,255),Color.rgb(111,47,244)},Color.rgb(175,244,255),18));call.setElevation(dp(6));Button profile=small("PROFILE");profile.setTextSize(9.0f);profile.setTextColor(Color.WHITE);profile.setBackground(gradient(new int[]{Color.rgb(50,66,116),Color.rgb(82,52,139)},Color.rgb(145,164,230),18));profile.setElevation(dp(4));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(46),1.35f);cp.rightMargin=dp(8);actions.addView(call,cp);actions.addView(profile,new LinearLayout.LayoutParams(0,dp(46),.65f));box.addView(actions,new LinearLayout.LayoutParams(-1,dp(50)));
        final AlertDialog dlg=new MyShopCompatDialogBuilder(this).setView(box).create();call.setOnClickListener(v->{dlg.dismiss();inviteToCall(u);});profile.setOnClickListener(v->{dlg.dismiss();openUserProfile(u);});dlg.setOnShowListener(d->{android.view.Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.65f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);}});dlg.show();
    }

    private void showAudienceList(){
        int n=currentViewerProfiles==null?0:currentViewerProfiles.length();
        if(n==0){Toast.makeText(this,"No active users right now",Toast.LENGTH_SHORT).show();return;}
        String[] items=new String[n]; for(int i=0;i<n;i++){JSONObject u=currentViewerProfiles.optJSONObject(i); items[i]=u==null?"User":u.optString("full_name","User")+"  •  ID "+u.optString("user_id",u.optString("userId",""))+"  •  🏅LV."+u.optInt("level",0);}
        new MyShopCompatDialogBuilder(this).setTitle("Active Users • "+currentViewerCount).setItems(items,(d,w)->{JSONObject u=currentViewerProfiles.optJSONObject(w);if(u==null)return;if(canSuggestCall||host||roomAdmin||SessionManager.isAdmin(this)||SessionManager.isModerator(this))showUserModeration(u);else showMiniProfile(u);}).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Close"),null).show();
    }

    private final java.util.HashSet<String> pendingCallInvites=new java.util.HashSet<>();
    private void inviteToCall(JSONObject u){
        if(u==null)return;
        boolean allowed=canSuggestCall||host||roomAdmin||SessionManager.isAdmin(this)||SessionManager.isModerator(this);
        if(!allowed){Toast.makeText(this,"You do not have Call Suggest permission",Toast.LENGTH_SHORT).show();return;}
        String uid=u.optString("user_id",u.optString("userId","")).trim();if(uid.isEmpty()||uid.equals(hostId))return;
        if(!pendingCallInvites.add(uid))return;
        showFloatingBanner("📞 পাঠানো হচ্ছে…");
        BackendClient.liveInvite(token(),hostId,uid,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{pendingCallInvites.remove(uid);String nm=u.optString("full_name","User"),st=d.optString("status","");if("SUGGESTED_TO_HOST".equals(st)){showFloatingBanner("🛡 Suggested "+shortName(nm)+" to Host");Toast.makeText(AudioLiveRoomActivity.this,"Call suggestion sent to Host",Toast.LENGTH_SHORT).show();}else{showFloatingBanner("📞 Call sent • waiting for "+shortName(nm));Toast.makeText(AudioLiveRoomActivity.this,"Call invitation sent to "+nm,Toast.LENGTH_SHORT).show();}refresh();});}public void onError(String m){runOnUiThread(()->{pendingCallInvites.remove(uid);showFloatingBanner("⚠ Call failed • "+String.valueOf(m));Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show();});}});
    }

    private void showIncomingInvite(JSONObject inv){
        if(inv==null||host||inviteDialogOpen)return;
        String key=inv.optString("host_id",hostId)+"|"+inv.optString("session_id","")+"|"+inv.optString("created_at","");
        if(key.equals(lastInviteNotice))return;
        lastInviteNotice=key;inviteDialogOpen=true;
        String hostName=inv.optString("host_name","Host");String invitedBy=inv.optString("invited_by",hostId),inviterName=inv.optString("inviter_name",hostName);boolean adminSuggested=!invitedBy.isEmpty()&&!invitedBy.equals(hostId);
        LinearLayout box=col();box.setPadding(dp(18),dp(16),dp(18),dp(16));box.setBackground(gradient(new int[]{Color.rgb(13,24,69),Color.rgb(47,28,102)},Color.rgb(104,211,255),22));
        TextView title=t(adminSuggested?"🛡  ADMIN SUGGEST CALL":"📞  LIVE CALL INVITATION",16.5f,Color.WHITE,true);title.setGravity(Gravity.CENTER);box.addView(title,new LinearLayout.LayoutParams(-1,dp(38)));
        TextView msg=t(adminSuggested?(inviterName+" (Live Admin) suggested you to "+hostName+" Live. Accept to join the call."):(hostName+" আপনাকে Live Call-এ speaker হিসেবে আমন্ত্রণ জানিয়েছে।"),11.2f,Color.rgb(218,228,255),false);msg.setGravity(Gravity.CENTER);msg.setPadding(dp(8),dp(4),dp(8),dp(8));box.addView(msg,new LinearLayout.LayoutParams(-1,dp(68)));
        LinearLayout actions=row();actions.setGravity(Gravity.CENTER);
        Button accept=small("✓  ACCEPT");accept.setTextSize(10.2f);accept.setTextColor(Color.WHITE);accept.setBackground(gradient(new int[]{Color.rgb(12,139,102),Color.rgb(30,211,145)},Color.rgb(151,255,218),18));accept.setElevation(dp(5));
        Button reject=small("✕  REJECT");reject.setTextSize(10.2f);reject.setTextColor(Color.WHITE);reject.setBackground(gradient(new int[]{Color.rgb(133,29,74),Color.rgb(225,54,100)},Color.rgb(255,145,177),18));reject.setElevation(dp(5));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(48),1);ap.rightMargin=dp(8);actions.addView(accept,ap);actions.addView(reject,new LinearLayout.LayoutParams(0,dp(48),1));box.addView(actions,new LinearLayout.LayoutParams(-1,dp(52)));
        final AlertDialog dlg=new MyShopCompatDialogBuilder(this).setView(box).create();
        accept.setOnClickListener(v->{accept.setEnabled(false);reject.setEnabled(false);handleInviteAction(true,dlg);});
        reject.setOnClickListener(v->{accept.setEnabled(false);reject.setEnabled(false);handleInviteAction(false,dlg);});
        dlg.setOnCancelListener(d->inviteDialogOpen=false);dlg.setOnDismissListener(d->inviteDialogOpen=false);dlg.setOnShowListener(d->{android.view.Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.72f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);}});dlg.show();
    }


    private void showIncomingAdminInvite(JSONObject inv){
        if(inv==null||host||adminInviteDialogOpen)return;String key=inv.optString("host_id",hostId)+"|"+inv.optString("created_at","");if(key.equals(lastAdminInviteKey))return;lastAdminInviteKey=key;adminInviteDialogOpen=true;
        String hostName=inv.optString("host_name","Host");LinearLayout box=col();box.setPadding(dp(18),dp(16),dp(18),dp(16));box.setBackground(gradient(new int[]{Color.rgb(13,24,69),Color.rgb(58,29,112)},Color.rgb(115,218,255),22));
        TextView title=t("🛡  LIVE ADMIN INVITATION",15.5f,Color.WHITE,true);title.setGravity(Gravity.CENTER);box.addView(title,new LinearLayout.LayoutParams(-1,dp(38)));TextView msg=t(hostName+" wants to make you a Live Admin. Accept to enable Call Suggest, Mute, Block and Music controls.",10.5f,Color.rgb(220,230,255),false);msg.setGravity(Gravity.CENTER);msg.setPadding(dp(6),dp(4),dp(6),dp(8));box.addView(msg,new LinearLayout.LayoutParams(-1,dp(72)));
        LinearLayout actions=row();Button accept=small("✓ ACCEPT"),decline=small("✕ DECLINE");accept.setBackground(gradient(new int[]{Color.rgb(10,139,102),Color.rgb(30,211,145)},Color.rgb(151,255,218),18));decline.setBackground(gradient(new int[]{Color.rgb(133,29,74),Color.rgb(225,54,100)},Color.rgb(255,145,177),18));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(48),1);ap.rightMargin=dp(8);actions.addView(accept,ap);actions.addView(decline,new LinearLayout.LayoutParams(0,dp(48),1));box.addView(actions,new LinearLayout.LayoutParams(-1,dp(52)));final AlertDialog dlg=new MyShopCompatDialogBuilder(this).setView(box).create();
        View.OnClickListener yes=v->{accept.setEnabled(false);decline.setEnabled(false);BackendClient.liveModeration(token(),hostId,SessionManager.getUserId(this),"ACCEPT_ROOM_ADMIN",new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{roomAdmin=true;adminInviteDialogOpen=false;dlg.dismiss();showFloatingBanner("🛡 Live Admin enabled");refresh();});}public void onError(String m){runOnUiThread(()->{adminInviteDialogOpen=false;dlg.dismiss();Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show();});}});};
        View.OnClickListener no=v->{accept.setEnabled(false);decline.setEnabled(false);BackendClient.liveModeration(token(),hostId,SessionManager.getUserId(this),"DECLINE_ROOM_ADMIN",new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{adminInviteDialogOpen=false;dlg.dismiss();refresh();});}public void onError(String m){runOnUiThread(()->{adminInviteDialogOpen=false;dlg.dismiss();Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show();});}});};accept.setOnClickListener(yes);decline.setOnClickListener(no);dlg.setOnDismissListener(d->adminInviteDialogOpen=false);dlg.show();
    }

    private void handleInviteAction(boolean accept,AlertDialog dlg){
        performInviteAction(accept,dlg,false);
    }

    private void performInviteAction(boolean accept,AlertDialog dlg,boolean retried){
        BackendClient.liveInviteAction(token(),hostId,accept,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                if(dlg!=null&&dlg.isShowing())dlg.dismiss();inviteDialogOpen=false;
                if(accept){
                    myRole="SPEAKER";currentSeatNo=d.optInt("seatNo",currentSeatNo);localMicOn=true;
                    requestRtcToken(true);updateSpeakerControls();updateLocalMicUi();
                    showFloatingBanner("✓ Call accepted • joining speaker seat");
                    Toast.makeText(AudioLiveRoomActivity.this,"Call accepted • joining speaker seat",Toast.LENGTH_SHORT).show();
                    refresh();handler.postDelayed(()->refresh(),120L);handler.postDelayed(()->refresh(),420L);handler.postDelayed(()->refresh(),900L);
                }else{Toast.makeText(AudioLiveRoomActivity.this,"Invitation rejected",Toast.LENGTH_SHORT).show();refresh();}
            });}
            public void onError(String m){runOnUiThread(()->{
                String err=String.valueOf(m);
                // The audience heartbeat may be a few seconds late on weak networks. Re-assert
                // viewer presence once, then retry the same pending invite instead of forcing the user to tap again.
                if(accept&&!retried&&(err.contains("NOT_IN_LIVE")||err.contains("INVITE_NOT_PENDING")||err.contains("LIVE_SESSION_NOT_READY"))){
                    BackendClient.liveViewer(token(),hostId,true,new BackendClient.Callback(){
                        public void onSuccess(JSONObject x){performInviteAction(true,dlg,true);}
                        public void onError(String e){inviteDialogOpen=false;if(dlg!=null&&dlg.isShowing())dlg.dismiss();Toast.makeText(AudioLiveRoomActivity.this,err,Toast.LENGTH_LONG).show();refresh();}
                    });
                    return;
                }
                inviteDialogOpen=false;if(dlg!=null&&dlg.isShowing())dlg.dismiss();Toast.makeText(AudioLiveRoomActivity.this,err,Toast.LENGTH_LONG).show();refresh();
            });}
        });
    }

    private void notifyHostOfNewRequest(JSONArray q){
        if(!host||requestNoticeBar==null)return;
        if(q==null||q.length()==0){requestNoticeBar.setVisibility(View.GONE);requestNoticeBar.removeAllViews();return;}
        JSONObject x=q.optJSONObject(0);if(x==null)return;
        String uid=x.optString("user_id","");String nm=x.optString("full_name","User");String key=uid+"|"+x.optString("created_at","");
        requestNoticeBar.removeAllViews();
        requestNoticeBar.setPadding(dp(8),dp(5),dp(7),dp(5));
        requestNoticeBar.setBackground(gradient(new int[]{Color.argb(248,18,27,72),Color.argb(248,70,39,139),Color.argb(248,27,86,164)},Color.rgb(99,225,255),18));
        requestNoticeBar.setElevation(dp(5));
        FrameLayout av=circleAvatar(x.optString("avatar_url",""),dp(42),false,identityTier(x));
        TextView live=t("JOIN",6.8f,Color.WHITE,true);live.setGravity(Gravity.CENTER);live.setBackground(bg(Color.rgb(238,57,108),Color.rgb(255,128,169),8));FrameLayout.LayoutParams lb=new FrameLayout.LayoutParams(dp(29),dp(15),Gravity.RIGHT|Gravity.BOTTOM);lb.rightMargin=-dp(2);lb.bottomMargin=-dp(1);av.addView(live,lb);
        LinearLayout.LayoutParams avp=new LinearLayout.LayoutParams(dp(42),dp(42));avp.rightMargin=dp(8);requestNoticeBar.addView(av,avp);
        LinearLayout meta=col();
        TextView who=t(shortName(nm)+"  •  JOIN REQUEST"+(q.length()>1?"  +"+(q.length()-1):""),10.6f,Color.WHITE,true);who.setSingleLine(true);who.setEllipsize(android.text.TextUtils.TruncateAt.END);meta.addView(who,new LinearLayout.LayoutParams(-1,dp(21)));
        TextView sub=t("ID "+uid+"  •  LV."+x.optInt("level",0)+"  •  🪙"+compact(x.optLong("coin_balance",0))+"  •  🟡"+compact(x.optLong("gold_balance",0)),8.5f,Color.rgb(205,232,255),false);AuthorityBadge.decorate(who,uid);sub.setSingleLine(true);sub.setEllipsize(android.text.TextUtils.TruncateAt.END);meta.addView(sub,new LinearLayout.LayoutParams(-1,dp(18)));
        requestNoticeBar.addView(meta,new LinearLayout.LayoutParams(0,dp(42),1));
        Button ok=small("✓ ACCEPT");ok.setTextSize(7.9f);ok.setTextColor(Color.WHITE);ok.setBackground(gradient(new int[]{Color.rgb(10,137,102),Color.rgb(30,213,146)},Color.rgb(146,255,216),15));ok.setElevation(dp(4));
        Button no=small("✕ REJECT");no.setTextSize(7.9f);no.setTextColor(Color.WHITE);no.setBackground(gradient(new int[]{Color.rgb(128,28,70),Color.rgb(221,49,96)},Color.rgb(255,137,171),15));no.setElevation(dp(4));
        ok.setOnClickListener(v->handleJoinRequestAction(uid,true,ok,no));no.setOnClickListener(v->handleJoinRequestAction(uid,false,ok,no));
        LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(dp(68),dp(38));op.rightMargin=dp(5);requestNoticeBar.addView(ok,op);requestNoticeBar.addView(no,new LinearLayout.LayoutParams(dp(68),dp(38)));
        requestNoticeBar.setVisibility(View.VISIBLE);
        if(!key.equals(lastRequestNotice)){lastRequestNotice=key;requestNoticeBar.setAlpha(.25f);requestNoticeBar.setScaleX(.98f);requestNoticeBar.setScaleY(.98f);requestNoticeBar.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(190).start();}
    }


    private void notifyHostOfCallSuggestion(JSONArray q){
        if(!host||requestNoticeBar==null||q==null||q.length()==0)return;JSONObject x=q.optJSONObject(0);if(x==null)return;String uid=x.optString("user_id","");String user=x.optString("user_name","User"),admin=x.optString("admin_name","Live Admin");requestNoticeBar.removeAllViews();requestNoticeBar.setPadding(dp(8),dp(5),dp(7),dp(5));requestNoticeBar.setBackground(gradient(new int[]{Color.argb(248,33,26,80),Color.argb(248,112,55,38),Color.argb(248,57,39,135)},Color.rgb(255,202,78),18));
        FrameLayout av=circleAvatar(x.optString("user_avatar",""),dp(42),false);LinearLayout.LayoutParams avp=new LinearLayout.LayoutParams(dp(42),dp(42));avp.rightMargin=dp(8);requestNoticeBar.addView(av,avp);LinearLayout meta=col();TextView who=t(shortName(user)+"  •  Suggested by Admin"+(q.length()>1?"  +"+(q.length()-1):""),10.2f,Color.WHITE,true);who.setSingleLine(true);meta.addView(who,new LinearLayout.LayoutParams(-1,dp(21)));TextView sub=t("by "+shortName(admin)+"  •  LV."+x.optInt("user_level",0),8.3f,Color.rgb(255,225,166),false);AuthorityBadge.decorate(who,uid);sub.setSingleLine(true);sub.setEllipsize(android.text.TextUtils.TruncateAt.END);meta.addView(sub,new LinearLayout.LayoutParams(-1,dp(18)));requestNoticeBar.addView(meta,new LinearLayout.LayoutParams(0,dp(42),1));Button yes=small("✓ ACCEPT"),no=small("✕ DECLINE");yes.setBackground(gradient(new int[]{Color.rgb(10,137,102),Color.rgb(30,213,146)},Color.rgb(146,255,216),15));no.setBackground(gradient(new int[]{Color.rgb(128,28,70),Color.rgb(221,49,96)},Color.rgb(255,137,171),15));yes.setOnClickListener(v->handleCallSuggestion(uid,true,yes,no));no.setOnClickListener(v->handleCallSuggestion(uid,false,yes,no));LinearLayout.LayoutParams yp=new LinearLayout.LayoutParams(dp(68),dp(38));yp.rightMargin=dp(5);requestNoticeBar.addView(yes,yp);requestNoticeBar.addView(no,new LinearLayout.LayoutParams(dp(68),dp(38)));requestNoticeBar.setVisibility(View.VISIBLE);
    }
    private void handleCallSuggestion(String uid,boolean accept,Button yes,Button no){yes.setEnabled(false);no.setEnabled(false);BackendClient.liveModeration(token(),hostId,uid,accept?"ACCEPT_CALL_SUGGESTION":"DECLINE_CALL_SUGGESTION",new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{showFloatingBanner(accept?"✓ Suggestion accepted • invitation sent":"Suggestion declined");refresh();});}public void onError(String m){runOnUiThread(()->{yes.setEnabled(true);no.setEnabled(true);Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show();refresh();});}});}

    private void handleJoinRequestAction(String uid,boolean accept,Button yes,Button no){
        if(yes!=null)yes.setEnabled(false);if(no!=null)no.setEnabled(false);
        BackendClient.liveRequestAction(token(),uid,accept,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,accept?"Speaker accepted • call connected":"Request rejected",Toast.LENGTH_SHORT).show();refresh();handler.postDelayed(()->refresh(),120L);});}
            public void onError(String m){runOnUiThread(()->{if(yes!=null)yes.setEnabled(true);if(no!=null)no.setEnabled(true);Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show();refresh();});}
        });
    }

    private void showJoinRequestsDialog(){
        if(!host)return;if(currentRequests==null||currentRequests.length()==0){Toast.makeText(this,"No pending join requests",Toast.LENGTH_SHORT).show();return;}
        int n=currentRequests.length();String[] items=new String[n];for(int i=0;i<n;i++){JSONObject x=currentRequests.optJSONObject(i);items[i]=x==null?"User":x.optString("full_name","User")+" • ID "+x.optString("user_id","");}
        new MyShopCompatDialogBuilder(this).setTitle("Join Requests • "+n).setItems(items,(d,w)->{JSONObject x=currentRequests.optJSONObject(w);if(x==null)return;String uid=x.optString("user_id","");new MyShopCompatDialogBuilder(this).setTitle(items[w]).setItems(new String[]{"Accept to Call","Decline"},(dd,which)->BackendClient.liveRequestAction(token(),uid,which==0,new BackendClient.Callback(){public void onSuccess(JSONObject z){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,which==0?"Speaker accepted • call connected":"Request rejected",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String e){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_LONG).show());}})).show();}).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Close"),null).show();
    }

    private void renderSpecialGuest(JSONObject x){
        specialArea.removeAllViews();
        FrameLayout stage=new FrameLayout(this);
        boolean speaking=x!=null&&x.optInt("speaking",0)==1;speaking=speaking||isRtcSpeaking(x,false);
        FrameLayout guestFrame=new FrameLayout(this); GoldenGuestHalo halo=new GoldenGuestHalo(this,x!=null);
        if(x==null){
            ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.live_main_guest_owner);logo.setScaleType(ImageView.ScaleType.CENTER_CROP);logo.setBackground(bg(Color.TRANSPARENT,Color.TRANSPARENT,100));logo.setOutlineProvider(new android.view.ViewOutlineProvider(){@Override public void getOutline(View view,android.graphics.Outline outline){outline.setOval(0,0,view.getWidth(),view.getHeight());}});logo.setClipToOutline(true);
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(146),dp(146),Gravity.CENTER);guestFrame.addView(logo,lp);
        }else{
            FrameLayout av=avatarWithMicState(x,dp(140),speaking); FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(dp(140),dp(140),Gravity.CENTER); guestFrame.addView(av,ap);
        }
        // Keep the guest photo/logo as the stable center layer and animate only the
        // transparent ornament above it. This prevents black frames and profile flicker.
        guestFrame.addView(halo,new FrameLayout.LayoutParams(-1,-1));
        
        FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(dp(230),dp(188),Gravity.CENTER); stage.addView(guestFrame,gp);
        specialArea.addView(stage,new LinearLayout.LayoutParams(-1,dp(184)));
        if(x!=null){guestFrame.setClickable(true);guestFrame.setFocusable(true);PremiumUi.press(guestFrame);guestFrame.setOnClickListener(v->{String uid=x.optString("user_id","");if(SessionManager.getUserId(this).equals(uid)&&"SPEAKER".equals(myRole))showSelfSpeakerMenu();else showSeatedUserActions(x);});}else guestFrame.setOnClickListener(null);
    }

    private void renderSeats(JSONArray a){
        StringBuilder visual=new StringBuilder(activeSessionId+lockedSeats.toString());if(a!=null)for(int i=0;i<a.length();i++){JSONObject seat=a.optJSONObject(i);if(seat!=null)visual.append(seat.optInt("seat_no")).append(portraitKey(seat));}String key=visual.toString();if(key.equals(seatVisualKey)&&seats.getChildCount()>0){refreshSpeakingAvatars();return;}seatVisualKey=key;
        seats.removeAllViews();
        // V-523 locked visual: eight default normal seats as 4 + 4. Host and Main Guest are separate.
        int seatNo=2;
        for(int rr=0;rr<2;rr++){
            LinearLayout r=row();r.setGravity(Gravity.CENTER);
            for(int c=0;c<4;c++,seatNo++)addSeatToRow(r,a,seatNo,true);
            seats.addView(r,new LinearLayout.LayoutParams(-1,dp(80)));
        }
        // Add further rows only when a dynamic seat is occupied; the eight default seats stay 4 + 4.
        int highest=9;
        if(a!=null)for(int i=0;i<a.length();i++){JSONObject seat=a.optJSONObject(i);if(seat!=null)highest=Math.max(highest,seat.optInt("seat_no",0));}
        for(int first=10;first<=highest;first+=4){
            LinearLayout extra=row();extra.setGravity(Gravity.CENTER);int added=0;
            for(int n=first;n<first+4&&n<=highest;n++)if(findSeat(a,n)!=null){addSeatToRow(extra,a,n,false);added++;}
            if(added>0)seats.addView(extra,new LinearLayout.LayoutParams(-1,dp(80)));
        }
    }

    private void addSeatToRow(LinearLayout r,JSONArray a,int n,boolean allowEmpty){
        JSONObject found=findSeat(a,n);
        if(found!=null&&hostId.equals(found.optString("user_id","")))found=null;
        boolean specialReserved=found!=null&&!specialGuestId.isEmpty()&&specialGuestId.equals(found.optString("user_id",""));
        if(specialReserved)found=null;
        if(found==null&&!allowEmpty)return;
        boolean locked=(n>1&&lockedSeats.contains(n))||specialReserved;
        LinearLayout tile=seatTile(n,found,locked); final int seatNo=n; final JSONObject clicked=found;
        tile.setOnClickListener(v->{
            if(clicked!=null){
                String clickedId=clicked.optString("user_id","");
                if(SessionManager.getUserId(this).equals(clickedId)&&"SPEAKER".equals(myRole)){showSelfSpeakerMenu();return;}
                showSeatedUserActions(clicked);return;
            }
            if(host){toggleSeatLock(seatNo,locked);return;}
            if("SPEAKER".equals(myRole)&&!locked){moveMySeat(seatNo);}
        });
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(80),1);lp.setMargins(dp(4),dp(2),dp(4),dp(2));r.addView(tile,lp);
    }

    private LinearLayout seatTile(int seatNo,JSONObject x,boolean locked){
        LinearLayout v=col(); v.setGravity(Gravity.CENTER); v.setPadding(dp(1),dp(1),dp(1),dp(1)); v.setBackgroundColor(Color.TRANSPARENT);
        boolean occupied=x!=null,speaking=occupied&&x.optInt("speaking",0)==1;speaking=speaking||isRtcSpeaking(x,false);
        if(occupied){
            int portraitSize=Math.min(dp(76),(getResources().getDisplayMetrics().widthPixels-dp(40))/4);FrameLayout av=avatarWithMicState(x,portraitSize,speaking); v.addView(av,new LinearLayout.LayoutParams(portraitSize,portraitSize));
        }else{
            FrameLayout stage=new FrameLayout(this); stage.addView(sofaIcon(locked),new FrameLayout.LayoutParams(dp(58),dp(58),Gravity.CENTER)); v.addView(stage,new LinearLayout.LayoutParams(dp(60),dp(60)));
        }
        return v;
    }

    private View sofaIcon(boolean locked){
        FrameLayout f=new FrameLayout(this);f.setPadding(dp(2),dp(2),dp(2),dp(2));f.setElevation(dp(1));
        GradientDrawable seatBg=new GradientDrawable();
        seatBg.setShape(GradientDrawable.OVAL);
        seatBg.setColor(locked?Color.argb(115,105,100,130):Color.argb(115,150,102,201));
        f.setBackground(seatBg);f.setElevation(0f);
        ImageView chair=new ImageView(this);chair.setImageResource(R.drawable.live_guest_chair);chair.setScaleType(ImageView.ScaleType.CENTER_INSIDE);chair.setAlpha(.97f);
        FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(24),dp(24),Gravity.CENTER);f.addView(chair,cp);
        if(locked){TextView mark=t("🔒",8,Color.WHITE,true);mark.setGravity(Gravity.CENTER);mark.setBackground(bg(Color.argb(170,20,20,24),Color.argb(190,220,220,230),18));FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(20),dp(20),Gravity.RIGHT|Gravity.BOTTOM);f.addView(mark,mp);}
        return f;
    }

    private void toggleSeatLock(int seatNo,boolean locked){BackendClient.liveSeatLock(token(),seatNo,!locked,new ToastCb(!locked?"Seat locked":"Seat unlocked"));}


    private void renderHighlightComments(JSONArray arr){
        if(arr==null||arr.length()==0)return; JSONObject c=arr.optJSONObject(arr.length()-1); if(c==null)return; long hid=c.optLong("id",0); if(hid<=lastHighlightId)return; lastHighlightId=hid; final TextView banner=t("✨ "+c.optString("full_name","User")+": "+c.optString("message",""),11,Color.WHITE,true); banner.setPadding(dp(14),0,dp(14),0); banner.setGravity(Gravity.CENTER_VERTICAL); banner.setBackground(gradient(new int[]{Color.argb(235,76,34,145),Color.argb(235,184,54,156)},Color.rgb(255,209,92),18)); addContentView(banner,new android.view.ViewGroup.LayoutParams(dp(310),dp(42))); banner.setX(getResources().getDisplayMetrics().widthPixels); banner.setY(getResources().getDisplayMetrics().heightPixels*0.46f); banner.animate().translationX(-getResources().getDisplayMetrics().widthPixels-dp(340)).setDuration(6500).withEndAction(()->((android.view.ViewGroup)banner.getParent()).removeView(banner)).start();
    }

    private void renderRequests(JSONArray q){
        requests.removeAllViews();
        if(q==null||q.length()==0){requests.addView(t("No pending requests",11,Color.LTGRAY,false));return;}
        for(int i=0;i<q.length();i++){
            JSONObject x=q.optJSONObject(i);if(x==null)continue;
            LinearLayout rr=row();rr.setGravity(Gravity.CENTER_VERTICAL);
            String tier=x.optString("tier","STANDARD");long fan=x.optLong("fan_points",0);
            String badge="STANDARD".equals(tier)?"":(" • "+tier);
            TextView nm=t(x.optString("full_name","User")+badge+" • ID "+x.optString("user_id")+(fan>0?" • ⭐"+fan:""),10.5f,Color.WHITE,true);
            rr.addView(nm,new LinearLayout.LayoutParams(0,dp(36),1));
            Button ok=small("Accept"),no=small("Decline");String id=x.optString("user_id");
            ok.setOnClickListener(v->handleJoinRequestAction(id,true,ok,no));
            no.setOnClickListener(v->handleJoinRequestAction(id,false,ok,no));
            rr.addView(ok,new LinearLayout.LayoutParams(dp(72),dp(38)));rr.addView(no,new LinearLayout.LayoutParams(dp(74),dp(38)));requests.addView(rr);
        }
    }

    private void compactCommentRow(TextView row){if(row==null)return;row.setMaxLines(Integer.MAX_VALUE);row.setEllipsize(null);row.setMinHeight(0);row.setGravity(Gravity.CENTER_VERTICAL);}

    private String top1Id(){JSONObject first=currentTopSupporters==null?null:currentTopSupporters.optJSONObject(0);return first==null?"":first.optString("sender_id","");}
    private String identityTier(JSONObject user){
        if(user==null)return "STANDARD";String uid=user.optString("user_id",user.optString("sender_id",user.optString("userId",user.optString("senderId",""))));
        String member=MembershipUi.tier(user.optString("tier","STANDARD"));return !uid.isEmpty()&&!uid.equals(hostId)&&uid.equals(top1Id())&&member.isEmpty()?"TOP1":member.isEmpty()?"STANDARD":member;
    }
    private boolean roomTop1(JSONObject user){if(user==null)return false;String uid=user.optString("user_id",user.optString("sender_id",user.optString("userId",user.optString("senderId",""))));return !uid.isEmpty()&&!uid.equals(hostId)&&uid.equals(top1Id());}
    private void refreshMembershipComments(){
        if(commentsList==null)return;for(int i=0;i<commentsList.getChildCount();i++){View old=commentsList.getChildAt(i);if(!(old.getTag() instanceof JSONObject))continue;
            JSONObject c=(JSONObject)old.getTag();LinearLayout replacement=buildUniversalCommentRow(c,c.optString("full_name","User"),c.optString("message",""),c.optString("gender","UNSPECIFIED"));
            ViewGroup.LayoutParams p=old.getLayoutParams();commentsList.removeViewAt(i);commentsList.addView(replacement,i,p);
        }
    }
    private int membershipAccent(String tier){
        if(MembershipUi.hasFrame(tier))return MembershipUi.accent(tier);
        if("KING".equalsIgnoreCase(tier))return Color.rgb(255,182,46);
        if("QUEEN".equalsIgnoreCase(tier))return Color.rgb(255,78,180);
        if("ROYAL".equalsIgnoreCase(tier))return Color.rgb(166,91,255);
        if("VVIP".equalsIgnoreCase(tier))return Color.rgb(52,205,255);
        if("VIP".equalsIgnoreCase(tier))return Color.rgb(83,224,126);
        return Color.rgb(153,132,255);
    }
    private String membershipIcon(String tier){if("KING".equalsIgnoreCase(tier))return "🦁";if("QUEEN".equalsIgnoreCase(tier))return "♛";if("ROYAL".equalsIgnoreCase(tier))return "✦";if("VVIP".equalsIgnoreCase(tier))return "◆";if("VIP".equalsIgnoreCase(tier))return "❖";return "";}
    private MembershipIdentityView readyMembershipAvatar(String tier,String url){Bitmap bitmap=url==null?null:avatarCache.get(url);MembershipIdentityView view=new MembershipIdentityView(this,tier,bitmap==null?url:null);if(bitmap!=null)view.setPortraitBitmap(bitmap);return view;}
    private String membershipFrameFor(JSONObject user){
        if(user==null||"TOP1".equals(identityTier(user)))return "";
        String asset=user.optString("membership_frame_url","");if(!asset.isEmpty())return asset;
        String uid=user.optString("user_id",user.optString("sender_id",user.optString("userId",user.optString("senderId",""))));
        JSONObject known=findUser(currentViewerProfiles,uid);if(known==null)known=findUser(currentSeats,uid);
        return known==null?"":known.optString("membership_frame_url","");
    }
    private FrameLayout liveCommentAvatar(String url,String gender,String tier,int size,String frameUrl){
        if(MembershipUi.hasFrame(tier)){FrameLayout frame=new FrameLayout(this);MembershipIdentityView identity=readyMembershipAvatar(tier,url);identity.setFrameAsset(frameUrl);frame.addView(identity,new FrameLayout.LayoutParams(size,size));return frame;}
        int stroke="STANDARD".equalsIgnoreCase(tier)?("FEMALE".equalsIgnoreCase(gender)?Color.rgb(255,83,190):"MALE".equalsIgnoreCase(gender)?Color.rgb(57,210,118):Color.rgb(153,132,255)):membershipAccent(tier);
        FrameLayout frame=new FrameLayout(this);frame.setBackground(bg(Color.argb(210,13,20,48),stroke,size/2));
        ImageView v=new ImageView(this);v.setImageResource(R.drawable.myshop_profile_avatar);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setClipToOutline(true);v.setBackground(bg(Color.rgb(31,40,84),stroke,size/2));
        FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,-1);ip.setMargins(dp(2),dp(2),dp(2),dp(2));frame.addView(v,ip);if(url!=null&&!url.trim().isEmpty())loadImage(v,url);
        if(!"STANDARD".equalsIgnoreCase(tier)){TextView dot=t("",1,Color.TRANSPARENT,false);dot.setBackground(bg(Color.TRANSPARENT,stroke,size/2));FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(-1,-1);rp.setMargins(dp(1),dp(1),dp(1),dp(1));frame.addView(dot,rp);ObjectAnimator pulse=ObjectAnimator.ofFloat(dot,"alpha",.25f,1f,.25f);pulse.setDuration(1500);pulse.setRepeatCount(ValueAnimator.INFINITE);pulse.start();dot.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View v){}public void onViewDetachedFromWindow(View v){pulse.cancel();}});}
        return frame;
    }

    private LinearLayout buildUniversalCommentRow(JSONObject c,String name,String message,String gender){
        int chatSlot611=ChatBubble611.slot(c.optString("comment_style_code","")+" "+c.optString("comment_style_url",""));String tier=identityTier(c);String cosmeticKey=AvatarCosmetics.fromUrl(c.optString("comment_style_url",c.optString("frame_url","")));int accent=cosmeticKey==null?membershipAccent(tier):AvatarCosmetics.accent(cosmeticKey);boolean premium=!"STANDARD".equals(tier)||cosmeticKey!=null||chatSlot611>=0;
        LinearLayout row=row();row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(MembershipUi.hasFrame(tier)?12:5),dp(MembershipUi.hasFrame(tier)?14:4),dp(MembershipUi.hasFrame(tier)?12:6),dp(MembershipUi.hasFrame(tier)?14:4));
        int bgc=Color.argb(180,7,12,31);android.graphics.drawable.Drawable commentSkin=chatSlot611>=0?new ChatBubble611.Skin(this,chatSlot611):cosmeticKey!=null?new AvatarCosmetics.Skin(cosmeticKey,getResources().getDisplayMetrics().density):MembershipUi.hasFrame(tier)?MembershipUi.commentBackground(this,tier):bg(bgc,Color.TRANSPARENT,10);row.setBackground(roomTop1(c)?new Top1CommentDrawable(commentSkin):commentSkin);row.setPadding(dp(premium?12:5),dp(premium?16:4),dp(premium?12:6),dp(premium?16:4));
        if(chatSlot611>=0){ChatBubble611.applyInsets(row);}String avatar=c==null?"":c.optString("avatar_url",c.optString("sender_avatar",""));String portraitCosmetic611=cosmeticKey!=null?cosmeticKey:cosmeticForComment611(c);int portraitSize=dp(chatSlot611>=0?40:MembershipUi.hasFrame(tier)||portraitCosmetic611!=null?64:26);FrameLayout av;if(portraitCosmetic611!=null){av=new FrameLayout(this);av.addView(new AvatarCosmetics.Portrait(this,portraitCosmetic611,avatar),new FrameLayout.LayoutParams(-1,-1));}else av=liveCommentAvatar(avatar,gender,tier,portraitSize,membershipFrameFor(c));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(portraitSize,portraitSize);ap.leftMargin=0;row.addView(av,ap);
        LinearLayout textBox=col();textBox.setPadding(dp(8),dp(2),dp(5),dp(2));String displayName=(name==null||name.trim().isEmpty()?"User":name.trim());int level=c==null?0:c.optInt("level",0);
        String normalizedGender=gender==null?"":gender.trim().toUpperCase(Locale.ROOT);
        int nameColor=chatSlot611>=0?ChatBubble611.ink(chatSlot611):cosmeticKey!=null&&!cosmeticKey.startsWith("luxury")?AvatarCosmetics.foreground(cosmeticKey):"MALE".equals(normalizedGender)?Color.rgb(89,224,132):"FEMALE".equals(normalizedGender)?Color.rgb(255,126,190):(premium?accent:Color.WHITE);
        TextView top=t(displayName+(level>0?"   LV."+level:""),Math.min(11.5f,liveCommentFontSize),nameColor,true);AuthorityBadge.decorate(top,c==null?"":c.optString("user_id",c.optString("sender_id","")));top.setSingleLine(true);top.setEllipsize(android.text.TextUtils.TruncateAt.END);if(roomTop1(c)){LinearLayout heading=row();heading.setGravity(Gravity.CENTER_VERTICAL);heading.addView(top,new LinearLayout.LayoutParams(0,-2,1));TextView badge=t("🏆 TOP‑1",8,0xffffdf78,true);badge.setSingleLine(true);heading.addView(badge,new LinearLayout.LayoutParams(dp(48),-2));textBox.addView(heading,new LinearLayout.LayoutParams(-1,-2));}else textBox.addView(top,new LinearLayout.LayoutParams(-1,-2));
        TextView body=t(LiveCommentLimit.truncate(message==null?"":message),Math.max(12f,Math.min(15f,liveCommentFontSize)),(chatSlot611>=0?ChatBubble611.ink(chatSlot611):cosmeticKey!=null&&!cosmeticKey.startsWith("luxury")?AvatarCosmetics.foreground(cosmeticKey):Color.WHITE),false);body.setLineSpacing(0,1.02f);compactCommentRow(body);body.setIncludeFontPadding(false);body.setMaxHeight(dp(180));body.setMovementMethod(android.text.method.ScrollingMovementMethod.getInstance());top.setIncludeFontPadding(false);body.setPadding(0,dp(4),0,dp(3));textBox.addView(body,new LinearLayout.LayoutParams(-1,-2));row.addView(textBox,new LinearLayout.LayoutParams(0,-2,1));
        String customComment=c==null?"":c.optString("comment_style_url","");if(!customComment.isEmpty()&&cosmeticKey==null&&chatSlot611<0){ImageView styleMark=new ImageView(this);styleMark.setScaleType(ImageView.ScaleType.CENTER_INSIDE);styleMark.setContentDescription("Applied premium comment style");AnimatedAssetLoader.load(styleMark,customComment,true);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(30),dp(36));sp.rightMargin=dp(4);row.addView(styleMark,sp);}
        if(cosmeticKey!=null){row.addView(new AvatarCosmetics.Emblem(this,cosmeticKey),new LinearLayout.LayoutParams(dp(25),dp(30)));}else if(MembershipUi.isTier(tier)){row.addView(new MembershipEmblemView(this,tier),new LinearLayout.LayoutParams(dp(25),dp(30)));}else if("TOP1".equals(tier)){TextView mark=t("TOP1",8,accent,true);row.addView(mark,new LinearLayout.LayoutParams(dp(28),dp(26)));}
        if(c!=null){row.setTag(c);final JSONObject profile=c;row.setClickable(true);row.setFocusable(true);PremiumUi.press(row);row.setOnClickListener(v->openUserProfile(profile));final String pinText=name+" : "+message;row.setOnLongClickListener(v->{showLiveCommentActions(profile,pinText);return true;});}return row;
    }

    private final java.util.ArrayDeque<JSONObject> joinNotices615=new java.util.ArrayDeque<>();
    private View joinNotice615;private boolean joinNoticePlaying615;
    private void enqueueJoin615(JSONObject event){if(joinNotices615.size()>=50)joinNotices615.removeFirst();joinNotices615.addLast(event);playJoin615();}
    private void playJoin615(){if(joinNoticePlaying615||joinNotices615.isEmpty()||isFinishing()||roomEnded)return;JSONObject event=joinNotices615.removeFirst();FrameLayout container=findViewById(android.R.id.content);if(container==null)return;joinNoticePlaying615=true;LinearLayout notice=buildJoinEventRow(event);joinNotice615=notice;int width=Math.min(dp(278),Math.max(1,container.getWidth()-dp(20)));FrameLayout.LayoutParams params=new FrameLayout.LayoutParams(width,dp(36),Gravity.TOP|Gravity.START);params.leftMargin=dp(10);int[] page=new int[2],stream=new int[2];container.getLocationOnScreen(page);if(commentsList!=null)commentsList.getLocationOnScreen(stream);params.topMargin=Math.max(dp(80),stream[1]-page[1]-dp(40));container.addView(notice,params);notice.setClickable(false);handler.postDelayed(()->{if(joinNotice615!=notice)return;notice.animate().alpha(0).translationX(-dp(60)).setDuration(240).withEndAction(()->{container.removeView(notice);joinNotice615=null;joinNoticePlaying615=false;playJoin615();}).start();},2800);}
    private LinearLayout buildJoinEventRow(JSONObject e){
        LinearLayout row=row();row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(6),dp(3),dp(8),dp(3));row.setBackground(softGradient(new int[]{0xff144d98,0xff642997,0xff164c8c},12));row.setAlpha(0);row.setTranslationX(dp(50));row.animate().alpha(1).translationX(0).setDuration(350).start();
        FrameLayout av=circleAvatar(e.optString("avatar_url",""),dp(28),false);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(28),dp(28));ap.rightMargin=dp(6);row.addView(av,ap);
        TextView copy=t(shortName(e.optString("full_name","User"))+" "+UiStrings.label(this,"has joined"),11,Color.WHITE,true);AuthorityBadge.decorate(copy,e.optString("user_id",""));copy.setSingleLine(true);copy.setEllipsize(android.text.TextUtils.TruncateAt.END);row.addView(copy,new LinearLayout.LayoutParams(0,dp(30),1));return row;
    }

    private void renderComments(JSONArray comments,JSONArray events,JSONArray highlights){
        if(commentsList==null)return;
        final int before=commentsList.getChildCount();
        final boolean followNewest=commentScroll==null||commentsList.getHeight()-commentScroll.getScrollY()-commentScroll.getHeight()<dp(60);
        if(events!=null){int start=Math.max(0,events.length()-12);for(int i=start;i<events.length();i++){JSONObject e=events.optJSONObject(i);if(e==null)continue;String eventType=e.optString("event_type","");if(!"JOIN".equalsIgnoreCase(eventType))continue;long id=e.optLong("id",0);if(id>0&&!renderedRoomEventIds.add(id))continue;enqueueJoin615(e);LinearLayout n=buildJoinEventRow(e);LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,-2);ep.bottomMargin=dp(3);commentsList.addView(n,ep);}}
        if(highlights!=null){for(int i=0;i<highlights.length();i++){JSONObject h=highlights.optJSONObject(i);if(h==null)continue;long id=h.optLong("id",0);if(id>0&&!renderedHighlightCommentIds.add(id))continue;LinearLayout hi=buildUniversalCommentRow(h,"✨ "+h.optString("full_name","User"),h.optString("message",""),h.optString("gender","UNSPECIFIED"));hi.setTag("paid-highlight");hi.setBackground(softGradient(new int[]{Color.argb(220,76,34,145),Color.argb(220,184,54,156)},13));LinearLayout.LayoutParams hlp=new LinearLayout.LayoutParams(-1,-2);hlp.bottomMargin=dp(3);commentsList.addView(hi,hlp);}}
        if(comments!=null){for(int i=0;i<comments.length();i++){
            JSONObject c=comments.optJSONObject(i);if(c==null)continue;long id=c.optLong("id",0);if(id>0&&!renderedCommentIds.add(id))continue;
            String nonce=c.optString("client_nonce","");if(!nonce.isEmpty()){pendingComments.remove(nonce);removePendingCommentView(nonce);}
            String name=c.optString("full_name","User"),message=c.optString("message",""),gender=c.optString("gender","UNSPECIFIED");
            LinearLayout row=buildUniversalCommentRow(c,name,message,gender);{final String pinText=name+" : "+message;row.setOnLongClickListener(v->{showLiveCommentActions(c,pinText);return true;});}
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(3);commentsList.addView(row,rp);
        }}
        // Keep the approved comment area clean when there are no comments; do not insert placeholder text.
        trimCommentRows();
        if(commentScroll!=null&&commentsList.getChildCount()>before&&followNewest)commentScroll.post(()->commentScroll.fullScroll(View.FOCUS_DOWN));
    }
    private void removePendingCommentView(String nonce){if(commentsList==null)return;String tag="pending:"+nonce;for(int i=commentsList.getChildCount()-1;i>=0;i--){View v=commentsList.getChildAt(i);if(tag.equals(String.valueOf(v.getTag())))commentsList.removeViewAt(i);}}
    private void trimCommentRows(){if(commentsList==null)return;for(int i=commentsList.getChildCount()-1;i>=0;i--){View v=commentsList.getChildAt(i);if("comments-empty".equals(String.valueOf(v.getTag()))&&commentsList.getChildCount()>1)commentsList.removeViewAt(i);}while(commentsList.getChildCount()>100)commentsList.removeViewAt(0);}




    private void updateHighlightControl(TextView control){
        control.setBackground(null);control.clearAnimation();control.setIncludeFontPadding(false);control.setPadding(0,0,0,0);control.setTextSize(20);control.setText(highlightSelected?"🚀\n"+(highlightPrice==0?"FREE":String.format(java.util.Locale.US,"%,d",highlightPrice)):"🚀");
        android.text.SpannableString rocketText=new android.text.SpannableString(control.getText());if(highlightSelected&&rocketText.length()>2)rocketText.setSpan(new android.text.style.AbsoluteSizeSpan(9,true),rocketText.toString().indexOf('\n')+1,rocketText.length(),0);control.setText(rocketText);
        // Android emoji are multicolored; saturation=0 produces a genuine grey inactive rocket.
        if(!highlightSelected){android.graphics.ColorMatrix matrix=new android.graphics.ColorMatrix();matrix.setSaturation(0);android.graphics.Paint paint=new android.graphics.Paint();paint.setColorFilter(new android.graphics.ColorMatrixColorFilter(matrix));control.setLayerType(View.LAYER_TYPE_HARDWARE,paint);control.setAlpha(1f);control.setShadowLayer(0,0,0,Color.TRANSPARENT);}
        else{control.setLayerType(View.LAYER_TYPE_NONE,null);control.setAlpha(1f);control.setShadowLayer(dp(3),0,0,Color.rgb(159,85,255));android.view.animation.ScaleAnimation pulse=new android.view.animation.ScaleAnimation(.96f,1.04f,.96f,1.04f,1,.5f,1,.5f);pulse.setDuration(950);pulse.setRepeatMode(2);pulse.setRepeatCount(-1);control.startAnimation(pulse);}
        control.setContentDescription("Highlight comment • "+(highlightPrice==0?"FREE":highlightPrice+" Coins")+(highlightSelected?" selected":" off"));
    }
    private void sendLiveComment(EditText input,TextView highlight){
        final String m=LiveCommentLimit.truncate(input.getText().toString().trim());if(m.isEmpty()||commentSending)return;
        commentSending=true;if(sendButton!=null){sendButton.setEnabled(false);sendButton.setText("…");}
        final boolean hi=highlightSelected;if(hi&&!m.equals(highlightRequestText)){highlightRequestText=m;highlightRequestId=UUID.randomUUID().toString();}final String nonce="c-"+SessionManager.getUserId(this)+"-"+UUID.randomUUID().toString();

        if(!hi){pendingComments.put(nonce,m);renderPendingOnly(nonce,m);}
        BackendClient.Callback cb=new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                commentSending=false;highlightRequestId="";highlightRequestText="";if(input.getText().toString().trim().equals(m))input.setText("");highlightSelected=false;updateHighlightControl(highlight);if(sendButton!=null){sendButton.setEnabled(!input.getText().toString().trim().isEmpty());sendButton.setText(UiStrings.label(AudioLiveRoomActivity.this,"Send"));sendButton.setAlpha(sendButton.isEnabled()?1f:.45f);}
                JSONObject ack=d.optJSONObject("comment");
                if(!hi && ack!=null) renderAcknowledgedComment(ack,nonce);
                else if(!roomEnded&&!endLiveInProgress) refresh();
                if(input==activeCommentInput&&commentComposerDialog!=null&&commentComposerDialog.isShowing()){liveCommentDraft="";commentComposerDialog.dismiss();}
            });}
            public void onError(String e){runOnUiThread(()->{
                pendingComments.remove(nonce);removePendingCommentView(nonce);commentSending=false;
                if(sendButton!=null){sendButton.setEnabled(!input.getText().toString().trim().isEmpty());sendButton.setText(UiStrings.label(AudioLiveRoomActivity.this,"Send"));sendButton.setAlpha(sendButton.isEnabled()?1f:.45f);}
                Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_SHORT).show();
                if(!roomEnded&&!endLiveInProgress)refresh();
            });}
        };
        if(hi)BackendClient.liveHighlightComment(token(),hostId,m,highlightRequestId,cb);else BackendClient.liveComment(token(),hostId,m,nonce,cb);
    }
    private void renderAcknowledgedComment(JSONObject c,String nonce){
        if(commentsList==null||c==null)return;
        long id=c.optLong("id",0);if(id>0&&!renderedCommentIds.add(id)){pendingComments.remove(nonce);removePendingCommentView(nonce);return;}
        pendingComments.remove(nonce);removePendingCommentView(nonce);
        String name=c.optString("full_name",SessionManager.getFullName(this)),message=c.optString("message",""),gender=c.optString("gender","UNSPECIFIED");
        LinearLayout row=buildUniversalCommentRow(c,name,message,gender);{final String pinText=name+" : "+message;row.setOnLongClickListener(v->{showLiveCommentActions(c,pinText);return true;});}
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(3);commentsList.addView(row,rp);trimCommentRows();if(commentScroll!=null)commentScroll.post(()->commentScroll.smoothScrollTo(0,commentsList.getBottom()));
    }

    private String currentUserGender(){
        String me=SessionManager.getUserId(this);
        JSONObject x=findUser(currentSeats,me);if(x!=null&&!x.optString("gender","").isEmpty())return x.optString("gender","UNSPECIFIED");
        x=findUser(currentViewerProfiles,me);if(x!=null&&!x.optString("gender","").isEmpty())return x.optString("gender","UNSPECIFIED");
        return "UNSPECIFIED";
    }
    private void renderPendingOnly(String nonce,String message){
        if(commentsList==null)return;JSONObject self=new JSONObject();String selfGender=currentUserGender();try{self.put("user_id",SessionManager.getUserId(this));self.put("full_name",SessionManager.getFullName(this));self.put("avatar_url",SessionManager.getAvatarUrl(this));self.put("gender",selfGender);}catch(Exception ignored){}
        LinearLayout pr=buildUniversalCommentRow(self,SessionManager.getFullName(this),message,selfGender);pr.setTag("pending:"+nonce);pr.setAlpha(.84f);
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(3);commentsList.addView(pr,rp);if(commentScroll!=null)commentScroll.post(()->commentScroll.smoothScrollTo(0,commentsList.getBottom()));
    }
    private final java.util.ArrayDeque<JSONObject> entryQueue=new java.util.ArrayDeque<>();
    private View entryStage;private boolean entryPlaying;
    private void renderEntryEffects(JSONArray events){
        if(events==null)return;java.util.ArrayList<JSONObject> fresh=new java.util.ArrayList<>();
        for(int n=0;n<events.length();n++){JSONObject x=events.optJSONObject(n);if(x!=null&&x.optLong("id")>lastEntryEventId)fresh.add(x);}
        java.util.Collections.sort(fresh,(a,b)->Long.compare(a.optLong("id"),b.optLong("id")));
        for(JSONObject x:fresh){lastEntryEventId=Math.max(lastEntryEventId,x.optLong("id"));entryQueue.addLast(x);}playNextEntry();
    }
    private void playNextEntry(){
        if(entryPlaying||entryQueue.isEmpty()||isFinishing())return;JSONObject x=entryQueue.removeFirst();String tier=identityTier(x);
        boolean ride=!x.optString("item_code").isEmpty()||!x.optString("animation_url").isEmpty(),member=MembershipUi.hasFrame(tier);
        if(!ride&&!member){playNextEntry();return;}entryPlaying=true;LinearLayout stage=col();entryStage=stage;stage.setGravity(Gravity.CENTER);stage.setBackgroundColor(Color.TRANSPARENT);
        if(member){MembershipIdentityView identity=new MembershipIdentityView(this,tier,x.optString("avatar_url"));identity.setFrameAsset(x.optString("membership_frame_url"));stage.addView(identity,new LinearLayout.LayoutParams(dp(126),dp(108)));}
        if(ride)stage.addView(new RideEffectView(this,x,true),new LinearLayout.LayoutParams(-1,dp(158)));
        TextView who=t(x.optString("full_name","Member")+" · "+(member?tier:"Welcome"),13,Color.WHITE,true);who.setGravity(Gravity.CENTER);who.setPadding(dp(8),dp(7),dp(8),dp(7));who.setBackground(gradient(new int[]{0xE612193B,0xE650277D},membershipAccent(tier),14));stage.addView(who,new LinearLayout.LayoutParams(-1,-2));
        int width=Math.min(dp(320),getResources().getDisplayMetrics().widthPixels-dp(24));addContentView(stage,new ViewGroup.LayoutParams(width,-2));stage.setX((getResources().getDisplayMetrics().widthPixels-width)/2f);stage.setY(dp(130));stage.setAlpha(0);stage.animate().alpha(1).setDuration(200).start();
        handler.postDelayed(()->{stage.animate().alpha(0).setDuration(180).withEndAction(()->{if(stage.getParent() instanceof ViewGroup)((ViewGroup)stage.getParent()).removeView(stage);entryStage=null;entryPlaying=false;playNextEntry();}).start();},Math.max(1500,Math.min(15000,x.optInt("effect_duration_ms",3500))));
    }
    private String entryAnimationIcon(String code){String c=String.valueOf(code).toUpperCase(Locale.US);if(c.contains("BICYCLE"))return "🚲";if(c.contains("MOTORCYCLE")||c.contains("BIKE"))return "🏍";if(c.contains("CAR")||c.contains("LIMO"))return "🏎";if(c.contains("HORSE"))return "🐎";if(c.contains("HELICOPTER"))return "🚁";if(c.contains("JET"))return "✈";if(c.contains("ROCKET")||c.contains("SPACESHIP"))return "🚀";if(c.contains("BOAT"))return "🚤";if(c.contains("UFO"))return "🛸";if(c.contains("LION"))return "🦁";if(c.contains("DRAGON"))return "🐉";if(c.contains("PHOENIX"))return "🔥";if(c.contains("UNICORN"))return "🦄";if(c.contains("BALLOON"))return "🎈";if(c.contains("EAGLE"))return "🦅";if(c.contains("TIGER"))return "🐯";if(c.contains("CLOUD"))return "☁";if(c.contains("PORTAL"))return "🌀";return "✨";}
    private final ManagedSoundPlayer entrySound430=new ManagedSoundPlayer();
    private void playEntrySound(String url,int volume,int durationMs){entrySound430.play(url,volume,durationMs,message->android.util.Log.w("MYSHOP_ENTRY_SOUND",message));}

    private long lastVoteCelebration=-1,lastReactionCelebration=-1;
    private final java.util.ArrayDeque<String> celebrationQueue=new java.util.ArrayDeque<>();
    private boolean celebrationPlaying=false;
    private View celebrationOverlay;
    private void checkCelebrations(JSONObject d){
        long votes=voteCount/100,reward=d.optLong("reactRewardMilestone",0)>0?1:0;
        if(lastVoteCelebration<0){lastVoteCelebration=votes;lastReactionCelebration=reward;return;}
        if(votes>lastVoteCelebration){for(long milestone=lastVoteCelebration+1;milestone<=votes;milestone++)celebrationQueue.add("🎉 "+(milestone*100)+" ভোট পূর্ণ!");lastVoteCelebration=votes;}
        if(reward==0)lastReactionCelebration=0;
        if(reward>lastReactionCelebration){celebrationQueue.add("🎉 ২,০০০ রিঅ্যাকশন!\n+১,০০০ কয়েন");lastReactionCelebration=reward;}
        playCelebration();
    }
    private void playCelebration(){
        if(celebrationPlaying||celebrationQueue.isEmpty()||roomEnded||isFinishing())return;
        celebrationPlaying=true;final String message=celebrationQueue.removeFirst(),session=activeSessionId;
        final FrameLayout overlay=new FrameLayout(this);celebrationOverlay=overlay;overlay.setClickable(false);addContentView(overlay,new ViewGroup.LayoutParams(-1,-1));
        addGiftParticles(overlay,"star",48);
        final LinearLayout card=col();card.setGravity(Gravity.CENTER);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-1,dp(260),Gravity.CENTER);overlay.addView(card,lp);
        final TextView number=t("5",76,0xffffdc71,true);number.setGravity(Gravity.CENTER);card.addView(number,new LinearLayout.LayoutParams(-1,dp(115)));
        final TextView caption=t("🌠",38,Color.WHITE,true);caption.setGravity(Gravity.CENTER);card.addView(caption,new LinearLayout.LayoutParams(-1,dp(80)));
        for(int i=1;i<=5;i++){final int step=i;handler.postDelayed(()->{if(roomEnded||!session.equals(activeSessionId)||celebrationOverlay!=overlay)return;if(step<5){number.setText(String.valueOf(5-step));number.setScaleX(.75f);number.setScaleY(.75f);number.animate().scaleX(1).scaleY(1).setDuration(250).start();}else{number.setText(message);number.setTextSize(25);caption.setText(currentLiveName);card.addView(avatarWithMicState(cachedHostProfile,dp(64),false),0,new LinearLayout.LayoutParams(dp(64),dp(64)));}},i*1000L);}
        handler.postDelayed(()->{if(overlay.getParent() instanceof ViewGroup)((ViewGroup)overlay.getParent()).removeView(overlay);if(celebrationOverlay==overlay){celebrationOverlay=null;celebrationPlaying=false;playCelebration();}},8500);
    }
    private void clearSessionEffects(){
        joinNotices615.clear();if(joinNotice615!=null&&joinNotice615.getParent() instanceof ViewGroup)((ViewGroup)joinNotice615.getParent()).removeView(joinNotice615);joinNotice615=null;joinNoticePlaying615=false;giftEffectQueue.clear();celebrationQueue.clear();entryQueue.clear();giftEffectPlaying=false;celebrationPlaying=false;lastVoteCelebration=-1;lastReactionCelebration=-1;
        for(View v:new View[]{activeGiftOverlay,celebrationOverlay,entryStage})if(v!=null&&v.getParent() instanceof ViewGroup)((ViewGroup)v.getParent()).removeView(v);
        activeGiftOverlay=null;celebrationOverlay=null;entryStage=null;entryPlaying=false;
    }
    private void renderMilestones(JSONArray a){if(a==null)return;for(int i=0;i<a.length();i++){String k=a.optString(i,"");if(!k.isEmpty()&&shownMilestones.add(k))showFloatingBanner("🏆 "+k.replace('_',' '));}}
    private void showFloatingBanner(String text){final TextView b=t(text,12,Color.WHITE,true);b.setGravity(Gravity.CENTER);b.setBackground(gradient(new int[]{Color.argb(235,102,43,178),Color.argb(235,219,64,143)},Color.rgb(255,223,101),18));addContentView(b,new android.view.ViewGroup.LayoutParams(dp(300),dp(42)));b.setX((getResources().getDisplayMetrics().widthPixels-dp(300))/2f);b.setY(dp(110));b.setAlpha(0f);b.animate().alpha(1f).translationY(dp(10)).setDuration(220).withEndAction(()->handler.postDelayed(()->b.animate().alpha(0f).setDuration(350).withEndAction(()->{if(b.getParent()!=null)((android.view.ViewGroup)b.getParent()).removeView(b);}).start(),1800)).start();}
    private void renderGiftActivityComment(JSONObject e){
        if(commentsList==null||e==null)return;
        LinearLayout giftRow=row();giftRow.setGravity(Gravity.CENTER_VERTICAL);giftRow.setPadding(dp(7),dp(4),dp(8),dp(4));giftRow.setBackground(gradient(new int[]{Color.argb(218,31,73,153),Color.argb(218,83,35,145)},Color.rgb(68,207,255),13));
        FrameLayout av=circleAvatar(e.optString("sender_avatar",""),dp(40),false);giftRow.addView(av,new LinearLayout.LayoutParams(dp(40),dp(40)));
        ImageView giftThumb=new ImageView(this);giftThumb.setScaleType(ImageView.ScaleType.CENTER_INSIDE);String giftAsset=e.optString("preview_url","");if(giftAsset.isEmpty())giftAsset=e.optString("animation_url","");if(!giftAsset.isEmpty())AnimatedAssetLoader.load(giftThumb,giftAsset);else giftThumb.setImageResource(builtInGiftArt(e.optString("name","Gift")));LinearLayout.LayoutParams gtp=new LinearLayout.LayoutParams(dp(48),dp(48));gtp.leftMargin=dp(6);giftRow.addView(giftThumb,gtp);
        String sender=e.optString("sender_name","Supporter"),gift=e.optString("name","Gift"),receiver=e.optString("receiver_name",currentLiveName);int price=e.optInt("price",0),level=e.optInt("sender_level",e.optInt("level",0)),qty=Math.max(1,e.optInt("quantity",e.optInt("combo",1)));String currency="GOLD".equalsIgnoreCase(e.optString("currency","COIN"))?"Diamond":"Coin";
        LinearLayout body=col();body.setPadding(dp(6),0,0,0);
        TextView who=t(sender+"  ⭐ LV."+level,13.6f,Color.rgb(255,231,111),true);AuthorityBadge.decorate(who,e.optString("sender_id",""));who.setMaxLines(1);body.addView(who,new LinearLayout.LayoutParams(-1,-2));
        TextView what=t("🎁 sent "+gift+" ×"+qty+"  •  "+price+" "+currency,14.2f,Color.WHITE,true);what.setMaxLines(1);what.setEllipsize(android.text.TextUtils.TruncateAt.END);body.addView(what,new LinearLayout.LayoutParams(-1,-2));
        TextView to=t("to "+receiver,9.8f,Color.rgb(205,225,255),false);to.setMaxLines(1);body.addView(to,new LinearLayout.LayoutParams(-1,-2));
        giftRow.addView(body,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(4);commentsList.addView(giftRow,rp);trimCommentRows();if(commentScroll!=null)commentScroll.post(()->commentScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void renderGiftActivityEventsOnly(JSONArray arr){
        if(arr==null||arr.length()==0)return;
        for(int i=0;i<arr.length();i++){
            JSONObject e=arr.optJSONObject(i);if(e==null)continue;long id=e.optLong("id",0);if(id>0&&!renderedGiftEventIds.add(id))continue;
            renderGiftActivityComment(e);
        }
    }

    private void renderGiftEffectsOnly(JSONArray arr){
        if(arr==null||arr.length()==0)return;
        for(int i=0;i<arr.length();i++){
            JSONObject e=arr.optJSONObject(i);if(e==null)continue;long id=e.optLong("id",0);if(id<=lastGiftEventId)continue;
            lastGiftEventId=id;if(!renderedGiftEffectIds.add(id))continue;
            JSONObject g=new JSONObject();try{g.put("name",e.optString("name","Gift")).put("currency",e.optString("currency","COIN")).put("price",e.optInt("price",1)).put("preview_url",e.optString("preview_url","")).put("animation_url",e.optString("animation_url","")).put("animation_mime",e.optString("animation_mime","")).put("animation_enabled",e.optInt("animation_enabled",1)).put("sound_url",e.optString("sound_url","")).put("sound_enabled",e.optInt("sound_enabled",1)).put("sound_volume",e.optInt("sound_volume",92)).put("effect_duration_ms",e.optInt("effect_duration_ms",4200)).put("sound_duration_ms",e.optInt("sound_duration_ms",3800)).put("sound_trim_start_pct",e.optInt("sound_trim_start_pct",0)).put("sound_trim_end_pct",e.optInt("sound_trim_end_pct",100)).put("vat_percent",e.optInt("vat_percent",10)).put("board_position",e.optString("board_position","CENTER")).put("animation_scale",e.optInt("animation_scale",82)).put("size_mode",e.optString("size_mode","MEDIUM"));}catch(Exception ignored){}
            JSONObject r=new JSONObject();try{r.put("eventId",id).put("receiverId",e.optString("receiver_id",hostId)).put("receiverName",e.optString("receiver_name",currentLiveName)).put("combo",Math.max(1,e.optInt("combo",1))).put("quantity",e.optInt("quantity",1)).put("senderName",e.optString("sender_name","Supporter"));}catch(Exception ignored){}
            showGiftEffect(g,r);
        }
    }

    private void renderGiftEvents(JSONArray arr){if(!host&&!visitReady)return;renderGiftActivityEventsOnly(arr);renderGiftEffectsOnly(arr);}


    private int builtInGiftArt(String name){
        int v381=GiftBuiltIns.art(name);if(v381!=0)return v381;
        String n=String.valueOf(name).toLowerCase(Locale.US);
        if(n.contains("neon prism"))return R.drawable.gift_v375_neon_prism;
        if(n.contains("panda cheer"))return R.drawable.gift_v375_panda_cheer;
        if(n.contains("love balloons"))return R.drawable.gift_v375_love_balloons;
        if(n.contains("celebration burst"))return R.drawable.gift_v375_celebration_burst;
        if(n.contains("sweet surprise"))return R.drawable.gift_v375_sweet_surprise;
        if(n.contains("lucky clover"))return R.drawable.gift_v375_lucky_clover;
        if(n.contains("butterfly glow"))return R.drawable.gift_v375_butterfly_glow;
        if(n.contains("music pulse"))return R.drawable.gift_v375_music_pulse;
        if(n.contains("sakura dream"))return R.drawable.gift_v375_sakura_dream;
        if(n.contains("turbo bike"))return R.drawable.gift_v375_turbo_bike;
        if(n.contains("royal scepter"))return R.drawable.gift_v375_royal_scepter;
        if(n.contains("aurora orb"))return R.drawable.gift_v375_aurora_orb;
        if(n.contains("celestial wings"))return R.drawable.gift_v375_celestial_wings;
        if(n.contains("time portal"))return R.drawable.gift_v375_time_portal;
        if(n.contains("ocean voyager"))return R.drawable.gift_v375_ocean_voyager;
        if(n.contains("fire phoenix"))return R.drawable.gift_v375_fire_phoenix;
        if(n.contains("rainbow unicorn"))return R.drawable.gift_v375_rainbow_unicorn;
        if(n.contains("moon romance"))return R.drawable.gift_v375_moon_romance;
        if(n.contains("starship"))return R.drawable.gift_v375_starship;
        if(n.contains("golden dragon"))return R.drawable.gift_v375_golden_dragon;
        if(n.contains("rose"))return R.drawable.gift_rose;
        if(n.contains("heart"))return R.drawable.gift_heart;
        if(n.contains("teddy"))return R.drawable.gift_teddy;
        if(n.contains("chocolate"))return R.drawable.gift_chocolate;
        if(n.equals("star")||n.contains("super star"))return R.drawable.gift_star;
        if(n.contains("diamond"))return R.drawable.gift_diamond;
        if(n.contains("crown"))return R.drawable.gift_crown;
        if(n.contains("car"))return R.drawable.gift_car;
        if(n.contains("jet"))return R.drawable.gift_jet;
        if(n.contains("castle"))return R.drawable.gift_castle;
        return R.drawable.gift_star;
    }
    private int builtInGiftSound(String name){
        int v381=GiftBuiltIns.sound(name);if(v381!=0)return v381;
        String n=String.valueOf(name).toLowerCase(Locale.US);
        if(n.contains("neon prism"))return R.raw.gift_v375_neon_prism_sound;
        if(n.contains("panda cheer"))return R.raw.gift_v375_panda_cheer_sound;
        if(n.contains("love balloons"))return R.raw.gift_v375_love_balloons_sound;
        if(n.contains("celebration burst"))return R.raw.gift_v375_celebration_burst_sound;
        if(n.contains("sweet surprise"))return R.raw.gift_v375_sweet_surprise_sound;
        if(n.contains("lucky clover"))return R.raw.gift_v375_lucky_clover_sound;
        if(n.contains("butterfly glow"))return R.raw.gift_v375_butterfly_glow_sound;
        if(n.contains("music pulse"))return R.raw.gift_v375_music_pulse_sound;
        if(n.contains("sakura dream"))return R.raw.gift_v375_sakura_dream_sound;
        if(n.contains("turbo bike"))return R.raw.gift_v375_turbo_bike_sound;
        if(n.contains("royal scepter"))return R.raw.gift_v375_royal_scepter_sound;
        if(n.contains("aurora orb"))return R.raw.gift_v375_aurora_orb_sound;
        if(n.contains("celestial wings"))return R.raw.gift_v375_celestial_wings_sound;
        if(n.contains("time portal"))return R.raw.gift_v375_time_portal_sound;
        if(n.contains("ocean voyager"))return R.raw.gift_v375_ocean_voyager_sound;
        if(n.contains("fire phoenix"))return R.raw.gift_v375_fire_phoenix_sound;
        if(n.contains("rainbow unicorn"))return R.raw.gift_v375_rainbow_unicorn_sound;
        if(n.contains("moon romance"))return R.raw.gift_v375_moon_romance_sound;
        if(n.contains("starship"))return R.raw.gift_v375_starship_sound;
        if(n.contains("golden dragon"))return R.raw.gift_v375_golden_dragon_sound;
        if(n.contains("rose"))return R.raw.gift_rose_sound;
        if(n.contains("heart"))return R.raw.gift_heart_sound;
        if(n.contains("teddy"))return R.raw.gift_teddy_sound;
        if(n.contains("chocolate"))return R.raw.gift_chocolate_sound;
        if(n.equals("star")||n.contains("super star"))return R.raw.gift_star_sound;
        if(n.contains("diamond"))return R.raw.gift_diamond_sound;
        if(n.contains("crown"))return R.raw.gift_crown_sound;
        if(n.contains("car"))return R.raw.gift_car_sound;
        if(n.contains("jet"))return R.raw.gift_jet_sound;
        if(n.contains("castle"))return R.raw.gift_castle_sound;
        return 0;
    }
    // V-380: Love Balloons + Celebration Burst live-board effects use transparent
    // premium artwork instead of the old square/card PNG. Admin-uploaded custom
    // animation/preview URLs still take priority, so existing Gift Manager controls
    // and backend behavior remain unchanged.
    private Bitmap v380PremiumGiftBitmap(String name){
        String n=String.valueOf(name).toLowerCase(Locale.US);
        if(!n.contains("love balloons")&&!n.contains("celebration burst"))return null;
        final int size=512;
        Bitmap bmp=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(bmp);
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStrokeCap(Paint.Cap.ROUND);

        if(n.contains("love balloons")){
            // Three clean heart balloons on a transparent canvas — visually aligned
            // with the simple Rose/Heart live effects, without any rectangular panel.
            v380DrawHeart(c,p,258,218,150,Color.rgb(255,39,112));
            v380DrawHeart(c,p,154,154,92,Color.rgb(255,92,158));
            v380DrawHeart(c,p,358,142,105,Color.rgb(255,52,124));
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(7f);p.setColor(Color.argb(220,255,205,226));
            c.drawLine(258,290,255,430,p);c.drawLine(154,198,232,430,p);c.drawLine(358,193,278,430,p);
            p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);
            c.drawCircle(214,180,10,p);c.drawCircle(331,114,8,p);c.drawCircle(129,126,7,p);
            p.setStrokeWidth(5f);p.setStyle(Paint.Style.STROKE);p.setColor(Color.argb(235,255,226,239));
            c.drawLine(102,226,132,226,p);c.drawLine(117,211,117,241,p);
            c.drawLine(390,237,420,237,p);c.drawLine(405,222,405,252,p);
            return bmp;
        }

        // Celebration Burst: transparent fireworks/sparkles. No dark square image.
        int[][] bursts={{256,242,Color.rgb(255,177,52)},{174,202,Color.rgb(224,66,255)},{342,188,Color.rgb(66,176,255)}};
        for(int[] b:bursts){
            float cx=b[0],cy=b[1];int color=b[2];
            for(int i=0;i<18;i++){
                double a=(Math.PI*2*i)/18.0;float inner=34f+(i%3)*7f,outer=108f+(i%4)*12f;
                float x1=cx+(float)Math.cos(a)*inner,y1=cy+(float)Math.sin(a)*inner;
                float x2=cx+(float)Math.cos(a)*outer,y2=cy+(float)Math.sin(a)*outer;
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(i%3==0?8f:5f);p.setColor(color);c.drawLine(x1,y1,x2,y2,p);
                p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);c.drawCircle(x2,y2,i%3==0?7f:4.5f,p);
            }
            p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);c.drawCircle(cx,cy,14f,p);
        }
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(6f);p.setColor(Color.rgb(255,111,67));
        c.drawLine(252,270,226,430,p);c.drawLine(262,270,291,430,p);
        p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(255,232,109));
        c.drawCircle(96,124,8,p);c.drawCircle(420,122,9,p);c.drawCircle(104,348,7,p);c.drawCircle(407,342,7,p);
        return bmp;
    }
    private void v380DrawHeart(Canvas c,Paint p,float cx,float cy,float size,int color){
        float s=size/100f;Path h=new Path();h.moveTo(cx,cy+38*s);
        h.cubicTo(cx-72*s,cy-7*s,cx-61*s,cy-78*s,cx-18*s,cy-75*s);
        h.cubicTo(cx-2*s,cy-74*s,cx+12*s,cy-63*s,cx,cy-48*s);
        h.cubicTo(cx+19*s,cy-70*s,cx+61*s,cy-76*s,cx+72*s,cy-40*s);
        h.cubicTo(cx+87*s,cy+7*s,cx+35*s,cy+48*s,cx,cy+78*s);h.close();
        p.setStyle(Paint.Style.FILL);p.setColor(color);c.drawPath(h,p);
        p.setColor(Color.argb(150,255,255,255));c.drawCircle(cx-24*s,cy-31*s,10*s,p);
    }
    private void setGiftArt(ImageView art,JSONObject gift){
        String asset=gift.optString("animation_url","");if(asset.isEmpty())asset=gift.optString("preview_url","");
        if(!asset.isEmpty()){AnimatedAssetLoader.load(art,asset);if(art.getDrawable() instanceof GiftArt620)((GiftArt620)art.getDrawable()).playOnce(gift.optInt("effect_duration_ms",6000));if(art.getDrawable() instanceof GiftArt619)((GiftArt619)art.getDrawable()).playOnce(gift.optInt("effect_duration_ms",3200));return;}
        Bitmap premium=v380PremiumGiftBitmap(gift.optString("name","Gift"));
        if(premium!=null){art.setImageBitmap(premium);return;}
        art.setImageResource(builtInGiftArt(gift.optString("name","Gift")));
    }
    private int giftInt(JSONObject gift,String snake,String camel,int def){
        if(gift==null)return def;Object v=gift.opt(snake);if(v==null||v==JSONObject.NULL)v=gift.opt(camel);if(v==null||v==JSONObject.NULL)return def;
        if(v instanceof Number)return ((Number)v).intValue();if(v instanceof Boolean)return ((Boolean)v)?1:0;try{return Integer.parseInt(String.valueOf(v).trim());}catch(Exception ignored){return def;}
    }
    private String giftString(JSONObject gift,String snake,String camel){if(gift==null)return "";String v=gift.optString(snake,"").trim();if(v.isEmpty())v=gift.optString(camel,"").trim();return v;}
    private void playBuiltInGiftSound(int resId,float volume,int maxDuration){
        if(resId==0||volume<=0f)return;
        try{
            final android.media.MediaPlayer fb=new android.media.MediaPlayer();giftPlayers613.add(fb);
            // V-353: gift audio uses the normal media stream. SONIFICATION + transient focus
            // could be inaudible on some devices and could also duck/interrupt Agora voice.
            android.media.AudioAttributes aa=new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build();fb.setAudioAttributes(aa);
            android.content.res.AssetFileDescriptor afd=getResources().openRawResourceFd(resId);if(afd==null){fb.release();return;}fb.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());afd.close();fb.prepare();fb.setVolume(volume,volume);
            final int targetDuration=Math.max(1500,Math.min(maxDuration,7000));if(fb.getDuration()>0&&fb.getDuration()<1200&&targetDuration>fb.getDuration()+150)fb.setLooping(true);
            final android.media.audiofx.LoudnessEnhancer[] boost={null};try{boost[0]=new android.media.audiofx.LoudnessEnhancer(fb.getAudioSessionId());boost[0].setTargetGain(500);boost[0].setEnabled(true);}catch(Throwable ignored){}
            final boolean[] done={false};final Runnable release=()->{if(done[0])return;done[0]=true;try{if(fb.isPlaying())fb.stop();}catch(Exception ignored){}try{if(boost[0]!=null){boost[0].setEnabled(false);boost[0].release();}}catch(Exception ignored){}giftPlayers613.remove(fb);try{fb.release();}catch(Exception ignored){}};
            fb.setOnCompletionListener(x->release.run());fb.setOnErrorListener((x,w,e)->{release.run();return true;});fb.start();handler.postDelayed(release,targetDuration);
        }catch(Exception ignored){}
    }
    private final java.util.Set<android.media.MediaPlayer> giftPlayers613=new java.util.HashSet<>();
    private void stopGiftSounds613(){for(android.media.MediaPlayer player:new java.util.ArrayList<>(giftPlayers613))try{player.stop();}catch(Exception ignored){}}
    private boolean giftSoundEnabled613=true;
    private void playGiftSound(JSONObject gift){if(!giftSoundEnabled613)return;
        if(giftInt(gift,"sound_enabled","soundEnabled",1)!=1)return;
        final float volume=Math.max(0f,Math.min(1f,giftInt(gift,"sound_volume","soundVolume",92)/100f));if(volume<=0f)return;
        final int configuredDuration=Math.max(600,giftInt(gift,"sound_duration_ms","soundDurationMs",3800));final int maxDuration=Math.max(1200,Math.min(18000,Math.round(configuredDuration*1.45f)));
        final String url=giftString(gift,"sound_url","soundUrl");final String giftName=gift.optString("name","Gift");final int fallbackRes=builtInGiftSound(giftName);final boolean[] fallbackUsed={false};
        final Runnable playFallback=()->{if(fallbackUsed[0])return;fallbackUsed[0]=true;playBuiltInGiftSound(fallbackRes,volume,maxDuration);};
        if(url.isEmpty()){playFallback.run();return;}
        try{
            final android.media.MediaPlayer mp=new android.media.MediaPlayer();giftPlayers613.add(mp);android.media.AudioAttributes aa=new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build();mp.setAudioAttributes(aa);GiftSounds619.configure(this,mp,url);
            final boolean[] released={false},prepared={false};final android.media.audiofx.LoudnessEnhancer[] boost={null};
            final Runnable release=()->{if(released[0])return;released[0]=true;try{if(mp.isPlaying())mp.stop();}catch(Exception ignored){}try{if(boost[0]!=null){boost[0].setEnabled(false);boost[0].release();}}catch(Exception ignored){}giftPlayers613.remove(mp);try{mp.reset();}catch(Exception ignored){}try{mp.release();}catch(Exception ignored){}};
            final Runnable watchdog=()->{if(!prepared[0]&&!released[0]){release.run();playFallback.run();}};handler.postDelayed(watchdog,1200L);
            mp.setOnPreparedListener(x->{prepared[0]=true;handler.removeCallbacks(watchdog);if(released[0])return;if(!giftSoundEnabled613){release.run();return;}try{x.setVolume(volume,volume);try{boost[0]=new android.media.audiofx.LoudnessEnhancer(x.getAudioSessionId());boost[0].setTargetGain(400);boost[0].setEnabled(true);}catch(Throwable ignored){}int total=Math.max(1,x.getDuration());int startPct=Math.max(0,Math.min(99,giftInt(gift,"sound_trim_start_pct","soundTrimStartPct",0)));int endPct=Math.max(startPct+1,Math.min(100,giftInt(gift,"sound_trim_end_pct","soundTrimEndPct",100)));int startMs=(int)((long)total*startPct/100L);int endMs=(int)((long)total*endPct/100L);int segmentMs=Math.max(100,endMs-startMs);int playMs=Math.min(maxDuration,segmentMs);x.setLooping(false);if(startMs>0){x.setOnSeekCompleteListener(player->{try{player.start();handler.postDelayed(release,playMs);}catch(Exception failure){release.run();}});x.seekTo(startMs);}else{x.start();handler.postDelayed(release,playMs);}}catch(Exception ex){release.run();playFallback.run();}});
            mp.setOnCompletionListener(x->release.run());mp.setOnErrorListener((x,w,e)->{handler.removeCallbacks(watchdog);release.run();playFallback.run();return true;});mp.prepareAsync();
        }catch(Exception ex){playFallback.run();}
    }

    private int giftScale(JSONObject gift){
        if(gift.has("animation_scale"))return Math.max(0,Math.min(100,gift.optInt("animation_scale",70)));
        String m=gift.optString("size_mode","MEDIUM").toUpperCase(Locale.US);if("SMALL".equals(m))return 15;if("LARGE".equals(m))return 75;if("FULL_SCREEN".equals(m))return 100;return 48;
    }
    private String giftModeForScale(int scale){if(scale<=20)return "SMALL";if(scale<=58)return "MEDIUM";if(scale<=84)return "LARGE";return "FULL_SCREEN";}
    private int giftArtPx(int scale){
        int w=getResources().getDisplayMetrics().widthPixels,h=getResources().getDisplayMetrics().heightPixels,base=Math.min(w,h);
        float pct=Math.max(0,Math.min(100,scale))/100f;
        return Math.max(1,(int)(base*pct));
    }
    private String giftParticleSymbol(String name){
        String n=String.valueOf(name).toLowerCase(Locale.US);
        if(n.contains("rose")||n.contains("flower"))return "✿";
        if(n.contains("heart")||n.contains("love"))return "♥";
        if(n.contains("diamond")||n.contains("ring"))return "◆";
        if(n.contains("crown")||n.contains("throne")||n.contains("palace"))return "✦";
        if(n.contains("fire")||n.contains("party"))return "✹";
        if(n.contains("butterfly")||n.contains("wing")||n.contains("phoenix"))return "✧";
        if(n.contains("moon")||n.contains("galaxy")||n.contains("star"))return "★";
        return "✦";
    }
    private void addGiftParticles(FrameLayout overlay,String name,int count){
        String symbol=giftParticleSymbol(name);String n=String.valueOf(name).toLowerCase(Locale.US);
        int w=getResources().getDisplayMetrics().widthPixels,h=getResources().getDisplayMetrics().heightPixels;
        for(int i=0;i<count;i++){
            final TextView p=t(symbol,12+(i%5)*3,(i%3==0&&n.contains("gold"))?Color.rgb(255,205,72):Color.WHITE,true);p.setGravity(Gravity.CENTER);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(34),dp(34));overlay.addView(p,lp);
            float x=(w*.05f)+((i*83)%(Math.max(1,(int)(w*.90f))));float y=h*(.76f+(i%5)*.028f);p.setX(x);p.setY(y);p.setAlpha(0f);p.setScaleX(.2f);p.setScaleY(.2f);
            long delay=(i%9)*55L;float rise=h*(.30f+(i%7)*.055f);float drift=((i%2==0)?1:-1)*dp(18+(i%6)*10);
            p.animate().alpha(.98f).scaleX(1f+(i%3)*.08f).scaleY(1f+(i%3)*.08f).translationY(-rise).translationX(drift).rotationBy((i%2==0?1:-1)*(70+(i%6)*24)).setStartDelay(delay).setDuration(1450+(i%5)*210L).withEndAction(()->p.animate().alpha(0f).setDuration(340).start()).start();
        }
    }
    private void addGiftBurstRings(FrameLayout overlay,boolean gold){
        int[] strokes=gold?new int[]{Color.rgb(255,205,70),Color.rgb(255,116,194),Color.rgb(104,169,255)}:new int[]{Color.rgb(255,106,202),Color.rgb(130,112,255),Color.rgb(79,208,255)};
        for(int i=0;i<3;i++){
            View ring=new View(this);android.graphics.drawable.GradientDrawable gd=new android.graphics.drawable.GradientDrawable();gd.setShape(android.graphics.drawable.GradientDrawable.OVAL);gd.setColor(Color.TRANSPARENT);gd.setStroke(dp(i==0?3:2),Color.argb(210,Color.red(strokes[i]),Color.green(strokes[i]),Color.blue(strokes[i])));ring.setBackground(gd);int side=dp(150+i*38);FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(side,side,Gravity.CENTER);overlay.addView(ring,lp);ring.setScaleX(.25f);ring.setScaleY(.25f);ring.setAlpha(.88f);ring.animate().scaleX(2.15f+i*.25f).scaleY(2.15f+i*.25f).alpha(0f).setStartDelay(i*120L).setDuration(1050+i*180L).start();
        }
    }
    private void animateGiftArt(ImageView art,String name,String sizeMode){
        String n=String.valueOf(name).toLowerCase(Locale.US);int sw=getResources().getDisplayMetrics().widthPixels,sh=getResources().getDisplayMetrics().heightPixels;
        art.setAlpha(0f);art.setScaleX(.38f);art.setScaleY(.38f);art.setTranslationX(0f);art.setTranslationY(0f);art.setRotation(0f);
        if(n.contains("car")||n.contains("bike")){
            art.setTranslationX(-sw*.78f);art.setTranslationY(dp(70));art.setAlpha(1f);art.setScaleX(.78f);art.setScaleY(.78f);art.animate().translationX(0f).translationY(0f).scaleX(1.12f).scaleY(1.12f).setDuration(1500).withEndAction(()->art.animate().translationX(sw*.48f).scaleX(.98f).scaleY(.98f).setDuration(1450).start()).start();return;
        }
        if(n.contains("jet")){
            art.setTranslationX(-sw*.72f);art.setTranslationY(sh*.24f);art.setRotation(-15f);art.setAlpha(1f);art.setScaleX(.72f);art.setScaleY(.72f);art.animate().translationX(0f).translationY(-dp(25)).rotation(2f).scaleX(1.18f).scaleY(1.18f).setDuration(1700).withEndAction(()->art.animate().translationX(sw*.58f).translationY(-sh*.22f).rotation(10f).setDuration(1650).start()).start();return;
        }
        if(n.contains("yacht")){
            art.setTranslationX(sw*.60f);art.setTranslationY(dp(55));art.setAlpha(1f);art.setScaleX(.76f);art.setScaleY(.76f);art.animate().translationX(0f).translationY(0f).scaleX(1.12f).scaleY(1.12f).setDuration(1800).withEndAction(()->art.animate().translationX(-dp(28)).translationY(-dp(12)).setDuration(1100).start()).start();return;
        }
        if(n.contains("dragon")||n.contains("phoenix")||n.contains("peacock")||n.contains("butterfly")||n.contains("wing")){
            art.setTranslationY(dp(180));art.setRotation(-8f);art.animate().alpha(1f).translationY(-dp(30)).rotation(5f).scaleX(1.16f).scaleY(1.16f).setDuration(1550).withEndAction(()->art.animate().translationY(-dp(48)).rotation(-2f).scaleX(1.03f).scaleY(1.03f).setDuration(1350).start()).start();return;
        }
        if(n.contains("fireworks")||n.contains("firecracker")||n.contains("party popper")||n.contains("diamond rain")){
            art.setScaleX(.18f);art.setScaleY(.18f);art.animate().alpha(1f).scaleX(1.28f).scaleY(1.28f).setDuration(720).withEndAction(()->art.animate().scaleX(.96f).scaleY(.96f).setDuration(280).withEndAction(()->art.animate().scaleX(1.08f).scaleY(1.08f).setDuration(800).start()).start()).start();return;
        }
        if(n.contains("rose")||n.contains("flower")||n.contains("balloon")){
            art.setTranslationY(dp(165));art.setRotation(-8f);art.animate().alpha(1f).translationY(-dp(28)).rotation(5f).scaleX(1.15f).scaleY(1.15f).setDuration(1350).withEndAction(()->art.animate().translationY(-dp(42)).rotation(-3f).scaleX(1.02f).scaleY(1.02f).setDuration(1300).start()).start();return;
        }
        if(n.contains("heart")||n.contains("teddy")||n.contains("cake")||n.contains("ice cream")||n.contains("chocolate")){
            art.animate().alpha(1f).scaleX(1.20f).scaleY(1.20f).setDuration(620).withEndAction(()->art.animate().scaleX(.98f).scaleY(.98f).setDuration(320).withEndAction(()->art.animate().scaleX(1.08f).scaleY(1.08f).translationY(-dp(24)).setDuration(900).start()).start()).start();return;
        }
        if(n.contains("crown")||n.contains("throne")||n.contains("palace")||n.contains("treasure")||n.contains("lion")||n.contains("elephant")||n.contains("perfume")||n.contains("coffee")){
            art.setTranslationY(dp(100));art.animate().alpha(1f).translationY(-dp(18)).scaleX(1.18f).scaleY(1.18f).setDuration(1450).withEndAction(()->art.animate().scaleX(1.04f).scaleY(1.04f).translationY(-dp(34)).setDuration(1250).start()).start();return;
        }
        if(n.contains("galaxy")||n.contains("rainbow")||n.contains("moon")||n.contains("magic wand")||n.contains("star")||n.contains("ring")){
            art.setRotation(-10f);art.animate().alpha(1f).rotation(7f).scaleX(1.18f).scaleY(1.18f).setDuration(1250).withEndAction(()->art.animate().rotation(-3f).scaleX(1.04f).scaleY(1.04f).setDuration(1350).start()).start();return;
        }
        art.animate().alpha(1f).scaleX(1.14f).scaleY(1.14f).translationY(-dp(22)).setDuration(1450).withEndAction(()->art.animate().scaleX(1.03f).scaleY(1.03f).setDuration(1000).start()).start();
    }
    private void showGiftEffect(JSONObject gift,JSONObject result){giftEffectQueue.addLast(new JSONObject[]{gift,result});playNextGiftEffect();}
    private void playNextGiftEffect(){if(giftEffectPlaying||giftEffectQueue.isEmpty()||isFinishing())return;JSONObject[] pair=giftEffectQueue.removeFirst();giftEffectPlaying=true;showGiftEffectNow(pair[0],pair[1]);}
    private void showGiftEffectNow(JSONObject gift,JSONObject result){
        final int combo=Math.max(1,result.optInt("combo",1));final String name=gift.optString("name","Gift");final int scale=giftScale(gift);final String sizeMode=giftModeForScale(scale);final int price=gift.optInt("price",0);final boolean goldGift="GOLD".equalsIgnoreCase(gift.optString("currency","COIN"));final String receiver=result.optString("receiverId",hostId);final int giftQty=result.optInt("quantity",combo);final String streak=combo>=5?"  ×"+giftQty+" COMBO":giftQty>1?"  ×"+giftQty:"";
        playGiftSound(gift);
        if(giftInt(gift,"animation_enabled","animationEnabled",1)!=1||scale<=0){prefetchGiftCatalog();giftEffectPlaying=false;playNextGiftEffect();return;}
        final boolean cinematic=goldGift||scale>=62||price>=1000;
        final FrameLayout overlay=new FrameLayout(this);activeGiftOverlay=overlay;overlay.setClickable(false);overlay.setBackgroundColor(Color.TRANSPARENT);addContentView(overlay,new android.view.ViewGroup.LayoutParams(-1,-1));
        if(combo>=5){TextView badge=t("COMBO  ×"+giftQty,34,0xffffd760,true);badge.setGravity(Gravity.CENTER);badge.setShadowLayer(dp(8),0,0,0xffff6600);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,dp(70),Gravity.TOP);bp.topMargin=dp(110);overlay.addView(badge,bp);badge.setScaleX(.6f);badge.setScaleY(.6f);badge.animate().scaleX(1).scaleY(1).setDuration(450).start();addGiftParticles(overlay,name,40);}
        addGiftBurstRings(overlay,goldGift);addGiftParticles(overlay,name,goldGift?58:(cinematic?38:24));
        final ImageView art=new ImageView(this);art.setScaleType(ImageView.ScaleType.CENTER_INSIDE);setGiftArt(art,gift);String animationVideo=gift.optString("animation_url");VideoView cinematicVideo=null;if(animationVideo.toLowerCase(Locale.US).split("\\?",2)[0].matches(".*\\.(mp4|webm)")||gift.optString("animation_mime").startsWith("video/")){cinematicVideo=new VideoView(this);final VideoView film=cinematicVideo;overlay.addView(film,new FrameLayout.LayoutParams(Math.max(1,getResources().getDisplayMetrics().widthPixels*scale/100),Math.max(1,getResources().getDisplayMetrics().heightPixels*scale/100),Gravity.CENTER));film.setVideoURI(android.net.Uri.parse(animationVideo));film.setOnPreparedListener(player->{player.setVolume(0,0);film.start();});film.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View v){}public void onViewDetachedFromWindow(View v){film.stopPlayback();}});art.setVisibility(View.INVISIBLE);}int artPx=giftArtPx(scale);String boardPos=gift.optString("board_position","CENTER").toUpperCase(Locale.US);int giftGravity="TOP".equals(boardPos)?(Gravity.TOP|Gravity.CENTER_HORIZONTAL):"BOTTOM".equals(boardPos)?(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL):Gravity.CENTER;if("FULL_SCREEN".equals(boardPos))artPx=Math.max(artPx,Math.min(getResources().getDisplayMetrics().widthPixels,getResources().getDisplayMetrics().heightPixels));FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(artPx,artPx,giftGravity);if("TOP".equals(boardPos))ap.topMargin=dp(115);else if("BOTTOM".equals(boardPos))ap.bottomMargin=dp(115);overlay.addView(art,ap);
        TextView glow=t("✦     ✧     ✦",cinematic?34:24,Color.rgb(255,230,125),true);glow.setGravity(Gravity.CENTER);glow.setAlpha(.25f);FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(-1,dp(70),Gravity.CENTER);overlay.addView(glow,gp);ObjectAnimator pulse=ObjectAnimator.ofFloat(glow,"alpha",.18f,.9f,.18f);pulse.setDuration(780);pulse.setRepeatCount(3);pulse.start();
        if(!gift.optString("animation_url").startsWith("https://")&&!gift.optString("animation_url").startsWith("myshop-gift619://")&&!gift.optString("animation_url").startsWith("myshop-gift620://"))animateGiftArt(art,name,sizeMode);
        String sender=result.optString("senderName",result.optString("sender_name",SessionManager.getFullName(this)));if(sender==null||sender.trim().isEmpty())sender="Supporter";String receiverName=result.optString("receiverName",result.optString("receiver_name",currentLiveName));if(receiverName==null||receiverName.trim().isEmpty())receiverName=receiver.equals(hostId)?"Host":"Guest";String currency=gift.optString("currency","COIN");
        LinearLayout giftMeta=col();giftMeta.setGravity(Gravity.CENTER);giftMeta.setPadding(dp(10),dp(4),dp(10),dp(5));giftMeta.setBackground(bg(Color.argb(175,10,13,37),Color.argb(220,255,201,78),14));
        TextView who=t(sender+"  ➜  "+receiverName,9.2f,Color.WHITE,true);who.setGravity(Gravity.CENTER);giftMeta.addView(who,new LinearLayout.LayoutParams(-2,dp(21)));
        TextView giftName=t("🎁 "+name+(streak.isEmpty()?"":streak),9.0f,Color.rgb(255,225,142),true);giftName.setGravity(Gravity.CENTER);giftMeta.addView(giftName,new LinearLayout.LayoutParams(-2,dp(20)));
        TextView val=t(("GOLD".equals(currency)?"👑 ":"🪙 ")+price+("GOLD".equals(currency)?" Diamond":" Coin"),8.8f,Color.rgb(255,210,71),true);val.setGravity(Gravity.CENTER);giftMeta.addView(val,new LinearLayout.LayoutParams(-2,dp(20)));
        FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(-2,dp(67),Gravity.CENTER);mp.topMargin=Math.min(dp(245),Math.max(dp(115),artPx/2+dp(30)));overlay.addView(giftMeta,mp);
        long configuredStay=Math.max(500,gift.optInt("effect_duration_ms",scale>=90?4200:cinematic?3600:3000));long stay=Math.max(3200,Math.min(18000,Math.round(configuredStay*1.45f)));handler.postDelayed(()->overlay.animate().alpha(0f).setDuration(420).withEndAction(()->{if(overlay.getParent()!=null)((android.view.ViewGroup)overlay.getParent()).removeView(overlay);if(activeGiftOverlay==overlay){activeGiftOverlay=null;giftEffectPlaying=false;playNextGiftEffect();}}).start(),stay);
        prefetchGiftCatalog();
    }

    private void openUserProfile(JSONObject u){if(u==null)return;String uid=u.optString("user_id",u.optString("userId",""));if(uid.isEmpty())return;Intent i=new Intent(this,UserProfileActivity.class);i.putExtra("userId",uid);startActivity(i);}

    private void showMiniProfile(JSONObject u){
        String uid=u.optString("user_id",u.optString("userId",""));if(uid.isEmpty())return;
        String tier=u.optString("tier","STANDARD"),name=u.optString("full_name",u.optString("name","User"));
        boolean isHost=uid.equals(hostId),isRoomAdmin=u.optInt("is_room_admin",u.optInt("room_admin",0))==1||"ROOM_ADMIN".equalsIgnoreCase(u.optString("role","")),isSpeaker="SPEAKER".equalsIgnoreCase(u.optString("role",""))||u.optInt("seat_no",0)>1;int supporterRank=u.optInt("supporterRank",u.optInt("rank",0));long giftedCoin=u.optLong("coin_value",0),giftedGold=u.optLong("gold_value",0);String role=isHost?"HOST":isRoomAdmin?"ROOM ADMIN":isSpeaker?"LIVE SPEAKER":supporterRank==1?"TOP GIFT SENDER":supporterRank>1?"GIFT SENDER":"AUDIENCE";
        boolean canInvite=!uid.equals(hostId)&&(canSuggestCall||host||roomAdmin||SessionManager.isAdmin(this)||SessionManager.isModerator(this));
        int accent="KING".equalsIgnoreCase(tier)?0xFFFFC342:"QUEEN".equalsIgnoreCase(tier)?0xFFFF62B4:"ROYAL".equalsIgnoreCase(tier)?0xFFA36BFF:"VVIP".equalsIgnoreCase(tier)?0xFF71D9FF:"VIP".equalsIgnoreCase(tier)?0xFF46D58B:0xFF6F78FF;
        android.app.Dialog dialog=new android.app.Dialog(this);dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        LinearLayout card=col();card.setPadding(dp(16),dp(14),dp(16),dp(14));card.setBackground(gradient(new int[]{0xF20B1230,0xF2211748},Color.TRANSPARENT,22));
        LinearLayout head=row();FrameLayout avatar=circleAvatar(u.optString("avatar_url",u.optString("avatarUrl","")),68,false,tier,u.optString("membership_frame_url",u.optString("frame_url","")));head.addView(avatar,new LinearLayout.LayoutParams(dp(68),dp(68)));LinearLayout meta=col();meta.setPadding(dp(10),dp(2),0,0);String roleIcon=isHost?"👑 ":isRoomAdmin?"🛡 ":isSpeaker?"🎙 ":supporterRank>0?"🎁 ":"● ";TextView badge=t(roleIcon+role,8.2f,Color.WHITE,true);badge.setGravity(Gravity.CENTER);badge.setBackground(bg(isHost?0xFFB77900:isRoomAdmin?0xFF315FC7:isSpeaker?0xFF7B43C7:supporterRank>0?0xFFC02B77:0xFF237D68,accent,11));meta.addView(badge,new LinearLayout.LayoutParams(dp(Math.min(132,Math.max(88,72+role.length()*3))),dp(22)));TextView nm=t(name,15,Color.WHITE,true);nm.setSingleLine(true);meta.addView(nm,new LinearLayout.LayoutParams(-1,dp(25)));TextView identity=t("ID "+uid+"  •  "+tier+"  •  Active now",8.8f,accent,true);AuthorityBadge.decorate(nm,uid);meta.addView(identity,new LinearLayout.LayoutParams(-1,dp(19)));head.addView(meta,new LinearLayout.LayoutParams(0,dp(68),1));TextView close=t("×",24,Color.WHITE,false);close.setGravity(Gravity.CENTER);close.setOnClickListener(v->dialog.dismiss());head.addView(close,new LinearLayout.LayoutParams(dp(40),dp(48)));card.addView(head,new LinearLayout.LayoutParams(-1,dp(72)));
        LinearLayout stats=row();stats.setPadding(0,dp(8),0,dp(8));stats.addView(profileStat(AuthorityBadge.isAuthority(uid)?"AUTHORITY":"LEVEL",AuthorityBadge.isAuthority(uid)?"Verified":"LV."+u.optInt("level",0),0xFF66D7FF),new LinearLayout.LayoutParams(0,dp(60),1));stats.addView(profileStat(supporterRank>0?"COIN GIFT":"COIN",supporterRank>0?compact(giftedCoin):u.has("coin_balance")?compact(u.optLong("coin_balance")):"—",0xFFFFC94D),new LinearLayout.LayoutParams(0,dp(60),1));stats.addView(profileStat(supporterRank>0?"DIAMOND GIFT":"GOLD",supporterRank>0?compact(giftedGold):u.has("gold_balance")?compact(u.optLong("gold_balance")):"—",0xFFFF7ABF),new LinearLayout.LayoutParams(0,dp(60),1));card.addView(stats,new LinearLayout.LayoutParams(-1,dp(76)));
        LinearLayout actions=row();addProfileAction(actions,"＋","Follow",accent,v->BackendClient.toggleFollow(token(),uid,new ToastCb("Follow updated")));addProfileAction(actions,"✉","Message",0xFF28BCEB,v->{dialog.dismiss();Intent i=new Intent(this,ChatActivity.class);i.putExtra("userId",uid);i.putExtra("name",name);startActivity(i);});addProfileAction(actions,"🎁","Gift",0xFFFF4F9A,v->{dialog.dismiss();giftReceiverId=uid;giftReceiverName=name;showGiftPanel();});addProfileAction(actions,"👤","Profile",0xFF8C6CFF,v->{dialog.dismiss();if(uid.equals(hostId))openCreatorCenter(uid);else{Intent i=new Intent(this,UserProfileActivity.class);i.putExtra("userId",uid);startActivity(i);}});card.addView(actions,new LinearLayout.LayoutParams(-1,dp(68)));
        if(canInvite){TextView invite=t("📞  Invite to Seat",10,Color.WHITE,true);invite.setGravity(Gravity.CENTER);invite.setBackground(bg(0xFF226BCB,Color.TRANSPARENT,14));invite.setOnClickListener(v->{dialog.dismiss();inviteToCall(u);});card.addView(invite,new LinearLayout.LayoutParams(-1,dp(42)));}
        if(host&&supporterRank>0){TextView thanks=t("💝  THANK GIFT SENDER",10,Color.WHITE,true);thanks.setGravity(Gravity.CENTER);thanks.setBackground(gradient(new int[]{0xFFE12E82,0xFF7B42E8},0xFFFFB7DE,14));thanks.setOnClickListener(v->{thanks.setEnabled(false);BackendClient.liveGiftThankYou(token(),hostId,uid,new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->{dialog.dismiss();showFloatingBanner("💝 Thank You sent to "+name);});}public void onError(String m){runOnUiThread(()->{thanks.setEnabled(true);Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show();});}});});card.addView(thanks,new LinearLayout.LayoutParams(-1,dp(42)));}
        TextView safety=t("Report or Block",8.5f,0xFFB9C1DD,false);safety.setGravity(Gravity.CENTER);safety.setOnClickListener(v->{dialog.dismiss();SafetyActions.show(this,uid,"LIVE_USER",hostId);});card.addView(safety,new LinearLayout.LayoutParams(-1,dp(38)));
        dialog.setContentView(card);dialog.show();android.view.Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);android.view.WindowManager.LayoutParams lp=w.getAttributes();lp.width=(int)(getResources().getDisplayMetrics().widthPixels*.88f);lp.height=android.view.WindowManager.LayoutParams.WRAP_CONTENT;lp.dimAmount=.48f;w.setAttributes(lp);}
    }

    private View profileStat(String label,String value,int accent){LinearLayout box=col();box.setGravity(Gravity.CENTER);box.setPadding(dp(3),dp(4),dp(3),dp(4));box.setBackground(gradient(new int[]{Color.argb(235,21,34,79),Color.argb(235,65,35,105)},accent,14));TextView v=t(value,13,Color.WHITE,true);v.setGravity(Gravity.CENTER);box.addView(v,new LinearLayout.LayoutParams(-1,dp(29)));TextView l=t(label,7.4f,accent,true);l.setGravity(Gravity.CENTER);box.addView(l,new LinearLayout.LayoutParams(-1,dp(19)));return box;}
    private void addProfileAction(LinearLayout row,String icon,String label,int color,View.OnClickListener click){LinearLayout b=col();b.setGravity(Gravity.CENTER);TextView i=t(icon,18,color,true);i.setGravity(Gravity.CENTER);b.addView(i,new LinearLayout.LayoutParams(-1,dp(30)));TextView l=t(label,7.8f,Color.WHITE,true);l.setGravity(Gravity.CENTER);b.addView(l,new LinearLayout.LayoutParams(-1,dp(20)));b.setOnClickListener(click);row.addView(b,new LinearLayout.LayoutParams(0,dp(55),1));}

    private void showPermissionRequests(){if(!livePower("requests"))return;if(currentRequests.length()==0){showFloatingBanner("কোনো Pending Join Request নেই");return;}String[] labels=new String[currentRequests.length()];for(int i=0;i<labels.length;i++){JSONObject u=currentRequests.optJSONObject(i);labels[i]=u==null?"User":u.optString("full_name")+" • ID "+u.optString("user_id");}new MyShopCompatDialogBuilder(this).setTitle("Join Requests").setItems(labels,(d,w)->{JSONObject u=currentRequests.optJSONObject(w);if(u==null)return;new MyShopCompatDialogBuilder(this).setTitle(labels[w]).setPositiveButton("Approve",(q,n)->BackendClient.liveRequestActionForHost(token(),hostId,u.optString("user_id"),true,new ToastCb("Request accepted"))).setNegativeButton("Reject",(q,n)->BackendClient.liveRequestActionForHost(token(),hostId,u.optString("user_id"),false,new ToastCb("Request rejected"))).setNeutralButton("Waiting",null).show();}).setNegativeButton("Close",null).show();}
    private void showLivePowerTools(){
        if(!livePower("view")){showFloatingBanner("Live পরিচালনার অনুমতি নেই");return;}
        java.util.ArrayList<String> options=new java.util.ArrayList<>();if(livePower("requests"))options.add("Join Requests");if(livePower("pin"))options.add("Comment Pin / Unpin");if(livePower("unblock"))options.add("Room Unblock by ID");if(livePower("settings"))options.add("Slow mode settings");if(!host&&livePower("end"))options.add("End this Live");
        if(options.isEmpty()){showFloatingBanner("এই মুহূর্তে অতিরিক্ত অনুমতি নেই");return;}
        new MyShopCompatDialogBuilder(this).setTitle("Live পরিচালনা").setItems(options.toArray(new String[0]),(d,w)->{String action=options.get(w);if(action.equals("Join Requests")){showPermissionRequests();return;}if(action.equals("End this Live")){new MyShopCompatDialogBuilder(this).setTitle("এই Host-এর Live বন্ধ করবেন?").setMessage("এই কাজ সব অংশগ্রহণকারীর Live বন্ধ করবে।").setPositiveButton("End Live",(q,n)->BackendClient.liveModeration(token(),hostId,SessionManager.getUserId(this),"END",new ToastCb("Live ended"))).setNegativeButton("Cancel",null).show();return;}
        EditText input=new EditText(this);input.setTextColor(Color.BLACK);input.setHint(action.startsWith("Room")?"User ID":action.startsWith("Slow")?"0–60 seconds":"Comment • খালি রাখলে Unpin");new MyShopCompatDialogBuilder(this).setTitle(action).setView(input).setPositiveButton("Save",(q,n)->{String value=input.getText().toString().trim();try{if(action.startsWith("Room")){BackendClient.liveModeration(token(),hostId,value,"UNBLOCK",new ToastCb("Room unblocked"));}else if(action.startsWith("Slow")){int seconds=Integer.parseInt(value);if(seconds<0||seconds>60)throw new IllegalArgumentException();BackendClient.liveBatchSettings(token(),hostId,new JSONObject().put("slowModeSeconds",seconds),new ToastCb("Settings saved"));}else BackendClient.livePinnedMessage(token(),hostId,value,new ToastCb("Pin updated"));}catch(Exception e){showFloatingBanner("সঠিক তথ্য দিন");}}).setNegativeButton("Cancel",null).show();}).setNegativeButton("Close",null).show();
    }
    private void showLiveCommunityMenu(){new MyShopCompatDialogBuilder(this).setTitle("Live Community").setItems(new String[]{"Host Creator Profile","Fan Club / Supporters","Scheduled Lives","Follow Host","Live পরিচালনা / Permissions"},(d,w)->{if(w==0)openCreatorCenter(hostId);else if(w==1)showFanClub();else if(w==2)showSchedules(hostId);else if(w==3)BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));else showLivePowerTools();}).show();}
    private void openCreatorCenter(String uid){Intent i=new Intent(this,CreatorCenterActivity.class);i.putExtra("userId",uid);startActivity(i);}
    private void showFanClub(){BackendClient.liveFanClub(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("members");StringBuilder z=new StringBuilder("Members: ").append(d.optInt("memberCount",0)).append("\nYour points: ").append(d.optLong("points",0)).append("\n\n");if(a!=null)for(int i=0;i<Math.min(8,a.length());i++){JSONObject x=a.optJSONObject(i);if(x!=null)z.append(i+1).append(". ").append(x.optString("full_name","User")).append(" • ").append(x.optLong("points",0)).append(" pts\n");}AlertDialog.Builder b=new MyShopCompatDialogBuilder(AudioLiveRoomActivity.this).setTitle("⭐ Fan Club").setMessage(z.toString()).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Close"),null);if(!host)b.setPositiveButton(d.optBoolean("joined",false)?"Leave Fan Club":"Join Fan Club",(q,w)->BackendClient.liveFanClubToggle(token(),hostId,new ToastCb("Fan Club updated")));b.show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}
    private void showPollComposer(){LinearLayout b=col();EditText q=new EditText(this);q.setHint("Poll question");EditText a=new EditText(this);a.setHint("Option A");EditText z=new EditText(this);z.setHint("Option B");b.addView(q);b.addView(a);b.addView(z);new MyShopCompatDialogBuilder(this).setTitle("📊 Start Live Poll").setView(b).setPositiveButton("START",(d,w)->BackendClient.livePollStart(token(),q.getText().toString().trim(),a.getText().toString().trim(),z.getText().toString().trim(),new ToastCb("Live Poll started"))).setNeutralButton(currentPollId>0?"CLOSE CURRENT":null,(d,w)->{if(currentPollId>0)BackendClient.livePollClose(token(),currentPollId,new ToastCb("Poll closed"));}).setNegativeButton("CANCEL",null).show();}
    private void renderLivePoll(JSONObject p){if(p==null){currentPollId=0;return;}currentPollId=p.optLong("id",0);if(currentPollId<=0||host||!p.optString("my_choice","").isEmpty()||lastPromptedPollId==currentPollId)return;lastPromptedPollId=currentPollId;String question=p.optString("question","Live Poll"),a=p.optString("option_a","A"),b=p.optString("option_b","B");String[] options={a+"  •  "+p.optInt("votes_a",0),b+"  •  "+p.optInt("votes_b",0)};new MyShopCompatDialogBuilder(this).setTitle("📊 "+question).setItems(options,(d,w)->BackendClient.livePollVote(token(),currentPollId,w==0?"A":"B",new ToastCb("Vote counted"))).setNegativeButton("LATER",null).show();}
    private void editWelcome(){EditText e=new EditText(this);e.setHint("Welcome message / room rules");new MyShopCompatDialogBuilder(this).setTitle("Room Welcome").setView(e).setPositiveButton(UiStrings.label(AudioLiveRoomActivity.this,"Save"),(d,w)->BackendClient.livePremiumConfig(token(),e.getText().toString().trim(),null,-1,-1,new ToastCb("Welcome updated"))).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Cancel"),null).show();}
    private void editGoal(){String[] types={"COIN","SUPPORTERS","MINUTES","VIEWERS","NONE"};new MyShopCompatDialogBuilder(this).setTitle("Live Goal Type").setItems(types,(d,w)->{String type=types[w];if("NONE".equals(type)){BackendClient.livePremiumConfig(token(),null,"NONE",0,-1,new ToastCb("Goal cleared"));return;}EditText e=new EditText(this);e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);e.setHint("Target");new MyShopCompatDialogBuilder(this).setTitle(type+" target").setView(e).setPositiveButton(UiStrings.label(AudioLiveRoomActivity.this,"Save"),(q,x)->{long target=0;try{target=Long.parseLong(e.getText().toString().trim());}catch(Exception ignored){}BackendClient.livePremiumConfig(token(),null,type,target,-1,new ToastCb("Live Goal updated"));}).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Cancel"),null).show();}).show();}
    private void choosePinnedProduct(){BackendClient.commerce("products",null,token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{final JSONArray a=d.optJSONArray("products");if(a==null||a.length()==0){Toast.makeText(AudioLiveRoomActivity.this,"No enabled physical Shop products",Toast.LENGTH_SHORT).show();return;}String[] names=new String[a.length()+1];long[] ids=new long[a.length()+1];names[0]="Clear pinned product";ids[0]=0;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);names[i+1]=x==null?"Item":x.optString("title","Item")+" • ৳"+String.format(Locale.US,"%.2f",x.optLong("effective_price",x.optLong("price"))/100.0);ids[i+1]=x==null?0:x.optLong("id",0);}new MyShopCompatDialogBuilder(AudioLiveRoomActivity.this).setTitle("🛍 Shopping Live • Pin Product").setItems(names,(q,w)->BackendClient.livePremiumConfig(token(),null,null,-1,ids[w],new ToastCb(w==0?"Product pin cleared":"Product pinned • viewers can buy now"))).show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}
    private void showSchedules(String uid){BackendClient.liveSchedules(token(),uid,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("schedules");if(a==null||a.length()==0){Toast.makeText(AudioLiveRoomActivity.this,"No scheduled live",Toast.LENGTH_SHORT).show();return;}String[] x=new String[a.length()];for(int i=0;i<a.length();i++){JSONObject z=a.optJSONObject(i);x[i]=(z==null?"Scheduled Live":z.optString("title","Scheduled Live")+" • "+z.optString("scheduled_at",""));}new MyShopCompatDialogBuilder(AudioLiveRoomActivity.this).setTitle("🔔 Scheduled Lives").setItems(x,(q,w)->{JSONObject z=a.optJSONObject(w);if(z!=null&&!host)BackendClient.liveScheduleReminder(token(),z.optLong("id"),new ToastCb("Reminder updated"));}).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Close"),null).show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}
    private void showScheduleDialog(){LinearLayout box=col();EditText title=new EditText(this);title.setHint("Live title");EditText topic=new EditText(this);topic.setHint("Topic");EditText at=new EditText(this);at.setHint("YYYY-MM-DD HH:MM:SS");box.addView(title);box.addView(topic);box.addView(at);new MyShopCompatDialogBuilder(this).setTitle("🔔 Schedule Live").setView(box).setPositiveButton(UiStrings.label(AudioLiveRoomActivity.this,"Save"),(d,w)->BackendClient.liveScheduleSave(token(),0,title.getText().toString().trim(),topic.getText().toString().trim(),at.getText().toString().trim(),new ToastCb("Live scheduled"))).setNeutralButton("View Schedules",(d,w)->showSchedules(hostId)).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Cancel"),null).show();}
    private void showPkDialog(){EditText e=new EditText(this);e.setHint("Other LIVE Host ID");e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);new MyShopCompatDialogBuilder(this).setTitle("⚔ Friendly PK / Battle").setMessage("Both hosts must already be live. V-304 foundation scores completed gifts during the PK.").setView(e).setPositiveButton("Invite",(d,w)->BackendClient.livePkStart(token(),e.getText().toString().trim(),new ToastCb("PK invitation sent"))).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Cancel"),null).show();}
    private void showIncomingPk(long id){new MyShopCompatDialogBuilder(this).setTitle("⚔ PK Invitation").setMessage("Another live host invited this room to a friendly PK.").setPositiveButton("Accept",(d,w)->BackendClient.livePkAction(token(),id,"ACCEPT",new ToastCb("PK started"))).setNegativeButton("Decline",(d,w)->BackendClient.livePkAction(token(),id,"DECLINE",new ToastCb("PK declined"))).show();}
    private void showAudienceEndSummary(){if(endedSummaryShown)return;endedSummaryShown=true;showAudienceEndSummaryAttempt(1);}
    private void showAudienceEndSummaryAttempt(final int attempt){
        BackendClient.liveSummary(token(),hostId,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{JSONObject x=d.optJSONObject("summary");if(x!=null){showSummary(x);return;}if(attempt<5){handler.postDelayed(()->showAudienceEndSummaryAttempt(attempt+1),450L+attempt*250L);return;}showLocalAudienceEndSummary();});}
            public void onError(String m){runOnUiThread(()->{if(attempt<5){handler.postDelayed(()->showAudienceEndSummaryAttempt(attempt+1),450L+attempt*250L);return;}showLocalAudienceEndSummary();});}
        });
    }
    private void showLocalAudienceEndSummary(){JSONObject x=new JSONObject();try{long duration=Math.max(0,serverElapsedSec+(System.currentTimeMillis()-serverElapsedSyncMs)/1000L);x.put("duration_seconds",duration).put("peak_viewers",Math.max(currentPeakViewers,currentViewerCount)).put("total_listeners",Math.max(currentTotalListeners,currentViewerCount)).put("react_count",Math.max(0,reactCount)).put("topSupporters",currentTopSupporters==null?new JSONArray():currentTopSupporters);}catch(Exception ignored){}showPremiumSummaryDialog(x,true);}


    private void updateSpeakerControls(){
        if(speakerActionButton!=null){
            String label;
            if(host)label="END LIVE";
            else if("SPEAKER".equals(myRole))label="LEAVE";
            else if("PENDING".equalsIgnoreCase(myRequestStatus))label="REQUESTED ✓";
            else label=pendingRequestCount>0?("JOIN • "+pendingRequestCount):"JOIN";
            speakerActionButton.setText(label);
            speakerActionButton.setContentDescription(host?"End Live room":"SPEAKER".equals(myRole)?"Leave speaker seat":"Join speaker seat");
            speakerActionButton.setTextSize(label.startsWith("REQUESTED")?10.5f:Math.max(15f,Math.min(joinFontSize,17.0f)));
            speakerActionButton.setTextColor(joinTextColor);
            // Pending remains tappable so the viewer can cancel without leaving the Live.
            speakerActionButton.setEnabled(true);
            speakerActionButton.setVisibility(View.GONE); // Join lives in the right-side animated rail.
        }
        if(micButton!=null){micButton.setEnabled(!listenOnly);updateLocalMicUi();}
        updateJoinButtonAnimation();
    }
    private void updateJoinButtonAnimation(){
        if(joinPulseAlpha!=null){joinPulseAlpha.cancel();joinPulseAlpha=null;}
        if(joinPulseX!=null){joinPulseX.cancel();joinPulseX=null;}
        if(joinPulseY!=null){joinPulseY.cancel();joinPulseY=null;}
    }
    private void requestJoinToCall(){
        if(roomEnded||endLiveInProgress||joinRequestInFlight||"PENDING".equalsIgnoreCase(myRequestStatus))return;
        // V-394 optimistic UI: the user immediately sees the request state while the
        // backend publishes the same state to the host/all participants.
        joinRequestInFlight=true;myRequestStatus="PENDING";pendingRequestCount=Math.max(1,pendingRequestCount+1);updateSpeakerControls();
        BackendClient.liveSpeakRequest(token(),hostId,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{joinRequestInFlight=false;String st=d.optString("status","PENDING");if("ACCEPTED".equalsIgnoreCase(st)){myRole="SPEAKER";myRequestStatus="ACCEPTED";currentSeatNo=d.optInt("seatNo",0);localMicOn=true;requestRtcToken(true);showFloatingBanner("✓ Joined call automatically");}else{myRequestStatus=st;showFloatingBanner("✋ Join request sent • waiting for Host");}updateSpeakerControls();refresh();});}
            public void onError(String m){runOnUiThread(()->{joinRequestInFlight=false;myRequestStatus="NONE";pendingRequestCount=Math.max(0,pendingRequestCount-1);updateSpeakerControls();showFloatingBanner("⚠ "+(m==null||m.trim().isEmpty()?"Join request failed":m));});}
        });
    }
    private void confirmCancelJoinRequest(){
        new MyShopCompatDialogBuilder(this).setTitle("Cancel Join Request?").setMessage("Your pending request will be removed from the Host screen.")
            .setPositiveButton("Cancel Request",(d,w)->cancelJoinRequest()).setNegativeButton("Keep Waiting",null).show();
    }
    private void cancelJoinRequest(){
        if(roomEnded||endLiveInProgress||joinRequestInFlight||!"PENDING".equalsIgnoreCase(myRequestStatus))return;
        BackendClient.liveCancelSpeakRequest(token(),hostId,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{myRequestStatus="NONE";pendingRequestCount=Math.max(0,pendingRequestCount-1);updateSpeakerControls();showFloatingBanner("✓ Join request cancelled");refresh();});}
            public void onError(String m){runOnUiThread(()->{showFloatingBanner("⚠ "+(m==null||m.trim().isEmpty()?"Could not cancel request":m));refresh();});}
        });
    }
    private void confirmLeaveSeat(){
        new MyShopCompatDialogBuilder(this).setTitle("Leave call?").setMessage("You will leave the speaker seat but stay in the Live as audience.").setPositiveButton("Leave Call",(d,w)->BackendClient.liveLeaveSeat(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->{myRole="AUDIENCE";currentSeatNo=0;localMicOn=true;if(rtcManager!=null){rtcManager.setPublishAudio(false);rtcManager.setMicEnabled(false);}requestRtcToken(false);updateSpeakerControls();Toast.makeText(AudioLiveRoomActivity.this,"Left the call • still watching Live",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}})).setNegativeButton("Stay",null).show();
    }
    private void moveMySeat(int seatNo){
        if(!"SPEAKER".equals(myRole)||seatNo<2||seatNo>11||seatNo==currentSeatNo)return;
        BackendClient.liveSelfSeatAssign(token(),hostId,seatNo,new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->{currentSeatNo=seatNo;Toast.makeText(AudioLiveRoomActivity.this,"Moved to seat "+seatNo,Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});
    }
    private void showSelfSeatChooser(){
        java.util.ArrayList<Integer> nums=new java.util.ArrayList<>();java.util.ArrayList<String> labels=new java.util.ArrayList<>();
        for(int seatNo=2;seatNo<=11;seatNo++){if(seatNo==currentSeatNo||lockedSeats.contains(seatNo))continue;JSONObject x=findSeat(currentSeats,seatNo);if(x!=null)continue;nums.add(seatNo);labels.add("Guest Seat "+seatNo);}
        if(nums.isEmpty()){Toast.makeText(this,"No free seat available",Toast.LENGTH_SHORT).show();return;}
        new MyShopCompatDialogBuilder(this).setTitle("Change Seat").setItems(labels.toArray(new String[0]),(d,w)->moveMySeat(nums.get(w))).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Cancel"),null).show();
    }
    private void showSelfSpeakerMenu(){
        String mic=localMicOn?"Mute microphone":"Unmute microphone";
        new MyShopCompatDialogBuilder(this).setTitle("My Call Controls").setItems(new String[]{"Change seat",mic,"Leave Seat / Leave Call"},(d,w)->{if(w==0)showSelfSeatChooser();else if(w==1)toggleMic();else confirmLeaveSeat();}).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Close"),null).show();
    }

    private boolean canModerateSeat(){return host||roomAdmin||SessionManager.isAdmin(this)||SessionManager.isModerator(this);}

    private void showSeatedUserActions(JSONObject x){
        final String uid=x.optString("user_id","");if(uid.isEmpty())return;
        final String title=x.optString("full_name","User")+" • ID "+uid;
        final boolean moderator=canModerateSeat();
        if(!moderator){
            new MyShopCompatDialogBuilder(this).setTitle(title).setItems(new String[]{"🎁 Send Gift","Open Profile"},(d,w)->{
                if(w==0){giftReceiverId=uid;giftReceiverName=x.optString("full_name","User");showGiftPanel();}
                else openUserProfile(x);
            }).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Close"),null).show();return;
        }
        showSpeakerActions(x);
    }

    private void refreshSpeakingAvatars(){
        if(isFinishing()||roomEnded)return;
        for(SpeakerPortrait portrait:speakerPortraits.values()){JSONObject user=portrait.user;if(user!=null){JSONObject latest=findUser(currentSeats,user.optString("user_id",""));if(latest!=null)user=latest;portrait.update(user,isRtcSpeaking(user,user.optString("user_id","").equals(hostId))||user.optInt("speaking",0)==1);}}
    }

    private void showSpeakerActions(JSONObject x){
        final String uid=x.optString("user_id","");if(uid.isEmpty())return;
        final boolean special=uid.equals(specialGuestId);
        final String title=x.optString("full_name","Speaker")+" • ID "+uid;
        java.util.ArrayList<String> actions=new java.util.ArrayList<>();
        actions.add("🎁 Send Gift"); actions.add("Open Profile");if(host)actions.add("My listening volume");actions.add("Report user");
        if(host){actions.add(special?"Remove Center Guest":"Make Center Guest");actions.add("Move to Guest Seat");}
        final boolean currentlyMuted=x.optInt("muted",0)==1||x.optInt("mic_on",1)==0;
        if(livePower(currentlyMuted?"unmute":"mute"))actions.add(currentlyMuted?"Unmute microphone":"Mute microphone");
        if(livePower("kick"))actions.add("Kick out of Live");
        if(livePower("block"))actions.add("Block from Live");
        if(livePower("room_admin")){actions.add("Make Room Admin");actions.add("Revoke Room Admin");}if(host)actions.add("Remove from Speaker Seat");
        java.util.List<String> order=java.util.Arrays.asList("🎁 Send Gift","Open Profile","My listening volume","Make Center Guest","Remove Center Guest","Move to Guest Seat","Mute microphone","Unmute microphone","Remove from Speaker Seat","Make Room Admin","Revoke Room Admin","Report user","Kick out of Live","Block from Live");actions.sort((a,b)->Integer.compare(order.indexOf(a),order.indexOf(b)));
        showSpeakerActionCard(x,actions,which->{
            String action=actions.get(which);
            if(action.startsWith("🎁")){if(uid.equals(SessionManager.getUserId(this))){Toast.makeText(this,"You cannot gift yourself",Toast.LENGTH_SHORT).show();return;}giftReceiverId=uid;giftReceiverName=x.optString("full_name","User");showGiftPanel();return;}
            if(action.equals("Open Profile")){openUserProfile(x);return;}if(action.equals("My listening volume")){showLocalGuestVolume(uid);return;}if(action.equals("Report user")){SafetyActions.show(this,uid,"LIVE_USER",hostId);return;}
            if(action.equals("Make Center Guest")){BackendClient.liveSpecialGuest(token(),uid,false,new ToastCb("Center Guest selected"));return;}
            if(action.equals("Remove Center Guest")){BackendClient.liveSpecialGuest(token(),uid,true,new ToastCb("Center Guest removed"));return;}
            if(action.equals("Move to Guest Seat")){showSeatChooser(uid);return;}
            if(action.equals("Mute microphone")){BackendClient.liveModeration(token(),hostId,uid,"MUTE",new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{refresh();handler.postDelayed(()->refresh(),180L);});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}});return;}
            if(action.equals("Unmute microphone")){BackendClient.liveModeration(token(),hostId,uid,"UNMUTE",new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{refresh();handler.postDelayed(()->refresh(),180L);});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}});return;}
            if(action.equals("Kick out of Live")){new MyShopCompatDialogBuilder(this).setTitle("Kick this user?").setMessage("The user will be removed from this Live.").setPositiveButton("Kick",(dd,ww)->BackendClient.liveModeration(token(),hostId,uid,"KICK",new ToastCb("User kicked out"))).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Cancel"),null).show();return;}
            if(action.equals("Block from Live")){new MyShopCompatDialogBuilder(this).setTitle("Block from this Live?").setMessage("This user will be removed and cannot rejoin until unblocked.").setPositiveButton("Block",(dd,ww)->BackendClient.liveModeration(token(),hostId,uid,"BLOCK",new ToastCb("User blocked from Live"))).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Cancel"),null).show();return;}
            if(action.equals("Make Room Admin")){BackendClient.liveModeration(token(),hostId,uid,"ADD_ROOM_ADMIN",new ToastCb("Live Admin invitation sent"));return;}
            if(action.equals("Revoke Room Admin")){BackendClient.liveModeration(token(),hostId,uid,"REMOVE_ROOM_ADMIN",new ToastCb("Room Admin removed"));return;}
            if(action.equals("Remove from Speaker Seat")){BackendClient.liveSpeakerRemove(token(),uid,new ToastCb("Speaker removed from seat"));}
        });
    }

    private void showSpeakerActionCard(JSONObject user,java.util.List<String> actions,java.util.function.IntConsumer dispatch){
        android.app.Dialog dialog=new android.app.Dialog(this);LinearLayout box=col();box.setPadding(dp(16),dp(14),dp(16),dp(14));box.setBackground(bg(0xff121c40,Color.TRANSPARENT,22));
        LinearLayout closeRow=row();TextView close=t("×",24,Color.WHITE,false);close.setGravity(Gravity.CENTER);close.setOnClickListener(v->dialog.dismiss());closeRow.setGravity(Gravity.RIGHT);closeRow.addView(close,new LinearLayout.LayoutParams(dp(36),dp(30)));box.addView(closeRow);
        LinearLayout.LayoutParams avatarParams=new LinearLayout.LayoutParams(dp(72),dp(72));avatarParams.gravity=Gravity.CENTER;box.addView(circleAvatar(user.optString("avatar_url"),72,false),avatarParams);
        TextView identity=t(user.optString("full_name","User")+"\nID "+user.optString("user_id"),15,Color.WHITE,true);identity.setGravity(Gravity.CENTER);identity.setPadding(0,dp(8),0,dp(8));box.addView(identity,new LinearLayout.LayoutParams(-1,-2));
        GridLayout grid=new GridLayout(this);grid.setColumnCount(2);int cell=0;
        for(int i=0;i<actions.size();i++){final int index=i;TextView action=t(actions.get(i),12,actions.get(i).contains("Block")?0xffff8197:Color.WHITE,true);action.setGravity(Gravity.CENTER);action.setPadding(dp(6),dp(8),dp(6),dp(8));action.setMinHeight(dp(48));action.setBackground(i==0?gradient(new int[]{0xffab28ef,0xff287cf4},Color.TRANSPARENT,14):bg(0xff202d52,Color.TRANSPARENT,12));action.setOnClickListener(v->{dialog.dismiss();dispatch.accept(index);});
            if(i==0){LinearLayout.LayoutParams first=new LinearLayout.LayoutParams(-1,dp(48));first.topMargin=dp(12);first.bottomMargin=dp(8);box.addView(action,first);}else{boolean full=actions.get(i).equals("Block from Live");if(full&&cell%2!=0)cell++;GridLayout.LayoutParams gp=new GridLayout.LayoutParams(GridLayout.spec(cell/2),GridLayout.spec(full?0:cell%2,full?2:1,1f));gp.width=0;gp.height=-2;gp.setMargins(dp(3),dp(3),dp(3),dp(3));grid.addView(action,gp);cell+=full?2:1;}}
        box.addView(grid);ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.addView(box);dialog.setContentView(scroll);dialog.show();android.view.Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.94f),-2);w.setGravity(Gravity.BOTTOM);}
    }

    private void showSeatChooser(String uid){String[] items=new String[10];for(int i=0;i<10;i++)items[i]="Guest Seat "+(i+2)+(lockedSeats.contains(i+2)?" • Locked":"");new MyShopCompatDialogBuilder(this).setTitle("Move Speaker to Guest Seat").setItems(items,(d,w)->BackendClient.liveSeatAssign(token(),uid,w+2,new ToastCb("Guest seat updated"))).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Cancel"),null).show();}
    private void clearSpecialGuest(){if(!host||specialGuestId.isEmpty())return;new MyShopCompatDialogBuilder(this).setTitle("Special Guest").setMessage("Return this guest to a normal speaker seat?").setPositiveButton("Remove Spotlight",(d,w)->BackendClient.liveSpecialGuest(token(),specialGuestId,true,new ToastCb("Spotlight cleared"))).setNegativeButton(UiStrings.label(AudioLiveRoomActivity.this,"Cancel"),null).show();}

    private void confirmLeaveLive(){new MyShopCompatDialogBuilder(this).setTitle("Leave Live?").setMessage("Leave this live room?").setPositiveButton("Leave",(d,w)->leaveAudienceLive()).setNegativeButton("Stay",null).show();}
    private void leaveAudienceLive(){
        if(host||roomEnded)return;
        roomEnded=true;myRequestStatus="NONE";pendingRequestCount=0;myRole="AUDIENCE";currentSeatNo=0;
        handler.removeCallbacks(tick);handler.removeCallbacks(realtimeTick);handler.removeCallbacks(presenceTick);handler.removeCallbacks(participantTick);
        if(rtcManager!=null){rtcManager.setPublishAudio(false);rtcManager.setMicEnabled(false);rtcManager.leave();}
        final boolean[] completed={false};
        BackendClient.liveViewer(token(),hostId,false,false,new BackendClient.Callback(){
            private void done(){if(completed[0])return;completed[0]=true;runOnUiThread(()->finish());}
            public void onSuccess(JSONObject d){done();}
            public void onError(String m){done();}
        });
        finish();
    }
    private android.app.Dialog endConfirmationDialog;
    private void confirmEndLive(){
        if(endLiveInProgress||roomEnded||(endConfirmationDialog!=null&&endConfirmationDialog.isShowing()))return;
        final android.app.Dialog dialog=new android.app.Dialog(this);endConfirmationDialog=dialog;
        LinearLayout box=col();box.setPadding(dp(20),dp(18),dp(20),dp(20));box.setBackground(bg(Color.WHITE,Color.TRANSPARENT,20));
        TextView question=t("Are you sure to end the Live?",16,Color.rgb(25,25,25),false);question.setGravity(Gravity.CENTER);box.addView(question,new LinearLayout.LayoutParams(-1,dp(40)));
        LinearLayout actions=row();actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView cancel=t(UiStrings.label(AudioLiveRoomActivity.this,"Cancel"),16,0xff85858a,false);cancel.setGravity(Gravity.CENTER);cancel.setBackground(bg(0xfff5f5f9,Color.TRANSPARENT,28));cancel.setOnClickListener(v->dialog.dismiss());
        TextView confirm=t("Confirm",16,Color.WHITE,true);confirm.setGravity(Gravity.CENTER);confirm.setBackground(bg(0xff5955f5,Color.TRANSPARENT,28));confirm.setOnClickListener(v->{dialog.dismiss();endHostLive();});
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(48),1);cp.rightMargin=dp(6);actions.addView(cancel,cp);LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(0,dp(48),1);fp.leftMargin=dp(6);actions.addView(confirm,fp);box.addView(actions,new LinearLayout.LayoutParams(-1,dp(52)));
        dialog.setContentView(box);dialog.setCanceledOnTouchOutside(false);dialog.setOnDismissListener(d->endConfirmationDialog=null);dialog.show();
        android.view.Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.84f),-2);w.setDimAmount(.55f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);}
    }
    private void endHostLive(){
        if(endLiveInProgress||roomEnded)return;
        endLiveInProgress=true;hostStarted=false;
        if(speakerActionButton!=null){speakerActionButton.setEnabled(false);speakerActionButton.setText("ENDING…");speakerActionButton.setAlpha(.72f);}
        if(onlineCountView!=null){onlineCountView.setEnabled(false);onlineCountView.setAlpha(.45f);}
        handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);handler.removeCallbacks(realtimeTick);handler.removeCallbacks(presenceTick);handler.removeCallbacks(participantTick);
        stopVoiceMonitor(false);
        if(rtcManager!=null)rtcManager.leave();
        syncState.setText("Ending live…");
        if(premiumStrip!=null)premiumStrip.setText("Ending live…");
        // One tap is authoritative, but keep this Activity alive until the server confirms close
        // so the Host End Summary can always be rendered before leaving the room.
        endHostLiveAttempt(1);
    }
    private void endHostLiveAttempt(final int attempt){
        if(roomEnded||isFinishing())return;
        if(attempt>3){showEndRetry();return;}
        BackendClient.endLive(token(),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                if(roomEnded)return;
                if(!d.optBoolean("closed",false)){
                    handler.postDelayed(()->endHostLiveAttempt(attempt+1),Math.min(3000L,500L+attempt*350L));
                    return;
                }
                roomEnded=true;endLiveInProgress=false;hostStarted=false;
                handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);handler.removeCallbacks(realtimeTick);handler.removeCallbacks(presenceTick);handler.removeCallbacks(participantTick);pendingComments.clear();
                final JSONObject closeSummary=d.optJSONObject("summary");
                // V-392: /live/end already returns the authoritative history row. Show it
                // immediately instead of waiting on a second network request that can hide/delay summary.
                if(closeSummary!=null){showSummary(closeSummary);return;}
                BackendClient.liveSummary(token(),hostId,new BackendClient.Callback(){
                    public void onSuccess(JSONObject ss){runOnUiThread(()->{JSONObject x=ss.optJSONObject("summary");if(x!=null)showSummary(x);else showLocalHostEndSummary();});}
                    public void onError(String m){runOnUiThread(()->showLocalHostEndSummary());}
                });
            });}
            public void onError(String m){
                if(roomEnded)return;
                // One tap is enough: keep retrying automatically. Do not return the room to LIVE/Reconnecting.
                handler.postDelayed(()->endHostLiveAttempt(attempt+1),Math.min(4000L,650L+attempt*450L));
            }
        });
    }
    private void showEndRetry(){
        runOnUiThread(()->{if(roomEnded||isFinishing())return;syncState.setText("End Live not confirmed • retry required");new MyShopCompatDialogBuilder(this).setTitle("Could not confirm Live ended").setMessage("Check your connection and retry. The server has not confirmed that the room is closed.").setPositiveButton("Retry",(d,w)->endHostLiveAttempt(1)).setCancelable(false).show();});
    }
    private void endLiveFailed(String message){
        // V-311 compatibility method: never re-activate an End request.
        if(roomEnded)return;endLiveInProgress=true;hostStarted=false;syncState.setText("Ending live…");
        handler.postDelayed(()->endHostLiveAttempt(1),1200L);
    }
    private void showLocalHostEndSummary(){
        // V-394 guaranteed host summary fallback. The authoritative server summary is preferred,
        // but the Host never loses the end screen because a second network read failed.
        JSONObject x=new JSONObject();
        try{
            long duration=Math.max(0,serverElapsedSec+(System.currentTimeMillis()-serverElapsedSyncMs)/1000L);
            x.put("duration_seconds",duration).put("peak_viewers",Math.max(currentPeakViewers,currentViewerCount))
             .put("total_listeners",Math.max(currentTotalListeners,currentViewerCount)).put("react_count",Math.max(0,reactCount));
        }catch(Exception ignored){}
        showSummary(x);
    }

    private void showClosedWithoutSummary(String message){
        roomEnded=true;endLiveInProgress=false;syncState.setText("Live ended • server confirmed");hostStarted=false;
        handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);handler.removeCallbacks(realtimeTick);handler.removeCallbacks(presenceTick);handler.removeCallbacks(participantTick);pendingComments.clear();
        new MyShopCompatDialogBuilder(this).setTitle("Live ended").setMessage(message).setPositiveButton("DONE",(d,w)->finish()).setCancelable(false).show();
    }

    private void showSummary(JSONObject x){
        if(x==null){showClosedWithoutSummary("The room is closed.");return;}
        endedSummaryShown=true;
        JSONArray top=x.optJSONArray("topSupporters");if(top!=null)currentTopSupporters=top;
        showEndedPage(x);
    }

    private void showEndedPage(JSONObject summary){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xff080b17);LinearLayout body=col();body.setPadding(dp(20),dp(18),dp(20),dp(24));scroll.addView(body);
        LinearLayout bar=row();TextView back=t("‹",28,Color.WHITE,false);back.setGravity(Gravity.CENTER);back.setOnClickListener(v->finish());bar.addView(back,new LinearLayout.LayoutParams(dp(40),dp(44)));TextView title=t("Live is over",20,Color.WHITE,true);title.setGravity(Gravity.CENTER);bar.addView(title,new LinearLayout.LayoutParams(0,dp(44),1));body.addView(bar);
        JSONObject hostProfile=cachedHostProfile;FrameLayout avatar=circleAvatar(hostProfile.optString("avatar_url",summary.optString("hostAvatar","")),84,false);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(84),dp(84));ap.gravity=Gravity.CENTER;ap.topMargin=dp(25);ap.bottomMargin=dp(12);body.addView(avatar,ap);
        TextView name=t(summary.optString("hostName",currentLiveName),21,Color.WHITE,true);name.setGravity(Gravity.CENTER);body.addView(name);TextView id=t("ID "+hostId,12,0xffb3bfd6,false);id.setGravity(Gravity.CENTER);body.addView(id);
        GridLayout grid=new GridLayout(this);grid.setColumnCount(2);String[] labels={"Live duration","Total listeners","Coin gifts","Diamond gifts","Peak viewers","Love reactions"};String[] values={hhmmss(summary.optLong("duration_seconds",summary.optLong("elapsedSeconds",0))),String.valueOf(summary.optLong("total_listeners",summary.optLong("totalListeners",currentTotalListeners))),summary.has("totalCoinGift")?String.valueOf(summary.optLong("totalCoinGift")):"—",summary.has("totalGoldGift")?String.valueOf(summary.optLong("totalGoldGift")):"—",String.valueOf(summary.optLong("peak_viewers",summary.optLong("peakViewers",currentPeakViewers))),String.valueOf(summary.optLong("react_count",summary.optLong("reactCount",reactCount)))};
        for(int i=0;i<labels.length;i++){LinearLayout cell=col();cell.setPadding(dp(12),dp(16),dp(12),dp(16));cell.setBackground(bg(0xff1b2132,Color.TRANSPARENT,14));TextView value=t(values[i],22,Color.WHITE,true);cell.addView(value);TextView label=t(labels[i],12,0xffbbc5d9,false);cell.addView(label);GridLayout.LayoutParams gp=new GridLayout.LayoutParams(GridLayout.spec(i/2),GridLayout.spec(i%2,1f));gp.width=0;gp.height=-2;gp.setMargins(dp(4),dp(4),dp(4),dp(4));grid.addView(cell,gp);}LinearLayout.LayoutParams gl=new LinearLayout.LayoutParams(-1,-2);gl.topMargin=dp(24);body.addView(grid,gl);
        TextView details=t("More details · Top 20",14,0xffb9c5ff,true);details.setGravity(Gravity.CENTER);details.setOnClickListener(v->{try{summary.put("closedSummary",true);}catch(Exception ignored){}showPremiumSummaryDialog(summary,false);});body.addView(details,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView done=t("Back to Live page",15,Color.WHITE,true);done.setGravity(Gravity.CENTER);done.setBackground(bg(0xff6652e6,Color.TRANSPARENT,16));done.setOnClickListener(v->finish());body.addView(done,new LinearLayout.LayoutParams(-1,dp(48)));
        scroll.setOnApplyWindowInsetsListener((v,in)->{v.setPadding(0,in.getSystemWindowInsetTop(),0,in.getSystemWindowInsetBottom());return in;});setContentView(scroll);scroll.post(scroll::requestApplyInsets);
    }

    private TextView summaryCard(String icon,String label,String value,int accent){
        TextView v=t(icon+"\n"+value+"\n"+label,11.2f,Color.WHITE,true);v.setGravity(Gravity.CENTER);v.setPadding(dp(4),dp(7),dp(4),dp(7));v.setBackground(gradient(new int[]{Color.argb(238,18,34,83),Color.argb(238,60,35,111)},accent,16));v.setElevation(dp(3));return v;
    }

    private void showPremiumSummaryDialog(JSONObject x,boolean ended){
        if(!ended&&!x.optBoolean("closedSummary")){showLifetimeGifters();return;}
        long duration=Math.max(0,x.optLong("duration_seconds",x.optLong("elapsedSeconds",0)));
        long peak=Math.max(0,x.optLong("peak_viewers",x.optLong("peakViewers",currentPeakViewers)));
        long listeners=Math.max(0,x.optLong("total_listeners",x.optLong("totalListeners",currentTotalListeners)));
        long reactions=Math.max(0,x.optLong("react_count",x.optLong("reactCount",reactCount)));
        long coin=x.optLong("totalCoinGift",0),gold=x.optLong("totalGoldGift",0),giftCount=x.optLong("giftCount",currentHostStats==null?0:currentHostStats.optLong("totalGift",0));
        LinearLayout box=col();box.setPadding(dp(10),dp(10),dp(10),dp(10));box.setBackground(gradient(new int[]{Color.rgb(8,18,55),Color.rgb(45,24,91)},Color.rgb(121,96,255),24));
        LinearLayout summaryHeader=row();summaryHeader.setGravity(Gravity.CENTER_VERTICAL);TextView summaryTab=t("▮▮  Live Summary",12.8f,Color.WHITE,true);summaryTab.setGravity(Gravity.CENTER);summaryTab.setBackground(gradient(new int[]{Color.rgb(64,47,242),Color.rgb(255,45,157)},Color.rgb(114,118,255),18));TextView profileTab=t("👤  Host Profile",12.2f,Color.rgb(190,204,255),true);profileTab.setGravity(Gravity.CENTER);profileTab.setBackground(bg(Color.argb(100,18,29,73),Color.rgb(60,76,139),18));TextView closeTop=t("×",24,Color.WHITE,true);closeTop.setGravity(Gravity.CENTER);LinearLayout.LayoutParams topTabLp=new LinearLayout.LayoutParams(0,dp(42),1);topTabLp.rightMargin=dp(5);summaryHeader.addView(summaryTab,topTabLp);LinearLayout.LayoutParams profileLp=new LinearLayout.LayoutParams(0,dp(42),1);profileLp.rightMargin=dp(5);summaryHeader.addView(profileTab,profileLp);summaryHeader.addView(closeTop,new LinearLayout.LayoutParams(dp(32),dp(42)));box.addView(summaryHeader,new LinearLayout.LayoutParams(-1,dp(46)));
        String summaryHostName=x.optString("hostName",currentLiveName);JSONObject hs=findSeat(currentSeats,1);if(hs!=null){String actual=hs.optString("full_name","");if(!actual.trim().isEmpty())summaryHostName=actual;}if(summaryHostName==null||summaryHostName.trim().isEmpty())summaryHostName="myshop User";
        final String summaryHostNameFinal=summaryHostName;
        final JSONObject hostCard=hs==null?new JSONObject():hs;try{hostCard.put("user_id",hostId).put("full_name",summaryHostNameFinal).put("role","HOST");if(hostCard.optString("avatar_url","").isEmpty())hostCard.put("avatar_url",x.optString("hostAvatar",""));if(hostCard.optInt("level",0)==0)hostCard.put("level",x.optInt("hostLevel",currentHostStats==null?0:currentHostStats.optInt("level",0)));}catch(Exception ignored){}
        LinearLayout hostStrip=row();hostStrip.setGravity(Gravity.CENTER_VERTICAL);hostStrip.setPadding(dp(9),dp(5),dp(9),dp(5));hostStrip.setBackground(gradient(new int[]{0xEE2B235D,0xEE132B64},0xFFFFC84A,16));FrameLayout hostAvatar=circleAvatar(hostCard.optString("avatar_url",""),72,false,hostCard.optString("tier","STANDARD"),hostCard.optString("membership_frame_url",hostCard.optString("frame_url","")));hostStrip.addView(hostAvatar,new LinearLayout.LayoutParams(dp(72),dp(72)));LinearLayout hostMeta=col();hostMeta.setPadding(dp(9),0,0,0);TextView hostBadge=t("👑  HOST",8.5f,Color.WHITE,true);hostBadge.setGravity(Gravity.CENTER);hostBadge.setBackground(bg(0xFFB87900,0xFFFFD76D,10));hostMeta.addView(hostBadge,new LinearLayout.LayoutParams(dp(82),dp(21)));TextView hostName=t(summaryHostNameFinal,16f,Color.WHITE,true);hostName.setSingleLine(true);hostMeta.addView(hostName,new LinearLayout.LayoutParams(-1,dp(24)));TextView hostIdLine=t("ID "+hostId+"  •  LV."+hostCard.optInt("level",0)+"  •  "+(ended||x.optBoolean("closedSummary")?"LIVE ENDED":"● LIVE NOW"),8.7f,ended?0xFFC5CDE8:0xFF59E69C,true);hostMeta.addView(hostIdLine,new LinearLayout.LayoutParams(-1,dp(20)));hostStrip.addView(hostMeta,new LinearLayout.LayoutParams(0,dp(76),1));profileTab.setOnClickListener(v->showMiniProfile(hostCard));hostStrip.setOnClickListener(v->showMiniProfile(hostCard));PremiumUi.press(hostStrip);LinearLayout.LayoutParams hsp=new LinearLayout.LayoutParams(-1,dp(86));hsp.setMargins(0,dp(2),0,dp(6));box.addView(hostStrip,hsp);
        TextView top=t("Rank          User                                      Coin / Diamond Gifts",10.5f,Color.rgb(205,214,246),true);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(8),0,0,0);
        ScrollView sc=new ScrollView(this);LinearLayout rows=col();sc.addView(rows,new ScrollView.LayoutParams(-1,-2));rows.addView(top,new LinearLayout.LayoutParams(-1,dp(34)));JSONArray arr=x.optJSONArray("topSupporters");if(arr==null)arr=currentTopSupporters;int n=arr==null?0:Math.min(20,arr.length());if(n==0){TextView empty=t("No completed gifts in this Live yet",11,Color.rgb(194,205,238),true);empty.setGravity(Gravity.CENTER);rows.addView(empty,new LinearLayout.LayoutParams(-1,dp(72)));}for(int i=0;i<n;i++){JSONObject g=arr.optJSONObject(i);if(g==null)continue;int rank=i+1;try{g.put("supporterRank",rank).put("role","GIFT_SENDER");}catch(Exception ignored){}LinearLayout rr=row();rr.setGravity(Gravity.CENTER_VERTICAL);rr.setPadding(dp(7),dp(4),dp(7),dp(4));rr.setBackground(bg(rank==1?0xff684a14:rank==2?0xff414d70:rank==3?0xff663820:Color.argb(220,12,28,72),rank==1?Color.rgb(255,210,74):rank==2?Color.rgb(203,215,236):rank==3?Color.rgb(222,153,92):Color.rgb(73,102,178),14));TextView rk=t(rank==1?"👑 #1":rank==2?"🥈 #2":rank==3?"🥉 #3":"#"+rank,10.5f,Color.WHITE,true);rk.setGravity(Gravity.CENTER);rr.addView(rk,new LinearLayout.LayoutParams(dp(34),dp(54)));FrameLayout av=circleAvatar(g.optString("avatar_url",""),40,false);rr.addView(av,new LinearLayout.LayoutParams(dp(40),dp(40)));LinearLayout meta=col();meta.setPadding(dp(7),0,0,0);TextView nm=t(("FEMALE".equalsIgnoreCase(g.optString("gender"))?"♀ ":"MALE".equalsIgnoreCase(g.optString("gender"))?"♂ ":"")+g.optString("full_name","Supporter"),12f,Color.WHITE,true);nm.setSingleLine(true);nm.setMinHeight(dp(20));meta.addView(nm,new LinearLayout.LayoutParams(-1,-2));TextView route=t("ID "+g.optString("sender_id","")+" • LV."+g.optInt("level",0)+"  "+("STANDARD".equalsIgnoreCase(g.optString("tier","STANDARD"))?"":g.optString("tier")),8.1f,Color.rgb(171,224,255),true);route.setSingleLine(true);route.setMinHeight(dp(18));meta.addView(route,new LinearLayout.LayoutParams(-1,-2));long gc=g.optLong("coin_value",g.optLong("total",0)),gg=g.optLong("gold_value",0);TextView vl=t("🪙 "+compact(gc)+" Coin   •   🟡 "+compact(gg)+" Diamond   •   🎁 "+g.optLong("gift_count",0),8.4f,Color.rgb(255,224,153),true);vl.setSingleLine(true);vl.setMinHeight(dp(18));rr.addView(meta,new LinearLayout.LayoutParams(0,-2,1));vl.setText("🪙 "+compact(gc)+"\n🟡 "+compact(gg));vl.setSingleLine(false);vl.setTextSize(12);vl.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);rr.addView(vl,new LinearLayout.LayoutParams(dp(78),dp(50)));final JSONObject supporter=g;rr.setClickable(true);rr.setFocusable(true);rr.setOnClickListener(v->showMiniProfile(supporter));PremiumUi.press(rr);rr.setMinimumHeight(dp(62));LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(-1,-2);rlp.bottomMargin=dp(4);rows.addView(rr,rlp);}
        JSONArray recent=x.optJSONArray("recentGifts");int recentCount=recent==null?0:Math.min(20,recent.length());
        if(recentCount>0){TextView recentTitle=t("🧾 RECENT GIFT HISTORY",11.5f,Color.rgb(126,220,255),true);recentTitle.setPadding(dp(8),dp(9),0,0);rows.addView(recentTitle,new LinearLayout.LayoutParams(-1,dp(38)));for(int i=0;i<recentCount;i++){JSONObject e=recent.optJSONObject(i);if(e==null)continue;String sender=e.optString("sender_name",e.optString("sender_id","Supporter"));String receiver=e.optString("receiver_name",e.optString("receiver_id",hostId));boolean goldEvent="GOLD".equalsIgnoreCase(e.optString("currency","COIN"));LinearLayout history=row();history.setGravity(Gravity.CENTER_VERTICAL);history.setPadding(dp(8),dp(5),dp(8),dp(5));history.setBackground(bg(Color.argb(218,13,31,68),goldEvent?Color.rgb(255,194,67):Color.rgb(64,198,255),12));FrameLayout senderAvatar=circleAvatar(e.optString("sender_avatar",""),36,false);history.addView(senderAvatar,new LinearLayout.LayoutParams(dp(36),dp(36)));LinearLayout hm=col();hm.setPadding(dp(8),0,0,0);TextView route=t(sender+"  ➜  "+receiver,9.2f,Color.WHITE,true);route.setSingleLine(true);hm.addView(route,new LinearLayout.LayoutParams(-1,dp(20)));TextView detail=t("🎁 "+e.optString("gift_name","Gift")+"  •  "+(goldEvent?"💎 ":"🪙 ")+compact(e.optLong("price",0))+" "+(goldEvent?"Diamond":"Coin"),8.5f,goldEvent?Color.rgb(255,220,126):Color.rgb(160,228,255),true);detail.setSingleLine(true);hm.addView(detail,new LinearLayout.LayoutParams(-1,dp(19)));history.addView(hm,new LinearLayout.LayoutParams(0,dp(42),1));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(50));hp.bottomMargin=dp(3);rows.addView(history,hp);}}
        int scrollHeight=Math.min(dp(380),dp(74)+n*dp(62)+(recentCount>0?dp(38)+Math.min(6,recentCount)*dp(53):0));
        LinearLayout tabBar=row();tabBar.setGravity(Gravity.CENTER);FrameLayout tabContent=new FrameLayout(this);
        TextView supportersTab=t("🎁 Top 20",10.5f,Color.WHITE,true),statsTab=t("▮▮ Live Stats",9.5f,Color.WHITE,true),aboutTab=t("ⓘ About Host",9.5f,Color.WHITE,true);
        TextView[] tabs={supportersTab,statsTab,aboutTab};for(TextView tab:tabs){tab.setGravity(Gravity.CENTER);tab.setSingleLine(true);LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(0,dp(40),1);tlp.setMargins(dp(2),0,dp(2),0);tabBar.addView(tab,tlp);}
        ScrollView supportersScroll=sc;FrameLayout.LayoutParams contentLp=new FrameLayout.LayoutParams(-1,-1);tabContent.addView(supportersScroll,contentLp);
        LinearLayout statsPage=col();statsPage.setPadding(dp(7),dp(10),dp(7),dp(6));statsPage.setVisibility(View.GONE);
        LinearLayout statRow1=row();statRow1.addView(profileStat("DURATION",hhmmss(duration),0xFF62D9FF),new LinearLayout.LayoutParams(0,dp(66),1));statRow1.addView(profileStat("PEAK VIEWERS",compact(peak),0xFFFFC94D),new LinearLayout.LayoutParams(0,dp(66),1));statsPage.addView(statRow1,new LinearLayout.LayoutParams(-1,dp(70)));
        LinearLayout statRow2=row();statRow2.addView(profileStat("TOTAL LISTENERS",compact(listeners),0xFF76E99D),new LinearLayout.LayoutParams(0,dp(66),1));statRow2.addView(profileStat("REACTIONS",compact(reactions),0xFFFF77BD),new LinearLayout.LayoutParams(0,dp(66),1));statsPage.addView(statRow2,new LinearLayout.LayoutParams(-1,dp(70)));
        LinearLayout statRow3=row();statRow3.addView(profileStat("COIN GIFTS",compact(coin),0xFFFFC94D),new LinearLayout.LayoutParams(0,dp(66),1));statRow3.addView(profileStat("DIAMOND GIFTS",compact(gold),0xFFFF79BD),new LinearLayout.LayoutParams(0,dp(66),1));statsPage.addView(statRow3,new LinearLayout.LayoutParams(-1,dp(70)));
        TextView giftStat=t("COMPLETED GIFTS  •  "+compact(giftCount),10.5f,Color.rgb(226,231,255),true);giftStat.setGravity(Gravity.CENTER);giftStat.setBackground(bg(Color.argb(190,15,29,72),Color.rgb(73,102,178),13));statsPage.addView(giftStat,new LinearLayout.LayoutParams(-1,dp(42)));tabContent.addView(statsPage,contentLp);
        LinearLayout aboutPage=col();aboutPage.setGravity(Gravity.CENTER);aboutPage.setPadding(dp(12),dp(8),dp(12),dp(8));aboutPage.setVisibility(View.GONE);
        FrameLayout aboutAvatar=circleAvatar(hostCard.optString("avatar_url",""),dp(74),false,hostCard.optString("tier","STANDARD"),hostCard.optString("membership_frame_url",hostCard.optString("frame_url","")));aboutPage.addView(aboutAvatar,new LinearLayout.LayoutParams(dp(74),dp(74)));
        TextView aboutName=t(summaryHostNameFinal,14,Color.WHITE,true);aboutName.setGravity(Gravity.CENTER);aboutName.setSingleLine(true);aboutPage.addView(aboutName,new LinearLayout.LayoutParams(-1,dp(30)));
        TextView aboutMeta=t("myshop ID  "+hostId+(hostCard.optInt("level",0)>0?"  •  LV."+hostCard.optInt("level"):""),10,Color.rgb(201,213,245),false);aboutMeta.setGravity(Gravity.CENTER);aboutPage.addView(aboutMeta,new LinearLayout.LayoutParams(-1,dp(26)));
        Button openHost=small("OPEN HOST PROFILE");openHost.setOnClickListener(v->{Intent q=new Intent(this,UserProfileActivity.class);q.putExtra("userId",hostId);startActivity(q);});aboutPage.addView(openHost,new LinearLayout.LayoutParams(-1,dp(42)));tabContent.addView(aboutPage,contentLp);
        View[] tabPages={supportersScroll,statsPage,aboutPage};
        supportersTab.setOnClickListener(v->selectLiveSummaryTab(tabPages,tabs,0));statsTab.setOnClickListener(v->selectLiveSummaryTab(tabPages,tabs,1));aboutTab.setOnClickListener(v->selectLiveSummaryTab(tabPages,tabs,2));tabBar.setBackground(bg(Color.argb(210,8,18,48),Color.rgb(69,73,132),14));box.addView(tabBar,new LinearLayout.LayoutParams(-1,dp(42)));box.addView(tabContent,new LinearLayout.LayoutParams(-1,scrollHeight));selectLiveSummaryTab(tabPages,tabs,0);
        AlertDialog dlg=new MyShopCompatDialogBuilder(this).setView(box).setPositiveButton(ended?"DONE":"CLOSE",(d,w)->{if(ended)finish();}).setNeutralButton("MY RECEIPT",(d,w)->showMyGiftReceipt()).setNegativeButton("SHARE",(d,w)->shareSummaryText(x)).setCancelable(!ended).create();dlg.setOnShowListener(d->{android.view.Window w=dlg.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.95f),-2);}for(int which:new int[]{android.content.DialogInterface.BUTTON_POSITIVE,android.content.DialogInterface.BUTTON_NEUTRAL,android.content.DialogInterface.BUTTON_NEGATIVE}){Button button=dlg.getButton(which);if(button!=null){button.setTextColor(Color.WHITE);button.setAllCaps(false);button.setTextSize(11.5f);}}});dlg.setOnDismissListener(d->{if(ended&&!isFinishing())finish();});dlg.setOnDismissListener(d->{if(ended&&!isFinishing())finish();});dlg.show();closeTop.setOnClickListener(v->dlg.dismiss());
    }

    private void showLifetimeGifters(){LifetimeGifters.show(this,hostId);}


    private void selectLiveSummaryTab(View[] pages,TextView[] tabs,int selected){
        for(int i=0;i<pages.length;i++)pages[i].setVisibility(i==selected?View.VISIBLE:View.GONE);
        for(int i=0;i<tabs.length;i++)tabs[i].setBackground(bg(i==selected?Color.rgb(55,62,165):Color.argb(175,8,18,48),i==selected?Color.rgb(130,145,255):Color.rgb(69,73,132),12));
    }

    private void showMyGiftReceipt(){
        String me=SessionManager.getUserId(this);long coin=0,gold=0,count=0;if(currentTopSupporters!=null)for(int i=0;i<currentTopSupporters.length();i++){JSONObject g=currentTopSupporters.optJSONObject(i);if(g!=null&&me.equals(g.optString("sender_id",""))){coin=g.optLong("coin_value",0);gold=g.optLong("gold_value",0);count=g.optLong("gift_count",0);break;}}
        LinearLayout card=col();card.setPadding(dp(15),dp(14),dp(15),dp(14));card.setBackground(gradient(new int[]{0xF20A173A,0xF23A195D},0xFFFFCB53,22));TextView title=t("🎁  MY LIVE GIFT RECEIPT",16,Color.WHITE,true);title.setGravity(Gravity.CENTER);card.addView(title,new LinearLayout.LayoutParams(-1,dp(40)));TextView id=t("myshop ID  "+me+"  •  VERIFIED SESSION",8.7f,0xFF76E7FF,true);id.setGravity(Gravity.CENTER);card.addView(id,new LinearLayout.LayoutParams(-1,dp(24)));LinearLayout stats=row();stats.setPadding(0,dp(8),0,dp(8));stats.addView(profileStat("COIN GIFT",compact(coin),0xFFFFC94D),new LinearLayout.LayoutParams(0,dp(60),1));stats.addView(profileStat("DIAMOND GIFT",compact(gold),0xFFFF79BD),new LinearLayout.LayoutParams(0,dp(60),1));stats.addView(profileStat("GIFTS SENT",compact(count),0xFF6FDBFF),new LinearLayout.LayoutParams(0,dp(60),1));card.addView(stats,new LinearLayout.LayoutParams(-1,dp(76)));TextView note=t(count>0?"✓ Only completed gifts are included":"No completed gifts from you in this Live",8.5f,count>0?0xFF61E4A0:0xFFC5CDE8,true);note.setGravity(Gravity.CENTER);card.addView(note,new LinearLayout.LayoutParams(-1,dp(30)));new MyShopCompatDialogBuilder(this).setView(card).setPositiveButton("CLOSE",null).show();
    }

    private void shareSummaryText(JSONObject x){
        Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,"myshop Live Summary • Host "+hostId+" • Duration "+hhmmss(x.optLong("duration_seconds",0))+" • Peak "+x.optLong("peak_viewers",0)+" • Listeners "+x.optLong("total_listeners",0)+" • Top Gifters 1–20");startActivity(Intent.createChooser(send,"Share Live Summary"));
    }

    private void renderPremiumState(JSONObject d){
        if(d==null||premiumStrip==null)return;
        String tier=d.optString("myTier",d.optString("membershipTier","")).trim();
        String role=d.optString("myRole",host?"HOST":"AUDIENCE");
        String net=networkQuality();
        StringBuilder line=new StringBuilder("⚡ LIVE AUDIO • ").append(role).append(" • ").append(net).append(" • ").append(rtcAudioIndicator());
        if(!tier.isEmpty()&&!"FREE".equalsIgnoreCase(tier))line.append(" • ").append(tier);
        premiumStrip.setText(line.toString());premiumStrip.setVisibility(View.VISIBLE);
    }

    private void renderPinnedProduct(JSONObject p){if(p==null||p.optLong("id")<1){productView.setVisibility(View.GONE);return;}long id=p.optLong("id");productView.setText("🛒 "+p.optString("title","Shop product")+"  •  ৳"+String.format(Locale.US,"%.2f",p.optLong("price")/100.0)+"  •  BUY NOW ›");productView.setVisibility(View.VISIBLE);productView.setOnClickListener(v->startActivity(new Intent(this,PhysicalStoreActivity.class).setData(android.net.Uri.parse("myshop://product/"+id))));}

    private JSONObject findSeat(JSONArray a,int seatNo){if(a==null)return null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&x.optInt("seat_no")==seatNo)return x;}return null;}
    private JSONObject findUser(JSONArray a,String userId){if(a==null||userId==null||userId.isEmpty())return null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&userId.equals(x.optString("user_id")))return x;}return null;}

    private boolean isRtcSpeaking(JSONObject x,boolean hostAvatar){
        if(System.currentTimeMillis()-activeRtcSpeakerAt>900L)return false;
        String uid=x==null?hostId:x.optString("user_id",hostId);if(uid.equals(SessionManager.getUserId(this)))return localMicOn&&localSpeaking;
        try{return rtcManager!=null&&rtcManager.isSpeaking(Integer.parseInt(uid));}catch(Exception ignored){return false;}

    }

    private final java.util.LinkedHashMap<String,SpeakerPortrait> speakerPortraits=new java.util.LinkedHashMap<>();
    private final class SpeakerPortrait extends FrameLayout {
        JSONObject user;final SpeakingWaveView wave;final TextView mutedMark;
        SpeakerPortrait(JSONObject x,int size){super(AudioLiveRoomActivity.this);String tier=identityTier(x);String asset=MembershipUi.isTier(tier)?x.optString("membership_frame_url",""):x.optString("frame_url","");addView(circleAvatar(x.optString("avatar_url",""),size,false,tier,asset),new FrameLayout.LayoutParams(-1,-1));wave=new SpeakingWaveView(AudioLiveRoomActivity.this);addView(wave,new FrameLayout.LayoutParams(-1,-1));mutedMark=t("🎙✕",8,0xffff525e,true);mutedMark.setGravity(Gravity.CENTER);mutedMark.setBackground(bg(0xe12d0a18,0xffff4654,9));addView(mutedMark,new FrameLayout.LayoutParams(dp(24),dp(16),Gravity.END|Gravity.BOTTOM));}
        void update(JSONObject x,boolean speaking){user=x;boolean muted=x.optInt("mic_on",1)==0||x.optInt("muted",0)==1;mutedMark.setVisibility(muted?View.VISIBLE:View.GONE);wave.setSpeaking(!muted&&speaking);}
    }
    private FrameLayout avatarWithMicState(JSONObject x,int size,boolean speaking){
        if(x==null)x=new JSONObject();String key=x.optString("user_id","")+":"+size+":"+identityTier(x)+":"+x.optString("avatar_url","")+":"+x.optString("membership_frame_url",x.optString("frame_url",""));
        SpeakerPortrait portrait=speakerPortraits.get(key);if(portrait==null){portrait=new SpeakerPortrait(x,size);speakerPortraits.put(key,portrait);}portrait.update(x,speaking);
        if(portrait.getParent() instanceof android.view.ViewGroup)((android.view.ViewGroup)portrait.getParent()).removeView(portrait);
        if(speakerPortraits.size()>100){java.util.Iterator<java.util.Map.Entry<String,SpeakerPortrait>> it=speakerPortraits.entrySet().iterator();while(it.hasNext()&&speakerPortraits.size()>80){SpeakerPortrait old=it.next().getValue();if(old!=portrait&&old.getParent()==null)it.remove();}}
        return portrait;
    }

    private boolean isTopGifter(String uid){
        if(uid==null||uid.isEmpty()||currentTopSupporters==null||currentTopSupporters.length()==0)return false;
        JSONObject top=currentTopSupporters.optJSONObject(0);return top!=null&&uid.equals(top.optString("sender_id",""));
    }

    private FrameLayout circleAvatar(String url,int size,boolean speaking){return circleAvatar(url,size,speaking,"STANDARD","");}
    private FrameLayout circleAvatar(String url,int size,boolean speaking,String tier){return circleAvatar(url,size,speaking,tier,"");}
    private FrameLayout circleAvatar(String url,int size,boolean speaking,String tier,String frameUrl){
        String cosmeticKey=AvatarCosmetics.fromUrl(frameUrl);if(cosmeticKey!=null){FrameLayout cosmetic=new FrameLayout(this);cosmetic.addView(new AvatarCosmetics.Portrait(this,cosmeticKey,url),new FrameLayout.LayoutParams(-1,-1));return cosmetic;}
        if(MembershipUi.hasFrame(tier)){MembershipIdentityView identity=readyMembershipAvatar(tier,url);identity.setFrameAsset(frameUrl);return identity;}
        FrameLayout frame=new FrameLayout(this);frame.setClipChildren(false);frame.setClipToPadding(false);int premiumStroke="KING".equalsIgnoreCase(tier)?Color.rgb(255,182,46):"QUEEN".equalsIgnoreCase(tier)?Color.rgb(255,78,180):"ROYAL".equalsIgnoreCase(tier)?Color.rgb(166,91,255):"VVIP".equalsIgnoreCase(tier)?Color.rgb(52,205,255):"VIP".equalsIgnoreCase(tier)?Color.rgb(83,224,126):Color.rgb(153,132,255);
        int stroke=speaking?Color.rgb(255,214,84):premiumStroke;frame.setBackground(bg(Color.argb(210,25,33,82),stroke,size/2));
        ImageView v=new ImageView(this);v.setImageResource(R.drawable.myshop_profile_avatar);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(bg(Color.rgb(34,45,105),stroke,size/2));v.setClipToOutline(true);
        boolean premiumTier=tier!=null&&!tier.trim().isEmpty()&&!"STANDARD".equalsIgnoreCase(tier)&&!"FREE".equalsIgnoreCase(tier);
        int pad=dp(premiumTier?5:3);FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,-1);ip.setMargins(pad,pad,pad,pad);frame.addView(v,ip);
        if(url!=null&&!url.trim().isEmpty())loadImage(v,url);
        if(frameUrl!=null&&!frameUrl.trim().isEmpty()&&!premiumTier){ImageView premiumFrame=new ImageView(this);premiumFrame.setScaleType(ImageView.ScaleType.FIT_CENTER);premiumFrame.setAdjustViewBounds(false);premiumFrame.setContentDescription("Equipped Live premium profile frame");FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(-1,-1);fp.setMargins(dp(1),dp(1),dp(1),dp(1));frame.addView(premiumFrame,fp);AnimatedAssetLoader.load(premiumFrame,frameUrl,true);}if(premiumTier&&!MembershipUi.hasFrame(tier)){TextView aura=t(liveMembershipCrest(tier),Math.max(15f,size/3.0f),Color.WHITE,true);aura.setGravity(Gravity.CENTER);aura.setTextColor(premiumStroke);aura.setShadowLayer(dp(8),0,0,premiumStroke);aura.setBackground(bg(Color.TRANSPARENT,premiumStroke,size/2));FrameLayout.LayoutParams af=new FrameLayout.LayoutParams(-1,-1);af.setMargins(dp(1),dp(1),dp(1),dp(1));frame.addView(aura,af);ObjectAnimator pulse=ObjectAnimator.ofFloat(aura,"alpha",.38f,1f,.38f);pulse.setDuration(1250);pulse.setRepeatCount(ValueAnimator.INFINITE);pulse.start();aura.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View x){}public void onViewDetachedFromWindow(View x){pulse.cancel();}});}
        if(premiumTier&&!MembershipUi.hasFrame(tier)){TextView crest=t(liveMembershipCrest(tier)+" "+tier.toUpperCase(Locale.US),Math.max(6.6f,size/8.2f),Color.WHITE,true);crest.setGravity(Gravity.CENTER);crest.setShadowLayer(dp(4),0,0,premiumStroke);crest.setBackground(bg(Color.argb(232,19,18,47),premiumStroke,10));FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(Math.max(34,size/1.45f)),dp(Math.max(16,size/4)),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);cp.bottomMargin=-dp(3);frame.addView(crest,cp);}
        if(MembershipUi.hasFrame(tier)){v.setAlpha(0f);MembershipIdentityView memberView=readyMembershipAvatar(tier,url);memberView.setFrameAsset(frameUrl);frame.addView(memberView,new FrameLayout.LayoutParams(-1,-1));}
        // Speaking effect animates only the ring/glow. The profile photo itself stays perfectly still.
        if(speaking){TextView ring=t("",1,Color.TRANSPARENT,false);GradientDrawable wave=bg(Color.TRANSPARENT,Color.rgb(255,221,102),size/2);wave.setStroke(dp(3),0xffffdc63);ring.setBackground(wave);ring.setElevation(dp(4));FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(-1,-1);rp.setMargins(dp(1),dp(1),dp(1),dp(1));frame.addView(ring,rp);ObjectAnimator glow=ObjectAnimator.ofFloat(ring,"alpha",.22f,1f,.22f);glow.setDuration(520);ObjectAnimator gx=ObjectAnimator.ofFloat(ring,"scaleX",1.04f,1.48f,1.04f);gx.setDuration(620);gx.setRepeatCount(ValueAnimator.INFINITE);gx.start();ObjectAnimator gy=ObjectAnimator.ofFloat(ring,"scaleY",1.04f,1.48f,1.04f);gy.setDuration(620);gy.setRepeatCount(ValueAnimator.INFINITE);gy.start();glow.setRepeatCount(ValueAnimator.INFINITE);glow.start();ring.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View x){}public void onViewDetachedFromWindow(View x){glow.cancel();gx.cancel();gy.cancel();}});}
        return frame;
    }
    private String liveMembershipCrest(String tier){String x=tier==null?"":tier.trim().toUpperCase(Locale.US);if("KING".equals(x))return "♛";if("QUEEN".equals(x))return "♕";if("ROYAL".equals(x))return "✦";if("VVIP".equals(x))return "◆";if("VIP".equals(x))return "❖";return "★";}

    private void loadImage(ImageView v,String u){if(u==null||u.trim().isEmpty())return;v.setTag(u);Bitmap cached=avatarCache.get(u);if(cached!=null){v.setImageBitmap(cached);return;}java.util.List<java.lang.ref.WeakReference<ImageView>> targets=avatarTargets.get(u);if(targets==null){targets=new java.util.ArrayList<>();avatarTargets.put(u,targets);}targets.add(new java.lang.ref.WeakReference<>(v));fetchAvatar(u);}

    private String networkQuality(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);NetworkInfo n=cm==null?null:cm.getActiveNetworkInfo();if(n==null||!n.isConnected())return "OFFLINE";return rtcNetworkQuality;}catch(Exception e){return "GOOD";}}
    private String signal(String q){q=q==null?"GOOD":q.toUpperCase();if("WEAK".equals(q)||"OFFLINE".equals(q))return "▂";if("FAIR".equals(q))return "▂▄";return "▂▄▆";}
    private long parseServerTime(String s){if(s==null||s.trim().isEmpty())return 0;String[] patterns={"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd'T'HH:mm:ss.SSS'Z'","yyyy-MM-dd'T'HH:mm:ss'Z'"};for(String p:patterns){try{SimpleDateFormat f=new SimpleDateFormat(p,Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));Date d=f.parse(s);if(d!=null)return d.getTime();}catch(Exception ignored){}}return 0;}
    private String summaryTime(String s){if(s==null||s.trim().isEmpty())return "—";String x=s.trim();return x.length()>=19?x.substring(11,19):x;}
    private String hhmm(long sec){long h=sec/3600,m=(sec%3600)/60;return String.format(Locale.US,"%02d:%02d",h,m);}
    private String hhmmss(long sec){long h=sec/3600,m=(sec%3600)/60,s=sec%60;return String.format(Locale.US,"%02d:%02d:%02d",h,m,s);}
    private String token(){return SessionManager.getToken(this);}

    @Override public void onBackPressed(){
        if(roomEnded){finish();return;}if(endLiveInProgress)return;
        if(!roomEnded && !endLiveInProgress && Build.VERSION.SDK_INT>=26){
            try{PictureInPictureParams params=new PictureInPictureParams.Builder().setAspectRatio(new Rational(9,16)).build();enterPictureInPictureMode(params);return;}catch(Exception ignored){}
        }
        moveTaskToBack(true);
    }
    @Override protected void onDestroy(){avatarPool.shutdownNow();avatarTargets.clear();clearSessionEffects();entryQueue.clear();giftEffectQueue.clear();giftEffectPlaying=false;if(entryStage!=null&&entryStage.getParent() instanceof ViewGroup)((ViewGroup)entryStage.getParent()).removeView(entryStage);entrySound430.stop();handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);handler.removeCallbacks(realtimeTick);handler.removeCallbacks(presenceTick);handler.removeCallbacks(participantTick);if(joinPulseAlpha!=null)joinPulseAlpha.cancel();if(joinPulseX!=null)joinPulseX.cancel();if(joinPulseY!=null)joinPulseY.cancel();joinPulseAlpha=null;joinPulseX=null;joinPulseY=null;activeSessionId="";serverElapsedSec=0;serverElapsedSyncMs=0;pendingComments.clear();stopVoiceMonitor(false);if(rtcManager!=null){rtcManager.destroy();rtcManager=null;}if(giftDialog613!=null&&giftDialog613.isShowing())giftDialog613.dismiss();if(giftLoadingDialog!=null&&giftLoadingDialog.isShowing())giftLoadingDialog.dismiss();if(giftStoreDialog!=null&&giftStoreDialog.isShowing())giftStoreDialog.dismiss();if(isFinishing()&&!roomEnded&&!host){BackendClient.liveLeaveSeat(token(),hostId,new Silent());BackendClient.liveViewer(token(),hostId,false,new Silent());}super.onDestroy();}


    private class GoldenGuestHalo extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private float phase=0;private ValueAnimator animator;private final boolean guestPresent;
        GoldenGuestHalo(Context c,boolean guestPresent){super(c);this.guestPresent=guestPresent;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onAttachedToWindow(){super.onAttachedToWindow();if(animator==null){animator=ValueAnimator.ofFloat(0,360);animator.setDuration(4200);animator.setInterpolator(new android.view.animation.LinearInterpolator());animator.setRepeatCount(ValueAnimator.INFINITE);animator.addUpdateListener(a->{phase=(float)a.getAnimatedValue();invalidate();});}animator.start();}
        @Override protected void onDetachedFromWindow(){if(animator!=null)animator.cancel();super.onDetachedFromWindow();}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float cx=getWidth()/2f,cy=getHeight()/2f,side=Math.min(getWidth(),getHeight()),t=phase/360f;float pulse=.55f+.45f*(float)Math.sin(t*6.283);p.setStyle(Paint.Style.STROKE);for(int i=0;i<3;i++){float f=(t+i/3f)%1;p.setColor(i==1?0xff56dcff:0xffffd471);p.setAlpha((int)(180*(1-f)));p.setStrokeWidth(dp(1.5f));p.setShadowLayer(dp(5)*pulse,0,0,p.getColor());c.drawCircle(cx,cy,side*(.38f+f*.105f),p);}p.clearShadowLayer();p.setAlpha(255);}



    }

    class ToastCb implements BackendClient.Callback{String ok;ToastCb(String s){ok=s;}public void onSuccess(JSONObject d){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,ok,Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}}
    static class Silent implements BackendClient.Callback{public void onSuccess(JSONObject d){}public void onError(String m){}}

    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private Button btn(String s){Button b=new Button(this);b.setAllCaps(false);b.setText(DisplayIds611.format(s));b.setTextColor(Color.WHITE);b.setTextSize(13);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);PremiumUi.premiumAccent(b);return b;}
    private Button small(String s){Button b=btn(s);b.setTextSize(9.5f);b.setMinWidth(0);b.setMinimumWidth(0);return b;}
    private TextView t(String s,float z,int c,boolean bold){TextView v=new TextView(this);v.setText(DisplayIds611.format(s));v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private GradientDrawable bg(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private GradientDrawable gradient(int[] colors,int stroke,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private GradientDrawable softGradient(int[] colors,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(radius));return g;}
    private int dp(float x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
 private String cosmeticForComment611(JSONObject comment){String url=comment.optString("frame_url");if(url.isEmpty()){String uid=comment.optString("user_id");JSONObject known=findUser(currentViewerProfiles,uid);if(known==null)known=findUser(currentSeats,uid);if(known!=null)url=known.optString("frame_url");}return AvatarCosmetics.fromUrl(url);}
}
