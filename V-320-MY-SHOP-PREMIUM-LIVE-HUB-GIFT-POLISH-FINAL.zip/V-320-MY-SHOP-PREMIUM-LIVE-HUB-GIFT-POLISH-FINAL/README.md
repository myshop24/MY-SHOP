# Current Release — MY SHOP V-319

V-319 is based on V-318 and contains two release-blocking changes: the user-reported Gift Store `GridLayout` compile fix and Priority #1 **Animated Gift Catalog System** for both Gift Coin and Gold Coin.

Read:
- `V-319_RELEASE_NOTES.md`
- `V-319_VALIDATION_REPORT.txt`
- `V-319_PLAY_COMPLIANCE_QA.md`
- `MY-SHOP-DEVELOPER-HANDOFF.md`

Build identity: `MY SHOP V-319` / Android `2.9.319` / versionCode `319`.
