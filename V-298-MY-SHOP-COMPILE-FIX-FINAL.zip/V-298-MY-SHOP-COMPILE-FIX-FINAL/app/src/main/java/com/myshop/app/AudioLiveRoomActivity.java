package com.myshop.app;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

/**
 * MY SHOP V-295 Premium Audio Live Room with light right-action spacing and bottom safe-area protection.
 * 12-seat authoritative layout: Seat 1 Host + Seats 2-12 Speakers (11 speaker seats).
 * The bundled Guitar Blue wallpaper is the safe default while Admin themes
 * can override it remotely without changing the Dashboard.
 */
public class AudioLiveRoomActivity extends AppCompatActivity {
    private final Handler handler = new Handler();
    private boolean host;
    private boolean hostStarted;
    private boolean localMicOn = true;
    private boolean roomAdmin = false;
    private boolean listenOnly = false;
    private String hostId;
    private String specialGuestId = "";
    private String myRole = "AUDIENCE";
    private long startedAtMs = 0L;
    private int shareCount = 0;
    private ImageView wallpaper;
    private LinearLayout hostArea, audienceRow, specialArea, seats, requests, commentsList;
    private TextView viewers, status, syncState, durationView, roomTitle, roomTopic, pinnedView, shareView, reactView;
    private String currentLiveName = "Host";
    private final Set<Integer> lockedSeats = new HashSet<>();
    private JSONArray currentViewerProfiles = new JSONArray();
    private JSONArray currentRequests = new JSONArray();
    private int currentViewerCount = 0;
    private String lastInviteNotice = "";
    private String lastRequestNotice = "";
    private boolean inviteDialogOpen = false;
    private boolean requestDialogOpen = false;
    private int highlightPrice = 1000;
    private boolean highlightSelected = false;
    private long lastHighlightId = 0L;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (hostStarted || !host) {
                if (host) BackendClient.setLivePresence(token(), true, new Silent());
                else BackendClient.liveViewer(token(), hostId, true, new Silent());
                if (host || "SPEAKER".equals(myRole)) {
                    BackendClient.liveParticipantState(token(), hostId, localMicOn, false, networkQuality(), new Silent());
                }
                refresh();
            }
            handler.postDelayed(this, 3000);
        }
    };

    private final Runnable durationTick = new Runnable() {
        @Override public void run() {
            if (startedAtMs > 0 && durationView != null) {
                long sec = Math.max(0, (System.currentTimeMillis() - startedAtMs) / 1000L);
                durationView.setText(hhmm(sec));
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        host = getIntent().getBooleanExtra("hostMode", false);
        hostId = host ? SessionManager.getUserId(this) : getIntent().getStringExtra("hostId");
        if (hostId == null || hostId.trim().isEmpty()) hostId = SessionManager.getUserId(this);
        build();
        renderLocalSkeleton();
        handler.post(durationTick);
        if (host) showHostSetup();
        else {
            BackendClient.liveViewer(token(), hostId, true, new Silent());
            handler.post(tick);
        }
    }

    private void showHostSetup() {
        final android.app.Dialog d=new android.app.Dialog(this);
        LinearLayout box=col();box.setPadding(dp(20),dp(18),dp(20),dp(18));box.setBackground(bg(Color.rgb(10,18,58),Color.rgb(170,69,255),24));
        TextView hd=t("🎙  START AUDIO LIVE",18,Color.WHITE,true);hd.setGravity(Gravity.CENTER);box.addView(hd,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView sub=t("Create your MY SHOP audio room",10.5f,Color.rgb(188,202,244),false);sub.setGravity(Gravity.CENTER);box.addView(sub,new LinearLayout.LayoutParams(-1,dp(30)));
        EditText title=new EditText(this);title.setHint("Live Name");title.setText(SessionManager.getFullName(this).isEmpty()?"My Live":SessionManager.getFullName(this));title.setTextColor(Color.WHITE);title.setHintTextColor(Color.rgb(155,166,205));title.setSingleLine(true);title.setPadding(dp(14),0,dp(14),0);title.setBackground(bg(Color.rgb(17,31,79),Color.rgb(94,110,225),16));LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(50));tp.topMargin=dp(10);box.addView(title,tp);
        EditText topic=new EditText(this);topic.setHint("Caption");topic.setText("");topic.setTextColor(Color.WHITE);topic.setHintTextColor(Color.rgb(155,166,205));topic.setSingleLine(true);topic.setPadding(dp(14),0,dp(14),0);topic.setBackground(bg(Color.rgb(17,31,79),Color.rgb(94,110,225),16));LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,dp(50));op.topMargin=dp(10);box.addView(topic,op);
        LinearLayout actions=row();Button cancel=small("Cancel");cancel.setBackground(bg(Color.rgb(27,38,83),Color.rgb(96,111,185),18));Button go=btn("GO LIVE");go.setBackground(bg(Color.rgb(126,43,218),Color.rgb(255,71,192),18));cancel.setOnClickListener(v->{d.dismiss();finish();});go.setOnClickListener(v->{String t=title.getText().toString().trim(),p=topic.getText().toString().trim();if(t.isEmpty())t=SessionManager.getFullName(AudioLiveRoomActivity.this);if(t==null||t.trim().isEmpty())t="My Live";d.dismiss();startHostLive(t,p);});LinearLayout.LayoutParams c=new LinearLayout.LayoutParams(0,dp(46),.38f);c.rightMargin=dp(8);actions.addView(cancel,c);actions.addView(go,new LinearLayout.LayoutParams(0,dp(46),.62f));LinearLayout.LayoutParams ax=new LinearLayout.LayoutParams(-1,dp(46));ax.topMargin=dp(16);box.addView(actions,ax);
        d.setContentView(box);d.setCancelable(false);d.setOnShowListener(x->{android.view.Window w=d.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.72f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.88f),-2);}});d.show();
    }

    private void startHostLive(String title, String topic) {
        BackendClient.setLivePresence(token(), true, new BackendClient.Callback() {
            @Override public void onSuccess(JSONObject data) {
                hostStarted = true;
                BackendClient.liveRoomConfig(token(), title, topic, null, null, new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(() -> { syncState.setText("● LIVE • Room connected"); refresh(); handler.post(tick); });}public void onError(String e){BackendClient.setLivePresence(token(),false,new Silent());hostStarted=false;runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_LONG).show();showHostSetup();});}});
            }
            @Override public void onError(String m) { runOnUiThread(() -> { syncState.setText("Could not start live"); Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show(); }); }
        });
    }

    private void build() {
        FrameLayout page = new FrameLayout(this);
        wallpaper = new ImageView(this);
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        wallpaper.setImageResource(R.drawable.live_guitar_wallpaper);
        page.addView(wallpaper, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout root = col(); root.setPadding(dp(10), dp(4), dp(10), dp(10));
        root.setBackgroundColor(Color.argb(170, 3, 8, 34));
        page.addView(root, new FrameLayout.LayoutParams(-1,-1));

        // V-292: preserve V-291 bottom safe-area and add only light spacing to right-side actions.
        // clearly above Android gesture/navigation controls on every device.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int navBottom = insets == null ? 0 : insets.getSystemWindowInsetBottom();
            root.setPadding(dp(10), dp(4), dp(10), Math.max(dp(18), navBottom + dp(18)));
            return insets;
        });
        root.post(root::requestApplyInsets);

        roomTitle = t("", 1, Color.TRANSPARENT, false);
        viewers = t("", 1, Color.TRANSPARENT, false); viewers.setVisibility(View.GONE);
        LinearLayout meta = row();
        status = t((host?"👑 Host":"🎧 Audience")+" • ID "+SessionManager.getUserId(this),11,Color.rgb(226,199,255),true);
        meta.addView(status,new LinearLayout.LayoutParams(0,dp(28),1));
        shareView=t("↗ 0",11,Color.rgb(226,199,255),true); shareView.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); meta.addView(shareView,new LinearLayout.LayoutParams(dp(70),dp(28)));
        meta.setVisibility(View.GONE); root.addView(meta,new LinearLayout.LayoutParams(1,1));
        syncState=t("",1,Color.TRANSPARENT,false); syncState.setVisibility(View.GONE); root.addView(syncState,new LinearLayout.LayoutParams(1,1));

        hostArea=row(); hostArea.setGravity(Gravity.CENTER_VERTICAL);
        audienceRow=row(); audienceRow.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(hostArea,new LinearLayout.LayoutParams(-1,dp(66)));
        roomTopic = t("Add caption",9.5f,Color.WHITE,true); roomTopic.setSingleLine(true); roomTopic.setEllipsize(android.text.TextUtils.TruncateAt.END); roomTopic.setGravity(Gravity.CENTER_VERTICAL); roomTopic.setPadding(dp(10),0,dp(10),0); roomTopic.setBackground(gradient(new int[]{Color.argb(215,54,31,126),Color.argb(215,174,45,151)},Color.rgb(255,206,91),13)); roomTopic.setOnClickListener(v->{if(host)editCaptionOnly();}); LinearLayout.LayoutParams ctp=new LinearLayout.LayoutParams(dp(220),dp(26)); ctp.topMargin=dp(1); ctp.bottomMargin=dp(2); root.addView(roomTopic,ctp);
        specialArea=col(); specialArea.setGravity(Gravity.CENTER_HORIZONTAL); LinearLayout.LayoutParams sgp=new LinearLayout.LayoutParams(-1,-2); sgp.topMargin=dp(2); root.addView(specialArea,sgp);

        seats=col(); seats.setPadding(dp(2),dp(2),dp(2),dp(2)); seats.setBackgroundColor(Color.TRANSPARENT); root.addView(seats,new LinearLayout.LayoutParams(-1,-2));

        if(host){
            requests=col(); requests.setVisibility(View.GONE); root.addView(requests,new LinearLayout.LayoutParams(1,1)); requests.addView(t("No pending requests",11,Color.LTGRAY,false));
        }

        pinnedView=t("📌 No pinned announcement",11,Color.rgb(255,224,138),true); pinnedView.setPadding(dp(8),dp(7),dp(8),dp(6)); pinnedView.setBackground(bg(Color.argb(125,25,26,66),Color.rgb(131,96,235),12));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(28)); pp.topMargin=dp(3); root.addView(pinnedView,pp);

        TextView chatTitle=t("💬 LIVE COMMENTS",11,Color.WHITE,true); chatTitle.setPadding(0,dp(3),0,dp(2)); root.addView(chatTitle,new LinearLayout.LayoutParams(-1,dp(22)));
        FrameLayout commentStage=new FrameLayout(this);
        ScrollView commentScroll=new ScrollView(this); commentsList=col(); commentsList.setPadding(dp(8),dp(6),dp(8),dp(6)); commentsList.setBackground(bg(Color.argb(150,7,16,52),Color.rgb(65,82,157),14)); commentScroll.addView(commentsList);
        FrameLayout.LayoutParams csp=new FrameLayout.LayoutParams(-1,-1); csp.rightMargin=dp(48); commentStage.addView(commentScroll,csp);
        LinearLayout floating=col(); floating.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView request=t("✋",18,Color.WHITE,true); request.setGravity(Gravity.CENTER); request.setBackground(bg(Color.argb(220,18,49,118),Color.rgb(69,208,255),21)); request.setOnClickListener(v->{if(host)showJoinRequestsDialog();else BackendClient.liveSpeakRequest(token(),hostId,new ToastCb("Join request sent"));}); floating.addView(request,new LinearLayout.LayoutParams(dp(42),dp(42)));
        TextView gift=t("🎁",19,Color.WHITE,true); gift.setGravity(Gravity.CENTER); gift.setBackground(bg(Color.argb(220,80,37,138),Color.rgb(255,195,72),21)); gift.setOnClickListener(v->showGiftPanel()); LinearLayout.LayoutParams gfp=new LinearLayout.LayoutParams(dp(42),dp(42)); gfp.topMargin=dp(8); floating.addView(gift,gfp);
        reactView=t("❤️",16,Color.WHITE,true); reactView.setGravity(Gravity.CENTER); reactView.setBackground(bg(Color.argb(220,111,22,125),Color.rgb(255,74,189),21)); reactView.setOnClickListener(v->{BackendClient.liveReact(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{reactView.setText("❤️\n"+compact(d.optLong("reactCount",0)));if(d.optInt("rewardCoin",0)>0&&host)Toast.makeText(AudioLiveRoomActivity.this,"React reward +"+d.optInt("rewardCoin")+" Coin",Toast.LENGTH_LONG).show();showReaction();});}public void onError(String e){runOnUiThread(()->showReaction());}});}); LinearLayout.LayoutParams frp=new LinearLayout.LayoutParams(dp(42),dp(42)); frp.topMargin=dp(8); floating.addView(reactView,frp);
        TextView share=t("↗",18,Color.WHITE,true); share.setGravity(Gravity.CENTER); share.setBackground(bg(Color.argb(220,15,59,118),Color.rgb(42,206,255),21)); share.setOnClickListener(v->shareRoom()); LinearLayout.LayoutParams sfp=new LinearLayout.LayoutParams(dp(42),dp(42)); sfp.topMargin=dp(8); floating.addView(share,sfp);
        FrameLayout.LayoutParams fap=new FrameLayout.LayoutParams(dp(42),dp(192),Gravity.RIGHT|Gravity.BOTTOM); fap.rightMargin=dp(1); fap.bottomMargin=dp(2); commentStage.addView(floating,fap);
        root.addView(commentStage,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout sendRow=row(); sendRow.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout commentBox=new FrameLayout(this);
        EditText commentInput=new EditText(this); commentInput.setHint("Write a comment…"); commentInput.setTextColor(Color.WHITE); commentInput.setHintTextColor(Color.rgb(155,165,195)); commentInput.setSingleLine(true); commentInput.setTextSize(11); commentInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_SHORT_MESSAGE); commentInput.setBackground(bg(Color.argb(170,10,24,61),Color.rgb(67,91,171),17)); commentInput.setPadding(dp(10),0,dp(38),0); commentBox.addView(commentInput,new FrameLayout.LayoutParams(-1,-1));
        TextView highlight=t("✨",15,Color.rgb(255,219,96),true); highlight.setGravity(Gravity.CENTER); FrameLayout.LayoutParams hlp=new FrameLayout.LayoutParams(dp(36),-1,Gravity.RIGHT); commentBox.addView(highlight,hlp);
        highlight.setOnClickListener(v->{highlightSelected=!highlightSelected;highlight.setBackground(highlightSelected?bg(Color.argb(170,112,48,170),Color.rgb(255,216,89),15):null);Toast.makeText(this,highlightSelected?"Highlight ON • "+highlightPrice+" Coin":"Highlight OFF",Toast.LENGTH_SHORT).show();});
        BackendClient.liveHighlightConfig(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{highlightPrice=d.optInt("coinPrice",1000);if(d.optBoolean("free",false))highlightPrice=0;});}public void onError(String e){}});
        Button send=small("Send"); send.setTextSize(9.5f); send.setOnClickListener(v->{if(listenOnly){Toast.makeText(this,"Muted • listen and gift only",Toast.LENGTH_SHORT).show();return;}String m=commentInput.getText().toString().trim(); if(m.isEmpty())return; BackendClient.Callback cb=new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{commentInput.setText("");highlightSelected=false;highlight.setBackground(null);refresh();});}public void onError(String e){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_SHORT).show());}};if(highlightSelected)BackendClient.liveHighlightComment(token(),hostId,m,cb);else BackendClient.liveComment(token(),hostId,m,cb);});
        TextView mic=t("🎙",17,Color.WHITE,true); mic.setGravity(Gravity.CENTER); mic.setBackground(gradient(new int[]{Color.rgb(22,68,187),Color.rgb(67,42,214)},Color.rgb(42,232,255),18)); mic.setOnClickListener(v->toggleMic());
        TextView join=t(host?"End":"Join",11,Color.WHITE,true); join.setGravity(Gravity.CENTER); join.setBackground(gradient(new int[]{Color.rgb(110,37,224),Color.rgb(242,45,206)},Color.rgb(255,132,245),18)); join.setOnClickListener(v->{if(host)confirmEndLive();else if(listenOnly)Toast.makeText(this,"Muted • listen and gift only",Toast.LENGTH_SHORT).show();else BackendClient.liveSpeakRequest(token(),hostId,new ToastCb("Join request sent"));});
        LinearLayout.LayoutParams cip=new LinearLayout.LayoutParams(0,dp(38),1); cip.rightMargin=dp(4); sendRow.addView(commentBox,cip);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(dp(58),dp(38)); sp.rightMargin=dp(4); sendRow.addView(send,sp);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(dp(48),dp(38)); mp.rightMargin=dp(4); sendRow.addView(mic,mp);
        sendRow.addView(join,new LinearLayout.LayoutParams(dp(70),dp(38)));
        LinearLayout.LayoutParams srp=new LinearLayout.LayoutParams(-1,dp(44)); srp.topMargin=dp(4); srp.bottomMargin=dp(2); root.addView(sendRow,srp);
        
        setContentView(page);
    }

    private void addControls(LinearLayout root){
        LinearLayout bottom=row(); bottom.setGravity(Gravity.CENTER_VERTICAL);
        String[] labels=host?new String[]{"🎙","➕","🪑","📌","↗","⚙"}:new String[]{"✋","➕","💬","📩","↗","⚙"};
        for(int i=0;i<labels.length;i++){final int idx=i;TextView v=t(labels[i],16,Color.WHITE,true);v.setGravity(Gravity.CENTER);v.setBackground(bg(Color.argb(185,12,27,72),Color.rgb(80,92,190),18));v.setOnClickListener(x->handleCompactControl(idx));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(40),1);lp.setMargins(dp(2),0,dp(2),0);bottom.addView(v,lp);}
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(42)); bp.topMargin=dp(3); root.addView(bottom,bp);
    }

    private void handleCompactControl(int i){
        if(host){if(i==0)toggleMic();else if(i==1)showAudienceList();else if(i==2)Toast.makeText(this,"Tap a sofa to lock/unlock or manage speaker",Toast.LENGTH_SHORT).show();else if(i==3)editPinned();else if(i==4)shareRoom();else if(i==5)showHostRoomMenu();}
        else{if(i==0)BackendClient.liveSpeakRequest(token(),hostId,new ToastCb("Request sent"));else if(i==1)BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));else if(i==2)Toast.makeText(this,"Live chat is above",Toast.LENGTH_SHORT).show();else if(i==3)Toast.makeText(this,"Open Inbox",Toast.LENGTH_SHORT).show();else if(i==4)shareRoom();else Toast.makeText(this,"More",Toast.LENGTH_SHORT).show();}
    }

    private void showHostRoomMenu(){new AlertDialog.Builder(this).setTitle("Host Room Controls").setItems(new String[]{"Theme","Live Name / Caption","Pinned announcement","End Live"},(d,w)->{if(w==0)chooseTheme();else if(w==1)editRoomInfo();else if(w==2)editPinned();else confirmEndLive();}).show();}

    private void handleControl(int i){
        if(host){
            if(i==0) toggleMic(); else if(i==2) Toast.makeText(this,"Tap any sofa to lock/unlock or manage speaker",Toast.LENGTH_SHORT).show();
            else if(i==3) editPinned(); else if(i==4) chooseTheme(); else if(i==5) shareRoom(); else if(i==6) showReaction(); else if(i==7) editRoomInfo();
            else Toast.makeText(this,"Host control ready",Toast.LENGTH_SHORT).show();
        } else {
            if(i==0) toggleMic(); else if(i==1) BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));
            else if(i==3) showReaction(); else if(i==5) shareRoom(); else Toast.makeText(this,"Live control",Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleMic(){localMicOn=!localMicOn;BackendClient.liveParticipantState(token(),hostId,localMicOn,false,networkQuality(),new ToastCb(localMicOn?"Mic on":"Mic muted"));}

    private void editPinned(){EditText e=new EditText(this);e.setHint("Pinned announcement");new AlertDialog.Builder(this).setTitle("Pinned message").setView(e).setPositiveButton("Save",(d,w)->BackendClient.liveRoomConfig(token(),null,null,e.getText().toString().trim(),null,new ToastCb("Pinned message updated"))).setNegativeButton("Cancel",null).show();}
    private void editRoomInfo(){LinearLayout b=col();EditText t1=new EditText(this);t1.setHint("Live Name");t1.setText(currentLiveName);EditText t2=new EditText(this);t2.setHint("Caption");t2.setText(roomTopic.getText());b.addView(t1);b.addView(t2);TextView note=t("Live Name: 24 ঘণ্টায় ১বার ফ্রি • আগে বদলালে 5,000 Coin. ID কখনো বদলাবে না।",10,Color.DKGRAY,false);b.addView(note);new AlertDialog.Builder(this).setTitle("Live Name & Caption").setView(b).setPositiveButton("Save",(d,w)->BackendClient.liveRoomConfig(token(),t1.getText().toString(),t2.getText().toString(),null,null,new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,"Live info updated",Toast.LENGTH_SHORT).show();refresh();});}public void onError(String e){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_LONG).show());}})).setNegativeButton("Cancel",null).show();}
    private void editCaptionOnly(){final EditText e=new EditText(this);e.setHint("Caption");e.setSingleLine(true);e.setText(roomTopic.getText());new AlertDialog.Builder(this).setTitle("Edit Caption").setView(e).setPositiveButton("Save",(d,w)->BackendClient.liveRoomConfig(token(),null,e.getText().toString(),null,null,new ToastCb("Caption updated"))).setNegativeButton("Cancel",null).show();}

    private void chooseTheme(){BackendClient.liveThemes(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("themes");if(a==null||a.length()==0){Toast.makeText(AudioLiveRoomActivity.this,"No enabled themes",Toast.LENGTH_SHORT).show();return;}String[] names=new String[a.length()];String[] keys=new String[a.length()];for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);names[i]=x==null?"Theme":x.optString("name","Theme");keys[i]=x==null?"GUITAR_BLUE":x.optString("theme_key","GUITAR_BLUE");}new AlertDialog.Builder(AudioLiveRoomActivity.this).setTitle("Live Theme").setItems(names,(q,which)->BackendClient.liveRoomConfig(token(),null,null,null,keys[which],new ToastCb("Theme changed"))).show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}

    private void shareRoom(){BackendClient.liveShare(token(),hostId,new Silent()); Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,"Join my MY SHOP Audio Live • Host ID "+hostId);startActivity(Intent.createChooser(send,"Share Live"));}

    private void showReaction(){
        if(commentsList==null)return;
        TextView r=t("❤️",28,Color.WHITE,true);
        r.setGravity(Gravity.CENTER);
        commentsList.addView(r,0,new LinearLayout.LayoutParams(-1,dp(42)));
        r.setAlpha(.2f);
        r.setTranslationY(dp(20));
        r.animate().alpha(1f).translationY(0).setDuration(220).withEndAction(() -> {
            r.animate().alpha(0f).translationY(-dp(20)).setDuration(650).withEndAction(() -> commentsList.removeView(r)).start();
        }).start();
    }

    private void showUserModeration(JSONObject u){
        String uid=u.optString("user_id","");if(uid.isEmpty()||uid.equals(hostId))return;
        String[] actions=host?new String[]{"📞 Invite to Call","Kick from Live","Mute • listen/gift only","Unmute","Block from this Live","Add as Room Admin","Remove Room Admin"}:new String[]{"Mute • listen/gift only","Unmute"};
        new AlertDialog.Builder(this).setTitle(u.optString("full_name","User")+" • ID "+uid).setItems(actions,(d,w)->{if(host&&w==0){inviteToCall(u);return;}int idx=host?w-1:w;String a=host?new String[]{"KICK","MUTE","UNMUTE","BLOCK","ADD_ROOM_ADMIN","REMOVE_ROOM_ADMIN"}[idx]:(idx==0?"MUTE":"UNMUTE");BackendClient.liveModeration(token(),hostId,uid,a,new ToastCb("Moderation updated"));}).setNegativeButton("Close",null).show();
    }

    private void showGiftPanel(){
        BackendClient.liveGifts(token(),new BackendClient.Callback(){
            public void onSuccess(JSONObject o){runOnUiThread(()->openGiftChart(o));}
            public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}
        });
    }
    private void openGiftChart(JSONObject o){
        final JSONArray gifts=o.optJSONArray("gifts")==null?new JSONArray():o.optJSONArray("gifts");
        LinearLayout box=col();box.setPadding(dp(10),dp(6),dp(10),dp(6));
        TextView balance=t("🪙 Coin  "+o.optLong("coinBalance",0)+"      🟡 Gold Coin  "+o.optLong("goldBalance",0),12,Color.rgb(35,40,65),true);box.addView(balance,new LinearLayout.LayoutParams(-1,dp(40)));
        LinearLayout tabs=row();Button coin=small("Coin Gifts"),gold=small("Gold Coin Gifts");tabs.addView(coin,new LinearLayout.LayoutParams(0,dp(42),1));tabs.addView(gold,new LinearLayout.LayoutParams(0,dp(42),1));box.addView(tabs);
        LinearLayout list=col();ScrollView sc=new ScrollView(this);sc.addView(list);box.addView(sc,new LinearLayout.LayoutParams(-1,dp(300)));
        final String[] selected={"COIN"};
        Runnable render=()->{list.removeAllViews();for(int i=0;i<gifts.length();i++){JSONObject g=gifts.optJSONObject(i);if(g==null||!selected[0].equals(g.optString("currency")))continue;LinearLayout r=row();r.setPadding(dp(6),dp(4),dp(6),dp(4));TextView nm=t(("GOLD".equals(selected[0])?"🟡 ":"🪙 ")+g.optString("name","Gift")+"  •  "+g.optInt("price",1),11,Color.rgb(25,30,60),true);r.addView(nm,new LinearLayout.LayoutParams(0,dp(40),1));Button send=small("Send");long id=g.optLong("id");send.setOnClickListener(v->BackendClient.liveGiftSend(token(),hostId,hostId,id,new ToastCb("Gift sent")));r.addView(send,new LinearLayout.LayoutParams(dp(72),dp(40)));list.addView(r,new LinearLayout.LayoutParams(-1,dp(48)));}};
        coin.setOnClickListener(v->{selected[0]="COIN";render.run();});gold.setOnClickListener(v->{selected[0]="GOLD";render.run();});render.run();
        new AlertDialog.Builder(this).setTitle("🎁 Send a Gift").setView(box).setNegativeButton("Close",null).show();
    }

    private void renderLocalSkeleton(){renderHost(null);renderAudience(null,0);renderSpecialGuest(null);renderSeats(null);}

    private void refresh(){BackendClient.liveRoomState(token(),hostId,new BackendClient.Callback(){@Override public void onSuccess(JSONObject d){runOnUiThread(()->{syncState.setText("● LIVE • Synced • "+networkQuality());render(d);});}@Override public void onError(String m){runOnUiThread(()->{syncState.setText("● LIVE • Weak network • Reconnecting…");if(seats.getChildCount()==0)renderLocalSkeleton();});}});}

    private void render(JSONObject d){
        int vc=d.optInt("viewerCount",0),peak=d.optInt("peakViewers",0); currentViewerCount=vc; viewers.setText("");
        myRole=d.optString("myRole",host?"HOST":"AUDIENCE"); roomAdmin=d.optBoolean("myRoomAdmin",false); String sanction=d.optString("mySanction","NONE"); listenOnly="MUTED".equals(sanction); if("BLOCKED".equals(sanction)||"KICKED".equals(sanction)){Toast.makeText(this,"You were removed from this live",Toast.LENGTH_SHORT).show();finish();return;} status.setText((host?"👑 Host":(roomAdmin?"🛡 Admin":"🎧 "+myRole))+" • ID "+SessionManager.getUserId(this)+(listenOnly?" • Listen only":""));
        specialGuestId=d.optString("specialGuestId",""); shareCount=d.optInt("shareCount",0); shareView.setText("↗ "+shareCount);
        currentLiveName=d.optString("title","Host"); roomTitle.setText("🎙 "+currentLiveName); String cap=d.optString("topic","").trim(); roomTopic.setText(cap.isEmpty()?"Add caption":cap); if(reactView!=null)reactView.setText("❤️\n"+compact(d.optLong("reactCount",0)));
        String pin=d.optString("pinnedMessage",""); pinnedView.setText(pin.isEmpty()?"📌 No pinned announcement":"📌 "+pin);
        long parsed=parseServerTime(d.optString("startedAt","")); if(parsed>0)startedAtMs=parsed;
        lockedSeats.clear();JSONArray locks=d.optJSONArray("lockedSeats");if(locks!=null)for(int i=0;i<locks.length();i++)lockedSeats.add(locks.optInt(i));
        JSONArray a=d.optJSONArray("seats"); renderHost(findSeat(a,1));renderAudience(d.optJSONArray("viewerProfiles"),vc);renderSpecialGuest(findUser(a,specialGuestId));renderSeats(a);
        currentRequests=d.optJSONArray("requests")==null?new JSONArray():d.optJSONArray("requests");
        if(host&&requests!=null){renderRequests(currentRequests);notifyHostOfNewRequest(currentRequests);}
        JSONArray highlights=d.optJSONArray("highlightComments");renderComments(d.optJSONArray("comments"),d.optJSONArray("events"),highlights);renderHighlightComments(highlights);
        if(!host)showIncomingInvite(d.optJSONObject("incomingInvite"));
        JSONObject theme=d.optJSONObject("theme"); if(theme!=null){String bg=theme.optString("background_url","");if(!bg.trim().isEmpty())loadImage(wallpaper,bg);}
    }

    private void renderHost(JSONObject x){
        hostArea.removeAllViews();
        LinearLayout hostBlock=row(); hostBlock.setGravity(Gravity.CENTER_VERTICAL); hostBlock.setPadding(0,0,dp(3),0); hostBlock.setBackgroundColor(Color.TRANSPARENT);
        boolean speaking=x!=null&&x.optInt("speaking",0)==1;
        FrameLayout av=circleAvatar(x==null?"":x.optString("avatar_url",""),dp(40),speaking);
        hostBlock.addView(av,new LinearLayout.LayoutParams(dp(40),dp(40)));
        String name=currentLiveName==null||currentLiveName.trim().isEmpty()?(x==null?"Host":x.optString("full_name","Host")):currentLiveName; String id=x==null?hostId:x.optString("user_id",hostId); int lv=x==null?0:x.optInt("level",0);
        long coin=x==null?0:x.optLong("coin_balance",0),gold=x==null?0:x.optLong("gold_balance",0);
        TextView info=t("👑 "+name+"\nID "+id+" • LV."+lv+"\n🪙 "+coin+"  🟡 "+gold,9.2f,Color.WHITE,true);
        info.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,dp(58),1); ip.leftMargin=dp(5); hostBlock.addView(info,ip);
        hostArea.addView(hostBlock,new LinearLayout.LayoutParams(dp(120),dp(62)));
        if(audienceRow.getParent()!=null)((android.view.ViewGroup)audienceRow.getParent()).removeView(audienceRow);
        hostArea.addView(audienceRow,new LinearLayout.LayoutParams(0,dp(62),1));
    }

    private void renderAudience(JSONArray a,int total){
        currentViewerProfiles=a==null?new JSONArray():a; currentViewerCount=total; audienceRow.removeAllViews(); audienceRow.setPadding(dp(2),0,0,0);
        int shown=0;
        for(int i=0;i<currentViewerProfiles.length()&&shown<6;i++){
            JSONObject u=currentViewerProfiles.optJSONObject(i); if(u==null)continue; shown++;
            LinearLayout cell=col(); cell.setGravity(Gravity.CENTER);
            FrameLayout av=circleAvatar(u.optString("avatar_url",""),dp(25),false); String uid=u.optString("user_id","");
            av.setOnClickListener(v->{if(host||roomAdmin)showUserModeration(u);else Toast.makeText(this,u.optString("full_name","User")+" • ID "+uid+" • LV."+u.optInt("level",0),Toast.LENGTH_SHORT).show();});
            cell.addView(av,new LinearLayout.LayoutParams(dp(25),dp(25)));
            TextView nm=t(shortName(u.optString("full_name","User")),7.2f,Color.WHITE,true); nm.setGravity(Gravity.CENTER); cell.addView(nm,new LinearLayout.LayoutParams(-1,dp(14)));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(54),1); cp.setMargins(dp(1),0,dp(1),0); audienceRow.addView(cell,cp);
        }
        while(shown<6){
            LinearLayout blank=col(); blank.setGravity(Gravity.CENTER); TextView dot=t("",1,Color.TRANSPARENT,false); blank.addView(dot,new LinearLayout.LayoutParams(dp(25),dp(25))); audienceRow.addView(blank,new LinearLayout.LayoutParams(0,dp(54),1)); shown++;
        }
        LinearLayout moreCell=col(); moreCell.setGravity(Gravity.CENTER);
        TextView more=t(">",17,Color.WHITE,true); more.setGravity(Gravity.CENTER); more.setBackground(bg(Color.argb(165,20,30,82),Color.rgb(94,111,223),16)); more.setOnClickListener(v->showAudienceList());
        moreCell.addView(more,new LinearLayout.LayoutParams(dp(29),dp(29)));
        audienceRow.addView(moreCell,new LinearLayout.LayoutParams(dp(31),dp(54)));
    }

    private String compact(long n){if(n>=1000000)return (n%1000000==0?(n/1000000)+"M":String.format(Locale.US,"%.1fM",n/1000000f));if(n>=1000)return (n%1000==0?(n/1000)+"K":String.format(Locale.US,"%.1fK",n/1000f));return String.valueOf(n);}

    private String shortName(String n){ if(n==null||n.trim().isEmpty())return "User"; n=n.trim(); int sp=n.indexOf(' '); if(sp>0)n=n.substring(0,sp); return n.length()>7?n.substring(0,7):n; }

    private void showAudienceList(){
        int n=currentViewerProfiles==null?0:currentViewerProfiles.length();
        if(n==0){Toast.makeText(this,"No active users right now",Toast.LENGTH_SHORT).show();return;}
        String[] items=new String[n]; for(int i=0;i<n;i++){JSONObject u=currentViewerProfiles.optJSONObject(i); items[i]=u==null?"User":u.optString("full_name","User")+"  •  ID "+u.optString("user_id","")+"  •  LV."+u.optInt("level",0);}
        new AlertDialog.Builder(this).setTitle("Active Users • "+currentViewerCount).setItems(items,(d,w)->{JSONObject u=currentViewerProfiles.optJSONObject(w);if(u==null)return;if(host)showUserModeration(u);else Toast.makeText(this,items[w],Toast.LENGTH_SHORT).show();}).setNegativeButton("Close",null).show();
    }

    private void inviteToCall(JSONObject u){
        if(!host||u==null)return;String uid=u.optString("user_id","");if(uid.isEmpty()||uid.equals(hostId))return;
        BackendClient.liveInvite(token(),uid,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,"Call invitation sent to "+u.optString("full_name","User"),Toast.LENGTH_SHORT).show());}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}});
    }

    private void showIncomingInvite(JSONObject inv){
        if(inv==null||host||inviteDialogOpen)return;String key=inv.optString("host_id",hostId)+"|"+inv.optString("session_id","")+"|"+inv.optString("created_at","");if(key.equals(lastInviteNotice))return;lastInviteNotice=key;inviteDialogOpen=true;
        String hostName=inv.optString("host_name","Host");
        new AlertDialog.Builder(this).setTitle("📞 Live Call Invitation").setMessage(hostName+" আপনাকে Live Call-এ speaker হিসেবে আমন্ত্রণ জানিয়েছে। Accept করলে available seat-এ উঠবেন।")
                .setPositiveButton("ACCEPT",(d,w)->{inviteDialogOpen=false;BackendClient.liveInviteAction(token(),hostId,true,new ToastCb("Invitation accepted • joining call"));})
                .setNegativeButton("DECLINE",(d,w)->{inviteDialogOpen=false;BackendClient.liveInviteAction(token(),hostId,false,new ToastCb("Invitation declined"));})
                .setOnCancelListener(d->inviteDialogOpen=false).show();
    }

    private void notifyHostOfNewRequest(JSONArray q){
        if(!host||q==null||q.length()==0||requestDialogOpen)return;JSONObject x=q.optJSONObject(0);if(x==null)return;String key=x.optString("user_id","")+"|"+x.optString("created_at","");if(key.equals(lastRequestNotice))return;lastRequestNotice=key;requestDialogOpen=true;
        String uid=x.optString("user_id","");String nm=x.optString("full_name","User");
        new AlertDialog.Builder(this).setTitle("✋ Join Request").setMessage(nm+" • ID "+uid+"\nLive Call-এ উঠতে চায়।")
                .setPositiveButton("ACCEPT",(d,w)->{requestDialogOpen=false;BackendClient.liveRequestAction(token(),uid,true,new ToastCb("Speaker accepted"));})
                .setNegativeButton("DECLINE",(d,w)->{requestDialogOpen=false;BackendClient.liveRequestAction(token(),uid,false,new ToastCb("Request declined"));})
                .setOnCancelListener(d->requestDialogOpen=false).show();
    }

    private void showJoinRequestsDialog(){
        if(!host)return;if(currentRequests==null||currentRequests.length()==0){Toast.makeText(this,"No pending join requests",Toast.LENGTH_SHORT).show();return;}
        int n=currentRequests.length();String[] items=new String[n];for(int i=0;i<n;i++){JSONObject x=currentRequests.optJSONObject(i);items[i]=x==null?"User":x.optString("full_name","User")+" • ID "+x.optString("user_id","");}
        new AlertDialog.Builder(this).setTitle("Join Requests • "+n).setItems(items,(d,w)->{JSONObject x=currentRequests.optJSONObject(w);if(x==null)return;String uid=x.optString("user_id","");new AlertDialog.Builder(this).setTitle(items[w]).setItems(new String[]{"Accept to Call","Decline"},(dd,which)->BackendClient.liveRequestAction(token(),uid,which==0,new ToastCb(which==0?"Speaker accepted":"Request declined"))).show();}).setNegativeButton("Close",null).show();
    }

    private void renderSpecialGuest(JSONObject x){
        specialArea.removeAllViews();
        FrameLayout stage=new FrameLayout(this);
        durationView=t("00:00",9.5f,Color.rgb(255,220,244),true); durationView.setGravity(Gravity.CENTER); durationView.setBackground(bg(Color.argb(170,55,18,75),Color.rgb(236,73,179),13));
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(dp(54),dp(26),Gravity.LEFT|Gravity.TOP); tp.leftMargin=dp(2); tp.topMargin=dp(5); stage.addView(durationView,tp);
        boolean speaking=x!=null&&x.optInt("speaking",0)==1;
        FrameLayout guestFrame=new FrameLayout(this); GoldenGuestHalo halo=new GoldenGuestHalo(this); guestFrame.addView(halo,new FrameLayout.LayoutParams(-1,-1));
        FrameLayout av=circleAvatar(x==null?"":x.optString("avatar_url",""),dp(70),speaking); FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(dp(70),dp(70),Gravity.CENTER); guestFrame.addView(av,ap);
        ObjectAnimator pulseX=ObjectAnimator.ofFloat(halo,"scaleX",1f,1.055f,1f); pulseX.setDuration(1650); pulseX.setRepeatCount(ValueAnimator.INFINITE); pulseX.start();
        ObjectAnimator pulseY=ObjectAnimator.ofFloat(halo,"scaleY",1f,1.055f,1f); pulseY.setDuration(1650); pulseY.setRepeatCount(ValueAnimator.INFINITE); pulseY.start();
        ObjectAnimator glow=ObjectAnimator.ofFloat(halo,"alpha",.78f,1f,.78f); glow.setDuration(1400); glow.setRepeatCount(ValueAnimator.INFINITE); glow.start();
        FrameLayout.LayoutParams gp=new FrameLayout.LayoutParams(dp(112),dp(94),Gravity.CENTER); stage.addView(guestFrame,gp);
        specialArea.addView(stage,new LinearLayout.LayoutParams(-1,dp(96)));
        if(host&&x!=null)guestFrame.setOnClickListener(v->clearSpecialGuest()); else guestFrame.setOnClickListener(null);
    }

    private void renderSeats(JSONArray a){seats.removeAllViews();int n=2;int[] counts={6,5};for(int rr=0;rr<counts.length;rr++){LinearLayout r=row();for(int c=0;c<counts[rr]&&n<=12;c++,n++){JSONObject found=findSeat(a,n);boolean locked=lockedSeats.contains(n);LinearLayout tile=seatTile(n,found,locked);final int seatNo=n;final JSONObject clicked=found;tile.setOnClickListener(v->{if(host){if(clicked!=null)showSpeakerActions(clicked);else toggleSeatLock(seatNo,locked);}});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(62),1);lp.setMargins(dp(1),dp(1),dp(1),dp(1));r.addView(tile,lp);}seats.addView(r,new LinearLayout.LayoutParams(-1,dp(64)));}}

    private LinearLayout seatTile(int seatNo,JSONObject x,boolean locked){
        LinearLayout v=col(); v.setGravity(Gravity.CENTER); v.setPadding(dp(1),dp(1),dp(1),dp(1)); v.setBackgroundColor(Color.TRANSPARENT);
        boolean occupied=x!=null,speaking=occupied&&x.optInt("speaking",0)==1;
        if(occupied){
            FrameLayout av=circleAvatar(x.optString("avatar_url",""),dp(42),speaking); v.addView(av,new LinearLayout.LayoutParams(dp(42),dp(42)));
            TextView nm=t(shortName(x.optString("full_name","User")),7.5f,Color.WHITE,true); nm.setGravity(Gravity.CENTER); v.addView(nm,new LinearLayout.LayoutParams(-1,dp(14)));
        }else{
            FrameLayout stage=new FrameLayout(this); stage.addView(sofaIcon(locked),new FrameLayout.LayoutParams(dp(52),dp(44),Gravity.CENTER)); v.addView(stage,new LinearLayout.LayoutParams(dp(56),dp(55)));
        }
        return v;
    }

    private View sofaIcon(boolean locked){FrameLayout f=new FrameLayout(this);int gold=locked?Color.rgb(105,88,55):Color.rgb(235,166,32);int light=locked?Color.rgb(135,118,78):Color.rgb(255,221,91);View back=new View(this);back.setBackground(bg(gold,light,10));FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(44),dp(28),Gravity.TOP|Gravity.CENTER_HORIZONTAL);f.addView(back,bp);View left=new View(this);left.setBackground(bg(gold,light,8));FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(12),dp(28),Gravity.LEFT|Gravity.BOTTOM);f.addView(left,lp);View right=new View(this);right.setBackground(bg(gold,light,8));FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(dp(12),dp(28),Gravity.RIGHT|Gravity.BOTTOM);f.addView(right,rp);View base=new View(this);base.setBackground(bg(light,Color.rgb(255,235,130),8));FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(44),dp(15),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);f.addView(base,sp);return f;}

    private void toggleSeatLock(int seatNo,boolean locked){BackendClient.liveSeatLock(token(),seatNo,!locked,new ToastCb(!locked?"Seat locked":"Seat unlocked"));}


    private void renderHighlightComments(JSONArray arr){
        if(arr==null||arr.length()==0)return; JSONObject c=arr.optJSONObject(arr.length()-1); if(c==null)return; long hid=c.optLong("id",0); if(hid<=lastHighlightId)return; lastHighlightId=hid; final TextView banner=t("✨ "+c.optString("full_name","User")+": "+c.optString("message",""),11,Color.WHITE,true); banner.setPadding(dp(14),0,dp(14),0); banner.setGravity(Gravity.CENTER_VERTICAL); banner.setBackground(gradient(new int[]{Color.argb(235,76,34,145),Color.argb(235,184,54,156)},Color.rgb(255,209,92),18)); addContentView(banner,new android.view.ViewGroup.LayoutParams(dp(310),dp(42))); banner.setX(getResources().getDisplayMetrics().widthPixels); banner.setY(getResources().getDisplayMetrics().heightPixels*0.46f); banner.animate().translationX(-getResources().getDisplayMetrics().widthPixels-dp(340)).setDuration(6500).withEndAction(()->((android.view.ViewGroup)banner.getParent()).removeView(banner)).start();
    }

    private void renderRequests(JSONArray q){requests.removeAllViews();if(q==null||q.length()==0){requests.addView(t("No pending requests",11,Color.LTGRAY,false));return;}for(int i=0;i<q.length();i++){JSONObject x=q.optJSONObject(i);if(x==null)continue;LinearLayout rr=row();rr.setGravity(Gravity.CENTER_VERTICAL);TextView nm=t(x.optString("full_name","User")+" • ID "+x.optString("user_id"),10.5f,Color.WHITE,true);rr.addView(nm,new LinearLayout.LayoutParams(0,dp(36),1));Button ok=small("Accept"),no=small("Decline");String id=x.optString("user_id");ok.setOnClickListener(v->BackendClient.liveRequestAction(token(),id,true,new ToastCb("Speaker accepted")));no.setOnClickListener(v->BackendClient.liveRequestAction(token(),id,false,new ToastCb("Request declined")));rr.addView(ok,new LinearLayout.LayoutParams(dp(72),dp(38)));rr.addView(no,new LinearLayout.LayoutParams(dp(74),dp(38)));requests.addView(rr);}}

    private void renderComments(JSONArray comments,JSONArray events,JSONArray highlights){
        commentsList.removeAllViews();
        if(events!=null){int start=Math.max(0,events.length()-3);for(int i=start;i<events.length();i++){JSONObject e=events.optJSONObject(i);if(e==null)continue;TextView n=t("• "+e.optString("full_name","Someone")+" "+e.optString("message",""),9.5f,Color.rgb(167,190,244),false);n.setPadding(dp(4),dp(2),dp(4),dp(2));commentsList.addView(n);}}
        if(highlights!=null){for(int i=0;i<highlights.length();i++){JSONObject h=highlights.optJSONObject(i);if(h==null)continue;LinearLayout row=col();row.setPadding(dp(8),dp(5),dp(8),dp(5));row.setBackground(gradient(new int[]{Color.argb(150,92,38,151),Color.argb(150,170,54,148)},Color.rgb(255,209,92),12));TextView who=t("✨ "+h.optString("full_name","User")+" • HIGHLIGHT",10.2f,Color.rgb(255,226,120),true);TextView msg=t(h.optString("message",""),11.2f,Color.WHITE,false);row.addView(who);row.addView(msg);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(4);commentsList.addView(row,rp);}}
        if(comments==null||comments.length()==0){commentsList.addView(t("Comments will appear here",10.5f,Color.rgb(170,178,205),false));return;}
        for(int i=0;i<comments.length();i++){JSONObject c=comments.optJSONObject(i);if(c==null)continue;LinearLayout row=col();row.setPadding(dp(7),dp(4),dp(7),dp(4));TextView who=t(c.optString("full_name","User")+"   LV."+Math.max(0,c.optInt("level",0)),10.5f,Color.rgb(107,214,255),true);TextView msg=t(c.optString("message",""),11.2f,Color.WHITE,false);row.addView(who);row.addView(msg);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(2);commentsList.addView(row,rp);}
    }


    private void showSpeakerActions(JSONObject x){final String uid=x.optString("user_id","");final boolean special=uid.equals(specialGuestId);String[] actions=special?new String[]{"Remove from Special Guest","Remove Speaker from Seat"}:new String[]{"Make Special Guest","Remove Speaker from Seat"};new AlertDialog.Builder(this).setTitle(x.optString("full_name","Speaker")).setItems(actions,(d,which)->{if(which==0)BackendClient.liveSpecialGuest(token(),uid,special,new ToastCb(special?"Special Guest removed":"Special Guest selected"));else BackendClient.liveSpeakerRemove(token(),uid,new ToastCb("Speaker removed"));}).show();}
    private void clearSpecialGuest(){if(!host||specialGuestId.isEmpty())return;new AlertDialog.Builder(this).setTitle("Special Guest").setMessage("Return this guest to a normal speaker seat?").setPositiveButton("Remove Spotlight",(d,w)->BackendClient.liveSpecialGuest(token(),specialGuestId,true,new ToastCb("Spotlight cleared"))).setNegativeButton("Cancel",null).show();}

    private void confirmLeaveLive(){new AlertDialog.Builder(this).setTitle("Leave Live?").setMessage("Leave this live room?").setPositiveButton("Leave",(d,w)->finish()).setNegativeButton("Stay",null).show();}
    private void confirmEndLive(){new AlertDialog.Builder(this).setTitle("End Live?").setMessage("This will end the room for everyone.").setPositiveButton("End Live",(d,w)->endHostLive()).setNegativeButton("Cancel",null).show();}
    private void endHostLive(){BackendClient.setLivePresence(token(),false,new BackendClient.Callback(){public void onSuccess(JSONObject d){hostStarted=false;BackendClient.liveSummary(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject s){runOnUiThread(()->showSummary(s.optJSONObject("summary")));}public void onError(String m){runOnUiThread(()->finish());}});}public void onError(String m){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,"Live closed locally • server sync will retry",Toast.LENGTH_LONG).show();finish();});}});}
    private void showSummary(JSONObject s){if(s==null){finish();return;}long dur=s.optLong("duration_seconds",0);LinearLayout box=col();box.setPadding(dp(18),dp(14),dp(18),dp(14));box.setBackground(bg(Color.rgb(15,23,63),Color.rgb(134,75,235),20));TextView h=t("🎙 LIVE SUMMARY",18,Color.WHITE,true);h.setGravity(Gravity.CENTER);box.addView(h,new LinearLayout.LayoutParams(-1,dp(42)));TextView sub=t("MY SHOP Audio Live",10,Color.rgb(185,199,238),false);sub.setGravity(Gravity.CENTER);box.addView(sub,new LinearLayout.LayoutParams(-1,dp(26)));String[] labels={"Duration","Peak Viewers","Total Listeners","Shares","Reacts","Earned Reward"};String[] vals={hhmmss(dur),String.valueOf(s.optInt("peak_viewers",0)),String.valueOf(s.optInt("total_listeners",0)),String.valueOf(s.optInt("share_count",0)),compact(s.optLong("react_count",0)),s.optLong("react_reward_coin",0)+" Coin"};for(int i=0;i<labels.length;i++){LinearLayout r=row();r.setPadding(dp(10),dp(5),dp(10),dp(5));r.setBackground(bg(Color.argb(125,35,46,94),Color.argb(120,112,126,213),12));TextView l=t(labels[i],11,Color.rgb(203,211,241),false);TextView v=t(vals[i],12,Color.WHITE,true);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);r.addView(l,new LinearLayout.LayoutParams(0,dp(34),1));r.addView(v,new LinearLayout.LayoutParams(0,dp(34),1));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(44));rp.bottomMargin=dp(5);box.addView(r,rp);}new AlertDialog.Builder(this).setView(box).setPositiveButton("DONE",(d,w)->finish()).setCancelable(false).show();}

    private JSONObject findSeat(JSONArray a,int seatNo){if(a==null)return null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&x.optInt("seat_no")==seatNo)return x;}return null;}
    private JSONObject findUser(JSONArray a,String userId){if(a==null||userId==null||userId.isEmpty())return null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&userId.equals(x.optString("user_id")))return x;}return null;}

    private FrameLayout circleAvatar(String url,int size,boolean speaking){FrameLayout frame=new FrameLayout(this);int stroke=speaking?Color.rgb(42,235,255):Color.rgb(163,93,255);frame.setBackground(bg(Color.argb(190,25,33,82),stroke,size/2));ImageView v=new ImageView(this);v.setImageResource(android.R.drawable.sym_def_app_icon);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(bg(Color.rgb(34,45,105),stroke,size/2));v.setClipToOutline(true);int pad=dp(3);FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,-1);ip.setMargins(pad,pad,pad,pad);frame.addView(v,ip);if(url!=null&&!url.trim().isEmpty())loadImage(v,url);if(speaking){ObjectAnimator a=ObjectAnimator.ofFloat(frame,"alpha",1f,.72f,1f);a.setDuration(850);a.setRepeatCount(ValueAnimator.INFINITE);a.start();}return frame;}
    private void loadImage(ImageView v,String u){new Thread(()->{try{Bitmap b=BitmapFactory.decodeStream(new URL(u).openStream());if(b!=null)runOnUiThread(()->v.setImageBitmap(b));}catch(Exception ignored){}}).start();}

    private String networkQuality(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);NetworkInfo n=cm==null?null:cm.getActiveNetworkInfo();if(n==null||!n.isConnected())return "OFFLINE";return n.getType()==ConnectivityManager.TYPE_WIFI?"GOOD":"FAIR";}catch(Exception e){return "GOOD";}}
    private String signal(String q){q=q==null?"GOOD":q.toUpperCase();if("WEAK".equals(q)||"OFFLINE".equals(q))return "▂";if("FAIR".equals(q))return "▂▄";return "▂▄▆";}
    private long parseServerTime(String s){if(s==null||s.trim().isEmpty())return 0;String[] patterns={"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd'T'HH:mm:ss.SSS'Z'","yyyy-MM-dd'T'HH:mm:ss'Z'"};for(String p:patterns){try{SimpleDateFormat f=new SimpleDateFormat(p,Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));Date d=f.parse(s);if(d!=null)return d.getTime();}catch(Exception ignored){}}return 0;}
    private String hhmm(long sec){long h=sec/3600,m=(sec%3600)/60;return String.format(Locale.US,"%02d:%02d",h,m);}
    private String hhmmss(long sec){long h=sec/3600,m=(sec%3600)/60,s=sec%60;return String.format(Locale.US,"%02d:%02d:%02d",h,m,s);}
    private String token(){return SessionManager.getToken(this);}

    @Override public void onBackPressed(){ if(host) confirmEndLive(); else confirmLeaveLive(); }
    @Override protected void onDestroy(){handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);if(host){if(hostStarted)BackendClient.setLivePresence(token(),false,new Silent());}else{BackendClient.liveLeaveSeat(token(),hostId,new Silent());BackendClient.liveViewer(token(),hostId,false,new Silent());}super.onDestroy();}


    private class GoldenGuestHalo extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF oval=new RectF();
        GoldenGuestHalo(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f;float r=Math.min(w,h)*.36f;
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2.2f));p.setColor(Color.rgb(255,194,47));p.setShadowLayer(dp(8),0,0,Color.rgb(255,139,22));c.drawCircle(cx,cy,r,p);p.clearShadowLayer();
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(255,190,42));
            for(int side=-1;side<=1;side+=2){for(int i=0;i<7;i++){float y=cy-r*.72f+i*r*.24f;float x=cx+side*(r+dp(5)+i*dp(.7f));c.save();c.rotate(side*(-32+i*5),x,y);oval.set(x-dp(5),y-dp(2.3f),x+dp(5),y+dp(2.3f));c.drawOval(oval,p);c.restore();}}
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(2));p.setColor(Color.rgb(255,221,97));oval.set(cx-r-dp(10),cy+r*.66f,cx+r+dp(10),cy+r+dp(12));c.drawArc(oval,188,164,false,p);
        }
    }

    class ToastCb implements BackendClient.Callback{String ok;ToastCb(String s){ok=s;}public void onSuccess(JSONObject d){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,ok,Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}}
    static class Silent implements BackendClient.Callback{public void onSuccess(JSONObject d){}public void onError(String m){}}

    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private Button btn(String s){Button b=new Button(this);b.setAllCaps(false);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setBackground(bg(Color.rgb(76,45,205),Color.rgb(217,46,255),18));return b;}
    private Button small(String s){Button b=btn(s);b.setTextSize(9.5f);b.setMinWidth(0);b.setMinimumWidth(0);return b;}
    private TextView t(String s,float z,int c,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private GradientDrawable bg(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private GradientDrawable gradient(int[] colors,int stroke,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private int dp(float x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
}
