package com.myshop.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;

/** V-297 premium, keyboard-safe one-password Admin Locker / Gate. */
public class AdminGateActivity extends AppCompatActivity {
    private final int NAVY=Color.rgb(15,25,62), PURPLE=Color.rgb(99,48,211), BLUE=Color.rgb(39,94,228), MUTED=Color.rgb(101,112,143), WHITE=Color.WHITE;
    private final String[] questions={
            "আপনার পছন্দের ব্যক্তির নাম কী?",
            "আপনার জন্মস্থানের জেলা কী?",
            "আপনার পছন্দের রং কী?",
            "আপনার পছন্দের শিক্ষকের নাম কী?",
            "নিজের Security Question লিখুন"
    };

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        if(!SessionManager.isAdmin(this)){finish();return;}
        showLoading();
        BackendClient.adminGateStatus(token(),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                if(d.optBoolean("unlocked",false)){SessionManager.setAdminGateUnlocked(true);openHub();}
                else if(d.optBoolean("configured",false)) showUnlock(d.optString("securityQuestion",""));
                else showSetup();
            });}
            public void onError(String e){runOnUiThread(()->{toast("Admin security status পাওয়া যায়নি। আবার চেষ্টা করুন।");showSetup();});}
        });
    }

    private void showLoading(){
        LinearLayout card=card(); card.addView(header("🔐","MY SHOP ADMIN SECURITY","নিরাপদ Admin session যাচাই হচ্ছে"));
        TextView t=label("নিরাপত্তা যাচাই…",12,MUTED,false);t.setGravity(Gravity.CENTER);card.addView(t,lp(-1,dp(66)));
        setContentView(screen(card));
    }

    private void showSetup(){
        LinearLayout card=card();
        card.addView(header("🛡","অ্যাডমিন লকার তৈরি করুন","একবার সেট করুন • এরপর শুধু Password দিয়ে Unlock"));
        card.addView(help("অ্যাডমিন পাসওয়ার্ড","কমপক্ষে ৬ অক্ষরের Password দিন। এই Password ছাড়া Admin Panel খুলবে না।"));
        EditText pass=passwordField("অ্যাডমিন পাসওয়ার্ড"); card.addView(passwordRow(pass));
        card.addView(help("নিরাপত্তা প্রশ্ন","Password ভুলে গেলে পরিচয় যাচাই করতে এই প্রশ্ন ব্যবহার হবে।"));
        Spinner spinner=new Spinner(this); spinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,questions)); spinner.setBackground(round(WHITE,Color.rgb(216,222,240),14)); card.addView(spinner,lp(-1,dp(52)));
        EditText custom=textField("নিজের Security Question লিখুন"); custom.setVisibility(View.GONE); card.addView(custom,lp(-1,dp(52)));
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){custom.setVisibility(pos==questions.length-1?View.VISIBLE:View.GONE);}
            public void onNothingSelected(android.widget.AdapterView<?> p){}
        });
        card.addView(help("নিরাপত্তা উত্তর","আপনার জানা ছোট কিন্তু মনে রাখা সহজ উত্তর দিন।"));
        EditText answer=textField("নিরাপত্তা উত্তর"); card.addView(answer,lp(-1,dp(52)));
        TextView create=primary("🔐  CREATE ADMIN LOCKER");
        create.setOnClickListener(v->{
            hideKeyboard(); String ps=pass.getText().toString(); int qi=spinner.getSelectedItemPosition();
            String qs=qi==questions.length-1?custom.getText().toString().trim():questions[Math.max(0,qi)]; String as=answer.getText().toString().trim();
            if(ps.length()<6){pass.setError("কমপক্ষে ৬ অক্ষর দিন");return;} if(qs.isEmpty()){custom.setError("Security Question দিন");return;} if(as.length()<2){answer.setError("Security Answer দিন");return;}
            create.setEnabled(false);create.setText("Locker তৈরি হচ্ছে…");
            BackendClient.adminGateSetup(token(),ps,qs,as,new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->{toast("Admin Locker সফলভাবে তৈরি হয়েছে");showUnlock(qs);});}
                public void onError(String e){runOnUiThread(()->{create.setEnabled(true);create.setText("🔐  CREATE ADMIN LOCKER");toast(e);});}
            });
        });
        card.addView(create,top(lp(-1,dp(54)),dp(14)));
        setContentView(screen(card));
    }

    private void showUnlock(String question){
        LinearLayout card=card();
        card.addView(header("🔐","MY SHOP অ্যাডমিন গেট","আপনার Admin Locker Unlock করুন"));
        TextView chip=label("এক পাসওয়ার্ড • সম্পূর্ণ অ্যাডমিন সেশন",10,WHITE,true); chip.setGravity(Gravity.CENTER); chip.setBackground(round(PURPLE,PURPLE,16)); card.addView(chip,lp(-1,dp(34)));
        TextView info=label("একবার Unlock হলে Gift, Coin, Live, Finance ও অন্যান্য Admin module-এ একই session চলবে।",10.5f,MUTED,false);info.setPadding(dp(8),dp(10),dp(8),dp(10));card.addView(info,lp(-1,-2));
        card.addView(help("অ্যাডমিন পাসওয়ার্ড","আপনার সেট করা Admin Password লিখুন।"));
        EditText pass=passwordField("অ্যাডমিন পাসওয়ার্ড"); card.addView(passwordRow(pass));
        TextView unlock=primary("🔓  UNLOCK ADMIN PANEL");
        unlock.setOnClickListener(v->{String p=pass.getText().toString();if(p.isEmpty()){pass.setError("Password দিন");return;}hideKeyboard();unlock.setEnabled(false);unlock.setText("যাচাই হচ্ছে…");BackendClient.adminGateUnlock(token(),p,new BackendClient.Callback(){public void onSuccess(JSONObject d){SessionManager.setAdminGateUnlocked(true);openHub();}public void onError(String e){runOnUiThread(()->{unlock.setEnabled(true);unlock.setText("🔓  UNLOCK ADMIN PANEL");toast(e);});}});});
        card.addView(unlock,top(lp(-1,dp(54)),dp(12)));
        TextView forgot=label("Password ভুলে গেছেন?",11,PURPLE,true);forgot.setGravity(Gravity.CENTER);forgot.setBackground(round(Color.rgb(248,246,255),Color.rgb(214,204,241),14));forgot.setOnClickListener(v->showQuestionRecovery(question));card.addView(forgot,top(lp(-1,dp(48)),dp(8)));
        setContentView(screen(card));
    }

    private LinearLayout passwordRow(EditText pass){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setBackground(round(WHITE,Color.rgb(211,219,239),14));
        pass.setBackgroundColor(Color.TRANSPARENT);row.addView(pass,new LinearLayout.LayoutParams(0,dp(52),1));
        TextView eye=label("👁",18,NAVY,true);eye.setGravity(Gravity.CENTER);eye.setContentDescription("পাসওয়ার্ড দেখুন বা লুকান");eye.setOnClickListener(v->{int pos=Math.max(0,pass.getSelectionStart());boolean hidden=(pass.getInputType()&InputType.TYPE_TEXT_VARIATION_PASSWORD)!=0;pass.setInputType(InputType.TYPE_CLASS_TEXT|(hidden?InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD:InputType.TYPE_TEXT_VARIATION_PASSWORD));pass.setSelection(Math.min(pos,pass.length()));eye.setText(hidden?"🙈":"👁");});row.addView(eye,new LinearLayout.LayoutParams(dp(52),dp(52)));
        return row;
    }

    private void showQuestionRecovery(String question){
        LinearLayout b=dialogBox();b.addView(help("নিরাপত্তা প্রশ্ন",question.isEmpty()?"আপনার সেট করা Security Question-এর উত্তর দিন।":question));EditText ans=textField("নিরাপত্তা উত্তর"),np=passwordField("নতুন Admin Password");b.addView(ans,lp(-1,dp(50)));b.addView(np,top(lp(-1,dp(50)),dp(8)));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("অ্যাডমিন লকার পুনরুদ্ধার").setView(b).setNegativeButton("বাতিল",null).setNeutralButton("Answer-ও ভুলে গেছি",null).setPositiveButton("পাসওয়ার্ড রিসেট",null).create();
        dlg.setOnShowListener(x->{dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(np.getText().length()<6){np.setError("কমপক্ষে ৬ অক্ষর");return;}BackendClient.adminGateRecoverQuestion(token(),ans.getText().toString(),np.getText().toString(),new Cb("Password reset হয়েছে",()->{dlg.dismiss();showUnlock(question);}));});dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{dlg.dismiss();showOwnerRecovery(question);});});dlg.show();
    }

    private void showOwnerRecovery(String question){
        LinearLayout b=dialogBox();b.addView(help("মালিকানা পুনরুদ্ধার","৩টি গোপন Admin ID-এর মধ্যে অন্তত ২টি সঠিক দিন। ID-গুলো screen-এ দেখানো হবে না।"));EditText a=textField("অ্যাডমিন আইডি ১"),c=textField("অ্যাডমিন আইডি ২"),d=textField("অ্যাডমিন আইডি ৩ • ঐচ্ছিক"),np=passwordField("নতুন Admin Password");b.addView(a);b.addView(c);b.addView(d);b.addView(np);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("মালিকানা পুনরুদ্ধার").setView(b).setNegativeButton("বাতিল",null).setPositiveButton("পাসওয়ার্ড রিসেট",null).create();dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(np.getText().length()<6){np.setError("কমপক্ষে ৬ অক্ষর");return;}BackendClient.adminGateRecoverIds(token(),a.getText().toString(),c.getText().toString(),d.getText().toString(),np.getText().toString(),new Cb("Password reset হয়েছে",()->{dlg.dismiss();showUnlock(question);}));}));dlg.show();
    }

    private View screen(LinearLayout card){
        FrameLayout outer=new FrameLayout(this);GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(242,246,255),Color.rgb(250,247,255),Color.rgb(246,250,255)});outer.setBackground(bg);
        ScrollView sv=new ScrollView(this);sv.setFillViewport(false);sv.setClipToPadding(false);sv.setPadding(dp(14),dp(22),dp(14),dp(22));sv.addView(card,new ScrollView.LayoutParams(-1,-2));outer.addView(sv,new FrameLayout.LayoutParams(-1,-1));return outer;
    }
    private LinearLayout card(){LinearLayout c=dialogBox();c.setPadding(dp(18),dp(18),dp(18),dp(20));c.setBackground(round(WHITE,Color.rgb(224,228,242),22));c.setElevation(dp(5));return c;}
    private View header(String icon,String title,String sub){LinearLayout h=dialogBox();TextView i=label(icon,26,PURPLE,true);i.setGravity(Gravity.CENTER);h.addView(i,lp(-1,dp(38)));TextView t=label(title,20,NAVY,true);t.setGravity(Gravity.CENTER);h.addView(t,lp(-1,dp(34)));TextView s=label(sub,10.5f,MUTED,false);s.setGravity(Gravity.CENTER);h.addView(s,lp(-1,dp(32)));return h;}
    private TextView help(String title,String desc){TextView t=label(title+"\n"+desc,10.5f,MUTED,false);t.setPadding(dp(10),dp(9),dp(10),dp(8));t.setBackground(round(Color.rgb(248,250,255),Color.rgb(232,235,246),12));return t;}
    private EditText textField(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextSize(12);e.setTextColor(NAVY);e.setHintTextColor(Color.rgb(143,151,176));e.setPadding(dp(13),0,dp(13),0);e.setBackground(round(WHITE,Color.rgb(211,219,239),14));return e;}
    private EditText passwordField(String hint){EditText e=textField(hint);e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);return e;}
    private TextView primary(String s){TextView t=label(s,12,WHITE,true);t.setGravity(Gravity.CENTER);t.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{BLUE,PURPLE}));((GradientDrawable)t.getBackground()).setCornerRadius(dp(16));return t;}
    private LinearLayout dialogBox(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private TextView label(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private GradientDrawable round(int fill,int stroke,int r){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(r));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=m;return p;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private String token(){return SessionManager.getToken(this);}private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void hideKeyboard(){try{InputMethodManager im=(InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);View v=getCurrentFocus();if(v!=null)im.hideSoftInputFromWindow(v.getWindowToken(),0);}catch(Exception ignored){}}
    private void openHub(){runOnUiThread(()->{startActivity(new android.content.Intent(this,AdminHubActivity.class).putExtra("gate_passed",true));finish();});}
    private class Cb implements BackendClient.Callback{private final String ok;private final Runnable done;Cb(String ok,Runnable done){this.ok=ok;this.done=done;}public void onSuccess(JSONObject d){runOnUiThread(()->{toast(ok);done.run();});}public void onError(String e){runOnUiThread(()->toast(e));}}
}
