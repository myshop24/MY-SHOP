# MY SHOP Developer Handoff — V-297

## Base / current version
- Base: V-296
- Current source: V-297
- Android versionCode: 297
- Android versionName: 2.9.297
- Worker: V-297 / 2.9.297

## Scope
V-297 follows `V-297_MASTER_32_CHECKLIST.md`: the user's 31-point Master Implementation List plus #32 Live Join Request + Host Invite two-way speaker flow.

## Completed in this checkpoint
- Preserved V-296 D1/R2/API/user identity/balance/live foundations.
- Bottom Navigation safe-area correction: one system inset + small safe gap, no double lift.
- Premium Admin Gate/Locker redesign and one-password admin-session behavior retained.
- Audio Live wallpaper upload from Gallery/File, preview, R2-backed upload path, replace/remove, save/publish and color picker UI.
- Bengali-first updated Admin management UI/field descriptions on touched V-297 screens.
- Live comments/session scoping, highlight handling, timer/end-summary presentation refinements.
- Profile Timeline/media/share/Edit Profile/Settings refinements, including in-app media viewer/player.
- Startup/App Open Ad size guidance: 1080x1920 9:16 recommended, 720x1280 minimum, preview/crop warning/no stretch.
- Added two-way Live speaker promotion:
  - Audience Join Request -> Host Accept -> next free speaker seat.
  - Host selects active audience user -> Invite -> user Accept -> next free speaker seat.
  - User Decline stays Audience.
  - Pending invite expiry, duplicate/already-seated checks, sanction checks, active-live checks and session scoping.
- Live seat allocation supports 12 total seats: Seat 1 Host, Seats 2–12 speakers.
- Added migration: `backend/worker/migrations/0014_v297_live_invites_12seat.sql`.

## Validation completed here
- Worker JS syntax: PASS.
- Android Manifest/resource XML parse: PASS (87 XML files + Manifest).
- Version markers: PASS (V-297 / 2.9.297 / versionCode 297).

## Known limitation — do not misrepresent
The V-296 base does not include Agora RTC SDK/audio-engine implementation. V-297 implements the authoritative backend/UI request-invite-seat state flow, but actual real-time voice transport is not verified/complete until an RTC SDK + secure token/channel integration is added and device-tested.

## Pending release checks
1. Run the existing GitHub Actions Android build/signing workflow; local full compile is unavailable because this environment has no Gradle/Android SDK runtime.
2. Apply D1 migration 0014 and deploy Worker V-297.
3. Verify D1/R2 health and V-297 Worker identity.
4. Test Admin Locker create/unlock/recovery and multiple admin modules in one session.
5. Test bottom nav on gesture and 3-button navigation devices.
6. Test startup image/video ad ratio warning, 1–4 second duration and fail-open behavior.
7. Test Live A -> end -> Live B isolation for comments/highlights/requests/invites.
8. Test Join Request -> Host Accept -> seat and Host Invite -> User Accept/Decline -> seat/audience state.
9. Test all 11 guest speaker seats (2–12), seat-full behavior, locked seat behavior and reconnect.
10. Complete Play Console pre-launch/Data safety/privacy checks before production release.
