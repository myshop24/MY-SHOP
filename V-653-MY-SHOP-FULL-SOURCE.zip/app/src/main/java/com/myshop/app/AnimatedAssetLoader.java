package com.myshop.app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.widget.ImageView;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** V-246 lightweight animated WebP/GIF loader. No heavy animation is bundled in the APK. */
public final class AnimatedAssetLoader {
  private static final ExecutorService IO=Executors.newCachedThreadPool();
  private AnimatedAssetLoader(){}
  private static final class AvatarMovieDrawable extends Drawable{final android.graphics.Movie movie;final boolean play;final long epoch=android.os.SystemClock.uptimeMillis();AvatarMovieDrawable(android.graphics.Movie m,boolean p){movie=m;play=p;}public void draw(android.graphics.Canvas c){android.graphics.Rect b=getBounds();float scale=Math.min(b.width()/(float)movie.width(),b.height()/(float)movie.height());int save=c.save();c.translate(b.left+(b.width()-movie.width()*scale)/2,b.top+(b.height()-movie.height()*scale)/2);c.scale(scale,scale);movie.setTime(play?(int)((android.os.SystemClock.uptimeMillis()-epoch)%Math.max(1,movie.duration())):0);movie.draw(c,0,0);c.restoreToCount(save);if(play)scheduleSelf(()->invalidateSelf(),android.os.SystemClock.uptimeMillis()+63);}public void setAlpha(int a){}public void setColorFilter(android.graphics.ColorFilter f){}public int getOpacity(){return android.graphics.PixelFormat.TRANSLUCENT;}}

  public static void load(ImageView view,String url){ load(view,url,true); }
  public static void load(ImageView view,String url,boolean autoplay){
    if(view==null||url==null||url.trim().isEmpty())return;
    if(url.startsWith("asset://themes622/")&&url.matches("asset://themes622/[a-z_]+\\.webp")){final String themeUrl=url;view.setTag(themeUrl);IO.execute(()->{try(java.io.InputStream in=view.getContext().getAssets().open(themeUrl.substring(8))){Bitmap bitmap=BitmapFactory.decodeStream(in);if(bitmap!=null)view.post(()->{if(themeUrl.equals(view.getTag()))view.setImageBitmap(bitmap);});}catch(Exception ignored){}});return;}
if(url.startsWith("myshop-flower653://")){view.setTag(url.trim());view.setImageDrawable(new FlowerGift653(view.getContext(),url,autoplay));return;}if(url.startsWith("myshop-gift620://")){view.setTag(url.trim());view.setImageDrawable(new GiftArt620(view.getContext(),url,autoplay));return;}if(url.startsWith("myshop-gift619://")){view.setTag(url.trim());view.setImageDrawable(new GiftArt619(view.getContext(),url,autoplay));return;}if(url.startsWith("myshop-gift613://")){view.setImageDrawable(new GiftArt613(view.getContext(),url,autoplay));return;} if(!autoplay){CachedImages.load(view,url);return;} final boolean play=autoplay&&!false;final String key=url.trim(); view.setTag(key);
    if(key.startsWith("asset://")){IO.execute(()->{try{if(Build.VERSION.SDK_INT>=28){Drawable d=ImageDecoder.decodeDrawable(ImageDecoder.createSource(view.getContext().getApplicationContext().getAssets(),key.substring(8)));view.post(()->{if(key.equals(view.getTag())){view.setImageDrawable(d);if(d instanceof AnimatedImageDrawable){((AnimatedImageDrawable)d).setRepeatCount(AnimatedImageDrawable.REPEAT_INFINITE);if(play)((AnimatedImageDrawable)d).start();}}});}else{try(InputStream in=view.getContext().getAssets().open(key.substring(8).replace(".webp",".gif"))){android.graphics.Movie movie=android.graphics.Movie.decodeStream(in);if(movie!=null)view.post(()->{if(key.equals(view.getTag())){view.setLayerType(android.view.View.LAYER_TYPE_SOFTWARE,null);view.setImageDrawable(new AvatarMovieDrawable(movie,play));}});}}}catch(Exception|OutOfMemoryError e){android.util.Log.w("MYSHOP_AVATAR","Asset unavailable");}});return;}
    IO.execute(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(key).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(12000);c.setUseCaches(true);try(InputStream in=c.getInputStream()){
      if(Build.VERSION.SDK_INT>=28){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n,total=0;while((n=in.read(b))>0&&total<9*1024*1024){out.write(b,0,n);total+=n;}Drawable d=ImageDecoder.decodeDrawable(ImageDecoder.createSource(ByteBuffer.wrap(out.toByteArray())));view.post(()->{if(key.equals(view.getTag())){view.setImageDrawable(d);if(d instanceof AnimatedImageDrawable){((AnimatedImageDrawable)d).setRepeatCount(AnimatedImageDrawable.REPEAT_INFINITE);if(play)((AnimatedImageDrawable)d).start();else ((AnimatedImageDrawable)d).stop();}}});}
      else{Bitmap bm=BitmapFactory.decodeStream(in);if(bm!=null)view.post(()->{if(key.equals(view.getTag()))view.setImageBitmap(bm);});}
    }}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}});
  }
}
