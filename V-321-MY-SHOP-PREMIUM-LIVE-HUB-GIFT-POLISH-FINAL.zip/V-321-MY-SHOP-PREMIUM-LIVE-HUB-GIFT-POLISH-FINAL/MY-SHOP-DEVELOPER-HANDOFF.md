# MY SHOP Developer Handoff — V-321

## Completed checkpoint
V-321 version-identity correction over the V-320 Premium Live Hub & Gift Catalog Polish source.

## Completed
- Corrected canonical source build identity to `MY SHOP V-321`.
- Corrected Android versionCode/versionName to `321` / `2.9.321`.
- Corrected all active Worker health version markers to `2.9.321` / `V-321`.
- Updated the permanent GitHub workflow display label to V-321 while preserving its dynamic highest-V source lock and safety guards.
- Preserved the V-320 full-screen Premium Live Streaming Hub.
- Preserved the established 12-seat 6+6 guest-seat structure, placement, role behavior, and seat logic.
- Preserved Gift Coin / Gold Coin catalogs, catalog animation behavior, single-SEND path, D1/R2 bindings, and existing backend routes.

## Last checkpoint
Source identity consistency, Worker JavaScript syntax, Android XML parsing, critical Live/Gift regression markers, D1/R2 binding markers, and ZIP integrity were checked locally. Full Android SDK compile/sign is still delegated to GitHub Actions because this container does not include the Android build environment/Gradle wrapper required for the release build.

## Next QA
1. Upload only the new highest-version `V-321-...zip` to the GitHub repository root.
2. Confirm `Extract and verify exact source identity` passes with V-321.
3. Complete GitHub Actions Android build/signing.
4. Test Live Hub on-device and perform a two-device Live room regression test.
5. Test Coin + Gold Coin gift selection, SEND, balance debit, animation/sound, and remote event delivery.
6. Verify production Worker `/health` reports V-321 after deployment.
