# MY SHOP V-321 — Version Identity Correction

## Purpose
V-321 corrects the release identity mismatch found in the V-320 source package while preserving the V-320 implementation and behavior.

## Corrected identity
- `SOURCE_BUILD_ID.txt`: `MY SHOP V-321`
- `SOURCE_VERSION_NAME.txt`: `V-321-MY-SHOP-PREMIUM-LIVE-HUB-GIFT-POLISH-FINAL`
- Android `versionCode`: `321`
- Android `versionName`: `2.9.321`
- Worker health markers: `2.9.321` / `V-321`
- GitHub Actions workflow display label: `AUTO-BUILD V-321`

## Regression preservation
- V-320 Premium Live Streaming Hub preserved.
- Existing 12-seat 6+6 Live Room guest-seat structure and seat logic preserved.
- Gift Coin and Gold Coin catalog behavior preserved.
- Existing gift animation/send path preserved.
- Cloudflare D1 database and R2 media bindings preserved.
- Existing backend routes and MY SHOP backend URL preserved.
- No new permission or digital-goods payment path added by this identity correction.

## Build environment
- compileSdk: 36
- targetSdk: 36
- Final Android compile/sign remains a GitHub Actions gate.
