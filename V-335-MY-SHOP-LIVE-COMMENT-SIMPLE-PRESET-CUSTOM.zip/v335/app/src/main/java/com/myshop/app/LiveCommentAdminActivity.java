package com.myshop.app;

import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.animation.AlphaAnimation;
import android.widget.*;
import org.json.*;
import java.util.*;

public class LiveCommentAdminActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(7,18,43), CARD=Color.rgb(14,31,69), BORDER=Color.rgb(58,90,165), MUTED=Color.rgb(157,174,207);
    private LinearLayout root;
    private StyleEditor globalEditor, presetEditor, customEditor;
    private Spinner badgeSpinner, genderSpinner, presetNoSpinner, assignModeSpinner, assignPresetSpinner;
    private EditText userIdInput;
    private TextView userResult;
    private JSONObject loaded=new JSONObject();
    private String foundUserId="";

    @Override protected void onCreate(Bundle b){super.onCreate(b);build();load();}

    private void build(){
        ScrollView sv=new ScrollView(this);root=col();root.setPadding(dp(14),dp(16),dp(14),dp(28));root.setBackgroundColor(BG);
        root.addView(t("💬 Live Comments & Banners",22,true));
        TextView sub=t("Simple controls • Preview/Test before Save • Changes apply only after Save/Publish",12,false);sub.setTextColor(MUTED);root.addView(sub);

        sectionTitle("1  Global Style (All Users)","New users and anyone without an assigned badge/custom style will use this design.");
        globalEditor=new StyleEditor("Global Comment Preview"); root.addView(globalEditor.view);
        Button saveGlobal=primary("Save & Publish Global Style"); root.addView(saveGlobal); saveGlobal.setOnClickListener(v->saveGlobal());

        sectionTitle("2  Ready-made Badge Presets","VIP / VVIP / ROYAL have Male + Female, 5 styles each. KING has Male 5. QUEEN has Female 5.");
        LinearLayout pick=row();
        badgeSpinner=spinner(new String[]{"VIP","VVIP","ROYAL","KING","QUEEN"});genderSpinner=spinner(new String[]{"MALE","FEMALE"});presetNoSpinner=spinner(new String[]{"1","2","3","4","5"});
        pick.addView(badgeSpinner,new LinearLayout.LayoutParams(0,dp(52),1));pick.addView(genderSpinner,new LinearLayout.LayoutParams(0,dp(52),1));pick.addView(presetNoSpinner,new LinearLayout.LayoutParams(0,dp(52),.65f));root.addView(pick);
        badgeSpinner.setOnItemSelectedListener(simpleListener(()->{syncGender();loadSelectedPreset();}));
        genderSpinner.setOnItemSelectedListener(simpleListener(this::loadSelectedPreset));
        presetNoSpinner.setOnItemSelectedListener(simpleListener(this::loadSelectedPreset));
        presetEditor=new StyleEditor("Badge Preset Preview");root.addView(presetEditor.view);
        Button savePreset=primary("Save This Badge Preset");root.addView(savePreset);savePreset.setOnClickListener(v->savePreset());

        sectionTitle("3  Search & Assign User","Search MY SHOP User ID first. The user name/ID will appear before assignment.");
        LinearLayout sr=row();userIdInput=in("MY SHOP User ID");Button search=primary("Search");sr.addView(userIdInput,new LinearLayout.LayoutParams(0,dp(52),1));sr.addView(search,new LinearLayout.LayoutParams(dp(112),dp(52)));root.addView(sr);
        userResult=t("No user selected",13,true);userResult.setTextColor(MUTED);root.addView(userResult);search.setOnClickListener(v->searchUser());

        assignModeSpinner=spinner(new String[]{"Assign Ready-made Preset","Create Custom Style for this User"});root.addView(label("Assignment Type"));root.addView(assignModeSpinner);
        assignPresetSpinner=spinner(buildPresetKeys());root.addView(label("Ready-made Preset"));root.addView(assignPresetSpinner);
        customEditor=new StyleEditor("Selected User Live Preview");root.addView(customEditor.view);customEditor.view.setVisibility(View.GONE);
        assignModeSpinner.setOnItemSelectedListener(simpleListener(()->customEditor.view.setVisibility(assignModeSpinner.getSelectedItemPosition()==1?View.VISIBLE:View.GONE)));
        Button assign=primary("Save & Assign to Selected User");root.addView(assign);assign.setOnClickListener(v->assignUser());

        TextView foot=t("Priority: User Custom Style  >  Assigned Badge Preset  >  Global All-User Style",11,true);foot.setTextColor(Color.rgb(111,210,255));foot.setPadding(dp(4),dp(18),dp(4),dp(4));root.addView(foot);
        sv.addView(root);setContentView(sv);
    }

    private void sectionTitle(String title,String desc){TextView h=t(title,18,true);h.setPadding(dp(4),dp(22),dp(4),dp(2));root.addView(h);TextView d=t(desc,11,false);d.setTextColor(MUTED);root.addView(d);}

    private void load(){BackendClient.liveCommentUi(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{loaded=o;JSONObject g=o.optJSONObject("globalStyle");if(g!=null)globalEditor.fromJson(g);loadSelectedPreset();});}public void onError(String m){toast(m);}});}

    private void saveGlobal(){JSONObject s=globalEditor.toJson();BackendClient.adminLiveCommentGlobalSave(SessionManager.getToken(this),s,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{toast("Global comment style published");load();});}public void onError(String m){toast(m);}});}

    private void syncGender(){String badge=String.valueOf(badgeSpinner.getSelectedItem());if("KING".equals(badge)){genderSpinner.setSelection(0);genderSpinner.setEnabled(false);}else if("QUEEN".equals(badge)){genderSpinner.setSelection(1);genderSpinner.setEnabled(false);}else genderSpinner.setEnabled(true);}

    private String selectedPresetKey(){return String.valueOf(badgeSpinner.getSelectedItem())+"-"+String.valueOf(genderSpinner.getSelectedItem())+"-"+String.valueOf(presetNoSpinner.getSelectedItem());}

    private void loadSelectedPreset(){if(presetEditor==null||loaded==null)return;String key=selectedPresetKey();JSONArray a=loaded.optJSONArray("presets");JSONObject found=null;if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&key.equalsIgnoreCase(x.optString("presetKey"))){found=x;break;}}if(found!=null)presetEditor.fromJson(found);else presetEditor.fromJson(defaultPreset(key));}

    private void savePreset(){String key=selectedPresetKey();JSONObject s=presetEditor.toJson();try{s.put("presetKey",key);s.put("badge",badgeSpinner.getSelectedItem().toString());s.put("gender",genderSpinner.getSelectedItem().toString());s.put("presetNo",Integer.parseInt(presetNoSpinner.getSelectedItem().toString()));}catch(Exception ignored){}BackendClient.adminLiveCommentPresetSave(SessionManager.getToken(this),s,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{toast(key+" saved");load();});}public void onError(String m){toast(m);}});}

    private void searchUser(){String uid=userIdInput.getText().toString().trim();if(uid.isEmpty()){toast("Enter User ID");return;}userResult.setText("Searching…");BackendClient.userProfile(SessionManager.getToken(this),uid,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONObject p=d.optJSONObject("profile");if(p==null){foundUserId="";userResult.setText("User not found");return;}foundUserId=p.optString("userId",uid);String name=p.optString("name","MY SHOP User");int lv=p.optInt("level",0);userResult.setText("✓ "+name+"   •   ID "+foundUserId+"   •   LV."+lv);customEditor.previewName=name+"  •  LV."+lv;customEditor.updatePreview();});}public void onError(String m){runOnUiThread(()->{foundUserId="";userResult.setText("User not found");});}});}

    private void assignUser(){if(foundUserId.isEmpty()){toast("Search and select a user first");return;}boolean custom=assignModeSpinner.getSelectedItemPosition()==1;String preset=custom?"":String.valueOf(assignPresetSpinner.getSelectedItem());JSONObject style=custom?customEditor.toJson():new JSONObject();BackendClient.adminLiveCommentAssignmentSave(SessionManager.getToken(this),foundUserId,preset,style,custom,true,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->toast("Style assigned to "+foundUserId));}public void onError(String m){toast(m);}});}

    private String[] buildPresetKeys(){ArrayList<String> x=new ArrayList<>();for(String b:new String[]{"VIP","VVIP","ROYAL"})for(String g:new String[]{"MALE","FEMALE"})for(int i=1;i<=5;i++)x.add(b+"-"+g+"-"+i);for(int i=1;i<=5;i++)x.add("KING-MALE-"+i);for(int i=1;i<=5;i++)x.add("QUEEN-FEMALE-"+i);return x.toArray(new String[0]);}

    private JSONObject defaultPreset(String key){JSONObject o=new JSONObject();try{String bg="#512DA8",text="#FFFFFF",border="#E040FB",glow="#FF40F8";if(key.startsWith("VVIP")){bg="#8E145F";border="#FF5DB1";glow="#FF4AA8";}else if(key.startsWith("ROYAL")){bg="#7A5510";border="#FFD45A";glow="#FFD45A";}else if(key.startsWith("KING")){bg="#083A8C";border="#42A5FF";glow="#42A5FF";}else if(key.startsWith("QUEEN")){bg="#9C145F";border="#FF63C4";glow="#FF63C4";}if(key.contains("FEMALE")){bg=lightenHex(bg);}
        o.put("backgroundColor",bg).put("textColor",text).put("nameColor","#FFD54F").put("levelColor","#40D9FF").put("borderColor",border).put("fontSize",17).put("fontWeight","BOLD").put("borderWidth",2).put("cornerRadius",16).put("opacity",100).put("borderGlow",true).put("borderGlowColor",glow).put("borderGlowIntensity",65).put("backgroundGlow",false).put("animation",true).put("animationType","PULSE").put("animationSpeed",55);
    }catch(Exception ignored){}return o;}

    private String lightenHex(String s){try{int c=Color.parseColor(s);int r=Math.min(255,Color.red(c)+28),g=Math.min(255,Color.green(c)+18),b=Math.min(255,Color.blue(c)+24);return String.format("#%02X%02X%02X",r,g,b);}catch(Exception e){return s;}}

    private class StyleEditor{
        LinearLayout view;EditText bgColor,textColor,nameColor,levelColor,borderColor,glowColor,testText;TextView fontValue,widthValue,radiusValue,opacityValue,glowValue,speedValue,preview;CheckBox borderGlow,bgGlow,animation;Spinner weight,animType;SeekBar opacity,glowIntensity,animSpeed;int font=16,width=1,radius=14;String previewName="Sample User  •  LV.5";
        StyleEditor(String title){view=col();view.setPadding(dp(12),dp(10),dp(12),dp(12));view.setBackground(round(CARD,BORDER,16));view.addView(t(title,14,true));
            LinearLayout colors=row();bgColor=hex("#111E3D","Background");textColor=hex("#FFFFFF","Text");colors.addView(bgColor,new LinearLayout.LayoutParams(0,dp(54),1));colors.addView(textColor,new LinearLayout.LayoutParams(0,dp(54),1));view.addView(colors);
            LinearLayout colors2=row();nameColor=hex("#FFFFFF","Name");levelColor=hex("#FFD54F","Level");colors2.addView(nameColor,new LinearLayout.LayoutParams(0,dp(54),1));colors2.addView(levelColor,new LinearLayout.LayoutParams(0,dp(54),1));view.addView(colors2);
            LinearLayout border=row();borderColor=hex("#435EA8","Border");glowColor=hex("#A855F7","Glow");border.addView(borderColor,new LinearLayout.LayoutParams(0,dp(54),1));border.addView(glowColor,new LinearLayout.LayoutParams(0,dp(54),1));view.addView(border);
            LinearLayout fs=row();fs.addView(label("Font"),new LinearLayout.LayoutParams(0,dp(44),1));Button fm=mini("−"),fp=mini("+");fontValue=t("16",15,true);fontValue.setGravity(17);fs.addView(fm,new LinearLayout.LayoutParams(dp(44),dp(42)));fs.addView(fontValue,new LinearLayout.LayoutParams(dp(46),dp(42)));fs.addView(fp,new LinearLayout.LayoutParams(dp(44),dp(42)));view.addView(fs);fm.setOnClickListener(v->{font=Math.max(12,font-1);refreshValues();});fp.setOnClickListener(v->{font=Math.min(28,font+1);refreshValues();});
            weight=spinner(new String[]{"NORMAL","BOLD"});view.addView(label("Font Weight"));view.addView(weight);
            LinearLayout wr=row();widthValue=stepper(wr,"Border",1,6,v->{width=v;updatePreview();});radiusValue=stepper(wr,"Radius",4,30,v->{radius=v;updatePreview();});view.addView(wr);
            borderGlow=new CheckBox(LiveCommentAdminActivity.this);borderGlow.setText("Border Glow");styleCheck(borderGlow);bgGlow=new CheckBox(LiveCommentAdminActivity.this);bgGlow.setText("Background Glow");styleCheck(bgGlow);animation=new CheckBox(LiveCommentAdminActivity.this);animation.setText("Animation");styleCheck(animation);LinearLayout checks=row();checks.addView(borderGlow,new LinearLayout.LayoutParams(0,-2,1));checks.addView(bgGlow,new LinearLayout.LayoutParams(0,-2,1));checks.addView(animation,new LinearLayout.LayoutParams(0,-2,1));view.addView(checks);
            view.addView(label("Glow Intensity"));glowIntensity=seek(0,100,55);glowValue=t("55%",11,true);view.addView(glowIntensity);view.addView(glowValue);
            view.addView(label("Opacity"));opacity=seek(30,100,95);opacityValue=t("95%",11,true);view.addView(opacity);view.addView(opacityValue);
            animType=spinner(new String[]{"PULSE","SOFT FADE","NONE"});view.addView(label("Animation Type"));view.addView(animType);view.addView(label("Animation Speed"));animSpeed=seek(10,100,55);speedValue=t("55",11,true);view.addView(animSpeed);view.addView(speedValue);
            testText=in("Type a test comment before saving");testText.setText("This is a sample live comment");view.addView(testText);
            preview=t("",16,false);preview.setPadding(dp(12),dp(10),dp(12),dp(10));LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2);pp.setMargins(0,dp(10),0,dp(6));view.addView(preview,pp);
            Button test=mini("▶ Test Preview / Animation");view.addView(test);test.setOnClickListener(v->{updatePreview();playAnimation();});
            TextWatcherLite w=new TextWatcherLite(this::updatePreview);for(EditText e:new EditText[]{bgColor,textColor,nameColor,levelColor,borderColor,glowColor,testText})e.addTextChangedListener(w);weight.setOnItemSelectedListener(simpleListener(this::updatePreview));animType.setOnItemSelectedListener(simpleListener(this::updatePreview));borderGlow.setOnCheckedChangeListener((b,c)->updatePreview());bgGlow.setOnCheckedChangeListener((b,c)->updatePreview());animation.setOnCheckedChangeListener((b,c)->updatePreview());
            opacity.setOnSeekBarChangeListener(seekListener(v->{opacityValue.setText(v+"%");updatePreview();}));glowIntensity.setOnSeekBarChangeListener(seekListener(v->{glowValue.setText(v+"%");updatePreview();}));animSpeed.setOnSeekBarChangeListener(seekListener(v->{speedValue.setText(String.valueOf(v));}));updatePreview();
        }
        void refreshValues(){fontValue.setText(String.valueOf(font));widthValue.setText(String.valueOf(width));radiusValue.setText(String.valueOf(radius));updatePreview();}
        JSONObject toJson(){JSONObject o=new JSONObject();try{o.put("backgroundColor",norm(bgColor,"#111E3D")).put("textColor",norm(textColor,"#FFFFFF")).put("nameColor",norm(nameColor,"#FFFFFF")).put("levelColor",norm(levelColor,"#FFD54F")).put("borderColor",norm(borderColor,"#435EA8")).put("fontSize",font).put("fontWeight",weight.getSelectedItem().toString()).put("borderWidth",width).put("cornerRadius",radius).put("opacity",opacity.getProgress()).put("borderGlow",borderGlow.isChecked()).put("borderGlowColor",norm(glowColor,"#A855F7")).put("borderGlowIntensity",glowIntensity.getProgress()).put("backgroundGlow",bgGlow.isChecked()).put("animation",animation.isChecked()).put("animationType",animType.getSelectedItem().toString()).put("animationSpeed",animSpeed.getProgress());}catch(Exception ignored){}return o;}
        void fromJson(JSONObject o){if(o==null)return;bgColor.setText(o.optString("backgroundColor","#111E3D"));textColor.setText(o.optString("textColor","#FFFFFF"));nameColor.setText(o.optString("nameColor","#FFFFFF"));levelColor.setText(o.optString("levelColor","#FFD54F"));borderColor.setText(o.optString("borderColor","#435EA8"));glowColor.setText(o.optString("borderGlowColor","#A855F7"));font=o.optInt("fontSize",16);width=o.optInt("borderWidth",1);radius=o.optInt("cornerRadius",14);opacity.setProgress(o.optInt("opacity",95));glowIntensity.setProgress(o.optInt("borderGlowIntensity",55));animSpeed.setProgress(o.optInt("animationSpeed",55));borderGlow.setChecked(o.optBoolean("borderGlow",false));bgGlow.setChecked(o.optBoolean("backgroundGlow",false));animation.setChecked(o.optBoolean("animation",false));select(weight,o.optString("fontWeight","NORMAL"));select(animType,o.optString("animationType","PULSE"));refreshValues();}
        void updatePreview(){if(preview==null)return;try{String msg=testText.getText().toString();String line=previewName+" : "+msg;android.text.SpannableString sp=new android.text.SpannableString(line);int nameEnd=previewName.indexOf("  •  LV.");if(nameEnd<0)nameEnd=previewName.length();int levelStart=Math.max(0,nameEnd);int prefixEnd=Math.min(line.length(),previewName.length()+3);sp.setSpan(new android.text.style.ForegroundColorSpan(parse(norm(nameColor,"#FFFFFF"),Color.WHITE)),0,nameEnd,android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);sp.setSpan(new android.text.style.ForegroundColorSpan(parse(norm(levelColor,"#FFD54F"),Color.YELLOW)),levelStart,prefixEnd,android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);sp.setSpan(new android.text.style.ForegroundColorSpan(parse(norm(textColor,"#FFFFFF"),Color.WHITE)),prefixEnd,line.length(),android.text.Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);preview.setText(sp);preview.setTextSize(font);preview.setTypeface(Typeface.DEFAULT,"BOLD".equals(weight.getSelectedItem())?Typeface.BOLD:Typeface.NORMAL);int fill=parse(norm(bgColor,"#111E3D"),Color.rgb(17,30,61));int op=opacity.getProgress();fill=Color.argb((int)(255*(op/100f)),Color.red(fill),Color.green(fill),Color.blue(fill));preview.setBackground(styleDrawable(fill,parse(norm(borderColor,"#435EA8"),BORDER),width,radius,borderGlow.isChecked(),parse(norm(glowColor,"#A855F7"),Color.MAGENTA),glowIntensity.getProgress()));preview.setElevation(dp(bgGlow.isChecked()?8:2));}catch(Exception ignored){}}
        void playAnimation(){if(!animation.isChecked())return;long dur=Math.max(220,1200-(animSpeed.getProgress()*8));AlphaAnimation a=new AlphaAnimation(.45f,1f);a.setDuration(dur);a.setRepeatMode(AlphaAnimation.REVERSE);a.setRepeatCount(1);preview.startAnimation(a);}
    }

    private interface IntSink{void set(int v);}private interface VoidRun{void run();}
    private TextView stepper(LinearLayout parent,String name,int min,int max,IntSink sink){LinearLayout box=col();TextView l=label(name);box.addView(l);LinearLayout r=row();Button m=mini("−"),p=mini("+");TextView val=t(String.valueOf("Border".equals(name)?1:14),13,true);val.setGravity(17);r.addView(m,new LinearLayout.LayoutParams(dp(38),dp(38)));r.addView(val,new LinearLayout.LayoutParams(dp(40),dp(38)));r.addView(p,new LinearLayout.LayoutParams(dp(38),dp(38)));box.addView(r);parent.addView(box,new LinearLayout.LayoutParams(0,-2,1));final int[] cur={"Border".equals(name)?1:14};m.setOnClickListener(v->{cur[0]=Math.max(min,cur[0]-1);val.setText(String.valueOf(cur[0]));sink.set(cur[0]);if(globalEditor!=null){} });p.setOnClickListener(v->{cur[0]=Math.min(max,cur[0]+1);val.setText(String.valueOf(cur[0]));sink.set(cur[0]);});return val;}

    private EditText hex(String value,String hint){EditText e=in(hint+" e.g. #FFFFFF");e.setText(value);return e;}
    private String norm(EditText e,String fallback){String s=e.getText().toString().trim().toUpperCase();return s.matches("#[0-9A-F]{6}")?s:fallback;}
    private int parse(String s,int fallback){try{return Color.parseColor(s);}catch(Exception e){return fallback;}}
    private android.graphics.drawable.Drawable styleDrawable(int fill,int stroke,int strokeWidth,int radius,boolean glow,int glowColor,int intensity){GradientDrawable inner=new GradientDrawable();inner.setColor(fill);inner.setCornerRadius(dp(radius));inner.setStroke(dp(Math.max(1,strokeWidth)),stroke);if(!glow)return inner;GradientDrawable outer=new GradientDrawable();outer.setColor(Color.TRANSPARENT);outer.setCornerRadius(dp(radius+3));int alpha=Math.max(30,Math.min(255,(int)(255*(intensity/100f))));int gc=Color.argb(alpha,Color.red(glowColor),Color.green(glowColor),Color.blue(glowColor));outer.setStroke(dp(Math.max(2,strokeWidth+2)),gc);android.graphics.drawable.LayerDrawable layers=new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{outer,inner});layers.setLayerInset(1,dp(3),dp(3),dp(3),dp(3));return layers;}

    private AdapterView.OnItemSelectedListener simpleListener(VoidRun r){return new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int pos,long id){r.run();}public void onNothingSelected(AdapterView<?> p){}};}
    private SeekBar.OnSeekBarChangeListener seekListener(IntSink s){return new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean u){s.set(p);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}};}
    private SeekBar seek(int min,int max,int value){SeekBar s=new SeekBar(this);if(Build.VERSION.SDK_INT>=26)s.setMin(min);s.setMax(max);s.setProgress(value);return s;}
    private void styleCheck(CheckBox c){c.setTextColor(Color.WHITE);c.setTextSize(11);}
    private void select(Spinner s,String val){for(int i=0;i<s.getCount();i++)if(String.valueOf(s.getItemAtPosition(i)).equalsIgnoreCase(val)){s.setSelection(i);break;}}
    private TextView label(String s){TextView v=t(s,11,true);v.setTextColor(MUTED);return v;}
    private Spinner spinner(String[] items){Spinner s=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,items);s.setAdapter(a);return s;}
    private TextView t(String s,float z,boolean b){TextView v=new TextView(this);v.setText(s);v.setTextColor(Color.WHITE);v.setTextSize(z);if(b)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);v.setPadding(dp(4),dp(6),dp(4),dp(6));return v;}
    private EditText in(String h){EditText e=new EditText(this);e.setHint(h);e.setHintTextColor(MUTED);e.setTextColor(Color.WHITE);e.setSingleLine();e.setPadding(dp(10),0,dp(10),0);return e;}
    private Button primary(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
    private Button mini(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setMinWidth(0);b.setMinimumWidth(0);return b;}
    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable round(int f,int st,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));g.setStroke(dp(1),st);return g;}
    private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}

    private static class TextWatcherLite implements android.text.TextWatcher{private final VoidRun r;TextWatcherLite(VoidRun r){this.r=r;}public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){r.run();}public void afterTextChanged(android.text.Editable e){}}
}
