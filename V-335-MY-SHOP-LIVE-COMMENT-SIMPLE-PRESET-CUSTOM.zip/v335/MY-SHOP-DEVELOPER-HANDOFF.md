# MY SHOP Developer Handoff — V-335

Base: V-334
Build identity: MY SHOP V-335
versionCode: 335
versionName: 2.9.335

## Completed
- Rebuilt Live Comments & Banners Admin around a simple 3-step system: Global Style, Badge Presets, Search/Assign User.
- Removed the previous 10 large slot-based UI from the active source.
- Added Global All-User style controls and preview-before-publish.
- Added 5-style Male/Female presets for VIP/VVIP/ROYAL, Male-only KING 5 and Female-only QUEEN 5.
- Added User ID search with profile confirmation before assignment.
- Added per-user custom design.
- Added background/text/name/level/border/font controls.
- Added border glow ON/OFF, glow color/intensity, background glow, animation ON/OFF/type/speed.
- Added runtime priority: per-user custom > assigned preset > global default.
- Updated Live Room normal-comment renderer to consume new style system.
- Added backend persistence tables/endpoints without changing core user IDs or finance schema.

## Deployment dependency
- Production Worker must be deployed before runtime persistence/assignment testing.

## Pending
- GitHub CI release build: NEEDS CI TEST.
- Real Android device UI/persistence/animation QA: NEEDS DEVICE TEST.
- Do not mark this feature fully PASS until both are green.

## Locked regression rules
- Main Home Dashboard is approved/locked; do not redesign it.
- Live Host remains separate at top; 12 user/guest seats remain 6+6.
- Preserve existing Coin/Gold flows and Google Play compliance safeguards.
