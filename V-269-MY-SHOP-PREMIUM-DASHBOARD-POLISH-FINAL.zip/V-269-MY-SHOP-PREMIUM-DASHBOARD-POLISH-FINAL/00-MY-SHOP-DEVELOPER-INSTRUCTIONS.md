# MY SHOP — Developer Instructions (Permanent Master Rules)

## 0. READ THIS FIRST — NON-NEGOTIABLE
Before opening, editing, replacing, deploying, building, or otherwise working on ANY MY SHOP project file, a developer/AI must read this document first.

This file is the project's permanent handoff/continuation guide. It must remain at the project root with the `00-` prefix so it is encountered before ordinary project files.

**Do not treat MY SHOP as a new project.** Continue from the latest valid sequential V-number and preserve all older versions.

### 0.1 DIRECT FAILURE-FIX RULE — NON-NEGOTIABLE
- If a build/test/deployment failure is shown with an exact error and the affected file/line is identifiable, inspect that exact failure first and fix it directly in the next sequential V-number.
- Do not make the user repeatedly navigate unrelated checks, repeat screenshots, or perform trial-and-error changes when the root compile/runtime error is already visible.
- Preserve the failed version as evidence; never overwrite it.
- After the direct fix, run the relevant validation/build path. If a new error appears, fix that exact new error in the same focused manner.
- Do not claim the fix is successful until the next available validation provides evidence.
- Only ask the user for additional information when the available evidence is genuinely insufficient to identify the failure.

## 1. LIVE VERSION / VERSIONING RULE
- Current development line: **V-257**. The immediate prior full-project source is **V-246** and must remain preserved.
- Historical protected builds **V-179 through V-190** remain preserved (V-184 is the failed-build reference; V-185, V-188 and V-190 are confirmed successful APK-build references; none may be overwritten).
- Next release after this source must use **V-258**. Never reuse or overwrite V-257.
- Never overwrite or delete V-179 through V-190, or any older protected version.
- Before creating a new release, make a complete backup/copy of the previous release.
- Every new release must contain its own SOURCE_BUILD_ID and release notes.
- The newest V-numbered source is the only source allowed for the next build/release.

## 2. HOW THIS DOCUMENT STAYS CURRENT
Whenever a new requirement, confirmed bug, architectural decision, security rule, deployment rule, or completed feature is learned during development:
1. Add it to this document in the appropriate section.
2. If it is a new historical event/decision, append it to **Section 12 — Running Project Change Log** with the V-number and date.
3. Do not silently remove older rules unless the rule was explicitly superseded; if superseded, record what changed and why.
4. The newest confirmed information has priority over older notes, but protected historical versions must not be rewritten.

## 3. PROJECT PURPOSE
MY SHOP is a mobile-first shopping/live-streaming platform with:
- User registration/login and account management.
- Dashboard, live categories, feed, gallery, banners and managed links.
- Live-streaming related features such as GO LIVE / JOIN LIVE.
- Admin-controlled content, ads, banners and media.
- Cloudflare Worker backend, D1 database and R2 media storage.
- Future monetization including startup advertisements and Google Ads-compatible placement.

## 4. CORE SAFETY / PRESERVATION RULES
- Do not remove or replace a working feature unless the user explicitly asks for it.
- Prefer additive, backward-compatible changes.
- Never overwrite a protected version.
- Before modifying/deploying production-related code, preserve a rollback copy.
- Never claim an APK or live deployment succeeded without actual build/deployment evidence.
- If live Cloudflare credentials/status are unavailable, say so instead of guessing.

## 5. PERMANENT USER / ADMIN IDENTITY RULE — CRITICAL
The Permanent User/Admin ID is immutable and globally unique.

- Never change, delete, recycle, overwrite, or reassign a Permanent User/Admin ID.
- A deleted/deactivated account's Permanent ID must never be reused by another account.
- Identity history must remain available for audit, transactions, moderation and account history.
- Email/mobile/password are credentials and may be reset/updated by authorized Admin without changing the Permanent ID.
- User may change profile photo and normal profile settings, but cannot change Permanent ID.
- Account removal must use a soft status such as ACTIVE / SUSPENDED / DISABLED / DEACTIVATED instead of hard-deleting the identity record.
- Enforce this rule in Android UI, Worker backend and D1 database constraints/logic.
- Passwords must never be stored in plaintext.
- Credential changes should be auditable.

## 6. AUTHENTICATION / GOOGLE LOGIN
Existing login must remain available:
- Email / Mobile / User ID + Password.
- Existing session/token backend flow must remain intact.
- Existing roles: USER / ADMIN / MODERATOR.
- Forgot-password/security-question flow must remain intact.

Google Login is an additional login option, not a replacement.
- Current V-183 state: Google button/UI exists, but real Google OAuth is not live without valid Google Cloud configuration.
- Never grant ADMIN based only on a Gmail address.
- Google identity must be linked to the existing account/Permanent ID and backend role must determine Admin access.
- When implementing real OAuth, prefer current Google-recommended Credential Manager / Google Identity Services.
- Verify Google ID tokens server-side; use Google's stable `sub` identifier for account linkage.

## 7. STARTUP AD
Desired flow:
**App Open → optional Admin-controlled Startup Advertisement → countdown/Skip → Login → Google or normal Login → Dashboard**

Current V-247 implementation / permanent rule:
- Startup ad is managed remotely from Admin Dashboard Ads under `startup_ad`.
- Admin controls ADD / EDIT / DELETE / SAVE, ON/OFF, optional click-through link, and Image or Video creative.
- Startup display duration is strictly **1 / 2 / 3 / 4 seconds maximum**; backend and Android both clamp it to this range.
- Creative/config changes are server/R2 driven and must not require an APK update.
- **Fail-open is mandatory:** a missing, corrupt, offline, slow, or failed ad/media request must never trap the app on a black/loading screen. The app proceeds to Login on a short safety watchdog.
- Last-known remote config may be cached for fast launch, but the actual media must become ready quickly; otherwise startup is skipped. Remote config can refresh for the next launch even after the app has already failed open.
- Admin OFF must cause the startup ad to be bypassed as soon as the current remote config is known.
- Future Google Ads integration must respect Google's actual ad format/policy and stays separate from this first-party Admin creative system.

## 8. ADMIN / CONTENT MANAGEMENT
Admin panels must remain Admin-only and must not expose management controls to ordinary users.

Managed areas include, as applicable:
- Dashboard ads/startup ad.
- Banners.
- Gallery/media.
- Dashboard configuration.
- Feature buttons.
- Social links.
- Managed external links.
- Other content-management folders already present in the project.

Known V-182 issue to solve in the next release:
- User reported that **all Admin Add/Save/Link/content features** fail, not only Banner upload.
- Banner error shown: `Upload failed: Banner save failed safely; the previous banner was kept.`
- This strongly suggests a shared backend/D1 write-path, schema, active Worker/database mismatch, or related infrastructure problem rather than one isolated UI feature.
- Do not assume the exact root cause without logs/probes.

## 8.1 SHARED ADMIN WRITE-PATH RULE — PERMANENT
The Admin Banner, Gallery, Advertisement, Dashboard, Social, Feature, External Link and other content folders are not independent infrastructure. They share the Cloudflare D1/R2 write layer.
- If multiple Admin folders fail with similar save/upload errors, treat it as a shared backend/D1/R2 problem first. Do not patch each folder separately as if each were a new bug.
- The first diagnostic path is: active Worker → D1 schema → D1 WRITE probe → R2 WRITE probe → exact endpoint error.
- Schema repair must be additive and explicit. Missing required columns/tables must be repaired automatically; migration errors must never be silently swallowed.
- Before a release is accepted, `/health/deep` must prove both D1 READ+WRITE and R2 READ+WRITE.
- Admin write endpoints must fail with a precise machine-readable error and message when the shared write layer is unavailable.
- If the exact root error is already visible in logs/screenshots, fix that exact layer directly in the next sequential V-number; do not make the user perform unrelated troubleshooting loops.
- R2 uploads must be compensated/deleted if their corresponding D1 record cannot be committed, so failed saves do not leave orphaned media.

## 9. NOTIFICATION SYSTEM — CORE REQUIREMENT
The in-app notification box is a required user-facing feature and must remain functional.
- Users must see MY SHOP broadcast/update notices such as dashboard, banner, gallery, advertisement and other confirmed content updates.
- A post owner must receive an in-app notification when another user likes their post.
- A post owner must receive an in-app notification when another user comments on their post.
- Notification creation must never cause the underlying like/comment/content action to fail.
- Notification schema must be self-healing at runtime and failures must be surfaced in logs/API responses rather than silently swallowed.
- The notification inbox should refresh when opened/resumed and periodically while visible.
- Unread count must remain synchronized with the notification list.
- This is currently an in-app notification inbox; Android push notifications are a separate future feature and must not be assumed to exist.

## 10. BACKEND / CLOUDFLARE
Architecture:
- Cloudflare Worker backend.
- D1 database: `my-shop-db`.
- R2 media bucket: `my-shop-media`.
- Worker name: `rapid-bush-62ea`.
- App/backend URL currently configured in source: `https://rapid-bush-62ea.myshopsatkania.workers.dev`.

Important:
- Live environment cannot be assumed healthy from source code alone.
- Current deep health is mostly read-only; it must be strengthened before relying on it as a write-health guarantee.
- Do not silently swallow schema/migration errors.

## 11. REQUIRED NEXT BACKEND HARDENING
For the next appropriate release, implement and verify:
1. D1 table + required column + index/constraint checks.
2. D1 write → verify → cleanup probe.
3. R2 put → verify/head → delete probe.
4. Auto schema repair with surfaced errors, not silent catches.
5. Safe compensation/rollback if R2 succeeds but D1 fails.
6. Atomic/batched D1 writes where appropriate.
7. Admin System Health diagnostics showing the actual failing layer.
8. GitHub Actions must refuse release/build when required D1/R2 write probes fail.
9. Protect production write probes with appropriate admin/secret authorization.

## 12. BUILD / RELEASE RULES
- Android Java project.
- Expected build environment: Java 17, Android SDK 36, Gradle 8.11.1.
- GitHub Actions is the expected build path when local Gradle/SDK is unavailable.
- Release must use the newest V-numbered source ZIP.
- Workflow must reject older source versions.
- Preserve permanent signing configuration.
- Produce one release APK artifact.
- Verify Worker health and version/build identity after deployment.


### V-201 — 2026-09-05 — FULL CONTENT-WRITE PROBE AUDIT
- V-198 content-write verification still contained a `dashboard_ads` probe using slot 999, despite production/application slot validation being 1-6.
- V-201 replaces invalid/unsafe probe values, uses exact inserted-row cleanup, avoids generic deletion predicates, and uses a real existing account ID for notification-read verification when available.
- V-201 is a complete full-project ZIP; previous V-numbered releases remain preserved.

## 13. RUNNING PROJECT CHANGE LOG

### V-234 — 2026-09-06 — COMPLETE FINAL DASHBOARD INSTRUCTIONS
- Reissued the completed dashboard work as a new sequential source so it cannot be confused with the earlier V-233 delivery.
- Preserves the fixed Header + Breaking News + Live Streaming region, scrolling full-width advertisement/MY FEED/posts, native responsive controls, six live profiles, See All, title-only animation, readable headline and single MY FEED logo.
- Source/build/Worker/workflow identities are locked consistently to V-234.

### V-235 — 2026-09-06 — COMPACT LIVE + NEW PEOPLE

- Live Streaming vertical padding is reduced while its readable text and six live icons retain their approved size.
- Advertisement height remains unchanged and uses the full available width.
- Four New People profiles appear at once below the advertisement with manual swipe, one-by-one auto-scroll, Add Friend and See All.
- Self, friends, pending requests and blocked relationships are excluded; an empty section stays hidden.
- Source/build/Worker/workflow identities are locked consistently to V-235.

### V-236 — 2026-09-06 — SOCIAL + VIDEO + ORIGINAL CHAT

- Incoming Friend Requests screen supports Accept and Decline, with accepted Friends list and targeted notifications.
- Header uses the approved original MY SHOP chat icon; the former Messenger-like asset is no longer referenced.
- Bottom LIVE opens the original vertical short-video viewer with autoplay, swipe navigation, mute, like, share and save feedback.
- Global activity transitions and action feedback are smooth and lightweight.
- Source/build/Worker/workflow identities are locked consistently to V-236.

### V-233 — 2026-09-06 — FINAL LIVE STREAMING DASHBOARD
- Header, Breaking News and the new medium-height Live Streaming surface remain fixed while advertisement, MY FEED and posts scroll naturally below.
- New Live Streaming surface uses native responsive text/buttons, a smooth title-only pulse, Go Live / Live Now / Join Live controls, six full-width live profiles and See All.
- Dashboard advertisement carousel moved below Live Streaming and uses the full safe content width.
- Breaking News headline minimum/default size increased for distance readability while preserving the approved megaphone treatment.
- Removed the duplicate MY FEED text label; retained and clarified the left MY FEED logo with POWER AD and See All.

### V-230 — 2026-09-06 — USER-APPROVED REFERENCE UI + PER-FOLDER ADMIN
- The user-supplied `design-reference/V-230_USER_APPROVED_REFERENCE.png` is the visual source of truth for the Dashboard. Default dashboard/button colors must match it and must not be changed during normal development. Only an authenticated Admin may intentionally change the dashboard palette from Admin controls.
- Top-left Profile/Avatar opens the left profile/menu drawer.
- Bottom navigation MORE alone opens the shortcut sheet. My Shop, Gallery, External Media, Earn & Reward, Categories, Orders, Cart, Social Links, Customer Support, Settings and Share App live inside MORE; Admin Panel is additionally visible to Admin only.
- Removed the always-visible MY SHOP / GALLERY / EXTERNAL MEDIA / EARN & REWARD feature row from the Dashboard.
- Admin taps route through a per-folder Admin entry panel with separate ADD / EDIT / DELETE / SAVE controls. Ordinary users never see these Admin controls.
- Every managed folder/module has an independent advertisement key with maximum 6 slots and sequential auto-rotation on user-facing pages.
- Gallery now also renders its own 6-slot `gallery` advertisement carousel when configured.
- Preserved existing Cloudflare Worker, D1 database, R2 bucket/bindings, permanent User ID logic and non-destructive identity rules.
- Added Admin-only server-backed dashboard color settings while retaining the approved reference palette as the default.

### V-229 — 2026-09-06 — FINAL DASHBOARD LAYOUT LOCK
- User-approved dashboard structure implemented: profile photo at top-left opens the left profile/menu drawer; top-right contains Language, Notifications and Chat.
- Hero banner + LIVE STREAMING + MY FEED composer are locked/fixed; real user posts below MY FEED are the scrolling area.
- Live Streaming is positioned above MY FEED and the existing circular live/dynamic row remains the live-feature surface.
- Five approved feature buttons (MY SHOP, GALLERY, EXTERNAL MEDIA, EARN & REWARD, MORE) stay fixed above bottom navigation.
- Bottom-right MORE opens an in-dashboard upward quick-actions panel instead of navigating away.
- Left drawer profile shows Name + immutable Permanent User ID (0100/0101/0102...) + Email and Admin badge when applicable.
- Feed posts include Share alongside Like and Comment.
- Final approved color direction: light background with blue/purple/pink gradients; Live Streaming is the strongest highlighted section.
### V-192 — 2026-09-04
- Fixed the repository build-blocking Java context guard failure found in the V-191 workflow.
- Replaced current `new Intent(this, FeatureActivity.class)` calls with explicit Activity contexts so callback/listener context cannot be mistaken for an Activity context.
- Kept the mandatory Cloudflare D1/R2 preflight/write-suite gate and permanent signing/update rules.
- Added a durable non-destructive V-192 schema metadata migration.
- Updated SOURCE_BUILD_ID, Android versionCode/versionName, Worker health markers, workflow version/threshold, and release documentation to V-192.
- Full Project ZIP is the required delivery format from V-192 onward.

### V-191 — 2026-09-04
- Permanent Cloudflare/D1/R2 hardening release.
- Added explicit legacy-D1 schema repair, versioned D1 schema metadata migration, and release-blocking live content write verification.
- Added repository-workflow synchronization rule after V-190 proved that a stale root GitHub workflow can bypass the newer source ZIP's Cloudflare checks.
- Preserved all prior versions and permanent identity rules.

### V-189 — 2026-09-04
- Added mandatory live Cloudflare preflight/write-suite requirement before APK build.
- Added real temporary write probes for the shared content tables and notification path so generic D1 health cannot hide a table-specific failure.
- Added Admin-only EDIT actions to MORE cards and relevant 3-line User Menu entries while keeping management hidden from ordinary users.
- Strengthened notification write verification and Admin diagnostics.
- Banner upload remains protected by R2 compensation if the D1 commit fails.

### V-186 — 2026-09-04
- Permanent shared Admin write-path hardening: content folders now validate the required D1 schema before writes instead of silently accepting incomplete migrations.
- Added D1 write → verify → cleanup health probe and R2 put → head → delete health probe.
- `/health/deep` now reports D1/R2 read and write health; release workflow refuses the APK release unless both write probes pass.
- Admin content/banner/gallery/ad write paths return a precise `D1_WRITE_READY_FAILED` error when the shared D1 layer is not ready.
- Legacy-safe Dashboard Ads write path no longer depends on a UNIQUE constraint for `ON CONFLICT`.
- Gallery upload now deletes the new R2 object if the D1 record cannot be saved.
- Client error display now surfaces exact backend `SERVER_ERROR`/D1 failure details instead of hiding the root cause.
- V-185 remains preserved and is not overwritten.

### V-185 — 2026-09-04
- Directly fixed the exact V-184 GitHub Actions compile failure in `NotificationActivity.java`: `self-reference in initializer` caused by `refreshPoll` referencing itself from its own field initializer.
- Preserved the 15-second notification refresh behavior using an anonymous `Runnable` with `this` inside `run()`.
- Added the permanent Direct Failure-Fix Rule: when an exact failure is visible, fix that exact failure directly in the next sequential version without unnecessary troubleshooting loops.
- V-184 remains preserved as the failed-build reference and is not overwritten.

### V-184 — 2026-09-04
- Added the permanent in-app notification requirement for MY SHOP updates, post likes and post comments.
- Added self-healing notification schema initialization and explicit notification database errors.
- Made like/comment notification creation best-effort so a notification database problem cannot break the underlying like/comment action.
- Added notification inbox refresh on resume and periodic refresh while open.
- V-184 must still use the same permanent Android signing key so it updates V-183 without uninstalling.

### V-183 — 2026-09-04
- Added this permanent Developer Instructions master file.
- Established the rule that this document must be read before any project file is handled.
- Established automatic accumulation of new confirmed project information in this document.
- Added permanent identity/ID immutability rules to the handoff guide.
- Recorded the V-182 Admin content save failure as an unresolved shared backend/infrastructure issue for the next fix cycle.

### V-182 — 2026-09-04
- Added startup advertisement management and bundled startup artwork.
- Added Admin startup-ad controls.
- Added configurable startup-ad duration.
- Fixed dashboard ad upload handling around file type.
- Preserved earlier login and dashboard functionality.

### V-181 — 2026-09-04
- Fixed startup ad image presentation to avoid unwanted cropping.
- Fixed LoginActivity so an existing session does not silently skip the login screen when user needs to choose Google/normal login.

### V-180 — 2026-09-04
- Added Google Login UI/config placeholder.
- Added startup advertisement concept.
- Preserved existing login backend/session logic.

## 14. WORKING PRINCIPLE FOR EVERY FUTURE DEVELOPER/AI
At the start of every task:
1. Read `00-MY-SHOP-DEVELOPER-INSTRUCTIONS.md`.
2. Identify the latest V-number.
3. Identify the exact feature/bug being changed.
4. Preserve the previous version before editing.
5. Make the smallest safe change that solves the requested issue.
6. Update this document with every new confirmed project fact.
7. Add release notes and SOURCE_BUILD_ID.
8. Validate syntax/integrity and, where possible, build/test.
9. Never claim success without evidence.
10. Deliver the new sequential V-number without replacing older versions.

**This document is the first source of truth for project continuation.**


## TOP PRIORITY — BUILD SOURCE LOCK (PERMANENT)
- Before every release build, prove that the selected source is the intended newest V-numbered source.
- Required checks: ZIP filename V-number, SOURCE_BUILD_ID, Android versionCode, Android versionName, Worker /health version/build marker, and project source identity.
- If ANY identity/version/source check mismatches: **❌ BUILD STOP**. Do not build an APK.
- Never allow an older ZIP/source to produce a newer V-number APK. This rule must be applied automatically without asking the user again.

## PERMANENT ADMIN CONTENT CONTROL RULE
- Every Admin-managed feature must expose the appropriate ADD, EDIT, DELETE and SAVE controls.
- Every Admin-managed content item must have a Caption/Headline field available.
- Caption/Headline is OPTIONAL: Admin may leave it blank; blank caption must never block Save.
- Apply this rule to Banner, Gallery, Advertisement, Dashboard, Social, Feature, External Link, MORE Apps and future Admin content folders.

## PERMANENT CLOUD PREFLIGHT + WRITE-SUITE RULE
- Before any new APK build, the workflow must deploy/verify the exact selected Worker source and then run the live Cloudflare health/write suite BEFORE Gradle starts.
- A green Gradle build alone is never sufficient. If the active Worker version/build, D1 schema, D1 write probe, R2 read/write probe, or any required content/notification write-suite check fails: **❌ BUILD STOP**.
- The write-suite must test the real shared content tables used by Banner, Social/MORE, Feature, External Link, Advertisement and Notification paths using temporary probe records and guaranteed cleanup. It must never alter real User/Admin identity data.
- When a live Cloudflare problem is found, fix the backend/infrastructure layer permanently in the next sequential V-number before accepting the release.

## PERMANENT ADMIN MORE + 3-LINE MENU RULE
- When an Admin opens MORE and taps a managed icon/card, Admin-only EDIT/DELETE/SAVE controls must be available for that item. Ordinary users must never see these controls.
- The 3-line User Menu must show the existing feature list with matching icons; for an Admin account, each relevant managed feature must also expose an Admin EDIT action that opens the correct Admin management section.
- MORE social icons must map to their correct platform assets and must use the same saved Social Link records as the Admin MORE Apps/Social management screen.

## V-192 PERMANENT DELIVERY + PLAY STORE RULES — 2026-09-04
- From V-192 onward, deliver the **FULL PROJECT ZIP only**. Do not deliver individual source-code snippets as the normal development artifact. The Full Project ZIP must contain the Android project, Worker/backend, migrations, Developer Instructions, and the repository workflow copy required by the project.
- Successful releases must be self-contained, versioned, integrity-checked, and safe to archive. No external Google Drive backup is required by the build workflow.
- Never ask the user to manually replace `.github/workflows/my-shop-apk.yml` on every build. The permanent repository workflow is the authoritative workflow; the same workflow must also be carried inside each Full Project ZIP so the project remains portable.
- Before APK compilation, the repository workflow must automatically select the newest valid V-numbered Full Project ZIP, verify SOURCE_BUILD_ID/versionCode/versionName/Worker version, run the Cloudflare D1/R2 gate, and stop safely on any mismatch.
- V-192 fixed the false-positive Java context guard failure by changing current FeatureActivity navigation to explicit `MainActivity.this` / `UserMenuActivity.this` Activity contexts. Future code must use explicit Activity context when launching FeatureActivity from callbacks/listeners. The preflight guard must remain enabled.
- The app must remain Play Store-ready: same applicationId/package, permanent signing key, monotonically increasing versionCode, stable versionName, production-safe HTTPS endpoints, no debug-only release behavior, and no data-loss migrations. Never require uninstalling the previous MY SHOP APK for an update.
- Any Play Store preparation must preserve permanent User/Admin IDs and existing account/data history.

## V-191 PERMANENT CLOUD / WORKFLOW RULES — 2026-09-04
- The GitHub Actions workflow that actually runs is the repository-root `.github/workflows/my-shop-apk.yml`; a workflow file buried inside a source ZIP does NOT update the repository workflow automatically.
- Before accepting any release, the repository-root workflow must be the V-191-or-newer workflow containing the mandatory Cloudflare gate. The workflow must deploy the exact selected Worker source, verify `/health`, `/health/deep`, `/v1/dashboard/config`, and `/health/content-write-suite`, and only then start Gradle.
- If the repository-root workflow is older and does not contain these gates, **BUILD STOP**; do not treat a green Gradle job as a valid release.
- Cloudflare verification evidence must be retained as a GitHub Actions artifact so future failures can be diagnosed without repeated screenshots.
- D1 schema repair is additive and explicit. Never silently swallow `PRAGMA`, `ALTER TABLE`, CREATE TABLE, index, or migration errors.
- Legacy production schemas must be migrated forward without deleting old columns/data. For the known legacy Banner schema (`section`/`position`), add and populate the current `folder`/`slot` columns while preserving the legacy columns.
- Required content schema includes `banners.folder/slot`, `dashboard_ads.duration_sec`, and `social_links.caption`; a missing required column is a release-blocking health failure until repaired and verified.
- Versioned D1 migrations are part of the project architecture. Runtime additive repair may heal legacy databases, but durable schema changes must also be recorded in `backend/worker/migrations/`.
- Health probes may create temporary probe rows/objects only and must never modify, delete, recycle, or reassign User/Admin identity data.
- The content write suite must cover every shared Admin write family: Dashboard, Banner, Banner Media, Gallery Item/Media, Social, Feature, Managed Link/External Link, Advertisement, Notification and Notification Read, plus R2.
- A failed probe must stop the release before APK compilation.

### V-191 CONFIRMED ROOT CAUSE / FIX TARGETS
- V-190 GitHub Actions screenshot showed a workflow named `MY SHOP FINAL RELEASE` that went from source/setup directly to Gradle and did not show the mandatory Cloudflare preflight/write-suite steps. This proves the repository-root workflow can become stale even when a newer workflow exists inside a source ZIP.
- Cloudflare D1 screenshots showed a legacy `banners` table using `section` and `position`, while the current backend requires `folder` and `slot`. V-191 repairs this mismatch additively and verifies the repaired schema before release.
- D1 screenshots also indicated legacy/missing content columns such as `dashboard_ads.duration_sec` and `social_links.caption`; V-191 repairs and verifies them.
- These are shared backend/schema problems, not separate Android UI bugs.

## V-190 CONFIRMED BUILD FIX — 2026-09-04
- GitHub Actions V-189 release build failed at `FeatureActivity.java:189` because `txt("EDIT",Color.WHITE,9,true)` referenced a helper method that does not exist in `FeatureActivity`.
- This was an exact compile failure, so V-190 directly replaces that call with an explicit `TextView` construction; no unrelated feature behavior is changed.
- V-189 remains preserved as the failed-build reference.

## V-189 CONFIRMED INCOMPLETE ISSUES
- V-188 APK build succeeded, but user testing confirmed the following remain incomplete: MORE icons open without Admin link-management controls; 3-line User Menu features have no Admin EDIT action; like/update notifications do not appear in the inbox; Banner upload still returns the previous-banner-safe failure.
- These are now mandatory V-189 acceptance tests.

## V-188 DIAGNOSTIC RULE
- When multiple Admin folders fail together, diagnose the active Worker/D1/R2 shared write path first.
- Admin System Health must expose the active Worker version, D1 schema status, D1 write probe, R2 read/write status, and exact error detail.
- A green APK build is NOT proof that the active production Worker is the correct source; the workflow must verify the live Worker before APK build.


## V-194 PERMANENT WORKFLOW RUNTIME FIX — 2026-09-04
- V-192 failed because the active repository-root workflow passed `app/build.gradle` as Python's script filename before a heredoc. The permanent master workflow now uses `python3 - <target-file> ... <<'PY'` for file-editing heredocs.
- The master workflow contains an automatic self-check that rejects the known bad invocation before the release can proceed.
- V-192 remains preserved as the failed-build reference.

## V-192 CONFIRMED ROOT CAUSE — GITHUB WORKFLOW PYTHON INVOCATION — 2026-09-04
- The active repository-root `.github/workflows/my-shop-apk.yml` failed before Cloudflare/Gradle because a Python heredoc was invoked as `python3 "$PROJECT/app/build.gradle" ... <<'PY'`.
- That form makes Python execute the Groovy `app/build.gradle` file and produces `SyntaxError: invalid syntax` at `plugins { id 'com.android.application' }`.
- Correct form is `python3 - "$PROJECT/app/build.gradle" ... <<'PY'` (and the same `python3 -` rule for Worker source heredocs).
- The repository-root workflow is the single permanent master workflow. It must be fixed once and inherited by all future V-number releases; the user must not manually replace workflow code for every build.
- Every future release workflow must contain an automated heredoc safety check that rejects the bad form and accepts the `python3 -` form.
- This is a workflow infrastructure fix, not an Android feature change. Preserve V-192 source and all older versions.

## PERMANENT FULL-PROJECT DELIVERY RULE
- Normal MY SHOP releases must be delivered as complete full-project ZIPs, not loose code snippets.
- The full ZIP must include Android source, Worker/backend, migrations, assets, Developer Instructions, release notes, and the repository-root `.github/workflows/my-shop-apk.yml`.
- A one-time replacement of the repository-root master workflow is allowed when repairing an old/stale workflow; after that, future V-number releases must inherit the master automatically.
- Do not ask the user to copy/paste workflow/code on every build.
- Keep the project Google Play Store ready from the beginning: same package identity, permanent signing key, increasing versionCode, Play-compatible architecture, and eventual signed AAB support.

## V-207 CURRENT PERMANENT SOURCE-SELECTION OVERRIDE

- Older V-numbered ZIP files may remain in the repository and MUST NOT by themselves cause BUILD STOP.
- The build selects the highest numeric V. If multiple ZIPs share that highest V, it selects the most recently committed/uploaded ZIP using git commit time, with filename as a deterministic tie-breaker.
- The selected ZIP is then verified by SOURCE_BUILD_ID, Android versionCode/versionName, and Worker version marker before any deploy or APK build.
- Older V sources must never be extracted, deployed, or built when a newer V is present.
- No external backup service is required by the release workflow. Historical backup notes are historical only and must not be scanned as active workflow logic.
- The selected source ZIP's master workflow is validated and auto-synced to the repository root so future builds do not continue using an older root workflow.


## V-208 CURRENT PERMANENT SOURCE-SELECTION OVERRIDE
- Older V-numbered ZIP files may remain in the repository and MUST NOT cause BUILD STOP.
- Only the highest numeric V-number is eligible for build.
- If multiple ZIP files share that highest V-number, select deterministically by latest Git commit timestamp; if timestamps tie, select the lexicographically greatest filename.
- Never build, extract, deploy, or run an older V source when a newer V source exists.
- The selected ZIP must pass SOURCE_BUILD_ID, Android versionCode/versionName, and Worker /health version/build identity checks before build/deploy.
- The root master workflow must be auto-synced from the selected source workflow only after the selected workflow passes the permanent safety checks.
- External Google Drive/backup service is NOT required. Historical references in old documents are historical only and are not active workflow requirements.


## PERMANENT MASTER YAML RULE (HIGHEST PRIORITY)
The repository file `.github/workflows/my-shop-apk.yml` is the permanent master workflow. Normal app/UI/backend/version development MUST NOT require editing that YAML. Deliver only the next sequential `V-<number>-...zip` full project source; upload it to repository root and let the master workflow select/build/sign it. Source packages must never overwrite, push, or replace the repository master workflow.

## V-232 CONFIRMED SOURCE BUILD ID FIX — 2026-09-06
- V-231 failed at the permanent master workflow source-identity gate because `SOURCE_BUILD_ID.txt` contained `V-231` instead of the required exact value `MY SHOP V-231`.
- Every future source ZIP must use `SOURCE_BUILD_ID.txt = MY SHOP V-<highest source number>` exactly, matching the ZIP V-number, Android versionCode, Android versionName `2.9.<V>`, and Worker version/build marker.
- Do not weaken or remove the master source-identity guard to bypass this check; fix the source identity instead.


## V-247 CURRENT PROFILE / SOCIAL / STARTUP RULES — 2026-09-07
- Preserve V-246 Dynamic Animated Badge + Admin User ID Grant and separate ROYAL / VVIP / VIP premium pages. Admin grants remain backend-authoritative and the granted active badge/membership must render on profile without changing the permanent User ID.
- Friends / Followers / Following are backend-authoritative profile statistics. Accepted friendship increments both users' Friends count; Follow/Unfollow changes target Followers and actor Following; Unfriend decrements both Friends counts. Counts must survive app restart and render on both own and public profiles.
- Public profile must expose working Friend, Follow/Unfollow and Message actions with duplicate-submit protection during network actions.
- Profile Cover Photo is a permanent user feature: Add / Change / Remove, stored through R2/backend, shown on own and public profiles, and never tied to Permanent User ID mutation.
- Startup Image/Video Ad is Admin controlled with 1–6 seconds maximum, optional link, ON/OFF and fail-open startup safety. No ad failure may block normal app entry.
- UI actions introduced by this release should use lightweight press/fade feedback and avoid obvious double-submit/flicker.
- The previously discussed Home video thumbnail/playback + Photo/Video download task is **not part of V-247 change scope**; preserve existing V-246/V-245 behavior without reopening that task in this release.

### V-248 — 2026-09-07 — LIVE / MEDIA / PROFILE SOCIAL INTEGRATION
- Implemented the 9-item current scope on V-247 base: 40/60 Live Streaming actions, Join Live pulse, backend-backed real live profile row, External Movie + MORE APPS/Social custom image upload/preview, in-app audio player, social icon priority, Facebook-style premium profile enhancements, real Friend/Follow stats flow hardening, and Profile Timeline/Media/Privacy controls.
- Social icon priority is permanently: Custom Upload → Icon URL → name-based built-in icon → default icon.
- Added additive D1 schema for social icon URLs, live presence and profile privacy.
- Friend response now returns live stats immediately so app/profile state can refresh without stale zeros.


## PERMANENT V-261+ RELEASE GATE — NO DUPLICATE VERSION / NO IDENTITY MISMATCH
- One V-number may have only one delivered source ZIP. Never create FINAL-FIXED, FINAL-2 or another source ZIP using the same V-number.
- Any correction after delivery must immediately use the next unused V-number.
- After creating the final ZIP, inspect the packaged ZIP itself and verify: ZIP V-number = SOURCE_BUILD_ID = SOURCE_VERSION_NAME = Android versionCode/versionName = Worker version/build = Handoff current version.
- Repository build input must contain exactly one source ZIP for the highest V-number; duplicate highest-version ZIPs are a hard failure.
- Confirm ZIP extracts successfully, contains one intended Android project/app module, required Gradle/project files and referenced resources, and contains no stale nested project that can be selected accidentally.
- Preserve the known-good signing and GitHub workflow configuration. Do not rename signing secret variables or alter workflow source-selection logic unless explicitly required and validated.
- Before delivery, check source syntax/resources and ensure changes do not remove previously working dashboard/backend features.
- Never call a package FINAL/ready until the post-package release gate passes.
- If CI fails, diagnose the exact failed step/root cause first; a corrected package gets the next unused V-number.


## V-269 FINAL CHECKPOINT
Current target/source is V-269. Preserve approved premium Dashboard cards, right-to-left Breaking News marquee, Admin visual Breaking News color/size controls, locked top flow, dynamic Live→Newest User fallback, and all existing MY Feed/social functionality.
