# MY SHOP Developer Handoff

Current source: **V-269** (`versionCode 269`, `versionName 2.9.269`).
Base: V-268 premium auth/cards/breaking-control source.

## Last checkpoint
V-269 combines the user's approved dashboard reference with final polish. Breaking News marquee remains intentionally right-to-left. The fixed top region remains Header + Breaking News + LIVE STREAMING; Live/New User cards are the first scrolling section.

## V-269 completed
1. Premium equal Live/New User card shells with circular profile image, badge, green dot, responsive Name + Level row, ID, and full-width relationship button.
2. Live profile pulse animation and newest-user offline fallback retained from backend ordering.
3. Skeleton placeholders instead of repeated fake/duplicate avatars while data is unavailable.
4. Requested friend action can cancel through the existing `/v1/friends/cancel` backend API and return to Add Friend.
5. Breaking News Admin: A-/A+ font size, visual RGB background/text color pickers, preview, server save; marquee behavior unchanged.
6. Existing feed, Quick Links, banner, profile, notification, message, live, and other dashboard flows preserved.

## Build / deployment
Use the permanent GitHub Actions workflow. Worker/backend V-268 endpoints already include dashboard Breaking News style fields and friend cancel endpoint. No new schema migration is required for the V-269 UI polish.

## Validation note
The source package has Gradle configuration but no runnable `gradlew`/wrapper JAR, so local APK compilation was not possible in this environment. Run the normal GitHub Actions APK build as the compile gate.
