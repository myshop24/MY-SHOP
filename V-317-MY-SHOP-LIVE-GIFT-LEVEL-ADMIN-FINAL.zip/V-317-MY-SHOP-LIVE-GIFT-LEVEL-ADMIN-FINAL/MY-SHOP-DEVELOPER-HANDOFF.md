# MY SHOP Developer Handoff — V-317

Current version: V-317
Base: V-316
Phase: Live Gift/Level production test build
Last checkpoint: Post-V-316 16-instruction scope implemented and source-level validated.

## Completed
- Official vs normal Star/Level rules implemented for Coin and Gold Coin.
- Legacy Admin-grant level reconciliation added, including the V-316-style balance-updated/LV.0 case.
- Feed/Profile plain Level and Live Room Level branding wired to backend level values.
- Gift Send success now dismisses Gift Store before animation/sound.
- Faster Live gift-event polling + event ID/client nonce dedupe.
- Premium responsive gift animations + bundled starter sounds retained.
- Separate Coin and Gold Coin gift catalogs.
- Premium Admin gift cards with per-item Price, Save/Edit/Delete/Publish.
- Per-item image/animation and sound add/change/test/remove/on-off.
- Per-item 0–100 volume + presets and Small/Medium/Large/Full Screen animation sizing.
- D1/R2 remote-config path used for routine gift changes; server validates current gift price.
- Existing D1/R2 bindings and Cloudflare Worker structure preserved.

## Next checkpoint
- GitHub Actions compile + Worker deploy.
- Two-account/device Live test of Coin and Gold gift delivery, animation and sound.
- Confirm production D1 wallet/creator-earnings/value-ledger rows after sends.
- Verify historical Official 100,000 Coin grant resolves to LV.2 on updated client/backend.

## Known environment limitation
The editing container does not include an executable Android Gradle wrapper/SDK build environment, so a signed APK/AAB was not locally compiled. Worker JavaScript syntax, XML parsing, source identity, resource presence, and structural Java checks were completed. The existing GitHub workflow remains the build/deploy gate.
