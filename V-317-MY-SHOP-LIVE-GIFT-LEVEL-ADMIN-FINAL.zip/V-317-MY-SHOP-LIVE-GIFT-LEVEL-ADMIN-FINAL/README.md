# Current Release — V-317

See `V-317_RELEASE_NOTES.md`, `V-317_VALIDATION_REPORT.txt`, and `MY-SHOP-DEVELOPER-HANDOFF.md` for the current Live Gift/Level/Admin scope.

---

# MY SHOP V-230

Current full-project source for the user-approved reference Dashboard and per-folder Admin system.

## V-230 locked goals
1. Match the supplied Dashboard reference color/structure; do not redesign it.
2. Top-left Profile/Avatar opens the left drawer.
3. Bottom MORE alone opens the shortcut grid.
4. My Shop, Gallery, External Media and Earn & Reward are inside MORE, not an always-visible feature row.
5. Admin taps open that folder/module Admin panel with ADD / EDIT / DELETE / SAVE.
6. Each managed folder/module supports up to 6 rotating advertisement banners.
7. Ordinary users see content and banners only, never Admin controls/activity.
8. Default dashboard colors stay exactly on the approved palette; only Admin can intentionally change them.
9. Preserve Cloudflare D1/R2 bindings and permanent User ID data.
10. Use the existing permanent signing key and one final APK artifact.

See `V-230_BUILD_NOTES.md` for verification details.
