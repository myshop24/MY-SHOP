package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.Locale;

/** V-317 premium, remote-configured Live Gift catalog manager. */
public class LiveGiftAdminActivity extends androidx.appcompat.app.AppCompatActivity {
    private static final int PICK_PREVIEW=9301, PICK_ANIM=9302, PICK_SOUND=9303, PICK_QUICK=9304;
    private String selectedCurrency="COIN";
    private LinearLayout list,editor;
    private TextView catalogTitle,editorTitle,uploadState,volumeValue;
    private Button addNewButton;
    private EditText name,price,category,preview,animation,sound,order;
    private Spinner size;
    private SeekBar volume;
    private CheckBox enabled,animOn,soundOn;
    private long editId=0;
    private JSONObject quickGift=null;
    private String quickKind="";

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        if(!SessionManager.isAdmin(this)){finish();return;}
        build();load("COIN");
    }

    private void build(){
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);LinearLayout root=col();root.setPadding(dp(12),dp(12),dp(12),dp(34));root.setBackgroundColor(Color.rgb(244,246,253));
        LinearLayout top=row();Button back=btn("‹");back.setOnClickListener(v->finish());top.addView(back,new LinearLayout.LayoutParams(dp(48),dp(46)));LinearLayout brand=col();TextView h=txt("LIVE GIFT CONTROL",20,true,Color.rgb(28,31,64));brand.addView(h);brand.addView(txt("Price • Animation • Sound • Volume • Publish",10,false,Color.rgb(100,104,135)));top.addView(brand,new LinearLayout.LayoutParams(0,dp(52),1));root.addView(top,new LinearLayout.LayoutParams(-1,dp(58)));

        LinearLayout tabs=row();Button coin=btn("🪙 COIN GIFTS"),gold=btn("🟡 GOLD COIN GIFTS");coin.setOnClickListener(v->{selectedCurrency="COIN";clearEditor(false);styleTabs(coin,gold);load("COIN");});gold.setOnClickListener(v->{selectedCurrency="GOLD";clearEditor(false);styleTabs(coin,gold);load("GOLD");});tabs.addView(coin,wt(1));tabs.addView(gold,wt(1));root.addView(tabs,new LinearLayout.LayoutParams(-1,dp(52)));styleTabs(coin,gold);

        LinearLayout help=card();help.addView(txt("ছোট পরিবর্তনে APK লাগবে না",13,true,Color.rgb(45,43,86)));help.addView(txt("Admin Save করলেই Live Gift Store-এ price, sound, volume, animation size ও publish state backend থেকে update হবে।",10,false,Color.rgb(92,94,126)));root.addView(help,top(-1,-2,8));

        addNewButton=btn("＋ ADD NEW COIN GIFT");addNewButton.setOnClickListener(v->{clearEditor(true);editor.setVisibility(View.VISIBLE);editorTitle.setText("New "+selectedCurrency+" Gift");});root.addView(addNewButton,top(-1,dp(50),8));

        editor=card();editor.setVisibility(View.GONE);editorTitle=txt("New Gift",16,true,Color.rgb(49,43,98));editor.addView(editorTitle);
        name=input("Gift name");price=input("Price");price.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);category=input("Category e.g. LOVE / LUXURY / SPECIAL");category.setText("ALL");
        editor.addView(label("Gift info"));editor.addView(name,h48());editor.addView(price,h48());editor.addView(category,h48());
        preview=input("Preview image URL");animation=input("Animation GIF/WebP URL");sound=input("Sound URL");editor.addView(label("Assets"));editor.addView(preview,h48());editor.addView(animation,h48());editor.addView(sound,h48());
        LinearLayout assetBtns=row();Button imageBtn=small("🖼 Add/Change Image"),animBtn=small("✨ Add/Change Animation"),soundBtn=small("🔊 Add/Change Sound");imageBtn.setOnClickListener(v->pick(PICK_PREVIEW,"image",null));animBtn.setOnClickListener(v->pick(PICK_ANIM,"animation",null));soundBtn.setOnClickListener(v->pick(PICK_SOUND,"sound",null));assetBtns.addView(imageBtn,wt(1));assetBtns.addView(animBtn,wt(1));assetBtns.addView(soundBtn,wt(1));editor.addView(assetBtns,top(-1,dp(48),4));
        uploadState=txt("No upload in progress",9,false,Color.rgb(99,102,132));editor.addView(uploadState);

        editor.addView(label("Animation size"));size=new Spinner(this);size.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"SMALL","MEDIUM","LARGE","FULL_SCREEN"}));size.setSelection(1);editor.addView(size,h48());
        LinearLayout sizeQuick=row();for(String z:new String[]{"Small","Medium","Large"}){Button q=small(z);q.setOnClickListener(v->select(size,((Button)v).getText().toString().toUpperCase(Locale.US)));sizeQuick.addView(q,wt(1));}editor.addView(sizeQuick,top(-1,dp(42),3));

        editor.addView(label("Sound volume"));LinearLayout volLine=row();volume=new SeekBar(this);volume.setMax(100);volume.setProgress(70);volumeValue=txt("70%",12,true,Color.rgb(75,52,180));volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){volumeValue.setText(p+"%");}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});volLine.addView(volume,new LinearLayout.LayoutParams(0,dp(46),1));volLine.addView(volumeValue,new LinearLayout.LayoutParams(dp(58),dp(46)));editor.addView(volLine);
        LinearLayout presets=row();int[] vals={0,30,60,90};String[] vs={"Mute","Low","Medium","High"};for(int i=0;i<vs.length;i++){final int x=vals[i];Button q=small(vs[i]);q.setOnClickListener(v->volume.setProgress(x));presets.addView(q,wt(1));}editor.addView(presets,top(-1,dp(40),2));
        order=input("Display order");order.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);order.setText("100");editor.addView(order,h48());enabled=check("Published / Enabled",true);animOn=check("Animation ON",true);soundOn=check("Sound ON",false);editor.addView(enabled);editor.addView(animOn);editor.addView(soundOn);
        LinearLayout editActions=row();Button save=btn("💾 SAVE / PUBLISH"),cancel=btn("Cancel");save.setOnClickListener(v->saveEditor());cancel.setOnClickListener(v->editor.setVisibility(View.GONE));editActions.addView(save,new LinearLayout.LayoutParams(0,dp(50),.68f));editActions.addView(cancel,new LinearLayout.LayoutParams(0,dp(50),.32f));editor.addView(editActions,top(-1,dp(50),6));root.addView(editor,top(-1,-2,8));

        catalogTitle=txt("COIN Gift Catalog",16,true,Color.rgb(37,40,78));root.addView(catalogTitle,top(-1,dp(42),12));list=col();root.addView(list,new LinearLayout.LayoutParams(-1,-2));
        sv.addView(root);setContentView(sv);
    }

    private void styleTabs(Button coin,Button gold){boolean c="COIN".equals(selectedCurrency);coin.setAlpha(c ? 1f : .55f);gold.setAlpha(c ? .55f : 1f);if(addNewButton!=null)addNewButton.setText("＋ ADD NEW "+(c?"COIN":"GOLD COIN")+" GIFT");}

    private void load(String currency){
        selectedCurrency=currency;catalogTitle.setText(("COIN".equals(currency)?"🪙 Coin Gift Catalog":"🟡 Gold Coin Gift Catalog")+" • individual controls");
        list.removeAllViews();TextView wait=txt("Loading catalog…",11,false,Color.rgb(100,103,132));wait.setGravity(Gravity.CENTER);list.addView(wait,new LinearLayout.LayoutParams(-1,dp(80)));
        BackendClient.adminLiveGifts(SessionManager.getToken(this),currency,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->render(o.optJSONArray("gifts")));}public void onError(String m){runOnUiThread(()->{list.removeAllViews();list.addView(txt("Catalog load failed: "+m,11,false,Color.rgb(170,45,65)));});}});
    }

    private void render(JSONArray a){
        list.removeAllViews();if(a==null||a.length()==0){TextView e=txt("No gifts yet. Tap ADD NEW GIFT.",11,false,Color.rgb(100,104,132));e.setGravity(Gravity.CENTER);list.addView(e,new LinearLayout.LayoutParams(-1,dp(90)));return;}
        for(int i=0;i<a.length();i++){
            final JSONObject g=a.optJSONObject(i);if(g==null)continue;
            LinearLayout c=card();
            LinearLayout head=row();ImageView art=new ImageView(this);art.setScaleType(ImageView.ScaleType.CENTER_INSIDE);String u=g.optString("preview_url","");if(u.isEmpty())u=g.optString("animation_url","");if(!u.isEmpty())AnimatedAssetLoader.load(art,u);else art.setImageResource(builtInArt(g.optString("name","Gift")));head.addView(art,new LinearLayout.LayoutParams(dp(76),dp(76)));LinearLayout info=col();info.addView(txt(g.optString("name","Gift"),14,true,Color.rgb(29,31,62)));info.addView(txt(g.optString("currency")+" • "+(g.optInt("enabled",1)==1?"PUBLISHED":"OFF")+" • "+g.optString("category","ALL"),9,false,Color.rgb(104,105,134)));info.addView(txt("Animation "+(g.optInt("animation_enabled",1)==1?"ON":"OFF")+" • Sound "+(g.optInt("sound_enabled",1)==1?"ON":"OFF"),9,false,Color.rgb(87,77,150)));head.addView(info,new LinearLayout.LayoutParams(0,dp(78),1));c.addView(head);

            c.addView(label("Price — this exact saved price is used in Live"));LinearLayout priceLine=row();EditText pr=input("Price");pr.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);pr.setText(String.valueOf(g.optInt("price",1)));priceLine.addView(pr,new LinearLayout.LayoutParams(0,dp(48),1));TextView unit=txt("GOLD".equals(g.optString("currency"))?"Gold Coin":"Coin",10,true,Color.rgb(82,62,175));unit.setGravity(Gravity.CENTER);priceLine.addView(unit,new LinearLayout.LayoutParams(dp(88),dp(48)));c.addView(priceLine);

            c.addView(label("Animation size"));Spinner sz=new Spinner(this);sz.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"SMALL","MEDIUM","LARGE","FULL_SCREEN"}));select(sz,g.optString("size_mode","MEDIUM"));c.addView(sz,h44());

            c.addView(label("Gift sound volume"));LinearLayout vol=row();SeekBar vb=new SeekBar(this);vb.setMax(100);vb.setProgress(g.optInt("sound_volume",70));TextView vv=txt(vb.getProgress()+"%",11,true,Color.rgb(78,56,180));vb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){vv.setText(p+"%");}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});vol.addView(vb,new LinearLayout.LayoutParams(0,dp(44),1));vol.addView(vv,new LinearLayout.LayoutParams(dp(56),dp(44)));c.addView(vol);
            LinearLayout preset=row();int[] val={0,30,60,90};String[] nam={"Mute","Low","Medium","High"};for(int k=0;k<nam.length;k++){final int qv=val[k];Button q=mini(nam[k]);q.setOnClickListener(v->vb.setProgress(qv));preset.addView(q,wt(1));}c.addView(preset,top(-1,dp(38),2));

            CheckBox pub=check("Published",g.optInt("enabled",1)==1),ao=check("Animation ON",g.optInt("animation_enabled",1)==1),so=check("Sound ON",g.optInt("sound_enabled",1)==1);LinearLayout toggles=row();toggles.addView(pub,wt(1));toggles.addView(ao,wt(1));toggles.addView(so,wt(1));c.addView(toggles);

            LinearLayout soundActions=row();Button addSound=mini(g.optString("sound_url","").isEmpty()?"🔊 Add Sound":"🔁 Change Sound"),previewSound=mini("▶ Test"),removeSound=mini("✕ Sound");addSound.setOnClickListener(v->pick(PICK_QUICK,"sound",g));previewSound.setOnClickListener(v->previewSound(g.optString("sound_url",""),g.optString("name","Gift"),vb.getProgress()));removeSound.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Remove sound?").setMessage("Gift থাকবে, শুধু এই Gift-এর custom sound সরানো হবে।").setPositiveButton("Remove",(d,w)->quickSave(g,pr,sz,vb,pub,ao,false,"sound_url","")).setNegativeButton("Cancel",null).show());soundActions.addView(addSound,wt(1));soundActions.addView(previewSound,wt(1));soundActions.addView(removeSound,wt(1));c.addView(soundActions,top(-1,dp(42),4));

            LinearLayout assetActions=row();Button image=mini("🖼 Image"),anim=mini("✨ Animation"),edit=mini("✏ Edit All");image.setOnClickListener(v->pick(PICK_QUICK,"preview",g));anim.setOnClickListener(v->pick(PICK_QUICK,"animation",g));edit.setOnClickListener(v->fillEditor(g));assetActions.addView(image,wt(1));assetActions.addView(anim,wt(1));assetActions.addView(edit,wt(1));c.addView(assetActions,top(-1,dp(42),4));

            LinearLayout finalActions=row();Button save=btn("💾 SAVE"),del=btn("🗑 DELETE");save.setOnClickListener(v->quickSave(g,pr,sz,vb,pub,ao,so.isChecked(),null,null));del.setOnClickListener(v->confirmDelete(g));finalActions.addView(save,new LinearLayout.LayoutParams(0,dp(48),.68f));finalActions.addView(del,new LinearLayout.LayoutParams(0,dp(48),.32f));c.addView(finalActions,top(-1,dp(48),6));
            list.addView(c,top(-1,-2,8));
        }
    }

    private void quickSave(JSONObject g,EditText pr,Spinner sz,SeekBar vb,CheckBox pub,CheckBox ao,boolean soundEnabled,String overrideKey,String overrideValue){
        try{JSONObject x=fromGift(g).put("price",num(pr,g.optInt("price",1))).put("sizeMode",sz.getSelectedItem().toString()).put("soundVolume",vb.getProgress()).put("enabled",pub.isChecked()).put("animationEnabled",ao.isChecked()).put("soundEnabled",soundEnabled);if(overrideKey!=null)x.put(apiKey(overrideKey),overrideValue);BackendClient.adminLiveGiftSave(SessionManager.getToken(this),x,new BackendClient.Callback(){public void onSuccess(JSONObject o){toast("Saved • Live Gift Store auto-updated");load(selectedCurrency);}public void onError(String m){toast(m);}});}catch(Exception e){toast("Please check gift settings");}
    }
    private String apiKey(String db){if("sound_url".equals(db))return "soundUrl";if("preview_url".equals(db))return "previewUrl";if("animation_url".equals(db))return "animationUrl";return db;}
    private JSONObject fromGift(JSONObject g)throws Exception{return new JSONObject().put("id",g.optLong("id")).put("name",g.optString("name","Gift")).put("currency",g.optString("currency",selectedCurrency)).put("price",g.optInt("price",1)).put("category",g.optString("category","ALL")).put("previewUrl",g.optString("preview_url","")).put("animationUrl",g.optString("animation_url","")).put("animationMime",g.optString("animation_mime","")).put("animationEnabled",g.optInt("animation_enabled",1)==1).put("soundUrl",g.optString("sound_url","")).put("soundEnabled",g.optInt("sound_enabled",1)==1).put("soundVolume",g.optInt("sound_volume",70)).put("sizeMode",g.optString("size_mode","MEDIUM")).put("sortOrder",g.optInt("sort_order",100)).put("enabled",g.optInt("enabled",1)==1);}

    private void fillEditor(JSONObject g){editId=g.optLong("id");editor.setVisibility(View.VISIBLE);editorTitle.setText("Edit • "+g.optString("name","Gift"));name.setText(g.optString("name"));price.setText(String.valueOf(g.optInt("price",1)));category.setText(g.optString("category","ALL"));preview.setText(g.optString("preview_url"));animation.setText(g.optString("animation_url"));sound.setText(g.optString("sound_url"));volume.setProgress(g.optInt("sound_volume",70));order.setText(String.valueOf(g.optInt("sort_order",100)));enabled.setChecked(g.optInt("enabled",1)==1);animOn.setChecked(g.optInt("animation_enabled",1)==1);soundOn.setChecked(g.optInt("sound_enabled",1)==1);select(size,g.optString("size_mode","MEDIUM"));}
    private void clearEditor(boolean show){editId=0;name.setText("");price.setText("");category.setText("ALL");preview.setText("");animation.setText("");sound.setText("");volume.setProgress(70);order.setText("100");enabled.setChecked(true);animOn.setChecked(true);soundOn.setChecked(false);size.setSelection(1);if(show)editor.setVisibility(View.VISIBLE);}
    private void saveEditor(){try{JSONObject x=new JSONObject().put("id",editId).put("name",name.getText().toString().trim()).put("currency",selectedCurrency).put("price",num(price,1)).put("category",category.getText().toString().trim()).put("previewUrl",preview.getText().toString().trim()).put("animationUrl",animation.getText().toString().trim()).put("soundUrl",sound.getText().toString().trim()).put("soundVolume",volume.getProgress()).put("sizeMode",size.getSelectedItem().toString()).put("sortOrder",num(order,100)).put("enabled",enabled.isChecked()).put("animationEnabled",animOn.isChecked()).put("soundEnabled",soundOn.isChecked());BackendClient.adminLiveGiftSave(SessionManager.getToken(this),x,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{toast("Gift saved • Live price/settings updated");editor.setVisibility(View.GONE);load(selectedCurrency);});}public void onError(String m){toast(m);}});}catch(Exception e){toast("Please check gift fields");}}

    private void confirmDelete(JSONObject g){new AlertDialog.Builder(this).setTitle("Delete "+g.optString("name","Gift")+"?").setMessage("Gift catalog থেকে hide হবে; historical Live transactions ভাঙবে না।").setPositiveButton("DELETE",(d,w)->BackendClient.adminLiveGiftDelete(SessionManager.getToken(this),g.optLong("id"),new BackendClient.Callback(){public void onSuccess(JSONObject o){load(selectedCurrency);}public void onError(String m){toast(m);}})).setNegativeButton("Cancel",null).show();}

    private void pick(int request,String kind,JSONObject gift){quickKind=kind;quickGift=gift;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);if("sound".equals(kind))i.setType("audio/*");else i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,request);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(c!=RESULT_OK||d==null||d.getData()==null)return;Uri u=d.getData();try{String mime=getContentResolver().getType(u),fn="gift_asset";android.database.Cursor q=getContentResolver().query(u,null,null,null,null);if(q!=null){int n=q.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(q.moveToFirst()&&n>=0)fn=q.getString(n);q.close();}InputStream in=getContentResolver().openInputStream(u);if(uploadState!=null)uploadState.setText("Uploading…");final String kind=quickKind;final JSONObject target=quickGift;BackendClient.adminLiveGiftAssetUpload(SessionManager.getToken(this),in,fn,mime,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{String url=o.optString("url","");if(r==PICK_QUICK&&target!=null){try{JSONObject x=fromGift(target);if("sound".equals(kind)){x.put("soundUrl",url).put("soundEnabled",true);}else if("preview".equals(kind))x.put("previewUrl",url);else{x.put("animationUrl",url).put("animationMime",o.optString("mediaType","")).put("animationEnabled",true);}BackendClient.adminLiveGiftSave(SessionManager.getToken(LiveGiftAdminActivity.this),x,new BackendClient.Callback(){public void onSuccess(JSONObject z){toast("Asset saved • Live updated");load(selectedCurrency);}public void onError(String m){toast(m);}});}catch(Exception e){toast("Asset save failed");}}else{if("sound".equals(kind)){sound.setText(url);if(soundOn!=null)soundOn.setChecked(true);}else if("image".equals(kind)||"preview".equals(kind))preview.setText(url);else animation.setText(url);if(uploadState!=null)uploadState.setText("Uploaded • "+o.optString("mediaType"));}});}public void onError(String m){toast(m);}});}catch(Exception e){toast("Could not read selected file");}finally{quickGift=null;quickKind="";}}

    private void previewSound(String url,String giftName,int vol){try{final android.media.MediaPlayer mp;if(url==null||url.trim().isEmpty()){int res=builtInSound(giftName);if(res==0){toast("No sound assigned to this gift");return;}mp=android.media.MediaPlayer.create(this,res);}else{mp=new android.media.MediaPlayer();mp.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);mp.setDataSource(url);mp.setOnPreparedListener(x->{float v=Math.max(0f,Math.min(1f,vol/100f));x.setVolume(v,v);x.start();});mp.prepareAsync();}if(mp!=null){float v=Math.max(0f,Math.min(1f,vol/100f));mp.setVolume(v,v);mp.setOnCompletionListener(x->{try{x.release();}catch(Exception ignored){}});if(url==null||url.trim().isEmpty())mp.start();}}catch(Exception e){toast("Sound preview failed");}}

    private int builtInArt(String n){String x=String.valueOf(n).toLowerCase(Locale.US);if(x.contains("rose"))return R.drawable.gift_rose;if(x.contains("heart"))return R.drawable.gift_heart;if(x.contains("teddy"))return R.drawable.gift_teddy;if(x.contains("chocolate"))return R.drawable.gift_chocolate;if(x.contains("diamond"))return R.drawable.gift_diamond;if(x.contains("crown"))return R.drawable.gift_crown;if(x.contains("car"))return R.drawable.gift_car;if(x.contains("jet"))return R.drawable.gift_jet;if(x.contains("castle"))return R.drawable.gift_castle;return R.drawable.gift_star;}
    private int builtInSound(String n){String x=String.valueOf(n).toLowerCase(Locale.US);if(x.contains("rose"))return R.raw.gift_rose_sound;if(x.contains("heart"))return R.raw.gift_heart_sound;if(x.contains("teddy"))return R.raw.gift_teddy_sound;if(x.contains("chocolate"))return R.raw.gift_chocolate_sound;if(x.contains("diamond"))return R.raw.gift_diamond_sound;if(x.contains("crown"))return R.raw.gift_crown_sound;if(x.contains("car"))return R.raw.gift_car_sound;if(x.contains("jet"))return R.raw.gift_jet_sound;if(x.contains("castle"))return R.raw.gift_castle_sound;if(x.equals("star")||x.contains("super star"))return R.raw.gift_star_sound;return 0;}

    private LinearLayout card(){LinearLayout x=col();x.setPadding(dp(12),dp(10),dp(12),dp(12));android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable();g.setColor(Color.WHITE);g.setCornerRadius(dp(18));g.setStroke(dp(1),Color.rgb(220,223,239));x.setBackground(g);x.setElevation(dp(2));return x;}
    private Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(11);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.rgb(73,72,223),Color.rgb(151,54,208)});g.setCornerRadius(dp(14));b.setBackground(g);return b;}
    private Button small(String s){Button b=btn(s);b.setTextSize(9);return b;}
    private Button mini(String s){Button b=btn(s);b.setTextSize(8.4f);b.setPadding(dp(2),0,dp(2),0);return b;}
    private EditText input(String h){EditText e=new EditText(this);e.setHint(h);e.setTextSize(12);e.setSingleLine(true);e.setPadding(dp(10),0,dp(10),0);return e;}
    private TextView label(String s){TextView t=txt(s,10,true,Color.rgb(78,80,112));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(32));p.topMargin=dp(5);t.setLayoutParams(p);return t;}
    private CheckBox check(String s,boolean on){CheckBox c=new CheckBox(this);c.setText(s);c.setTextSize(10);c.setChecked(on);return c;}
    private TextView txt(String s,float z,boolean bold,int color){TextView x=new TextView(this);x.setText(s);x.setTextSize(z);x.setTextColor(color);if(bold)x.setTypeface(Typeface.DEFAULT,Typeface.BOLD);x.setPadding(0,dp(4),0,dp(4));return x;}
    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private LinearLayout.LayoutParams wt(float w){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,w);p.setMargins(dp(2),0,dp(2),0);return p;}
    private LinearLayout.LayoutParams h48(){return new LinearLayout.LayoutParams(-1,dp(48));}private LinearLayout.LayoutParams h44(){return new LinearLayout.LayoutParams(-1,dp(44));}
    private LinearLayout.LayoutParams top(int w,int h,int m){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.topMargin=dp(m);return p;}
    private void select(Spinner s,String v){for(int i=0;i<s.getCount();i++)if(v.equalsIgnoreCase(String.valueOf(s.getItemAtPosition(i)))){s.setSelection(i);return;}}
    private int num(EditText e,int d){try{return Math.max(1,Integer.parseInt(e.getText().toString().trim()));}catch(Exception x){return d;}}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}
}
