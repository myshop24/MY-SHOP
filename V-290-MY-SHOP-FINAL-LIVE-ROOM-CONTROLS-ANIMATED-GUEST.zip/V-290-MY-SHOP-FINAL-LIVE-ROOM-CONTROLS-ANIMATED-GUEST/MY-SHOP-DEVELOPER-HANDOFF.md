# MY SHOP Developer Handoff — V-290

## NEXT START HERE
Use **V-290** as the current source. Do not redesign the final approved Audio Live Room unless the owner explicitly requests a new change. Next major technical phase remains real Agora/equivalent Audio RTC integration after installed-device visual/behavior QA.

## Final locked Live Room layout
- Host profile/info stays top-left with no extra enclosing profile box.
- Up to **6 active users** stay on the **same top line as Host**, to the Host's right.
- Exactly one **`>`** control sits at the far-right of that same line and opens the remaining active-user list.
- Timer is `HH:MM`, no seconds, positioned far-left **below Host profile/info**.
- Guest profile stays centered.
- Remove the `SPECIAL GUEST` text entirely.
- Guest uses a neutral **golden animated laurel/glow frame**, with **no crown**.
- 10 speaker positions remain exact **5 + 5**; occupied position shows circular user profile, empty position shows golden sofa.
- Right-side vertical actions: **Request → Gift → React → Share**.
- Bottom row remains at the safe existing vertical position: **Comment → Send → colored Mic → highlighted Join/End**.
- The previous 6-icon bottom control bar is deleted and must not return.
- No controls may drop into Android system-navigation/button area.
- No-scroll/single-screen behavior remains locked.

## Completed in V-290
1. Removed old bottom 6-icon control row.
2. Compact comment composer retained in its safe position.
3. Added Send, premium colored Mic, and highlighted Join/End to same row.
4. Added Request/Gift/React/Share vertical action stack.
5. Removed Special Guest text.
6. Added custom programmatic crown-free golden guest halo/laurel animation.
7. Moved timer to the far-left below Host area.
8. Preserved Host + six active-user same-line layout with one `>` overflow control.
9. Preserved backend authoritative 10 speaker seats at positions 2–11.
10. Updated source/Android/Worker version identity to V-290 / 2.9.290.

## Reference files
- `docs/reference/V-290-FINAL-APPROVED-LIVE-ROOM.png`
- `docs/reference/V-290-SPECIAL-GUEST-ANIMATION-REFERENCE.mp4`
These are documentation/reference assets only, not APK runtime assets.

## Known limitation / test boundary
- Real RTC/Agora voice transport is still not integrated.
- Full Android APK/AAB compilation was not claimed unless a Gradle build actually runs in a configured Android environment.
- Installed-device QA should verify bottom safe-area behavior on gesture navigation and 3-button navigation devices.

## Version identity
- Build: MY SHOP V-290
- Android versionCode: 290
- Android versionName: 2.9.290
- Worker health markers: 2.9.290 / V-290
