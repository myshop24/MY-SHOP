-- V647 additive schema. Apply AFTER all V646 migrations; never reset financial history.
CREATE TABLE IF NOT EXISTS live_layout647(host_id TEXT PRIMARY KEY,session_id TEXT NOT NULL,mode TEXT NOT NULL CHECK(mode IN ('AUDIO','VIDEO')),layout INTEGER NOT NULL CHECK(layout IN (2,4,6,7,8,12,18)));

CREATE TABLE IF NOT EXISTS live_pk647(id TEXT PRIMARY KEY,host_id TEXT NOT NULL,session_id TEXT NOT NULL,guest_id TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('COIN','GOLD')),starts INTEGER NOT NULL,expires INTEGER NOT NULL,duration INTEGER NOT NULL DEFAULT 180,state TEXT NOT NULL CHECK(state IN ('INVITED','ACTIVE','DECLINED','STOPPED')));

CREATE TABLE IF NOT EXISTS live_pk_events647(pk_id TEXT NOT NULL,gift_id INTEGER NOT NULL,receiver_id TEXT NOT NULL,amount INTEGER NOT NULL,currency TEXT NOT NULL,PRIMARY KEY(pk_id,gift_id));

CREATE TABLE IF NOT EXISTS animation_boxes647(id TEXT PRIMARY KEY,amount INTEGER NOT NULL CHECK(amount BETWEEN 1 AND 1000000),winners INTEGER NOT NULL CHECK(winners BETWEEN 1 AND 5),starts INTEGER NOT NULL,expires INTEGER NOT NULL CHECK(expires=starts+10000),enabled INTEGER NOT NULL DEFAULT 1,actor TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS animation_rooms647(box_id TEXT NOT NULL,host_id TEXT NOT NULL,session_id TEXT NOT NULL,PRIMARY KEY(box_id,host_id));

CREATE TABLE IF NOT EXISTS animation_claims647(box_id TEXT NOT NULL,host_id TEXT NOT NULL,user_id TEXT NOT NULL,amount INTEGER NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(box_id,user_id));

CREATE TRIGGER IF NOT EXISTS live_capacity_insert647 BEFORE INSERT ON myshop_live_seats_dynamic WHEN EXISTS(SELECT 1 FROM live_layout647 l JOIN myshop_live_room_meta m ON m.host_id=l.host_id AND m.session_id=l.session_id WHERE l.host_id=NEW.host_id AND NEW.seat_no>CASE WHEN l.mode='VIDEO' THEN l.layout ELSE l.layout+1 END) BEGIN SELECT RAISE(ABORT,'ROOM_CAPACITY_REACHED');END;

CREATE TRIGGER IF NOT EXISTS live_capacity_update647 BEFORE UPDATE OF seat_no ON myshop_live_seats_dynamic WHEN EXISTS(SELECT 1 FROM live_layout647 l JOIN myshop_live_room_meta m ON m.host_id=l.host_id AND m.session_id=l.session_id WHERE l.host_id=NEW.host_id AND NEW.seat_no>CASE WHEN l.mode='VIDEO' THEN l.layout ELSE l.layout+1 END) BEGIN SELECT RAISE(ABORT,'ROOM_CAPACITY_REACHED');END;

CREATE INDEX IF NOT EXISTS live_pk_events647_round ON live_pk_events647(pk_id,receiver_id);

CREATE INDEX IF NOT EXISTS live_pk647_active ON live_pk647(host_id,state,expires);

CREATE TRIGGER IF NOT EXISTS live_pk_gift647 AFTER INSERT ON myshop_live_gift_events WHEN NEW.status='COMPLETED' BEGIN INSERT OR IGNORE INTO live_pk_events647(pk_id,gift_id,receiver_id,amount,currency) SELECT p.id,NEW.id,NEW.receiver_id,NEW.price,NEW.currency FROM live_pk647 p JOIN myshop_live_room_meta m ON m.host_id=p.host_id AND m.session_id=p.session_id WHERE p.host_id=NEW.host_id AND p.state='ACTIVE' AND p.currency=NEW.currency AND NEW.receiver_id IN (p.host_id,p.guest_id) AND p.starts<=CAST((julianday('now')-2440587.5)*86400000 AS INTEGER) AND p.expires>CAST((julianday('now')-2440587.5)*86400000 AS INTEGER);END;

CREATE TRIGGER IF NOT EXISTS live_pk_complete647 AFTER UPDATE OF status ON myshop_live_gift_events WHEN NEW.status='COMPLETED' AND OLD.status<>'COMPLETED' BEGIN INSERT OR IGNORE INTO live_pk_events647(pk_id,gift_id,receiver_id,amount,currency) SELECT p.id,NEW.id,NEW.receiver_id,NEW.price,NEW.currency FROM live_pk647 p JOIN myshop_live_room_meta m ON m.host_id=p.host_id AND m.session_id=p.session_id WHERE p.host_id=NEW.host_id AND p.state='ACTIVE' AND p.currency=NEW.currency AND NEW.receiver_id IN (p.host_id,p.guest_id) AND p.starts<=CAST((julianday('now')-2440587.5)*86400000 AS INTEGER) AND p.expires>CAST((julianday('now')-2440587.5)*86400000 AS INTEGER);END;

CREATE INDEX IF NOT EXISTS live_pk647_room ON live_pk647(host_id,session_id,starts DESC);

CREATE INDEX IF NOT EXISTS animation_rooms647_host ON animation_rooms647(host_id,session_id,box_id);

CREATE INDEX IF NOT EXISTS animation_claims647_history ON animation_claims647(created_at DESC);

CREATE INDEX IF NOT EXISTS animation_claims645_history ON animation_claims645(created_at DESC);

CREATE INDEX IF NOT EXISTS animation_claims647_room ON animation_claims647(box_id,host_id);

CREATE INDEX IF NOT EXISTS animation_boxes647_active ON animation_boxes647(enabled,expires,starts);

CREATE INDEX IF NOT EXISTS animation_events647_recent ON animation_events645(created_ms DESC,expires_ms);

CREATE INDEX IF NOT EXISTS animation_rewards647_recent ON myshop_live_reward_claims(status,created_at DESC);

CREATE INDEX IF NOT EXISTS animation_catalog647_types ON myshop_store_catalog(enabled,item_type,priority,id);

CREATE INDEX IF NOT EXISTS animation_purchase647_lookup ON myshop_store_purchase_requests(catalog_id,status);

CREATE INDEX IF NOT EXISTS animation_reservation647_lookup ON myshop_special_id_reservations(user_id,status);

CREATE INDEX IF NOT EXISTS animation_rare647_lookup ON myshop_rare_ids611(catalog_id,state);

CREATE TRIGGER IF NOT EXISTS animation_claim_guard647 BEFORE INSERT ON animation_claims647 BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM animation_boxes647 b JOIN animation_rooms647 r ON r.box_id=b.id JOIN myshop_live_room_meta m ON m.host_id=r.host_id AND m.session_id=r.session_id JOIN myshop_live_presence p ON p.user_id=r.host_id AND p.active=1 AND p.last_seen>datetime('now','-90 seconds') WHERE b.id=NEW.box_id AND r.host_id=NEW.host_id AND b.enabled=1 AND b.amount=NEW.amount AND b.starts<=CAST((julianday('now')-2440587.5)*86400000 AS INTEGER) AND b.expires>CAST((julianday('now')-2440587.5)*86400000 AS INTEGER) AND (SELECT COUNT(*) FROM animation_claims647 q WHERE q.box_id=b.id AND q.host_id=r.host_id)<b.winners AND (NEW.user_id=r.host_id OR EXISTS(SELECT 1 FROM myshop_live_visits v JOIN myshop_live_viewers w ON w.host_id=v.host_id AND w.user_id=v.user_id WHERE v.host_id=r.host_id AND v.session_id=r.session_id AND v.user_id=NEW.user_id AND w.last_seen>datetime('now','-25 seconds')))) THEN RAISE(ABORT,'BOX_CLOSED_OR_INELIGIBLE') END;END;

CREATE TRIGGER IF NOT EXISTS animation_claim_credit647 AFTER INSERT ON animation_claims647 BEGIN
INSERT INTO myshop_coin_wallets(user_id,balance) VALUES(NEW.user_id,NEW.amount) ON CONFLICT(user_id) DO UPDATE SET balance=balance+NEW.amount,updated_at=CURRENT_TIMESTAMP;
INSERT INTO myshop_coin_transactions(user_id,kind,amount,reference,metadata) VALUES(NEW.user_id,'LIVE_BOX_REWARD',NEW.amount,'box647:'||NEW.box_id||':'||NEW.host_id,'Admin live gift box');
INSERT INTO myshop_wallet_sources(user_id,currency,official_balance) VALUES(NEW.user_id,'COIN',NEW.amount) ON CONFLICT(user_id,currency) DO UPDATE SET official_balance=official_balance+NEW.amount,updated_at=CURRENT_TIMESTAMP;
INSERT INTO myshop_value_ledger(tx_type,currency,sender_id,receiver_id,host_id,gross_amount,net_amount,reference) VALUES('LIVE_BOX_REWARD','COIN','OFFICIAL',NEW.user_id,NEW.host_id,NEW.amount,NEW.amount,'box647:'||NEW.box_id||':'||NEW.host_id);END;
