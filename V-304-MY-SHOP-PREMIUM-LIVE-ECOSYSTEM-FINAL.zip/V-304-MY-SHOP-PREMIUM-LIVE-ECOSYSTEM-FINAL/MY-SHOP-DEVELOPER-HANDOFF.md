# MY SHOP Developer Handoff — V-304

## Current version
V-304 (versionCode 304 / versionName 2.9.304)

## Source basis
V-304 is built from the exact V-303 final source line and preserves the permanent MY SHOP regression rule: fixing or adding one feature must not remove/break another working feature.

## Completed V-304 scope
See `V-304_MASTER_30_CHECKLIST.md` and `V-304_RELEASE_NOTES.md` for the full 30-point implementation scope.

Key architecture changes:
- Live comments use current-session transient D1 buffering only for active-room fan-out/polling, with nonce de-duplication, an 80-row/session cap, abandoned-row cleanup, and deletion on Live End. No Live-comment history is retained; R2 is not used for text comments.
- Live timer is keyed by current session ID and server elapsed time to prevent previous-session carryover.
- Premium Live ecosystem adds goals, fan club, creator analytics, live shop pinning, discover/ranking, scheduled live/reminders, achievements and PK foundation.
- Existing 12-seat Host/Speaker/Audience architecture, Join Request/Host Invite flow, moderation, themes/gifts and Dashboard/Feed/Profile/Shop contracts are preserved.

## Protected configuration
- `.github/workflows/my-shop-apk.yml` unchanged from V-303.
- `backend/worker/wrangler.toml` unchanged from V-303, including D1/R2 bindings.
- applicationId remains `com.myshop.app`.
- Root Gradle/settings/properties remain unchanged; app Gradle changes are versionCode/versionName only.

## Validation state
- SOURCE_BUILD_ID = `MY SHOP V-304`.
- SOURCE_VERSION_NAME = `2.9.304`.
- Android = versionCode `304`, versionName `2.9.304`.
- Worker health/build markers = `2.9.304` / `V-304`.
- Worker JavaScript syntax check: PASS.
- Android XML parsing: PASS.
- Changed Java source syntax scan: no Java parser/syntax errors detected; local compilation cannot resolve Android classes because Android SDK is not installed here.
- Protected workflow/D1/R2 configuration hash comparison against V-303: PASS.
- ZIP integrity and SHA-256 are produced after final packaging.

## Required release verification
GitHub Actions remains the definitive Android compile/sign/deploy verification. After a green build, run two-device Host/Audience tests for timer reset/rejoin, comment send/de-duplication, Join Request/Host Invite, reconnect, gifts, Fan Club, Schedule Reminder and PK flows.
