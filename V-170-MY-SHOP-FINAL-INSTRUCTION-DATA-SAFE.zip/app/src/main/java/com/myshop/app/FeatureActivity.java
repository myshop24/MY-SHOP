package com.myshop.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import org.json.JSONArray;
import org.json.JSONObject;
import androidx.appcompat.app.AppCompatActivity;

public class FeatureActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String title = getIntent().getStringExtra("title");
        if (title == null || title.trim().isEmpty()) title = "MY SHOP";

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 42, 28, 28);
        root.setBackgroundColor(getColor(R.color.myshop_bg));

        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextSize(27);
        heading.setTextColor(getColor(R.color.myshop_dark));
        heading.setGravity(Gravity.CENTER);
        root.addView(heading, new LinearLayout.LayoutParams(-1, 100));

        TextView status = new TextView(this);
        status.setText("MY SHOP module frame\n\nThis feature is ready for backend-driven content. Where supported, Admin changes can be delivered without rebuilding the APK.");
        status.setTextSize(17);
        status.setTextColor(getColor(R.color.text_muted));
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, 0, 1));

        String featureKey=getIntent().getStringExtra("feature_key");
        if ("more_apps".equals(featureKey)) {
            renderMore(root,status);
        }
        if ("help_support".equals(featureKey)) {
            status.setText("Loading Customer Support…");
            BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->renderSupport(root,status,d.optJSONArray("managedLinks")));}
                public void onError(String m){runOnUiThread(()->status.setText("Customer support is not configured yet."));}
            });
        }

        if ("social_media".equals(featureKey)) {
            status.setText("Loading Social Media…");
            BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->renderSocial(root,status,d.optJSONArray("socialLinks")));}
                public void onError(String m){runOnUiThread(()->status.setText("Social links unavailable: "+m));}
            });
        }

        String url = getIntent().getStringExtra("url");
        if (FeatureRegistry.isSafeHttpUrl(url)) {
            Button open = new Button(this);
            open.setText("Open Link");
            open.setOnClickListener(v -> openUrl(url));
            root.addView(open, new LinearLayout.LayoutParams(-1, 58));
        }

        Button back = new Button(this);
        back.setText("Back");
        back.setOnClickListener(v -> finish());
        root.addView(back, new LinearLayout.LayoutParams(-1, 58));
        setContentView(root);
    }



    private void renderMore(LinearLayout root, TextView status){
        status.setText("");
        status.setVisibility(TextView.GONE);
        LinearLayout content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0,0,0,10);
        root.addView(content,0,new LinearLayout.LayoutParams(-1,0,1));
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                JSONArray social=d.optJSONArray("socialLinks");
                String[] wanted={"Facebook","Page","YouTube","WhatsApp","imo","Instagram","Telegram"};
                for(String w:wanted){
                    JSONObject found=null;
                    if(social!=null) for(int i=0;i<social.length();i++){JSONObject x=social.optJSONObject(i);if(x!=null&&w.equalsIgnoreCase(x.optString("platform",""))){found=x;break;}}
                    if(found!=null&&found.optInt("active",1)==1&&FeatureRegistry.isSafeHttpUrl(found.optString("url",""))) addPlatformButton(content,w,found.optString("url",""));
                }
                addMoreButton(content,"💬  CUSTOMER SUPPORT","WhatsApp support • number hidden",v->{
                    Intent i=new Intent(FeatureActivity.this,FeatureActivity.class); i.putExtra("title","CUSTOMER SUPPORT"); i.putExtra("feature_key","help_support"); startActivity(i);
                });
                addMoreButton(content,"📤  SHARE APP","Share MY SHOP",v->shareApp());
            });}
            public void onError(String m){runOnUiThread(()->{addMoreButton(content,"💬  CUSTOMER SUPPORT","WhatsApp support • number hidden",v->{Intent i=new Intent(FeatureActivity.this,FeatureActivity.class);i.putExtra("title","CUSTOMER SUPPORT");i.putExtra("feature_key","help_support");startActivity(i);});addMoreButton(content,"📤  SHARE APP","Share MY SHOP",v->shareApp());});}
        });
    }

    private void addPlatformButton(LinearLayout root,String platform,String url){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(12,4,12,4); card.setBackgroundColor(Color.WHITE);
        TextView icon=new TextView(this); icon.setText(platformIcon(platform)); icon.setTextSize(22); icon.setGravity(Gravity.CENTER); card.addView(icon,new LinearLayout.LayoutParams(54,54));
        TextView name=new TextView(this); name.setText(platform); name.setTextSize(16); name.setTextColor(Color.rgb(24,29,62)); name.setTypeface(Typeface.DEFAULT,Typeface.BOLD); card.addView(name,new LinearLayout.LayoutParams(0,58,1));
        TextView go=new TextView(this); go.setText("›"); go.setTextSize(25); go.setTextColor(Color.rgb(83,32,180)); go.setGravity(Gravity.CENTER); card.addView(go,new LinearLayout.LayoutParams(42,58));
        card.setOnClickListener(v->openUrl(url)); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,64);cp.setMargins(0,0,0,8);root.addView(card,cp);
    }
    private String platformIcon(String p){String s=p.toLowerCase();if(s.contains("facebook"))return "ⓕ";if(s.equals("page"))return "📄";if(s.contains("youtube"))return "▶";if(s.contains("whatsapp"))return "◉";if(s.contains("imo"))return "💬";if(s.contains("instagram"))return "◎";if(s.contains("telegram"))return "✈";return "●";}

    private void addMoreButton(LinearLayout root,String title,String desc,android.view.View.OnClickListener listener){
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(18,10,18,10);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setBackgroundColor(Color.WHITE);
        TextView t=new TextView(this); t.setText(title); t.setTextSize(16); t.setTextColor(Color.rgb(24,29,62)); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        TextView d=new TextView(this); d.setText(desc); d.setTextSize(11); d.setTextColor(Color.rgb(105,111,130));
        card.addView(t,new LinearLayout.LayoutParams(-1,42)); card.addView(d,new LinearLayout.LayoutParams(-1,30));
        card.setOnClickListener(listener);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,78); cp.setMargins(0,0,0,10); root.addView(card,cp);
    }

    private void shareApp(){
        try{ Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_SUBJECT,"MY SHOP"); i.putExtra(Intent.EXTRA_TEXT,"MY SHOP — https://rapid-bush-62ea.myshopsatkania.workers.dev"); startActivity(Intent.createChooser(i,"Share MY SHOP")); }
        catch(Exception e){ Toast.makeText(this,"Share is not available.",Toast.LENGTH_SHORT).show(); }
    }

    private void renderSupport(LinearLayout root,TextView status,JSONArray a){
        status.setText(""); int count=0;
        if(a!=null) for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String cat=x.optString("category","");String url=x.optString("url","").trim();String title=x.optString("title","Customer Support");if(!"help_support".equals(cat))continue;final String target=normalizeWhatsApp(url);if(target.isEmpty())continue;Button b=new Button(this);b.setText("💬  "+title);b.setTextSize(15);b.setAllCaps(false);b.setOnClickListener(v->openUrl(target));root.addView(b,new LinearLayout.LayoutParams(-1,60));count++;}
        if(count==0)status.setText("Customer support link has not been configured by Admin yet.");
    }

    private void renderSocial(LinearLayout root,TextView status,JSONArray a){
        status.setText("");
        int count=0;
        if(a!=null) for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String platform=x.optString("platform","").trim();String url=x.optString("url","").trim();if(platform.isEmpty()||!FeatureRegistry.isSafeHttpUrl(url))continue;LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(10,4,10,4);ImageView icon=new ImageView(this);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setImageResource(R.drawable.feature_social_selected);row.addView(icon,new LinearLayout.LayoutParams(48,48));LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);TextView name=new TextView(this);name.setText(platform);name.setTextSize(14);name.setTextColor(Color.rgb(24,29,62));name.setTypeface(Typeface.DEFAULT,Typeface.BOLD);TextView domain=new TextView(this);domain.setText(url);domain.setTextSize(9);domain.setTextColor(Color.rgb(105,111,130));box.addView(name);box.addView(domain);row.addView(box,new LinearLayout.LayoutParams(0,56,1));row.setOnClickListener(v->openUrl(url));loadSocialIcon(icon,url,platform);root.addView(row,new LinearLayout.LayoutParams(-1,64));count++;}
        if(count==0) status.setText("No social links have been saved by Admin yet.");
    }
    private String normalizeWhatsApp(String raw){
        String v=raw==null?"":raw.trim(); if(v.isEmpty())return "";
        if(v.startsWith("http://")||v.startsWith("https://")){
            try{ Uri u=Uri.parse(v); String host=u.getHost()==null?"":u.getHost().toLowerCase(); if(host.contains("wa.me")||host.contains("whatsapp.com"))return v; }catch(Exception ignored){}
            return FeatureRegistry.isSafeHttpUrl(v)?v:"";
        }
        String digits=v.replaceAll("[^0-9]",""); if(digits.length()<8)return ""; return "https://wa.me/"+digits;
    }

    private void loadSocialIcon(ImageView target,String url,String platform){Executors.newSingleThreadExecutor().execute(()->{try{String host=new URL(url).getHost();if(host==null||host.isEmpty())throw new Exception("no host");String iconUrl="https://www.google.com/s2/favicons?sz=128&domain_url="+java.net.URLEncoder.encode("https://"+host,"UTF-8");HttpURLConnection c=(HttpURLConnection)new URL(iconUrl).openConnection();c.setConnectTimeout(6000);c.setReadTimeout(8000);c.setInstanceFollowRedirects(true);try(InputStream in=c.getInputStream()){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null)runOnUiThread(()->target.setImageBitmap(b));}}catch(Exception ignored){}});}
    private String socialIcon(String p){String s=p.toLowerCase();if(s.contains("facebook"))return "ⓕ";if(s.contains("youtube"))return "▶";if(s.contains("tiktok"))return "♪";if(s.contains("instagram"))return "◎";if(s.contains("whatsapp"))return "◉";if(s.contains("telegram"))return "✈";return "●";}

    private void openUrl(String value) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(value.trim())));
        } catch (Exception e) {
            Toast.makeText(this, "Unable to open link.", Toast.LENGTH_SHORT).show();
        }
    }
}
