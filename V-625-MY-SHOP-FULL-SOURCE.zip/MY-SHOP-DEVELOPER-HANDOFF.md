# MY SHOP V625 / 2.9.625 — handoff
Continue V624; no restart. Preserve unrelated working features and GitHub signing secrets.

Implemented: Level0 voting; ordinary perHost24h and self/inactive restrictions retained. Buyer cancellation of own Pending Store request, full held Diamond/source refund once, RareID release, private My Buy Requests history; Admin approve/reject preserved. Available RareID Buy Now remains colored/clickable at low balance and reports Insufficient balance on tap. Catalogue data retained and cancellation updates current item.

Gift level bar completed green/remainder red, existing level calculation and lower LV/English Coin-needed line preserved. Join animation uses slim borderless/ringless gradient, larger plain circular avatar, centered name has joined, thinner suffix; Top1 medal in same moving notice and actual name in normal bottom comment, no third entrance. Existing MS profile logo retained; real onboarding People API key corrected. Admin/Moderator Close Live from Home and full Live list; Join/free seat directly, occupied/locked protection and ordinary Host approval retained. No Close Reason or extra mic banner.

Read amplification: Home revision watcher replaces full profiles every5sec; recent expression indexes plus purchase/refund lookup indexes and existing D1 query diagnostics. Actual shipped hourly SQL synthetic SQLite work350400->500 with same results. This is not production D1 rows_read telemetry. Download cache age/cap cleanup and Settings Clear downloaded cache only touch reproducible files; originals/camera/voice/drafts/account protected. Screenshot D1 storage3.02MB, not3GB; phone3GB location unconfirmed, no remote/private-device deletion claimed.

All inherited commission switches, gift policy, store prices, level rules, original assets, billing and signing behavior preserved. Production deploy/device QA not performed. Full source ZIP itself goes to existing GitHub main root; leave repository workflow/release script and secrets unchanged. Existing pipeline builds signed APK; source ZIP contains no prebuilt APK.

Validation: tools/v625_target_verify.sh, full backend suites, local assembleRelease and cache/layout unit tests. See verification/V625-RESULTS.md. Next changed delivery V626.
