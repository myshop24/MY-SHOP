# MY SHOP — V-43

V-17 is the consolidated MY SHOP Android foundation with release-build hardening.

## Build
GitHub Actions builds:
- `V-17 MY SHOP-debug.apk`
- `V-17 MY SHOP-release-unsigned.apk`

If the four optional signing secrets are configured, it also produces:
- `V-17 MY SHOP-release-signed.apk`

No private signing key is stored in this repository.

## Admin / backend principle
Admin identity, roles, passwords, content management, banners, links, payment methods and other remotely changeable settings must be controlled by a secure backend. Credentials must never be embedded in the APK.

## Versioning
This package is a new version. V-1 through V-15 remain separate backups.


## V-43 critical rule
Do not treat GitHub Actions success alone as final. The APK must pass package/version/integrity checks and be installed on a phone for launch/login runtime verification.

## MY SHOP V-59 BUILD

Use `.github/workflows/MY_SHOP_V-59_BUILD.yml` for the V-59 build. The final GitHub Artifact is intentionally APK-only: exactly one `.apk` file is uploaded. Source ZIPs and release notes are never uploaded as artifacts.
