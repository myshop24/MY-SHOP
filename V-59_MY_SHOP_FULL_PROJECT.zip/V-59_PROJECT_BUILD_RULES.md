# MY SHOP V-59 — BUILD RULES

- This package is the V-59 full Android project.
- The GitHub workflow is the only workflow in this package.
- The workflow builds exactly one installable debug APK.
- The artifact contains exactly one APK and no ZIP/source/notes files.
- The APK package is `com.myshop.app`.
- The generated version name is `5.9.<run number>`.
- The generated version code is unique per GitHub run/attempt.
- APK signature, package/version metadata, and ZIP integrity are verified before upload.
- Older V-58/V-57 build workflows are not included in this package.
