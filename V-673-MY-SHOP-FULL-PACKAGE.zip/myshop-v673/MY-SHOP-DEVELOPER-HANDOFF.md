# V-673 — Guardian Admin preview consistency

Owner screenshot144779.jpg showed legacy wing artwork even on new1/2/3month plan rows. Confirmed bug: AdminStoreActivity.adminProductPreview fell through to old catalog animation_url (guardian667/frame.webp), while user Store/MyCollection/Live already used Guardian667.art native halo. Admin config cannot repair this renderer mismatch. Added a GUARDIAN-specific first branch invoking the exact shared native MS/halo. It covers product grid, editor preview and request thumbnails. No new Guardian artwork, pricing or membership behavior. Existing data/catalog URLs and paid IDs remain untouched.

Added direct Guardian Controls button on the existing GUARDIAN Admin page, opening GuardianAdmin671Activity (background/prices/Admin-only Remove/Restore). Previously the new controls were accessible only from AdminHub's separate Guardian module. User screenshot is the product/pricing page, not that controls page.

Actual Android release assembly/lint/APK verification PASS (57s; previously passed preBuild checks reused). New Guardian Controls text verified in actual DEX; AAPT2 independently verifies673/2.9.673. Current source673/2.9.673. Results in verification/V673-RESULTS.json. No original signing key locally, no remote deploy, no phone screenshot test. One complete sourceZIP<25MB; signed APK obtained from existing GitHub original signing. Next changed release674 after this delivered. Historical notes below are retained.

---

# V-672 — Gift icon physical-pixel scaling correction

Owner reported tiny/non-visible Gift icon with screenshot144765.jpg. Found confirmed root cause: Drawable intrinsic size40 is physical pixels; ImageView.CENTER_INSIDE refuses to upscale. On3x-density phone the visible32px box is only10.7dp despite a48dp hit target. Changed ONLY the Gift ImageView scale type to FIT_CENTER: same vector,48dp viewport, existing lid/flower animation and Send listener. Approx38.4dp visible body across densities. No rail ordering/positions, payment, gifts, Guardian, wallpaper, FULL video or rider feature changes. V671 remains preserved and unmodified as a delivery.

Actual Android672 assembly/lint and APK contents verification PASS (1m4s; final assembly reused previously verified preBuild checks). AAPT2 independently verifies672/2.9.672. Local APK unsigned; original signing absent. New regression tests8 screen densities and protects actual scale selection,48dp size and Send wiring. Current verification results are in verification/V672-RESULTS.json. Source identity672/2.9.672. No new signing key, no production deployment. One sourceZIP<25MB; signed installable APK must come from existing GitHub original signing. Physical phone screenshot acceptance has not been performed. Next changed deliveryV673 after this is delivered.

Historical V671 handoff below explains all inherited features; it is not a new scope expansion.

---

# MY SHOP V-671 — selected changes and verified build

Latest owner scope: **02 → 03 → 06 → 17 only**. Guardian Remove/Restore is **ADMIN ONLY**, explicitly corrected by owner. Task19 and all other new tasks are deferred. Existing rider work is retained without further visual/feature development. One necessary packaging correction changes its generated compressed model suffix from .gz to .bin: AAPT had silently unpacked/renamed .gz and would make the reader fail. The bytes/model/animation remain identical.

Actual verification: Android36/JDK17/Gradle8.11.1 release assembly and lintVital PASS, APK DEX/resources/media checks PASS, package com.myshop.app /671 /2.9.671 verified with AAPT2.156 Node tests pass; current source/financial locks,744 unrelated production file hashes,221 seat/camera-policy cases,4105 FULL-geometry cases,24 actual SQL free-theme cases and Admin Guardian controls pass. Final assembly reused previously passed preBuild checks (-x preBuild), then reran actual APK contents verification. See verification/V671-RESULTS.json.

Local APK is **UNSIGNED**,311+MB; original release keystore is not available here. No APK is bundled in this under25MB source archive. Do not install/distribute the unsigned local QA file. Existing GitHub original signing must build the matching new installable APK. No new signing key was created; no production push/deploy or phone/Agora acceptance is claimed. This source bundle still uses the documented pinned, hash-verified baseline-media restore and included generators; it is not an offline dependency bundle.

02 Guardian: native bounded30fps animated cyan/gold/violet halo and portrait glow around MS/default or rotating active member photos; no displayed member names; tap photo→profile, empty MS→duration catalog, long press/More→Guardian list.30/60/90-day drafts added without repricing/deleting existing plans. Admin must price/enable/publish. Admin Panel→Guardian provides background upload/publish, plan management, Host ID→member Remove/Restore. Remove hides display only; membership/expiry/paid history retained, no refund or permission grant. Clients refresh Guardian state on the existing30-second interval. Guardian membership never forces a seat/microphone/moderator authority. Fullscreen video has no central Guardian/profile overlay per17; video users can access Guardian from More.

03 Gift: fixed48dp rail artwork within the existing target; three small flowers rise by less than one-third of the box, settle/fade, lid closes;2-second closed pause. View visibility/detach pauses drawing. No gift financial/sound/send change.

06 Wallpaper: one root Wallpaper, internal Wallpaper/Animated Wallpaper tabs. Crystal1234→Rare ID; four useless red-heart shortcuts removed from the category rail only. Ownership/data preserved. Paid catalogs retain Admin price, days, approvals, gifts and expiry. All7 owner wallpaper drafts remain available to Admin to publish. Free themes are separate: Audio6 image+6 animated, Video6 image+6 animated, plus existing default. Admin uses Audio/Video and Wallpaper/Animated switches, chooses one of6 slots, uploads real media (MP4/WebM/GIF/WebP), enables and publishes. Server enforces free slot price0, authorization, room mode and disable fallback. Video poster generated/uploaded; preview is muted. Live videos never request audio focus or play sound, retain poster while preparing, time out to visible retry; stale transition/decoder resources released. Remote animated GIF/WebP uses the animation loader rather than static avatar loader. Profile→My Collection→Theme shows free and owned choices, mode labels, preview/apply; white/sky-blue background and horizontal unbroken tabs. Existing24-hour theme-choice reset and paid item expiry retained.

17 FULL video only: camera-off MAIN HOST tile reveals room theme and hides central portrait/name/wave. Microphone mute does not hide video. Guests and NORMAL/SIDE/GUEST/duel layouts retain previous fallbacks. Original three purple/white-chair seats retained. Comments are clipped below measured third seat. Existing cricket board/seat consent/voice/gift/RTC unchanged. Portrait fallback still applies to the normal layouts and disconnected-but-not-camera-off stream.

Remaining boundaries: No physical-phone/reference-animation approval, live server deployment, multi-phone sound/RTC test or signed APK delivery here. Full original rider cinematic quality is still partial at owner's requested freeze. All rejected/deferred tasks (including4,5,19,20) remain deferred; tap Gift Receipt is rejected. Historical notes below are retained for continuation, not current authorization/completion. Next changed delivery after this archive is actually delivered: **V-672**.

---

# V671 WORK CHECKPOINT — NOT A RELEASE / NOT APK-COMPLETE
Baseline: delivered V670. Owner explicitly said Bismillah start, follow photos/videos and tasks1→20 in strict sequence. No subagents, no production deployment. Latest actual delivery V670; final eventual name V-671-MY-SHOP-FULL-PACKAGE.zip. Do NOT deliver or upload this work checkpoint to the permanent production pipeline.

## Current stage: Task01/20 PARTIAL
Implemented source changes:
- Found entry renderer was declared but never called by Live render: now actual entryEvents are consumed after session/reset guards.
- New per-visit/per-session bounded32 event cursor pages, oldest first; removes9-second/largest8 loss for updated clients. Legacy cursorless clients retain previous response window.
- Queue accepts sorted unique IDs, never acknowledges events beyond capacity; drains/refills without second playback. Disabled entrance effect clears stage and advances server-provided watermark so reenable does not replay old disabled events. New(host_id,id) index additive only.
- Scene completion installed before attaching views; stale/double finish callbacks cannot clear a newer stage. Session cleanup stops current rider and its sound.
- Live-only focus loss completes entrance once; focus regain never replays it. Demo's deliberate replay path remains.
- No wallet/paid gift/owned-item writes added, no retirement/revocation, no mic/RTC/seat changes.

Actual verification: all155 root Node tests passed (including real SQL entry test), Java queue/delivery +actual RideEffectView callback/focus tests pass; existing2–8 participant RTC/publish/consent and221 seat-policy cases pass.309 Java sources parse and callback-context checks pass; this is NOT Android SDK compilation.
Initial Node failures: test module loader did not include new entry module; fixed loader to execute actual helper. Other two failures were missing inherited generated assets in fresh working copy; restored byte-identical outputs locally for QA. They remain generated/hash-restored build dependencies, not deleted required media.

FREE-ONLY CONTINUATION: Owner explicitly said no money; do not use paid generation or ask for upgrade. Original procedural CPU 3D study now implemented in tools/ride671/render_prototype.py: 72 motion frames, changing perspective, four rotating 3D wheels, five body materials; no downloaded model or old atlas recolor. Visually reviewed gold-study.png: geometry is angular/basic and does NOT meet cinematic reference quality. Intentionally NOT integrated into Android or claimed complete. Next improve geometry/material/light quality, then native integration and Demo/Live/sound verification only after quality review. Task1 remains PARTIAL; Task2 has not started. Original paid Runway attempt was rejected before a job and produced no media. Android build/signing and physical-device acceptance remain pending.

## OWNER PAUSED HERE — 2026-10-23
Owner explicitly asked to pause at the current point and never restart from the beginning. Pause is deliberate; do not continue feature work until owner says resume. No final file was delivered. Last actual delivery remains V670. Current Task01/20 PARTIAL, Tasks02–20 not started in this continuation. Owner wants no interim delivery and one file after all requested work is finished. Free/local tools only; no paid generation or upgrade requests.

### Changes since the first V671 checkpoint
- New RoadsterView671 TextureView/GLES2 renderer + bounded RoadsterMesh671 decoder. Original procedural roadster built from included Python source; four rotating wheels, curved body, material reflections and five body colours. <=24fps render loop, no remote video download/second decoder. Lifecycle closes EGL/thread on surface destruction; stops drawing/sound when consumed.
- Only R665_CAR_RED/BLUE/BLACK/WHITE/GOLD with their original myshop-ride://11 default use this candidate. Admin custom video, image or different native-slot choices retain their existing paths. No catalog prices, enable flags, IDs, ownership or expiry writes were made.
- Same Demo/Live renderer; movement and sound wait for first actual GLES frame. Continuous right→left motion with approach scale and saved animation_speed. One Live entry cannot replay after completion/focus loss. Added regression for focus loss BEFORE queued autoplay starts; late media callbacks cannot restart sound. Live missing avatar/name no longer defaults to the viewer's own identity.
- New generated original mesh is rebuilt locally by tools/ride671/export_mesh.py in <1s; prepare-build-assets.sh calls it. APK verifier checks renderer/queue DEX markers and the mesh. Actual original mesh has16278 vertices/28592 triangles; stored generated mesh format1. This original candidate is still visibly basic, not reference-quality acceptance.
- Found explicit workflow installs Build Tools36 while Gradle implicitly requested34; pinned buildToolsVersion36.0.0 to match workflow and avoid extra installation.

### Actual verification / unresolved build
- Actual RoadsterView671 + RoadsterMesh671 compiled against the REAL Android36 android.jar. Actual GLES2 vertex/fragment shaders compiled, linked and rendered the indexed mesh with GL_NO_ERROR under local Mesa EGL. No Android-device/RTC render acceptance claimed.
- Native decoder tests reject malformed header, huge counts, nonfinite data, bad indices, truncation/trailing bytes; all four wheel groups and repeatable generation checked. Actual RideEffectView lifecycle/sound tests passed, including before-start focus loss, duplicate completion, detached callbacks, native sound deferral and Admin mute. Queue/SQLite88-event tests passed. Latest source has311 Java files, syntax/context audits passed before final small changes; rerun at resume after source updates.
- Java compiler caught3 illegal forward references in the new GL class; fixed via a draw method. A final-field lambda initialization error in RideEffectView was caught and fixed with complete671() method. Do not revert these fixes.
- Full unsigned Android build is NOW POSSIBLE to attempt locally: SDK36 and Build Tools36 exist at ../android-qa/sdk. Official Gradle8.11.1 was downloaded from downloads.gradle.org, SHA256 matches wrapper pin, extracted under ../android-qa/gradle-8.11.1. Network via Python works; Java/Gradle needs proxy settings derived from urllib.getproxies(), no credentials printed.
- Full build progressed through actual resource/manifest/dependency/native-library tasks and preBuild checks, then failed BEFORE Java compilation because installed Java17 runtime lacks bin/javac/toolchain JAVA_COMPILER capability. jdk.compiler module works for direct java -m compiler checks. Last log ../v671-android-build.log; no APK produced. Need a real JDK17 installation, not changing app signing. Adoptium download attempt returned403 and was stopped at owner pause. /tmp/myshop-build671.py contains task-local nonsecret proxy/environment setup. No paid services or production deploy.
- One earlier build failed because source manifest changed during concurrent editing. Do NOT edit source while a verification build runs. Freeze edits, regenerate source manifest, then rerun. Current manifest regenerated for the paused source.

### Better FREE licensed-model candidate — NOT integrated
- Hand-modelled car study was not premium enough. Investigated Khronos ToyCar (CC0), rejected its old toy-car style. CarConcept looks substantially better; upstream is CC-BY-4.0, Eric Chadwick / Darmstadt Graphics Group GmbH2024, based on Unity Fan public-domain model. Never call this third-party model our original artwork. Attribution must be included if shipped.
- Pinned glTF Git blob SHA02c769342fd03da1a104f7671993fcfeb011a7d6 and BIN081d3598a400e43fbd6516c5036d2bbdf43ae96b, exact raw files in ../ride671-preview/concept-source.gltf and concept-source.bin. Direct urllib raw.githubusercontent.com succeeded; GitHub connector binary fetch cannot handle this size/encoding. Do not repeat failed connector binary routes.
- tools/ride671/import_licensed_concept.py creates format3 licensed candidate: transforms, quantization, removed logos/hidden parts, correct wheel groups/axes and stationary brake pads.119577vertices/172071triangles/92parts,1,385,071bytes. Native Android decoder currently accepts only format1, <=65535 vertices/64parts; format3 is only supported by desktop verify_gl.py. DO NOT copy it into runtime without extending native decoder, bounds tests, pivots/axes/batch offsets and APK verifier.
- /tmp/import_concept671_packed.py experiments with format4 component planes and delta-varint indices,1,122,150bytes, not yet supported by either native/desktop decoders. Full geometry retained. /tmp/import_concept671_qem.py uses fast-simplification0.1.13 (installed locally) and nearest normals;20% QEM output342173bytes but VISUAL FAIL: holes/cracks/ugly wheels. Do NOT ship QEM20 or claim quality. Desktop licensed full-model render looks materially better than original procedural car; still needs motion/native integration/performance/phone acceptance.
- Native GLES shader now supports arbitrary wheel axis/pivot; current original model still uses legacy Z axis/pivots. Desktop verify_gl.py supports formats1 and3, --mesh path and --frames. Internal videos native-motion-study-v2.mp4 show ORIGINAL procedural candidate, not licensed model. Do not label old preview as new licensed motion proof.

### Source-size research only — no baseline media altered
- Final canonicalZIP must stay<25,000,000bytes. No final package exists yet. Current private WIP archive may exceed this limit; do NOT upload it as release.
- Moon GIF (24frames460x760) is3,115,025bytes and~3,106,204ZIP bytes. A lossless animated WebP source is2,599,710bytes. /tmp/repack_moon671.py proved all24RGBA frames and durations EXACTLY unchanged after sourceWebP→exact indexed-colour GIF reconstruction (<=255colours per composed frame). ReconstructedGIF4,471,251bytes: larger at runtime, same decoded visuals/timing; NOT integrated. SourceWebP/proof are ../ride671-preview/moon-lossless.webp and moon-proof.json. Original GIF remains untouched in source/runtime. Need full baseline/proof/prepare handling before any storage conversion, especially API24 fallback. Prefer improve WebP compression/minimize_size first if needed.
- Seven design/owner665/*.mp4 frame inputs contain ~496KB unused audio total. Frame importer uses video only. Potential remux audio removal needs decoded frame/timestamp equivalence and exact generated-frame verification BEFORE changing pins/frameInputs. None changed. Do not strip runtime gift/ride/Live sound.

Next on owner resume: read this checkpoint; continue Task1. Resolve JDK17 and actual build; improve/free licensed-model integration and size without discarding required assets or history. Run appropriate target tests and true build. Do not advanceTask2 or mark all20complete based on these partial results. No final signed APK/device acceptance, no production deploy.

## Approved serial plan — all pending unless noted above
01 cinematic right-to-left rider, matching Demo/Live/sound, no lost/duplicate entries, preserve old purchases/expiry/history; PARTIAL as above.
02 Guardian: approved142534.mp4 animated frame around central MS/rotating Guardian photos; no names; portrait glow, tap profile.1/2/3month Admin-priced plans, renew, host-specific lists, HostRemove. Remove semantics(display-only vs relationship cancellation) still needs owner decision before that part. Guardian catalog blue reference background, Admin replaceable; Audio andVideo presentation. Rejected static Silver/Gold wing demo must not be used.
03 fixed-position larger gift rail icon; lid opens2–3smallflowersrise slightly/fall onto giftbox, close/fade, then2second pause; pause offscreen. No gift financial change.
04 giftcategoryALL first/default beforeFlower. RecipientALL separate.
05 full sender→recipient/gift/quantity/totalCoinOrGold text; wrap card height, no truncation/overlap; preserve commentflow/design. Separate tap GiftReceipt explicitly REJECTED.
06 Wallpapers: ONE rootWallpaper category, internalWallpaper/AnimatedWallpaper tabs.1234→RareID; remove4 red-heart shortcuts(RareID duplicate/MatchingSet/Cosmetics/Wishlist), keep data/ownership.7original clips paidcatalog/admin/demo/BuyGiftGrant/CollectionApplyExpiry. AdminAudio6still+6animated andVideo6still+6animated=24free slots+default; enabledslotsfreeallusers. This supersedes unclear4free remark. Remaining paidwallpapers Adminpriced/duration. Alwaysmutevideo; livevoice/giftsound unaffected. CatalogPreview withroomcontrols/dimmer/posterfallback/crop/Adminuploadvalidation, smoothready-switch, expirydefault, white–skyblue Collection clear labels/cards/no broken names.
07 sharedheader/navHome→myshop→Live→Video→Profile, properselectioncolor/routes, noSupport/More substitutions. Moon controls theme only. Video duplicateheader fix.
08 restore previous startup image advertisement; inspectAdminenable/publish/url/schedule/load; respect current Play policy, no unsolicited startup behavior.
09 official Seen removeshighlight only; permanentOfficialMessage conversation sortedbylatesttime, history; newunreadraiseshighlight; Admindelete. Existing unread-only disappearing behavior not final.
10 consensualPrivateTalk withinroom; no public microphone leakage; AcceptRejectEnd, restorepriorMicState; HostAllowcontrol. No phone privacy acceptance yet.
11 opt-inbirthdaycelebration photo/name/cake onceperday, birthyearprivate, profile/Admincontrols.
12 PKchallengecard opponent/time/challenge.
13 PKhistory opponent/scores/results.
14 Hostselected LiveQ&A.
15 Hosttriggered sharedconfetti.
16 seatwaitinglist +Hostinvite; no forcedcamera/mic.
17 ONLYFullscreenVideo: CameraOff→theme, no centralportrait; threepurple/whitechair guestseats unchanged; commentsstop atbelowthirdseat, cricketboardreadable. MicMute alone mustnot hidevideo. Otherlayouts/audio locked.
18 preLivefullscreenpreview/setup matching144754.mp4, Single/MultiAudioVideo/layouts/Theme/CameraMicTest/GoLive; preserve2/4/7/8+consent. Not runningroomredesign.
19 same-sessionAudio↔Video withallusers/state/timer/ledger/moderation retained, consent, enoughseats andfailure rollback.
20 ≤10sec mutedprofilevideo trim/preview/staticfallback; pendingmoderation beforepublish, rejectunsafe orAdminreview, ReportRemove; neverclaim100percent automaticdetection.

Historical V66731-task ledger remains authoritative unfinished backlog; do not silently drop. iOS excluded. Original signingidentity/package/D1R2 bindings/paidfinancialmethods locked. APK/phone acceptance absent; no remote push/deploy. Need genuine matching signed APK and one canonicalZIP<25,000,000bytes if possible; no deleting required source/media to force size. Existing root workflow deploys before APK and ZIP does not install a root workflow; do not claim build-only by embedding YAML.

## References inspected
Task1 cinematic144684.mp4(owner Librarylibfile_855490eb43ac8191a8a75635312e2c89), current144730.mp4(libfile_b92fbba08fe88191a81c4f0528ffa0f6).
Guardian142534.mp4(libfile_d75e1728d50c8191824f59631320c541), catalog144663.mp4(libfile_bce1d52b14fc8191849b1f97a7ea5f7f), current144733.mp4(libfile_8b79b95ad16881918ca6c724bf85845f).
Wallpaper144638.mp4(libfile_168e7585775c8191ae071c7a90c107de), catalog144742.mp4(libfile_810d0f0bb8cc8191a0655f7c4b74d688), nav144741.mp4(libfile_625e6fdaf94c81919e9d248ff64594aa), setup144754.mp4(libfile_378054f0faf48191955a27ec5a73cd60). Other owner images remain in conversation/Library.

## OWNER RESUMED — scoped delivery671
Only02→03→06→17 authorized, rider frozen at prior checkpoint.19 and other tasks deferred. Guardian Remove/Restore ADMIN ONLY per explicit owner correction; display control preserves purchases/expiry/history. Source edit ongoing, not completed.
