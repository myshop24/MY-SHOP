# MY SHOP Developer Handoff — V-268

## Current base
- Current source: **MY SHOP V-268**
- Android versionName: **2.9.268**
- Android versionCode: **268**
- Previous tested install base: V-266 (derived from stable V-263 lineage).

## Completed in V-268
1. Approved MY shop LIVE logo installed as launcher + Auth hero artwork.
2. Premium Login/Create Account layouts updated without replacing the existing backend auth logic.
3. Google + Facebook actions are deliberately reserved: both display short animated `UPCOMING` notices.
4. Security Question selector high-contrast/readability fix.
5. Dashboard user-card action buttons converted to a fixed reusable layout shell to prevent icon/text overflow.
6. Existing profile cover and live Friends/Followers/Following backend counts preserved.
7. Breaking News Admin controls: headline 10–24sp, text HEX color, background HEX color, preview, remote Save.
8. Worker `dashboard_config` additive fields: `breaking_news_bg_color`, `breaking_news_text_color`; schema repair supports existing D1 databases.

## Pending / intentionally disabled
- Real Google OAuth: disabled until configured; UI says UPCOMING.
- Real Facebook OAuth/Meta configuration: disabled until configured; UI says UPCOMING.
- Video Live remains disabled per project policy; Audio Live is the intended initial RTC mode.

## Exact checkpoint
V-268 source is ready for static validation and GitHub Actions compile/deploy. Do not rebuild from an older V-number. Continue only from V-268 or a later verified successor.

## Non-regression rules
- Do not remove working login/register/password-reset/backend/session behavior.
- Do not break fixed dashboard header/live/new-user layout or bottom navigation.
- Do not change the fixed user-card action shell when adding dashboard features.
- Do not make Breaking News styling APK-only; Admin/backend remote config is authoritative.
- Keep all source/version/Worker identity markers synchronized.
