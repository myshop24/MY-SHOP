# V-227 GitHub upload

Normal permanent flow:
1. Upload `V-227-MY-SHOP-UNIVERSAL-FEATURE-ADMIN-FIX-AUTO-BUILD-SAFE.zip` to the repository root.
2. The repository-root `.github/workflows/my-shop-apk.yml` selects the highest V-number source ZIP.
3. Build/sign V-227.
4. Download the artifact and install the APK.
5. Test functions separately from build status.

The repository-root workflow was already corrected so the downloaded artifact ZIP should contain only `MY_SHOP_FINAL_RELEASE.apk`.
