# MY SHOP V-227 BUILD NOTES

- Build target: Android release APK
- Package: `com.myshop.app`
- versionCode: `227`
- versionName: `2.9.227`
- Java: 17
- Gradle: 8.11.1
- Permanent signing key: existing cached key only; never regenerate for an update.
- Final user artifact: one APK only.

Build PASS and Function PASS are separate. See `V-227_BUILD_NOTES.md` for the V-227 feature changes and verification status.
