# MY SHOP Developer Handoff — V-325

## Scope locked for this version
Only the Admin **Gift Coin & Gold Coin Catalog** was changed in this version. No unrelated Live Room, dashboard, profile, navigation, or other feature redesign was intentionally added.

## Completed
- Admin page title remains **GIFT COIN & GOLD COIN CATALOG**.
- Two clear catalog tabs: **GIFT COIN** and **GOLD COIN**.
- Each tab loads every non-deleted gift in that currency catalog (up to the existing 50-gift limit).
- Gift list is simplified to premium summary cards; tapping a gift opens its full editor.
- Full editor preserves name, price, category, preview/image, live animation, catalog animation, sound, publish, order/box position, and Add/Edit/Delete/Save/Publish controls.
- Added per-gift Sound Volume 0–100%.
- Added per-gift Sound Duration in seconds.
- Added sound Start/End trim controls and a trimmed-sound preview. Live playback respects the selected trim range without creating duplicate media files.
- Added gift effect duration in seconds.
- Added Live board visual size 0–100% and board position (CENTER / TOP / BOTTOM / FULL_SCREEN).
- Added per-gift VAT 0–100%.
- Added catalog-wide VAT control to apply one VAT percentage to every Gift Coin gift or every Gold Coin gift in the selected catalog.
- Per-gift VAT is used for the platform share on normal live-gift sends; fixed Main Admin sends retain the existing fee exemption.
- Existing 50-gift-per-currency limit and separate Coin / Gold Coin catalogs remain intact.

## Backend additions
`myshop_live_gifts` gains safe additive columns through `ensureLiveRoomSchema`: `sound_trim_start_pct`, `sound_trim_end_pct`, `vat_percent`, `board_position`.
A protected admin endpoint `/v1/admin/live/gifts/bulk-vat` applies VAT to one selected currency catalog.

## Regression safety
The change is intentionally focused on the gift catalog. Existing D1 tables are not dropped or recreated. Existing gift records receive defaults through additive ALTER statements.

## Validation status
- Worker JavaScript syntax: PASS (`node --check`).
- Gift INSERT placeholder/bind count: PASS (29/29).
- Version identity: V-325 / 2.9.325 / versionCode 325.
- Android full compile: requires the normal GitHub Actions Android build environment.
- Real-device verification still required for audio trim playback, R2 upload, and admin catalog interaction.
