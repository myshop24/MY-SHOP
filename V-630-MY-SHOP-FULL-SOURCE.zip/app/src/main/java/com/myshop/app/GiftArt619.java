package com.myshop.app;
import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Animatable;
import android.os.SystemClock;
/** Six original free procedural mesh samples. This is not a rendered-video asset or all200 gifts. */
final class GiftArt619 extends Drawable implements Animatable {
 private final String type;private final boolean allowed;private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);private boolean running,loop=true;private int durationMs=3200;private long started;private final Runnable tick=()->{if(running&&isVisible()&&getCallback()!=null)invalidateSelf();};
 GiftArt619(Context c,String uri,boolean autoplay){String requested=android.net.Uri.parse(uri).getHost();String chosen="diamond";for(String name:GiftMesh619.TYPES)if(name.equals(requested))chosen=name;type=chosen;allowed=!c.getSharedPreferences("myshop_accessibility",0).getBoolean("reduce_animation",false);if(autoplay&&allowed)start();}
 public void draw(Canvas canvas){Rect bounds=getBounds();int saved=canvas.save();canvas.clipRect(bounds);double elapsed=(SystemClock.uptimeMillis()-started)/(double)durationMs;double phase=running?(loop?elapsed%1:Math.min(1,elapsed)):(loop?.5:1);float unit=Math.min(bounds.width(),bounds.height())*.244f,cx=bounds.exactCenterX(),cy=bounds.exactCenterY()+bounds.height()*.025f;
 for(GiftMesh619.Face face:GiftMesh619.sorted(GiftMesh619.scene(type,phase))){Path path=new Path();int n=0;for(double[] point:face.points){double[] q=GiftMesh619.project(point);float x=cx+(float)q[0]*unit,y=cy-(float)q[1]*unit;if(n++==0)path.moveTo(x,y);else path.lineTo(x,y);}path.close();paint.setColor(GiftMesh619.shade(face));paint.setStyle(Paint.Style.FILL);canvas.drawPath(path,paint);}
 int[] colors={0xffffdd71,0xffff49ba,0xff74dfff,0xffe1faff,0xffff6e2a};for(double[] point:GiftMesh619.sparks(type,phase)){float x=cx+(float)point[0]*unit,y=cy-(float)point[1]*unit,r=Math.max(.7f,unit*.014f*(float)point[2]);paint.setColor(colors[(int)point[3]]);paint.setAlpha((int)(255*point[2]));canvas.drawCircle(x,y,r,paint);paint.setStrokeWidth(Math.max(.6f,r*.3f));canvas.drawLine(x-r*2,y,x+r*2,y,paint);canvas.drawLine(x,y-r*2,x,y+r*2,paint);}paint.setAlpha(255);canvas.restoreToCount(saved);if(running&&!loop&&elapsed>=1){running=false;}if(running&&getCallback()!=null&&isVisible()){unscheduleSelf(tick);scheduleSelf(tick,SystemClock.uptimeMillis()+42);}}
 void playOnce(int duration){durationMs=Math.max(500,Math.min(15000,duration));loop=false;start();}
 public void start(){if(!allowed)return;running=true;started=SystemClock.uptimeMillis();invalidateSelf();}public void stop(){running=false;unscheduleSelf(tick);}public boolean isRunning(){return running;}
 @Override public boolean setVisible(boolean visible,boolean restart){boolean changed=super.setVisible(visible,restart);if(!visible)unscheduleSelf(tick);else if(running){if(restart)started=SystemClock.uptimeMillis();invalidateSelf();}return changed;}
 public void setAlpha(int alpha){}public void setColorFilter(ColorFilter filter){}public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
