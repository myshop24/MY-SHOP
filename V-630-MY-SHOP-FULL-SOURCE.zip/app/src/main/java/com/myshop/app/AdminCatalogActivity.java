package com.myshop.app;

import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** V-566: one four-part Admin catalog over the existing, permission-checked modules. */
public class AdminCatalogActivity extends androidx.appcompat.app.AppCompatActivity {
    private static final String PREFS = "myshop_admin_catalog_v566";
    private static final int NAVY = 0xff17223f;
    private static final int MUTED = 0xff6e7890;
    private LinearLayout catalogHost;
    private boolean dragging;

    private static final class Folder {
        final String id, label, route, notice, icon;
        Folder(String id, String label, String route, String notice, String icon) {
            this.id=id; this.label=label; this.route=route; this.notice=notice; this.icon=icon;
        }
    }
    private static final class Catalog {
        final String id, title, subtitle;
        final int color;
        final ArrayList<Folder> folders;
        Catalog(String id, String title, String subtitle, int color, Folder... folders) {
            this.id=id; this.title=title; this.subtitle=subtitle; this.color=color;
            this.folders=new ArrayList<>(Arrays.asList(folders));
        }
    }

    private final ArrayList<Catalog> catalogs = new ArrayList<>();
    private Catalog[] seed() {
        Catalog finance = new Catalog("finance", "আয়-ব্যয় ও বিক্রি", "FINANCE & SALES", 0xff17202f,
            f("income","মোট আয়","finance","NONE","coins"), f("expenses","মোট ব্যয়","finance","NONE","tasks"),
            f("commission","MY SHOP কমিশন","finance","NONE","tag"), f("sales","মোট সেলস","finance","NONE","bag"),
            f("coin_sales","Coin বিক্রি","finance","NONE","coins"), f("gold_sales","Diamond বিক্রি","finance","NONE","gem"),
            f("creator","Creator আয়","finance","NONE","star"), f("withdraw_summary","উত্তোলন সারাংশ","finance","WITHDRAW","history"),
            f("gifts","গিফট হিসাব","finance","NONE","gift"), f("transfers","ট্রান্সফার হিসাব","finance","NONE","share"),
            f("refund_summary","রিফান্ড সারাংশ","finance","NONE","shield"), f("ledger","ইউজার লেজার","history","NONE","people"));
        Catalog requests = new Catalog("requests", "MY SHOP রিকোয়েস্ট", "REQUESTS", 0xff48a7dc,
            f("withdraw","উত্তোলন","payout","WITHDRAW","gem"), f("membership","মেম্বারশিপ","membership","PREMIUM_MEMBERSHIP","crown"),
            f("badge","ব্লু ব্যাজ","badge","NONE","shield"), f("feature_request","সাধারণ ফিচার","requests","ALL","tasks"),
            f("verification","প্রোফাইল যাচাই","users","NONE","people"), f("support","সাপোর্ট টিকিট","support","SUPPORT","headphones"),
            f("post_reports","পোস্ট রিপোর্ট","reports","REPORT","page"), f("video_reports","ভিডিও রিপোর্ট","reports","REPORT","play"),
            f("appeals","অ্যাকাউন্ট আপিল","reports","REPORT","shield"), f("user_reports","ইউজার রিপোর্ট","reports","REPORT","people"),
            f("other_requests","অন্যান্য","requests","ALL","more"), f("request_history","রিকোয়েস্ট ইতিহাস","history","NONE","history"));
        Catalog superAdmin = new Catalog("super", "সুপার এডমিন", "SUPER ADMIN", 0xff80593f,
            f("master_features","Master Feature Controls","master_features","NONE","tasks"), f("platform","প্ল্যাটফর্ম","system","NONE","globe"), f("users","মূল ইউজার নিয়ন্ত্রণ","users","NONE","people"),
            f("special_user_id","বিশেষ ID তৈরি","special_user_id","NONE","people"), f("admin_moderators","এডমিন / মডারেটর","admin_roles","NONE","shield"), f("live","লাইভ","live","NONE","live"),
            f("coin_settings","Coin / Diamond","coin_catalog","NONE","coins"), f("gifts_transfers","গিফট / ট্রান্সফার","finance","NONE","gift"),
            f("moderation_history","মডারেশন / এডমিন-Moderator ইতিহাস","audit","NONE","history"), f("content","কনটেন্ট / ফিড","content","NONE","gallery"),
            f("banners","ব্যানার","banners","NONE","gallery"), f("mini_ads","মিনি কার্ড বিজ্ঞাপন","mini","NONE","play"),
            f("themes","থিম","themes","NONE","star"), f("notifications","নোটিফিকেশন / স্বাস্থ্য","system","NONE","tasks"),
            f("headline_strip","চলমান হেডলাইন","headline","NONE","tasks"),
            f("menu_design","মেনু ও আইকন ডিজাইন","design","NONE","star"),f("withdrawal_qr","উত্তোলন ও QR","qr","NONE","gem"),f("home_whatsapp","হোম WhatsApp","whatsapp","NONE","headphones"));
        Catalog shop = new Catalog("ecommerce", "MY SHOP ই-কমার্স", "E-COMMERCE ADMIN", 0xff57362e,
            f("store_products","দোকানের পণ্য","shop_products","NONE","bag"), f("orders","অর্ডার","orders","ORDER","tasks"),
            f("stock","স্টক","shop_products","NONE","tag"), f("categories","ক্যাটাগরি","shop_products","NONE","more"),
            f("sellers","বিক্রেতা","shop_products","NONE","people"), f("approval","পণ্য অনুমোদন","shop_products","NONE","shield"),
            f("delivery","ডেলিভারি","orders","ORDER","share"), f("returns","রিটার্ন","orders","ORDER","history"),
            f("refunds","রিফান্ড","orders","ORDER","coins"), f("offers","কুপন / অফার","shop_products","NONE","tag"),
            f("store_banners","দোকানের ব্যানার","banners","NONE","gallery"), f("sales_reports","বিক্রির রিপোর্ট","finance","NONE","history"));
        superAdmin.folders.add(f("module_page1_icons","পেইজ ১ • আইকন ও পজিশন","module:page1_icons","NONE","tasks"));
        superAdmin.folders.add(f("module_dashboard","পেইজ ১ • হেডলাইন","module:dashboard","NONE","tasks"));
        superAdmin.folders.add(f("module_live_home_page","পেইজ ২ • ২০টি ব্যানার","module:live_home_page","NONE","tasks"));
        superAdmin.folders.add(f("module_page2_icons","পেইজ ২ • আইকন ও পজিশন","module:page2_icons","NONE","tasks"));
        superAdmin.folders.add(f("commission_management","কমিশন ম্যানেজমেন্ট","commission_management","NONE","tag"));
        finance.folders.add(f("module_payment_methods","পেমেন্ট পদ্ধতি","module:payment_methods","NONE","tasks"));
        finance.folders.add(f("module_admin_wallet","ইউজারকে Coin / Diamond দিন","module:admin_wallet","NONE","tasks"));
        superAdmin.folders.add(f("module_highlight_settings","হাইলাইট কমেন্ট ফি ও হোস্টের ভাগ","module:highlight_settings","NONE","live"));
        superAdmin.folders.add(f("module_live_comments","লাইভ কমেন্ট ও ব্যানার","module:live_comments","NONE","live"));
        superAdmin.folders.add(f("module_live_themes","অডিও লাইভ থিম","module:live_themes","PREMIUM_THEME","live"));
        superAdmin.folders.add(f("module_membership_admin","মেম্বারশিপ ম্যানেজমেন্ট","module:membership_admin","PREMIUM_MEMBERSHIP","live"));
        superAdmin.folders.add(f("module_entry_ride","রাইড / এন্ট্রি ম্যানেজমেন্ট","module:entry_ride","PREMIUM_RIDE","live"));
        superAdmin.folders.add(f("module_wallpaper_admin","ওয়ালপেপার ম্যানেজমেন্ট","module:wallpaper_admin","PREMIUM_WALLPAPER","live"));
        superAdmin.folders.add(f("module_live_music","স্থায়ী মিউজিক লাইব্রেরি","module:live_music","NONE","live"));
        superAdmin.folders.add(f("module_upcoming_live","Home Upcoming Live","module:upcoming_live","NONE","tasks"));
        superAdmin.folders.add(f("module_upcoming_live_page","Live Page Upcoming Live","module:upcoming_live_page","NONE","tasks"));
        superAdmin.folders.add(f("module_gallery","গ্যালারি ম্যানেজমেন্ট","module:gallery","NONE","gallery"));
        superAdmin.folders.add(f("module_ads","ড্যাশবোর্ড বিজ্ঞাপন","module:ads","NONE","gallery"));
        superAdmin.folders.add(f("module_content_translations","কনটেন্টের চার ভাষা","module:content_translations","NONE","tasks"));
        superAdmin.folders.add(f("module_features","ফিচার ম্যানেজমেন্ট","module:features","NONE","tasks"));
        superAdmin.folders.add(f("module_dynamic_content","ড্যাশবোর্ড ছোট ফিচার স্লট","module:dynamic_content","NONE","tasks"));
        superAdmin.folders.add(f("module_social","সোশ্যাল লিংক","module:social","NONE","tasks"));
        superAdmin.folders.add(f("module_external_movie","এক্সটার্নাল মুভি","module:external_movie","NONE","tasks"));
        superAdmin.folders.add(f("module_more_apps","আরও অ্যাপ","module:more_apps","NONE","tasks"));
        superAdmin.folders.add(f("module_startup_ads","অ্যাপ ওপেন বিজ্ঞাপন","module:startup_ads","NONE","gallery"));
        requests.folders.add(f("module_feed_moderation","MY FEED মডারেশন","module:feed_moderation","REPORT","tasks"));
        return new Catalog[]{finance,requests,superAdmin,shop};
    }
    private static Folder f(String id,String label,String route,String notice,String icon){return new Folder(id,label,route,notice,icon);}

    private int dp(float n) { return Math.round(n * AdminAppearance.zoom(this) * getResources().getDisplayMetrics().density); }
    private TextView text(String s,float sp,int color,boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp*AdminAppearance.zoom(this)); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
        return t;
    }
    private GradientDrawable rounded(int fill,int stroke,int radius) {
        GradientDrawable d=new GradientDrawable(); d.setColor(fill); d.setCornerRadius(dp(radius));
        if(stroke!=0)d.setStroke(dp(1),stroke); return d;
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        if(!SessionManager.isAdmin(this)){finish();return;}
        if(!SessionManager.isAdminGateUnlocked()){startActivity(new Intent(this,AdminGateActivity.class));finish();return;}
        catalogs.clear(); catalogs.addAll(Arrays.asList(seed()));
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(12),dp(10),dp(12),dp(24));page.setBackgroundColor(AdminAppearance.background(this));
        int ink=AdminAppearance.ink(AdminAppearance.background(this));
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
        TextView menu=text("☰",25,ink,true);menu.setContentDescription("Admin shortcut menu");menu.setOnClickListener(v->showShortcutMenu());header.addView(menu,new LinearLayout.LayoutParams(dp(42),dp(48)));
        TextView title=text("MY SHOP 👑\nADMIN PANEL",16,ink,true);title.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);header.addView(title,new LinearLayout.LayoutParams(0,dp(58),1));
        TextView themes=text("◐",24,ink,true);themes.setContentDescription("Admin theme");themes.setOnClickListener(v->AdminAppearance.theme(this,this::recreate));header.addView(themes,new LinearLayout.LayoutParams(dp(42),dp(48)));
        TextView language=text(AdminAppearance.english(this)?"EN":"বাংলা",11,ink,true);language.setOnClickListener(v->AdminAppearance.language(this,this::recreate));header.addView(language,new LinearLayout.LayoutParams(dp(44),dp(48)));page.addView(header);
        TextView helper=text(AdminAppearance.english(this)?"Hold folders to reorder · Personal Admin layout":"ফোল্ডার চেপে ধরে সাজান • ব্যক্তিগত এডমিন লেআউট",11,ink,false);page.addView(helper,new LinearLayout.LayoutParams(-1,dp(36)));
        TextView zoom=text("−  "+Math.round(AdminAppearance.zoom(this)*100)+"%  +",12,ink,true);zoom.setContentDescription("Admin display zoom");zoom.setOnClickListener(v->AdminAppearance.zoom(this,this::recreate));page.addView(zoom,new LinearLayout.LayoutParams(-1,dp(40)));
        if(AuthorityBadge.isAuthority(SessionManager.getUserId(this))){Button drafts=new Button(this);drafts.setText("Saved Draft Review • সব সংরক্ষিত Draft");drafts.setOnClickListener(v->startActivity(new Intent(this,AdminDraftReviewActivity.class)));page.addView(drafts,new LinearLayout.LayoutParams(-1,dp(48)));}
        if(AuthorityBadge.isAuthority(SessionManager.getUserId(this))){Button menuEditor=new Button(this);menuEditor.setText("Profile Menu • Name / Icon / Visibility / Order");menuEditor.setOnClickListener(v->startActivity(new Intent(this,ProfileMenuAdminActivity.class)));page.addView(menuEditor,new LinearLayout.LayoutParams(-1,dp(48)));}
        Button dashboard=new Button(this);dashboard.setAllCaps(false);dashboard.setText("পূর্ণ Admin Dashboard খুলুন ›");dashboard.setTextColor(Color.WHITE);dashboard.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff1768db));dashboard.setOnClickListener(v->startActivity(new Intent(this,AdminHubActivity.class).putExtra("gate_passed",true)));page.addView(dashboard,new LinearLayout.LayoutParams(-1,dp(52)));
        if(AuthorityBadge.isAuthority(SessionManager.getUserId(this))){Button legacy=new Button(this);legacy.setAllCaps(false);legacy.setText("সুপার এডমিন • আগের Dashboard খুলুন ›");legacy.setOnClickListener(v->startActivity(new Intent(this,SuperAdminActivity.class)));page.addView(legacy,new LinearLayout.LayoutParams(-1,dp(48)));}
        catalogHost=new LinearLayout(this); catalogHost.setOrientation(LinearLayout.VERTICAL); page.addView(catalogHost,new LinearLayout.LayoutParams(-1,-2));
        scroll.addView(page);Appearance.preserve(page);scroll.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());return insets;});setContentView(scroll);scroll.requestApplyInsets(); render();
    }

    private void render() {
        if(catalogHost==null)return; AdminNoticeBadge.reset(this); catalogHost.removeAllViews(); restoreCatalogOrder();
        for(int i=0;i<catalogs.size();i++) {
            Catalog c=catalogs.get(i); LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(10),dp(11),dp(10),dp(12)); card.setBackground(rounded(AdminAppearance.card(this),0,20)); Appearance.preserve(card); card.setElevation(dp(2)); card.setTag(c.id);
            TextView h=text(AdminAppearance.english(this)?c.subtitle:c.title,18,AdminAppearance.ink(AdminAppearance.card(this)),true); h.setGravity(Gravity.CENTER); card.addView(h,new LinearLayout.LayoutParams(-1,dp(30)));
            TextView sub=text(c.subtitle,10,AdminAppearance.ink(AdminAppearance.card(this)),true); sub.setLetterSpacing(.12f); card.addView(sub,new LinearLayout.LayoutParams(-1,dp(20)));
            if(c.folders.size()>12){TextView count=text("+ "+(c.folders.size()-12)+" ফোল্ডার",10,AdminAppearance.ink(AdminAppearance.card(this)),false);card.addView(count);}
            LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL); card.addView(grid,new LinearLayout.LayoutParams(-1,-2));
            ArrayList<Folder> folders=folderOrder(c);int columns=AdminAppearance.zoom(this)>1?3:4;int rows=(folders.size()+columns-1)/columns;
            for(int r=0;r<rows;r++) {
                LinearLayout line=new LinearLayout(this); line.setOrientation(LinearLayout.HORIZONTAL); line.setGravity(Gravity.CENTER_VERTICAL);
                LinearLayout.LayoutParams lineLp=new LinearLayout.LayoutParams(-1,dp(94)); if(r>0)lineLp.topMargin=dp(3); grid.addView(line,lineLp);
                for(int col=0;col<columns;col++) {
                    int at=r*columns+col; if(at>=folders.size()){line.addView(new View(this),new LinearLayout.LayoutParams(0,-1,1f));continue;} Folder item=folders.get(at);
                    LinearLayout cell=new LinearLayout(this); cell.setOrientation(LinearLayout.VERTICAL); cell.setGravity(Gravity.CENTER); cell.setPadding(dp(2),dp(4),dp(2),dp(3));
                    cell.setBackground(rounded(Color.TRANSPARENT,0,14)); cell.setTag(c.id+"|"+item.id); cell.setContentDescription(item.label+" folder");
                    FrameLayout iconBox=new FrameLayout(this); iconBox.setBackgroundColor(Color.TRANSPARENT);
                    ImageView icon=new ImageView(this); PremiumFolderIcons.apply(icon,item.icon); icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE); icon.setPadding(0,0,0,0);
                    iconBox.addView(icon,new FrameLayout.LayoutParams(-1,-1)); cell.addView(iconBox,new LinearLayout.LayoutParams(dp(48),dp(48)));
                    TextView label=text(folderLabel(item),11,AdminAppearance.ink(AdminAppearance.card(this)),true); label.setMaxLines(2); label.setEllipsize(android.text.TextUtils.TruncateAt.END);
                    LinearLayout.LayoutParams textLp=new LinearLayout.LayoutParams(-1,dp(31)); textLp.topMargin=dp(3); cell.addView(label,textLp);
                    if("users".equals(item.id)){cell.setBackground(rounded(0xffdc2338,0,14));label.setTextColor(Color.WHITE);Appearance.preserve(cell);Appearance.preserve(label);}
                    if(!"NONE".equals(item.notice))AdminNoticeBadge.attachCount(this,iconBox,item.notice);
                    cell.setOnClickListener(v->{if(dragging)return;open(item);});
                    cell.setOnLongClickListener(v->{dragging=true;ClipData data=ClipData.newPlainText("admin-folder",c.id+"|"+item.id);v.startDragAndDrop(data,new View.DragShadowBuilder(v),null,0);return true;});
                    cell.setOnDragListener((v,e)->handleFolderDrop(c,item,e));
                    LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-1,1f);cp.setMargins(dp(2),0,dp(2),0);line.addView(cell,cp);
                }
            }
            card.setOnLongClickListener(v->{dragging=true;ClipData data=ClipData.newPlainText("admin-card","card:"+c.id);v.startDragAndDrop(data,new View.DragShadowBuilder(v),null,0);return true;});
            card.setOnDragListener((v,e)->handleCardDrop(c,e));
            LinearLayout.LayoutParams cardLp=new LinearLayout.LayoutParams(-1,-2);cardLp.topMargin=dp(i==0?10:12);catalogHost.addView(card,cardLp);
        }
        catalogHost.setOnDragListener((v,e)->handleCatalogDrop(e));
        AdminNoticeBadge.refresh(this);
    }

    private String folderLabel(Folder folder){if(!AdminAppearance.english(this))return folder.label;String label=folder.id.replace("module_", "").replace('_',' ');return Character.toUpperCase(label.charAt(0))+label.substring(1);}
    private void showShortcutMenu(){
        ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);scroll.addView(list);
        android.app.AlertDialog dialog=new MyShopDialogBuilder(this).setTitle("MY SHOP · Admin Folders").setView(scroll).setNegativeButton("Close",null).create();
        for(Catalog group:catalogs){TextView heading=text(AdminAppearance.english(this)?group.subtitle:group.title,15,NAVY,true);list.addView(heading,new LinearLayout.LayoutParams(-1,dp(44)));for(Folder folder:folderOrder(group)){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),0,dp(10),0);FrameLayout iconBox=new FrameLayout(this);ImageView icon=new ImageView(this);PremiumFolderIcons.apply(icon,folder.icon);iconBox.addView(icon,new FrameLayout.LayoutParams(-1,-1));row.addView(iconBox,new LinearLayout.LayoutParams(dp(40),dp(40)));TextView label=text(folderLabel(folder),12,NAVY,true);label.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);row.addView(label,new LinearLayout.LayoutParams(0,dp(52),1));if(!"NONE".equals(folder.notice))AdminNoticeBadge.attachCount(this,iconBox,folder.notice);row.setOnClickListener(v->{dialog.dismiss();open(folder);});list.addView(row);}}
        dialog.setOnDismissListener(d->render());dialog.show();AdminNoticeBadge.refresh(this);
    }

    private int iconFor(String key) {
        switch(key) {
            case "bag":return R.drawable.premium438_bag; case "coins":return R.drawable.premium438_coins;
            case "gem":return R.drawable.profile_withdraw_card; case "tasks":return R.drawable.premium540_tasks;
            case "tag":return R.drawable.premium438_tag; case "star":return R.drawable.premium438_star;
            case "history":return R.drawable.dashboard_history_3d; case "gift":return R.drawable.premium438_gift;
            case "share":return R.drawable.premium438_share; case "shield":return R.drawable.premium540_shield;
            case "people":return R.drawable.premium438_people; case "crown":return R.drawable.premium438_crown;
            case "headphones":return R.drawable.premium438_headphones; case "play":return R.drawable.premium438_play;
            case "globe":return R.drawable.premium438_globe; case "live":return R.drawable.premium438_live;
            case "gallery":return R.drawable.premium438_gallery; case "page":return R.drawable.premium438_page;
            default:return R.drawable.premium438_more;
        }
    }
    private boolean handleFolderDrop(Catalog targetGroup,Folder target,android.view.DragEvent e) {
        switch(e.getAction()) {
            case android.view.DragEvent.ACTION_DRAG_STARTED:return e.getClipDescription()!=null;
            case android.view.DragEvent.ACTION_DRAG_ENTERED:return true;
            case android.view.DragEvent.ACTION_DRAG_EXITED:return true;
            case android.view.DragEvent.ACTION_DROP:
                String raw=e.getClipData().getItemAt(0).getText().toString();String[] parts=raw.split("\\|",2);
                if(parts.length==2&&parts[0].equals(targetGroup.id)){moveFolder(targetGroup,parts[1],target.id);}
                dragging=false;return true;
            case android.view.DragEvent.ACTION_DRAG_ENDED:dragging=false;return true;
            default:return true;
        }
    }
    private boolean handleCardDrop(Catalog target,android.view.DragEvent e){
        if(e.getAction()==android.view.DragEvent.ACTION_DROP){String id=e.getClipData().getItemAt(0).getText().toString();if(id.startsWith("card:"))moveCatalog(id.substring(5),target.id);dragging=false;return true;}
        if(e.getAction()==android.view.DragEvent.ACTION_DRAG_ENDED)dragging=false;
        return e.getAction()==android.view.DragEvent.ACTION_DRAG_STARTED||e.getAction()==android.view.DragEvent.ACTION_DRAG_ENTERED||e.getAction()==android.view.DragEvent.ACTION_DRAG_EXITED;
    }
    private boolean handleCatalogDrop(android.view.DragEvent e){
        if(e.getAction()==android.view.DragEvent.ACTION_DROP){String id=e.getClipData().getItemAt(0).getText().toString();if(id.startsWith("card:")){String target="finance";for(Catalog c:catalogs){View v=catalogHost.findViewWithTag(c.id);if(v!=null&&e.getY()<=v.getBottom()){target=c.id;break;}}moveCatalog(id.substring(5),target);}dragging=false;return true;}
        if(e.getAction()==android.view.DragEvent.ACTION_DRAG_ENDED)dragging=false;
        return e.getAction()==android.view.DragEvent.ACTION_DRAG_STARTED||e.getAction()==android.view.DragEvent.ACTION_DRAG_ENTERED||e.getAction()==android.view.DragEvent.ACTION_DRAG_EXITED;
    }
    private void moveCatalog(String from,String before){int a=indexCatalog(from),b=indexCatalog(before);if(a<0||b<0||a==b)return;Catalog item=catalogs.remove(a);catalogs.add(b,item);saveCatalogOrder();render();}
    private int indexCatalog(String id){for(int i=0;i<catalogs.size();i++)if(catalogs.get(i).id.equals(id))return i;return -1;}
    private void moveFolder(Catalog group,String from,String before){ArrayList<Folder> a=folderOrder(group);int i=indexFolder(a,from),j=indexFolder(a,before);if(i<0||j<0||i==j)return;Folder moved=a.remove(i);a.add(j,moved);StringBuilder s=new StringBuilder();for(Folder f:a){if(s.length()>0)s.append(',');s.append(f.id);}prefs().edit().putString("folders_"+group.id,s.toString()).apply();render();}
    private int indexFolder(List<Folder> list,String id){for(int i=0;i<list.size();i++)if(list.get(i).id.equals(id))return i;return -1;}
    private void saveCatalogOrder(){StringBuilder s=new StringBuilder();for(Catalog c:catalogs){if(s.length()>0)s.append(',');s.append(c.id);}prefs().edit().putString("catalog_order",s.toString()).apply();}
    private void restoreCatalogOrder(){String raw=prefs().getString("catalog_order","");if(raw.isEmpty())return;String[] ids=raw.split(",");Collections.sort(catalogs,Comparator.comparingInt(c->{for(int i=0;i<ids.length;i++)if(ids[i].equals(c.id))return i;return ids.length;}));}
    private ArrayList<Folder> folderOrder(Catalog c){ArrayList<Folder> out=new ArrayList<>(c.folders);String raw=prefs().getString("folders_"+c.id,"");if(raw.isEmpty())return out;String[] ids=raw.split(",");Collections.sort(out,Comparator.comparingInt(f->{for(int i=0;i<ids.length;i++)if(ids[i].equals(f.id))return i;return ids.length;}));return out;}
    private SharedPreferences prefs(){return getSharedPreferences(PREFS,MODE_PRIVATE);}
    private void open(Folder folder){
        Intent i;
        if(folder.route.startsWith("module:")){startActivity(new Intent(this,AdminHubActivity.class).putExtra("gate_passed",true).putExtra("open_module",folder.route.substring(7)));return;}
        switch(folder.route){
            case "commission_management":i=new Intent(this,CommissionManagementActivity.class);break;
            case "master_features":i=new Intent(this,MasterFeatureAdminActivity.class);break;
            case "design":i=new Intent(this,PanelDesignAdminActivity.class).putExtra("scope","home_quick");break;
            case "qr":i=new Intent(this,PanelDesignAdminActivity.class).putExtra("scope","withdrawal");break;
            case "whatsapp":i=new Intent(this,PanelDesignAdminActivity.class).putExtra("scope","home_support");break;
            case "finance":i=new Intent(this,(folder.id.equals("income")||folder.id.equals("expenses")||folder.id.equals("sales")||folder.id.equals("sales_reports"))?AdminAccountingActivity.class:AdminFinanceActivity.class);break;
            case "commerce":i=new Intent(this,AdminFinanceActivity.class);break;
            case "history":i=new Intent(this,UserHistoryAdminActivity.class);break;
            case "payout":new MyShopDialogBuilder(this).setTitle("Withdraw Management").setItems(new String[]{"Withdraw Requests • Pending / Review / Paid / Rejected","Withdraw Settings • Coin / Diamond / Methods / Rates"},(d,n)->startActivity(n==0?new Intent(this,PayoutInboxActivity.class).putExtra("admin",true):new Intent(this,WithdrawalCatalogAdminActivity.class))).show();return;
            case "membership":i=new Intent(this,AdminRequestCenterActivity.class);break;
            case "badge":i=new Intent(this,BlueBadgeAdminActivity.class);break;
            case "requests":i=new Intent(this,AdminRequestCenterActivity.class);break;
            case "special_user_id":i=new Intent(this,AdminSpecialIdActivity.class);break;
            case "users":i=new Intent(this,AdminUserControlActivity.class);break;
            case "support":i=new Intent(this,AdminSectionActivity.class).putExtra("section","help_support").putExtra("admin_context",true);break;
            case "reports":i=new Intent(this,AdminSafetyActivity.class);break;
            case "audit":i=new Intent(this,AdminModerationHistoryActivity.class);break;
            case "system":i=new Intent(this,AdminSystemHealthActivity.class);break;
            case "live":i=new Intent(this,AdminHubActivity.class).putExtra("gate_passed",true).putExtra("admin_context",true);break;
            case "coin_catalog":i=new Intent(this,CoinGoldCatalogActivity.class);break;
            case "content":i=new Intent(this,AdminHubActivity.class).putExtra("gate_passed",true).putExtra("admin_context",true);break;
            case "banners":if("store_banners".equals(folder.id))i=new Intent(this,LiveHomeAdminActivity.class).putExtra("folder","shop_home").putExtra("folderTitle","Shop Home Banner Line");else i=new Intent(this,BannerAdminActivity.class);break;
            case "mini":i=new Intent(this,MiniAdAdminActivity.class);break;
            case "headline":i=new Intent(this,HeadlineStripAdminActivity.class);break;
            case "themes":i=new Intent(this,AppThemeAdminActivity.class);break;
            case "orders":i=new Intent(this,PhysicalStoreActivity.class).putExtra("admin",true).putExtra("openOrders",true);break;
            case "shop_products":i=new Intent(this,PhysicalStoreActivity.class).putExtra("admin",true);break;
            case "admin_roles":i=new Intent(this,AdminManagementActivity.class).putExtra("admin_context",true);break;
            default:i=new Intent(this,AdminHubActivity.class).putExtra("gate_passed",true).putExtra("admin_context",true);break;
        }
        i.putExtra("catalog_folder",folder.id).putExtra("catalog_title",folder.label);
        startActivity(i);
    }
}
