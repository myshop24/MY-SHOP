package com.myshop.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;

/** V-308 owner-only review board for UGC safety reports and external account deletion requests. */
public class AdminSafetyActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(246,248,252), DARK=Color.rgb(22,28,55), MUTED=Color.rgb(100,106,122), BLUE=Color.rgb(46,47,190), RED=Color.rgb(205,45,55), GREEN=Color.rgb(18,135,88);
    private LinearLayout list; private TextView status; private boolean deletionMode=false; private String deletionFilter="OPEN"; private int loadGeneration;
    private String token(){return SessionManager.getToken(this);}
    @Override protected void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)){finish();return;}build();loadReports();}
    private void build(){
        LinearLayout root=col();root.setBackgroundColor(BG);root.setPadding(dp(12),dp(10),dp(12),dp(18));
        LinearLayout h=row();Button back=button("‹",DARK,27);back.setOnClickListener(v->finish());h.addView(back,lp(dp(42),dp(44)));LinearLayout hb=col();hb.addView(txt("myshop",19,DARK,true),lp(-1,dp(24)));hb.addView(txt("SAFETY & PLAY COMPLIANCE",9,MUTED,true),lp(-1,dp(18)));h.addView(hb,new LinearLayout.LayoutParams(0,dp(46),1));root.addView(h,lp(-1,dp(52)));
        LinearLayout note=card();note.setBackground(round(DARK,DARK,13));note.addView(txt("🛡 Admin-only safety queue",12,Color.WHITE,true),lp(-1,dp(25)));note.addView(txt("User reports review করুন। External account-deletion request-এর identity verify না করে Complete করবেন না।",10,Color.WHITE,false),lp(-1,dp(45)));root.addView(note,lp(-1,-2));
        LinearLayout tabs=row();TextView reports=tab("⚑ REPORTS",true),deletions=tab("DELETE REQUESTS",false);reports.setOnClickListener(v->{deletionMode=false;loadReports();});deletions.setOnClickListener(v->{deletionMode=true;loadDeletions();});tabs.addView(reports,new LinearLayout.LayoutParams(0,dp(44),1));tabs.addView(gap(),lp(dp(7),1));tabs.addView(deletions,new LinearLayout.LayoutParams(0,dp(44),1));root.addView(tabs,lp(-1,dp(52)));
        status=txt("Loading…",9,MUTED,false);status.setGravity(Gravity.CENTER);root.addView(status,lp(-1,dp(34)));ScrollView sc=new ScrollView(this);list=col();sc.addView(list);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }
    private String reportFilter="OPEN";
    private void loadReports(){final int generation=++loadGeneration;status.setOnClickListener(v->new MyShopDialogBuilder(this).setTitle("Complaint queue").setItems(new String[]{"Pending","Reviewing","Resolved","All"},(d,n)->{reportFilter=new String[]{"OPEN","REVIEWING","RESOLVED","ALL"}[n];getIntent().removeExtra("reportId");loadReports();}).show());status.setText("Loading open safety reports…");loadReportQueue629(new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{if(generation==loadGeneration&&!deletionMode&&!isFinishing())renderReports(d.optJSONArray("reports"));});}public void onError(String m){runOnUiThread(()->{if(generation==loadGeneration&&!deletionMode)status.setText("Report load failed: "+m);});}});}
    private void loadReportQueue629(BackendClient.Callback cb){String id=getIntent().getStringExtra("reportId");if(id!=null&&!id.isEmpty())BackendClient.adminReport629(token(),id,cb);else BackendClient.adminSafetyReports(token(),reportFilter,cb);}
    private void renderReports(JSONArray a){list.removeAllViews();int n=a==null?0:a.length();status.setText(n+" "+reportFilter.toLowerCase()+" report(s) • tap to filter");for(int i=0;i<n;i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;long id=x.optLong("id");String reporter=x.optString("reporter_name",x.optString("reporter_id","User")),target=x.optString("target_name",x.optString("target_user_id",""));LinearLayout c=card();c.addView(txt(x.optString("status","OPEN")+" • "+x.optString("content_type","USER")+" • #"+id,12,DARK,true),lp(-1,dp(24)));c.addView(txt("Reporter: "+reporter+" ("+x.optString("reporter_id","")+")\nTarget: "+(target.isEmpty()?"Content only":target+" ("+x.optString("target_user_id","")+")"),9.5f,MUTED,false),lp(-1,dp(43)));c.addView(txt("Reason: "+x.optString("reason","OTHER")+(x.optString("content_id","").isEmpty()?"":" • Content #"+x.optString("content_id")),10,DARK,true),lp(-1,dp(28)));String details=x.optString("details","");if(!details.isEmpty())c.addView(txt(details,9.5f,DARK,false),lp(-1,dp(42)));TextView review=action("REVIEWING",BLUE);review.setOnClickListener(v->reportAction(id,"REVIEWING"));c.addView(review,lp(-1,dp(44)));String reviewReason=x.optString("review_reason","");if(!reviewReason.isEmpty())c.addView(txt("Review: "+reviewReason,11,MUTED,false),lp(-1,-2));c.addView(actions(()->reportAction(id,"RESOLVED"),()->reportAction(id,"DISMISSED"),"RESOLVE","DISMISS"),lp(-1,dp(42)));list.addView(c,lp(-1,-2));list.addView(gap(),lp(1,dp(8)));}if(n==0)empty("✓ No open safety reports.");}
    private void loadDeletions(){
        final int generation=++loadGeneration;
        status.setOnClickListener(v->new MyShopDialogBuilder(this).setTitle("Deletion requests").setItems(new String[]{"Open","Verified","Media cleanup pending","Completed","Dismissed","All"},(d,n)->{deletionFilter=new String[]{"OPEN","VERIFIED","MEDIA_PENDING","COMPLETED","DISMISSED","ALL"}[n];loadDeletions();}).show());
        status.setText("Loading deletion requests…");
        BackendClient.adminDeletionRequests(token(),deletionFilter,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{if(generation==loadGeneration&&deletionMode&&!isFinishing())renderDeletions(d.optJSONArray("requests"));});}public void onError(String m){runOnUiThread(()->{if(generation==loadGeneration&&deletionMode)status.setText("Deletion request load failed: "+m);});}});
    }
    private void renderDeletions(JSONArray a){
        list.removeAllViews();int n=a==null?0:a.length();status.setText(n+" "+deletionFilter.toLowerCase().replace('_',' ')+" request(s) · tap to filter");
        for(int i=0;i<n;i++){
            JSONObject x=a.optJSONObject(i);if(x==null)continue;long id=x.optLong("id");String state=x.optString("status","OPEN");LinearLayout c=card();
            c.addView(txt("Delete Request #"+id+" · "+state.replace('_',' '),12,DARK,true),lp(-1,-2));
            c.addView(txt("Matched User ID: "+(x.optString("user_id","").isEmpty()?"Not matched":x.optString("user_id"))+"\nIdentifier: "+x.optString("identifier","")+"\nContact: "+x.optString("contact",""),9.5f,DARK,false),lp(-1,-2));
            String reason=x.optString("reason","");if(!reason.isEmpty())c.addView(txt("Reason: "+reason,9,MUTED,false),lp(-1,-2));
            if(state.equals("OPEN"))c.addView(actions(()->deleteAction(id,"VERIFIED"),()->deleteAction(id,"DISMISSED"),"VERIFY","DISMISS"),lp(-1,dp(42)));
            else if(state.equals("VERIFIED")){TextView dismiss=action("DISMISS",RED);dismiss.setOnClickListener(v->deleteAction(id,"DISMISSED"));c.addView(dismiss,lp(-1,dp(42)));}
            else if(state.equals("MEDIA_PENDING"))c.addView(txt("Account removed. Media cleanup is pending automatic retry.",11,MUTED,false),lp(-1,-2));
            list.addView(c,lp(-1,-2));list.addView(gap(),lp(1,dp(8)));
        }
        if(n==0)empty("No deletion requests in this filter.");
    }
    private LinearLayout actions(Runnable yes,Runnable no,String y,String n){LinearLayout r=row();TextView a=action(y,GREEN),b=action(n,RED);a.setOnClickListener(v->yes.run());b.setOnClickListener(v->no.run());r.addView(a,new LinearLayout.LayoutParams(0,dp(38),1));r.addView(gap(),lp(dp(7),1));r.addView(b,new LinearLayout.LayoutParams(0,dp(38),1));return r;}
    private void reportAction(long id,String st){EditText reason=new EditText(this);reason.setHint("Review / resolution reason");new MyShopDialogBuilder(this).setTitle(st).setView(reason).setPositiveButton("Save",(d,w)->BackendClient.adminSafetyReportAction(token(),id,st,reason.getText().toString().trim(),new BackendClient.Callback(){public void onSuccess(JSONObject data){runOnUiThread(()->loadReports());}public void onError(String error){runOnUiThread(()->Toast.makeText(AdminSafetyActivity.this,error,android.widget.Toast.LENGTH_LONG).show());}})).setNegativeButton("Cancel",null).show();}
    private void deleteAction(long id,String st){new MyShopDialogBuilder(this).setTitle(st.equals("VERIFIED")?"Identity verified?":"Dismiss request?").setMessage(st.equals("VERIFIED")?"Only mark VERIFIED after you have confirmed the requester owns this myshop account. Verification alone does not silently delete the account.":"Use Dismiss only for invalid/duplicate requests.").setNegativeButton("CANCEL",null).setPositiveButton(st,(d,w)->BackendClient.adminDeletionRequestAction(token(),id,st,new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->{Toast.makeText(AdminSafetyActivity.this,st+" saved",Toast.LENGTH_SHORT).show();loadDeletions();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AdminSafetyActivity.this,m,Toast.LENGTH_LONG).show());}})).show();}
    private void empty(String s){TextView t=txt(s,11,MUTED,false);t.setGravity(Gravity.CENTER);list.addView(t,lp(-1,dp(80)));}
    private TextView tab(String s,boolean on){TextView t=txt(s,9,on?Color.WHITE:BLUE,true);t.setGravity(Gravity.CENTER);t.setBackground(round(on?BLUE:Color.WHITE,BLUE,11));return t;}private TextView action(String s,int c){TextView t=txt(s,9,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setBackground(round(c,c,9));return t;}
    private LinearLayout card(){LinearLayout c=col();c.setPadding(dp(10),dp(9),dp(10),dp(9));c.setBackground(round(Color.WHITE,Color.rgb(224,226,235),12));return c;}private TextView txt(String s,float z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}private Button button(String s,int c,float z){Button b=new Button(this);b.setText(s);b.setTextColor(c);b.setTextSize(z);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackgroundColor(Color.TRANSPARENT);return b;}private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private View gap(){return new View(this);}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private GradientDrawable round(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
