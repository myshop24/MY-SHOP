package com.myshop.app;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** V-395 dedicated Page 2 twenty-slot Live Streaming banner manager. */
public class LiveHomeAdminActivity extends AppCompatActivity {
    private static final int PICK=9551;
    private final int BG=Color.rgb(6,15,47),CARD=Color.rgb(17,29,77),WHITE=Color.WHITE,MUTED=Color.rgb(184,196,230),BLUE=Color.rgb(45,114,246),PURPLE=Color.rgb(123,63,242),PINK=Color.rgb(240,43,183),GREEN=Color.rgb(36,177,111),RED=Color.rgb(224,61,82),GOLD=Color.rgb(255,201,74);
    private LinearLayout list;private boolean orderDirty=false,orderSaving=false,loadingSection=false;private final java.util.ArrayList<Integer> bannerOrder=new java.util.ArrayList<>();private TextView orderStatus;private Switch sectionSwitch;private int pendingDisplaySeconds=4;
    private int pendingSlot=0;
    private Uri retryImage;private boolean uploading=false;
    private String pendingCaption="",pendingLink="",pendingStart="",pendingEnd="";
    private String folder="live_home",folderTitle="Main Advertising Banners";
    private final ExecutorService imageIo=Executors.newFixedThreadPool(2);

    @Override protected void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)){finish();return;}String f=getIntent().getStringExtra("folder");if(f!=null&&f.matches("live_home|live2_promo_[1-4]|shop_home|shop_promo"))folder=f;String title=getIntent().getStringExtra("folderTitle");if(title!=null&&!title.trim().isEmpty())folderTitle=title;for(int i=1;i<=20;i++)bannerOrder.add(i);setContentView(build());load();}

    private View build(){
        LinearLayout page=col();page.setBackgroundColor(BG);page.setPadding(dp(12),dp(8),dp(12),dp(18));page.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(dp(12),Math.max(dp(8),i.getSystemWindowInsetTop()+dp(4)),dp(12),Math.max(dp(18),i.getSystemWindowInsetBottom()+dp(8)));return i;});
        LinearLayout top=row();TextView back=txt("‹",30,WHITE,true);back.setGravity(Gravity.CENTER);back.setOnClickListener(v->onBackPressed());top.addView(back,lp(dp(46),dp(48)));LinearLayout copy=col();copy.addView(txt(("shop_home".equals(folder)?"SHOP • ":"PAGE 2 • ")+folderTitle,16,WHITE,true),lp(-1,dp(28)));copy.addView(txt("Admin Banner Control • 20 Slots • Horizontal Swipe",9.5f,MUTED,false),lp(-1,dp(18)));top.addView(copy,new LinearLayout.LayoutParams(0,dp(48),1));page.addView(top,lp(-1,dp(52)));
        TextView size=txt((("live_home".equals(folder)||"shop_home".equals(folder))?"Recommended banner: 1200 × 500 px • 12:5 • keep key text inside safe area":"Product ad: 1200 × 500 px • 12:5 recommended"),11,GOLD,true);size.setGravity(Gravity.CENTER);size.setPadding(dp(8),dp(7),dp(8),dp(7));size.setBackground(gradient(new int[]{Color.rgb(48,36,104),Color.rgb(89,37,126)},14));page.addView(size,lp(-1,dp(42)));
        TextView help=txt("Banner 1–20 এখান থেকেই Add/Replace, Save/Publish, Enable/Disable, Link, Gallery, Schedule এবং Delete করুন। Start/End সময় backend-এ save হবে এবং Live Home-এ active window-এর banner-ই দেখাবে।",9.3f,MUTED,false);help.setPadding(dp(8),dp(8),dp(8),dp(8));page.addView(help,lp(-1,-2));
        sectionSwitch=new Switch(this);sectionSwitch.setText("এই ব্যানার লাইন দেখান • বন্ধ হলে নিচের কনটেন্ট ওপরে উঠবে");sectionSwitch.setTextColor(WHITE);sectionSwitch.setVisibility(("live_home".equals(folder)||"shop_home".equals(folder)||"shop_promo".equals(folder))?View.VISIBLE:View.GONE);page.addView(sectionSwitch,lp(-1,dp(44)));sectionSwitch.setOnCheckedChangeListener((v,enabled)->{if(!loadingSection)saveSection(enabled);});
        orderStatus=txt("Hold a banner card and drag to move · Save order to publish",10,MUTED,false);page.addView(orderStatus,lp(-1,dp(30)));LinearLayout orderControls=row();TextView saveOrder=button("Save order",BLUE);saveOrder.setOnClickListener(v->publishOrder());orderControls.addView(saveOrder,wt(1));TextView cancelOrder=button("Cancel order",PURPLE);cancelOrder.setOnClickListener(v->{if(orderSaving)return;new MyShopDialogBuilder(this).setTitle("Discard position changes?").setPositiveButton("Discard",(d,w)->{orderDirty=false;bannerOrder.clear();for(int n=1;n<=20;n++)bannerOrder.add(n);load();}).setNegativeButton("Keep editing",null).show();});orderControls.addView(cancelOrder,wt(1));page.addView(orderControls,lp(-1,dp(44)));
        list=col();ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.setVerticalScrollBarEnabled(false);sv.addView(list);page.addView(sv,new LinearLayout.LayoutParams(-1,0,1));page.post(page::requestApplyInsets);return page;
    }

    private void load(){BackendClient.adminBannerFolder(SessionManager.getToken(this),folder,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{loadingSection=true;sectionSwitch.setChecked(d.optBoolean("sectionEnabled",true));loadingSection=false;render(d.optJSONArray("banners"));});}public void onError(String m){runOnUiThread(()->{new MyShopDialogBuilder(LiveHomeAdminActivity.this).setTitle("Banner load failed · existing draft kept").setMessage(m).setPositiveButton("Retry",(d,w)->load()).setNegativeButton("Keep editing",null).show();});}});}
    private void saveSection(boolean enabled){BackendClient.adminBannerSection(SessionManager.getToken(this),folder,enabled,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->toast(enabled?"ব্যানার লাইন চালু হয়েছে":"ব্যানার লাইন বন্ধ; ফাঁকা জায়গাও থাকবে না"));}public void onError(String m){runOnUiThread(()->{loadingSection=true;sectionSwitch.setChecked(!enabled);loadingSection=false;toast("সেটিংস সংরক্ষণ হয়নি: "+m);});}});}

    private void render(JSONArray a){list.removeAllViews();JSONObject[] slots=new JSONObject[20];if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;int s=x.optInt("slot",0);if(s>=1&&s<=20)slots[s-1]=x;}for(int i=1;i<=20;i++)slotCard(i,slots[i-1]);}

    private void slotCard(int slot,JSONObject x){
        boolean exists=x!=null;boolean enabled=exists&&x.optInt("active",1)==1;String image=exists?x.optString("image_url",""):"",caption=exists?x.optString("caption",""):"",target=exists?x.optString("target_url",""):"",startAt=exists?x.optString("start_at",""):"",endAt=exists?x.optString("end_at",""):"";int displaySeconds=exists?Math.max(1,Math.min(30,x.optInt("display_seconds",4))):4;
        LinearLayout card=col();card.setPadding(dp(10),dp(10),dp(10),dp(10));card.setBackground(gradient(new int[]{Color.rgb(18,31,82),Color.rgb(30,27,88)},17));LinearLayout.LayoutParams cp=lp(-1,-2);cp.bottomMargin=dp(10);card.setLayoutParams(cp);
        LinearLayout head=row();TextView name=txt("Banner "+slot,14,WHITE,true);head.addView(name,new LinearLayout.LayoutParams(0,dp(32),1));TextView st=txt(!exists?"EMPTY":enabled?"PUBLISHED":"DISABLED",8.5f,!exists?MUTED:enabled?Color.rgb(88,235,166):Color.rgb(255,139,148),true);st.setGravity(Gravity.CENTER);st.setBackground(round(Color.argb(45,255,255,255),Color.argb(60,255,255,255),10));head.addView(st,lp(dp(86),dp(28)));card.addView(head,lp(-1,dp(34)));
        FrameLayout previewBox=new FrameLayout(this);previewBox.setBackground(round(Color.rgb(8,18,52),Color.rgb(68,84,153),13));ImageView preview=new ImageView(this);preview.setScaleType(ImageView.ScaleType.FIT_CENTER);preview.setImageDrawable(null);previewBox.addView(preview,new FrameLayout.LayoutParams(-1,-1));TextView empty=txt(exists?"Loading preview…":"No banner in this slot",9.5f,MUTED,true);empty.setGravity(Gravity.CENTER);previewBox.addView(empty,new FrameLayout.LayoutParams(-1,-1));if(exists&&!image.isEmpty())loadImage(preview,image,empty);card.addView(previewBox,lp(-1,dp(132)));
        TextView guide=txt("Keep price / offer / product photo inside the safe area",8.4f,MUTED,false);card.addView(guide,lp(-1,dp(28)));
        EditText cap=field("Caption (optional)",caption);card.addView(cap,lp(-1,dp(46)));EditText link=field("Link URL (optional)",target);card.addView(link,top(lp(-1,dp(46)),5));EditText start=field("Start date/time (optional)",startAt);card.addView(start,top(lp(-1,dp(46)),5));EditText end=field("End / expiry date/time (optional)",endAt);card.addView(end,top(lp(-1,dp(46)),5));LinearLayout schedule=row();TextView setStart=button("Set Start",BLUE);TextView setEnd=button("Set End",PURPLE);setStart.setOnClickListener(v->pickDateTime(start));setEnd.setOnClickListener(v->pickDateTime(end));schedule.addView(setStart,wt(1));schedule.addView(space(dp(5)));schedule.addView(setEnd,wt(1));card.addView(schedule,top(lp(-1,dp(44)),5));EditText duration=field("Display time in seconds (1–30)",String.valueOf(displaySeconds));duration.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);card.addView(duration,top(lp(-1,dp(46)),5));
        Switch active=new Switch(this);active.setText("Enable / Publish");active.setTextColor(WHITE);active.setTextSize(10.5f);active.setChecked(!exists||enabled);card.addView(active,lp(-1,dp(42)));
        LinearLayout a1=row();TextView add=button(exists?"Replace":"Add",PURPLE);add.setOnClickListener(v->{if(orderDirty){toast("Save or Cancel position changes first");return;}if(uploading){toast("Upload in progress");return;}pendingSlot=slot;pendingCaption=cap.getText().toString().trim();pendingLink=link.getText().toString().trim();pendingStart=start.getText().toString().trim();pendingEnd=end.getText().toString().trim();pendingDisplaySeconds=readSeconds(duration);if(pendingDisplaySeconds<1){toast("সময় ১–৩০ সেকেন্ডের মধ্যে দিন");return;}pick();});a1.addView(add,wt(1));a1.addView(space(dp(5)));TextView save=button("Save / Publish",GREEN);save.setOnClickListener(v->{if(orderDirty||orderSaving){toast("Save or Cancel position changes first");return;}if(!exists){toast("আগে Banner Add করুন");return;}int seconds=readSeconds(duration);if(seconds<1){toast("সময় ১–৩০ সেকেন্ডের মধ্যে দিন");return;}BackendClient.adminBannerUpdate(SessionManager.getToken(this),folder,slot,cap.getText().toString().trim(),link.getText().toString().trim(),active.isChecked(),start.getText().toString().trim(),end.getText().toString().trim(),seconds,new Cb("✓ Banner saved",this::load));});a1.addView(save,wt(1));card.addView(a1,lp(-1,dp(44)));
        LinearLayout a2=row();TextView toggle=button(active.isChecked()?"Disable":"Enable",BLUE);toggle.setOnClickListener(v->{if(orderDirty||orderSaving){toast("Save or Cancel position changes first");return;}if(!exists){toast("Slot empty");return;}BackendClient.adminBannerUpdate(SessionManager.getToken(this),folder,slot,cap.getText().toString().trim(),link.getText().toString().trim(),!enabled,start.getText().toString().trim(),end.getText().toString().trim(),new Cb(!enabled?"✓ Enabled":"✓ Disabled",this::load));});a2.addView(toggle,wt(1));a2.addView(space(dp(5)));TextView del=button(UiStrings.label(LiveHomeAdminActivity.this,"Delete"),RED);del.setAlpha(exists?1f:.45f);del.setOnClickListener(v->{if(orderDirty||orderSaving){toast("Save or Cancel position changes first");return;}if(!exists){toast("Slot empty");return;}new MyShopDialogBuilder(this).setTitle("Delete Banner "+slot+"?").setMessage("এই banner এবং তার link সরানো হবে।").setPositiveButton("DELETE",(d,w)->BackendClient.adminBannerDelete(SessionManager.getToken(this),folder,slot,new Cb("✓ Banner deleted",this::load))).setNegativeButton(UiStrings.label(LiveHomeAdminActivity.this,"Cancel"),null).show();});a2.addView(del,wt(1));card.addView(a2,top(lp(-1,dp(44)),5));card.setTag(slot);card.setOnLongClickListener(v->{if(orderSaving||uploading)return false;return v.startDragAndDrop(android.content.ClipData.newPlainText("banner",String.valueOf(slot)),new View.DragShadowBuilder(v),Integer.valueOf(slot),0);});card.setOnDragListener((v,e)->{if(!(e.getLocalState() instanceof Integer))return false;if(e.getAction()==android.view.DragEvent.ACTION_DROP){int origin=bannerOrder.indexOf((Integer)e.getLocalState()),dropPosition=bannerOrder.indexOf(slot);if(origin>=0&&dropPosition>=0){Integer from=bannerOrder.remove(origin);bannerOrder.add(dropPosition,from);java.util.ArrayList<View> views=new java.util.ArrayList<>();for(int n=0;n<list.getChildCount();n++)views.add(list.getChildAt(n));list.removeAllViews();for(Integer key:bannerOrder)for(View item:views)if(key.equals(item.getTag()))list.addView(item);orderDirty=true;orderStatus.setText("Draft positions changed · Save or Cancel");}return true;}return true;});list.addView(card);
    }

    private void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,PICK);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r!=PICK||c!=RESULT_OK||d==null||d.getData()==null)return;Uri u=d.getData();try{if((d.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION)!=0)getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}showUploadPreview(u);}
    private void showUploadPreview(Uri image){ImageView preview=new ImageView(this);preview.setScaleType(ImageView.ScaleType.FIT_CENTER);preview.setImageURI(image);LinearLayout box=col();box.addView(preview,lp(-1,dp(180)));new MyShopDialogBuilder(this).setTitle("Preview Banner "+pendingSlot).setView(box).setPositiveButton("Publish image",(d,w)->upload(image)).setNegativeButton(UiStrings.label(LiveHomeAdminActivity.this,"Cancel"),null).show();}
    private void publishOrder(){if(!orderDirty||orderSaving||uploading)return;orderSaving=true;orderStatus.setText("Saving positions…");BackendClient.adminBannerOrder(SessionManager.getToken(this),folder,new JSONArray(bannerOrder),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{orderSaving=false;orderDirty=false;bannerOrder.clear();for(int n=1;n<=20;n++)bannerOrder.add(n);orderStatus.setText("Positions saved · use each card’s Save for text edits");load();});}public void onError(String m){runOnUiThread(()->{orderSaving=false;orderStatus.setText("Save failed · position draft retained · retry Save");});}});}
    @Override public void onBackPressed(){if(orderSaving||uploading)return;if(orderDirty)new MyShopDialogBuilder(this).setTitle("Unsaved banner positions").setPositiveButton(UiStrings.label(LiveHomeAdminActivity.this,"Save"),(d,w)->publishOrder()).setNegativeButton("Discard",(d,w)->finish()).setNeutralButton("Keep editing",null).show();else super.onBackPressed();}
    private int readSeconds(EditText e){try{int n=Integer.parseInt(e.getText().toString().trim());return n>=1&&n<=30?n:0;}catch(Exception ignored){return 0;}}
    private void upload(Uri u){if(uploading)return;retryImage=u;uploading=true;try{InputStream in=getContentResolver().openInputStream(u);String mime=getContentResolver().getType(u);BackendClient.adminBannerUpload(SessionManager.getToken(this),in,"live-home-banner.jpg",mime==null?"image/jpeg":mime,folder,pendingSlot,pendingCaption,pendingLink,pendingStart,pendingEnd,pendingDisplaySeconds,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{uploading=false;retryImage=null;toast("✓ Banner "+pendingSlot+" added");load();});}public void onError(String m){runOnUiThread(()->{uploading=false;new MyShopDialogBuilder(LiveHomeAdminActivity.this).setTitle("Upload failed · image kept").setMessage(m).setPositiveButton("Retry",(dialog,which)->{if(retryImage!=null)upload(retryImage);}).setNegativeButton("Keep editing",null).show();});}});}catch(Exception e){uploading=false;toast("Selected image open হয়নি");}}

    private void pickDateTime(EditText target){
        Calendar cal=Calendar.getInstance();
        android.app.DatePickerDialog dpd=new android.app.DatePickerDialog(this,(v,y,m,d)->{
            android.app.TimePickerDialog tpd=new android.app.TimePickerDialog(this,(tv,h,min)->{
                Calendar chosen=Calendar.getInstance(); chosen.set(y,m,d,h,min,0);
                SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd\'T\'HH:mm:ssXXX",Locale.US);
                target.setText(fmt.format(chosen.getTime()));
            },cal.get(Calendar.HOUR_OF_DAY),cal.get(Calendar.MINUTE),true);
            tpd.show();
        },cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH));
        dpd.show();
    }

    private void loadImage(ImageView v,String url,TextView ph){imageIo.execute(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(5000);c.setReadTimeout(7000);try(InputStream in=c.getInputStream()){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null)runOnUiThread(()->{v.setImageBitmap(b);ph.setVisibility(View.GONE);});}}catch(Exception e){runOnUiThread(()->ph.setText("Preview unavailable"));}finally{if(c!=null)c.disconnect();}});}
    @Override protected void onDestroy(){imageIo.shutdownNow();super.onDestroy();}

    private EditText field(String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.rgb(126,139,181));e.setText(value);e.setTextColor(WHITE);e.setSingleLine(true);e.setTextSize(11.5f);e.setPadding(dp(11),0,dp(11),0);e.setBackground(round(Color.rgb(9,20,55),Color.rgb(69,84,146),11));return e;}
    private TextView button(String s,int color){TextView t=txt(s,10,WHITE,true);t.setGravity(Gravity.CENTER);t.setBackground(round(color,Color.argb(90,255,255,255),11));PremiumUi.press(t);return t;}
    private TextView txt(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private View space(int w){Space s=new Space(this);s.setLayoutParams(new LinearLayout.LayoutParams(w,1));return s;}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams wt(float w){return new LinearLayout.LayoutParams(0,dp(44),w);}private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}private GradientDrawable gradient(int[] colors,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(radius));return g;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}
    private class Cb implements BackendClient.Callback{private final String ok;private final Runnable done;Cb(String ok,Runnable done){this.ok=ok;this.done=done;}public void onSuccess(JSONObject d){runOnUiThread(()->{toast(ok);if(done!=null)done.run();});}public void onError(String m){runOnUiThread(()->toast(m));}}
}
