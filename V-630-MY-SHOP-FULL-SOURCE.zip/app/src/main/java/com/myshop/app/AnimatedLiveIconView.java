package com.myshop.app;
import android.content.Context;
import android.graphics.*;
import android.view.View;
/** Design29: stationary camera, slow expanding blue/pink light. */
final class AnimatedLiveIconView extends View {
 private final Paint p=new Paint(3);private boolean reduce;
 AnimatedLiveIconView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);reduce=c.getSharedPreferences("myshop_accessibility",Context.MODE_PRIVATE).getBoolean("reduce_animation",false);setContentDescription("Live video");}
 @Override protected void onAttachedToWindow(){super.onAttachedToWindow();invalidate();}
 @Override public void onWindowFocusChanged(boolean focus){super.onWindowFocusChanged(focus);if(focus)invalidate();}
 @Override protected void onDraw(Canvas c){reduce=getContext().getSharedPreferences("myshop_accessibility",Context.MODE_PRIVATE).getBoolean("reduce_animation",false);float s=Math.min(getWidth(),getHeight()),x=getWidth()/2f,y=getHeight()/2f,t=reduce?0:(android.os.SystemClock.uptimeMillis()%3000)/3000f;
 p.setStyle(Paint.Style.FILL);p.setShader(new RadialGradient(x,y,s*.4f,new int[]{0xff02030d,0xff070723,0xff18214a},null,Shader.TileMode.CLAMP));c.drawCircle(x,y,s*.37f,p);
 p.setStyle(Paint.Style.STROKE);p.setShadowLayer(s*.04f,0,0,0xff4ccfff);p.setShader(new SweepGradient(x,y,new int[]{0xff43dbff,0xff7353ff,0xffff3ab9,0xff43dbff},null));for(int i=0;i<3;i++){float f=(t+i/3f)%1;p.setStrokeWidth(s*.014f);p.setAlpha((int)(120*(1-f)));c.drawCircle(x,y,s*(.37f+.115f*f),p);}p.setAlpha(125+(int)(120*(.5f+.5f*Math.sin(t*6.283))));p.setStrokeWidth(s*.035f);c.drawCircle(x,y,s*.37f,p);
 p.setShader(null);p.setStyle(Paint.Style.FILL);int[] lights={0xff35dfff,0xff9760ff,0xffff47c7,0xff4deaff};for(int i=0;i<8;i++){double angle=i*Math.PI/4;float intensity=.5f+.5f*(float)Math.sin(t*6.283+i*.8);p.setColor(lights[i%4]);p.setAlpha((int)(70+185*intensity));c.drawCircle(x+(float)Math.cos(angle)*s*.395f,y+(float)Math.sin(angle)*s*.395f,s*.017f,p);}
 p.setShader(null);p.clearShadowLayer();p.setAlpha(255);p.setColor(Color.WHITE);p.setStyle(Paint.Style.FILL);c.drawRoundRect(x-s*.19f,y-s*.135f,x+s*.085f,y+s*.135f,s*.045f,s*.045f,p);Path camera=new Path();camera.moveTo(x+s*.11f,y-s*.08f);camera.lineTo(x+s*.22f,y-s*.13f);camera.lineTo(x+s*.22f,y+s*.13f);camera.lineTo(x+s*.11f,y+s*.08f);camera.close();c.drawPath(camera,p);p.setColor(0xff392074);Path play=new Path();play.moveTo(x-s*.09f,y-s*.055f);play.lineTo(x-s*.09f,y+s*.055f);play.lineTo(x-s*.015f,y);play.close();c.drawPath(play,p);if(!reduce&&isShown())postInvalidateOnAnimation();}
}
