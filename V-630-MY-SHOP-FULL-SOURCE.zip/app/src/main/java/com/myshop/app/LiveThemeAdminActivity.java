package com.myshop.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.URL;

/** V-297 বাংলা premium Audio Live wallpaper/theme manager with R2 upload and visual color picker. */
public class LiveThemeAdminActivity extends AppCompatActivity {
    private boolean uploading629=false;private int previewGeneration629=0;
    private static final int PICK_WALLPAPER=7851;
    private EditText key,name,price,sort;
    private Switch enabled;
    private Spinner fitMode;
    private SeekBar joinFontSize;
    private TextView joinFontValue,joinPreview;
    private int joinTextColor=Color.WHITE;
    private ImageView preview;
    private TextView uploadState,colorValue,colorPreview;
    private SeekBar red,green,blue;
    private String backgroundUrl="";
    private final int DARK=Color.rgb(23,31,63),PURPLE=Color.rgb(92,45,205),MUTED=Color.rgb(101,111,139),RED=Color.rgb(190,44,62),GREEN=Color.rgb(25,154,102);

    @Override protected void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)){finish();return;}build();loadPublished();loadLiveUiSettings();}

    private void build(){
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);LinearLayout root=col();root.setPadding(dp(14),dp(14),dp(14),dp(26));root.setBackgroundColor(Color.rgb(247,249,254));
        LinearLayout head=row();TextView back=action("‹",DARK);back.setTextSize(26);back.setBackgroundColor(Color.TRANSPARENT);back.setTextColor(DARK);back.setOnClickListener(v->finish());head.addView(back,new LinearLayout.LayoutParams(dp(44),dp(44)));LinearLayout hb=col();hb.addView(t("অডিও লাইভ ওয়ালপেপার",18,DARK,true));hb.addView(t("গ্যালারি/ফাইল → প্রিভিউ → প্রকাশ",10,MUTED,false));head.addView(hb,new LinearLayout.LayoutParams(0,dp(48),1));root.addView(head);
        root.addView(note("ফোন থেকে ছবি বাছুন → প্রিভিউ দেখুন → সংরক্ষণ / Publish চাপুন। কোনো URL লিখতে হবে না; myshop নিজে R2-তে আপলোড করবে।"));
        root.addView(note("✅ Recommended Live Wallpaper: 1080 × 2400 px • Aspect Ratio 20:9 Portrait • JPG/PNG • গুরুত্বপূর্ণ লেখা/মুখ মাঝামাঝি safe area-তে রাখুন।"));

        LinearLayout media=card();media.addView(fieldLabel("ওয়ালপেপার ছবি","Recommended: 1080 × 2400 px (20:9 Portrait). এই ছবি Audio Live room-এর full-screen background হিসেবে দেখাবে।"));preview=new ImageView(this);preview.setScaleType(ImageView.ScaleType.CENTER_CROP);preview.setImageResource(R.drawable.live_room_default_wallpaper);preview.setBackground(round(Color.rgb(234,238,248),Color.rgb(211,218,239),15));media.addView(preview,new LinearLayout.LayoutParams(-1,dp(190)));
        uploadState=t("ডিফল্ট/বর্তমান ছবি",10,MUTED,false);uploadState.setPadding(0,dp(6),0,dp(6));media.addView(uploadState);
        LinearLayout mBtns=row();TextView upload=action("📁 ছবি আপলোড",PURPLE);upload.setOnClickListener(v->pickWallpaper());mBtns.addView(upload,new LinearLayout.LayoutParams(0,dp(46),1));Space sp=new Space(this);mBtns.addView(sp,new LinearLayout.LayoutParams(dp(6),1));TextView remove=action("🗑 ছবি সরান",RED);remove.setOnClickListener(v->{previewGeneration629++;uploading629=false;backgroundUrl="";preview.setImageResource(R.drawable.live_room_default_wallpaper);uploadState.setText("ছবি সরানো হয়েছে • সংরক্ষণ/প্রকাশ চাপুন");});mBtns.addView(remove,new LinearLayout.LayoutParams(0,dp(46),1));media.addView(mBtns);
        TextView quickSave=action("💾 ওয়ালপেপার Save / Publish",GREEN);quickSave.setOnClickListener(v->{if(key!=null&&key.getText().toString().trim().isEmpty())key.setText("DEFAULT_LIVE");if(name!=null&&name.getText().toString().trim().isEmpty())name.setText("Audio Live Default");submit629("UPSERT",true);});LinearLayout.LayoutParams qsp=new LinearLayout.LayoutParams(-1,dp(48));qsp.topMargin=dp(8);media.addView(quickSave,qsp);root.addView(media);

        LinearLayout fitCard=card();fitCard.addView(fieldLabel("Wallpaper Fit Mode","Live Room-এ ছবি কীভাবে বসবে তা বেছে নিন।"));fitMode=new Spinner(this);String[] fitItems={"Center Crop (Recommended)","Fill Screen","Fit / Contain"};ArrayAdapter<String> fitAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,fitItems);fitMode.setAdapter(fitAdapter);fitCard.addView(fitMode,new LinearLayout.LayoutParams(-1,dp(50)));root.addView(fitCard);

        LinearLayout joinCard=card();joinCard.addView(fieldLabel("Join Status Font & Color","JOIN / REQUESTED লেখার size ও রঙ Admin এখান থেকে নির্ভুলভাবে বদলাতে পারবে।"));joinPreview=t("JOIN   •   REQUESTED ✓",18,Color.WHITE,true);joinPreview.setGravity(Gravity.CENTER);joinPreview.setBackground(round(Color.rgb(63,42,150),Color.rgb(125,199,255),13));joinCard.addView(joinPreview,new LinearLayout.LayoutParams(-1,dp(48)));joinFontValue=t("Font Size: 18sp",10,DARK,true);joinCard.addView(joinFontValue,new LinearLayout.LayoutParams(-1,dp(28)));joinFontSize=new SeekBar(this);joinFontSize.setMax(12);joinFontSize.setProgress(4);joinCard.addView(joinFontSize,new LinearLayout.LayoutParams(-1,dp(42)));joinFontSize.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean from){float z=14f+p;joinFontValue.setText("Font Size: "+((int)z)+"sp");joinPreview.setTextSize(z);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});joinCard.addView(fieldLabel("Join Text Color","ABC sample নয়—নিচের আসল রঙের swatch-এ চাপুন।"));LinearLayout swatches=row();int[] joinColors={Color.WHITE,Color.rgb(255,71,87),Color.rgb(55,145,255),Color.rgb(37,214,154),Color.rgb(255,199,55),Color.rgb(194,73,255),Color.rgb(255,80,182),Color.rgb(71,224,255)};for(int c:joinColors){TextView sw=t("",1,c,false);sw.setBackground(round(c,Color.argb(100,255,255,255),50));LinearLayout.LayoutParams sp2=new LinearLayout.LayoutParams(0,dp(36),1);sp2.setMargins(dp(2),dp(2),dp(2),dp(2));swatches.addView(sw,sp2);final int chosen=c;sw.setOnClickListener(v->{joinTextColor=chosen;joinPreview.setTextColor(chosen);});}joinCard.addView(swatches,new LinearLayout.LayoutParams(-1,dp(42)));TextView saveJoin=action("💾 Join Style Save / Publish",GREEN);saveJoin.setOnClickListener(v->saveJoinUi());LinearLayout.LayoutParams sj=new LinearLayout.LayoutParams(-1,dp(48));sj.topMargin=dp(7);joinCard.addView(saveJoin,sj);root.addView(joinCard);

        LinearLayout details=card();details.addView(fieldLabel("থিম কী","উদাহরণ: NIGHT_BLUE — একবার ব্যবহার হলে একই key দিয়ে Edit করা যাবে।"));key=input("থিম কী");details.addView(key);details.addView(fieldLabel("থিমের নাম","হোস্ট যে নামে থিম দেখবে।"));name=input("থিমের নাম");details.addView(name);details.addView(fieldLabel("কয়েনে মূল্য","ইউজার কিনতে কত কয়েন লাগবে। ০ দিলে বিনামূল্যে ধরা হবে।"));price=input("0");price.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);details.addView(price);details.addView(fieldLabel("সাজানোর ক্রম","ছোট সংখ্যা আগে দেখাবে।"));sort=input("0");sort.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);details.addView(sort);enabled=new Switch(this);enabled.setText("চালু / প্রকাশ");enabled.setChecked(true);details.addView(enabled,new LinearLayout.LayoutParams(-1,dp(50)));root.addView(details);

        LinearLayout colorCard=card();colorCard.addView(fieldLabel("রং নির্বাচন","Color code লিখতে হবে না। নিচের slider সরিয়ে Live room-এর accent color বাছুন।"));colorPreview=t("লাইভ রং প্রিভিউ",11,Color.WHITE,true);colorPreview.setGravity(Gravity.CENTER);colorCard.addView(colorPreview,new LinearLayout.LayoutParams(-1,dp(44)));red=colorSeek("লাল (R)",colorCard);green=colorSeek("সবুজ (G)",colorCard);blue=colorSeek("নীল (B)",colorCard);red.setProgress(91);green.setProgress(103);blue.setProgress(255);colorValue=t("#5B67FF",10,DARK,true);colorValue.setGravity(Gravity.CENTER);colorCard.addView(colorValue,new LinearLayout.LayoutParams(-1,dp(30)));SeekBar.OnSeekBarChangeListener cl=new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){updateColor();}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}};red.setOnSeekBarChangeListener(cl);green.setOnSeekBarChangeListener(cl);blue.setOnSeekBarChangeListener(cl);updateColor();root.addView(colorCard);

        LinearLayout actions=card();TextView save=action("💾 সংরক্ষণ / Publish",GREEN);save.setOnClickListener(v->submit("UPSERT"));actions.addView(save,new LinearLayout.LayoutParams(-1,dp(50)));TextView del=action("🗑 থিম মুছুন",RED);del.setOnClickListener(v->confirmDelete());LinearLayout.LayoutParams dp1=new LinearLayout.LayoutParams(-1,dp(48));dp1.topMargin=dp(8);actions.addView(del,dp1);root.addView(actions);

        TextView existing=t("প্রকাশিত থিমে চাপলে সম্পাদনার ফর্মে তথ্য চলে আসবে।",10,MUTED,false);existing.setPadding(dp(3),dp(10),dp(3),dp(6));root.addView(existing);LinearLayout published=col();published.setTag("published");root.addView(published);
        sv.addView(root);setContentView(sv);
    }

    private SeekBar colorSeek(String label,LinearLayout parent){parent.addView(t(label,10,DARK,true),new LinearLayout.LayoutParams(-1,dp(25)));SeekBar s=new SeekBar(this);s.setMax(255);parent.addView(s,new LinearLayout.LayoutParams(-1,dp(38)));return s;}
    private void updateColor(){int c=Color.rgb(red.getProgress(),green.getProgress(),blue.getProgress());colorPreview.setBackground(round(c,c,13));colorValue.setText(String.format("#%02X%02X%02X",red.getProgress(),green.getProgress(),blue.getProgress()));}
    private void setColor(String hex){try{int c=Color.parseColor(hex);red.setProgress(Color.red(c));green.setProgress(Color.green(c));blue.setProgress(Color.blue(c));updateColor();}catch(Exception ignored){}}

    private void pickWallpaper(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_WALLPAPER);}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode!=PICK_WALLPAPER||resultCode!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();final int generation629=++previewGeneration629;uploading629=true;preview.setImageURI(uri);uploadState.setText("আপলোড হচ্ছে…");try{InputStream in=getContentResolver().openInputStream(uri);String mime=getContentResolver().getType(uri);String file=(mime!=null&&mime.contains("png"))?"live-wallpaper.png":"live-wallpaper.jpg";BackendClient.adminAssetUpload(SessionManager.getToken(this),in,file,mime==null?"image/jpeg":mime,"live_wallpaper",new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{if(generation629!=previewGeneration629)return;uploading629=false;backgroundUrl=d.optString("image_url","");uploadState.setText(backgroundUrl.isEmpty()?"আপলোডের উত্তর সঠিক নয়":"✓ R2 আপলোড সম্পন্ন • প্রিভিউ প্রস্তুত");});}public void onError(String m){runOnUiThread(()->{if(generation629!=previewGeneration629)return;uploading629=false;uploadState.setText("আপলোড ব্যর্থ");toast(m);});}});}catch(Exception e){uploading629=false;toast("ছবি খোলা যায়নি");}}

    private void loadPublished(){BackendClient.liveThemes(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->renderPublished(d.optJSONArray("themes")));}public void onError(String m){runOnUiThread(()->{uploadState.setText("তালিকা লোড ব্যর্থ • আবার চাপুন");uploadState.setOnClickListener(v->loadPublished());});}});}
    private void renderPublished(JSONArray a){LinearLayout root=findTagged((ViewGroup)findViewById(android.R.id.content),"published");if(root==null)return;root.removeAllViews();if(a==null||a.length()==0){root.addView(note("এখনো কোনো প্রকাশিত থিম নেই।"));return;}for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;TextView item=action("🎨  "+x.optString("name",x.optString("theme_key"))+"   •   "+x.optInt("coin_price",0)+" কয়েন",PURPLE);item.setOnClickListener(v->loadTheme(x));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(46));p.bottomMargin=dp(6);root.addView(item,p);}}
    private LinearLayout findTagged(ViewGroup v,String tag){for(int i=0;i<v.getChildCount();i++){View c=v.getChildAt(i);if(c instanceof LinearLayout&&tag.equals(c.getTag()))return (LinearLayout)c;if(c instanceof ViewGroup){LinearLayout r=findTagged((ViewGroup)c,tag);if(r!=null)return r;}}return null;}
    private void loadTheme(JSONObject x){final int generation629=++previewGeneration629;uploading629=false;key.setText(x.optString("theme_key",""));name.setText(x.optString("name",""));price.setText(String.valueOf(x.optInt("coin_price",0)));sort.setText(String.valueOf(x.optInt("sort_order",0)));backgroundUrl=x.optString("background_url","");String fm=x.optString("fit_mode","CENTER_CROP");fitMode.setSelection("FILL".equals(fm)?1:("FIT".equals(fm)?2:0));setColor(x.optString("accent","#5B67FF"));if(backgroundUrl.isEmpty()){preview.setImageResource(R.drawable.live_room_default_wallpaper);uploadState.setText("এই থিমে কাস্টম ওয়ালপেপার নেই");}else{uploadState.setText("বর্তমান ওয়ালপেপার");final String imageUrl629=backgroundUrl;new Thread(()->{try(java.io.InputStream stream=new URL(imageUrl629).openStream()){Bitmap b=BitmapFactory.decodeStream(stream);if(b!=null)runOnUiThread(()->{if(generation629==previewGeneration629&&!isDestroyed())preview.setImageBitmap(b);});}catch(Exception ignored){runOnUiThread(()->{if(generation629==previewGeneration629)uploadState.setText("প্রিভিউ লোড হয়নি • আবার থিম নির্বাচন করুন");});}}).start();}toast("সম্পাদনা মোড: "+x.optString("name","Theme"));}

    private void confirmDelete(){String k=key.getText().toString().trim().toUpperCase();if(k.isEmpty()){toast("যে থিম মুছবেন তার কী নির্বাচন করুন");return;}new MyShopCompatDialogBuilder(this).setTitle("থিম মুছবেন?").setMessage("প্রকাশিত তালিকা থেকে থিম সরবে। আগে কেনা/রেকর্ড করা ইউজারের ইতিহাস মুছবে না।").setPositiveButton("মুছুন",(d,w)->submit("DELETE")).setNegativeButton("বাতিল",null).show();}
    private void submit(String action){submit629(action,false);}
    private void submit629(String action,boolean makeDefault){if(uploading629){toast("ছবি আপলোড শেষ হলে Save করুন");return;}String k=key.getText().toString().trim().toUpperCase().replace(' ','_');if(k.length()<2){key.setError("থিম কী দিন");return;}int order=parse(sort.getText().toString(),0),coinPrice=Math.max(0,parse(price.getText().toString(),0));String fm=fitMode.getSelectedItemPosition()==1?"FILL":(fitMode.getSelectedItemPosition()==2?"FIT":"CENTER_CROP");BackendClient.adminLiveTheme629(SessionManager.getToken(this),action,k,name.getText().toString().trim(),backgroundUrl,colorValue.getText().toString(),enabled.isChecked(),order,coinPrice,fm,makeDefault,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{toast("DELETE".equals(action)?"থিম মুছে ফেলা হয়েছে":"থিম সংরক্ষণ/প্রকাশ হয়েছে");loadPublished();});}public void onError(String m){runOnUiThread(()->toast(m));}});}
    private void loadLiveUiSettings(){BackendClient.liveUiSettings(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{float fs=(float)Math.max(14,Math.min(26,d.optDouble("joinFontSize",18)));joinFontSize.setProgress(Math.round(fs-14));joinPreview.setTextSize(fs);joinFontValue.setText("Font Size: "+((int)fs)+"sp");try{joinTextColor=Color.parseColor(d.optString("joinTextColor","#FFFFFF"));}catch(Exception e){joinTextColor=Color.WHITE;}joinPreview.setTextColor(joinTextColor);});}public void onError(String m){}});}
    private void saveJoinUi(){float fs=14f+joinFontSize.getProgress();String hex=String.format("#%06X",(0xFFFFFF & joinTextColor));BackendClient.adminLiveUiSettings(SessionManager.getToken(this),fs,hex,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->toast("Join font/color Save & Publish হয়েছে"));}public void onError(String m){runOnUiThread(()->toast(m));}});}

    private int parse(String s,int d){try{return Integer.parseInt(s.trim());}catch(Exception e){return d;}}

    private LinearLayout card(){LinearLayout c=col();c.setPadding(dp(12),dp(11),dp(12),dp(12));c.setBackground(round(Color.WHITE,Color.rgb(224,228,241),15));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(9);c.setLayoutParams(p);return c;}
    private TextView fieldLabel(String title,String desc){TextView v=t(title+"\n"+desc,11.5f,DARK,false);v.setLineSpacing(dp(2),1.05f);v.setPadding(dp(2),dp(5),dp(2),dp(9));return v;}
    private TextView note(String s){TextView v=t(s,11,DARK,false);v.setLineSpacing(dp(2),1.05f);v.setPadding(dp(10),dp(9),dp(10),dp(9));v.setBackground(round(Color.rgb(249,250,255),Color.rgb(229,232,243),12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(9);v.setLayoutParams(p);return v;}
    private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setTextSize(12);e.setTextColor(DARK);e.setPadding(dp(12),0,dp(12),0);e.setBackground(round(Color.WHITE,Color.rgb(215,220,235),12));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(50));p.bottomMargin=dp(8);e.setLayoutParams(p);return e;}
    private TextView action(String s,int color){TextView v=t(s,11,Color.WHITE,true);v.setGravity(Gravity.CENTER);v.setBackground(round(color,color,13));return v;}
    private TextView t(String s,float z,int c,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private GradientDrawable round(int fill,int stroke,int r){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(r));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
