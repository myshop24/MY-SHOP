package com.myshop.app;
import org.json.JSONArray;
import org.json.JSONObject;
/** Local editor drafts never publish automatically or overwrite a different card after reorder. */
final class MiniDraft617 {
 static int locate(JSONArray cards,String id){if(id==null||id.isEmpty())return -1;if(cards!=null)for(int i=0;i<cards.length();i++){JSONObject item=cards.optJSONObject(i);if(item!=null&&id.equals(item.optString("id")))return i;}return -2;}
 static boolean current(int request,int latest,int page,int selected){return request==latest&&page==selected;}
 static boolean conflict(int base,int current){return base>=0&&base!=current;}
 static boolean savedMatches(JSONObject saved,int revision,JSONArray submitted,boolean enabled){return saved!=null&&saved.optInt("revision",-1)==revision&&saved.optBoolean("enabled")==enabled&&saved.optJSONArray("cards")!=null&&saved.optJSONArray("cards").toString().equals(submitted.toString());}
 static String expiry(long now,int days){java.util.Calendar c=java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));c.setTimeInMillis(now);c.add(java.util.Calendar.DAY_OF_YEAR,days);java.text.SimpleDateFormat format=new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",java.util.Locale.US);format.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));return format.format(c.getTime());}
 private MiniDraft617(){}
}
