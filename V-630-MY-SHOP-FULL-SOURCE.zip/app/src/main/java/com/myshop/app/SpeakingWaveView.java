package com.myshop.app;
import android.content.Context;
import android.graphics.*;
import android.view.View;
/** Audio state affects only the surrounding wave, never the portrait. */
final class SpeakingWaveView extends View {
 private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);private boolean speaking;
 SpeakingWaveView(Context c){super(c);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
 void setSpeaking(boolean value){if(speaking!=value){speaking=value;invalidate();}}
 @Override protected void onDraw(Canvas c){super.onDraw(c);if(!speaking||!isShown())return;float side=Math.min(getWidth(),getHeight()),phase=(android.os.SystemClock.uptimeMillis()%1100)/1100f;paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(1,side*.025f));for(int i=0;i<2;i++){float p=(phase+i*.5f)%1;paint.setColor(i==0?0xffffd970:0xff59e7ff);paint.setAlpha((int)(210*(1-p)));c.drawCircle(getWidth()/2f,getHeight()/2f,side*(.405f+.07f*p),paint);}postInvalidateOnAnimation();}
}
