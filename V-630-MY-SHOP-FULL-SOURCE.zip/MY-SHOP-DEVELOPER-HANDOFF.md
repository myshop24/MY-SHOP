Current V630 / 2.9.630: owner-requested next full GitHub APK source ZIP from delivered V629. App behavior unchanged; version identities and delivery instructions corrected. Keep existing permanent repository pipeline; upload ZIP unchanged. Read GITHUB-UPLOAD-V630-BN.md and handoffs/MY-SHOP-V630-HANDOFF.md. No local APK claimed. Next delivery V631. Latest owner instructions override older workflow-install notes.

Current V629 / 2.9.629 source checkpoint: owner-approved corrections, source checks complete; full Android/device/production acceptance pending. Read V629-APPROVED-WORK-BN.md, handoffs/MY-SHOP-V629-HANDOFF.md and GITHUB-UPLOAD-V629-BN.md. Gradle download blocked locally; no APK bundled. Next changed delivery V630. Latest owner instructions override historical notes below.

# MY SHOP V628 / 2.9.628 — developer handoff

Continued from delivered V627 full ZIP (SHA256 963942c6e8c2f12817c88544ef1ca02add88a772231af4f968134fb62850c7f8). This is the next complete source/build package, not a claim that all original1–10 references passed phone acceptance. Next changed delivery V629. No bundled APK; no remote write, build trigger, Worker/D1 deployment or production test was performed.

## Implemented current scope

| Step | Source change | Evidence / practical limit |
|---|---|---|
| 1 | Actual LevelBadge626 draws pulsing halo, outline, moving facet shimmer and sparkles; stable readable level number; attach/visibility/detach frame lifecycle | Actual Java draw/lifecycle methods compiled with Android doubles at12 levels. No phone animation recording/quality acceptance |
| 2 | Moving Join measures content width with bounded name and small trailing shine/padding, removing weighted blank area | Source/Java syntax checked; actual small-screen motion/fitting pending |
| 3 | Comment renders independently before gift effects, receiver names carried in receipt/event, monotonic same-combo message updates; complete idempotent receipt stored in charging transaction | Actual Java dispatch compiled; SQLite verifies one charge, rollback and delivery-error acknowledgement. Two-device realtime pending |
| 4 | Main Admin reserves/claims4–8-digit special IDs; existing account public ID preview/confirm preserves internal UID and retires old numbers; available Rare catalog edits update registry atomically | Verified Google claim/rollback/duplicate/ownership tests and SQLite alias/Rare tests. Ordinary serial allocator unchanged |
| 5 | Readable Rare preview, user photo/name and old→new public ID; server availability preview then explicit confirm; product preview can select/continue real batch grant | Read-only preview and transactional save/grant tested; complete Android dialog execution pending |
| 6 | Original lower Send visual size/position retained, touch target expanded within existing layout; busy feedback; one network-error retry with same nonce; recovered receipt renders once | Compiled send/quote/persist methods tested. Real touchscreen/network latency pending |
| 7 | Alias-aware Admin grant, Rare ID claim/replacement, explicit draft office-grant; owned themes retain individual source/expiry and switch; owned missing-media fallback matches preview | SQLite ten-theme inventory/switch and Rare history/rollback tested. Host room background/device asset playback pending |
| 8 | Applied COMMENT_STYLE takes priority over later frame, bubble text/picture fitting revised; friend ID4–8 resolves internal recipient, pending confirmation and idempotent approval ownership | SQLite ephemeral comment style and8-digit friend hold/retry/approval/expiry tested. Real rendered multiline bubble/Gift unboxing pending |

Draft/unpublished paid catalog items still require Admin-configured Diamond price and publication. Explicit Main Admin office-grant permits draft entitlement without changing price/publication. Never invent a price or treat this gate as a transaction failure. Rare available number edits retire the former number; sold/held/previously used numbers cannot be renamed/reissued. Previous owned Rare records remain history, not an Apply option.

## Preserved behavior

Original package com.myshop.app, signing configuration/certificate, database bindings, existing baseline entries and asset bytes retained. Lower Send design, ordinary serial registration, original internal UIDs/account relations, balances/commission/ledger, historical levels and normal Join entry retained. Office double-level remains cancelled; earned-source rules and shared100000Coin/1000Diamond point calculation preserved. No existing Level replay/recalculation. See verification/V628-PRESERVATION.json and V628-SOURCE-CHANGES.json.

## Build and setup

Read GITHUB-UPLOAD-V628-BN.md and SIGNING-SETUP.md. JDK17, Node22+, Python3.12/pinned tools/requirements-build-assets.txt, ffmpeg/DejaVu, Android SDK/build-tools36, Gradle8.11.1. Existing asset generators restore build outputs; use the pinned toolchain and keep hash checks. Original release signing key/cache or configured original-key restoration, plus Firebase setup, are required. No plaintext secrets are included in this handoff.

Current targeted check: `bash tools/v628_target_verify.sh`. Full configured build: `bash tools/ci-apk-build.sh`. Gradle preBuild includes current V628 plus retained V626/V627 guards. Included .github/workflows/my-shop-apk.yml uses exact github.sha, newest version selection, clean build/test/lint, original certificate, package/version and provenance checks and one canonical APK artifact. It does not deploy Worker/D1. Legacy root pipeline snapshots remain historical and may deploy Worker first; uploading only ZIP does not replace the external workflow.

APK628 must use backend628 for new public-ID preview, grant and receipt behavior. Backend deploy is separate and was not performed here. Preserve existing D1/R2 settings and secrets; do not reset database. Asset file hashes were preserved, but inherited generated-avatar toolchain reproducibility remains open locally; see archived V627-ASSET-CHECK.log. This limitation has not been hidden by changing expected hashes.

## Verification and remaining work

See verification/V628-RESULTS.md and actual logs. Local SQLite tests are not production Cloudflare D1. Java syntax/double tests are not full Android symbol compilation. Full Android/signed APK was blocked before compilation by unavailable Gradle distribution network and no local SDK; log V628-ANDROID-BUILD.log. No APK size or on-device claim can be supplied before that build. The observed successful GitHub run690 was V627, not this V628 source.

Next: clean GitHub Android build then verify intended SHA/version/certificate/provenance/APK size; inspect phone rendering against owner images; test Host/Guest/Audience audio, reconnect/end, two-device Join/Gift/Combo/comments, payment/push and item application. Compact badge glow/premium quality needs actual phone acceptance. Inherited original1–10 gaps include full reference fidelity, premium media quality, Rare suggestion UI and eventual automatic general5–8-digit internal registration migration. Current ordinary auto allocator retains its legacy4-digit internal capacity; the approved Admin/public4–8-digit path is implemented. No claim of that future general migration.

## Google Play check

Checked official Android target-SDK and Play UGC policy sources for this task (2026-10-15). Existing targetSdk36 retained; UGC reporting/block/moderation and payments still need release-wide review and real behavior checks. No blanket policy-compliance or future approval guarantee. Sources: https://developer.android.com/google/play/requirements/target-sdk and https://support.google.com/googleplay/android-developer/answer/9876937?hl=en . No billing/commission policy change was introduced by these corrections.
