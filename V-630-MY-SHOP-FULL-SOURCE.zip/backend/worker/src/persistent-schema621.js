// Schema completion survives isolate restarts. No user data, permission or balance is cached.
export async function persistentSchema621(DB,key,initialize){
 const marker='schema621:'+key;
 let ready;try{ready=await DB.prepare('SELECT value FROM myshop_schema_meta WHERE key=?').bind(marker).first();}catch(e){if(!/no such table.*myshop_schema_meta/i.test(String(e?.message||e)))throw e;}
 if(ready?.value==='complete')return;
 await initialize();
 await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_schema_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
 await DB.prepare(`INSERT INTO myshop_schema_meta(key,value,updated_at) VALUES(?,'complete',CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value='complete',updated_at=CURRENT_TIMESTAMP`).bind(marker).run();
}
