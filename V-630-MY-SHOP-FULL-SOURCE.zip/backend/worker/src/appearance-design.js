// V593: focused text styling using the established visual-design validator,
// draft/publish storage and audit table. Never changes user IDs, routes or Live.
import {normalizeVisualStyles,publicVisualStyles,schema} from './visual-design.js';
const OWNER="user_id IN ('0001','0002','0003') AND role='ADMIN' AND active=1";
const protectedFeature=key=>/(?:^|_)(?:live[0-9]*|rtc|audio|room|gift|gifts)(?:_|$)/.test(key);
export function appearanceTarget(value){
 const target=String(value||'');
 if(/^identity_[0-9]{4}$/.test(target))return {target,user:target.slice(9),permission:'identity',keys:['element_name','element_id']};
 if(/^post_[1-9][0-9]{0,14}$/.test(target))return {target,post:Number(target.slice(5)),permission:'status',keys:['element_caption']};
 if(target==='headline')return {target,keys:['element_headline']};
 if(/^feature_[a-z0-9_]{1,80}$/.test(target)&&!protectedFeature(target))return {target,keys:['element_title','element_caption']};
 throw Error('PROTECTED_OR_INVALID_TARGET');
}
export function normalizeAppearance(input,info){
 if(!input||typeof input!=='object'||Array.isArray(input))throw Error('INVALID_STYLES');
 const base={},extras={};for(const [key,value] of Object.entries(input)){if(!value||typeof value!=='object'||Array.isArray(value))throw Error('INVALID_TARGET');const copy={...value};extras[key]={};if('bold' in copy){if(typeof copy.bold!=='boolean')throw Error('INVALID_BOLD');extras[key].bold=copy.bold;delete copy.bold;}if('align' in copy){if(!['START','CENTER','END'].includes(copy.align))throw Error('INVALID_ALIGNMENT');extras[key].align=copy.align;delete copy.align;}base[key]=copy;}
 const styles=normalizeVisualStyles(base,2);for(const [key,value] of Object.entries(extras))Object.assign(styles[key],value);
 const permitted=new Set(['text','textEnd','word','segments','background','backgroundEnd','fontSize','bold','align']);
 for(const [key,s] of Object.entries(styles)){
  if(!info.keys.includes(key)||Object.keys(s).some(k=>!permitted.has(k)))throw Error('INVALID_APPEARANCE_PROPERTY');
  if(info.permission==='identity'&&(s.fontSize!==undefined||(s.segments||[]).some(p=>p.fontSize!==undefined)))throw Error('IDENTITY_SIZE_LOCKED');
 }
 return styles;
}
export async function grantSchema(DB){await schema(DB);await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_appearance_grants(user_id TEXT PRIMARY KEY,identity INTEGER NOT NULL DEFAULT 0,status INTEGER NOT NULL DEFAULT 0,revision INTEGER NOT NULL DEFAULT 0,actor_id TEXT,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();}
export async function appearanceDesign(request,env,h){
 const fail=(error,status=400)=>h.json({error},status,h.cors);
 const me=await h.getUser(request,env);if(!me)return fail('UNAUTHORIZED',401);
 const auth=await env.DB.prepare('SELECT user_id,role,active FROM myshop_auth_users_v108 WHERE user_id=?').bind(me.user_id).first();
 if(!auth||Number(auth.active)!==1)return fail('UNAUTHORIZED',401);
 const owner=['0001','0002','0003'].includes(String(me.user_id))&&auth.role==='ADMIN';
 const url=new URL(request.url);if(!['GET','POST'].includes(request.method))return fail('METHOD_NOT_ALLOWED',405);
 let b={};if(request.method==='POST'){try{b=await request.json();}catch(_){return fail('INVALID_JSON');}}
 if(!b||typeof b!=='object'||Array.isArray(b))return fail('INVALID_JSON');
 if(url.pathname==='/v1/admin/appearance-grant'){
  if(!owner)return fail('OWNER_PERMISSION_REQUIRED',403);
  const id=String(request.method==='POST'?b.userId:url.searchParams.get('userId')||'');if(!/^[0-9]{4}$/.test(id))return fail('INVALID_USER');
  const user=await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=?').bind(id).first();if(!user)return fail('USER_NOT_FOUND',404);
  await grantSchema(env.DB);
  const old=await env.DB.prepare('SELECT * FROM myshop_appearance_grants WHERE user_id=?').bind(id).first();
  if(request.method==='GET')return h.json({ok:true,userId:id,identity:Number(old?.identity||0)===1,status:Number(old?.status||0)===1,revision:Number(old?.revision||0)},200,h.cors);
  if(typeof b.identity!=='boolean'||typeof b.status!=='boolean'||!Number.isSafeInteger(b.expectedRevision))return fail('INVALID_GRANT');
  const revision=Number(old?.revision||0);if(b.expectedRevision!==revision)return fail('REVISION_CONFLICT',409);
  const acl=`EXISTS(SELECT 1 FROM myshop_auth_users_v108 WHERE user_id=? AND ${OWNER})`;
  const write=old?env.DB.prepare(`UPDATE myshop_appearance_grants SET identity=?,status=?,revision=revision+1,actor_id=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=? AND revision=? AND ${acl}`).bind(+b.identity,+b.status,me.user_id,id,revision,me.user_id):env.DB.prepare(`INSERT OR IGNORE INTO myshop_appearance_grants(user_id,identity,status,revision,actor_id) SELECT ?,?,?,1,? WHERE ${acl}`).bind(id,+b.identity,+b.status,me.user_id,me.user_id);
  const after=JSON.stringify({identity:b.identity,status:b.status});
  const results=await env.DB.batch([write,env.DB.prepare('INSERT INTO myshop_visual_design_events(scope,actor_id,action,revision,old_payload,new_payload) SELECT ?,?,?,?,?,? WHERE changes()=1').bind('appearance-grant:'+id,me.user_id,'GRANT',revision+1,JSON.stringify(old||{}),after)]);
  if(!Number(results[0]?.meta?.changes))return fail('REVISION_OR_PERMISSION_CHANGED',409);
  return h.json({ok:true,userId:id,identity:b.identity,status:b.status,revision:revision+1},200,h.cors);
 }
 let info;try{info=appearanceTarget(request.method==='POST'?b.target:url.searchParams.get('target'));}catch(e){return fail(e.message,403);}
 if(info.post){const post=await env.DB.prepare("SELECT user_id,status FROM myshop_posts WHERE id=?").bind(info.post).first();if(!post||post.status!=='ACTIVE')return fail('POST_NOT_FOUND',404);info.user=post.user_id;}
 if(info.permission==='identity'&&!await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=?').bind(info.user).first())return fail('USER_NOT_FOUND',404);
 await grantSchema(env.DB);
 const grant=info.user?await env.DB.prepare('SELECT * FROM myshop_appearance_grants WHERE user_id=?').bind(info.user).first():null;
 const canEdit=(!info.post||String(info.user)===String(me.user_id))&&(owner||String(info.user)===String(me.user_id)&&Number(grant?.[info.permission])===1);
 const scope='appearance:'+info.target;
 const old=await env.DB.prepare('SELECT * FROM myshop_visual_designs WHERE scope=?').bind(scope).first();
 const revision=Number(old?.revision||0),draftRevision=Number(old?.draft_revision||0);
 const publicStyles=async raw=>{const copy=JSON.parse(raw||'{}');for(const style of Object.values(copy))for(const part of style.segments||[])part.sourceLength=part.source.length;return publicVisualStyles(copy);};
 const response=async row=>({ok:true,target:info.target,canEdit,revision:Number(row?.revision||0),styles:await publicStyles(row?.published),...(canEdit?{draftRevision:Number(row?.draft_revision||0),draft:JSON.parse(row?.draft||'{}')}:{}),...(info.permission==='identity'&&String(info.user)===String(me.user_id)?{permissions:{identity:owner||Number(grant?.identity)===1,status:owner||Number(grant?.status)===1}}:{})});
 if(request.method==='GET'){
  const result=await response(old);
  if(canEdit&&url.searchParams.get('history')==='1')result.history=(await env.DB.prepare("SELECT id,revision,actor_id,created_at FROM myshop_visual_design_events WHERE scope=? AND action='PUBLISH' ORDER BY id DESC LIMIT 30").bind(scope).all()).results||[];
  return h.json(result,200,h.cors);
 }
 if(!canEdit)return fail('APPEARANCE_PERMISSION_REQUIRED',403);
 if(!['SAVE_DRAFT','PUBLISH','RESTORE_DRAFT'].includes(b.action)||!Number.isSafeInteger(b.expectedRevision)||!Number.isSafeInteger(b.expectedDraftRevision))return fail('INVALID_CHANGE');
 if(b.expectedRevision!==revision||b.expectedDraftRevision!==draftRevision)return fail('REVISION_CONFLICT',409);
 let input=b.styles;
 if(b.action==='RESTORE_DRAFT'){
  if(!Number.isSafeInteger(b.eventId)||b.eventId<1)return fail('INVALID_HISTORY_ITEM');
  const event=await env.DB.prepare("SELECT new_payload FROM myshop_visual_design_events WHERE id=? AND scope=? AND action='PUBLISH'").bind(b.eventId,scope).first();if(!event)return fail('HISTORY_NOT_FOUND',404);input=JSON.parse(event.new_payload);
 }
 if(b.action==='PUBLISH'&&!old)return fail('SAVE_DRAFT_FIRST',409);
 let styles;try{styles=normalizeAppearance(b.action==='PUBLISH'?JSON.parse(old.draft):input,info);}catch(e){return fail(e.message);}
 const publish=b.action==='PUBLISH',payload=JSON.stringify(styles);
 // Recheck roles/grants inside the write, so a racing revocation cannot publish.
 const acl=`EXISTS(SELECT 1 FROM myshop_auth_users_v108 a WHERE a.user_id=? AND a.active=1 AND ((a.${OWNER.replaceAll(' AND ',' AND a.')} )${info.permission?' OR (a.user_id=? AND EXISTS(SELECT 1 FROM myshop_appearance_grants g WHERE g.user_id=a.user_id AND g.'+info.permission+'=1))':''}))`;
 const params=[me.user_id,...(info.permission?[info.user]:[])];
 const contentAcl=info.post?" AND EXISTS(SELECT 1 FROM myshop_posts WHERE id=? AND user_id=? AND status='ACTIVE')":'';
 const contentParams=info.post?[info.post,me.user_id]:[];
 const write=old?env.DB.prepare(`UPDATE myshop_visual_designs SET ${publish?'published=?,revision=revision+1':'draft=?,draft_revision=draft_revision+1'},actor_id=?,updated_at=CURRENT_TIMESTAMP WHERE scope=? AND revision=? AND draft_revision=? AND ${acl}${contentAcl}`).bind(payload,me.user_id,scope,revision,draftRevision,...params,...contentParams):env.DB.prepare(`INSERT OR IGNORE INTO myshop_visual_designs(scope,draft,draft_revision,actor_id) SELECT ?,?,1,? WHERE ${acl}${contentAcl}`).bind(scope,payload,me.user_id,...params,...contentParams);
 const result=await env.DB.batch([write,env.DB.prepare('INSERT INTO myshop_visual_design_events(scope,actor_id,action,revision,old_payload,new_payload) SELECT ?,?,?,?,?,? WHERE changes()=1').bind(scope,me.user_id,b.action,publish?revision+1:draftRevision+1,publish?old?.published||'{}':old?.draft||'{}',payload)]);
 if(!Number(result[0]?.meta?.changes))return fail('REVISION_OR_PERMISSION_CHANGED',409);
 return h.json(await response(await env.DB.prepare('SELECT * FROM myshop_visual_designs WHERE scope=?').bind(scope).first()),200,h.cors);
}
