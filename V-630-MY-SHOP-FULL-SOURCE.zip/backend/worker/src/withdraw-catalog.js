import { effectiveCommission } from './commission-management.js';
const currencies=new Set(['COIN','GOLD']);
export async function catalogSchema(DB){
  await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_withdraw_catalog(currency TEXT PRIMARY KEY,revision INTEGER NOT NULL DEFAULT 0,payload TEXT NOT NULL,actor_id TEXT NOT NULL,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
  await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_withdraw_catalog_audit(id INTEGER PRIMARY KEY AUTOINCREMENT,currency TEXT NOT NULL,revision INTEGER NOT NULL,actor_id TEXT NOT NULL,old_payload TEXT NOT NULL,new_payload TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
}
export function normalizeCatalog(input){
  if(!input||typeof input!=='object'||Array.isArray(input)||!Array.isArray(input.amounts)||input.amounts.length<1||input.amounts.length>30)throw Error('INVALID_CATALOG');
  for(const key of ['enabled','published'])if(input[key]!==undefined&&typeof input[key]!=='boolean')throw Error('INVALID_AVAILABILITY');
  const amounts=[...new Set(input.amounts)];if(amounts.some(x=>!Number.isSafeInteger(x)||x<1000||x>2000000000))throw Error('INVALID_AMOUNT');
  if(!Array.isArray(input.methods)||!input.methods.length||input.methods.some(x=>!['bkash','nagad','rocket','bank'].includes(x)))throw Error('INVALID_METHOD');
  const processingDays=Number(input.processingDays||0),unitsPer600Taka=Number(input.unitsPer600Taka||0);
  if(!Number.isSafeInteger(processingDays)||processingDays<0||processingDays>90||!Number.isSafeInteger(unitsPer600Taka)||unitsPer600Taka<0||unitsPer600Taka>2000000000)throw Error('INVALID_TERMS');
  const startsAt=String(input.startsAt||''),endsAt=String(input.endsAt||'');for(const date of [startsAt,endsAt])if(date&&!Number.isFinite(Date.parse(date)))throw Error('INVALID_DATE');
  if(startsAt&&endsAt&&Date.parse(startsAt)>=Date.parse(endsAt))throw Error('INVALID_DATE_RANGE');
  const extra={};
  if(input.feeMode!==undefined){if(!['INCLUDED','ADDITIONAL'].includes(input.feeMode))throw Error('INVALID_FEE_MODE');extra.feeMode=input.feeMode;}
  if(input.withdrawalCommissionPercent!==undefined){const percent=input.withdrawalCommissionPercent;if(typeof percent!=='number'||!Number.isFinite(percent)||percent<0||percent>100||Math.abs(Math.round(percent*100)-percent*100)>0.000001)throw Error('INVALID_WITHDRAW_COMMISSION');extra.withdrawalCommissionPercent=percent;}
  if(input.takaPer100000Minor!==undefined){const minor=input.takaPer100000Minor;if(!Number.isSafeInteger(minor)||minor<0||minor>100000000)throw Error('INVALID_CONVERSION');extra.takaPer100000Minor=minor;}
  return {amounts:amounts.sort((a,b)=>a-b),methods:[...new Set(input.methods)],processingDays,unitsPer600Taka,enabled:input.enabled!==false,published:input.published!==false,startsAt,endsAt,...extra};
}
export async function readCatalog(DB,currency){
  if(!currencies.has(currency))throw Error('INVALID_CURRENCY');await catalogSchema(DB);
  const row=await DB.prepare('SELECT * FROM myshop_withdraw_catalog WHERE currency=?').bind(currency).first();
  const config=row?normalizeCatalog(JSON.parse(row.payload)):normalizeCatalog({amounts:[300000,500000,1000000,1500000,2000000,2500000,3000000,4000000,5000000],methods:['bkash','nagad','rocket'],enabled:true,published:true,feeMode:'ADDITIONAL'});
  return {currency,revision:Number(row?.revision||0),...config};
}
export function termsFor(catalog,finance,gross,now=Date.now()){
  if(!catalog.enabled||!catalog.published||catalog.startsAt&&Date.parse(catalog.startsAt)>now||catalog.endsAt&&Date.parse(catalog.endsAt)<=now)return {error:'WITHDRAWAL_UNAVAILABLE'};
  if(!catalog.amounts.includes(gross))return {error:'INVALID_WITHDRAW_AMOUNT'};
  const fallback=catalog.withdrawalCommissionPercent??(catalog.currency==='GOLD'?finance.goldCommissionPercent:finance.coinCommissionPercent);
  const percent=finance.commissionConfig?effectiveCommission(finance.commissionConfig,catalog.currency,'WITHDRAW',fallback,now):fallback;
  const fee=Math.round(gross*percent/100),additional=finance.commissionConfig?.master623?true:catalog.feeMode!=='INCLUDED',net=additional?gross:gross-fee,unitsPer600Taka=catalog.unitsPer600Taka||finance.unitsPer600Taka;
  const totalDeducted=additional?gross+fee:gross;
  if(!Number.isSafeInteger(totalDeducted)||!Number.isFinite(percent)||percent<0||percent>100)throw Error('INVALID_PAYOUT_VALUE');
  const cashMinor=catalog.takaPer100000Minor?Number(BigInt(net)*BigInt(catalog.takaPer100000Minor)/100000n):Math.floor(net/unitsPer600Taka*60000);
  if(!Number.isSafeInteger(cashMinor)||cashMinor<0)throw Error('INVALID_PAYOUT_VALUE');
  return {currency:catalog.currency,catalogRevision:catalog.revision,grossAmount:gross,serviceFeePercent:percent,serviceFeeAmount:fee,netAmount:net,totalDeducted,feeMode:additional?'ADDITIONAL':'INCLUDED',takaPer100000Minor:catalog.takaPer100000Minor||0,cashMinor,processingDays:catalog.processingDays,unitsPer600Taka};
}
export async function withdrawCatalog(request,env,h){
  const me=await h.getUser(request,env);if(!me)return h.json({error:'UNAUTHORIZED'},401,h.cors);
  const active=await env.DB.prepare('SELECT active FROM myshop_auth_users_v108 WHERE user_id=?').bind(me.user_id).first();if(Number(active?.active)!==1)return h.json({error:'UNAUTHORIZED'},401,h.cors);
  const admin=new URL(request.url).pathname.startsWith('/v1/admin/');
  if(admin&&!['0001','0002','0003'].includes(String(me.user_id)))return h.json({error:'OWNER_FINANCE_PERMISSION_REQUIRED'},403,h.cors);
  if(!['GET','POST'].includes(request.method)||request.method==='POST'&&!admin)return h.json({error:'METHOD_NOT_ALLOWED'},405,h.cors);
  let b={};if(request.method==='POST'){try{b=await request.json();}catch(_){return h.json({error:'INVALID_JSON'},400,h.cors);}}
  const currency=String(b.currency||new URL(request.url).searchParams.get('currency')||'COIN');if(!currencies.has(currency))return h.json({error:'INVALID_CURRENCY'},400,h.cors);
  const old=await readCatalog(env.DB,currency);
  if(request.method==='GET'){
    if(admin){const finance=await h.financeConfig(env,'WITHDRAW');return h.json({ok:true,...old,effectiveWithdrawalCommissionPercent:finance.commissionConfig?effectiveCommission(finance.commissionConfig,currency,'WITHDRAW',old.withdrawalCommissionPercent??(currency==='GOLD'?finance.goldCommissionPercent:finance.coinCommissionPercent)):(old.withdrawalCommissionPercent??(currency==='GOLD'?finance.goldCommissionPercent:finance.coinCommissionPercent)),effectiveUnitsPer600Taka:old.unitsPer600Taka||finance.unitsPer600Taka},200,h.cors);}
    const finance=await h.financeConfig(env,'WITHDRAW'),quotes=old.amounts.map(n=>termsFor(old,finance,n)).filter(x=>!x.error);
    return h.json({ok:true,currency,revision:old.revision,methods:quotes.length?old.methods:[],quotes},200,h.cors);
  }
  if(!Number.isSafeInteger(b.expectedRevision)||b.expectedRevision!==old.revision)return h.json({error:'REVISION_CONFLICT'},409,h.cors);
  let next;try{next=normalizeCatalog(b.config);}catch(e){return h.json({error:e.message},400,h.cors);}
  const finance623=await h.financeConfig(env,'WITHDRAW');if(b.config.withdrawalCommissionPercent===undefined&&old.withdrawalCommissionPercent!==undefined)next.withdrawalCommissionPercent=old.withdrawalCommissionPercent;if(finance623.commissionConfig?.master623&&next.withdrawalCommissionPercent!==old.withdrawalCommissionPercent)return h.json({error:'USE_MASTER_COMMISSION_PANEL'},409,h.cors);
  const revision=old.revision+1,payload=JSON.stringify(next),acl="EXISTS(SELECT 1 FROM myshop_auth_users_v108 WHERE user_id=? AND active=1 AND user_id IN ('0001','0002','0003'))";
  const write=old.revision?env.DB.prepare(`UPDATE myshop_withdraw_catalog SET payload=?,revision=revision+1,actor_id=?,updated_at=CURRENT_TIMESTAMP WHERE currency=? AND revision=? AND ${acl}`).bind(payload,me.user_id,currency,old.revision,me.user_id):env.DB.prepare(`INSERT OR IGNORE INTO myshop_withdraw_catalog(currency,revision,payload,actor_id) SELECT ?,1,?,? WHERE ${acl}`).bind(currency,payload,me.user_id,me.user_id);
  const results=await env.DB.batch([write,env.DB.prepare('INSERT INTO myshop_withdraw_catalog_audit(currency,revision,actor_id,old_payload,new_payload) SELECT ?,?,?,?,? WHERE changes()=1').bind(currency,revision,me.user_id,JSON.stringify(old),payload)]);
  if(!Number(results[0]?.meta?.changes))return h.json({error:'REVISION_OR_PERMISSION_CHANGED'},409,h.cors);
  return h.json({ok:true,currency,revision,...next},200,h.cors);
}
