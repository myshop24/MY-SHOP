// Opt-in server metrics. Log statement fingerprints + metadata only, never SQL, bound values or tokens.
const wrapped=new WeakMap(),rawStatements=new WeakMap();
export function queryId621(sql){let h=2166136261;for(const c of sql){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return (h>>>0).toString(16);}
export function diagnoseDb621(DB,enabled=false){
 if(!enabled)return DB;let cached=wrapped.get(DB);if(cached)return cached;
 function record(sql,r){const meta=r?.meta||{};if(Number(meta.rows_read||0)>=100)console.info(JSON.stringify({kind:'D1_READ621',queryId:queryId621(sql),rowsRead:Number(meta.rows_read||0),rowsWritten:Number(meta.rows_written||0),durationMs:Number(meta.duration||0)}));return r;}
 function stmt(raw,sql){const proxy=new Proxy(raw,{get(target,key){if(key==='bind')return (...args)=>stmt(target.bind(...args),sql);if(key==='all'||key==='run')return async()=>record(sql,await target[key]());if(key==='first')return async(column)=>{const r=record(sql,await target.all()),row=r.results?.[0]||null;if(row&&column!==undefined&&!(column in row))throw Error('D1_ERROR: Column not found');return row&&column!==undefined?row[column]:row;};const v=target[key];return typeof v==='function'?v.bind(target):v;}});rawStatements.set(proxy,{raw,sql});return proxy;}
 cached=new Proxy(DB,{get(target,key){if(key==='prepare')return sql=>stmt(target.prepare(sql),sql);if(key==='batch')return async statements=>{const infos=statements.map(s=>rawStatements.get(s)||{raw:s,sql:''});const results=await target.batch(infos.map(i=>i.raw));return results.map((r,i)=>record(infos[i].sql,r));};const value=target[key];return typeof value==='function'?value.bind(target):value;}});wrapped.set(DB,cached);return cached;
}
