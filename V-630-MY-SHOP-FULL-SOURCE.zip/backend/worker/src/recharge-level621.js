// V626: preserve all existing levels/counters. Never rebuild historical earnings.
export async function rechargeSchema621(env){}
export async function reconcileRecharge621(env,userId){
 await env.DB.prepare(`INSERT OR IGNORE INTO myshop_user_progress(user_id,level) VALUES(?,?)`).bind(userId,['0001','0002','0003'].includes(String(userId))?0:1).run();
 return env.DB.prepare('SELECT * FROM myshop_user_progress WHERE user_id=?').bind(userId).first();
}
export function remaining621(pr){
 const coin=Number(pr?.normal_coin_units||0)+Number(pr?.official_coin_units||0),diamond=Number(pr?.normal_gold_units||0)+Number(pr?.official_gold_units||0),points=coin+diamond*100,remain=100000-points%100000;
 return {level:Number(pr?.level??1),coinRemaining:remain,goldRemaining:Math.ceil(remain/100),officeCoinRemaining:remain,officeGoldRemaining:Math.ceil(remain/100),officeMultiplier:1,totalCoin:coin,totalDiamond:diamond,qualifyingPoints:points,progressPoints:100000-remain};
}
