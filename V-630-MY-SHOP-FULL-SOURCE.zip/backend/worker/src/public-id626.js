// Public ID changes never rewrite auth, wallets, friendships or RTC foreign keys.
export async function publicIdSchema626(DB){
 await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_public_id_audit626(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,old_id TEXT NOT NULL,new_id TEXT NOT NULL UNIQUE,admin_id TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
 await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_id_guard626(ok INTEGER CHECK(ok=1))`).run();
}
export async function adminPublicId626(request,env,h){
 const me=await h.getUser(request,env),fail=(error,status=400)=>h.json({error},status,h.cors);
 if(!me)return fail('UNAUTHORIZED',401);
 if(!['0001','0002','0003'].includes(me.user_id)||me.role!=='ADMIN')return fail('MAIN_ADMIN_ONLY',403);
 await publicIdSchema626(env.DB);await h.specialIdSchema(env.DB);
 const b=await request.json().catch(()=>({})),requestedId=String(b.userId||''),number=String(b.number||'');
 if(!/^\d{4,8}$/.test(requestedId)||!/^\d{4,8}$/.test(number)||Number(number)<4||b.confirm!==true&&b.preview!==true)return fail('INVALID_PUBLIC_ID');
 const alias=await env.DB.prepare("SELECT owner_id FROM myshop_rare_ids611 WHERE number=? AND state='OWNED'").bind(requestedId).first();const uid=alias?.owner_id||requestedId;
 if(!/^\d{4}$/.test(uid))return fail('USER_NOT_FOUND',404);
 if(['0001','0002','0003'].includes(uid))return fail('ADMIN_ID_PROTECTED',403);
 const user=await env.DB.prepare('SELECT user_id,full_name FROM myshop_auth_users_v108 WHERE user_id=?').bind(uid).first();if(!user)return fail('USER_NOT_FOUND',404);
 const prior=await env.DB.prepare("SELECT number FROM myshop_rare_ids611 WHERE owner_id=? AND state='OWNED'").bind(uid).first(),old=prior?.number||uid;
 if(old!==String(b.expectedId||''))return fail('ID_CHANGED_RELOAD',409);
 if(old===number)return fail('ID_UNCHANGED',409);
 if(b.preview===true){const conflict=await env.DB.prepare('SELECT 1 used FROM myshop_auth_users_v108 WHERE user_id=? UNION ALL SELECT 1 FROM myshop_rare_ids611 WHERE number=? UNION ALL SELECT 1 FROM myshop_special_id_reservations WHERE user_id=? UNION ALL SELECT 1 FROM myshop_public_id_audit626 WHERE old_id=? OR new_id=? LIMIT 1').bind(number,number,number,number,number).first();if(conflict)return fail('ID_IN_USE_OR_RESERVED',409);return h.json({ok:true,preview:true,user:{userId:uid,name:user.full_name},oldId:old,publicId:number},200,h.cors);}
 try{await env.DB.batch([
 env.DB.prepare(`INSERT INTO myshop_id_guard626(ok) SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM myshop_auth_users_v108 WHERE user_id=?) AND NOT EXISTS(SELECT 1 FROM myshop_rare_ids611 WHERE number=?) AND NOT EXISTS(SELECT 1 FROM myshop_special_id_reservations WHERE user_id=?) AND NOT EXISTS(SELECT 1 FROM myshop_public_id_audit626 WHERE old_id=? OR new_id=?) AND COALESCE((SELECT number FROM myshop_rare_ids611 WHERE owner_id=? AND state='OWNED'),?)=? THEN 1 ELSE 0 END`).bind(number,number,number,number,number,uid,uid,old),
 env.DB.prepare("UPDATE myshop_rare_ids611 SET state='RETIRED',owner_id=NULL,holder_id=NULL WHERE owner_id=? AND state='OWNED'").bind(uid),
 env.DB.prepare("INSERT OR IGNORE INTO myshop_rare_ids611(number,state) VALUES(?,'RETIRED')").bind(old),
 env.DB.prepare("INSERT INTO myshop_rare_ids611(number,state,owner_id) VALUES(?,'OWNED',?)").bind(number,uid),
 env.DB.prepare('INSERT INTO myshop_public_id_audit626(user_id,old_id,new_id,admin_id) VALUES(?,?,?,?)').bind(uid,old,number,me.user_id),
 env.DB.prepare('DELETE FROM myshop_id_guard626')]);}catch(_){return fail('ID_IN_USE_OR_RESERVED',409);}
 h.invalidate();return h.json({ok:true,user:{userId:uid,publicId:number,name:user.full_name},oldId:old,publicId:number},200,h.cors);
}
