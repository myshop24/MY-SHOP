import {schemaOnce} from './schema-once.js';
import {persistentSchema621} from './persistent-schema621.js';
export const indexes621=[
 ['notifications','idx621_notifications_audience','audience,user_id,status,id'],
 ['myshop_value_ledger','idx621_value_receiver_currency','receiver_id,currency,status,tx_type'],
 ['myshop_star_level_ledger','idx621_progress_receiver','receiver_id,official,currency'],
 ['myshop_gold_transactions','idx621_gold_user_kind','user_id,kind,id'],
 ['myshop_live_gift_events','idx621_gift_host_sender','host_id,status,sender_id'],
 ['myshop_live_votes','idx621_vote_host','host_id'],
 ['myshop_live_history','idx621_history_host','host_id,id'],
 ['myshop_owned_items','idx621_owned_user_equipped','user_id,equipped,item_type,id'],
 ['myshop_user_badges','idx621_badge_user_status','user_id,status,is_displayed,id'],
 ['myshop_live_schedules','idx621_schedule_status_time','status,scheduled_at'],
 ['myshop_store_audit','idx621_store_audit_catalog','catalog_id,action'],
 ['myshop_deleted_media','idx621_deleted_state','state,updated_at,object_key'],
 ['myshop_live_gift_events','idx625_gift_recent','host_id,status,datetime(created_at),id'],
 ['myshop_live_entry_events','idx625_entry_recent','host_id,datetime(created_at),id'],
 ['myshop_live_requests','idx625_request_session','host_id,status,session_id,datetime(created_at)'],
 ['myshop_live_invites','idx625_invite_expiry','host_id,status,datetime(expires_at)'],
 ['myshop_store_purchase_requests','idx625_purchase_user_status','user_id,status,catalog_id'],
 ['myshop_gold_transactions','idx625_refund_reference','user_id,kind,reference']
];
export function ensureReadIndexes621(env){return schemaOnce(env.DB,'read_indexes625',()=>persistentSchema621(env.DB,'read_indexes625',async()=>{for(const [table,name,columns] of indexes621){const exists=await env.DB.prepare("SELECT 1 present FROM sqlite_master WHERE type='table' AND name=?").bind(table).first();if(exists)await env.DB.prepare(`CREATE INDEX IF NOT EXISTS ${name} ON ${table}(${columns})`).run();}}));}
