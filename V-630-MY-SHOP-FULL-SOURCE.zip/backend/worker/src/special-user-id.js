// Keep the established immutable four-digit auth/financial/Live identity contract.
export async function specialIdSchema(DB){
 await DB.prepare("CREATE TABLE IF NOT EXISTS myshop_rare_ids611 (number TEXT PRIMARY KEY,catalog_id INTEGER UNIQUE,state TEXT NOT NULL DEFAULT 'AVAILABLE',holder_id TEXT,owner_id TEXT UNIQUE,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)").run();
 await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_special_id_reservations(user_id TEXT PRIMARY KEY,email TEXT NOT NULL UNIQUE,status TEXT NOT NULL DEFAULT 'RESERVED',actor_id TEXT NOT NULL,reason TEXT NOT NULL,claimed_at TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
 await DB.prepare(`CREATE TABLE IF NOT EXISTS myshop_special_id_audit(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT NOT NULL,email TEXT NOT NULL,actor_id TEXT NOT NULL,action TEXT NOT NULL,reason TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)`).run();
}
export async function specialUserId(request,env,h){
 const fail=(error,status=400)=>h.json({error},status,h.cors),me=await h.getUser(request,env);if(!me)return fail('UNAUTHORIZED',401);
 const role=await env.DB.prepare('SELECT active,role FROM myshop_auth_users_v108 WHERE user_id=?').bind(me.user_id).first();
 if(!['0001','0002','0003'].includes(String(me.user_id))||Number(role?.active)!==1||role?.role!=='ADMIN')return fail('MAIN_ADMIN_ONLY',403);
 if(!['GET','POST'].includes(request.method))return fail('METHOD_NOT_ALLOWED',405);
 await specialIdSchema(env.DB);
 if(request.method==='GET'){const rows=(await env.DB.prepare('SELECT user_id,email,status,actor_id,created_at,claimed_at FROM myshop_special_id_reservations ORDER BY created_at DESC,user_id LIMIT 100').all()).results||[];return h.json({ok:true,reservations:rows,idDigits:8,minIdDigits:4,newAccountsOnly:true},200,h.cors);}
 const b=await request.json().catch(()=>null);if(!b)return fail('INVALID_JSON');
 const uid=String(b.userId||''),email=String(b.email||'').trim().toLowerCase(),reason=String(b.reason||'').trim();
 if(!/^\d{4,8}$/.test(uid)||Number(uid)<100||!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)||email.length>254||!reason||reason.length>300||b.confirm!==true)return fail('INVALID_SPECIAL_ID');
 if(await h.ownerAdminIdForIdentifier(email))return fail('PROTECTED_ADMIN_IDENTITY',403);
 const existing=await env.DB.prepare('SELECT user_id FROM myshop_auth_users_v108 WHERE user_id=? OR email=? LIMIT 1').bind(uid,email).first();if(existing)return fail('EXISTING_ACCOUNT_CANNOT_CHANGE_ID',409);
 const prior=await env.DB.prepare('SELECT * FROM myshop_special_id_reservations WHERE user_id=? OR email=? LIMIT 1').bind(uid,email).first();
 if(prior)return prior.user_id===uid&&prior.email===email?h.json({ok:true,userId:uid,status:prior.status,alreadyReserved:true},200,h.cors):fail('ID_OR_EMAIL_RESERVED',409);
 try{await env.DB.batch([
  env.DB.prepare(`INSERT INTO myshop_special_id_reservations(user_id,email,actor_id,reason) SELECT ?,?,?,? WHERE NOT EXISTS(SELECT 1 FROM myshop_auth_users_v108 WHERE user_id=? OR email=?) AND NOT EXISTS(SELECT 1 FROM myshop_rare_ids611 WHERE number=?)`).bind(uid,email,String(me.user_id),reason,uid,email,uid),
  env.DB.prepare(`INSERT INTO myshop_special_id_audit(user_id,email,actor_id,action,reason) SELECT ?,?,?,'RESERVE',? WHERE changes()=1`).bind(uid,email,String(me.user_id),reason)
 ]);}catch(_){return fail('ID_OR_EMAIL_RESERVED',409);}
 const saved=await env.DB.prepare('SELECT user_id,email,status FROM myshop_special_id_reservations WHERE user_id=? AND email=?').bind(uid,email).first();if(!saved)return fail('ACCOUNT_CHANGED_RELOAD',409);
 return h.json({ok:true,userId:uid,status:'RESERVED',verificationRequired:'GOOGLE_EMAIL',newAccountsOnly:true},201,h.cors);
}
export async function newAccountIdentity(DB,email,verified){
 await specialIdSchema(DB);
 const reservation=email?await DB.prepare("SELECT user_id,email,status FROM myshop_special_id_reservations WHERE email=? AND status='RESERVED'").bind(email).first():null;
 if(reservation&&!verified)return{error:'VERIFY_SPECIAL_ID_WITH_GOOGLE'};
 if(reservation&&reservation.user_id.length===4)return{userId:reservation.user_id,reservation};
 let n=Number((await DB.prepare('SELECT COALESCE(MAX(CAST(user_id AS INTEGER))+1,100) n FROM myshop_auth_users_v108 WHERE CAST(user_id AS INTEGER)>=100').first())?.n||100);
 const reserved=new Set(((await DB.prepare('SELECT user_id FROM myshop_special_id_reservations').all()).results||[]).map(r=>r.user_id));
 for(const r of (await DB.prepare("SELECT number FROM myshop_rare_ids611").all()).results||[])reserved.add(r.number);
 while(n<=9999&&reserved.has(String(n).padStart(4,'0')))n++;
 return n<=9999?{userId:String(n).padStart(4,'0'),reservation}:{error:'NO_ID_AVAILABLE'};
}
export async function insertSpecialAccount(DB,columns,values,reservation){
 const uid=String(values[columns.indexOf('user_id')]),email=String(values[columns.indexOf('email')]);
 if((reservation.user_id.length===4?uid!==reservation.user_id:!/^\d{4}$/.test(uid))||email!==reservation.email||values[columns.indexOf('role')]!=='USER')throw Error('INVALID_RESERVED_ACCOUNT');
 // Column names are fixed by our registration code, never accepted from a request.
 if(columns.some(c=>!['user_id','full_name','email','mobile','password_hash','security_q1','security_a1_hash','security_q2','security_a2_hash','security_q3','security_a3_hash','role','avatar_url','gender'].includes(c)))throw Error('INVALID_ACCOUNT_COLUMNS');
 if(reservation.user_id.length>4){
  await specialIdSchema(DB);const number=reservation.user_id;
  const inserted=await DB.batch([
   DB.prepare(`INSERT INTO myshop_auth_users_v108(${columns.join(',')}) SELECT ${columns.map(()=>'?').join(',')} WHERE EXISTS(SELECT 1 FROM myshop_special_id_reservations WHERE user_id=? AND email=? AND status='RESERVED') AND NOT EXISTS(SELECT 1 FROM myshop_rare_ids611 WHERE number IN (?,?)) AND NOT EXISTS(SELECT 1 FROM myshop_special_id_reservations WHERE user_id=?)`).bind(...values,number,email,number,uid,uid),
   DB.prepare("INSERT INTO myshop_rare_ids611(number,state,owner_id) SELECT ?,'OWNED',? WHERE changes()=1").bind(number,uid),
   DB.prepare("UPDATE myshop_special_id_reservations SET status='CLAIMED',claimed_at=CURRENT_TIMESTAMP WHERE user_id=? AND email=? AND status='RESERVED' AND changes()=1").bind(number,email),
   DB.prepare("INSERT INTO myshop_special_id_audit(user_id,email,actor_id,action,reason) SELECT user_id,email,?,'CLAIM','Verified Google email; stable account identity' FROM myshop_special_id_reservations WHERE user_id=? AND email=? AND status='CLAIMED' AND changes()=1").bind(uid,number,email)
  ]);if(!inserted[0]?.meta?.changes)throw Error('RESERVATION_CHANGED');return;
 }
 const results=await DB.batch([
  DB.prepare(`INSERT INTO myshop_auth_users_v108(${columns.join(',')}) SELECT ${columns.map(()=>'?').join(',')} WHERE EXISTS(SELECT 1 FROM myshop_special_id_reservations WHERE user_id=? AND email=? AND status='RESERVED') AND NOT EXISTS(SELECT 1 FROM myshop_rare_ids611 WHERE number=?)`).bind(...values,uid,email,uid),
  DB.prepare("UPDATE myshop_special_id_reservations SET status='CLAIMED',claimed_at=CURRENT_TIMESTAMP WHERE user_id=? AND email=? AND status='RESERVED' AND changes()=1").bind(uid,email),
  DB.prepare("INSERT INTO myshop_special_id_audit(user_id,email,actor_id,action,reason) SELECT user_id,email,user_id,'CLAIM','Verified Google email' FROM myshop_special_id_reservations WHERE user_id=? AND email=? AND status='CLAIMED' AND changes()=1").bind(uid,email)
 ]);if(!results[0]?.meta?.changes)throw Error('RESERVATION_CHANGED');
}

export async function insertUnreservedAccount(DB,columns,values){
 if(columns.some(c=>!['user_id','full_name','email','mobile','password_hash','security_q1','security_a1_hash','security_q2','security_a2_hash','security_q3','security_a3_hash','role','avatar_url','gender'].includes(c)))throw Error('INVALID_ACCOUNT_COLUMNS');
 await specialIdSchema(DB);
 const uid=values[columns.indexOf('user_id')],email=values[columns.indexOf('email')];
 const result=await DB.prepare(`INSERT INTO myshop_auth_users_v108(${columns.join(',')}) SELECT ${columns.map(()=>'?').join(',')} WHERE NOT EXISTS(SELECT 1 FROM myshop_special_id_reservations WHERE user_id=? OR (email=? AND status='RESERVED')) AND NOT EXISTS(SELECT 1 FROM myshop_rare_ids611 WHERE number=?)`).bind(...values,uid,email,uid).run();
 if(!result?.meta?.changes)throw Error('ACCOUNT_OR_ID_CHANGED_RETRY');
}
