# MY SHOP V630 / 2.9.630

Upload V-630-MY-SHOP-FULL-SOURCE.zip unchanged to existing MY-SHOP root/main, as before. Keep the existing permanent workflow and root my-shop-release.sh. Read GITHUB-UPLOAD-V630-BN.md. Open MY SHOP PERMANENT RELEASE PIPELINE, not Pages. Successful artifact: MY-SHOP-FINAL-V-630 → MY_SHOP_FINAL_RELEASE.apk.

Full Android/Worker source, matching V630 identities. No bundled APK/local Android build claim. V629 app behavior unchanged; version/current delivery docs updated. Original signing/Firebase/Cloudflare setup retained. Existing permanent pipeline deploys matching Worker before APK; no remote changes performed here. Included build-only workflow is optional, not a replacement requirement.

Tests: node --test tests/*.test.mjs tests/*.spec.cjs; bash tools/v629_target_verify.sh. See handoffs/MY-SHOP-V630-HANDOFF.md and verification/V630-RESULTS.md. Historical limitations retained. Next delivery V631.
