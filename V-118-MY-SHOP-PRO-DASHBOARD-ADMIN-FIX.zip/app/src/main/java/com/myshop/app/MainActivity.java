package com.myshop.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;

/**
 * MY SHOP dashboard: compact, responsive, border-free cards and remote-config aware.
 * No authentication/database behavior is changed here.
 */
public class MainActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(248,249,253), BLUE=Color.rgb(56,54,190), NAVY=Color.rgb(18,32,75), DARK=Color.rgb(35,38,52), RED=Color.rgb(238,35,52);
    private final Handler handler=new Handler(); private int slide=0; private ImageView hero; private ImageView[] promoViews=new ImageView[3]; private String[] remoteHeroUrls=new String[6]; private String[] remotePromoUrls=new String[3]; private TextView dots,newsText;
    private final int[] heroImgs={R.drawable.banner_wide_1,R.drawable.banner_wide_2,R.drawable.banner_wide_3,R.drawable.banner_wide_4,R.drawable.banner_wide_5,R.drawable.banner_wide_6};
    private final int[] left={R.drawable.banner_top_left_1,R.drawable.banner_top_left_2,R.drawable.banner_top_left_3,R.drawable.banner_top_left_4,R.drawable.banner_top_left_5,R.drawable.banner_top_left_6};
    private final int[] right={R.drawable.banner_top_right_1,R.drawable.banner_top_right_2,R.drawable.banner_top_right_3,R.drawable.banner_top_right_4,R.drawable.banner_top_right_5,R.drawable.banner_top_right_6};
    private final int[] live={R.drawable.dash_live1,R.drawable.dash_live2,R.drawable.dash_live3,R.drawable.dash_live4};

    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(build());loadRemote();startCarousel();}

    private View build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(BG);
        ScrollView sv=new ScrollView(this); sv.setVerticalScrollBarEnabled(false); sv.setFillViewport(true);
        LinearLayout page=col(); page.setPadding(dp(12),dp(8),dp(12),dp(66));
        page.addView(header(),lp(-1,dp(58)));
        hero=pic(heroImgs[0]); page.addView(hero,top(lp(-1,dp(126)),6));
        dots=text("●   ○   ○   ○   ○   ○",BLUE,10,true); dots.setGravity(Gravity.CENTER); page.addView(dots,lp(-1,dp(18)));
        page.addView(triplePromos(),top(lp(-1,dp(76)),1));
        page.addView(breaking(),top(lp(-1,dp(36)),4));
        page.addView(sectionTitle("🔴  LIVE NOW",true),top(lp(-1,dp(28)),3));
        page.addView(liveRow(),lp(-1,dp(102)));
        page.addView(actionRow(),top(lp(-1,dp(62)),5));
        page.addView(featureGrid(),top(lp(-1,-2),5));
        sv.addView(page,new ScrollView.LayoutParams(-1,-2)); root.addView(sv,new FrameLayout.LayoutParams(-1,-1));
        root.addView(bottom(),new FrameLayout.LayoutParams(-1,dp(56),Gravity.BOTTOM)); return root;
    }

    private View header(){
        LinearLayout h=row(); h.setGravity(Gravity.CENTER_VERTICAL); h.setPadding(dp(2),0,dp(2),0);
        h.setBackground(round(Color.WHITE,Color.TRANSPARENT,dp(22)));
        Button menu=icon("☰",NAVY,25); menu.setOnClickListener(v->{if(SessionManager.isAdmin(this))startActivity(new android.content.Intent(this,AdminManagementActivity.class));else startActivity(new android.content.Intent(this,AccountActivity.class));}); h.addView(menu,lp(dp(42),dp(54)));
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.myshop_icon); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); h.addView(logo,lp(dp(46),dp(52)));
        TextView brand=text("MY SHOP",Color.rgb(24,28,70),16,true); brand.setGravity(Gravity.CENTER_VERTICAL); h.addView(brand,weight(0.70f,dp(50)));
        EditText search=new EditText(this); search.setSingleLine(true); search.setTextSize(11); search.setHint("খুঁজুন পণ্য, লাইভ..."); search.setPadding(dp(10),0,dp(6),0); search.setBackground(round(Color.WHITE,Color.rgb(228,229,235),dp(24))); h.addView(search,weight(1.05f,dp(42)));
        Button bell=icon("♧",NAVY,23); bell.setOnClickListener(v->toast("Notifications")); h.addView(bell,lp(dp(38),dp(50)));
        ImageView av=new ImageView(this); av.setImageResource(R.drawable.myshop_profile_avatar); av.setScaleType(ImageView.ScaleType.CENTER_CROP); av.setBackground(round(Color.WHITE,Color.TRANSPARENT,dp(20))); av.setClipToOutline(true); av.setOnClickListener(v->startActivity(new android.content.Intent(this,AccountActivity.class))); h.addView(av,lp(dp(40),dp(40)));
        return h;
    }

    private View triplePromos(){LinearLayout r=row(); ImageView a=pic(left[0]),b=pic(right[0]),c=pic(R.drawable.banner_wide_2); promoViews[0]=a;promoViews[1]=b;promoViews[2]=c; r.addView(a,weight(1,dp(74))); r.addView(space(),lp(dp(6),1)); r.addView(b,weight(1,dp(74))); r.addView(space(),lp(dp(6),1)); r.addView(c,weight(1,dp(74))); return r;}

    private View breaking(){
        LinearLayout b=row(); b.setPadding(dp(2),dp(2),dp(2),dp(2)); b.setBackground(round(Color.WHITE,Color.TRANSPARENT,dp(12)));
        TextView l=text("• BREAKING",Color.WHITE,7.5f,true); l.setGravity(Gravity.CENTER); l.setSingleLine(true); l.setBackground(round(RED,RED,dp(7))); b.addView(l,lp(dp(76),dp(28)));
        newsText=text("বাংলাদেশে আজ স্বর্ণের দাম কিছুটা কমেছে...",Color.rgb(20,45,110),10.5f,true); newsText.setGravity(Gravity.CENTER_VERTICAL); newsText.setSingleLine(true); newsText.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE); newsText.setMarqueeRepeatLimit(-1); newsText.setSelected(true); newsText.setPadding(dp(8),0,dp(2),0); b.addView(newsText,weight(1,dp(28)));
        TextView arrow=text("›",NAVY,22,true); arrow.setGravity(Gravity.CENTER); b.addView(arrow,lp(dp(22),dp(28))); return b;
    }

    private View sectionTitle(String title,boolean all){LinearLayout h=row(); h.addView(text(title,DARK,13,true),weight(1,dp(28))); if(all)h.addView(text("সব দেখুন ›",BLUE,9.5f,true),lp(dp(64),dp(28))); return h;}
    private View liveRow(){HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);LinearLayout r=row();for(int i=0;i<4;i++){ImageView v=pic(live[i]);final int idx=i;v.setOnClickListener(x->openFeature("LIVE "+(idx+1),"live_now"));r.addView(v,lp(dp(122),dp(100)));if(i<3)r.addView(space(),lp(dp(6),1));}hs.addView(r,new HorizontalScrollView.LayoutParams(-2,-1));return hs;}
    private View actionRow(){LinearLayout r=row(); ImageView liveBtn=pic(R.drawable.dash_action_live),go=pic(R.drawable.dash_action_go),feed=pic(R.drawable.dash_action_feed); liveBtn.setOnClickListener(v->openFeature("LIVE","live_now"));go.setOnClickListener(v->openFeature("GO LIVE","go_live"));feed.setOnClickListener(v->openFeature("MY FEED","my_feed"));r.addView(liveBtn,weight(1,dp(62)));r.addView(space(),lp(dp(6),1));r.addView(go,weight(1,dp(62)));r.addView(space(),lp(dp(6),1));r.addView(feed,weight(1,dp(62)));return r;}

    private View featureGrid(){
        LinearLayout grid=col(); LinearLayout r1=row(),r2=row();
        r1.addView(tile(R.drawable.dash_feat_shop,"MY SHOP","my_shop"),weight(1,dp(56)));r1.addView(space(),lp(dp(4),1));
        r1.addView(tile(R.drawable.dash_feat_gallery,"GALLERY","gallery"),weight(1,dp(56)));r1.addView(space(),lp(dp(4),1));
        r1.addView(tile(R.drawable.dash_feat_tv,"LIVE TV","live_tv"),weight(1,dp(56)));r1.addView(space(),lp(dp(4),1));
        r1.addView(tile(R.drawable.dash_feat_movie,"EXTERNAL","external_movie"),weight(1,dp(56)));
        r2.addView(tile(R.drawable.dash_feat_social,"SOCIAL","social_media"),weight(1,dp(56)));r2.addView(space(),lp(dp(4),1));
        r2.addView(tile(R.drawable.dash_feat_reward,"EARN & REWARD","earn_reward"),weight(1,dp(56)));r2.addView(space(),lp(dp(4),1));
        r2.addView(tile(R.drawable.dash_feat_share,"SHARE","share"),weight(1,dp(56)));r2.addView(space(),lp(dp(4),1));
        r2.addView(tile(R.drawable.dash_feat_apps,"MORE APPS","more"),weight(1,dp(56)));
        grid.addView(r1,lp(-1,dp(56)));grid.addView(r2,top(lp(-1,dp(56)),4));return grid;
    }
    private View tile(int res,String title,String key){ImageView v=pic(res);v.setContentDescription(title);v.setOnClickListener(x->openFeature(title,key));return v;}

    private View bottom(){LinearLayout n=row();n.setBackground(round(Color.WHITE,Color.TRANSPARENT,dp(18)));String[] labels={"⌂\nHOME","🛒\nSTORE","◉\nLIVE","💬\nCHAT","▦\nMORE"};for(int i=0;i<5;i++){Button b=icon(labels[i],i==0?BLUE:Color.rgb(95,98,110),9);final int j=i;b.setOnClickListener(v->{if(j==1)openFeature("MY SHOP","my_shop");else if(j==2)openFeature("LIVE","live_now");else if(j==3)openFeature("CHAT","chat");else if(j==4)startActivity(new android.content.Intent(this,AccountActivity.class));});n.addView(b,weight(1,dp(52)));}return n;}

    private void loadRemote(){BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(org.json.JSONObject d){runOnUiThread(()->applyRemote(d));}public void onError(String m){}});}
    private void applyRemote(org.json.JSONObject d){
        try{
            org.json.JSONObject c=d.optJSONObject("config"); if(c!=null){String n=c.optString("breaking_news","").trim();if(!n.isEmpty())newsText.setText(n); saveRemoteUrl("my_shop",c.optString("my_shop_url","")); saveRemoteUrl("live_tv",c.optString("live_tv_url","")); saveRemoteUrl("external_movie",c.optString("external_movie_url","")); saveRemoteUrl("chat",c.optString("chat_url",""));}
            org.json.JSONArray banners=d.optJSONArray("banners"); if(banners!=null){for(int i=0;i<banners.length();i++){org.json.JSONObject o=banners.optJSONObject(i);if(o==null)continue;String folder=o.optString("folder","");int slot=o.optInt("slot",0);String url=o.optString("image_url","").trim();if(url.isEmpty())continue;if("hero".equalsIgnoreCase(folder)&&slot>=1&&slot<=6){remoteHeroUrls[slot-1]=url;if(slot==slide+1)loadRemoteImage(hero,url);}else if("promo".equalsIgnoreCase(folder)&&slot>=1&&slot<=3){remotePromoUrls[slot-1]=url;loadRemoteImage(promoViews[slot-1],url);}}}
            org.json.JSONArray social=d.optJSONArray("socialLinks"); if(social!=null){for(int i=0;i<social.length();i++){org.json.JSONObject o=social.optJSONObject(i);if(o==null)continue;String url=o.optString("url","").trim();if(!url.isEmpty())getSharedPreferences("myshop_remote_config",MODE_PRIVATE).edit().putString("social_"+o.optString("platform","").toLowerCase(),url).apply();}}
            org.json.JSONArray gallery=d.optJSONArray("gallery"); if(gallery!=null&&gallery.length()>0){String url=gallery.optJSONObject(0)!=null?gallery.optJSONObject(0).optString("media_url",""):"";saveRemoteUrl("gallery",url);}
        }catch(Exception ignored){}
    }
    private void saveRemoteUrl(String key,String url){if(url!=null&&!url.trim().isEmpty())getSharedPreferences("myshop_remote_config",MODE_PRIVATE).edit().putString("url_"+key,url.trim()).apply();}
    private void loadRemoteImage(ImageView target,String url){Executors.newSingleThreadExecutor().execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(10000);c.setInstanceFollowRedirects(true);try(InputStream in=c.getInputStream()){Bitmap bm=BitmapFactory.decodeStream(in);if(bm!=null)runOnUiThread(()->target.setImageBitmap(bm));}}catch(Exception ignored){}});}
    private void startCarousel(){handler.postDelayed(new Runnable(){public void run(){slide=(slide+1)%6;if(remoteHeroUrls[slide]!=null&&!remoteHeroUrls[slide].isEmpty())loadRemoteImage(hero,remoteHeroUrls[slide]);else hero.setImageResource(heroImgs[slide]);StringBuilder s=new StringBuilder();for(int i=0;i<6;i++){s.append(i==slide?"●":"○");if(i<5)s.append("   ");}dots.setText(s.toString());handler.postDelayed(this,3500);}},3500);}
    private void openFeature(String title,String key){try{android.content.Intent i=new android.content.Intent(this,FeatureActivity.class);i.putExtra("title",title);i.putExtra("feature_key",key);String url=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("url_"+key,""); if("social_media".equals(key)&&url.isEmpty())url=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("social_"+"facebook",""); if(FeatureRegistry.isSafeHttpUrl(url))i.putExtra("url",url); else { url=FeatureRegistry.getUrl(this,key); if(FeatureRegistry.isSafeHttpUrl(url))i.putExtra("url",url); }startActivity(i);}catch(Throwable t){toast(title+" is ready.");}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private ImageView pic(int r){ImageView v=new ImageView(this);v.setImageResource(r);v.setScaleType(ImageView.ScaleType.FIT_XY);v.setBackgroundColor(Color.TRANSPARENT);v.setClipToOutline(false);return v;}
    private Button icon(String s,int c,float z){Button b=new Button(this);b.setText(s);b.setTextColor(c);b.setTextSize(z);b.setGravity(Gravity.CENTER);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setPadding(0,0,0,0);b.setBackgroundColor(Color.TRANSPARENT);return b;}
    private TextView text(String s,int c,float z,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private View space(){return new View(this);}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private GradientDrawable round(int fill,int stroke,int rad){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(rad));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}@Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
}
