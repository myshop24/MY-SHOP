package com.myshop.app;

import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;

/** Server-authorized admin content console. No user IDs or legacy data are reset. */
public class AdminManagementActivity extends AppCompatActivity {
    private EditText news, shopUrl, tvUrl, movieUrl, chatUrl, modId;
    private EditText[] heroUrls = new EditText[6], promoUrls = new EditText[3];
    private EditText[] socialPlatforms = new EditText[6], socialUrls = new EditText[6];
    private EditText[] galleryTitles = new EditText[3], galleryUrls = new EditText[3];
    private LinearLayout root;
    private final int purple=Color.rgb(83,32,180), dark=Color.rgb(20,28,60), bg=Color.rgb(247,248,252);

    @Override protected void onCreate(Bundle savedInstanceState){super.onCreate(savedInstanceState);if(!SessionManager.isAdmin(this)){finish();return;}buildUi();loadCurrentConfig();}

    private void buildUi(){
        ScrollView scroll=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(18,18,18,42);root.setBackgroundColor(bg);
        TextView title=text("MY SHOP • ADMIN CONTROL",25,dark,true);title.setGravity(Gravity.CENTER);root.addView(title,lp(-1,58));
        TextView sub=text("Admin ID: "+SessionManager.getUserId(this)+"  •  Server authorized",13,Color.DKGRAY,false);sub.setGravity(Gravity.CENTER);root.addView(sub,lp(-1,32));
        root.addView(section("① Dashboard / Headline"));
        news=field("Breaking News headline");shopUrl=field("MY SHOP URL");tvUrl=field("LIVE TV URL");movieUrl=field("External Movie URL");chatUrl=field("Chat URL");
        root.addView(section("② Main Hero Banners • 6 slots"));
        for(int i=0;i<6;i++) heroUrls[i]=field("Hero Banner "+(i+1)+" image URL (https://...)"); for(int i=0;i<3;i++) promoUrls[i]=field("Promo Banner "+(i+1)+" image URL (https://...)");
        TextView bnNote=text("Banner image changes are remote-config changes; APK rebuild is not required after the backend is deployed.",12,Color.DKGRAY,false);bnNote.setPadding(0,4,0,8);root.addView(bnNote);
        root.addView(section("③ Social Links • edit / disable"));
        for(int i=0;i<6;i++){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);socialPlatforms[i]=field("Platform "+(i+1));socialUrls[i]=field("URL");r.addView(socialPlatforms[i],weight(.35f));r.addView(socialUrls[i],weight(.65f));root.addView(r);}
        root.addView(section("④ Gallery • photo / video / audio links"));
        for(int i=0;i<3;i++){galleryTitles[i]=field("Gallery item "+(i+1)+" title");galleryUrls[i]=field("Media URL (https://...)");}
        TextView gNote=text("Gallery entries are stored as remote media links. Existing records are not deleted by saving other dashboard settings.",12,Color.DKGRAY,false);gNote.setPadding(0,4,0,8);root.addView(gNote);
        Button save=button("SAVE ALL DASHBOARD CONTENT");save.setOnClickListener(v->saveAll());root.addView(save,lp(-1,58));
        root.addView(section("⑤ Moderators • maximum 5"));modId=field("4-digit User ID");LinearLayout mr=new LinearLayout(this);mr.setOrientation(LinearLayout.HORIZONTAL);Button add=button("ADD MODERATOR"),remove=button("REMOVE MODERATOR");add.setOnClickListener(v->moderator("add_moderator"));remove.setOnClickListener(v->moderator("remove_moderator"));mr.addView(add,weight(1));mr.addView(remove,weight(1));root.addView(mr);
        TextView note=text("Admin-only controls stay hidden from normal users. Permanent User IDs and existing database records are never reset here.",12,Color.DKGRAY,false);note.setPadding(0,18,0,12);root.addView(note);
        Button back=button("BACK");back.setOnClickListener(v->finish());root.addView(back,lp(-1,52));scroll.addView(root);setContentView(scroll);
    }

    private void loadCurrentConfig(){BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{try{JSONObject c=d.optJSONObject("config");if(c!=null){news.setText(c.optString("breaking_news",""));shopUrl.setText(c.optString("my_shop_url",""));tvUrl.setText(c.optString("live_tv_url",""));movieUrl.setText(c.optString("external_movie_url",""));chatUrl.setText(c.optString("chat_url",""));}JSONArray bs=d.optJSONArray("banners");if(bs!=null)for(int i=0;i<bs.length();i++){JSONObject x=bs.optJSONObject(i);if(x!=null){int slot=x.optInt("slot",0);if("hero".equalsIgnoreCase(x.optString("folder",""))&&slot>=1&&slot<=6)heroUrls[slot-1].setText(x.optString("image_url","")); if("promo".equalsIgnoreCase(x.optString("folder",""))&&slot>=1&&slot<=3)promoUrls[slot-1].setText(x.optString("image_url",""));}}JSONArray ss=d.optJSONArray("socialLinks");if(ss!=null)for(int i=0;i<Math.min(6,ss.length());i++){JSONObject x=ss.optJSONObject(i);if(x!=null){socialPlatforms[i].setText(x.optString("platform",""));socialUrls[i].setText(x.optString("url",""));}}JSONArray gg=d.optJSONArray("gallery");if(gg!=null)for(int i=0;i<Math.min(3,gg.length());i++){JSONObject x=gg.optJSONObject(i);if(x!=null){galleryTitles[i].setText(x.optString("title",""));galleryUrls[i].setText(x.optString("media_url",""));}}}catch(Exception e){toast("Config read error");}});}public void onError(String m){runOnUiThread(()->toast("Config load: "+m));}});}

    private void saveAll(){
        try{
            BackendClient.adminDashboardPut(SessionManager.getToken(this),news.getText().toString().trim(),shopUrl.getText().toString().trim(),tvUrl.getText().toString().trim(),movieUrl.getText().toString().trim(),chatUrl.getText().toString().trim(),new BackendClient.Callback(){public void onSuccess(JSONObject d){saveRemoteContent();}public void onError(String m){toast("Dashboard save failed: "+m);}});
        }catch(Exception e){toast("Invalid dashboard content");}
    }
    private void saveRemoteContent(){try{
        JSONObject p=new JSONObject();JSONArray bs=new JSONArray();for(int i=0;i<6;i++)bs.put(new JSONObject().put("folder","hero").put("slot",i+1).put("imageUrl",heroUrls[i].getText().toString().trim()).put("caption","Hero "+(i+1)).put("active",!heroUrls[i].getText().toString().trim().isEmpty())); for(int i=0;i<3;i++)bs.put(new JSONObject().put("folder","promo").put("slot",i+1).put("imageUrl",promoUrls[i].getText().toString().trim()).put("caption","Promo "+(i+1)).put("active",!promoUrls[i].getText().toString().trim().isEmpty()));p.put("banners",bs);
        JSONArray ss=new JSONArray();for(int i=0;i<6;i++){String platform=socialPlatforms[i].getText().toString().trim();String url=socialUrls[i].getText().toString().trim();if(!platform.isEmpty())ss.put(new JSONObject().put("platform",platform).put("url",url).put("active",!url.isEmpty()));}p.put("socialLinks",ss);
        JSONArray gg=new JSONArray();for(int i=0;i<3;i++){String title=galleryTitles[i].getText().toString().trim(),url=galleryUrls[i].getText().toString().trim();if(!url.isEmpty())gg.put(new JSONObject().put("title",title).put("mediaUrl",url).put("mediaType","image").put("active",true).put("displayOrder",i+1));}p.put("gallery",gg);
        BackendClient.adminContentPut(SessionManager.getToken(this),p,new BackendClient.Callback(){public void onSuccess(JSONObject d){toast("All dashboard content saved.");}public void onError(String m){toast("Remote content save failed: "+m);}});
    }catch(Exception e){toast("Invalid remote content");}}

    private void moderator(String action){String id=modId.getText().toString().trim();if(!id.matches("\\d{4}")){toast("Enter a valid 4-digit User ID.");return;}BackendClient.adminAction(SessionManager.getToken(this),id,action,new BackendClient.Callback(){public void onSuccess(JSONObject d){toast(action.equals("add_moderator")?"Moderator added.":"Moderator removed.");}public void onError(String m){toast("Action failed: "+m);}});}
    private TextView section(String s){TextView t=text(s,18,purple,true);t.setPadding(0,16,0,7);return t;}
    private EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(14);e.setSingleLine(true);e.setPadding(14,0,14,0);root.addView(e,lp(-1,52));return e;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setAllCaps(false);return b;}
    private TextView text(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return t;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams weight(float w){return new LinearLayout.LayoutParams(0,52,w);}private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
}
