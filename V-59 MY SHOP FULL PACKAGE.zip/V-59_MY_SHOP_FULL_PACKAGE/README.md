# MY SHOP V-59

V-59 is the corrected full Android source package for MY SHOP.

The project keeps the selected Login/Register and Dashboard source, preserves the existing package ID `com.myshop.app`, and uses version `2.9.59` / versionCode `59`.

The GitHub Actions workflow builds directly from this project root and publishes exactly one signed APK: `MY_SHOP_V-59.apk`.

No source ZIP is copied into the release artifact.
