# V-59 Release Checklist

- [x] V-59 source root used directly
- [x] No dependency on a V-57/V-58 ZIP
- [x] No dependency on `gradlew`
- [x] Gradle 8.9 configured
- [x] Java 17 configured
- [x] Android SDK 35 configured
- [x] `com.myshop.app` package retained
- [x] Version 2.9.59 / code 59 retained
- [x] MS + LIVE app icon applied
- [x] Login/register brand image uses the same icon
- [x] XML files parsed successfully before packaging
- [x] Known searchBox listener regression explicitly blocked
- [x] Release APK is signed and verified
- [x] Package/version/signature/integrity verification included
- [x] Final release contains exactly one APK
- [x] GitHub artifact uploads only the APK
- [ ] Actual GitHub build must still complete successfully
- [ ] APK must be installed and launched on the target phone after build
