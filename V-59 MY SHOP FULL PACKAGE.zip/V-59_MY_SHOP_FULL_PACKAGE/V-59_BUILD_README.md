# V-59 MY SHOP — Full Build Package

This package is the corrected V-59 source root for GitHub Actions.

## Important fixes

1. The workflow no longer searches for a V-57/V-58 ZIP.
2. The Android project is built directly from this package root.
3. Gradle 8.9 is installed by the workflow, so a missing `gradlew` file cannot stop the build.
4. Java 17 and Android SDK 35 are used.
5. Version is fixed to **versionName 2.9.59 / versionCode 59**.
6. The approved MS + LIVE icon is used for the app icon and the login/register brand image.
7. APK package, version, signature and ZIP integrity are verified after signing.
8. The final release directory is checked to contain **exactly one APK and nothing else**.
9. GitHub Actions uploads **only `MY_SHOP_V-59.apk`** as the artifact.

## Signing

For a permanent upgrade path, configure these GitHub repository secrets:

- `MYSHOP_KEYSTORE_BASE64`
- `MYSHOP_KEYSTORE_PASSWORD`
- `MYSHOP_KEY_ALIAS`
- `MYSHOP_KEY_PASSWORD`

If those secrets are not configured, the workflow creates a temporary test signing key so the V-59 APK can still be installed for testing. A temporary key should not be used for production upgrades because a future build signed with a different key will not update it in place.

## Release rule

Do not put the source ZIP, another APK, a keystore, or any other file inside the release artifact. The release artifact must contain one APK only.
