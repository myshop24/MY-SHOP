# MY SHOP V-153

- V-152 is the preserved baseline; no destructive database/user-ID migration.
- 3-line menu is always the normal User Menu, including for Admin.
- Admin management opens from the feature/folder being managed; Admin controls are not shown to normal users.
- Social Links have per-row Save/Delete and link-based opening; existing social rows are preserved by backend upsert.
- Added Customer Support under More; Admin stores the WhatsApp URL, users only see the button and never the phone number.
- Added Share App in More and on User Profile using the Android share sheet.
- Feed action controls reduced in size; feed share now works.
- Removed the separate POWER AD strip beside MY FEED title.
- Added additive-only dashboard support_url column.
- No OTP/verification-code flow added.
- User account, Permanent User ID, D1 records and existing R2 objects are preserved; avatar replacement remains upload -> DB update -> old-object delete.
