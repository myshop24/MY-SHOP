package com.myshop.app;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;

/**
 * MY SHOP V-285 Premium Audio Live Room.
 * 10-seat authoritative layout: Seat 1 Host + Seats 2-10 Speakers.
 * The bundled Guitar Blue wallpaper is the safe default while Admin themes
 * can override it remotely without changing the Dashboard.
 */
public class AudioLiveRoomActivity extends AppCompatActivity {
    private final Handler handler = new Handler();
    private boolean host;
    private boolean hostStarted;
    private boolean localMicOn = true;
    private String hostId;
    private String specialGuestId = "";
    private String myRole = "AUDIENCE";
    private long startedAtMs = 0L;
    private int shareCount = 0;
    private ImageView wallpaper;
    private LinearLayout hostArea, specialArea, seats, requests, commentsList;
    private TextView viewers, status, syncState, durationView, roomTitle, roomTopic, pinnedView, shareView;
    private final Set<Integer> lockedSeats = new HashSet<>();

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (hostStarted || !host) {
                if (host) BackendClient.setLivePresence(token(), true, new Silent());
                else BackendClient.liveViewer(token(), hostId, true, new Silent());
                if (host || "SPEAKER".equals(myRole)) {
                    BackendClient.liveParticipantState(token(), hostId, localMicOn, false, networkQuality(), new Silent());
                }
                refresh();
            }
            handler.postDelayed(this, 5000);
        }
    };

    private final Runnable durationTick = new Runnable() {
        @Override public void run() {
            if (startedAtMs > 0 && durationView != null) {
                long sec = Math.max(0, (System.currentTimeMillis() - startedAtMs) / 1000L);
                durationView.setText("● LIVE  " + hhmmss(sec));
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        host = getIntent().getBooleanExtra("hostMode", false);
        hostId = host ? SessionManager.getUserId(this) : getIntent().getStringExtra("hostId");
        if (hostId == null || hostId.trim().isEmpty()) hostId = SessionManager.getUserId(this);
        build();
        renderLocalSkeleton();
        handler.post(durationTick);
        if (host) showHostSetup();
        else {
            BackendClient.liveViewer(token(), hostId, true, new Silent());
            handler.post(tick);
        }
    }

    private void showHostSetup() {
        LinearLayout box = col(); box.setPadding(dp(20), dp(4), dp(20), 0);
        EditText title = new EditText(this); title.setHint("Room title"); title.setText("Let's Talk Together");
        EditText topic = new EditText(this); topic.setHint("Topic"); topic.setText("Audio Live");
        box.addView(title, new LinearLayout.LayoutParams(-1, dp(52)));
        box.addView(topic, new LinearLayout.LayoutParams(-1, dp(52)));
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Start Audio Live")
                .setView(box)
                .setCancelable(false)
                .setPositiveButton("Go Live", null)
                .setNegativeButton("Cancel", (x,w) -> finish())
                .create();
        d.setOnShowListener(x -> d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String t = title.getText().toString().trim();
            String p = topic.getText().toString().trim();
            if (t.isEmpty()) t = "Let's Talk Together";
            if (p.isEmpty()) p = "Audio Live";
            d.dismiss(); startHostLive(t,p);
        }));
        d.show();
    }

    private void startHostLive(String title, String topic) {
        BackendClient.setLivePresence(token(), true, new BackendClient.Callback() {
            @Override public void onSuccess(JSONObject data) {
                hostStarted = true;
                BackendClient.liveRoomConfig(token(), title, topic, null, null, new Silent());
                runOnUiThread(() -> { syncState.setText("● LIVE • Room connected"); refresh(); handler.post(tick); });
            }
            @Override public void onError(String m) { runOnUiThread(() -> { syncState.setText("Could not start live"); Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show(); }); }
        });
    }

    private void build() {
        FrameLayout page = new FrameLayout(this);
        wallpaper = new ImageView(this);
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        wallpaper.setImageResource(R.drawable.live_guitar_wallpaper);
        page.addView(wallpaper, new FrameLayout.LayoutParams(-1,-1));

        ScrollView sc = new ScrollView(this); sc.setFillViewport(true); sc.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout root = col(); root.setPadding(dp(12), dp(10), dp(12), dp(24));
        root.setBackgroundColor(Color.argb(178, 3, 8, 34)); sc.addView(root);
        page.addView(sc, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout top = row(); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = t("👑 MY SHOP\nAUDIO LIVE", 17, Color.WHITE, true);
        top.addView(brand, new LinearLayout.LayoutParams(0, dp(54), 1));
        durationView = t("● LIVE  00:00:00", 12, Color.rgb(255,105,170), true);
        durationView.setGravity(Gravity.CENTER); durationView.setBackground(bg(Color.argb(190,35,16,67), Color.rgb(255,67,149), 18));
        top.addView(durationView, new LinearLayout.LayoutParams(dp(126), dp(38)));
        if (!host) {
            TextView close = t("✕", 22, Color.WHITE, true); close.setGravity(Gravity.CENTER); close.setOnClickListener(v -> finish());
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(42),dp(42)); cp.leftMargin=dp(6); top.addView(close,cp);
        }
        root.addView(top);

        roomTitle = t("🎙 Let's Talk Together", 17, Color.WHITE, true); roomTitle.setPadding(0,dp(7),0,0); root.addView(roomTitle);
        roomTopic = t("Audio Live", 12, Color.rgb(183,205,255), false); root.addView(roomTopic);
        viewers = t("👁 0 Listeners  •  Peak 0", 12, Color.rgb(177,208,255), true); root.addView(viewers);
        LinearLayout meta = row();
        status = t((host?"👑 Host":"🎧 Audience")+" • ID "+SessionManager.getUserId(this),11,Color.rgb(226,199,255),true);
        meta.addView(status,new LinearLayout.LayoutParams(0,dp(28),1));
        shareView=t("↗ 0",11,Color.rgb(226,199,255),true); shareView.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); meta.addView(shareView,new LinearLayout.LayoutParams(dp(70),dp(28)));
        root.addView(meta);
        syncState=t("● LIVE • Connecting…",10,Color.rgb(149,172,232),false); syncState.setPadding(0,0,0,dp(6)); root.addView(syncState);

        hostArea=col(); root.addView(hostArea,new LinearLayout.LayoutParams(-1,-2));
        specialArea=col(); specialArea.setGravity(Gravity.CENTER_HORIZONTAL); LinearLayout.LayoutParams sgp=new LinearLayout.LayoutParams(-1,-2); sgp.topMargin=dp(5); root.addView(specialArea,sgp);

        TextView seatTitle=t("SPEAKER SOFA • SEATS 2–10",11,Color.rgb(228,232,255),true); seatTitle.setGravity(Gravity.CENTER); seatTitle.setPadding(0,dp(7),0,dp(4)); root.addView(seatTitle);
        seats=col(); seats.setPadding(dp(4),dp(4),dp(4),dp(4)); seats.setBackground(bg(Color.argb(135,8,20,66),Color.rgb(88,71,218),18)); root.addView(seats,new LinearLayout.LayoutParams(-1,-2));

        if(host){
            TextView rq=t("Join Requests",13,Color.WHITE,true); rq.setPadding(0,dp(8),0,dp(3)); root.addView(rq);
            requests=col(); root.addView(requests); requests.addView(t("No pending requests",11,Color.LTGRAY,false));
        } else {
            Button req=btn("🎤 Request to Speak"); req.setOnClickListener(v->BackendClient.liveSpeakRequest(token(),hostId,new ToastCb("Request sent")));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(42)); rp.topMargin=dp(7); root.addView(req,rp);
        }

        pinnedView=t("📌 No pinned announcement",11,Color.rgb(255,224,138),true); pinnedView.setPadding(dp(8),dp(7),dp(8),dp(6)); pinnedView.setBackground(bg(Color.argb(125,25,26,66),Color.rgb(131,96,235),12));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,-2); pp.topMargin=dp(8); root.addView(pinnedView,pp);

        TextView chatTitle=t("💬 LIVE COMMENTS",13,Color.WHITE,true); chatTitle.setPadding(0,dp(8),0,dp(4)); root.addView(chatTitle);
        ScrollView commentScroll=new ScrollView(this); commentsList=col(); commentsList.setPadding(dp(8),dp(6),dp(8),dp(6)); commentsList.setBackground(bg(Color.argb(150,7,16,52),Color.rgb(65,82,157),14)); commentScroll.addView(commentsList);
        root.addView(commentScroll,new LinearLayout.LayoutParams(-1,dp(170)));

        LinearLayout sendRow=row(); EditText commentInput=new EditText(this); commentInput.setHint("Write a comment…"); commentInput.setTextColor(Color.WHITE); commentInput.setHintTextColor(Color.rgb(155,165,195)); commentInput.setSingleLine(true); commentInput.setBackground(bg(Color.argb(170,10,24,61),Color.rgb(67,91,171),16)); commentInput.setPadding(dp(12),0,dp(8),0);
        Button send=small("Send"); send.setOnClickListener(v->{String m=commentInput.getText().toString().trim(); if(m.isEmpty())return; BackendClient.liveComment(token(),hostId,m,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{commentInput.setText("");refresh();});}public void onError(String e){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,e,Toast.LENGTH_SHORT).show());}});});
        LinearLayout.LayoutParams cip=new LinearLayout.LayoutParams(0,dp(42),1); cip.rightMargin=dp(5); sendRow.addView(commentInput,cip); sendRow.addView(send,new LinearLayout.LayoutParams(dp(72),dp(42))); root.addView(sendRow);

        addControls(root);
        if(host){Button end=btn("End Live"); end.setBackground(bg(Color.rgb(111,41,211),Color.rgb(226,55,255),18)); end.setOnClickListener(v->confirmEndLive()); LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(48)); ep.topMargin=dp(8); root.addView(end,ep);}
        setContentView(page);
    }

    private void addControls(LinearLayout root){
        String[] items=host
                ? new String[]{"🔇\nMic","➕\nInvite","🪑\nSeats","📌\nPin","🎨\nTheme","↗\nShare","❤️\nReact","⚙\nRoom"}
                : new String[]{"🎤\nMic","➕\nFollow","💬\nChat","❤️\nReact","📩\nInbox","↗\nShare","✨\nEffects","⚙\nMore"};
        for(int start=0;start<items.length;start+=4){LinearLayout controls=row(); for(int i=start;i<Math.min(start+4,items.length);i++){final int idx=i;TextView v=t(items[i],9.5f,Color.WHITE,true);v.setGravity(Gravity.CENTER);v.setBackground(bg(Color.argb(190,13,29,76),Color.rgb(72,78,176),13));v.setOnClickListener(x->handleControl(idx));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1);lp.setMargins(dp(2),dp(2),dp(2),dp(2));controls.addView(v,lp);}root.addView(controls);}
    }

    private void handleControl(int i){
        if(host){
            if(i==0) toggleMic(); else if(i==2) Toast.makeText(this,"Tap any sofa to lock/unlock or manage speaker",Toast.LENGTH_SHORT).show();
            else if(i==3) editPinned(); else if(i==4) chooseTheme(); else if(i==5) shareRoom(); else if(i==6) showReaction(); else if(i==7) editRoomInfo();
            else Toast.makeText(this,"Host control ready",Toast.LENGTH_SHORT).show();
        } else {
            if(i==0) toggleMic(); else if(i==1) BackendClient.toggleFollow(token(),hostId,new ToastCb("Host follow updated"));
            else if(i==3) showReaction(); else if(i==5) shareRoom(); else Toast.makeText(this,"Live control",Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleMic(){localMicOn=!localMicOn;BackendClient.liveParticipantState(token(),hostId,localMicOn,false,networkQuality(),new ToastCb(localMicOn?"Mic on":"Mic muted"));}

    private void editPinned(){EditText e=new EditText(this);e.setHint("Pinned announcement");new AlertDialog.Builder(this).setTitle("Pinned message").setView(e).setPositiveButton("Save",(d,w)->BackendClient.liveRoomConfig(token(),null,null,e.getText().toString().trim(),null,new ToastCb("Pinned message updated"))).setNegativeButton("Cancel",null).show();}
    private void editRoomInfo(){LinearLayout b=col();EditText t1=new EditText(this);t1.setHint("Room title");EditText t2=new EditText(this);t2.setHint("Topic");b.addView(t1);b.addView(t2);new AlertDialog.Builder(this).setTitle("Room info").setView(b).setPositiveButton("Save",(d,w)->BackendClient.liveRoomConfig(token(),t1.getText().toString(),t2.getText().toString(),null,null,new ToastCb("Room info updated"))).setNegativeButton("Cancel",null).show();}

    private void chooseTheme(){BackendClient.liveThemes(token(),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("themes");if(a==null||a.length()==0){Toast.makeText(AudioLiveRoomActivity.this,"No enabled themes",Toast.LENGTH_SHORT).show();return;}String[] names=new String[a.length()];String[] keys=new String[a.length()];for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);names[i]=x==null?"Theme":x.optString("name","Theme");keys[i]=x==null?"GUITAR_BLUE":x.optString("theme_key","GUITAR_BLUE");}new AlertDialog.Builder(AudioLiveRoomActivity.this).setTitle("Live Theme").setItems(names,(q,which)->BackendClient.liveRoomConfig(token(),null,null,null,keys[which],new ToastCb("Theme changed"))).show();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}});}

    private void shareRoom(){BackendClient.liveShare(token(),hostId,new Silent()); Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,"Join my MY SHOP Audio Live • Host ID "+hostId);startActivity(Intent.createChooser(send,"Share Live"));}

    private void showReaction(){
        if(commentsList==null)return;
        TextView r=t("❤️",28,Color.WHITE,true);
        r.setGravity(Gravity.CENTER);
        commentsList.addView(r,0,new LinearLayout.LayoutParams(-1,dp(42)));
        r.setAlpha(.2f);
        r.setTranslationY(dp(20));
        r.animate().alpha(1f).translationY(0).setDuration(220).withEndAction(() -> {
            r.animate().alpha(0f).translationY(-dp(20)).setDuration(650).withEndAction(() -> commentsList.removeView(r)).start();
        }).start();
    }

    private void renderLocalSkeleton(){renderHost(null);renderSpecialGuest(null);renderSeats(null);}

    private void refresh(){BackendClient.liveRoomState(token(),hostId,new BackendClient.Callback(){@Override public void onSuccess(JSONObject d){runOnUiThread(()->{syncState.setText("● LIVE • Synced • "+networkQuality());render(d);});}@Override public void onError(String m){runOnUiThread(()->{syncState.setText("● LIVE • Weak network • Reconnecting…");if(seats.getChildCount()==0)renderLocalSkeleton();});}});}

    private void render(JSONObject d){
        int vc=d.optInt("viewerCount",0),peak=d.optInt("peakViewers",0); viewers.setText("👁 "+vc+" Listeners  •  Peak "+peak+"  •  Total "+d.optInt("totalListeners",0));
        myRole=d.optString("myRole",host?"HOST":"AUDIENCE"); status.setText((host?"👑 Host":"🎧 "+myRole)+" • ID "+SessionManager.getUserId(this));
        specialGuestId=d.optString("specialGuestId",""); shareCount=d.optInt("shareCount",0); shareView.setText("↗ "+shareCount);
        roomTitle.setText("🎙 "+d.optString("title","Let's Talk Together")); roomTopic.setText(d.optString("topic","Audio Live"));
        String pin=d.optString("pinnedMessage",""); pinnedView.setText(pin.isEmpty()?"📌 No pinned announcement":"📌 "+pin);
        long parsed=parseServerTime(d.optString("startedAt","")); if(parsed>0)startedAtMs=parsed;
        lockedSeats.clear();JSONArray locks=d.optJSONArray("lockedSeats");if(locks!=null)for(int i=0;i<locks.length();i++)lockedSeats.add(locks.optInt(i));
        JSONArray a=d.optJSONArray("seats"); renderHost(findSeat(a,1));renderSpecialGuest(findUser(a,specialGuestId));renderSeats(a);
        if(host&&requests!=null)renderRequests(d.optJSONArray("requests"));renderComments(d.optJSONArray("comments"),d.optJSONArray("events"));
        JSONObject theme=d.optJSONObject("theme"); if(theme!=null){String bg=theme.optString("background_url","");if(!bg.trim().isEmpty())loadImage(wallpaper,bg);}
    }

    private void renderHost(JSONObject x){hostArea.removeAllViews();LinearLayout card=row();card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(5),dp(5),dp(7),dp(5));boolean speaking=x!=null&&x.optInt("speaking",0)==1;card.setBackground(bg(Color.argb(160,15,24,69),speaking?Color.rgb(45,226,255):Color.rgb(118,76,225),18));FrameLayout av=circleAvatar(x==null?"":x.optString("avatar_url",""),dp(62),speaking);card.addView(av,new LinearLayout.LayoutParams(dp(62),dp(62)));String name=x==null?"Host":x.optString("full_name","Host");String id=x==null?hostId:x.optString("user_id",hostId);int lv=x==null?0:x.optInt("level",0);long coin=x==null?0:x.optLong("coin_balance",0),gold=x==null?0:x.optLong("gold_balance",0);String nq=x==null?"GOOD":x.optString("network_quality","GOOD");TextView info=t("👑 "+name+"\nID "+id+" • LV."+lv+"   "+signal(nq)+"\n🪙 "+coin+"   🟡 "+gold+(speaking?"   ≋ Speaking":""),11,Color.WHITE,true);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,-2,1);ip.leftMargin=dp(9);card.addView(info,ip);hostArea.addView(card,new LinearLayout.LayoutParams(-1,-2));}

    private void renderSpecialGuest(JSONObject x){specialArea.removeAllViews();TextView label=t("✨ SPECIAL GUEST",10.5f,Color.rgb(255,188,244),true);label.setGravity(Gravity.CENTER);specialArea.addView(label);if(x==null){FrameLayout av=circleAvatar("",dp(78),false);specialArea.addView(av,new LinearLayout.LayoutParams(dp(78),dp(78)));TextView e=t("Host can spotlight a speaker here",10,Color.rgb(195,205,245),true);e.setGravity(Gravity.CENTER);specialArea.addView(e);return;}boolean speaking=x.optInt("speaking",0)==1;FrameLayout av=circleAvatar(x.optString("avatar_url",""),dp(86),speaking);specialArea.addView(av,new LinearLayout.LayoutParams(dp(86),dp(86)));TextView info=t(x.optString("full_name","Special Guest")+"  •  ID "+x.optString("user_id")+" • LV."+x.optInt("level",0)+(speaking?"  ≋ Speaking":""),10.5f,Color.WHITE,true);info.setGravity(Gravity.CENTER);specialArea.addView(info);if(host)specialArea.setOnClickListener(v->clearSpecialGuest());}

    private void renderSeats(JSONArray a){seats.removeAllViews();int n=2;for(int row=0;row<3;row++){LinearLayout r=row();for(int c=0;c<3;c++,n++){JSONObject found=findSeat(a,n);boolean locked=lockedSeats.contains(n);LinearLayout tile=seatTile(n,found,locked);final int seatNo=n;final JSONObject clicked=found;tile.setOnClickListener(v->{if(host){if(clicked!=null)showSpeakerActions(clicked);else toggleSeatLock(seatNo,locked);}});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(86),1);lp.setMargins(dp(2),dp(2),dp(2),dp(2));r.addView(tile,lp);}seats.addView(r);}}

    private LinearLayout seatTile(int seatNo,JSONObject x,boolean locked){LinearLayout v=col();v.setGravity(Gravity.CENTER);v.setPadding(dp(2),dp(3),dp(2),dp(3));boolean occupied=x!=null,speaking=occupied&&x.optInt("speaking",0)==1;int stroke=locked?Color.rgb(131,139,166):(speaking?Color.rgb(35,225,255):(occupied?Color.rgb(65,176,255):Color.rgb(111,82,187)));v.setBackground(bg(Color.argb(165,10,27,72),stroke,14));if(occupied){FrameLayout av=circleAvatar(x.optString("avatar_url",""),dp(40),speaking);v.addView(av,new LinearLayout.LayoutParams(dp(40),dp(40)));TextView tx=t(x.optString("full_name","Speaker")+"\n"+"ID "+x.optString("user_id")+" • LV."+x.optInt("level",0)+"  "+(x.optInt("mic_on",1)==1?"🎙":"🔇")+" "+signal(x.optString("network_quality","GOOD")),8.4f,Color.WHITE,true);tx.setGravity(Gravity.CENTER);v.addView(tx);}else{v.addView(sofaIcon(locked),new LinearLayout.LayoutParams(dp(34),dp(24)));TextView tx=t((locked?"Locked":"Seat "+seatNo),9.2f,locked?Color.LTGRAY:Color.WHITE,true);tx.setGravity(Gravity.CENTER);v.addView(tx);}return v;}

    private View sofaIcon(boolean locked){FrameLayout f=new FrameLayout(this);View back=new View(this);back.setBackground(bg(locked?Color.rgb(73,83,111):Color.rgb(50,113,211),locked?Color.rgb(95,105,133):Color.rgb(74,189,255),5));FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,dp(15));bp.gravity=Gravity.TOP;f.addView(back,bp);View base=new View(this);base.setBackground(bg(locked?Color.rgb(61,70,96):Color.rgb(35,82,179),locked?Color.rgb(95,105,133):Color.rgb(80,199,255),5));FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(-1,dp(9));sp.gravity=Gravity.BOTTOM;f.addView(base,sp);return f;}

    private void toggleSeatLock(int seatNo,boolean locked){BackendClient.liveSeatLock(token(),seatNo,!locked,new ToastCb(!locked?"Seat locked":"Seat unlocked"));}

    private void renderRequests(JSONArray q){requests.removeAllViews();if(q==null||q.length()==0){requests.addView(t("No pending requests",11,Color.LTGRAY,false));return;}for(int i=0;i<q.length();i++){JSONObject x=q.optJSONObject(i);if(x==null)continue;LinearLayout rr=row();rr.setGravity(Gravity.CENTER_VERTICAL);TextView nm=t(x.optString("full_name","User")+" • ID "+x.optString("user_id"),10.5f,Color.WHITE,true);rr.addView(nm,new LinearLayout.LayoutParams(0,dp(42),1));Button ok=small("Accept"),no=small("Decline");String id=x.optString("user_id");ok.setOnClickListener(v->BackendClient.liveRequestAction(token(),id,true,new ToastCb("Speaker accepted")));no.setOnClickListener(v->BackendClient.liveRequestAction(token(),id,false,new ToastCb("Request declined")));rr.addView(ok,new LinearLayout.LayoutParams(dp(72),dp(38)));rr.addView(no,new LinearLayout.LayoutParams(dp(74),dp(38)));requests.addView(rr);}}

    private void renderComments(JSONArray comments,JSONArray events){commentsList.removeAllViews();if(events!=null){int start=Math.max(0,events.length()-4);for(int i=start;i<events.length();i++){JSONObject e=events.optJSONObject(i);if(e==null)continue;String who=e.optString("full_name","Someone");TextView n=t("• "+who+" "+e.optString("message",""),9.5f,Color.rgb(167,190,244),false);commentsList.addView(n);}}if(comments==null||comments.length()==0){commentsList.addView(t("Comments will appear here",10.5f,Color.rgb(170,178,205),false));return;}for(int i=0;i<comments.length();i++){JSONObject c=comments.optJSONObject(i);if(c==null)continue;TextView msg=t(c.optString("full_name","User")+": "+c.optString("message",""),10.5f,Color.WHITE,false);msg.setPadding(0,dp(2),0,dp(2));commentsList.addView(msg);}}

    private void showSpeakerActions(JSONObject x){final String uid=x.optString("user_id","");final boolean special=uid.equals(specialGuestId);String[] actions=special?new String[]{"Remove from Special Guest","Remove Speaker from Seat"}:new String[]{"Make Special Guest","Remove Speaker from Seat"};new AlertDialog.Builder(this).setTitle(x.optString("full_name","Speaker")).setItems(actions,(d,which)->{if(which==0)BackendClient.liveSpecialGuest(token(),uid,special,new ToastCb(special?"Special Guest removed":"Special Guest selected"));else BackendClient.liveSpeakerRemove(token(),uid,new ToastCb("Speaker removed"));}).show();}
    private void clearSpecialGuest(){if(!host||specialGuestId.isEmpty())return;new AlertDialog.Builder(this).setTitle("Special Guest").setMessage("Return this guest to a normal speaker seat?").setPositiveButton("Remove Spotlight",(d,w)->BackendClient.liveSpecialGuest(token(),specialGuestId,true,new ToastCb("Spotlight cleared"))).setNegativeButton("Cancel",null).show();}

    private void confirmEndLive(){new AlertDialog.Builder(this).setTitle("End Live?").setMessage("This will end the room for everyone.").setPositiveButton("End Live",(d,w)->endHostLive()).setNegativeButton("Cancel",null).show();}
    private void endHostLive(){BackendClient.setLivePresence(token(),false,new BackendClient.Callback(){public void onSuccess(JSONObject d){hostStarted=false;BackendClient.liveSummary(token(),hostId,new BackendClient.Callback(){public void onSuccess(JSONObject s){runOnUiThread(()->showSummary(s.optJSONObject("summary")));}public void onError(String m){runOnUiThread(()->finish());}});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_LONG).show());}});}
    private void showSummary(JSONObject s){if(s==null){finish();return;}long dur=s.optLong("duration_seconds",0);new AlertDialog.Builder(this).setTitle("Live Summary").setMessage("Duration  "+hhmmss(dur)+"\nPeak viewers  "+s.optInt("peak_viewers",0)+"\nTotal listeners  "+s.optInt("total_listeners",0)+"\nShares  "+s.optInt("share_count",0)).setPositiveButton("Done",(d,w)->finish()).setCancelable(false).show();}

    private JSONObject findSeat(JSONArray a,int seatNo){if(a==null)return null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&x.optInt("seat_no")==seatNo)return x;}return null;}
    private JSONObject findUser(JSONArray a,String userId){if(a==null||userId==null||userId.isEmpty())return null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&userId.equals(x.optString("user_id")))return x;}return null;}

    private FrameLayout circleAvatar(String url,int size,boolean speaking){FrameLayout frame=new FrameLayout(this);int stroke=speaking?Color.rgb(42,235,255):Color.rgb(163,93,255);frame.setBackground(bg(Color.argb(190,25,33,82),stroke,size/2));ImageView v=new ImageView(this);v.setImageResource(android.R.drawable.sym_def_app_icon);v.setScaleType(ImageView.ScaleType.CENTER_CROP);v.setBackground(bg(Color.rgb(34,45,105),stroke,size/2));v.setClipToOutline(true);int pad=dp(3);FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(-1,-1);ip.setMargins(pad,pad,pad,pad);frame.addView(v,ip);if(url!=null&&!url.trim().isEmpty())loadImage(v,url);if(speaking){ObjectAnimator a=ObjectAnimator.ofFloat(frame,"alpha",1f,.72f,1f);a.setDuration(850);a.setRepeatCount(ValueAnimator.INFINITE);a.start();}return frame;}
    private void loadImage(ImageView v,String u){new Thread(()->{try{Bitmap b=BitmapFactory.decodeStream(new URL(u).openStream());if(b!=null)runOnUiThread(()->v.setImageBitmap(b));}catch(Exception ignored){}}).start();}

    private String networkQuality(){try{ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);NetworkInfo n=cm==null?null:cm.getActiveNetworkInfo();if(n==null||!n.isConnected())return "OFFLINE";return n.getType()==ConnectivityManager.TYPE_WIFI?"GOOD":"FAIR";}catch(Exception e){return "GOOD";}}
    private String signal(String q){q=q==null?"GOOD":q.toUpperCase();if("WEAK".equals(q)||"OFFLINE".equals(q))return "▂";if("FAIR".equals(q))return "▂▄";return "▂▄▆";}
    private long parseServerTime(String s){if(s==null||s.trim().isEmpty())return 0;String[] patterns={"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd'T'HH:mm:ss.SSS'Z'","yyyy-MM-dd'T'HH:mm:ss'Z'"};for(String p:patterns){try{SimpleDateFormat f=new SimpleDateFormat(p,Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));Date d=f.parse(s);if(d!=null)return d.getTime();}catch(Exception ignored){}}return 0;}
    private String hhmmss(long sec){long h=sec/3600,m=(sec%3600)/60,s=sec%60;return String.format(Locale.US,"%02d:%02d:%02d",h,m,s);}
    private String token(){return SessionManager.getToken(this);}

    @Override protected void onDestroy(){handler.removeCallbacks(tick);handler.removeCallbacks(durationTick);if(host){if(hostStarted)BackendClient.setLivePresence(token(),false,new Silent());}else{BackendClient.liveLeaveSeat(token(),hostId,new Silent());BackendClient.liveViewer(token(),hostId,false,new Silent());}super.onDestroy();}

    class ToastCb implements BackendClient.Callback{String ok;ToastCb(String s){ok=s;}public void onSuccess(JSONObject d){runOnUiThread(()->{Toast.makeText(AudioLiveRoomActivity.this,ok,Toast.LENGTH_SHORT).show();refresh();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AudioLiveRoomActivity.this,m,Toast.LENGTH_SHORT).show());}}
    static class Silent implements BackendClient.Callback{public void onSuccess(JSONObject d){}public void onError(String m){}}

    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private Button btn(String s){Button b=new Button(this);b.setAllCaps(false);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setBackground(bg(Color.rgb(76,45,205),Color.rgb(217,46,255),18));return b;}
    private Button small(String s){Button b=btn(s);b.setTextSize(9.5f);b.setMinWidth(0);b.setMinimumWidth(0);return b;}
    private TextView t(String s,float z,int c,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private GradientDrawable bg(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));g.setStroke(dp(1),stroke);return g;}
    private int dp(float x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
}
