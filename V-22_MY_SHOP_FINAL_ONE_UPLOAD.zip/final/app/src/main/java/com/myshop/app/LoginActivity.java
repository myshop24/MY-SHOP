package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        findViewById(R.id.createAccountButton).setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
        findViewById(R.id.loginButton).setOnClickListener(v -> login());
        findViewById(R.id.forgotButton).setOnClickListener(v -> Toast.makeText(this, "Password reset will be connected to the backend.", Toast.LENGTH_LONG).show());
    }

    private void login() {
        EditText id = findViewById(R.id.loginId), password = findViewById(R.id.loginPassword);
        if (id.getText().toString().trim().isEmpty() || password.getText().toString().isEmpty()) {
            Toast.makeText(this, "Enter login and password.", Toast.LENGTH_SHORT).show(); return;
        }
        // Production rule: authentication + Admin/Moderator role detection must come from the backend.
        // This build uses USER as the safe offline fallback; no admin credentials are embedded in the APK.
        SessionManager.setSession(this, Role.USER, "");
        Toast.makeText(this, "Login shell ready. Backend authentication will provide the real role.", Toast.LENGTH_LONG).show();
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
