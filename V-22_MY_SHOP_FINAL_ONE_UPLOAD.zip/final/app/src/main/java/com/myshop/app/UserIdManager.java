package com.myshop.app;

import android.content.Context;
import android.content.SharedPreferences;

/** Local prototype only. Production serial IDs must be allocated atomically by the backend. */
public final class UserIdManager {
    private static final String PREFS = "myshop_users";
    private static final String KEY_NEXT = "next_user_id";
    private static final int START = 1;

    private UserIdManager() {}

    public static String allocateLocalId(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int next = p.getInt(KEY_NEXT, START);
        if (next > 9999) throw new IllegalStateException("Four-digit User ID limit reached in local prototype.");
        p.edit().putInt(KEY_NEXT, next + 1).apply();
        return String.format("%04d", next);
    }
}
