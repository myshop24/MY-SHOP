package com.myshop.app;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** Account/settings shell. Sensitive authentication and server-side permissions remain backend-owned. */
public class AccountActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        TextView id = findViewById(R.id.accountId);
        TextView role = findViewById(R.id.accountRole);
        id.setText("Profile ID: " + (SessionManager.getUserId(this).isEmpty() ? "Not assigned" : SessionManager.getUserId(this)));
        role.setText("Role: " + SessionManager.getRole(this).name());

        Switch notifications = findViewById(R.id.notificationSwitch);
        notifications.setChecked(getPreferences(MODE_PRIVATE).getBoolean("notifications", true));
        notifications.setOnCheckedChangeListener((button, checked) ->
                getPreferences(MODE_PRIVATE).edit().putBoolean("notifications", checked).apply());

        findViewById(R.id.profileButton).setOnClickListener(v ->
                Toast.makeText(this, "Profile editing will sync with the backend.", Toast.LENGTH_SHORT).show());
        findViewById(R.id.passwordButton).setOnClickListener(v ->
                Toast.makeText(this, "Password reset/change is handled by secure backend authentication.", Toast.LENGTH_LONG).show());
        findViewById(R.id.reportButton).setOnClickListener(v ->
                Toast.makeText(this, "Report system is ready for backend integration.", Toast.LENGTH_SHORT).show());
        findViewById(R.id.blockButton).setOnClickListener(v ->
                Toast.makeText(this, "Block list is ready for backend integration.", Toast.LENGTH_SHORT).show());
        findViewById(R.id.logoutButton).setOnClickListener(v -> {
            SessionManager.clear(this);
            finishAffinity();
        });
    }
}
