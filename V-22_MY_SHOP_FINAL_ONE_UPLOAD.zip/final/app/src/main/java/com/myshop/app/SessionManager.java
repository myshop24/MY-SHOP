package com.myshop.app;

import android.content.Context;
import android.content.SharedPreferences;

/** Local session shell. Production authentication/roles must be supplied by the backend. */
public final class SessionManager {
    private static final String PREF = "myshop_session";
    private static final String ROLE = "role";
    private static final String USER_ID = "user_id";

    private SessionManager() {}

    public static void setSession(Context c, Role role, String userId) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putString(ROLE, role.name())
                .putString(USER_ID, userId == null ? "" : userId)
                .putBoolean("logged_in", role != Role.GUEST)
                .apply();
    }

    public static Role getRole(Context c) {
        String value = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getString(ROLE, Role.GUEST.name());
        try { return Role.valueOf(value); } catch (Exception ignored) { return Role.GUEST; }
    }

    public static String getUserId(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(USER_ID, "");
    }

    public static boolean isAdmin(Context c) { return getRole(c) == Role.ADMIN; }
    public static boolean isModerator(Context c) { return getRole(c) == Role.MODERATOR; }

    public static void clear(Context c) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply();
    }
}
