package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        findViewById(R.id.backLoginButton).setOnClickListener(v -> finish());
        findViewById(R.id.createButton).setOnClickListener(v -> createAccount());
    }

    private void createAccount() {
        EditText name = findViewById(R.id.fullName), email = findViewById(R.id.email), mobile = findViewById(R.id.mobile);
        EditText pass = findViewById(R.id.password), confirm = findViewById(R.id.confirmPassword);
        CheckBox terms = findViewById(R.id.terms);
        if (name.getText().toString().trim().isEmpty() || email.getText().toString().trim().isEmpty() || mobile.getText().toString().trim().isEmpty() || pass.getText().toString().isEmpty()) {
            Toast.makeText(this, "Please complete all required fields.", Toast.LENGTH_SHORT).show(); return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email.getText().toString().trim()).matches()) {
            Toast.makeText(this, "Enter a valid email address.", Toast.LENGTH_SHORT).show(); return;
        }
        if (pass.getText().toString().length() < 6 || !pass.getText().toString().equals(confirm.getText().toString())) {
            Toast.makeText(this, "Use 6+ characters and make both passwords match.", Toast.LENGTH_SHORT).show(); return;
        }
        if (!terms.isChecked()) { Toast.makeText(this, "Please accept the Terms & Conditions.", Toast.LENGTH_SHORT).show(); return; }
        String id = UserIdManager.allocateLocalId(this);
        getSharedPreferences("myshop_session", MODE_PRIVATE).edit().putBoolean("logged_in", true).putString("user_id", id).apply();
        Toast.makeText(this, "Account created. Your User ID: " + id, Toast.LENGTH_LONG).show();
        startActivity(new Intent(this, MainActivity.class));
        finishAffinity();
    }
}
