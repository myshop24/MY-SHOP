package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    private final int[] spinnerIds={R.id.securityQuestion1,R.id.securityQuestion2,R.id.securityQuestion3};
    @Override protected void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_register); findViewById(R.id.backLoginButton).setOnClickListener(v->finish()); findViewById(R.id.languageButton).setOnClickListener(v->LanguageManager.showPicker(this,this::applyLanguage)); setupSpinners(); findViewById(R.id.createButton).setOnClickListener(v->createAccount()); applyLanguage(); }

    private void setupSpinners(){ for(int id:spinnerIds){ Spinner s=findViewById(id); int pos=s.getSelectedItemPosition(); if(pos<0)pos=0; ArrayAdapter<String> a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,LanguageManager.securityQuestionOptions(this)); a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); s.setAdapter(a); if(pos<a.getCount())s.setSelection(pos); } }

    private void applyLanguage(){
        int[] pos=new int[3]; for(int i=0;i<3;i++)pos[i]=((Spinner)findViewById(spinnerIds[i])).getSelectedItemPosition();
        ((Button)findViewById(R.id.languageButton)).setText("🌐  "+languageLabel());
        ((TextView)findViewById(R.id.registerTitle)).setText(LanguageManager.t(this,"register"));
        ((TextView)findViewById(R.id.registerSubtitle)).setText(LanguageManager.t(this,"createSubtitle"));
        ((EditText)findViewById(R.id.fullName)).setHint(LanguageManager.t(this,"fullName"));
        ((EditText)findViewById(R.id.email)).setHint(LanguageManager.t(this,"email"));
        ((EditText)findViewById(R.id.mobile)).setHint(LanguageManager.t(this,"mobile"));
        ((EditText)findViewById(R.id.password)).setHint(LanguageManager.t(this,"password"));
        ((EditText)findViewById(R.id.confirmPassword)).setHint(LanguageManager.t(this,"confirm"));
        ((TextView)findViewById(R.id.securityTitle)).setText(LanguageManager.t(this,"security"));
        ((TextView)findViewById(R.id.securityHint)).setText(LanguageManager.t(this,"securityHint"));
        ((EditText)findViewById(R.id.securityAnswer1)).setHint(LanguageManager.t(this,"answer1")); ((EditText)findViewById(R.id.securityAnswer2)).setHint(LanguageManager.t(this,"answer2")); ((EditText)findViewById(R.id.securityAnswer3)).setHint(LanguageManager.t(this,"answer3"));
        ((CheckBox)findViewById(R.id.terms)).setText(LanguageManager.t(this,"terms")); ((Button)findViewById(R.id.createButton)).setText(LanguageManager.t(this,"register")); ((Button)findViewById(R.id.backLoginButton)).setText(LanguageManager.t(this,"alreadyLogin"));
        setupSpinners(); for(int i=0;i<3;i++){Spinner s=findViewById(spinnerIds[i]); if(pos[i]>=0&&pos[i]<s.getCount())s.setSelection(pos[i]);}
    }
    private String languageLabel(){String l=LanguageManager.get(this);return LanguageManager.EN.equals(l)?"English":LanguageManager.HI.equals(l)?"हिन्दी":LanguageManager.AR.equals(l)?"العربية":"বাংলা";}

    private void createAccount(){
        EditText name=findViewById(R.id.fullName),email=findViewById(R.id.email),mobile=findViewById(R.id.mobile),pass=findViewById(R.id.password),confirm=findViewById(R.id.confirmPassword); CheckBox terms=findViewById(R.id.terms);
        String nv=name.getText().toString().trim(),ev=email.getText().toString().trim(),mv=mobile.getText().toString().trim(),pw=pass.getText().toString();
        String[] qs=new String[3],ans=new String[3]; int[] selected=new int[3];
        for(int i=0;i<3;i++){Spinner s=findViewById(spinnerIds[i]);selected[i]=s.getSelectedItemPosition();qs[i]=LanguageManager.securityQuestionKey(selected[i]);}
        ans[0]=((EditText)findViewById(R.id.securityAnswer1)).getText().toString().trim(); ans[1]=((EditText)findViewById(R.id.securityAnswer2)).getText().toString().trim(); ans[2]=((EditText)findViewById(R.id.securityAnswer3)).getText().toString().trim();
        if(nv.isEmpty()){toast("Full Name is required.");return;} if(ev.isEmpty()&&mv.isEmpty()){toast("Email অথবা Mobile Number যেকোনো একটি দিন।");return;} if(!ev.isEmpty()&&!Patterns.EMAIL_ADDRESS.matcher(ev).matches()){toast("Enter a valid email address.");return;} if(pw.length()<6||!pw.equals(confirm.getText().toString())){toast("Use 6+ characters and make both passwords match.");return;} if(!terms.isChecked()){toast("Please accept the Terms & Conditions.");return;} if(selected[0]==0||selected[1]==0||selected[2]==0){toast("সব ৩টি Security Question নির্বাচন করুন।");return;} if(selected[0]==selected[1]||selected[0]==selected[2]||selected[1]==selected[2]){toast("৩টি Security Question আলাদা হতে হবে।");return;} for(String a:ans)if(a.isEmpty()){toast("৩টি Security Answer-ই দিতে হবে।");return;}
        if(!BackendClient.configured()){toast("Backend URL এখনো সেট করা হয়নি।");return;} findViewById(R.id.createButton).setEnabled(false);
        BackendClient.register(nv,ev,mv,pw,qs,ans,new BackendClient.Callback(){public void onSuccess(org.json.JSONObject data){try{org.json.JSONObject u=data.getJSONObject("user");String id=u.optString("userId","");Role role=Role.valueOf(u.optString("role","USER"));SessionManager.setRemoteSession(RegisterActivity.this,data.optString("token",""),role,id);SessionManager.saveProfile(RegisterActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""));Toast.makeText(RegisterActivity.this,"Account created. Your permanent User ID: "+id,Toast.LENGTH_LONG).show();Intent in=new Intent(RegisterActivity.this,MainActivity.class);in.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(in);finish();}catch(Exception e){toast("Server response invalid.");findViewById(R.id.createButton).setEnabled(true);}} public void onError(String m){toast(m);findViewById(R.id.createButton).setEnabled(true);}});
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
