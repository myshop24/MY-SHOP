package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

/** V-106: MY SHOP dashboard locked to the user's approved reference image. */
public class MainActivity extends AppCompatActivity {
    private static final int BG = Color.rgb(249,250,253);
    private static final int NAVY = Color.rgb(10,25,66);
    private static final int BLUE = Color.rgb(28,52,218);
    private static final int RED = Color.rgb(239,28,39);
    private static final int DARK = Color.rgb(30,32,44);
    private final Handler handler = new Handler();
    private int slide = 0;
    private ImageView leftBanner, rightBanner, wideBanner;
    private TextView dots;
    private final int[] left = {R.drawable.banner_top_left_1,R.drawable.banner_top_left_2,R.drawable.banner_top_left_3,R.drawable.banner_top_left_4,R.drawable.banner_top_left_5,R.drawable.banner_top_left_6};
    private final int[] right = {R.drawable.banner_top_right_1,R.drawable.banner_top_right_2,R.drawable.banner_top_right_3,R.drawable.banner_top_right_4,R.drawable.banner_top_right_5,R.drawable.banner_top_right_6};
    private final int[] wide = {R.drawable.banner_wide_1,R.drawable.banner_wide_2,R.drawable.banner_wide_3,R.drawable.banner_wide_4,R.drawable.banner_wide_5,R.drawable.banner_wide_6};
    private final int[] live = {R.drawable.dash_live1,R.drawable.dash_live2,R.drawable.dash_live3,R.drawable.dash_live4,R.drawable.dash_live1,R.drawable.dash_live2};

    @Override protected void onCreate(Bundle b){ super.onCreate(b); setContentView(build()); startCarousel(); }

    private View build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(BG);
        ScrollView sv=new ScrollView(this); sv.setVerticalScrollBarEnabled(false); sv.setClipToPadding(false);
        LinearLayout page=col(); page.setPadding(dp(12),dp(8),dp(12),dp(82));
        page.addView(header(), lp(-1,dp(82)));
        LinearLayout pair=row(); leftBanner=pic(left[0]); rightBanner=pic(right[0]);
        pair.addView(leftBanner, weight(1,dp(164))); pair.addView(space(),lp(dp(7),1)); pair.addView(rightBanner,weight(1,dp(164)));
        page.addView(pair, top(lp(-1,dp(164)),7));
        dots=text("●   ○   ○   ○   ○   ○",BLUE,11,true); dots.setGravity(Gravity.CENTER); page.addView(dots,lp(-1,dp(25)));
        wideBanner=pic(wide[0]); page.addView(wideBanner,top(lp(-1,dp(116)),2));
        page.addView(breaking(),top(lp(-1,dp(48)),8));
        page.addView(sectionTitle("🔴  "+LanguageManager.t(this,"liveNow"),true),top(lp(-1,dp(38)),7));
        page.addView(liveRow(),lp(-1,dp(180)));
        page.addView(actionRow(),top(lp(-1,dp(116)),10));
        page.addView(featureGrid(),top(lp(-1,-2),10));
        sv.addView(page,new ScrollView.LayoutParams(-1,-2)); root.addView(sv,new FrameLayout.LayoutParams(-1,-1));
        root.addView(bottom(),new FrameLayout.LayoutParams(-1,dp(70),Gravity.BOTTOM)); return root;
    }

    private View header(){
        LinearLayout h=row(); h.setGravity(Gravity.CENTER_VERTICAL);
        ImageView avatar=new ImageView(this); avatar.setImageResource(R.drawable.myshop_profile_avatar); avatar.setScaleType(ImageView.ScaleType.CENTER_CROP); h.addView(avatar,lp(dp(68),dp(68)));
        LinearLayout who=col(); who.setPadding(dp(8),0,dp(8),0);
        who.addView(text("Hi, Touhid 👋",DARK,18,true),lp(-1,dp(34)));
        who.addView(text("ID: 0100  ✜",DARK,14,true),lp(-1,dp(26))); h.addView(who,weight(0.72f,dp(70)));
        EditText search=new EditText(this); search.setSingleLine(true); search.setTextSize(13); search.setHint("খুঁজুন পণ্য, লাইভ, ইউজার..."); search.setPadding(dp(14),0,dp(8),0); search.setBackground(round(Color.WHITE,Color.rgb(225,226,233),dp(28))); h.addView(search,weight(1.28f,dp(58)));
        Button bell=icon("♧",NAVY,28); bell.setOnClickListener(v->Toast.makeText(this,"Notifications",Toast.LENGTH_SHORT).show()); h.addView(bell,lp(dp(48),dp(58)));
        Button menu=icon("☰",NAVY,27); menu.setOnClickListener(v->startActivity(new Intent(this,AccountActivity.class))); h.addView(menu,lp(dp(48),dp(58)));
        return h;
    }

    private View breaking(){
        LinearLayout b=row(); b.setPadding(dp(6),dp(4),dp(6),dp(4)); b.setBackground(round(Color.WHITE,Color.rgb(228,229,235),dp(13)));
        TextView label=text("BREAKING NEWS",Color.WHITE,11,true); label.setGravity(Gravity.CENTER); label.setBackground(round(RED,RED,dp(8))); b.addView(label,lp(dp(158),dp(34)));
        TextView news=text("  📢   বাংলাদেশে আজ স্বর্ণের দাম কিছুটা কমেছে...",Color.rgb(15,45,110),12,true); news.setSingleLine(true); news.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE); news.setSelected(true); b.addView(news,weight(1,dp(34)));
        TextView all=text("View All",BLUE,11,true); all.setGravity(Gravity.CENTER); b.addView(all,lp(dp(72),dp(34))); return b;
    }

    private View sectionTitle(String title,boolean all){ LinearLayout h=row(); h.addView(text(title,DARK,14,true),weight(1,dp(38))); if(all) h.addView(text("View All",BLUE,11,true),lp(dp(70),dp(38))); return h; }

    private View liveRow(){ HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); LinearLayout r=row(); for(int i=0;i<6;i++){ ImageView v=pic(live[i]); final int idx=i; v.setOnClickListener(x->openFeature("LIVE "+(idx+1),"live_now")); r.addView(v,lp(dp(151),dp(170))); if(i<5)r.addView(space(),lp(dp(6),1)); } hs.addView(r,new HorizontalScrollView.LayoutParams(-2,-1)); return hs; }

    private View actionRow(){ LinearLayout r=row(); ImageView feed=pic(R.drawable.dash_action_feed); feed.setOnClickListener(v->openFeature("MY FEED","my_feed")); ImageView shop=pic(R.drawable.dash_feat_shop); shop.setOnClickListener(v->openFeature("MY SHOP","my_shop")); r.addView(feed,weight(1,dp(110))); r.addView(space(),lp(dp(8),1)); r.addView(shop,weight(1,dp(110))); return r; }

    private View featureGrid(){
        LinearLayout grid=row();
        LinearLayout leftCol=col();
        leftCol.addView(tile(R.drawable.dash_feat_gallery,"GALLERY\nফটো, অডিও, ভিডিও","gallery"),lp(-1,dp(78)));
        leftCol.addView(tile(R.drawable.dash_feat_tv,"LIVE TV\nটিভি দেখুন","live_tv"),top(lp(-1,dp(78)),7));
        leftCol.addView(tile(R.drawable.dash_feat_reward,"EARN & REWARD\nআয় করুন","earn_reward"),top(lp(-1,dp(78)),7));
        grid.addView(leftCol,weight(1,dp(252)));
        FrameLayout center=new FrameLayout(this);
        ImageView go=pic(R.drawable.dash_action_go); go.setOnClickListener(v->openFeature("GO LIVE","go_live"));
        center.addView(go,new FrameLayout.LayoutParams(-1,dp(118),Gravity.CENTER));
        grid.addView(center,weight(0.9f,dp(252)));
        LinearLayout rightCol=col();
        rightCol.addView(tile(R.drawable.dash_feat_movie,"EXTERNAL\n১২ টি ফোল্ডার","external_movie"),lp(-1,dp(78)));
        rightCol.addView(tile(R.drawable.dash_feat_social,"SOCIAL\nসোশ্যাল লিংক","social_media"),top(lp(-1,dp(78)),7));
        rightCol.addView(tile(R.drawable.dash_feat_share,"SHARE\nশেয়ার করুন","share"),top(lp(-1,dp(78)),7));
        grid.addView(rightCol,weight(1,dp(252)));
        return grid;
    }

    private View tile(int res,String fallback,String key){ ImageView v=pic(res); v.setContentDescription(fallback); v.setOnClickListener(x->openFeature(fallback,key)); return v; }

    private View bottom(){ LinearLayout n=row(); n.setBackground(round(Color.WHITE,Color.rgb(226,227,234),dp(20))); String[] labels={"⌂\nHOME","🛒\nSTORE","◉\nLIVE","💬\nCHAT","▦\nMORE"}; String[] keys={"home","my_shop","live_now","chat","more"}; for(int i=0;i<5;i++){ Button b=icon(labels[i],i==0?BLUE:DARK,10); final int j=i; b.setOnClickListener(v->{ if(j==0)return; if(j==1)openFeature("MY SHOP","my_shop"); else if(j==2)openFeature("LIVE","live_now"); else if(j==3)openFeature("CHAT","chat"); else startActivity(new Intent(this,AccountActivity.class));}); n.addView(b,weight(1,dp(66))); } return n; }

    private ImageView pic(int r){ ImageView v=new ImageView(this); v.setImageResource(r); v.setScaleType(ImageView.ScaleType.CENTER_CROP); v.setBackground(round(Color.WHITE,Color.rgb(228,229,235),dp(12))); v.setClipToOutline(true); return v; }
    private Button icon(String s,int c,float z){ Button b=new Button(this); b.setText(s); b.setTextColor(c); b.setTextSize(z); b.setGravity(Gravity.CENTER); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setPadding(0,0,0,0); b.setBackgroundColor(Color.TRANSPARENT); return b; }
    private TextView text(String s,int c,float z,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextColor(c); t.setTextSize(z); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout col(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private View space(){ return new View(this); }
    private LinearLayout.LayoutParams lp(int w,int h){ return new LinearLayout.LayoutParams(w,h); }
    private LinearLayout.LayoutParams weight(float w,int h){ return new LinearLayout.LayoutParams(0,h,w); }
    private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private GradientDrawable round(int fill,int stroke,int rad){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(rad));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    private void startCarousel(){ handler.postDelayed(new Runnable(){public void run(){slide=(slide+1)%6;leftBanner.setImageResource(left[slide]);rightBanner.setImageResource(right[slide]);wideBanner.setImageResource(wide[slide]);StringBuilder s=new StringBuilder();for(int i=0;i<6;i++){s.append(i==slide?"●":"○");if(i<5)s.append("   ");}dots.setText(s.toString());handler.postDelayed(this,3500);}},3500); }
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
    private void openFeature(String title,String key){try{Intent i=new Intent(this,FeatureActivity.class);i.putExtra("title",title);i.putExtra("feature_key",key);String url=FeatureRegistry.getUrl(this,key);if(FeatureRegistry.isSafeHttpUrl(url))i.putExtra("url",url);startActivity(i);}catch(Throwable t){Toast.makeText(this,title+" is ready.",Toast.LENGTH_SHORT).show();}}
}
