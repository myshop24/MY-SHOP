package com.myshop.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.content.Intent;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

/** V-125 normal-user menu. Admin controls are intentionally absent. */
public class UserMenuActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(247,248,252), DARK=Color.rgb(24,29,62), BLUE=Color.rgb(46,47,190), PURPLE=Color.rgb(83,32,180), RED=Color.rgb(210,45,55);
    @Override protected void onCreate(Bundle b){super.onCreate(b);build();}
    private void build(){
        LinearLayout root=col();root.setBackgroundColor(BG);root.setPadding(dp(14),dp(14),dp(14),dp(18));
        LinearLayout head=row();head.setBackground(bg(Color.WHITE,Color.TRANSPARENT,16));head.setPadding(dp(10),dp(8),dp(10),dp(8));
        Button back=button("‹",DARK,22);back.setOnClickListener(v->finish());head.addView(back,lp(dp(44),dp(44)));
        TextView title=txt("MY SHOP",18,DARK,true);title.setGravity(Gravity.CENTER_VERTICAL);head.addView(title,weight(1));
        TextView role=txt("PROFILE • "+(SessionManager.isAdmin(this)?"ADMIN":"USER"),BLUE,8,true);role.setGravity(Gravity.CENTER);role.setSingleLine(true);role.setBackground(bg(Color.rgb(245,246,255),Color.TRANSPARENT,12));role.setOnClickListener(v->startActivity(new android.content.Intent(this,AccountActivity.class)));head.addView(role,lp(dp(100),dp(38)));
        TextView lang=txt("🌐  "+code(),BLUE,9,true);lang.setGravity(Gravity.CENTER);lang.setBackground(bg(Color.rgb(245,246,255),Color.TRANSPARENT,12));lang.setOnClickListener(v->LanguageManager.showPicker(this,()->recreate()));head.addView(lang,lp(dp(58),dp(38)));root.addView(head,lp(-1,dp(60)));
        TextView welcome=txt(LanguageManager.t(this,"more"),14,PURPLE,true);welcome.setPadding(dp(4),dp(16),0,dp(8));root.addView(welcome,lp(-1,dp(40)));
        root.addView(item("MY FEED","Personal feed and posts",R.drawable.dash_action_feed,()->open("MY FEED","my_feed")));
        if(SessionManager.isModerator(this)) root.addView(item("FEED MODERATION","Review and remove inappropriate posts",android.R.drawable.ic_menu_delete,()->startActivity(new android.content.Intent(UserMenuActivity.this,FeedModerationActivity.class))));
        root.addView(item("LIVE","Watch live streams",R.drawable.dash_action_live,()->open("LIVE","live_now")));
        root.addView(item("GO LIVE","Start a live stream",R.drawable.dash_action_go,()->open("GO LIVE","go_live")));
        root.addView(item("MY SHOP","Shop and products",R.drawable.dash_feat_shop,()->open("MY SHOP","my_shop")));
        root.addView(item("GALLERY","Photo • Audio • Video",R.drawable.dash_feat_gallery,()->{
            android.content.Intent intent=new android.content.Intent(UserMenuActivity.this,GalleryActivity.class);
            startActivity(intent);
        }));
        root.addView(item("SOCIAL MEDIA","Facebook • YouTube • TikTok • Instagram",R.drawable.dash_feat_social,()->open("SOCIAL MEDIA","social_media")));
        root.addView(item("LIVE TV","Live TV channels",R.drawable.dash_feat_tv,()->open("LIVE TV","live_tv")));
        root.addView(item("EXTERNAL MOVIE","External movie links",R.drawable.dash_feat_movie,()->open("EXTERNAL MOVIE","external_movie")));
        root.addView(item("EARN & REWARD","Coins, gifts and rewards",R.drawable.dash_feat_reward,()->open("EARN & REWARD","earn_reward")));
        root.addView(item("CHAT","Chat and messages",android.R.drawable.ic_dialog_email,()->open("CHAT","chat")));
        root.addView(item("MORE APPS","More connected apps",R.drawable.dash_feat_apps,()->open("MORE APPS","more_apps")));
        root.addView(item("LANGUAGE","বাংলা • English • हिन्दी • العربية",android.R.drawable.ic_menu_manage,()->LanguageManager.showPicker(this,()->recreate())));
        root.addView(item("PROFILE","Profile and account",android.R.drawable.ic_menu_myplaces,()->startActivity(new android.content.Intent(UserMenuActivity.this,AccountActivity.class))));
        root.addView(item("LOGOUT","Sign out of this device",android.R.drawable.ic_lock_power_off,()->logout()));
        root.addView(space(6),lp(1,6));
        TextView close=button("CLOSE MENU",DARK,11);close.setGravity(Gravity.CENTER);close.setOnClickListener(v->finish());root.addView(close,lp(-1,dp(44)));
        setContentView(root);
    }
    private LinearLayout item(String title,String desc,int icon,Runnable r){
        LinearLayout c=col(); c.setPadding(dp(10),dp(9),dp(10),dp(9)); c.setBackground(bg(Color.WHITE,Color.rgb(230,232,238),12));
        LinearLayout.LayoutParams cp=lp(-1,dp(108)); cp.bottomMargin=dp(8); c.setLayoutParams(cp);
        LinearLayout row=row();
        ImageView iv=new ImageView(this); iv.setImageResource(icon); iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE); row.addView(iv,lp(dp(48),dp(54)));
        LinearLayout b=col(); b.setPadding(dp(10),dp(1),dp(4),dp(1));
        TextView t=txt(title,13,DARK,true); t.setGravity(Gravity.CENTER_VERTICAL); t.setSingleLine(true); t.setEllipsize(android.text.TextUtils.TruncateAt.END); b.addView(t,lp(-1,dp(30)));
        TextView d=txt(desc,9.5f,Color.DKGRAY,false); d.setGravity(Gravity.CENTER_VERTICAL); d.setMaxLines(2); d.setEllipsize(android.text.TextUtils.TruncateAt.END); b.addView(d,lp(-1,dp(36)));
        row.addView(b,weight(1)); TextView go=txt("›",BLUE,22,true); go.setGravity(Gravity.CENTER); row.addView(go,lp(dp(34),dp(72)));
        c.addView(row,lp(-1,dp(72))); c.setOnClickListener(v->r.run()); return c;
    }
    private void open(String title,String key){try{android.content.Intent i=new android.content.Intent(this,FeatureActivity.class);i.putExtra("title",title);i.putExtra("feature_key",key);startActivity(i);}catch(Exception e){}}
    private void logout(){
        String token=SessionManager.getToken(this);
        SessionManager.clear(this);
        Intent i=new Intent(this,LoginActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        if(token!=null&&!token.isEmpty()) BackendClient.logout(token,new BackendClient.Callback(){public void onSuccess(org.json.JSONObject d){} public void onError(String m){}});
    }
    private String code(){String l=LanguageManager.get(this);if(LanguageManager.EN.equals(l))return "EN";if(LanguageManager.HI.equals(l))return "HI";if(LanguageManager.AR.equals(l))return "AR";return "বাং";}
    private Button button(String s,int c,float z){Button b=new Button(this);b.setText(s);b.setTextColor(c);b.setTextSize(z);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackgroundColor(Color.TRANSPARENT);b.setPadding(0,0,0,0);return b;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private View space(int h){return new View(this);}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams weight(float w){return new LinearLayout.LayoutParams(0,dp(72),w);}private GradientDrawable bg(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;}private TextView txt(String s,float z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
