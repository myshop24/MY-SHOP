# MY SHOP V-641 / 2.9.641 — implementation checkpoint

Base: delivered and CRC/SHA-verified V-640. Next new delivery: V-642. VersionCode641. This is a full source project, not a signed APK. Keep the existing root release pipeline, package identity, original signing Secrets and D1/R2 bindings. No production deployment was performed.

## Ordered work 1–17

1. Ornate comment skins now reserve 104dp minimum and 24dp top/bottom content padding; nine-slice source caps increased so the inner text region can grow rather than remain a thin strip. Messages wrap.
2. Catalog and Live retain the shared renderer, photo/level/name/message ordering. Preview uses authenticated server level and applies the existing fixed-main-Admin level-zero policy consistently. Server failure does not invent a level. Frame fidelity still needs phone verification.
3. Store detail and My Collection support a temporary typed-comment Try preview. No purchase, equip or Live send occurs. Existing catalog default preview remains.
4. General header message padding reduced its visual size; normal footer icons use consistent32dp bounds. Central AnimatedLiveIconView unchanged.
5. Black Create circle, red horizontal arms and green vertical arms. Profile diameter32→35.2dp (+10%).
6. Default duplicate color-preview text is hidden; explicit color edits can show a private style preview. Photo/video controls enlarged. Picker accepts direct URI or ClipData. Selected video gets a background-generated thumbnail and a tappable player. Composer still uses one selected attachment, not a new multi-media editor.
7. Profile post filters All/Videos/Photos; caption expands by tap; video opens the actual post; own caption editing/delete and Gift use existing APIs/postID. Profile edits/deletes mark Home feed dirty for refresh. Existing ACL/like/comment/share and Home publishing APIs preserved.
8. Hamburger is one compact four-column grid filtered by five one-line tabs All/স্টোর/এজেন্ট/কুইক লিংক/এক্সপ্লোর. Existing cell routes retained. Admin stays last and role-gated. Store tab currently shows its Store entry, whose tap opens the existing full Store.
9. Admin long-press drag reorders cells; explicit Save/Publish writes order under existing revision-guarded panel settings. Stable visual keys survive label language changes. Color edits preserve the saved order.
10. Per-tab independent panel scopes expose the existing20 ready colors and wheel only to Admin. Backend validates scope, authority, revisions and duplicate/invalid order. Existing other panel scopes retained.
11. Authority GIF pixels/frames unchanged; view clips its bottom12% to hide the source underline. Verify on phone that no desired animation detail is clipped. Membership emblems align vertically center.
12. SpeakingWaveView no longer draws a perpetual decorative orbit when silent; speaking pulse/bars still run only while speaking. Purchased/Equipped frame rendering remains independent and unchanged.
13. Profile menu: identity → Live Streaming → My Collection, connected to existing owned-items system. Collection filters owned theme/comment/member/frame/rider, includes free enabled Admin themes and active assigned comment preview.
14. Collection shows source/expiry, retains existing ownership/renewal/history, adds unequip with owner/expiry/type checks, and retains persisted theme selection. Reminder cadence extends existing entitlement-deduplicated expiry reminders to3days and1day. Actual device push delivery unverified.
15. Admin comment settings exposed in profile menu. ID/name/photo confirmation,1–3650day grants, revoke, role presets, Admin-only wheel and separate assignment audit. Normal users may now receive an Admin grant as authorized; Moderator cannot assign. Own active grant is returned only in authenticated own Collection. Existing authority legacy styles retained for migration.
16. Approved storefront entrance artwork generated as a separate150KB WebP, below shop advertising and above search; one continuous glass showcase with central Store doorway. Tap opens existing StoreActivity. The artwork is a fixed entrance asset, not an ad carousel.
17. Catalog shelf and HorizontalScrollView child explicitly wrap height with fillViewport disabled, preventing a full-screen New shelf gap before Membership. No catalog items/prices/ownership removed.

## Verification

V641-regression.log: complete tools/v626_target_verify.sh passed, including Node/SQLite suites, Live invite/lifecycle/integrity/fast-ack, account deletion, exact gift send compiler, Java parsing/Context audit, resource and package checks.
V641-target.log: tools/v640_target_verify.sh passed including privacy, quota, authority grants, defaults, Story cleanup, dashboard/notices, Story callback negative control and lambda audit.
V641-menu.log: actual SQLite panel handler verifies five isolated scopes, role denial, revision conflicts, invalid order and order survival during color saves.
These are local source/SQLite/Java-fixture checks, NOT full Android type checking or a phone test. Local assembleRelease was attempted; Gradle8.11.1 download failed with java.net.SocketException: Network is unreachable. No APK exists for V641 here. GitHub must build this exact selected source and verify latest commit SHA, SOURCE_BUILD_ID, version, original signing certificate and final artifact timestamp/hash. Only one verified signed APK should be presented to end users.

## Acceptance limits and remaining work

Do not claim all17 items are100% device/reference accepted. No actual Android build, emulator, real-phone test, RTC/audio session, purchase or production D1/R2/push test was possible. Validate320/360/412dp widths, Bengali font scaling, keyboard/media picker lifecycle, loading/error states, menu drag/save across two accounts, animated badge clipping and all Live comment lengths on phones. Catalogue preview still uses plain own avatar while Live can decorate an equipped frame. Normal Home/Profile view counts were not newly implemented. Profile caption expands by tap without a separate textual “আরও দেখুন” label. The fixed storefront artwork has one Store tap target, not separate per-product hot spots. Collection retains existing membership automatic priority, not a new membership switcher; expiry/grant/preview parity and granted style selection need further phone acceptance. Multi-attachment/album/music/tag/location/Feeling editors from Facebook comparison remain outside this scoped composer fix. These limits must be reported honestly, not hidden by a green source test.

## Safe continuation

Continue from this source, never restartV640. Latest owner17-task conversation is authoritative. Review pending acceptance above before marking feature-complete. Required full-source inputs and original signing workflow remain. Prior version ZIPs are retained. Regressions outside authorized menu/comment/post/collection scope are locked. Source ZIP is CRC-tested, system-unzip tested, extracted and byte-compared before atomic rename, then saved and downloaded once for exact SHA verification.
