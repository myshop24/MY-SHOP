package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** Shared Login entry point for USER / MODERATOR / ADMIN. */
public class LoginActivity extends AppCompatActivity {
    private EditText fallbackLoginId;
    private EditText fallbackPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            if (SessionManager.isLoggedIn(this) && !SessionManager.getUserId(this).isEmpty()) {
                String profile = getSharedPreferences("myshop_session", MODE_PRIVATE)
                        .getString("full_name", "");
                if (!profile.trim().isEmpty()) {
                    openMain();
                    return;
                }
                SessionManager.clear(this);
            }
            showXmlLogin();
        } catch (Throwable t) {
            // If XML/theme inflation ever fails, keep the app usable instead of leaving
            // a blank Activity. The fallback still requires normal authentication.
            showLoginFallback(t);
        }
    }

    private void showXmlLogin() {
        setContentView(R.layout.activity_login);
        Button create = findViewById(R.id.createAccountButton);
        Button login = findViewById(R.id.loginButton);
        Button forgot = findViewById(R.id.forgotButton);

        if (create == null || login == null || forgot == null) {
            throw new IllegalStateException("Login layout is missing required buttons");
        }

        create.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
        login.setOnClickListener(v -> login());
        forgot.setOnClickListener(v -> Toast.makeText(
                this,
                "Password reset will be connected to the secure backend.",
                Toast.LENGTH_LONG
        ).show());
    }

    private void showLoginFallback(Throwable error) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(28, 40, 28, 28);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("🛍️\nMY SHOP\nShop Smart, Live Better");
        title.setGravity(Gravity.CENTER);
        title.setTextSize(28);
        title.setTextColor(Color.rgb(18, 87, 232));
        title.setPadding(0, 10, 0, 28);

        fallbackLoginId = new EditText(this);
        fallbackLoginId.setHint("User ID / Email / Mobile");
        fallbackLoginId.setSingleLine(true);

        fallbackPassword = new EditText(this);
        fallbackPassword.setHint("Password");
        fallbackPassword.setSingleLine(true);
        fallbackPassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        Button login = new Button(this);
        login.setText("LOGIN");
        login.setOnClickListener(v -> login());

        Button create = new Button(this);
        create.setText("Create Account");
        create.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));

        Button forgot = new Button(this);
        forgot.setText("Forgot Password?");
        forgot.setOnClickListener(v -> Toast.makeText(
                this,
                "Password reset will be connected to the secure backend.",
                Toast.LENGTH_LONG
        ).show());

        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        root.addView(fallbackLoginId, new LinearLayout.LayoutParams(-1, 58));
        root.addView(fallbackPassword, new LinearLayout.LayoutParams(-1, 58));
        root.addView(login, new LinearLayout.LayoutParams(-1, 60));
        root.addView(create, new LinearLayout.LayoutParams(-1, 56));
        root.addView(forgot, new LinearLayout.LayoutParams(-1, 48));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);
        Toast.makeText(this, "MY SHOP login loaded in safe mode.", Toast.LENGTH_SHORT).show();
    }

    private void login() {
        try {
            String identifier;
            String pass;

            if (fallbackLoginId != null && fallbackPassword != null) {
                identifier = fallbackLoginId.getText().toString().trim();
                pass = fallbackPassword.getText().toString();
            } else {
                EditText id = findViewById(R.id.loginId);
                EditText password = findViewById(R.id.loginPassword);
                identifier = id == null ? "" : id.getText().toString().trim();
                pass = password == null ? "" : password.getText().toString();
            }

            if (identifier.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Email/Mobile/User ID and Password are required.", Toast.LENGTH_SHORT).show();
                return;
            }

            AccountStore.Account account = AccountStore.authenticate(this, identifier, pass);
            if (account == null) {
                Toast.makeText(this, "Login failed. Check your Email/Mobile/User ID and Password.", Toast.LENGTH_LONG).show();
                return;
            }

            // Role resolution remains backend-owned. This local prototype never grants
            // Admin/Moderator privileges by matching an email or phone inside the APK.
            SessionManager.setSession(this, Role.USER, account.userId);
            SessionManager.saveProfile(this, account.name, account.email, account.mobile);
            openMain();
        } catch (Throwable t) {
            Toast.makeText(this, "Login failed safely. Your account data was not changed.", Toast.LENGTH_LONG).show();
        }
    }

    private void openMain() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }
}
