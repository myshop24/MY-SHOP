package com.myshop.app;
import org.json.JSONObject;
/** Public aliases are presentation only. Session/financial/RTC identifiers never change. */
final class DisplayIds611 {
 private static final java.util.Map<String,String> IDS=new java.util.HashMap<>();
 static void observe(JSONObject response){JSONObject map=response.optJSONObject("displayIds");if(map!=null){IDS.clear();java.util.Iterator<String> keys=map.keys();while(keys.hasNext()){String key=keys.next(),value=map.optString(key);if(!key.matches("000[123]")&&value.matches("[1-9][0-9]{3}"))IDS.put(key,value);}}JSONObject user=response.optJSONObject("user");if(user!=null){String id=user.optString("userId",user.optString("user_id")),alias=user.optString("publicId");if(!id.matches("000[123]")&&alias.matches("[1-9][0-9]{3}"))IDS.put(id,alias);}}
 static String number(String id){return IDS.getOrDefault(id,id);}
 static String format(String text){if(text==null)return "";java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?i)(ID\\s*[•:#]?\\s*)([0-9]{4})(?![0-9])").matcher(text);StringBuffer out=new StringBuffer();while(m.find())m.appendReplacement(out,java.util.regex.Matcher.quoteReplacement(m.group(1)+IDS.getOrDefault(m.group(2),m.group(2))));m.appendTail(out);return out.toString();}
 private DisplayIds611(){}
}
