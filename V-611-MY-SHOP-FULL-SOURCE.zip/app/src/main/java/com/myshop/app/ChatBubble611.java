package com.myshop.app;
import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
/** Approved blank textures + live light/particle animation. Text and identity are separate Views. */
final class ChatBubble611 {
 private static Bitmap atlas;
 static synchronized Bitmap atlas(Context c){if(atlas==null)try(java.io.InputStream in=c.getAssets().open("chat_v611/skins.webp")){atlas=BitmapFactory.decodeStream(in);}catch(Exception ignored){}return atlas;}
 static int slot(JSONObject x){return slot(x.optString("code",x.optString("item_code",""))+" "+x.optString("animation_url"));}
 static int slot(String raw){if(raw==null)return -1;java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?:CHAT611_|myshop-chat://)([0-9]{1,2})",java.util.regex.Pattern.CASE_INSENSITIVE).matcher(raw);if(m.find()){int n=Integer.parseInt(m.group(1))-1;return n>=0&&n<10?n:-1;}return -1;}
 static int ink(int slot){return slot==6?0xff382439:Color.WHITE;}
 static int accent(int slot){return new int[]{0xff40c8ff,0xffff79b6,0xffffd766,0xffaf73ff,0xff49f5be,0xffc9e8ff,0xffff93c2,0xffff6a33,0xff60e5ff,0xffffd370}[Math.max(0,Math.min(9,slot))];}
 static View preview(Context c,JSONObject x,String name){int slot=slot(x);LinearLayout box=new LinearLayout(c);box.setOrientation(1);box.setGravity(android.view.Gravity.CENTER);LinearLayout comment=new LinearLayout(c);comment.setOrientation(0);comment.setGravity(android.view.Gravity.CENTER_VERTICAL);comment.setBackground(new Skin(c,slot));int pad=Math.round(14*c.getResources().getDisplayMetrics().density);comment.setPadding(pad,pad,pad,pad);ImageView photo=new ImageView(c);photo.setImageResource(R.drawable.myshop_profile_avatar);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);CachedImages.load(photo,SessionManager.getAvatarUrl(c));comment.addView(photo,new LinearLayout.LayoutParams(pad*3,pad*3));LinearLayout text=new LinearLayout(c);text.setOrientation(1);TextView title=new TextView(c);title.setText(name);title.setTextSize(12);title.setTextColor(ink(slot));title.setSingleLine(true);text.addView(title);TextView body=new TextView(c);body.setText("সবাই কেমন আছেন? ❤️");body.setTextColor(ink(slot));body.setTextSize(11);text.addView(body);comment.addView(text,new LinearLayout.LayoutParams(0,-2,1));box.addView(comment,new LinearLayout.LayoutParams(-1,-2));return box;}
 static final class Skin extends Drawable {
  private final Context context;private final int slot;private final Paint paint=new Paint(3);private final Runnable tick=this::invalidateSelf;private final boolean play;private final Rect source;
  Skin(Context c,int slot){context=c.getApplicationContext();this.slot=Math.max(0,Math.min(9,slot));play=!c.getSharedPreferences("myshop_accessibility",0).getBoolean("reduce_animation",false);int row=this.slot/2,left=(this.slot%2)*512;int[] tops={90,340,600,870,1138},bottoms={340,610,860,1138,1440};source=new Rect(left,tops[row],left+512,bottoms[row]);atlas(c);}
  public void draw(Canvas c){Rect b=getBounds();Bitmap texture=atlas(context);if(texture!=null){int sw=source.width(),sh=source.height(),xcap=84,ycap=48;float dx=Math.min(b.width()/4f,b.height()*.35f),dy=Math.min(b.height()/4f,18*context.getResources().getDisplayMetrics().density);int[] xs={source.left,source.left+xcap,source.right-xcap,source.right},ys={source.top,source.top+ycap,source.bottom-ycap,source.bottom};float[] xd={b.left,b.left+dx,b.right-dx,b.right},yd={b.top,b.top+dy,b.bottom-dy,b.bottom};for(int y=0;y<3;y++)for(int x=0;x<3;x++)c.drawBitmap(texture,new Rect(xs[x],ys[y],xs[x+1],ys[y+1]),new RectF(xd[x],yd[y],xd[x+1],yd[y+1]),paint);}
   if(play&&getCallback()!=null){float time=(android.os.SystemClock.uptimeMillis()%4200)/4200f;paint.setColor(accent(slot));for(int i=0;i<7;i++){float phase=(time+i/7f)%1f;paint.setAlpha((int)(80+150*Math.sin(Math.PI*phase)));float x=b.left+phase*b.width(),y=(i%2==0?b.top+8:b.bottom-8);float radius=1.4f+1.7f*(float)Math.sin(Math.PI*phase);c.drawCircle(x,y,radius,paint);if(i==0){paint.setStrokeWidth(1.5f);c.drawLine(x-6,y,x+6,y,paint);c.drawLine(x,y-6,x,y+6,paint);}}paint.setAlpha(255);unscheduleSelf(tick);scheduleSelf(tick,android.os.SystemClock.uptimeMillis()+33);}
  }
  public void setAlpha(int a){paint.setAlpha(a);}public void setColorFilter(ColorFilter f){paint.setColorFilter(f);}public int getOpacity(){return PixelFormat.TRANSLUCENT;}
 }
 private ChatBubble611(){}
}
