package com.myshop.app;
import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;
/** 20 distinct reference-approved ad textures, with live edge light and sparkle effects. */
final class AdSkin611 extends Drawable {
 private static Bitmap atlas;private final Paint paint=new Paint(3);private final int template;private final boolean play;private Integer first,last;private final Runnable tick=this::invalidateSelf;
 AdSkin611(Context c,int template,boolean animate,String first,String last){this(c,template,animate);try{this.first=Color.parseColor(first);this.last=Color.parseColor(last);}catch(Exception ignored){}}
 AdSkin611(Context c,int template,boolean animate){this.template=Math.max(1,Math.min(20,template))-1;play=animate&&!c.getSharedPreferences("myshop_accessibility",0).getBoolean("reduce_animation",false);if(atlas==null)try(java.io.InputStream in=c.getApplicationContext().getAssets().open("ads_v611/cards.webp")){atlas=BitmapFactory.decodeStream(in);}catch(Exception ignored){}}
 public void draw(Canvas c){Rect b=getBounds();if(atlas!=null){int left=template%2*atlas.getWidth()/2,top=template/2*atlas.getHeight()/10,bottom=(template/2+1)*atlas.getHeight()/10;c.drawBitmap(atlas,new Rect(left,top,left+atlas.getWidth()/2,bottom),b,paint);}if(first!=null){paint.setAlpha(195);paint.setShader(new LinearGradient(b.left,b.top,b.right,b.bottom,first,last,Shader.TileMode.CLAMP));c.drawRoundRect(new RectF(b.left+b.width()*.28f,b.top+b.height()*.27f,b.left+b.width()*.87f,b.top+b.height()*.73f),8,8,paint);paint.setShader(null);paint.setAlpha(255);}if(play&&getCallback()!=null){float t=(android.os.SystemClock.uptimeMillis()%3600)/3600f;paint.setColor(Color.WHITE);for(int i=0;i<6;i++){float f=(t+i/6f)%1;float x=b.left+b.width()*f,y=i%2==0?b.top+b.height()*.12f:b.bottom-b.height()*.12f;paint.setAlpha((int)(60+180*Math.sin(Math.PI*f)));c.drawCircle(x,y,1.3f+1.2f*(float)Math.sin(Math.PI*f),paint);}paint.setAlpha(255);unscheduleSelf(tick);scheduleSelf(tick,android.os.SystemClock.uptimeMillis()+33);}}
 public void setAlpha(int a){paint.setAlpha(a);}public void setColorFilter(ColorFilter f){paint.setColorFilter(f);}public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
