# MY SHOP DEVELOPER HANDOFF — V-373

## Phase
Live mute/join/call eligibility stabilization.

## Completed
- Mute is no longer treated as a join-request ban.
- A previously muted audience user can send a new Join Request.
- Host / Room Admin / MY SHOP Admin / Moderator can invite a muted audience user to call, subject only to real Block/Kick restrictions.
- Accepting a fresh Join Request clears stale MUTED sanction before assigning the speaker seat.
- Accepting a host invite continues to clear stale MUTED sanction before assigning a seat.
- Permanent Block/Kick restrictions remain enforced.
- V-372 premium button work and all unrelated modules preserved.

## Pending real-device QA
- Mute audience user -> user remains visible -> Join Request succeeds.
- Mute audience user -> Host top-user Invite/Suggest Call succeeds.
- Room Admin / MY SHOP Admin / Moderator Call Suggest succeeds according to role.
- Accepted user reaches speaker seat with mic state usable.
- Blocked/Kicked user still cannot request or accept call.

## Last checkpoint
V-373 source prepared from V-372 baseline with scoped backend-only live eligibility logic plus release metadata.

## Next tasks
Real-device multi-user validation, then lock as golden stable source if PASS.

## Known issues
Full Android/Cloudflare deployment runtime cannot be executed in this container; device + deployed Worker validation remains required.
