package com.myshop.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

/** V-181: Startup banner ad shown without cropping, then explicit Login choice. */
public class StartupAdActivity extends Activity {
    private CountDownTimer timer;
    private boolean opened = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);

        // Wide banner must stay fully visible on portrait phones.
        // CENTER_INSIDE prevents the old CENTER_CROP behavior that cut off the artwork.
        ImageView ad = new ImageView(this);
        ad.setImageResource(R.drawable.banner_wide_1);
        ad.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        ad.setAdjustViewBounds(true);
        FrameLayout.LayoutParams adLp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        adLp.leftMargin = dp(10);
        adLp.rightMargin = dp(10);
        root.addView(ad, adLp);

        TextView label = new TextView(this);
        label.setText("ADVERTISEMENT");
        label.setTextColor(Color.WHITE);
        label.setTextSize(11);
        label.setGravity(Gravity.CENTER);
        label.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(118), dp(34), Gravity.TOP|Gravity.START);
        lp.setMargins(dp(12), dp(12), 0, 0);
        root.addView(label, lp);

        Button skip = new Button(this);
        skip.setText("Skip 3");
        skip.setAllCaps(false);
        skip.setTextColor(Color.WHITE);
        skip.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(dp(105), dp(48), Gravity.TOP|Gravity.END);
        sp.setMargins(0, dp(10), dp(10), 0);
        root.addView(skip, sp);
        skip.setOnClickListener(v -> openLogin());

        TextView hint = new TextView(this);
        hint.setText("Startup Advertisement");
        hint.setTextColor(Color.DKGRAY);
        hint.setTextSize(13);
        hint.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, dp(44), Gravity.BOTTOM);
        hp.setMargins(dp(12), 0, dp(12), dp(12));
        root.addView(hint, hp);

        setContentView(root);
        timer = new CountDownTimer(3000, 1000) {
            int seconds = 3;
            public void onTick(long left) {
                skip.setText("Skip " + seconds);
                seconds--;
            }
            public void onFinish() { openLogin(); }
        }.start();
    }

    private void openLogin() {
        if (opened) return;
        opened = true;
        if (timer != null) timer.cancel();
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    @Override protected void onDestroy() {
        if (timer != null) timer.cancel();
        super.onDestroy();
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
