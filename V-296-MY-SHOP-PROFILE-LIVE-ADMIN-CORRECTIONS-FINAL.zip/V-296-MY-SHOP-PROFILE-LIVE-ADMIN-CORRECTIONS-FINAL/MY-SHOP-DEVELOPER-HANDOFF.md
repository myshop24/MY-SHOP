# MY SHOP Developer Handoff — V-296

## Base / current version
- Base: V-295
- Current source: V-296
- Android versionCode: 296
- Android versionName: 2.9.296
- Worker: V-296 / 2.9.296

## Completed in this checkpoint
- Admin Locker first-time setup/unlock/recovery UI and backend-safe owner recovery handling.
- Main Admin Gate is one-password-per-admin-session; no repeated password prompts inside folders.
- Dashboard bottom navigation safe-area lift.
- Live comments/highlights isolated by live session ID.
- Highlight one-purchase/one-event replay protection.
- Compact profile redesign with separate Settings & Privacy.
- Dedicated Coin Wallet (Buy/Withdraw/History) and Gold Wallet.
- Store categories and My Items / Inventory.
- Live-only Avatar Frame/Theme ownership + equip API.
- Expanded Admin Store product types and Add/Edit/Save/Publish/Enable/Delete controls.
- Configurable VAT/service-charge integration for Store Coin purchases and value-ledger recording.
- Preserved V-295 Live Name 24h/5000 Coin, React reward, finance overview and user investigation features.

## Database changes
Run/apply backend/worker/migrations/0013_v296_profile_live_admin_corrections.sql through the existing deployment workflow.
Live session_id columns are repaired idempotently in ensureLiveRoomSchema() instead of being unconditionally ALTERed in the migration.

## Validation completed
- Worker JS syntax: PASS.
- Android Manifest/resource XML parse: PASS.
- Java parser-level syntax scan: PASS (not a full Android compile).
- Account profile resource-ID compatibility scan: PASS.
- Raw owner recovery identifier scan: PASS (none in deliverable source).
- Version markers: PASS.
- targetSdk/compileSdk 36: PASS for current target API requirement.

## Pending release checks
1. Push V-296 ZIP to the repository root and run the existing GitHub Actions release workflow.
2. Confirm D1 migration 0013 and active Worker health V-296.
3. Install the produced release build on gesture-navigation and 3-button-navigation Android devices.
4. Live QA: start Live A, comment/highlight, end; start Live B and confirm Live A comments/highlights do not appear.
5. Admin QA: first-time locker create -> close -> reopen -> password unlock -> open multiple admin folders without repeated password.
6. Store QA: purchase/equip Avatar Frame and Live Theme; confirm normal profile avatar is unchanged and items appear in My Items.
7. Wallet QA: Coin withdrawal Pending request and finance ledger/VAT totals.
8. Run Play Console pre-launch report and complete/update privacy/Data safety declarations before production release.

## Known limitation
The current local execution environment does not contain the Android SDK/Gradle runtime needed for a full APK/AAB compile. The repository workflow installs Gradle 8.11.1 and performs the release build.
