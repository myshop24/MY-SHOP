package com.myshop.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;

/** V-296: one-time premium Admin Locker gate with working setup/recovery controls. */
public class AdminGateActivity extends AppCompatActivity {
    private LinearLayout root;
    private final int NAVY=Color.rgb(18,27,63), PURPLE=Color.rgb(101,48,210), BLUE=Color.rgb(42,92,224), MUTED=Color.rgb(102,111,139), CARD=Color.WHITE;
    private final String[] questions={
            "আপনার পছন্দের ব্যক্তির নাম কী?",
            "আপনার জন্মস্থানের জেলা কী?",
            "আপনার পছন্দের রং কী?",
            "আপনার পছন্দের শিক্ষকের নাম কী?",
            "নিজের Security Question লিখুন"
    };

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        if(!SessionManager.isAdmin(this)){finish();return;}
        buildLoading();
        BackendClient.adminGateStatus(token(),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                if(d.optBoolean("unlocked",false)){SessionManager.setAdminGateUnlocked(true);openHub();}
                else if(d.optBoolean("configured",false)) buildUnlock(d.optString("securityQuestion",""));
                else buildSetup();
            });}
            public void onError(String e){runOnUiThread(()->{toast(e);buildSetup();});}
        });
    }

    private void buildLoading(){
        root=base(); root.addView(title("🔐 MY SHOP ADMIN LOCKER",22),lp(-1,64));
        TextView t=txt("Security check…",13,MUTED,false);t.setGravity(Gravity.CENTER);root.addView(t,lp(-1,80));
        setContentView(scroll(root));
    }

    private void buildSetup(){
        root=base();
        root.addView(title("🔐 Create Admin Locker",23),lp(-1,58));
        root.addView(info("একবার Password ও Security Question সেট করুন। এরপর Admin Panel-এ ঢোকার সময় শুধু একবার Password লাগবে।"),lp(-1,-2));

        final EditText pass=field("Admin Password • minimum 6 characters",true); root.addView(pass);
        CheckBox show=new CheckBox(this);show.setText("Show password");show.setTextColor(MUTED);show.setTextSize(11);show.setOnCheckedChangeListener((b,c)->{int pos=pass.getSelectionStart();pass.setInputType(InputType.TYPE_CLASS_TEXT|(c?InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD:InputType.TYPE_TEXT_VARIATION_PASSWORD));pass.setSelection(Math.max(0,pos));});root.addView(show,lp(-1,38));

        TextView qLabel=txt("Security Question",12,NAVY,true);root.addView(qLabel,top(lp(-1,30),8));
        Spinner spinner=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,questions);spinner.setAdapter(adapter);spinner.setBackground(round(CARD,Color.rgb(211,216,234),14));root.addView(spinner,lp(-1,52));
        EditText custom=field("Custom Security Question",false);custom.setVisibility(View.GONE);root.addView(custom);
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){custom.setVisibility(pos==questions.length-1?View.VISIBLE:View.GONE);}public void onNothingSelected(android.widget.AdapterView<?> p){}});
        EditText ans=field("Security Answer",false);root.addView(ans);

        TextView save=action("🔐  CREATE ADMIN LOCKER",BLUE,Color.WHITE);
        save.setOnClickListener(v->{
            hideKeyboard(); String ps=pass.getText().toString(); int qi=spinner.getSelectedItemPosition();
            String qs=(qi==questions.length-1?custom.getText().toString().trim():questions[Math.max(0,qi)]); String as=ans.getText().toString().trim();
            if(ps.length()<6){pass.setError("কমপক্ষে 6 characters দিন");return;}
            if(qs.isEmpty()){custom.setError("Security Question দিন");return;}
            if(as.length()<2){ans.setError("Security Answer দিন");return;}
            save.setEnabled(false);save.setText("Creating locker…");
            BackendClient.adminGateSetup(token(),ps,qs,as,new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->{toast("Admin Locker Created Successfully");buildUnlock(qs);});}
                public void onError(String e){runOnUiThread(()->{save.setEnabled(true);save.setText("🔐  CREATE ADMIN LOCKER");toast(e);});}
            });
        });
        root.addView(save,top(lp(-1,54),14));
        setContentView(scroll(root));
    }

    private void buildUnlock(String question){
        root=base(); root.addView(title("🔐 Admin Gate",24),lp(-1,58));
        TextView badge=txt("ONE PASSWORD • FULL ADMIN SESSION",10,Color.WHITE,true);badge.setGravity(Gravity.CENTER);badge.setBackground(round(PURPLE,PURPLE,14));root.addView(badge,lp(-1,38));
        root.addView(info("Password দিয়ে একবার Unlock করুন। এরপর Gift, Coin, Live, Finance, Add/Edit/Save/Delete-এ আর Password চাইবে না।"),top(lp(-1,-2),10));
        final EditText pass=field("Admin Password",true);root.addView(pass);
        CheckBox show=new CheckBox(this);show.setText("Show password");show.setTextColor(MUTED);show.setTextSize(11);show.setOnCheckedChangeListener((b,c)->{int pos=pass.getSelectionStart();pass.setInputType(InputType.TYPE_CLASS_TEXT|(c?InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD:InputType.TYPE_TEXT_VARIATION_PASSWORD));pass.setSelection(Math.max(0,pos));});root.addView(show,lp(-1,38));
        TextView unlock=action("🔓  UNLOCK ADMIN PANEL",BLUE,Color.WHITE);unlock.setOnClickListener(v->{String p=pass.getText().toString();if(p.isEmpty()){pass.setError("Password দিন");return;}hideKeyboard();unlock.setEnabled(false);unlock.setText("Checking…");BackendClient.adminGateUnlock(token(),p,new BackendClient.Callback(){public void onSuccess(JSONObject d){SessionManager.setAdminGateUnlocked(true);openHub();}public void onError(String e){runOnUiThread(()->{unlock.setEnabled(true);unlock.setText("🔓  UNLOCK ADMIN PANEL");toast(e);});}});});root.addView(unlock,top(lp(-1,54),14));
        TextView forgot=action("Forgot Password?",Color.WHITE,PURPLE);forgot.setBackground(round(Color.WHITE,Color.rgb(195,181,235),15));forgot.setOnClickListener(v->showQuestionRecovery(question));root.addView(forgot,top(lp(-1,50),9));
        setContentView(scroll(root));
    }

    private void showQuestionRecovery(String question){
        LinearLayout b=dialogBox();b.addView(info("Security Question\n"+(question.isEmpty()?"আপনার সেট করা Security Question":question)));
        EditText ans=field("Security Answer",false),np=field("New Admin Password",true);b.addView(ans);b.addView(np);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Recover Admin Locker").setView(b).setNegativeButton("Cancel",null).setNeutralButton("Answerও ভুলে গেছি",null).setPositiveButton("Reset",null).create();
        dlg.setOnShowListener(x->{dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(np.getText().length()<6){np.setError("Minimum 6 characters");return;}BackendClient.adminGateRecoverQuestion(token(),ans.getText().toString(),np.getText().toString(),new Cb("Password reset",()->{dlg.dismiss();buildUnlock(question);}));});dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{dlg.dismiss();showOwnerRecovery(question);});});dlg.show();
    }

    private void showOwnerRecovery(String question){
        LinearLayout b=dialogBox();b.addView(info("Owner Recovery: আপনার ৩টি গোপন Admin ID-এর মধ্যে অন্তত ২টি সঠিক দিন। ID-গুলো Screen-এ দেখানো হবে না।"));
        EditText a=field("Admin ID 1",false),c=field("Admin ID 2",false),d=field("Admin ID 3 • optional",false),np=field("New Admin Password",true);b.addView(a);b.addView(c);b.addView(d);b.addView(np);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Owner Recovery").setView(b).setNegativeButton("Cancel",null).setPositiveButton("Reset Password",null).create();
        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(np.getText().length()<6){np.setError("Minimum 6 characters");return;}BackendClient.adminGateRecoverIds(token(),a.getText().toString(),c.getText().toString(),d.getText().toString(),np.getText().toString(),new Cb("Password reset",()->{dlg.dismiss();buildUnlock(question);}));}));dlg.show();
    }

    private void openHub(){runOnUiThread(()->{startActivity(new android.content.Intent(this,AdminHubActivity.class).putExtra("gate_passed",true));finish();});}
    private String token(){return SessionManager.getToken(this);} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void hideKeyboard(){try{InputMethodManager im=(InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);View v=getCurrentFocus();if(v!=null)im.hideSoftInputFromWindow(v.getWindowToken(),0);}catch(Exception ignored){}}
    private LinearLayout base(){LinearLayout l=dialogBox();l.setPadding(dp(18),dp(24),dp(18),dp(34));return l;} private LinearLayout dialogBox(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;} private ScrollView scroll(LinearLayout l){ScrollView s=new ScrollView(this);s.setFillViewport(true);s.setClipToPadding(false);s.setPadding(0,0,0,dp(18));s.setBackgroundColor(Color.rgb(247,249,254));s.addView(l);return s;}
    private TextView title(String s,int z){TextView t=txt(s,z,NAVY,true);t.setGravity(Gravity.CENTER_VERTICAL);return t;} private TextView info(String s){TextView t=txt(s,11,MUTED,false);t.setPadding(dp(12),dp(10),dp(12),dp(10));t.setBackground(round(Color.WHITE,Color.rgb(225,228,240),14));return t;}
    private EditText field(String h,boolean pass){EditText e=new EditText(this);e.setHint(h);e.setTextColor(NAVY);e.setHintTextColor(Color.rgb(136,145,170));e.setTextSize(13);e.setSingleLine(true);e.setPadding(dp(14),0,dp(14),0);e.setBackground(round(Color.WHITE,Color.rgb(211,216,234),14));if(pass)e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);LinearLayout.LayoutParams p=lp(-1,52);p.topMargin=dp(10);e.setLayoutParams(p);return e;}
    private TextView action(String s,int bg,int fg){TextView b=txt(s,12,fg,true);b.setGravity(Gravity.CENTER);b.setBackground(round(bg,bg,15));b.setClickable(true);b.setFocusable(true);return b;}
    private TextView txt(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;} private GradientDrawable round(int fill,int stroke,int r){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(r));g.setStroke(dp(1),stroke);return g;} private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;} private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
    private class Cb implements BackendClient.Callback{final String ok;final Runnable r;Cb(String o,Runnable rr){ok=o;r=rr;}public void onSuccess(JSONObject d){runOnUiThread(()->{toast(ok);r.run();});}public void onError(String e){runOnUiThread(()->toast(e));}}
}
