# MY SHOP Developer Handoff — V-366

## Phase
Critical carousel continuity + Live Audio on-device verification.

## Completed
- Kept V-365 crash/lifecycle guards intact.
- Added last-known Live Home banner cache so a previously loaded active banner set can render before the fresh network response.
- Changed Live Home carousel to a single self-sustaining scheduler: each tick advances once and schedules exactly one next tick. Resume/network refresh/manual swipe reset only that single timer.
- Added fast first banner tick (~900 ms) while preserving the normal steady 4.5-second Live Home rotation interval.
- Added fast first Dashboard hero tick (~900 ms) after resume/config refresh, then normal 3.5-second rotation.
- Added a visible compact Live Audio status strip using existing RTC callbacks. It reports connecting, mic connected/sending, audience listening, and actual remote voice receiving.
- Preserved Agora app ID/token/channel role architecture and backend seat/role authority; no RTC provider replacement.
- Version identity aligned to V-366 / 2.9.366; Worker health metadata advanced to V-366 only.

## Locked / unchanged
Login/auth, Create Account/Gender, Gift/Coin/Gold Coin economy, Profile/Social/Feed, Store/Wallet, Admin feature modules, core user IDs, D1 schema/data model, Live comments/gifts, moderation, seat actions, join request/invite contracts, and unrelated backend APIs.

## Last checkpoint
Static validation completed for Worker syntax, Android XML, Java delimiter balance, javac syntax-pattern smoke test, targeted content diff, version identity, and protected-file integrity.

## Device acceptance
1. Cold-start app and open Dashboard: hero banner should begin changing quickly and continue indefinitely at the normal cadence.
2. Open Live Streaming Home with 2–6 active banners: first change should occur quickly, then continue 1→2→3→…→1 without freezing for 10+ minutes.
3. Background/foreground Dashboard and Live Home several times: no accelerated duplicate timer and no stopped carousel.
4. Start Audio Live as Host. The Live Audio strip should progress from `Audio connecting` to `Mic connected`; speaking should briefly show `Mic sending`.
5. Join from a second account/device. Audience should show `Listening`; when Host speaks and remote audio packets are decoded, audience should show `Voice receiving`.
6. Verify the actual voice is audible on the second device. The strip is a transport diagnostic, not a substitute for the final ear test.

## Known limitation
This container does not include a runnable Android Gradle wrapper/Android SDK, so signed APK compile and real-device audio playback cannot be claimed here. The source has been statically validated; device acceptance remains the final runtime gate.
