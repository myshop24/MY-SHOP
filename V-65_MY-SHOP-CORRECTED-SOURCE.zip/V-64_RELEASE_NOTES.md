# MY SHOP V-64 — corrective source

Fixes included:
- Approved dashboard runtime is rebuilt from the V-59 final source and keeps the selected banner assets.
- Six LIVE cards are visible together; the old horizontal-scroll live row is removed.
- Header profile photo is selectable from the device gallery and persisted across app updates.
- Admin detection uses the authenticated account identity (permanent Admin IDs 0001/0002/0003 plus configured admin email/mobile identifiers), not only the raw login field.
- Admin mobile matching accepts 018..., 88018... and +88018... forms.
- Admin control screen provides working local Breaking News persistence and status controls instead of dead placeholder buttons.
- Supplied MS icon artwork is used as the application icon.
- Exactly one V-64 APK is accepted by the CI guard and uploaded.

Important: this package does not invent backend credentials or claim a production backend exists. The real server-side Admin authority remains required for production authorization.
