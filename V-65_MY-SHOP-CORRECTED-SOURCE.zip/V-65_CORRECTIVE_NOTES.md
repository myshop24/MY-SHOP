MY SHOP V-65 CORRECTIVE SOURCE

Fixes added beyond V-64:
- Functional local profile editing.
- Functional local password change with current-password verification.
- Account report/block actions now persist locally instead of placeholder-only messages.
- Admin Control button appears only for a recognized Admin session.
- Admin console now has real local actions for breaking news, moderator IDs and shop URL, plus explicit Admin identity/status checks.
- Dashboard notification button opens a functional module.
- FeatureActivity no longer uses a generic placeholder-only screen; each dashboard feature has an action/destination.
- Supplied MS launcher icon retained.
- Version incremented to 2.9.65 / versionCode 65.
- Workflow renamed V-65 and still enforces exactly one APK.

Limitations:
- True production server-side Admin authorization still requires the backend service; this source does not invent admin passwords.
- Runtime APK verification must be performed by GitHub Actions/Android SDK environment.
