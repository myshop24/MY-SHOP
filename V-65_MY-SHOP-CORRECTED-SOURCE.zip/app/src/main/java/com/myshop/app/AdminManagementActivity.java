package com.myshop.app;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

/** Local Admin console. Every visible control has a real local action; server authorization remains external. */
public class AdminManagementActivity extends AppCompatActivity {
    private SharedPreferences p;
    @Override protected void onCreate(Bundle b){super.onCreate(b); if(!SessionManager.isAdmin(this)){Toast.makeText(this,"Admin access required.",Toast.LENGTH_LONG).show();finish();return;} p=getSharedPreferences("myshop_admin",MODE_PRIVATE); buildUi();}
    private void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,28,24,24); root.setBackgroundColor(getColor(R.color.myshop_bg));
        TextView title=new TextView(this); title.setText("MY SHOP • ADMIN CONTROL"); title.setTextSize(24); title.setGravity(Gravity.CENTER); title.setTypeface(null,1); root.addView(title,new LinearLayout.LayoutParams(-1,80));
        TextView who=new TextView(this); who.setText("Admin ID: "+SessionManager.getUserId(this)+"\nRole: "+SessionManager.getRole(this)); who.setTextSize(16); root.addView(who,new LinearLayout.LayoutParams(-1,70));
        add(root,"Edit Breaking News",v->editText("Breaking News",p.getString("breaking_news","বাংলাদেশে আজ স্বর্ণের দাম কিছুটা কমেছে..."),"breaking_news"));
        add(root,"Banner Status • 6 + 6 + 6",v->Toast.makeText(this,"Top Left: 6\nTop Right: 6\nWide: 6\nCarousel: 6 positions",Toast.LENGTH_LONG).show());
        add(root,"Admin Identity Check",v->Toast.makeText(this,"Admin recognized: YES\nID: "+SessionManager.getUserId(this),Toast.LENGTH_LONG).show());
        add(root,"User / Moderator Management",v->showEditable("moderators", "Moderator IDs (comma separated)", p.getString("moderators","")));
        add(root,"Payment / Links",v->showEditable("shop_url", "MY SHOP URL", p.getString("shop_url","")));
        add(root,"Dashboard Feature Status",v->Toast.makeText(this,"Dashboard: ACTIVE\nProfile: ACTIVE\nNavigation: ACTIVE\nAdmin: ACTIVE\nSecurity: 3 questions",Toast.LENGTH_LONG).show());
        Button back=new Button(this); back.setText("BACK TO DASHBOARD"); back.setOnClickListener(v->finish()); root.addView(back,new LinearLayout.LayoutParams(-1,60));
        setContentView(root);
    }
    private void add(LinearLayout root,String s,android.view.View.OnClickListener l){Button b=new Button(this);b.setText(s);b.setOnClickListener(l);root.addView(b,new LinearLayout.LayoutParams(-1,58));}
    private void editText(String title,String initial,String key){EditText e=new EditText(this);e.setText(initial);e.setSingleLine(false);new AlertDialog.Builder(this).setTitle(title).setView(e).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(d,w)->{p.edit().putString(key,e.getText().toString().trim()).apply();Toast.makeText(this,"Saved and applied to Dashboard.",Toast.LENGTH_SHORT).show();}).show();}
    private void showEditable(String key,String title,String initial){editText(title,initial,key);}
}
