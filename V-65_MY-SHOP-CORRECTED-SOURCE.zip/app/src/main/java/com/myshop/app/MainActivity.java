package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** MY SHOP V-64 approved dashboard runtime. */
public class MainActivity extends AppCompatActivity {
    private static final int BG=Color.rgb(248,249,252), TEXT=Color.rgb(25,31,45), BLUE=Color.rgb(29,82,225), PURPLE=Color.rgb(98,36,225), RED=Color.rgb(235,35,55), ORANGE=Color.rgb(245,92,18);
    private static final int MAX=6;
    private static final long SLIDE_MS=3500L;
    private final Handler handler=new Handler();
    private final ImageView[] banners=new ImageView[3];
    private int bannerIndex=0;
    private final int[] left={R.drawable.banner_top_left_1,R.drawable.banner_top_left_2,R.drawable.banner_top_left_3,R.drawable.banner_top_left_4,R.drawable.banner_top_left_5,R.drawable.banner_top_left_6};
    private final int[] right={R.drawable.banner_top_right_1,R.drawable.banner_top_right_2,R.drawable.banner_top_right_3,R.drawable.banner_top_right_4,R.drawable.banner_top_right_5,R.drawable.banner_top_right_6};
    private final int[] wide={R.drawable.banner_wide_1,R.drawable.banner_wide_2,R.drawable.banner_wide_3,R.drawable.banner_wide_4,R.drawable.banner_wide_5,R.drawable.banner_wide_6};
    private final String[] liveNames={"Cute Girl Live","Music Live","Gaming Live","Talk & Fun","Dance Live","Comedy Live"};
    private final int[] liveColors={0xFFEC417E,0xFF0E4896,0xFF122341,0xFF1576BE,0xFF652155,0xFF23233C};
    private ImageView avatar;
    private static final int PICK_PROFILE=7001;

    @Override protected void onCreate(Bundle b){super.onCreate(b); try{setContentView(buildDashboard()); startCarousel();}catch(Throwable t){setContentView(buildSafeHome());}}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams wt(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}

    private View buildDashboard(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(12),dp(8),dp(12),dp(8));

        LinearLayout header=row();
        avatar=new ImageView(this); avatar.setImageResource(R.drawable.myshop_profile_avatar); loadProfilePhoto(); avatar.setScaleType(ImageView.ScaleType.CENTER_CROP); avatar.setBackground(round(Color.WHITE,0xFFDCE0E8,dp(32))); avatar.setClipToOutline(true); avatar.setContentDescription("Profile photo"); avatar.setOnClickListener(v->chooseProfilePhoto()); header.addView(avatar,lp(dp(64),dp(64)));
        LinearLayout user=column(); user.setGravity(Gravity.CENTER_VERTICAL);
        String id=SessionManager.getUserId(this); String name=getSharedPreferences("myshop_session",MODE_PRIVATE).getString("full_name",""); if(name.trim().isEmpty()) name=SessionManager.isAdmin(this)?"Admin":"My Shop User";
        user.addView(text("Hi, "+name+" 👋",TEXT,15,true)); user.addView(text("ID: "+(id.isEmpty()?"Guest":id)+(SessionManager.isLoggedIn(this)?"  ✓":""),BLUE,12,true)); header.addView(user,wt(1.0f,dp(62)));
        EditText search=new EditText(this); search.setSingleLine(true); search.setHint("খুঁজুন পণ্য, লাইভ, ইউজার..."); search.setTextSize(13); search.setPadding(dp(12),0,dp(8),0); search.setBackground(round(Color.WHITE,0xFFDCE0E8,dp(26))); header.addView(search,wt(2.25f,dp(56)));
        TextView bell=pill("🔔 12",RED,Color.WHITE); header.addView(bell,lp(dp(58),dp(56))); bell.setOnClickListener(v->openFeature("Notifications","notifications"));
        Button menu=plainButton("☰",TEXT,27); header.addView(menu,lp(dp(54),dp(56)));
        menu.setOnClickListener(v->{if(SessionManager.isAdmin(this)) startActivity(new Intent(this,AdminManagementActivity.class)); else startActivity(new Intent(this,AccountActivity.class));});
        content.addView(header,lp(-1,dp(66)));

        int screen=getResources().getDisplayMetrics().widthPixels, gap=dp(6), pad=dp(24);
        int sideH=Math.max(dp(70),Math.round(((screen-pad-gap)/2f)*0.53f));
        LinearLayout top=row(); banners[0]=banner(left[0]); banners[1]=banner(right[0]); top.addView(banners[0],wt(1,sideH)); top.addView(space(gap,1)); top.addView(banners[1],wt(1,sideH)); content.addView(top,lp(-1,sideH));
        TextView dots=text("●   ○   ○   ○   ○   ○",PURPLE,13,true); dots.setGravity(Gravity.CENTER); content.addView(dots,lp(-1,dp(24)));
        int wideH=Math.max(dp(54),Math.round((screen-pad)*0.1894f)); banners[2]=banner(wide[0]); LinearLayout.LayoutParams wp=lp(-1,wideH); wp.topMargin=dp(4); content.addView(banners[2],wp);

        String news=getSharedPreferences("myshop_admin",MODE_PRIVATE).getString("breaking_news","বাংলাদেশে আজ স্বর্ণের দাম কিছুটা কমেছে..."); TextView breaking=card("🔴  BREAKING NEWS    |    "+news+"    View All",Color.WHITE,TEXT,13); LinearLayout.LayoutParams bp=lp(-1,dp(48)); bp.topMargin=dp(8); content.addView(breaking,bp); breaking.setOnClickListener(v->openFeature("BREAKING NEWS","breaking_news"));
        LinearLayout lh=row(); lh.addView(text("🔴  LIVE NOW",TEXT,15,true),wt(1,dp(40))); TextView va=text("View All  ›",BLUE,13,true); lh.addView(va,lp(dp(82),dp(40))); va.setOnClickListener(v->openFeature("LIVE NOW","live_now")); content.addView(lh,lp(-1,dp(40)));

        // Six cards are visible together on the approved dashboard; no horizontal-scroll container.
        LinearLayout lives=row(); lives.setGravity(Gravity.CENTER); int cardW=Math.max(dp(92),Math.round((screen-dp(24)-dp(25))/6f));
        for(int i=0;i<6;i++){ TextView c=liveCard(i,cardW); lives.addView(c,lp(cardW,dp(222))); if(i<5) lives.addView(space(dp(5),1)); }
        content.addView(lives,lp(-1,dp(226)));

        LinearLayout pair=row(); ImageView feed=featureImage(R.drawable.feature_my_feed_selected,"MY FEED","my_feed"); ImageView shop=featureImage(R.drawable.feature_my_shop_selected,"MY SHOP","my_shop"); pair.addView(feed,wt(1,dp(86))); pair.addView(space(dp(7),1)); pair.addView(shop,wt(1,dp(86))); content.addView(pair,lp(-1,dp(92)));

        LinearLayout lower=row(); LinearLayout l=column(), r=column(); addSmallImage(l,R.drawable.feature_gallery_selected,"GALLERY","gallery"); addSmallImage(l,R.drawable.feature_live_tv_selected,"LIVE TV","live_tv"); addSmallImage(l,R.drawable.feature_earn_selected,"EARN & REWARD","earn_reward"); addSmallImage(r,R.drawable.feature_external_selected,"EXTERNAL","external_movie"); addSmallImage(r,R.drawable.feature_social_selected,"SOCIAL","social_media"); addSmallImage(r,R.drawable.feature_share_selected,"SHARE","share"); lower.addView(l,wt(1,dp(258))); lower.addView(goLiveImage(),lp(dp(176),dp(258))); lower.addView(r,wt(1,dp(258))); content.addView(lower,lp(-1,dp(264)));
        scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav=row(); nav.setPadding(dp(5),dp(4),dp(5),dp(4)); nav.setBackground(round(Color.WHITE,0xFFE1E4EB,dp(26))); Button home=navButton("⌂\nHOME",BLUE), store=navButton("🛒\nSTORE",TEXT), live=navButton("◉\nLIVE",TEXT), chat=navButton("💬\nCHAT",TEXT), more=navButton("▦\nMORE",TEXT); nav.addView(home,wt(1,dp(62))); nav.addView(store,wt(1,dp(62))); nav.addView(live,wt(1,dp(62))); nav.addView(chat,wt(1,dp(62))); nav.addView(more,wt(1,dp(62))); root.addView(nav,lp(-1,dp(70)));
        store.setOnClickListener(v->openFeature("MY SHOP","my_shop")); live.setOnClickListener(v->openFeature("LIVE","live_now")); chat.setOnClickListener(v->openFeature("CHAT","chat")); more.setOnClickListener(v->startActivity(new Intent(this,AccountActivity.class)));
        return root;
    }

    private TextView liveCard(int i,int w){ TextView v=card("LIVE\n"+liveNames[i]+"\nID: 10"+(i+1)+" ✓\n👁 "+(12-i*1.7f)+"K\nWATCH NOW  ▶",Color.WHITE,0xFF111827,9); v.setGravity(Gravity.CENTER); v.setPadding(dp(3),dp(4),dp(3),dp(4)); v.setOnClickListener(x->openFeature(liveNames[i],"live_room")); return v; }
    private void addSmallImage(LinearLayout p,int res,String desc,String key){ImageView v=featureImage(res,desc,key); v.setScaleType(ImageView.ScaleType.CENTER_CROP); LinearLayout.LayoutParams q=lp(-1,dp(82)); q.bottomMargin=dp(4); p.addView(v,q);}
    private ImageView goLiveImage(){return featureImage(R.drawable.feature_go_live_selected,"GO LIVE","go_live");}
    private ImageView featureImage(int res,String desc,String key){ImageView v=new ImageView(this); v.setImageResource(res); v.setScaleType(ImageView.ScaleType.CENTER_CROP); v.setBackground(round(Color.WHITE,0xFFE1E4EB,dp(14))); v.setClipToOutline(true); v.setContentDescription(desc); v.setOnClickListener(x->openFeature(desc,key)); return v;}
    private ImageView banner(int res){ImageView v=new ImageView(this); v.setImageResource(res); v.setScaleType(ImageView.ScaleType.CENTER_CROP); v.setBackground(round(Color.WHITE,0xFFE1E4EB,dp(14))); v.setClipToOutline(true); return v;}
    private Button navButton(String s,int c){return plainButton(s,c,11);}
    private Button plainButton(String s,int c,float size){Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setTextColor(c); b.setTextSize(size); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setBackground(round(Color.WHITE,0xFFE0E3EB,dp(14))); return b;}
    private TextView card(String s,int bg,int fg,float size){TextView v=text(s,fg,size,true); v.setGravity(Gravity.CENTER); v.setBackground(round(bg,0xFFE1E4EB,dp(14))); return v;}
    private TextView pill(String s,int bg,int fg){TextView v=text(s,fg,11,true); v.setGravity(Gravity.CENTER); v.setBackground(round(bg,bg,dp(22))); return v;}
    private TextView text(String s,int c,float size,boolean bold){TextView v=new TextView(this); v.setText(s); v.setTextColor(c); v.setTextSize(size); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;}
    private View space(int w,int h){return new View(this);}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable(); g.setColor(fill); g.setCornerRadius(radius); g.setStroke(dp(1),stroke); return g;}
    private void startCarousel(){handler.postDelayed(new Runnable(){public void run(){bannerIndex=(bannerIndex+1)%MAX; banners[0].setImageResource(left[bannerIndex]); banners[1].setImageResource(right[bannerIndex]); banners[2].setImageResource(wide[bannerIndex]); handler.postDelayed(this,SLIDE_MS);}},SLIDE_MS);}
    private void openFeature(String title,String key){Intent i=new Intent(this,FeatureActivity.class); i.putExtra("title",title); i.putExtra("feature_key",key); startActivity(i);}
    private void chooseProfilePhoto(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); startActivityForResult(i,PICK_PROFILE);}
    private void loadProfilePhoto(){String u=getSharedPreferences("myshop_profile",MODE_PRIVATE).getString("photo_uri",""); if(!u.isEmpty())try{avatar.setImageURI(Uri.parse(u));}catch(Throwable ignored){}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data); if(request==PICK_PROFILE&&result==RESULT_OK&&data!=null&&data.getData()!=null){Uri u=data.getData(); try{getContentResolver().takePersistableUriPermission(u,data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION));}catch(Throwable ignored){} getSharedPreferences("myshop_profile",MODE_PRIVATE).edit().putString("photo_uri",u.toString()).apply(); if(avatar!=null)avatar.setImageURI(u); Toast.makeText(this,"Profile photo updated.",Toast.LENGTH_SHORT).show();}}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null); super.onDestroy();}
    private View buildSafeHome(){LinearLayout r=column(); r.setGravity(Gravity.CENTER); r.setBackgroundColor(BG); TextView t=text("MY SHOP\nHome Dashboard",PURPLE,25,true); t.setGravity(Gravity.CENTER); r.addView(t,lp(-1,-2)); Button retry=plainButton("OPEN DASHBOARD",BLUE,15); retry.setOnClickListener(v->recreate()); r.addView(retry,lp(-1,dp(64))); return r;}
}
