package com.myshop.app;

/** Central admin identity matching. Passwords remain outside the APK. */
public final class AdminIdentifiers {
    private AdminIdentifiers() {}

    public static boolean isAdminIdentifier(String value) {
        if (value == null) return false;
        String v = value.trim().toLowerCase(java.util.Locale.US);
        String digits = v.replaceAll("[^0-9]", "");
        if (v.equals("myshopsatkania@gmail.com") || v.equals("touhidsatkania@gmail.com")) return true;
        // Accept the configured Bangladesh mobile in common forms: 018..., +88018..., 88018...
        return digits.equals("01860626700") || digits.equals("8801860626700");
    }

    public static boolean isAdminUserId(String userId) {
        return "0001".equals(userId) || "0002".equals(userId) || "0003".equals(userId);
    }

    public static boolean isAdminAccount(AccountStore.Account account) {
        if (account == null) return false;
        return isAdminUserId(account.userId)
                || isAdminIdentifier(account.email)
                || isAdminIdentifier(account.mobile);
    }
}
