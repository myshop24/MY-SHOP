package com.myshop.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** Functional local feature destinations instead of placeholder-only screens. */
public class FeatureActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String title = getIntent().getStringExtra("title");
        String key = getIntent().getStringExtra("feature_key");
        if (title == null || title.trim().isEmpty()) title = "MY SHOP";
        if (key == null) key = "";

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 34, 28, 24);
        root.setBackgroundColor(getColor(R.color.myshop_bg));

        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextSize(26);
        heading.setTextColor(getColor(R.color.myshop_dark));
        heading.setGravity(Gravity.CENTER);
        root.addView(heading, new LinearLayout.LayoutParams(-1, 90));

        TextView status = new TextView(this);
        status.setText(messageFor(key));
        status.setTextSize(17);
        status.setTextColor(getColor(R.color.text_muted));
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, 0, 1));

        Button action = new Button(this);
        action.setText(actionText(key));
        action.setOnClickListener(v -> performAction(key));
        root.addView(action, new LinearLayout.LayoutParams(-1, 58));

        Button back = new Button(this);
        back.setText("Back to Dashboard");
        back.setOnClickListener(v -> finish());
        root.addView(back, new LinearLayout.LayoutParams(-1, 58));
        setContentView(root);
    }

    private String messageFor(String key) {
        if ("my_shop".equals(key)) return "MY SHOP store\nBrowse products and shopping links.";
        if ("gallery".equals(key)) return "Gallery\nPhotos, audio and video can be opened from this module.";
        if ("live_tv".equals(key)) return "LIVE TV\nYour TV links can be configured by Admin.";
        if ("external_movie".equals(key)) return "External Movie\nExternal movie/video links can be opened safely.";
        if ("social_media".equals(key)) return "Social\nSocial links are controlled from Admin settings.";
        if ("share".equals(key)) return "Share MY SHOP\nUse Android sharing to send the app/content link.";
        if ("earn_reward".equals(key)) return "Earn & Reward\nReward area is ready for local navigation.";
        if ("my_feed".equals(key)) return "My Feed\nYour feed destination is ready.";
        if ("go_live".equals(key)) return "GO LIVE\nLive creation entry is ready.";
        if ("chat".equals(key)) return "Chat\nChat destination is ready.";
        if ("live_room".equals(key)) return "LIVE ROOM\nThis live room is ready to open.";
        if ("breaking_news".equals(key)) return "Breaking News\nAdmin-controlled headline is shown on the Dashboard.";
        return "MY SHOP feature is ready.";
    }

    private String actionText(String key) {
        if ("share".equals(key)) return "SHARE NOW";
        if ("gallery".equals(key)) return "OPEN DEVICE GALLERY";
        if ("my_shop".equals(key)) return "OPEN SHOP LINK";
        return "OPEN MODULE";
    }

    private void performAction(String key) {
        if ("share".equals(key)) {
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,"MY SHOP"); startActivity(Intent.createChooser(i,"Share MY SHOP")); return;
        }
        if ("gallery".equals(key)) {
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); startActivity(i); return;
        }
        String url=getIntent().getStringExtra("url");
        if (FeatureRegistry.isSafeHttpUrl(url)) { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url.trim()))); } catch(Exception e){ Toast.makeText(this,"Unable to open link.",Toast.LENGTH_SHORT).show(); } }
        else Toast.makeText(this,"Module opened successfully.",Toast.LENGTH_SHORT).show();
    }
}
