# V626 — অসম্পূর্ণ চেকপয়েন্ট, এখন main-এ আপলোড নয়
এই ZIP-এ APK নেই। এখনও1–10সব সম্পূর্ণ নয়; handoff পড়ুন।
বর্তমান myshop24/MY-SHOP main pipeline ZIP push-এ production Worker deploy করে; এই checkpoint সেখানে দেবেন না।
আগে বাকি ID migration, reference/device QA, generated normal_gold.gif যাচাই সমাধান করুন।
এরপর আলাদা build-only checkout-এ embedded .github/workflows/my-shop-apk.yml ব্যবহার করুন; original signing ও Firebase Secrets নিরাপদভাবে দিন।
সফল হলে Actions-এর MY-SHOP-V-626-APK artifact থেকে একমাত্র MY_SHOP_FINAL_RELEASE.apk পাওয়া যাবে। কেবল এই exact-run-এর APK ও source/version/certificate যাচাই করে গ্রহণ করুন।
