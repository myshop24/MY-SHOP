# MY SHOP V-504 — Build Fix

- Fixed missing Android view imports used by PhysicalStoreActivity and LiveHomeActivity.
- Restored the LiveHomeActivity RED color constant used by the no-live state.
- Kept GeneralUsersActivity Bitmap/BitmapFactory imports explicit.
- Advanced release identity to V-504 / 2.9.504 / versionCode 504.
- Kept the V-503 feature set and backend structure intact.
- No APK/ZIP is included inside the source package.

Build limitation: Android SDK/Gradle is not installed in this workspace, so final Android compilation remains authoritative in GitHub Actions.
