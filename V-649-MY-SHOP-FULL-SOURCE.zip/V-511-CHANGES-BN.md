# MY SHOP V-511 — Reference UI + backend scheduling correction pass

Base: V-510 complete editable source.

## User-side reference corrections
- Home reference 130300 aligned: shared header, breaking strip, five-item top menu, 6-slide banner carousel, My Feed composer, icon-only post actions, and red broadcast Live bottom icon.
- Removed the Home Feed placeholder/status block that created the large blank gap below the feed composer.
- Removed the Quick Links "See All" affordance from the locked Home layout; the current Home reference flow is header → top menu → banner → My Feed → posts.
- Feed action row is only Like → Comment → Share → •••; no inline text counts/Flag/Trash controls.
- General reference 130304 implemented as a real backend-driven two-column member grid with search/refresh, NEW badge, vote, Add Friend/Requested/Friends and Profile actions.
- History reference 130305 implemented as a backend/local activity history surface with clear action and visit/watch actions.
- Live reference 130334 aligned with shared header, large Membership/Games/Earn top menu, six-item Live navigation, live cards, and no-live state.
- Live Page bottom navigation keeps the same red broadcast icon and uses the label "Go Live"; it opens the real live-room host flow.
- No Live 130328: large broadcast icon + "No Live is running now" + explanatory text + gradient Go Live button with a real camera icon.

## Admin / backend corrections
- Live Streaming banner admin remains capped at 6 slots and now supports Gallery image, caption, link, Enable/Disable, Save/Publish, Delete, and start/end schedule timestamps.
- Banner upload now actually sends startAt/endAt fields to the backend; public Live banner delivery filters by active schedule window.
- MY SHOP Official Message supports backend color_hex + scheduled_at + status, while the Official identity remains RED.
- Official messages scheduled for the future are not pushed immediately; the Worker scheduled handler delivers due messages.
- Cloudflare Worker cron trigger added every 5 minutes for scheduled Official Message delivery.
- Admin Official Message UI includes direct visual Color Picker and schedule fields; no HEX typing is required for color selection.
- Active configuration version markers updated to V-511 / 2.9.511 where consumed by the running app/backend.

## Release identity
- Android: V-511 / 2.9.511 / versionCode 511.
- Worker: V-511 / 2.9.511.

## Verification completed locally
- `node --check backend/worker/src/index.js` — PASS.
- `python3 -m py_compile tools_verify_master.py` — PASS.
- All Android resource XML files parse — PASS (0 XML errors).
- QuickLinkLayout test — PASS (201 catalog sizes).
- Existing Worker premium behavior suite — PASS (23/23).
- Active-source stale V-510/2.9.510 and old 2.9.102 identity scan — PASS (0 hits in active app/backend/tools config).

## Not yet called complete
- Android APK compile/sign/install/device runtime and production D1/R2 verification remain GitHub Actions / device verification steps.
- V-511 is therefore an implementation source package, not a falsely declared final APK release.

## Build-failure correction pass
- Replaced feed action vector XML resources with stable drawable-nodpi PNG resources so `R.drawable.feed_action_*` symbols are generated consistently on the GitHub Android build runner.
- Corrected LiveListActivity to use the Android framework `android.R.drawable.sym_def_app_icon` rather than an app resource that does not exist.
- Added `verifyMyShopResourceReferences` preBuild guard to catch missing app resource references before Java compilation.
- Added `FUTURE-FEATURE-ROADMAP-BN.md` with placement and architecture notes for the approved future feature roadmap.
