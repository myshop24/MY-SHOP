# MY SHOP V-570 / 2.9.570

Status: source changes and local regression checks completed; full Android build, signing and device acceptance are NOT verified. Do not represent this archive as a tested APK.

## Changes implemented
1. Admin catalog: white cards, black labels, clean colorful folder icons, four columns, initial twelve folders with additional real modules appended, saved drag ordering, real red request counts. Catalog/Admin routes retain role and AdminGate checks. Existing Blue Badge and history routes repaired; catalog exposes existing AdminHub modules.
2. Main Home support uses editable WhatsApp link. Other support surfaces retain agent Help Center. Default link remains the previously configured number; owner must confirm it in Menu Design > Home support before release.
3. Header has white En text beside the moon. Main and shared navigation use a gold trolley with blue handle, gold my label; central Live control sizing preserved.
4. Shared image loading: bounded background work, request deduplication, memory/disk caches, stale-view protection and video-thumbnail cache. No device speed measurements are claimed. Mini-ad view events no longer repeatedly send per carousel cycle in one session.
5. Withdrawal form shows bKash/Nagad/Rocket logos sourced from the supplied screenshot, plus admin-uploadable Bangla QR image. Logos are limited by supplied image resolution. QR is display/enlarge functionality, not automatic payment confirmation. Creator-earned eligibility and payout protections remain.
6. Main Quick Links/General, Live Discover and Shop use consistent premium art. Per-menu design editor provides twenty presets, custom color wheel, preview and persisted server settings. Consumer-menu defaults use the first dark-purple reference; Shop defaults pale blue. Admin catalog retains the final approved white design.
7. Mini ads retain twenty styles, custom color, image/text, independent animation/flash, validity dates and configured display duration. Shared saved content can be assigned to selected pages without copying edits. Preview size respects smaller screens.
8. Moving headline has separate configuration from Breaking News, per-layer colors, size, pause and draggable x/y preview placement; actual overlay enters from right and exits left. Shared content placement and lifecycle pause/resume added.
9. Feed online indicators use bounded batched presence reads and server privacy/freshness rules. Existing optimistic like-count behavior and server authoritative counts retained.
10. Feed video opens immersive fullscreen with controls, back/close and retained position. Aspect ratio uses native VideoView behavior; device validation pending.
11. Removed 55 proven unreferenced raster assets (2,638,202 bytes). Exact paths and hashes in verification/v570-asset-cleanup.json; original baseline archive retained outside this release. Logo/launcher assets preserved.
12. Small-screen adjustments, contrast fixes, lifecycle cleanup and the previous two lambda-capture compiler regressions checked.

## Evidence and limits
- verification/v570-checks.json: broad run, 26 of 27 command groups passed. One older V438 push test expects a data-only payload and fails identically on untouched V569; do not silently remove or claim it passed.
- verification/v570-final-checks.json: final focused tests on modified source, including real local HTTP cache deduplication/stale-result tests, Worker SQLite behavior, locked function preservation and both Java17 compiler regression tests.
- 178 production Java sources parse successfully. This is syntax parsing, NOT Android type checking.
- Whole MiniHeadlineOverlay and MiniAd save lambda compile under Java17 test doubles; these do NOT substitute for Android SDK compilation.
- Local Gradle build blocked: no Android SDK or cached Gradle; wrapper download failed with Network is unreachable. No signed APK was produced here, no phone/emulator tests, no production Worker/D1 deployment.

## Remaining acceptance / incomplete scope
- Run actual release compile, Android lint/unit tests, verify the original signing certificate and install on small and normal phones before calling this finished.
- Check every catalog route with an authorized account, notification counts after a real request, background changes, image loading/offline behavior and video fullscreen on a phone.
- Dedicated seller-management, physical return and refund workflows do not exist in this baseline. Their current catalog entries lead to existing product/order management; those specialized workflows are NOT newly implemented.
- Mini-headline preview supports selecting and positioning one layer; preview playback of all animated layers is not implemented. Actual overlay motion exists.
- Additional expiry-reminder workflows and unspecified older ideas absent from the available conversation are not claimed complete.
- Measure Cloudflare D1 usage after release. Cache changes reduce repeated image work, but no quota outcome or production performance guarantee is asserted.

## Deployment identity
Use V-570-MY-SHOP-SOURCE.zip with the existing permanent release pipeline. Preserve original signing key, package com.myshop.app, Cloudflare bindings and secrets. New migrations: 0056_v570_panel_designs.sql and 0057_v570_overlay_placements.sql. The existing permanent pipeline deploys Worker before APK compilation; a failed APK job does not roll back that backend deploy. The included tools/ci-apk-build.sh is a build-only gate and now includes V570 tests.
