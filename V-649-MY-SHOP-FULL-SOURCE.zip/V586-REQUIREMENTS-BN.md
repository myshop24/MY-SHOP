# MY SHOP V-586 — অনুমোদিত কাজ ও সর্বশেষ সংশোধন

১. ছবির রেফারেন্স মেনে Home avatar → Side Menu → নিজের পূর্ণ Profile। সাধারণ user-এর Admin folder/control লুকানো এবং server permission enforced। নিজস্ব profile menu আলাদা।
২. নিচের Home/myshop/Support/More Apps নাম ও icon নিচে; Live-এর অবস্থান অপরিবর্তিত।
৩. Navy/purple My Wallet ও withdrawal navigation। সর্বশেষ মালিকের নির্দেশ: demo-র ৩,০০০ বা অন্য নতুন preset বসানো যাবে না। V-585-এর server-controlled withdrawal amount catalog, commission/conversion/quote calculation এবং Admin amount edit বজায় থাকবে। Purchased balance ও eligible earned balance আলাদা।
৪. Master Admin controls ১–১০৪ entity অনুযায়ী প্রযোজ্য; বাস্তব CRUD/Coming Soon/permission/history দরকার, শুধু button নয়।
৫. Owner-only text color/gradient/selected part size এবং পুনর্ব্যবহারযোগ্য color wheel।

প্রোফাইল আবার image reference দিয়ে যাচাই করতে হবে। Source checks কখনো device visual QA বা APK build-এর বিকল্প হিসেবে দাবি করা যাবে না। প্রতিটি চূড়ান্ত delivery পূর্ণ project ZIP এবং নতুন version হতে হবে।
