# V-563 approved scope — 2026-10-04
Base complete V562, unchanged delivery. Only discussed scope; icons/seats locked. 32/33 excluded. All source changes version563; one complete ZIP with original encrypted signing and workflows.
1 wallet route 2 shop route 3 membership route 4 photos rendering 5 videos rendering 6 timeline rendering 7 real profile tabs 8 gallery preview/open 9 follow nonself
10 cumulative lifetime host Top20 visible all, gifts persist across lives, ranks update; Coin and Gold separate. User selected legacy Star ranking (100000Coin =1000Gold) independently of new level thresholds. Top3 badges in live.
11 viewer line priority Top1/2/3 thenKING/QUEEN/ROYAL/VVIP/VIP thenothers, present only no gaps
12 Coin10%,Gold5% commission paid extra by sender,1000Coin debit1100 credit1000; official spend exemption, no separate VAT
13 recipient level normal100000Coin=1,100000Gold=2; gifts/transfers receipt; withdrawals nolevel
14 official purchase doublelevel, officialspent nofee, purchased nonwithdrawable
15 admins0001/0002/0003 permanentlyLV0Authority
16 withdrawal per-folder admin notices, pendinghold approve/paid/reference reject/release; payout conversion rate remains configured, no invented rate
17 Coin[5,10,15,20,25,30,40,50]lakh Gold[3,5,10,15,20,25,30,40,50]lakh
18 option05 typography UPCOMINGcyan LIVEred; onlyLIVE sequential L I V E subtle rise, no blur or whiteoutline
19 EN visible commonheader
20 presence greenonline dot clearlastactive respectingprivacy
21 cleanmessenger whitesurface purpleown graypeer
22 miniads 4scopes live_room/home/live/shop independent20cards,colorpalettenocodes,dwell1..5,image/text/link enable/delete/order close×; do not cover lockedcontrols
23 adminpreview dragdrop normalizedxy slidefromright
24 scheduledads25views/clicks26dismisscooldown27restore28exactchargepreview29ownrank30adminaudit34pinchat35reply36withdrawprogress37linkpreview38adminIDsearch
Working rules: runtimevoice/headset unverified, nofalse100%; reference mockups do not authorize seat changes. cashout rates must show configured values. Backenddeploy necessary.

2026-10-04 user correction: three main-admin IDs show a blue verified badge, no LV.0 or any LV text. Server levels remain zero, UI shows Authority.

2026-10-04 admin can grant/revoke blue verification by user ID. This never gives admin authority or level exemption; fixed three admins retain permanent blue badge. Server authorization and audit required.

Final badge placement: immediately after the user name, never beside ID or Level. Main 3 Authority accounts hide all public level labels. Granted user badges preserve normal level.

Owner override 2026-10-04 09:03–09:20 Asia/Riyadh: REMOVE room ad collision/overlap suppression. Admin freely drags the preview; show mini-card at that saved normalized position. Never auto-move or hide it because it overlaps another element. Keep all existing seats/icons unchanged underneath. Blue badge must have an explicit Admin panel entry for granting/revoking by ID.
