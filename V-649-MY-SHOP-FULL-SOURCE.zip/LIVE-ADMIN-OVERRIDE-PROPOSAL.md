# Owner-approved main-admin unblock / unmute

Owner approved this exact scope on 2026-10-09 after the microphone behavior was explained. The source implementation and target SQLite tests are now present. No deployment or device acceptance has occurred.

The red Main User Control panel will show the selected host, target user, existing block/mute and original actor. Only currently active ADMIN accounts 0001/0002/0003 can remove that specific restriction. The action requires a reason, confirmation and a current-record check, with permanent audit in the same database transaction. A repeated request must not apply twice; stale records require refresh.

Unmute removes the host-imposed mute record/sanction and the occupied seat's forced-mute flag. It does **not** turn the user's microphone on automatically. The user retains their own microphone choice. After commit, the existing room refresh signal updates participants. No rejoin is required. Unblock removes only the selected host-to-target restriction; unrelated blocks and account bans remain.

Existing `liveUnmuteSavedUser` also writes `mic_on=1`; this proposed main-admin path must not reuse that behavior blindly. RTC capture, audio processing, room layout, gifts, comments and existing host/room-admin actions are outside this change.

Required verification: authorization/revocation, stale-action conflict, double-click idempotency, atomic audit rollback, record targeting, self-mic preservation, immediate room refresh, host/guest device regression.

Owner approval is satisfied for this scoped override. It does not authorize unrelated RTC/audio, Live layout or identity-contract changes.
