# MY SHOP V-563 — complete source handoff

## Completed
Profile wallet/shop/membership routes, gallery layout and profile tabs; EN header; clearer online presence and chat, pin/reply/link preview; sharp UPCOMING cyan / LIVE red sequential letters. Lifetime host Top20 across sessions, Top3 indicators and viewer priority. Coin 10% / Gold 5% extra sender commission, full recipient credit, official-spend exemption; recipient level rules and selected withdrawal presets. Existing withdrawal approval/payment flow retained. Blue badge after names, authority levels hidden, separate Admin panel badge manager. Four independent mini-ad folders, 20 cards, palette, schedules, duration, metrics, restore and freely dragged normalized placement.

## Last checkpoint
V-562 was the complete base. V-563 source identity, Android versionCode 563, versionName 2.9.563 and backend identity updated. Additive migration: backend/worker/migrations/0052_v563_mini_ads_verification.sql. Seats, microphone controls and room icon geometry preserved. Original encrypted signing files and workflow preserved.

## Validation
Android assembleRelease, testDebugUnitTest and lintRelease passed. tools/v563_verify.sh passed: 36 V561/V563 behavior groups and 336 locked named Worker functions unchanged, plus inherited checks. Fresh progress initialization prevents legacy receipt backfill from counting a new gift twice. These are automated source/build checks, not physical-device audio tests.

## Pending / known limits / next developer tasks
Deploy the matching Worker and database migration using the existing deployment configuration. Run the existing GitHub APK workflow with its original signing secrets; local APK is unsigned and is not supplied as a signed APK. Verify real-device voice, wired headphones, Bluetooth, reconnect, push notifications, presence, payment processing and screen sizes. Existing configured cash-out rate is retained; no cash rate invented. Production signing/deployment and actual financial settlement have not been performed in this session. Review live room reference screenshots before any further room changes. Do not alter unrelated features or seats/icons.

## Delivery and future versions
Use only V-563-MY-SHOP-SOURCE.zip: it includes all project source and assets, backend, migrations, tests, workflows and original encrypted signing material. Generated builds/caches/local toolchain paths are excluded. No earlier archive required. Upload to the existing repository using the existing root .github/workflows/my-shop-apk.yml. A workflow inside a ZIP does not install a GitHub root workflow automatically. Every later delivery requires a new version number and a complete archive.
