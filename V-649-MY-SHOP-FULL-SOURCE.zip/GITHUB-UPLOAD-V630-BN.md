# V630 — আগের মতো GitHub APK ফুল প্যাকেজ

1. V-630-MY-SHOP-FULL-SOURCE.zip না খুলে আগের MY-SHOP repository-র main/root-এ Upload files দিয়ে upload ও commit করুন।
2. আগের স্থায়ী .github/workflows/my-shop-apk.yml এবং my-shop-release.sh অক্ষত রাখুন। নতুন workflow বসাতে বা ZIP extract করতে হবে না। ZIP-এর ভেতরের build-only workflow ঐচ্ছিক পরীক্ষার উপকরণ; স্থায়ী workflow দিয়ে সেটি বদলাবেন না।
3. Actions → MY SHOP PERMANENT RELEASE PIPELINE → এই upload-এর run। Job: WORKER VERIFY -> APK। Pages build and deployment আলাদা website run।
4. সফল হলে Artifacts → MY-SHOP-FINAL-V-630 → extract → MY_SHOP_FINAL_RELEASE.apk। Upload commit, SOURCE_VERSION V-630, versionCode630/versionName2.9.630, original signature/hash মিলিয়ে নিন।
5. Original signing/Firebase/Cloudflare secrets ও cache আগের মতোই। স্থায়ী pipeline matching Worker deploy/verify করে signed APK বানায়। এই কাজের সময় production deploy বা GitHub run চালানো হয়নি।

V629-এর app কাজ অক্ষত; V630-এ প্রকৃত Android/Worker version markers ও নির্দেশনা আপডেট। শুধু ZIP rename নয়। স্থানীয় APK তৈরি হয়নি; আগের Gradle download network বাধা ও device/production test-এর সীমা বহাল।
