# V629 — অনুমোদিত কাজ ও যাচাই

ভিত্তি: সরবরাহ করা V628 ফুল সোর্স; পুরোনো deliverable অপরিবর্তিত। নতুন versionCode 629, versionName 2.9.629।

1. সাদা Home header, মোটা নীল Myshop, প্রথম M বড়; পুরোনো MS avatar ও actions।
2. নিচের চারটি side icon নতুন native design; মাঝের Live অপরিবর্তিত, Home underline নেই। বিদ্যমান Admin visual-design customization অক্ষত।
3. Theme Management-এ Pure White-সহ ছয় নির্বাচিত রং; পুরোনো preset রেখে পাঁচটি যোগ, মোট 36 light ও 30 dark।
4. Admin wallpaper upload চলাকালে Publish বন্ধ, পুরোনো preview response উপেক্ষা, প্রকাশিত default নির্বাচন।
5. My Items-এ owned theme ও expiry অক্ষত; default-এ ফেরার সুযোগ, ব্যর্থ load-এ আগের items থাকে ও retry।
6. Live শুরুর আগে owned/default theme নির্বাচন ও preview; session-এ নির্বাচিত theme snapshot, পরবর্তী My Items পরিবর্তন পরের Live-এ।
7. Theme/Frame/Bubble/Membership per-user ownership অক্ষত; Rare ID uniqueness অপরিবর্তিত। অন্য ব্যবহারকারীর theme ব্যবহার প্রত্যাখ্যান।
8. Main Guest ছোট করে পুরোনো আটটি seat ওপরে; নতুন তৃতীয় সারি যোগ নয়, অন্য Live controls রাখা।
9. Compact avatar/animated level/name/comment layout; decorative bubble 9-slice ও text wrap, bounded image cache।
10. Live mini profile-এ public identity, এই Live-এ পাওয়া gifts ও followers; নিজস্ব wallet প্রকাশ নয়। সাধারণ user ও Host/Admin permission অনুযায়ী actions; remove/block confirmation।
11. Store-এ দামহীন/deleted product Enable প্রত্যাখ্যান; state+audit atomic, unsold Rare edit আগের নিরাপত্তা বজায়।
12. Inbox/Chat রং ও group spacing, group শেষে সময়, অপরিবর্তিত response-এ পুরো list rebuild নয়; পুরোনো media/voice/actions রাখা।
13. Badge reconciliation ও read retry/account isolation; আগের push বজায়। সমর্থিত launcher-এ existing per-event count ব্যবহৃত, একই event-এর দ্বিগুণ cumulative count নয়।
14. Report+Admin bell notification atomic; Admin-only Safety queue ও direct link; push ব্যর্থ হলে durable retry, report duplicate nonce সুরক্ষা। রিপোর্টে automatic ban নয়।
15. নতুন ব্যক্তিগত preference/receipt deletion cleanup; পুরোনো অর্থ, কমিশন, signing ও পরিচয় অক্ষত।
16. V629 target gate, regression, source inventory ও GitHub build-only workflowসহ পুরো source package।

## সীমা

এগুলো source/SQLite/Java-double পরীক্ষিত পরিবর্তন। ফোনে final visual match, animation smoothness, সত্যিকারের RTC/audio, launcher লাল সংখ্যার badge, production D1/R2/FCM এবং signed APK এই পরিবেশে যাচাই হয়নি। Gradle 8.11.1 download Network is unreachable হওয়ায় full Android compile হয়নি। কোনো APK/production deploy দাবি করা হচ্ছে না।

বিদ্যমান Firebase project ও MYSHOP_FIREBASE_* configuration রাখুন। নতুন Firebase project প্রয়োজন নেই; প্রকৃত FCM credentials/channel permission/ফোনের launcher settings দিয়ে device test আবশ্যক। সব Android launcher-এ লাল numeric badge জোর করে দেখানো যায় না।

## প্যাকেজের সীমিত পরিষ্কার

শুধু verification/historical-logs.tar.gz (পুরোনো 37টি non-build verification log-এর archive) নতুন ZIP থেকে বাদ; সেটি V628 মূল deliverable-এ অপরিবর্তিত সংরক্ষিত। কোনো app/backend source, runtime asset বা generation input বাদ নয়। পুরোনো history files-এর দাবি বর্তমান build success নয়। Browser upload-এর 25,000,000-byte সীমার জন্য এই ইতিহাসের পুনরাবৃত্তি বাদ।
