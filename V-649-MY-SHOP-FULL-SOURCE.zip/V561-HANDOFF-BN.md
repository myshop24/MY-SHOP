# MY SHOP V-561 — কাজ ও বিল্ড নির্দেশনা

V-560-এর পূর্ণ সোর্স থেকে V-561; Android versionCode 561, versionName 2.9.561।

## কী হয়েছে
1. হোম ও লাইভ Upcoming Live-এর আলাদা ২০-স্লট এডমিন ফোল্ডার; পুরোনো ডেটা না মুছে প্রথমবার দুটিতে কপি।
2. আইডি খুঁজে নাম, ছবি ও পরিচয় আনা; হাতে সম্পাদনা, ছবি crop, রঙ নির্বাচন, সিরিয়াল, প্রকাশ/বন্ধ ও সময় নির্বাচন আগের মতো।
3. ছবি চাপলে সত্যিকারের প্রোফাইল; existing Friend / Follow / Message।
4. ঘড়ি/পাশের signal সরানো; সামান্য বাঁকা mixed-color Upcoming ও সীমার মধ্যে glow; ঘণ্টা-মিনিট লাল, সেকেন্ড সবুজ; গোল সাদা timer অপরিবর্তিত।
5. ঘণ্টার reminder বন্ধে gold/orange, সংরক্ষণ সফল হলে green; দ্বিতীয় চাপে বন্ধ। ডিফল্ট পাঁচ মিনিট আগে; সময় বদলালে নতুন notice; অ্যাকাউন্ট/event/page অনুযায়ী আলাদা।
6. সত্যিকারের fresh Live session থাকলেই JOIN LIVE; শুধু countdown শেষ হলে নয়। সাধারণ ইউজারের মাঝখানে চাপে আগামী সাত দিনের সেই পেইজের schedule।
7. Super Admin-এ রঙিন দুই-কলামের কার্ড; Coin ও Gold-এর সত্যিকারের বিদ্যমান হিসাব।
8. হোম bell, admin catalog ও request folder-এ একই event-এর read state; প্রত্যেক premium item type-এর নিজস্ব notification filter/count। নতুন view কোনো approval/payment করে না।

## গিটহাবে আপলোড
আগের মতো repository root-এ সম্পূর্ণ `V-561-MY-SHOP-SOURCE.zip` আপলোড করুন; পুরোনো কাজের workflow ও signing secrets মুছবেন না। Actions-এ সর্বশেষ V-561 run দেখুন। আপনার স্থাপিত permanent pipeline-ই ZIP খুলে matching Worker / APK build করবে। এই ZIP-এর ভিতরের workflow নিজে থেকে repository root-এর workflow বদলাবে না।

নতুন repository-তে ব্যবহার করলে extracted source-এর `.github/workflows/my-shop-apk.yml` ও release scripts ঠিকমতো root-এ স্থাপন এবং original signing / Firebase / deployment secrets provision করতে হবে। দেওয়া workflow-তে ZIP push-এর build/QA job এবং আলাদা gated production release আছে। QA debug APK-কে মূল অ্যাপের update হিসেবে ব্যবহার করবেন না।

## সার্ভার ও সাইনিং
V561 client-এর সঙ্গে matching `backend/worker` deploy করা দরকার; নতুন additive SQL `backend/worker/migrations/0051_v561_upcoming_scopes_and_notice_reads.sql` এবং runtime guards দেওয়া আছে। D1/R2 binding বদলানো হয়নি। V560 server-এর response পেলে নতুন editor shared legacy data সম্পাদনা করবে না।

মূল `myshop-release.jks.enc` byte-identical রাখা হয়েছে। এই পরিবেশে original decryption recipe/password, alias ও key passwords নেই। কাজেই local release compile unsigned; সেটি ব্যবহারকারীর APK হিসেবে দেওয়া হয়নি। GitHub-এর বিদ্যমান original-key signing ব্যবস্থা রাখুন। `tools/restore-signing.sh`-এ original encryption parameters লাগে; অনুমান বা নতুন key তৈরি নয়। `my-shop-release.sh` original V559 certificate যাচাই করে।

## পরীক্ষা এবং সীমা
Final evidence: `verification/v561-results.json`, preservation report, Android/backend logs, native UI preview ও tests। পূর্ণ local build/SQLite/native rendering পরীক্ষা production D1/RTC/ফোনে push আসার প্রমাণ নয়। Actual device, screen-lock/background push, two-account follow/chat navigation ও production deployment এখনো যাচাই করা হয়নি।

আইডিয়ার আলোচনায় থাকা কিন্তু স্পষ্ট implementation scope না পাওয়া নতুন ফিচার যোগ করা হয়নি। Product/e-commerce-এর নতুন কাজ, Live recording, স্থানীয় ঘড়ি ও বাদ দেওয়া আইডিয়াগুলো করা হয়নি। বিদ্যমান কাজের সীমার বাইরে পাওয়া routing/legacy আচরণ পরিবর্তন করা হয়নি।

## পুনরায় পরীক্ষা
Java 17, Gradle 8.11.1, Android SDK 36 ও CI-এর Firebase configuration লাগবে।
`bash tools/v561_verify.sh`
`gradle clean :app:assembleRelease :app:testDebugUnitTest :app:lintRelease -PrequirePush`

লাস্ট ZIP-ই পরবর্তী কাজের পূর্ণ base। পরের delivered version হবে V-562 অথবা সর্বশেষ owner-supplied version-এর পরবর্তী অব্যবহৃত নম্বর।

## আগে থেকে থাকা একটি সীমাবদ্ধতা
`EcommerceAdminActivity`-এর পুরোনো Product / Inventory / Seller / Return / Reports ইত্যাদি কার্ড একই `AdminStoreActivity` route ব্যবহার করে; শুধু request কার্ডে `requests_mode` দেওয়া হয়। এগুলো পূর্ণ পৃথক e-commerce workflow হিসেবে সম্পূর্ণ নয়। এই আপডেটে নতুন product/e-commerce কাজ স্থগিত এবং অন্য feature locked থাকায় সেই পুরোনো routing পরিবর্তন করা হয়নি। নতুন notification entry নিজস্ব সংশ্লিষ্ট existing inbox-এ যায়।
