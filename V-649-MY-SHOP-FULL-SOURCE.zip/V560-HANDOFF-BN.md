# MY SHOP V-560 — পূর্ণ সোর্স হ্যান্ডঅফ

বেস: মালিকের V559, নতুন versionCode 560 / versionName 2.9.560। এটি পূর্ণ Android project + Worker/backend/SQL + পুরোনো modules/assets/tests + নতুন tests + Gradle wrapper + release scripts + developer নির্দেশনা + মালিকের encrypted signing file। আলাদা V559 থেকে ফাইল জোড়া দিতে হবে না।

## এই সংস্করণের পরিবর্তন

- Gift panel সরাসরি খুলে cache দেখায়; catalog background-এ আসে। শুরুর আলাদা কালো loading modal সরানো হয়েছে। Host একা থাকলেও catalog দেখতে পারেন; Send-এর সময় বৈধ recipient প্রয়োজন। বাস্তব নেটওয়ার্কে ছবি আসার গতি আলাদাভাবে যাচাই করতে হবে।
- Super Admin-এ locker বন্ধ থাকলে অনুমোদিত unlock flow খুলবে; role/locker পরীক্ষা বজায় আছে।
- Live list compact square ছবি ও নাম/badge/ID/vote/location দিয়ে সাজানো। Live banner-এর পাশের gap app theme নেয়।
- বিজ্ঞাপন folder-এ ২০টি পৃথক serial slot; disabled পুরোনো banner-ও admin editor-এ পাওয়া যায়। অন্য support/commerce slot-এর সংখ্যা বাড়ানো হয়নি।
- Home এবং Live-এ স্বাধীন Upcoming Live row; ২০টি entry, crop/ID/name/identity/target time/background/dwell/enable/order। একই admin folder থেকে নিয়ন্ত্রণ। পুরো row বন্ধ বা খালি হলে View.GONE—ফাঁকা জায়গা থাকবে না। প্রতি entry-র absolute countdown সোয়াইপে রিসেট হয় না।
- System labels ও আগে দেওয়া BN/EN/HI/AR content ভাষা অনুযায়ী নির্বাচন হয়। অতিথির নাম/পরিচয় এবং অনুবাদহীন custom content-এর স্বয়ংক্রিয় machine translation এই সংস্করণে নেই।

## যাচাই ও কাজের সীমা

স্থানীয় Worker syntax, পূর্বের regression suite, ১৩টি নতুন বাস্তব SQLite আচরণ group, countdown tests এবং Android native/UI tests পাস করেছে। Android release compilation এবং lintRelease পাস করেছে। Lint-এ ১,২১০টি warning আছে; error নেই। পুরোনো Java deprecated/unchecked compiler warning-ও আছে। “সব warning দূর করা হয়েছে” এমন দাবি করা হচ্ছে না।

মূল ৮৬৯টি ফাইলের একটিও বাদ যায়নি। ৮২৩টি byte-identical; ৪৬টিতে প্রয়োজনীয় পরিবর্তন। ১৬টি অন্য Java module-এ lint-এর জন্য সংখ্যার বদলে একই মানের Android constant-এর নাম দেওয়া হয়েছে; token equivalence রিপোর্টে behavior অপরিবর্তিত যাচাই করা হয়েছে। RTC, gift admin, session, commerce module ও Worker bindings byte-identical। রিপোর্ট verification/V560-preservation-audit.json এবং V560-named-constant-preservation.json-এ।

কোনো production Worker deploy, public release অথবা বাস্তব ফোন পরীক্ষা করা হয়নি। আগের নির্দেশনার device-screen/lock-screen notification delivery এখনো UNVERIFIED। Compilation/UI tests বাস্তব ফোনে gift/RTC/push delivery প্রমাণ করে না।

## APK অবস্থা ও প্রয়োজনীয় ব্যবস্থা

Release APK compile হয়েছে, কিন্তু original-key signed canonical V560 APK তৈরি হয়নি। দেওয়া myshop-release.jks.enc-এর confirmed encryption recipe/decryption credential, keystore alias/store/key credentials সরবরাহ করা হয়নি। আলাদা signing key দিয়ে আপডেট বানানো হয়নি। মূল V559 APK-এর signature যাচাই করা হয়েছে; SIGNING-SETUP.md-এ SHA256 আছে। CI secrets/private environment-এ মূল key সেট করে original certificate মিলিয়ে signed build চালাতে হবে। Password chat বা source-এ লিখবেন না।

পুরোনো workflow-এর push থেকে স্বয়ংক্রিয় production প্রকাশ বন্ধ করা হয়েছে। এখন কেবল manual workflow_dispatch; publish_latest_apk=false হলে build/QA, true কেবল মালিকের আলাদা প্রকাশ নির্দেশনার পর। APK প্রকাশ private source repository-তে নয়—পৃথক APK-only repository ও private token প্রয়োজন; SIGNING-SETUP.md দেখুন। এই পরিবর্তন নিজে কোনো প্রকাশ করেনি।

## নতুন ডেভেলপার কীভাবে শুরু করবেন

১. ZIP extract করে এই project directory খুলুন। JDK17, Android SDK36, Gradle8.11.1 ব্যবহার করুন। পূর্ণ Gradle wrapper দেওয়া আছে। Firebase client config আছে; backend/FCM/Cloudflare/signing secrets private environment-এ রাখুন।
২. bash tools/v560_verify.sh চালিয়ে backend/countdown regression যাচাই করুন।
৩. ./gradlew clean :app:testDebugUnitTest :app:assembleRelease :app:lintRelease -PrequirePush চালান। Original key ছাড়া release output unsigned হবে; এটিকে canonical update APK বলা যাবে না।
৪. SIGNING-SETUP.md অনুসারে original key restore/signature check করুন। অনুমোদিত প্রকাশের আগে একই source থেকে signed APK, package/version/signature এবং staging/device tests যাচাই করুন।
৫. Upcoming Live পরিচালনার নির্দেশনা V560-UPCOMING-LIVE-GUIDE-BN.md-এ। নতুন Worker API deploy হলে এই row ব্যবহারের backend প্রস্তুত হবে। নতুন table আলাদা; পুরোনো schema/data অপরিবর্তিত।

চূড়ান্ত clean build-এর source commit, package/version, test result এবং unsigned APK checksum verification/V560-final-validation.json-এ যুক্ত থাকবে। Signed release pending অবস্থাটি বজায় থাকবে।
