# MY SHOP V-446 — বাস্তবায়িত ব্যাচ

## সম্পন্ন

1. স্থায়ী Admin Music Library: Album ও Song আলাদা।
2. Audio R2-তে এবং catalog/order/state D1-এ সংরক্ষণ।
3. Album Add/Edit এবং Song upload/Edit/Publish/Unpublish/Permanent Delete।
4. Admin Hub-এ আলাদা Live Music module।
5. Live bottom dock-এ Mic-এর পরে সমান মাপের Music control।
6. Admin catalog থেকে track নির্বাচন করে Agora audio mixing publish path।
7. Music volume, Pause, Resume ও Stop।
8. Host Follow state backend থেকে restore: `+` থেকে `✓`, re-entry/refresh/reconnect-এ স্থায়ী।
9. V-445-এর Join/Invite/Comment/Gift/RTC behavior অক্ষত রাখা হয়েছে।
10. বাতিল ৮৭ নম্বর Live Duet Mode যোগ করা হয়নি।

## যাচাই

- Worker JavaScript syntax: PASS
- Existing backend regression tests: 91 PASS (25 commerce + 12 payout + 31 V430 + 23 V438)
- Android debug/release Java compilation: PASS
- Android lintVitalRelease: PASS
- assembleRelease: PASS
- Release identity: V-446 / versionCode 446 / versionName 2.9.446

## Production-এর আগে আবশ্যক

- Updated Worker deploy করতে হবে; তা না হলে নতুন Music endpoints পাওয়া যাবে না।
- Production D1/R2 binding দিয়ে Album/Song upload test করতে হবে।
- দুইটি physical Android device দিয়ে Host music + Mic একসঙ্গে শোনা যাচাই করতে হবে।
- Signing secrets ছাড়া local output unsigned; user release হিসেবে unsigned APK দেওয়া যাবে না।

## Pending master scope

এই version-এ সর্বশেষ Music/Follow/premium-control batch বাস্তবায়িত হয়েছে। ৯৯টি কার্যকর master নির্দেশনার যেগুলো V-445-এ আগে থেকেই ছিল সেগুলো রাখা হয়েছে; device/production verification ছাড়া সমগ্র master list-কে runtime-complete বলা হয়নি।
