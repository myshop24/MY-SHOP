# MY SHOP V-517 — পরিবর্তন

- V-516-এর GitHub Actions resource-preflight failure বিশ্লেষণ করা হয়েছে।
- সম্পূর্ণ Android resource tree নিশ্চিত করা হয়েছে।
- Gift v375 drawable ও raw sound assets retained/verified।
- Login/Register, navigation, membership, Live এবং feed resource references verified।
- XML-এর inline `@+id/...` resource scan শক্ত করা হয়েছে।
- V-512-এর পূর্ববর্তী Java compiler fixes retained।
- Release identity: V-517 / 2.9.517 / versionCode 517।
- কোনো APK Source ZIP-এর মধ্যে রাখা হয়নি।

**গুরুত্বপূর্ণ:** GitHub Actions green না হওয়া পর্যন্ত V-517-কে successful APK release বলা যাবে না।
