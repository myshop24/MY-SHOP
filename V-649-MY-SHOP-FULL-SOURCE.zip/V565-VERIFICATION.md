# V-565 Verification

- `node --check backend/worker/src/index.js`: PASS.
- `node --input-type=module --check < backend/worker/src/index.js`: PASS.
- `node tests/v561/worker-behavior.spec.cjs`: PASS, 40 behavior groups. Includes Admin-only row visibility, public hide/show, interval validation, duration moving with reorder, and first-request banner-only schema setup.
- `node tests/v561/preservation.spec.cjs`: PASS, 326 named locked Worker functions preserved.
- `node --test tests/*.test.mjs`: PASS, 7 root Node tests.
- `python3 tests/v565/banner-sections.spec.py`: PASS; existing banner row unchanged, three section defaults enabled, separate interval table defaults to four seconds.
- `python3 tools/v516_preflight.py`: PASS, 166 Java files, R syntax, resource references, compiler-failure contracts.
- Full `tools/v565_verify.sh`: BLOCKED at inherited `tools/v560_verify.sh` because `javac` is not installed.
- `bash gradlew --no-daemon :app:assembleDebug`: BLOCKED; Gradle 8.11.1 was not cached and outbound socket access to `services.gradle.org` is denied. No Android compile/install/device result is claimed.
- No production D1 migration or Worker deployment was run.
