# V-646 GitHub APK build ও যাচাই

এই source ZIP-এ APK নেই। সম্পূর্ণ `.github`-সহ project বা অপরিবর্তিত নতুন ZIP existing repository-এর আলাদা review/build branch-এ দিন। Repository-এর স্থায়ী main workflow দেখে নিন: main-এ ZIP push production Worker deployment চালালে আগে staging যাচাই ও আলাদা production সিদ্ধান্ত প্রয়োজন। Source-এর সঙ্গে থাকা `.github/workflows/my-shop-apk.yml` একটি build-only workflow; এটিতে Worker production deploy নেই। বিদ্যমান production pipeline অনুমান করে প্রতিস্থাপন করবেন না।

## প্রয়োজনীয় setup
- Original signing certificate/package `com.myshop.app` অক্ষত। MYSHOP_KEYSTORE_BASE64 অথবা অন্তর্ভুক্ত encrypted keystore-এর জন্য আগের secure setup। SIGNING-SETUP.md অনুসরণ করুন।
- MYSHOP_KEYSTORE_PASSWORD, MYSHOP_KEY_ALIAS, MYSHOP_KEY_PASSWORD; encrypted route হলে MYSHOP_KEYSTORE_DECRYPT_PASSWORD ও প্রযোজ্য cipher/KDF/iterations। মান repository/source/log-এ নয়, Actions Secrets-এ।
- Existing Firebase MYSHOP_FIREBASE_API_KEY, MYSHOP_FIREBASE_APP_ID, MYSHOP_FIREBASE_PROJECT_ID, MYSHOP_FIREBASE_SENDER_ID অথবা existing valid google-services.json setup। কোনো নতুন secret hardcode নয়।
- Backend-এর existing DB/R2/LIVE_ROOM_HUB bindings এবং Agora configuration অপরিবর্তিত। `npm ci` ব্যবহার করা যায়; pinned lock file অন্তর্ভুক্ত।

## Build
Actions → MY SHOP Android APK → Run workflow → build branch নির্বাচন করুন। Canonical highest-V ZIP extraction source workflow-এ সমর্থিত। Root-source mode-ও সমর্থিত। Workflow চলে `tools/ci-apk-build.sh`: source/asset checks, new V646 source fingerprints, actual SQLite tests, Android unit tests, release/lint এবং original signing যাচাই।

সফল run-এর Artifacts → MY-SHOP-V-646-APK থেকে `MY_SHOP_FINAL_RELEASE.apk` নিন। Artifact না হলে বা signing না মিললে signed APK সম্পন্ন নয়। Original certificate fingerprint, package, versionCode646/versionName2.9.646, commit SHA ও source identity মিলিয়ে নিন। DEX-এ `AnimationAds645Activity`, `AnimationOverlay645`, `AnimationCard645` এবং V-646 build string থাকবে; অবসর দেওয়া MiniAdAdminActivity থাকবে না। App খুলে Admin → Live Management → এনিমেশন বিজ্ঞাপন এবং প্রকৃত গিফট/কয়েন বক্স পরীক্ষা করুন। শুধু সবুজ Build successful যথেষ্ট নয়।

## APK size
Source ZIP25MB-এর নিচে। সংরক্ষিত পুরোনো animation/audio/চার native ABI-এর কারণে পরীক্ষার APK300MB-এর বেশি হতে পারে; প্রয়োজনীয় asset বাদ দেওয়া হয়নি। GitHub artifact দিয়ে এমন বড় APK ডাউনলোড করা যাবে। সাইজ report ও SHA256 সঙ্গে রাখুন। App Bundle / asset-delivery / ABI split পরবর্তী আলাদা যাচাইকৃত optimization হতে পারে; বর্তমান accepted feature বাদ দিয়ে25MB দাবি নয়।

এই deliverable থেকে GitHub run বা production deploy চালানো হয়নি। Original-signed APK ও real-phone acceptance এখনও বাকি।
