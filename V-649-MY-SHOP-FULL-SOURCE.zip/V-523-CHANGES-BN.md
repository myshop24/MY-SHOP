# MY SHOP V-523 — Live Room Locked Reference + Realtime Reliability

Base: V-522-MY-SHOP-FINAL-SOURCE.zip
Release: V-523 / 2.9.523 / versionCode 523

## V-522-এর পরের অনুমোদিত পরিবর্তনসমূহ

### Live Page 2
- Main Dashboard-এর working banner behavior Page 2-তেও একই family-তে রাখা হয়েছে: side-peek carousel, auto-slide, manual horizontal swipe/scroll, continuous sequence.
- Page 2 top shortcut row Main Dashboard-এর premium dark background family-তে আনা হয়েছে; hamburger সাদা, Membership/Games/Earn icon আরও clear/premium/consistent size.
- No-Live state-এ দুইটি polished Go Live card থাকে; Explore filler বাদ। দুই card-এর CTA একই Start Live flow খুলে।
- Active Live list-এ অপ্রয়োজনীয় Explore filler card আর যোগ হয় না।

### Locked Live Room visual
- Latest user-approved Live Room layout locked: compact Host identity + Host ID-এর পাশে Follow +, User Line Host block-এর পরেই, top stats/timer, top-right ❌, center Main Guest, 8 default seats (4+4), right rail, bottom composer/control row.
- Exact selected MY SHOP/MS logo (`122947.png`) Main Guest empty-state artwork হিসেবে source-এ বসানো হয়েছে.
- Main Guest occupied হলে guest profile center-এ থাকে; existing animated MY SHOP surround/branding path preserved.
- Default seat visual user-approved gold-ring chair style; 8 default seats, extra seats demand-based.
- Right rail locked order: Music → Love → Vote → Gift → Share.
- Bottom locked order: Comment box + Highlight ✨ → Send → Mic → Message → single JOIN/LEAVE.
- Host-এর bottom END duplicate control বাদ; Host Live end/close top-right ❌ flow দিয়ে.

### Join / Leave / Admin Suggest
- Audience sees JOIN; caller/seat user sees LEAVE; একই সঙ্গে JOIN+LEAVE নয়.
- MY SHOP Admin / assigned Moderator / accepted Live Admin JOIN করলে privileged auto-seat path backend-এ supported.
- Normal user Join request Host queue-তে যায় এবং stale pending request auto-expire হয়.
- Live Admin appointment এখন invite/accept based: Host সর্বোচ্চ 5 জন pending/active admin manage করতে পারে; target present থাকতে হবে এবং target Accept/Decline করে.
- Live Admin call suggestion Host-এর কাছে যায়; Host Accept/Decline করে. Accept করলে target user-এর কাছে actual invite যায়.
- Direct call/invite এবং Admin Suggest card data backend state-এ আলাদা রাখা হয়েছে.

### Vote / Love / realtime
- Love React session-scoped; per user per Live সর্বোচ্চ 100. Live session বদলালে নতুন session counter শুরু হয়.
- Existing Host-based Vote restriction/permanent total path preserved; self-vote block preserved.
- Live start state remains realtime-discoverable; Live end/cleanup realtime state preserved.
- Seat release cooldown added (3s) to reduce duplicate/rapid seat reassignment.

### Moderation / Admin
- Live Admin invitation table/status added.
- Room Admin can use scoped moderation (mute/unmute, block/unblock, call suggestion, music path) while Host ownership remains authoritative.
- Host can remove Live Admin; pending invite is revoked when removed.
- Moderation audit path preserved.

### Gifts / Summary
- Gift animations are queued so simultaneous gifts do not destructively overlap.
- Live Gift Summary remains Top 20; ranks 1–3 now show explicit `Top 1`, `Top 2`, `Top 3` labels; 4–20 have no Top badge.
- Profile/name/coin/gold/gift totals remain visible for supporters.
- Running Live Summary / Live history path preserved.

### Comments / audio / recovery
- Ephemeral realtime comments preserved: re-entry does not replay old room comments; continuous-presence comments remain scrollable.
- Slow-mode/duplicate comment suppression path retained.
- Mic vs room-audio role behavior preserved.
- Host/Guest/Speaker RTC publishing/subscribing path retained; network quality/speaking indicators and reconnect protections retained.
- Pre-Live audio/mic self-test intentionally NOT added, per user instruction.

## Verification performed
- `python tools/v516_preflight.py` → PASS
- `python tools_verify_master.py` → PASS
- `node --check backend/worker/src/index.js` → PASS
- `node --test tests/commerce.test.mjs tests/payout-inbox.test.mjs` → PASS (25 commerce + 12 payout/inbox local SQLite assertions)
- Full Android APK compilation/runtime still requires GitHub Actions/Android SDK if unavailable locally.
