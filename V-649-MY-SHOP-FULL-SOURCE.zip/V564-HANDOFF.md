# MY SHOP V-564 — full source handoff

## Completed
Fixed the V-563 Worker deployment failure by removing the duplicate top-level `isAdminUser` declaration. The original shared helper already existed and grants the established ADMIN role and authority IDs; the redundant later copy was deleted. Version identities are V-564 / Android versionCode 564 / versionName 2.9.564 / Worker health V-564. All V-563 features and assets were retained from its complete source.

## Why V-563 failed
GitHub reached “Deploy verified Worker then build signed APK” and Wrangler/esbuild stopped with `The symbol "isAdminUser" has already been declared`. It identified declarations at `src/index.js:96` and `src/index.js:1662`. Since deploy is gated before signed APK generation in that workflow, no signed APK was produced. The existing JavaScript `node --check` test parsed the `.js` file as CommonJS and missed the ESM-only duplicate declaration; V-564 adds `node --input-type=module --check` in the project verification, release script and workflow to catch it before release.

## Last checkpoint
Base: complete V-563 archive, 935 files. Change scope: one duplicate Worker declaration removed; V-564 identities; ESM syntax gate. Database migrations and existing feature implementations unchanged.

## Verification
The added ESM gate passes for the V-564 Worker and reproduces/fails on the original V-563 source at line 1662. `node --check` passes. ESM syntax check passes and fails on original V-563 as expected. Full regression results are recorded in V564-VERIFICATION.md. Local Android build and live Wrangler bundling could not be run in this restricted session: Gradle cannot open its localhost daemon socket and npm cannot reach the package registry. No production deployment was performed from this workspace.

## Pending and known limits
Run the existing GitHub workflow on this exact V-564 archive to produce the signed APK and deploy the Worker. Actual Android audio/headphone/Bluetooth/device and production checks still require the owner’s devices and deployment environment.

## Delivery
Use the single complete archive `V-564-MY-SHOP-SOURCE.zip`; no V-563 archive is needed to build it. It includes Android project, Worker/backend, migrations, source assets, tests and build workflow. Every later changed delivery needs a new V-number and a complete ZIP.
