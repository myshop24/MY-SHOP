# MY SHOP V-512 — build-failure elimination + release hardening

Base: V-511 editable source package.

## Exact CI failures fixed
- Fixed invalid `R.drawable/...` slash syntax in MainActivity.
- Added missing `weight(float,int)` helper to LiveHomeActivity and WatchHistoryActivity.
- Added missing `android.app.AlertDialog` import to WatchHistoryActivity.
- Added missing `android.app.DatePickerDialog` and `android.app.TimePickerDialog` imports to LiveHomeAdminActivity.
- Added BackendClient.historyAdd(...) compatibility API delegating to the existing historyRecord backend contract.

## Build hardening
- Added Android preBuild guard for invalid `R.*/*` resource syntax.
- Release identity moved to V-512 / 2.9.512 / versionCode 512 across active app/backend configuration.
- Historical V-511 change logs remain unchanged.

## Scope protection
- Home / General / History / Live / No-Live / Banner / Official Message reference corrections remain preserved.
- Future feature roadmap remains documented but is not forced into this stabilization build.

## Verification status
- Source package inspected after edits.
- Java resource syntax scan: PASS.
- Active release identity scan: PASS.
- Worker syntax: PASS.
- Full Android compile still requires GitHub Actions runner; no APK is claimed until that runner succeeds.
