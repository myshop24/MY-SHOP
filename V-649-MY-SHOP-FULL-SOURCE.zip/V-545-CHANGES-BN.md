# MY SHOP V-545

- V544-এর অনুমোদিত Live Room ও Theme কাজ অপরিবর্তিত রাখা হয়েছে।
- APK workflow এখন `V-545-...zip` এবং `V-545-MY-SHOP-SOURCE.zip`—দুই নামেই সোর্স প্যাকেজ শনাক্ত করতে পারে। তাই V545 সোর্স আপলোড করলে ভুল করে পুরোনো `V-*.zip` নির্বাচন হওয়ার ঝুঁকি কমে।
- APK build-এর আগে V544 Worker regression suite চালানো হয়। সফল হলে `MY-SHOP-V-545-QA-APK` artifact-এ installable debug APK জমা হয়।
- Version identity `MY SHOP V-545`, Android versionCode `545`, versionName `2.9.545`, Worker health `2.9.545 / V-545` করা হয়েছে।
- Pages-এর `github-pages` artifact APK নয়। Pages build এবং Android APK build আলাদা।

V545 ZIP GitHub-এ আপলোড হলেই এই workspace থেকে APK তৈরি হয়েছে—এমন দাবি করা হচ্ছে না। Android SDK/Gradle এই workspace-এ নেই; APK তৈরির জন্য GitHub-এর Android APK workflow সফলভাবে চালাতে হবে।
