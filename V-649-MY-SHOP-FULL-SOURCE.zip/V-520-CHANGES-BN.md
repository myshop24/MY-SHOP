MY SHOP V-520 — Build failure fix and release stabilization

Base: V-519 source.

- Fixed LiveHomeActivity.java compile error in noLivePanel(): duplicate local variable name `title`.
- Renamed the TextView local to `titleView` without changing the displayed title text or UI behavior.
- Release identity synchronized to V-520 / 2.9.520 / versionCode 520.
- Worker version/build markers synchronized to V-520.
- Existing V-519 UI/reference changes and backend structure retained.
- Static preflight and master regression checks must pass before release.
- Authoritative Android compile remains the GitHub Actions gate.
