# MY SHOP V-517 — Build Stabilization

- V-516-এর উপর ভিত্তি করে শুধুমাত্র build-stability কাজ করা হয়েছে।
- Java `R.drawable` reference audit সম্পন্ন।
- V-375/V-381 gift assets এবং existing profile/avatar assets যাচাই।
- Build preflight-এ ধরা 3টি genuinely missing app drawable যোগ করা হয়েছে: `ic_menu_gallery`, `ic_menu_search`, `sym_def_app_icon`।
- Android release identity: V-517 / 2.9.517 / versionCode 517।
- Worker health identity: V-517 / 2.9.517।
- নতুন feature যোগ করা হয়নি।
- এই package GitHub Actions green build না পাওয়া পর্যন্ত APK-final হিসেবে গণ্য নয়।
