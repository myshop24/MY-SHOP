# Gradle build status — V-542

Gradle 8.11.1, JDK 17, Android SDK 36 are used by the included GitHub workflow. Local Debug/Release assemble and release lint are documented in V542-VERIFICATION.md. The source has wrapper properties but no gradlew/gradlew.bat/wrapper JAR; use installed Gradle 8.11.1, as CI does.

Push delivery builds require `-PrequirePush` and matching Firebase client configuration. Local QA assembly without credentials is not a usable push-delivery build. Release signing requires the private keystore and matching secrets; none are included in the source ZIP.

## V-545 active workspace

The current workspace does not have the Gradle executable or Android SDK installed. V-545 Android assemble/lint therefore could not run here; the Worker suite and Worker syntax checks are the local gates. See `V545-VERIFICATION.md`.
