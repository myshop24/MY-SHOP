# MY SHOP V-540 — Developer Handoff

V-539-MY-SHOP-SOURCE.zip-এর সম্পূর্ণ source-এর ওপর এই পরিবর্তন। Base SHA256: `024722ba28f9a87848f46738bc72cf8fd1aa6e092e880647ab34db0dc03941e1`। App versionCode 540, versionName 2.9.540; Worker health-ও V-540/2.9.540। পরের source version V-541।

আগে `00-MY-SHOP-DEVELOPER-INSTRUCTIONS.md`-এর ৩০টি নিয়ম পড়ুন। পুরোনো handoff/report ইতিহাস হিসেবে রাখা হয়েছে; V540-এর বর্তমান ফল `V540-VERIFICATION.md`-এ।

## কী বদলেছে

- General menu পাঁচ কলাম, দশ আইকন, hidden item থাকলে gap ছাড়া compact placement। Tasks ও Privacy-এর যথার্থ native shaded vector। More Apps নতুন shaded vector; পুরোনো অন্য screen-এর artwork রাখা হয়েছে।
- Home feed continuous white; post-card frame/shadow/blue gap সরানো। Like/Comment/Share outline icons ও visible counts, liked tint। Feed name fixed 20sp; level secondary line।
- Profile: white cover/avatar hierarchy, cover hamburger, fixed one-line name, unboxed badge/level, ID clipboard, subtle Edit/Share, muted sculpted six shortcuts, Posts/Gallery/About, populated privacy-filtered details, নিচে এক composer ও actual user posts। Own-post Delete confirmation, report/block, transfer, follow/friend ও gallery routes বজায় আছে।
- Saved posts account-scoped ID references; stored private post content পুনরায় দেখানো নয়। প্রতিবার backend থেকে বর্তমান access পরীক্ষা হয়। Gallery-এর পুরোনো cross-account cached private content প্রদর্শন বন্ধ করা হয়েছে।
- Page 2-এর default startup ad সরানো। Empty preview blank। Deleted slot reload-এ খালি। Empty public banner endpoint থেকে unavailable database-কে false-success empty বলা হয় না।
- Home, Live Home ও Shop carousel automatic left-to-right। Touch pause/resume এবং neighbour peeks। Shop-এর static Mega Sale বদলে independently managed ছয়-slot `shop_home` banner folder। Shop header compact; bottom navigation যুক্ত, Live white artwork-এর জন্য pink circular contrast।
- `GeneralMenuOrderActivity`: General দশটি এবং Profile ছয়টি shortcut-এর draft drag/drop, Preview, Save, Cancel; full feature editor-এ tap। নতুন backend endpoint admin-authorized; order save metadata/hidden state অক্ষত রাখে।
- Banner card hold/drag reorder, explicit Save/Cancel, atomic banner + media slot updates; image chooser থেকে Preview → Publish; upload failure-এ একই selected image দিয়ে Retry। Existing card-এর caption/link/enable/start/end/delete controls বজায় আছে।
- Existing feature-card admin-এ draft Preview এবং Cancel যুক্ত। PageIconAdmin-এ Preview/Cancel যুক্ত; existing transaction-based order publish বহাল।
- Name policy Android-এ 20sp bold text measurement + 24 codepoint cap; backend manual name updates/registration-এ newline/24 cap। Provider-created পুরোনো Google names জোর করে কাটে না; দীর্ঘ legacy display ellipsis ব্যবহার করে, font একই।
- `SafeImageLoader` bounded decode ও generation tag ব্যবহার করে; Shop/Profile recycled view-এ stale image বসতে দেয় না।

## Backend endpoints / migration

- `GET /v1/shop/banners`: active scheduled `shop_home` banners।
- `POST /v1/admin/general-menu/order`: `{page:"general"|"profile",keys:[...]}`; General prefix `home_menu_`, Profile prefix `profile_shortcut_`; exact full permutation প্রয়োজন।
- `POST /v1/admin/banner-order`: `{folder,slots:[1..6 permutation]}`; order array-এ original slot keys; mapping to new positions 1..6; D1 batch rollback-safe।
- `POST /v1/feed/share`: `{postId,eventId}`; authenticated, blocked/private/deleted post deny; UUID idempotency। Additive table `myshop_post_shares` schema bootstrap-এ আছে।
- Share count মানে Android chooser-এ **destination app নির্বাচন**; chooser খুলে বা Cancel করলে বাড়ে না। অন্য app-এ শেষ পর্যন্ত post পাঠানো হয়েছে কিনা Android নিশ্চিত করতে পারে না। IntentSender explicit non-exported receiver এবং immutable one-shot PendingIntent ব্যবহার করে। Account বদলালে stale callback বাদ দেওয়া হয়।
- নতুন app/backend pair চালাতে Worker update প্রয়োজন। এই session-এ production Worker deploy বা production database mutation করা হয়নি। Existing deploy documents/CI workflow ব্যবহার করুন; secret source-এ বসাবেন না।

## Admin ব্যবহার

General menu বা নিজের Profile shortcut দীর্ঘচাপ → reorder editor; সেখানে tap → full feature admin। Normal tap নিজের admin shortcut-এ সরাসরি full feature editor। Saved ordering সব user-এর dashboard payload-এ যায়। Agent-এর existing ছয় contact card-এ admin Edit এখনও আছে। Admin General Agent icon দিয়ে তার top-level link/image/visibility edit করা যাবে; contact directory-র ছয় slot AgentActivity থেকেই পরিচালনা হয়।

Banner admin-এ card দীর্ঘচাপ দিয়ে drag/drop → Save order। Caption/link/schedule পরিবর্তন আলাদা card-এর Save-এ। Order draft থাকলে অন্য card mutation আগে Save/Cancel করতে হবে। Image picker → preview → Publish image। Confirmed delete permanent; R2 object মুছে যাওয়ায় fictitious Undo যোগ করা হয়নি।

## গুরুত্বপূর্ণ সীমা / পরের যাচাই

- Build ও স্থানীয় backend tests-এর ফল আলাদা report-এ। Actual signed-in Android screen / small phone / gesture / real Live audio / production D1/R2 end-to-end device test হয়নি। এগুলো completed হিসেবে চিহ্নিত করবেন না।
- Release signing আগের optional keystore/environment ব্যবস্থা অনুসরণ করে। Keystore না থাকলে release artifact unsigned; build success প্রকাশ করার আগে installed signing identity ও upgrade compatibility আলাদাভাবে যাচাই করুন।
- Feed/profile like counts আগের 24-hour counting policy অনুসরণ করে; এই release সেটা পরিবর্তন করেনি।
- Admin metadata price/offer/time fields রাখা হয়েছে; wallet/live/gift entitlement-এর অর্থ বা purchase rules এ দিয়ে পরিবর্তন করা হয়নি। Profile/General built-in shortcut-এর link/status/visibility/order কার্যকর; price/time metadata-কে নতুন payment engine বলে দাবি করা যাবে না।
- Footer-এর পুরোনো Home bottom-nav drag publish flow এই release-এ বড়ভাবে পুনর্লিখন করা হয়নি। নতুন General/Profile/Banner reorder-এ explicit draft Save/Cancel আছে।
- Emulator/device ছাড়া reference-perfect rendering দাবি নয়। Approved reference অনুযায়ী source layout/artwork করা হয়েছে; 320/360/412dp এবং বড় font-এ install করে শেষ visual acceptance দরকার।
