# V-555 handoff — source changes, not a verified APK release

## Implemented
- Keep approved room structure, seats, purchased themes and ticker; reserve Level row width for Follow.
- Anchor right action rail outside the clipping comment stage, above input/navigation safe area.
- Live invites dirty the realtime hub before background push notification delivery; one-tap feedback and duplicate-tap guard.
- Reuse bounded avatar cache and download pool with timeouts and retry backoff. Defer avatar-strip identity and JOIN notice until the real avatar is ready.
- Register viewer/JOIN atomically to prevent duplicate notices on retry/concurrent registration.
- Explicit Agora ultra-low audience role option; avoid routine playback reconfiguration on unchanged role. End-to-end latency remains unmeasured.
- Shared host/session URL, public intent landing, login-resume router and ended-session check.
- Combo threshold >=5 with larger count and effects. Do not suppress other recipients' event IDs after a local gift response.
- Remove VAT label from gift selection, retain server finance policy. Existing summaries and financial records remain.
- Atomic once-only 2,000-reaction reward/ledger with rollback protection and 24h reset of underlying per-user counts.
- Vote/reaction countdown, star particles, host identity celebration; baseline historical counts do not replay on entry; clean effects on session change/destroy.
- Full hue/saturation/value wheel with plain controls, presets and existing full Home preview/save/publish.
- Theme-aware Quick Links and legible History icon.
- 12:5 carousel image sizing and FIT_CENTER for Home/Live/Store banner cards; update admin recommended dimensions.
- VersionCode 555, versionName 2.9.555, Worker health V-555.

## Local verification
All twelve commands recorded in verification/v555/checks.json passed: Worker syntax, commerce/payout/profile tests, V430/V540/V541/V542/V544 regression harnesses, V547 invite, V549 lifecycle, V552 gift/presence, V554 start, V555 integrity. Java syntax parsed for 142 source files (javalang); this is not Android compilation.
The old V552 quantity=5 assertion was updated from combo=1 to combo=5 to match the newly approved >=5 behavior. Debit, multi-recipient and rollback checks remain.

## Pending, must not be represented as complete
- Android symbol/type compilation, signed APK, installation and all-device screenshot QA. This environment has JRE only (javac absent), no Android SDK/Gradle or release signing material; Gradle distribution download timed out. No APK is included or relabeled from an older version.
- Real two-phone measured audio latency, simultaneous JOIN/avatar behavior on slow/failed image network, small-screen/large-font Join and Follow bounds.
- Gift animation/comment overlap, countdown timing synchronization across different phones, home icon behavior across all theme modes. Countdown is locally triggered from observed milestones, so arrival timing depends on each phone's network.
- Shared-link runtime validation after Worker deployment; HTTPS App Links verification requires a real signing-certificate assetlinks.json. Landing intent button works without making an unverified autoVerify claim.
- APK distribution and production Worker deployment. Existing remote latest release was not changed. GitHub write access previously returned 403.

## Build/release
Use .github/workflows/my-shop-apk.yml with the original repository secrets and original signing certificate. The existing gated release workflow was retained and V552/V554/V555 tests added.
RELEASE_AUTOMATION/my-shop-apk.yml contains the previously prepared automatic main/ZIP release pipeline as an alternative for the repository root; it has NOT been deployed. Do not run two release workflows for the same artifact.
The stable latest/download APK URL points to whatever GitHub has actually published; it must not be advertised as V555 before signed asset verification. Share a direct APK URL, not this private developer source ZIP.
Keep Cloudflare D1/R2/FCM secrets in their existing server secrets. Never copy service-account private keys or signing passwords to public source/releases.

## Preservation evidence
V554 source directory untouched. V555-SOURCE-INVENTORY.json lists all files and SHA256 plus changed/added files relative to baseline. No ticker source was modified. Older handoffs are historical; this document and current numbered instructions take precedence.
