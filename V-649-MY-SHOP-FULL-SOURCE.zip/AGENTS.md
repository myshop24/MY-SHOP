V649 final: read MY-SHOP-DEVELOPER-HANDOFF.md and verification/V649-RESULTS.json; exact current gate tools/v649_target_verify.sh. Final V648 is baseline. Audio/Video/camera/direct-seat/PK and restrained icons are explicitly authorized; Dark-mode redesign and new gift media deferred. Continue work649, no restart. No deployment/key replacement. Full Android/source/phone results are distinct.

V648 continuation: latest owner-approved Video4 = large Host left60%,3 vertical guests right; Video2/4/7/8 and Audio4/6/8/12/18 selectable before/during Live. Cross-room PK, Admin Video policy, compact direct-edit setup, current default/24h themes are authorized. Read MY-SHOP-DEVELOPER-HANDOFF.md and V648-CHECKPOINTS.md. Run tools/v648_target_verify.sh. No deployment, original signing identity retained. Source gates and phone/production acceptance are separate.

V647 combined Phase2/3: read current MY-SHOP-DEVELOPER-HANDOFF.md and verification/V647-RESULTS.json. Owner approved actual video, Host-only Camera/Beauty, seats, ad fixes,10-second boxes and same-room PK. Run tools/v647_target_verify.sh. No deployment/signing-key replacement. Device/production/cross-room PK acceptance remains pending. Next changed releaseV648. Latest owner instructions override historical entries below.

V646 Phase1 only: read MY-SHOP-DEVELOPER-HANDOFF.md and verification/V646-RESULTS.json. Current target tools/v646_target_verify.sh. Video/Go Live/seat/coin-box changes deferred. Tests require -PmyshopOfflineTests. No production deploy. Next changed releaseV647.

V645 final source: read MY-SHOP-DEVELOPER-HANDOFF.md and verification/V645-release-proof.json. Actual Android tests31pass and unsigned release/lint gates pass with132 proven inherited V644 baseline errors. Original-signed GitHub APK/production/device acceptance remain pending. Next changed releaseV646. Unit tests require -PmyshopOfflineTests to avoid production network calls.

V644: owner-authorized post crash/grey field + unified Collection/Admin custom designer and 24h theme reset. Next delivery645. Read current handoff. No actual Android/device acceptance.
V643: run705 AdCard611 undefined afalse compiler repair. Next version644.
V642: latest owner correction batch. Next delivery643. Read current handoff; no Android/device acceptance claimed.
V641: continue this owner-authorized17-task implementation checkpoint. Read current handoff; source tests are not phone/full Android acceptance. Next delivery642.

V640 /2.9.640: owner-authorized phase3 Home/Profile/menu/theme/privacy, Story physical cleanup, comment renderer/authority presets and Admin folder notices. Read current MY-SHOP-DEVELOPER-HANDOFF.md. Local source/SQLite gates are distinct from Android/device/production acceptance. Do not restart from639. Next new delivery641. Latest owner instructions override historical rules.

V639 /2.9.639: reconstruct complete source from verified637, retain exact638 Story callback patch. Read MY-SHOP-DEVELOPER-HANDOFF.md and GITHUB-UPLOAD-V639-BN.md. Run701 unzip failure is packaging, not new compiler error. Third phase now640. Do not use incomplete638 repaired archive as baseline. Latest instructions override historical entries.

V637 /2.9.637: build repair only, obsolete UiStrings test doubles fixed. Read MY-SHOP-DEVELOPER-HANDOFF.md. Phase3 explicitly moved V638. No feature redesign in637. Full Android/GitHub signed APK acceptance pending.

V636 /2.9.636: continue this source; read MY-SHOP-DEVELOPER-HANDOFF.md and GITHUB-UPLOAD-V636-BN.md. King=Queen priority. Full Android/device/production and exhaustive language/profit acceptance unverified. V637 redesign deferred. Latest owner instructions override historical entries below.

V635: scoped FolderNoticeActivity lambda parameter compiler fix; V634 features retained. Phase 2 Story/Priority/Cleanup/D1 work deferred. Read MY-SHOP-DEVELOPER-HANDOFF.md. Next delivery V636.

V634 source checkpoint from attached V633. Read MY-SHOP-DEVELOPER-HANDOFF.md, verification/V634-RESULTS.md and GITHUB-UPLOAD-V634-BN.md. Dashboard/User Control/Home/Story source changes and focused SQLite tests; Android build blocked at Gradle network download. No APK/device/production proof. Full legacy internal Diamond migration and remaining acceptance are documented. Next changed delivery V635.

Current V633 /2.9.633: owner-authorized Admin/accounting/Home corrections from delivered V632. Read MY-SHOP-DEVELOPER-HANDOFF.md and GITHUB-UPLOAD-V633-BN.md. No local APK/device/production proof; next changed delivery V634. Latest owner instructions override historical rules below.

Current V631 / 2.9.631: exact GitHub run692 compiler repairs only; source tests pass, full Android/device acceptance remains pending. Read handoffs/MY-SHOP-V631-HANDOFF.md and GITHUB-UPLOAD-V631-BN.md. One unchanged ZIP uploaded to existing permanent pipeline. Next delivery V632. Latest instructions override historical notes below.

Current V630 / 2.9.630: owner-requested next full GitHub APK source ZIP from delivered V629. App behavior unchanged; version identities and delivery instructions corrected. Keep existing permanent repository pipeline; upload ZIP unchanged. Read GITHUB-UPLOAD-V630-BN.md and handoffs/MY-SHOP-V630-HANDOFF.md. No local APK claimed. Next delivery V631. Latest owner instructions override older workflow-install notes.

Current V629 / 2.9.629 source checkpoint: owner-approved corrections, source checks complete; full Android/device/production acceptance pending. Read V629-APPROVED-WORK-BN.md, handoffs/MY-SHOP-V629-HANDOFF.md and GITHUB-UPLOAD-V629-BN.md. Gradle download blocked locally; no APK bundled. Next changed delivery V630. Latest owner instructions override historical notes below.

Current V628 / 2.9.628: owner-approved eight correction groups continued from verified delivered V627. Read MY-SHOP-DEVELOPER-HANDOFF.md, V628-APPROVED-WORK-BN.md and GITHUB-UPLOAD-V628-BN.md first. Source/SQLite/Java-double checks are not Android/device acceptance. No APK bundled, no remote deployment performed. Next changed delivery V629. Latest owner instructions override historical notes below.

Current V627 / 2.9.627: scoped V626 Java overlay compiler fix. Read MY-SHOP-DEVELOPER-HANDOFF.md and GITHUB-UPLOAD-V627-BN.md first. No bundled APK; full Android/device acceptance pending. V626 unfinished feature work remains unfinished. Next changed delivery V628. Latest owner instructions override historical notes below.

Current V626 / 2.9.626 PARTIAL SOURCE CHECKPOINT. Read MY-SHOP-DEVELOPER-HANDOFF.md and V626-APPROVED-WORK-BN.md first. Owner authorized tasks 1–10 on 2026-10-15. Source tests are not Android/device/reference acceptance. Do not auto-deploy this checkpoint; ID expansion and visual/build verification remain pending. Next changed delivery V627. Latest owner instructions override older notes.

Current V625 /2.9.625: continue exact source. Read MY-SHOP-DEVELOPER-HANDOFF.md and V625-APPROVED-WORK-BN.md. Preserve existing modules, prices, currency rules and signing secrets. Next changed delivery V626. Latest owner instructions override historical notes.

Current V624 /2.9.624: read MY-SHOP-DEVELOPER-HANDOFF.md and V624-APPROVED-WORK-BN.md. Owner approved eight scoped corrections including Live Join/progress/sound icon. Preserve unrelated modules and signing secrets. Next changed version V625.

Current V623 /2.9.623: read MY-SHOP-DEVELOPER-HANDOFF.md and V623-APPROVED-WORK-BN.md. Owner authorized Master Commission and exact V622 Java build fix. Preserve other V622 features/Signing Secrets. Next newly changed delivery V624. Latest owner instructions override historical notes.

Current V622 /2.9.622: read MY-SHOP-DEVELOPER-HANDOFF.md. Six task groups source-tested; Task4 premium cinematic quality incomplete. Android/signedAPK/production/device acceptance pending. Next new deliveryV623. Latest owner rules supersede historical notes.

Current V621 /2.9.621: read handoffs/MY-SHOP-V621-HANDOFF.md. D1 mitigations, compact gift panel, recharge/office levels and live directory revision source implemented; local checks pass; fullAndroid/production/device acceptance pending. Next new deliveryV622.

Current V620 /2.9.620: read handoffs/MY-SHOP-V620-HANDOFF.md. Latest three-item source scope implemented,20additive gifts; local tests pass. ProductionD1, fullAndroid/signedAPK/device acceptance pending. Next changeddeliveryV621.

CurrentV619 /2.9.619: handoffs/MY-SHOP-V619-HANDOFF.md. Three actual compiler errors fixed/tested;6 basic free3D/sound prototypes.200 premium gifts/reference/device/signedAPK remainpending. Next changed deliveryV620.

Current V618 /2.9.618 partial checkpoint. Read handoffs/MY-SHOP-V618-HANDOFF.md.200 real media/production/reference/device/APK acceptance remain pending. Next changed deliveryV619.

Current V617 /2.9.617: read handoffs/MY-SHOP-V617-HANDOFF.md. Local tests passed; APK/device/real media/production acceptance pending. Next delivery V618.

Current V616 /2.9.616: read handoffs/MY-SHOP-V616-HANDOFF.md. Full source checkpoint, partial14-task completion. Local target/regression pass; actual new Rider/Gift videos, Android APK/device, full localization and production D1/policy acceptance pending. Next new delivery V617.

Current V615 /2.9.615: read handoffs/MY-SHOP-V615-HANDOFF.md. Partial13-task source correction; true3D media/full localization/production D1/device acceptance pending. Next delivery V616.

Current V614 / 2.9.614: read handoffs/MY-SHOP-V614-HANDOFF.md. GitHub missing Dialog import corrected; local target/regression checks passed, full Android build pending network. Next delivery V615.

Current V613 / 2.9.613: read handoffs/MY-SHOP-V613-HANDOFF.md. Partial source checkpoint; true3D media, full Android/device acceptance pending. Next delivery V614.

Current V612 / 2.9.612: read handoffs/MY-SHOP-V612-HANDOFF.md. Store/Mini Card source corrections and local tests; full Android/device acceptance pending. Next V613.

Current V611 / 2.9.611: read handoffs/MY-SHOP-V611-HANDOFF.md. Approved source changes and local checks; full Android/device acceptance pending. Next delivery V612.

Current V610 / 2.9.610: read handoffs/MY-SHOP-V610-HANDOFF.md. Version-correct canonical delivery; next V611.

Current V609 / 2.9.609: read handoffs/MY-SHOP-V609-HANDOFF.md. Approved Store/frame/comment source changes and local checks complete; full Android and phone acceptance pending. D1 optimization excluded. Next delivery V610.

Current V608 /2.9.608: read handoffs/MY-SHOP-V608-HANDOFF.md. Scoped missing-key compilation fix; next deliveryV609.

Current V607 /2.9.607: read handoffs/MY-SHOP-V607-HANDOFF.md. Eight approved source correction groups checked locally; signed APK/device acceptance and Admin animation reproduction pending. Next deliveryV608.

Current V606 /2.9.606: read handoffs/MY-SHOP-V606-HANDOFF.md. Seven approved source groups implemented; signed APK/full Android/device checks pending. Next new deliveryV607.

Current V605 /2.9.605: read handoffs/MY-SHOP-V605-HANDOFF.md. Six-group correction is PARTIAL; new30 rides and signed APK/device checks remain pending. Next deliveryV606.

Current V604 /2.9.604: read handoffs/MY-SHOP-V604-HANDOFF.md. Canonical source<=25,000,000 bytes. Next deliveryV605. No APK; inherited partial work recorded.

Current V603 partial checkpoint: read handoffs/MY-SHOP-V603-HANDOFF.md. All9 are NOT completed; rides blocked. Next delivery V604.

Current V602 checkpoint: read handoffs/MY-SHOP-V602-HANDOFF.md. Next delivery V603.

# MY SHOP — Mandatory Developer Entry Point

Read `DEVELOPER-POLICY-BN.md` and `MY-SHOP-DEVELOPER-INSTRUCTIONS.md` BEFORE inspecting implementation, editing, building or producing a delivery. Read `V575-APPROVED-WORK-BN.md` for current scope and `MY-SHOP-DEVELOPER-HANDOFF.md` for the last verified checkpoint. The latest owner instruction overrides historical notes. Never infer completion from a requirement document or an old log.

Current continuation: **V603 / 2.9.603**. Read `V600-APPROVED-WORK-BN.md` and `handoffs/MY-SHOP-V600-HANDOFF.md` after the entry rules. V600's membership visuals, General filters and Host lifetime Top1 ranking were explicitly discussed and authorized by the owner; no repeated approval is needed inside that scope. Other Live changes still require their own scope discussion. Read `handoffs/MY-SHOP-V601-HANDOFF.md` and `BUILD-ASSETS-BN.md`; prepare generated assets before local checks/build. Cleanup only changes source storage/build generation; runtime GIF/WAV bytes and image pixels are verified unchanged. Next new delivery is V604.

**LIVE IS A CRITICAL / HIGH-RISK ZONE.** Before changing Live Streaming code, design, audio, realtime, or its related backend, explain the exact proposed change and impact to the owner, discuss it and obtain explicit owner approval. This includes shared helpers, bug fixes, optimization, deletion and styling that would alter Live. Read-only inspection/testing is allowed. Continue independent non-Live work while a Live decision is pending.

Keep unrelated approved modules locked. Make scoped changes, preserve data/signing/package identity and run target plus regression verification. Never publish, deploy, overwrite an old version or claim a real-device test that was not performed.
