# Current delivery: V628 / 2.9.628

Read GITHUB-UPLOAD-V628-BN.md before upload. The included workflow is build-only; the legacy repository main workflow can deploy Worker before building if left in place. Use the included workflow for APK QA, preserving original signing/Firebase secrets. This source package contains no APK. APK628 and backend628 are required together for the new APIs; deployment is a separate reviewed step and was not done here.

Older upload instructions are archived in handoffs/GITHUB_UPLOAD-V627.md for history, not current release authorization.
