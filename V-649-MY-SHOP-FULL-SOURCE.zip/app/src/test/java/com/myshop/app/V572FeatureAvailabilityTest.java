package com.myshop.app;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;
@RunWith(org.robolectric.RobolectricTestRunner.class)
@Config(sdk=28,application=android.app.Application.class)
public class V572FeatureAvailabilityTest {
    @Test public void activeExternalLinkCanOpenButIncompletePageCannot() throws Exception {
        JSONObject c=new JSONObject().put("active",1).put("status","ACTIVE").put("url","https://example.com/path");
        assertTrue(FeatureAvailability.canExecute(c));c.put("url","");assertFalse(FeatureAvailability.canExecute(c));assertTrue(FeatureAvailability.message(c).startsWith("Coming Soon"));
    }
    @Test public void comingSoonNeverExecutesEvenWithLink() throws Exception {
        JSONObject c=new JSONObject().put("active",1).put("status","COMING_SOON").put("url","https://example.com").put("coming_soon_message","Testing is in progress");
        assertFalse(FeatureAvailability.canExecute(c));assertEquals("Testing is in progress",FeatureAvailability.message(c));
    }
    @Test public void inactiveAndArchivedStateOverridesActiveStatus() throws Exception {
        JSONObject c=new JSONObject().put("active",0).put("status","ACTIVE").put("url","https://example.com");assertFalse(FeatureAvailability.canExecute(c));
        c.put("active",true).put("archived",1);assertFalse(FeatureAvailability.canExecute(c));assertEquals("This feature is currently unavailable.",FeatureAvailability.message(c));
    }
    @Test public void malformedCredentialAndUnsafeLinksCannotExecute() throws Exception {
        for(String url:new String[]{"javascript:alert(1)","https:///missing-host","https://user:password@example.com","https://example.com/invalid path"})assertFalse(FeatureAvailability.canExecute(new JSONObject().put("url",url).put("status","ACTIVE")));
    }
}
