package com.myshop.app;

import android.app.Application;
import android.content.Context;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;

@RunWith(org.robolectric.RobolectricTestRunner.class)
@Config(sdk=28,application=Application.class)
public class V572WithdrawalOperationTest {
    @Test public void retriesKeepKeyUntilConfirmedWithoutStoringPrivateAccount() throws Exception {
        Context c=RuntimeEnvironment.getApplication();SessionManager.setSession(c,Role.USER,"0104");
        WithdrawalOperation first=WithdrawalOperation.begin(c,"COIN",500000,"bkash","01712345678","withdraw");
        assertEquals(first.key,WithdrawalOperation.begin(c,"COIN",500000,"bkash","01712345678","withdraw").key);
        assertFalse(c.getSharedPreferences("myshop_withdraw_operations_v572",0).getAll().toString().contains("01712345678"));
        first.confirmed();assertNotEquals(first.key,WithdrawalOperation.begin(c,"COIN",500000,"bkash","01712345678","withdraw").key);
    }
    @Test public void currencyUserAndPayloadHaveIndependentKeys() throws Exception {
        Context c=RuntimeEnvironment.getApplication();SessionManager.setSession(c,Role.USER,"0104");
        String coin=WithdrawalOperation.begin(c,"COIN",500000,"bkash","01712345678","withdraw").key;
        assertNotEquals(coin,WithdrawalOperation.begin(c,"GOLD",500000,"bkash","01712345678","withdraw").key);
        assertNotEquals(coin,WithdrawalOperation.begin(c,"COIN",1000000,"bkash","01712345678","withdraw").key);
        SessionManager.setSession(c,Role.USER,"0105");assertNotEquals(coin,WithdrawalOperation.begin(c,"COIN",500000,"bkash","01712345678","withdraw").key);
    }
}
