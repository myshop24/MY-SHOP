package com.myshop.app;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.widget.TextView;
import org.json.JSONObject;
import org.json.JSONArray;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;
/** Runs on the real Android text APIs under Robolectric during GitHub APK CI. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk=28)
public class V593TextAppearanceTest {
 private TextView label(){TextView t=new TextView(RuntimeEnvironment.getApplication());t.setText("MY SHOP");t.setTextColor(Color.BLACK);t.setTextSize(16);t.setBackground(new ColorDrawable(Color.BLUE));return t;}
 @Test public void wholeSolidGradientThenResetPreservesOriginalBackground()throws Exception{
  TextView t=label();Object background=t.getBackground();float size=t.getTextSize();
  TextAppearance.paint(t,new JSONObject().put("text","#FF0000"));Spanned text=(Spanned)t.getText();ForegroundColorSpan[] spans=text.getSpans(0,7,ForegroundColorSpan.class);assertEquals(1,spans.length);assertEquals(Color.RED,spans[0].getForegroundColor());assertSame(background,t.getBackground());
  TextAppearance.paint(t,new JSONObject().put("text","#FF0000").put("textEnd","#0000FF").put("background","#FFFFFF"));text=(Spanned)t.getText();spans=text.getSpans(0,7,ForegroundColorSpan.class);assertTrue(spans.length>1);assertNotSame(background,t.getBackground());
  TextAppearance.paint(t,null);assertSame(background,t.getBackground());assertEquals(size,t.getTextSize(),0);assertEquals(0,((Spanned)t.getText()).getSpans(0,7,ForegroundColorSpan.class).length);
 }
 @Test public void selectedPartOnlyAndChangedTextIgnoresOldSelection()throws Exception{
  TextView t=label();JSONObject style=new JSONObject().put("segments",new JSONArray().put(new JSONObject().put("source","MY SHOP").put("start",3).put("end",7).put("text","#00FF00")));
  TextAppearance.paint(t,style);Spanned text=(Spanned)t.getText();ForegroundColorSpan[] spans=text.getSpans(0,7,ForegroundColorSpan.class);assertEquals(1,spans.length);assertEquals(3,text.getSpanStart(spans[0]));assertEquals(7,text.getSpanEnd(spans[0]));
  t.setText("New name");TextAppearance.paint(t,style);assertEquals(0,((Spanned)t.getText()).getSpans(0,8,ForegroundColorSpan.class).length);
 }
 @Test public void selectedBengaliWordDoesNotSplitConjunct()throws Exception{
  TextView t=label();t.setText("ক্ষ SHOP");TextAppearance.paint(t,new JSONObject().put("word","ক্ষ").put("text","#FF0000").put("textEnd","#0000FF"));Spanned text=(Spanned)t.getText();ForegroundColorSpan[] spans=text.getSpans(0,text.length(),ForegroundColorSpan.class);assertEquals(1,spans.length);assertEquals(0,text.getSpanStart(spans[0]));assertEquals(3,text.getSpanEnd(spans[0]));
 }
}
