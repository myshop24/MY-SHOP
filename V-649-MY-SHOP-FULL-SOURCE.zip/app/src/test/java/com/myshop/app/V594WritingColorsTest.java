package com.myshop.app;
import android.app.Activity;
import android.widget.EditText;
import org.json.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;
import static org.junit.Assert.*;
@RunWith(RobolectricTestRunner.class) @Config(sdk=28)
public class V594WritingColorsTest {
 @Test public void selectedWordSurvivesCaptionTrimAndChangedSourceIsDropped() throws Exception {
  Activity a=Robolectric.buildActivity(Activity.class).setup().get();EditText input=new EditText(a);WritingColors c=new WritingColors(a,"post_draft",TextAppearance.labels("element_caption",input));
  c.styles.put("element_caption",new JSONObject().put("text","#FF0000").put("segments",new JSONArray().put(new JSONObject().put("source","  Hello world  ").put("start",8).put("end",13).put("text","#00FF00"))));
  JSONObject p=c.payload("  Hello world  ","Hello world").getJSONObject("element_caption");JSONObject part=p.getJSONArray("segments").getJSONObject(0);assertEquals(6,part.getInt("start"));assertEquals(11,part.getInt("end"));assertEquals("Hello world",part.getString("source"));
  assertEquals(8,c.styles.getJSONObject("element_caption").getJSONArray("segments").getJSONObject(0).getInt("start"));
  assertEquals(0,c.payload("new text","new text").getJSONObject("element_caption").getJSONArray("segments").length());a.finish();
 }
}
