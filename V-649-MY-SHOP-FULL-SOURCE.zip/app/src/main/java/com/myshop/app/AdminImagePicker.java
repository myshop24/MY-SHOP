package com.myshop.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.*;
import android.media.ExifInterface;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

/** System photo picker, bounded decoding, real crop preview and authenticated R2 upload. */
public final class AdminImagePicker {
    public static final int REQUEST = 62438;
    public static final int WALL_WIDTH = 1080, WALL_HEIGHT = 2400;
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    public interface Listener {
        void progress(String text);
        void ready(JSONObject asset);
        void failed(String reason);
    }
    private final Activity activity;
    private Listener listener;
    private boolean wallpaper, square, busy;
    private int generation;
    public AdminImagePicker(Activity activity) { this.activity = activity; }
    public boolean isBusy() { return busy; }
    public void cancel() { generation++; listener = null; busy = false; }
    public void chooseSquare(Listener listener) { square = true; chooseInternal(false, listener); }
    public void choose(boolean wallpaper, Listener listener) { square = false; chooseInternal(wallpaper, listener); }
    private void chooseInternal(boolean wallpaper, Listener listener) {
        if (busy) return;
        this.wallpaper = wallpaper; this.listener = listener; generation++; busy = true;
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*");
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { activity.startActivityForResult(pick, REQUEST); }
        catch (Exception e) { fail("ছবি বাছাই করার অ্যাপ পাওয়া যায়নি।"); }
    }
    private boolean valid(int ticket) {
        return ticket == generation && listener != null && !activity.isFinishing() && !activity.isDestroyed();
    }
    private void fail(String reason) {
        busy = false;
        if (listener != null && !activity.isFinishing()) listener.failed(reason);
    }
    public boolean handle(int request, int result, Intent data) {
        if (request != REQUEST) return false;
        if (result != Activity.RESULT_OK || data == null || data.getData() == null) {
            fail("ছবি নির্বাচন বাতিল হয়েছে।"); return true;
        }
        final int ticket = generation; final Uri uri = data.getData();
        if (!valid(ticket)) return true;
        listener.progress("ছবি প্রস্তুত হচ্ছে…");
        IO.execute(() -> {
            try {
                BitmapFactory.Options bounds = new BitmapFactory.Options(); bounds.inJustDecodeBounds = true;
                try (InputStream in = activity.getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, bounds); }
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IOException("Unsupported image");
                BitmapFactory.Options options = new BitmapFactory.Options(); options.inSampleSize = 1;
                while (Math.max(bounds.outWidth, bounds.outHeight) / options.inSampleSize > 3072) options.inSampleSize *= 2;
                Bitmap decoded;
                try (InputStream in = activity.getContentResolver().openInputStream(uri)) { decoded = BitmapFactory.decodeStream(in, null, options); }
                if (decoded == null) throw new IOException("Cannot decode image");
                Matrix rotation = new Matrix();
                try (InputStream in = activity.getContentResolver().openInputStream(uri)) {
                    int orientation = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                    switch (orientation) {
                        case 2: rotation.setScale(-1, 1); break;
                        case 3: rotation.setRotate(180); break;
                        case 4: rotation.setScale(1, -1); break;
                        case 5: rotation.setRotate(90); rotation.postScale(-1, 1); break;
                        case 6: rotation.setRotate(90); break;
                        case 7: rotation.setRotate(270); rotation.postScale(-1, 1); break;
                        case 8: rotation.setRotate(270); break;
                    }
                } catch (Exception ignored) { }
                final Bitmap image = rotation.isIdentity() ? decoded : Bitmap.createBitmap(decoded, 0, 0, decoded.getWidth(), decoded.getHeight(), rotation, true);
                activity.runOnUiThread(() -> { if (valid(ticket)) preview(image, ticket, bounds.outWidth, bounds.outHeight); });
            } catch (Exception | OutOfMemoryError e) {
                activity.runOnUiThread(() -> { if (valid(ticket)) fail("ছবিটি খোলা যায়নি। JPG, PNG বা WebP ছবি বেছে নিন।"); });
            }
        });
        return true;
    }
    private void preview(Bitmap image, int ticket, int originalWidth, int originalHeight) {
        LinearLayout box = new LinearLayout(activity); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), dp(8));
        TextView help = new TextView(activity); help.setTextColor(0xff253354); help.setTextSize(14);
        help.setText(square ? "এজেন্টের ছবি • Square Crop\nসরিয়ে বা জুম করে ছবি ঠিক করুন।" : wallpaper ? "Wallpaper: 1080 × 2400 px · 9:20\nআপনার ছবি: " + originalWidth + " × " + originalHeight + " px\nছবি সরিয়ে বা দুই আঙুলে জুম করে Crop ঠিক করুন।" : "ছবি: " + originalWidth + " × " + originalHeight + " px\nPreview দেখে Upload করুন।");
        box.addView(help);
        final CropView crop = new CropView(image, wallpaper || square);
        int height = Math.min(dp(390), Math.max(dp(200), activity.getResources().getDisplayMetrics().heightPixels / 2));
        box.addView(crop, new LinearLayout.LayoutParams(-1, height));
        if (wallpaper) {
            CheckBox demo = new CheckBox(activity); demo.setText("Live Room-এর Demo দেখুন");
            demo.setOnCheckedChangeListener((v, checked) -> { crop.demo = checked; crop.invalidate(); });
            if(originalWidth<WALL_WIDTH||originalHeight<WALL_HEIGHT){demo.setChecked(true);help.append("\nছবিটি ছোট; বড় করলে বিস্তারিত কম দেখা যেতে পারে। Demo দেখে নিশ্চিত করুন।");}
            box.addView(demo);
        }
        AlertDialog dialog = new MyShopDialogBuilder(activity).setTitle(wallpaper ? "Wallpaper Crop & Preview" : "পণ্যের ছবির Preview")
            .setView(box).setPositiveButton("UPLOAD", null).setNegativeButton("CANCEL", (d, w) -> fail("আপলোড বাতিল হয়েছে।")).create();
        dialog.setOnCancelListener(d -> fail("আপলোড বাতিল হয়েছে।"));
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (!valid(ticket)) { dialog.dismiss(); return; }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            final Rect source = crop.sourceRect(); final boolean wall = wallpaper; final boolean avatar = square;
            listener.progress("ছবি আপলোড হচ্ছে…"); dialog.dismiss();
            IO.execute(() -> {
                try {
                    Bitmap output;
                    if (avatar) { output=Bitmap.createBitmap(512,512,Bitmap.Config.ARGB_8888);new Canvas(output).drawBitmap(image,source,new Rect(0,0,512,512),new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG)); } else if (wall) {
                        output = Bitmap.createBitmap(WALL_WIDTH, WALL_HEIGHT, Bitmap.Config.ARGB_8888);
                        Canvas canvas=new Canvas(output);canvas.drawColor(Color.WHITE);canvas.drawBitmap(image, source, new Rect(0, 0, WALL_WIDTH, WALL_HEIGHT), new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG));
                    } else {output=Bitmap.createBitmap(image.getWidth(),image.getHeight(),Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(output);canvas.drawColor(Color.WHITE);canvas.drawBitmap(image,0,0,new Paint(Paint.FILTER_BITMAP_FLAG));}
                    ByteArrayOutputStream bytes = new ByteArrayOutputStream(); output.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
                    final int exportWidth = output.getWidth(), exportHeight = output.getHeight();
                    BackendClient.adminStoreAssetUpload(SessionManager.getToken(activity), new ByteArrayInputStream(bytes.toByteArray()), wall ? "wallpaper.jpg" : "product.jpg", "image/jpeg", new BackendClient.Callback() {
                        public void onSuccess(JSONObject asset) { if (!valid(ticket)) return; busy = false; try { asset.put("width", exportWidth).put("height", exportHeight); } catch (Exception ignored) { } listener.ready(asset); }
                        public void onError(String reason) { if (valid(ticket)) fail(reason); }
                    });
                } catch (Exception | OutOfMemoryError e) { activity.runOnUiThread(() -> { if (valid(ticket)) fail("ছবি প্রস্তুত করা যায়নি। আবার চেষ্টা করুন।"); }); }
            });
        }));
        dialog.show();
    }
    private int dp(int value) { return Math.round(value * activity.getResources().getDisplayMetrics().density); }
    private final class CropView extends View {
        private final Bitmap bitmap;
        private final boolean cropEnabled;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final RectF frame = new RectF();
        private final ScaleGestureDetector pinch;
        private float scale, minimum, x, y, previousX, previousY;
        private boolean demo;
        CropView(Bitmap bitmap, boolean cropEnabled) {
            super(activity); this.bitmap = bitmap; this.cropEnabled = cropEnabled;
            pinch = new ScaleGestureDetector(activity, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScale(ScaleGestureDetector detector) {
                    float next = Math.max(minimum, Math.min(minimum * 5, scale * detector.getScaleFactor()));
                    float factor = next / scale;
                    x = detector.getFocusX() - (detector.getFocusX() - x) * factor;
                    y = detector.getFocusY() - (detector.getFocusY() - y) * factor;
                    scale = next; clamp(); invalidate(); return true;
                }
            });
        }
        @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
            float fw = cropEnabled ? Math.min(w, h * (square ? 1f : WALL_WIDTH / (float)WALL_HEIGHT)) : w;
            float fh = cropEnabled ? fw * (square ? 1f : (float) WALL_HEIGHT / WALL_WIDTH) : h;
            frame.set((w-fw)/2, (h-fh)/2, (w+fw)/2, (h+fh)/2);
            minimum = cropEnabled ? Math.max(fw/bitmap.getWidth(), fh/bitmap.getHeight()) : Math.min(fw/bitmap.getWidth(), fh/bitmap.getHeight());
            scale = minimum; x = (w-bitmap.getWidth()*scale)/2; y = (h-bitmap.getHeight()*scale)/2;
        }
        private void clamp() {
            x = Math.min(frame.left, Math.max(frame.right - bitmap.getWidth()*scale, x));
            y = Math.min(frame.top, Math.max(frame.bottom - bitmap.getHeight()*scale, y));
        }
        Rect sourceRect() {
            if (!cropEnabled) return new Rect(0,0,bitmap.getWidth(),bitmap.getHeight());
            int left = Math.max(0, Math.round((frame.left-x)/scale)), top = Math.max(0, Math.round((frame.top-y)/scale));
            return new Rect(left, top, Math.min(bitmap.getWidth(), Math.max(left+1, Math.round((frame.right-x)/scale))), Math.min(bitmap.getHeight(), Math.max(top+1, Math.round((frame.bottom-y)/scale))));
        }
        @Override public boolean onTouchEvent(MotionEvent event) {
            if (!cropEnabled) return true;
            getParent().requestDisallowInterceptTouchEvent(true); pinch.onTouchEvent(event);
            if (event.getActionMasked()==MotionEvent.ACTION_MOVE && !pinch.isInProgress() && event.getPointerCount()==1) { x += event.getX()-previousX; y += event.getY()-previousY; clamp(); invalidate(); }
            previousX=event.getX(); previousY=event.getY();
            if(event.getActionMasked()==MotionEvent.ACTION_UP)performClick();
            return true;
        }
        @Override public boolean performClick() { super.performClick(); return true; }
        @Override protected void onDraw(Canvas canvas) {
            canvas.drawColor(0xff101729); canvas.save(); canvas.clipRect(frame);
            canvas.drawBitmap(bitmap, null, new RectF(x,y,x+bitmap.getWidth()*scale,y+bitmap.getHeight()*scale), paint);
            if (demo) {
                paint.setColor(0x99101a32); canvas.drawRect(frame.left,frame.top,frame.right,frame.top+frame.height()*.14f,paint);
                paint.setColor(Color.WHITE); paint.setTextSize(Math.max(12,frame.width()*.06f)); canvas.drawText("myshop · LIVE PREVIEW",frame.left+8,frame.top+frame.height()*.075f,paint);
                for(int n=0;n<8;n++){float cx=frame.left+frame.width()*(.14f+(n%4)*.24f),cy=frame.top+frame.height()*(.27f+(n/4)*.14f);paint.setColor(0xbb172445);canvas.drawCircle(cx,cy,frame.width()*.065f,paint);}
                paint.setColor(0xcc172445); canvas.drawRoundRect(new RectF(frame.left+8,frame.bottom-frame.height()*.13f,frame.right-8,frame.bottom-12),12,12,paint);
                paint.setColor(Color.WHITE); canvas.drawText("Comment · Mic · Message",frame.left+12,frame.bottom-frame.height()*.07f,paint);
            }
            canvas.restore();
        }
    }
}
