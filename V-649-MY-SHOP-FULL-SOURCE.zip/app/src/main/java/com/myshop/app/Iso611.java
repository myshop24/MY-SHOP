package com.myshop.app;
/** ISO/SQLite UTC timestamps, including API24 devices without java.time desugaring. */
final class Iso611 {
 private static long offset;static long now(){return System.currentTimeMillis()+offset;}static void observe(org.json.JSONObject data){long server=data.optLong("serverTime");if(server>946684800000L)offset=server-System.currentTimeMillis();}
 static long millis(String value){if(value==null||value.isEmpty())return 0;for(String pattern:new String[]{"yyyy-MM-dd'T'HH:mm:ss.SSSXXX","yyyy-MM-dd'T'HH:mm:ssXXX","yyyy-MM-dd HH:mm:ss"})try{java.text.SimpleDateFormat f=new java.text.SimpleDateFormat(pattern,java.util.Locale.US);f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));f.setLenient(false);return f.parse(value).getTime();}catch(Exception ignored){}return 0;}
 static boolean active(org.json.JSONObject card){long now=now(),start=millis(card.optString("startsAt")),end=millis(card.optString("endsAt"));return card.optBoolean("enabled",true)&&(start==0||start<=now)&&(end==0||end>now);}
 static long hold(org.json.JSONObject card){long duration=Math.max(1,Math.min(3600,card.optInt("seconds",3)))*1000L,end=millis(card.optString("endsAt"));return end==0?duration:Math.max(0,Math.min(duration,end-now()));}
 private Iso611(){}
}
