package com.myshop.app;
import android.graphics.*;import android.widget.ImageView;
/** Render custom emoji at the current screen density instead of stretching a small bitmap. */
final class IconAsset {
 static boolean emoji(ImageView target,String raw){if(raw==null||!raw.startsWith("emoji:"))return false;String value=raw.substring(6).trim();if(value.isEmpty()||value.length()>64)return false;int edge=Math.max(256,Math.round(56*target.getResources().getDisplayMetrics().density*2));Bitmap image=Bitmap.createBitmap(edge,edge,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(image);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setTypeface(Typeface.DEFAULT);p.setTextSize(edge*.7f);p.setTextAlign(Paint.Align.CENTER);float width=p.measureText(value);if(width>edge*.88f)p.setTextSize(p.getTextSize()*edge*.88f/width);Paint.FontMetrics metrics=p.getFontMetrics();target.clearColorFilter();canvas.drawText(value,edge/2f,edge/2f-(metrics.ascent+metrics.descent)/2f,p);target.setImageBitmap(image);target.setScaleType(ImageView.ScaleType.CENTER_INSIDE);return true;}
}
