package com.myshop.app;
/** Deterministic per-object timeline shared by native renderer and QA. Coordinates normalized. */
public final class GiftMotion620 {
 public static final String[] KEYS={"rose","tulip","bouquet","car","rocket","chocolate","teddy","cake","butterfly","star","dome","necklace","ring","crown","diamond","bracelet","earrings","tiara","pendant","chest"};
 public static final class State {public final double x,y,reveal,wing,light;public final int frame;State(double x,double y,double reveal,double wing,double light,int frame){this.x=x;this.y=y;this.reveal=reveal;this.wing=wing;this.light=light;this.frame=frame;}}
 public static int index(String uri){if(uri==null)return -1;String[] parts=uri.split("/");if(parts.length!=4||!parts[0].equals("myshop-gift620:")||!parts[1].isEmpty())return -1;try{int n=Integer.parseInt(parts[3]);return n>=0&&n<10&&(parts[2].equals("coin")||parts[2].equals("gold"))?n+(parts[2].equals("gold")?10:0):-1;}catch(Exception e){return -1;}}
 public static double ease(double x){x=Math.max(0,Math.min(1,x));return x*x*(3-2*x);}
 public static State state(int index,double phase,boolean catalogue){double p=Math.max(0,Math.min(1,phase));double reveal=ease(p/.48);double x=index==3&&!catalogue?-.95*(1-ease(p/.42)):0;double y=index==4&&!catalogue?-.85*ease(Math.max(0,p-.3)/.65):0;if((index==13||index==17)&&!catalogue)y=-.38*(1-ease(p/.46));double wing=index==8?.30+.70*Math.abs(Math.cos(p*Math.PI*8)):1;double light=.5+.5*Math.sin(p*Math.PI*4+index*.4);return new State(x,y,reveal,wing,light,(int)Math.min(7,Math.floor(p/.62*8)));}
}
