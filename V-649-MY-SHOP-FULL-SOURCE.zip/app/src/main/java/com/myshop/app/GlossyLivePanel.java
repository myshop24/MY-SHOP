package com.myshop.app;
import android.graphics.*;import android.graphics.drawable.Drawable;
/** Reflective enamel information panel, no image frame or spacer. */
final class GlossyLivePanel extends Drawable {
 private final Paint p=new Paint(3);private final int[] colors;
 GlossyLivePanel(int index){int[][] palettes={{0xff02102b,0xff064bbe,0xff03122d},{0xff21072f,0xff851bb0,0xff21062e},{0xff031c22,0xff087f8f,0xff052127},{0xff281709,0xffa16b16,0xff2c1b0b}};colors=palettes[Math.floorMod(index,4)];}
 public void draw(Canvas c){Rect b=getBounds();p.setShader(new LinearGradient(b.left,b.bottom,b.right,b.top,colors,null,Shader.TileMode.CLAMP));c.drawRect(b,p);p.setShader(new LinearGradient(b.left,b.top,b.right,b.bottom,new int[]{0x60ffffff,0x00ffffff,0x00ffffff,0x2834ceff},new float[]{0,.18f,.7f,1},Shader.TileMode.CLAMP));Path sweep=new Path();sweep.moveTo(b.left,b.top);sweep.lineTo(b.right,b.top);sweep.cubicTo(b.right-b.width()*.15f,b.top+b.height()*.22f,b.left+b.width()*.72f,b.top+b.height()*.32f,b.left,b.bottom);sweep.lineTo(b.left,b.bottom-b.height()*.18f);sweep.cubicTo(b.left+b.width()*.7f,b.top+b.height()*.18f,b.right-b.width()*.1f,b.top+b.height()*.09f,b.left,b.top);c.drawPath(sweep,p);p.setShader(null);p.setColor(0x8868dfff);p.setStrokeWidth(1.4f);c.drawLine(b.left,b.top+1,b.right,b.top+1,p);}
 public void setAlpha(int a){p.setAlpha(a);}public void setColorFilter(ColorFilter f){p.setColorFilter(f);}public int getOpacity(){return PixelFormat.OPAQUE;}
}
