package com.myshop.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

/**
 * Lightweight looping banner carousel with a centered card and visible previous/next peeks.
 * No RecyclerView/ViewPager dependency: safe for the existing myshop Android stack.
 */
public final class PeekBannerCarousel extends FrameLayout {
    public interface Binder { void bind(ImageView view, int index); }
    public interface Listener {
        void onIndexChanged(int index);
        void onTap(int index);
        void onHold();
        void onTouching(boolean active);
    }

    private ImageView prev;
    private ImageView current;
    private ImageView next;
    private int count=0;
    private int index=0;
    private int gapPx;
    private int cardWidth;
    private Binder binder;
    private Listener listener;
    private boolean animating=false;

    public PeekBannerCarousel(Context context){
        super(context);
        setClipChildren(false);
        setClipToPadding(false);
        gapPx=dp(7);
        prev=makeImage(); current=makeImage(); next=makeImage();
        addView(prev); addView(current); addView(next);
        setOnTouchListener(new HorizontalBannerTouch(this,new HorizontalBannerTouch.Actions(){
            @Override public void touching(boolean active){ if(listener!=null)listener.onTouching(active); }
            @Override public void swipe(boolean forward){ move(forward); }
            @Override public void drag(float dx){if(!animating&&count>1){float x=Math.max(-cardWidth,Math.min(cardWidth,dx));prev.setTranslationX(x);current.setTranslationX(x);next.setTranslationX(x);}}
            @Override public void settle(){if(!animating){for(ImageView v:new ImageView[]{prev,current,next})v.animate().translationX(0).setDuration(180).start();}}
            @Override public void tap(){ if(listener!=null && count>0)listener.onTap(index); }
            @Override public void hold(){ if(listener!=null)listener.onHold(); }
        }));
        setClickable(true);
    }

    private ImageView makeImage(){
        ImageView v=new ImageView(getContext());
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        GradientDrawable bg=new GradientDrawable();
        bg.setColor(Color.rgb(241,243,252));
        bg.setCornerRadius(dp(15));
        v.setBackground(bg);
        v.setClipToOutline(true);
        v.setElevation(dp(1));
        return v;
    }

    public void setListener(Listener l){ listener=l; }

    public void setData(int itemCount,int startIndex,Binder b){
        resetTranslations();animating=false;count=Math.max(0,itemCount);
        binder=b;
        index=count==0?0:mod(startIndex,count);
        setVisibility(count==0?View.GONE:View.VISIBLE);
        bindAll();
        requestLayout();
        if(listener!=null && count>0)listener.onIndexChanged(index);
    }

    public void refresh(){ bindAll(); }

    public int getIndex(){ return index; }
    public int getCount(){ return count; }

    public void setIndex(int target){
        if(count<=0)return;
        index=mod(target,count);
        resetTranslations();
        bindAll();
        if(listener!=null)listener.onIndexChanged(index);
    }

    public void animateTo(int target,boolean forward){
        if(count<=1){setIndex(target);return;}
        int normalized=mod(target,count);
        if(normalized==index)return;
        animateStep(normalized,forward,false);
    }

    /** Advances the configured order while the visible card travels left-to-right. */
    public void animateNextLeftToRight(){
        if(count<=1||animating)return;
        animateStep(mod(index+1,count),false,true);
    }

    public void move(boolean forward){
        if(count<=1 || animating)return;
        int target=mod(index+(forward?1:-1),count);
        animateStep(target,forward);
    }

    private void animateStep(final int target,boolean forward){animateStep(target,forward,false);}

    private void animateStep(final int target,boolean forward,boolean orderedLeftToRight){
        if(animating || count<=1)return;
        if(binder==null)return;
        ImageView incoming=forward?next:prev;if(!BannerImages.ready(incoming)){resetTranslations();return;}
        animating=true;
        final float distance=cardWidth+gapPx;
        final float dx=forward?-distance:distance;
        final long duration=520L;
        if(orderedLeftToRight){binder.bind(prev,target);binder.bind(next,mod(index-1,count));}
        prev.animate().translationX(dx).setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator()).setDuration(duration).start();
        next.animate().translationX(dx).setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator()).setDuration(duration).start();
        current.animate().translationX(dx).setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator()).setDuration(duration).withEndAction(()->{
            index=target;
            ImageView recycled;if(forward){recycled=prev;prev=current;current=next;next=recycled;}else{recycled=next;next=current;current=prev;prev=recycled;}
            resetTranslations();
            layoutCards(getWidth(),getHeight());
            if(forward)binder.bind(next,mod(index+1,count));else binder.bind(prev,mod(index-1,count));
            animating=false;
            if(listener!=null)listener.onIndexChanged(index);
        }).start();
    }

    private void bindAll(){
        if(count<=0 || binder==null){
            prev.setTag(null);current.setTag(null);next.setTag(null);prev.setImageDrawable(null);current.setImageDrawable(null);next.setImageDrawable(null);return;
        }
        binder.bind(current,index);
        if(count==1){
            prev.setVisibility(INVISIBLE);next.setVisibility(INVISIBLE);
        }else{
            prev.setVisibility(VISIBLE);next.setVisibility(VISIBLE);
            binder.bind(prev,mod(index-1,count));
            binder.bind(next,mod(index+1,count));
        }
    }

    private void resetTranslations(){
        prev.animate().cancel();current.animate().cancel();next.animate().cancel();
        prev.setTranslationX(0f);current.setTranslationX(0f);next.setTranslationX(0f);
    }

    @Override protected void onMeasure(int widthMeasureSpec,int heightMeasureSpec){
        int w=MeasureSpec.getSize(widthMeasureSpec);
        int h=MeasureSpec.getSize(heightMeasureSpec);
        cardWidth=Math.max(dp(120),Math.round(w*.84f));
        h=Math.round(cardWidth*5f/12f);
        int cw=MeasureSpec.makeMeasureSpec(cardWidth,MeasureSpec.EXACTLY);
        int ch=MeasureSpec.makeMeasureSpec(h,MeasureSpec.EXACTLY);
        prev.measure(cw,ch);current.measure(cw,ch);next.measure(cw,ch);
        setMeasuredDimension(w,h);
    }

    @Override protected void onLayout(boolean changed,int l,int t,int r,int b){
        layoutCards(r-l,b-t);
    }

    private void layoutCards(int w,int h){
        cardWidth=Math.max(dp(120),Math.round(w*.84f));
        int centerLeft=(w-cardWidth)/2;
        current.layout(centerLeft,0,centerLeft+cardWidth,h);
        prev.layout(centerLeft-cardWidth-gapPx,0,centerLeft-gapPx,h);
        next.layout(centerLeft+cardWidth+gapPx,0,centerLeft+2*cardWidth+gapPx,h);
    }

    private int mod(int value,int m){int x=value%m;return x<0?x+m:x;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
