package com.myshop.app;

/** Advertising cover: one 12:5 ratio at every device width. */
@android.annotation.SuppressLint("AppCompatCustomView")
public final class AspectBannerImageView extends android.widget.ImageView {
    public AspectBannerImageView(android.content.Context context) {
        super(context);
        setScaleType(ScaleType.FIT_CENTER);
    }
    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        int width = android.view.View.MeasureSpec.getSize(widthSpec);
        if (width == 0) { super.onMeasure(widthSpec, heightSpec); return; }
        setMeasuredDimension(width, Math.max(1, Math.round(width * 5f / 12f)));
    }
}
