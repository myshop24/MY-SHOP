package com.myshop.app;

/** Column-first pairing preserves Admin order with any number of visible items. */
public final class QuickLinkLayout {
    private QuickLinkLayout() {}
    public static int columns(int count) { return Math.max(0, count / 2 + count % 2); }
    public static int index(int column, int row, int count) {
        if (column < 0 || row < 0 || row > 1) return -1;
        long i = 2L * column + row;
        return i < count ? (int)i : -1;
    }
}
