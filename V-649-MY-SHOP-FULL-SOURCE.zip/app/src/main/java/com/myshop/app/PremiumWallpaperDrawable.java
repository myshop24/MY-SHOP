package com.myshop.app;

import android.graphics.*;
import android.graphics.drawable.Drawable;
import java.util.Random;

/**
 * V-409 lightweight built-in premium Live wallpaper fallback.
 * Draws a real full-screen portrait wallpaper (dark luxury waves + glow + stars)
 * from the wallpaper code, so all 50 seeded wallpapers are visible before Admin
 * uploads a replacement image. No bitmap payload is added to the APK.
 */
public final class PremiumWallpaperDrawable extends Drawable {
    private final String key;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random;
    private int alpha = 255;

    public PremiumWallpaperDrawable(String key) {
        this.key = key == null ? "MY_SHOP" : key;
        this.random = new Random(this.key.hashCode() * 2654435761L);
    }

    @Override public void draw(Canvas canvas) {
        Rect b = getBounds();
        float w = Math.max(1, b.width()), h = Math.max(1, b.height());
        canvas.save();
        canvas.translate(b.left, b.top);

        int seed = Math.abs(key.hashCode());
        int[][] palettes = {
                {Color.rgb(1,5,14), Color.rgb(4,29,67), Color.rgb(29,113,236)},
                {Color.rgb(4,3,18), Color.rgb(36,15,83), Color.rgb(129,57,231)},
                {Color.rgb(8,2,12), Color.rgb(78,11,39), Color.rgb(240,54,136)},
                {Color.rgb(2,12,11), Color.rgb(4,63,54), Color.rgb(29,197,154)},
                {Color.rgb(10,7,2), Color.rgb(82,49,4), Color.rgb(246,183,53)},
                {Color.rgb(2,8,18), Color.rgb(3,73,99), Color.rgb(41,199,255)}
        };
        int[] p = palettes[seed % palettes.length];
        LinearGradient bg = new LinearGradient(0,0,w,h,p[0],p[1], Shader.TileMode.CLAMP);
        paint.setShader(bg); paint.setAlpha(alpha); canvas.drawRect(0,0,w,h,paint); paint.setShader(null);

        // Soft radial spotlight, similar to a premium portrait phone wallpaper.
        float gx = w * (.25f + ((seed % 45) / 100f));
        float gy = h * (.34f + (((seed / 7) % 28) / 100f));
        RadialGradient glow = new RadialGradient(gx, gy, Math.max(w,h)*.44f,
                new int[]{withAlpha(p[2],160), withAlpha(p[2],48), Color.TRANSPARENT},
                new float[]{0f,.42f,1f}, Shader.TileMode.CLAMP);
        paint.setShader(glow); paint.setAlpha(alpha); canvas.drawCircle(gx,gy,Math.max(w,h)*.44f,paint); paint.setShader(null);

        // Two sweeping ribbons / waves; shape varies by wallpaper code.
        for (int i=0;i<3;i++) {
            Path path = new Path();
            float off = i * w * .12f;
            path.moveTo(-w*.25f, h*(.76f - i*.08f));
            path.cubicTo(w*.18f+off, h*(.84f-i*.06f), w*.46f+off, h*(.42f-i*.03f), w*1.22f, h*(.48f+i*.10f));
            path.lineTo(w*1.25f, h*(.56f+i*.10f));
            path.cubicTo(w*.52f+off, h*(.52f-i*.02f), w*.22f+off, h*(.92f-i*.05f), -w*.25f, h*(.84f-i*.07f));
            path.close();
            LinearGradient ribbon = new LinearGradient(0,h*.5f,w,h*.75f,
                    withAlpha(p[2], i==0?170:(i==1?115:75)), Color.TRANSPARENT, Shader.TileMode.CLAMP);
            paint.setShader(ribbon); paint.setAlpha(alpha); canvas.drawPath(path,paint); paint.setShader(null);
        }

        // Tiny star/dust lights. Deterministic per wallpaper, not animated/bouncing.
        random.setSeed(key.hashCode() * 2654435761L);
        for(int i=0;i<48;i++){
            float x=random.nextFloat()*w, y=random.nextFloat()*h;
            float r=0.7f+random.nextFloat()*2.1f;
            paint.setColor(random.nextInt(5)==0?withAlpha(p[2],210):Color.argb(150,235,245,255));
            paint.setAlpha(alpha); canvas.drawCircle(x,y,r,paint);
        }
        canvas.restore();
    }

    private int withAlpha(int c,int a){return Color.argb(a,Color.red(c),Color.green(c),Color.blue(c));}
    @Override public void setAlpha(int a){alpha=Math.max(0,Math.min(255,a));invalidateSelf();}
    @Override public void setColorFilter(ColorFilter f){paint.setColorFilter(f);invalidateSelf();}
    @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
