package com.myshop.app;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
/** The identical animation and sound renderer is used by catalog Demo and Live entry. */
public final class RideEffectView extends FrameLayout {
 private final JSONObject item;private final boolean autoplay;private final View art;
 private final ManagedSoundPlayer sound=new ManagedSoundPlayer();private ObjectAnimator movement;private boolean attached,playing;
 private VideoView video;private android.media.MediaPlayer preparedPlayer;private boolean prepared;private ArticulatedRideView mechanical;
 public RideEffectView(Context c,JSONObject data,boolean autoplay){super(c);item=data;this.autoplay=autoplay;setClipChildren(true);
  String url=item.optString("animation_url","");if(url.isEmpty())url=item.optString("preview_url","");
  if(RideAssets.slot(item)>=0&&!RideAssets.video(item)){mechanical=new ArticulatedRideView(c,RideAssets.slot(item));FrameLayout group=new FrameLayout(c);group.addView(mechanical,new LayoutParams(-1,-1));LinearLayout tag=new LinearLayout(c);tag.setGravity(Gravity.CENTER);ImageView portrait=new ImageView(c);portrait.setImageResource(R.drawable.myshop_profile_avatar);String avatar=item.optString("avatar_url",SessionManager.getAvatarUrl(c));if(!avatar.isEmpty())AnimatedAssetLoader.load(portrait,avatar,false);tag.addView(portrait,new LinearLayout.LayoutParams(dp(28),dp(28)));TextView name=new TextView(c);name.setText(item.optString("full_name",SessionManager.getFullName(c))+" "+UiStrings.label(c,UiStrings.ui636("has joined")));name.setTextColor(Color.WHITE);name.setTextSize(11);name.setSingleLine(true);tag.addView(name);group.addView(tag,new LayoutParams(-2,dp(30),Gravity.TOP|Gravity.CENTER_HORIZONTAL));art=group;}
  else if(!url.isEmpty()&&RideAssets.video(item)){video=new VideoView(c);video.setVideoURI(android.net.Uri.parse(url));video.setOnPreparedListener(mp->{prepared=true;preparedPlayer=mp;mp.setLooping(false);String u=RideAssets.sound(c,item);float level=playing&&u.isEmpty()?Math.max(0,Math.min(100,item.optInt("sound_volume",90)))/100f:0;mp.setVolume(level,level);if(playing){video.start();playSound();}});art=video;}
  else if(!url.isEmpty()||RideAssets.art(item)!=0){ImageView image=new ImageView(c);image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);if(!url.isEmpty())AnimatedAssetLoader.load(image,url,true);else image.setImageResource(RideAssets.art(item));art=image;}
  else{TextView symbol=new TextView(c);symbol.setText(RideAssets.symbol(item));symbol.setTextSize(82);symbol.setGravity(Gravity.CENTER);symbol.setTextColor(Color.WHITE);art=symbol;}
  addView(art,new LayoutParams(-1,-1));setContentDescription(item.optString("title","Ride entry"));
 }
 public void replay(){stop();if(!attached)return;playing=true;if(mechanical!=null)mechanical.setMoving(true);if(video!=null){video.seekTo(0);if(preparedPlayer!=null){float level=RideAssets.sound(getContext(),item).isEmpty()?Math.max(0,Math.min(100,item.optInt("sound_volume",90)))/100f:0;preparedPlayer.setVolume(level,level);}video.start();if(prepared)playSound();}else playSound();
  int ms=Math.max(800,Math.min(15000,item.optInt("effect_duration_ms",3500)));float distance=Math.max(getWidth(),dp(180));
  float travel=.40f-Math.max(1,Math.min(100,item.optInt("animation_speed",55)))*.003f;if(video==null)movement=ObjectAnimator.ofPropertyValuesHolder(art,android.animation.PropertyValuesHolder.ofKeyframe("translationX",android.animation.Keyframe.ofFloat(0,distance),android.animation.Keyframe.ofFloat(travel,0),android.animation.Keyframe.ofFloat(1-travel,0),android.animation.Keyframe.ofFloat(1,-distance)));if(movement!=null){movement.setDuration(ms);movement.setInterpolator(new android.view.animation.LinearInterpolator());movement.start();}
  postDelayed(complete,ms);
 }
 private final Runnable complete=()->{playing=false;if(mechanical!=null)mechanical.setMoving(false);sound.stop();if(video!=null)video.pause();};
 private void playSound(){String url=RideAssets.sound(getContext(),item);if(!url.isEmpty())sound.play(getContext(),url,item.optInt("sound_volume",90),item.optInt("sound_duration_ms",3000),message->android.util.Log.w("MYSHOP_RIDE",message));}
 public void stop(){removeCallbacks(complete);playing=false;if(mechanical!=null)mechanical.setMoving(false);sound.stop();if(movement!=null){movement.cancel();movement=null;}art.setTranslationX(0);if(video!=null)try{video.pause();}catch(Exception ignored){}}
 @Override protected void onAttachedToWindow(){super.onAttachedToWindow();attached=true;if(autoplay)post(this::replay);else if(mechanical!=null)mechanical.setMoving(true);}
 @Override protected void onDetachedFromWindow(){attached=false;stop();if(video!=null)video.stopPlayback();super.onDetachedFromWindow();}
 @Override public void onWindowFocusChanged(boolean focus){super.onWindowFocusChanged(focus);if(!focus)stop();else if(attached){if(autoplay)post(this::replay);else if(mechanical!=null)mechanical.setMoving(true);}}
 private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
}
