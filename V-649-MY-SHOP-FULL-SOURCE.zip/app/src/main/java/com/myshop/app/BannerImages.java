package com.myshop.app;
import android.widget.ImageView;
public final class BannerImages {public static boolean ready(ImageView v){return CachedImages.ready(v);}public static void load(ImageView v,String url){CachedImages.load(v,url);}private BannerImages(){}}
