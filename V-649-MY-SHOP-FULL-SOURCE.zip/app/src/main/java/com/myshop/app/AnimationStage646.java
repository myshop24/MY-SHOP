package com.myshop.app;
import android.content.Context;import android.graphics.*;import android.view.View;
/** Noninteractive proportional page backdrop; never opens a real room or microphone. */
final class AnimationStage646 extends View {
 private final int page;private final Paint p=new Paint(3);
 AnimationStage646(Context c,int page){super(c);this.page=page;setContentDescription("Placement preview • "+AnimationAds645Activity.PAGE_NAMES[page]);}
 private void text(Canvas c,String s,float x,float y,int size,int color){p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));c.drawText(s,x,y,p);}
 @Override protected void onDraw(Canvas c){super.onDraw(c);c.save();c.scale(getWidth()/360f,getHeight()/700f);c.drawColor(0xff0b1030);p.setShader(new LinearGradient(0,150,360,600,new int[]{0xff151445,0xff192965,0xff0b1030},null,Shader.TileMode.CLAMP));c.drawRect(0,0,360,700,p);p.setShader(null);
 text(c,page==0?"Host ✓ • ID 0001":"MY SHOP",18,32,17,Color.WHITE);text(c,"×",330,32,24,Color.WHITE);
 if(page==0){text(c,"Coin 0       Gold 0       Vote 0",16,68,13,0xffffdc7c);p.setColor(0xff3b2c6b);c.drawCircle(180,145,43,p);text(c,"MS",156,157,31,0xffffd463);for(int y=0;y<2;y++)for(int x=0;x<4;x++){float cx=45+x*82,cy=240+y*86;p.setColor(0xff543778);c.drawCircle(cx,cy,27,p);text(c,"▣",cx-9,cy+7,22,Color.WHITE);}String[] labels={"♥","Vote","Gift","Join"};for(int i=0;i<4;i++){p.setColor(0xff693cbd);c.drawCircle(332,442+i*55,18,p);text(c,labels[i],319,447+i*55,10,Color.WHITE);}p.setColor(0xff191e3e);c.drawRoundRect(10,649,263,688,19,19,p);text(c,"Write a comment…",22,674,13,0xffd3d8eb);text(c,"Mic   •••",280,675,13,Color.WHITE);
 }else{text(c,AnimationAds645Activity.PAGE_NAMES[page],18,67,15,0xffd1c4ff);p.setColor(0xff26315c);c.drawRoundRect(14,96,346,185,10,10,p);text(c,"MY SHOP",28,143,22,0xfff1d181);for(int i=0;i<3;i++){p.setColor(0xff1b244a);c.drawRoundRect(14,210+i*125,346,322+i*125,9,9,p);}text(c,"Home     myshop     Live     Profile",16,680,14,Color.WHITE);}c.restore();}
}
