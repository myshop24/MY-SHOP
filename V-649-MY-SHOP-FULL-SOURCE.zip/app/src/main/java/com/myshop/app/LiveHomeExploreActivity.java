package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

/** V-387: real See All destination for Live Home categories/challenges. */
public class LiveHomeExploreActivity extends AppCompatActivity {
    private final int BG=Color.rgb(5,14,45), WHITE=Color.WHITE, MUTED=Color.rgb(183,196,232), CYAN=Color.rgb(41,203,255);

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        String section=String.valueOf(getIntent().getStringExtra("section")).toUpperCase(java.util.Locale.US);
        setContentView(build(section));
    }

    private View build(String section){
        LinearLayout root=col();root.setBackgroundColor(BG);root.setPadding(dp(12),dp(8),dp(12),dp(14));
        root.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(dp(12),Math.max(dp(8),i.getSystemWindowInsetTop()+dp(3)),dp(12),Math.max(dp(14),i.getSystemWindowInsetBottom()+dp(8)));return i;});
        LinearLayout head=row();TextView back=t("‹",32,WHITE,true);back.setGravity(Gravity.CENTER);back.setOnClickListener(v->finish());head.addView(back,new LinearLayout.LayoutParams(dp(46),dp(50)));
        LinearLayout titleBox=col();String title="EVENTS".equals(section)?"Upcoming Events":"CHALLENGES".equals(section)?"Today’s Live Challenge":"Live Categories";String sub="EVENTS".equals(section)?"Published myshop event announcements":"CHALLENGES".equals(section)?"Pick a theme and start your Live":"Choose a category and explore Live rooms";titleBox.addView(t(title,20,WHITE,true),new LinearLayout.LayoutParams(-1,dp(28)));titleBox.addView(t(sub,9,MUTED,false),new LinearLayout.LayoutParams(-1,dp(20)));head.addView(titleBox,new LinearLayout.LayoutParams(0,dp(50),1));root.addView(head,new LinearLayout.LayoutParams(-1,dp(54)));
        ScrollView sv=new ScrollView(this);sv.setVerticalScrollBarEnabled(false);LinearLayout list=col();
        if("EVENTS".equals(section))renderEvents(list);else if("CHALLENGES".equals(section))renderChallenges(list);else renderCategories(list);
        sv.addView(list,new ScrollView.LayoutParams(-1,-2));root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));root.post(root::requestApplyInsets);return root;
    }

    private void renderEvents(LinearLayout list){
        if(SessionManager.isAdmin(this)){Button manage=new Button(this);manage.setText("ADMIN · EDIT EVENT ANNOUNCEMENT");manage.setOnClickListener(v->startActivity(new Intent(this,AdminSectionActivity.class).putExtra("section","feature_card").putExtra("managed_category","live2_events").putExtra("managed_title","Upcoming Events").putExtra("admin_context",true)));list.addView(manage);}
        TextView state=t("Loading published events…",13,MUTED,false);list.addView(state);
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(org.json.JSONObject data){runOnUiThread(()->{int count=0;org.json.JSONArray links=data.optJSONArray("managedLinks");if(links!=null)for(int n=0;n<links.length();n++){org.json.JSONObject item=links.optJSONObject(n);if(item==null||!"live2_events".equals(item.optString("category"))||item.optInt("active",0)!=1)continue;count++;TextView card=t(item.optString("title","Event")+"\n"+item.optString("caption","")+"\nOPEN EVENT ›",14,WHITE,true);card.setPadding(dp(12),dp(14),dp(12),dp(14));card.setBackground(gradient(new int[]{0xFF2653A1,0xFF882EAE},14));String target=item.optString("url","");card.setOnClickListener(v->{if(FeatureRegistry.isSafeHttpUrl(target)){try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(target)));}catch(Exception e){Toast.makeText(LiveHomeExploreActivity.this,"Event link unavailable",Toast.LENGTH_SHORT).show();}}else Toast.makeText(LiveHomeExploreActivity.this,"Admin has not published an event link",Toast.LENGTH_SHORT).show();});list.addView(card,new LinearLayout.LayoutParams(-1,-2));}state.setText(count==0?"No upcoming events have been published yet.":"");});}public void onError(String m){runOnUiThread(()->state.setText("Events unavailable. "+m));}});
    }

    private void renderCategories(LinearLayout list){
        TextView state=t("Loading saved category order…",13,MUTED,false);list.addView(state);
        final String[] suffix={"music","chat","talent","friendship","gaming","shopping","pk","more","custom_09","custom_10","custom_11","custom_12","custom_13","custom_14","custom_15","custom_16"};
        final String[] names={"Music","Chat & Talk","Talent","Friendship","Gaming","Shopping","PK Battle","More","Custom 9","Custom 10","Custom 11","Custom 12","Custom 13","Custom 14","Custom 15","Custom 16"};
        final String[] targets={"LIVE_NOW","TALK_ROOM","TRENDING","FRIENDS","LIVE_NOW","SHOP_LIVE","TRENDING","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW","LIVE_NOW"};
        final int[] art={R.drawable.home2_music,R.drawable.home2_chat,R.drawable.home2_talent,R.drawable.home2_friend,R.drawable.home2_game,R.drawable.home2_shop,R.drawable.home2_trophy,R.drawable.home2_more};
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(org.json.JSONObject data){runOnUiThread(()->{
            if(isFinishing())return;list.removeAllViews();java.util.ArrayList<org.json.JSONObject> rows=new java.util.ArrayList<>();org.json.JSONArray saved=data.optJSONArray("featureButtons");
            for(int i=0;i<suffix.length;i++){org.json.JSONObject found=null;if(saved!=null)for(int k=0;k<saved.length();k++){org.json.JSONObject f=saved.optJSONObject(k);if(f!=null&&("live2_"+suffix[i]).equals(f.optString("key"))){found=f;break;}}
                if(found==null&&i>=8)continue;if(found!=null&&found.optInt("active",0)!=1)continue;
                org.json.JSONObject item=new org.json.JSONObject();try{item.put("title",found==null?names[i]:found.optString("title",names[i]));String target=found==null?"":found.optString("target_url","");item.put("target",target.isEmpty()?targets[i]:target);item.put("icon",found==null?"":found.optString("icon_url",""));item.put("order",found==null?i+1:found.optInt("display_order",i+1));item.put("art",art[i%art.length]);rows.add(item);}catch(org.json.JSONException ignored){}
            }
            java.util.Collections.sort(rows,(a,b)->Integer.compare(a.optInt("order"),b.optInt("order")));
            for(org.json.JSONObject item:rows){LinearLayout card=row();card.setPadding(dp(10),dp(5),dp(10),dp(5));card.setBackground(gradient(new int[]{0xFF143275,0xFF382767},14));ImageView icon=new ImageView(LiveHomeExploreActivity.this);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setImageResource(item.optInt("art"));if(!item.optString("icon").isEmpty())AnimatedAssetLoader.load(icon,item.optString("icon"));card.addView(icon,new LinearLayout.LayoutParams(dp(46),dp(46)));TextView title=t(item.optString("title"),13,WHITE,true);card.addView(title,new LinearLayout.LayoutParams(0,dp(46),1));TextView open=t("OPEN ›",10,CYAN,true);open.setGravity(Gravity.CENTER);card.addView(open,new LinearLayout.LayoutParams(dp(66),dp(40)));card.setOnClickListener(v->{String target=item.optString("target");if(FeatureRegistry.isSafeHttpUrl(target)){try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(target)));}catch(Exception e){Toast.makeText(LiveHomeExploreActivity.this,"Link unavailable",Toast.LENGTH_SHORT).show();}}else startActivity(new Intent(LiveHomeExploreActivity.this,LiveListActivity.class).putExtra("category",target));});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(62));lp.bottomMargin=dp(6);list.addView(card,lp);}
            if(rows.isEmpty())list.addView(t("No categories are published.",13,MUTED,false));
        });}public void onError(String message){runOnUiThread(()->{state.setText("Could not load categories. Tap to retry.");state.setOnClickListener(v->{list.removeAllViews();renderCategories(list);});});}});
    }

    private void renderChallenges(LinearLayout list){
        String[][] data={{"🎵","Sing Your Favourite Song","Music"},{"😂","Tell a Funny Story","Talk"},{"✨","Show Your Hidden Talent","Talent"},{"💭","Let’s Talk About Life","Chat"},{"🎤","One Minute Talent","Talent"},{"🤝","Make a New Friend","Friendship"},{"🎮","Game Talk & Tips","Gaming"},{"🛍","Show Your Favourite Item","Shopping"}};
        for(int i=0;i<data.length;i++){String[] x=data[i];LinearLayout c=row();c.setPadding(dp(12),dp(8),dp(12),dp(8));int a=(i%2==0)?Color.rgb(45,73,161):Color.rgb(72,45,151),b=(i%3==0)?Color.rgb(138,55,177):Color.rgb(41,93,151);c.setBackground(gradient(new int[]{a,b},16));TextView icon=t(x[0],24,WHITE,true);icon.setGravity(Gravity.CENTER);c.addView(icon,new LinearLayout.LayoutParams(dp(54),dp(56)));LinearLayout info=col();info.addView(t(x[1],12.6f,WHITE,true),new LinearLayout.LayoutParams(-1,dp(30)));info.addView(t(x[2]+" challenge",9.1f,MUTED,false),new LinearLayout.LayoutParams(-1,dp(24)));c.addView(info,new LinearLayout.LayoutParams(0,dp(56),1));TextView start=t("GO LIVE",8.2f,WHITE,true);start.setGravity(Gravity.CENTER);start.setBackground(round(Color.rgb(170,45,181),Color.rgb(255,120,221),12));c.addView(start,new LinearLayout.LayoutParams(dp(70),dp(34)));String challenge=x[1];c.setOnClickListener(v->{Intent q=new Intent(this,AudioLiveRoomActivity.class);q.putExtra("hostMode",true);q.putExtra("challengeTitle",challenge);startActivity(q);});PremiumUi.press(c);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(76));lp.bottomMargin=dp(8);list.addView(c,lp);}
    }

    private LinearLayout col(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);return x;}
    private LinearLayout row(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);return x;}
    private TextView t(String s,float z,int c,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private GradientDrawable round(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    private GradientDrawable gradient(int[] colors,int radius){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(radius));return g;}
    private int dp(float x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
}
