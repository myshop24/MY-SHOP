package com.myshop.app;
import android.widget.ImageView;
public final class SafeImageLoader {public static void load(ImageView v,String url){CachedImages.load(v,url);}private SafeImageLoader(){}}
