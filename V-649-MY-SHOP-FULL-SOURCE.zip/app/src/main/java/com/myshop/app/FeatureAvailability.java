package com.myshop.app;

import org.json.JSONObject;
import java.net.URI;

/** Safety gate for configurable external feature pages, including stale/inconsistent config. */
final class FeatureAvailability {
    static boolean canExecute(JSONObject config){
        if(config==null||config.optInt("archived",0)!=0||Boolean.FALSE.equals(config.opt("active"))||config.optInt("active",1)==0||!"ACTIVE".equalsIgnoreCase(config.optString("status","ACTIVE")))return false;
        try{URI uri=new URI(config.optString("url","").trim());return ("https".equalsIgnoreCase(uri.getScheme())||"http".equalsIgnoreCase(uri.getScheme()))&&uri.getHost()!=null&&!uri.getHost().isEmpty()&&uri.getUserInfo()==null;}
        catch(Exception e){return false;}
    }
    static String message(JSONObject config){
        if(config!=null&&(config.optInt("archived",0)!=0||Boolean.FALSE.equals(config.opt("active"))||config.optInt("active",1)==0||"DISABLED".equalsIgnoreCase(config.optString("status"))))return "This feature is currently unavailable.";
        String custom=config==null?"":config.optString("coming_soon_message","").trim();
        return custom.isEmpty()?"Coming Soon — this feature is not available yet.":custom;
    }
}
