package com.myshop.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;
import org.json.JSONArray;

/** Persists only hashed request identities and random keys, never account numbers or tokens. */
final class WithdrawalOperation {
    private final SharedPreferences prefs;
    private final String fingerprint;
    final String key;
    private WithdrawalOperation(SharedPreferences prefs,String fingerprint,String key){this.prefs=prefs;this.fingerprint=fingerprint;this.key=key;}
    static synchronized WithdrawalOperation begin(Context context,String currency,int amount,String method,String account,String note) throws Exception {
        String payload=new JSONArray().put(SessionManager.getUserId(context)).put(currency).put(amount).put(method.trim().toLowerCase(java.util.Locale.ROOT)).put(account.trim()).put(note.trim()).toString();
        byte[] digest=MessageDigest.getInstance("SHA-256").digest(payload.getBytes(StandardCharsets.UTF_8));
        StringBuilder name=new StringBuilder();for(byte b:digest)name.append(String.format(java.util.Locale.ROOT,"%02x",b&255));
        SharedPreferences prefs=context.getApplicationContext().getSharedPreferences("myshop_withdraw_operations_v572",Context.MODE_PRIVATE);
        String fingerprint=name.toString(),key=prefs.getString(fingerprint,"");
        if(key.isEmpty()){key=UUID.randomUUID().toString();if(!prefs.edit().putString(fingerprint,key).commit())throw new IllegalStateException("Cannot safely save withdrawal request identity");}
        return new WithdrawalOperation(prefs,fingerprint,key);
    }
    void confirmed(){synchronized(WithdrawalOperation.class){if(key.equals(prefs.getString(fingerprint,"")))prefs.edit().remove(fingerprint).commit();}}
}
