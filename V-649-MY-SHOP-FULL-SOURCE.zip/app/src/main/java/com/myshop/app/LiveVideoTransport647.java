package com.myshop.app;
import android.view.View;
/** Provider boundary: UI and server room rules do not depend on Agora-specific video types. */
interface LiveVideoTransport647 {
 void videoMode647(boolean enabled,boolean publisher);
 int camera647(boolean enabled);
 int switchCamera647();
 int beauty647(boolean enabled,float amount);
 default int bridge648(String token,String channel,int uid){return -1;}
 default void stopBridge648(){}
 void attachVideo647(View target,int uid,boolean local);
}
