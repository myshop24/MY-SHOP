package com.myshop.app;
import android.app.Activity;import android.os.Handler;import android.os.Looper;import org.json.JSONObject;
/** Verify latest published feature state before following a configurable destination. */
final class FeatureAccess {
 static void open(Activity a,String key,Runnable next){
  if(SessionManager.isAdmin(a)){next.run();return;}final boolean[] done={false};Handler timer=new Handler(Looper.getMainLooper());Runnable timeout=()->{if(done[0]||a.isFinishing()||a.isDestroyed())return;done[0]=true;android.widget.Toast.makeText(a,"ফিচারের তথ্য পাওয়া যায়নি। আবার চেষ্টা করুন।",1).show();};timer.postDelayed(timeout,20000);
  BackendClient.featureAccess(SessionManager.getToken(a),key,new BackendClient.Callback(){public void onSuccess(JSONObject x){a.runOnUiThread(()->{if(done[0]||a.isFinishing()||a.isDestroyed())return;done[0]=true;timer.removeCallbacks(timeout);if(!x.has("allowed")){android.widget.Toast.makeText(a,"ফিচারের তথ্য পাওয়া যায়নি",1).show();return;}if(x.optBoolean("allowed"))next.run();else new MyShopDialogBuilder(a).setTitle(x.optString("title","Coming Soon")).setMessage(x.optString("message","Coming Soon")).setPositiveButton("ঠিক আছে",null).show();});}public void onError(String m){a.runOnUiThread(()->{timer.removeCallbacks(timeout);timeout.run();});}});
 }
}
