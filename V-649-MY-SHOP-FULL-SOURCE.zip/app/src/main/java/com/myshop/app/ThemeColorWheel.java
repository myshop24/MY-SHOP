package com.myshop.app;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;

/** Continuous hue ring and saturation/value field; no text codes required. */
public final class ThemeColorWheel extends View {
    public interface Listener { void changed(int color); }
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float[] hsv=new float[3];
    private Listener listener;
    private int touchMode;
    public ThemeColorWheel(Context c,int color){super(c);Color.colorToHSV(color,hsv);setContentDescription("রঙের চাকা: বাইরে রং, মাঝখানে হালকা গাঢ় ও ফিকে কড়া");}
    public void setListener(Listener l){listener=l;}
    public int color(){return Color.HSVToColor(hsv);}
    public void select(int color){Color.colorToHSV(color,hsv);invalidate();if(listener!=null)listener.changed(color());}
    @Override protected void onMeasure(int w,int h){int size=Math.round(280*getResources().getDisplayMetrics().density);setMeasuredDimension(resolveSize(size,w),resolveSize(size,h));}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);float cx=getWidth()/2f,cy=getHeight()/2f,r=Math.min(cx,cy)-12,stroke=r*.20f;
        int[] colors={Color.RED,Color.YELLOW,Color.GREEN,Color.CYAN,Color.BLUE,Color.MAGENTA,Color.RED};
        paint.setShader(new SweepGradient(cx,cy,colors,null));paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(stroke);canvas.drawCircle(cx,cy,r-stroke/2,paint);paint.setShader(null);paint.setStyle(Paint.Style.FILL);
        float half=r*.49f;RectF field=new RectF(cx-half,cy-half,cx+half,cy+half);
        paint.setShader(new LinearGradient(field.left,0,field.right,0,Color.WHITE,Color.HSVToColor(new float[]{hsv[0],1,1}),Shader.TileMode.CLAMP));canvas.drawRect(field,paint);
        paint.setShader(new LinearGradient(0,field.top,0,field.bottom,Color.TRANSPARENT,Color.BLACK,Shader.TileMode.CLAMP));canvas.drawRect(field,paint);paint.setShader(null);
        double angle=Math.toRadians(hsv[0]);float ring=r-stroke/2;
        marker(canvas,cx+(float)Math.cos(angle)*ring,cy+(float)Math.sin(angle)*ring,stroke*.34f);
        marker(canvas,field.left+hsv[1]*field.width(),field.top+(1-hsv[2])*field.height(),9);
    }
    private void marker(Canvas c,float x,float y,float r){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(4);paint.setColor(Color.BLACK);c.drawCircle(x,y,r+1,paint);paint.setStrokeWidth(2);paint.setColor(Color.WHITE);c.drawCircle(x,y,r,paint);paint.setStyle(Paint.Style.FILL);}
    @Override public boolean onTouchEvent(MotionEvent e){
        float cx=getWidth()/2f,cy=getHeight()/2f,r=Math.min(cx,cy)-12,half=r*.49f,x=e.getX()-cx,y=e.getY()-cy;
        if(e.getActionMasked()==MotionEvent.ACTION_DOWN){touchMode=Math.abs(x)<=half&&Math.abs(y)<=half?2:1;getParent().requestDisallowInterceptTouchEvent(true);}
        if(e.getActionMasked()==MotionEvent.ACTION_DOWN||e.getActionMasked()==MotionEvent.ACTION_MOVE){if(touchMode==1)hsv[0]=(float)((Math.toDegrees(Math.atan2(y,x))+360)%360);else{hsv[1]=Math.max(0,Math.min(1,(x+half)/(2*half)));hsv[2]=1-Math.max(0,Math.min(1,(y+half)/(2*half)));}invalidate();if(listener!=null)listener.changed(color());return true;}
        if(e.getActionMasked()==MotionEvent.ACTION_UP){performClick();getParent().requestDisallowInterceptTouchEvent(false);return true;}return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
