package com.myshop.app;

import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.text.TextUtils;
import android.provider.MediaStore;
import android.media.MediaScannerConnection;
import android.media.MediaMetadataRetriever;
import android.text.style.ForegroundColorSpan;
import android.text.Spanned;
import android.text.SpannableString;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Window;
import android.view.WindowManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.content.res.ColorStateList;
import android.util.LruCache;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

/** myshop V-503: reference-parity home polish, animated live signal, compact 3D quick links and hide-on-scroll bottom navigation. */
public class MainActivity extends androidx.appcompat.app.AppCompatActivity {
    private static final int REQUEST_NOTIFICATIONS_V323=9322;
    private int BG=Color.rgb(248,249,253), BLUE=Color.rgb(46,47,190), PURPLE=Color.rgb(91,38,214), PINK=Color.rgb(235,36,168);
    private final int NAVY=Color.rgb(18,32,75), DARK=Color.rgb(35,38,52), RED=Color.rgb(238,35,52), GREEN=Color.rgb(24,169,98), MUTED=Color.rgb(105,111,130);
    private final Handler handler=new Handler();
    private final ArrayList<JSONObject> homeMenuConfigs=new ArrayList<>();
    private final java.util.concurrent.ExecutorService imagePool=Executors.newFixedThreadPool(2);
    private final LruCache<String,Bitmap> imageCache=new LruCache<String,Bitmap>(4*1024*1024){
        @Override protected int sizeOf(String key,Bitmap value){return value.getByteCount();}
    };
    private long lastFeedLoadAt=0L;
    // V-364 recovery: avoid duplicating the entire dashboard network/image boot on the
    // first onResume immediately after onCreate, and serialize Live/New People refresh.
    private boolean firstDashboardResume=true;
    private boolean liveProfilesLoading=false;private final LiveDirectoryWatch621 homeDirectory625=new LiveDirectoryWatch621(()->loadRealLiveProfiles());
    // V-365: lifecycle gate for dashboard callbacks/timers. Prevent stale callbacks from
    // touching views or submitting image work after Activity recreation/destruction.
    private boolean dashboardVisible=false;
    private boolean dashboardDestroyed=false;
    private final Runnable notificationPoll = new Runnable() {
        @Override public void run() {
            loadNotificationCount(); loadMessageCount();
            handler.postDelayed(this,12000);
        }
    };
    private final java.util.Map<String,java.util.List<View>> feedPresenceDots=new java.util.LinkedHashMap<>();private boolean feedPresenceLoading;private int presenceTick;
    private final Runnable profilePresencePoll = new Runnable() {
        @Override public void run() {
            if(++presenceTick%3==0)refreshFeedPresence();
            handler.postDelayed(this,5000);
        }
    };
    private final Runnable heroCarouselTick=new Runnable(){@Override public void run(){
        if(!dashboardVisible||dashboardDestroyed)return;
        try{if(heroCarousel!=null)heroCarousel.move(true);else showHeroSlide(nextHeroSlide(slide));}catch(Throwable ignored){}
        scheduleHeroCarousel(currentHeroIntervalMs());
    }};
    private final Runnable promoCarouselTick=new Runnable(){@Override public void run(){
        if(!dashboardVisible||dashboardDestroyed)return;
        try{promoSlide=(promoSlide+1)%promoCount();applyPromoSlide();}catch(Throwable ignored){}
        schedulePromoCarousel();
    }};
    private final Runnable liveAdCarouselTick=new Runnable(){@Override public void run(){
        if(!dashboardVisible||dashboardDestroyed)return;
        try{if(!liveAds.isEmpty()){liveAdIndex=(liveAdIndex+1)%liveAds.size();renderPowerAds();}}catch(Throwable ignored){}
        scheduleLiveAdCarousel();
    }};
    private int slide=0;
    private int promoSlide=0;
    private String renderedLanguage;
    private UpcomingCarousel upcomingCarousel;
    private PeekBannerCarousel heroCarousel;
    private final java.util.ArrayList<Integer> activeHeroSlots=new java.util.ArrayList<>();
    private float heroDownX=0f,heroDownY=0f,promoDownX=0f,promoDownY=0f;
    private ImageView[] promoViews=new ImageView[2];
    private String[] remoteHeroUrls=new String[20];
    private String[] remoteHeroTargets=new String[20];
    private int[] remoteHeroSeconds=new int[20];
    private String[] remotePromoUrls=new String[20];
    private String[] remotePromoTargets=new String[20];
    private int[] remotePromoSeconds=new int[20];
    private boolean homeHeroSectionEnabled=true,homePromoSectionEnabled=true;
    private TextView dots,newsText,notificationBadge,messageBadge,feedStatus,postLimit;
    private LinearLayout breakingBox;
    private ImageView headerAvatar,composerAvatar;
    private LinearLayout feedList;
    private LinearLayout newPeopleRow; private View newPeopleSection; private HorizontalScrollView newPeopleScroll; private final ArrayList<JSONObject> newPeopleData=new ArrayList<>(); private int newPeopleStep=0;
    private ScrollView scroll;
    private static final String STATE_HOME_SCROLL_Y="home_scroll_y";
    private int pendingHomeScrollRestore=-1;
    private LinearLayout bottomNavView;
    private ValueAnimator chromeMarginAnimator;
    private View feedAnchor;private HomeLayout632 homeLayout632;private boolean homeLayoutShown632;private TextView feedHeading632;private LinearLayout heroGroup632;private StoryRail632 storyRail632;private View promoArt632;
    private LinearLayout liveAdBox;
    private TextView powerAdTitle, powerAdByline; private LinearLayout dynamicFolderBox; private LinearLayout realLiveProfilesRow;private TextView livePortalBadge,premiumPortalBadge,upcomingLiveText;private ImageView followedHostPreview;private long upcomingLiveAt=0L,upcomingScheduleId=0L;
    private final Runnable upcomingCountdownTick=new Runnable(){@Override public void run(){if(upcomingLiveText!=null&&upcomingLiveAt>0){long left=Math.max(0,upcomingLiveAt-System.currentTimeMillis());long mins=(left+59999)/60000;upcomingLiveText.setText(left<=0?"Starting now":(mins>=60?"Starts in "+(mins/60)+"h "+(mins%60)+"m":"Starts in "+mins+"m"));upcomingLiveText.setVisibility(View.VISIBLE);handler.postDelayed(this,30000L);}}};
    private long feedBefore=0;
    private boolean feedLoading=false,feedHasMore=true;
    private int feedGeneration;
    private static final int PICK_POST=9421;
    private Uri pendingPostUri;
    private boolean postPublishing;
    private String pendingPostMime="image/jpeg";
    private int unreadNotificationCount=0, unreadMessageCount=0;
    private boolean sessionValidationRouted=false;
    private final java.util.HashSet<Long> renderedPostIds=new java.util.HashSet<>();
    private final ArrayList<VideoView> inlineVideos=new ArrayList<>();
    private VideoView activeInlineVideo=null;
    private final java.util.HashMap<Long,View> postViews=new java.util.HashMap<>();
    private long pendingFocusPostId=0;
    private float newsTextSizeSp=13.0f;
    private ImageView liveAdImage; private TextView liveAdCaption; private View liveAdStripView; private final ArrayList<JSONObject> liveAds=new ArrayList<>(); private int liveAdIndex=0;
    private final int[] heroImgs={R.drawable.banner_wide_1,R.drawable.banner_wide_2,R.drawable.banner_wide_3,R.drawable.banner_wide_4,R.drawable.banner_wide_5,R.drawable.banner_wide_6};
    private final int[] left={R.drawable.banner_top_left_1,R.drawable.banner_top_left_2,R.drawable.banner_top_left_3,R.drawable.banner_top_left_4,R.drawable.banner_top_left_5,R.drawable.banner_top_left_6};
    private final int[] right={R.drawable.banner_top_right_1,R.drawable.banner_top_right_2,R.drawable.banner_top_right_3,R.drawable.banner_top_right_4,R.drawable.banner_top_right_5,R.drawable.banner_top_right_6};
    private final int[] live={R.drawable.dash_live1,R.drawable.dash_live2,R.drawable.dash_live3,R.drawable.dash_live4};
    // V-395 Home Page 1 quick links: compact 3D-quality icons, real actions, admin order/enable controls.
    private final String[] mainKeys={"home1_page","home1_website","home1_level","home1_membership","home1_rewards","home1_gallery","home1_external","home1_help","home1_topup","home1_share","home1_my_invite","home1_general","home1_live_tv","home1_follow_us","home1_custom_15","home1_custom_16","home1_custom_17","home1_custom_18","home1_custom_19","home1_custom_20"};
    private final String[] mainTitles={"Page","Website","My Level","Membership","Earn Rewards","Gallery +","External Media","Help Center","Top Up","Share App","My Invite","General","Live TV","Follow Us","New Link 15","New Link 16","New Link 17","New Link 18","New Link 19","New Link 20"};
    private final int[] mainIcons={R.drawable.premium438_page,R.drawable.premium438_globe,R.drawable.premium438_star,R.drawable.premium438_crown,R.drawable.premium438_gift,R.drawable.premium438_gallery,R.drawable.premium438_play,R.drawable.premium438_headphones,R.drawable.premium438_coins,R.drawable.premium438_share,R.drawable.premium438_gift,R.drawable.premium438_people,R.drawable.premium438_live,R.drawable.premium438_follow,R.drawable.premium438_more,R.drawable.premium438_more,R.drawable.premium438_more,R.drawable.premium438_more,R.drawable.premium438_more,R.drawable.premium438_more};
    private final FrameLayout[] mainCards=new FrameLayout[20];
    private final TextView[] mainLabels=new TextView[20];
    private final ImageView[] mainIconViews=new ImageView[20];
    private final String[] mainRemoteUrls=new String[20];
    private final String[] mainRemoteIconUrls=new String[20];
    private final int[] mainDisplayOrder={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
    private final boolean[] mainActive={true,true,true,true,true,true,true,true,true,true,true,true,true,true,false,false,false,false,false,false};
    private final int[] mainIconSize={44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44,44};
    private LinearLayout quickTrack;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);PanelDesign.refresh(this,"home_support");
        if(!SessionManager.hasUsableSession(this)){
            Intent i=new Intent(this,LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);finish();return;
        }
        if(Onboarding624Activity.pending(this)){startActivity(new Intent(this,Onboarding624Activity.class));finish();return;}
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},REQUEST_NOTIFICATIONS_V323);
        }
        DownloadCache625.prune(this);PushRegistration.sync(this);
        loadCachedTheme();
        pendingFocusPostId=getIntent().getLongExtra("focusPostId",0);
        setContentView(build());
        AnimationOverlay645.install(this,"home");
        MiniHeadlineOverlay.install(this,"home");
        if(pendingFocusPostId<=0){pendingHomeScrollRestore=b!=null?b.getInt(STATE_HOME_SCROLL_Y,-1):getSharedPreferences("myshop_home_state",MODE_PRIVATE).getInt(STATE_HOME_SCROLL_Y,-1);if(pendingHomeScrollRestore>=0)scroll.post(()->restoreHomeScrollPosition());}
        handlePushIntent(getIntent());
        validateStoredSession();
        loadRemote(); loadNotificationCount(); loadMessageCount(); loadNewPeople(); loadFeed(true);
        startCarousel(); startPromoCarousel(); startLiveAdCarousel();
        LiveLinkActivity.resumePending(this);
        ProfileLinkActivity.resumePending(this);
        if(getIntent().getBooleanExtra("openMyFeed",false)) handler.postDelayed(this::openMyFeed,220L);if(getIntent().getBooleanExtra("openTextComposer",false)){handler.postDelayed(()->openRequestedComposer(getIntent()),350L);getIntent().removeExtra("openTextComposer");}
    }

    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        if(intent!=null&&intent.getBooleanExtra("openMyFeed",false)) handler.postDelayed(this::openMyFeed,120L);if(intent!=null&&intent.getBooleanExtra("openTextComposer",false)){handler.postDelayed(()->openRequestedComposer(intent),180L);intent.removeExtra("openTextComposer");}
        handlePushIntent(intent);
    }

    private void handlePushIntent(Intent intent){
        if(intent==null)return;
        String type=intent.getStringExtra("type"), actor=intent.getStringExtra("actorUserId"), target=intent.getStringExtra("targetId");
        if(type==null||type.trim().isEmpty())return;
        final String t=type.trim().toUpperCase(java.util.Locale.US);
        intent.removeExtra("type");
        if("SAFETY_REPORT".equals(t)&&SessionManager.isAdmin(this)){startActivity(new Intent(this,AdminSafetyActivity.class).putExtra("reportId",target));}
        else if("MESSAGE".equals(t) && actor!=null && !actor.trim().isEmpty()){
            startActivity(new Intent(this,ChatActivity.class).putExtra("userId",actor.trim()));
        }else if(t.startsWith("LIVE_") && actor!=null && !actor.trim().isEmpty()){
            Intent i=new Intent(this,AudioLiveRoomActivity.class);i.putExtra("hostMode",false);i.putExtra("hostId",target!=null&&!target.trim().isEmpty()?target.trim():actor.trim());i.putExtra("fromNotification",true);startActivity(i);
        }else if("OFFICIAL".equals(t)){
            startActivity(new Intent(this,NotificationActivity.class));
        }
    }


    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==REQUEST_NOTIFICATIONS_V323){PushRegistration.sync(this);if(grantResults.length>0&&grantResults[0]!=android.content.pm.PackageManager.PERMISSION_GRANTED&&!getSharedPreferences("notification_help",MODE_PRIVATE).getBoolean("shown",false)){getSharedPreferences("notification_help",MODE_PRIVATE).edit().putBoolean("shown",true).apply();NotificationSettings.explain(this);}}
    }

    private void loadCachedTheme(){BG=ThemeConfig.bg(this);BLUE=ThemeConfig.blue(this);PURPLE=ThemeConfig.purple(this);PINK=ThemeConfig.pink(this);}

    private void validateStoredSession(){
        final String token=SessionManager.getToken(this);
        if(token==null||token.isEmpty()){routeToLoginForExpiredSession();return;}
        BackendClient.me(token,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                JSONObject u=d.optJSONObject("user");if(u==null)return;
                try{
                    Role role=Role.valueOf(u.optString("role",SessionManager.getRole(MainActivity.this).name()));
                    String uid=u.optString("userId",SessionManager.getUserId(MainActivity.this));
                    SessionManager.setRemoteSession(MainActivity.this,token,role,uid);
                    SessionManager.saveProfile(MainActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""),u.optString("avatarUrl",""),u.optString("coverUrl",""),u.optString("bio",""));
                    runOnUiThread(()->{if(!dashboardDestroyed&&headerAvatar!=null)CachedImages.load(headerAvatar,u.optString("avatarUrl",""));});
                    PushRegistration.sync(MainActivity.this);
                }catch(Throwable ignored){}
            }
            public void onError(String m){
                if("UNAUTHORIZED".equalsIgnoreCase(String.valueOf(m).trim())) runOnUiThread(()->routeToLoginForExpiredSession());
                // Network/server errors do not destroy a known session. Cached login stays active.
            }
        });
    }
    private void routeToLoginForExpiredSession(){
        if(sessionValidationRouted)return;sessionValidationRouted=true;
        SessionManager.clear(this);
        Intent i=new Intent(this,LoginActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(i);finish();
    }


    private View build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(BG);
        final LinearLayout fixed=col(); fixed.setPadding(0,dp(8),0,0); fixed.setBackgroundColor(BG);
        fixed.addView(header(),lp(-1,dp(58)));
        fixed.addView(breaking(),top(lp(-1,dp(42)),5));

        scroll=new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);

        LinearLayout page=col();
        page.setPadding(0,dp(2),0,dp(92));
        page.setBackgroundColor(BG);
        page.setOnApplyWindowInsetsListener((v,insets)->{
            int bottomInset=Math.max(0,insets.getSystemWindowInsetBottom());
            v.setPadding(0,dp(4),0,dp(76)+bottomInset);
            return insets;
        });

        // V-503: new locked Home reference flow — top menu → banner → My Feed.
        // V640: these shortcuts are in the four-column hamburger menu.

        heroCarousel=new PeekBannerCarousel(this);
        heroCarousel.setListener(new PeekBannerCarousel.Listener(){
            public void onIndexChanged(int idx){if(idx<activeHeroSlots.size())slide=activeHeroSlots.get(idx);updateHeroDots();}
            public void onTap(int idx){if(idx<activeHeroSlots.size())slide=activeHeroSlots.get(idx);openHeroTarget();}
            public void onHold(){if(SessionManager.isAdmin(MainActivity.this))startActivity(new Intent(MainActivity.this,BannerAdminActivity.class).putExtra("admin_context",true));}
            public void onTouching(boolean active){if(active)handler.removeCallbacks(heroCarouselTick);else scheduleHeroCarousel();}
        });
        heroCarousel.setData(0,0,(view,index)->{});
        heroGroup632=col();heroGroup632.addView(heroCarousel,top(lp(-1,dp(142)),3));page.addView(heroGroup632,lp(-1,-2));
        heroCarousel.post(()->{ViewGroup.LayoutParams p=heroCarousel.getLayoutParams();if(p!=null&&heroCarousel.getWidth()>0){p.height=Math.round(heroCarousel.getWidth()*.84f*5f/12f);heroCarousel.setLayoutParams(p);}});

        dots=text("",BLUE,8.5f,true); dots.setGravity(Gravity.CENTER); heroGroup632.addView(dots,lp(-1,dp(14)));
        upcomingCarousel=new UpcomingCarousel(this);
        feedAnchor=feedComposerSection();feedAnchor.setBackgroundColor(Color.WHITE);feedAnchor.setBackgroundColor(Color.WHITE);
        page.addView(feedAnchor,top(lp(-1,-2),2));

        feedStatus=text("",MUTED,8.8f,false); feedStatus.setVisibility(View.GONE); feedStatus.setGravity(Gravity.CENTER);
        feedList=col();feedList.setBackgroundColor(Color.WHITE);feedList.setPadding(0,0,0,0); page.addView(feedList,lp(-1,-2));
        storyRail632=new StoryRail632(this);LinearLayout promo632=col();promoArt632=doublePromos();promoArt632.setVisibility(View.GONE);promo632.addView(promoArt632,lp(-1,dp(100)));homeLayout632=new HomeLayout632(this,page,feedList,feedHeading632);homeLayout632.add("stories",storyRail632);homeLayout632.add("composer",feedAnchor);homeLayout632.add("hero",heroGroup632);homeLayout632.add("promo",promo632);homeLayout632.add("upcoming",upcomingCarousel);homeLayout632.apply();homeLayout632.load();
        scroll.addView(page,new ScrollView.LayoutParams(-1,-2));

        final View bottomNav=bottom();
        final View portalBar=new View(this); portalBar.setVisibility(View.GONE);
        final boolean[] chromeHidden={false};
        final int fixedHeight=110;
        final int[] topInset={0};
        scroll.setOnScrollChangeListener((v,sx,sy,osx,osy)->{
            View child=scroll.getChildAt(0); if(child!=null && sy+scroll.getHeight()>=child.getHeight()-dp(420)) loadFeed(false); updateInlineVideoPlayback();
            int dy=sy-osy;if(Math.abs(dy)>dp(2)){if(dy>0 && sy>dp(40) && !chromeHidden[0]){chromeHidden[0]=true;portalBar.animate().translationY(0f).alpha(0f).setDuration(190).start();bottomNav.animate().translationY(dp(82)).alpha(0f).setDuration(190).start();animateScrollTopMargin(topInset[0]+dp(fixedHeight+3),190);}else if(dy<0 && chromeHidden[0]){chromeHidden[0]=false;portalBar.animate().translationY(0f).alpha(0f).setDuration(190).start();bottomNav.animate().translationY(0f).alpha(1f).setDuration(190).start();animateScrollTopMargin(topInset[0]+dp(fixedHeight+3),190);}}
            if(sy<=dp(8)&&chromeHidden[0]){chromeHidden[0]=false;portalBar.animate().translationY(0f).alpha(0f).setDuration(160).start();bottomNav.animate().translationY(0f).alpha(1f).setDuration(160).start();animateScrollTopMargin(topInset[0]+dp(fixedHeight+3),160);}
        });

        FrameLayout.LayoutParams scrollLp=new FrameLayout.LayoutParams(-1,-1); scrollLp.topMargin=dp(fixedHeight+3); root.addView(scroll,scrollLp);
        root.addView(fixed,new FrameLayout.LayoutParams(-1,dp(fixedHeight),Gravity.TOP));
        final FrameLayout.LayoutParams navLp=new FrameLayout.LayoutParams(-1,dp(78),Gravity.BOTTOM); root.addView(bottomNav,navLp);

        root.setOnApplyWindowInsetsListener((v,insets)->{
            int ti=Math.max(0,insets.getSystemWindowInsetTop()); int bi=Math.max(0,insets.getSystemWindowInsetBottom());topInset[0]=ti;
            fixed.setPadding(0,ti+dp(8),0,0);
            FrameLayout.LayoutParams fp=(FrameLayout.LayoutParams)fixed.getLayoutParams();fp.height=ti+dp(fixedHeight);fixed.setLayoutParams(fp);
            FrameLayout.LayoutParams sp=(FrameLayout.LayoutParams)scroll.getLayoutParams();sp.topMargin=ti+dp(fixedHeight+3);sp.bottomMargin=Math.max(0,bi-dp(6));scroll.setLayoutParams(sp);
            navLp.bottomMargin=Math.max(0,bi-dp(6)); bottomNav.setLayoutParams(navLp); return insets;
        });
        root.post(root::requestApplyInsets); return root;
    }

    private void animateScrollTopMargin(int target,int duration){if(scroll==null)return;android.view.ViewGroup.LayoutParams raw=scroll.getLayoutParams();if(!(raw instanceof FrameLayout.LayoutParams))return;FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)raw;int start=lp.topMargin;if(start==target)return;if(chromeMarginAnimator!=null)chromeMarginAnimator.cancel();chromeMarginAnimator=ValueAnimator.ofInt(start,target);chromeMarginAnimator.setDuration(duration);chromeMarginAnimator.addUpdateListener(a->{FrameLayout.LayoutParams p=(FrameLayout.LayoutParams)scroll.getLayoutParams();p.topMargin=(Integer)a.getAnimatedValue();scroll.setLayoutParams(p);});chromeMarginAnimator.start();}

    private View header(){SharedPageHeader h=new SharedPageHeader(this);headerAvatar=h.headerAvatar;headerAvatar.setOnClickListener(v->startActivity(new Intent(this,UserMenuActivity.class).putExtra("profile_context",true)));notificationBadge=h.notificationBadge;messageBadge=h.messageBadge;updateNotificationBadge();updateMessageBadge();VisualDesign.apply(this,h,"home_header");return h;}
    private FrameLayout headerAction(int iconRes,String description){FrameLayout box=new FrameLayout(this);ImageView icon=new ImageView(this);icon.setImageResource(iconRes);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setPadding(dp(6),dp(6),dp(6),dp(6));icon.setImageTintList(ColorStateList.valueOf(Color.WHITE));icon.setContentDescription(description);box.addView(icon,new FrameLayout.LayoutParams(-1,-1));applyRipple(box);return box;}
    private FrameLayout headerMessageAction(){FrameLayout box=new FrameLayout(this);ImageView icon=new ImageView(this);icon.setImageResource(R.drawable.ui_message_hd);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setPadding(dp(3),dp(3),dp(3),dp(3));icon.clearColorFilter();icon.setContentDescription("Messages");box.addView(icon,new FrameLayout.LayoutParams(-1,-1));applyRipple(box);return box;}

    private View threeLineMenu(){
        LinearLayout box=col(); box.setGravity(Gravity.CENTER); box.setPadding(dp(4),dp(4),dp(4),dp(4)); box.setBackground(round(Color.TRANSPARENT,Color.TRANSPARENT,12));
        for(int i=0;i<3;i++){ View line=new View(this);Appearance.preserve(line); line.setBackground(round(0xff172338,Color.TRANSPARENT,2)); LinearLayout.LayoutParams q=lp(dp(25),dp(3)); if(i>0)q.topMargin=dp(3); box.addView(line,q); }
        return box;
    }

    private View homeTopMenu(){
        LinearLayout bar=row();Appearance.preserve(bar); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(5),dp(1),dp(5),dp(1));
        bar.setBackgroundColor(Color.WHITE);
        FrameLayout menuWrap=new FrameLayout(this);
        menuWrap.addView(threeLineMenu(),new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
        menuWrap.setContentDescription("Home menu");
        menuWrap.setOnClickListener(v->showHomeMenuDialog());menuWrap.setOnLongClickListener(v->{if(!SessionManager.isAdmin(this))return false;startActivity(new Intent(this,MainActivity.class).putExtra("home_layout_preview632",true));return true;});
        bar.addView(menuWrap,lp(dp(58),dp(50)));
        addHomeTopItem(bar,"External",v->{WatchHistoryActivity.record(this,"EXTERNAL","External","external_movie");startActivity(new Intent(this,MediaHubActivity.class).putExtra("section","external"));});
        addHomeTopItem(bar,"Store",v->{WatchHistoryActivity.record(this,"STORE","Store","store");startActivity(new Intent(this,StoreActivity.class));});
        addHomeTopItem(bar,"Video",v->{WatchHistoryActivity.record(this,"VIDEO","Video","video");startActivity(new Intent(this,ShortVideoActivity.class));});
        addHomeTopItem(bar,"General",v->startActivity(new Intent(this,GeneralUsersActivity.class)));
        addHomeTopItem(bar,"History",v->startActivity(new Intent(this,WatchHistoryActivity.class)));
        return bar;
    }

    private void addHomeTopItem(LinearLayout bar,String label,View.OnClickListener listener){
        LinearLayout cell=col();cell.setGravity(Gravity.CENTER);cell.setPadding(dp(1),dp(2),dp(1),0);cell.setBackgroundColor(Color.TRANSPARENT);
        int iconRes=R.drawable.premium438_page;
        if("External".equals(label))iconRes=R.drawable.home590_external; else if("Store".equals(label))iconRes=R.drawable.home609_store; else if("Video".equals(label))iconRes=R.drawable.home590_video; else if("General".equals(label))iconRes=R.drawable.home590_general; else if("History".equals(label))iconRes=R.drawable.home590_history;
        ImageView icon=new ImageView(this);icon.setImageResource(iconRes);Appearance.preserve(icon);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setElevation(0);cell.addView(icon,lp(dp(29),dp(29)));
        TextView v=text(label,0xff172338,8.5f,false);Appearance.preserve(v);v.setGravity(Gravity.CENTER);v.setSingleLine(true);v.setIncludeFontPadding(false);cell.addView(v,lp(-1,dp(18)));cell.setOnClickListener(listener);applyRipple(cell);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(50),1f);cp.leftMargin=dp(2);bar.addView(cell,cp);
    }

    void showCreateMenu640(){
        android.app.Dialog dialog=new android.app.Dialog(this);LinearLayout panel=col();panel.setPadding(dp(16),dp(12),dp(16),dp(22));panel.setBackground(round(Color.WHITE,Color.TRANSPARENT,22));LinearLayout heading=row();heading.addView(text(UiStrings.label(this,"Create"),NAVY,19,true),weight(1,dp(44)));TextView close=text("×",MUTED,26,false);close.setGravity(Gravity.CENTER);close.setOnClickListener(v->dialog.dismiss());heading.addView(close,lp(dp(40),dp(44)));panel.addView(heading);
        String[] labels={"Post","Reel / Video","Story","Live"},descriptions={"লেখা, ছবি ও সাধারণ পোস্ট","ছোট-বড় ভিডিও আপলোড","নতুন স্টোরি তৈরি","লাইভ পেজ খুলুন"};int[] icons={R.drawable.feed_action_post,R.drawable.feed_action_video,R.drawable.header_create640,R.drawable.feed_action_video};int[] colors={0xffee2964,0xff8b38ee,0xff087bff,0xffff2a5d};
        for(int at=0;at<4;at++){final int action=at;LinearLayout item=row();item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(0,dp(8),0,dp(8));ImageView icon=new ImageView(this);icon.setImageResource(icons[at]);icon.setImageTintList(ColorStateList.valueOf(colors[at]));icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setPadding(dp(8),dp(8),dp(8),dp(8));icon.setBackground(round(Color.argb(28,Color.red(colors[at]),Color.green(colors[at]),Color.blue(colors[at])),Color.TRANSPARENT,12));item.addView(icon,lp(dp(48),dp(48)));LinearLayout copy=col();copy.setPadding(dp(14),0,0,0);copy.addView(text(UiStrings.label(this,labels[at]),NAVY,16,true));copy.addView(text(descriptions[at],MUTED,12,false));item.addView(copy,weight(1,-2));item.setOnClickListener(v->{dialog.dismiss();if(action==0)showTextPostDialog();else if(action==1)pickPost("video");else if(action==2){if(storyRail632!=null)storyRail632.create640();}else startActivity(new Intent(this,LiveHomeActivity.class));});panel.addView(item,lp(-1,dp(72)));}
        dialog.setContentView(panel);dialog.show();if(dialog.getWindow()!=null){dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));dialog.getWindow().setGravity(Gravity.BOTTOM);dialog.getWindow().setLayout(-1,-2);}Appearance.dialog(dialog);
    }

    void showHomeMenuDialog(){
        final String[] titles={"Agent","My Links","Deals","What’s New","My Tasks","Shorts","Events","Flash Sale","Invite","Safety & Privacy"};
        final String[] keys={"agent","my_links","deals","whats_new","my_tasks","shorts","events","flash_sale","invite","safety_privacy"};
        final int[] icons={R.drawable.premium438_people,R.drawable.premium438_globe,R.drawable.premium438_tag,R.drawable.premium438_more,R.drawable.premium438_page,R.drawable.premium438_play,R.drawable.premium438_trophy,R.drawable.premium438_fire,R.drawable.premium438_people,R.drawable.premium438_headphones};
        ArrayList<Integer> order=new ArrayList<>();for(int i:new int[]{0,1,3,9,8})order.add(i);
        java.util.Collections.sort(order,(a,b)->{JSONObject oa=findHomeMenuConfig(keys[a]),ob=findHomeMenuConfig(keys[b]);int da=oa==null?a+1:Math.max(1,oa.optInt("display_order",a+1));int db=ob==null?b+1:Math.max(1,ob.optInt("display_order",b+1));return Integer.compare(da,db);});
        LinearLayout outer=col(); outer.setPadding(dp(10),dp(10),dp(10),dp(8)); outer.setBackground(round(Color.WHITE,Color.rgb(224,228,240),22));
        LinearLayout titleRow=row(); TextView title=text("GENERAL MENU",NAVY,15,true); titleRow.addView(title,weight(1,dp(34))); TextView close=text("✕",MUTED,16,true); close.setGravity(Gravity.CENTER); titleRow.addView(close,lp(dp(38),dp(34))); outer.addView(titleRow,lp(-1,dp(38)));
        GridLayout grid=new GridLayout(this); grid.setColumnCount(4); grid.setPadding(0,dp(2),0,dp(2));
        int visiblePos=0;for(int pos=0;pos<order.size();pos++){final int i=order.get(pos);final String cfgKey=keys[i];final JSONObject cfg=findHomeMenuConfig(cfgKey);if(cfg!=null&&cfg.optInt("active",1)!=1&&!SessionManager.isAdmin(this))continue;String label=cfg==null?titles[i]:cfg.optString("title",titles[i]);if(label.trim().isEmpty())label=titles[i];if("invite".equals(cfgKey))label="Share";final String itemLabel=label;
            LinearLayout item=col();item.setTag(R.id.visual_design_key,"element_general_"+cfgKey+"_container");item.setGravity(Gravity.CENTER);item.setPadding(dp(3),dp(4),dp(3),dp(3));ImageView iv=new ImageView(this);iv.setTag(R.id.visual_design_key,"element_general_"+cfgKey+"_icon");PremiumArt.apply(iv,"invite".equals(cfgKey)?R.drawable.premium438_share:PremiumIconLibrary.general(cfgKey));iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);iv.setPadding(dp(2),dp(2),dp(2),dp(2));item.addView(iv,lp(dp(46),dp(46)));if(cfg!=null){String asset=cfg.optString("icon_url","").trim();if(asset.isEmpty())asset=cfg.optString("image_url","").trim();if(!asset.isEmpty())loadRemoteImage(iv,asset);}
            TextView tx=text(UiStrings.label(this,label),NAVY,9.2f,true);tx.setTag(R.id.visual_design_key,"element_general_"+cfgKey+"_label");tx.setGravity(Gravity.CENTER);tx.setMaxLines(2);tx.setEllipsize(TextUtils.TruncateAt.END);item.addView(tx,lp(-1,-2));item.setMinimumHeight(dp(78));item.setContentDescription(itemLabel+" feature");item.setOnClickListener(v->{if("invite".equals(cfgKey))shareAppFromDashboard();else openHomeMenuFeature(cfgKey,itemLabel);});item.setOnLongClickListener(v->{if(!SessionManager.isAdmin(this))return false;new MyShopDialogBuilder(this).setTitle(itemLabel).setItems(new String[]{"এডমিন প্যানেল","টেনে অবস্থান বদলান","লেখা / আইকন / ইমোজির ডিজাইন"},(dialog,which)->{if(which==0)openFeatureCardAdmin("home_menu_"+cfgKey,itemLabel);else if(which==1)startActivity(new Intent(this,GeneralMenuOrderActivity.class));else VisualDesign.edit(this,outer,"home_general");}).show();return true;});applyRipple(item);
            GridLayout.LayoutParams gp=new GridLayout.LayoutParams(GridLayout.spec(visiblePos/4,1f),GridLayout.spec(visiblePos++%4,1f));gp.width=0;gp.height=-2;gp.setMargins(dp(2),dp(2),dp(2),dp(2));grid.addView(item,gp);
        }
        outer.addView(grid,lp(-1,-2));
        addMenuGroup640(outer,"Explore",new String[]{"External","Store","Video","General","History"},new int[]{R.drawable.home590_external,R.drawable.home609_store,R.drawable.home590_video,R.drawable.home590_general,R.drawable.home590_history},new Runnable[]{()->startActivity(new Intent(this,MediaHubActivity.class).putExtra("section","external")),()->startActivity(new Intent(this,StoreActivity.class)),()->startActivity(new Intent(this,ShortVideoActivity.class)),()->startActivity(new Intent(this,GeneralUsersActivity.class)),()->startActivity(new Intent(this,WatchHistoryActivity.class))});
        addMenuGroup640(outer,"Quick Links",new String[]{"Page","Website","My Level","Top Up","Earn Rewards","Gallery","Support","More Apps","Language","All Features"},new int[]{R.drawable.premium438_page,R.drawable.premium438_globe,R.drawable.premium438_star,R.drawable.premium438_crown,R.drawable.premium438_gift,R.drawable.premium438_gallery,R.drawable.premium438_headphones,R.drawable.premium438_more,R.drawable.premium438_globe,R.drawable.premium438_more},new Runnable[]{()->openHomeShortcut(0),()->openHomeShortcut(1),()->openHomeShortcut(2),()->openHomeShortcut(8),()->openHomeShortcut(4),()->startActivity(new Intent(this,GalleryActivity.class)),()->openSupport(),()->showMoreQuickActions(),()->LanguageManager.showPicker(this,()->recreate()),()->startActivity(new Intent(this,UserMenuActivity.class))});
        if(SessionManager.isAdmin(this))addMenuGroup640(outer,"Admin",new String[]{"Admin"},new int[]{R.drawable.premium438_crown},new Runnable[]{()->startActivity(new Intent(this,AdminCatalogActivity.class).putExtra("admin_context",true))});
        MenuGrid641.install(this,outer); ScrollView menuScroll640=new ScrollView(this);menuScroll640.addView(outer);AlertDialog dialog=new MyShopDialogBuilder(this).setView(menuScroll640).create(); close.setOnClickListener(v->dialog.dismiss()); dialog.show(); Window w=dialog.getWindow(); if(w!=null){w.setBackgroundDrawable(round(Color.TRANSPARENT,Color.TRANSPARENT,22)); WindowManager.LayoutParams wp=w.getAttributes(); wp.width=Math.min(getResources().getDisplayMetrics().widthPixels-dp(18),dp(560)); w.setAttributes(wp); w.setDimAmount(.52f); w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);}
    }

    private void addMenuGroup640(LinearLayout outer,String title,String[] labels,int[] icons,Runnable[] actions){
        TextView heading=text(UiStrings.label(this,title),AppThemePalette.current(this).text,13,true);heading.setTag(title);heading.setPadding(dp(6),dp(10),0,dp(5));outer.addView(heading,lp(-1,-2));
        GridLayout grid=new GridLayout(this);grid.setColumnCount(4);
        for(int at=0;at<labels.length;at++){final int index=at;LinearLayout cell=quickCell(icons[at],labels[at]);cell.setTag(R.id.visual_design_key,"element_menu640_"+title+"_"+at);cell.setMinimumHeight(dp(84));cell.setOnClickListener(v->actions[index].run());cell.setOnLongClickListener(v->{if(!SessionManager.isAdmin(this))return false;new MyShopDialogBuilder(this).setTitle(labels[index]).setItems(new String[]{"এডমিন প্যানেল","আইকন মাপ / অবস্থান","লেখার রং / ফন্ট মাপ","Admin / Moderator কমেন্ট"},(dialog,which)->{if(which==3)startActivity(new Intent(this,AdminCommentStyle640Activity.class));else if(which==0)actions[index].run();else if(which==1)startActivity(new Intent(this,PageIconAdminActivity.class).putExtra("page","home1"));else VisualDesign.edit(this,outer,"home_general");}).show();return true;});GridLayout.LayoutParams params=new GridLayout.LayoutParams(GridLayout.spec(at/4),GridLayout.spec(at%4,1f));params.width=0;params.height=-2;grid.addView(cell,params);}
        // Reserve all four columns even when the final row is incomplete.
        for(int at=labels.length;at%4!=0;at++){View spacer=new View(this);GridLayout.LayoutParams params=new GridLayout.LayoutParams(GridLayout.spec(at/4),GridLayout.spec(at%4,1f));params.width=0;params.height=1;grid.addView(spacer,params);}outer.addView(grid,lp(-1,-2));
    }

    private void applyHomeMenuConfig(JSONArray links){homeMenuConfigs.clear();if(links==null)return;for(int i=0;i<links.length();i++){JSONObject x=links.optJSONObject(i);if(x==null)continue;String c=x.optString("category","").trim().toLowerCase(java.util.Locale.US);if(c.startsWith("home_menu_"))homeMenuConfigs.add(x);}java.util.Collections.sort(homeMenuConfigs,(a,b)->Integer.compare(Math.max(1,a.optInt("display_order",999)),Math.max(1,b.optInt("display_order",999))));}
    private JSONObject findHomeMenuConfig(String key){String wanted="home_menu_"+key;if(homeMenuConfigs==null)return null;for(JSONObject x:homeMenuConfigs)if(x!=null&&wanted.equalsIgnoreCase(x.optString("category","")))return x;return null;}

    private void openHomeMenuFeature(String key,String title){FeatureAccess.open(this,"home_menu_"+key,()->openHomeMenuFeatureAllowed(key,title));}
    private void openHomeMenuFeatureAllowed(String key,String title){
        if("agent".equals(key)){startActivity(new Intent(this,AgencyActivity.class));return;}
        if(SessionManager.isAdmin(this)){openFeatureCardAdmin("home_menu_"+key,title);return;}
        try{JSONObject cfg=findHomeMenuConfig(key);if(cfg!=null){String target=cfg.optString("url","").trim();String status=cfg.optString("status",cfg.optInt("active",1)==1?"ACTIVE":"DISABLED");if(!"ACTIVE".equalsIgnoreCase(status)){startActivity(new Intent(this,FeatureActivity.class).putExtra("title",title).putExtra("feature_key","home_menu_"+key));return;}if(FeatureRegistry.isSafeHttpUrl(target)){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));return;}}switch(key){case "agent":startActivity(new Intent(this,AgentActivity.class));break;case "my_links":openManagedFeature("My Links","home_menu_my_links");break;case "deals":startActivity(new Intent(this,PhysicalStoreActivity.class).putExtra("folder",1));break;case "whats_new":openManagedFeature("What’s New","home_menu_whats_new");break;case "my_tasks":openManagedFeature("My Tasks","home_menu_my_tasks");break;case "shorts":startActivity(new Intent(this,ShortVideoActivity.class));break;case "events":openManagedFeature("Events","home_menu_events");break;case "flash_sale":startActivity(new Intent(this,PhysicalStoreActivity.class).putExtra("folder",2));break;case "invite":startActivity(new Intent(this,MyInviteActivity.class));break;default:openManagedFeature("Safety & Privacy","home_menu_safety_privacy");break;}}catch(Exception e){toast(title+" is not configured yet.");}
    }

    private void openManagedFeature(String title,String category){FeatureAccess.open(this,category,()->openManagedFeatureAllowed(title,category));}
    private void openManagedFeatureAllowed(String title,String category){
        String url=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("managed_url_"+category,"").trim(); String savedTitle=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("managed_title_"+category,"").trim();
        if(FeatureRegistry.isSafeHttpUrl(url)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));return;}catch(Exception ignored){}}
        Intent i=new Intent(this,FeatureActivity.class);i.putExtra("title",savedTitle.isEmpty()?title:savedTitle);i.putExtra("feature_key",category);startActivity(i);
    }


    private View breaking(){
        LinearLayout b=row(); breakingBox=b;
        b.setPadding(dp(5),dp(1),dp(5),dp(1));
        b.setBackground(round(Color.WHITE,Color.TRANSPARENT,11));
        Appearance.preserve(b);

        TextView megaphone=text("📣",Color.rgb(235,35,53),26,true);
        megaphone.setGravity(Gravity.CENTER);
        megaphone.setContentDescription("Breaking news");
        b.setClipChildren(true);b.setClipToPadding(true);b.addView(megaphone,lp(dp(44),dp(40)));

        ObjectAnimator sx=ObjectAnimator.ofFloat(megaphone,"scaleX",.96f,1.10f,.96f);
        ObjectAnimator sy=ObjectAnimator.ofFloat(megaphone,"scaleY",.96f,1.10f,.96f);
        ObjectAnimator al=ObjectAnimator.ofFloat(megaphone,"alpha",1f,.48f,1f);
        sx.setRepeatCount(ValueAnimator.INFINITE); sy.setRepeatCount(ValueAnimator.INFINITE); al.setRepeatCount(ValueAnimator.INFINITE);
        sx.setDuration(1250); sy.setDuration(1250); al.setDuration(1250);
        AnimatorSet glow=new AnimatorSet(); glow.playTogether(sx,sy,al); glow.start();

        newsTextSizeSp=Math.max(newsTextSizeSp,13.0f);
        newsText=text("আপনার উন্নয়ন ও নতুন ফিচার যুক্ত করার খবর এখানে দেখাবে",Color.rgb(65,70,98),newsTextSizeSp,true);
        newsText.setGravity(Gravity.CENTER_VERTICAL);
        newsText.setSingleLine(true);
        newsText.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        newsText.setMarqueeRepeatLimit(-1);
        newsText.setSelected(true);
        newsText.setHorizontallyScrolling(true);
        newsText.setPadding(dp(5),0,dp(5),0);
        b.addView(newsText,weight(1,dp(40)));

        b.setOnClickListener(v->{if(SessionManager.isAdmin(this)){Intent i=new Intent(this,AdminSectionActivity.class);i.putExtra("section","dashboard");i.putExtra("admin_context",true);startActivity(i);}});
        applyRipple(b);
        return b;
    }

    private View doublePromos(){
        LinearLayout r=row();ImageView a=pic(left[0]),b=pic(right[0]);promoViews[0]=a;promoViews[1]=b;a.setScaleType(ImageView.ScaleType.CENTER_CROP);b.setScaleType(ImageView.ScaleType.CENTER_CROP);
        View.OnTouchListener promoTouch=(v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){promoDownX=e.getX();promoDownY=e.getY();v.getParent().requestDisallowInterceptTouchEvent(true);return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){float dx=e.getX()-promoDownX,dy=e.getY()-promoDownY;if(Math.abs(dy)>Math.abs(dx)&&Math.abs(dy)>dp(8)){v.getParent().requestDisallowInterceptTouchEvent(false);return false;}return true;}if(e.getAction()==MotionEvent.ACTION_UP){v.getParent().requestDisallowInterceptTouchEvent(false);float dx=e.getX()-promoDownX;if(Math.abs(dx)>dp(36)){promoSlide=(promoSlide+(dx<0?1:promoCount()-1))%promoCount();applyPromoSlide();schedulePromoCarousel();}else{if(SessionManager.isAdmin(this))startActivity(new Intent(this,BannerAdminActivity.class).putExtra("admin_context",true));else openPromoTarget(v==a?0:1);}return true;}if(e.getAction()==MotionEvent.ACTION_CANCEL)v.getParent().requestDisallowInterceptTouchEvent(false);return true;};a.setOnTouchListener(promoTouch);b.setOnTouchListener(promoTouch);
        r.addView(a,weight(1,dp(74)));r.addView(space(),lp(dp(6),1));r.addView(b,weight(1,dp(74)));return r;
    }

    private View sectionTitle(String title,boolean all){
        LinearLayout h=row(); h.addView(text(title,DARK,13,true),weight(1,dp(28))); if(all){TextView a=text("View All",BLUE,9.5f,true);a.setGravity(Gravity.CENTER);a.setOnClickListener(v->openFeature("LIVE","live_now"));h.addView(a,lp(dp(58),dp(28)));} return h;
    }

    private View liveRow(){
        realLiveProfilesRow=row(); realLiveProfilesRow.setGravity(Gravity.CENTER_VERTICAL); realLiveProfilesRow.setPadding(dp(1),0,dp(1),0);
        loadRealLiveProfiles();
        return realLiveProfilesRow;
    }

    private void loadRealLiveProfiles(){
        if(realLiveProfilesRow==null||liveProfilesLoading)return;
        liveProfilesLoading=true;
        BackendClient.liveProfiles(SessionManager.getToken(this),4,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){if(dashboardDestroyed)return;runOnUiThread(()->{if(dashboardDestroyed)return;liveProfilesLoading=false;renderRealLiveProfiles(d.optJSONArray("profiles"));applyPortalSignals(d);});}
            public void onError(String m){if(dashboardDestroyed)return;runOnUiThread(()->{if(dashboardDestroyed)return;liveProfilesLoading=false;renderRealLiveProfiles(null);});}
        });
    }
    private void renderRealLiveProfiles(JSONArray a){
        if(realLiveProfilesRow==null)return; realLiveProfilesRow.removeAllViews();
        int shown=0;
        if(a!=null)for(int i=0;i<a.length()&&shown<4;i++){
            JSONObject x=a.optJSONObject(i);if(x==null)continue;
            final String uid=x.optString("userId","");
            final String nm=x.optString("name",x.optBoolean("live",false)?"Live":"New User");
            String av=x.optString("avatarUrl","");
            int viewers=x.optInt("viewerCount",0);
            boolean isLive=x.optBoolean("live",true);
            final String relation=x.optString("state","NONE");
            LinearLayout wrap=col();wrap.setGravity(Gravity.CENTER_HORIZONTAL);wrap.setPadding(dp(4),dp(3),dp(4),dp(3));wrap.setBackground(round(Color.WHITE,Color.rgb(226,229,240),14));
            FrameLayout card=new FrameLayout(this);card.setBackground(round(Color.WHITE,isLive?Color.rgb(255,55,186):Color.rgb(210,216,238),26));
            ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setImageResource(R.drawable.myshop_profile_avatar);im.setClipToOutline(true);if(!av.isEmpty())loadRemoteImage(im,av);card.addView(im,new FrameLayout.LayoutParams(dp(66),dp(66),Gravity.CENTER));
            
            if(isLive){ObjectAnimator px=ObjectAnimator.ofFloat(card,"scaleX",1f,1.035f,1f);ObjectAnimator py=ObjectAnimator.ofFloat(card,"scaleY",1f,1.035f,1f);px.setRepeatCount(ValueAnimator.INFINITE);py.setRepeatCount(ValueAnimator.INFINITE);px.setDuration(1250);py.setDuration(1250);AnimatorSet pulse=new AnimatorSet();pulse.playTogether(px,py);pulse.start();}
            wrap.addView(card,lp(dp(78),dp(78)));
            TextView nameView=text(nm,NAVY,10.2f,true);AuthorityBadge.decorate(nameView,uid);nameView.setGravity(Gravity.CENTER);nameView.setSingleLine(true);nameView.setEllipsize(TextUtils.TruncateAt.END);if(Build.VERSION.SDK_INT>=26)nameView.setAutoSizeTextTypeUniformWithConfiguration(8,11,1,android.util.TypedValue.COMPLEX_UNIT_SP);wrap.addView(nameView,lp(-1,dp(18)));
            LinearLayout meta=row();meta.setGravity(Gravity.CENTER);TextView idv=text("🆔 "+uid,MUTED,8.6f,true);idv.setSingleLine(true);TextView lv=text("LV."+Math.max(0,x.optInt("level",0)),NAVY,8.6f,true);lv.setSingleLine(true);if(AuthorityBadge.isAuthority(uid))lv.setVisibility(View.GONE);meta.addView(idv,lp(-2,dp(18)));meta.addView(space(),lp(dp(6),1));meta.addView(lv,lp(-2,dp(18)));wrap.addView(meta,lp(-1,dp(19)));
            if(isLive){TextView vc=text(viewers>0?"◉ "+compactCount(viewers):"",MUTED,8.2f,true);vc.setGravity(Gravity.CENTER);wrap.addView(vc,lp(dp(78),dp(12)));}
            else{
                TextView add=fixedFriendAction(relation);
                if("FRIEND".equals(relation)){add.setEnabled(false);add.setAlpha(.78f);}else if("REQUESTED".equals(relation)){add.setAlpha(.86f);add.setOnClickListener(v->cancelFriendRequest(uid,add));}else if("INCOMING".equals(relation)){add.setOnClickListener(v->startActivity(new Intent(this,FriendRequestsActivity.class)));}else{add.setOnClickListener(v->{try{JSONObject person=new JSONObject().put("userId",uid).put("state",relation);sendFriendRequest(person,add);}catch(Exception ignored){}});}LinearLayout.LayoutParams abp=lp(-1,dp(30));abp.setMargins(dp(3),0,dp(3),0);wrap.addView(add,abp);
            }
            wrap.setOnClickListener(v->{if(isLive){openFeature(nm,"live_now");}else{Intent q=new Intent(MainActivity.this,UserProfileActivity.class);q.putExtra("userId",uid);startActivity(q);}});
            realLiveProfilesRow.addView(wrap,weight(1,isLive?dp(132):dp(148)));shown++;
        }
        if(shown==0){ renderDynamicFoldersFallbackForLive(); }
    }
    private String compactCount(int n){if(n>=1000000)return String.format(java.util.Locale.US,"%.1fM",n/1000000f);if(n>=1000)return String.format(java.util.Locale.US,"%.1fK",n/1000f);return String.valueOf(n);}
    private void renderDynamicFoldersFallbackForLive(){
        if(realLiveProfilesRow==null)return;
        int shown=0;
        for(int i=0;i<newPeopleData.size()&&shown<4;i++){
            JSONObject p=newPeopleData.get(i);if(p==null)continue;
            final String uid=p.optString("userId","");final String relation=p.optString("state","NONE");String nm=p.optString("name","New User"),av=p.optString("avatarUrl","");
            LinearLayout wrap=col();wrap.setGravity(Gravity.CENTER_HORIZONTAL);wrap.setPadding(dp(4),dp(3),dp(4),dp(3));wrap.setBackground(round(Color.WHITE,Color.rgb(226,229,240),14));
            FrameLayout card=new FrameLayout(this);card.setBackground(round(Color.WHITE,Color.rgb(210,216,238),26));
            ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setImageResource(R.drawable.myshop_profile_avatar);im.setClipToOutline(true);if(!av.isEmpty())loadRemoteImage(im,av);card.addView(im,new FrameLayout.LayoutParams(dp(66),dp(66),Gravity.CENTER));if(p.optBoolean("online",false)){View dot2=new View(this);dot2.setBackground(round(GREEN,Color.WHITE,20));FrameLayout.LayoutParams d2=new FrameLayout.LayoutParams(dp(7),dp(7),Gravity.BOTTOM|Gravity.RIGHT);d2.rightMargin=dp(5);d2.bottomMargin=dp(9);card.addView(dot2,d2);}wrap.addView(card,lp(dp(78),dp(78)));
            TextView t=text(nm,NAVY,10.2f,true);AuthorityBadge.decorate(t,uid);t.setGravity(Gravity.CENTER);t.setSingleLine(true);t.setEllipsize(TextUtils.TruncateAt.END);if(Build.VERSION.SDK_INT>=26)t.setAutoSizeTextTypeUniformWithConfiguration(8,11,1,android.util.TypedValue.COMPLEX_UNIT_SP);wrap.addView(t,lp(-1,dp(18)));
            LinearLayout meta=row();meta.setGravity(Gravity.CENTER);TextView idv=text("🆔 "+uid,MUTED,8.6f,true);idv.setSingleLine(true);TextView lv=text("LV."+Math.max(0,p.optInt("level",0)),NAVY,8.6f,true);lv.setSingleLine(true);if(AuthorityBadge.isAuthority(uid))lv.setVisibility(View.GONE);meta.addView(idv,lp(-2,dp(18)));meta.addView(space(),lp(dp(6),1));meta.addView(lv,lp(-2,dp(18)));wrap.addView(meta,lp(-1,dp(19)));
            TextView add=fixedFriendAction(relation);
            if("FRIEND".equals(relation)){add.setEnabled(false);add.setAlpha(.78f);}else if("REQUESTED".equals(relation)){add.setAlpha(.86f);add.setOnClickListener(v->cancelFriendRequest(uid,add));}else if("INCOMING".equals(relation)){add.setOnClickListener(v->startActivity(new Intent(this,FriendRequestsActivity.class)));}else add.setOnClickListener(v->sendFriendRequest(p,add));LinearLayout.LayoutParams abp=lp(-1,dp(30));abp.setMargins(dp(3),dp(1),dp(3),0);wrap.addView(add,abp);
            wrap.setOnClickListener(v->{Intent q=new Intent(MainActivity.this,UserProfileActivity.class);q.putExtra("userId",uid);startActivity(q);});realLiveProfilesRow.addView(wrap,weight(1,dp(148)));shown++;
        }
        for(;shown<4;shown++){LinearLayout wrap=col();wrap.setGravity(Gravity.CENTER_HORIZONTAL);wrap.setPadding(dp(3),dp(2),dp(3),dp(2));wrap.setBackground(round(Color.WHITE,Color.rgb(232,234,242),12));View circle=new View(this);circle.setBackground(round(Color.rgb(238,240,246),Color.rgb(226,229,238),28));wrap.addView(circle,lp(dp(58),dp(58)));View line1=new View(this);line1.setBackground(round(Color.rgb(238,240,246),Color.TRANSPARENT,6));LinearLayout.LayoutParams l1=lp(dp(58),dp(10));l1.topMargin=dp(6);wrap.addView(line1,l1);View line2=new View(this);line2.setBackground(round(Color.rgb(242,243,248),Color.TRANSPARENT,6));LinearLayout.LayoutParams l2=lp(dp(70),dp(20));l2.topMargin=dp(7);wrap.addView(line2,l2);ObjectAnimator a=ObjectAnimator.ofFloat(wrap,"alpha",.55f,1f,.55f);a.setDuration(1100);a.setRepeatCount(ValueAnimator.INFINITE);a.start();realLiveProfilesRow.addView(wrap,weight(1,dp(156)));}
    }

    /** V-230: dynamic dashboard content remains INSIDE the existing small circular/live row.
     * No second placeholder row is created. Each slot has its own Admin editor. */
    private void renderDynamicFolders(JSONArray a){
        if(dynamicFolderBox==null)return;
        dynamicFolderBox.removeAllViews();
        JSONObject[] slots=new JSONObject[6];
        if(a!=null){
            for(int i=0;i<a.length();i++){
                JSONObject x=a.optJSONObject(i); if(x==null)continue;
                String cat=x.optString("category","").trim().toLowerCase();
                if(cat.startsWith("dashboard_slot_")){
                    try{int n=Integer.parseInt(cat.substring("dashboard_slot_".length()));if(n>=1&&n<=6&&slots[n-1]==null)slots[n-1]=x;}catch(Exception ignored){}
                }
            }
        }
        String[] defaults={"Shopping Live","Gadget Live","Fashion Live","Gaming Live","Beauty Live","AD"};
        String[] viewers={"1.2K","956","743","2.1K","1.8K",""};
        for(int i=0;i<6;i++){
            JSONObject cfg=slots[i];
            boolean slotActive=cfg==null || cfg.optInt("active",1)==1;
            boolean adminMode=SessionManager.isAdmin(this);
            if(!slotActive && !adminMode) continue; // hidden for normal users; Admin can still tap to restore
            LinearLayout wrap=col(); wrap.setGravity(Gravity.CENTER_HORIZONTAL); wrap.setPadding(dp(2),0,dp(2),0); wrap.setAlpha(slotActive?1f:0.48f);
            String title=cfg==null?defaults[i]:cfg.optString("title",defaults[i]).trim(); if(title.isEmpty())title=defaults[i]; if(!slotActive&&adminMode)title=title+" • HIDDEN";
            String caption=cfg==null?"":cfg.optString("caption","").trim();
            String url=cfg==null?"":cfg.optString("url","").trim();
            String image=cfg==null?"":cfg.optString("image_url","").trim();
            String iconUrl=cfg==null?"":cfg.optString("icon_url","").trim();
            FrameLayout card=new FrameLayout(this); card.setBackground(round(Color.WHITE,Color.rgb(255,72,182),40));
            ImageView im=new ImageView(this); im.setScaleType(ImageView.ScaleType.CENTER_CROP); im.setBackground(round(Color.WHITE,Color.TRANSPARENT,40)); im.setClipToOutline(true);
            if(i==5) im.setTag("live_folder_ad");
            if(!image.isEmpty())loadRemoteImage(im,image); else if(!iconUrl.isEmpty())loadRemoteImage(im,iconUrl); else im.setImageResource(i==5?R.drawable.banner_top_left_3:live[i%live.length]);
            card.addView(im,new FrameLayout.LayoutParams(dp(52),dp(52),Gravity.CENTER));
            TextView badge=text("● LIVE",Color.WHITE,6.3f,true); badge.setGravity(Gravity.CENTER); badge.setBackground(round(RED,Color.TRANSPARENT,8)); FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(dp(50),dp(16),Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL); card.addView(badge,bp);
            wrap.addView(card,lp(dp(56),dp(58)));
            final int slot=i+1; final String target=url; final String slotTitle=title;
            wrap.setOnClickListener(v->{
                if(SessionManager.isAdmin(this)){openFeatureCardAdmin("dashboard_slot_"+slot,"DASHBOARD SLOT "+slot);return;}
                if(FeatureRegistry.isSafeHttpUrl(target)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception ignored){}}
                else if(slot<=5)openFeature(slotTitle,"live_now");
            });
            dynamicFolderBox.addView(wrap,weight(1,dp(64)));
        }
    }

    private View liveStreamingSection(){
        LinearLayout row=row();row.setGravity(Gravity.CENTER_VERTICAL);row.setClipChildren(false);row.setClipToPadding(false);
        View store=homePortal(false,"myshop","Shop • Buy • Earn",new int[]{Color.rgb(255,176,34),Color.rgb(238,91,33),Color.rgb(255,117,20)});store.setOnClickListener(v->FeatureAccess.open(this,"my_shop",()->startActivity(new Intent(this,PhysicalStoreActivity.class))));
        View live=homePortal(true,"LIVE STREAMING","Go Live • Join Live • Enjoy",new int[]{Color.rgb(4,126,255),Color.rgb(25,60,220),Color.rgb(131,36,236)});live.setOnClickListener(v->startActivity(new Intent(this,LiveHomeActivity.class)));
        LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(0,dp(50),42f);a.rightMargin=dp(8);row.addView(store,a);row.addView(live,new LinearLayout.LayoutParams(0,dp(50),58f));
        if(SessionManager.isAdmin(this))row.setOnLongClickListener(v->{Intent i=new Intent(this,AdminCatalogActivity.class);i.putExtra("admin_context",true);startActivity(i);return true;});return row;
    }
    private View homePortal(boolean isLive,String title,String subtitle,int[] colors){
        FrameLayout shell=new FrameLayout(this);shell.setClipChildren(false);shell.setClipToPadding(false);GradientDrawable bg=gradient(colors[0],colors[colors.length-1],17);shell.setBackground(bg);shell.setElevation(dp(4));
        LinearLayout line=row();line.setGravity(Gravity.CENTER_VERTICAL);line.setPadding(dp(7),0,dp(6),0);
        View icon;
        if(isLive){BroadcastSignalView sig=new BroadcastSignalView(this);sig.setContentDescription("Live broadcast microphone and signal");icon=sig;}else{ImageView bag=new ImageView(this);bag.setImageResource(R.drawable.premium438_bag);bag.setScaleType(ImageView.ScaleType.CENTER_INSIDE);bag.setContentDescription("myshop bag");icon=bag;}
        line.addView(icon,lp(dp(36),dp(36)));
        LinearLayout copy=col();copy.setGravity(Gravity.CENTER_VERTICAL);TextView t=text(title,Color.WHITE,isLive?10.4f:10.8f,true);t.setSingleLine(true);if(isLive){SpannableString sp=new SpannableString(title);sp.setSpan(new ForegroundColorSpan(Color.WHITE),0,4,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);sp.setSpan(new ForegroundColorSpan(Color.rgb(25,226,255)),5,title.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);t.setText(sp);}copy.addView(t,lp(-1,dp(21)));TextView sub=text(subtitle,Color.rgb(244,247,255),7.2f,false);sub.setSingleLine(true);copy.addView(sub,lp(-1,dp(15)));line.addView(copy,weight(1,dp(38)));
        shell.addView(line,new FrameLayout.LayoutParams(-1,-1));
        TextView badge=text("",Color.WHITE,7.2f,true);badge.setGravity(Gravity.CENTER);badge.setVisibility(View.GONE);badge.setBackground(round(isLive?RED:Color.rgb(238,61,166),Color.WHITE,10));FrameLayout.LayoutParams badgeLp=new FrameLayout.LayoutParams(dp(54),dp(18),Gravity.TOP|Gravity.RIGHT);badgeLp.topMargin=dp(2);badgeLp.rightMargin=dp(3);shell.addView(badge,badgeLp);if(isLive){livePortalBadge=badge;followedHostPreview=new ImageView(this);followedHostPreview.setScaleType(ImageView.ScaleType.CENTER_CROP);followedHostPreview.setClipToOutline(true);followedHostPreview.setVisibility(View.GONE);followedHostPreview.setBackground(round(Color.WHITE,Color.rgb(255,108,207),12));FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(dp(22),dp(22),Gravity.BOTTOM|Gravity.RIGHT);fp.rightMargin=dp(5);fp.bottomMargin=dp(2);shell.addView(followedHostPreview,fp);upcomingLiveText=text("",Color.rgb(255,239,164),6.8f,true);upcomingLiveText.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);upcomingLiveText.setVisibility(View.GONE);upcomingLiveText.setOnClickListener(v->{if(upcomingScheduleId<=0)return;upcomingLiveText.setEnabled(false);BackendClient.liveScheduleReminder(SessionManager.getToken(this),upcomingScheduleId,new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->{upcomingLiveText.setEnabled(true);Toast.makeText(MainActivity.this,x.optBoolean("reminded",true)?"Live reminder set":"Live reminder removed",Toast.LENGTH_SHORT).show();});}public void onError(String m){runOnUiThread(()->{upcomingLiveText.setEnabled(true);Toast.makeText(MainActivity.this,m,Toast.LENGTH_SHORT).show();});}});});FrameLayout.LayoutParams up=new FrameLayout.LayoutParams(dp(92),dp(16),Gravity.BOTTOM|Gravity.RIGHT);up.rightMargin=dp(29);up.bottomMargin=0;shell.addView(upcomingLiveText,up);}else premiumPortalBadge=badge;
        applyRipple(shell);return shell;
    }
    private void applyPortalSignals(JSONObject d){int liveCount=Math.max(0,d.optInt("liveCount",0));if(livePortalBadge!=null){livePortalBadge.setText(liveCount>0?"● "+liveCount+" LIVE":"");livePortalBadge.setVisibility(liveCount>0?View.VISIBLE:View.GONE);}int pending=Math.max(0,d.optInt("pendingPremium",0)),fresh=Math.max(0,d.optInt("newPremium",0));if(premiumPortalBadge!=null){String label=pending>0?"PENDING "+pending:fresh>0?"NEW "+fresh:"";premiumPortalBadge.setText(label);premiumPortalBadge.setVisibility(label.isEmpty()?View.GONE:View.VISIBLE);}JSONArray profiles=d.optJSONArray("profiles");String followedAvatar="";if(profiles!=null)for(int i=0;i<profiles.length();i++){JSONObject p=profiles.optJSONObject(i);if(p!=null&&p.optBoolean("live",false)&&p.optBoolean("followed",false)){followedAvatar=p.optString("avatarUrl","");break;}}if(followedHostPreview!=null){followedHostPreview.setVisibility(followedAvatar.isEmpty()?View.GONE:View.VISIBLE);if(!followedAvatar.isEmpty())loadRemoteImage(followedHostPreview,followedAvatar);}JSONObject upcoming=d.optJSONObject("upcomingLive");handler.removeCallbacks(upcomingCountdownTick);upcomingScheduleId=upcoming==null?0L:upcoming.optLong("id",0);upcomingLiveAt=upcoming==null?0L:parseServerTime(upcoming.optString("scheduled_at",""));if(upcomingLiveAt>0)upcomingCountdownTick.run();else if(upcomingLiveText!=null)upcomingLiveText.setVisibility(View.GONE);}
    private long parseServerTime(String raw){if(raw==null||raw.trim().isEmpty())return 0L;String s=raw.trim().replace('T',' ').replace("Z","");String[] patterns={"yyyy-MM-dd HH:mm:ss.SSS","yyyy-MM-dd HH:mm:ss","yyyy-MM-dd HH:mm"};for(String pattern:patterns)try{java.text.SimpleDateFormat f=new java.text.SimpleDateFormat(pattern,java.util.Locale.US);f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));f.setLenient(false);java.util.Date date=f.parse(s);if(date!=null)return date.getTime();}catch(Exception ignored){}return 0L;}
    private static class BroadcastSignalView extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private final RectF r=new RectF();private float phase=0f;private ValueAnimator animator;
        BroadcastSignalView(Context c){super(c);p.setStrokeCap(Paint.Cap.ROUND);setLayerType(View.LAYER_TYPE_SOFTWARE,null);if(!false){animator=ValueAnimator.ofFloat(0f,1f);animator.setDuration(1450);animator.setRepeatCount(ValueAnimator.INFINITE);animator.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());animator.addUpdateListener(a->{phase=(float)a.getAnimatedValue();invalidate();});animator.start();}}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f,min=Math.min(w,h);float wave=(float)(.5f+.5f*Math.sin(phase*Math.PI*2f));int cyan=Color.rgb(37,230,255),violet=Color.rgb(117,66,255),pink=Color.rgb(255,64,190);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(2.3f,min*.064f));for(int i=0;i<2;i++){float rr=min*(.29f+i*.14f+.025f*wave);p.setColor(i==0?cyan:pink);p.setAlpha(155+(int)(85*((phase+i*.28f)%1f)));p.setShadowLayer(min*.07f,0,0,i==0?cyan:pink);r.set(cx-rr,cy-rr,cx+rr,cy+rr);c.drawArc(r,-58,116,false,p);c.drawArc(r,122,116,false,p);}p.clearShadowLayer();p.setStyle(Paint.Style.FILL);p.setColor(violet);p.setAlpha(255);p.setShadowLayer(min*.13f,0,0,pink);r.set(cx-min*.105f,cy-min*.235f,cx+min*.105f,cy+min*.095f);c.drawRoundRect(r,min*.10f,min*.10f,p);p.clearShadowLayer();p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(2.2f,min*.065f));p.setColor(cyan);p.setAlpha(245);r.set(cx-min*.19f,cy-min*.08f,cx+min*.19f,cy+min*.22f);c.drawArc(r,0,180,false,p);c.drawLine(cx,cy+min*.22f,cx,cy+min*.31f,p);c.drawLine(cx-min*.11f,cy+min*.31f,cx+min*.11f,cy+min*.31f,p);p.setStyle(Paint.Style.FILL);p.setColor(pink);p.setAlpha(175+(int)(80*wave));c.drawCircle(cx,cy-min*.08f,min*(.035f+.018f*wave),p);}
        @Override protected void onDetachedFromWindow(){if(animator!=null)animator.cancel();super.onDetachedFromWindow();}
    }
    private static class PremiumCrownView extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private final android.graphics.Path path=new android.graphics.Path();private float phase=0f;private ValueAnimator animator;
        PremiumCrownView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);if(!false){animator=ValueAnimator.ofFloat(0f,1f);animator.setDuration(1900);animator.setRepeatCount(ValueAnimator.INFINITE);animator.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());animator.addUpdateListener(a->{phase=(float)a.getAnimatedValue();invalidate();});animator.start();}}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),cx=w/2f,min=Math.min(w,h);int gold=Color.rgb(255,202,54),pink=Color.rgb(255,68,187),violet=Color.rgb(126,62,255);float shimmer=(float)(.5f+.5f*Math.sin(phase*Math.PI*2f));path.reset();path.moveTo(w*.17f,h*.67f);path.lineTo(w*.22f,h*.31f);path.lineTo(w*.43f,h*.49f);path.lineTo(cx,h*.20f);path.lineTo(w*.57f,h*.49f);path.lineTo(w*.78f,h*.31f);path.lineTo(w*.83f,h*.67f);path.close();p.setStyle(Paint.Style.FILL);p.setShader(new android.graphics.LinearGradient(w*.16f,h*.25f,w*.84f,h*.73f,new int[]{gold,pink,violet},null,android.graphics.Shader.TileMode.CLAMP));p.setShadowLayer(min*(.08f+.035f*shimmer),0,0,pink);c.drawPath(path,p);p.clearShadowLayer();p.setShader(null);p.setColor(Color.rgb(255,228,119));p.setAlpha(235);c.drawRoundRect(w*.17f,h*.63f,w*.83f,h*.78f,min*.07f,min*.07f,p);p.setColor(Color.WHITE);p.setAlpha(210+(int)(45*shimmer));float sx=w*(.27f+.46f*phase);float sy=h*(.30f+.10f*(float)Math.sin(phase*Math.PI));path.reset();path.moveTo(sx,sy-min*.08f);path.lineTo(sx+min*.025f,sy-min*.025f);path.lineTo(sx+min*.08f,sy);path.lineTo(sx+min*.025f,sy+min*.025f);path.lineTo(sx,sy+min*.08f);path.lineTo(sx-min*.025f,sy+min*.025f);path.lineTo(sx-min*.08f,sy);path.lineTo(sx-min*.025f,sy-min*.025f);path.close();c.drawPath(path,p);p.setColor(Color.rgb(106,55,238));p.setAlpha(255);c.drawCircle(cx,h*.63f,min*.075f,p);p.setColor(Color.WHITE);p.setAlpha(205);c.drawCircle(cx-min*.02f,h*.61f,min*.022f,p);}
        @Override protected void onDetachedFromWindow(){if(animator!=null)animator.cancel();super.onDetachedFromWindow();}
    }

    private View liveProfilesSection(){
        LinearLayout box=col();
        box.setPadding(dp(6),dp(4),dp(6),dp(4));
        box.setBackground(round(Color.WHITE,Color.rgb(229,231,240),16));
        LinearLayout profileHead=row(); profileHead.setGravity(Gravity.CENTER_VERTICAL);
        TextView newTitle=text("●  New Users",NAVY,9.4f,true); newTitle.setTextColor(GREEN); newTitle.setGravity(Gravity.CENTER_VERTICAL); profileHead.addView(newTitle,lp(dp(86),dp(24)));
        TextView status=text("•  Live users first  •  New users when offline",MUTED,7.9f,true); status.setGravity(Gravity.CENTER_VERTICAL); status.setSingleLine(true); status.setEllipsize(TextUtils.TruncateAt.END); profileHead.addView(status,weight(1,dp(24)));
        TextView see=text("See All  →",BLUE,9.2f,true); see.setGravity(Gravity.CENTER); see.setSingleLine(true); see.setOnClickListener(v->showAllNewPeople()); profileHead.addView(see,lp(dp(68),dp(24))); box.addView(profileHead,lp(-1,dp(24)));
        box.addView(liveRow(),lp(-1,dp(158)));
        box.setElevation(dp(1));
        if(SessionManager.isAdmin(this)) box.setOnLongClickListener(v->{Intent a=new Intent(this,AdminSectionActivity.class);a.putExtra("section","dynamic_content");a.putExtra("admin_context",true);startActivity(a);return true;});
        return box;
    }

    private View newPeopleSection(){
        LinearLayout box=col(); box.setPadding(dp(6),dp(4),dp(6),dp(4)); box.setBackground(round(Color.WHITE,Color.rgb(229,231,240),14));
        LinearLayout head=row(); TextView title=text("New People",NAVY,10.5f,true); head.addView(title,weight(1,dp(24))); TextView see=text("See All  →",BLUE,8.5f,true); see.setGravity(Gravity.CENTER); see.setOnClickListener(v->showAllNewPeople()); head.addView(see,lp(dp(76),dp(24))); box.addView(head,lp(-1,dp(24)));
        newPeopleScroll=new HorizontalScrollView(this); newPeopleScroll.setHorizontalScrollBarEnabled(false); newPeopleScroll.setFillViewport(false); newPeopleRow=row(); newPeopleScroll.addView(newPeopleRow,new HorizontalScrollView.LayoutParams(-2,dp(90))); box.addView(newPeopleScroll,lp(-1,dp(90))); return box;
    }

    private void loadNewPeople(){
        String token=SessionManager.getToken(this);if(token==null||token.isEmpty())return;
        renderCachedNewPeople();
        BackendClient.newPeople(token,20,0,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                getSharedPreferences("myshop_people",MODE_PRIVATE).edit().putString("latest",d.toString()).apply();
                applyNewPeoplePayload(d);
            }
            public void onError(String m){ }
        });
    }
    private boolean renderCachedNewPeople(){try{String raw=getSharedPreferences("myshop_people",MODE_PRIVATE).getString("latest","");if(raw.isEmpty())return false;JSONObject cached=new JSONObject(raw);JSONArray people=cached.optJSONArray("people");if(people!=null)for(int i=0;i<people.length();i++){JSONObject p=people.optJSONObject(i);if(p!=null)p.put("online",false);}applyNewPeoplePayload(cached);return true;}catch(Exception e){return false;}}
    private void applyNewPeoplePayload(JSONObject d){JSONArray a=d.optJSONArray("people");newPeopleData.clear();if(a!=null)for(int i=0;i<a.length();i++){JSONObject p=a.optJSONObject(i);if(p!=null&&!SessionManager.getUserId(this).equals(p.optString("userId","")))newPeopleData.add(p);}if(!dashboardDestroyed)runOnUiThread(()->{if(dashboardDestroyed)return;renderNewPeople();/* Standalone block is removed in V-256, but the Live section still needs fresh New User fallback data. */if(realLiveProfilesRow!=null)loadRealLiveProfiles();});}
    private void renderNewPeople(){
        if(newPeopleSection==null||newPeopleRow==null)return;newPeopleRow.removeAllViews();
        if(newPeopleData.isEmpty()){newPeopleSection.setVisibility(View.GONE);return;}
        newPeopleSection.setVisibility(View.VISIBLE);int visible=Math.min(5,newPeopleData.size());int cardWidth=Math.max(dp(66),(getResources().getDisplayMetrics().widthPixels-dp(18))/5);
        for(int i=0;i<visible;i++)newPeopleRow.addView(newPersonCard(newPeopleData.get(i)),lp(cardWidth,dp(88)));
    }
    private View newPersonCard(JSONObject p){
        LinearLayout c=col();c.setGravity(Gravity.CENTER_HORIZONTAL);c.setPadding(dp(2),0,dp(2),0);c.setOnClickListener(v->{Intent q=new Intent(this,UserProfileActivity.class);q.putExtra("userId",p.optString("userId",""));startActivity(q);});
        ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setBackground(round(Color.rgb(239,241,248),Color.rgb(223,226,237),24));av.setClipToOutline(true);String url=p.optString("avatarUrl","");if(!url.isEmpty())loadRemoteImage(av,url);c.addView(av,lp(dp(42),dp(42)));
        TextView name=text(p.optString("name","New Member"),DARK,7.2f,true);name.setGravity(Gravity.CENTER);name.setSingleLine(true);name.setEllipsize(TextUtils.TruncateAt.END);c.addView(name,lp(-1,dp(18)));
        String state=p.optString("state","NONE");TextView add=fixedFriendAction(state);
        if("FRIEND".equals(state)){add.setEnabled(false);add.setAlpha(.78f);}else if("REQUESTED".equals(state)){add.setEnabled(false);add.setAlpha(.72f);}else if("INCOMING".equals(state)){add.setOnClickListener(v->startActivity(new Intent(this,FriendRequestsActivity.class)));}else add.setOnClickListener(v->sendFriendRequest(p,add));
        LinearLayout.LayoutParams abp=lp(-1,dp(24));abp.setMargins(dp(4),0,dp(4),0);c.addView(add,abp);return c;
    }
    /** Fixed/locked action button shell used by every dashboard user card.
     * Keeps icon/text on one line and prevents Add Friend/Respond/Requested/Friends overflow. */
    private TextView fixedFriendAction(String state){
        String label="FRIEND".equals(state)?"✓ Friends":"INCOMING".equals(state)?"Respond":"REQUESTED".equals(state)?"Requested":"＋ Add Friend";
        TextView b=text(label,Color.WHITE,7.8f,true); b.setGravity(Gravity.CENTER); b.setSingleLine(true); b.setMaxLines(1);
        b.setIncludeFontPadding(false); b.setPadding(dp(3),0,dp(3),0); b.setMinWidth(0); b.setMinimumWidth(0);
        int fill="REQUESTED".equals(state)?MUTED:"FRIEND".equals(state)?Color.rgb(28,148,104):BLUE;
        b.setBackground(round(fill,Color.TRANSPARENT,9)); applyRipple(b); return b;
    }

    private void sendFriendRequest(JSONObject person,TextView button){String id=person.optString("userId","");String token=SessionManager.getToken(this);if(token==null||token.isEmpty()||id.isEmpty())return;button.setEnabled(false);BackendClient.sendFriendRequest(token,id,new BackendClient.Callback(){public void onSuccess(JSONObject d){try{person.put("state","REQUESTED");}catch(Exception ignored){}button.setText("Requested");button.setAlpha(.7f);}public void onError(String m){button.setEnabled(true);if(m!=null&&m.toLowerCase().contains("pending")){button.setText("Requested");button.setAlpha(.7f);}else toast(m);}});}
    private void cancelFriendRequest(String userId,TextView button){String token=SessionManager.getToken(this);if(token==null||token.isEmpty()||userId==null||userId.isEmpty())return;button.setEnabled(false);button.setText("Cancelling…");BackendClient.cancelFriendRequest(token,userId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{button.setEnabled(true);button.setAlpha(1f);button.setText("＋ Add Friend");button.setOnClickListener(v->{try{JSONObject person=new JSONObject().put("userId",userId).put("state","NONE");sendFriendRequest(person,button);}catch(Exception ignored){}});});}public void onError(String m){runOnUiThread(()->{button.setEnabled(true);button.setText("Requested");toast(m);});}});}
    private void showAllNewPeople(){startActivity(new Intent(this,NewPeopleActivity.class));}

    private View liveActions(){ return liveStreamingSection(); }

    private View liveAdStrip(){
        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); hs.setFillViewport(false);
        liveAdStripView=hs; liveAdBox=row(); liveAdBox.setPadding(dp(4),dp(4),dp(4),dp(4)); liveAdBox.setBackground(round(Color.WHITE,Color.rgb(232,233,238),16));
        renderPowerAds();
        hs.addView(liveAdBox,new HorizontalScrollView.LayoutParams(-2,dp(92))); return hs;
    }

    private void renderPowerAds(){
        if(liveAdBox!=null){ liveAdBox.removeAllViews(); liveAdBox.setVisibility(View.GONE); }
        if(liveAds.isEmpty()) return;
        int n=Math.min(20,liveAds.size()); JSONObject a=liveAds.get(liveAdIndex%n);
        final ImageView target=findLiveFolderAd(); if(target==null)return;
        String u=a.optString("image_url",""); if(!u.isEmpty())loadRemoteImage(target,u);
        target.setOnClickListener(v->{if(SessionManager.isAdmin(this)){startActivity(new Intent(this,DashboardAdsAdminActivity.class).putExtra("admin_context",true).putExtra("box_key","live_now"));return;}String t=a.optString("target_url","");if(FeatureRegistry.isSafeHttpUrl(t)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(t)));}catch(Exception ignored){}}});
    }
    private ImageView findLiveFolderAd(){ if(scroll==null)return null; return findImageByTag(scroll,"live_folder_ad"); }
    private ImageView findImageByTag(View v,String tag){ if(v instanceof ViewGroup){ ViewGroup g=(ViewGroup)v; for(int i=0;i<g.getChildCount();i++){View c=g.getChildAt(i);if(tag.equals(c.getTag())&&c instanceof ImageView)return (ImageView)c; ImageView r=findImageByTag(c,tag);if(r!=null)return r;}} return null; }

    private View mainFeatureGrid(){
        HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);hs.setFillViewport(false);quickTrack=row();quickTrack.setGravity(Gravity.TOP);renderQuickLinks();hs.addView(quickTrack,new HorizontalScrollView.LayoutParams(-2,-2));hs.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{if(r-l!=or-ol)renderQuickLinks();});return hs;
    }
    private void renderQuickLinks(){
        if(quickTrack==null||VisualDesign.isEditing(quickTrack))return;quickTrack.removeAllViews();ArrayList<Integer> ids=new ArrayList<>();for(int i=0;i<mainKeys.length;i++)if(i!=7&&mainActive[i])ids.add(i);java.util.Collections.sort(ids,(a,b)->Integer.compare(mainDisplayOrder[a],mainDisplayOrder[b]));
        int viewport=getResources().getDisplayMetrics().widthPixels-dp(24);if(quickTrack.getParent() instanceof View){View parent=(View)quickTrack.getParent();if(parent.getWidth()>0)viewport=parent.getWidth()-parent.getPaddingLeft()-parent.getPaddingRight();}
        int gap=dp(4),available=Math.max(5,viewport-gap*4),width=available/5,remainder=available%5;
        int cellHeight=dp(62)+Math.round(26*getResources().getDisplayMetrics().scaledDensity);
        for(int column=0;column<QuickLinkLayout.columns(ids.size());column++){
            LinearLayout pair=col();int columnWidth=width+(column%5<remainder?1:0);
            for(int row=0;row<2;row++){
                int n=QuickLinkLayout.index(column,row,ids.size());
                pair.addView(n>=0?mainFeatureCard(ids.get(n)):new View(this),lp(columnWidth,cellHeight));
            }
            LinearLayout.LayoutParams cp=lp(columnWidth,-2);cp.rightMargin=gap;quickTrack.addView(pair,cp);
        }
        quickTrack.setTag(R.id.visual_design_layout,(Runnable)this::fitQuickLinkText);VisualDesign.apply(this,quickTrack,"home_quick");
    }

    private void fitQuickLinkText(){
        if(quickTrack==null)return;int tallest=dp(62)+Math.round(26*getResources().getDisplayMetrics().scaledDensity);
        for(int n=0;n<quickTrack.getChildCount();n++){View column=quickTrack.getChildAt(n);if(!(column instanceof ViewGroup))continue;ViewGroup pair=(ViewGroup)column;int width=Math.max(1,column.getLayoutParams().width);for(int j=0;j<pair.getChildCount();j++){View card=pair.getChildAt(j);if(!(card instanceof ViewGroup)||((ViewGroup)card).getChildCount()==0)continue;View content=((ViewGroup)card).getChildAt(0);content.measure(View.MeasureSpec.makeMeasureSpec(width,View.MeasureSpec.AT_MOST),View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED));tallest=Math.max(tallest,content.getMeasuredHeight());}}
        for(int n=0;n<quickTrack.getChildCount();n++){View column=quickTrack.getChildAt(n);if(!(column instanceof ViewGroup))continue;ViewGroup pair=(ViewGroup)column;for(int j=0;j<pair.getChildCount();j++){View card=pair.getChildAt(j);ViewGroup.LayoutParams params=card.getLayoutParams();if(params.height!=tallest){params.height=tallest;card.setLayoutParams(params);}}}
    }
    private View mainFeatureCard(final int idx){
        int[] tile={Color.rgb(226,246,255),Color.rgb(247,229,255),Color.rgb(224,246,255),Color.rgb(250,232,255),Color.rgb(230,255,235),Color.rgb(255,234,229),Color.rgb(226,240,255),Color.rgb(240,231,255),Color.rgb(222,251,248),Color.rgb(231,255,235)};
        FrameLayout card=new FrameLayout(this);card.setTag(R.id.visual_design_key,"element_"+mainKeys[idx]+"_container");mainCards[idx]=card;card.setBackgroundColor(Color.TRANSPARENT);card.setAlpha(mainActive[idx]?1f:.45f);
        LinearLayout c=col();c.setGravity(Gravity.CENTER);c.setPadding(dp(3),dp(4),dp(3),dp(2));ImageView iv=new ImageView(this);mainIconViews[idx]=iv;iv.setTag(R.id.visual_design_key,"element_"+mainKeys[idx]+"_icon");iv.setImageResource(mainIcons[idx]);iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);iv.setElevation(0);if(mainRemoteIconUrls[idx]!=null&&!mainRemoteIconUrls[idx].trim().isEmpty())loadRemoteImage(iv,mainRemoteIconUrls[idx].trim());int isz=Math.max(28,Math.min(56,mainIconSize[idx]));c.addView(iv,lp(dp(isz),dp(isz)));TextView t=text(UiStrings.label(this,mainTitles[idx]),Color.rgb(28,48,134),9f,true);mainLabels[idx]=t;if(!mainKeys[idx].matches(".*(?:live|rtc|audio|room|gift).*"))TextAppearance.bind(this,"feature_"+mainKeys[idx],TextAppearance.labels("element_title",t));t.setTag(R.id.visual_design_key,"element_"+mainKeys[idx]+"_label");t.setGravity(Gravity.CENTER);t.setMaxLines(2);t.setEllipsize(TextUtils.TruncateAt.END);c.addView(t,lp(-1,-2));card.addView(c,new FrameLayout.LayoutParams(-1,-1));applyRipple(card);card.setOnClickListener(v->openHomeShortcut(idx));card.setOnLongClickListener(v->{if(!SessionManager.isAdmin(this))return false;new MyShopDialogBuilder(this).setTitle(mainTitles[idx]).setItems(new String[]{"এডমিন প্যানেল","আইকন / নাম / অবস্থান","লেখার রং / ফন্ট মাপ"},(dialog,which)->{if(which==0)startActivity(new Intent(this,AdminSectionActivity.class).putExtra("section","feature_card").putExtra("managed_category","feature_"+mainKeys[idx]).putExtra("managed_title",mainTitles[idx]).putExtra("admin_context",true));else if(which==1)startActivity(new Intent(this,PageIconAdminActivity.class).putExtra("page","home1"));else VisualDesign.edit(this,quickTrack,"home_quick");}).show();return true;});return card;
    }
    /** Legacy dashboard helper retained for regression compatibility; V-503 Home uses the locked reference flow above. */
    private View finalDashboardActions(){
        LinearLayout outer=row();
        outer.setGravity(Gravity.CENTER_VERTICAL);
        outer.setPadding(dp(3),dp(3),dp(3),dp(3));
        outer.setBackground(round(Color.WHITE,Color.rgb(224,228,241),16));
        int[][] colors={
            {Color.rgb(28,105,255),Color.rgb(67,48,220)},
            {Color.rgb(255,194,54),Color.rgb(233,74,190)},
            {Color.rgb(255,59,91),Color.rgb(222,24,146)},
            {Color.rgb(19,187,125),Color.rgb(0,139,172)},
            {Color.rgb(147,67,240),Color.rgb(62,68,220)}
        };
        int[] icons={R.drawable.dashboard_game_3d,R.drawable.dashboard_premium_3d,R.drawable.dashboard_live_3d,R.drawable.dashboard_history_3d,R.drawable.dashboard_agent_3d};
        String[] labels={"GAMES","PREMIUM SHOP","LIVE STREAMING","WATCH HISTORY","AGENT"};
        int[] actions={0,1,2,3,4};
        for(int i=0;i<5;i++){
            View card=dashboardAction(i,icons[i],labels[i],colors[i],actions[i]);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1f);
            if(i>0)p.leftMargin=dp(2);
            outer.addView(card,p);
        }
        return outer;
    }
    private View dashboardAction(int index,int iconRes,String label,int[] colors,int action){
        LinearLayout c=row();
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(3),0,dp(3),0);
        ImageView icon=new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        c.addView(icon,lp(dp(15),dp(24)));
        TextView t=text(label,Color.WHITE,6.7f,true);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        if(Build.VERSION.SDK_INT>=26)t.setAutoSizeTextTypeUniformWithConfiguration(5,7,1,android.util.TypedValue.COMPLEX_UNIT_SP);
        t.setIncludeFontPadding(false);
        c.addView(t,weight(1,dp(30)));
        PremiumUi.premiumButton(c,colors,12,Color.argb(190,255,255,255),3);
        c.setContentDescription(label);
        c.setOnClickListener(v->{
            switch(action){
                case 0:startActivity(new Intent(this,GamesComingSoonActivity.class));break;
                case 1:startActivity(new Intent(this,StoreActivity.class));break;
                case 2:startActivity(new Intent(this,LiveHomeActivity.class));break;
                case 3:startActivity(new Intent(this,WatchHistoryActivity.class));break;
                case 4:startActivity(new Intent(this,AgentActivity.class));break;
            }
        });
        return c;
    }

    private View shortcutSection(){
        LinearLayout box=col();box.setPadding(dp(7),dp(5),dp(7),dp(7));box.setBackground(round(Color.WHITE,Color.rgb(229,231,240),14));box.setElevation(dp(1));TextView title=text("🔗  Quick Links",NAVY,12.0f,true);box.addView(title,lp(-1,dp(26)));box.addView(mainFeatureGrid(),top(lp(-1,-2),1));if(SessionManager.isAdmin(this))box.setOnLongClickListener(v->{startActivity(new Intent(this,PageIconAdminActivity.class).putExtra("page","home1").putExtra("admin_context",true));return true;});return box;
    }
    private void showQuickLinksAll(){showMoreQuickActions();}
    private void openHomeShortcut(int idx){
        if(idx<0||idx>=mainKeys.length)return;
        FeatureAccess.open(this,mainKeys[idx],()->openHomeShortcutAllowed(idx));
    }
    private void openHomeShortcutAllowed(int idx){
        if(idx<0||idx>=mainKeys.length||(!mainActive[idx]&&!SessionManager.isAdmin(this)))return;String remote=mainRemoteUrls[idx]==null?"":mainRemoteUrls[idx].trim();if(FeatureRegistry.isSafeHttpUrl(remote)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(remote)));return;}catch(Exception ignored){}}
        switch(idx){case 0:openQuickWeb("Page","facebook_page");break;case 1:openQuickWeb("Website","myshop_website");break;case 2:startActivity(new Intent(this,MyLevel621Activity.class));break;case 3:{Intent i=new Intent(this,StoreActivity.class);i.putExtra("category","MEMBER");startActivity(i);break;}case 4:openQuickFeature("EARN & REWARD","earn_reward");break;case 5:startActivity(new Intent(this,MediaHubActivity.class));break;case 6:startActivity(new Intent(this,MediaHubActivity.class).putExtra("section","external"));break;case 7:openQuickFeature("HELP CENTER","help_support");break;case 8:startActivity(new Intent(this,CoinWalletActivity.class));break;case 9:shareAppFromDashboard();break;case 10:if(SessionManager.isAdmin(this))startActivity(new Intent(this,AdminStoreActivity.class).putExtra("admin_context",true));else startActivity(new Intent(this,MyInviteActivity.class));break;case 11:if(SessionManager.isAdmin(this))startActivity(new Intent(this,AdminManagementActivity.class).putExtra("admin_context",true));else showHomeMenuDialog();break;case 12:if(SessionManager.isAdmin(this))startActivity(new Intent(this,LiveTvAdminActivity.class).putExtra("admin_context",true));else startActivity(new Intent(this,LiveTvActivity.class));break;case 13:if(SessionManager.isAdmin(this))startActivity(new Intent(this,AdminSectionActivity.class).putExtra("section","social").putExtra("admin_context",true));else startActivity(new Intent(this,FollowUsActivity.class));break;default:openQuickFeature(mainTitles[idx],mainKeys[idx]);break;}
    }
    private void openQuickWeb(String title,String key){String u=featureRemoteUrl(key);if(!FeatureRegistry.isSafeHttpUrl(u)){u=FeatureRegistry.getUrl(this,key);}if(!FeatureRegistry.isSafeHttpUrl(u)){toast(title+" link is not configured yet.");return;}try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){toast("Could not open "+title);}}
    private void openQuickFeature(String title,String key){Intent i=new Intent(this,FeatureActivity.class);i.putExtra("title",title);i.putExtra("feature_key",key);String u=featureRemoteUrl(key);if(FeatureRegistry.isSafeHttpUrl(u))i.putExtra("url",u);startActivity(i);}

    private View feedComposerSection(){
        LinearLayout box=col(); box.setPadding(dp(7),dp(0),dp(7),dp(0)); box.setBackgroundColor(Color.WHITE);
        TextView heading=text(UiStrings.label(MainActivity.this,"My Feed"),Color.rgb(10,112,228),17.0f,true); heading.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); heading.setIncludeFontPadding(false); String feedText=UiStrings.label(this,UiStrings.ui636("My Feed"));SpannableString feedTitle=new SpannableString(feedText);int length=feedTitle.length();if(length>0){int first=Math.max(1,length/3),second=Math.max(first,2*length/3);feedTitle.setSpan(new ForegroundColorSpan(Color.rgb(104,42,230)),0,first,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);feedTitle.setSpan(new ForegroundColorSpan(Color.rgb(236,48,128)),first,second,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);feedTitle.setSpan(new ForegroundColorSpan(Color.rgb(20,139,224)),second,length,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);} heading.setText(feedTitle);
        feedHeading632=heading;box.addView(heading,lp(-1,dp(28)));

        LinearLayout compose=row();
        ImageView av=new ImageView(this); composerAvatar=av; av.setImageResource(R.drawable.myshop_profile_avatar); av.setScaleType(ImageView.ScaleType.CENTER_CROP); av.setBackground(round(Color.rgb(238,240,248),Color.TRANSPARENT,22)); av.setClipToOutline(true);
        String avatarUrl=SessionManager.getAvatarUrl(this); if(avatarUrl!=null&&!avatarUrl.isEmpty())loadRemoteImage(av,avatarUrl);
        compose.addView(av,lp(dp(52),dp(52)));
        TextView hint=text(UiStrings.label(MainActivity.this,"What's on your mind?"),MUTED,11.5f,false); hint.setGravity(Gravity.CENTER_VERTICAL); hint.setPadding(dp(18),0,dp(10),0); hint.setBackground(round(0xffe9ecf1,Color.TRANSPARENT,24));Appearance.preserve(hint); hint.setOnClickListener(v->showTextPostDialog());
        compose.addView(hint,weight(1,dp(52))); box.addView(compose,top(lp(-1,dp(52)),2));

        ImageView photo=new ImageView(this);photo.setImageResource(R.drawable.feed_action_photo);photo.setImageTintList(ColorStateList.valueOf(0xff12b94d));photo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);photo.setPadding(Math.round(9.6f*getResources().getDisplayMetrics().density),Math.round(9.6f*getResources().getDisplayMetrics().density),Math.round(9.6f*getResources().getDisplayMetrics().density),Math.round(9.6f*getResources().getDisplayMetrics().density));photo.setContentDescription("Add photo");photo.setOnClickListener(v->pickPost("image"));compose.addView(photo,lp(dp(48),dp(52)));
        postLimit=text("",MUTED,7,false); postLimit.setVisibility(View.GONE);
        if(SessionManager.isAdmin(this))box.setOnLongClickListener(v->{startActivity(new Intent(this,MainActivity.class).putExtra("home_layout_preview632",true));return true;});
        return box;
    }

    private View feedComposerAction(int iconRes,String label,int color,View.OnClickListener listener){
        LinearLayout cell=row(); cell.setGravity(Gravity.CENTER); cell.setOnClickListener(listener);
        ImageView icon=new ImageView(this); icon.setImageResource(iconRes); icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE); icon.setImageTintList(ColorStateList.valueOf(color)); cell.addView(icon,lp(dp(24),dp(24)));
        TextView tx=text(UiStrings.label(this,label),NAVY,14f,true); tx.setGravity(Gravity.CENTER_VERTICAL); cell.addView(tx,top(lp(dp(60),dp(36)),0)); applyRipple(cell); return cell;
    }

    private TextView miniFeedAction(String label,int color){TextView t=text(label,color,11.5f,true);t.setGravity(Gravity.CENTER);t.setSingleLine(true);return t;}

    private int feedInk632(){return Appearance.dark(this)?0xffd9e7ff:Color.rgb(83,86,105);}
    private TextView feedAction(int res,int count,String label){TextView t=miniFeedAction(String.valueOf(count),feedInk632());android.graphics.drawable.Drawable icon=getDrawable(res);icon.setBounds(0,0,dp(28),dp(28));t.setCompoundDrawables(icon,null,null,null);t.setCompoundDrawablePadding(dp(7));t.setGravity(Gravity.CENTER_VERTICAL);t.setPadding(dp(10),0,dp(8),0);t.setContentDescription(label+" "+count);return t;}

    private View feedSection(){ return feedComposerSection(); }

    private void showFeedFilter(){
        new MyShopDialogBuilder(this).setTitle(LanguageManager.t(this,"filter"))
                .setItems(new String[]{LanguageManager.t(this,"textPost"),LanguageManager.t(this,"galleryAction")},(d,w)->{if(w==0)showTextPostDialog();else pickPost("image");}).show();
    }

    private boolean renderCachedFeed(){
        try{String raw=getSharedPreferences("myshop_feed_cache",MODE_PRIVATE).getString("first_page_"+SessionManager.getUserId(this),"");if(raw.isEmpty()||System.currentTimeMillis()-getSharedPreferences("myshop_feed_cache",MODE_PRIVATE).getLong("at_"+SessionManager.getUserId(this),0)>180000L)return false;JSONObject d=new JSONObject(raw);JSONArray a=d.optJSONArray("posts");if(a==null||a.length()==0)return false;feedList.removeAllViews();if(homeLayout632!=null)handler.post(()->homeLayout632.apply());feedPresenceDots.clear();renderedPostIds.clear();postViews.clear();inlineVideos.clear();activeInlineVideo=null;for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)renderPost(x);handler.removeCallbacks(initialPresenceRefresh);handler.postDelayed(initialPresenceRefresh,250);}feedBefore=d.optLong("nextBefore",0);feedHasMore=d.optBoolean("hasMore",feedBefore>0);if(feedStatus!=null)feedStatus.setText("Updating Feed…");return true;}catch(Exception e){return false;}
    }
    private void loadFeed(boolean reset){
        lastFeedLoadAt=System.currentTimeMillis();
        if(feedLoading || (!feedHasMore && !reset)) return; String token=SessionManager.getToken(this); if(token==null||token.isEmpty()){if(feedStatus!=null)feedStatus.setText(LanguageManager.t(this,"loginFeed"));return;}
        feedLoading=true; boolean hadCache=false;if(feedStatus!=null){feedStatus.setVisibility(View.VISIBLE);feedStatus.setOnClickListener(null);}
        if(reset){feedBefore=0;feedHasMore=true;hadCache=renderCachedFeed();if(!hadCache){if(feedList!=null){feedList.removeAllViews();if(homeLayout632!=null)handler.post(()->homeLayout632.apply());feedPresenceDots.clear();renderedPostIds.clear();postViews.clear();showFeedSkeleton();}if(feedStatus!=null)feedStatus.setText("Loading latest posts…");}}
        final boolean cachedVisible=hadCache; final long before=reset?0:feedBefore;
        final int sequence=++feedGeneration;final boolean[] finished={false};
        Runnable timeout=()->{if(dashboardDestroyed||sequence!=feedGeneration||finished[0])return;finished[0]=true;feedLoading=false;if(!cachedVisible&&reset&&feedList!=null)feedList.removeAllViews();if(homeLayout632!=null)handler.post(()->homeLayout632.apply());if(feedStatus!=null){feedStatus.setVisibility(View.VISIBLE);feedStatus.setText(cachedVisible?"Saved posts shown • Tap to retry":"পোস্ট লোড হয়নি • আবার চেষ্টা করতে চাপুন");feedStatus.setOnClickListener(v->loadFeed(reset));}};
        handler.postDelayed(timeout,25000);
        BackendClient.feedList(token,5,before,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{
            if(dashboardDestroyed||sequence!=feedGeneration||finished[0])return;
            if(d.optJSONArray("posts")==null){timeout.run();handler.removeCallbacks(timeout);return;}
            finished[0]=true;handler.removeCallbacks(timeout);
            if(reset){pauseInlineVideos();feedList.removeAllViews();if(homeLayout632!=null)handler.post(()->homeLayout632.apply());feedPresenceDots.clear();renderedPostIds.clear();postViews.clear();inlineVideos.clear();activeInlineVideo=null;getSharedPreferences("myshop_feed_cache",MODE_PRIVATE).edit().remove("first_page").putString("first_page_"+SessionManager.getUserId(MainActivity.this),d.toString()).putLong("at_"+SessionManager.getUserId(MainActivity.this),System.currentTimeMillis()).apply();}
            JSONArray a=d.optJSONArray("posts");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null)renderPost(x);handler.removeCallbacks(initialPresenceRefresh);handler.postDelayed(initialPresenceRefresh,250);}
            feedBefore=d.optLong("nextBefore",0);feedHasMore=feedBefore>0&&d.optBoolean("hasMore",false);int today=d.optInt("postsToday",0);boolean can=d.optBoolean("canPost",false);if(postLimit!=null)postLimit.setText(d.optString("postingQuotaMessage",can?"Posting available":"আজকের পোস্ট সীমা পূর্ণ হয়েছে"));if(feedStatus!=null){feedStatus.setText("");feedStatus.setVisibility(View.GONE);}feedLoading=false;loadFocusedPostIfNeeded();restoreHomeScrollPosition();
        });}public void onError(String m){runOnUiThread(()->{if(dashboardDestroyed||sequence!=feedGeneration||finished[0])return;finished[0]=true;handler.removeCallbacks(timeout);if(!cachedVisible&&reset&&feedList!=null)feedList.removeAllViews();if(homeLayout632!=null)handler.post(()->homeLayout632.apply());if(feedStatus!=null){feedStatus.setVisibility(View.VISIBLE);feedStatus.setText(cachedVisible?"Saved posts shown • Tap to retry":LanguageManager.t(MainActivity.this,"feedUnavailable")+m+" • Tap to retry");feedStatus.setOnClickListener(v->loadFeed(reset));}feedLoading=false;});}});
    }
    private void restoreHomeScrollPosition(){if(pendingHomeScrollRestore<0||scroll==null)return;scroll.post(()->{if(pendingHomeScrollRestore<0||scroll==null)return;View child=scroll.getChildAt(0);if(child==null)return;int wanted=pendingHomeScrollRestore;int max=Math.max(0,child.getHeight()-scroll.getHeight());if(max<wanted&&feedHasMore&&!feedLoading){scroll.scrollTo(0,max);loadFeed(false);return;}scroll.scrollTo(0,Math.min(wanted,max));pendingHomeScrollRestore=-1;getSharedPreferences("myshop_home_state",MODE_PRIVATE).edit().putInt(STATE_HOME_SCROLL_Y,scroll.getScrollY()).apply();});}
    private void showFeedSkeleton(){if(feedList==null)return;for(int i=0;i<2;i++){LinearLayout sk=col();sk.setPadding(dp(10),dp(10),dp(10),dp(10));sk.setBackground(round(Color.WHITE,Color.rgb(233,235,241),14));TextView a=text("",MUTED,1,false);a.setBackground(round(Color.rgb(236,238,244),Color.TRANSPARENT,12));sk.addView(a,lp(-1,dp(42)));TextView b=text("",MUTED,1,false);b.setBackground(round(Color.rgb(241,242,246),Color.TRANSPARENT,10));sk.addView(b,top(lp(-1,dp(110)),7));feedList.addView(sk,lp(-1,-2));feedList.addView(space(),lp(1,dp(8)));}}
    private void loadFocusedPostIfNeeded(){final long id=pendingFocusPostId;if(id<=0)return;View found=postViews.get(id);if(found!=null){scrollToPost(id);pendingFocusPostId=0;return;}BackendClient.feedPost(SessionManager.getToken(this),id,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONObject post=d.optJSONObject("post");if(post!=null)renderPostAtTop(post);scrollToPost(id);pendingFocusPostId=0;});}public void onError(String m){pendingFocusPostId=0;}});}
    private void scrollToPost(long id){View v=postViews.get(id);if(v==null||scroll==null)return;scroll.postDelayed(()->scroll.smoothScrollTo(0,Math.max(0,feedList.getTop()+v.getTop()-dp(12))),120);}

    private final Runnable initialPresenceRefresh=this::refreshFeedPresence;
    private void refreshFeedPresence(){if(!dashboardVisible||feedPresenceLoading||feedPresenceDots.isEmpty())return;java.util.ArrayList<String> ids=new java.util.ArrayList<>();for(String id:feedPresenceDots.keySet()){if(ids.size()>=50)break;ids.add(id);}feedPresenceLoading=true;BackendClient.appPresenceRead(SessionManager.getToken(this),android.text.TextUtils.join(",",ids),new BackendClient.Callback(){public void onSuccess(JSONObject d){feedPresenceLoading=false;JSONArray users=d.optJSONArray("users");if(users==null)return;for(int i=0;i<users.length();i++){JSONObject u=users.optJSONObject(i);if(u==null)continue;java.util.List<View> dots=feedPresenceDots.get(u.optString("userId"));if(dots!=null)for(View dot:dots){dot.setBackground(round(u.optBoolean("online")?GREEN:0xff9ca3af,Color.WHITE,12));dot.setContentDescription(u.optBoolean("online")?"অনলাইন":"অফলাইন");}}}public void onError(String m){feedPresenceLoading=false;for(java.util.List<View> dots:feedPresenceDots.values())for(View dot:dots){dot.setBackground(round(0xff9ca3af,Color.WHITE,12));dot.setContentDescription("স্ট্যাটাস লোড হয়নি");}}});}

    private void renderPostAtTop(JSONObject x){if(feedList==null||x==null)return;renderPost(x);View card=postViews.get(x.optLong("id"));if(card!=null&&card.getParent()==feedList){int at=feedList.indexOfChild(card);View gap=at+1<feedList.getChildCount()&&"feed_gap632".equals(feedList.getChildAt(at+1).getTag())?feedList.getChildAt(at+1):null;feedList.removeView(card);if(gap!=null)feedList.removeView(gap);feedList.addView(card,0);if(gap!=null)feedList.addView(gap,1);if(homeLayout632!=null)homeLayout632.apply();}handler.removeCallbacks(initialPresenceRefresh);handler.postDelayed(initialPresenceRefresh,250);}


    private void renderPost(JSONObject x){
        long id=x.optLong("id",0);if(id>0&&renderedPostIds.contains(id))return;if(id>0)renderedPostIds.add(id);String uid=x.optString("userId","");String name=x.optString("name","myshop User");String avatar=x.optString("avatarUrl","");String cap=x.optString("caption","");String url=x.optString("mediaUrl","");String type=x.optString("mediaType","image"); final int likeCount=x.optInt("likeCount",0);
        LinearLayout card=col();card.setPadding(dp(10),dp(9),dp(10),dp(8));card.setBackgroundColor(Color.WHITE);card.setElevation(0f);final TextView[] capView={null};
        LinearLayout head=row();head.setGravity(Gravity.CENTER_VERTICAL);head.setOnClickListener(v->{Intent q=new Intent(this,UserProfileActivity.class);q.putExtra("userId",uid);startActivity(q);});ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setBackground(round(Color.rgb(238,240,248),Color.TRANSPARENT,20));av.setClipToOutline(true);if(!avatar.isEmpty())loadRemoteImage(av,avatar);FrameLayout avatarBox=new FrameLayout(this);avatarBox.addView(av,new FrameLayout.LayoutParams(-1,-1));View onlineDot=new View(this);onlineDot.setBackground(round(0xff9ca3af,Color.WHITE,12));onlineDot.setContentDescription("অফলাইন / স্ট্যাটাস লোড হয়নি");avatarBox.addView(onlineDot,new FrameLayout.LayoutParams(dp(9),dp(9),Gravity.BOTTOM|Gravity.END));feedPresenceDots.computeIfAbsent(uid,k->new java.util.ArrayList<>()).add(onlineDot);head.addView(avatarBox,lp(dp(46),dp(46)));LinearLayout who=col();who.setPadding(dp(11),dp(2),dp(5),0);String levelText="LV."+Math.max(0,x.optInt("level",0));TextView nm=text(name,Color.rgb(25,30,55),ProfileNamePolicy.SIZE_SP,true);nm.setSingleLine(true);nm.setEllipsize(TextUtils.TruncateAt.END);LinearLayout nameLine=row();nameLine.setGravity(Gravity.CENTER_VERTICAL);nm.setIncludeFontPadding(true);nm.setGravity(Gravity.CENTER_VERTICAL);nameLine.addView(nm,lp(-2,-2));TextView levelView=text(levelText,MUTED,11f,false);AuthorityBadge.decorate(nm,uid);if(AuthorityBadge.isAuthority(uid))levelView.setVisibility(View.GONE);levelView.setSingleLine(true);levelView.setGravity(Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams levelLp=lp(-2,-2);levelLp.leftMargin=dp(5);nameLine.addView(levelView,levelLp);TextView follow632=text(UiStrings.label(this,x.optBoolean("following",false)?"Unfollow":"Follow"),0xff0866df,10.5f,true);follow632.setPadding(dp(7),dp(5),dp(2),dp(5));follow632.setVisibility(uid.equals(SessionManager.getUserId(this))?View.GONE:View.VISIBLE);final boolean[] following632={x.optBoolean("following",false)};follow632.setOnClickListener(v->{follow632.setEnabled(false);BackendClient.toggleFollow(SessionManager.getToken(this),uid,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{following632[0]=d.optBoolean("following",!following632[0]);follow632.setText(UiStrings.label(MainActivity.this,following632[0]?"Unfollow":"Follow"));follow632.setEnabled(true);});}public void onError(String e){runOnUiThread(()->{follow632.setEnabled(true);toast(e);});}});});nameLine.addView(follow632,lp(-2,-2));nameLine.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{int max=Math.max(0,r-l-levelView.getMeasuredWidth()-follow632.getMeasuredWidth()-dp(10));if(nm.getMaxWidth()!=max)nm.setMaxWidth(max);});who.addView(nameLine,lp(-1,-2));who.addView(text("ID "+uid+" • "+UiTime.relative(x.optString("createdAt","")),MUTED,9.2f,false),lp(-1,dp(20)));head.addView(who,weight(1,-2));TextView moreTop=text("⋮",Color.rgb(91,95,117),20f,true);moreTop.setGravity(Gravity.CENTER);moreTop.setContentDescription("More");moreTop.setOnClickListener(v->{PopupMenu pm=new PopupMenu(MainActivity.this,moreTop);boolean owner=SessionManager.getUserId(MainActivity.this).equals(uid);if(!owner)pm.getMenu().add("Report");if(owner)pm.getMenu().add("Edit caption");if(owner&&TextAppearance.allowed(this,"status"))pm.getMenu().add("রঙ দিন");if(owner||SessionManager.isAdmin(MainActivity.this)||SessionManager.isModerator(MainActivity.this))pm.getMenu().add("Delete");pm.setOnMenuItemClickListener(item->{String label=item.getTitle().toString();if("Report".equals(label)){SafetyActions.show(MainActivity.this,uid,"POST",String.valueOf(id));return true;}if("রঙ দিন".equals(label)){if(!owner)return false;TextStyleEditor.open(this,"post_"+id,TextAppearance.labels("element_caption",capView[0]));return true;}if("Edit caption".equals(label)){if(!owner)return false;showEditPostCaption(id,cap,capView[0]);return true;}if("Delete".equals(label)){deletePost(id);return true;}return false;});pm.show();});head.addView(moreTop,lp(dp(34),dp(46)));card.addView(head,lp(-1,-2));
        TextView captionText=text(cap,Color.rgb(31,35,49),18.0f,false);captionText.setPadding(dp(2),dp(10),dp(2),dp(11));captionText.setLineSpacing(dp(4),1.04f);captionText.setMaxLines(12);captionText.setEllipsize(TextUtils.TruncateAt.END);captionText.setVisibility(cap.isEmpty()?View.GONE:View.VISIBLE);capView[0]=captionText;card.addView(captionText,lp(-1,-2));TextAppearance.bind(this,"post_"+id,TextAppearance.labels("element_caption",captionText));captionText.setOnLongClickListener(v->{if(!SessionManager.getUserId(this).equals(uid))return false;TextStyleEditor.open(this,"post_"+id,TextAppearance.labels("element_caption",captionText));return true;});TextAppearance.bind(this,"identity_"+uid,TextAppearance.labels("element_name",nm));
        if(!url.isEmpty()){
            if("video".equalsIgnoreCase(type)){
                FrameLayout media=new FrameLayout(this); media.setBackground(round(Color.BLACK,Color.rgb(226,228,236),12)); media.setClipToOutline(true);
                ImageView thumb=new ImageView(this); thumb.setScaleType(ImageView.ScaleType.CENTER_CROP); thumb.setBackgroundColor(Color.BLACK); media.addView(thumb,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER)); loadVideoThumbnail(thumb,url);
                VideoView vv=new VideoView(this); vv.setBackgroundColor(Color.TRANSPARENT); vv.setVideoURI(Uri.parse(url),MediaAccess640.headers(this,url)); vv.setTag(url);
                FrameLayout.LayoutParams vp=new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER); media.addView(vv,vp);
                TextView play=text("▶",Color.WHITE,22f,true); play.setGravity(Gravity.CENTER); play.setBackground(round(Color.argb(150,30,30,35),Color.TRANSPARENT,28)); FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(56),dp(56),Gravity.CENTER); media.addView(play,pp);
                TextView expand=text("⛶",Color.WHITE,15f,true); expand.setGravity(Gravity.CENTER); expand.setBackground(round(Color.argb(145,20,20,25),Color.TRANSPARENT,10)); FrameLayout.LayoutParams ep=new FrameLayout.LayoutParams(dp(40),dp(36),Gravity.TOP|Gravity.END); ep.setMargins(0,dp(8),dp(8),0); media.addView(expand,ep);
                final boolean[] prepared={false}; final android.media.MediaPlayer[] player={null};
                vv.setOnPreparedListener(mp->{try{prepared[0]=true;player[0]=mp;mp.setVolume(0f,0f);mp.setLooping(false);vv.seekTo(10);play.setVisibility(View.VISIBLE);}catch(Exception ignored){}});
                vv.setOnErrorListener((mp,what,extra)->{play.setText("↻");play.setVisibility(View.VISIBLE);return true;});
                View.OnClickListener toggle=v->{try{if(vv.isPlaying()){vv.pause();play.setText("▶");play.setVisibility(View.VISIBLE);}else{WatchHistoryActivity.record(MainActivity.this,"VIDEO",cap.isEmpty()?"Video by "+name:cap,name,"video:"+id,avatar,"Watch Video");pauseInlineVideosExcept(vv);if(!prepared[0])vv.setVideoURI(Uri.parse(url),MediaAccess640.headers(this,url));if(player[0]!=null)player[0].setVolume(1f,1f);vv.start();activeInlineVideo=vv;play.setText("▶");play.setVisibility(View.GONE);}}catch(Exception e){play.setText("↻");play.setVisibility(View.VISIBLE);}};
                vv.setOnClickListener(toggle); play.setOnClickListener(toggle); vv.setOnCompletionListener(mp->{play.setText("▶");play.setVisibility(View.VISIBLE);});
                expand.setOnClickListener(v->openFeedVideo(url));
                inlineVideos.add(vv); card.addView(media,top(lp(-1,dp(285)),6));
            }else{
                ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);im.setBackground(round(Color.rgb(242,243,248),Color.TRANSPARENT,10));applyRipple(im);im.setOnClickListener(v->{WatchHistoryActivity.record(MainActivity.this,"FEED_POST",name,cap,"feed:"+id,url,"View Post");openFeedImage(url);});card.addView(im,top(lp(-1,dp(300)),6));loadRemoteImage(im,url);
            }
        }
        // Reference assets retained by V-516 contract: R.drawable.feed_action_like_ref and R.drawable.feed_action_more_ref
        LinearLayout actions=row(); actions.setGravity(Gravity.CENTER_VERTICAL); actions.setPadding(0,0,0,0);
        final boolean[] likedState={x.optBoolean("liked",false)},likeBusy={false};final int commentCount=x.optInt("commentCount",0);final int[] liveLikeCount={likeCount};
        TextView like=feedAction(R.drawable.action540_like,likeCount,"Like");like.setCompoundDrawableTintList(ColorStateList.valueOf(likedState[0]?0xff168545:feedInk632()));like.setOnClickListener(v->{if(likeBusy[0])return;likeBusy[0]=true;boolean wanted=!likedState[0];int old=liveLikeCount[0];likedState[0]=wanted;liveLikeCount[0]=Math.max(0,old+(wanted?1:-1));like.setText(String.valueOf(liveLikeCount[0]));like.setContentDescription((wanted?"Liked ":"Like ")+liveLikeCount[0]);like.setCompoundDrawableTintList(ColorStateList.valueOf(wanted?0xff168545:feedInk632()));like.setTextColor(wanted?0xff168545:feedInk632());BackendClient.feedLike(SessionManager.getToken(this),id,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{likedState[0]=d.optBoolean("liked",wanted);liveLikeCount[0]=d.optInt("likeCount",liveLikeCount[0]);like.setText(String.valueOf(liveLikeCount[0]));like.setContentDescription((likedState[0]?"Liked ":"Like ")+liveLikeCount[0]);like.setCompoundDrawableTintList(ColorStateList.valueOf(likedState[0]?0xff168545:feedInk632()));like.setTextColor(likedState[0]?0xff168545:feedInk632());likeBusy[0]=false;loadNotificationCount();});}public void onError(String m){runOnUiThread(()->{likedState[0]=!wanted;liveLikeCount[0]=old;like.setText(String.valueOf(old));like.setContentDescription((likedState[0]?"Liked ":"Like ")+old);like.setCompoundDrawableTintList(ColorStateList.valueOf(likedState[0]?0xff168545:feedInk632()));like.setTextColor(likedState[0]?0xff168545:feedInk632());likeBusy[0]=false;toast("Like failed: "+m);});}});});
        like.setOnLongClickListener(v->{showLikeUsers(id);return true;});
        TextView comment=feedAction(R.drawable.action540_comment,commentCount,"Comment");comment.setOnClickListener(v->showCommentDialog(id,comment));
        TextView share=feedAction(R.drawable.action540_share,x.optInt("shareCount",0),"Share");share.setOnClickListener(v->PostShareReceiver.launch(this,id,name,cap,url,share));
        actions.addView(like,lp(-2,dp(44)));actions.addView(comment,lp(-2,dp(44)));actions.addView(share,lp(-2,dp(44)));
        actions.addView(space(),weight(1,1));TextView postGift=text("🎁 Gift",0xffe40083,11,true);postGift.setGravity(Gravity.END|Gravity.CENTER_VERTICAL);postGift.setOnClickListener(v->PostGiftDialog.show(this,id,()->showCommentDialog(id,comment)));actions.addView(postGift,lp(dp(64),dp(38)));card.addView(actions,top(lp(-1,dp(44)),2));if(id>0)postViews.put(id,card);card.setTag("feed_post632");feedList.addView(card,lp(-1,-2));View gap=new View(this);gap.setBackgroundColor(0xfff1f3f6);gap.setTag("feed_gap632");feedList.addView(gap,lp(-1,dp(1)));if(homeLayout632!=null)homeLayout632.apply();
    }

    private void showReplyDialog(long postId,long parentId,String name,LinearLayout list,TextView status){final EditText input=new EditText(this);input.setHint("Reply to "+name+"…");input.setMaxLines(4);AlertDialog d=new MyShopDialogBuilder(this).setTitle("Reply").setView(input).setNegativeButton(UiStrings.label(MainActivity.this,"Cancel"),null).setPositiveButton("Reply",null).create();d.setOnShowListener(x->d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String msg=input.getText().toString().trim();if(msg.isEmpty())return;BackendClient.feedCommentReply(SessionManager.getToken(this),postId,parentId,msg,new BackendClient.Callback(){public void onSuccess(JSONObject o){runOnUiThread(()->{d.dismiss();loadCommentsInto(postId,list,status);});}public void onError(String m){runOnUiThread(()->toast("Reply failed: "+m));}});}));d.show();}

    private void pauseInlineVideos(){for(VideoView v:inlineVideos){try{if(v!=null&&v.isPlaying())v.pause();}catch(Exception ignored){}}activeInlineVideo=null;}
    private void pauseInlineVideosExcept(VideoView keep){for(VideoView v:inlineVideos){if(v==keep)continue;try{if(v!=null&&v.isPlaying())v.pause();}catch(Exception ignored){}}}
    private void updateInlineVideoPlayback(){
        if(inlineVideos.isEmpty()||scroll==null)return;
        android.graphics.Rect viewport=new android.graphics.Rect(); scroll.getGlobalVisibleRect(viewport);
        VideoView best=null; int bestArea=0;
        for(VideoView v:inlineVideos){if(v==null||!v.isShown())continue; android.graphics.Rect r=new android.graphics.Rect(); if(!v.getGlobalVisibleRect(r))continue; int area=Math.max(0,r.width())*Math.max(0,r.height()); if(area>bestArea){bestArea=area;best=v;}}
        int threshold=Math.max(1,scroll.getWidth()*dp(110));
        if(best!=null&&bestArea>threshold){ if(activeInlineVideo!=best){pauseInlineVideosExcept(best); try{best.start();activeInlineVideo=best;}catch(Exception ignored){}} }
        else if(activeInlineVideo!=null){try{activeInlineVideo.pause();}catch(Exception ignored){}activeInlineVideo=null;}
    }

    private void shareFeedPost(String name,String caption,String mediaUrl){try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");StringBuilder b=new StringBuilder();if(name!=null&&!name.isEmpty())b.append(name).append(" on myshop\n");if(caption!=null&&!caption.isEmpty())b.append(caption).append("\n");if(mediaUrl!=null&&!mediaUrl.isEmpty())b.append(mediaUrl);i.putExtra(Intent.EXTRA_TEXT,b.toString().trim());startActivity(Intent.createChooser(i,"Share post"));}catch(Exception e){toast("Share is not available.");}}

    private void showLikeUsers(long postId){
        BackendClient.feedLikeUsers(SessionManager.getToken(this),postId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{JSONArray a=d.optJSONArray("users");String[] names=new String[a==null?0:a.length()];for(int i=0;i<names.length;i++){JSONObject u=a.optJSONObject(i);names[i]=u==null?"myshop User":u.optString("name","myshop User")+"  •  ID "+u.optString("userId","");}new MyShopDialogBuilder(MainActivity.this).setTitle("People who liked this post").setItems(names,null).setPositiveButton(UiStrings.label(MainActivity.this,"Close"),null).show();});}public void onError(String m){runOnUiThread(()->toast("Likes unavailable: "+m));}});
    }

    private void showCommentDialog(long postId, final TextView commentButton){
        LinearLayout wrap=col(); wrap.setPadding(dp(10),dp(4),dp(10),dp(4));
        TextView loading=text("Loading comments…",MUTED,9.5f,false); wrap.addView(loading,lp(-1,dp(28)));
        ScrollView sv=new ScrollView(this); sv.setVerticalScrollBarEnabled(false); LinearLayout comments=col(); sv.addView(comments,new ScrollView.LayoutParams(-1,-2)); wrap.addView(sv,lp(-1,dp(270)));
        EditText input=new EditText(this); input.setHint(UiStrings.label(MainActivity.this,"Write a comment…")); input.setTextSize(11); input.setMinLines(2); input.setMaxLines(4); input.setBackground(round(Color.rgb(246,247,251),Color.rgb(222,225,234),12)); wrap.addView(input,top(lp(-1,dp(64)),6));
        AlertDialog dlg=new MyShopDialogBuilder(this).setTitle("Comments").setView(wrap).setNegativeButton(LanguageManager.t(this,"cancel"),null).setPositiveButton("POST",null).create();
        dlg.setOnShowListener(x->{
            loadCommentsInto(postId,comments,loading);
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String text=input.getText().toString().trim();if(text.isEmpty())return;dlg.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);BackendClient.feedComment(SessionManager.getToken(this),postId,text,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{input.setText("");if(commentButton!=null){commentButton.setText(String.valueOf(d.optInt("commentCount",0)));commentButton.setContentDescription("Comment "+d.optInt("commentCount",0));}dlg.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);loadCommentsInto(postId,comments,loading);loadNotificationCount();});}public void onError(String m){runOnUiThread(()->{dlg.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);toast("Comment failed: "+m);});}});});
        });
        dlg.show();
    }
    private void loadCommentsInto(long postId,LinearLayout list,TextView status){status.setText("Loading comments…");BackendClient.feedComments(SessionManager.getToken(this),postId,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{list.removeAllViews();JSONArray a=d.optJSONArray("comments");if(a==null||a.length()==0){status.setText("No comments yet");return;}status.setText(a.length()+" comment"+(a.length()==1?"":"s"));for(int i=0;i<a.length();i++){JSONObject c=a.optJSONObject(i);if(c==null)continue;LinearLayout row=row();row.setPadding(dp(4),dp(5),dp(4),dp(5));ImageView av=new ImageView(MainActivity.this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setClipToOutline(true);av.setBackground(round(Color.rgb(238,240,248),Color.TRANSPARENT,18));String au=c.optString("avatarUrl","");if(!au.isEmpty())loadRemoteImage(av,au);row.addView(av,lp(dp(36),dp(36)));LinearLayout body=col();body.setPadding(dp(8),0,0,0);body.addView(text(c.optString("name","myshop User"),DARK,9.5f,true),lp(-1,dp(19)));body.addView(text(c.optString("comment",""),Color.rgb(45,48,64),10.5f,false),lp(-1,-2));body.addView(text(UiTime.relative(c.optString("createdAt","")),MUTED,7.5f,false),lp(-1,dp(17)));TextView reply=text("Reply",BLUE,8.0f,true);reply.setOnClickListener(v->showReplyDialog(postId,c.optLong("id",0),c.optString("name","User"),list,status));if(!"GIFT".equals(c.optString("type")))body.addView(reply,lp(dp(54),dp(22)));else{JSONObject giftData=c.optJSONObject("gift");if(giftData!=null){row.setBackground(round(0xffedf6ff,Color.TRANSPARENT,10));ImageView giftArt=new ImageView(MainActivity.this);PostGiftDialog.art(MainActivity.this,giftArt,giftData);giftArt.setScaleType(ImageView.ScaleType.FIT_CENTER);body.addView(giftArt,lp(-1,dp(148)));giftArt.setOnClickListener(v->PostGiftDialog.play(MainActivity.this,giftData));}}row.addView(body,weight(1,-2));String commentUid=c.optString("userId","");if(!commentUid.isEmpty()&&!commentUid.equals(SessionManager.getUserId(MainActivity.this))){TextView flag=action("⚑",Color.rgb(148,48,70));flag.setOnClickListener(v->SafetyActions.show(MainActivity.this,commentUid,"COMMENT",String.valueOf(c.optLong("id",0))));row.addView(flag,lp(dp(38),dp(32)));}list.addView(row,lp(-1,-2));}});}public void onError(String m){runOnUiThread(()->status.setText("Comments unavailable: "+m));}});}

    private final java.util.Map<String,java.util.List<java.lang.ref.WeakReference<ImageView>>> videoWaiting=new java.util.HashMap<>();
    private void loadVideoThumbnail(ImageView view,String url){String key="video:"+url;view.setTag(key);Bitmap hit=imageCache.get(key);if(hit!=null){view.setImageBitmap(hit);return;}java.util.List<java.lang.ref.WeakReference<ImageView>> pending=videoWaiting.get(key);if(pending!=null){pending.add(new java.lang.ref.WeakReference<>(view));return;}pending=new java.util.ArrayList<>();pending.add(new java.lang.ref.WeakReference<>(view));videoWaiting.put(key,pending);imagePool.execute(()->{MediaMetadataRetriever retriever=new MediaMetadataRetriever();Bitmap result=null;try{retriever.setDataSource(url,MediaAccess640.headers(this,url));result=Build.VERSION.SDK_INT>=27?retriever.getScaledFrameAtTime(0,MediaMetadataRetriever.OPTION_CLOSEST_SYNC,640,360):retriever.getFrameAtTime(0,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);if(result!=null&&Math.max(result.getWidth(),result.getHeight())>640){float scale=640f/Math.max(result.getWidth(),result.getHeight());Bitmap scaled=Bitmap.createScaledBitmap(result,Math.max(1,Math.round(result.getWidth()*scale)),Math.max(1,Math.round(result.getHeight()*scale)),true);if(scaled!=result)result.recycle();result=scaled;}if(result!=null)imageCache.put(key,result);}catch(Exception|OutOfMemoryError ignored){}finally{try{retriever.release();}catch(Exception ignored){}}final Bitmap thumbnail=result;runOnUiThread(()->{java.util.List<java.lang.ref.WeakReference<ImageView>> waiting=videoWaiting.remove(key);if(dashboardDestroyed||waiting==null||thumbnail==null)return;for(java.lang.ref.WeakReference<ImageView> ref:waiting){ImageView target=ref.get();if(target!=null&&key.equals(target.getTag()))target.setImageBitmap(thumbnail);}});});}


    private void openFeedVideo(String url){pauseInlineVideos();startActivity(new Intent(this,FullscreenVideoActivity.class).putExtra("url",url));}
    private void oldFeedVideoDialog(String url){LinearLayout box=col();box.setPadding(dp(8),dp(8),dp(8),dp(8));box.setBackgroundColor(Color.BLACK);VideoView v=new VideoView(this);box.addView(v,lp(-1,dp(520)));LinearLayout actions=row();TextView close=action("CLOSE",Color.rgb(70,73,86));TextView down=action("DOWNLOAD VIDEO",BLUE);actions.addView(close,weight(1,dp(46)));actions.addView(space(),lp(dp(8),1));actions.addView(down,weight(1,dp(46)));box.addView(actions,top(lp(-1,dp(46)),8));AlertDialog dlg=new MyShopDialogBuilder(this).setView(box).create();close.setOnClickListener(q->{try{v.stopPlayback();}catch(Exception ignored){}dlg.dismiss();});down.setOnClickListener(q->downloadVideo(url));dlg.setOnDismissListener(q->{try{v.stopPlayback();}catch(Exception ignored){}});dlg.show();if(dlg.getWindow()!=null){dlg.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);dlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.BLACK));}v.setVideoURI(Uri.parse(url),MediaAccess640.headers(this,url));v.setOnPreparedListener(mp->{mp.setLooping(false);v.start();});}

    private void downloadVideo(String url){try{DownloadManager dm=(DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE);DownloadManager.Request r=new DownloadManager.Request(Uri.parse(url));for(java.util.Map.Entry<String,String> header640:MediaAccess640.headers(this,url).entrySet())r.addRequestHeader(header640.getKey(),header640.getValue());r.setTitle("myshop Video");r.setDescription("Downloading video");r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);r.setMimeType("video/mp4");r.setDestinationInExternalPublicDir(Environment.DIRECTORY_MOVIES,"myshop/MY_SHOP_"+System.currentTimeMillis()+".mp4");dm.enqueue(r);toast("✓ Video download started");}catch(Exception e){toast("Video download failed. Please try again.");}}

    private void openFeedImage(String url){
        final AlertDialog[] holder=new AlertDialog[1]; LinearLayout box=col();box.setPadding(dp(8),dp(8),dp(8),dp(8));box.setBackgroundColor(Color.BLACK);
        ImageView full=new ImageView(this);full.setScaleType(ImageView.ScaleType.FIT_CENTER);full.setBackgroundColor(Color.BLACK);box.addView(full,lp(-1,dp(520)));loadRemoteImage(full,url);
        LinearLayout actions=row();TextView close=action("CLOSE",Color.rgb(70,73,86));TextView save=action("SAVE PHOTO",BLUE);actions.addView(close,weight(1,dp(46)));actions.addView(space(),lp(dp(8),1));actions.addView(save,weight(1,dp(46)));box.addView(actions,top(lp(-1,dp(46)),8));
        AlertDialog dlg=new MyShopDialogBuilder(this).setView(box).create();holder[0]=dlg;close.setOnClickListener(v->dlg.dismiss());save.setOnClickListener(v->{save.setEnabled(false);save.setText("SAVING…");saveImageToGallery(url,ok->runOnUiThread(()->{save.setEnabled(true);save.setText("SAVE PHOTO");toast(ok?"✓ Photo saved to gallery":"Save failed. Please try again.");}));});dlg.show();
        if(dlg.getWindow()!=null){dlg.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);dlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.BLACK));}
    }
    private interface SaveResult{void done(boolean ok);}
    private void saveImageToGallery(String url,SaveResult result){imagePool.execute(()->{boolean ok=false;try{Bitmap bm=imageCache.get(url);if(bm==null){HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(12000);c.setRequestProperty("User-Agent","MY-SHOP/2.9.241");MediaAccess640.authorize(this,c);try(InputStream in=c.getInputStream()){bm=BitmapFactory.decodeStream(in);}c.disconnect();}if(bm==null)throw new Exception("decode failed");String name="MY_SHOP_"+System.currentTimeMillis()+".jpg";if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");v.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/myshop");v.put(MediaStore.Images.Media.IS_PENDING,1);Uri u=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(u==null)throw new Exception("insert failed");try(OutputStream out=getContentResolver().openOutputStream(u)){if(out==null||!bm.compress(Bitmap.CompressFormat.JPEG,95,out))throw new Exception("write failed");}v.clear();v.put(MediaStore.Images.Media.IS_PENDING,0);getContentResolver().update(u,v,null,null);ok=true;}else{File dir=new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES),"myshop");if(!dir.exists())dir.mkdirs();File f=new File(dir,name);try(OutputStream out=new FileOutputStream(f)){if(!bm.compress(Bitmap.CompressFormat.JPEG,95,out))throw new Exception("write failed");}MediaScannerConnection.scanFile(MainActivity.this,new String[]{f.getAbsolutePath()},new String[]{"image/jpeg"},null);ok=true;}}catch(Exception ignored){}result.done(ok);});}

    private void deletePost(long id){new MyShopDialogBuilder(this).setTitle("Delete this post?").setMessage("The post will be removed. User account and Permanent ID will not be affected.").setNegativeButton(LanguageManager.t(this,"cancel"),null).setPositiveButton("DELETE",(d,w)->{BackendClient.Callback cb=new BackendClient.Callback(){public void onSuccess(JSONObject x){toast("✓ Post removed");loadFeed(true);}public void onError(String m){toast("Delete failed: "+m);}};if(SessionManager.isAdmin(this)||SessionManager.isModerator(this))BackendClient.moderatorFeedDelete(SessionManager.getToken(this),id,"Removed from Feed",cb);else BackendClient.feedDelete(SessionManager.getToken(this),id,cb);}).show();}

    private void showEditPostCaption(long postId,String current,TextView target){
        EditText input=new EditText(this);input.setHint("ক্যাপশন লিখুন");input.setText(current);input.setMinLines(2);input.setMaxLines(8);
        WritingColors colors=new WritingColors(this,"post_"+postId,TextAppearance.labels("element_caption",input));
        AlertDialog dialog=new MyShopDialogBuilder(this).setTitle("পোস্টের ক্যাপশন সম্পাদনা").setView(colors.field(input,"element_caption","status")).setNegativeButton(LanguageManager.t(this,"cancel"),null).setPositiveButton("সেভ",null).create();
        dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String value=input.getText().toString().trim();dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);BackendClient.feedEdit(SessionManager.getToken(this),postId,value,new BackendClient.Callback(){public void onSuccess(JSONObject result){runOnUiThread(()->{if(target!=null){target.setText(value);target.setVisibility(value.isEmpty()?View.GONE:View.VISIBLE);}if(target!=null)TextAppearance.bind(MainActivity.this,"post_"+postId,TextAppearance.labels("element_caption",target));colors.styles=colors.payload(input.getText().toString(),value);colors.publish(()->{if(target!=null)TextAppearance.bind(MainActivity.this,"post_"+postId,TextAppearance.labels("element_caption",target));dialog.dismiss();toast("ক্যাপশন ও রঙ আপডেট হয়েছে");},m->{dialog.getButton(-1).setEnabled(true);toast("ক্যাপশন সেভ হয়েছে; রঙ হয়নি: "+m);});});}public void onError(String message){runOnUiThread(()->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);toast("ক্যাপশন সেভ হয়নি: "+message);});}});}));
        dialog.show();
    }

    private void openRequestedComposer(Intent request){String kind=request.getStringExtra("profileComposerKind");request.removeExtra("profileComposerKind");if("image".equals(kind)||"video".equals(kind))pickPost(kind);else showTextPostDialog();}
    private void pickPost(String type){
        if(SessionManager.getToken(this)==null||SessionManager.getToken(this).isEmpty()){startActivity(new Intent(this,AccountActivity.class));return;}
        Intent i=new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);
        i.setType("video".equals(type)?"video/*":"image/*");
        pendingPostMime="video".equals(type)?"video/mp4":"image/jpeg";
        startActivityForResult(i,PICK_POST);
    }

    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r!=PICK_POST||c!=RESULT_OK||data==null)return;Uri chosen641=data.getData();if(chosen641==null&&data.getClipData()!=null&&data.getClipData().getItemCount()>0)chosen641=data.getClipData().getItemAt(0).getUri();if(chosen641==null)return;pendingPostUri=chosen641;String mime641=getContentResolver().getType(chosen641);if(mime641!=null)pendingPostMime=mime641;showPostCaptionDialog();}
    private String postPrivacy640="PUBLIC";
    private void showPostCaptionDialog(){showPostComposer640(true);}
    private void showTextPostDialog(){showPostComposer640(false);}
    private void showPostComposer640(boolean media){
        final android.app.Dialog dialog=new android.app.Dialog(this);LinearLayout body=col();body.setPadding(dp(14),dp(12),dp(14),dp(16));body.setBackgroundColor(Color.WHITE);
        LinearLayout top=row();TextView close=text("×",NAVY,27,false);close.setGravity(Gravity.CENTER);close.setOnClickListener(v->dialog.dismiss());top.addView(close,lp(dp(40),dp(48)));TextView title=text(UiStrings.label(this,"Create Post"),NAVY,17,true);title.setGravity(Gravity.CENTER);top.addView(title,weight(1,dp(48)));TextView publish=text(UiStrings.label(this,"Post"),Color.WHITE,14,true);publish.setGravity(Gravity.CENTER);publish.setBackground(round(BLUE,Color.TRANSPARENT,8));top.addView(publish,lp(dp(66),dp(38)));body.addView(top,lp(-1,dp(54)));
        LinearLayout identity=row();identity.setGravity(Gravity.CENTER_VERTICAL);ImageView photo=new ImageView(this);photo.setImageResource(R.drawable.myshop_profile_avatar);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);photo.setBackground(round(Color.WHITE,Color.TRANSPARENT,26));photo.setClipToOutline(true);CachedImages.load(photo,SessionManager.getAvatarUrl(this));identity.addView(photo,lp(dp(48),dp(48)));LinearLayout details=col();details.setPadding(dp(10),0,0,0);TextView who=text(SessionManager.getFullName(this),NAVY,14,true);details.addView(who,lp(-1,-2));Spinner privacy=new Spinner(this);privacy.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,UiStrings.labels(this,new String[]{"Public","Friends","Only me"})));privacy.setSelection("ONLY_ME".equals(postPrivacy640)?2:"FRIENDS".equals(postPrivacy640)?1:0);privacy.setContentDescription("Who can see your post?");privacy.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> parent){}public void onItemSelected(android.widget.AdapterView<?> parent,View view,int at,long id){postPrivacy640=new String[]{"PUBLIC","FRIENDS","ONLY_ME"}[at];}});details.addView(privacy,lp(-2,dp(36)));identity.addView(details,weight(1,-2));body.addView(identity,top(lp(-1,-2),8));
        final EditText caption=new EditText(this);caption.setHint(UiStrings.label(this,"What's on your mind?"));caption.setGravity(Gravity.TOP|Gravity.START);caption.setTextSize(16);caption.setMinLines(6);caption.setBackground(round(0xfff3f4f7,Color.TRANSPARENT,12));caption.setPadding(dp(12),dp(12),dp(12),dp(12));final String draftKey=media?"media_caption":"text_caption";caption.setText(getSharedPreferences("myshop_post_drafts",MODE_PRIVATE).getString(draftKey,""));WritingColors colors=new WritingColors(this,"post_draft",TextAppearance.labels("element_caption",caption));ScrollView content=new ScrollView(this);LinearLayout draft=col();draft.addView(colors.field(caption,"element_caption","status"),lp(-1,-2));
        if(media&&pendingPostUri!=null){ImageView preview=new ImageView(this);preview.setScaleType(ImageView.ScaleType.FIT_CENTER);if(pendingPostMime.startsWith("video/")){preview.setImageResource(R.drawable.feed_action_video);preview.setContentDescription("Selected video • tap to play");final Uri selected641=pendingPostUri;new Thread(()->{android.media.MediaMetadataRetriever retriever641=new android.media.MediaMetadataRetriever();try{retriever641.setDataSource(MainActivity.this,selected641);android.graphics.Bitmap frame641=retriever641.getFrameAtTime(0);runOnUiThread(()->{if(frame641!=null)preview.setImageBitmap(frame641);});}catch(Exception ignored){}finally{try{retriever641.release();}catch(Exception ignored){}}}).start();preview.setOnClickListener(v->{android.app.Dialog movie641=new android.app.Dialog(this);android.widget.VideoView video641=new android.widget.VideoView(this);video641.setVideoURI(selected641);android.widget.MediaController controls641=new android.widget.MediaController(this);controls641.setAnchorView(video641);video641.setMediaController(controls641);movie641.setContentView(video641);movie641.setOnDismissListener(done->video641.stopPlayback());movie641.show();if(movie641.getWindow()!=null)movie641.getWindow().setLayout(-1,dp(360));video641.start();});}else preview.setImageURI(pendingPostUri);draft.addView(preview,top(lp(-1,dp(160)),10));}
        content.addView(draft);body.addView(content,new LinearLayout.LayoutParams(-1,0,1));LinearLayout attachments=row();attachments.addView(feedComposerAction(R.drawable.feed_action_photo,"Photo",0xff12b94d,v->{getSharedPreferences("myshop_post_drafts",MODE_PRIVATE).edit().putString("media_caption",caption.getText().toString()).apply();dialog.dismiss();pickPost("image");}),weight(1,dp(48)));attachments.addView(feedComposerAction(R.drawable.feed_action_video,"Video",0xffef174d,v->{getSharedPreferences("myshop_post_drafts",MODE_PRIVATE).edit().putString("media_caption",caption.getText().toString()).apply();dialog.dismiss();pickPost("video");}),weight(1,dp(48)));body.addView(attachments,lp(-1,dp(48)));
        dialog.setOnDismissListener(d->getSharedPreferences("myshop_post_drafts",MODE_PRIVATE).edit().putString(draftKey,caption.getText().toString()).apply());publish.setOnClickListener(v->{String value=caption.getText().toString().trim();if(value.isEmpty()){caption.setError(UiStrings.label(this,"Please write something first."));return;}if(postPublishing)return;JSONObject style=colors.payload(caption.getText().toString(),value);dialog.dismiss();if(media)uploadPost(value,style);else uploadTextPost(value,style);});dialog.setContentView(body);dialog.show();if(dialog.getWindow()!=null){dialog.getWindow().setLayout(-1,-1);dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.WHITE));dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);}Appearance.dialog(dialog);
    }

    private void uploadTextPost(String caption,JSONObject colors){
        if(caption.isEmpty()){toast("Please write something first.");return;}
        if(postPublishing){toast("পোস্ট পাঠানো হচ্ছে…");return;}
        String token=SessionManager.getToken(this);
        if(token==null||token.isEmpty()){startActivity(new Intent(this,AccountActivity.class));return;}
        postPublishing=true;
        BackendClient.feedText640(token,caption,colors,postPrivacy640,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{postPublishing=false;getSharedPreferences("myshop_post_drafts",MODE_PRIVATE).edit().remove("text_caption").apply();toast("✓ Post published");JSONObject post=d.optJSONObject("post");if(post!=null&&feedList!=null){renderPostAtTop(post);}else{loadFeed(true);}});}
            public void onError(String m){runOnUiThread(()->{postPublishing=false;toast("Post failed: "+m);});}
        });
    }
    private void uploadPost(String caption,JSONObject colors){
        if(pendingPostUri==null){toast("Please select a photo first.");return;}
        if(postPublishing){toast("পোস্ট পাঠানো হচ্ছে…");return;}
        try{
            InputStream in=getContentResolver().openInputStream(pendingPostUri);
            if(in==null){toast("Selected media could not be opened. Please choose it again.");return;}
            String mime=getContentResolver().getType(pendingPostUri);
            if(mime==null||mime.trim().isEmpty())mime=pendingPostMime;
            String name=queryName(pendingPostUri);
            String mediaType=mime.toLowerCase().startsWith("video/")?"video":"image";
            postPublishing=true;
            BackendClient.feedUpload640(SessionManager.getToken(this),in,name,mime,mediaType,caption,colors,postPrivacy640,new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->{postPublishing=false;getSharedPreferences("myshop_post_drafts",MODE_PRIVATE).edit().remove("media_caption").apply();toast("✓ Post published");pendingPostUri=null;JSONObject post=d.optJSONObject("post");if(post!=null&&feedList!=null)renderPostAtTop(post);else loadFeed(true);});}
                public void onError(String m){runOnUiThread(()->{postPublishing=false;toast("Post failed: "+m);});}
            });
        }catch(Exception e){postPublishing=false;toast("Could not open selected media. Please choose the file again.");}
    }
    private String queryName(Uri u){try(android.database.Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}catch(Exception ignored){}return "myshop-post";}

    private View bottom(){
        LinearLayout n=row();bottomNavView=n;n.setClipChildren(false);n.setClipToPadding(false);n.setPadding(dp(4),dp(2),dp(4),dp(1));n.setBackgroundColor(Color.WHITE);n.setElevation(dp(7));
        String[] keys={"home","store","live","video","profile"};
        int[] icons={R.drawable.nav_home,R.drawable.nav_store,R.drawable.nav_live,R.drawable.nav_support,R.drawable.nav_more540};
        String[] labels={LanguageManager.t(this,"home"),"myshop","Live","Video","Profile"};
        int[] colors={Color.rgb(20,112,247),Color.rgb(20,112,247),Color.rgb(255,23,89),0xff101934,0xff101934};
        java.util.ArrayList<Integer> order=new java.util.ArrayList<>();for(int i=0;i<5;i++)order.add(i);
        android.content.SharedPreferences sp=getSharedPreferences("myshop_bottom_nav",MODE_PRIVATE);
        java.util.Collections.sort(order,(a,b)->Integer.compare(sp.getInt("order_"+keys[a],a+1),sp.getInt("order_"+keys[b],b+1)));
        for(int idx:order)addNav(n,navItem(icons[idx],labels[idx],"home".equals(keys[idx]),keys[idx],colors[idx]));pinLive640(n);
        if(SessionManager.isAdmin(this)) n.setOnDragListener((v,e)->handleBottomNavDrag(n,e));
        return n;
    }
    private boolean handleBottomNavDrag(LinearLayout nav,android.view.DragEvent e){
        if(e.getAction()==android.view.DragEvent.ACTION_DROP){Object state=e.getLocalState();if(!(state instanceof View))return false;View dragged=(View)state;int target=Math.min(nav.getChildCount()-1,Math.max(0,(int)(e.getX()/Math.max(1f,nav.getWidth()/(float)Math.max(1,nav.getChildCount())))));int from=nav.indexOfChild(dragged);if(from>=0&&target>=0&&from!=target){nav.removeView(dragged);nav.addView(dragged,target,new LinearLayout.LayoutParams(0,dp(76),1));pinLive640(nav);saveBottomNavOrder(nav);}dragged.setVisibility(View.VISIBLE);return true;}
        if(e.getAction()==android.view.DragEvent.ACTION_DRAG_ENDED&&e.getLocalState() instanceof View)((View)e.getLocalState()).setVisibility(View.VISIBLE);
        return true;
    }
    private void saveBottomNavOrder(LinearLayout nav){
        try{JSONArray arr=new JSONArray();android.content.SharedPreferences.Editor ed=getSharedPreferences("myshop_bottom_nav",MODE_PRIVATE).edit();for(int i=0;i<nav.getChildCount();i++){View v=nav.getChildAt(i);String key=String.valueOf(v.getTag());ed.putInt("order_"+key,i+1);arr.put(new JSONObject().put("key","bottom_nav_"+key).put("title",key).put("active",true).put("displayOrder",i+1));}ed.apply();BackendClient.adminContentPut(SessionManager.getToken(this),new JSONObject().put("featureButtons",arr),new BackendClient.Callback(){public void onSuccess(JSONObject x){runOnUiThread(()->toast("Navigation order published"));}public void onError(String m){runOnUiThread(()->toast("Saved on this device; server publish failed"));}});}catch(Exception ignored){}
    }
    private void applyBottomNavOrder(JSONArray features){
        if(features==null||bottomNavView==null)return;try{java.util.HashMap<String,Integer> map=new java.util.HashMap<>();for(int i=0;i<features.length();i++){JSONObject f=features.optJSONObject(i);if(f==null)continue;String key=f.optString("key","");if(key.startsWith("bottom_nav_"))map.put(key.substring(11),Math.max(1,f.optInt("display_order",f.optInt("displayOrder",99))));}if(map.isEmpty())return;android.content.SharedPreferences.Editor ed=getSharedPreferences("myshop_bottom_nav",MODE_PRIVATE).edit();for(java.util.Map.Entry<String,Integer>x:map.entrySet())ed.putInt("order_"+x.getKey(),x.getValue());ed.apply();java.util.ArrayList<View> vs=new java.util.ArrayList<>();while(bottomNavView.getChildCount()>0){View v=bottomNavView.getChildAt(0);bottomNavView.removeViewAt(0);vs.add(v);}java.util.Collections.sort(vs,(a,b)->Integer.compare(map.getOrDefault(String.valueOf(a.getTag()),99),map.getOrDefault(String.valueOf(b.getTag()),99)));for(View v:vs)addNav(bottomNavView,v);pinLive640(bottomNavView);}catch(Exception ignored){}
    }
    private void pinLive640(LinearLayout nav){for(int at=0;at<nav.getChildCount();at++)if("live".equals(nav.getChildAt(at).getTag())){if(at!=2){View live=nav.getChildAt(at);nav.removeViewAt(at);nav.addView(live,Math.min(2,nav.getChildCount()),new LinearLayout.LayoutParams(0,dp(76),1));}return;}}
    private void addNav(LinearLayout parent,View child){parent.addView(child,new LinearLayout.LayoutParams(0,dp(76),1));}
    private View navItem(int iconRes,String label,boolean active,String key,int color){View item=SharedPageNav.item(this,iconRes,label,active,key,color,v->{if("home".equals(key)){pendingHomeScrollRestore=-1;getSharedPreferences("myshop_home_state",MODE_PRIVATE).edit().putInt(STATE_HOME_SCROLL_Y,0).apply();if(scroll!=null)scroll.smoothScrollTo(0,0);return;}if("store".equals(key))FeatureAccess.open(this,"my_shop",()->startActivity(new Intent(this,PhysicalStoreActivity.class)));else if("live".equals(key))startActivity(new Intent(this,LiveHomeActivity.class));else if("video".equals(key))startActivity(new Intent(this,ShortVideoActivity.class));else if("profile".equals(key))startActivity(new Intent(this,UserMenuActivity.class).putExtra("profile_context",true));else if("support".equals(key))openSupport();else if("more".equals(key))showMoreQuickActions();});if(SessionManager.isAdmin(this))item.setOnLongClickListener(v->{v.startDragAndDrop(android.content.ClipData.newPlainText("nav",key),new View.DragShadowBuilder(v),v,0);v.setVisibility(View.INVISIBLE);return true;});return item;}


    private void openMyFeed(){
        if(scroll==null)return;
        final View target=feedAnchor!=null?feedAnchor:feedList;
        if(target==null){scroll.smoothScrollTo(0,Math.max(0,scroll.getChildAt(0)==null?0:scroll.getChildAt(0).getHeight()/2));return;}
        scroll.post(()->{int y=Math.max(0,target.getTop()-dp(10));scroll.smoothScrollTo(0,y);if(feedStatus!=null&&System.currentTimeMillis()-lastFeedLoadAt>8000)loadFeed(true);});
    }

    private void showMoreQuickActions(){
        final AppThemePalette palette=AppThemePalette.current(this);
        final PopupWindow[] holder=new PopupWindow[1];
        LinearLayout sheet=col();sheet.setPadding(dp(12),dp(9),dp(12),dp(12));sheet.setBackground(round(palette.card,palette.border,22));
        LinearLayout head=row();head.addView(text(UiStrings.label(MainActivity.this,"Quick Links • See All"),palette.text,15,true),weight(1,dp(34)));TextView close=text("✕",palette.muted,15,true);close.setGravity(Gravity.CENTER);head.addView(close,lp(dp(38),dp(34)));sheet.addView(head,lp(-1,dp(36)));
        sheet.addView(text("All Home Page 1 shortcuts",palette.muted,8,false),lp(-1,dp(22)));
        ArrayList<Integer> ids=new ArrayList<>();for(int i:new int[]{0,1,2,8,4,9})if(mainActive[i])ids.add(i);
        if(ids.isEmpty()){TextView empty=text("No Quick Links are published yet.",palette.muted,9.0f,false);empty.setGravity(Gravity.CENTER);sheet.addView(empty,lp(-1,dp(64)));}
        int cols=4,index=0;while(index<ids.size()){LinearLayout r=row();for(int c=0;c<cols;c++){if(index<ids.size()){final int idx=ids.get(index++);LinearLayout cell=quickCell(mainIcons[idx],mainTitles[idx]);cell.setTag(R.id.visual_design_key,"element_"+mainKeys[idx]+"_container");cell.setMinimumHeight(dp(92));TextView label=(TextView)cell.getChildAt(1);label.setTag(R.id.visual_design_key,"element_"+mainKeys[idx]+"_label");if(!mainKeys[idx].matches(".*(?:live|rtc|audio|room|gift).*"))TextAppearance.bind(this,"feature_"+mainKeys[idx],TextAppearance.labels("element_title",label));label.setLayoutParams(lp(-1,-2));FrameLayout iconShell=(FrameLayout)cell.getChildAt(0);ImageView custom=(ImageView)iconShell.getChildAt(0);custom.setTag(R.id.visual_design_key,"element_"+mainKeys[idx]+"_icon");int qsz=Math.max(28,Math.min(56,mainIconSize[idx]));iconShell.setLayoutParams(lp(dp(qsz),dp(qsz)));if(mainRemoteIconUrls[idx]!=null&&!mainRemoteIconUrls[idx].trim().isEmpty()){loadRemoteImage(custom,mainRemoteIconUrls[idx].trim());}cell.setOnClickListener(v->{if(holder[0]!=null)holder[0].dismiss();openHomeShortcut(idx);});cell.setOnLongClickListener(v->{if(!SessionManager.isAdmin(this))return false;new MyShopDialogBuilder(this).setTitle(mainTitles[idx]).setItems(new String[]{"এডমিন প্যানেল","আইকন মাপ / অবস্থান","লেখার রং / ফন্ট মাপ"},(dialog,which)->{if(which==2){VisualDesign.edit(this,sheet,"home_quick");return;}if(holder[0]!=null)holder[0].dismiss();if(which==0)startActivity(new Intent(this,AdminSectionActivity.class).putExtra("section","feature_card").putExtra("managed_category","feature_"+mainKeys[idx]).putExtra("managed_title",mainTitles[idx]).putExtra("admin_context",true));else startActivity(new Intent(this,PageIconAdminActivity.class).putExtra("page","home1"));}).show();return true;});r.addView(cell,weight(1,-2));}else r.addView(space(),weight(1,dp(92)));}sheet.addView(r,top(lp(-1,-2),4));}
        if(SessionManager.isAdmin(this)){
            LinearLayout adminRow=row();adminRow.setGravity(Gravity.CENTER);LinearLayout admin=quickCell(R.drawable.premium438_crown,"Admin");
            admin.setContentDescription("Admin Panel");admin.setOnClickListener(v->{if(holder[0]!=null)holder[0].dismiss();startActivity(new Intent(this,AdminCatalogActivity.class).putExtra("admin_context",true));});
            adminRow.addView(admin,weight(1,dp(84)));for(int k=0;k<2;k++)adminRow.addView(space(),weight(1,dp(84)));sheet.addView(adminRow,top(lp(-1,dp(84)),4));
        }
        PanelDesign.adminButton(this,sheet,"home_quick");PanelDesign.apply(this,sheet,"home_quick");sheet.setTag(R.id.visual_design_layout,(Runnable)()->{if(holder[0]==null)return;sheet.measure(View.MeasureSpec.makeMeasureSpec(getResources().getDisplayMetrics().widthPixels,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED));holder[0].update(ViewGroup.LayoutParams.MATCH_PARENT,Math.min(sheet.getMeasuredHeight(),getResources().getDisplayMetrics().heightPixels-dp(150)));});VisualDesign.apply(this,sheet,"home_quick");ScrollView sheetScroll=new ScrollView(this);sheetScroll.setFillViewport(false);sheetScroll.addView(sheet);int maxSheetHeight=getResources().getDisplayMetrics().heightPixels-dp(150);sheet.measure(View.MeasureSpec.makeMeasureSpec(getResources().getDisplayMetrics().widthPixels,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(0,View.MeasureSpec.UNSPECIFIED));PopupWindow pop=new PopupWindow(sheetScroll,ViewGroup.LayoutParams.MATCH_PARENT,Math.min(sheet.getMeasuredHeight(),maxSheetHeight),true);holder[0]=pop;pop.setBackgroundDrawable(round(palette.card,Color.TRANSPARENT,22));pop.setOutsideTouchable(true);pop.setElevation(dp(12));close.setOnClickListener(v->pop.dismiss());pop.showAtLocation(getWindow().getDecorView(),Gravity.BOTTOM,0,dp(70));sheet.setTranslationY(dp(24));sheet.setAlpha(0f);sheet.animate().translationY(0f).alpha(1f).setDuration(180).start();
    }
    private LinearLayout quickCell(int iconRes,String label){
        AppThemePalette palette=AppThemePalette.current(this);LinearLayout c=col();c.setGravity(Gravity.CENTER);c.setPadding(dp(2),dp(4),dp(2),dp(3));
        FrameLayout shell=new FrameLayout(this);shell.setElevation(dp(3));shell.setBackgroundColor(Color.TRANSPARENT);
        ImageView i=new ImageView(this);PremiumArt.apply(i,iconRes);i.setScaleType(ImageView.ScaleType.CENTER_INSIDE);i.setPadding(0,0,0,0);shell.addView(i,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));c.addView(shell,lp(dp(PremiumIconLibrary.QUICK_SIZE_DP),dp(PremiumIconLibrary.QUICK_SIZE_DP)));
        TextView t=text(label,palette.text,8.1f,true);t.setGravity(Gravity.CENTER);t.setMaxLines(2);c.addView(t,lp(-1,dp(30)));c.setBackground(round(Color.TRANSPARENT,Color.TRANSPARENT,12));applyRipple(c);return c;
    }
    private void runQuickAction(String label){
        if("Page".equals(label))openHomeShortcut(0);else if("Website".equals(label))openHomeShortcut(1);else if("My Level".equals(label))openHomeShortcut(2);else if("Membership".equals(label))openHomeShortcut(3);else if("Earn Rewards".equals(label))openHomeShortcut(4);else if("Gallery +".equals(label))openHomeShortcut(5);else if("External Media".equals(label))openHomeShortcut(6);else if("Help Center".equals(label))openHomeShortcut(7);else if("Top Up".equals(label))openHomeShortcut(8);else if("Share App".equals(label))openHomeShortcut(9);
    }
    private void openShortcutByKey(String title,String key){if(SessionManager.isAdmin(this)){openAdminFolder(title,key);return;}String u=featureRemoteUrl(key);if(!FeatureRegistry.isSafeHttpUrl(u)){toast(title+" link is not configured yet.");return;}try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){toast("Could not open "+title);}}
    private void openGalleryExternalAdmin(){String[] items={"Gallery Photo/Audio/Video","External Links"};new MyShopDialogBuilder(this).setTitle("GALLERY + EXTERNAL ADMIN").setItems(items,(d,w)->{if(w==0)startActivity(new Intent(this,GalleryAdminActivity.class).putExtra("admin_context",true));else startActivity(new Intent(this,AdminSectionActivity.class).putExtra("section","external_movie").putExtra("admin_context",true));}).show();}
    private void openDirectFeature(String title,String key){try{if("chat".equals(key)){startActivity(new Intent(this,InboxActivity.class));return;}if(SessionManager.isAdmin(this)){openAdminFolder(title,key);return;}Intent i=new Intent(MainActivity.this,FeatureActivity.class);i.putExtra("title",title);i.putExtra("feature_key",key);String u=featureRemoteUrl(key);if(FeatureRegistry.isSafeHttpUrl(u))i.putExtra("url",u);startActivity(i);}catch(Throwable t){toast(title+" is ready.");}}
    private void openAdminFolder(String title,String key){Intent i=new Intent(this,AdminFolderActivity.class);i.putExtra("title",title);i.putExtra("feature_key",key);i.putExtra("admin_context",true);startActivity(i);}
    private void shareAppFromDashboard(){try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"myshop");i.putExtra(Intent.EXTRA_TEXT,AppDistribution.shareText());startActivity(Intent.createChooser(i,"Share myshop"));}catch(Exception e){toast("Share is not available.");}}

    private void openSupport(){
        
        // Open the owner's WhatsApp chat directly; never print the phone number in MY SHOP UI.
        String message=Uri.encode("Message 𒆜 𝐓𝐨𝐮𝐡𝐢𝐝 𒆜 on WhatsApp");
        Uri target=Uri.parse(PanelDesign.homeSupportLink(this));
        try{
            Intent direct=new Intent(Intent.ACTION_VIEW,target).setPackage("com.whatsapp");
            startActivity(direct);
        }catch(Exception noWhatsApp){
            try{startActivity(new Intent(Intent.ACTION_VIEW,target));}
            catch(Exception unavailable){startActivity(new Intent(this,HelpCenterActivity.class));}
        }
    }
    private String powerAdText(){ String l=LanguageManager.get(this); if(LanguageManager.BN.equals(l))return "⚡  পাওয়ার অ্যাড বাই তৌহিদ"; if(LanguageManager.HI.equals(l))return "⚡  पावर ऐड द्वारा तौहिद"; if(LanguageManager.AR.equals(l))return "⚡  إعلان قوي بواسطة توحيد"; return "⚡  POWER AD by Touhid"; }
    private void applyPowerAdColors(TextView v){ String s=v.getText().toString(); SpannableString sp=new SpannableString(s); if(s.length()>0)sp.setSpan(new ForegroundColorSpan(Color.rgb(245,145,0)),0,1,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); int mid=Math.min(s.length(),Math.max(1,s.length()/2)); sp.setSpan(new ForegroundColorSpan(Color.rgb(91,38,214)),1,mid,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); if(mid<s.length())sp.setSpan(new ForegroundColorSpan(Color.rgb(235,45,100)),mid,s.length(),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); v.setText(sp); }

    private void loadCurrentProfile(){String token=SessionManager.getToken(this);if(token==null||token.isEmpty())return;BackendClient.me(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){JSONObject u=d.optJSONObject("user");if(u!=null){String avatar=u.optString("avatarUrl","").trim();SessionManager.saveProfile(MainActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""),avatar,u.optString("bio",""));runOnUiThread(()->{if(!avatar.isEmpty()){if(headerAvatar!=null)loadRemoteImage(headerAvatar,avatar);if(composerAvatar!=null)loadRemoteImage(composerAvatar,avatar);}});}}public void onError(String m){}});}
    private int safeColor(String hex,int fallback){try{String x=hex==null?"":hex.trim();return x.matches("#[0-9A-Fa-f]{6}")?Color.parseColor(x):fallback;}catch(Exception e){return fallback;}}

    private boolean dashboardInFlight=false, dashboardCacheApplied=false;
    private void loadRemote(){
        if(dashboardInFlight||dashboardDestroyed)return;
        if(!dashboardCacheApplied){dashboardCacheApplied=true;String cached=getSharedPreferences("myshop_home_visual_cache",MODE_PRIVATE).getString("visual_"+SessionManager.getUserId(this),"");if(!cached.isEmpty())try{applyRemote(new JSONObject(cached));}catch(Exception ignored){}}
        dashboardInFlight=true;BackendClient.dashboard632(SessionManager.getToken(this),SessionManager.isAdmin(this)&&getIntent().getBooleanExtra("home_layout_preview632",false),new BackendClient.Callback(){public void onSuccess(JSONObject d){dashboardInFlight=false;if(dashboardDestroyed)return;runOnUiThread(()->{if(dashboardDestroyed)return;applyRemote(d);saveHomeVisualCache(d);if(newsText!=null&&newsText.getTextSize()/getResources().getDisplayMetrics().scaledDensity<10.0f)newsText.setTextSize(10.0f);restartNewsMarquee();scheduleHeroCarousel(900L);});}public void onError(String m){dashboardInFlight=false;}});}
    private void saveHomeVisualCache(JSONObject d){if(getIntent().getBooleanExtra("home_layout_preview632",false))return;try{JSONObject visual=new JSONObject();for(String key:new String[]{"config","banners","dashboardAds","translations","featureButtons","managedLinks"})if(d.has(key))visual.put(key,d.get(key));String value=visual.toString();if(value.length()<512000)getSharedPreferences("myshop_home_visual_cache",MODE_PRIVATE).edit().putString("visual_"+SessionManager.getUserId(this),value).apply();}catch(Exception ignored){}}
    private void applyRemote(JSONObject d){try{UiStrings.cache(this,d.optJSONArray("translations"));JSONObject c=d.optJSONObject("config");if(c!=null){String n=UiStrings.content(this,"breaking_news",c.optString("breaking_news","")).trim();if(!n.isEmpty()&&newsText!=null)newsText.setText(n);newsTextSizeSp=(float)Math.max(10.0,Math.min(24.0,c.optDouble("breaking_news_text_size",13.0)));if(newsText!=null){newsText.setTextSize(newsTextSizeSp);int fg=safeColor(c.optString("breaking_news_text_color","#414662"),Color.rgb(65,70,98));newsText.setTextColor(fg);if(breakingBox!=null){int bg=safeColor(c.optString("breaking_news_bg_color","#FFEFF7"),Color.rgb(255,239,247));int stroke=Color.argb(70,Color.red(fg),Color.green(fg),Color.blue(fg));breakingBox.setBackground(round(bg,Color.TRANSPARENT,11));Appearance.preserve(breakingBox);}}// V640: published headline colors are independent of the personal Sun/Moon preference.
if(newsText!=null)TextAppearance.bind(this,"headline",TextAppearance.labels("element_headline",newsText));saveRemoteUrl("my_shop",c.optString("my_shop_url",""));saveRemoteUrl("live_tv",c.optString("live_tv_url",""));saveRemoteUrl("external_movie",c.optString("external_movie_url",""));saveRemoteUrl("chat",c.optString("chat_url",""));if(powerAdTitle!=null){powerAdTitle.setText(UiStrings.content(this,"power_ad_title",c.optString("power_ad_title","POWER AD")));powerAdByline.setText(UiStrings.content(this,"power_ad_byline",c.optString("power_ad_byline","by Touhid")));}ThemeConfig.cacheFromConfig(this,c);}for(int z=0;z<remoteHeroUrls.length;z++){remoteHeroUrls[z]="";remoteHeroTargets[z]="";remoteHeroSeconds[z]=4;}for(int z=0;z<remotePromoUrls.length;z++){remotePromoUrls[z]="";remotePromoTargets[z]="";remotePromoSeconds[z]=4;}JSONArray banners=d.optJSONArray("banners");if(banners!=null){for(int i=0;i<banners.length();i++){JSONObject o=banners.optJSONObject(i);if(o==null)continue;String folder=o.optString("folder","");int slot=o.optInt("slot",0);String url=o.optString("image_url","").trim();String target=o.optString("target_url","").trim();String updated=o.optString("updated_at","").trim();if(!updated.isEmpty()&&!url.contains("?"))url=url+"?v="+Uri.encode(updated);if(url.isEmpty())continue;if("hero".equalsIgnoreCase(folder)&&slot>=1&&slot<=20){remoteHeroUrls[slot-1]=url;remoteHeroTargets[slot-1]=target;remoteHeroSeconds[slot-1]=Math.max(1,Math.min(30,o.optInt("display_seconds",4)));}else if("promo".equalsIgnoreCase(folder)&&slot>=1&&slot<=20){remotePromoUrls[slot-1]=url;remotePromoTargets[slot-1]=target;remotePromoSeconds[slot-1]=Math.max(1,Math.min(30,o.optInt("display_seconds",4)));}}}showFirstRemoteHeroIfAvailable();if(promoArt632!=null){boolean any=false;for(String u:remotePromoUrls)if(u!=null&&!u.isEmpty())any=true;promoArt632.setVisibility(any?View.VISIBLE:View.GONE);}applyPromoSlide();JSONArray managedLinks=d.optJSONArray("managedLinks");renderDynamicFolders(managedLinks);applyManagedFeatureCards(managedLinks);applyHomeMenuConfig(managedLinks);JSONArray ads=d.optJSONArray("dashboardAds");liveAds.clear();if(ads!=null){for(int i=0;i<ads.length();i++){JSONObject o=ads.optJSONObject(i);if(o!=null&&"live_now".equalsIgnoreCase(o.optString("box_key","")))liveAds.add(o);}}if(liveAdStripView!=null)liveAdStripView.setVisibility(View.VISIBLE); renderPowerAds();JSONArray features=d.optJSONArray("featureButtons");if(features!=null){for(int i=0;i<features.length();i++){JSONObject f=features.optJSONObject(i);if(f==null)continue;String key=f.optString("key","");for(int j=0;j<mainKeys.length;j++)if(mainKeys[j].equals(key)){mainRemoteUrls[j]=f.optString("target_url","");String legacyIcon=f.optString("icon_url","");if(mainRemoteIconUrls[j]==null||mainRemoteIconUrls[j].isEmpty())mainRemoteIconUrls[j]=legacyIcon;mainDisplayOrder[j]=Math.max(1,f.optInt("display_order",j+1));mainIconSize[j]=Math.max(28,Math.min(56,f.optInt("icon_size",38)));mainActive[j]=f.optInt("active",j<14?1:0)==1;String label=UiStrings.content(this,"feature_"+key,f.optString("title","")).trim();if(!label.isEmpty())mainTitles[j]=label;}}if(quickTrack!=null)renderQuickLinks();applyBottomNavOrder(features);}}catch(Exception ignored){}}
    private void saveRemoteUrl(String key,String url){if(url!=null&&!url.trim().isEmpty())getSharedPreferences("myshop_remote_config",MODE_PRIVATE).edit().putString("url_"+key,url.trim()).apply();}
    private void openFeatureCardAdmin(String category,String title){Intent a=new Intent(this,AdminSectionActivity.class);a.putExtra("section","feature_card");a.putExtra("managed_category",category);a.putExtra("managed_title",title);a.putExtra("admin_context",true);startActivity(a);}
    private void applyManagedFeatureCards(JSONArray links){
        android.content.SharedPreferences sp=getSharedPreferences("myshop_remote_config",MODE_PRIVATE); android.content.SharedPreferences.Editor ed=sp.edit();
        for(int j=0;j<mainKeys.length;j++){if(mainCards[j]!=null){mainCards[j].setVisibility(View.VISIBLE);mainCards[j].setAlpha(1f);}if(mainLabels[j]!=null)mainLabels[j].setText(mainTitles[j]);if(mainIconViews[j]!=null)PremiumArt.apply(mainIconViews[j],mainIcons[j]);ed.remove("managed_url_"+mainKeys[j]);ed.remove("managed_title_"+mainKeys[j]);}
        String[] clearKeys={"go_live","live_now","live_tv","external_movie","my_feed","social_media","earn_reward","more_apps","gallery","my_shop"}; for(String k:clearKeys)ed.remove("managed_url_"+k);
        if(links!=null)for(int i=0;i<links.length();i++){JSONObject x=links.optJSONObject(i);if(x==null)continue;String cat=x.optString("category","").trim();if(!cat.startsWith("feature_"))continue;String key=cat.substring(8);int active=x.optInt("active",1);String title=UiStrings.content(this,"managed_"+x.optLong("id",0)+"_title",x.optString("title","")).trim();String url=x.optString("url","").trim();String image=x.optString("image_url","").trim();String icon=x.optString("icon_url","").trim();ed.putInt("managed_active_"+key,active);ed.putString("managed_url_"+key,url);ed.putString("managed_title_"+key,title);for(int j=0;j<mainKeys.length;j++)if(mainKeys[j].equals(key)){mainRemoteIconUrls[j]=!image.isEmpty()?image:icon;boolean adminMode=SessionManager.isAdmin(this);if(mainCards[j]!=null){mainCards[j].setVisibility(active==1||adminMode?View.VISIBLE:View.GONE);mainCards[j].setAlpha(active==1?1f:0.48f);}if(mainLabels[j]!=null){if(active==1&&!title.isEmpty())mainLabels[j].setText(title);else if(active!=1&&adminMode)mainLabels[j].setText((title.isEmpty()?mainTitles[j]:title)+" • HIDDEN");}if(mainIconViews[j]!=null&&(active==1||adminMode)){PremiumArt.apply(mainIconViews[j],mainIcons[j]);if(!image.isEmpty()){mainIconViews[j].clearColorFilter();loadRemoteImage(mainIconViews[j],image);}else if(!icon.isEmpty()){mainIconViews[j].clearColorFilter();loadRemoteImage(mainIconViews[j],icon);}else mainIconViews[j].clearColorFilter();}}}
        ed.apply();
    }
    private String featureRemoteUrl(String key){String managed=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("managed_url_"+key,"").trim();if(!managed.isEmpty())return managed;for(int i=0;i<mainKeys.length;i++)if(mainKeys[i].equals(key))return mainRemoteUrls[i]==null?"":mainRemoteUrls[i].trim();return getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("url_"+key,"");}
    private void openFeature(String title,String key){try{
        if("chat".equals(key)){openDirectFeature(title,key);return;}
        if(SessionManager.isAdmin(this)){openAdminFolder(title,key);return;}
        if("gallery".equals(key)){startActivity(new Intent(this,GalleryActivity.class));return;}
        Intent i=new Intent(MainActivity.this,FeatureActivity.class);String managedTitle=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("managed_title_"+key,"").trim();i.putExtra("title",managedTitle.isEmpty()?title:managedTitle);i.putExtra("feature_key",key);String url=featureRemoteUrl(key);if("my_shop".equals(key)&&url.isEmpty())url=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("url_my_shop",url);if("external_movie".equals(key)&&url.isEmpty())url=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("url_external_movie",url);if(FeatureRegistry.isSafeHttpUrl(url))i.putExtra("url",url);else{String fallback=FeatureRegistry.getUrl(this,key);if(FeatureRegistry.isSafeHttpUrl(fallback))i.putExtra("url",fallback);}startActivity(i);}catch(Throwable t){toast(title+" is ready.");}}
    private void applyLiveAd(int index){if(liveAdImage==null||liveAds.isEmpty())return;JSONObject a=liveAds.get(index%liveAds.size());String u=a.optString("image_url","");String cap=UiStrings.content(this,"ad_"+a.optLong("id",0)+"_caption",a.optString("caption",""));if(!u.isEmpty())loadRemoteImage(liveAdImage,u);liveAdCaption.setText(cap.isEmpty()?"Advertisement":cap);liveAdImage.setOnClickListener(v->{String target=a.optString("target_url","");if(FeatureRegistry.isSafeHttpUrl(target)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception ignored){}}});}
    private void startLiveAdCarousel(){scheduleLiveAdCarousel();}
    private void scheduleLiveAdCarousel(){handler.removeCallbacks(liveAdCarouselTick);if(dashboardVisible&&!dashboardDestroyed)handler.postDelayed(liveAdCarouselTick,5000);}
    private void openPromoTarget(int visibleIndex){int idx=(promoSlide+visibleIndex)%promoCount();String t=remotePromoTargets[idx];if(FeatureRegistry.isSafeHttpUrl(t)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(t)));}catch(Exception ignored){}}}

    private int promoCount(){for(int i=remotePromoUrls.length-1;i>=0;i--)if(remotePromoUrls[i]!=null&&!remotePromoUrls[i].isEmpty())return i+1;return 6;}
    private void applyPromoSlide(){if(promoViews==null||promoViews.length<2)return;int idx=promoSlide%promoCount();for(int i=0;i<2;i++){final int slotIndex=i;final int slideIndex=(idx+i)%promoCount();final String u=remotePromoUrls[slideIndex];final ImageView v=promoViews[i];if(v==null)continue;v.animate().alpha(0.35f).setDuration(180).withEndAction(()->{v.setTag(null);v.setImageDrawable(null);if(u!=null&&!u.isEmpty())loadRemoteImage(v,u);else v.setImageResource(slotIndex==0?left[slideIndex%left.length]:right[slideIndex%right.length]);v.animate().alpha(1f).setDuration(260).start();}).start();}}
    private void startPromoCarousel(){schedulePromoCarousel();}
    private void schedulePromoCarousel(){handler.removeCallbacks(promoCarouselTick);if(dashboardVisible&&!dashboardDestroyed)handler.postDelayed(promoCarouselTick,4000);}

    private int previousHeroSlide(int current){boolean any=false;for(String u:remoteHeroUrls)if(u!=null&&!u.isEmpty()){any=true;break;}if(any){for(int step=1;step<=remoteHeroUrls.length;step++){int idx=(current-step+remoteHeroUrls.length*2)%remoteHeroUrls.length;if(remoteHeroUrls[idx]!=null&&!remoteHeroUrls[idx].isEmpty())return idx;}}return (current+5)%6;}
    private void openHeroTarget(){if(SessionManager.isAdmin(this)){startActivity(new Intent(this,BannerAdminActivity.class).putExtra("admin_context",true));return;}String t=(slide>=0&&slide<remoteHeroTargets.length)?remoteHeroTargets[slide]:"";if(FeatureRegistry.isSafeHttpUrl(t)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(t)));}catch(Exception ignored){}}}
    private int nextHeroSlide(int current){
        boolean any=false; for(String u:remoteHeroUrls) if(u!=null&&!u.isEmpty()){any=true;break;}
        if(any){for(int step=1;step<=remoteHeroUrls.length;step++){int idx=(current+step)%remoteHeroUrls.length;if(remoteHeroUrls[idx]!=null&&!remoteHeroUrls[idx].isEmpty())return idx;}}
        return (current+1)%6;
    }
    private void bindHeroImage(ImageView view,int idx){
        if(view==null)return;String u=remoteHeroUrls[idx];BannerImages.load(view,u);
    }
    private void updateHeroDots(){StringBuilder b=new StringBuilder();for(int i=0;i<activeHeroSlots.size();i++){b.append(activeHeroSlots.get(i)==slide?"●":"○");if(i+1<activeHeroSlots.size())b.append("   ");}if(dots!=null){dots.setText(b.toString());dots.setVisibility(activeHeroSlots.size()>1?View.VISIBLE:View.GONE);}}
    private void showHeroSlide(int idx){int at=activeHeroSlots.indexOf(idx);if(at>=0){slide=idx;if(heroCarousel!=null)heroCarousel.setIndex(at);}updateHeroDots();}
    private void showFirstRemoteHeroIfAvailable(){
        activeHeroSlots.clear();for(int i=0;i<remoteHeroUrls.length;i++)if(remoteHeroUrls[i]!=null&&!remoteHeroUrls[i].isEmpty())activeHeroSlots.add(i);
        int at=activeHeroSlots.indexOf(slide);if(at<0)at=0;if(!activeHeroSlots.isEmpty())slide=activeHeroSlots.get(at);
        if(heroCarousel!=null){heroCarousel.setData(activeHeroSlots.size(),at,(view,index)->{if(index<activeHeroSlots.size())bindHeroImage(view,activeHeroSlots.get(index));});heroCarousel.setVisibility(activeHeroSlots.isEmpty()?View.GONE:View.VISIBLE);}updateHeroDots();
    }
    private void startCarousel(){scheduleHeroCarousel(900L);}
    private long currentHeroIntervalMs(){int slot=(slide>=0&&slide<remoteHeroSeconds.length)?remoteHeroSeconds[slide]:4;return Math.max(1000L,Math.min(30000L,slot*1000L));}
    private void scheduleHeroCarousel(){scheduleHeroCarousel(currentHeroIntervalMs());}
    private void scheduleHeroCarousel(long delayMs){handler.removeCallbacks(heroCarouselTick);if(dashboardVisible&&!dashboardDestroyed&&activeHeroSlots.size()>1)handler.postDelayed(heroCarouselTick,Math.max(500L,delayMs));}
    private int adminFolderUnread;
    private void loadNotificationCount(){if(SessionManager.isAdmin(this))BackendClient.folderNotices(SessionManager.getToken(this),"ALL",new BackendClient.Callback(){public void onSuccess(JSONObject d){adminFolderUnread=d.optInt("unread");updateNotificationBadge();}public void onError(String m){}});String token=SessionManager.getToken(this);if(token==null||token.isEmpty()){unreadNotificationCount=0;updateNotificationBadge();return;}BackendClient.notifications(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){unreadNotificationCount=Math.max(0,d.optInt("unreadCount",0));getSharedPreferences("myshop_notifications",MODE_PRIVATE).edit().putString("last_payload",d.toString()).apply();runOnUiThread(()->updateNotificationBadge());}public void onError(String m){}});}
    private void updateNotificationBadge(){if(notificationBadge==null)return;if(unreadNotificationCount+adminFolderUnread<=0)notificationBadge.setVisibility(View.GONE);else{notificationBadge.setVisibility(View.VISIBLE);notificationBadge.setText(unreadNotificationCount+adminFolderUnread>99?"99+":String.valueOf(unreadNotificationCount+adminFolderUnread));}}
    private void loadMessageCount(){String token=SessionManager.getToken(this);if(token==null||token.isEmpty()){unreadMessageCount=0;updateMessageBadge();return;}BackendClient.messageUnread(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){unreadMessageCount=Math.max(0,d.optInt("unreadCount",0));runOnUiThread(()->updateMessageBadge());}public void onError(String m){}});}
    private void updateMessageBadge(){if(messageBadge==null)return;if(unreadMessageCount<=0)messageBadge.setVisibility(View.GONE);else{messageBadge.setVisibility(View.VISIBLE);messageBadge.setText(unreadMessageCount>99?"99+":String.valueOf(unreadMessageCount));}}
    private String languageCode(){String l=LanguageManager.get(this);if(LanguageManager.EN.equals(l))return "EN";if(LanguageManager.HI.equals(l))return "HI";if(LanguageManager.AR.equals(l))return "AR";return "বাং";}
    @Override protected void onResume(){BadgeSync629.retry(this);if(getIntent().getBooleanExtra("openMoreApps",false)){getIntent().removeExtra("openMoreApps");handler.post(this::showMoreQuickActions);}
        super.onResume();if(getIntent().getBooleanExtra("open_menu640",false)){getIntent().removeExtra("open_menu640");handler.post(this::showHomeMenuDialog);}if(getIntent().getBooleanExtra("open_create640",false)){getIntent().removeExtra("open_create640");handler.post(this::showCreateMenu640);}if(storyRail632!=null)storyRail632.reload();if(homeLayout632!=null&&!getIntent().getBooleanExtra("home_layout_preview632",false)){if(homeLayoutShown632)homeLayout632.load();homeLayoutShown632=true;}String designScope=getIntent().getStringExtra("open_design_scope");if("home_general".equals(designScope))handler.post(this::showHomeMenuDialog);else if("home_quick".equals(designScope))handler.post(this::showMoreQuickActions);if(renderedLanguage!=null&&!renderedLanguage.equals(LanguageManager.get(this))){recreate();return;}renderedLanguage=LanguageManager.get(this);if(upcomingCarousel!=null)upcomingCarousel.resume();
        dashboardVisible=true;
        // onCreate already performs the first dashboard load. Running the same API/image
        // burst again from the first onResume doubled memory/network pressure at startup.
        if(firstDashboardResume){
            firstDashboardResume=false;
        }else{
            loadCurrentProfile();loadRemote();loadNotificationCount();loadMessageCount();loadNewPeople();
            if(feedList!=null&&!feedLoading&&(getSharedPreferences("feed_change641",MODE_PRIVATE).getBoolean("dirty",false)||System.currentTimeMillis()-lastFeedLoadAt>30000)){getSharedPreferences("feed_change641",MODE_PRIVATE).edit().putBoolean("dirty",false).apply();loadFeed(true);}
        }
        handler.removeCallbacks(notificationPoll);handler.postDelayed(notificationPoll,12000);
        homeDirectory625.start();handler.removeCallbacks(profilePresencePoll);handler.postDelayed(profilePresencePoll,5000);
        scheduleHeroCarousel(900L);schedulePromoCarousel();scheduleLiveAdCarousel();restartNewsMarquee();if(upcomingLiveAt>0){handler.removeCallbacks(upcomingCountdownTick);upcomingCountdownTick.run();}
    }
    @Override protected void onSaveInstanceState(Bundle state){if(scroll!=null)state.putInt(STATE_HOME_SCROLL_Y,scroll.getScrollY());super.onSaveInstanceState(state);}
    @Override protected void onPause(){if(upcomingCarousel!=null)upcomingCarousel.pause();if(scroll!=null)getSharedPreferences("myshop_home_state",MODE_PRIVATE).edit().putInt(STATE_HOME_SCROLL_Y,scroll.getScrollY()).apply();dashboardVisible=false;homeDirectory625.stop();handler.removeCallbacks(notificationPoll);handler.removeCallbacks(profilePresencePoll);handler.removeCallbacks(initialPresenceRefresh);handler.removeCallbacks(heroCarouselTick);handler.removeCallbacks(promoCarouselTick);handler.removeCallbacks(liveAdCarouselTick);handler.removeCallbacks(upcomingCountdownTick);pauseInlineVideos();super.onPause();}
    @Override public void onWindowFocusChanged(boolean hasFocus){super.onWindowFocusChanged(hasFocus);if(hasFocus&&dashboardVisible)restartNewsMarquee();}
    private void restartNewsMarquee(){
        if(newsText==null||dashboardDestroyed)return;
        newsText.setSingleLine(true);newsText.setEllipsize(TextUtils.TruncateAt.MARQUEE);newsText.setMarqueeRepeatLimit(-1);newsText.setHorizontallyScrolling(true);
        newsText.setSelected(false);newsText.postDelayed(()->{if(newsText!=null&&!dashboardDestroyed&&dashboardVisible)newsText.setSelected(true);},80);
    }
    private void loadRemoteImage(ImageView target,String url){if(IconAsset.emoji(target,url))return;CachedImages.load(target,url);}

    private Bitmap decodeRemoteBitmap(String url,BitmapFactory.Options opts) throws Exception{
        HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(6000);c.setReadTimeout(8000);c.setInstanceFollowRedirects(true);c.setUseCaches(true);MediaAccess640.authorize(this,c);int code=c.getResponseCode();if(code<200||code>=300)throw new java.io.IOException("HTTP "+code);try(InputStream in=c.getInputStream()){return BitmapFactory.decodeStream(in,null,opts);}}finally{if(c!=null)c.disconnect();}
    }
    private void applyRipple(View v){
        if(android.os.Build.VERSION.SDK_INT>=21){
            android.graphics.drawable.Drawable base=v.getBackground();
            if(base==null)return;
            v.setBackground(new RippleDrawable(ColorStateList.valueOf(Color.argb(42,30,55,120)),base,null));
        }
    }
    private TextView action(String s,int c){TextView t=text(s,Color.WHITE,10.5f,true);t.setGravity(Gravity.CENTER);t.setMinHeight(dp(44));t.setPadding(dp(10),0,dp(10),0);t.setBackground(gradient(c,Color.rgb(Math.max(0,Color.red(c)-18),Math.max(0,Color.green(c)-18),Math.max(0,Color.blue(c)-18)),12));t.setElevation(dp(2));applyRipple(t);return t;}
    private ImageView pic(int r){ImageView v=new ImageView(this);v.setImageResource(r);v.setScaleType(ImageView.ScaleType.FIT_XY);return v;}
    private Button icon(String s,int c,float z){Button b=new Button(this);b.setText(DisplayIds611.format(s));b.setTextColor(c);b.setTextSize(Math.max(z,11f));b.setGravity(Gravity.CENTER);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setPadding(0,0,0,0);b.setBackgroundColor(Color.TRANSPARENT);return b;}
    private TextView text(String s,int c,float z,boolean bold){TextView t=new TextView(this);t.setText(DisplayIds611.format(s));t.setTextColor(c);t.setTextSize(z);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);} private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;} private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;} private View space(){return new View(this);} private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);} private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;} private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);} private GradientDrawable round(int fill,int stroke,int rad){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(rad));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;} private GradientDrawable gradient(int[] colors,int rad){int[] safe=(colors==null||colors.length==0)?new int[]{Color.TRANSPARENT}:colors;GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,safe);g.setCornerRadius(dp(rad));return g;} private GradientDrawable gradient(int a,int b,int rad){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});g.setCornerRadius(dp(rad));return g;} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    @Override protected void onDestroy(){if(upcomingCarousel!=null)upcomingCarousel.destroy();dashboardDestroyed=true;dashboardVisible=false;handler.removeCallbacksAndMessages(null);pauseInlineVideos();imagePool.shutdownNow();imageCache.evictAll();super.onDestroy();}
    private void showPremiumLiveLauncher(){
        final android.app.Dialog d=new android.app.Dialog(this);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(18),dp(18),dp(18));box.setBackground(round(Color.rgb(12,20,62),Color.rgb(157,67,255),24));
        TextView title=text("✨  CHOOSE LIVE TYPE",Color.WHITE,17,true);title.setGravity(Gravity.CENTER);box.addView(title,lp(-1,dp(42)));
        TextView sub=text("Start your myshop live room",Color.rgb(185,199,245),10,false);sub.setGravity(Gravity.CENTER);box.addView(sub,lp(-1,dp(28)));
        TextView audio=text("🎙️  AUDIO LIVE\nStart Audio Room",Color.WHITE,15,true);audio.setGravity(Gravity.CENTER);audio.setBackground(gradient(Color.rgb(88,45,220),Color.rgb(216,39,190),22));audio.setOnClickListener(v->{d.dismiss();Intent i=new Intent(this,AudioLiveRoomActivity.class);i.putExtra("hostMode",true);startActivity(i);});LinearLayout.LayoutParams ap=lp(-1,dp(78));ap.topMargin=dp(10);box.addView(audio,ap);
        TextView video=text("📹  VIDEO LIVE\nCOMING SOON",Color.rgb(220,226,255),14,true);video.setGravity(Gravity.CENTER);video.setBackground(round(Color.rgb(20,31,78),Color.rgb(78,118,220),22));video.setOnClickListener(v->Toast.makeText(this,"Video Live — Coming Soon",Toast.LENGTH_SHORT).show());LinearLayout.LayoutParams vp=lp(-1,dp(70));vp.topMargin=dp(10);box.addView(video,vp);
        TextView cancel=text(UiStrings.label(MainActivity.this,"Cancel"),Color.rgb(190,200,235),11,true);cancel.setGravity(Gravity.CENTER);cancel.setOnClickListener(v->d.dismiss());box.addView(cancel,lp(-1,dp(42)));
        d.setContentView(box);android.view.Window w=d.getWindow();if(w!=null){w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));w.setDimAmount(.68f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.88f),-2);}d.setOnShowListener(x->{android.view.Window ww=d.getWindow();if(ww!=null)ww.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.88f),-2);});d.show();
    }

}
