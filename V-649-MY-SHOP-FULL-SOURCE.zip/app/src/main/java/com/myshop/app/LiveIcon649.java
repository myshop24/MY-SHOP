package com.myshop.app;
import android.graphics.*;import android.graphics.drawable.Drawable;
/** Original restrained mono-line room controls; no bitmap glow/rings/emoji. */
final class LiveIcon649 extends Drawable {
 private final String kind;private final Paint p=new Paint(3);private int color=0xffeaf0fa;
 LiveIcon649(String kind){this.kind=kind.toLowerCase(java.util.Locale.ROOT);}
 public void draw(Canvas c){Rect b=getBounds();c.save();c.translate(b.left,b.top);c.scale(b.width()/32f,b.height()/32f);c.translate(4,4);p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.65f);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
 if(kind.contains("camera")||kind.contains("beauty")){c.drawRoundRect(2,6,21,20,3,3,p);c.drawCircle(11.5f,13,4,p);line(c,6,6,8,3);line(c,8,3,14,3);line(c,14,3,16,6);line(c,21,0,21,5);line(c,18.5f,2.5f,23.5f,2.5f);}
 else if(kind.contains("mic")||kind.contains("sound")){c.drawRoundRect(9,2,15,15,3,3,p);c.drawArc(6,7,18,19,0,180,false,p);line(c,12,19,12,23);line(c,8,23,16,23);}
 else if(kind.contains("game")){c.drawRoundRect(2,6,22,19,5,5,p);line(c,6,12,12,12);line(c,9,9,9,15);c.drawCircle(17,11,.8f,p);c.drawCircle(19,14,.8f,p);}
 else if(kind.contains("more")){for(int y:new int[]{7,17})for(int x:new int[]{7,17})c.drawCircle(x,y,2,p);}
 else if(kind.contains("gift")){c.drawRoundRect(3,9,21,22,1,1,p);line(c,2,9,22,9);line(c,12,9,12,22);c.drawOval(5,2,12,8,p);c.drawOval(12,2,19,8,p);}
 else if(kind.contains("love")){Path a=new Path();a.moveTo(12,21);a.cubicTo(-6,10,5,-2,12,7);a.cubicTo(19,-2,30,10,12,21);c.drawPath(a,p);}
 else if(kind.contains("message")){c.drawRoundRect(2,3,22,18,4,4,p);line(c,6,18,5,23);line(c,5,23,12,18);for(int x:new int[]{7,12,17})c.drawPoint(x,10,p);}
 else if(kind.contains("share")){line(c,3,18,3,21);line(c,3,21,20,21);line(c,20,21,20,18);line(c,12,16,12,2);line(c,12,2,7,7);line(c,12,2,17,7);}
 else if(kind.contains("music")){line(c,10,18,10,4);line(c,10,4,21,2);line(c,21,2,21,16);c.drawOval(3,16,10,21,p);c.drawOval(14,14,21,19,p);}
 else if(kind.contains("audio")){line(c,2,9,7,9);line(c,7,9,12,4);line(c,12,4,12,21);line(c,12,21,7,16);line(c,7,16,2,16);line(c,2,16,2,9);c.drawArc(12,6,22,19,-70,140,false,p);}
 else if(kind.contains("settings")){c.drawCircle(12,12,7,p);c.drawCircle(12,12,2.5f,p);for(int i=0;i<8;i++){double a=i*Math.PI/4;line(c,12+(float)Math.cos(a)*8,12+(float)Math.sin(a)*8,12+(float)Math.cos(a)*10,12+(float)Math.sin(a)*10);}}
 else if(kind.contains("favourite")){Path a=new Path();for(int i=0;i<10;i++){double t=-Math.PI/2+i*Math.PI/5;float r=i%2==0?10:4.5f,x=12+(float)Math.cos(t)*r,y=12+(float)Math.sin(t)*r;if(i==0)a.moveTo(x,y);else a.lineTo(x,y);}a.close();c.drawPath(a,p);}
 else if(kind.contains("join")){c.drawCircle(8,7,3,p);c.drawArc(2,12,14,26,180,180,false,p);line(c,15,12,23,12);line(c,23,12,19,8);line(c,23,12,19,16);}
 else if(kind.contains("vote")){Path a=new Path();a.moveTo(4,9);a.lineTo(9,3);a.lineTo(15,10);a.lineTo(10,16);a.close();c.drawPath(a,p);line(c,3,16,3,22);line(c,3,22,22,22);line(c,22,22,22,16);line(c,14,16,19,16);}
 else if(kind.contains("layout")||kind.contains("seat")){c.drawRoundRect(2,3,11,22,2,2,p);for(int y:new int[]{3,10,17})c.drawRoundRect(14,y,22,y+5,1,1,p);}
 else if(kind.contains("pk")){p.setTextSize(10);p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));p.setStyle(Paint.Style.FILL);c.drawText("VS",5,16,p);p.setStyle(Paint.Style.STROKE);line(c,1,4,7,4);line(c,1,4,1,20);line(c,23,4,17,4);line(c,23,4,23,20);}
 c.restore();}
 private void line(Canvas c,float x,float y,float a,float b){c.drawLine(x,y,a,b,p);}
 public void setAlpha(int a){p.setAlpha(a);}public void setColorFilter(ColorFilter f){p.setColorFilter(f);}public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
