package com.myshop.app;
/** Edge-only cleanup: keeps enclosed white logo details, never edits other assets. */
final class IconPixels {
 static int[] prepare(int[] original,int width,int height,boolean removeWhite){
  int[] pixels=original.clone();
  if(removeWhite){boolean[] seen=new boolean[pixels.length];int[] queue=new int[pixels.length];int tail=0;
   for(int x=0;x<width;x++){tail=offer(x,pixels,seen,queue,tail);tail=offer((height-1)*width+x,pixels,seen,queue,tail);}
   for(int y=0;y<height;y++){tail=offer(y*width,pixels,seen,queue,tail);tail=offer(y*width+width-1,pixels,seen,queue,tail);}
   for(int head=0;head<tail;head++){int at=queue[head];pixels[at]=0;if(at%width>0)tail=offer(at-1,pixels,seen,queue,tail);if(at%width<width-1)tail=offer(at+1,pixels,seen,queue,tail);if(at>=width)tail=offer(at-width,pixels,seen,queue,tail);if(at+width<pixels.length)tail=offer(at+width,pixels,seen,queue,tail);}
  }return pixels;
 }
 private static int offer(int at,int[] pixels,boolean[] seen,int[] q,int tail){if(seen[at])return tail;seen[at]=true;int c=pixels[at],r=(c>>>16)&255,g=(c>>>8)&255,b=c&255;boolean light=Math.min(r,Math.min(g,b))>=232&&Math.max(r,Math.max(g,b))-Math.min(r,Math.min(g,b))<=18;if((c>>>24)<16||light)q[tail++]=at;return tail;}
 static int[] bounds(int[] pixels,int width,int height){int l=width,t=height,r=-1,b=-1;for(int y=0;y<height;y++)for(int x=0;x<width;x++)if((pixels[y*width+x]>>>24)>16){l=Math.min(l,x);r=Math.max(r,x);t=Math.min(t,y);b=Math.max(b,y);}return r<l?new int[]{0,0,width,height}:new int[]{l,t,r-l+1,b-t+1};}
 private IconPixels(){}
}
