package com.myshop.app;
import android.animation.ValueAnimator;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.view.View;
/** Light-only motion, cancelled when detached; the button and label stay still. */
final class ButtonShimmer extends Drawable implements View.OnAttachStateChangeListener {
 private final View host; private final Paint paint=new Paint(3);private ValueAnimator animator;private float phase;
 private ButtonShimmer(View v){host=v;v.addOnAttachStateChangeListener(this);v.getOverlay().add(this);if(v.isAttachedToWindow())onViewAttachedToWindow(v);}
 static void attach(View v){new ButtonShimmer(v);}
 public void onViewAttachedToWindow(View v){if(animator!=null)return;if(android.os.Build.VERSION.SDK_INT>=26&&!ValueAnimator.areAnimatorsEnabled())return;animator=ValueAnimator.ofFloat(-.4f,1.4f);animator.setDuration(3000);animator.setRepeatCount(ValueAnimator.INFINITE);animator.addUpdateListener(a->{phase=(float)a.getAnimatedValue();setBounds(0,0,host.getWidth(),host.getHeight());invalidateSelf();});animator.start();}
 public void onViewDetachedFromWindow(View v){if(animator!=null){animator.cancel();animator=null;}}
 public void draw(Canvas c){float w=getBounds().width(),h=getBounds().height();if(w==0)return;int save=c.save();Path clip=new Path();clip.addRoundRect(new RectF(0,0,w,h),h/2,h/2,Path.Direction.CW);c.clipPath(clip);float x=phase*w;paint.setShader(new LinearGradient(x-w*.2f,0,x+w*.2f,h,new int[]{0x00ffffff,0x55ffffff,0x00ffffff},null,Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,paint);c.restoreToCount(save);}
 public void setAlpha(int a){paint.setAlpha(a);}public void setColorFilter(ColorFilter f){paint.setColorFilter(f);}public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
