package com.myshop.app;
import android.graphics.*;import android.graphics.drawable.Drawable;import android.widget.TextView;import android.text.*;import android.text.style.ImageSpan;
final class DiamondPrice640 {
 private static Bitmap bitmap;
 static void decorate(TextView view){CharSequence value=view.getText();if(value==null||!value.toString().startsWith("💎"))return;try{if(bitmap==null)try(java.io.InputStream in=view.getContext().getAssets().open("comments640/diamond.jpg")){bitmap=BitmapFactory.decodeStream(in);}if(bitmap==null)return;Drawable icon=new Drawable(){final Paint paint=new Paint(3);public void draw(Canvas canvas){canvas.drawBitmap(bitmap,new Rect(65,540,840,1130),new RectF(getBounds()),paint);}public void setAlpha(int alpha){paint.setAlpha(alpha);}public void setColorFilter(ColorFilter filter){paint.setColorFilter(filter);}public int getOpacity(){return PixelFormat.TRANSLUCENT;}};int size=Math.max(1,Math.round(view.getTextSize()));icon.setBounds(0,0,size,size);SpannableString text=new SpannableString(value);text.setSpan(new ImageSpan(icon,ImageSpan.ALIGN_BASELINE),0,2,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);view.setText(text);}catch(Exception ignored){}}
 private DiamondPrice640(){}
}
