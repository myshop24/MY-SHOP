package com.myshop.app;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

/**
 * myshop V-230 Gallery with a six-slot rotating advertising banner area.
 * Gallery is viewable by Users. Upload/Edit/Delete controls are Admin Only; PHOTO / AUDIO / VIDEO remain independent folders;
 * media bytes stay in R2 while metadata/ownership stays in D1.
 */
public class GalleryActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(8,10,22), CARD=Color.rgb(20,24,42), PURPLE=Color.rgb(121,49,232), PINK=Color.rgb(205,53,198), MUTED=Color.rgb(171,178,202), WHITE=Color.WHITE, RED=Color.rgb(220,60,80);
    private LinearLayout list;
    private String folder="photo";
    private TextView photoTab,audioTab,videoTab,folderTitle,empty,addMediaButton;
    private static final int PICK_MEDIA=9101;
    private final Handler adHandler=new Handler(Looper.getMainLooper());
    private final ArrayList<JSONObject> folderAds=new ArrayList<>();
    private LinearLayout folderAdBox; private ImageView folderAdImage; private TextView folderAdCaption,folderAdDots;
    private int folderAdIndex=0;
    private final Runnable folderAdTick=new Runnable(){@Override public void run(){if(!folderAds.isEmpty()){folderAdIndex=(folderAdIndex+1)%folderAds.size();showFolderAd();}scheduleNextFolderAd();}};

    @Override protected void onCreate(Bundle b){ super.onCreate(b); String requested=getIntent().getStringExtra("folder"); if("audio".equals(requested)||"video".equals(requested)||"photo".equals(requested))folder=requested; build(); loadFolderAds(); load(); }

    private void build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(BG);
        LinearLayout page=col(); page.setPadding(dp(14),dp(12),dp(14),dp(86));
        LinearLayout head=row();
        TextView back=txt("‹",WHITE,30,true); back.setGravity(Gravity.CENTER); back.setOnClickListener(v->finish()); head.addView(back,lp(dp(42),dp(46)));
        LinearLayout titleBox=col(); titleBox.addView(txt("myshop",WHITE,19,true),lp(-1,dp(24))); titleBox.addView(txt("PERSONAL GALLERY",MUTED,9,true),lp(-1,dp(18))); head.addView(titleBox,weight(1,dp(46)));
        TextView addTop=action("＋ ADD",PURPLE); addTop.setOnClickListener(v->pickMedia()); if(SessionManager.isAdmin(this)) head.addView(addTop,lp(dp(82),dp(42))); page.addView(head,lp(-1,dp(50)));

        LinearLayout tabs=row(); photoTab=tab("📷  PHOTO","photo"); audioTab=tab("🎵  AUDIO","audio"); videoTab=tab("🎬  VIDEO","video"); tabs.addView(photoTab,weight(1,dp(48))); tabs.addView(gap(),lp(dp(6),1)); tabs.addView(audioTab,weight(1,dp(48))); tabs.addView(gap(),lp(dp(6),1)); tabs.addView(videoTab,weight(1,dp(48))); page.addView(tabs,top(lp(-1,dp(48)),10));

        // V-230: Gallery has its own independent 6-slot advertisement folder. Hidden when no banner is active.
        folderAdBox=createFolderAdBox(); page.addView(folderAdBox,top(lp(-1,-2),8));

        if(SessionManager.isAdmin(this)){
            LinearLayout hero=col(); hero.setPadding(dp(14),dp(12),dp(14),dp(12)); hero.setBackground(gradient(PURPLE,Color.rgb(55,30,150),16));
            folderTitle=txt("My Photos",WHITE,18,true); hero.addView(folderTitle,lp(-1,dp(26)));
            hero.addView(txt("Admin can upload, edit, save and delete media. Users can only view.",Color.rgb(245,238,255),10,false),lp(-1,dp(38)));
            addMediaButton=action("＋  ADD PHOTO",Color.rgb(245,112,213)); addMediaButton.setTextColor(Color.WHITE); addMediaButton.setOnClickListener(v->pickMedia()); hero.addView(addMediaButton,lp(-1,dp(44))); page.addView(hero,top(lp(-1,-2),10));
        } else {
            folderTitle=txt("PHOTO",WHITE,16,true); folderTitle.setPadding(dp(4),dp(10),dp(4),dp(0)); page.addView(folderTitle,lp(-1,dp(34)));
        }

        list=col(); ScrollView sv=new ScrollView(this); sv.setFillViewport(true); sv.setVerticalScrollBarEnabled(false); sv.addView(list); page.addView(sv,lp(-1,0,1));
        if(SessionManager.isAdmin(this)){ TextView foot=txt("Gallery changes are Admin Only.",MUTED,9,false); foot.setGravity(Gravity.CENTER); page.addView(foot,top(lp(-1,dp(28)),6)); }
        root.addView(page,new FrameLayout.LayoutParams(-1,-1));
        TextView nav=txt("‹  BACK TO PROFILE",WHITE,11,true); nav.setGravity(Gravity.CENTER); nav.setBackground(round(Color.rgb(29,34,56),Color.TRANSPARENT,16)); nav.setOnClickListener(v->finish()); FrameLayout.LayoutParams np=new FrameLayout.LayoutParams(-1,dp(54),Gravity.BOTTOM);np.setMargins(dp(12),0,dp(12),dp(10));root.addView(nav,np);
        setContentView(root); updateTabs();
    }

    private TextView tab(String label,String f){ TextView t=txt(label,WHITE,11,true); t.setGravity(Gravity.CENTER); t.setOnClickListener(v->{folder=f;updateTabs();load();}); return t; }
    private void updateTabs(){
        photoTab.setBackground(round("photo".equals(folder)?PURPLE:CARD,Color.TRANSPARENT,12));
        audioTab.setBackground(round("audio".equals(folder)?PURPLE:CARD,Color.TRANSPARENT,12));
        videoTab.setBackground(round("video".equals(folder)?PURPLE:CARD,Color.TRANSPARENT,12));
        String title="photo".equals(folder)?"My Photos":"audio".equals(folder)?"My Audio":"My Videos"; if(folderTitle!=null)folderTitle.setText(title); if(addMediaButton!=null){boolean admin=SessionManager.isAdmin(this);addMediaButton.setText("＋  ADD "+folder.toUpperCase());addMediaButton.setVisibility(admin?View.VISIBLE:View.GONE);addMediaButton.setOnClickListener(v->pickMedia());}
    }

    private LinearLayout createFolderAdBox(){
        LinearLayout box=col(); box.setPadding(dp(5),dp(5),dp(5),dp(4)); box.setBackground(round(Color.WHITE,Color.rgb(226,229,238),16)); box.setVisibility(View.GONE); box.setElevation(dp(2));
        folderAdImage=new AspectBannerImageView(this); folderAdImage.setBackground(round(Color.rgb(245,247,252),Color.TRANSPARENT,13)); box.addView(folderAdImage,lp(-1,-2));
        LinearLayout r=row(); folderAdCaption=txt("Advertisement",Color.rgb(24,35,86),10,true); folderAdCaption.setSingleLine(true); r.addView(folderAdCaption,weight(1,dp(30)));
        folderAdDots=txt("",Color.rgb(91,38,214),8,true); folderAdDots.setGravity(Gravity.END|Gravity.CENTER_VERTICAL); r.addView(folderAdDots,lp(dp(96),dp(30))); box.addView(r,lp(-1,dp(30))); return box;
    }
    private void loadFolderAds(){
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{folderAds.clear();JSONArray a=d.optJSONArray("dashboardAds");if(a!=null)for(int i=0;i<a.length()&&folderAds.size()<6;i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;if(!"gallery".equalsIgnoreCase(x.optString("box_key","")))continue;if(x.optInt("active",1)!=1)continue;if(!"image".equalsIgnoreCase(x.optString("media_type","image")))continue;if(x.optString("image_url","").trim().isEmpty())continue;int slot=x.optInt("slot",0);if(slot<1||slot>6)continue;folderAds.add(x);}folderAdIndex=0;if(folderAds.isEmpty()){folderAdBox.setVisibility(View.GONE);adHandler.removeCallbacks(folderAdTick);}else{folderAdBox.setVisibility(View.VISIBLE);showFolderAd();scheduleNextFolderAd();}});}
            public void onError(String m){runOnUiThread(()->{if(folderAdBox!=null)folderAdBox.setVisibility(View.GONE);});}
        });
    }
    private void showFolderAd(){
        if(folderAds.isEmpty()||folderAdImage==null)return;JSONObject x=folderAds.get(folderAdIndex%folderAds.size());String url=x.optString("image_url","");String cap=x.optString("caption","").trim();
        folderAdImage.animate().alpha(.25f).setDuration(120).withEndAction(()->{loadImage(folderAdImage,url);folderAdImage.animate().alpha(1f).setDuration(180).start();}).start();folderAdCaption.setText(cap.isEmpty()?"Advertisement":cap);
        StringBuilder dots=new StringBuilder();for(int i=0;i<folderAds.size();i++){dots.append(i==folderAdIndex?"●":"○");if(i<folderAds.size()-1)dots.append("  ");}folderAdDots.setText(dots.toString());String target=x.optString("target_url","").trim();folderAdBox.setOnClickListener(v->{if(FeatureRegistry.isSafeHttpUrl(target)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(target)));}catch(Exception ignored){}}});
    }
    private void scheduleNextFolderAd(){adHandler.removeCallbacks(folderAdTick);if(folderAds.size()<2)return;int sec=Math.max(1,Math.min(60,folderAds.get(folderAdIndex%folderAds.size()).optInt("duration_sec",5)));adHandler.postDelayed(folderAdTick,sec*1000L);}
    @Override protected void onDestroy(){adHandler.removeCallbacks(folderAdTick);super.onDestroy();}

    private void load(){
        String token=SessionManager.getToken(this); if(token==null||token.isEmpty()){render(null,"Login required");return;}
        BackendClient.galleryList(token,folder,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->render(d.optJSONArray("media"),""));}
            public void onError(String m){runOnUiThread(()->render(null,"Gallery load failed: "+m));}
        });
    }

    private void render(JSONArray a,String error){
        if(list==null)return; list.removeAllViews();
        if(error!=null&&!error.isEmpty()){TextView e=txt(error,Color.rgb(255,150,160),11,true);e.setGravity(Gravity.CENTER);e.setPadding(dp(8),dp(24),dp(8),dp(24));list.addView(e);return;}
        int count=0;
        if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;count++;card(x);}
        if(count==0){empty=txt("এখনো কোনো media নেই।\nউপরে + ADD অথবা নিচের ADD বাটনে চাপুন।",MUTED,12,false);empty.setGravity(Gravity.CENTER);empty.setPadding(dp(10),dp(42),dp(10),dp(42));list.addView(empty);}
    }

    private void card(JSONObject x){
        long id=x.optLong("id",0); String title=x.optString("title",""); String caption=x.optString("caption",""); String url=x.optString("media_url","");
        LinearLayout c=col();c.setPadding(dp(10),dp(10),dp(10),dp(10));c.setBackground(round(CARD,Color.rgb(43,48,75),14));c.setElevation(dp(2));
        LinearLayout h=row(); h.addView(txt(folderIcon(),WHITE,20,true),lp(dp(34),dp(32))); LinearLayout tt=col();tt.addView(txt(title.isEmpty()?defaultTitle():title,WHITE,14,true),lp(-1,dp(22)));tt.addView(txt("Your media • "+folder.toUpperCase(),MUTED,9,false),lp(-1,dp(16)));h.addView(tt,weight(1,dp(34))); c.addView(h,lp(-1,dp(38)));
        if("photo".equals(folder)){ImageView iv=new ImageView(this);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setBackground(round(Color.rgb(12,15,28),Color.TRANSPARENT,10));c.addView(iv,top(lp(-1,dp(210)),8));loadImage(iv,url);}
        else {TextView play=action("audio".equals(folder)?"▶  PLAY AUDIO":"▶  PLAY VIDEO",PURPLE);play.setOnClickListener(v->{try{if("audio".equals(folder)){Intent q=new Intent(GalleryActivity.this,AudioPlayerActivity.class);q.putExtra("url",url);q.putExtra("title",title);startActivity(q);}else{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}}catch(Exception e){toast("Media could not be opened.");}});c.addView(play,top(lp(-1,dp(46)),8));}
        if(!caption.isEmpty()){TextView cap=txt(caption,Color.rgb(231,234,246),11,false);cap.setPadding(dp(4),dp(9),dp(4),dp(5));c.addView(cap,lp(-1,-2));}
        if(SessionManager.isAdmin(this)){LinearLayout actions=row(); TextView edit=action("✏ EDIT",Color.rgb(56,90,220)); TextView del=action("🗑 DELETE",RED); edit.setOnClickListener(v->editDialog(id,title,caption)); del.setOnClickListener(v->deleteDialog(id)); actions.addView(edit,weight(1,dp(42)));actions.addView(gap(),lp(dp(6),1));actions.addView(del,weight(1,dp(42)));c.addView(actions,top(lp(-1,dp(42)),8));}
        list.addView(c,lp(-1,-2)); Space sp=new Space(this);list.addView(sp,lp(1,dp(10)));
    }

    private void pickMedia(){
        if(!SessionManager.isAdmin(this)){toast("🔒 Gallery changes are Admin Only. Users can view media.");return;}
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        i.setType("photo".equals(folder)?"image/*":"audio".equals(folder)?"audio/*":"video/*"); startActivityForResult(i,PICK_MEDIA);
    }
    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r!=PICK_MEDIA||c!=RESULT_OK||data==null)return;List<Uri> uris=new ArrayList<>();if(data.getClipData()!=null){ClipData cd=data.getClipData();for(int i=0;i<cd.getItemCount();i++)uris.add(cd.getItemAt(i).getUri());}else if(data.getData()!=null)uris.add(data.getData());if(uris.isEmpty())return;try{if((data.getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION)!=0&&data.getData()!=null)getContentResolver().takePersistableUriPermission(data.getData(),Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){} captionDialog(uris);}

    private void captionDialog(List<Uri> uris){
        LinearLayout box=col();box.setPadding(dp(8),0,dp(8),0);EditText title=new EditText(this);title.setHint("Title (optional)");title.setTextColor(WHITE);title.setHintTextColor(MUTED);box.addView(title,lp(-1,dp(50)));EditText cap=new EditText(this);cap.setHint("Write a caption…");cap.setTextColor(WHITE);cap.setHintTextColor(MUTED);cap.setMinLines(3);box.addView(cap,lp(-1,dp(90)));
        new MyShopDialogBuilder(this).setTitle("Add "+folder.toUpperCase()).setMessage(uris.size()+" item(s) selected").setView(box).setNegativeButton("CANCEL",null).setPositiveButton("UPLOAD",(d,w)->uploadUris(uris,title.getText().toString().trim(),cap.getText().toString().trim())).show();
    }
    private void uploadUris(List<Uri> uris,String title,String caption){uploadNext(uris,0,title,caption);}
    private void uploadNext(List<Uri> uris,int index,String title,String caption){
        if(index>=uris.size()){toast("✓ All selected media uploaded safely.");load();return;}
        Uri u=uris.get(index);try{InputStream in=getContentResolver().openInputStream(u);String mime=getContentResolver().getType(u);String name=queryName(u);BackendClient.galleryUpload(SessionManager.getToken(this),in,name,mime==null?fallbackMime():mime,folder,title,caption,new BackendClient.Callback(){public void onSuccess(JSONObject d){uploadNext(uris,index+1,title,caption);}public void onError(String m){toast("Upload stopped at item "+(index+1)+": "+m);load();}});}catch(Exception e){toast("Could not open selected media.");load();}}
    private String queryName(Uri u){try(android.database.Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}catch(Exception ignored){}return folder+"-media";}
    private String fallbackMime(){return "photo".equals(folder)?"image/jpeg":"audio".equals(folder)?"audio/mpeg":"video/mp4";}

    private void editDialog(long id,String oldTitle,String oldCaption){
        LinearLayout box=col();EditText title=field(UiStrings.ui636("Title"),oldTitle);EditText cap=field("Caption",oldCaption);cap.setMinLines(3);box.addView(title,lp(-1,dp(50)));box.addView(cap,lp(-1,dp(90)));
        new MyShopDialogBuilder(this).setTitle("Edit Media").setView(box).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(d,w)->BackendClient.galleryUpdate(SessionManager.getToken(this),id,title.getText().toString().trim(),cap.getText().toString().trim(),new BackendClient.Callback(){public void onSuccess(JSONObject x){toast("✓ Caption saved");load();}public void onError(String m){toast("Edit failed: "+m);}})).show();
    }
    private void deleteDialog(long id){new MyShopDialogBuilder(this).setTitle("Delete this media?").setMessage("This removes your Gallery record and its R2 object. Other users' media are not affected.").setNegativeButton("CANCEL",null).setPositiveButton("DELETE",(d,w)->BackendClient.galleryDelete(SessionManager.getToken(this),id,new BackendClient.Callback(){public void onSuccess(JSONObject x){toast("✓ Deleted");load();}public void onError(String m){toast("Delete failed: "+m);}})).show();}

    private void loadImage(ImageView v,String u){if(u==null||u.isEmpty())return;Executors.newSingleThreadExecutor().execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(12000);c.setInstanceFollowRedirects(true);try(InputStream in=c.getInputStream()){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null)runOnUiThread(()->v.setImageBitmap(b));}}catch(Exception ignored){}});}
    private String folderIcon(){return "photo".equals(folder)?"📷":"audio".equals(folder)?"🎵":"🎬";} private String defaultTitle(){return "photo".equals(folder)?"Photo":"audio".equals(folder)?"Audio":"Video";}
    private EditText field(String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setTextColor(WHITE);e.setHintTextColor(MUTED);e.setSingleLine(false);e.setPadding(dp(8),0,dp(8),0);return e;}
    private TextView action(String s,int c){TextView t=txt(s,WHITE,10.5f,true);t.setGravity(Gravity.CENTER);t.setBackground(round(c,Color.TRANSPARENT,10));return t;}
    private TextView txt(String s,int c,float z,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;} private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;} private View gap(){return new View(this);} private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams lp(int w,int h,float wt){return new LinearLayout.LayoutParams(w,h,wt);} private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);} private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;} private GradientDrawable round(int fill,int stroke,int r){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(r));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;} private GradientDrawable gradient(int a,int b,int r){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,b});g.setCornerRadius(dp(r));return g;} private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);} private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}
}
