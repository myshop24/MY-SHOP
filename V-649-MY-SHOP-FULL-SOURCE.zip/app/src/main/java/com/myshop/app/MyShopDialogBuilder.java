package com.myshop.app;
public class MyShopDialogBuilder extends android.app.AlertDialog.Builder {
 public MyShopDialogBuilder(android.content.Context c){super(c);}
 @Override public android.app.AlertDialog create(){android.app.AlertDialog d=super.create();if(d.getWindow()!=null)d.getWindow().getDecorView().getViewTreeObserver().addOnGlobalLayoutListener(()->{Appearance.dialog(d);d.getWindow().getDecorView().setLayoutDirection(LanguageManager.AR.equals(LanguageManager.get(getContext()))?android.view.View.LAYOUT_DIRECTION_RTL:android.view.View.LAYOUT_DIRECTION_LTR);});return d;}
 @Override public android.app.AlertDialog show(){android.app.AlertDialog d=super.show();Appearance.dialog(d);return d;}
}
