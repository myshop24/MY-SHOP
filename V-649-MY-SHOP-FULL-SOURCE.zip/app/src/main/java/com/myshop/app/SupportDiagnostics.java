package com.myshop.app;
import android.app.Activity;
/** User-approved support metadata, deliberately excludes tokens and message contents. */
public final class SupportDiagnostics {
 private SupportDiagnostics(){}
 public static String summary(Activity a){android.content.SharedPreferences p=a.getSharedPreferences("myshop_push_v349",0);return "App "+BuildConfig.VERSION_NAME+" ("+BuildConfig.VERSION_CODE+")\nAndroid API "+android.os.Build.VERSION.SDK_INT+"\nNotifications enabled: "+androidx.core.app.NotificationManagerCompat.from(a).areNotificationsEnabled()+"\nDevice registration: "+p.getBoolean("token_registered",false)+"\nServer connection: "+p.getBoolean("server_configured",false)+"\nProject matches: "+p.getBoolean("project_matched",false);}
}
