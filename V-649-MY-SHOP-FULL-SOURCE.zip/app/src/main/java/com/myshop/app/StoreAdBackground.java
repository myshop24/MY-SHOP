package com.myshop.app;
import android.graphics.*;
import android.graphics.drawable.Drawable;
/** Twenty lightweight inline-card motifs, shared by Store preview and live banner. */
final class StoreAdBackground extends Drawable {
 private final int first,second,template;private final Paint p=new Paint(3);
 StoreAdBackground(int a,int b,int style){first=a;second=b;template=Math.max(1,Math.min(20,style));}
 public void draw(Canvas c){Rect bounds=getBounds();float w=bounds.width(),h=bounds.height();p.setShader(new LinearGradient(0,0,template%2==0?w:w*.4f,h,new int[]{first,second},null,Shader.TileMode.CLAMP));p.setStyle(Paint.Style.FILL);c.drawRoundRect(new RectF(bounds),12,12,p);p.setShader(null);int save=c.save();c.clipRect(bounds);p.setColor(0x28ffffff);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);int style=(template-1)%10;
  switch(style){case 0:for(int i=0;i<3;i++)c.drawRoundRect(8+i*5,8+i*5,w-8-i*5,h-8-i*5,8,8,p);break;case 1:for(int i=0;i<5;i++)c.drawCircle(w*.75f,h*.5f,20+i*20,p);break;case 2:for(int i=-2;i<10;i++)c.drawLine(i*40,0,i*40+h,h,p);break;case 3:for(int i=0;i<4;i++)c.drawOval(w*.4f-i*30,-h*.7f-i*10,w*1.2f+i*30,h*1.6f+i*10,p);break;case 4:for(int x=0;x<w;x+=34)for(int y=0;y<h;y+=24)c.drawCircle(x,y,2,p);break;case 5:for(int x=0;x<w;x+=48){Path diamond=new Path();diamond.moveTo(x,h*.25f);diamond.lineTo(x+18,h*.5f);diamond.lineTo(x,h*.75f);diamond.lineTo(x-18,h*.5f);diamond.close();c.drawPath(diamond,p);}break;case 6:for(int i=0;i<4;i++){Path wave=new Path();wave.moveTo(0,h*(.2f+i*.16f));wave.cubicTo(w*.3f,h*.9f,w*.7f,-h*.3f,w,h*(.3f+i*.16f));c.drawPath(wave,p);}break;case 7:c.drawLine(w*.62f,0,w*.4f,h,p);c.drawLine(w*.8f,0,w*.62f,h,p);p.setStyle(Paint.Style.FILL);c.drawCircle(w*.8f,h*.3f,h*.5f,p);break;case 8:for(int i=0;i<8;i++){float x=(i*47)%Math.max(1,w),y=10+(i*29)%Math.max(1,h-20);c.drawLine(x-3,y,x+3,y,p);c.drawLine(x,y-3,x,y+3,p);}break;default:c.drawRoundRect(10,10,w-10,h-10,20,20,p);c.drawLine(30,h*.8f,w*.65f,h*.8f,p);}
  if(template>10){p.setStyle(Paint.Style.FILL);p.setColor(0x21ffdf8d);c.drawCircle(w*.9f,-h*.2f,h*1.2f,p);p.setStyle(Paint.Style.STROKE);c.drawLine(0,h-3,w,h-3,p);}c.restoreToCount(save);
 }
 public void setAlpha(int a){p.setAlpha(a);}public void setColorFilter(ColorFilter f){p.setColorFilter(f);}public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
