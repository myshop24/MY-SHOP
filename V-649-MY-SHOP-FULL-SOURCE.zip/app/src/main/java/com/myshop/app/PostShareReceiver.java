package com.myshop.app;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;
import java.lang.ref.WeakReference;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONObject;

/** Shares count chooser destination selections, not external delivery (which Android cannot verify). */
public final class PostShareReceiver extends BroadcastReceiver {
    private static final ConcurrentHashMap<String,WeakReference<TextView>> labels=new ConcurrentHashMap<>();
    public static void launch(Activity activity,long postId,String name,String caption,String media,TextView count){
        String event=UUID.randomUUID().toString();
        Intent callback=new Intent(activity,PostShareReceiver.class).setAction("com.myshop.app.SHARE."+event)
            .putExtra("event",event).putExtra("postId",postId).putExtra("owner",SessionManager.getUserId(activity));
        PendingIntent selected=PendingIntent.getBroadcast(activity,0,callback,PendingIntent.FLAG_ONE_SHOT|PendingIntent.FLAG_IMMUTABLE);
        Intent send=new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,
            (name+" on myshop\n"+caption+"\n"+media).trim());
        labels.put(event,new WeakReference<>(count));
        new Handler(Looper.getMainLooper()).postDelayed(()->labels.remove(event),600000);
        try{activity.startActivity(Intent.createChooser(send,"Share post",selected.getIntentSender()));}
        catch(Exception e){labels.remove(event);selected.cancel();Toast.makeText(activity,"Share unavailable",Toast.LENGTH_SHORT).show();}
    }
    @Override public void onReceive(Context context,Intent intent){
        String event=intent.getStringExtra("event"),owner=intent.getStringExtra("owner");long id=intent.getLongExtra("postId",0);
        if(event==null||id<=0||!SessionManager.getUserId(context).equals(owner))return;
        PendingResult pending=goAsync();
        BackendClient.feedShare(SessionManager.getToken(context),id,event,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){new Handler(Looper.getMainLooper()).post(()->{WeakReference<TextView> ref=labels.remove(event);TextView label=ref==null?null:ref.get();if(label!=null&&label.isAttachedToWindow()){String old=label.getText().toString();label.setText((old.startsWith("Share")?"Share ":"")+d.optInt("shareCount",0));label.setContentDescription("Shares "+d.optInt("shareCount",0));}});pending.finish();}
            public void onError(String m){labels.remove(event);pending.finish();}
        });
    }
}
