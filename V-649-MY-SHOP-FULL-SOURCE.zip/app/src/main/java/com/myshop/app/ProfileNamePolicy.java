package com.myshop.app;
import android.content.Context;
import android.graphics.Typeface;
import android.text.TextPaint;
public final class ProfileNamePolicy {
 public static final float SIZE_SP=20f;
 public static final int MAX_CODEPOINTS=24;
 public static boolean valid(Context c,String value){String n=value==null?"":value.trim();if(n.isEmpty()||n.contains("\n")||n.contains("\r")||n.codePointCount(0,n.length())>MAX_CODEPOINTS)return false;TextPaint p=new TextPaint();p.setTypeface(Typeface.DEFAULT_BOLD);p.setTextSize(SIZE_SP*c.getResources().getDisplayMetrics().scaledDensity);float width=Math.min(198*c.getResources().getDisplayMetrics().density,c.getResources().getDisplayMetrics().widthPixels-48*c.getResources().getDisplayMetrics().density);return p.measureText(n)<=width;}
 private ProfileNamePolicy(){}
}
