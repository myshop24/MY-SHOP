package com.myshop.app;
import android.graphics.Rect;import org.json.JSONObject;
/** Identical proportional safety bounds in Admin preview and foreground overlay. */
final class AnimationPlacement646 {
 static Rect bounds(JSONObject card,String page,int width,int height,int cardHeight,boolean box){JSONObject all=card.optJSONObject("positions"),p=all==null?null:all.optJSONObject(page);double fraction=p==null?(box?.32:AnimationCard645.defaultWidth(card)):p.optDouble("width",AnimationCard645.defaultWidth(card));int available=Math.max(1,(int)(width*("live_room".equals(page)?.83:.97)));int w=Math.max(1,Math.min(available,(int)(width*fraction)));int h=Math.min(cardHeight,Math.max(1,(int)(height*.78)));int x=Math.max(0,Math.min(available-w,(int)(width*(p==null?.03:p.optDouble("x",.03)))));int y=Math.max((int)(height*.06),Math.min((int)(height*.85)-h,(int)(height*(p==null?(box?.60:.22):p.optDouble("y",.22)))));return new Rect(x,y,x+w,y+h);}
}
