package com.myshop.app;
import android.text.InputFilter;
import android.text.Spanned;
import android.icu.text.BreakIterator;
import java.util.Locale;
/** 200 Unicode code points, keeping each visible grapheme intact. */
final class LiveCommentLimit implements InputFilter {
    static final int MAX=200;
    static String truncate(String text){return take(text,MAX);}
    private static String take(String text,int room){
        if(room<=0)return "";
        BreakIterator it=BreakIterator.getCharacterInstance(Locale.forLanguageTag("bn"));it.setText(text);
        int end=0,used=0;for(int start=it.first(),next=it.next();next!=BreakIterator.DONE;start=next,next=it.next()){
            int count=text.codePointCount(start,next);if(used+count>room)break;used+=count;end=next;
        }return text.substring(0,end);
    }
    public CharSequence filter(CharSequence source,int start,int end,Spanned dest,int dstart,int dend){
        String incoming=source.subSequence(start,end).toString();String retained=dest.subSequence(0,dstart).toString()+dest.subSequence(dend,dest.length());
        String allowed=take(incoming,Math.max(0,MAX-retained.codePointCount(0,retained.length())));
        return allowed.equals(incoming)?null:allowed;
    }
}
