package com.myshop.app;
/** V-534 single source of truth for premium shortcut/menu icon families. */
public final class PremiumIconLibrary {
    private PremiumIconLibrary(){}
    public static final int QUICK_SIZE_DP=40;
    public static final int GENERAL_SIZE_DP=38;
    public static final int DISCOVER_SIZE_DP=34;
    public static int general(String key){
        if("agent".equals(key)||"invite".equals(key))return R.drawable.premium438_people;
        if("my_links".equals(key))return R.drawable.premium438_globe;
        if("deals".equals(key))return R.drawable.premium438_tag;
        if("whats_new".equals(key))return R.drawable.premium438_more;
        if("my_tasks".equals(key))return R.drawable.premium540_tasks;
        if("shorts".equals(key))return R.drawable.premium438_play;
        if("events".equals(key))return R.drawable.premium438_trophy;
        if("flash_sale".equals(key))return R.drawable.premium438_fire;
        return R.drawable.premium540_shield;
    }
    public static int discover(String key){
        if("discover".equals(key))return R.drawable.premium438_globe;
        if("events".equals(key))return R.drawable.premium438_trophy;
        if("live_ranking".equals(key))return R.drawable.premium438_star;
        if("rewards".equals(key))return R.drawable.premium438_gift;
        if("achievements".equals(key))return R.drawable.premium438_crown;
        if("spotlight".equals(key))return R.drawable.premium438_gallery;
        if("deal_zone".equals(key))return R.drawable.premium438_fire;
        if("experiences".equals(key))return R.drawable.premium438_people;
        if("ai_studio".equals(key))return R.drawable.premium438_more;
        return R.drawable.premium438_headphones;
    }
}
