package com.myshop.app;
import android.os.Handler;import org.json.JSONObject;
/** Lightweight directory revision polling; full D1 discovery only on change/fallback. */
final class LiveDirectoryWatch621 {
 private final Handler handler=new Handler();private final Runnable reload;private boolean active,inFlight;private long revision=-1,lastReload;private int generation;private final Runnable tick=this::poll;
 LiveDirectoryWatch621(Runnable reload){this.reload=reload;}
 void start(){stop();active=true;lastReload=System.currentTimeMillis();handler.post(tick);}
 void stop(){active=false;generation++;handler.removeCallbacks(tick);inFlight=false;}
 private void poll(){if(!active||inFlight)return;inFlight=true;final int g=generation;BackendClient.liveDirectoryRevision621(new BackendClient.Callback(){public void onSuccess(JSONObject d){handler.post(()->{if(!active||g!=generation)return;inFlight=false;long next=d.optLong("revision",-1);if(next<0){schedule(10000);return;}if(revision<0||next!=revision||System.currentTimeMillis()-lastReload>=30000){lastReload=System.currentTimeMillis();reload.run();}revision=next;schedule(2000);});}public void onError(String m){handler.post(()->{if(!active||g!=generation)return;inFlight=false;if(System.currentTimeMillis()-lastReload>=30000){lastReload=System.currentTimeMillis();reload.run();}schedule(10000);});}});}
 private void schedule(long ms){if(active)handler.postDelayed(tick,ms);}
}
