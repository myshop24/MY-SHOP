package com.myshop.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;
import org.json.*;

/** Bounded, server-filtered public identity lists; never returns private contacts. */
final class ProfileConnections {
    static void show(Activity owner,String userId,String kind){new Page(owner,userId,kind).show();}
    private static final class Page {
        final Activity owner; final String userId,kind;
        final LinearLayout list; final TextView status; final Button more;
        AlertDialog dialog; int offset; boolean loading;
        Page(Activity owner,String userId,String kind){
            this.owner=owner;this.userId=userId;this.kind=kind;
            list=new LinearLayout(owner);list.setOrientation(LinearLayout.VERTICAL);
            status=new TextView(owner);status.setTextSize(12);status.setPadding(dp(12),dp(8),dp(12),dp(8));
            more=new Button(owner);more.setAllCaps(false);more.setText(UiStrings.label(more.getContext(),"Load More"));more.setOnClickListener(v->load());
        }
        int dp(int value){return Math.round(value*owner.getResources().getDisplayMetrics().density);}
        void show(){
            LinearLayout box=new LinearLayout(owner);box.setOrientation(LinearLayout.VERTICAL);box.addView(status);
            ScrollView scroll=new ScrollView(owner);scroll.addView(list);box.addView(scroll,new LinearLayout.LayoutParams(-1,Math.min(dp(380),owner.getResources().getDisplayMetrics().heightPixels/2)));
            box.addView(more);dialog=new MyShopDialogBuilder(owner).setTitle(kind.substring(0,1).toUpperCase()+kind.substring(1)).setView(box).setPositiveButton(UiStrings.ui636("Close"),null).create();dialog.show();load();
        }
        void load(){
            if(loading||owner.isFinishing()||!dialog.isShowing())return;
            loading=true;more.setEnabled(false);status.setText(UiStrings.label(status.getContext(),"Loading…"));
            BackendClient.profileConnections(SessionManager.getToken(owner),userId,kind,offset,30,new BackendClient.Callback(){
                public void onSuccess(JSONObject result){owner.runOnUiThread(()->{
                    if(owner.isFinishing()||!dialog.isShowing())return;
                    loading=false;JSONArray users=result.optJSONArray("users");
                    if(users!=null)for(int i=0;i<users.length();i++){JSONObject user=users.optJSONObject(i);if(user!=null)add(user);}
                    offset=result.optInt("nextOffset",offset);status.setText(list.getChildCount()==0?"No users to show.":list.getChildCount()+" users shown");
                    more.setEnabled(true);more.setVisibility(result.optBoolean("hasMore")?android.view.View.VISIBLE:android.view.View.GONE);
                });}
                public void onError(String message){owner.runOnUiThread(()->{if(owner.isFinishing()||!dialog.isShowing())return;loading=false;status.setText("Could not load · "+message);more.setText(UiStrings.label(more.getContext(),"Retry"));more.setEnabled(true);more.setVisibility(android.view.View.VISIBLE);});}
            });
        }
        void add(JSONObject user){
            LinearLayout row=new LinearLayout(owner);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(10),dp(6),dp(10),dp(6));
            ImageView photo=new ImageView(owner);photo.setImageResource(R.drawable.myshop_profile_avatar);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
            GradientDrawable shape=new GradientDrawable();shape.setColor(Color.WHITE);shape.setCornerRadius(dp(24));photo.setBackground(shape);photo.setClipToOutline(true);SafeImageLoader.load(photo,user.optString("avatarUrl"));row.addView(photo,new LinearLayout.LayoutParams(dp(44),dp(44)));
            TextView name=new TextView(owner);name.setText(user.optString("name")+"\nID "+user.optString("userId"));name.setTextColor(0xff17223f);name.setTextSize(13);name.setPadding(dp(10),0,0,0);row.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            row.setOnClickListener(v->{dialog.dismiss();owner.startActivity(new Intent(owner,UserProfileActivity.class).putExtra("userId",user.optString("userId")));});list.addView(row);
        }
    }
}
