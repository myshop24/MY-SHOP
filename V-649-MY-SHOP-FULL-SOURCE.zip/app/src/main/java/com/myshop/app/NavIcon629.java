package com.myshop.app;
import android.graphics.*;import android.graphics.drawable.Drawable;
/** Four approved side controls; central AnimatedLiveIconView is deliberately independent. */
final class NavIcon629 extends Drawable {
 static int labelColor632(android.content.Context c,String key,int normal){if(!Appearance.dark(c))return normal;return "home".equals(key)?0xff8bc7ff:"store".equals(key)?0xffffd277:"support".equals(key)?0xff71efdc:"more".equals(key)?0xffd4a3ff:0xffff8cc0;}
 private final String key;private final Paint p=new Paint(3);NavIcon629(String k){key=k;}
 private void fill(int hi,int lo){p.setStyle(Paint.Style.FILL);p.setShader(new LinearGradient(0,1,26,30,hi,lo,Shader.TileMode.CLAMP));}
 private void line(Canvas c,float x,float y,float xx,float yy,int color,float width){p.setShader(null);p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(width);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(x,y,xx,yy,p);p.setStyle(Paint.Style.FILL);}
 @Override public void draw(Canvas c){int save=c.save();Rect b=getBounds();c.translate(b.left,b.top);c.scale(b.width()/32f,b.height()/32f);p.setShader(null);p.setColor(0xff858695);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.5f);p.setStrokeJoin(Paint.Join.ROUND);p.setStrokeCap(Paint.Cap.ROUND);
 if("home".equals(key)){p.setColor(0xff0866ff);p.setStyle(Paint.Style.FILL);Path h=new Path();h.moveTo(3,14);h.lineTo(16,3);h.lineTo(29,14);h.close();h.moveTo(7,12);h.lineTo(7,29);h.lineTo(13,29);h.lineTo(13,20);h.lineTo(19,20);h.lineTo(19,29);h.lineTo(25,29);h.lineTo(25,12);c.drawPath(h,p);}
 else if("store".equals(key)){p.setColor(0xff0866ff);Path q=new Path();q.moveTo(3,4);q.lineTo(7,4);q.lineTo(11,23);q.lineTo(26,23);q.moveTo(9,9);q.lineTo(29,9);q.lineTo(25,19);q.lineTo(10,19);c.drawPath(q,p);c.drawCircle(12,28,1.5f,p);c.drawCircle(25,28,1.5f,p);}
 else if("video".equals(key)){p.setColor(0xff101934);c.drawRoundRect(4,4,28,29,3,3,p);c.drawLine(4,12,28,12,p);c.drawLine(10,4,15,12,p);c.drawLine(19,4,24,12,p);Path play=new Path();play.moveTo(13,17);play.lineTo(22,21);play.lineTo(13,26);play.close();p.setStyle(Paint.Style.FILL);c.drawPath(play,p);}
 else if("support".equals(key)){c.drawArc(5,3,27,27,180,180,false,p);c.drawRoundRect(3,14,9,25,2,2,p);c.drawRoundRect(23,14,29,25,2,2,p);Path q=new Path();q.moveTo(26,25);q.lineTo(24,29);q.lineTo(17,29);c.drawPath(q,p);}
 else for(int y=0;y<2;y++)for(int x=0;x<2;x++){float l=3+x*15,t=3+y*15;c.drawRoundRect(l,t,l+11,t+11,2,2,p);}
 p.setStyle(Paint.Style.FILL);c.restoreToCount(save);}
 @Override public void setAlpha(int a){p.setAlpha(a);}@Override public void setColorFilter(ColorFilter f){p.setColorFilter(f);}@Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
