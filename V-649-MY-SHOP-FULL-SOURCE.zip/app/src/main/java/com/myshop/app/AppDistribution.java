package com.myshop.app;
/** Permanent direct APK asset link. Latest means published release, not unbuilt source. */
public final class AppDistribution {
    private AppDistribution(){}
    public static final String LATEST_APK_URL="https://github.com/myshop24/MY-SHOP/releases/latest/download/MY_SHOP_FINAL_RELEASE.apk";
    public static String shareText(){return "MY SHOP অ্যাপ ডাউনলোড করুন: "+LATEST_APK_URL;}
}
