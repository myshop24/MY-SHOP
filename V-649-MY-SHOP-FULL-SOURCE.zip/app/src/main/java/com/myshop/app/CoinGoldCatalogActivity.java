package com.myshop.app;
/** Legacy navigation compatibility only; no separate wallet or catalog implementation. */
@Deprecated public class CoinGoldCatalogActivity extends CoinDiamondCatalogActivity {}
