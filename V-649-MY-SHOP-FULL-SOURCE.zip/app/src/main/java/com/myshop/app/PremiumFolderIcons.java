package com.myshop.app;
import android.graphics.*;import android.graphics.drawable.Drawable;import android.widget.ImageView;
/** Glossy folder body and a crisp high resolution 3D functional symbol. */
final class PremiumFolderIcons extends Drawable {
 private final Bitmap icon;private final Paint paint=new Paint(3);private final int base;
 private PremiumFolderIcons(android.content.Context c,String key){int at=PremiumArt.index(key);icon=PremiumArt.bitmap(c,at);int[] colors={0xff17bf61,0xff2395ff,0xffffbc20,0xffbd50ed,0xff00bba9};base=colors[at%colors.length];}
 static void apply(ImageView v,String key){v.setImageTintList(null);v.setImageDrawable(new PremiumFolderIcons(v.getContext(),key));}
 @Override public void draw(Canvas canvas){Rect b=getBounds();canvas.save();canvas.translate(b.left,b.top);canvas.scale(b.width()/64f,b.height()/64f);paint.setShader(null);paint.setColor(0x18000000);canvas.drawOval(new RectF(5,55,61,62),paint);paint.setColor(base);canvas.drawRoundRect(new RectF(5,10,29,29),5,5,paint);paint.setShader(new LinearGradient(8,16,52,58,new int[]{light(base),base,dark(base)},null,Shader.TileMode.CLAMP));canvas.drawRoundRect(new RectF(4,19,60,57),7,7,paint);paint.setShader(null);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1);paint.setColor(0x99ffffff);canvas.drawRoundRect(new RectF(5,20,59,55),6,6,paint);paint.setStyle(Paint.Style.FILL);canvas.drawBitmap(icon,null,new RectF(17,22,49,53),paint);canvas.restore();}
 private int light(int c){return Color.rgb((Color.red(c)+255)/2,(Color.green(c)+255)/2,(Color.blue(c)+255)/2);}private int dark(int c){return Color.rgb(Color.red(c)*3/4,Color.green(c)*3/4,Color.blue(c)*3/4);}
 @Override public void setAlpha(int a){paint.setAlpha(a);}@Override public void setColorFilter(ColorFilter f){paint.setColorFilter(f);}@Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}@Override public int getIntrinsicWidth(){return 64;}@Override public int getIntrinsicHeight(){return 64;}
}
