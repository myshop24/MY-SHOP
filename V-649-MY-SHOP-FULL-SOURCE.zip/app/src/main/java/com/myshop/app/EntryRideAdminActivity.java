package com.myshop.app;

import android.os.Bundle;

/** Dedicated Entry / Ride Animation Admin route. Uses the shared premium CRUD core in entry-only mode. */
public class EntryRideAdminActivity extends AdminStoreActivity {
  @Override protected void onCreate(Bundle b){
    getIntent().putExtra("entry_ride_mode",true);
    getIntent().putExtra("catalog_filter","ENTRY_ANIMATION");
    super.onCreate(b);
  }
}
