package com.myshop.app;
import android.content.Context;import android.graphics.*;import android.view.View;
/** Smooth decorative activity bars, not a remote microphone meter. */
public final class LiveEqualizerView extends View {
 private final Paint p=new Paint(3);private final int[] colors={0xff248aff,0xff34dcff,0xff2af0dc,0xffa765ff,0xffff54d3,0xffff73ab,0xff43baff};
 public LiveEqualizerView(Context c){super(c);setContentDescription("Animated Live activity");setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
 @Override protected void onDraw(Canvas c){float step=getWidth()/7f,h=getHeight(),time=android.os.SystemClock.uptimeMillis()/430f;boolean reduce=false;for(int i=0;i<7;i++){float v=.22f+.68f*(.5f+.5f*(float)Math.sin((reduce?0:time)+i*1.35f)),x=i*step+step*.16f,w=step*.62f;p.setColor(colors[i]);p.setShadowLayer(2,0,0,colors[i]);c.drawRoundRect(x,h-h*v,x+w,h,w/2,w/2,p);p.clearShadowLayer();}if(!reduce&&isShown())postInvalidateOnAnimation();}
}
