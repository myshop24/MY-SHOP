package com.myshop.app;
import android.content.Context;import android.graphics.*;import android.view.View;
/** Layered edge-only orbit; portrait and microphone state remain independent. */
final class SpeakingWaveView extends View {
 private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);private boolean speaking;private final boolean reduced;
 SpeakingWaveView(Context c){super(c);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);reduced=false;}
 void setSpeaking(boolean value){if(speaking!=value){speaking=value;invalidate();}}
 @Override protected void onDraw(Canvas c){super.onDraw(c);if(!isShown())return;float side=Math.min(getWidth(),getHeight()),cx=getWidth()/2f,cy=getHeight()/2f;if(!speaking)return;if(speaking){float pulse=(android.os.SystemClock.uptimeMillis()%1000)/1000f;paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(side*.02f);for(int i=0;i<2;i++){float p=(pulse+i*.5f)%1;paint.setColor(0xff65e9ff);paint.setAlpha((int)(200*(1-p)));c.drawCircle(cx,cy,side*(.41f+.075f*p),paint);}paint.setAlpha(255);paint.setStyle(Paint.Style.FILL);for(int i=0;i<5;i++){float h=side*(.025f+.06f*(.5f+.5f*(float)Math.sin((pulse*2+i*.3f)*Math.PI)));float x=cx+(i-2)*side*.045f;c.drawRoundRect(x-side*.012f,cy+side*.39f-h,x+side*.012f,cy+side*.39f,side*.01f,side*.01f,paint);}}if(!reduced)postInvalidateOnAnimation();}
}
