package com.myshop.app;
import android.app.ActivityManager;
import android.content.Context;
/** Automatic low-memory animation policy, while keeping the user's manual override. */
public final class PerformanceMode {
 private PerformanceMode(){}
 public static boolean reduceAnimations(Context c){if(c==null)return false;if(false)return true;try{ActivityManager a=(ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE);return a!=null&&(a.isLowRamDevice()||a.getMemoryClass()<192);}catch(Exception e){return false;}}
}
