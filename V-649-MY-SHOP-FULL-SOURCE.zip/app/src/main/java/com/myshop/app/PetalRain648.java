package com.myshop.app;
import android.content.Context;import android.graphics.*;import android.view.*;import android.animation.ValueAnimator;
final class PetalRain648 extends View {
 private final Paint p=new Paint(3);private final float[] x=new float[42],speed=new float[42],offset=new float[42];private ValueAnimator animator;private float time;
 PetalRain648(Context c){super(c);setClickable(false);java.util.Random rng=new java.util.Random(648);for(int i=0;i<x.length;i++){x[i]=rng.nextFloat();speed[i]=.4f+rng.nextFloat()*.5f;offset[i]=rng.nextFloat();}}
 void play(){animator=ValueAnimator.ofFloat(0,1);animator.setDuration(6500);animator.addUpdateListener(a->{time=(Float)a.getAnimatedValue();invalidate();});animator.addListener(new android.animation.AnimatorListenerAdapter(){public void onAnimationEnd(android.animation.Animator a){if(getParent() instanceof android.view.ViewGroup)((android.view.ViewGroup)getParent()).removeView(PetalRain648.this);}});animator.start();}
 protected void onDraw(Canvas c){super.onDraw(c);c.save();c.clipRect(0,0,getWidth(),getHeight());for(int i=0;i<x.length;i++){float y=((time*2*speed[i]+offset[i])%1f)*getHeight(),cx=(x[i]+.035f*(float)Math.sin(time*14+i))*getWidth();p.setColor(i%4==0?0xff79bc87:i%3==0?0xffffe6ba:0xffffa2cd);p.setAlpha((int)(165*Math.min(1,(1-time)*6)));c.save();c.rotate(time*280+i*31,cx,y);float d=getResources().getDisplayMetrics().density;c.drawOval(cx-3*d,y-6*d,cx+3*d,y+6*d,p);c.restore();}c.restore();}
 protected void onDetachedFromWindow(){if(animator!=null){animator.removeAllListeners();animator.cancel();}super.onDetachedFromWindow();}
}
