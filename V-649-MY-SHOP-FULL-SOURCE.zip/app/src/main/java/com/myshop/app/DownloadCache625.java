package com.myshop.app;
import android.content.Context;import java.io.File;import java.io.IOException;import java.util.*;
/** Only reproducible image/download caches. Never account files, drafts, camera photos or recordings. */
final class DownloadCache625 {
 static List<File> files(File root)throws IOException{List<File> out=new ArrayList<>();String parent=root.getCanonicalPath()+File.separator;for(String folder:new String[]{"images570","message-media"}){File dir=new File(root,folder);if(!dir.getCanonicalPath().startsWith(parent))continue;File[] entries=dir.listFiles();if(entries==null)continue;for(File file:entries){if(!file.isFile()||!file.getCanonicalPath().startsWith(dir.getCanonicalPath()+File.separator))continue;if(folder.equals("images570")||file.getName().startsWith("attachment-"))out.add(file);}}return out;}
 static long bytes(File root){try{long total=0;for(File f:files(root))total+=f.length();return total;}catch(IOException e){return 0;}}
 static long clean(File root,boolean explicit,long now){try{List<File> list=files(root);list.sort(Comparator.comparingLong(File::lastModified));long total=bytes(root),removed=0;for(File file:list){long age=now-file.lastModified();if(age<60000)continue;boolean expire=age>7L*24*60*60*1000,over=total>128L*1024*1024&&age>24L*60*60*1000;if(!explicit&&!expire&&!over)continue;long size=file.length();if(file.delete()){removed+=size;total-=size;}}return removed;}catch(IOException e){return 0;}}
 static void prune(Context c){File cache=c.getApplicationContext().getCacheDir();new Thread(()->clean(cache,false,System.currentTimeMillis()),"myshop-cache-prune").start();}
}
