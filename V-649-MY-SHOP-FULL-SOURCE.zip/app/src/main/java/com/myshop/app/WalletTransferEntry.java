package com.myshop.app;
import android.app.Activity;import android.content.Intent;import android.widget.EditText;
/** Recipient entry reuses the profile's authenticated transfer flow and receipt. */
final class WalletTransferEntry {
 static void show(Activity a){EditText id=new EditText(a);id.setHint("৪ সংখ্যার প্রাপকের আইডি");id.setInputType(2);id.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(4)});new MyShopDialogBuilder(a).setTitle("Coin / Diamond ট্রান্সফার").setMessage("আগে প্রাপকের প্রোফাইল যাচাই করুন, তারপর পরিমাণ দিয়ে নিশ্চিত করুন।").setView(id).setNegativeButton(UiStrings.ui636("বাতিল"),null).setPositiveButton("প্রাপক দেখুন",(d,w)->{String uid=id.getText().toString().trim();if(!uid.matches("[0-9]{4}")||uid.equals(SessionManager.getUserId(a))){android.widget.Toast.makeText(a,"অন্য ইউজারের সঠিক আইডি দিন",android.widget.Toast.LENGTH_LONG).show();return;}a.startActivity(new Intent(a,UserProfileActivity.class).putExtra("userId",uid).putExtra("openTransfer",true));}).show();}
}
