package com.myshop.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;
import java.util.ArrayList;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import org.json.JSONArray;
import org.json.JSONObject;
import androidx.appcompat.app.AppCompatActivity;

public class FeatureActivity extends AppCompatActivity {
    private final Handler adHandler=new Handler();
    private final ArrayList<JSONObject> folderAds=new ArrayList<>();
    private LinearLayout folderAdBox; private ImageView folderAdImage; private TextView folderAdCaption,folderAdDots;
    private int folderAdIndex=0; private String currentFeatureKey="";
    private final Runnable folderAdTick=new Runnable(){@Override public void run(){if(!folderAds.isEmpty()){folderAdIndex=(folderAdIndex+1)%folderAds.size();showFolderAd();}scheduleNextFolderAd();}};
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String requested=getIntent().getStringExtra("feature_key");
        currentFeatureKey=requested==null?"":requested.trim().toLowerCase(java.util.Locale.US);
        if(needsPublishedCheck()){
            LinearLayout waiting=new LinearLayout(this);waiting.setOrientation(LinearLayout.VERTICAL);waiting.setPadding(dp(20),dp(28),dp(20),dp(20));
            TextView notice=new TextView(this);notice.setText("ফিচারের বর্তমান অবস্থা যাচাই করা হচ্ছে…");waiting.addView(notice);
            Button retry=new Button(this);retry.setText("আবার চেষ্টা করুন");retry.setOnClickListener(v->FeatureAccess.open(this,currentFeatureKey,this::buildContent));waiting.addView(retry);
            Button back=new Button(this);back.setText("ফিরে যান");back.setOnClickListener(v->finish());waiting.addView(back);setContentView(waiting);
            FeatureAccess.open(this,currentFeatureKey,this::buildContent);
        }else buildContent();
    }
    private boolean needsPublishedCheck(){return !currentFeatureKey.isEmpty()&&!"about".equals(currentFeatureKey)&&!currentFeatureKey.matches(".*(?:^|_)(?:live|rtc|audio|gift|gifts|room)(?:_|$).*");}
    private boolean contentBuilt=false;
    private void buildContent(){
        if(contentBuilt||isFinishing()||isDestroyed())return;contentBuilt=true;
        String title = getIntent().getStringExtra("title");
        if (title == null || title.trim().isEmpty()) title = "myshop";

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(18), dp(14), dp(14));
        root.setBackgroundColor(getColor(R.color.myshop_bg));

        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextSize(24);
        heading.setTextColor(getColor(R.color.myshop_dark));
        heading.setGravity(Gravity.CENTER);
        heading.setPadding(dp(4),dp(8),dp(4),dp(8));
        root.addView(heading, new LinearLayout.LayoutParams(-1, -2));if(!currentFeatureKey.matches(".*(?:live|rtc|audio|room|gift).*"))TextAppearance.bind(this,"feature_"+currentFeatureKey,TextAppearance.labels("element_title",heading));

        folderAdBox=createFolderAdBox();
        LinearLayout.LayoutParams adp=new LinearLayout.LayoutParams(-1,-2); adp.topMargin=dp(6); adp.bottomMargin=dp(7); root.addView(folderAdBox,adp);

        TextView status = new TextView(this);
        status.setText("myshop module frame\n\nThis feature is ready for backend-driven content. Where supported, Admin changes can be delivered without rebuilding the APK.");
        status.setTextSize(14.5f);
        status.setTextColor(getColor(R.color.text_muted));
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(8),dp(8),dp(8),dp(10));
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        String featureKey=getIntent().getStringExtra("feature_key"); currentFeatureKey=featureKey==null?"":featureKey.trim().toLowerCase(java.util.Locale.US); loadFolderAds();
        if ("about".equals(currentFeatureKey)) renderBuildIdentity(status);
        LinearLayout contentRoot=root;
        if ("external_movie".equals(featureKey) || "help_support".equals(featureKey) || "social_media".equals(featureKey)) {
            ScrollView featureScroll=new ScrollView(this); featureScroll.setFillViewport(true);
            LinearLayout inner=new LinearLayout(this); inner.setOrientation(LinearLayout.VERTICAL); inner.setPadding(0,dp(4),0,dp(18));
            featureScroll.addView(inner,new ScrollView.LayoutParams(-1,-2)); root.addView(featureScroll,new LinearLayout.LayoutParams(-1,0,1)); contentRoot=inner;
        }
        final LinearLayout renderRoot=contentRoot;
        if ("more_apps".equals(featureKey)) {
            renderMore(root,status);
        }
        if ("external_movie".equals(featureKey)) {
            status.setText("Loading External Movies…");
            BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->renderExternalMovies(renderRoot,status,d.optJSONArray("managedLinks")));}
                public void onError(String m){runOnUiThread(()->status.setText("External Movies unavailable: "+m));}
            });
        }
        if ("help_support".equals(featureKey)) {
            startActivity(new Intent(this, HelpCenterActivity.class));
            finish();
            return;
        }

        if ("social_media".equals(featureKey)) {
            status.setText("Loading Social Media…");
            BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->renderSocial(renderRoot,status,d.optJSONArray("socialLinks")));}
                public void onError(String m){runOnUiThread(()->status.setText("Social links unavailable: "+m));}
            });
        }

        if (!"about".equals(currentFeatureKey) && !"more_apps".equals(featureKey) && !"external_movie".equals(featureKey) && !"help_support".equals(featureKey) && !"social_media".equals(featureKey)) {
            status.setText("Loading feature…");
            BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->renderManagedFeature(renderRoot,status,d.optJSONArray("managedLinks")));}
                public void onError(String m){runOnUiThread(()->status.setText("Feature is not configured yet. Admin can add or enable it."));}
            });
        }

        String url = getIntent().getStringExtra("url");
        if (FeatureRegistry.isSafeHttpUrl(url)) {
            Button open = new Button(this);
            open.setText("Open Link");open.setTextColor(Color.WHITE);open.setTypeface(Typeface.DEFAULT,Typeface.BOLD);open.setBackground(PremiumUi.gradient(this,new int[]{Color.rgb(49,111,245),Color.rgb(111,63,232)},16,Color.argb(100,255,255,255),1));applyRipple(open);
            open.setOnClickListener(v -> openUrl(url));
            root.addView(open, new LinearLayout.LayoutParams(-1, 58));
        }

        Button back = new Button(this);
        back.setText("BACK");
        back.setAllCaps(false);
        back.setTextColor(Color.WHITE);
        back.setTextSize(14);
        back.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        back.setBackground(PremiumUi.gradient(this,new int[]{Color.rgb(40,62,145),Color.rgb(94,55,186)},16,Color.argb(105,255,255,255),1));PremiumUi.premiumElevation(back,3);
        back.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(48)); bp.topMargin=dp(8); root.addView(back,bp);
        setContentView(root);
    }


    private void renderManagedFeature(LinearLayout root,TextView status,JSONArray links){
        JSONObject found=null;int bestPriority=99;long newest=-1;
        if(links!=null){
            for(int i=0;i<links.length();i++){
                JSONObject x=links.optJSONObject(i);
                if(x==null)continue;String category=x.optString("category","").trim();
                int priority=("feature_"+currentFeatureKey).equalsIgnoreCase(category)?0:currentFeatureKey.equalsIgnoreCase(category)?1:99;
                if(priority<99&&(priority<bestPriority||priority==bestPriority&&x.optLong("id")>newest)){found=x;bestPriority=priority;newest=x.optLong("id");}
            }
        }
        if(found==null){
            status.setText(FeatureAvailability.message(null));
            return;
        }
        String title=found.optString("title",getIntent().getStringExtra("title"));
        String caption=found.optString("caption","");
        String image=found.optString("image_url","");
        String link=found.optString("url","");
        String st=found.optString("status",found.optInt("active",1)==1?"ACTIVE":"DISABLED").toUpperCase(java.util.Locale.US);
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(10),dp(10),dp(10));card.setBackground(PremiumUi.gradient(this,new int[]{Color.rgb(236,244,255),Color.rgb(246,237,255)},18,Color.argb(75,91,38,214),1));card.setElevation(dp(2));
        if(!image.isEmpty()){ImageView iv=new ImageView(this);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setBackground(roundBg(Color.WHITE,Color.TRANSPARENT,14));card.addView(iv,new LinearLayout.LayoutParams(-1,dp(145)));loadImageInto(iv,image);}
        TextView tt=new TextView(this);tt.setText(title);tt.setTextSize(17);tt.setTextColor(Color.rgb(24,35,86));tt.setTypeface(Typeface.DEFAULT,Typeface.BOLD);tt.setPadding(0,dp(8),0,dp(2));card.addView(tt);java.util.LinkedHashMap<String,TextView> appearance=TextAppearance.labels("element_title",tt);
        if(!caption.isEmpty()){TextView cc=new TextView(this);cc.setText(caption);cc.setTextSize(11);cc.setTextColor(Color.rgb(90,98,120));cc.setMaxLines(4);card.addView(cc,new LinearLayout.LayoutParams(-1,dp(54)));appearance.put("element_caption",cc);}
        if(!currentFeatureKey.matches(".*(?:live|rtc|audio|room|gift).*"))TextAppearance.bind(this,"feature_"+currentFeatureKey,appearance);int price=found.optInt("price_minor",0);String offer=found.optString("offer_text","");String start=found.optString("offer_start","");String end=found.optString("offer_end","");int limit=found.optInt("time_limit_minutes",0);
        StringBuilder meta=new StringBuilder(st);if(price>0)meta.append(" • Price ").append(price);if(!offer.isEmpty())meta.append(" • ").append(offer);if(limit>0)meta.append(" • ").append(limit).append(" min");if(!start.isEmpty()||!end.isEmpty())meta.append(" • ").append(start).append(end.isEmpty()?"":" → ").append(end);
        TextView mt=new TextView(this);mt.setText(meta.toString());mt.setTextSize(8.8f);mt.setTextColor(Color.rgb(89,64,155));card.addView(mt,new LinearLayout.LayoutParams(-1,dp(28)));
        final boolean executable=FeatureAvailability.canExecute(found);
        if(!executable){TextView notice=new TextView(this);notice.setText(FeatureAvailability.message(found));notice.setTextSize(14);notice.setPadding(0,dp(10),0,dp(10));card.addView(notice);}
        Button action=new Button(this);action.setAllCaps(false);action.setText(executable?"Open Link →":"Unavailable");action.setEnabled(executable);action.setTextColor(Color.WHITE);action.setTypeface(Typeface.DEFAULT,Typeface.BOLD);action.setBackground(PremiumUi.gradient(this,new int[]{Color.rgb(44,101,244),Color.rgb(112,57,226)},14,Color.argb(95,255,255,255),1));
        action.setOnClickListener(v->{if(executable)openUrl(link);});
        card.addView(action,new LinearLayout.LayoutParams(-1,dp(48)));root.addView(card,new LinearLayout.LayoutParams(-1,-2));
        status.setVisibility(View.GONE);
    }

    private void loadImageInto(ImageView v,String u){new android.os.AsyncTask<Void,Void,Bitmap>(){protected Bitmap doInBackground(Void...z){try{java.net.URL url=new java.net.URL(u);return BitmapFactory.decodeStream(url.openConnection().getInputStream());}catch(Exception e){return null;}}protected void onPostExecute(Bitmap b){if(b!=null)v.setImageBitmap(b);}}.execute();}

    private GradientDrawable roundBg(int fill,int stroke,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);if(stroke!=0)g.setStroke(dp(1),stroke);g.setCornerRadius(dp(radius));return g;}

    /** V-370: visible APK/source/backend identity so an installed build can never be mistaken for another version. */
    private void renderBuildIdentity(TextView status){
        String sha=BuildConfig.MYSHOP_GIT_SHA==null?"local":BuildConfig.MYSHOP_GIT_SHA;
        if(sha.length()>12)sha=sha.substring(0,12);
        final String git=sha;
        status.setText("myshop Build Identity\n\n"+BuildConfig.MYSHOP_BUILD_ID+"  •  "+BuildConfig.VERSION_NAME+"\nversionCode "+BuildConfig.VERSION_CODE+"  •  Git "+git+"\n\nBackend check: checking…");
        Executors.newSingleThreadExecutor().execute(()->{
            String result="Backend check: unavailable";
            HttpURLConnection c=null;
            try{
                URL u=new URL(BuildConfig.MYSHOP_BACKEND_URL+"/health");
                c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(4500);c.setReadTimeout(4500);c.setRequestMethod("GET");
                String body="";try(InputStream in=c.getInputStream()){java.util.Scanner sc=new java.util.Scanner(in,"UTF-8").useDelimiter("\\A");body=sc.hasNext()?sc.next():"";}
                JSONObject j=new JSONObject(body);String v=j.optString("version","");String b=j.optString("build","");
                boolean match=BuildConfig.MYSHOP_EXPECTED_BACKEND_VERSION.equals(v) && BuildConfig.MYSHOP_BUILD_ID.equals("myshop "+b);
                result=match?("Backend check: MATCH  •  "+b+" / "+v):("Backend check: MISMATCH  •  "+b+" / "+v);
            }catch(Exception ignored){}finally{if(c!=null)c.disconnect();}
            final String r=result;runOnUiThread(()->status.setText("myshop Build Identity\n\n"+BuildConfig.MYSHOP_BUILD_ID+"  •  "+BuildConfig.VERSION_NAME+"\nversionCode "+BuildConfig.VERSION_CODE+"  •  Git "+git+"\n\n"+r));
        });
    }


    private LinearLayout createFolderAdBox(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(5),dp(5),dp(5),dp(4)); box.setBackground(roundedBg(Color.WHITE,Color.rgb(226,229,238),16)); box.setVisibility(View.GONE); box.setElevation(dp(2));
        folderAdImage=new AspectBannerImageView(this); folderAdImage.setBackground(roundedBg(Color.rgb(245,247,252),0,13)); folderAdImage.setClipToOutline(true); box.addView(folderAdImage,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
        folderAdCaption=new TextView(this); folderAdCaption.setTextSize(10); folderAdCaption.setTextColor(Color.rgb(24,35,86)); folderAdCaption.setTypeface(Typeface.DEFAULT,Typeface.BOLD); folderAdCaption.setSingleLine(true); row.addView(folderAdCaption,new LinearLayout.LayoutParams(0,dp(30),1));
        folderAdDots=new TextView(this); folderAdDots.setTextSize(8); folderAdDots.setTextColor(Color.rgb(91,38,214)); folderAdDots.setGravity(Gravity.END|Gravity.CENTER_VERTICAL); row.addView(folderAdDots,new LinearLayout.LayoutParams(dp(96),dp(30))); box.addView(row,new LinearLayout.LayoutParams(-1,dp(30)));
        applyRipple(box); return box;
    }

    private void loadFolderAds(){
        if(currentFeatureKey.isEmpty()||folderAdBox==null)return;
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{folderAds.clear();JSONArray a=d.optJSONArray("dashboardAds");if(a!=null)for(int i=0;i<a.length()&&folderAds.size()<6;i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;if(!currentFeatureKey.equalsIgnoreCase(x.optString("box_key","")))continue;if(x.optInt("active",1)!=1)continue;String media=x.optString("media_type","image");if(!"image".equalsIgnoreCase(media))continue;if(x.optString("image_url","").trim().isEmpty())continue;int slot=x.optInt("slot",0);if(slot<1||slot>6)continue;folderAds.add(x);}folderAdIndex=0;if(folderAds.isEmpty()){folderAdBox.setVisibility(View.GONE);adHandler.removeCallbacks(folderAdTick);}else{folderAdBox.setVisibility(View.VISIBLE);showFolderAd();scheduleNextFolderAd();}});}
            public void onError(String m){runOnUiThread(()->{if(folderAdBox!=null)folderAdBox.setVisibility(View.GONE);});}
        });
    }
    private void showFolderAd(){
        if(folderAds.isEmpty()||folderAdImage==null)return; JSONObject x=folderAds.get(folderAdIndex%folderAds.size()); String url=x.optString("image_url",""); String cap=x.optString("caption","").trim();
        folderAdImage.animate().alpha(.25f).setDuration(120).withEndAction(()->{loadImageUrl(folderAdImage,url);folderAdImage.animate().alpha(1f).setDuration(180).start();}).start();
        folderAdCaption.setText(cap.isEmpty()?"Advertisement":cap); StringBuilder dots=new StringBuilder();for(int i=0;i<folderAds.size();i++){dots.append(i==folderAdIndex?"●":"○");if(i<folderAds.size()-1)dots.append("  ");}folderAdDots.setText(dots.toString());
        String target=x.optString("target_url","").trim(); folderAdBox.setOnClickListener(v->{if(FeatureRegistry.isSafeHttpUrl(target))openUrl(target);});
    }
    private void scheduleNextFolderAd(){adHandler.removeCallbacks(folderAdTick);if(folderAds.size()<2)return;int sec=5;try{sec=Math.max(1,Math.min(60,folderAds.get(folderAdIndex%folderAds.size()).optInt("duration_sec",5)));}catch(Exception ignored){}adHandler.postDelayed(folderAdTick,sec*1000L);}
    @Override protected void onDestroy(){adHandler.removeCallbacks(folderAdTick);super.onDestroy();}

    private int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private GradientDrawable roundedBg(int fill, int stroke, int radius){
        GradientDrawable g=new GradientDrawable(); g.setColor(fill); g.setCornerRadius(dp(radius));
        if(stroke!=0) g.setStroke(dp(1),stroke); return g;
    }
    private void applyRipple(View v){
        if(android.os.Build.VERSION.SDK_INT>=21){
            android.graphics.drawable.Drawable base=v.getBackground();
            if(base!=null)v.setBackground(new android.graphics.drawable.RippleDrawable(ColorStateList.valueOf(Color.argb(36,255,255,255)),base,null));
        }
        PremiumUi.press(v);
    }

    private void renderExternalMovies(LinearLayout root, TextView status, JSONArray a){
        status.setText(""); int count=0;
        if(a!=null) for(int i=0;i<a.length()&&count<6;i++){JSONObject x=a.optJSONObject(i);if(x==null||!"external_movie".equalsIgnoreCase(x.optString("category",""))||x.optInt("active",1)!=1)continue;String title=x.optString("title","External Movie").trim();String caption=x.optString("caption","").trim();String url=x.optString("url","").trim();String image=x.optString("image_url","").trim();String icon=x.optString("icon_url","").trim();if(url.isEmpty())continue;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(10),dp(8),dp(10),dp(8));card.setBackground(roundedBg(Color.WHITE,Color.rgb(232,234,240),14));if(!image.isEmpty()){ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);card.addView(im,new LinearLayout.LayoutParams(-1,dp(150)));loadImageUrl(im,image);}LinearLayout titleRow=new LinearLayout(this);titleRow.setOrientation(LinearLayout.HORIZONTAL);titleRow.setGravity(Gravity.CENTER_VERTICAL);ImageView iv=new ImageView(this);iv.setImageResource(R.drawable.icon_more);if(!icon.isEmpty())loadImageUrl(iv,icon);titleRow.addView(iv,new LinearLayout.LayoutParams(dp(38),dp(38)));TextView cap=new TextView(this);cap.setText(title);cap.setTextSize(14);cap.setTextColor(Color.rgb(24,29,62));cap.setTypeface(Typeface.DEFAULT,Typeface.BOLD);cap.setPadding(dp(8),dp(4),dp(6),dp(4));titleRow.addView(cap,new LinearLayout.LayoutParams(0,dp(44),1));card.addView(titleRow);if(!caption.isEmpty()){TextView ct=new TextView(this);ct.setText(caption);ct.setTextSize(11);ct.setTextColor(Color.rgb(105,111,130));ct.setPadding(dp(6),0,dp(6),dp(8));card.addView(ct,new LinearLayout.LayoutParams(-1,-2));}card.setOnClickListener(v->openUrl(url));root.addView(card,new LinearLayout.LayoutParams(-1,-2));count++;}
        if(count==0)status.setText("No External Movie links have been configured yet.");
    }

    private void renderMore(LinearLayout root, TextView status){
        status.setVisibility(TextView.VISIBLE);
        status.setText(UiStrings.label(status.getContext(),"Loading…"));
        LinearLayout content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(2),dp(4),dp(2),dp(14));

        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.addView(content,new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll,1,new LinearLayout.LayoutParams(-1,0,1));

        TextView hint=new TextView(this);
        hint.setText("Connect with myshop"); hint.setTextSize(14); hint.setTextColor(Color.rgb(105,111,130));
        hint.setPadding(dp(4),dp(2),dp(4),dp(10));
        content.addView(hint,new LinearLayout.LayoutParams(-1,dp(30)));

        final String[] wanted={"Facebook","Page","YouTube","WhatsApp","imo","Instagram","Telegram","TikTok"};
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                JSONArray social=d.optJSONArray("socialLinks");
                for(String w:wanted){
                    String target="";
                    if(social!=null) for(int i=0;i<social.length();i++){
                        JSONObject x=social.optJSONObject(i);
                        if(x!=null && w.equalsIgnoreCase(x.optString("platform","")) && x.optInt("active",1)==1){
                            String u=x.optString("url","").trim();
                            String normalized=normalizePlatformTarget(w,u); if(!normalized.isEmpty()){target=normalized;break;}
                        }
                    }
                    String caption="",iconUrl="",imageUrl=""; if(social!=null) for(int i=0;i<social.length();i++){JSONObject x=social.optJSONObject(i);if(x!=null&&w.equalsIgnoreCase(x.optString("platform",""))){caption=x.optString("caption","");iconUrl=x.optString("icon_url",x.optString("iconUrl",""));imageUrl=x.optString("image_url",x.optString("imageUrl",""));break;}} addPlatformButton(content,w,target,caption,iconUrl,imageUrl);
                }
                addMoreButton(content,"CUSTOMER SUPPORT","Contact myshop support",v->{
                    Intent i=new Intent(FeatureActivity.this,FeatureActivity.class);
                    i.putExtra("title","CUSTOMER SUPPORT"); i.putExtra("feature_key","help_support"); startActivity(i);
                });
                addMoreButton(content,"SHARE APP","Share myshop with friends",v->shareApp());
            });}
            public void onError(String m){runOnUiThread(()->{
                for(String w:wanted) addPlatformButton(content,w,"","","","");
                addMoreButton(content,"CUSTOMER SUPPORT","Contact myshop support",v->{
                    Intent i=new Intent(FeatureActivity.this,FeatureActivity.class);
                    i.putExtra("title","CUSTOMER SUPPORT"); i.putExtra("feature_key","help_support"); startActivity(i);
                });
                addMoreButton(content,"SHARE APP","Share myshop with friends",v->shareApp());
            });}
        });
    }

    private void addPlatformButton(LinearLayout root,String platform,String url,String caption,String iconUrl,String imageUrl){
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14),dp(6),dp(10),dp(6));
        card.setBackground(PremiumUi.solid(this,Color.WHITE,17,Color.rgb(226,230,243),1));
        PremiumUi.premiumElevation(card,3); applyRipple(card);

        ImageView icon=new ImageView(this);
        icon.setImageResource(platformIconRes(platform)); icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE); if(imageUrl!=null&&!imageUrl.trim().isEmpty())loadImageUrl(icon,imageUrl.trim()); else if(iconUrl!=null&&!iconUrl.trim().isEmpty())loadImageUrl(icon,iconUrl.trim());
        icon.setBackground(roundedBg(Color.rgb(242,244,248),0,14));
        card.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));

        LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); texts.setGravity(Gravity.CENTER_VERTICAL);
        TextView name=new TextView(this); name.setText(platform); name.setTextSize(16); name.setTextColor(Color.rgb(24,29,62)); name.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        TextView sub=new TextView(this); sub.setText(!caption.isEmpty()?caption:(!url.isEmpty()?"Open":"Not configured")); sub.setTextSize(11); sub.setTextColor(!url.isEmpty()?Color.rgb(91,96,112):Color.rgb(160,164,175));
        texts.addView(name,new LinearLayout.LayoutParams(-1,dp(24))); texts.addView(sub,new LinearLayout.LayoutParams(-1,dp(18)));
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(58),1); tp.setMargins(dp(12),0,dp(6),0); card.addView(texts,tp);

        TextView go=new TextView(this); go.setText(!url.isEmpty()?"›":"—"); go.setTextSize(27); go.setTextColor(!url.isEmpty()?Color.rgb(83,32,180):Color.rgb(170,174,185)); go.setGravity(Gravity.CENTER);
        card.addView(go,new LinearLayout.LayoutParams(dp(30),dp(58)));
        if(!url.isEmpty()) card.setOnClickListener(v->openUrl(url)); else card.setAlpha(0.82f);
        if(SessionManager.isAdmin(this)) {
            TextView edit=new TextView(this); edit.setText("EDIT"); edit.setTextColor(Color.WHITE); edit.setTextSize(9); edit.setTypeface(Typeface.DEFAULT,Typeface.BOLD); edit.setGravity(Gravity.CENTER); edit.setBackground(roundedBg(Color.rgb(46,47,190),0,8)); applyRipple(edit);
            edit.setOnClickListener(v->{ Intent i=new Intent(FeatureActivity.this,AdminSectionActivity.class); i.putExtra("section","more_apps"); i.putExtra("admin_context",true); startActivity(i); });
            LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(dp(54),dp(30)); ep.setMargins(dp(6),0,0,0); card.addView(edit,ep);
        }
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(72)); cp.setMargins(0,0,0,dp(10)); root.addView(card,cp);
    }

    private int platformIconRes(String p){
        String s=p==null?"":p.toLowerCase();
        if(s.contains("facebook"))return R.drawable.icon_facebook;
        if(s.equals("page"))return R.drawable.icon_page;
        if(s.contains("youtube"))return R.drawable.icon_youtube;
        if(s.contains("whatsapp"))return R.drawable.icon_whatsapp;
        if(s.contains("imo"))return R.drawable.icon_imo;
        if(s.contains("instagram"))return R.drawable.icon_instagram;
        if(s.contains("telegram"))return R.drawable.icon_telegram;if(s.contains("tiktok"))return R.drawable.icon_tiktok;
        return R.drawable.icon_more;
    }

    private void addMoreButton(LinearLayout root,String title,String desc,android.view.View.OnClickListener listener){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14),dp(6),dp(12),dp(6)); card.setBackground(PremiumUi.solid(this,Color.WHITE,17,Color.rgb(226,230,243),1)); PremiumUi.premiumElevation(card,3); applyRipple(card);
        ImageView icon=new ImageView(this); icon.setImageResource(title.contains("SUPPORT")?R.drawable.icon_support:R.drawable.icon_more); icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE); icon.setBackground(roundedBg(Color.rgb(242,244,248),0,14));
        card.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); texts.setGravity(Gravity.CENTER_VERTICAL);
        TextView t=new TextView(this); t.setText(title); t.setTextSize(16); t.setTextColor(Color.rgb(24,29,62)); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        TextView d=new TextView(this); d.setText(desc); d.setTextSize(11); d.setTextColor(Color.rgb(105,111,130));
        texts.addView(t,new LinearLayout.LayoutParams(-1,dp(24))); texts.addView(d,new LinearLayout.LayoutParams(-1,dp(18)));
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(58),1); tp.setMargins(dp(12),0,dp(6),0); card.addView(texts,tp);
        TextView go=new TextView(this); go.setText("›"); go.setTextSize(27); go.setTextColor(Color.rgb(83,32,180)); go.setGravity(Gravity.CENTER); card.addView(go,new LinearLayout.LayoutParams(dp(30),dp(58)));
        if(SessionManager.isAdmin(this) && title.contains("SUPPORT")){
            TextView edit=new TextView(this);edit.setText("EDIT");edit.setTextColor(Color.WHITE);edit.setTextSize(9);edit.setTypeface(Typeface.DEFAULT,Typeface.BOLD);edit.setGravity(Gravity.CENTER);edit.setBackground(roundedBg(Color.rgb(46,47,190),0,8));applyRipple(edit);edit.setOnClickListener(v->{Intent i=new Intent(FeatureActivity.this,AdminSectionActivity.class);i.putExtra("section","help_support");i.putExtra("admin_context",true);startActivity(i);});LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(dp(54),dp(30));ep.setMargins(dp(6),0,0,0);card.addView(edit,ep);
        }
        card.setOnClickListener(listener); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(72)); cp.setMargins(0,0,0,dp(10)); root.addView(card,cp);
    }

    private void shareApp(){
        try{ Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_SUBJECT,"myshop"); i.putExtra(Intent.EXTRA_TEXT,AppDistribution.shareText()); startActivity(Intent.createChooser(i,"Share myshop")); }
        catch(Exception e){ Toast.makeText(this,"Share is not available.",Toast.LENGTH_SHORT).show(); }
    }

    private void renderSupport(LinearLayout root,TextView status,JSONArray a){
        status.setText(""); status.setVisibility(View.GONE); root.setPadding(dp(2),dp(6),dp(2),dp(18)); int count=0;
        if(a!=null) for(int i=0;i<a.length();i++){
            JSONObject x=a.optJSONObject(i); if(x==null||x.optInt("active",1)!=1)continue;
            String cat=x.optString("category",""); if(!"help_support".equals(cat))continue;
            String raw=x.optString("url","").trim(); final String target=normalizeSupportTarget(raw); if(target.isEmpty())continue;
            String title=x.optString("title","Customer Support").trim(); if(title.isEmpty())title="Customer Support";
            String caption=x.optString("caption","Contact myshop support").trim(); if(caption.isEmpty())caption="Contact myshop support";
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);card.setPadding(dp(12),dp(8),dp(12),dp(8));card.setBackground(roundedBg(Color.WHITE,Color.rgb(232,234,240),14));
            ImageView icon=new ImageView(this);icon.setImageResource(R.drawable.icon_support);icon.setScaleType(ImageView.ScaleType.CENTER_CROP);String imageUrl=x.optString("image_url","").trim();String iconUrl=x.optString("icon_url","").trim();if(!imageUrl.isEmpty())loadImageUrl(icon,imageUrl);else if(!iconUrl.isEmpty())loadImageUrl(icon,iconUrl);icon.setContentDescription(title);card.addView(icon,new LinearLayout.LayoutParams(dp(52),dp(52)));
            LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);TextView t=new TextView(this);t.setText(title);t.setTextSize(16);t.setTextColor(Color.rgb(24,29,62));t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);TextView d=new TextView(this);d.setText(caption);d.setTextSize(11);d.setTextColor(Color.rgb(105,111,130));tx.addView(t,new LinearLayout.LayoutParams(-1,dp(26)));tx.addView(d,new LinearLayout.LayoutParams(-1,dp(20)));LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(52),1);tp.setMargins(dp(12),0,0,0);card.addView(tx,tp);
            TextView go=new TextView(this);go.setText("›");go.setTextSize(28);go.setTextColor(Color.rgb(83,32,180));go.setGravity(Gravity.CENTER);card.addView(go,new LinearLayout.LayoutParams(dp(32),dp(52)));card.setOnClickListener(v->openUrl(target));
            if(SessionManager.isAdmin(this)){TextView edit=new TextView(this);edit.setText("EDIT");edit.setTextColor(Color.WHITE);edit.setTextSize(9);edit.setTypeface(Typeface.DEFAULT,Typeface.BOLD);edit.setGravity(Gravity.CENTER);edit.setBackground(roundedBg(Color.rgb(46,47,190),0,8));applyRipple(edit);edit.setOnClickListener(v->{Intent z=new Intent(FeatureActivity.this,AdminSectionActivity.class);z.putExtra("section","help_support");z.putExtra("admin_context",true);startActivity(z);});LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(dp(54),dp(30));ep.setMargins(dp(5),0,0,0);card.addView(edit,ep);}
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(76));cp.setMargins(0,0,0,dp(10));root.addView(card,cp);count++;
        }
        if(count==0){
            LinearLayout empty=new LinearLayout(this); empty.setOrientation(LinearLayout.VERTICAL); empty.setGravity(Gravity.CENTER); empty.setPadding(dp(16),dp(20),dp(16),dp(20)); empty.setBackground(roundedBg(Color.WHITE,Color.rgb(232,234,240),14));
            ImageView icon=new ImageView(this); icon.setImageResource(R.drawable.icon_support); icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE); empty.addView(icon,new LinearLayout.LayoutParams(dp(64),dp(64)));
            TextView t=new TextView(this); t.setText("Customer Support"); t.setTextSize(18); t.setTextColor(Color.rgb(24,29,62)); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setGravity(Gravity.CENTER); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2); tp.topMargin=dp(8); empty.addView(t,tp);
            TextView d=new TextView(this); d.setText("Admin has not configured a support link yet."); d.setTextSize(13); d.setTextColor(Color.rgb(105,111,130)); d.setGravity(Gravity.CENTER); d.setPadding(dp(4),dp(8),dp(4),dp(4)); empty.addView(d,new LinearLayout.LayoutParams(-1,-2));
            if(SessionManager.isAdmin(this)){TextView edit=new TextView(this);edit.setText("ADD / EDIT CUSTOMER SUPPORT");edit.setTextColor(Color.WHITE);edit.setTextSize(11);edit.setTypeface(Typeface.DEFAULT,Typeface.BOLD);edit.setGravity(Gravity.CENTER);edit.setBackground(roundedBg(Color.rgb(46,47,190),0,10));edit.setOnClickListener(v->{Intent z=new Intent(FeatureActivity.this,AdminSectionActivity.class);z.putExtra("section","help_support");z.putExtra("admin_context",true);startActivity(z);});LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(-1,dp(42));ep.topMargin=dp(12);empty.addView(edit,ep);}
            root.addView(empty,new LinearLayout.LayoutParams(-1,-2));
        }
    }
    private String normalizeSupportTarget(String raw){String v=raw==null?"":raw.trim();if(v.isEmpty())return "";if(v.startsWith("http://")||v.startsWith("https://")||v.startsWith("tel:")||v.startsWith("mailto:"))return v;String digits=v.replaceAll("[^0-9]","");if(digits.length()>=8)return "https://wa.me/"+digits;if(v.startsWith("www.")||v.contains("."))return "https://"+v;return "";}

    private void renderSocial(LinearLayout root,TextView status,JSONArray a){
        status.setText("");
        int count=0;
        if(a!=null) for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String platform=x.optString("platform","").trim();String url=x.optString("url","").trim();if(platform.isEmpty()||!FeatureRegistry.isSafeHttpUrl(url))continue;LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(10,4,10,4);ImageView icon=new ImageView(this);icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);icon.setImageResource(platformIconRes(platform));String custom=x.optString("image_url",x.optString("imageUrl","")).trim();String iconUrl=x.optString("icon_url",x.optString("iconUrl","")).trim();if(!custom.isEmpty())loadImageUrl(icon,custom);else if(!iconUrl.isEmpty())loadImageUrl(icon,iconUrl);row.addView(icon,new LinearLayout.LayoutParams(48,48));LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);TextView name=new TextView(this);name.setText(platform);name.setTextSize(14);name.setTextColor(Color.rgb(24,29,62));name.setTypeface(Typeface.DEFAULT,Typeface.BOLD);TextView domain=new TextView(this);domain.setText(url);domain.setTextSize(9);domain.setTextColor(Color.rgb(105,111,130));box.addView(name);box.addView(domain);row.addView(box,new LinearLayout.LayoutParams(0,56,1));row.setOnClickListener(v->openUrl(url));icon.setContentDescription(platform+" icon");root.addView(row,new LinearLayout.LayoutParams(-1,64));count++;}
        if(count==0) status.setText("No social links have been saved by Admin yet.");
    }
    private String normalizePlatformTarget(String platform,String raw){
        String v=raw==null?"":raw.trim(); if(v.isEmpty())return "";
        if(v.startsWith("http://")||v.startsWith("https://"))return v;
        String digits=v.replaceAll("[^0-9]","");
        if(digits.length()<8)return "";
        if(platform.equalsIgnoreCase("WhatsApp"))return "https://wa.me/"+digits;
        if(platform.equalsIgnoreCase("imo"))return "tel:"+digits;
        return "";
    }
    private String normalizeWhatsApp(String raw){return normalizePlatformTarget("WhatsApp",raw);}
    private Button actionButton(String label,int color){Button b=new Button(this);b.setText(label);b.setTextSize(13);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setGravity(Gravity.CENTER);b.setPadding(dp(12),0,dp(12),0);b.setBackground(roundedBg(color,0,14));b.setElevation(dp(2));applyRipple(b);return b;}

    private void loadSocialIcon(ImageView target,String url,String platform){Executors.newSingleThreadExecutor().execute(()->{try{String host=new URL(url).getHost();if(host==null||host.isEmpty())throw new Exception("no host");String iconUrl="https://www.google.com/s2/favicons?sz=128&domain_url="+java.net.URLEncoder.encode("https://"+host,"UTF-8");HttpURLConnection c=(HttpURLConnection)new URL(iconUrl).openConnection();c.setConnectTimeout(6000);c.setReadTimeout(8000);c.setInstanceFollowRedirects(true);try(InputStream in=c.getInputStream()){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null)runOnUiThread(()->target.setImageBitmap(b));}}catch(Exception ignored){}});}
    private String socialIcon(String p){String s=p.toLowerCase();if(s.contains("facebook"))return "ⓕ";if(s.contains("youtube"))return "▶";if(s.contains("tiktok"))return "♪";if(s.contains("instagram"))return "◎";if(s.contains("whatsapp"))return "◉";if(s.contains("telegram"))return "✈";return "●";}

    private void loadImageUrl(ImageView target,String value){Executors.newSingleThreadExecutor().execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(value).openConnection();c.setConnectTimeout(6000);c.setReadTimeout(8000);try(InputStream in=c.getInputStream()){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null)runOnUiThread(()->target.setImageBitmap(b));}c.disconnect();}catch(Exception ignored){}});}

    private void openUrl(String value) {
        if(needsPublishedCheck()){FeatureAccess.open(this,currentFeatureKey,()->openAllowedUrl(value));return;}
        openAllowedUrl(value);
    }
    private void openAllowedUrl(String value) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(value.trim())));
        } catch (Exception e) {
            Toast.makeText(this, "Unable to open link.", Toast.LENGTH_SHORT).show();
        }
    }
}
