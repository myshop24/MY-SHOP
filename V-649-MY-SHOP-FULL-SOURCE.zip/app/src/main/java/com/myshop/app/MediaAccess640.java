package com.myshop.app;
/** Send session credentials only to the configured first-party media endpoint. */
final class MediaAccess640 {
 static java.util.Map<String,String> headers(android.content.Context c,String url){java.util.HashMap<String,String> headers=new java.util.HashMap<>();try{java.net.URI target=new java.net.URI(url),base=new java.net.URI(BuildConfig.MYSHOP_BACKEND_URL);if("https".equals(target.getScheme())&&target.getHost()!=null&&target.getHost().equalsIgnoreCase(base.getHost())&&target.getPort()==base.getPort()&&target.getPath().startsWith("/v1/media/")){String token=SessionManager.getToken(c);if(token!=null&&!token.isEmpty())headers.put("Authorization","Bearer "+token);}}catch(Exception ignored){}return headers;}
 static void authorize(android.content.Context c,java.net.HttpURLConnection connection){java.util.Map<String,String> h=headers(c,connection.getURL().toString());if(!h.isEmpty()){connection.setInstanceFollowRedirects(false);connection.setUseCaches(false);for(java.util.Map.Entry<String,String> entry:h.entrySet())connection.setRequestProperty(entry.getKey(),entry.getValue());}}
 private MediaAccess640(){}
}
