package com.myshop.app;
import android.content.Context;import android.graphics.*;import android.view.View;
/** Metallic bodies plus independently rotating rims, crank and moving energy trails. */
final class ArticulatedRideView extends View {
 private static Bitmap atlas;private static final int[] ROWS={0,320,550,780,1000,1280};
 private static final float[][] WHEELS={{68,250,262,250,53},{67,257,258,257,53},{68,257,261,257,50},{50,283,277,283,30},{51,170,274,170,31},{59,173,270,173,40},{57,180,273,180,39},{63,179,274,179,40},{65,153,265,153,50},{102,166,291,166,30},{78,164,258,164,32},{68,164,255,164,32},{75,155,278,155,32},{78,154,275,154,33},{74,153,267,153,36},{77,150,284,150,38},{76,142,270,142,55}};
 private final int slot;private final Paint p=new Paint(3);private boolean moving=true;
 ArticulatedRideView(Context c,int slot){super(c);this.slot=Math.max(0,Math.min(19,slot));if(atlas==null)try{atlas=BitmapFactory.decodeStream(c.getAssets().open("rides_v606/vehicles.webp"));}catch(Exception ignored){}setContentDescription("Animated ride with moving mechanical parts");}
 void setMoving(boolean value){moving=value;invalidate();}
 private void wheel(Canvas c,float x,float y,float r,float angle){r*=.82f;c.save();c.translate(x,y);c.rotate(angle);p.setStyle(Paint.Style.FILL);p.setShader(new RadialGradient(0,0,r,new int[]{0xffeeeeff,0xff738ca7,0xff121522,0xff020712},new float[]{0,.25f,.78f,1},Shader.TileMode.CLAMP));c.drawCircle(0,0,r,p);p.setShader(null);p.setColor(0xffc4e8ff);p.setStrokeWidth(2);p.setStyle(Paint.Style.STROKE);int spokes=slot<3?20:8;for(int i=0;i<spokes;i++){double a=i*2*Math.PI/spokes;c.drawLine(0,0,(float)Math.cos(a)*r*.75f,(float)Math.sin(a)*r*.75f,p);}c.drawCircle(0,0,r*.8f,p);p.setStyle(Paint.Style.FILL);p.setColor(0xffe8efff);c.drawCircle(0,0,4,p);c.restore();}
 @Override protected void onDraw(Canvas c){if(atlas==null)return;int row=slot/4,col=slot%4,h=ROWS[row+1]-ROWS[row];float scale=Math.min(getWidth()/340f,getHeight()/(float)h),phase=moving?(android.os.SystemClock.uptimeMillis()%1600)/1600f:0;
 c.save();c.translate((getWidth()-320*scale)/2,(getHeight()-h*scale)/2);c.scale(scale,scale);
 p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);for(int i=0;i<5;i++){p.setColor(i%2==0?0xff7cdaff:0xffffcb57);p.setAlpha((int)(100*(1-phase)));float y=h*(.35f+i*.09f);c.drawLine(265+phase*22,y,316,y,p);}p.setAlpha(255);p.setStyle(Paint.Style.FILL);
 float f=atlas.getWidth()/1280f;Rect src=new Rect(Math.round(col*320*f),Math.round(ROWS[row]*f),Math.round((col+1)*320*f),Math.round(ROWS[row+1]*f));c.drawBitmap(atlas,src,new RectF(0,0,320,h),p);
 if(slot<WHEELS.length){float[] w=WHEELS[slot];wheel(c,w[0],w[1],w[4],-phase*360);wheel(c,w[2],w[3],w[4],-phase*360);if(slot<3){c.save();c.translate(165,250);c.rotate(-phase*360);p.setColor(0xffd9eaff);p.setStrokeWidth(5);c.drawLine(-21,0,21,0,p);p.setColor(0xff23293a);c.drawRect(-28,-4,-14,4,p);c.drawRect(14,-4,28,4,p);c.restore();}}
 else{p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(0xff56ddff);p.setAlpha((int)(140+90*Math.sin(phase*6.283)));c.drawOval(new RectF(40,h*.68f,285,h*.88f),p);p.setAlpha(255);}
 c.restore();if(moving&&isShown())postInvalidateOnAnimation();}
}
