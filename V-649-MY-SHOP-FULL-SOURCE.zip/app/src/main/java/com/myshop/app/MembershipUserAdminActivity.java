package com.myshop.app;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.*;
import org.json.*;
import java.util.ArrayList;

/** Exact ID -> select verified profile -> category/product -> grant or remove one entitlement. */
public final class MembershipUserAdminActivity extends androidx.appcompat.app.AppCompatActivity {
    private EditText id,grantDays; private TextView user,status;private ImageView photo;
    private Spinner category,choice;private Button select,grant;private LinearLayout active;
    private final ArrayList<JSONObject> products=new ArrayList<>(),visible=new ArrayList<>();
    private String verifiedId="",selectedId="",verifiedName="";private int generation;private boolean busy;
    private static final String[] TYPES={"MEMBERSHIP","ENTRY_ANIMATION","WALLPAPER","AVATAR_FRAME","COMMENT_STYLE","BADGE","ANIMATED_RING","LIVE_THEME","PROFILE_STYLE","GIFT"};
    @Override protected void onCreate(Bundle state){super.onCreate(state);if(!SessionManager.isAdmin(this)){finish();return;}
        ScrollView sc=new ScrollView(this);LinearLayout root=column();root.setBackgroundColor(0xFFF3F5FC);
        root.setPadding(dp(16),dp(12),dp(16),dp(24));root.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(dp(16),Math.max(dp(12),i.getSystemWindowInsetTop()),dp(16),Math.max(dp(24),i.getSystemWindowInsetBottom()));return i;});
        root.addView(button("‹ User premium control",v->finish()));
        id=new EditText(this);id.setHint("ইউজারের ৪ সংখ্যার ID");id.setInputType(InputType.TYPE_CLASS_NUMBER);id.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(4)});root.addView(id);
        root.addView(button("Search ID",v->search()));
        photo=new ImageView(this);photo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);photo.setImageResource(R.drawable.myshop_profile_avatar);root.addView(photo,new LinearLayout.LayoutParams(-1,dp(88)));
        user=label("ইউজার সার্চ করুন",17);root.addView(user);status=label("",13);root.addView(status);
        select=button("এই ইউজারকে নির্বাচন করুন",v->{selectedId=verifiedId;status.setText("Selected: "+verifiedName+" · "+selectedId);update();});root.addView(select);
        category=new Spinner(this);category.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,TYPES));root.addView(category,new LinearLayout.LayoutParams(-1,dp(52)));
        choice=new Spinner(this);root.addView(choice,new LinearLayout.LayoutParams(-1,dp(56)));
        category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int n,long row){filter();}public void onNothingSelected(AdapterView<?> p){}});
        choice.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int n,long row){if(grantDays!=null&&n>=0&&n<visible.size())grantDays.setText(String.valueOf(visible.get(n).optInt("duration_days",30)));update();}public void onNothingSelected(AdapterView<?> p){}});
        grantDays=new EditText(this);grantDays.setHint("Membership duration · days (1–3650)");grantDays.setInputType(InputType.TYPE_CLASS_NUMBER);grantDays.setText("30");root.addView(grantDays);
        grant=button("Select product · Approve / Grant",v->confirmGrant());root.addView(grant);
        root.addView(label("সরাসরি Admin Grant করলে ইউজারের কয়েন কাটবে না। ক্রয়ের রিকোয়েস্ট Purchase requests পৃষ্ঠায় দেখুন।",13));
        root.addView(label("এই ইউজারের সক্রিয় ফিচার",18));active=column();root.addView(active);sc.addView(root);setContentView(sc);root.post(root::requestApplyInsets);
        id.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int count,int after){}public void onTextChanged(CharSequence s,int st,int before,int count){generation++;verifiedId="";selectedId="";user.setText("ইউজার সার্চ করুন");photo.setImageResource(R.drawable.myshop_profile_avatar);active.removeAllViews();update();}public void afterTextChanged(android.text.Editable e){}});
        update();loadCatalog();
    }
    private void loadCatalog(){BackendClient.adminStoreCatalog(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){products.clear();JSONArray a=d.optJSONArray("catalog");if(a!=null)for(int n=0;n<a.length();n++){JSONObject x=a.optJSONObject(n);if(x!=null&&x.optInt("enabled",0)==1)products.add(x);}filter();}public void onError(String m){status.setText(m);}});}
    private void filter(){if(choice==null)return;String type=String.valueOf(category.getSelectedItem());visible.clear();ArrayList<String> names=new ArrayList<>();for(JSONObject x:products)if(type.equals(x.optString("item_type"))){visible.add(x);names.add(x.optString("title")+" · "+x.optInt("duration_days",30)+" days");}choice.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));update();}
    private void update(){if(grantDays!=null)grantDays.setVisibility("MEMBERSHIP".equals(String.valueOf(category.getSelectedItem()))?View.VISIBLE:View.GONE);if(select!=null)select.setEnabled(!busy&&!verifiedId.isEmpty());if(grant!=null)grant.setEnabled(!busy&&!selectedId.isEmpty()&&selectedId.equals(id.getText().toString())&&choice.getSelectedItemPosition()>=0&&choice.getSelectedItemPosition()<visible.size());}
    private void search(){String uid=id.getText().toString().trim();if(!uid.matches("[0-9]{4}")){status.setText("সঠিক ৪ সংখ্যার ID দিন।");return;}final int ticket=++generation;verifiedId="";selectedId="";active.removeAllViews();status.setText("ইউজার যাচাই হচ্ছে…");update();
        BackendClient.adminWalletPreview(SessionManager.getToken(this),uid,new BackendClient.Callback(){public void onSuccess(JSONObject d){if(ticket!=generation||isFinishing())return;JSONObject u=d.optJSONObject("user");if(u==null||!uid.equals(u.optString("userId"))){status.setText("User verification failed.");return;}verifiedId=uid;verifiedName=u.optString("name");user.setText(verifiedName+" · ID "+uid);photo.setImageResource(R.drawable.myshop_profile_avatar);String url=u.optString("avatarUrl");if(!url.isEmpty())AnimatedAssetLoader.load(photo,url,false);status.setText("নাম ও ছবি দেখে ইউজার নির্বাচন করুন।");renderActive(d.optJSONArray("activePremiumItems"));update();}public void onError(String m){if(ticket==generation){status.setText(m);update();}}});
    }
    private void confirmGrant(){int pos=choice.getSelectedItemPosition();if(selectedId.isEmpty()||pos<0||pos>=visible.size())return;final JSONObject product=visible.get(pos);final String uid=selectedId;final boolean membership="MEMBERSHIP".equals(product.optString("item_type"));final int duration;try{duration=membership?Integer.parseInt(grantDays.getText().toString().trim()):product.optInt("duration_days",30);if(duration<1||duration>3650)throw new IllegalArgumentException();}catch(Exception e){status.setText("Duration must be 1–3650 days.");return;}
        new MyShopDialogBuilder(this).setTitle("Confirm Admin Grant").setMessage(verifiedName+" · ID "+uid+"\n"+product.optString("title")+" · "+duration+" days\n\nঅনুমোদন করলে ফিচার চালু হবে। কয়েন কাটবে না।").setNegativeButton(UiStrings.label(MembershipUserAdminActivity.this,"Cancel"),null).setPositiveButton("APPROVE",(d,w)->{busy=true;update();if(membership)BackendClient.adminMembershipGrant(SessionManager.getToken(this),uid,product.optLong("id"),duration,callback(uid,"ফিচার চালু হয়েছে।"));else BackendClient.adminStoreGrant(SessionManager.getToken(this),uid,product.optLong("id"),"Verified ID direct grant",callback(uid,"ফিচার চালু হয়েছে।"));}).show();
    }
    private void renderActive(JSONArray items){active.removeAllViews();if(items==null||items.length()==0){active.addView(label("কোনো সক্রিয় ফিচার নেই।",14));return;}for(int n=0;n<items.length();n++){JSONObject item=items.optJSONObject(n);if(item==null)continue;LinearLayout card=column();card.setPadding(dp(12),dp(8),dp(12),dp(8));card.setBackground(PremiumUi.solid(this,Color.WHITE,14,0xFFC9C7F0,1));card.addView(label(item.optString("title",item.optString("item_code")),16));card.addView(label(item.optString("item_type")+" · "+(item.optInt("equipped")==1?"In use":"Owned")+"\nExpiry: "+item.optString("expires_at","No expiry"),12));card.addView(button("Remove from this user",v->confirmRemove(item)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(8);active.addView(card,p);}}
    private void confirmRemove(JSONObject item){if(busy||selectedId.isEmpty()||!selectedId.equals(verifiedId)){status.setText("আগে উপরের যাচাইকৃত ইউজার নির্বাচন করুন।");return;}final String uid=selectedId;
        new MyShopDialogBuilder(this).setTitle("Remove this feature?").setMessage(verifiedName+" · ID "+uid+"\n"+item.optString("title",item.optString("item_code"))+"\n\nশুধু এই ইউজারের ফিচার সরবে; ক্যাটালগে পণ্য থাকবে।").setNegativeButton(UiStrings.label(MembershipUserAdminActivity.this,"Cancel"),null).setPositiveButton("REMOVE",(d,w)->{busy=true;update();BackendClient.adminStoreRevoke(SessionManager.getToken(this),uid,item.optLong("id"),item.optString("entitlement_kind"),callback(uid,"ফিচার সরানো হয়েছে।"));}).show();
    }
    private BackendClient.Callback callback(String uid,String message){return new BackendClient.Callback(){public void onSuccess(JSONObject d){busy=false;Toast.makeText(MembershipUserAdminActivity.this,message,Toast.LENGTH_LONG).show();if(uid.equals(id.getText().toString().trim()))search();else update();}public void onError(String m){busy=false;status.setText(m);update();}};}
    private Button button(String s,View.OnClickListener listener){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(14);b.setPadding(dp(10),dp(10),dp(10),dp(10));b.setMinHeight(dp(48));b.setBackground(PremiumUi.solid(this,0xFF6557CB,12,Color.TRANSPARENT,0));b.setOnClickListener(listener);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(5),0,dp(5));b.setLayoutParams(p);return b;}
    private TextView label(String s,float size){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(0xFF253354);v.setPadding(0,dp(7),0,dp(7));return v;}
    private LinearLayout column(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
}
