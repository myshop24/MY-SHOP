package com.myshop.app;

/** Pixel-independent dashboard budget, shared with the layout regression test. */
public final class Home2Metrics {
    public final int widthDp,bannerHeightDp;
    public Home2Metrics(int screenWidthDp){widthDp=Math.max(200,screenWidthDp-24);bannerHeightDp=Math.round(widthDp/2.5f);}
    public int itemWidthDp(int visible,int gap){if(visible<1||gap<0)throw new IllegalArgumentException("Invalid row");return Math.max(1,(widthDp-gap*(visible-1))/visible);}
    public int bodyHeightDp(){return bannerHeightDp+44+70+22+52+22+48+48+22+76+22+58+42;}
}
