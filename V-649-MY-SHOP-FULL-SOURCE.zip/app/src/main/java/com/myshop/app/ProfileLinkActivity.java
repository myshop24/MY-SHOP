package com.myshop.app;
import android.app.Activity;import android.os.Bundle;import android.content.Intent;import android.net.Uri;import android.widget.Toast;
/** Keeps the shared profile identity through authentication. */
public final class ProfileLinkActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b);Uri u=getIntent().getData();String id=u==null?null:u.getQueryParameter("userId");if(id==null||!id.matches("[0-9]{4}")){Toast.makeText(this,"প্রোফাইল লিংক সঠিক নয়",Toast.LENGTH_LONG).show();finish();return;}if(!SessionManager.hasUsableSession(this)){getSharedPreferences("pending_profile_link",MODE_PRIVATE).edit().putString("userId",id).apply();startActivity(new Intent(this,LoginActivity.class));}else open(this,id);finish();}
 static void resumePending(Activity a){android.content.SharedPreferences p=a.getSharedPreferences("pending_profile_link",MODE_PRIVATE);String id=p.getString("userId","");if(id.matches("[0-9]{4}")&&SessionManager.hasUsableSession(a)){p.edit().clear().apply();open(a,id);}}
 private static void open(Activity a,String id){a.startActivity(new Intent(a,UserProfileActivity.class).putExtra("userId",id));}
}
