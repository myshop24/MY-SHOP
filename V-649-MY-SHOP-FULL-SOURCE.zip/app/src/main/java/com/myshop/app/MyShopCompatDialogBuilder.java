package com.myshop.app;
public class MyShopCompatDialogBuilder extends androidx.appcompat.app.AlertDialog.Builder {
 public MyShopCompatDialogBuilder(android.content.Context c){super(c);}
 @Override public androidx.appcompat.app.AlertDialog create(){androidx.appcompat.app.AlertDialog d=super.create();if(d.getWindow()!=null)d.getWindow().getDecorView().getViewTreeObserver().addOnGlobalLayoutListener(()->{Appearance.dialog(d);d.getWindow().getDecorView().setLayoutDirection(LanguageManager.AR.equals(LanguageManager.get(getContext()))?android.view.View.LAYOUT_DIRECTION_RTL:android.view.View.LAYOUT_DIRECTION_LTR);});return d;}
 @Override public androidx.appcompat.app.AlertDialog show(){androidx.appcompat.app.AlertDialog d=super.show();Appearance.dialog(d);return d;}
}
