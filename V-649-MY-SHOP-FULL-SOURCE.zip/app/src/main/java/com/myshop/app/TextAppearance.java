package com.myshop.app;
import android.app.Activity;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.*;
import android.text.style.ForegroundColorSpan;
import android.widget.TextView;
import org.json.*;
import java.util.*;
/** Appearance only, opt-in on non-Live screens; keeps existing layout and text. */
final class TextAppearance {
 static boolean owner(Activity a){return SessionManager.isAdmin(a)&&AuthorityBadge.isAuthority(SessionManager.getUserId(a));}
 static boolean allowed(Activity a,String kind){return owner(a)||a.getSharedPreferences("appearance593_"+SessionManager.getUserId(a),0).getBoolean(kind,false);}
 private static final class Ink extends ForegroundColorSpan{Ink(int c){super(c);}}
 private static final class Original{final Drawable bg;final int color;final float size;final Shader shader;final Typeface face;final int gravity;Original(TextView t){face=t.getTypeface();gravity=t.getGravity();bg=t.getBackground();color=t.getCurrentTextColor();size=t.getTextSize();shader=t.getPaint().getShader();}}
 
 static void forget(TextView t){t.setTag(R.id.appearance593_original,null);}
 private static int color(JSONObject s,String key,int fallback){try{return Color.parseColor(s.optString(key));}catch(Exception e){return fallback;}}
 static void paint(TextView t,JSONObject s){
  Original base=(Original)t.getTag(R.id.appearance593_original);if(base==null){base=new Original(t);t.setTag(R.id.appearance593_original,base);}t.setBackground(base.bg);t.setTextColor(base.color);t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX,base.size);t.getPaint().setShader(base.shader);t.setTypeface(base.face);t.setGravity(base.gravity);
  SpannableString text=new SpannableString(t.getText());for(Ink ink:text.getSpans(0,text.length(),Ink.class))text.removeSpan(ink);
  if(s==null){t.setText(text);return;}
  if(s.has("background")){GradientDrawable bg=new GradientDrawable();if(s.has("backgroundEnd"))bg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{color(s,"background",Color.TRANSPARENT),color(s,"backgroundEnd",Color.TRANSPARENT)});else bg.setColor(color(s,"background",Color.TRANSPARENT));bg.setCornerRadius(6*t.getResources().getDisplayMetrics().density);t.setBackground(bg);}
  if(s.has("bold"))t.setTypeface(base.face,s.optBoolean("bold")?Typeface.BOLD:Typeface.NORMAL);if(s.has("align")){String align=s.optString("align");t.setGravity((base.gravity&android.view.Gravity.VERTICAL_GRAVITY_MASK)|("CENTER".equals(align)?android.view.Gravity.CENTER_HORIZONTAL:"END".equals(align)?android.view.Gravity.END:android.view.Gravity.START));}
  if(s.has("fontSize"))t.setTextSize((float)s.optDouble("fontSize",14));
  if(s.has("text")){String word=s.optString("word");if(word.isEmpty())range(text,0,text.length(),s,base.color);else{String source=text.toString();for(int start=source.indexOf(word);start>=0;start=source.indexOf(word,start+word.length()))range(text,TextBoundaries.start(source,start),TextBoundaries.end(source,start+word.length()),s,base.color);}}
  JSONArray parts=s.optJSONArray("segments");if(parts!=null)for(int i=0;i<parts.length();i++){JSONObject p=parts.optJSONObject(i);if(p==null||!matches(text.toString(),p))continue;int start=p.optInt("start"),end=p.optInt("end");if(start>=0&&end>start&&end<=text.length()&&TextBoundaries.valid(text.toString(),start)&&TextBoundaries.valid(text.toString(),end))range(text,start,end,p,base.color);}
  t.setText(text);t.invalidate();
 }
 private static boolean matches(String current,JSONObject s){String source=s.optString("source",null);if(source!=null)return current.equals(source)||current.startsWith(source)&&current.substring(source.length()).matches("(?: ✎)?(?: ✓)?(?:  LV\\.\\d+)?");try{int n=s.optInt("sourceLength",current.length());if(n>current.length())return false;String value=current.substring(0,n);if(n!=current.length()&&!current.substring(n).matches("(?: ✎)?(?: ✓)?(?:  LV\\.\\d+)?"))return false;byte[] hash=java.security.MessageDigest.getInstance("SHA-256").digest(value.getBytes(java.nio.charset.StandardCharsets.UTF_8));StringBuilder hex=new StringBuilder();for(byte b:hash)hex.append(String.format(java.util.Locale.US,"%02x",b&255));return hex.toString().equals(s.optString("sourceHash"));}catch(Exception e){return false;}}
 private static void range(SpannableString text,int start,int end,JSONObject s,int fallback){if(end<=start||!s.has("text"))return;int first=color(s,"text",fallback),last=color(s,"textEnd",first);if(!s.has("textEnd")){text.setSpan(new Ink(first),start,end,Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);return;}ArrayList<Integer> points=new ArrayList<>();points.add(start);for(int i=start+1;i<end;i++)if(TextBoundaries.valid(text.toString(),i))points.add(i);points.add(end);for(int i=0;i<points.size()-1;i++){float f=points.size()>2?(float)i/(points.size()-2):0;int c=Color.rgb(Math.round(Color.red(first)+(Color.red(last)-Color.red(first))*f),Math.round(Color.green(first)+(Color.green(last)-Color.green(first))*f),Math.round(Color.blue(first)+(Color.blue(last)-Color.blue(first))*f));text.setSpan(new Ink(c),points.get(i),points.get(i+1),Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}}
 private static final class Binding{JSONObject style;boolean painting;}
 
 private static void attach(TextView label,JSONObject style){Binding state=(Binding)label.getTag(R.id.appearance593_binding);if(state==null&&style==null)return;if(state==null){state=new Binding();label.setTag(R.id.appearance593_binding,state);final Binding saved=state;label.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){}public void afterTextChanged(Editable e){if(saved.painting)return;saved.painting=true;paint(label,saved.style);saved.painting=false;}});}state.style=style;state.painting=true;paint(label,style);state.painting=false;}
 private static final class RequestState{JSONObject data;long time;boolean loading;final ArrayList<LinkedHashMap<String,TextView>> waiting=new ArrayList<>();}
 private static final Map<Activity,Map<String,RequestState>> requests=new WeakHashMap<>();
 private static void apply(Activity a,LinkedHashMap<String,TextView> labels,JSONObject d){JSONObject styles=d.optJSONObject("styles");for(Map.Entry<String,TextView> label:labels.entrySet())attach(label.getValue(),styles==null?null:styles.optJSONObject(label.getKey()));JSONObject grants=d.optJSONObject("permissions");if(grants!=null)a.getSharedPreferences("appearance593_"+SessionManager.getUserId(a),0).edit().putBoolean("identity",grants.optBoolean("identity")).putBoolean("status",grants.optBoolean("status")).apply();}
 static void invalidate(Activity a,String target){Map<String,RequestState> map=requests.get(a);if(map!=null)map.remove(SessionManager.getUserId(a)+":"+target);}
 static void bind(Activity a,String target,LinkedHashMap<String,TextView> labels){
  if(a instanceof AudioLiveRoomActivity||a instanceof LiveHomeActivity)return;
  Map<String,RequestState> map=requests.get(a);if(map==null){map=new HashMap<>();requests.put(a,map);}String key=SessionManager.getUserId(a)+":"+target;RequestState state=map.get(key);if(state==null){state=new RequestState();map.put(key,state);}if(state.data!=null&&System.currentTimeMillis()-state.time<30000){apply(a,labels,state.data);return;}state.waiting.add(labels);if(state.loading)return;state.loading=true;final RequestState pending=state;final String actor=SessionManager.getUserId(a);
  BackendClient.appearance(SessionManager.getToken(a),target,false,new BackendClient.Callback(){public void onSuccess(JSONObject d){a.runOnUiThread(()->{pending.loading=false;if(a.isFinishing()||a.isDestroyed()||!actor.equals(SessionManager.getUserId(a))){pending.waiting.clear();return;}try{JSONObject data=new JSONObject().put("styles",d.optJSONObject("styles"));if(d.has("permissions"))data.put("permissions",d.optJSONObject("permissions"));pending.data=data;pending.time=System.currentTimeMillis();for(LinkedHashMap<String,TextView> fields:pending.waiting)apply(a,fields,data);}catch(Exception ignored){}pending.waiting.clear();});}public void onError(String m){a.runOnUiThread(()->{pending.loading=false;pending.waiting.clear();});}});
 }
 static LinkedHashMap<String,TextView> labels(String key,TextView label){LinkedHashMap<String,TextView> map=new LinkedHashMap<>();map.put(key,label);return map;}
 private TextAppearance(){}
}
