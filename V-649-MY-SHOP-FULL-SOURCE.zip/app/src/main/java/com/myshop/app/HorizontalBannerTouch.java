package com.myshop.app;

import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

/** A manual horizontal swipe must not become a click or be stolen by vertical scroll. */
public final class HorizontalBannerTouch implements View.OnTouchListener {
    public interface Actions { void swipe(boolean next); void tap(); void hold(); default void touching(boolean active){} default void drag(float dx){} default void settle(){} }
    private final Actions actions; private final Handler handler=new Handler(Looper.getMainLooper());
    private final float slop,threshold; private float x,y; private boolean moved,held,vertical;
    private final Runnable hold;
    public HorizontalBannerTouch(View v,Actions a){actions=a;slop=ViewConfiguration.get(v.getContext()).getScaledTouchSlop();threshold=28*v.getResources().getDisplayMetrics().density;hold=()->{if(!moved&&!vertical){held=true;actions.hold();}};v.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View w){}public void onViewDetachedFromWindow(View w){handler.removeCallbacksAndMessages(null);}});}
    @Override public boolean onTouch(View v,MotionEvent e){switch(e.getActionMasked()){
        case MotionEvent.ACTION_DOWN:actions.touching(true);x=e.getX();y=e.getY();moved=held=vertical=false;if(v.getParent()!=null)v.getParent().requestDisallowInterceptTouchEvent(true);handler.postDelayed(hold,ViewConfiguration.getLongPressTimeout());return true;
        case MotionEvent.ACTION_MOVE:{float dx=e.getX()-x,dy=e.getY()-y;if(Math.abs(dx)>slop||Math.abs(dy)>slop){moved=true;handler.removeCallbacks(hold);vertical=Math.abs(dy)>Math.abs(dx);if(v.getParent()!=null)v.getParent().requestDisallowInterceptTouchEvent(!vertical);}if(moved&&!vertical&&!held)actions.drag(dx);else if(vertical)actions.settle();return true;}
        case MotionEvent.ACTION_UP:handler.removeCallbacks(hold);actions.touching(false);if(v.getParent()!=null)v.getParent().requestDisallowInterceptTouchEvent(false);if(!held&&!vertical){float dx=e.getX()-x;if(Math.abs(dx)>threshold)actions.swipe(dx<0);else if(!moved){v.performClick();actions.tap();}else actions.settle();}else actions.settle();return true;
        case MotionEvent.ACTION_CANCEL:actions.settle();handler.removeCallbacks(hold);actions.touching(false);if(v.getParent()!=null)v.getParent().requestDisallowInterceptTouchEvent(false);return true;
        default:return true;
    }}
}
