package com.myshop.app;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

/** Admin sees the shared audit stream; a moderator sees only actions they performed. */
public final class AdminModerationHistoryActivity extends androidx.appcompat.app.AppCompatActivity {
    private LinearLayout rows;
    private TextView status;
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView label(String value,int size,int color,boolean bold){TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(color);if(bold)v.setTypeface(null,android.graphics.Typeface.BOLD);return v;}
    @Override protected void onCreate(Bundle state){super.onCreate(state);if(!SessionManager.isAdmin(this)&&!SessionManager.isModerator(this)){finish();return;}ScrollView scroll=new ScrollView(this);LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(16),dp(20),dp(16),dp(24));page.setBackgroundColor(0xfff4f6fb);scroll.addView(page);TextView title=label("ADMIN • MODERATOR HISTORY",20,0xff17223f,true);page.addView(title);status=label("ইতিহাস লোড হচ্ছে…",12,0xff66718b,false);page.addView(status);rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);page.addView(rows);setContentView(scroll);load();}
    private void load(){BackendClient.moderationAudit(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->render(d.optJSONArray("audit"),d.optString("scope")));}public void onError(String e){runOnUiThread(()->status.setText("ইতিহাস লোড হয়নি • "+e));}});}
    private void render(JSONArray data,String scope){rows.removeAllViews();status.setText("ALL".equals(scope)?"সব Admin / Moderator সিদ্ধান্ত • নতুন থেকে পুরোনো":"আপনার করা moderator action-গুলো • নতুন থেকে পুরোনো");if(data==null||data.length()==0){rows.addView(label("এখনো কোনো action history নেই।",13,0xff66718b,false));return;}for(int i=0;i<data.length();i++){JSONObject a=data.optJSONObject(i);if(a==null)continue;LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(12),dp(14),dp(12));GradientDrawable bg=new GradientDrawable();bg.setColor(Color.WHITE);bg.setCornerRadius(dp(14));bg.setStroke(dp(1),0xffdfe4ee);card.setBackground(bg);TextView action=label(a.optString("action","Action").replace('_',' '),14,0xff223a80,true);card.addView(action);card.addView(label("কে করেছেন: "+a.optString("actor_id","—")+"    •    কাকে: "+a.optString("target_id","—"),11,0xff515d78,false));String host=a.optString("host_id","");if(!host.isEmpty())card.addView(label("লাইভ host: "+host,10,0xff737d92,false));String reason=a.optString("reason","");if(!reason.isEmpty())card.addView(label("কারণ: "+reason,11,0xff515d78,false));card.addView(label(a.optString("created_at","সময় পাওয়া যায়নি"),10,0xff737d92,false));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(8);rows.addView(card,p);}}
}
