package com.myshop.app;
import android.graphics.*;import android.widget.ImageView;
/** Brand marks retained from the owner's payment reference, without redrawing. */
final class PaymentLogos {
 private static Bitmap source;private static final Bitmap[] logos=new Bitmap[3];
 static synchronized void apply(ImageView image,int method){if(source==null)source=BitmapFactory.decodeResource(image.getResources(),R.drawable.payment_reference570);int[] y={778,871,965};if(logos[method]==null){float sx=source.getWidth()/699f,sy=source.getHeight()/1536f;logos[method]=Bitmap.createBitmap(source,Math.round(54*sx),Math.round(y[method]*sy),Math.round(62*sx),Math.round(62*sy));}image.setImageBitmap(logos[method]);image.setScaleType(ImageView.ScaleType.FIT_CENTER);}
 private PaymentLogos(){}
}
