package com.myshop.app;
/** Absolute target times; changing cards never resets a countdown. */
public final class UpcomingClock {
 private UpcomingClock(){}
 public static long secondsLeft(long target,long serverNow,long elapsedSinceSync){long now=serverNow+Math.max(0,elapsedSinceSync);long left=Math.max(0,target-now);return left/1000+(left%1000==0?0:1);}
 public static String hours(long seconds){return String.format(java.util.Locale.US,"%02d",seconds/3600);}
 public static String minutes(long seconds){return String.format(java.util.Locale.US,"%02d",seconds/60%60);}
 public static String seconds(long seconds){return String.format(java.util.Locale.US,"%02d",seconds%60);}
}
