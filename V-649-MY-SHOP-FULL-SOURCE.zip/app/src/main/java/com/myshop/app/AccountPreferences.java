package com.myshop.app;
/** Private account state must never be reused by a different login on the same phone. */
public final class AccountPreferences {private AccountPreferences(){}public static android.content.SharedPreferences get(android.content.Context c,String family){String uid=SessionManager.getUserId(c);return c.getSharedPreferences("myshop_account_"+(uid==null?"none":uid)+"_"+family,0);}}
