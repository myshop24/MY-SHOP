package com.myshop.app;

import java.util.Locale;

/** myshop V-381 built-in fallback artwork + original instrumental cues for the 20+20 gift pack. */
final class GiftBuiltIns {
    private GiftBuiltIns() {}
    private static String key(String name){ return name==null?"":name.trim().toLowerCase(Locale.US); }

    static int art(String name){
        switch(key(name)){
            case "red rose": return R.drawable.gift_v381_red_rose;
            case "heart pop": return R.drawable.gift_v381_heart_pop;
            case "love letter": return R.drawable.gift_v381_love_letter;
            case "teddy bear": return R.drawable.gift_v381_teddy_bear;
            case "chocolate box": return R.drawable.gift_v381_chocolate_box;
            case "flower bouquet": return R.drawable.gift_v381_flower_bouquet;
            case "balloon blast": return R.drawable.gift_v381_balloon_blast;
            case "coffee cup": return R.drawable.gift_v381_coffee_cup;
            case "cute ring": return R.drawable.gift_v381_cute_ring;
            case "butterfly": return R.drawable.gift_v381_butterfly;
            case "sparkle star": return R.drawable.gift_v381_sparkle_star;
            case "rainbow": return R.drawable.gift_v381_rainbow;
            case "cute cake": return R.drawable.gift_v381_cute_cake;
            case "ice cream": return R.drawable.gift_v381_ice_cream;
            case "perfume": return R.drawable.gift_v381_perfume;
            case "guitar tune": return R.drawable.gift_v381_guitar_tune;
            case "magic wand": return R.drawable.gift_v381_magic_wand;
            case "firecracker": return R.drawable.gift_v381_firecracker;
            case "moon light": return R.drawable.gift_v381_moon_light;
            case "party popper": return R.drawable.gift_v381_party_popper;
            case "red rose royal": return R.drawable.gift_v381_red_rose_royal;
            case "diamond ring": return R.drawable.gift_v381_diamond_ring;
            case "golden crown": return R.drawable.gift_v381_golden_crown;
            case "royal throne": return R.drawable.gift_v381_royal_throne;
            case "luxury car": return R.drawable.gift_v381_luxury_car;
            case "super bike": return R.drawable.gift_v381_super_bike;
            case "private jet": return R.drawable.gift_v381_private_jet;
            case "yacht": return R.drawable.gift_v381_yacht;
            case "treasure chest": return R.drawable.gift_v381_treasure_chest;
            case "diamond rain": return R.drawable.gift_v381_diamond_rain;
            case "fireworks show": return R.drawable.gift_v381_fireworks_show;
            case "golden dragon": return R.drawable.gift_v381_golden_dragon;
            case "palace": return R.drawable.gift_v381_palace;
            case "phoenix fire": return R.drawable.gift_v381_phoenix_fire;
            case "angel wings": return R.drawable.gift_v381_angel_wings;
            case "galaxy love": return R.drawable.gift_v381_galaxy_love;
            case "golden peacock": return R.drawable.gift_v381_golden_peacock;
            case "lion king": return R.drawable.gift_v381_lion_king;
            case "golden elephant": return R.drawable.gift_v381_golden_elephant;
            case "moon palace": return R.drawable.gift_v381_moon_palace;
            default: return 0;
        }
    }

    static int sound(String name){
        switch(key(name)){
            case "red rose": return R.raw.gift_v381_red_rose_sound;
            case "heart pop": return R.raw.gift_v381_heart_pop_sound;
            case "love letter": return R.raw.gift_v381_love_letter_sound;
            case "teddy bear": return R.raw.gift_v381_teddy_bear_sound;
            case "chocolate box": return R.raw.gift_v381_chocolate_box_sound;
            case "flower bouquet": return R.raw.gift_v381_flower_bouquet_sound;
            case "balloon blast": return R.raw.gift_v381_balloon_blast_sound;
            case "coffee cup": return R.raw.gift_v381_coffee_cup_sound;
            case "cute ring": return R.raw.gift_v381_cute_ring_sound;
            case "butterfly": return R.raw.gift_v381_butterfly_sound;
            case "sparkle star": return R.raw.gift_v381_sparkle_star_sound;
            case "rainbow": return R.raw.gift_v381_rainbow_sound;
            case "cute cake": return R.raw.gift_v381_cute_cake_sound;
            case "ice cream": return R.raw.gift_v381_ice_cream_sound;
            case "perfume": return R.raw.gift_v381_perfume_sound;
            case "guitar tune": return R.raw.gift_v381_guitar_tune_sound;
            case "magic wand": return R.raw.gift_v381_magic_wand_sound;
            case "firecracker": return R.raw.gift_v381_firecracker_sound;
            case "moon light": return R.raw.gift_v381_moon_light_sound;
            case "party popper": return R.raw.gift_v381_party_popper_sound;
            case "red rose royal": return R.raw.gift_v381_red_rose_royal_sound;
            case "diamond ring": return R.raw.gift_v381_diamond_ring_sound;
            case "golden crown": return R.raw.gift_v381_golden_crown_sound;
            case "royal throne": return R.raw.gift_v381_royal_throne_sound;
            case "luxury car": return R.raw.gift_v381_luxury_car_sound;
            case "super bike": return R.raw.gift_v381_super_bike_sound;
            case "private jet": return R.raw.gift_v381_private_jet_sound;
            case "yacht": return R.raw.gift_v381_yacht_sound;
            case "treasure chest": return R.raw.gift_v381_treasure_chest_sound;
            case "diamond rain": return R.raw.gift_v381_diamond_rain_sound;
            case "fireworks show": return R.raw.gift_v381_fireworks_show_sound;
            case "golden dragon": return R.raw.gift_v381_golden_dragon_sound;
            case "palace": return R.raw.gift_v381_palace_sound;
            case "phoenix fire": return R.raw.gift_v381_phoenix_fire_sound;
            case "angel wings": return R.raw.gift_v381_angel_wings_sound;
            case "galaxy love": return R.raw.gift_v381_galaxy_love_sound;
            case "golden peacock": return R.raw.gift_v381_golden_peacock_sound;
            case "lion king": return R.raw.gift_v381_lion_king_sound;
            case "golden elephant": return R.raw.gift_v381_golden_elephant_sound;
            case "moon palace": return R.raw.gift_v381_moon_palace_sound;
            default: return 0;
        }
    }
}
