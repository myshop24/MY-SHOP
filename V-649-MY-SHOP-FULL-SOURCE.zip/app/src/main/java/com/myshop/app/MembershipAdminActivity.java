package com.myshop.app;
/** Dedicated category route. */
public final class MembershipAdminActivity extends AdminStoreActivity {
 @Override protected void onCreate(android.os.Bundle state){getIntent().putExtra("catalog_filter","MEMBERSHIP");super.onCreate(state);}
}
