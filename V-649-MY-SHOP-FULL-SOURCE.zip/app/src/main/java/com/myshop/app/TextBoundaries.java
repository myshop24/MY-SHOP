package com.myshop.app;
/** UTF-16 grapheme boundaries; includes Bengali virama and joining marks. */
final class TextBoundaries {
 static boolean valid(String source,int offset){if(offset==0||offset==source.length())return true;if(offset<0||offset>source.length())return false;android.icu.text.BreakIterator b=android.icu.text.BreakIterator.getCharacterInstance(new java.util.Locale("bn"));b.setText(source);if(!b.isBoundary(offset))return false;int before=source.codePointBefore(offset),after=source.codePointAt(offset),type=Character.getType(after);return before!=0x09cd&&before!=0x200d&&after!=0x200d&&type!=Character.NON_SPACING_MARK&&type!=Character.COMBINING_SPACING_MARK&&type!=Character.ENCLOSING_MARK;}
 static int start(String source,int n){while(n>0&&!valid(source,n))n--;return n;}static int end(String source,int n){while(n<source.length()&&!valid(source,n))n++;return n;}
}
