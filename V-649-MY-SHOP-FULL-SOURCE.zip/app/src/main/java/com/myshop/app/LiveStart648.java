package com.myshop.app;
import org.json.JSONObject;
/** An unselected theme is not an owned item ID. */
final class LiveStart648 {
 static JSONObject body(String title,long theme,String mode,int layout)throws Exception {
  JSONObject b=new JSONObject().put("active",true).put("title",title).put("mode647",mode).put("layout647",layout);
  if(theme>=0)b.put("themeOwnedId",theme);return b;
 }
}
