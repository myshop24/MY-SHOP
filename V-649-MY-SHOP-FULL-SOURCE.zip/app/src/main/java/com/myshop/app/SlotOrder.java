package com.myshop.app;

import java.util.List;

/** Shared, UI-independent insert-at-slot ordering. Other entries shift; never swap. */
public final class SlotOrder {
    private SlotOrder() {}
    public static <T> boolean move(List<T> items, int from, int to) {
        if (items == null || from < 0 || to < 0 || from >= items.size() || to >= items.size()) return false;
        if (from == to) return false;
        T moved = items.remove(from);
        items.add(to, moved);
        return true;
    }
}
