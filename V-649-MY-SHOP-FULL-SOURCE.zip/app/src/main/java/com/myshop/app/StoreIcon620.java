package com.myshop.app;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;

/** Selected crystal design. Shared atlas decoded once; category text remains native/localized. */
final class StoreIcon620 extends Drawable {
 private static Bitmap atlas;
 private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
 private final Rect source;
 StoreIcon620(Context context,int index){
  synchronized(StoreIcon620.class){if(atlas==null){BitmapFactory.Options options=new BitmapFactory.Options();options.inScaled=false;atlas=BitmapFactory.decodeResource(context.getResources(),R.drawable.store_crystal620,options);}}
  int i=Math.max(0,Math.min(8,index));int w=atlas==null?3:atlas.getWidth(),h=atlas==null?3:atlas.getHeight();
  source=new Rect((i%3)*w/3,(i/3)*h/3,((i%3)+1)*w/3,((i/3)+1)*h/3);
 }
 public void draw(Canvas canvas){if(atlas==null)return;Rect b=getBounds();float size=Math.min(b.width(),b.height());RectF dest=new RectF(b.centerX()-size/2,b.centerY()-size/2,b.centerX()+size/2,b.centerY()+size/2);canvas.drawBitmap(atlas,source,dest,paint);}
 public void setAlpha(int alpha){paint.setAlpha(alpha);invalidateSelf();}
 public void setColorFilter(ColorFilter filter){paint.setColorFilter(filter);invalidateSelf();}
 public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
