package com.myshop.app;
import android.content.Context;import android.graphics.Rect;import android.net.Uri;import android.view.View;import android.view.ViewTreeObserver;import android.widget.FrameLayout;import android.widget.ImageView;import android.widget.VideoView;
/** Silent inline MP4/WebM preview. Only visible tiles own a video decoder. */
final class GiftTileMedia621 extends FrameLayout implements ViewTreeObserver.OnScrollChangedListener {
 final ImageView art;private final String video;private VideoView player;private boolean failed;
 GiftTileMedia621(Context c,String poster,String media,String mime){super(c);art=new ImageView(c);art.setScaleType(ImageView.ScaleType.FIT_CENTER);AnimatedAssetLoader.load(art,poster,true);addView(art,new FrameLayout.LayoutParams(-1,-1));String u=media==null?"":media;video=u.startsWith("https://")&&(mime!=null&&mime.startsWith("video/")||u.toLowerCase(java.util.Locale.ROOT).matches(".*\\.(mp4|webm)(\\?.*)?$"))?u:"";}
 protected void onAttachedToWindow(){super.onAttachedToWindow();getViewTreeObserver().addOnScrollChangedListener(this);post(this::update);}
 protected void onDetachedFromWindow(){stop();if(getViewTreeObserver().isAlive())getViewTreeObserver().removeOnScrollChangedListener(this);super.onDetachedFromWindow();}
 protected void onWindowVisibilityChanged(int visibility){super.onWindowVisibilityChanged(visibility);if(visibility!=View.VISIBLE)stop();else post(this::update);}
 public void onScrollChanged(){update();}
 private void update(){if(video.isEmpty()||failed)return;boolean visible=isShown()&&getWindowVisibility()==View.VISIBLE&&getGlobalVisibleRect(new Rect());if(!visible){stop();return;}if(player!=null)return;player=new VideoView(getContext());addView(player,new FrameLayout.LayoutParams(-1,-1));final VideoView current=player;player.setOnPreparedListener(mp->{mp.setVolume(0f,0f);mp.setLooping(true);if(player==current&&isShown())current.start();});player.setOnErrorListener((mp,w,e)->{if(player==current){failed=true;stop();}return true;});player.setVideoURI(Uri.parse(video));player.start();}
 void stop(){if(player!=null){player.stopPlayback();removeView(player);player=null;}}
}
