package com.myshop.app;

import android.content.Context;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;

/** V-323: safely registers this Android install for real FCM push when Firebase CI config is present. */
public final class PushRegistration {
    private PushRegistration() {}
    public static boolean firebaseConfigured(){return BuildConfig.PUSH_CLIENT_CONFIGURED&&BuildConfig.FIREBASE_APP_ID!=null&&!BuildConfig.FIREBASE_APP_ID.isEmpty()&&BuildConfig.FIREBASE_PROJECT_ID!=null&&!BuildConfig.FIREBASE_PROJECT_ID.isEmpty()&&BuildConfig.FIREBASE_SENDER_ID!=null&&!BuildConfig.FIREBASE_SENDER_ID.isEmpty()&&BuildConfig.FIREBASE_API_KEY!=null&&!BuildConfig.FIREBASE_API_KEY.isEmpty();}
    public static void sync(Context c){
        if(c==null)return;
        if(!firebaseConfigured()){c.getSharedPreferences("myshop_push_v349",Context.MODE_PRIVATE).edit().putBoolean("token_registered",false).putString("last_error","Firebase client configuration missing from this APK").apply();return;}
        if(FirebaseApp.getApps(c).isEmpty()){c.getSharedPreferences("myshop_push_v349",Context.MODE_PRIVATE).edit().putBoolean("token_registered",false).putString("last_error","Firebase initialization failed").apply();return;}
        String auth=SessionManager.getToken(c);if(auth==null||auth.trim().isEmpty())return;
        FirebaseMessaging.getInstance().setAutoInitEnabled(true);
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task->{
            if(!task.isSuccessful()||task.getResult()==null||task.getResult().trim().isEmpty()){
                c.getSharedPreferences("myshop_push_v349",Context.MODE_PRIVATE).edit().putBoolean("token_registered",false).putString("last_error","Firebase token unavailable; retry when connected").putLong("last_attempt_at",System.currentTimeMillis()).apply();return;
            }
            if(!auth.equals(SessionManager.getToken(c)))return;
            final String fcmToken=task.getResult();
            BackendClient.registerPushToken(auth,fcmToken,new BackendClient.Callback(){
                public void onSuccess(org.json.JSONObject d){if(!auth.equals(SessionManager.getToken(c))){sync(c);return;}c.getSharedPreferences("myshop_push_v349",Context.MODE_PRIVATE).edit().putBoolean("token_registered",true).putBoolean("server_configured",d.optBoolean("serverConfigured",false)).putBoolean("project_matched",d.optBoolean("projectMatched",false)).putLong("registered_at",System.currentTimeMillis()).putLong("last_attempt_at",System.currentTimeMillis()).putString("token_tail",fcmToken.length()>12?fcmToken.substring(fcmToken.length()-12):fcmToken).putString("last_error",d.optBoolean("serverConfigured",false)?"":"Worker Firebase service account is missing; token saved but device push cannot be delivered").apply();}
                public void onError(String m){c.getSharedPreferences("myshop_push_v349",Context.MODE_PRIVATE).edit().putBoolean("token_registered",false).putLong("last_attempt_at",System.currentTimeMillis()).putString("last_error",String.valueOf(m)).apply();}
            });
        });
    }
}
