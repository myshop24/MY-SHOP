package com.myshop.app;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.*;
import android.widget.*;
import org.json.*;

/** V646: one compact, lifecycle-bound renderer used by preview and published cards. */
final class AnimationCard645 extends FrameLayout {
 private android.animation.ValueAnimator glow;
 private float phase;
 final JSONObject card;
 private final Handler clock=new Handler(Looper.getMainLooper());
 private JSONObject currentItem;
 private LinearLayout row;
 private ArticulatedRideView ride;
 private final Runnable rotate=()->{render();scheduleRotation();};
 static boolean strip(JSONObject c){return java.util.Arrays.asList("ANNOUNCEMENT","GLOBAL_GIFT","LIVE_INVITE","COMING_SOON").contains(c.optString("type"));}
 static int height(JSONObject c){return "MOVING_MIC".equals(c.optString("type"))?88:strip(c)?30:48;}
 static double defaultWidth(JSONObject c){return "MOVING_MIC".equals(c.optString("type"))?.14:strip(c)?.90:.52;}
 AnimationCard645(Context c,JSONObject data){super(c);card=data;setClipChildren(true);setClipToPadding(true);Appearance.preserve(this);setPadding(dp(7),dp(3),dp(7),dp(3));setWillNotDraw(false);render();}
 long catalogId(){return currentItem==null?card.optLong("catalogId"):currentItem.optLong("id",card.optLong("catalogId"));}
 private void render(){
  AnimationArt646.playback(this,false);removeAllViews();ride=null;currentItem=card.optJSONObject("item");JSONArray choices=card.optJSONArray("items");
  if(!"SELECTED".equals(card.optString("catalogMode647"))&&card.optBoolean("rotate",true)&&choices!=null&&choices.length()>0)currentItem=choices.optJSONObject((int)((System.currentTimeMillis()/2400)%choices.length()));
  String type=card.optString("type");boolean slim=strip(card);
  int base=ink("background",0xff182656),end=ink("backgroundEnd",0xff402775);
  if("WINNER_REWARD".equals(type)){base=0xffa85e0c;end=0xffffd54b;}
  GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{base,blend(base,0xff080d25,.63f),end});bg.setCornerRadius(dp(slim?14:10));bg.setStroke(dp(1),blend(end,Color.WHITE,.45f));setBackground("MOVING_MIC".equals(type)?null:bg);
  if("MOVING_MIC".equals(type)){setContentDescription("Moving microphone");return;}
  row=new LinearLayout(getContext());row.setGravity(Gravity.CENTER_VERTICAL);addView(row,new LayoutParams(-1,-1));
  if(currentItem!=null&&"COMMENT_STYLE".equals(type)){ChatBubble611.Skin skin=new ChatBubble611.Skin(getContext(),ChatBubble611.slot(currentItem),0);Bitmap texture=Bitmap.createBitmap(512,96,Bitmap.Config.ARGB_8888);skin.setBounds(0,0,512,96);skin.draw(new Canvas(texture));row.setBackground(new android.graphics.drawable.BitmapDrawable(getResources(),texture));portrait("",28);LinearLayout sample=words();sample.addView(text("myshop • "+currentItem.optString("title"),11,true));sample.addView(text("আসসালামু আলাইকুম ♥",11,false));row.addView(sample,new LinearLayout.LayoutParams(0,-1,1));
  }else if(currentItem!=null&&"RARE_ID".equals(type)){
   LinearLayout words=words();TextView id=text("ID "+currentItem.optString("title"),20,true);id.setTextColor(0xffffe8a0);words.addView(id,new LinearLayout.LayoutParams(-1,0,1));words.addView(text(price(currentItem),10,false));row.addView(words,new LinearLayout.LayoutParams(0,-1,1));TextView arrow=text("›",25,true);row.addView(arrow,new LinearLayout.LayoutParams(dp(16),-1));
  }else{
   if("GLOBAL_GIFT".equals(type)||"WINNER_REWARD".equals(type))portrait(card.optString("avatar"),slim?22:34);
   LinearLayout words=words();String title=card.optString("title"),caption=card.optString("caption");
   if(currentItem!=null&&!slim){title=currentItem.optString("title",title);caption=price(currentItem);}
   TextView heading=text(title,slim?11:12,true);heading.setSingleLine(true);heading.setEllipsize(slim&&card.optBoolean("animation",true)?android.text.TextUtils.TruncateAt.MARQUEE:android.text.TextUtils.TruncateAt.END);heading.setMarqueeRepeatLimit(-1);heading.setSelected(true);words.addView(heading,new LinearLayout.LayoutParams(-1,slim?-1:-2));
   if(!slim&&!caption.isEmpty()){TextView sub=text(caption,10,false);sub.setSingleLine(true);sub.setEllipsize(android.text.TextUtils.TruncateAt.END);words.addView(sub);}
   row.addView(words,new LinearLayout.LayoutParams(0,-1,1));
   if("WINNER_REWARD".equals(type)){TextView win=text("WIN",18,true);win.setTextColor(0xfffff1a0);row.addView(win,new LinearLayout.LayoutParams(dp(43),-1));}
   else if(currentItem!=null)addArt(type,currentItem,slim?24:62);
  }
  setContentDescription(currentItem==null?card.optString("title"):currentItem.optString("title"));
 }
 private LinearLayout words(){LinearLayout v=new LinearLayout(getContext());v.setOrientation(LinearLayout.VERTICAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
 private String price(JSONObject item){if(item.optBoolean("demo647"))return "অফলাইন প্রিভিউ";long gold=item.optLong("gold_price"),coin=item.optLong("coin_price");return gold>0?"Gold "+gold:coin>0?"Coin "+coin:"বিস্তারিত দেখুন";}
 private void portrait(String url,int size){ImageView photo=new ImageView(getContext());photo.setImageResource(R.drawable.myshop_profile_avatar);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);GradientDrawable circle=new GradientDrawable();circle.setShape(GradientDrawable.OVAL);circle.setColor(0xff171c34);photo.setBackground(circle);photo.setClipToOutline(true);if(!url.isEmpty())AnimatedAssetLoader.load(photo,url,false);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(size),dp(size));p.rightMargin=dp(5);row.addView(photo,p);}
 private void addArt(String type,JSONObject item,int width){
  FrameLayout art=new FrameLayout(getContext());row.addView(art,new LinearLayout.LayoutParams(dp(width),-1));
  if("ENTRY_ANIMATION".equals(type)&&RideAssets.slot(item)>=0){ride=new ArticulatedRideView(getContext(),RideAssets.slot(item));art.addView(ride,new LayoutParams(-1,-1));ride.setMoving(card.optBoolean("animation",true));return;}
  if("COMMENT_STYLE".equals(type)){ChatBubble611.Skin skin=new ChatBubble611.Skin(getContext(),ChatBubble611.slot(item),0);Bitmap preview=Bitmap.createBitmap(124,84,Bitmap.Config.ARGB_8888);skin.setBounds(0,0,124,84);skin.draw(new Canvas(preview));art.setBackground(new android.graphics.drawable.BitmapDrawable(getResources(),preview));TextView sample=text("myshop\nHello ♥",7,true);sample.setGravity(Gravity.CENTER);art.addView(sample,new LayoutParams(-1,-1));return;}
  if("AVATAR_FRAME".equals(type)||"MEMBERSHIP".equals(type)){ImageView profile=new ImageView(getContext());profile.setImageResource(R.drawable.myshop_profile_avatar);profile.setScaleType(ImageView.ScaleType.CENTER_CROP);GradientDrawable circle=new GradientDrawable();circle.setShape(GradientDrawable.OVAL);circle.setColor(Color.TRANSPARENT);profile.setBackground(circle);profile.setClipToOutline(true);art.addView(profile,new LayoutParams(dp(26),dp(26),Gravity.CENTER));}
  ImageView image=new ImageView(getContext());image.setScaleType(ImageView.ScaleType.FIT_CENTER);art.addView(image,new LayoutParams(-1,-1));String asset=item.optString("animation_url");if(asset.isEmpty())asset=item.optString("preview_url");String tier=MembershipUi.tier(item.optString("code"));if("MEMBERSHIP".equals(type)&&!tier.isEmpty()&&!asset.startsWith("http")&&!asset.startsWith("asset://"))asset="asset://membership_v603/"+tier.toLowerCase(java.util.Locale.ROOT)+".gif";if(!asset.isEmpty())AnimationArt646.load(image,asset,card.optBoolean("animation",true));
 }
 private int ink(String key,int fallback){try{return Color.parseColor(card.optString(key));}catch(Exception e){return fallback;}}
 private int blend(int a,int b,float f){return Color.rgb((int)(Color.red(a)*(1-f)+Color.red(b)*f),(int)(Color.green(a)*(1-f)+Color.green(b)*f),(int)(Color.blue(a)*(1-f)+Color.blue(b)*f));}
 private TextView text(String s,int size,boolean bold){TextView t=new TextView(getContext());t.setText(s);t.setTextSize(size);t.setTextColor(ink("textColor",Color.WHITE));t.setTypeface(null,bold?Typeface.BOLD:Typeface.NORMAL);t.setGravity(Gravity.CENTER_VERTICAL);t.setIncludeFontPadding(false);return t;}
 int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 private void scheduleRotation(){clock.removeCallbacks(rotate);JSONArray a=card.optJSONArray("items");if(isAttachedToWindow()&&getWindowVisibility()==VISIBLE&&!"SELECTED".equals(card.optString("catalogMode647"))&&card.optBoolean("rotate",true)&&a!=null&&a.length()>1)clock.postDelayed(rotate,2400-System.currentTimeMillis()%2400);}
 @Override protected void onAttachedToWindow(){super.onAttachedToWindow();start();scheduleRotation();}
 private void start(){if(glow!=null||!card.optBoolean("animation",true)||getWindowVisibility()!=VISIBLE)return;glow=android.animation.ValueAnimator.ofFloat(0,1);glow.setDuration(2600);glow.setRepeatCount(-1);glow.addUpdateListener(v->{phase=(Float)v.getAnimatedValue();invalidate();});glow.start();if(ride!=null)ride.setMoving(true);AnimationArt646.playback(this,true);}
 private void stop(){clock.removeCallbacks(rotate);AnimationArt646.playback(this,false);if(glow!=null){glow.cancel();glow=null;}if(ride!=null)ride.setMoving(false);}
 @Override protected void onWindowVisibilityChanged(int v){super.onWindowVisibilityChanged(v);if(card==null)return;if(v==VISIBLE&&isAttachedToWindow()){start();scheduleRotation();}else stop();}
 @Override protected void onDetachedFromWindow(){stop();super.onDetachedFromWindow();}
 @Override protected void dispatchDraw(Canvas c){super.dispatchDraw(c);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);if("MOVING_MIC".equals(card.optString("type"))){drawMic(c,p);return;}if(glow==null)return;float x=(phase*1.6f-.3f)*getWidth();p.setShader(new LinearGradient(x-dp(15),0,x+dp(15),0,new int[]{0x00ffffff,0x65ffffff,0x00ffffff},null,Shader.TileMode.CLAMP));c.drawRoundRect(0,0,getWidth(),getHeight(),dp(12),dp(12),p);p.setShader(null);p.setColor(0xfff5ddff);for(int i=0;i<4;i++){float sx=((phase+i*.27f)%1)*getWidth(),sy=i%2==0?dp(2):getHeight()-dp(2);c.drawCircle(sx,sy,dp(1),p);}}
 private void drawMic(Canvas c,Paint p){float cx=getWidth()/2f,cy=getHeight()*.38f,w=Math.min(getWidth()*.24f,dp(12)),wave=glow==null?0:(float)Math.sin(phase*Math.PI*2);c.save();c.rotate(wave*5,cx,cy);p.setColor(ink("background",0xffb42bff));p.setAlpha(45);c.drawCircle(cx,cy,w*2.6f,p);p.setAlpha(255);p.setShader(new LinearGradient(cx-w,cy-w*2,cx+w,cy+w*2,new int[]{0xff7cf5ff,0xffd44aff},null,Shader.TileMode.CLAMP));c.drawRoundRect(cx-w,cy-w*1.7f,cx+w,cy+w*1.7f,w,w,p);p.setShader(null);p.setStrokeWidth(dp(2));p.setColor(0xffeffaff);for(int i=-2;i<=2;i++)c.drawLine(cx-w*.6f,cy+i*w*.4f,cx+w*.6f,cy+i*w*.4f,p);p.setStyle(Paint.Style.STROKE);c.drawArc(cx-w*1.5f,cy-w,cx+w*1.5f,cy+w*2.3f,0,180,false,p);c.drawLine(cx,cy+w*2.3f,cx,getHeight()*.82f,p);c.drawLine(cx-w, getHeight()*.83f,cx+w,getHeight()*.83f,p);p.setStyle(Paint.Style.FILL);p.setColor(0xff71eeff);c.drawCircle(cx+w*2,cy+w*2+wave*w,w*.22f,p);c.restore();}
}
