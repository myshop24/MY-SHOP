package com.myshop.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import org.json.JSONObject;

/** V-187: Admin-only production diagnostic board. */
public class AdminSystemHealthActivity extends androidx.appcompat.app.AppCompatActivity {
  private TextView out;
  @Override protected void onCreate(Bundle b){super.onCreate(b); if(!SessionManager.isAdmin(this)){finish();return;} build(); PushRegistration.sync(this);load();}
  private void build(){
    LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(14),dp(12),dp(14),dp(18)); root.setBackgroundColor(Color.rgb(246,248,252));
    TextView h=txt("সিস্টেম স্বাস্থ্য / পরীক্ষা",20,true); h.setGravity(Gravity.CENTER); root.addView(h,lp(-1,dp(48)));
    TextView note=txt("এখানেই আসল সমস্যা দেখা যাবে: সক্রিয় Worker, D1, স্কিমা, D1 লেখা, R2 এবং R2 লেখা।",11,false); root.addView(note,lp(-1,dp(50)));
    Button refresh=new Button(this); refresh.setText("আবার পরীক্ষা করুন"); refresh.setOnClickListener(v->load()); root.addView(refresh,lp(-1,dp(46))); Button push=new Button(this);push.setText("SEND TEST DEVICE NOTIFICATION");push.setOnClickListener(v->BackendClient.pushSelfTest(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->Toast.makeText(AdminSystemHealthActivity.this,"FCM accepted • phone receipt is still unverified",Toast.LENGTH_LONG).show());}public void onError(String m){runOnUiThread(()->Toast.makeText(AdminSystemHealthActivity.this,m,Toast.LENGTH_LONG).show());}}));root.addView(push,lp(-1,dp(46)));Button settings=new Button(this);settings.setText("Device notification permission / channels");settings.setOnClickListener(v->NotificationSettings.open(this));root.addView(settings,lp(-1,dp(46)));Button token=new Button(this);token.setText("Retry device token registration");token.setOnClickListener(v->{PushRegistration.sync(this);load();});root.addView(token,lp(-1,dp(46)));
    ScrollView sv=new ScrollView(this); out=txt("পরীক্ষা চলছে…",11,false); out.setPadding(dp(8),dp(10),dp(8),dp(10)); sv.addView(out); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    Button back=new Button(this); back.setText("ফিরে যান"); back.setOnClickListener(v->finish()); root.addView(back,lp(-1,dp(46))); setContentView(root);
  }
  private void load(){BackendClient.pushDiagnostics(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{getSharedPreferences("myshop_push_v349",MODE_PRIVATE).edit().putBoolean("server_configured",d.optBoolean("serverConfigured",false)).putBoolean("project_matched",BuildConfig.FIREBASE_PROJECT_ID.equals(d.optString("serverProject"))).apply();});}public void onError(String m){}});BackendClient.adminSystemHealth(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->out.setText(localPushHealth()+"\n\n"+pretty(d)));}public void onError(String m){runOnUiThread(()->out.setText(localPushHealth()+"\n\n❌ পরীক্ষা ব্যর্থ\n\n"+m));}});}
  private String localPushHealth(){
    boolean permission=android.os.Build.VERSION.SDK_INT<33||checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==android.content.pm.PackageManager.PERMISSION_GRANTED;
    android.content.SharedPreferences p=getSharedPreferences("myshop_push_v349",MODE_PRIVATE);
    boolean registered=p.getBoolean("token_registered",false);
    long at=p.getLong("registered_at",0L);
    String error=p.getString("last_error","");
    StringBuilder s=new StringBuilder();
    s.append("Push Client Config: ").append(PushRegistration.firebaseConfigured()?"OK":"MISSING FIREBASE BUILD SECRETS");
    s.append("\nNotification Permission: ").append(permission?"GRANTED":"NOT GRANTED");
    s.append("\nFCM Token Registered: ").append(registered?"YES":"NO");
    if(at>0)s.append("\nLast Registration: ").append(new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",java.util.Locale.US).format(new java.util.Date(at)));
    if(error!=null&&!error.trim().isEmpty())s.append("\nLast Push Error: ").append(error.trim());
    android.app.NotificationManager nm=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);
    s.append("\nSystem Notifications: ").append(androidx.core.app.NotificationManagerCompat.from(this).areNotificationsEnabled()?"ENABLED":"BLOCKED");
    if(android.os.Build.VERSION.SDK_INT>=26&&nm!=null){
      for(String id:new String[]{MyShopMessagingService.MESSAGE_CHANNEL,MyShopMessagingService.LIVE_CHANNEL,MyShopMessagingService.GENERAL_CHANNEL}){
        android.app.NotificationChannel ch=nm.getNotificationChannel(id);
        s.append("\nChannel ").append(id).append(": ").append(ch==null?"MISSING":ch.getImportance()==0?"BLOCKED":"importance="+ch.getImportance());
      }
    }
    s.append("\nLast device push received: ").append(p.getString("last_received_at","NONE"));
    s.append("\nAPK Firebase project: ").append(BuildConfig.FIREBASE_PROJECT_ID);
    s.append("\nDevice receipt and screen-off sound need a real-phone test.");
    return s.toString();
  }
  private String pretty(JSONObject d){return d.toString().replace(",","\n\n").replace("{","{\n").replace("}","\n}");}
  private TextView txt(String s,float z,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(Color.rgb(22,28,55));if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
