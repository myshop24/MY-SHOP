package com.myshop.app;

import android.os.Bundle;

/** Dedicated Wallpaper Admin: wallpaper-only grid, upload/preview, price/duration, order, publish and permanent delete. */
public class WallpaperAdminActivity extends AdminStoreActivity {
  @Override protected void onCreate(Bundle b){
    getIntent().putExtra("catalog_filter","WALLPAPER");
    super.onCreate(b);
  }
}
