package com.myshop.app;

import android.os.Bundle;
import android.graphics.Color;
import android.widget.*;
import org.json.JSONObject;

/** V-542: dedicated, server-authorized highlight price and host income settings. */
public class HighlightSettingsActivity extends androidx.appcompat.app.AppCompatActivity {
 private EditText price,percent;private Switch enabled;private Button save;private TextView status;
 @Override protected void onCreate(Bundle state){super.onCreate(state);if(!SessionManager.isAdmin(this)){finish();return;}
 LinearLayout root=new LinearLayout(this);root.setOrientation(android.widget.LinearLayout.VERTICAL);root.setPadding(dp(16),dp(20),dp(16),dp(20));root.setBackgroundColor(0xfff5f7fc);
 TextView title=new TextView(this);title.setText(UiStrings.label(this,UiStrings.ui636("Highlight Fee & Host Share")));title.setTextSize(20);title.setPadding(0,0,0,dp(16));title.setTextColor(0xff17213b);root.addView(title);
 LinearLayout card=new LinearLayout(this);card.setOrientation(android.widget.LinearLayout.VERTICAL);card.setPadding(dp(16),dp(16),dp(16),dp(16));card.setBackground(PremiumUi.solid(this,Color.WHITE,18,0xffe2e7f0,1));card.setElevation(dp(2));root.addView(card);price=field(UiStrings.label(this,UiStrings.ui636("Highlight comment fee (Coins)")),card);enabled=new Switch(this);enabled.setText(UiStrings.label(this,UiStrings.ui636("Enable host share")));enabled.setPadding(0,dp(12),0,dp(12));card.addView(enabled);
 percent=field(UiStrings.label(this,UiStrings.ui636("Host share (%)")),card);enabled.setOnCheckedChangeListener((b,on)->{percent.setEnabled(on);percent.setVisibility(on?android.view.View.VISIBLE:android.view.View.GONE);});
 status=new TextView(this);status.setTextSize(13);status.setTextColor(0xff647086);status.setPadding(0,dp(16),0,dp(12));status.setText("Loading saved settings…");root.addView(status);
 save=new Button(this);save.setText(UiStrings.label(HighlightSettingsActivity.this,"Save"));save.setAllCaps(false);save.setTextColor(Color.WHITE);save.setTextSize(16);save.setBackground(PremiumUi.gradient(this,new int[]{0xff6240e8,0xff286bf1},14,Color.TRANSPARENT,0));save.setEnabled(false);root.addView(save,new LinearLayout.LayoutParams(-1,dp(48)));Button back=new Button(this);back.setText("Cancel / Back");back.setOnClickListener(v->finish());root.addView(back);ScrollView scroll=new ScrollView(this);scroll.addView(root);setContentView(scroll);
 BackendClient.adminFinanceConfig(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{price.setText(String.valueOf(d.optInt("highlightPrice",1000)));percent.setText(String.valueOf(d.optDouble("highlightHostSharePercent",0)));enabled.setChecked(d.optBoolean("highlightHostShareEnabled",false));percent.setVisibility(enabled.isChecked()?android.view.View.VISIBLE:android.view.View.GONE);save.setEnabled(true);status.setText("One fee only. Disabled host share = all income to MY SHOP.");});}public void onError(String m){runOnUiThread(()->status.setText(m));}});
 save.setOnClickListener(v->{try{int fee=Integer.parseInt(price.getText().toString());double share=Double.parseDouble(percent.getText().toString());if(fee<0||fee>100000000||!Double.isFinite(share)||share<0||share>100)throw new IllegalArgumentException();save.setEnabled(false);BackendClient.saveHighlightSettings(SessionManager.getToken(this),fee,enabled.isChecked(),share,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{save.setEnabled(true);status.setText("Saved • fee "+fee+" Coin • host "+(enabled.isChecked()?share:0)+"%");});}public void onError(String m){runOnUiThread(()->{save.setEnabled(true);status.setText("Save failed: "+m+" • draft kept, retry");});}});}catch(Exception e){status.setText("Enter a non-negative whole Coin fee and host share between 0 and 100.");}});
 }
 private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 private EditText field(String label,LinearLayout root){TextView l=new TextView(this);l.setText(label);l.setTextSize(14);l.setTextColor(0xff17213b);l.setPadding(0,dp(6),0,dp(8));root.addView(l);EditText e=new EditText(this);e.setTextSize(17);e.setPadding(dp(12),0,dp(12),0);e.setBackground(PremiumUi.solid(this,0xfff6f8fc,12,0xffdce3ef,1));e.setSingleLine();e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);root.addView(e,new LinearLayout.LayoutParams(-1,dp(48)));return e;}
}
