package com.myshop.app;
/** Dedicated category route. */
public final class AvatarFrameAdminActivity extends AdminStoreActivity {
 @Override protected void onCreate(android.os.Bundle state){getIntent().putExtra("catalog_filter","AVATAR_FRAME");super.onCreate(state);}
}
