package com.myshop.app;

import android.graphics.*;
import android.graphics.drawable.Drawable;

/** Lightweight pastel backdrop. No bitmap of the page and no animation loop. */
public final class Home2BackgroundDrawable extends Drawable {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    @Override public void draw(Canvas c){Rect b=getBounds();float w=b.width(),h=b.height();if(w<=0||h<=0)return;c.drawColor(Color.rgb(252,252,255));
        wash(c,w*.02f,h*.15f,w*.8f,Color.argb(125,70,206,255));wash(c,w*.99f,h*.27f,w*.72f,Color.argb(115,255,76,183));wash(c,w*.0f,h*.75f,w*.64f,Color.argb(115,255,187,55));wash(c,w*.98f,h*.93f,w*.7f,Color.argb(96,149,106,255));
        paint.setShader(null);paint.setColor(Color.argb(70,255,255,255));Path ribbon=new Path();ribbon.moveTo(0,h*.56f);ribbon.cubicTo(w*.18f,h*.66f,w*.03f,h*.72f,w*.24f,h*.83f);ribbon.lineTo(w*.14f,h*.92f);ribbon.cubicTo(0,h*.78f,w*.09f,h*.67f,0,h*.63f);ribbon.close();c.drawPath(ribbon,paint);
    }
    private void wash(Canvas c,float x,float y,float r,int color){paint.setShader(new RadialGradient(x,y,r,color,Color.TRANSPARENT,Shader.TileMode.CLAMP));c.drawCircle(x,y,r,paint);}
    @Override public void setAlpha(int a){} @Override public void setColorFilter(ColorFilter f){} @Override public int getOpacity(){return PixelFormat.OPAQUE;}
}
