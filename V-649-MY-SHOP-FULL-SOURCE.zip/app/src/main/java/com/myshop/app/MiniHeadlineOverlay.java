package com.myshop.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

/** Separate animated Breaking News companion strip with grouped text/background motion. */
final class MiniHeadlineOverlay {
 private final Activity activity;private final FrameLayout host,overlay;private final Handler handler=new Handler(Looper.getMainLooper());private JSONArray layers;private JSONObject config;private int index;private boolean active=true,closed=false;
 private MiniHeadlineOverlay(Activity a,FrameLayout h,String scope){activity=a;host=h;overlay=new FrameLayout(a);host.addView(overlay,new FrameLayout.LayoutParams(-1,-1));}
 static void install(Activity a,String scope){ViewGroup root=a.findViewById(android.R.id.content);if(!(root instanceof FrameLayout))return;MiniHeadlineOverlay strip=new MiniHeadlineOverlay(a,(FrameLayout)root,scope);if(a instanceof androidx.lifecycle.LifecycleOwner)((androidx.lifecycle.LifecycleOwner)a).getLifecycle().addObserver((androidx.lifecycle.LifecycleEventObserver)(owner,event)->{if(event==androidx.lifecycle.Lifecycle.Event.ON_STOP)strip.suspend();else if(event==androidx.lifecycle.Lifecycle.Event.ON_RESUME&&strip.config!=null)strip.resume();else if(event==androidx.lifecycle.Lifecycle.Event.ON_DESTROY)strip.close();});BackendClient.headlineStrip(SessionManager.getToken(a),scope,false,new BackendClient.Callback(){public void onSuccess(JSONObject d){a.runOnUiThread(()->strip.start(d));}public void onError(String e){a.runOnUiThread(strip::close);}});}
 private int dp(float n){return Math.round(n*activity.getResources().getDisplayMetrics().density);}
 private void start(JSONObject d){if(closed||activity.isFinishing()||activity.isDestroyed()||!d.optBoolean("enabled"))return;config=d;layers=d.optJSONArray("layers");if(layers==null||layers.length()==0){close();return;}if(active)showNext();}
 private void showNext(){if(!active||activity.isFinishing()||activity.isDestroyed())return;JSONObject item=null;for(int tries=0;tries<layers.length();tries++){JSONObject x=layers.optJSONObject(index++%layers.length());if(x!=null&&x.optBoolean("enabled",true)){item=x;break;}}if(item==null){close();return;}final JSONObject selected=item;TextView line=new TextView(activity);line.setText(selected.optString("text"));line.setTextColor(color(selected.optString("textColor"),Color.WHITE));line.setTextSize(Math.max(10,Math.min(24,selected.optInt("size",14))));line.setTypeface(null,android.graphics.Typeface.BOLD);line.setSingleLine(true);line.setMaxWidth(Math.round(activity.getResources().getDisplayMetrics().widthPixels*.92f));line.setEllipsize(android.text.TextUtils.TruncateAt.END);line.setPadding(dp(12),dp(6),dp(12),dp(6));GradientDrawable bg=new GradientDrawable();bg.setColor(color(selected.optString("backgroundColor"),0xff31205b));bg.setCornerRadius(dp(7));line.setBackground(bg);line.setElevation(dp(2));FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT);lp.topMargin=dp(95);overlay.addView(line,lp);line.post(()->{if(selected.optDouble("yPosition",-1)>=0)line.setY((float)selected.optDouble("yPosition",.1)*Math.max(0,overlay.getHeight()-line.getHeight()));float requestedTarget=(float)selected.optDouble("position",.5)*(overlay.getWidth()-line.getWidth());final float target=Math.max(0,Math.min(overlay.getWidth()-line.getWidth(),requestedTarget));line.setX(overlay.getWidth());if(config.optBoolean("animate",true)){line.animate().alpha(1f).translationX(target-overlay.getWidth()).setDuration(650).withEndAction(()->pauseThenExit(line,selected,target)).start();}else{line.setX(target);pauseThenExit(line,selected,target);}});}
 private void pauseThenExit(TextView line,JSONObject item,float x){if(config.optBoolean("flashEnabled",true)){View flash=new View(activity);GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{0x00ffffff,0xddffffff,0x00ffffff});flash.setBackground(g);overlay.addView(flash,new FrameLayout.LayoutParams(dp(55),dp(2),Gravity.TOP|Gravity.LEFT));flash.setY(line.getY());flash.setX(x);flash.animate().translationX(x+line.getWidth()).alpha(.2f).setDuration(500).withEndAction(()->overlay.removeView(flash)).start();}handler.postDelayed(()->{if(!active)return;if(config.optBoolean("animate",true))line.animate().translationX(-line.getWidth()-dp(20)).setDuration(620).withEndAction(()->{overlay.removeView(line);handler.postDelayed(this::showNext,180);}).start();else{overlay.removeView(line);showNext();}},Math.max(0,Math.min(30,item.optInt("pauseSeconds",2)))*1000L);}
 private int color(String s,int fallback){try{return Color.parseColor(s);}catch(Exception e){return fallback;}}
 private void suspend(){active=false;handler.removeCallbacksAndMessages(null);overlay.removeAllViews();}
 private void resume(){if(closed||layers==null)return;active=true;showNext();}
 private void close(){closed=true;active=false;handler.removeCallbacksAndMessages(null);if(overlay.getParent()!=null)host.removeView(overlay);}
}
