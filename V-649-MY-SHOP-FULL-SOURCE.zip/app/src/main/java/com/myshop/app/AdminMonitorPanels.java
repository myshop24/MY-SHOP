package com.myshop.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.*;
import org.json.*;

/** Read-only dashboard: canonical notices and currency ledger summaries, never demo balances. */
final class AdminMonitorPanels {
 private final Activity owner;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private final LinearLayout root,requestTiles,requests,finance,activity;
 private final TextView status;
 private JSONArray events632=new JSONArray();
 private boolean active,busy;
 private int generation;
 private final Runnable refresh=()->load();
 AdminMonitorPanels(Activity a){
  owner=a;root=column();root.setPadding(dp(8),dp(8),dp(8),dp(8));
  GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff071638,0xff25135a});bg.setCornerRadius(dp(18));root.setBackground(bg);Appearance.preserve(root);
  status=text("Live monitor • loading…",11);root.addView(status);status.setOnClickListener(v->{handler.removeCallbacks(refresh);load();});
  root.addView(heading("USER REQUESTS",()->folder("ALL")));
  requestTiles=column();root.addView(requestTiles);
  root.addView(heading("নতুন রিকোয়েস্ট • New requests",()->folder("ALL")));
  requests=column();root.addView(requests);
  root.addView(heading("FINANCE MONITOR • Coin / Diamond",()->owner.startActivity(new Intent(owner,AdminFinanceActivity.class))));
  finance=column();root.addView(finance);finance.addView(text("হিসাব লোড হচ্ছে…",12));
  root.addView(heading("LIVE ACTIVITY • সাম্প্রতিক কার্যক্রম",()->showActivity632()));activity=column();root.addView(activity);activity.addView(text("কার্যক্রম লোড হচ্ছে…",12));
 }
 LinearLayout view(){return root;}
 void resume(){active=true;load();}
 void pause(){active=false;generation++;busy=false;handler.removeCallbacksAndMessages(null);}
 private void load(){
  if(!active||busy||owner.isFinishing()||owner.isDestroyed())return;
  busy=true;final int request=++generation;final boolean[] extraDone={false,false};
  handler.postDelayed(()->{if(valid(request)&&busy){busy=false;status.setText("রিকোয়েস্ট পাওয়া যায়নি • আবার চাপুন");schedule();}},25000);
  handler.postDelayed(()->{if(!valid(request))return;if(!extraDone[0]){extraDone[0]=true;finance.removeAllViews();finance.addView(text("হিসাব পাওয়া যায়নি • আবার refresh করুন",12));}if(!extraDone[1]){extraDone[1]=true;activity.removeAllViews();activity.addView(text("কার্যক্রম পাওয়া যায়নি • আবার refresh করুন",12));}},25000);
  BackendClient.folderNotices(SessionManager.getToken(owner),"ALL",new BackendClient.Callback(){
   public void onSuccess(JSONObject data){owner.runOnUiThread(()->{if(!valid(request))return;busy=false;if(!renderRequests(data)){schedule();return;}status.setText("Updated • প্রতি ১৫ সেকেন্ডে refresh • চাপলে এখনই");schedule();});}
   public void onError(String error){owner.runOnUiThread(()->{if(!valid(request))return;busy=false;status.setText("রিকোয়েস্ট refresh হয়নি • আবার চাপুন");schedule();});}
  });
  BackendClient.adminFinanceOverview(SessionManager.getToken(owner),new BackendClient.Callback(){
   public void onSuccess(JSONObject data){owner.runOnUiThread(()->{if(valid(request)&&!extraDone[0]){extraDone[0]=true;renderFinance(data);}});}
   public void onError(String error){owner.runOnUiThread(()->{if(!valid(request)||extraDone[0])return;extraDone[0]=true;finance.removeAllViews();finance.addView(text("Finance unavailable • আবার refresh করুন",12));});}
  });
  BackendClient.adminActivity(SessionManager.getToken(owner),new BackendClient.Callback(){public void onSuccess(JSONObject data){owner.runOnUiThread(()->{if(valid(request)&&!extraDone[1]){extraDone[1]=true;renderActivity(data);}});}public void onError(String message){owner.runOnUiThread(()->{if(!valid(request)||extraDone[1])return;extraDone[1]=true;activity.removeAllViews();activity.addView(text("কার্যক্রম পাওয়া যায়নি • আবার refresh করুন",12));});}});
 }
 private void renderActivity(JSONObject data){JSONArray events=data.optJSONArray("events");activity.removeAllViews();if(events==null){activity.addView(text("Activity unavailable • Retry",12));return;}events632=events;TextView summary=text(events.length()+" recent events • View all ›",12);summary.setPadding(dp(8),dp(8),dp(8),dp(8));summary.setOnClickListener(v->showActivity632());activity.addView(summary);}
 private void showActivity632(){ScrollView scroll=new ScrollView(owner);LinearLayout list=column();for(int j=0;j<events632.length();j++){JSONObject e=events632.optJSONObject(j);if(e==null)continue;String uid=e.optString("user_id");TextView item=text(e.optString("kind")+" • "+e.optString("title")+"\nID "+uid+" • "+e.optString("event_at"),13);item.setPadding(dp(12),dp(12),dp(12),dp(12));item.setTextColor(0xff172347);item.setOnClickListener(v->owner.startActivity(new Intent(owner,AdminUserControlActivity.class).putExtra("userId",uid)));list.addView(item);}scroll.addView(list);new MyShopDialogBuilder(owner).setTitle("Live Activity").setView(scroll).setPositiveButton(UiStrings.ui636("Close"),null).show();}
 private boolean valid(int request){return active&&request==generation&&!owner.isFinishing()&&!owner.isDestroyed();}
 private void schedule(){handler.removeCallbacks(refresh);if(active)handler.postDelayed(refresh,15000);}
 private long count(JSONArray a,String kind,String field){long value=0;if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&kind.equals(x.optString("kind")))value+=Math.max(0,x.optLong(field));}return value;}
 private boolean renderRequests(JSONObject data){
  if(data.optJSONArray("counts")==null||data.optJSONArray("pendingCounts")==null||data.optJSONArray("notices")==null){status.setText("Invalid request response • Retry");return false;}
  requestTiles.removeAllViews();requests.removeAllViews();
  String[] kinds={"WITHDRAW","PREMIUM_MEMBERSHIP","SUPPORT","REPORT","ORDER","ACCOUNT_DELETE"};
  String[] labels={"Withdraw","Membership","Support","Report","Orders","Account Delete"};
  int[] colors={0xfff57c00,0xff8e24aa,0xff00897b,0xffd81b60,0xff1565c0,0xff5e35b1};
  for(int row=0;row<2;row++){LinearLayout line=new LinearLayout(owner);for(int j=0;j<3;j++){int index=row*3+j;String kind=kinds[index];TextView tile=text(labels[index]+"\n"+count(data.optJSONArray("counts"),kind,"unread")+" নতুন\n"+count(data.optJSONArray("pendingCounts"),kind,"pending")+" pending",12);tile.setGravity(Gravity.CENTER);tile.setPadding(dp(3),dp(8),dp(3),dp(8));GradientDrawable bg=new GradientDrawable();bg.setColor(colors[index]);bg.setCornerRadius(dp(10));tile.setBackground(bg);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(94),1);p.setMargins(dp(3),dp(3),dp(3),dp(3));line.addView(tile,p);tile.setOnClickListener(v->folder(kind));}requestTiles.addView(line);}
  JSONArray list=data.optJSONArray("notices");int shown=0;for(int i=0;i<list.length()&&shown<5;i++){JSONObject n=list.optJSONObject(i);if(n==null||n.optInt("is_read")==1)continue;String kind=n.optString("folder_kind",n.optString("kind"));TextView item=text(n.optString("kind")+" • "+n.optString("name")+" • ID "+n.optString("user_id")+"\n"+n.optString("item_title")+" • "+n.optString("request_status")+"\n"+n.optString("created_at"),11);item.setPadding(dp(8),dp(7),dp(8),dp(7));item.setOnClickListener(v->folder(kind));requests.addView(item);shown++;}if(shown==0)requests.addView(text("নতুন unread রিকোয়েস্ট নেই",12));return true;
 }
 private void renderFinance(JSONObject data){
  JSONObject currencies=data.optJSONObject("currencySummary");if(currencies==null){finance.removeAllViews();finance.addView(text("Invalid finance response • Retry",12));return;}
  finance.removeAllViews();for(String currency:new String[]{"COIN","GOLD"}){JSONObject summary=currencies.optJSONObject(currency);if(summary==null){finance.addView(text(currency+" • তথ্য পাওয়া যায়নি",12));continue;}boolean complete=true;for(String key:new String[]{"todayGross","todayPlatform","todayNet","allGross","allPlatform","allNet"})if(!(summary.opt(key) instanceof Number))complete=false;if(!complete){finance.addView(text(currency+" • অসম্পূর্ণ হিসাব • আবার refresh করুন",12));continue;}TextView card=text((currency.equals("GOLD")?"Diamond":"Coin")+"\nআজ: In "+summary.optLong("todayGross")+" • Commission "+summary.optLong("todayPlatform")+" • Net "+summary.optLong("todayNet")+"\nমোট: In "+summary.optLong("allGross")+" • Commission "+summary.optLong("allPlatform")+" • Net "+summary.optLong("allNet"),12);card.setPadding(dp(8),dp(10),dp(8),dp(10));card.setOnClickListener(v->owner.startActivity(new Intent(owner,AdminFinanceActivity.class)));finance.addView(card);}
 }
 private void folder(String kind){owner.startActivity(new Intent(owner,FolderNoticeActivity.class).putExtra("notice_kind",kind));}
 private TextView heading(String title,Runnable action){TextView t=text(title+"   ›",14);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(dp(4),dp(12),dp(4),dp(8));t.setOnClickListener(v->action.run());return t;}
 private TextView text(String title,float size){TextView t=new TextView(owner);t.setText(title);t.setTextSize(size);t.setTextColor(Color.WHITE);return t;}
 private LinearLayout column(){LinearLayout l=new LinearLayout(owner);l.setOrientation(LinearLayout.VERTICAL);return l;}
 private int dp(int value){return Math.round(value*owner.getResources().getDisplayMetrics().density);}
}
