package com.myshop.app;
import android.content.Context;
import android.graphics.*;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.View;
import android.view.MotionEvent;import android.view.ViewConfiguration;
import org.json.JSONObject;
/** Live native template, not a flattened poster. All coordinates scale with the banner. */
public final class UpcomingBannerView extends View {
 private final Paint p=new Paint(3);private JSONObject item=new JSONObject();private Bitmap photo;private String photoUrl="";private long serverNow=System.currentTimeMillis(),synced=SystemClock.elapsedRealtime();
 private Runnable profileAction,reminderAction,joinAction;private float downX,downY;
 public void setActions(Runnable profile,Runnable reminder,Runnable join){profileAction=profile;reminderAction=reminder;joinAction=join;setClickable(true);}
 @Override public boolean onTouchEvent(MotionEvent e){if(e.getActionMasked()==MotionEvent.ACTION_DOWN){downX=e.getX();downY=e.getY();return true;}if(e.getActionMasked()==MotionEvent.ACTION_UP){float slop=ViewConfiguration.get(getContext()).getScaledTouchSlop();if(Math.hypot(e.getX()-downX,e.getY()-downY)<=slop){if(e.getX()<getWidth()*.30f&&profileAction!=null)profileAction.run();else if(e.getX()>getWidth()*.70f){if(item.optBoolean("isLive")&&joinAction!=null)joinAction.run();else if(reminderAction!=null)reminderAction.run();}else performClick();}return true;}return true;}
 @Override public boolean performClick(){return super.performClick();}
 public UpcomingBannerView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
 public void bind(JSONObject x,long now){String nextPhoto=x.optString("photoUrl");if(!nextPhoto.equals(photoUrl))photo=null;photoUrl=nextPhoto;item=x;serverNow=now;synced=SystemClock.elapsedRealtime();setContentDescription("Upcoming Live • "+x.optString("name")+" • ID "+x.optString("userId"));invalidate();}
 public void setPhoto(Bitmap b){photo=b;invalidate();} public void tick(){invalidate();}
 private int backgroundColor(){try{return Color.parseColor(item.optString("background","#101C4A"));}catch(Exception e){return 0xff101c4a;}}
 static int contrast(int c){double[] v={Color.red(c)/255d,Color.green(c)/255d,Color.blue(c)/255d};for(int i=0;i<3;i++)v[i]=v[i]<=.04045?v[i]/12.92:Math.pow((v[i]+.055)/1.055,2.4);double y=.2126*v[0]+.7152*v[1]+.0722*v[2];return (y+.05)/.05>=1.05/(y+.05)?Color.BLACK:Color.WHITE;}
 @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();if(w<=0||h<=0)return;int bg=backgroundColor(),fg=contrast(bg);int clipped=c.save();Path boundary=new Path();boundary.addRoundRect(new RectF(0,0,w,h),h*.07f,h*.07f,Path.Direction.CW);c.clipPath(boundary);p.setColor(bg);c.drawRoundRect(new RectF(0,0,w,h),h*.07f,h*.07f,p);
  // Subtle edge accents leave the selected background and central text legible.
  p.setColor(0x25209fff);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(h*.014f);c.drawArc(new RectF(-w*.1f,-h*.55f,w*1.2f,h*1.05f),25,145,false,p);c.drawArc(new RectF(-w*.1f,-h*.45f,w*1.2f,h*1.15f),25,145,false,p);p.setStyle(Paint.Style.FILL);
  float px=w*.16f,py=h*.47f,r=w*.128f; p.setColor(0xff35cfff);c.drawCircle(px,py,r+w*.004f,p);p.setColor(Color.WHITE);c.drawCircle(px,py,r+1,p);
  if(photo!=null){int save=c.save();Path path=new Path();path.addCircle(px,py,r,Path.Direction.CW);c.clipPath(path);int side=Math.min(photo.getWidth(),photo.getHeight());Rect source=new Rect((photo.getWidth()-side)/2,(photo.getHeight()-side)/2,(photo.getWidth()+side)/2,(photo.getHeight()+side)/2);c.drawBitmap(photo,source,new RectF(px-r,py-r,px+r,py+r),p);c.restoreToCount(save);}else{p.setColor(0xffd3dcf0);c.drawCircle(px,py,r,p);text(c,"👤",px,py+r*.28f,r,0xff172b55,r*1.8f,true);}
  text(c,"ID "+item.optString("userId","0000"),px,h*.93f,h*.063f,fg,w*.25f,true);
  float center=w*.50f,wide=w*.37f;float brandSize=h*.10f;String brand="MYSHOP";p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(brandSize);float my=p.measureText("MY"),shop=p.measureText("SHOP"),start=center-(my+shop)/2;p.setTextAlign(Paint.Align.LEFT);if(fg==Color.BLACK){p.setColor(0xff172955);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(h*.008f);c.drawText("MY",start,h*.21f,p);c.drawText("SHOP",start+my,h*.21f,p);p.setStyle(Paint.Style.FILL);}p.setColor(0xffffcf57);c.drawText("MY",start,h*.21f,p);p.setColor(0xffdfe7f2);c.drawText("SHOP",start+my,h*.21f,p);
  p.setShader(null);p.clearShadowLayer();p.setStyle(Paint.Style.FILL);
  p.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));p.setTextSize(h*.132f);
  while(p.measureText("UPCOMING LIVE")>wide*.95f)p.setTextSize(p.getTextSize()-.5f);
  p.setTextAlign(Paint.Align.LEFT);float titleX=center-p.measureText("UPCOMING LIVE")/2f;
  p.setColor(0xff00dce8);c.drawText("UPCOMING ",titleX,h*.424f,p);titleX+=p.measureText("UPCOMING ");
  long phase=SystemClock.uptimeMillis()%2600;String live="LIVE";p.setColor(0xffff294b);
  for(int letter=0;letter<4;letter++){float local=(phase-letter*280)/420f;float rise=local>=0&&local<=1?(float)Math.sin(local*Math.PI)*h*.025f:0;c.drawText(live.substring(letter,letter+1),titleX,h*.424f-rise,p);titleX+=p.measureText(live.substring(letter,letter+1));}

  text(c,item.optString("name","অতিথির নাম"),center,h*.67f,h*.13f,fg,wide,true);
  text(c,item.optString("identity","পরিচয়"),center,h*.88f,h*.085f,fg,wide,false);
  float tx=w*.846f,tr=w*.129f;p.setColor(Color.WHITE);c.drawCircle(tx,h*.5f,tr,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(w*.003f);p.setColor(0xffc8dcff);c.drawCircle(tx,h*.5f,tr-w*.003f,p);p.setStyle(Paint.Style.FILL);
  long seconds=UpcomingClock.secondsLeft(item.optLong("liveAt",System.currentTimeMillis()),serverNow,SystemClock.elapsedRealtime()-synced);
  float bellY=h*.35f,bellR=h*.067f;p.setColor(item.optBoolean("reminded")?0xff16834d:0xffbe7900);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(h*.012f);Path bell=new Path();bell.moveTo(tx-bellR*.7f,bellY+bellR*.45f);bell.lineTo(tx-bellR*.5f,bellY-bellR*.25f);bell.cubicTo(tx-bellR*.5f,bellY-bellR,tx+bellR*.5f,bellY-bellR,tx+bellR*.5f,bellY-bellR*.25f);bell.lineTo(tx+bellR*.7f,bellY+bellR*.45f);bell.close();c.drawPath(bell,p);c.drawArc(new RectF(tx-bellR*.23f,bellY+bellR*.4f,tx+bellR*.23f,bellY+bellR*.9f),0,180,false,p);p.setStyle(Paint.Style.FILL);
  String hours=UpcomingClock.hours(seconds),minutes=UpcomingClock.minutes(seconds),ss=UpcomingClock.seconds(seconds);String[] parts={hours,":",minutes,":",ss};p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(h*.20f);String full=hours+":"+minutes+":"+ss;while(p.measureText(full)>tr*1.78f)p.setTextSize(p.getTextSize()-.5f);float left=tx-p.measureText(full)/2;p.setTextAlign(Paint.Align.LEFT);if(item.optBoolean("isLive")){text(c,"JOIN LIVE",tx,h*.61f,h*.15f,0xff16834d,tr*1.8f,true);}else for(int i=0;i<parts.length;i++){p.setColor(i==4?0xff16834d:i%2==1?0xff122955:0xffdc213f);c.drawText(parts[i],left,h*.61f,p);left+=p.measureText(parts[i]);}
  c.restoreToCount(clipped);


 }
 private void signal(Canvas c,float x,float y,float r,float a){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(1,r*.17f));p.setColor(Color.argb((int)(255*a),0,176,222));for(int i=1;i<=2;i++)c.drawArc(new RectF(x-r*i/2,y-r*i/2,x+r*i/2,y+r*i/2),-60,120,false,p);p.setStyle(Paint.Style.FILL);c.drawCircle(x,y,r*.13f,p);}
 private void text(Canvas c,String s,float x,float y,float size,int color,float max,boolean bold){p.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));p.setTextSize(size);while(p.measureText(s)>max&&p.getTextSize()>size*.7f)p.setTextSize(p.getTextSize()-.5f);CharSequence value=TextUtils.ellipsize(s,new android.text.TextPaint(p),max,TextUtils.TruncateAt.END);p.setColor(color);p.setTextAlign(Paint.Align.CENTER);c.drawText(value.toString(),x,y,p);}
}
