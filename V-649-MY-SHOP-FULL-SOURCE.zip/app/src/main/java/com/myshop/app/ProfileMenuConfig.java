package com.myshop.app;
import org.json.*;
/** Canonical configurable compact-drawer slots; targets remain the existing code routes. */
public final class ProfileMenuConfig {
 public static final String[] KEYS={"home","new_hub","my_feed","myshop","categories","orders","cart","gallery","external","earn","history","website","profile_actions","notifications","reduce_animation","support","social","share","language","about"};
 public static final String[] TITLES={"Home","New Hub","My Feed","myshop","Categories","Orders","Cart","Gallery","External Media","Earn & Reward","Activity History","Website","Profile Actions","Notifications","Reduce Animation","Customer Support","Social Links","Share App","Language","About"};
 public static JSONArray defaults(){JSONArray rows=new JSONArray();try{for(int i=0;i<KEYS.length;i++)rows.put(new JSONObject().put("key",KEYS[i]).put("title",TITLES[i]).put("iconUrl","").put("visible",true).put("order",i));}catch(Exception ignored){}return rows;}
 public static String key(String title){for(int i=0;i<TITLES.length;i++)if(TITLES[i].equals(title))return KEYS[i];return "";}
 public static boolean complete(JSONArray rows){if(rows==null||rows.length()!=KEYS.length)return false;java.util.Set<String> keys=new java.util.HashSet<>();java.util.Set<Integer> orders=new java.util.HashSet<>();for(int i=0;i<rows.length();i++){JSONObject r=rows.optJSONObject(i);if(r==null||!java.util.Arrays.asList(KEYS).contains(r.optString("key"))||!keys.add(r.optString("key"))||!(r.opt("visible") instanceof Boolean)||!(r.opt("order") instanceof Number)||r.optInt("order",-1)<0||r.optInt("order",-1)>=KEYS.length||!orders.add(r.optInt("order"))||r.optString("title").trim().isEmpty()||r.optString("title").length()>60||!safeIcon(r.optString("iconUrl")))return false;}return true;}
 public static boolean safeIcon(String value){if(value==null||value.isEmpty())return true;try{java.net.URI u=new java.net.URI(value);String path=u.getPath();return value.length()<=2000&&"https".equalsIgnoreCase(u.getScheme())&&u.getHost()!=null&&u.getUserInfo()==null&&path!=null&&path.toLowerCase(java.util.Locale.ROOT).matches(".*\\.(png|webp|jpe?g)$");}catch(Exception e){return false;}}
 private ProfileMenuConfig(){}
}
