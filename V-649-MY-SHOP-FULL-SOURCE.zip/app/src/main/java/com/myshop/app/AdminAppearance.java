package com.myshop.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Personal Admin display preferences; never publishes a consumer App theme. */
final class AdminAppearance {
    private static SharedPreferences prefs(Activity a) {
        return a.getSharedPreferences("myshop_admin_appearance_"+SessionManager.getUserId(a), Activity.MODE_PRIVATE);
    }
    static int background(Activity a) { return prefs(a).getInt("background",0xff150d38); }
    static int card(Activity a) { return prefs(a).getInt("card",0xff241a52); }
    static float zoom(Activity a) { return prefs(a).getInt("zoom",100)/100f; }
    static boolean english(Activity a) { return prefs(a).getBoolean("english",false); }
    static int ink(int fill) { return (.299*Color.red(fill)+.587*Color.green(fill)+.114*Color.blue(fill))>155?0xff17223f:Color.WHITE; }
    static void language(Activity a,Runnable redraw) {
        new MyShopDialogBuilder(a).setTitle("ভাষা / Language").setSingleChoiceItems(new String[]{"বাংলা","English"},english(a)?1:0,(d,n)->{prefs(a).edit().putBoolean("english",n==1).apply();d.dismiss();redraw.run();}).setNegativeButton(UiStrings.ui636("Cancel"),null).show();
    }
    static void zoom(Activity a,Runnable redraw) {
        new MyShopDialogBuilder(a).setTitle("Zoom").setItems(new String[]{"75%","100%","125%","150%"},(d,n)->{prefs(a).edit().putInt("zoom",new int[]{75,100,125,150}[n]).apply();redraw.run();}).show();
    }
    static void theme(Activity a,Runnable redraw) {
        String[] labels=new String[22];for(int i=0;i<20;i++)labels[i]=(i<10?"Sun ":"Moon ")+(i%10+1);labels[20]="Custom colors";labels[21]="Reset Default";
        int[] backgrounds={0xfff7f8ff,0xfffff8ed,0xffeff9fc,0xfff7efff,0xfff0faf4,0xfffff0f5,0xfff3f6fa,0xfffff9df,0xffeef5ff,0xfff3f1ed,0xff150d38,0xff08152f,0xff1d102c,0xff071f21,0xff241b10,0xff231026,0xff151922,0xff102621,0xff12132d,0xff141414};
        int[] cards={0xffffffff,0xffffefd4,0xffd7f3ff,0xffe8ddff,0xffdcf4e6,0xffffdce9,0xffe5eaf3,0xffffefaf,0xffdbe9ff,0xffe9e3d8,0xff241a52,0xff172a50,0xff392046,0xff11363b,0xff463018,0xff48203d,0xff2b3242,0xff20483a,0xff242759,0xff303030};
        new MyShopDialogBuilder(a).setTitle("Admin Theme · 20 presets").setItems(labels,(d,n)->{if(n==20){custom(a,redraw);return;}if(n==21){preview(a,0xff150d38,0xff241a52,redraw);return;}preview(a,backgrounds[n],cards[n],redraw);}).setNegativeButton(UiStrings.ui636("Cancel"),null).show();
    }
    private static void custom(Activity a,Runnable redraw) {
        LinearLayout box=new LinearLayout(a);box.setOrientation(LinearLayout.VERTICAL);
        int pad=Math.round(12*a.getResources().getDisplayMetrics().density);box.setPadding(pad,pad,pad,pad);
        final int[] chosen={background(a),card(a)};
        TextView sample=new TextView(a);sample.setText("MY SHOP • Admin preview");sample.setTextSize(18);sample.setPadding(pad,pad,pad,pad);box.addView(sample);
        Button backgroundChoice=new Button(a),cardChoice=new Button(a);
        backgroundChoice.setText("পেজের ব্যাকগ্রাউন্ড • রঙের চাকা");cardChoice.setText("কার্ডের রং • রঙের চাকা");box.addView(backgroundChoice);box.addView(cardChoice);
        Runnable refresh=()->{box.setBackgroundColor(chosen[0]);sample.setBackgroundColor(chosen[1]);sample.setTextColor(ink(chosen[1]));};refresh.run();
        backgroundChoice.setOnClickListener(v->ColorPicker.show(a,chosen[0],value->{chosen[0]=value;refresh.run();}));
        cardChoice.setOnClickListener(v->ColorPicker.show(a,chosen[1],value->{chosen[1]=value;refresh.run();}));
        new MyShopDialogBuilder(a).setTitle("Admin রং • কোড লাগবে না").setView(box).setNegativeButton(UiStrings.ui636("Cancel"),null).setPositiveButton(UiStrings.ui636("Preview"),(d,n)->preview(a,chosen[0],chosen[1],redraw)).show();
    }
    private static void preview(Activity a,int bg,int card,Runnable redraw) {
        LinearLayout sample=new LinearLayout(a);sample.setPadding(24,24,24,24);sample.setBackgroundColor(bg);TextView title=new TextView(a);title.setText("MY SHOP · ADMIN PANEL");title.setTextSize(20);title.setTextColor(ink(card));title.setPadding(24,24,24,24);title.setBackgroundColor(card);sample.addView(title);
        new MyShopDialogBuilder(a).setTitle("Preview · Personal Admin theme").setView(sample).setNegativeButton(UiStrings.ui636("Cancel"),null).setPositiveButton("Save & Apply",(d,n)->{prefs(a).edit().putInt("background",bg).putInt("card",card).apply();redraw.run();}).show();
    }
}
