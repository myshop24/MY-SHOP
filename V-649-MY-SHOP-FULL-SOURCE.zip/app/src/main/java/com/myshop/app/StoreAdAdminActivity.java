package com.myshop.app;
/** Uses isolated Store advertisement scope; other page ads remain intact. */
public final class StoreAdAdminActivity extends AnimationAds645Activity {
 @Override public void onCreate(android.os.Bundle b){getIntent().putExtra("store_ads",true);super.onCreate(b);}
}
