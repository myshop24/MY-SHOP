package com.myshop.app;
import android.graphics.*;import android.graphics.drawable.Drawable;
/** Brief, unobtrusive flames in top padding; membership artwork remains unchanged. */
final class Top1CommentDrawable extends Drawable implements Drawable.Callback {
 private final Drawable base;private final Paint p=new Paint(3);private final long born=android.os.SystemClock.uptimeMillis();
 Top1CommentDrawable(Drawable base){this.base=base;base.setCallback(this);}
 public void draw(Canvas c){base.setBounds(getBounds());base.draw(c);long elapsed=android.os.SystemClock.uptimeMillis()-born;if(elapsed>1900)return;Rect b=getBounds();float fade=(float)Math.sin(Math.PI*Math.min(1,elapsed/1900f)),h=Math.min(18,b.height()*.13f);for(int i=0;i<9;i++){float x=b.left+(i+1)*b.width()/10f,y=b.top+h,tip=h*(.55f+.45f*(float)Math.sin(elapsed/160f+i*2.1f));Path f=new Path();f.moveTo(x-4,y);f.cubicTo(x-8,y-tip*.5f,x+4,y-tip*.8f,x,y-tip);f.cubicTo(x+11,y-tip*.5f,x+8,y,x-4,y);p.setShader(new LinearGradient(x,y-tip,x,y,new int[]{0xffffee8c,0xffff9823,0x00ff4010},null,Shader.TileMode.CLAMP));p.setAlpha((int)(220*fade));c.drawPath(f,p);}p.setShader(null);invalidateSelf();}
 public void invalidateDrawable(Drawable d){invalidateSelf();}public void scheduleDrawable(Drawable d,Runnable task,long at){scheduleSelf(task,at);}public void unscheduleDrawable(Drawable d,Runnable task){unscheduleSelf(task);}
 public void setAlpha(int alpha){base.setAlpha(alpha);}public void setColorFilter(ColorFilter filter){base.setColorFilter(filter);}public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
