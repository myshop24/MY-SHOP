package com.myshop.app;
import android.content.Context;
import android.graphics.*;
import android.view.View;
/** Design29: stationary camera, slow expanding blue/pink light. */
final class AnimatedLiveIconView extends View {
 private final Paint p=new Paint(3);private boolean reduce;
 AnimatedLiveIconView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);reduce=false;setContentDescription("Live video");}
 @Override protected void onAttachedToWindow(){super.onAttachedToWindow();invalidate();}
 @Override public void onWindowFocusChanged(boolean focus){super.onWindowFocusChanged(focus);if(focus)invalidate();}
 @Override protected void onDraw(Canvas c){reduce=false;float s=Math.min(getWidth(),getHeight()),x=getWidth()/2f,y=getHeight()/2f,t=reduce?0:(android.os.SystemClock.uptimeMillis()%3000)/3000f;
 p.setStyle(Paint.Style.FILL);p.setShader(new RadialGradient(x,y,s*.4f,new int[]{0xff02030d,0xff070723,0xff18214a},null,Shader.TileMode.CLAMP));c.drawCircle(x,y,s*.37f,p);
 // Two stationary half-rings alternate intensity. Camera and center never pulse, rotate or scale.
 p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(s*.035f);float wave=reduce?.5f:(.5f+.5f*(float)Math.sin(t*6.283185));RectF ring=new RectF(x-s*.37f,y-s*.37f,x+s*.37f,y+s*.37f);
 p.setColor(0xff36dcff);p.setAlpha((int)(45+210*wave));p.setShadowLayer(s*.045f,0,0,0xff36dcff);c.drawArc(ring,-90,180,false,p);
 p.setColor(0xffff3ab9);p.setAlpha((int)(45+210*(1-wave)));p.setShadowLayer(s*.045f,0,0,0xffff3ab9);c.drawArc(ring,90,180,false,p);
 p.setShader(null);p.clearShadowLayer();p.setAlpha(255);p.setColor(Color.WHITE);p.setStyle(Paint.Style.FILL);c.drawRoundRect(x-s*.19f,y-s*.135f,x+s*.085f,y+s*.135f,s*.045f,s*.045f,p);Path camera=new Path();camera.moveTo(x+s*.11f,y-s*.08f);camera.lineTo(x+s*.22f,y-s*.13f);camera.lineTo(x+s*.22f,y+s*.13f);camera.lineTo(x+s*.11f,y+s*.08f);camera.close();c.drawPath(camera,p);p.setColor(0xff392074);Path play=new Path();play.moveTo(x-s*.09f,y-s*.055f);play.lineTo(x-s*.09f,y+s*.055f);play.lineTo(x-s*.015f,y);play.close();c.drawPath(play,p);if(!reduce&&isShown())postInvalidateOnAnimation();}
}
