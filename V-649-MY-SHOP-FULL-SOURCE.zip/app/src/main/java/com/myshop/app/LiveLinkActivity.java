package com.myshop.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

/** Routes a shared live link through login without losing the session identity. */
public final class LiveLinkActivity extends Activity {
    @Override public void onCreate(Bundle b){super.onCreate(b);route();}
    private void route(){
        Uri uri=getIntent().getData();String host=uri==null?"":uri.getQueryParameter("hostId"),session=uri==null?"":uri.getQueryParameter("sessionId");
        if(host==null||!host.matches("[0-9]{4}")||session==null||session.isEmpty()||session.length()>160){Toast.makeText(this,"এই লাইভ লিংক সঠিক নয়",Toast.LENGTH_LONG).show();finish();return;}
        if(!SessionManager.hasUsableSession(this)){getSharedPreferences("pending_live_link",MODE_PRIVATE).edit().putString("hostId",host).putString("sessionId",session).apply();startActivity(new Intent(this,LoginActivity.class));finish();return;}
        open(this,host,session);finish();
    }
    static void resumePending(Activity a){android.content.SharedPreferences p=a.getSharedPreferences("pending_live_link",MODE_PRIVATE);String host=p.getString("hostId",""),session=p.getString("sessionId","");if(!host.isEmpty()&&!session.isEmpty()&&SessionManager.hasUsableSession(a)){p.edit().clear().apply();open(a,host,session);}}
    private static void open(Activity a,String host,String session){a.startActivity(new Intent(a,AudioLiveRoomActivity.class).putExtra("hostId",host).putExtra("sharedSessionId",session).putExtra("fromNotification",true));}
}
