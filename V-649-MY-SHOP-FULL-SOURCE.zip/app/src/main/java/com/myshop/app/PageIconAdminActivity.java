package com.myshop.app;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;

/** V-430: real compact icon grid -> long press -> insert at slot -> atomic publish. */
public class PageIconAdminActivity extends AppCompatActivity {
    private final int NAVY=Color.rgb(24,34,70), BLUE=Color.rgb(31,93,235), RED=Color.rgb(216,35,56);
    private String page="home1";
    private final ArrayList<Item> items=new ArrayList<>();
    private GridLayout grid;
    private ScrollView scroll;
    private TextView status,save;
    private boolean dirty=false,saving=false,loaded=false;
    private int columns=4;
    private static final class Item {
        String key,title,url="",icon="";
        int order,size=38;
        boolean active;
        Item(String k,String t,int o,boolean a){key=k;title=t;order=o;active=a;}
    }
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if(!SessionManager.isAdmin(this)||!SessionManager.isAdminGateUnlocked()){finish();return;}
        if("live2".equals(getIntent().getStringExtra("page")))page="live2";
        defaults(); build(); load();
    }
    private void defaults(){
        String[] names="live2".equals(page)?new String[]{"Music","Chat & Talk","Talent","Friendship","Gaming","Shopping","PK Battle","More","New Link 9","New Link 10","New Link 11","New Link 12","New Link 13","New Link 14","New Link 15","New Link 16"}:new String[]{"Page","Website","My Level","Membership","Earn Rewards","Gallery +","External Media","Help Center","Top Up","Share App","My Invite","General","Live TV","Follow Us","New Link 15","New Link 16","New Link 17","New Link 18","New Link 19","New Link 20"};
        String[] suffixes="live2".equals(page)?new String[]{"music","chat","talent","friendship","gaming","shopping","pk","more","custom_09","custom_10","custom_11","custom_12","custom_13","custom_14","custom_15","custom_16"}:new String[]{"page","website","level","membership","rewards","gallery","external","help","topup","share","my_invite","general","live_tv","follow_us","custom_15","custom_16","custom_17","custom_18","custom_19","custom_20"};
        for(int i=0;i<names.length;i++)items.add(new Item(page+"_"+suffixes[i],names[i],i+1,i<("live2".equals(page)?8:14)));
    }
    private void build(){
        LinearLayout root=column();root.setPadding(dp(12),dp(8),dp(12),dp(8));root.setBackgroundColor(Color.rgb(248,250,255));
        root.setOnApplyWindowInsetsListener((v,in)->{v.setPadding(dp(12),Math.max(dp(8),in.getSystemWindowInsetTop()),dp(12),Math.max(dp(8),in.getSystemWindowInsetBottom()));return in;});
        TextView head=text("‹  "+("live2".equals(page)?"PAGE 2 ICONS":"QUICK LINKS"),18,NAVY,true);head.setOnClickListener(v->onBackPressed());root.addView(head,lp(-1,dp(44)));
        TextView guide=text("চেপে ধরে টানুন → পছন্দের আইকনের ঘরে ছাড়ুন। অন্য আইকনগুলো সরে যাবে। Edit করতে একবার চাপুন।",12,NAVY,false);guide.setPadding(dp(4),dp(6),dp(4),dp(6));root.addView(guide,lp(-1,-2));
        status=text("Loading saved positions…",11,BLUE,true);root.addView(status,lp(-1,dp(32)));
        TextView add=button("＋ ADD ICON",RED);add.setOnClickListener(v->addItem());root.addView(add,lp(-1,dp(44)));
        scroll=new ScrollView(this);scroll.setFillViewport(true);grid=new GridLayout(this);columns=getResources().getConfiguration().screenWidthDp>=600?6:4;grid.setColumnCount(columns);grid.setPadding(0,dp(8),0,dp(12));scroll.addView(grid,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView preview=button("PREVIEW USER ICONS",BLUE);preview.setOnClickListener(v->preview());root.addView(preview,lp(-1,dp(42)));
        TextView cancel=button("CANCEL",NAVY);cancel.setOnClickListener(v->onBackPressed());root.addView(cancel,lp(-1,dp(42)));
        save=button("SAVE ORDER / PUBLISH",BLUE);save.setOnClickListener(v->publish());root.addView(save,lp(-1,dp(48)));
        setContentView(root);root.post(root::requestApplyInsets);render();
    }
    private void render(){
        grid.removeAllViews();
        for(int pos=0;pos<items.size();pos++){
            final Item item=items.get(pos);
            LinearLayout tile=column();tile.setGravity(Gravity.CENTER);tile.setPadding(dp(3),dp(4),dp(3),dp(4));tile.setBackground(bg(Color.WHITE,12));tile.setElevation(dp(2));tile.setAlpha(item.active?1f:.48f);tile.setTag(item.key);
            ImageView icon=new ImageView(this);icon.setImageResource(iconResource(item.key));icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);if(!item.icon.isEmpty()){if(!"home1".equals(page)||!IconAsset.emoji(icon,item.icon))AnimatedAssetLoader.load(icon,item.icon);}tile.addView(icon,lp(dp(item.size),dp(item.size)));
            TextView name=text(item.title,10,NAVY,true);name.setGravity(Gravity.CENTER);name.setMaxLines(2);name.setEllipsize(TextUtils.TruncateAt.END);tile.addView(name,lp(-1,dp(30)));
            TextView slot=text("#"+(pos+1)+(item.active?"":" · Hidden"),9,BLUE,false);slot.setGravity(Gravity.CENTER);tile.addView(slot,lp(-1,dp(16)));
            tile.setContentDescription(item.title+", position "+(pos+1)+", hold to move, tap to edit");
            tile.setOnClickListener(v->{if(loaded&&!saving)edit(item);});
            tile.setOnLongClickListener(v->{if(!loaded||saving)return false;if(!item.active){toast("Enable this hidden icon before moving it");return false;}boolean started=v.startDragAndDrop(ClipData.newPlainText("myshop-icon",item.key),new View.DragShadowBuilder(v),item.key,0);if(started){status.setText("টেনে পছন্দের ঘরে ছাড়ুন • "+item.title);v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);}return started;});
            tile.setOnDragListener((v,e)->{
                if(!(e.getLocalState() instanceof String))return false;
                switch(e.getAction()){
                    case DragEvent.ACTION_DRAG_STARTED:return true;
                    case DragEvent.ACTION_DRAG_ENTERED:v.setBackground(bg(Color.rgb(214,229,255),12));return true;
                    case DragEvent.ACTION_DRAG_LOCATION:{int[] xy=new int[2];v.getLocationOnScreen(xy);int[] sy=new int[2];scroll.getLocationOnScreen(sy);float y=xy[1]+e.getY()-sy[1];if(y<dp(50))scroll.smoothScrollBy(0,-dp(26));else if(y>scroll.getHeight()-dp(50))scroll.smoothScrollBy(0,dp(26));return true;}
                    case DragEvent.ACTION_DRAG_EXITED:v.setBackground(bg(Color.WHITE,12));return true;
                    case DragEvent.ACTION_DROP:{if(!item.active)return false;int from=index((String)e.getLocalState()),to=index(item.key);if(SlotOrder.move(items,from,to)){normalize();dirty=true;status.setText("Position changed — SAVE ORDER চাপুন");grid.post(this::render);}return true;}
                    case DragEvent.ACTION_DRAG_ENDED:v.setBackground(bg(Color.WHITE,12));return true;
                    default:return true;
                }
            });
            GridLayout.LayoutParams params=new GridLayout.LayoutParams(GridLayout.spec(pos/columns),GridLayout.spec(pos%columns,1f));params.width=0;params.height=dp("home1".equals(page)?Math.max(96,item.size+58):96);params.setMargins(dp(3),dp(3),dp(3),dp(3));grid.addView(tile,params);
        }
    }
    private void preview(){LinearLayout list=column();GridLayout g=new GridLayout(this);g.setColumnCount(5);int n=0;for(Item item:items){if(!item.active)continue;LinearLayout tile=column();tile.setGravity(Gravity.CENTER);ImageView icon=new ImageView(this);icon.setImageResource(iconResource(item.key));if(!item.icon.isEmpty()&&!IconAsset.emoji(icon,item.icon))SafeImageLoader.load(icon,item.icon);tile.addView(icon,lp(dp(item.size),dp(item.size)));TextView label=text(item.title,9,NAVY,true);label.setMaxLines(2);label.setGravity(Gravity.CENTER);tile.addView(label,lp(-1,dp(30)));GridLayout.LayoutParams p=new GridLayout.LayoutParams(GridLayout.spec(n/5),GridLayout.spec(n%5,1f));p.width=0;p.height=dp("home1".equals(page)?Math.max(78,item.size+38):78);g.addView(tile,p);n++;}list.addView(g);new MyShopDialogBuilder(this).setTitle("Preview · unsaved draft").setView(list).setPositiveButton(UiStrings.label(PageIconAdminActivity.this,"Close"),null).show();}
    private int index(String key){for(int i=0;i<items.size();i++)if(items.get(i).key.equals(key))return i;return -1;}
    private void normalize(){Collections.sort(items,(a,b)->Boolean.compare(b.active,a.active));for(int i=0;i<items.size();i++)items.get(i).order=i+1;}
    private void addItem(){if(!loaded||saving)return;for(Item item:new ArrayList<>(items))if(!item.active&&item.key.contains("custom_")){items.remove(item);items.add(item);item.active=true;normalize();dirty=true;edit(item);render();return;}toast("All configured slots are in use. Edit or enable a hidden icon.");}
    private EditText field(String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setTextSize(13);e.setSingleLine(true);return e;}
    private void edit(Item item){
        if("home1".equals(page)&&!item.key.contains("live")){new MyShopDialogBuilder(this).setTitle("এডমিন প্যানেল • "+item.title).setItems(new String[]{"নাম / আইকন / ইমোজি / লিংক / Coming Soon", "আইকন মাপ / অবস্থান / Show–Hide", "লেখার রং / গ্রেডিয়েন্ট / ফন্ট মাপ"},(dialog,which)->{if(which==0)startActivity(new Intent(this,AdminSectionActivity.class).putExtra("section","feature_card").putExtra("managed_category","feature_"+item.key).putExtra("managed_title",item.title).putExtra("admin_context",true));else if(which==1)editLayout(item);else startActivity(new Intent(this,MainActivity.class).putExtra("open_design_scope","home_quick"));}).show();return;}editLayout(item);
    }
    private void editLayout(Item item){
        LinearLayout form=column();form.setPadding(dp(16),dp(4),dp(16),dp(8));EditText title=field("Icon name",item.title),url=field("Link / target",item.url),icon=field("ছবির লিংক বা emoji:🌟 লিখুন",item.icon),size=field("Display size 28–56 dp",String.valueOf(item.size));size.setInputType(InputType.TYPE_CLASS_NUMBER);if(!"home1".equals(page)||item.key.contains("live")){form.addView(title);form.addView(url);form.addView(icon);}form.addView(size);CheckBox show=new CheckBox(this);show.setText("Published / visible");show.setChecked(item.active);form.addView(show);if("home1".equals(page)&&!item.key.contains("live")){Button controls=new Button(this);controls.setText("এডমিন প্যানেল • Coming Soon / Draft / Publish / Delete");controls.setOnClickListener(v->startActivity(new Intent(this,AdminSectionActivity.class).putExtra("section","feature_card").putExtra("managed_category","feature_"+item.key).putExtra("managed_title",item.title).putExtra("admin_context",true)));form.addView(controls);Button design=new Button(this);design.setText("লেখার রং / গ্রেডিয়েন্ট / ফন্ট মাপ");design.setOnClickListener(v->startActivity(new Intent(this,MainActivity.class).putExtra("open_design_scope","home_quick")));form.addView(design);}
        AlertDialog dialog=new MyShopDialogBuilder(this).setTitle("Edit "+item.title).setView(form).setPositiveButton("APPLY TO DRAFT",null).setNeutralButton("DELETE / HIDE",(d,w)->new MyShopDialogBuilder(this).setTitle("Remove this icon?").setMessage("User screens থেকে সরবে। Save Order চাপলে স্থায়ী হবে; app update-এ নিজে থেকে ফিরবে না।").setPositiveButton("REMOVE",(a,b)->{item.active=false;normalize();dirty=true;status.setText("Removed in draft — SAVE ORDER চাপুন");render();}).setNegativeButton("CANCEL",null).show()).setNegativeButton("CANCEL",null).create();
        dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String name=title.getText().toString().trim();if(name.isEmpty()){title.setError("Name required");return;}item.title=name;item.url=url.getText().toString().trim();item.icon=icon.getText().toString().trim();try{item.size=Math.max(28,Math.min(56,Integer.parseInt(size.getText().toString().trim())));}catch(Exception ignored){}item.active=show.isChecked();normalize();dirty=true;render();status.setText("Draft changed — SAVE ORDER চাপুন");dialog.dismiss();}));dialog.show();
    }
    private void load(){BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{if(isFinishing()||dirty)return;JSONArray data=d.optJSONArray("featureButtons");if(data!=null)for(int i=0;i<data.length();i++){JSONObject x=data.optJSONObject(i);if(x==null)continue;int n=index(x.optString("key"));if(n<0)continue;Item item=items.get(n);item.title=x.optString("title",item.title);item.url=x.optString("target_url","");item.icon=x.optString("icon_url","");item.order=x.optInt("display_order",item.order);item.size=Math.max(28,Math.min(56,x.optInt("icon_size",38)));item.active=x.optInt("active",0)==1;}Collections.sort(items,(a,b)->{int c=Integer.compare(a.order,b.order);return c==0?a.key.compareTo(b.key):c;});normalize();loaded=true;render();status.setText("Saved order loaded • চেপে ধরে সাজান");});}public void onError(String m){runOnUiThread(()->{status.setText("Load failed — tap to retry");status.setOnClickListener(v->load());toast(m);});}});}
    private void publish(){
        if(!loaded||saving)return;
        try{normalize();JSONArray array=new JSONArray();for(Item i:items)array.put(new JSONObject().put("key",i.key).put("title",i.title).put("iconUrl",i.icon).put("targetUrl",i.url).put("active",i.active).put("displayOrder",i.order).put("iconSize",i.size));JSONObject payload=new JSONObject().put("orderPage",page).put("featureButtons",array);saving=true;save.setEnabled(false);status.setText("Saving exact positions…");BackendClient.adminContentPut(SessionManager.getToken(this),payload,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{saving=false;save.setEnabled(true);dirty=false;setResult(RESULT_OK);Intent changed=new Intent("com.myshop.app.CONTENT_CHANGED");changed.setPackage(getPackageName());sendBroadcast(changed);toast("Saved • Home + See All use this order");load();});}public void onError(String m){runOnUiThread(()->{saving=false;save.setEnabled(true);status.setText("Not saved. Your draft is kept — retry.");toast(m);});}});}catch(Exception e){toast("Could not prepare icon order");}
    }
    @Override protected void onResume(){super.onResume();if("home1".equals(page)&&loaded&&!dirty&&!saving)load();}
    @Override public void onBackPressed(){if(dirty&&!saving)new MyShopDialogBuilder(this).setTitle("Unsaved positions").setMessage("Save Order দিয়ে publish করুন, অথবা draft বাদ দিন।").setPositiveButton("SAVE",(d,w)->publish()).setNegativeButton("DISCARD",(d,w)->finish()).setNeutralButton("CONTINUE EDITING",null).show();else if(!saving)super.onBackPressed();}
    private int iconResource(String key){if(key.contains("member")||key.contains("level"))return R.drawable.ui_admin_hd;if(key.contains("gallery"))return R.drawable.ui_gallery_hd;if(key.contains("live")||key.contains("music"))return R.drawable.ui_live_hd;if(key.contains("chat"))return R.drawable.ui_message_hd;if(key.contains("reward")||key.contains("invite"))return R.drawable.ui_reward_hd;if(key.contains("help"))return R.drawable.ui_support_hd;if(key.contains("share"))return R.drawable.ui_share_hd;if(key.contains("topup")||key.contains("shopping"))return R.drawable.ui_shop_hd;return R.drawable.ui_categories_hd;}
    private TextView text(String s,float z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private TextView button(String s,int c){TextView t=text(s,12,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setBackground(bg(c,12));return t;}
    private GradientDrawable bg(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
