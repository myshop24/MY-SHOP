package com.myshop.app;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.widget.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
/** Explicit preview for uploaded shortcut icons; photographs and Live assets excluded. */
final class IconUploadPreview {
 interface Ready{void image(ByteArrayInputStream bytes);}
 static Bitmap fitted(Bitmap original,boolean removeWhite){int w=original.getWidth(),h=original.getHeight();int[] p=new int[w*h];original.getPixels(p,0,w,0,0,w,h);p=IconPixels.prepare(p,w,h,removeWhite);int[] b=IconPixels.bounds(p,w,h);Bitmap clean=Bitmap.createBitmap(p,w,h,Bitmap.Config.ARGB_8888);Bitmap crop=Bitmap.createBitmap(clean,b[0],b[1],b[2],b[3]);if(crop!=clean)clean.recycle();return crop;}
 static void show(Activity a,Bitmap original,Ready ready){
  LinearLayout box=new LinearLayout(a);box.setOrientation(1);int d=Math.round(a.getResources().getDisplayMetrics().density);box.setPadding(12*d,8*d,12*d,8*d);
  TextView hint=new TextView(a);hint.setText("আইকনের অনুপাত ঠিক থাকবে। বাইরের সাদা অংশ সরালে ভেতরের সাদা লেখা থাকবে। Preview মিলিয়ে আপলোড করুন।");box.addView(hint);
  CheckBox remove=new CheckBox(a);remove.setText("চারপাশের সাদা / হালকা ব্যাকগ্রাউন্ড সরান");remove.setChecked(true);box.addView(remove);
  LinearLayout examples=new LinearLayout(a);ImageView before=new ImageView(a),after=new ImageView(a);before.setImageBitmap(original);before.setScaleType(ImageView.ScaleType.FIT_CENTER);after.setScaleType(ImageView.ScaleType.FIT_CENTER);before.setBackgroundColor(0xff232650);after.setBackgroundColor(0xff232650);examples.addView(before,new LinearLayout.LayoutParams(0,120*d,1));examples.addView(after,new LinearLayout.LayoutParams(0,120*d,1));box.addView(examples);final Bitmap[] result={fitted(original,true)};after.setImageBitmap(result[0]);remove.setOnCheckedChangeListener((v,c)->{Bitmap old=result[0];result[0]=fitted(original,c);after.setImageBitmap(result[0]);old.recycle();});
  new MyShopDialogBuilder(a).setTitle("আগের ছবি → আইকনের Preview").setView(box).setNegativeButton(UiStrings.ui636("বাতিল"),null).setPositiveButton("এই আইকন আপলোড করুন",(dialog,n)->{ByteArrayOutputStream bytes=new ByteArrayOutputStream();result[0].compress(Bitmap.CompressFormat.PNG,100,bytes);ready.image(new ByteArrayInputStream(bytes.toByteArray()));}).setOnDismissListener(dialog->{result[0].recycle();original.recycle();}).show();
 }
 private IconUploadPreview(){}
}
