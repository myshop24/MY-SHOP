package com.myshop.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

/** V-533 Google OAuth: obtains a Google ID token and exchanges it for a myshop backend session. */
public final class GoogleAuth {
    public static final int REQUEST_CODE=5331;
    public static final int DELETE_REAUTH_REQUEST_CODE=5721;
    private GoogleAuth(){}

    public static void startDeletionReauthentication(Activity a){
        if(BuildConfig.GOOGLE_WEB_CLIENT_ID==null||BuildConfig.GOOGLE_WEB_CLIENT_ID.trim().isEmpty()){
            Toast.makeText(a,"Google verification is not configured.",Toast.LENGTH_LONG).show();return;
        }
        GoogleSignInOptions options=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail().requestIdToken(BuildConfig.GOOGLE_WEB_CLIENT_ID).build();
        GoogleSignInClient client=GoogleSignIn.getClient(a,options);
        client.signOut().addOnCompleteListener(done->{if(!a.isFinishing())a.startActivityForResult(client.getSignInIntent(),DELETE_REAUTH_REQUEST_CODE);});
    }

    public static String deletionVerificationToken(Intent data) throws ApiException {
        GoogleSignInAccount account=GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException.class);
        return account==null?null:account.getIdToken();
    }

    public static void start(Activity a){
        if(BuildConfig.GOOGLE_WEB_CLIENT_ID==null||BuildConfig.GOOGLE_WEB_CLIENT_ID.trim().isEmpty()){
            Toast.makeText(a,"Google Login is not configured in this build.",Toast.LENGTH_LONG).show();return;
        }
        GoogleSignInOptions gso=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail().requestProfile().requestIdToken(BuildConfig.GOOGLE_WEB_CLIENT_ID).build();
        GoogleSignInClient c=GoogleSignIn.getClient(a,gso);
        // Always show account choice so testers can use either allowed Google account.
        c.signOut().addOnCompleteListener(x->a.startActivityForResult(c.getSignInIntent(),REQUEST_CODE));
    }

    public static boolean handle(Activity a,int requestCode,Intent data){
        if(requestCode!=REQUEST_CODE)return false;
        Task<GoogleSignInAccount> task=GoogleSignIn.getSignedInAccountFromIntent(data);
        try{
            GoogleSignInAccount acct=task.getResult(ApiException.class);
            String idToken=acct==null?null:acct.getIdToken();
            if(idToken==null||idToken.trim().isEmpty()){Toast.makeText(a,"Google did not return a valid login token.",Toast.LENGTH_LONG).show();return true;}
            BackendClient.googleLogin(idToken,new BackendClient.Callback(){
                public void onSuccess(org.json.JSONObject result){
                    try{
                        org.json.JSONObject u=result.getJSONObject("user");
                        Role role=Role.valueOf(u.optString("role","USER"));
                        String uid=u.optString("userId","");
                        SessionManager.setRemoteSession(a,result.optString("token",""),role,uid);
                        SessionManager.saveProfile(a,u.optString("name",""),u.optString("email",""),u.optString("mobile",""),u.optString("avatarUrl",""),u.optString("coverUrl",""),u.optString("bio",""));
                        PushRegistration.sync(a);
                        Intent i=new Intent(a,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);a.startActivity(i);a.finish();
                    }catch(Exception e){Toast.makeText(a,"Google login response was invalid.",Toast.LENGTH_LONG).show();}
                }
                public void onError(String message){Toast.makeText(a,message,Toast.LENGTH_LONG).show();}
            });
        }catch(ApiException e){Toast.makeText(a,"Google Login failed ("+e.getStatusCode()+").",Toast.LENGTH_LONG).show();}
        return true;
    }
}
