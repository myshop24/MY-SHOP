package com.myshop.app;
import android.content.Intent;import android.os.Bundle;import android.widget.*;
/** One visible inventory of all existing banner editors; no banner data is deleted. */
public class BannerManager633Activity extends androidx.appcompat.app.AppCompatActivity {
 private LinearLayout body;private String tr(String b,String e){return LanguageManager.BN.equals(LanguageManager.get(this))?b:e;}
 protected void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)||!SessionManager.isAdminGateUnlocked()){finish();return;}ScrollView sc=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(1);body.setPadding(16,16,16,24);sc.addView(body);setContentView(sc);TextView title=new TextView(this);title.setText(tr("ব্যানার ম্যানেজার","Banner Manager"));title.setTextSize(24);body.addView(title);
 add(tr("হোম সাজান—ধরে টানুন ও কনফার্ম করুন","Arrange Home — drag, preview and confirm"),new Intent(this,MainActivity.class).putExtra("home_layout_preview632",true));
 add(tr("হোম • বিজ্ঞাপন লাইন ১ ও প্রমো লাইন ২","Home • Advertising row 1 & Promo row 2"),new Intent(this,BannerAdminActivity.class));
 add(tr("হোম • আপকামিং লাইভ","Home • Upcoming Live"),new Intent(this,UpcomingLiveAdminActivity.class).putExtra("upcoming_scope","home"));
 add(tr("লাইভ পেইজ • বিজ্ঞাপন","Live page • Advertising"),new Intent(this,LiveHomeAdminActivity.class));
 add(tr("লাইভ পেইজ • আপকামিং লাইভ","Live page • Upcoming Live"),new Intent(this,UpcomingLiveAdminActivity.class).putExtra("upcoming_scope","live"));
 add(tr("মাইশপ • বিজ্ঞাপন লাইন ১","Shop • Advertising row 1"),new Intent(this,LiveHomeAdminActivity.class).putExtra("folder","shop_home"));
 add(tr("মাইশপ • প্রমো লাইন ২","Shop • Promo row 2"),new Intent(this,LiveHomeAdminActivity.class).putExtra("folder","shop_promo"));
 add(tr("অন্যান্য বিজ্ঞাপন","Other advertisements"),new Intent(this,DashboardAdsAdminActivity.class));add(tr("অ্যাপ ওপেন বিজ্ঞাপন","Startup advertisement"),new Intent(this,DashboardAdsAdminActivity.class).putExtra("box_key","startup_ad"));Button back=new Button(this);back.setText(tr("ফিরে যান","Back"));back.setOnClickListener(v->finish());body.addView(back);sc.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(i.getSystemWindowInsetLeft(),i.getSystemWindowInsetTop(),i.getSystemWindowInsetRight(),i.getSystemWindowInsetBottom());return i;});sc.requestApplyInsets();}
 private void add(String title,Intent intent){Button b=new Button(this);b.setAllCaps(false);b.setText(title);body.addView(b);b.setOnClickListener(v->startActivity(intent.putExtra("admin_context",true)));}
}
