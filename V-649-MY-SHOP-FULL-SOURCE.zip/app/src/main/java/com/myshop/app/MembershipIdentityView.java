package com.myshop.app;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.*;
import java.io.InputStream;
import java.util.concurrent.*;

/** One video-derived identity renderer shared by catalog, profile and Live. */
public final class MembershipIdentityView extends FrameLayout {
    private final ImageView photo;
    private final String tier,avatarSource;
    private String frameSource="";
    private final FrameAnimation reference;private ImageView customFrame;private boolean custom;
    private float cx=.50f, cy=.48f, radius=.265f;
    private long expiresAt;private Runnable expiryAction;
    private final Runnable expiryTick=new Runnable(){public void run(){
        if(expiresAt<=0)return;long remaining=expiresAt-System.currentTimeMillis();
        if(remaining<=0){expiresAt=0;if(expiryAction!=null)expiryAction.run();}
        else postDelayed(this,Math.min(remaining,86400000L));
    }};
    public MembershipIdentityView(Context context,String code,String avatarUrl){
        super(context);avatarSource=avatarUrl==null?"":avatarUrl;tier="TOP1".equals(code)?"TOP1":MembershipUi.tier(code);
        setClipChildren(false);setClipToPadding(false);
        switch(tier){case "ROYAL":cy=.49f;radius=.275f;break;case "VVIP":radius=.245f;break;case "VIP":cy=.535f;radius=.205f;break;case "TOP1":cy=.47f;radius=.23f;break;}
        photo=new ImageView(context);photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        photo.setImageResource(R.drawable.myshop_profile_avatar);
        GradientDrawable circle=new GradientDrawable();circle.setShape(GradientDrawable.OVAL);circle.setColor(0xFF15253E);
        photo.setBackground(circle);photo.setClipToOutline(true);addView(photo,new LayoutParams(1,1));
        if(avatarUrl!=null&&!avatarUrl.trim().isEmpty())CachedImages.load(photo,avatarUrl);
        reference=new FrameAnimation(context,tier);addView(reference,new LayoutParams(-1,-1));
        setContentDescription(tier+" animated frame with profile photo");
    }
    public boolean matches(String code,String url,String asset){return tier.equals("TOP1".equalsIgnoreCase(code)?"TOP1":MembershipUi.tier(code))&&avatarSource.equals(url==null?"":url)&&frameSource.equals(asset==null?"":asset.trim());}
    public void setExpiry(String value,Runnable action){
        removeCallbacks(expiryTick);expiresAt=0;expiryAction=action;
        try{String date=value==null?"":value.trim().replace('T',' ');if(date.length()>=19){
            java.text.SimpleDateFormat format=new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",java.util.Locale.US);
            format.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));expiresAt=format.parse(date.substring(0,19)).getTime();
        }}catch(Exception ignored){}
        if(expiresAt>0)post(expiryTick);
    }
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();removeCallbacks(expiryTick);if(expiresAt>0)post(expiryTick);}
    @Override protected void onDetachedFromWindow(){removeCallbacks(expiryTick);super.onDetachedFromWindow();}
    public void setPortraitBitmap(Bitmap bitmap){if(bitmap!=null)photo.setImageBitmap(bitmap);}
    public void setDemo(){setContentDescription(tier+" membership preview with your photo");}
    /** V603 approved video identity supersedes legacy still-photo frame overrides.
     * Saved Admin URLs stay in the database; no catalog/entitlement record is deleted. */
    public void setFrameAsset(String url){frameSource=url==null?"":url.trim();}
    @Override protected void onLayout(boolean changed,int left,int top,int right,int bottom){
        super.onLayout(changed,left,top,right,bottom);
        int w=right-left,h=bottom-top;float side=Math.min(w,h);
        int size=Math.max(1,Math.round(radius*2*side));
        int x=Math.round((w-side)/2+(cx-radius)*side),y=Math.round((h-side)/2+(cy-radius)*side);
        photo.measure(View.MeasureSpec.makeMeasureSpec(size,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(size,View.MeasureSpec.EXACTLY));photo.layout(x,y,x+size,y+size);
    }
    @Override protected void onSizeChanged(int w,int h,int ow,int oh){
        super.onSizeChanged(w,h,ow,oh);layoutPortrait(w,h);
    }
    private void layoutPortrait(int w,int h){
        if(custom){float x=168,y=139,r=88;switch(tier){case "KING":x=166;y=139;r=83;break;case "QUEEN":x=165;y=141;r=84;break;case "ROYAL":x=168;y=136;r=85;break;case "VVIP":y=141;break;}
            float scale=Math.min(w/320f,h/275f);LayoutParams p=new LayoutParams(Math.round(r*2*scale)+2,Math.round(r*2*scale)+2);
            p.leftMargin=Math.round((w-320*scale)/2+(x-r)*scale)-1;p.topMargin=Math.round((h-275*scale)/2+(y-r)*scale)-1;photo.setLayoutParams(p);return;}
        float s=Math.min(w,h),left=(w-s)/2,top=(h-s)/2;
        LayoutParams p=new LayoutParams(Math.round(radius*2*s)+2,Math.round(radius*2*s)+2);
        p.leftMargin=Math.round(left+(cx-radius)*s)-1;p.topMargin=Math.round(top+(cy-radius)*s)-1;photo.setLayoutParams(p);
    }
    private static final class FrameAnimation extends View {
        private static final ConcurrentHashMap<String,byte[]> CACHE=new ConcurrentHashMap<>();
        private static final ExecutorService IO=Executors.newFixedThreadPool(2);
        private Movie movie;private android.graphics.drawable.Drawable modern;private final String key;private boolean reduce;private int requestedSize,decodeGeneration;private final long animationEpoch=android.os.SystemClock.uptimeMillis();
        FrameAnimation(Context c,String tier){super(c);key=tier.toLowerCase(java.util.Locale.US);updatePreference();if(android.os.Build.VERSION.SDK_INT<28)loadLegacy();}
        private void updatePreference(){reduce=false;}
        private void loadModern(){
            if(android.os.Build.VERSION.SDK_INT<28||getWidth()<=0||getHeight()<=0)return;if(!android.animation.ValueAnimator.areAnimatorsEnabled()){if(requestedSize!=1){requestedSize=1;loadLegacy();}return;}
            final int target=Math.max(64,Math.min(512,Math.min(getWidth(),getHeight())));if(requestedSize==target)return;requestedSize=target;final int generation=++decodeGeneration;
            IO.execute(()->{try{
                android.graphics.drawable.Drawable decoded=android.graphics.ImageDecoder.decodeDrawable(android.graphics.ImageDecoder.createSource(getContext().getApplicationContext().getAssets(),"membership_v603/"+key+".webp"),(decoder,info,source)->decoder.setTargetSize(target,target));
                if(!(decoded instanceof android.graphics.drawable.AnimatedImageDrawable)){loadLegacy();return;}
                post(()->{if(generation!=decodeGeneration)return;if(modern instanceof android.graphics.drawable.AnimatedImageDrawable)((android.graphics.drawable.AnimatedImageDrawable)modern).stop();modern=decoded;movie=null;setLayerType(View.LAYER_TYPE_NONE,null);modern.setCallback(this);((android.graphics.drawable.AnimatedImageDrawable)modern).setRepeatCount(android.graphics.drawable.AnimatedImageDrawable.REPEAT_INFINITE);updatePreference();if(!reduce&&isAttachedToWindow())((android.graphics.drawable.AnimatedImageDrawable)modern).start();invalidate();});
            }catch(Exception|OutOfMemoryError failure){loadLegacy();}});
        }
        private void loadLegacy(){
            IO.execute(()->{try{byte[] bytes=CACHE.get(key);if(bytes==null){try(InputStream in=getContext().getApplicationContext().getAssets().open("membership_v603/"+key+".gif")){java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buffer=new byte[8192];int read;while((read=in.read(buffer))!=-1)out.write(buffer,0,read);bytes=out.toByteArray();CACHE.put(key,bytes);}}Movie decoded=Movie.decodeByteArray(bytes,0,bytes.length);if(decoded!=null)post(()->{if(android.os.Build.VERSION.SDK_INT>=28&&modern instanceof android.graphics.drawable.AnimatedImageDrawable)((android.graphics.drawable.AnimatedImageDrawable)modern).stop();if(modern!=null)modern.setCallback(null);movie=decoded;modern=null;setLayerType(View.LAYER_TYPE_SOFTWARE,null);invalidate();});}catch(Exception|OutOfMemoryError failure){android.util.Log.w("MYSHOP_MEMBER","Animation unavailable for "+key);}});
        }
        @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){super.onSizeChanged(w,h,oldw,oldh);loadModern();}
        @Override protected void onDraw(Canvas c){updatePreference();super.onDraw(c);boolean animate=!reduce&&isShown();if(modern!=null){int side=Math.min(getWidth(),getHeight()),x=(getWidth()-side)/2,y=(getHeight()-side)/2;modern.setBounds(x,y,x+side,y+side);modern.draw(c);android.graphics.drawable.AnimatedImageDrawable animation=(android.graphics.drawable.AnimatedImageDrawable)modern;if(animate&&!animation.isRunning())animation.start();else if(!animate&&animation.isRunning())animation.stop();if(animate)postInvalidateDelayed(42);return;}if(movie==null)return;float scale=Math.min(getWidth()/(float)movie.width(),getHeight()/(float)movie.height());int save=c.save();c.translate((getWidth()-movie.width()*scale)/2,(getHeight()-movie.height()*scale)/2);c.scale(scale,scale);movie.setTime(animate?(int)((android.os.SystemClock.uptimeMillis()-animationEpoch)%Math.max(1,movie.duration())):0);movie.draw(c,0,0);c.restoreToCount(save);if(animate)postInvalidateDelayed(42);}
        @Override public void onVisibilityAggregated(boolean visible){super.onVisibilityAggregated(visible);updatePreference();if(android.os.Build.VERSION.SDK_INT>=28&&modern instanceof android.graphics.drawable.AnimatedImageDrawable){if(visible&&!reduce)((android.graphics.drawable.AnimatedImageDrawable)modern).start();else ((android.graphics.drawable.AnimatedImageDrawable)modern).stop();}if(visible){loadModern();invalidate();}}
        @Override public void onWindowFocusChanged(boolean focus){super.onWindowFocusChanged(focus);if(focus){loadModern();invalidate();}}
        @Override protected void onWindowVisibilityChanged(int visibility){super.onWindowVisibilityChanged(visibility);if(visibility==View.VISIBLE){loadModern();invalidate();}}
        @Override protected boolean verifyDrawable(android.graphics.drawable.Drawable d){return d==modern||super.verifyDrawable(d);}
        @Override protected void onAttachedToWindow(){super.onAttachedToWindow();loadModern();updatePreference();if(android.os.Build.VERSION.SDK_INT>=28&&modern instanceof android.graphics.drawable.AnimatedImageDrawable&&!reduce)((android.graphics.drawable.AnimatedImageDrawable)modern).start();invalidate();}
        @Override protected void onDetachedFromWindow(){if(android.os.Build.VERSION.SDK_INT>=28&&modern instanceof android.graphics.drawable.AnimatedImageDrawable)((android.graphics.drawable.AnimatedImageDrawable)modern).stop();super.onDetachedFromWindow();}
    }
}
