# MY SHOP V-537 — পরবর্তী Developer-এর জন্য Handoff

## Source identity

- Base archive: V-536.
- Working source: V-537 / 2.9.537 / Android versionCode 537.
- V-537 source ZIP ইউজারের সরাসরি অনুরোধে দেওয়া হচ্ছে; Android/device acceptance pending। আগের ZIP overwrite করা যাবে না।
- Locked checklist: `MY-SHOP-V537-REQUIREMENTS-CHECKLIST-BN.md`.
- Change log: `V-537-CHANGES-BN.md`.
- GitHub release setup: `MY-SHOP-V537-RELEASE-SETUP-BN.md`.

## Work completed so far

All 16 requested feature corrections have corresponding source changes. The checklist marks device/build dependent checks as pending. A profile Social Links render crash and public profile privacy leak found during the audit were fixed. The release workflow no longer publishes on source push, and the production Worker deploy now runs only after the matching signed APK passes verification.

## Local verification

- `node --check backend/worker/src/index.js`
- `node --test tests/*.test.mjs` — 41 local tests passed (commerce 25, inbox 12, Personal Details/social-link validation 4).
- Android XML, manifest activity classes, resource references and Java delimiter checks passed.
- `tools_verify_master.py` — 24 source/reference guard checks passed.
- `bash -n my-shop-release.sh` and GitHub Actions workflow gate/order checks passed.
- Last complete-source size check: about 24.27 MB, below 25,000,000 bytes.

## Required before calling it final

1. Run the private GitHub Actions QA build on the final source ZIP; fix any compile/resource error in the same V-537 working tree before any accepted release.
2. Install that QA APK on a real Android device. Compare More Apps, General/Live menu, History, Messenger, Profile, and Personal Details against the supplied references.
3. Check message and Live push while app backgrounded and swiped away; verify the notification opens the correct chat/room.
4. Validate production D1 migrations/permissions for VAT, recovery, banner cleanup, profile details/social links and dynamic Live seats before production deployment.
5. Use two devices to test Host/Guest RTC audio, delay, mute/unmute, Join/Leave, comments, gifts, Vote/Love and Exit.
6. Re-run the regression suite, verify the delivered source ZIP identity, contents and <25 MB size; use the next sequential version for subsequent delivery.
7. Do not enable `publish_latest_apk`, deploy the Worker or change the permanent friends APK until the owner explicitly says `আপডেট দাও`.

No APK build, production deployment, public Release update, real-device push test, or RTC/audio acceptance is claimed in this handoff.
