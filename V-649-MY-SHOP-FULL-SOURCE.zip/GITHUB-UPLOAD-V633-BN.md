# V633 পূর্ণ সোর্স ZIP

১. V-633-MY-SHOP-FULL-SOURCE.zip ফাইলটি না খুলে আগের myshop24/MY-SHOP রিপোজিটরির মূল জায়গায় main ব্রাঞ্চে আপলোড করুন।
২. আগের স্থায়ী MY SHOP PERMANENT RELEASE PIPELINE এবং Signing Secrets রাখুন।
৩. Actions-এ WORKER VERIFY -> APK সফল হওয়া পর্যন্ত অপেক্ষা করুন। Pages build সফল হওয়া APK build নয়।
৪. সফল হলে MY-SHOP-FINAL-V-633 artifact থেকে MY_SHOP_FINAL_RELEASE.apk নিন।
৫. SOURCE_BUILD_ID MY SHOP V-633, versionCode633 এবং versionName2.9.633 মিলিয়ে নিন।

এই ZIP-এ APK নেই। এখানে Gradle ডাউনলোডের নেটওয়ার্ক সীমাবদ্ধতায় Android বিল্ড শেষ হয়নি; GitHub Android build সফল হলে APK পাবেন।

এডমিন → লাইভ হিসাব মনিটর: বর্তমান ব্যালেন্স ও রেকর্ডভিত্তিক হিসাব।
এডমিন → হোম ডিজাইন ও ব্যানার → ব্যানার ম্যানেজার / হোম সাজান।
এডমিন → মাইশপ কমিশন কয়েন & ডায়মন্ড → হাইলাইট কমেন্ট ফি ও হোস্ট কমিশন।

পুরোনো হিসাবে পার্থক্য দেখালে সেটি যাচাই প্রয়োজন; অটো ব্যালেন্স সংশোধন করা হয় না। ডিলিট করা প্রমো ছবি থাকলে নতুন করে আপলোড করুন।
