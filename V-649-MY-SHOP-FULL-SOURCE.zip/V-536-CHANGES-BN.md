# V-536 Changes (BN)

## Working batch — numbered user instructions
- #1 Splash branding: `myshop` একসাথে lowercase; `my` gold + `shop` silver.
- #2 Registration: Email Address field restored and validated; mobile remains available as optional recovery/contact field.
- #3 Bottom More Apps: experimental popup path removed; stable More Apps navigation now opens the dedicated User Menu, with stable grid icon resource on Home + Live Page 2.
- #9 Main Admin Account Recovery: email + mobile edit, recovery history summary, and Main Admin temporary password reset added. Password reset revokes old sessions; user must change the temporary password from Settings after login. Password/security answers are never displayed.

## Regression / security notes
- Permanent 4-digit User ID remains immutable.
- Recovery actions are server-authorized for Main Admin IDs 0001/0002/0003 and audited.
- Existing V-535 features remain locked unless explicitly changed above.

## Still pending in the numbered master list
- #4 reference icon/menu visual reconciliation
- #5 Messenger-style realtime presence accuracy
- device push delivery verification
- #8 MY SHOP VAT (non-ecommerce scope)
- #10 History reference parity
- #11 Live Room 8-item correction batch + real two-device RTC verification
- #12 profile social-link launcher row
- #13 deleted banner slot/cache + scroll behavior
- Messenger redesign
- #15 locked profile reference implementation
- Personal Details optional-field module
