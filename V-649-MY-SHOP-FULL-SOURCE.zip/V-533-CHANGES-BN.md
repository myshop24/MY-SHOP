# MY SHOP V-533 — Locked delivery scope

1. Google Login: real Google OAuth button on Login/Register, Android Web Client ID configured, backend verifies Google ID token audience/issuer/email verification and creates/links a MY SHOP session.
2. Full self-contained source: this ZIP contains Android app, backend Worker, workflow, release script, download page and release documentation. No older V ZIP is required by the build source.
3. Friends permanent download: https://myshop24.github.io/MY-SHOP/download.html. Successful release replaces the fixed `friends-latest` APK asset; the public page URL does not change. No automatic update notification is sent to users.
4. Device notification: preserves FCM client/server path, Android 13+ POST_NOTIFICATIONS request, notification channels, token registration, message/live deep links. Release script fails if required Firebase client secrets or Worker FCM server secret are missing.
5. Online/offline: foreground heartbeat and immediate background offline publication retained; backend stale-online TTL standardized to 45 seconds to recover from killed/crashed apps without permanent false-online state.

Security: Google OAuth client secret is NOT embedded in the Android app/source. The Web Client ID is public configuration, not a secret.
