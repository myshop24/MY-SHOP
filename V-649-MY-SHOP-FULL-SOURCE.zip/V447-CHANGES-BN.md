# MY SHOP V-447 — Live 5+5 Final Alignment

## এই ব্যাচে বাস্তবায়িত
- সাধারণ Guest Seat এখন স্থায়ী ৫+৫ = ১০টি (seat_no 2..11); Host ও Main Guest আলাদা।
- ১০টি empty/occupied normal seat সবসময় দুই সারিতে ৫টি করে render হয়।
- Music control শুধু Host-এর right action rail-এ থাকে; Guest/Audience-এ Music-এর খালি slot নেই।
- Mic control right action rail-এ Music-এর নিচে (Host) / একই top position-এ (Guest/Audience)।
- Audience Mic control এখন live playback mute/unmute করে; Host/Speaker Mic publish mute/unmute আগের মতো থাকে।
- Bottom composer compact করা হয়েছে: comment → Send → Message → Join/Leave/End; duplicate Mic/Music সরানো হয়েছে।
- V-446 Music backend/catalog, Join/Invite, comments, gifts, RTC, Profile এবং অন্যান্য working modules অক্ষত রাখা হয়েছে।

## Verification note
Source-level regression/build checks run করতে হবে। Physical multi-device RTC/runtime verification ছাড়া runtime-complete দাবি করা যাবে না।
