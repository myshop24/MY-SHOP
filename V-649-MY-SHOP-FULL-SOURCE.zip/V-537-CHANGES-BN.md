# V-537 — Source Change Log

Base: V-536  
Identity: `MY SHOP V-537` / `2.9.537` / Android `versionCode 537`

## Implemented in the source

1. Kept the approved single-word `myshop` splash wordmark and branding from V-536.
2. Preserved the Create Account Email field and its recovery/login linkage from V-536.
3. Preserved More Apps crash/navigation corrections and restored the approved More Apps navigation icon. The home Quick Links sheet keeps its full source-defined list, not only the screenshot's first ten entries.
4. Reworked General and Live Page 2 menus into compact icon/name entries.
5. Cleared stale inbox online indicators until refreshed server presence arrives; profile and chat status use freshness and visibility rules.
6. Kept Messenger conversations backend-backed with latest activity, message previews, unread state and actual presence.
7. Added FCM data-message handling, Android notification channels, token refresh registration, message/live notification deep links and backend push delivery. Device delivery remains unverified here.
8. Added central MY SHOP VAT administration and server-side VAT fields for applicable digital/live spends; physical e-commerce remains separate.
9. Added audited Main Admin email/mobile recovery edits, temporary password reset and session revocation; user ID remains immutable.
10. Improved History record types, thumbnails, timestamps, action labels, navigation and clear behavior.
11. Updated Live Room comments/controls, viewer overflow, gender colors, Host End behavior, summary tabs, moderator music permission and dynamic seats 1–99; real-device RTC/audio remains unverified.
12. Added self-managed Facebook, Page, Messenger, WhatsApp, imo, YouTube, TikTok and Telegram links with validated destinations and hidden empty slots.
13. Made banner deletion remove the associated backend media and clear stale image requests; saved/restored Home scroll position and loaded pages to the saved position.
14. Aligned Messenger status and unread logic with backend state; voice-message previews reflect actual message types. Unsupported calls/groups remain absent.
15. Redesigned the profile and About surfaces around the approved compact light layout. Fixed a profile rendering crash where Social Links views were used before initialization. Removed public purchased-Coin totals and registration gender from other users' profile responses.
16. Added optional Personal Details editing with per-field Public/Friends/Only Me privacy. Empty values are removed; About returns only populated fields visible to that viewer.

## Release workflow and source size

- Replaced push-triggered publishing with manual workflow dispatch. Default runs build a QA APK; production deployment and friend APK replacement require the explicit publish input. The publish job checks out the same commit that passed QA, and builds/verifies/signs the APK before it deploys the Worker.
- The friend APK is configured for a separate APK-only public repository; the source repository stays private.
- Converted 12 drawable PNGs to pixel-identical lossless WebP assets. `minSdk` remains 24. This keeps the complete V-537 source ZIP under the 25 MB limit.

## Verification limits

- Local checks and regression test results are recorded in `MY-SHOP-V537-REQUIREMENTS-CHECKLIST-BN.md`.
- No Android APK build has run in this workspace because Gradle and Android SDK are unavailable.
- No real-device visual review, background/terminated push test, production D1 migration, or two-device Live audio/RTC test has run here. Do not treat V-537 as fully QA-passed until those checks succeed.
- No Worker deployment, GitHub Release publication, or friends link update was performed.
