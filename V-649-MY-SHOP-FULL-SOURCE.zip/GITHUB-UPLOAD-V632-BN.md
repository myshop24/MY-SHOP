# V-632 — GitHub পূর্ণাঙ্গ সোর্স ZIP

১. V-632-MY-SHOP-FULL-SOURCE.zip ডাউনলোড করুন। ZIP খুলবেন না।
২. আগের মতো myshop24/MY-SHOP repository-র root/main-এ ZIP আপলোড করে Commit করুন। বিদ্যমান workflow ও signing setup রাখুন।
৩. Actions → MY SHOP PERMANENT RELEASE PIPELINE খুলুন। আগের রান থাকলে নতুনটি Waiting থাকতে পারে।
৪. WORKER VERIFY -> APK সফল হলে Artifacts → MY-SHOP-FINAL-V-632 ডাউনলোড করুন; ভিতরে MY_SHOP_FINAL_RELEASE.apk পাবেন।
৫. GitHub Pages-এর ফল APK বিল্ডের ফল নয়।

এই ZIP-এ আগে বানানো APK নেই। এই পরিবেশে Gradle ডাউনলোড নেটওয়ার্কে আটকে যাওয়ায় পূর্ণ Android বিল্ড হয়নি। GitHub-এ সঠিক V632 source, original signing secrets ও Android build সফল হলেই নতুন APK তৈরি হবে। সোর্স/SQLite পরীক্ষা এবং ফোনে পরীক্ষা আলাদা; প্রকৃত ফল হ্যান্ডঅফে দেওয়া আছে।
