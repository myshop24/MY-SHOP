# ১/৫ — Profile system audit (V-586 source checkpoint)

মূল reference: 01-138862.png; video: 138863.mp4। ছবি আর কথোপকথন একসঙ্গে মিলিয়ে কাজ চলছে। This is not a completion certificate.

| অংশ | বর্তমান source অবস্থা | এখনও প্রয়োজন |
|---|---|---|
| Home avatar → Side Menu → own profile | পৃথক route, identity tap, normal user Admin hide | Android runtime/device যাচাই |
| Own cover menu | আলাদা Profile Actions drawer | device visual fit |
| Cover/avatar edit | own-only edit route | actual upload network/device QA |
| Own profile actions | Edit Profile, Create Post, Message Inbox | device navigation QA |
| Stats | Followers / Following / Posts | বাস্তব account count QA |
| Shortcuts | Wallet, Store, Join Live, Top Gifters, View As, Links; other profile-এ own shortcuts লুকানো | reference/device spacing |
| Posts / Gallery | embedded photo/video gallery এবং existing permission endpoint | photo/video rendering/device QA |
| Personal Details | Name/ID/Bio/Photo/Cover/Join Date/Social Links সহ ২০টি field, compact row, per-row edit, Public/Friends/Only Me/Custom | প্রোফাইল পেইজে field visibility server-side mask করা; public Feed/Live-এ ইতিমধ্যে দেখানো পরিচয় তথ্য এই setting বদলায় না; device QA বাকি |
| Custom audience | user IDs, grant validation, atomic replacement/revocation | friendly user picker/device QA |
| Other profile | Add Friend / Message / three-dot drawer | device visual fit |
| Three-dot working entries | Message, Follow/Unfollow, Friend, Premium Gift Request, Message Notification Mute, Share, Copy, Safety Block/Report | live gift animation নয়; Block এবং Report পৃথক entry; একই existing safety endpoints ব্যবহার করা |
| Audio/Video Call, Restrict, Live Invitation | স্পষ্ট Coming Soon | বাস্তব implementation ও end-to-end QA প্রয়োজন |
| Make Room Admin | profile-এ অননুমোদিত button নেই | active Live-room context/permissions; Live change rule অনুযায়ী নির্দিষ্ট approval প্রয়োজন |
| Identity | ID immutable; 0001/0002/0003 verified identity rule বজায় | reference-এর authority Level/special badge developer rule-এর সাথে মিলিয়ে final decision |
| Bottom nav | fixed five-item profile navigation; main Home Live untouched | device safe area/pixel comparison |

## পরীক্ষা
Custom privacy authentication, owner isolation, grant deduplication, invalid-save preservation, atomic rollback, revoke/delete পরীক্ষা পাস। Core Profile masking owner/friend/stranger/Public Preview actual handler + SQLite fixture-এ পাস। পুরোনো client optional detail save করলেও core privacy অক্ষত থাকে। Gift quote পরিবর্তিত হলে reserve-এর আগে প্রত্যাখ্যান পরীক্ষা পাস। Java source parsing পাস; Android types/APK/device visual QA হয়নি। SDK/Gradle dependencies পরিবেশে নেই এবং Gradle download blocked.

## সর্বশেষ মালিকের সংশোধন
Withdrawal amount selection/calculation এবং Admin amount editor V-585-এর সঙ্গে byte-for-byte unchanged। Demo-র ৩,০০০ বা অন্য amount preset প্রয়োগ করা হয়নি। Source amounts সার্ভারের catalog থেকে আসে।
