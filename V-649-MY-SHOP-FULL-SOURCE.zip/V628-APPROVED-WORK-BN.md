# V628 — অনুমোদিত আটটি সংশোধন

V627-এর সম্পূর্ণ সোর্স থেকে চালানো হয়েছে; শুরু থেকে লেখা নয়। পরের পরিবর্তিত ডেলিভারি V629। কাজের অনুমোদন: মালিকের সর্বশেষ “বিসমিল্লাহ বলে কাজ শুরু করেন, কাজের ধাপ স্ক্রিনে দেখাবেন।” আগের নিয়মের সঙ্গে সংঘর্ষ হলে সর্বশেষ চ্যাটের সিদ্ধান্ত কার্যকর।

1. Level badge ছোট, স্পষ্ট এবং pulse/glow/shimmer করবে; সংখ্যা স্থির ও পাঠযোগ্য থাকবে।
2. চলন্ত Join প্রয়োজনমতো চওড়া হবে; ডানে অযথা ফাঁকা থাকবে না। নিচের স্বাভাবিক Join বহাল।
3. Gift comment-এ দাতা, প্রাপক, gift ও পরিমাণ থাকবে; একই Combo-তে এক বার্তা আপডেট হবে।
4. স্বাভাবিক account আগের serial পদ্ধতিতে হবে। Admin ৪–৮ সংখ্যার unique public ID দিতে ও বিশেষ নতুন ID reserve করতে পারবেন; internal identity/হিসাব অক্ষত।
5. ID/Product Preview পাঠযোগ্য হবে এবং সেখান থেকে বাস্তব Confirm/Save/Grant হবে।
6. নিচের Send-এর মূল মাপ/ডিজাইন রেখে এক ট্যাপে পাঠানো, pending feedback এবং একই nonce-এ নিরাপদ retry।
7. Admin/কেনা পণ্য সত্যিকারে পাওয়া যাবে; Rare ID বদলাবে। সব বৈধ Theme পৃথক মেয়াদসহ My Items-এ থাকবে, পালটে ব্যবহার করা যাবে।
8. কেনা/Admin Chat Bubble Apply করে comment-এ আসবে; ছবি/নাম/বেজ/লেখা ফিট হবে। Gift to Friend সঠিক প্রাপকের জন্য hold/approval/expiryসহ কাজ করবে।

অতিরিক্ত অনুমান করা হয়নি: price=0 বা unpublished paid item নিজে থেকে publish/দাম বসানো নয়। Main Admin-এর স্পষ্ট office-grant আলাদা; draft grant করলেও public catalog publish হয় না। অফিস কয়েন double level বাতিল; পুরোনো Level অক্ষত। Coin100000 ও Diamond1000 একই point progress-এ +1; existing earning-source ও commission rules অপরিবর্তিত।

পুরোনো ১–১০-এর পূর্ণ reference/device acceptance এই source checkpoint দ্বারা সম্পন্ন ঘোষণা করা হয়নি। ফোনে অ্যানিমেশনের সৌন্দর্য, fitting ও realtime যাচাই এখনও প্রয়োজন।
