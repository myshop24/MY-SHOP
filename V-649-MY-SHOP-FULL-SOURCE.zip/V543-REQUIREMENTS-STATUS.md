# V-543 • ৯টি নির্দেশনার অবস্থা

V-542 সম্পূর্ণ সোর্সের ওপর সীমিত সংশোধন। এটি signed APK নয়। কোনো ফোন/emulator সংযুক্ত ছিল না; নিচে source/local-test ফল ও ফোনের acceptance আলাদা।

| নং | সর্বশেষ অনুমোদিত নির্দেশনা | এই সংস্করণের কাজ | যাচাই |
|---|---|---|---|
| ১ | EN-এর আগে চাঁদ M2 সোনালি, সূর্য S7 বেগুনি; পূর্ণ আইকন | Glossy vector, 36dp reserved width, font glyph বাদ | Android compile PASS; phone visual pending |
| ২ | এক সারি, ডান→বাম smooth banner, খালি frame নয়, দুই দিকে swipe | Cached bounded decode, coalesced requests, ready check, bitmap বহনকারী ImageView rotation; বর্তমান bitmap আর মুছে reload নয় | Compile PASS; supplied video-এর আচরণ ফোনে তুলনা বাকি |
| ৩ | নাম এক লাইনে fixed 20sp; ছোট LV পাশে; ID/date নিচে; LV.0 যাচাই | Wrap-content height, font padding, constrained name width, পাশে LV; feed এখন Profile-এর coinLevelFor reconciliation ব্যবহার করে | Actual SQLite feed/post LV.426 tests PASS; production user data ও visual pending |
| ৪ | LIVE NOW/Following/New/Explore এবং status icons স্পষ্ট | Actual background অনুযায়ী text contrast; light status flags; LIVE NOW red অক্ষত | Palette contrast PASS; phone pending |
| ৫ | শুধু মূল নীল header লক; নিচের সব surface ও bottom bar থিমে | Shared palette traversal, Home2 custom backdrop explicit themed, header subtree preserved | Compile PASS; all old activity/dialog combinations phone pending |
| ৬ | Admin ১০ লাইট+১০ ডার্ক, clear Preview/Save/Publish/Reset; no APK update per selection | Content folder-এ App Themes; 20 labeled swatches, separate draft/published, revision conflict protection; actual Home1/Home2 draft preview; public sync ~30s foreground, persisted offline palette | Real SQLite auth/draft/publish/conflict/failure/reset tests PASS; production Worker deploy required |
| ৭ | White comment input, readable text, clear gray→colored rocket, single fee, transparent Send | White input; dark text; rocket 20sp, selected fee 9sp; inactive full opacity gray; responsive localized short hint on narrow closed composer; transparent full Send | Build PASS; keyboard and small-device runtime pending |
| ৮ | Music absent হলে অন্য right icons উঠবে না | Music INVISIBLE retains slot; rail bottom-anchored; five slots determine size consistently | Source/compile PASS; host/guest phone comparison pending |
| ৯ | অন্য অনুমোদিত cards/features সম্পূর্ণ লক | No wallet/transfer/gift/join/RTC/membership logic changes; original assets retained; only theme surfaces recolored by instruction | Old SQLite/module regressions PASS; real RTC/push regression untested |

## অবশিষ্ট সীমা
Push configuration, signed APK ও physical-device notification/streaming QA-এর V-542 সীমাবদ্ধতা অপরিবর্তিত। পুরোনো সব ভাষার label audit এখনও সম্পূর্ণ নয়। এই সংস্করণে OTP যোগ করা হয়নি।

## ফোনে acceptance
1. দুই Home-এ M2/S7 পুরোটা, কোনো header clipping নয়।
2. Slow network-এ প্রতিটি banner transition, wrap last→first, manual both ways, one-banner stationary, empty-folder no cross-folder fallback।
3. Decorative/Bangla name, font scale এবং LV.426 backend value; কোনো বানানো level নয়।
4. Admin draft শুধু preview, publish অন্য account/device-এ, offline retention, reboot, 20 palettes text visibility; blue header unchanged।
5. Host/guest rail aligned; keyboard open/closed, white input, one fee, one charge; join/seat/audio unchanged।
