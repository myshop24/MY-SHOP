# V628 — GitHub APK ফুল সোর্স প্যাকেজ ব্যবহার

এই ZIP সম্পূর্ণ project source; APK নয়। Android versionCode628 / versionName2.9.628 / SOURCE_BUILD_ID MY SHOP V-628। আগের APK নতুন নামে দেওয়া হয়নি।

1. ZIP Extract করে `.github`-সহ project files নিন। বিল্ড-only পরীক্ষার জন্য repository root-এর `.github/workflows/my-shop-apk.yml` এই প্যাকেজেরটি হতে হবে; আলাদা build repository-তেও ব্যবহার করা যায়। এটি Worker/D1 deploy করে না।
2. বর্তমান পুরোনো main pipeline-এ শুধু ZIP upload করলে Worker আগে deploy হয়। সেই পুরোনো workflow রেখে ZIP দেওয়া build-only পরীক্ষা নয়। প্যাকেজের workflow বসানোর পর complete source অথবা repository root-এ V-628-MY-SHOP-FULL-SOURCE.zip দিন। Workflow সর্বোচ্চ version নির্বাচন করে, exact commit checkout করে; পুরোনো ZIP মুছতে হবে না।
3. Original signing key/cache `my-shop-release-signing-v1` রাখুন। প্রয়োজনীয় original secrets: MYSHOP_KEYSTORE_PASSWORD, MYSHOP_KEY_ALIAS, MYSHOP_KEY_PASSWORD; cache না থাকলে original MYSHOP_KEYSTORE_BASE64 বা SIGNING-SETUP.md-এর encrypted-key setup। নতুন release key নয়। Firebase MYSHOP_FIREBASE_* সেটআপও SIGNING-SETUP.md-তে আছে। গোপন মান source/chat/log-এ রাখবেন না।
4. Actions → MY SHOP Android APK → Run workflow। লগে `Building V-628` ও নতুন target checks থাকতে হবে। Build-এ JDK17, Node22, Python3.12, Android SDK/build-tools36, Gradle8.11.1, pinned asset dependencies, ffmpeg ও DejaVu লাগে; workflow এসব setup করে।
5. সফল run → Artifacts → **MY-SHOP-V-628-APK** → Extract → **MY_SHOP_FINAL_RELEASE.apk**। ভুল Pages run বা আগের version-এর artifact নেবেন না।
6. সত্যিকারের নতুন APK যাচাই: intended commit SHA, V628/2.9.628, com.myshop.app, original certificate, provenance, artifact time, APK byte-size ও SHA256 মিলবে। `Build successful` একা যথেষ্ট নয়। মূল signing certificate SHA256: `4c6784cd027679169b60168a3dec744858c56ab681f860880cea435bb2992acd`।
7. নতুন API-র জন্য APK628-এর সঙ্গে backend628 লাগবে। Worker deploy আলাদা reviewed step: existing backend/worker config, D1/R2 bindings ও secrets অক্ষত রেখে GitHub build-এর বাইরে করুন। এই কাজ production deploy করেনি; পুরোনো backend থাকলে নতুন Preview/Grant/receipt আচরণ পাওয়া যাবে না। D1 backup এবং existing bindings যাচাই করুন; database reset নয়।
8. Price0/unpublished Chat Bubble/Theme-এ paid Buy/Gift কাজ করতে আগে Admin-কে বৈধ Diamond price দিয়ে Publish করতে হবে। কেবল Main Admin চাইলে user grant confirmation-এ unpublished office-grant স্পষ্টভাবে দিতে পারবেন; এতে catalog নিজে publish হবে না।

ফোনে যাচাই: ছোট স্ক্রিনে badge glow ও সংখ্যা; Join ফাঁকা জায়গা; দুই account-এ Gift comment/Combo; এক tap Send ও slow-network retry; Admin ৪/৫/৬/৭/৮-digit Preview→Confirm; সব Theme expiry রেখে switch; Chat Apply করে comment fitting; ৮-digit friend ID-তে Gift→Admin approval→প্রাপকের My Items। RTC audio, join/end/reconnect, existing payment/push ও পুরোনো Level-ও যাচাই করুন।

এখানে পূর্ণ Android build হয়নি: Gradle download network unavailable এবং local SDK নেই। APK-size তাই মাপা হয়নি। GitHub log-এ কোনো ত্রুটি হলে সেই run-এর প্রথম fatal error ধরে ঠিক করতে হবে; পুরোনো artifact দিয়ে success দাবি নয়।
