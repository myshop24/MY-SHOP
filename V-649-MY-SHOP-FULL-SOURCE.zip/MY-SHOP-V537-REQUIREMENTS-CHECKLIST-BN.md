# MY SHOP V-537 — লক করা কাজের তালিকা

Base source: V-536. Next sequential identity: V-537. No intermediate ZIP; final source archive must be under 25 MB.

## Locked requirements

1. **Splash branding:** one `myshop` wordmark; `my` gold and `shop` silver/white, matching the approved brand.
2. **Registration Email:** keep the approved Create Account email field and save/link it to login and recovery.
3. **Bottom More Apps:** restore the approved More Apps icon and Quick Links contents/behavior; opening it must not crash. Inspect the full source list because the user has more items than the supplied partial reference shows.
4. **General / Live Page 2 menus:** compact reference-style icon layout with correct icon/name pairings and existing admin configuration, ordering, and navigation; no oversized gradient cards.
5. **Online presence:** only a genuinely active user gets an online indicator. Presence must refresh and honor Active Status/privacy; stale cached online state must be cleared.
6. **Messenger conversation list:** backend-backed latest activity ordering, avatar, online state, name, latest preview, relative time, unread count/state; keep the screen compact and expose only features that work.
7. **Device push:** Android system notification for messages and relevant Live start while backgrounded or terminated. Check Android 13+ permission, FCM token save/refresh, backend trigger, notification channel, tap target to exact chat/room. In-app badge alone does not pass. Requires real-device test.
8. **Central MY SHOP VAT:** Super Admin controls a single VAT percentage distinct from Service Fee. Apply once to relevant Live/digital Coin, Gold Coin, gift, transfer, highlight, Premium/Membership spends; show base + VAT + total; keep auditable VAT fields. Exclude physical e-commerce. VAT default remains 0 until Admin configures it.
9. **Account recovery/login management:** Main Admin searches by immutable User ID; can change email and mobile, inspect change history/summary, and issue a temporary password. User signs in and changes it in Settings. Audit sensitive changes; do not display credentials or security answers. Fix visible `null`/empty fields.
10. **History page:** match approved reference across Profile, Product, Shop, Live, Video, Feed Post and other actual types: correct thumbnail/icon, title/type, date/time, appropriate action, Clear History, mobile spacing.
11. **Live Room — 8 fixes:** (a) comments rise from bottom over seat zone and stop before top-seat line; (b) responsive fixed Music → Love → Vote → Gift → Share rail; (c) Host then active avatar line with overflow/total count; (d) Male comment names green, Female pink; (e) Host has no JOIN, has End behavior; (f) functional Live Summary / Top 20 Supporters / Stats / About Host; (g) Music permission for Host / Room Admin / Main Admin / Moderator; (h) accepted callers get dynamic seats after the first eight. Also test Host↔Guest audio, delay and mute/unmute on two devices, plus Join/Leave, comments, gifts, Vote/Love, Exit.
12. **User Social Links:** predefined Facebook, Page, Messenger, WhatsApp, imo, YouTube, TikTok, Telegram links; open each user's own destination; unset links are hidden or cleanly inactive.
13. **Banner deletion/Home scroll:** deleted banner is absent from backend and cache/UI immediately; true empty slot state. Preserve the agreed Home sticky/restore-scroll behavior.
14. **Messenger functional quality:** reconcile the visual redesign with real backend/realtime message state, presence, unread state, and ordering. Do not ship mock calls, groups, tabs or statuses.
15. **New Profile design:** match approved reference; compact mobile layout, clean light background, no duplicate/oversized/color-heavy items, remove unnecessary MY SHOP logo/header branding, keep financial details private and owner-scoped.
16. **Personal Details/About:** optional dynamic fields including Location, Birthday, Relationship, Family, Gender, Languages, Education; show only populated fields. No blank/null/`Not set` rows. Per-field Public/Friends/Only Me privacy.

## Global rules and release checks

- Compare every screen to its supplied reference. Preserve already-approved features and fix related bugs found during source review.
- Show live progress as `V-537 — কাজ NN/16` without pausing work.
- The permanent friends download should be a GitHub Release link to the latest APK, with source private. Prepare automatic release generation; do not publish/update until the owner explicitly says `আপডেট দাও`.
- Release source is manual-only. The workflow defaults to QA build; production Worker deployment and APK replacement are gated behind an explicit input and target a separate APK-only repository.
- The release ZIP must be the complete working source, under 25 MB, and contain this checklist, developer rules, version identity, change log, and QA notes.
- Never claim Android build, push delivery, or RTC verification passed unless actually tested. Final QA includes Android release build, screen-by-screen reference review, relevant backend regression tests, and two-device tests for push and Live audio.

## V-537 progress

- [x] #1–#3 present in V-536 source; recheck during final regression.
- [~] #4 compact menus implemented in working source; final visual review pending.
- [~] #5 presence privacy and stale cached state corrections implemented; final cross-client verification pending.
- [~] #6 backend-backed compact Messenger list implemented; final visual review pending.
- [~] #7 data-only push delivery path and Android system notification intent implemented; Firebase configuration and background/terminated delivery require real-device verification.
- [~] #8 central VAT config, server-side charging, display and ledger work implemented; local syntax/SQLite checks pass; Android build and production-backend verification pending.
- [~] #9 Account recovery source fixes: null display, blank contact preservation, immutable ID, audited email/mobile change, temporary-password reset now revokes `myshop_auth_sessions_v108` sessions. Full Android/API test pending.
- [~] #10 History reference corrections and history recording/navigation paths implemented in working source; Android visual test pending.
- [~] #11 source fixes: comments overlay/rail, viewer overflow, gender colors, Host JOIN removal, interactive summary tabs, music roles, dynamic seats to 99 with one-time legacy migration. Still requires Android build, visual/reference review, and two-real-device RTC/audio tests.
- [~] #12 per-user Social Links implemented: eight fixed platforms, authenticated self-only edit/save, URL validation, optional imo phone number, empty slots hidden, configured icons open each user’s own destination. Android/device review pending.
- [~] #13 banner delete removes both D1 banner rows and associated banner_media/R2 objects; carousel rebinding clears stale image tags so in-flight requests cannot restore deleted images. Home scroll Y now saves/restores across pauses/recreation and loads feed pages until the prior point is reachable. Device verification pending.
- [~] #14 Messenger checks/fixes: thread header now reports real Online/Offline/last-active with visibility privacy; inbox previews voice messages; hidden/deleted-for-me messages no longer affect unread/conversation state. Calls/groups/photo send remain absent rather than mocked. End-to-end backend/device regression pending.
- [~] #15 Profile page now follows the approved light, compact layout with cover/avatar, ID/name/tier, four social counters, owner edit/share actions, role-scoped shortcuts, media/About tabs, post composer entry, and optional social link icons. Build/visual reference review pending.
- [~] #16 optional Personal Details implemented for Location, Birthday, Relationship Status, Family, Gender, Languages, Education. Self-edit screen saves only populated fields with Public/Friends/Only Me privacy; API filters by viewer relation and About renders no empty rows. Build/reference/privacy regression pending.

## V-537 local QA snapshot — 2026-10-01

- Worker syntax check: passed.
- Node regression suite: 41 passed across commerce (25), inbox (12), profile privacy and social URL normalization (4); uses local SQLite and does not verify production D1.
- Android XML parse: passed. Manifest activity source check: 78 declared activities, no missing Java classes. Static resource-reference check: no missing `R.*` resources.
- `tools_verify_master.py`: 24 source/reference guard checks passed after its General Menu rule was updated to expect the compact 3-column icon/name layout.
- Release shell syntax: passed. GitHub workflow parsed; only manual dispatch, public release input defaults off, APK target must be configured separately.
- Lossless resource conversion: 12 PNG assets converted to WebP after decoded pixels were compared exactly. Android minSdk is 24.
- Complete-source ZIP size check after V-537 docs and identity: about 24.27 MB (<25,000,000 bytes).
- Not verified here: Android/Gradle build (SDK/Gradle unavailable), visual device screenshots, push delivery on real devices, production D1 migration, or two-device RTC/audio. Do not call V-537 final until these gates pass or the owner explicitly accepts the limits.
