# V-535 Changes (BN)

## Build blocker fix
- GitHub Actions `:app:mergeReleaseResources` failure-এর root cause ছিল `app/src/main/res/drawable/myshop_icon.png` ফাইলটি আসলে JPEG/JFIF bytes হলেও `.png` extension ছিল।
- ফাইলটি একই 1536x1536 image রেখে সত্যিকারের PNG হিসেবে re-encoded করা হয়েছে।
- `tools_verify_master.py`-এ PNG signature guard যোগ হয়েছে, যাতে ভবিষ্যতে JPEG/other bytes `.png` নামে ঢুকলে CI upload-এর আগেই FAIL হয়।

## Version
- versionCode: 535
- versionName: 2.9.535
- SOURCE_BUILD_ID: MY SHOP V-535
- Worker health/build identity: V-535 / 2.9.535

## Live Room audit
- `LIVE-ROOM-AUDIT-V535-BN.md` যোগ হয়েছে।
- Build fix-এর সঙ্গে Live Room behavior rewrite করা হয়নি।
