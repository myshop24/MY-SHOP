# MY SHOP V-518 — Reference UI Correction + Release Preflight Stabilization

## এই release-এ সম্পন্ন
- User-provided Home/Live reference অনুযায়ী Hamburger/menu proportions আরও compact করা হয়েছে।
- Home `My Feed` heading decoration ও composer spacing tighten করা হয়েছে।
- Photo / Video / Post action row-এর alignment ও spacing Reference-এর কাছাকাছি করা হয়েছে।
- Feed post action row এখন `Like | Comment | Share` পাশাপাশি এবং `•••` ডান পাশে রাখে।
- Main Dashboard ও Live Page-এর Live/Go Live icon একই `nav_live` design family রেখে glow treatment পেয়েছে।
- Live Page-এর No Live state-এর Live icon আরও বড়/স্পষ্ট ও glowing করা হয়েছে।
- Live Page-এর Hamburger icon এখন dedicated compact blue vector ব্যবহার করে।
- Live Page-এর Membership / Games / Earn icons আরও দৃশ্যমান করা হয়েছে।
- Existing six-slot Live Home banner admin system retained করা হয়েছে; gallery upload, link, save/publish, enable/disable, schedule এবং delete controls source-এ অক্ষত আছে।
- `tools/v516_preflight.py`-এর hard-coded V-517 identity সরিয়ে source-driven version validation করা হয়েছে; V-518 এখন সঠিকভাবে preflight PASS করে।

## Validation
- ZIP/source structure inspection: PASS
- V-518 dynamic preflight: PASS
- Master regression verifier: PASS
- Android APK compile: এই execution environment-এ Gradle/Android SDK নেই; authoritative GitHub Actions build এখনও আলাদা করে চালাতে হবে।

## Release identity
- Source: V-518
- Android version: 2.9.518
- Worker build: V-518

## V-518 Reference UI correction pass — Feed + Live icon polish
- Home-এর navigation → banner spacing আরও compact করা হয়েছে; অতিরিক্ত gap কমানো হয়েছে।
- My Feed heading/composer vertical spacing কমানো হয়েছে।
- Photo / Video / Post একই লাইনে equal-centred রেখে icon size ছোট ও clean করা হয়েছে।
- Feed action row-এর Like / Comment / Share icon reference-style ছোট ও পরিষ্কার করা হয়েছে; Share icon ভুল arrow থেকে reference-style curved share mark-এ বদলানো হয়েছে; Comment icon-এ three-dot bubble রাখা হয়েছে।
- Feed action row-এর spacing সমান করা হয়েছে এবং ••• ডান পাশে রাখা হয়েছে।
- Bottom Live icon-এ stronger red/pink circular treatment + glow + white broadcast mark দেওয়া হয়েছে, যাতে Live CTA স্পষ্ট হয়।
