# myshop V-534 — Final Change Checklist

Version: V-534 / 2.9.534 / versionCode 534

1. V-533 baseline preserved; regression lock applied.
2. Login Board rebuilt to locked premium reference.
3. Create Account Board rebuilt to locked premium reference.
4. Login/Create Account are non-scroll compact layouts.
5. Official MS shopping-bag logo used exactly on auth screens.
6. Official MS logo used as Android launcher/round icon.
7. App label changed to `myshop` (lowercase, no space).
8. Visible `MY SHOP` branding normalized to `myshop` in Android UI.
9. Login identifier is Mobile Number / User ID.
10. Password + show/hide preserved.
11. Remember Me preserved.
12. Forgot Password preserved.
13. Google Login preserved and wired to existing working OAuth flow.
14. Facebook Login removed from auth UI.
15. Create Account has no Google/Facebook social buttons.
16. Create Account fields compacted: name/mobile/gender/password/confirm.
17. Security Question + Security Answer preserved.
18. Terms / Privacy / Delete Account links preserved.
19. High-contrast auth field text/placeholders applied.
20. Normal users cannot edit recovery email/mobile from Edit Profile.
21. Backend profile update ignores user-supplied recovery email/mobile.
22. Main Admin Account Recovery activity added.
23. Main Admin IDs 0001/0002/0003 only for recovery contact changes.
24. Recovery by immutable 4-digit User ID.
25. Recovery changes keep User ID/balance/history unchanged.
26. Recovery duplicate email/mobile validation added.
27. Recovery audit table/log stores admin, user, masked old/new values, time.
28. Password/Security Answer are never exposed in recovery UI.
29. Security notification is generated after Main Admin recovery change.
30. Real FCM token registration/refresh preserved.
31. Android 13+ notification permission preserved.
32. Message high-priority notification channel preserved.
33. Live high-priority notification channel preserved.
34. Message notification deep-links to Chat.
35. Live notification deep-links to Live Room.
36. Foreground/background/closed-app FCM delivery pipeline preserved.
37. Push token delivery logging/unregistered-token cleanup preserved.
38. App foreground presence heartbeat remains 15 seconds.
39. Backend online TTL remains 45 seconds.
40. Background/exit publishes offline when possible.
41. General/People/Inbox presence uses backend online status.
42. Online shows green dot; offline shows no green dot.
43. Support page now has 6 admin-managed photo/WhatsApp slots.
44. Agent page now has 6 admin-managed photo/WhatsApp slots.
45. Support/Agent accepts WhatsApp number or safe link and routes to chat.
46. Super Admin support folder exposes Support 1–6 management.
47. Agent menu opens six-agent directory; admin can edit slots.
48. Permanent friend download page points to `friends-latest` APK.
49. GitHub Actions keeps the same permanent latest-APK asset/link.
50. Global premium compact icon library added for Quick/General/Discover.
51. More Apps gets a clearer premium purple 3D 9-grid icon; admin-only shortcut remains hidden from normal users.
52. Main Admin long-press bottom navigation drag/drop ordering persists and publishes.
53. V-534 identity, backend health identity, XML/resources, Worker JS and master verifier are release-checked.

## Important runtime notes
- Google Login was already confirmed working by the user on V-533; V-534 preserves that flow.
- Production closed-app push still depends on valid Firebase client secrets in GitHub Actions and `FCM_SERVICE_ACCOUNT_JSON` in the Worker environment.
- Real multi-device notification/presence behavior must be finally validated on physical devices after GitHub Actions produces the APK.
