# MY SHOP V-552 — পূর্ণ সোর্স ও যাচাই

V-551-এর পূর্ণ সোর্স থেকে V-552 / 2.9.552 / versionCode 552। এটি source release; APK নয়। আগের ফাইলগুলো বাদ দেওয়া হয়নি।

## কী পরিবর্তন হয়েছে
লাইভের নামের দিক, Join, MS halo, কয়েনের ফাঁক, speaking wave, live-end summary close, More emoji controls; foreground presence, typing/read/delivery/draft retry; audio routing/mute/reconnect; notification diagnostics/preferences/deep links; admin room settings/history/restore/report review; combo, multi-recipient atomic gifts and transparent animation queue। মূল লেজার, VAT/commission ও পুরোনো ফিচারের সোর্স রাখা হয়েছে।

## যা নিশ্চিত নয় / বাকি
- Android SDK/Gradle নেই; APK compilation চালানো হয়নি। GitHub integration-এর write permission 403 হওয়ায় remote verification branch/run তৈরি হয়নি।
- বাস্তব ফোনে UI, animation, Bluetooth, lifecycle ও push receipt পরীক্ষিত নয়। ১০০% runtime success দাবি করা হচ্ছে না।
- Firebase client JSON অন্তর্ভুক্ত। একই project myshop-2713c-এর service account Cloudflare Worker secret FCM_SERVICE_ACCOUNT_JSON-এ নিরাপদে configure এবং device delivery test করতে হবে। এটি সরবরাহ/যাচাই হয়নি। private key chat/repository-তে রাখবেন না।
- ৪ নম্বরের ধূসর বৃত্ত forest wallpaper-এর moon/asset হওয়ার সম্ভাবনা আছে; মূল custom theme asset পাওয়া যায়নি। এই অংশ সংশোধিত বলে দাবি করা হচ্ছে না।
- Production D1 migration/actual concurrent traffic এবং reference pixel match পরীক্ষিত নয়।
- ZIP-এর ভেতরের release scripts/workflow root GitHub pipeline-এ নিজে থেকে বসে যায় না। Build/upload-এর আগে বর্তমান root pipeline ও secrets মিলাতে হবে।

## পরীক্ষার ফল
verification/v552/checks.json-এর ১৩টি command সফল: ১৪০ Java file syntax parse (Android type checking নয়), resource/build-contract preflight, master checks, actual SQLite-backed V552 behavior, live lifecycle/invite, Worker suites V541–544/V540/V430, commerce/payout/profile regression। লগ সংযুক্ত। পুরোনো push tests notification+data contract অনুযায়ী বদলানো হয়েছে; app build bypass করা হয়নি।

## ৫০টি কাজের রিভিউ ম্যাট্রিক্স
সব source change বা পূর্বের আচরণ বজায় রাখার scope; device verification pending. Excluded historical IDs 42,44,46.

| ID | Scope | Release review |
|---|---|---|
| 1 | Touhid left-to-right ticker | Source updated; device/visual verification pending |
| 2 | Clearer Join gradient icon | Source updated; device/visual verification pending |
| 3 | Smaller MS icon / larger animated halo | Source updated; device/visual verification pending |
| 4 | Remove gray circle in custom forest wallpaper | BLOCKED: original custom wallpaper required |
| 5 | Equal visual spacing of four statistics | Source updated; device/visual verification pending |
| 6 | Device push notifications | Client/server source updated; server credential and device delivery UNVERIFIED |
| 7 | Stronger actual speaking waves | Source updated; device/visual verification pending |
| 8 | End live and close summary/screen | Source updated; device/visual verification pending |
| 9 | Foreground presence / stale expiry | Source updated; device/visual verification pending |
| 10 | Premium live summary | Source updated; device/visual verification pending |
| 11 | Invite top-row user to call | Existing behavior retained / integrated; device verification pending |
| 12 | Privileged direct join; ordinary host approval | Existing behavior retained / integrated; device verification pending |
| 13 | Automatic push diagnostics | Source updated; device/visual verification pending |
| 14 | Call Request/Connecting/Joined/Failed states | Source updated; device/visual verification pending |
| 15 | Transient RTC reconnect | Source updated; device/visual verification pending |
| 16 | Sent/Delivered/Seen | Source updated; device/visual verification pending |
| 17 | Draft and offline message retry | Source updated; device/visual verification pending |
| 18 | Exact notification deep link / ended-live notice | Source updated; device/visual verification pending |
| 19 | Message/Live/Promo notification preferences | Source updated; device/visual verification pending |
| 20 | Typing timeout | Source updated; device/visual verification pending |
| 21 | Automatic mic setup / optional voice test | Existing behavior retained / integrated; device verification pending |
| 22 | Speaker/earpiece/Bluetooth route | Source updated; device/visual verification pending |
| 23 | Actual RTC network quality | Source updated; device/visual verification pending |
| 24 | Join request expiry and deduplication | Source updated; device/visual verification pending |
| 25 | Host seat lock/unlock | Existing behavior retained / integrated; device verification pending |
| 26 | Atomic idempotent gift debit | Source updated; device/visual verification pending |
| 27 | Quantity-aware gift receipts and ledger | Existing behavior retained / integrated; device verification pending |
| 28 | Admin comment slow interval | Source updated; device/visual verification pending |
| 29 | Live comment/user report | Source updated; device/visual verification pending |
| 30 | Live settings audit and restore | Source updated; device/visual verification pending |
| 31 | Optional keep screen awake | Source updated; device/visual verification pending |
| 32 | Audio interruption and mute restoration | Source updated; device/visual verification pending |
| 33 | Admin preview and publish | Source updated; device/visual verification pending |
| 34 | Live title/topic draft | Source updated; device/visual verification pending |
| 35 | Favourite host list | Source updated; device/visual verification pending |
| 36 | Compact first-entry rules | Source updated; device/visual verification pending |
| 37 | Step down and remain viewer | Existing behavior retained / integrated; device verification pending |
| 38 | Audience local mute | Source updated; device/visual verification pending |
| 39 | Host local guest listening volume | Source updated; device/visual verification pending |
| 40 | Timed announcement | Source updated; device/visual verification pending |
| 41 | Clear insufficient balance response | Existing behavior retained / integrated; device verification pending |
| 43 | Favourite gifts | Existing behavior retained / integrated; device verification pending |
| 45 | Messenger-only image compression; no Live photo comments | Source updated; device/visual verification pending |
| 47 | Late join sees only new Live comments | Existing behavior retained / integrated; device verification pending |
| 48 | Font/touch readability | Summary sizing improved; full accessibility/font audit pending |
| 49 | Report Pending/Reviewing/Resolved with reason | Source updated; device/visual verification pending |
| 50 | Opt-in support diagnostics | Source updated; device/visual verification pending |
| 51 | Same-gift quantity >5 combo | Source updated; device/visual verification pending |
| 52 | Multiple recipients / Select All, immediate Send | Source updated; device/visual verification pending |
| 53 | Transparent nonblocking FIFO gift animations | Source updated; device/visual verification pending |
