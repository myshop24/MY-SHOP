# V559 কাজ ও যাচাই

## পরিবর্তন
- ID search থেকে এক জায়গায় প্রোফাইল, Coin/Gold প্রদান ও কারণসহ অপসারণ, membership/theme/rider প্রদান/অপসারণ, ব্লক/সাময়িক ব্লক এবং হিস্ট্রি।
- পণ্য, premium/membership ও withdrawal রিকোয়েস্টের কেন্দ্র; approve/activate/reject, order status, payment reference সহ paid record। Paid record নিজে টাকা পাঠায় না।
- আজ/মাস/সর্বমোট বিক্রি, পণ্য খরচ, অন্য ব্যয়, লাভ; অজানা product cost হলে লাভকে নিশ্চিত সংখ্যা হিসেবে দেখায় না। Coin/Gold হিসাব নগদ হিসাব থেকে পৃথক।
- Admin inbox-এ request center। Request notice একই database transaction-এ তৈরি হয়।
- Coin/Gold transfer, কেন্দ্রীয় commission, gift/withdraw consistency, reservation ও একবার debit/audit। ব্যর্থ সংযোগে অনিরাপদ POST স্বয়ংক্রিয়ভাবে দ্বিতীয়বার পাঠানো বন্ধ।
- নতুন solid/gradient theme, Admin-only নির্বাচন এবং published setting sync; contrast, Quick Links/menu; internal live palette unchanged।
- বড় live-list card, profile/live share routing, সর্বশেষ প্রকাশিত APK-এর canonical download link।
- Join/invite acknowledgement আর notification network response-এর জন্য অপেক্ষা করে না; pending join race ও audience exit response ঠিক করা হয়েছে। মূল audio engine অপরিবর্তিত।
- Host summary Top 20 presentation; Inbox/Chat neutral fallback avatar যাতে ছবির ভেতরের সবুজ dot offline অবস্থায় না জ্বলে।
- Home/live/shop carousels ও folder/gallery ad-এর 12:5 অনুপাত। Startup full-screen advertising তার নিজস্ব configured mode রাখে। স্ক্রিনভেদে physical pixels বদলাবে, অনুপাত একই থাকবে।
- Exact duplicate image resources পাওয়া যায়নি; ব্যবহৃত ছবি মুছে ফেলা হয়নি।

## পরীক্ষা
- Android :app:assembleDebug: BUILD SUCCESSFUL, version 2.9.559। এটি development QA build; পুরোনো release-এর ওপর update হিসেবে দেওয়ার জন্য নয়।
- tools/v559_verify.sh-এ release-gate suites: SQLite-backed finance, payout, wallet, commerce, request notices, premium/admin, live lifecycle/invite/acknowledgement, presence, theme allowlist/contrast ও preflight পাস।
- Historical V438-এর পুরোনো data-only FCM assertion বর্তমান notification-plus-data payload-এর সঙ্গে মেলে না; এটি release gate-এ নেই। ওই assertion দিয়ে production notification কাজ করে বলে দাবি করা হয়নি।
- Real phones-এ audio latency, device screenshots ও production D1 execution পরীক্ষা হয়নি।

## প্রকাশের অবস্থা
- এই কাজ থেকে production Worker deploy, signed release APK build ও latest release publication হয়নি। GitHub integration branch-write-এ 403 দিয়েছে। Original signing key-এর decrypted copy/password স্থানীয়ভাবে নেই।
- Source-এর workflow ও release script repository root-এ বসানো প্রয়োজন; source ZIP-এর ভেতরের workflow নিজে থেকে repository workflow হয় না। Existing cache key my-shop-release-signing-v1 এবং existing secrets ব্যবহার করা হয়েছে।
- WhatsApp delivery চালুর জন্য Worker-এ MYSHOP_WHATSAPP_TOKEN secret, PHONE_ID, ADMIN_NUMBER, GRAPH_VERSION, TEMPLATE এবং TEMPLATE_LANGUAGE values লাগবে (সবগুলোর পূর্ণ নাম MYSHOP_WHATSAPP_ prefix সহ)। Template body-তে একটি text parameter রাখতে হবে। অনুপস্থিত হলে dashboard SETUP_REQUIRED দেখায়। API accepted মানে delivery confirmed নয়; অনিশ্চিত failure REVIEW_REQUIRED থাকে।
- WhatsApp sender/API configuration বা automated bank/mobile-money payout credentials তৈরি বা পরীক্ষা করা হয়নি।

## GitHub-এ বসানো
1. V-559-MY-SHOP-SOURCE.zip repository root-এ দিন।
2. এর ভেতরের my-shop-release.sh দিয়ে repository root-এর একই file replace করুন।
3. এর ভেতরের .github/workflows/my-shop-apk.yml দিয়ে repository-এর একই workflow replace করুন।
4. একই commit-এ তিনটি পরিবর্তন দিলে নতুন workflow স্বয়ংক্রিয় পরীক্ষা ও release চালাবে; অথবা Actions থেকে publish_latest_apk=true দিয়ে চালানো যাবে।
5. সফল signed build/deploy/publication হলে https://github.com/myshop24/MY-SHOP/releases/latest/download/MY_SHOP_FINAL_RELEASE.apk সর্বশেষ প্রকাশিত APK দেবে। আগে থেকে প্রকাশ না হলে এই link নতুন APK তৈরি করে না।
