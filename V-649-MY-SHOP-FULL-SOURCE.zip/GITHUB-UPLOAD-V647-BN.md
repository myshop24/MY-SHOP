# V647 সম্পূর্ণ সোর্স আপলোড

V-647-MY-SHOP-FULL-SOURCE.zip অপরিবর্তিত অবস্থায় আগের স্থায়ী GitHub APK pipeline-এ দিন। নতুন repository/workflow বা signing key বানাবেন না। SOURCE_BUILD_ID=MY SHOP V-647, version2.9.647, package com.myshop.app। মূল signing/Firebase secrets আগেরটাই থাকবে।

এটি সোর্স ZIP; APK নয়। Original-signed APK তৈরি করতে বিদ্যমান signing secrets প্রয়োজন। স্থানীয় unsigned build/পরীক্ষার ফল verification/V647-RESULTS.json-এ। Worker/D1 production-এ deploy করা হয়নি। Backend update-এর আগে staging-এ0060 migration ও একই V647 Worker দিয়ে পরীক্ষা করুন; পুরোনো ডেটাবেস reset/delete করবেন না।

বাস্তব দুই ফোনে Agora ভিডিও, Beauty, ক্যামেরা অনুমতি, guest join, PK এবং10সেকেন্ড gift claim পরীক্ষা বাকি। PK বর্তমানে একই রুমের হোস্ট+গেস্ট; আলাদা দুই রুমের PK নয়। D1 read কমানোর পরিবর্তন করা হয়েছে, কিন্তু production quota reset/root cause নিশ্চিত করা হয়নি। বিস্তারিত বর্তমান developer handoff-এ।
