# MY SHOP V-543 • Developer handoff

Canonical base: V-543 সম্পূর্ণ source ZIP, V-542-এর সব প্রয়োজনীয় files/assets retained। পরের সংস্করণ V-544; V-543 পুনর্ব্যবহার নয়। SOURCE_BUILD_ID MY SHOP V-543; versionCode 543; versionName 2.9.543; Worker health matching।

## Scope lock
User-এর এবারের ৯টি নির্দেশনা V543-REQUIREMENTS-STATUS.md-তে authoritative। Theme icon M2 gold/S7 purple supersedes orange. Only original blue top header remains fixed; all lower board and bottom navigation adopt palette. Unrelated approved card/layout/icon/feature behavior locked. Existing Live background/seat/RTC/gift/finance settings unaffected. White Live comment input is explicit exception to dark Live skin.

## App Themes Admin
Main Admin → Dashboard & Content → App Themes • Light / Dark। Labels, selected check, published pair, revision, 10+10 palettes। SAVE updates only draft; PUBLISH applies selected pair atomically; RESET publishes L1/D1. Concurrent old revision returns 409, never overwrites silently. Failed save retains local selection. Reload is explicit. Preview board uses shared AppThemePalette; Actual Home Preview / Home 2 Preview launch existing screens with local Intent override, never publish or change shared dark_mode preference. Preview's moon/sun toggle stays preview-local.

GET /v1/app/themes public published pair; GET /v1/admin/app/themes authorized includes draft; PUT /v1/admin/app/themes accepts action SAVE/PUBLISH/RESET, lightId, darkId, revision. New additive D1 table myshop_app_themes. No existing table dropped. AdminOnly matches existing admin policy. Table contains colors' preset IDs only, no executable remote code.

Foreground palette fetch at most once/30s with heartbeat/resume; cached SharedPreferences survive offline/relaunch. Background/offline change arrives on foreground sync. Saving draft does not change public pair. App update NOT needed to select these existing 20 presets; adding different layout/new preset definitions still requires app changes. Server endpoints and Android must be deployed together. Existing workflow deploy_production path remains unchanged; QA build alone does not publish Worker.

## Visual implementation
Header subtree tagged theme_preserve. Home2 custom backgrounds and lower menu explicitly theme_board. Appearance palettes preserve artwork and colorful icon drawables, recolor soft background surfaces and neutral text, set status/navigation contrast flags; Live-room skin excluded. L1 white/light sky blue default; D1 navy default. Actual preview and published rendering use same palette definitions; generated concept images are not pixel-perfect app output. Numerical contrast checks all 20 palette backgrounds/cards >=4.5:1 for primary/secondary text; actual phone still must be inspected.

Feed name 20sp default bold, singleline ellipsis, wrap-content font height, LV11sp directly beside name. Existing decorative Unicode user names are data, not forcibly rewritten. Feed/List and Post read same authoritative level reconciliation as profile; no fake LV.426 or economy formula edits. Deploy latest Worker to replace old feed level behavior.

BannerImages 12MiB bitmap cache, two decode workers, coalesced URL fetches, 8MiB network limit, bounded1280 decode. Carousel rotates loaded ImageView roles without erasing center; it waits when incoming image not ready, retains current picture on network failure. Later retry on refresh/next attempt. Test wrap, dragging and URL changes with slow network; no fabricated local banners.

Live rail anchored bottom with Music invisible (not gone) for unauthorized users; same five-slot sizing. No permission changes. Comment input white, black text, 20sp rocket, selected9sp price; dynamic short localized Comment… hint if full hint won't fit. Keyboard still hides existing extra controls; request and charge rules unchanged.

## Build / delivery
JDK17 + Gradle8.11.1 + Android SDK36/AGP8.7.3. clean Debug+Release build and final assemble logs under verification/v543. V543 backend62 tests; V54017; V43031; commerce25/payout12/profile6 regression PASS. Firebase missing client/service credentials and release signing are still not provided. -PrequirePush production guard unchanged; local QA compile success is not phone push success. No physical Android device/emulator connected. Source ZIP<25,000,000 bytes; unsigned built APK much larger, deliberately excluded.

## Recommendations / next QA
Verify screenshots at user's phone width/font scale before declaring visual complete; banner slow-network endurance; Admin publish on two accounts/devices; Live host/audience rail and keyboard; RTC audio/join/leave/gifts and screen-off push. Preserve immutable last good V-542 if rollback required. Use no chat-pasted private keys. Do not promise signed APK, FCM delivery or Play compliance acceptance from local source tests. V-542 handoff contains unchanged push/translation blockers.
