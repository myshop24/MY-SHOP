# V-512 CI Failure Audit → V-515 Fixes

Source examined: V-512 editable source. GitHub Actions run #595 selected `V-512-MY-SHOP-FINAL-SOURCE.zip` and failed during `:app:compileReleaseJavaWithJavac` with 33 errors.

Observed failure groups:
- LiveHomeAdminActivity: DatePickerDialog / TimePickerDialog symbol resolution.
- WatchHistoryActivity: record overload mismatch, historyAdd API mismatch, text helper color/size overload mismatch, weight layout helper mismatch, AlertDialog resolution.
- MainActivity: malformed `R.drawable/...` references for feed action assets.
- GeneralUsersActivity: text helper color/size overload mismatch.
- LiveHomeActivity: weight layout helper mismatch.

V-515 source corrections:
- Added the compatible WatchHistory `record(...)` call shape.
- Added `t(String,int,float,boolean)` helper overload where reference code uses color before size.
- Ensured `weight(float,int)` exists in the affected screens.
- Made date/time dialogs explicitly reference Android framework classes.
- Normalized Android project drawable references to `R.drawable.<name>` syntax.
- Kept/verified `BackendClient.historyAdd(...)` contract.
- Synchronized release-critical config/version markers to V-515.

Verification performed before packaging:
- V-515 preflight: PASS.
- Master source verification: PASS.
- Worker `node --check`: PASS.
- Commerce tests: 25/25 PASS.
- Payout/Inbox tests: 12/12 PASS.

Boundary: an Android runner with the project SDK/AGP is still required for the authoritative APK compile/sign/verification. This audit does not claim a GitHub Android build passed.
