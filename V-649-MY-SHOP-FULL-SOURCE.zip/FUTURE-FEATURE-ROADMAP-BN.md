# MY SHOP — Future Feature Roadmap

These features are planned as future development modules. They are NOT required to be fully implemented in the V-512 stabilization build unless separately approved.

## 1. LIVE SHOPPING
Placement: Live Page + Live Room + MY SHOP product catalog.
Purpose: Attach products to a live session so viewers can see a compact product card without leaving the live room.
Flow: Product Catalog -> Host selects product -> Pin to Live -> Viewer opens card -> Add to Cart / Buy Now.
Admin: product attach/remove, price, discount, stock, featured state, ordering, enable/disable.

## 2. MY WALLET 2.0
Placement: Profile / More Apps -> My Wallet.
Purpose: Unified balance, coins, earnings, purchases, payouts and transaction history.
Admin: wallet rules, transaction controls, payout settings and audit records.

## 3. CREATOR HUB
Placement: 3-line menu -> Creator Hub.
Purpose: Creator dashboard for followers, live hours, views, posts, videos, earnings, level and missions.
Admin: creator eligibility, missions, limits, rewards and moderation.

## 4. MY REWARDS
Placement: More Apps / Profile -> My Rewards.
Purpose: Rewards for approved activities such as login, watching live, engagement, posting, live hosting and purchases.
Admin: reward amount, points/coins, campaigns, eligibility, limits, dates and enable/disable.

## 5. MY EVENTS
Placement: 3-line menu -> Events; related events can also appear from Live.
Purpose: Upcoming live, shopping events, creator events, flash sales and special campaigns.
Admin: banner, title, host, date/time, countdown, reminder, link, start/end, enable/disable.

## 6. MY CLUB
Placement: More Apps -> My Club.
Purpose: Creator/community clubs with members, posts, announcements, club live and approved exclusive content.
Admin: club approval, moderation, membership and safety controls.

## 7. MY DISCOVER
Placement: Live/More Apps -> Discover.
Purpose: Discovery hub for live sessions, products, videos, creators, shops, deals and events.
It must remain distinct from the Home Feed.

## 8. SHOP ORDER CENTER
Placement: MY SHOP -> My Orders.
Purpose: User order lifecycle and seller order management.
States: Pending, Confirmed, Shipped, Delivered, Cancelled.
Admin: order oversight, status controls, seller controls and audit history.

## 9. MY LINKS + AFFILIATE
Placement: 3-line menu -> My Links; affiliate controls can be added inside My Links later.
Purpose: Shareable links and optional affiliate/referral tracking.
Admin: campaigns, eligible products, commission rules and expiry.

## 10. SMART NOTIFICATION CENTER
Placement: existing notification bell.
Categories: Official, Live, Message, Friend, Order, Reward, Event, Membership.
Purpose: Every notification opens its related destination and supports unread/read state.

## 11. AI STUDIO
Placement: Live menu -> AI Studio.
Purpose: Approved AI utilities such as post captions, product descriptions, live titles, banner text and translation.
Admin: feature enable/disable, usage limits and policy controls.

## 12. TRUST & SAFETY CENTER
Placement: 3-line menu -> Safety & Privacy and Help Center -> Report/Safety.
Purpose: Report user/live/post, block, restrict, appeal and safety status.
Admin: moderation queue, actions, appeals and audit history.

## Placement principle
Home stays clean and reference-locked. Large future modules should enter through the appropriate existing navigation: MY SHOP for commerce, Live for live ecosystem, Profile/More Apps for personal services, 3-line menu for catalog features, and Support for help/safety.
