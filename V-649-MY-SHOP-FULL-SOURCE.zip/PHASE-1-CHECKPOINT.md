# MY SHOP — Phase 1 active work

## Baseline
- Pinned repository main: `527d9ba9389fa19e1ebab506350a7ce50a53af83`.
- V570 source ZIP verified against Git blob `78fca6cc98345220e2609c7ebcd78aedbdecaf02` (24,883,490 bytes).
- Supplied V570 APK: Android versionCode 570 / versionName 2.9.570, but asset configuration/inventory still 560 / 2.9.560.
- V567/V568 supplied archives contain full Android/backend source; V565/V570 supplied final archives contain APK only.
- Isolated working version: V571; not released, built or device-tested.

## Authorized scope
1. New Profile reference `138431.png`: clean cover, top-left menu/top-right cover edit, overlapping photo, single photo presence dot, one-line name, ID + LV (official 0001–0003 keep visible ID, no LV or Special MS badge in this phase), retained Bio, private-safe Intro + See Details, stats, other-user Add Friend + Message, six owner shortcuts Wallet/Store/Join Live/Top Gifters/View As/Links, compact friends preview, Posts/Gallery, own composer. Summary retained in own menu. Preserve owned items within Store; no financial/economy or Live seat redesign.
2. Profile field privacy, server-safe public preview, Friend Request + separate Auto Follow, account deletion at Menu > Settings & Privacy > Account & Data > Delete Account. Secure true deletion, public request URL, documented legitimate retention, real SDK/privacy audit. No false password/technical claims.
3. Admin reference images 138009/138042/138043/138044/138051: compact purple/navy dashboard, menu drawer, actual request badges, main folders, truthful finance/system status, admin-only language, personal theme/card color/20 presets (10 Sun + 10 Moon), usable zoom and mobile layout. Existing API/DB/permission logic preserved.
4. Each feature/module has its own identifiable Admin folder; relevant requests show pending/new badges on matching folder and open matching queue; actual authorized counts, completion reduces pending count. Admin folder controls apply only where relevant: CRUD/draft/preview/publish, visibility/status/Coming Soon message, media, link, pricing/offer/time/countdown, drag/order/pin, archive/restore/history; granular sensitive permissions protected on backend.
5. Global Master Rules and current Play rules; no fake completion, no unrelated breakage, no secret exposure, no destructive cleanup. Unready features clear Coming Soon/disabled, listing truthful.
6. Final delivery must contain complete source, assets, Android/build files, backend/migrations, developer handoff and accurate QA/pending status. One unique version; only exact verified canonical signed release artifact if produced; Play AAB vs install APK purposes separate.

## Constraints and next actions
- No local Android SDK/Gradle cache. Actual Java syntax is not Android type-checking. CI can build, but existing main release pipeline deploys production Worker before build: do not trigger it while work is incomplete. Prepare build-only verification separately.
- Latest baseline already implements personal-detail privacy, deletion handler, real folder notices and many Admin routes. Extend/reuse, not replace logic wholesale.
- User explicitly deferred Special MS badge on 2026-10-07: do not display it in this phase; detailed design will follow in a later phase.
- No changes deployed to production. No original signing secret read or printed.
- Baseline fetched and inspected. Implementation and final QA pending.

## Latest checkpoint
See MY-SHOP-DEVELOPER-HANDOFF.md for actual implemented/checked/pending status. GitHub write blocked HTTP403; local git push unauthenticated. No remote commit or build/deploy performed.
