# V-598 — GitHub upload ও APK
১. ZIP Extract করুন। এই ZIP-এ project files সরাসরি আছে।
২. সব contents (.github-সহ) repository root-এ upload/commit করুন। শুধু ZIP upload করলে ভেতরের workflow চলে না।
৩. main/master-এ commit হলে MY SHOP Android APK workflow শুরু হবে। প্রয়োজন হলে Actions → MY SHOP Android APK → Run workflow।
৪. মূল signing/Firebase Secrets আগের মতো থাকতে হবে।
৫. সফল build → Artifacts → MY-SHOP-V-598-APK → MY_SHOP_FINAL_RELEASE.apk।
এই ZIP-এ তৈরি APK নেই; GitHub Android build সফল হলে নতুন V-598 APK পাবেন। Pages build Android build নয়।
পরবর্তী developer: MY-SHOP-DEVELOPER-HANDOFF.md ও handoffs/MY-SHOP-V598-HANDOFF.md পড়ুন।
