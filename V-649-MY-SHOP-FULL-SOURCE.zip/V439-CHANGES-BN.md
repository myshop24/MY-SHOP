# MY SHOP V-439 — নোটিফিকেশন সংশোধন

ফোনে পরীক্ষায় অ্যাপের ভেতরের notification পাওয়া গেছে, কিন্তু Android system
notification পাওয়া যায়নি। এটি প্রমাণ করে realtime/in-app অংশ চলছে এবং FCM
client/server সংযোগ সম্পূর্ণ হয়নি।

1. Firebase Android-এর চারটি secret না থাকলে Release Run এখন সরাসরি ব্যর্থ হবে।
2. Cloudflare Worker-এ `FCM_SERVICE_ACCOUNT_JSON` না থাকলেও Run থেমে সঠিক কারণ দেখাবে।
3. Admin → System Health-এ Firebase config, notification permission, FCM token
   registration, শেষ registration সময় এবং শেষ error দেখা যাবে।
4. Firebase config বা initialization ব্যর্থ হলে অ্যাপ এখন কারণ সংরক্ষণ করবে।
5. V-439 / versionCode 439 / versionName 2.9.439 identity প্রয়োগ করা হয়েছে।
6. Clean Debug build ও Android lint সফল হয়েছে।

GitHub Actions secrets:

- `MYSHOP_FIREBASE_API_KEY`
- `MYSHOP_FIREBASE_APP_ID`
- `MYSHOP_FIREBASE_PROJECT_ID`
- `MYSHOP_FIREBASE_SENDER_ID`

Cloudflare Worker secret:

- `FCM_SERVICE_ACCOUNT_JSON`

বাস্তব lock-screen পরীক্ষা করতে V-439 signed APK, deployed V-439 Worker এবং দুইটি
ফোন প্রয়োজন: একটি ফোন থেকে message/Live event পাঠাতে হবে এবং অন্য ফোনে app
background ও screen locked রেখে পরীক্ষা করতে হবে।
