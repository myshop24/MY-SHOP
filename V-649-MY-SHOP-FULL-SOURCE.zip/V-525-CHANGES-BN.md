# MY SHOP V-525 — Major Upgrade

Base: V-524. Existing Old Admin Panel remains preserved and accessible from the new Admin Catalog.

## V-525 additions / locks
- Admin Catalog: Old Admin Panel / Super Admin Panel / MY SHOP E-commerce Admin Panel under the same authenticated admin session.
- Super Admin premium folder sidebar with dashboard summary cards and dedicated routes to existing functional management surfaces.
- Official Message is exposed as a Super Admin folder and uses the existing server-authorized broadcast/schedule/history backend; user-side Official identity is red and message text is deep blue.
- E-commerce Admin has a dedicated catalog entry and routes to the production product/request/held-Gold store administration rather than creating a second ledger.
- Existing Android FCM device push remains enabled for Messages and Live alerts; app foreground presence heartbeat/background offline transition remains enabled.
- Live Page 2 banner content margins tightened while retaining the six-slot auto/manual carousel.
- V-523/V-524 locked Live Room controls, Top-20 summary, realtime/reliability work are preserved.

## Verification
- V-525 source preflight: PASS.
- Worker JavaScript syntax: PASS.
- Commerce tests: 25 PASS.
- Payout inbox tests: 12 PASS.
- V430 backend behavior: 31 PASS.
- V438 premium behavior: 23 PASS.
- Full Android Gradle/APK build: NOT RUN locally because this source package does not contain `gradlew`; CI/device build is still required.
