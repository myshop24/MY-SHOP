# MY SHOP V-544

- লাইভ রুমের নিচে Comment • Game • Mic • More; Game চাপলে Coming Soon। Comment চাপলে আলাদা composer, optional Rocket highlight ও Send খোলে। More-এ Share, Music, Message।
- ডান rail Love • Vote • Gift • Join; Join-এর দুই রঙের link icon দুই fixed রঙে ধীরে ঘোরে। Bottom control row-তে ring/border সরানো হয়েছে।
- Header থেকে host ID সরিয়ে level ও Follow রাখা হয়েছে। Viewer line-এ পাঁচটি avatar এবং overflow count `+99`। Stat line-এ Coin, Gold Coin, Vote; লাল timer dot/time।
- Main guest/logo ring থেকে দুই পাশের wave/teeth বাদ; গোলাকার সূক্ষ্ম animated halo রাখা হয়েছে। Seat grid 4+4 আগের মতো। X host-এর `/live/end` একবার পাঠিয়ে server-confirmed close retry করে; audience X শুধু room ছাড়ে।
- Admin theme: S1–S10 ready Sun, L11 Pure White, আগের 10 Moon; HEX টাইপ ছাড়াই দুই slider দিয়ে light/dark custom background color বাছা যায়। Preview, Save draft, Publish, Reset আছে। Header নীল ও স্থির; body/nav একই palette নেয়।
- Worker draft ও published custom color/revision রাখে। Foreground app সর্বোচ্চ 12 সেকেন্ডে published palette আনে; পাল্টালে খোলা non-live screen reload হয়। Save draft ব্যবহারকারীদের palette বদলায় না।

আগের RTC broadcast/remote auto-subscribe এবং retry logic রাখা হয়েছে। এই পরিবেশে ফোন/দুই-ডিভাইস audio test হয়নি। Android Gradle/SDK ইনস্টল না থাকায় APK build-ও করা যায়নি; নিচে verification সীমা দেখুন।
