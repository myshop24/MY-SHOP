# MY SHOP V-572 — অসম্পূর্ণ কাজ ও Developer Handoff

এটি PARTIAL SOURCE HANDOFF, সম্পূর্ণ/Release Ready নয়। AAB ও Play Console submission বর্তমান scope-এর বাইরে। MS special badge deferred; blue verified badge ও official IDs অক্ষত রাখতে হবে।

## স্থানীয়ভাবে বাস্তবায়িত ও পরীক্ষিত অংশ
- Folder-scoped View/Save Draft grants; Moderator grants/revocation এবং audit foundation।
- Withdrawal operation key, retry/double-tap deduplication, payload conflict ও atomic ledger protection।
- Owner-authorized account deletion, atomic personal-data cleanup, media tombstone/retry queue, Google fresh reauthentication ও Admin false-completion protection।
- feature_* config revision/history/archive/restore/rollback, custom Coming Soon message ও unsafe/inactive destination guard।
- V-572 / 2.9.572 identity। Android 21 local tests passed; targeted Worker regression passed। বাস্তব device/production QA হয়নি।

## বাকি বাস্তবায়ন / যাচাই
1. Root Save Draft ও Publish আলাদা করা। বর্তমান feature_* SAVE সঙ্গে সঙ্গে published configuration পরিবর্তন করে।
2. Moderator private Draft-এর Main Admin review/approval UI এবং conflict-safe explicit Publish।
3. Master 104 controls-এর applicable per-folder/item inventory ও implementation; current history scope শুধু feature_*। Banner/Gift/Product/other scopes পূর্ণ নয়।
4. Action-wise granular permissions, sensitive finance/withdraw/export/permission protection-এর পূর্ণ audit। Legacy non-root Admin broad access যাচাই/সংশোধন প্রয়োজন।
5. Folder/subfolder management, drag/drop/pin/layout, notification badges, schedule/server time, quota/dependency, media quality/translation, backup/recovery এবং সব applicable controls gap audit।
6. Profile 01–48 gap audit ও reference design validation। Shortcut slot 5 এখনও View As; final text spec অনুযায়ী Summary করতে হবে, existing View As menu access preserve করতে হবে। Summary aggregate activity/public-safe backend প্রয়োজন; wallet balance প্রকাশ নয়।
7. Header En visibility real-device validation। Bottom Home/myshop/Support/More icons 24dp-equivalent consistent ছোট করা; Live বড় রাখতে হবে।
8. Profile field privacy/identity sync, stats/friends/auto-follow/message/gallery/posts/composer/links/menus functional+regression QA।
9. Coin/Gold currency, purchased/earned eligibility, Gift/transfer/withdraw/ledger multi-user/runtime financial QA।
10. Account deletion real D1/R2/Google-provider device QA; public deletion website/domain/contact/retention policy deployment যাচাই। Source page থাকা মানেই live URL নয়।
11. Real Host+Guest+Audience Live: invite/call/sound/audio/seat/mute/comments/gift/reconnect/minimize/restore/leave/end QA। Locked seats redesign নয়।
12. Messenger offline/reconnect/block এবং background/closed-app real device push QA। Firebase client/server setup যাচাই।
13. Incomplete commerce/payment/reward/cricket/media public states audit; authorized content rights; hide/disable/Coming Soon; no misleading active entry।
14. Actual permissions/SDK/privacy/Terms/Community Guidelines/current applicable Google Play rules audit। Console submission/AAB এখন নয়।
15. Every visible button/link/screen responsive & regression QA; no false completion percentage।
16. Original signing identity + Firebase config দিয়ে clean GitHub signed APK build; artifact commit/version/certificate/hash internally যাচাই। Backend deployment আলাদা; APK build Worker/D1 deploy করে না।

## APK build-এর বর্তমান বাধা
Local assembleRelease failed at verifyMyShopPushConfiguration: MYSHOP_FIREBASE_API_KEY, MYSHOP_FIREBASE_APP_ID, MYSHOP_FIREBASE_PROJECT_ID, MYSHOP_FIREBASE_SENDER_ID missing। Original release signing key এখানে নেই। কোনো signed installable APK তৈরি হয়নি; এই ZIP-এ APK নেই। Unsigned/debug/replacement-key APK-কে release বলে দেওয়া হয়নি।
GitHub existing signing secrets/cache ও Firebase values থাকলে workflow ব্যবহারযোগ্য; remote সফল build এখন যাচাই হয়নি। Secrets print/overwrite/delete করবেন না।

## GitHub upload
ZIP extract করে project contents repository root-এ upload করুন, .github/workflows/my-shop-apk.yml-সহ। শুধু ZIP upload করলে repository-তে ওই workflow আগে থেকেই থাকতে হবে; ZIP-এর ভেতরের workflow GitHub নিজে activate করে না। বিকল্প: root-এ এই V-572-MY-SHOP-SOURCE.zip রেখে existing matching workflow run করুন। Actions → MY SHOP Android APK → Run workflow। Success হলে artifact-এ MY_SHOP_FINAL_RELEASE.apk। Pages build APK তৈরি করে না।
Required secret names ও preserved signing checks tools/ci-apk-build.sh এবং workflow-এ আছে; values handoff-এ নেই।

## Resume
V572-RECOVERY-CHECKPOINT.md-এর C07 থেকে continue। পুরো project restart নয়। Existing source/data/locked Live/Profile unrelated modules preserve করুন। Recovery incident-এ হারানো unpublished modifications restored only where documented; পুরনো logs completion proof নয়।
