# V-635 GitHub APK

আগের স্থায়ী repository-তে V-635-MY-SHOP-FULL-SOURCE.zip অপরিবর্তিত আপলোড করুন। আগের root workflow ও Secrets রাখুন। নতুন repository হলে .github-সহ পুরো ZIP extract করে root-এ দিতে হবে।

Actions-এ নির্বাচিত source V635 / 2.9.635, versionCode635 এবং intended commit মিলিয়ে দেখুন। Android build, পুরোনো signing certificate ও provenance যাচাই সফল হলে সেই run-এর MY_SHOP_FINAL_RELEASE.apk নিন। পুরোনো APK নয়।

এই সংস্করণে শুধু FolderNoticeActivity-এর Java lambda variable conflict ঠিক হয়েছে। ২য় ধাপের নতুন ফিচার এখনও যোগ হয়নি। স্থানীয় পূর্ণ Android build যাচাই হয়নি; ZIP-এ APK নেই।
