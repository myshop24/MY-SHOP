# V-551
১. দেওয়া Firebase Android ফাইল যোগ; আগের চারটি missing value এখন আছে।
২. Live More: উপরে রঙিন আইকন, নিচে নাম; Share/Music/Messages কাজ রাখা।
৩. V-549-এর সংশোধন ও সম্পূর্ণ সোর্স বহাল।

লোকাল source/resource/backend পরীক্ষা পাস। CI APK build ও ফোনে কার্যক্রম পরীক্ষা বাকি। Device push-এর জন্য একই Firebase প্রকল্পের Worker service-account secret ও বাস্তব পরীক্ষা প্রয়োজন। এটি সোর্স ZIP, APK নয়।
