# V-560 — original release signing

The exact owner-supplied `myshop-release.jks.enc` is included. It is an OpenSSL `Salted__` encrypted container. Its password, cipher/KDF/iteration recipe and the keystore passwords/alias were not supplied, so decryption and original certificate identity remain unverified. No replacement signing key is generated.

Keep credentials in private CI secrets/environment, never commit or send plaintext credentials in chat. Required variables:

- `MYSHOP_KEYSTORE_DECRYPT_PASSWORD`, `MYSHOP_KEYSTORE_CIPHER`, `MYSHOP_KEYSTORE_KDF`; for PBKDF2, `MYSHOP_KEYSTORE_ITERATIONS`.
- `MYSHOP_KEYSTORE_PASSWORD`, `MYSHOP_KEY_ALIAS`, `MYSHOP_KEY_PASSWORD`.

Use the encryption recipe from whoever created this encrypted file. Do not guess defaults. `bash tools/restore-signing.sh` supports confirmed AES-256-CBC with PBKDF2-SHA256 or original legacy SHA256/MD5 recipes. An original different cipher requires adapting the script from the actual recipe. It validates the original alias before moving the decrypted key into ignored `.signing/`.

For production, compare the resulting signing certificate against the existing V559 APK using `apksigner verify --print-certs`. Then run `./gradlew clean :app:assembleRelease -PrequirePush`, `apksigner verify --verbose --print-certs app/build/outputs/apk/release/app-release.apk`, and verify version560/package com.myshop.app. An unsigned release APK or debug APK is not the canonical update release.

The existing release workflow also supports the original private signing cache; the encrypted-file fallback is documented here. Production secrets for Cloudflare/FCM stay outside source. `wrangler.toml`, existing D1/R2/RTC bindings and Firebase Android client configuration are retained.

Verified owner V559 APK certificate SHA256: `4c6784cd027679169b60168a3dec744858c56ab681f860880cea435bb2992acd`. The release script now refuses another signing certificate before any production deploy.

The workflow runs only through manual workflow_dispatch; publish_latest_apk=false keeps production untouched. Explicit publication additionally requires MYSHOP_APK_REPOSITORY (a separate APK-only repository) and private MYSHOP_APK_PUBLISH_TOKEN. Existing permanent signing cache must be populated with the original decrypted key. For encrypted restoration, follow the confirmed recipe above locally/private CI first. No production publish was executed during V560 development.
