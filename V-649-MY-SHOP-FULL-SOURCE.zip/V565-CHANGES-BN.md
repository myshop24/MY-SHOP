# V-565 পরিবর্তন — ব্যানার লাইনের নিয়ন্ত্রণ

- Home Page 1-এর ব্যানার লাইনের Admin চালু/বন্ধ সুইচ যোগ; বন্ধ লাইন পাবলিক হোমে বাদ যায়, ফলে নিচের অংশ ফাঁকা না রেখে ওপরে উঠে আসে। বিদ্যমান ব্যানার ডেটা অক্ষত থাকে।
- Live Page 2-এর মূল ব্যানার লাইনের আলাদা Admin সুইচ যোগ; বন্ধ থাকলে carousel ও তার indicator সম্পূর্ণ GONE হয়।
- প্রতিটি ব্যানারের প্রদর্শনের সময় ১–৩০ সেকেন্ড; প্রাথমিক মান ৪ সেকেন্ড। Admin-এ সংরক্ষিত সময় carousel-এ ব্যবহৃত হয়।
- Home Page 1-এর ২০টি slot-এ উপরে/নিচে সরানোর নিয়ন্ত্রণ; Live Page 2-এর আগের চেপে-ধরে reorder ব্যবস্থা অক্ষত।
- D1-এ additive `myshop_banner_sections` ও `myshop_banner_durations` table; বিদ্যমান `banners` table/row অপরিবর্তিত থাকে।
- Android/Worker identity V-565 / 2.9.565 / versionCode 565 করা হয়েছে।

**যাচাই:** ESM/Worker syntax, 326 locked Worker function preservation, migration data-preservation, Android resource preflight পাস। Gradle distribution download sandbox-এর network policy-তে বন্ধ এবং `javac` অনুপস্থিত থাকায় APK build/device test সম্পন্ন হয়নি; production Worker deploy করা হয়নি।
