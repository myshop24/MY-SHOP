# V649 সোর্স / APK বিল্ড
বিদ্যমান ZIP-গ্রহণকারী pipeline-এ V-649-MY-SHOP-FULL-SOURCE.zip অপরিবর্তিত দিন। সরাসরি সোর্স বিল্ড হলে .github-সহ সব ফাইল repository root-এ extract করুন। নতুন repository বা signing key নয়; আগের ORIGINAL signing/Firebase secrets রাখুন।

পরিচয়: com.myshop.app, MY SHOP V-649, versionCode649, versionName2.9.649। tools/ci-apk-build.sh নতুন649 পরীক্ষা, source/DEX/provenance এবং আগের signing certificate যাচাই করবে। Local unsigned QA APK ZIP-এ নেই; পুরোনো APK-ও জোড়া হয়নি।

একই Worker649 প্রয়োজন।0061-এর পরে0062_v649_live_controls.sql staging-এ migration workflow দিয়ে প্রয়োগ করুন; financial/history reset নয়। এই কাজ থেকে Worker/D1 deploy হয়নি।

৪৯টি Android ও১১২টি Node পরীক্ষা পাস; ফোনে দুইজন বক্তা ও আলাদা দর্শক দিয়ে শব্দ/ভিডিও/ক্যামেরা/PK যাচাই এখনও প্রয়োজন। বিস্তারিত বর্তমান handoff ও verification/V649-RESULTS.json-এ।
