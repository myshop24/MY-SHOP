# V581 source testing delivery

Latest owner instruction authorizes partial source ZIP for testing. The pending work below remains outstanding; this list is retained for the next update. Current source581/2.9.581.

# V580 — বর্তমান কাজের অবস্থা (অসম্পূর্ণ)

Bank account-এর private API/editor, Save/Restore guard, compact Profile menu এবং মূল Admin-এর saved Draft review যোগ ও স্থানীয়ভাবে পরীক্ষা হয়েছে। V579-এর Profile/View As/Personal details/En/trolley সংশোধন অক্ষত।

এখনও বাকি: Admin104-এর পূর্ণ applicable controls, সম্পূর্ণ menu configuration ও cross-folder review queue, সর্বত্র editor integration; বর্তমান APK build/ফোনে reference তুলনা; production পুরোনো gift/finance রেকর্ড এবং বাস্তব loading-এর কারণ; payment/push/RTC/public-page যাচাই। Bank catalog বন্ধ থাকলে request বন্ধ থাকবে।

GitHub read পাওয়া যায়, write আগের চেষ্টায়403 হয়েছে। কোনো diagnostic run তৈরি হয়নি। প্রস্তুত read-only workflow production-এ চালানো হয়নি। প্রকৃত সব কাজ শেষ না হওয়ায় এই তালিকা মুছে completion দেখানো হয়নি। নিচে পুরোনো inventory historical; বর্তমান identity580/2.9.580, শেষ delivered source579।

--- Historical inventory; newer state above overrides ---

# V579 — সর্বশেষ পরীক্ষার অবস্থা

প্রোফাইল menu/Admin entry, Public View As, Personal details-এর অবস্থান, Withdraw contrast/ধাপ/Bank entry, En/trolley এবং non-Live color wheel/editor সংশোধন করা হয়েছে। স্থানীয় পরীক্ষা পাস; APK/ফোনে সব দৃশ্য যাচাই বাকি।

বিশেষ বাকি: production-এ পুরোনো gift/finance রেকর্ড না আসা ও loading-এর আসল কারণ এখনও নিশ্চিত নয়। স্থানীয় fixture-এ পুরোনো রেকর্ড আসে; তা production data-এর প্রমাণ নয়। Bank catalog বন্ধ থাকলে request বন্ধ থাকবে; আলাদা সংরক্ষিত Bank account বই/API এখনও যোগ হয়নি। Full 104 controls ও সর্বত্র design editor সম্পূর্ণ নয়।

এই ফাইলের নিচের V575 অংশ historical inventory; পরের কাজের baseline V579, release identity 579 / 2.9.579। V578/পুরোনো ZIP overwrite করা যাবে না। Live-সংশ্লিষ্ট পরিবর্তনের আগে নির্দিষ্ট owner অনুমোদন প্রয়োজন।

--- আগের অসম্পূর্ণ কাজের বিস্তারিত ---

# MY SHOP — V575-এর পরে অসম্পূর্ণ কাজ

তারিখ: ৮ অক্টোবর ২০২৬। মালিকের সিদ্ধান্ত: এখন পর্যন্ত কাজ V575 হিসেবে GitHub-এ build করে পরীক্ষা; বাকি কাজ পরের আপডেটে। এটি requirements/status record, ১০০% completion দাবি নয়।

## পরের ডেভেলপারের শুরু
প্রথমে AGENTS.md, MY-SHOP-DEVELOPER-INSTRUCTIONS.md, V575-APPROVED-WORK-BN.md, MY-SHOP-DEVELOPER-HANDOFF.md এবং V575-CONTINUE-HANDOFF.md পড়বেন। V575-কে নতুন baseline ধরে owner-এর APK পরীক্ষার ফল থেকে শুরু করবেন; আগের কাজ নতুন করে rewrite করবেন না। পরের deliverable-এর আগে সর্বশেষ delivered version যাচাই করবেন; V575 আবার ব্যবহার করবেন না। Live code/design/audio/realtime বা সংশ্লিষ্ট shared backend পরিবর্তনের আগে মালিকের নির্দিষ্ট অনুমোদন প্রয়োজন।

## ধাপ অনুযায়ী বাকি
1. Developer rules সোর্সে সংরক্ষিত। পরের update-এ মানা এবং handoff বজায় রাখা প্রয়োজন।
2. Header En, icon alignment ও language placement বিভিন্ন Android width-এ screenshot মিলিয়ে যাচাই।
3. ছোট trolley এবং bottom navigation-এর touch area, spacing ও approved page consistency ফোনে যাচাই। Live layout lock বজায় থাকবে।
4. Loading: বাস্তব startup, feed, profile, media ও slow-network সময় মাপা; offline/retry/reconnect, cache freshness এবং lifecycle যাচাই। বর্তমান local code checks কোনো performance benchmark নয়।
5. User menu: reference অনুযায়ী সব item/destination/visibility, active status, persisted order ও Admin editor পরীক্ষা; অসম্পূর্ণ feature-এর নিরাপদ Coming Soon আচরণ যাচাই।
6. Master Admin 01–104: প্রতিটি folder/item-এ কোন control প্রযোজ্য তার পূর্ণ inventory এবং ঘাটতি implementation। বিশেষ করে folder/subfolder, bulk, drag/drop/snap/layer, SVG/vector/compression, contrast/quality, translation, audience/device targeting, dependencies, backup/recovery। Generic controls আছে মানেই সব 104 শেষ নয়।
7. Admin: granular action permissions, sensitive finance/export/permissions audit; Moderator private draft review/approval UX; সব folder-এর version/history/restore coverage; badge/unread বনাম unresolved state; বাংলা/English editor labels, 20 themes/zoom/preview ফোনে যাচাই।
8. Withdraw: real backend migration ও বহু-user pending/approve/reject/retry; proof/reference, exact hold release, receipt/processing deadline এবং Coin/Gold/source separation end-to-end QA। Local SQLite পরীক্ষাগুলো production D1 পরীক্ষা নয়।
9. Profile: 01–48 ও সর্বশেষ correction অনুযায়ী screenshot fidelity ও সব flow ফোনে QA; official0001/0002/0003 শুধু ID+blue badge, normal users-এর Level; identity sync; privacy accepted-friends-only/API; Summary/Top20 gift contribution; menu/settings/gallery/posts। Account deletion-এর real owner reauth, server/R2 cleanup/retry/retention এবং public URL যাচাই বাকি।
10. Home Page1: প্রাপ্ত PART1-এর1–38 অনুযায়ী সব route, notification/push, Messenger offline/block/reconnect, membership expiry, referral reward/duplicate guard, search/history/post/edit/like/comment/share QA। 38 নম্বরের শেষাংশ ও PART2–6-এর অনুপস্থিত লেখা অনুমান করা যাবে না।
11. Visual design: বর্তমান editor ছয়টি non-Live scope-এ আছে। সব অনুমোদিত জায়গায় একই wheel/selection/editor integration এখনও সম্পূর্ণ নয়। Tap selection, apply color to matching elements, undo/redo, copy/paste, draft/publish/history/restore Android-এ যাচাই; layout overflow/contrast এবং cache sync পরীক্ষা। Live ও locked Profile অনুমতি ছাড়া editor-এ যোগ নয়।

## Release/বাহ্যিক যাচাই বাকি
- GitHub clean Android compile, unit tests, lint ও signed APK build সফল হতে হবে। স্থানীয় Gradle8.11.1 download নেটওয়ার্কে ব্যর্থ; এখানে APK তৈরি হয়নি।
- Original signing certificate ও Firebase config দিয়ে build; secret values chat-এ দেওয়া প্রয়োজন নেই। Existing secrets/config preserve করতে হবে।
- APK-এর version575 /2.9.575, commit/run, timestamp, signature ও artifact মিলিয়ে যাচাই। ফোনে screenshot/reference QA ও install/update পরীক্ষা।
- Real Host+Guest+Audience Live audio, join/invite, seats, gift, mute, reconnect, minimize/end এবং closed-app push regression QA।
- Google Play purchase verification-এর বাস্তব merchant/Play configuration, licensed test purchase, pending/recovery/consume/refund lifecycle। Local mocks পেমেন্ট নয়; production billing চালু করা হয়নি।
- Public account deletion/Privacy/Terms/Community pages বাস্তবে খুলছে কি না, contact ও actual retention/SDK data behavior-এর সঙ্গে লেখা মেলে কি না যাচাই।
- APK workflow Worker/D1/R2 backend deploy করে না। অন্তর্ভুক্ত নতুন backend changes আলাদা review/migration/deployment ছাড়া production-এ পৌঁছাবে না।
- V575-এ অসম্পূর্ণ/পরীক্ষাহীন feature-কে production-ready ঘোষণা করা যাবে না।

## যাচাইকৃত স্থানীয় প্রমাণ
20 root backend suites, V430/V541/V542/V543/V544/V552 Worker fixtures, 248 route handler structural gate, V573-এর356টি unchanged function preservation, Java187 syntax ও resource preflight পাস। tools/v575_verify.sh পুনরায় চালানো যায়। বিস্তারিত verification/ এবং V575-CONTINUE-HANDOFF.md-তে।
