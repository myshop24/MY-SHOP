# MY SHOP V-542 — সম্পূর্ণ সোর্স হ্যান্ডঅফ

মূল সোর্স V-541। এই সংস্করণ `MY SHOP V-542`, `2.9.542`, versionCode `542`। পরের কাজ V-543 থেকে হবে। প্রথমে `00-MY-SHOP-DEVELOPER-INSTRUCTIONS.md`, `V542-REQUIREMENTS-STATUS.md` এবং `V542-VERIFICATION.md` পড়ুন। আগের সব সোর্স/অ্যাসেট রাখা হয়েছে; source ZIP-এ APK, generated build/cache বা গোপন credentials দেওয়া হয়নি।

## প্রথম অগ্রাধিকার: ডিভাইস নোটিফিকেশন

এই পরিবেশে Firebase-এর চারটি client build value, `app/google-services.json`, Worker-এর FCM service-account secret এবং বাস্তব Android ফোন নেই। স্থানীয় সোর্স বিল্ড সফল হলেও সেই APK-তে push চালু হয়েছে বলা যাবে না। ইতিমধ্যে চালু থাকা ব্যবহারকারীর APK/Worker না দেখে তার একমাত্র সমস্যার কারণ বলে এই অনুপস্থিতিকে দাবি করা হচ্ছে না। বর্তমান সোর্সের reproducible blocker এটি।

1. একই Firebase project-এর Android app package অবশ্যই `com.myshop.app` হবে। সেই app-এর `google-services.json` স্থানীয়ভাবে `app/google-services.json`-এ বসান, অথবা CI-এর `MYSHOP_FIREBASE_API_KEY`, `MYSHOP_FIREBASE_APP_ID`, `MYSHOP_FIREBASE_PROJECT_ID`, `MYSHOP_FIREBASE_SENDER_ID` পূরণ করুন। Private service-account JSON চ্যাটে বা source ZIP-এ দেবেন না।
2. Worker-এ একই project-এর `FCM_SERVICE_ACCOUNT_JSON` secret নিরাপদ deployment environment থেকে সেট করুন। Client/server project mismatch হলে token registration এখন স্পষ্ট error দেবে। Firebase Messaging API/OAuth permission এবং সংশ্লিষ্ট server account যাচাই করতে হবে।
3. ব্যবহারযোগ্য push build-এর command: `gradle :app:assembleDebug -PrequirePush`। Firebase client values ছাড়া এই guard ইচ্ছাকৃতভাবে build বন্ধ করে কারণ জানায়। কেবল local compile QA করতে `-PrequirePush` বাদ দেওয়া যায়; ওই APK দিয়ে screen-off push acceptance দাবি করা যাবে না। GitHub QA workflow-এ guard সক্রিয় আছে।
4. Production Worker এবং APK একই V-542 থেকে build/deploy করুন। এই কাজের সময়ে production deploy হয়নি। আগের V-541 server-এ নতুন media/translation/host-share feature সক্রিয় হবে না। Live Highlight নতুন idempotency request ID চায়; নতুন APK ও Worker একসঙ্গে release করুন।
5. Admin → System Health: Firebase configured, app permission, channels, registered token, last received timestamp এবং Worker health দেখুন। token retry ও Android notification settings-এর বোতাম আছে। `FCM accepted` মানে Google request গ্রহণ করেছে; ফোনে শব্দ/lock-screen alert নিশ্চিত হয়েছে নয়।
6. দুটি বাস্তব account/device ব্যবহার করুন: A-তে app foreground করে registration নিশ্চিত করে screen lock করুন; B থেকে message পাঠান, followed host Live শুরু করুন। Notification shade/lock screen/sound এবং notification চাপলে সঠিক Chat/Live room খোলে কিনা যাচাই করুন। Android mute/DND/channel permission সম্মান করা হবে। Recent task থেকে সরানো ও screen off আলাদা পরীক্ষা; Android force-stop-এর ফলকে screen-off পরীক্ষার সঙ্গে মেলাবেন না।
7. ফোনে receipt timestamp নেই: registration/server log/network/FCM project দেখুন। receipt আছে কিন্তু alert নেই: permission/channel/mute/OS settings দেখুন। alert আছে কিন্তু sound নেই: channel sound/DND/phone sound দেখুন। পরীক্ষার build, device, Android version, timestamp লিখুন।

## Highlight-এর পূর্ণ সেটিংস

Admin → Live Streaming → Highlight Fee & Host Share। Main admin server permission প্রয়োজন। Coin fee, host-share enable/disable এবং 0–100% save হয়। Invalid input-এ আগের price আংশিক বদলায় না। disabled হলে host শূন্য; enabled হলে Coin share নিচের পূর্ণসংখ্যায় round হয়, বাকি platform। VAT দ্বিতীয়বার যোগ হয় না। free comment থেকে আয় তৈরি হয় না।

Rocket প্রথমে grey; selected হলে colored glow/pulse ও একটি fee। Config আসার আগে rocket disabled। Coin শুধুমাত্র পাঠানো accepted হলে হিসাব হয়। request ID retry-তে অক্ষত থাকে। delivery failure reservation/refund atomic; host income তখন তৈরি হয় না। Google/DB/R2 বাস্তব credentials দিয়ে এই financial path-এর production acceptance এখনও প্রয়োজন।

SQLite additive schema/runtime trigger-এ `myshop_highlight_payments` আছে। এতে comment hash থাকে, আসল comment text থাকে না। Live text/effect Durable Object-এর সাময়িক session data-তেই থাকে। Pending reservation-এর crash recovery existing five-minute cron-এ age >2 minutes হলে refund হয়; retry একই key দিয়ে করা যায়। Realtime hub key dedup রাখে session clear পর্যন্ত।

## UI / ভাষা / রেফারেন্স

Feed name 20sp bold single-line, LV 11sp পাশে, ID/date নিচে। Like/Comment/Share 22dp সমান আইকন ও কাছাকাছি count, left group। More Apps দুই home-তে একই চার-square 24dp; অন্য nav আইকন/বড় center Live রক্ষা করা হয়েছে। Banner latest direction **ডান থেকে বামে**; আগের বাম→ডান নির্দেশনা superseded। Home hero-এর packaged default fallback সরানো হয়েছে; admin-এর filled active slot ছাড়া কোনো পুরোনো banner বসে না। এক banner স্থির, একাধিক auto/drag/snap।

Inbox white/compact, names 16sp fixed one line, preview 13sp, inline search/unread filter; active কেউ না থাকলে খালি বড় row নেই। Cached বা failed refresh online light দেখায় না। Chat/inbox/privacy/mute local preference এখন account ID অনুযায়ী আলাদা; account switch-এর পরে আগের login-এর chat cache নতুন login-এ দেখানো হয় না। নতুন push payload recipient ID check করে ভুল account-এর notification বাদ দেয়। Chat text 15sp, left/right bubble, private photo/video/audio/file, camera, mute/profile/block/report। Group/video calling-এর mock control নতুন করে দাবি করা হয়নি। বাস্তব microphone/camera/keyboard/playback/reference screenshot যাচাই হয়নি। ছবি আপলোডের limit 20MB। Preview images bounded decode/cache ব্যবহার করে।

Moon/sun EN-এর আগে; preference persisted। bn/en/hi/ar core system labels এবং existing login/register dictionary ব্যবহার করে, header selected code দেখায়। Arabic standard screen RTL। সম্পূর্ণ পুরোনো admin description/error vocabulary এখনও audited/translated হয়েছে বলা যাবে না: requirement 19 partial। User-এর post/comment/name/message অনুবাদ নয়; paid API নেই। Admin → Content translations-এ চার ভাষার নিজস্ব headline/feature/ad/managed title/caption দেওয়া যায়। Empty translated text original fallback ব্যবহার করে; administrator-কে desired text দিতে হবে। Image-এর লেখা পাল্টানো হয় না।

Neutral UI dark surface/contrast policy Home/Inbox/Profile/Wallet/dialog-এ প্রয়োগ হয়; branded images/colors ও Live skin রক্ষা করা হয়েছে। সব screen/custom dialog-এর device visual acceptance বাকি। Existing uploaded avatar-এ সবুজ চিহ্ন আঁকা থাকলে সেটি server presence dot নয়; original photo বদলানো হয়নি।

## যাচাই ও পরের ডেভেলপার

`V542-VERIFICATION.md` এবং 31-row checklist দেখুন। Build pass ≠ phone behavior pass। Firebase real delivery, production data, live streaming end-to-end, reference-perfect dimensions, comprehensive legacy translations ও signed APK acceptance ছাড়া “সব 31টি completed” লিখবেন না। আগের ভালো feature রক্ষা করে এই remaining acceptance সম্পন্ন করুন।

Release signing keystore এই পরিবেশে নেই। Source ZIP 25,000,000 bytes-এর নিচে; APK-এর native Agora library বড় হওয়ায় APK এই সীমার নিচে নয় এবং unsigned local release APK দেওয়া হয়নি। ব্যবহারকারীর সম্পূর্ণ source handoff এই ZIP-ই।
