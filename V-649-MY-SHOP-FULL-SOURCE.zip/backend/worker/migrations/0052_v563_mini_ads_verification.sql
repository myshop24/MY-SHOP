-- Additive V-563: does not replace accounts, wallets, seats or existing room data.
CREATE TABLE IF NOT EXISTS myshop_user_verification (
 user_id TEXT PRIMARY KEY, verified INTEGER NOT NULL DEFAULT 0,
 updated_by TEXT, updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS myshop_mini_ads (
 scope TEXT PRIMARY KEY, revision INTEGER NOT NULL DEFAULT 0,
 payload TEXT NOT NULL, previous_payload TEXT,
 updated_by TEXT, updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS myshop_mini_ad_events (
 scope TEXT, card_id TEXT, user_id TEXT, event TEXT, day TEXT,
 PRIMARY KEY(scope,card_id,user_id,event,day)
);
-- Fixed Authority verification is returned by the server even without these rows.
INSERT OR IGNORE INTO myshop_user_verification(user_id,verified) VALUES
 ('0001',1),('0002',1),('0003',1);
UPDATE myshop_user_progress SET level=0 WHERE user_id IN ('0001','0002','0003');
-- Other users' existing levels and all Star history are preserved.
