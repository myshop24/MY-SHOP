-- V561 additive only. Runtime guards also create these tables safely.
CREATE TABLE IF NOT EXISTS myshop_upcoming_live(id INTEGER PRIMARY KEY CHECK(id=1),enabled INTEGER NOT NULL DEFAULT 0,entries_json TEXT NOT NULL DEFAULT '[]',revision INTEGER NOT NULL DEFAULT 0,updated_by TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS myshop_upcoming_reminders(scope TEXT NOT NULL,event_id TEXT NOT NULL,user_id TEXT NOT NULL,live_at INTEGER NOT NULL,PRIMARY KEY(scope,event_id,user_id));
CREATE TABLE IF NOT EXISTS myshop_upcoming_deliveries(scope TEXT NOT NULL,event_id TEXT NOT NULL,user_id TEXT NOT NULL,live_at INTEGER NOT NULL,kind TEXT NOT NULL,PRIMARY KEY(scope,event_id,user_id,live_at,kind));
CREATE TABLE IF NOT EXISTS myshop_upcoming_scopes(scope TEXT PRIMARY KEY,enabled INTEGER NOT NULL DEFAULT 0,entries_json TEXT NOT NULL DEFAULT '[]',revision INTEGER NOT NULL DEFAULT 0,updated_by TEXT NOT NULL DEFAULT '',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS myshop_folder_notice_migration(admin_id TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS myshop_folder_notice_reads(admin_id TEXT NOT NULL,event_key TEXT NOT NULL,PRIMARY KEY(admin_id,event_key));
INSERT OR IGNORE INTO myshop_upcoming_live(id) VALUES(1);
INSERT OR IGNORE INTO myshop_upcoming_scopes(scope,enabled,entries_json) SELECT 'home',enabled,entries_json FROM myshop_upcoming_live WHERE id=1;
INSERT OR IGNORE INTO myshop_upcoming_scopes(scope,enabled,entries_json) SELECT 'live',enabled,entries_json FROM myshop_upcoming_live WHERE id=1;
