# MY SHOP V-505 — BUILD RECOVERY + 5 LOCKED INSTRUCTIONS

- Fixed missing Android Java symbols/imports shown by the V-504 GitHub failure.
- Preserved existing Like/Comment backend persistence and Messages inbox architecture.
- Added real backend MY SHOP Official notice delivery; Official identity is RED on User Side.
- Added Help Center with FAQ, Support Ticket, Support Thread/Reply and Admin ticket queue foundation.
- Added Admin Official Message controls: title, message, image URL, action URL, expiry and send-to-all.
- Android identity: V-505 / 2.9.505 / versionCode 505.
- GitHub Actions remains final Android compile authority because this workspace has no Android SDK runtime.
