# V648 — সোর্স থেকে APK

আগের স্থায়ী repository/pipeline ও ORIGINAL signing secrets ব্যবহার করুন। বিদ্যমান ZIP-গ্রহণকারী pipeline থাকলে V-648-MY-SHOP-FULL-SOURCE.zip অপরিবর্তিত দিন। সরাসরি source build-এর ক্ষেত্রে ZIP-এর সব ফাইল (বিশেষ করে .github) repository root-এ extract করে বিদ্যমান workflow চালান। নতুন keystore তৈরি করবেন না। SOURCE_BUILD_ID=MY SHOP V-648; versionCode648; versionName2.9.648।

Build-only pipeline: tools/ci-apk-build.sh. Node24, JDK17, SDK36 এবং Gradle8.11.1 প্রয়োজন। আসল runtime assets tools/prepare_build_assets.py দিয়ে পুনরায় তৈরি/হ্যাশ যাচাই হয়। Signed release-এর certificate আগের secret-এর সঙ্গে মিলতে হবে। ZIP-এ পুরোনো APK নেই।

একই Worker648 ও additive migration0061 প্রয়োজন; আগে0060 এবং পূর্বের migrations/Live tables থাকতে হবে। D1 reset করবেন না। এই কাজ থেকে production deploy করা হয়নি। পুরোনো Worker-এ Video mode নিশ্চিত না হলে নতুন client ত্রুটি দেখাবে।

পরীক্ষা: bash tools/v648_target_verify.sh; bash gradlew clean :app:testDebugUnitTest :app:assembleRelease :app:lintRelease -PmyshopOfflineTests. Actual two-phone RTC/PK/Beauty, production D1 এবং original-signed APK গ্রহণযোগ্যতা আলাদাভাবে যাচাই করতে হবে।
