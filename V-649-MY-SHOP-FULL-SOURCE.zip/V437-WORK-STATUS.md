# MY SHOP V-437 — PARTIAL SOURCE CHECKPOINT

THIS IS NOT THE COMPLETED 300-FEATURE DELIVERY. No signed APK is included.

## Implemented source changes

1. Quick Links outer viewport no longer clips the second row at 94dp. Two compact
   rows size to their content; five cells fill the measured horizontal viewport.
   Font-scale-aware row height and zero trailing column gap preserve page width.
2. Physical Store Admin controls are visible below the title instead of hidden
   beyond the horizontally scrolling tabs. Existing product editor and four-slot
   promotion publisher are reused; regular users do not see Admin controls.
3. Physical Store applies system-window insets to avoid the title overlapping
   the phone status bar.
4. Admin Finance has a Coin/Gold Withdrawal Requests inbox backed by the actual
   myshop_creator_withdraw_requests table. Currency filters and ID pagination
   are independent. Request ownership is enforced by the server.
5. Each wallet links to My Withdrawal Requests and available creator earnings;
   successful submission shows request ID and Pending status. Coin cash-out
   wording uses MY SHOP Commission without changing rates or eligibility.

## Payment safety boundary

The new payout inbox is READ-ONLY. It does not pay money, approve requests, mark
requests paid, reject requests, alter creator balances or transfer currencies.
The legacy request-submission implementation is preserved. Its concurrency,
idempotency, settlement, Admin notification and currency-specific conversion
configuration still require a separate audited implementation. Do not treat
visibility in the inbox as completed withdrawal processing.

## Not completed

- The full 300-item accepted roadmap, including the new social, creator,
  personalization, multi-seller, learning, podcast and communication features.
- Push configuration and real lock-screen delivery validation.
- Complete withdrawal decision/settlement and duplicate-payment safeguards.
- Live-empty-state scheduled-event/product-ad fallback.
- New icon artwork, photo upload UI, complete Bengali localization.
- Full Android build, dependency resolution, APK signing and device regression.
- Production D1/R2/RTC and two-device Live tests.

The planning total is not a count of implemented or tested features. Some
roadmap items overlap pre-existing features and must be reconciled individually.
Excluded proposals (Message Requests and My Notes, and rejected unique ideas)
must not be reintroduced merely to reach a numeric total.

## Verification scope

12 new payout-inbox assertions against local SQLite. Existing 25 commerce and
31 legacy SQLite-backed assertions rerun. Java syntax and duplicate-member
checks cover 102 Java sources. These checks do NOT compile Android types, render
the UI, exercise production Cloudflare, test FCM or certify absence of regressions.

## GitHub handoff

This is a full source layout, not an installable APK. SOURCE_BUILD_ID is MY SHOP
V-437; versionCode 437; versionName/Worker version 2.9.437. Upload only this one
V-437 ZIP if intentionally testing this partial checkpoint. Do not represent it
as the full requested release. Preserve the previous ZIP/signing key and back up
D1 before any deployment. Existing release automation may deploy the Worker;
review that behavior before running it. New payout-inbox.js must accompany
index.js. Never deploy index.js alone.

Next task: reconcile all accepted requirements into a deduplicated implementation
and acceptance-test inventory, then implement the still-missing workflows. No
background work or future completion is implied by this checkpoint.
