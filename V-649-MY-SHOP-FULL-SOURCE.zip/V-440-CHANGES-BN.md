# MY SHOP V-440 — শেষ কাজের তালিকা

1. Upcoming Live countdown থেকে Remind Me চালু/বন্ধ করা যায়।
2. Premium Shop-এর উপরের Preview Room থেকে category অনুযায়ী product demo খোলা যায়।
3. Host supporter card থেকে gift sender-কে Thank You notification পাঠাতে পারে।
4. Host দুই-option Live Poll শুরু/বন্ধ করতে পারে; audience একবার vote দেয় এবং live result দেখে।
5. Shopping Live এখন physical Store product pin করে; room-এর BUY NOW strip থেকে product/checkout flow খোলে।
6. Store-এ Price Drop Alert এবং out-of-stock product-এর Back in Stock alert আছে; update Store Updates-এ আসে।
7. Low-RAM ফোনে animated remote asset স্বয়ংক্রিয়ভাবে static থাকে; manual Reduce Animation setting-ও কার্যকর।
8. আগের V-440 কাজ—smart dashboard, 14 Quick Links-এর balanced grid, slim 3D portal icons, gallery upload, separated Admin catalogs, wallpaper crop/demo, presence, premium cards, gift history এবং notification pipeline—একই source-এ সংরক্ষিত।

## যাচাই

- Clean `assembleDebug`, `assembleRelease`, `lint`, `test`: PASS (95 Gradle tasks)
- Worker JavaScript syntax: PASS
- SQLite behavior: 25 commerce + 12 payout + 31 legacy/backend + 23 premium = 91 PASS
- Release identity: MY SHOP V-440 / 2.9.440 / versionCode 440 PASS

Signed production APK, production Worker/D1/R2/FCM এবং দুইটি বাস্তব ফোনের lock-screen/Live test source archive-এর বাইরে release gate। GitHub Actions-এ প্রয়োজনীয় secrets দিলে repository workflow matching Worker deploy ও signed APK build করবে।
