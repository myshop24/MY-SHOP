# V-639: তৃতীয় ধাপের অনুমোদিত নির্দেশনা; V638-এ বাস্তবায়িত নয়

১. দেওয়া143017/143016 ডেমোর হোমপেজ: ওপরের ☰,Myshop,Sun/Moon,+,Notification,Search,Message। নিচে Home,myshop,Live,Video,Profile; আগের Home/myshop/Live আইকন বজায়।
২. +Create: Post,Reel/Video,Story,Live। পোস্ট লেখা/ছবি/ভিডিও, Public/Friends/Only me; backend-এ অনুমতি কার্যকর। Reels ওVideo এক বিভাগ। লাইক/কমেন্ট/শেয়ার পাশাপাশি,ডানে Gift।
৩.143024 ডেমো Profile menu, স্পষ্টLog Out। আগেরসবshortcuts ওপরের☰তে আলাদাগ্রুপে: Agent/My Links/What's New/Safety & Privacy/Share, External/Store/Video/General/History,More Apps, Page/Website/My Level/Top Up/Earn Rewards/Admin ওঅন্যবিদ্যমানঅপশন। একইকাজেরঅপ্রয়োজনীয়duplicate বাদ,সুবিধাহারাবেনা।
৪. Adminরং/লেখা/gradient/backgroundবদলাবেন; ইউজারশুধুSun/Moon। হেডলাইনAdminনির্ধারিতরংডিজাইনঅক্ষত; Moonঅন্যঅংশগাঢ়সামঞ্জস্যপূর্ণপঠনযোগ্য। হেডলাইনে > নেই। Headerওheadlineমাঝেরদাগমুছতে হবে; বাকিডিজাইনঅক্ষত।
৫. Story24hপর তালিকা/সার্ভারডেটা/মিডিয়াপরিষ্কার; sharedmediaঅন্যত্রব্যবহৃতহলেভুলেমুছবেনা। Draft24hexpiryঅযথাপ্রয়োগনয়।
৬. বিদ্যমানStorecommentbubbleচেপেছোট/নামলেখাগাদাগাদি ঠিক।143045রেফারেন্স: Avatarঠিকজায়গায়ফিট,ইউজারেরনিজনাম/প্রকৃতlevel/প্রোফাইল,পৃথকলাইনেcomment। লম্বাটেক্সটেheightমানাবে,frameবিকৃতনয়। StoreTryওআসলLiveএএকইrender।
৭. অনুমোদিত১০নতুনdesign:01BlueCrystal,02RoseHeart,03RoyalGold,04Galaxy,05Emerald,06IceSilver,07Dragon,08OceanPearl,09Neon,10Lotus। পরেরসংশোধিতKINGবিহীনgeneratedimagesচূড়ান্তরেফারেন্স;রং/বর্ডার/অলংকরণহুবহু। KINGলেখা/ব্যাজনেই। previewনম্বর/titleআসলcommentেনেই। নাম/ছবি/level/commentdynamic;bitmapএস্থায়ীবার্ননয়।
৮. প্রতিটিনতুনbubbleডিফল্ট300Diamond/30days। Adminবিদ্যমানpanelথেকেপ্রাইজ/মেয়াদবদলাবেন;পরিবর্তননাকরলেডিফল্টেইbuy। নতুনপণ্যseedকখনওAdminoverrideoverwriteকরবেনা। বিদ্যমানBuy/GiveFriend/ownership/expirylogicপড়েযুক্তকরতে হবে;backendবর্তমানpricevalidateকরেকাটবে। Tryফ্রিpreview,কেনাবাEquipনয়। পূর্বেকেনাexpiryঅপরিবর্তিত। Equipকরলেঅন্যরাওতারLivecommentbubbleদেখবে।
৯.140513রেফারেন্সনীলবেগুনীDiamondছবিরbackgroundছাড়াছোটiconpriceএরআগে,iconও300লেখাসমানউচ্চতা/একইbaseline।
১০. পুরোনোসচলফিচারনষ্টনয়;নম্বরভিত্তিকঅগ্রগতি,compiler+backend+UIchecks,পূর্ণsourceGitHubpackage।
