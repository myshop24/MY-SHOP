# V626 — মালিকের অনুমোদিত ধাপ ১–১০
মূল নির্দেশনা: ছবি + চ্যাটের সর্বশেষ সিদ্ধান্ত + Developer Rules। আগে ভালো থাকা কাজ অক্ষত।
১ Password Reset/Login; ২ মূল ইউজার নিয়ন্ত্রণ/Public ID/মোবাইল/ইমেইল; ৩ স্টোরের প্রোডাক্ট দিন; ৪ Rare ID; ৫ My Level পেজ; ৬ একক হারে Level/সব animated badge; ৭ Join notice; ৮ Gift panel; ৯ cumulative combo; ১০ backend/regression/build.
বর্তমানটি PARTIAL CHECKPOINT; পূর্ণ ফল ও বাকি কাজ MY-SHOP-DEVELOPER-HANDOFF.md-এ। ছবির হুবহু মিল বা APK সফলতার দাবি নয়।
আগের Level অক্ষত; অফিস Double বাতিল;100000Coin বা1000Diamond মিলিয়ে+1;LoveReact বাদ; নিচের Send অপরিবর্তিত।
