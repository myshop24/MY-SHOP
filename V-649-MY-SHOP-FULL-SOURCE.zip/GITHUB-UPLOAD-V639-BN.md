# V-639 পূর্ণ সোর্স

১. V-639-MY-SHOP-FULL-SOURCE.zip ফাইলটি সম্পূর্ণ ডাউনলোড করে নাম অপরিবর্তিত রেখে আগের স্থায়ী repository-তে আপলোড করুন। আগের root workflow ও Secrets রাখুন।
২. এই প্যাকেজ নতুন করে সম্পূর্ণ সোর্স থেকে তৈরি; আগের অসম্পূর্ণ V638 ZIP rename বা repaired copy নয়।
৩. Actions-এ SOURCE V-639 এবং2.9.639/versionCode639 নির্বাচন হয়েছে দেখুন। unzip ধাপ সফল হওয়ার পরই Android build চলবে।
৪. build/signing/provenance সফল হলে ওই run-এর MY_SHOP_FINAL_RELEASE.apk artifact ডাউনলোড করুন। ZIP-এ APK নেই; source পরীক্ষাকে APK success বলা হয়নি।
৫. ৩য় ধাপের সব কাজ এখন V-640। V639-এ নতুন Home বা bubble redesign নেই।
