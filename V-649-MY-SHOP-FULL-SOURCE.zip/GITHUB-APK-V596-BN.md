# V-596 GitHub upload ও APK

১. ZIP খুলুন। MY-SHOP-V596 folder-এর **ভেতরের সব contents** GitHub repository root-এ upload করুন—বিশেষ করে .github/workflows/my-shop-apk.yml।
২. Original signing এবং Firebase secrets আগের মতো রাখুন। নতুন key তৈরি করবেন না; secret public file-এ লিখবেন না।
৩. Actions → MY SHOP APK workflow চালান। Job successful হওয়ার পরে Artifacts থেকে MY_SHOP_FINAL_RELEASE.apk নিন। Version হবে V-596 / 2.9.596।
৪. ZIP-এ APK নেই। এখানে full Android build চালানো হয়নি; syntax/Worker/SQLite/regression পরীক্ষা পাস করেছে।
৫. APK build backend deploy করে না। D1/Agency/End Live পরিবর্তনের জন্য V-596 Worker-ও deploy করতে হবে।
৬. আগে ২ ফোনে audio, X End/summary, gift/Join/Invite, app locked push পরীক্ষা; তারপর production metrics ও ধাপে ধাপে load পরীক্ষা।
