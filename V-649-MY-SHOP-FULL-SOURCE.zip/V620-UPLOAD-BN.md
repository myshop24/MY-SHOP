# V-620 GitHub ফুল সোর্স প্যাকেজ

এটি সম্পূর্ণ প্রজেক্ট সোর্স; আগের changes-only checkpoint নয়। এই ZIP-এ APK নেই; GitHub Android build সফল হলে Artifacts থেকে APK পাওয়া যাবে।

১. বর্তমান myshop24/MY-SHOP repository-র root-এ V-620-MY-SHOP-FULL-SOURCE.zip আপলোড করুন। আপনার কার্যকর permanent pipeline সর্বোচ্চ V-number-এর ZIP নির্বাচন করে। পুরোনো workflow/signing Secrets মুছবেন না।
২. Actions খুলে নতুন run-এ SOURCE V620/2.9.620 নির্বাচিত হয়েছে দেখুন। আপনার root pipeline APK তৈরির আগে Worker deploy করে; Worker success APK success নয়।
৩. পুরো Android build সফল হলে Artifacts থেকে একমাত্র signed MY_SHOP_FINAL_RELEASE.apk ডাউনলোড করুন। নতুন run/commit, APK version ও আগের signing মিলতে হবে।
৪. ZIP খুলে পুরো source upload করলে .github-সহ সব ফাইল root-এ রাখুন। বিস্তারিত original signing/Firebase Secrets setup আগের UPLOAD-INSTRUCTIONS-BN.md-তে আছে।
৫. ২৬টি sound build-এর সময় included script দিয়ে তৈরি হয়; assets বাদ যায়নি। Native animation/শব্দের জন্য paid video plan প্রয়োজন নেই।
৬. সার্ভারের ক্যাটালগ/D1 ও আসল ফোনের ফল এখনও যাচাই বাকি; ভুল হলে run-এর প্রথম error-সহ log দিন।
