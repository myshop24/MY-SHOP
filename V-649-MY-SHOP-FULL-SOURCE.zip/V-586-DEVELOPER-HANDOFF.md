# MY SHOP V-586 — Developer Handoff / Source Checkpoint

This is a complete source project, NOT a signed APK or a claim that all requested features are finished. Based on V585 after comparison with V570/V575/V584. User requested sequential work with visible task numbers; the current focus is **1/5 Profile**. Next delivered version must be V587, never reuse V586.

## Identity and baseline
SOURCE_BUILD_ID: MY SHOP V-586. Android versionCode: 586. versionName: 2.9.586. Worker health/source identity: V-586 / 2.9.586. Package/signing/Firebase/Cloudflare configuration retained. No deployment performed. No private release keystore or signed APK in this package.

## Current implemented source
- Home avatar opens compact Side Menu; drawer identity opens own full profile. Profile cover menu opens separate Profile Actions drawer. Admin entries are own/admin only, with existing Admin Gate. Ordinary users do not get Admin controls.
- Own profile: cover/avatar edit routes, name pencil, Followers/Following/Posts, Edit Profile/Create Post/Message Inbox, six shortcuts, fixed bottom navigation, Posts and embedded Photos/Videos Gallery. Other profiles have Add Friend/Message/three-dot drawer. Existing Saved Posts, gift summary, peer transfer and friends access retained.
- Personal Details: twenty fields including Name/ID/Bio/Photo/Cover/Join Date/Social Links, compact field rows, per-field editor and Public/Friends/Only Me/Custom. Custom grants validated, replaced atomically, revoked on removal. Core metadata always comes from the account; editing visibility cannot change immutable ID or spoof account identity. Legacy clients cannot clear existing core privacy when saving optional details. Profile-page core response is masked for viewers. Public content elsewhere is explicitly outside this page visibility setting.
- Other-user drawer: Message/Follow/Friend/Premium Gift Request/Block/Report/message notification mute/Share/Copy/Transfer. Gift request shows base/VAT/total hold and refuses changed quotes before wallet access. It is an approval request, not a completed animated Live gift.
- Four non-Live Home bottom items translated 7dp down. The existing central Live behavior/dimensions are preserved.
- Dark navy/purple My Wallet overview and existing Coin/Gold withdrawal flow. Spendable and eligible earnings are independently loaded. Buy reads actual published Coin/Gold packages and uses existing Play Billing/server verification.
- Admin Withdraw entry opens Requests or Settings. Master Feature Controls gives a searchable route into canonical existing per-feature editors for Draft/Publish/Coming Soon/archive/delete/history. It does not certify all 104 controls.
- Bounded selected-text color/gradient/size segments added to existing owner design editor; backend validates them. Shared wheel keeps per-account recent/favorite colors across app restarts/updates on that device. Owner design writes require active ADMIN identity 0001/0002/0003.

## Last verified checkpoint
Run `bash tools/v586_verify.sh` from project root. Includes historical complete local suite plus new privacy, response masking, gift quote, text-segment and shipped Profile UI-state fixtures. Java parsing/resource references/package checks pass. 349 locked baseline Worker functions remain exact, excluding eleven documented scoped handlers. Local verification log is in verification/V586-local-verification.log. Rasterized vector-icon QA was performed; this is not Android screenshot QA.

No Android SDK/Gradle distribution cache is available; Gradle download fails in this environment. No full Android type/APK build, signed release, production D1 test, real payment, device visual/push/RTC test or pixel-perfect certification has been performed. Do not describe local fixtures as a real-device pass.

## Latest owner correction — must retain
CoinWithdrawalActivity.java and WithdrawalCatalogAdminActivity.java are byte-for-byte V585. Do not replace amount options/calculation with demo numbers such as 3,000. Keep server amount catalog, original commission/conversion/quote calculation and Admin amount editor. Purchased Coin/Gold Coin remains non-withdrawable.

## Unfinished / next tasks
1. Audio Call, Video Call, Restrict and Live Invitation currently open an honest Coming Soon message. Dedicated Live History is also Coming Soon. Do not describe these engines as implemented.
2. Profile-context Make Room Admin needs current active host/permission context. Before any RTC/Live code, shared audio/engine behavior, invitation or room-admin integration change, obtain specific owner approval under AGENTS.md/DEVELOPER_RULES.md. General implementation authorization is not Live approval.
3. Proposed call work for approval: a separate call screen and authenticated caller/recipient signalling, microphone/camera permission and Agora session lifecycle, plus a guard against simultaneous Call and Live using the shared RTC/audio engine. Profile Live Invitation/Room Admin actions must use real active host and existing permission checks; ordinary users never get those controls. Existing Live audio/state must pass real-device regression after such changes.
4. Perform clean full Android build and real-device image comparison for normal user/admin/other profile/public preview, navigation, upload, Gallery playback, post actions and all privacy levels. Preserve source signing/release pipeline; do not invent a signed APK.
5. Master104 is incomplete: full entity coverage, arbitrary folder CRUD, bulk operations/import/export, richer permissions/workflows, asset quality/contrast checks, analytics/A-B testing/template controls and recovery need implementation/validation where applicable. Existing Master entry is not an implementation of every list item.
6. Owner typography/wheel coverage is limited to current VisualDesign scopes. Profile and other unintegrated app areas still need coverage and stable target design. Favorite colors are device-local, not guaranteed after reinstall or on another device. Live scope remains protected.
7. Wallet non-Bank account-holder UI and final literal reference layout still need review; original financial amount system must remain unchanged.
8. Coordinate Worker/application rollout: new core privacy fields require this Worker source. No production rollout has occurred. Additive grant table is created by normal personal-detail schema path; no financial schema or rates were changed.

## Reference and instruction files
All supplied visual references and profile video are included under references/. V586-REQUIREMENTS-BN.md records five user instructions and the latest amount correction. V586-PROFILE-AUDIT-BN.md records profile mapping and remaining items. Read AGENTS.md, DEVELOPER_RULES.md and the original developer instruction documents before further work. Historical handoffs remain context, not current completion certificates.
