# V634 — পূর্ণ সোর্স ও GitHub APK বিল্ড প্যাকেজ

আগের স্থায়ী MY SHOP repository-তে V-634-MY-SHOP-FULL-SOURCE.zip অপরিবর্তিত আপলোড করুন। আগের root pipeline, Signing ও Firebase/Cloudflare Secrets রাখুন। ZIP আপলোড করলেই নতুন repository-তে workflow নিজে ইনস্টল হয় না; নতুন repository হলে ZIP খুলে .github-সহ সব project ফাইল root-এ দিতে হবে।

Actions-এ সঠিক V634 source নির্বাচন, Worker যাচাই এবং Android APK run দেখুন। শুধু Pages success বা Build successful লেখা যথেষ্ট নয়। SOURCE_BUILD_ID MY SHOP V-634, versionCode 634, versionName 2.9.634, intended commit, original signing ও artifact provenance মিলতে হবে। ঠিক সেই run থেকে একটি MY_SHOP_FINAL_RELEASE.apk নিন।

এই ZIP-এ APK নেই। স্থানীয় Gradle download নেটওয়ার্কে আটকে গেছে; GitHub Android build সফল হলে APK artifact পাওয়া যাবে। কোন কাজ source-implemented ও কোন পরীক্ষা বাকি—MY-SHOP-DEVELOPER-HANDOFF.md-তে আছে। সব কাজ/device acceptance শেষ হয়েছে বলা হয়নি।

ডেটা না থাকলে Profit/Office stock Unverified দেখাবে। পুরোনো GOLD wire/database identifiers এখনো compatibility-র জন্য আছে; নতুন wallet/catalog class-এর নাম Diamond। ব্যালেন্স বা পুরোনো ledger মুছবেন না।
