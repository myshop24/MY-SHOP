# MY SHOP V575 — অসম্পূর্ণ কাজের checkpoint / continue handoff

This is a WORK-IN-PROGRESS backup, NOT a finished V575 release. Baseline is immutable V573. Android/source version markers still V573; update only at final delivery. User paused because ChatGPT usage limit ran out. Continue the same task; do not restart or claim all 11 stages finished.

## Mandatory rules
Read AGENTS.md, MY-SHOP-DEVELOPER-INSTRUCTIONS.md and V575-APPROVED-WORK-BN.md first. Show Bangla progress headings কাজ NN/১১ and keep working. No subagents authorized. Live code/design/audio/realtime/related backend changes require specific owner discussion and approval BEFORE applying. No production deploy, external publishing, payment, GitHub workflow trigger, APK/AAB release or account deletion execution is authorized. Final delivery one source ZIP V575, ideally below 25,000,000 bytes; never remove required code to shrink it.

## Implemented but not device validated
- Permanent current developer rules added to AGENTS and three developer documents; immutable baseline hashes in verification/v575-baseline.json.
- Header plain En preserved; Home header avatar goes to own Profile. Duplicate Main header badge calls and duplicate initial profile fetch reduced. LiveHome behavior guarded.
- Only non-Live trolley size reduced to 24dp; Live nav remains unchanged.
- Home feed cache user scoped with short TTL; loading/retry state corrected. No fabricated performance benchmark.
- Menu remote avatars use existing bounded SafeImageLoader; Privacy Policy and Terms entries added; central External destination.
- Home Media renamed External, routes directly to central External section; Quick Links Help Center removed with compact grid, Support retained. General entry points unified to existing General feature menu.
- Profile Summary + Top Gifters use new Profile-only ProfileGifters presentation over SAME existing authoritative gift endpoint; Live Room LifetimeGifters is untouched. Podium 2/1/3, ranked rows, fixed Your Rank. Summary replaces View As. Own wallet only. About/Personal Details in other-user menu, authorized compact personal details below shortcuts above Friends, See Details opens existing About view. Profile post normal level restored; admin IDs remain blue verification + ID, no LV/MS. Settings About MY SHOP and persisted notification preference toggle added. Edit Profile links to existing per-field privacy form; save disabled until existing details load successfully.
- New owner-only VisualDesign + ColorPicker: target selection, shared wheel, white/black/gray and presets, background/text/word gradients, icon tint, bounded sizes/spacing/radius/border/shadow, real page preview, reset selected target, cancel restoration, server-private draft then separate publish. Protected Live/Profile scopes excluded. Only selected non-Live menu/header/shop/withdrawal scopes integrated. Not every app area supports the new editor yet; do NOT claim all places complete.
- New withdrawal catalog: independent Coin/Gold amount packages, methods, availability/dates, conversion and processing days; owner API + Admin form. Uses existing finance commission rules, does NOT modify shared Live economy. Unified Coin/Gold earned-only form, server quotes, final cancel/confirmation, separate currency balances and operation retry, captured original terms. Gold old hard-coded form replaced with central form. Bank details supported if Admin enables bank. Existing payout approval/rejection/ledger logic retained.
- Generic non-Live feature folders: private Draft Save separated from root Publish. Backend checks current draft AND feature revision and active authorization; Live folders blocked from new publish API. Existing Archive/Restore remains; no destructive user/transaction data removal introduced.

## Critical discovered baseline defect and recovery
A route audit found V573 routes referenced missing functions. This was proven in unchanged V573 tests, not introduced by this work.
Missing originally: messageInbox, messageThread, messageMediaUpload, messageVoiceUpload, messageSend, messageDeleteForMe, messageUnread, mediaGet, adminSafetyReports, playBillingReady, playPurchaseVerify.
Older V569 was retrieved read-only and contains these implementations.
Restored only Messenger handlers, read-only Admin safety reports, read-only playBillingReady to current source. Added private AUDIO origin/ownership checks and nonce-conflict checks. The former failing V541 suite now passes 28 local tests.
STILL MISSING and NOT APPLIED: mediaGet and playPurchaseVerify, plus Google Play helper functions such as playGrantAtomic, googlePublisherAccessToken and base64/key helpers. Shared media serves Live assets; purchase verification credits economy/premium entitlements. Discuss precise restoration and impact with owner and obtain Live-related backend approval before applying. Prepare reviewable proposal first; do not simply copy entire older index.js. Preserve V572 account deletion media tombstone protections (mediaWasDeleted) and current finance/entitlement rules. Existing shared CachedImages also merits privacy/session cache review; it is used by Live so obtain specific approval before changing it.

## Verification actually run
- Java parser: 187 Java sources pass syntax parsing. Android types and APK NOT checked.
- Worker index syntax check passed before last restoration; rerun after subsequent changes.
- Local Node/SQLite suites passed for commerce/finance, payouts, Profile privacy, request notices, deletion/Google reauth, folder grants, feature history, wallet adjustment, withdrawal idempotency, new visual design, new withdrawal catalog, new private feature publish.
- After changing admin-folder-controls to import feature-history, adapted legacy VM fixture to inject real dependency; folder grant tests pass again.
- V541 worker behavior: 28 passed after Messenger handler restoration. Later nonce-hardening should be rerun and covered with targeted tests.
- Broad tools/v564_verify.sh stopped at original missing messageInbox; baseline V573 reproduction failed identically. It has NOT been fully rerun after restoration. Next media tests will likely stop at missing mediaGet pending owner approval.
- APK build attempted with bash gradlew :app:assembleDebug --no-daemon. FAILED before compile: Gradle 8.11.1 download network unreachable. No Android SDK/Gradle cache available here. No APK, signed artifact, device screenshots, real push, RTC, production D1, payment or runtime QA claimed.

## Immediate next work
1. Re-read actual changes, fix any Java type/reference/UI issues; parser alone is insufficient. Final UI visual QA pending.
2. Add/run Messenger nonce/media authorization tests. Re-run current backend tests, XML/resource references and parser. Add full endpoint route-handler completeness gate that intentionally reports remaining missing handlers.
3. Check withdrawal original terms retained through retries; snapshot test was just added to tests/v572-withdraw-request.test.mjs and needs rerun. Expose recorded processing terms/deadline in request history if needed. Validate quotes agree with existing commission rounding.
4. Finish scoped menu/admin controls audit, icon upload sizing/contrast and relevant missing 104 controls. Do not claim 104 complete from generic controls alone. Legal/deletion public URL and policy behavior need verification; no fake URL.
5. Prepare media/purchase recovery proposal and obtain owner approval BEFORE protected shared Live backend changes. Continue independent non-Live work until approval.
6. Finish all approved 11 tasks, regression/device/build acceptance. Update V575 identity consistently and package one final source ZIP. Store final file persistently and deliver with exact remaining limitations if any. This checkpoint is not final delivery.

## Resume 2026-10-08 / owner approval
Owner explicitly approved the discussed media handler and Google Play verification corrections (04:25 Asia/Riyadh). No production deployment/payment authorized. Restored scoped mediaGet from V569 with current deletion tombstone protection and private no-store chat caching. Purchase recovery still being reviewed, especially atomic financial/source/level effects. Current 18 root backend suites pass; Java187 syntax pass; Messenger changed nonce/recipient/attachment and foreign voice ownership tests pass.

## Checkpoint 04:34+ resume implementation
mediaGet restored and V542 50 behavior checks pass (private owner/recipient R2 reads); V543/V544 fixtures now load real deletion-media module. Purchase verification restored with sanitized stored payload/errors, active owner, product/catalog matching, quantity-one guard, account binding derived in readiness and set by Android Billing flow. Currency purchase claim, balance, source and progress ledger now one atomic batch; premium uses existing grant plan. Local V552 tests prove duplicate claim rollback, injected late progress failure rollback, wrong-account and pending-payment rejection and exactly-once endpoint success. Google real service/merchant setup remains unconfigured and untested; acknowledgement/recovery/refund lifecycle needs further review. Existing level formula retained, not redesigned. Resource preflight now supports Android values item declarations rather than falsely missing visual_design_state. Withdraw inbox exposes only bounded snapshot processing terms to existing authorized viewers; old requests still compatible. Target inbox and withdrawal suites passed; Android runtime/compile still pending. All stages remain WIP.

## Checkpoint 04:40 continuation
Profile post avatar now uses current loaded profile photo and author name; long bio limited to two lines with tap-to-expand dialog. Java syntax187 and resource preflight pass. Broad verification advanced through legacy Live/finance/banner tests using actual JDK JavaCompiler via a temporary launcher (javac binary absent); stopped at historical V561 locked hash for updateMyPersonalDetails, not a functional test failure. Do not waive that guard blindly; compare immutable V573 functions to current scoped changes and retain audit evidence. Full Android build still unavailable. ALL11 stages remain unfinished.

## Current continuation — 2026-10-08 (not final delivery)
- Visual history / restore to private draft, audit/CAS rollback; tap selection on actual page; copy/paste, undo/redo, bounded rotation/opacity; confirmed current-scope apply selected color to matching components. Scope remains six non-Live areas, not all app areas.
- Generic non-Live permanent delete requires owner, prior archive, current revision, explicit confirmation/reason; atomic retained audit and matching private draft deletion. Protects financial/Live/Profile categories. Failure leaves content and draft intact.
- Admin upload preview FIT_CENTER and captured upload target, bounds/quality checks. No claim of compression/SVG/all104 completion.
- Legacy non-Live direct content publication bypass rejected before mixed payload mutations; private draft and explicit publish required. Protected Live path unchanged.
- Public privacy/deletion source explanation expanded to match supported per-field visibility, hashed passwords, real service processors, personal deletion and retained finance/security records. Public URL inaccessible from this environment; no public deployment verified.
- Added actual V573 function baseline preservation: 356 unchanged named functions; four scoped changed functions explicitly listed. Historical V561 guard still intentionally not waived.
- New route structural gate verifies 248 handlers and named exports, including recovered missing Messenger/media/Play handlers.
- Local tools/v575_verify.sh passed: 20 root suites plus V430/V541/V542/V543/V544/V552 actual Worker fixtures, Java187 syntax and resource preflight. Real SQLite rollback/owner separation/idempotency checks; mocks are not real Google transactions.
- Profile unavailable/null-response now has tap retry and lifecycle checks rather than a dead-end title. Parser/resource check repeated after this UI change.
- Android build attempt again failed before compile: Gradle8.11.1 download Network is unreachable. SDK/signing/Firebase/runtime/RTC/push/payment/public URL QA not established. No APK created, no production deploy, no payment/deletion executed.
- Outstanding: full per-folder104 applicability/implementation audit, all-area color wheel integration, granular permission/draft review and runtime reference acceptance; real Android compile/device/regression, external configuration/payment/URL QA. Never infer100% from local suites.
