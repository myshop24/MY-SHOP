# V-549 — সোর্স পরিবর্তন ও অবস্থা

১. হোস্টের নামের রঙ ও টাইম alignment সংশোধন।
২. আটটি সাধারণ সিট বেগুনি স্বচ্ছ গোল, ছোট সাদা চেয়ার; সোনালি outline বাদ।
৩. মেইন গেস্ট খালি থাকলে দেওয়া MS ছবি, গেস্ট থাকলে প্রোফাইল ও halo।
৪. কমেন্ট keyboard composer-এর dim বাদ, icon-only Send, Rocket logic রাখা।
৫. Host X → Cancel/Confirm; session heartbeat লাইভ আবার চালু করতে পারবে না।
৬. Firebase ছাড়া release build থামবে; server push config না থাকলে diagnostics-এ ত্রুটি। বাস্তব ফোনের push এখনও যাচাই হয়নি।
৭. Gift animation-এর পুরো-screen dark/gray layer বাদ; ব্যর্থ send-এ gift panel খোলা থাকে।

লোকাল backend/regression/resource পরীক্ষা পাশ। Android build/ফোনের UI/RTC/Push পরীক্ষা বাকি। এটি সম্পূর্ণ সোর্স হ্যান্ডঅফ, APK নয়; ১০০% runtime verified দাবি করা হয়নি। বিস্তারিত MY-SHOP-DEVELOPER-HANDOFF.md।
