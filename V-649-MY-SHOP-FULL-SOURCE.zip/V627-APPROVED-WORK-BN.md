# V627 অনুমোদিত সংশোধন
মালিকের বিল্ড-ব্যর্থতার ছবি অনুযায়ী AudioLiveRoomActivity gift overlay View/FrameLayout compiler error ঠিক করা, regression যাচাই ও পরবর্তী full GitHub APK source/build package।
Live behavior/UI/RTC পরিবর্তন নয়। V626-এর অসম্পূর্ণ ১–১০ কাজ অপরিবর্তিত handoff-এ থাকবে। পরের নতুন ডেলিভারি V628।
