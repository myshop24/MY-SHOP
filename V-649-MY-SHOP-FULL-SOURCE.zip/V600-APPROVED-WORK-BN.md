# V600 — সর্বশেষ অনুমোদিত কাজ

Owner: Touhid ভাই। V599/2.9.599 পূর্ণ source থেকে V600/2.9.600। সর্বশেষ চ্যাটের নির্দেশনা পুরোনো নির্দেশনার ওপর প্রাধান্য পাবে।

১/ KING, QUEEN, ROYAL, VVIP, VIP: সরবরাহ করা আসল ভিডিওর frame/আলো animate হবে; photo স্থির। KING plaque-এ KING। Catalog, preview, profile ও Live একই renderer।
২/ ওই identity-র সঙ্গে matching comment box। Live-এ member comment ও catalog demo একই shared background/design।
৩/ প্রতি Host-এর lifetime completed gifts থেকে Top20/Top1; আজকের session দিয়ে Top1 নির্ধারিত নয়। এক Coin বেশি হলে নতুন Top; সমান হলে পূর্বের Top।
৪/ Top1 logo/comment/entry কেবল সেই Host-এর Live-এর ভেতরে; purchasable membership নয়; global profile/feed entitlement নয়; guest seat স্বয়ংক্রিয়ভাবে নয়।
৫/ উপস্থিত lifetime Top1 → KING/QUEEN একই tier → ROYAL → VVIP → VIP।
৬/ একই tier-এ wallet Coin বেশি যার, সে আগে। Top2/Top3 membership-এর আগে বিশেষ priority পাবে না। Gift tie-তে wallet Coin নয়—শেষ নির্দেশ অনুযায়ী পূর্বের Top থাকবে।
৭/ Home post/status/composer avatars plain থাকবে, Admin identity অপরিবর্তিত। Profile খুললে member animation।
৮/ Main Home shortcut row অপরিবর্তিত; General destination-এর row: ☰, General, KING, QUEEN, ROYAL, VVIP, VIP।
৯/ General শুরুতে All Users; পুরোনো ২-column cards/Add Friend/Profile/ID search থাকবে; tier tabs-এ active membership users; expired/revoked নয়।
১০/ Membership বর্তমান Store/catalog-এ যাবে; নিজের photo/name দিয়ে matching preview/comment; পুরোনো catalog controls/Buy Request অক্ষত।
১১/ বর্তমান Admin price/day, লাল user/admin entry, ID search/grant/remove/expiry থাকবে; Diamond price-এর আগে supplied diamond image।
১২/ Finance/Level thresholds/ledger/commission/IDs/D1/R2/package/signing অক্ষত। Live পরিবর্তন শুধু উপরোক্ত membership visual/lifetime order scope-এ অনুমোদিত; RTC/audio/Join/Invite/seat permissions/notifications/End/minimize পুনর্লিখন নয়। Production deployment নয়।
১৩/ এক canonical পূর্ণ V600 ZIP, প্রকৃত পরীক্ষা ও build বাধা, matching Worker নির্দেশনা এবং পরবর্তী developer-এর checkpoint।

Reference mapping: KING=140470, QUEEN=125265, ROYAL=140853, VVIP=140472, VIP=140468, Top1=140854। আসল clips: design/membership-v600; filename/hash mapping: references.json।

এটি অনুমোদিত scope-এর রেকর্ড, ১০০% device-verified completion-এর দাবি নয়। প্রকৃত ফল handoffs/MY-SHOP-V600-HANDOFF.md-তে।
