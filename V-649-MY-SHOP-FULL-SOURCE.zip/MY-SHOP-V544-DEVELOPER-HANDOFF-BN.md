# MY SHOP V-544 • Handoff

Build identity: `MY SHOP V-544`, `versionCode 544`, `versionName 2.9.544`, Worker health `2.9.544 / V-544`.

## Theme configuration

Main Admin → Dashboard & Content → App Themes. Ready Light IDs L1–L10 follow the selected S1–S10 sheet; L11 is Pure White. Dark IDs D1–D10 remain the approved Moon set. Light/dark custom color buttons use visual sliders (no code entry) and derive readable text, card, and border colors. Preview does not publish. Save stores draft only. Publish updates the global selection. `myshop_app_themes` receives four additive color columns at first endpoint use, so no destructive data rewrite is involved. The app fetches the published palette while foregrounded and recreates visible non-live Activities only after published colors/IDs change.

## Live room

The room's lower controls now read Comment, Game, Mic, More; Comment opens the separate composer and Rocket option. More contains Share, Music, and Messages. Right rail order is Love, Vote, Gift, Join. Viewer overflow is capped visually at `+99`; host's profile row shows level/Follow rather than ID. Main guest halo has no external bars/teeth. X directly ends the host room through the existing idempotent/retrying endpoint; a viewer X leaves the room.

## Verify and deploy

- `node tests/v544/worker-behavior.spec.cjs` — 63 checks pass.
- `node --check backend/worker/src/index.js` — pass.
- Android Gradle assembly unavailable here because Gradle and Android SDK are absent; no APK is included.
- Before delivery to users, deploy the V544 Worker, then sign/build with the project's configured release environment and check host + two listener devices for end-to-end audio, X close, theme publish, keyboard composer, and live-room visual alignment. This source handoff does not claim those production/device checks were completed.
