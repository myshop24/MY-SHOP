# V-436 Store handoff

## Deliverable and identity

Full source candidate based on V-435-MY-SHOP-FULL-BUILD-READY.zip.
SOURCE_BUILD_ID = MY SHOP V-436; Android versionCode = 436;
versionName and Worker health version = 2.9.436.
No production deployment, signed APK, live order or wallet change was made.
This file supersedes older release claims inside historical documentation.

## New Store

- Bottom Store navigation opens PhysicalStoreActivity. Premium Shop remains
  StoreActivity and is also accessible from the Store's Premium button.
- Product name, description, category, HTTPS image URL, BDT price, stock,
  publish/disable and soft-delete controls. Deleted products remain in orders.
- Cart quantity/removal; checkout captures recipient name, phone and address.
  COD only. Delivery is explicitly zero; there is no shipping fee/rate editor.
- Server calculates integer-paisa totals, checks the displayed total, reserves
  stock transactionally and protects repeated checkout via a persisted key.
- Orders keep item/price snapshots and status history. Admin transitions:
  PENDING -> CONFIRMED -> SHIPPED -> DELIVERED; PENDING/CONFIRMED -> CANCELLED.
  Cancellation returns stock once. Customers cannot alter admin status.
- Admin product stock saves reject stale stock values after intervening sales.
- Four offer folders, four numbered slots each. Pick a Store product, BDT offer
  price and duration. Replacing/removing a slot does not delete the product.
  Products inside the selected folder appear in a horizontal swipe row.
  Existing folder name/order/visibility controls remain on long press.
- Wishlist, text search and price/in-stock filters; delivered-buyer-only reviews
  with an optional HTTPS photo URL; countdown and expired-offer exclusion.
- Share links point to a public Worker product page with an installed-app link.
  Product details remain public; customer addresses/orders require authentication.
- Store Updates contains order status and opt-in restock notices. No device push.
- Admin metrics count product daily-unique clicks, delivered units and delivered
  revenue. These are NOT per-banner conversion attribution or profit figures.

## Prior UI requests included in source

- Quick Links: five per row, two rows per horizontal page; compact existing art.
  Reference-quality replacement artwork was NOT newly created.
- Page 2 main image: full-width centre crop at 5:2; Admin guidance 1200×480 px,
  60 px text-safe inset. Different image ratios crop; upload 5:2 to avoid it.
- GO LIVE/JOIN LIVE shimmer: only light moves; button bounds/text remain fixed.
- Membership catalog uses neutral Demo User identity. Personal preview/active
  identity remains separate. Must verify every membership tier on device.

## Files and data

New Worker modules: backend/worker/src/commerce.js and product-page.js.
New native classes: PhysicalStoreActivity and ButtonShimmer.
Worker routing uses existing login and Admin authorization helpers.
New additive shop_* tables/triggers are created idempotently on authenticated
commerce access. No automatic migration of old image-only promo banners into
real products: prices/stock must be entered explicitly by the Admin.
Existing legacy six-slot banner APIs/data remain; the new Store folders use
their own four-slot commerce model. Do not confuse the historical tests with it.

## Setup and acceptance gates

1. Review diff/source-preservation report. Back up existing D1 before deployment.
2. Compile Android using the existing project/CI, matching backend modules and
   original signing configuration. Do not upload only index.js: it imports the
   two new modules. Do not assume a source ZIP is installable on a phone.
3. Exercise a staging D1 instance first: create product with stock 2, add to cart,
   place COD order, retry same request, reject a second buyer's oversell, cancel
   and verify stock restoration. Test two concurrent clients, not just SQLite.
4. Verify Admin-only access, buyer isolation, order history, offer expiry and
   return-to-foreground refresh on real Android devices. Check all legacy Live,
   membership, Gold, media, account and navigation flows.
5. Capture measured screenshots at narrow/wide screens and large font sizes.
   Existing native Store UI is functional source, not approved visual QA.
6. Account deletion removes Store addresses, cart, wishlist, reviews, notices
   and click records. Minimal transaction snapshots/internal IDs remain under
   the existing retention policy. It does not cancel orders; the confirmation
   warns users to resolve deliveries first. Review this operational flow and
   retention policy before launch; this is not a legal-compliance certification.

## Known limits / not completed

- No APK compile/sign, Android type check, device test or production D1 test.
- Image URL entry only, not gallery upload. No push delivery or courier tracking.
- No online payment, taxes, shipping-rate editor, returns/refunds or invoice PDF.
- List caps: 500 products, latest 200 orders, latest 100 updates; no pagination.
- No full per-banner sales attribution, new icon artwork or separate live-wave art.
- Offer slots edited by number; no drag-to-reorder promotion UI.
- New Store strings are mainly English; full Bengali localization remains.
- No claim that all earlier requested features are finished or regression-free.

## Verification

verification/v436 contains local test logs and a baseline preservation report.
25 commerce assertions and 31 existing SQLite-backed assertions pass. Java
parser/duplicate-member checks cover 101 sources; they do not resolve Android
types or substitute for Gradle compilation. XML parsing is structural only.
