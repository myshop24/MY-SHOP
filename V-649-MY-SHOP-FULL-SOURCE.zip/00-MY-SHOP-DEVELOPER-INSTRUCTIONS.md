# CURRENT MANDATORY OWNER RULES — 2026-10-08 / V-575

Read this before any work. `AGENTS.md` and `V575-APPROVED-WORK-BN.md` record the latest authorized scope and override conflicting historical text below. Current source baseline V-573; V-574 was documentation only; next delivery V-575.

**LIVE STREAMING IS CRITICAL / HIGH-RISK. Before ANY Live code/design/audio/realtime/related-backend change, shared-helper behavior change, deletion, bugfix or optimization, explicitly inform the owner, discuss proposed change/impact and obtain explicit approval.** General implementation authorization is not Live approval. Continue independent non-Live tasks; inspection/tests do not authorize mutation.

Show active work as `কাজ NN/11 — title` with honest status, without stopping solely to show progress. Follow the current references and latest corrections: official IDs0001/0002/0003 show ID + blue verified only, no Level/MS special badge; normal users retain existing profile/feed Levels. Summary uses gift contribution ranking, never private wallet balances. All color pickers use the shared wheel, no codes required. Save Draft and Publish are distinct. Notification/Terms/Privacy/About and Account & Data deletion remain required.

Keep unchanged approved modules/data/financial ledger/signing/package intact. Use server permission, validation, confirmation and audit for critical actions. No raw passwords/OTP/token in logs/admin/history. Financial operations atomic/idempotent/auditable; purchased vs earned and Coin vs Gold separate. Preserve established MY SHOP Commission rules; historical VAT text cannot silently replace them.

No production deployment/public APK release/AAB is authorized by this source implementation request. Deliver ONE complete latest source package, no V-number reuse, measured file size, current handoff and exact source/build identity. A build pass does not establish runtime, Play compliance or release readiness. Never claim missing real-device/RTC/payment/push/visual verification as passed.

## Historical supporting instructions (only where consistent)

# Latest global instruction update — 2026-10-07

The user-provided Master Developer Instructions 01–65 (including 54.*, 55.*, 65.*) and locked Profile 01–48 govern current V572 work. The latest MASTER ADMIN FEATURE CONTROLS 01–104 are recorded in MY-SHOP-MASTER-ADMIN-CONTROLS-104.md and replace the older common-control inventory without duplicating capabilities. Existing working modules, business rules, original signing and data remain protected. Only applicable controls are shown; release requires actual target/regression/security/platform verification. Build success is not completion or release readiness. The earlier instructions below remain historical/supporting only where consistent with the latest user-approved rules.

# MY SHOP Developer Instructions
_Last updated: 2026-10-04_

This document records the owner's standing requirements for every MY SHOP development handoff. Follow it across future tasks so the owner does not have to repeat these instructions.

## 1. Versioning and delivery

- Every delivered build/file package must use a new sequential version number. Continue from the **last actually delivered version**; for example, V-501 is followed by V-502. Never reuse a version number or guess the next version without checking the last handoff.
- Keep the delivered APK under 25 MB where feasible, to avoid GitHub upload problems. Optimize assets and size without weakening required functionality or the build.
- Deliver one canonical signed release APK for the version. If a ZIP is used, include only that user-facing APK. Include the version identity and developer handoff notes as agreed for that release.
- Report the delivered file's version and size.

## 2. Build and functional verification

- Before building, inspect likely failure points: source/build configuration, dependencies, signing configuration, SDK/toolchain compatibility, and relevant backend bindings/secrets/configuration.
- After building, verify the artifact is from the intended latest source and version, is signed as expected, and is under the target size when feasible.
- A successful build is not proof that a feature works. Install/run the release build and exercise the changed feature end to end: tap controls, navigation, save/publish state, API/backend behavior, media handling, and error states as applicable.
- Test on a real or representative Android device and a slower network where practical. Report any unresolved failures or important pre-existing defects before handoff.

## 3. Reference fidelity and scope

- Read the conversation and inspect every supplied reference image before implementation. Match the actual reference for icon, order, colors, dimensions, spacing, text, and behavior. Do not guess or substitute a different design.
- Compare the finished screen side by side with the reference at the intended mobile size. Avoid clipping, unintended overlap, excess gaps, oversized controls, or one section intruding into another.
- Keep approved/working features locked. Make the smallest scoped change; do not break or remove existing Home, Feed, Live, backend, admin, wallet, notification, or other approved behavior.
- Treat every previously working feature as locked. Before changing code, identify shared screens, handlers, APIs, D1 tables/indexes, Worker bindings, and state used by the target and neighboring features. Do not refactor or alter unrelated behavior as cleanup.
- Preserve existing contracts and defaults. If a target fix requires a shared change, check its effects on every dependent feature and run regression checks for those paths before delivery.
- A change is not complete if it fixes the target but breaks another feature. Resolve the regression before handoff; if a safe fix is not possible, leave the approved feature unchanged, explain the blocker, and do not silently ship the regression.
- If a serious existing defect is discovered, fix it only when in scope and safe; otherwise document it clearly in the handoff.

## 4. Admin controls for new features

- Every new configurable feature must have a complete, organized, premium-looking Admin panel so the owner can operate it without code changes.
- Each relevant icon/control should open the correct Admin settings. Provide only the controls that make sense for that feature, including Add, Edit, Save, Delete, Enable/Disable, Publish/Unpublish, ordering/repositioning, links, gallery media, price, validity/duration, schedule/time limits, and usage limits where applicable.
- Admin must support press-and-hold drag-and-drop reordering where placement is configurable. Save the order persistently and show the resulting order to users.
- For an Agent or Social shortcut, for example, Admin must be able to set its display name, phone number or destination link, icon/image, enabled state, and placement.
- If a necessary Admin control is missing while implementing a feature, add that control as part of the feature rather than leaving the feature unmanageable.
- Admin screens must be clearly labeled, easy to use, and visually consistent with MY SHOP's approved premium styling.

## 5. Visual quality and performance

- Follow the supplied catalog/screen references for color, scale, finish, and premium appearance. Avoid plain default-looking screens when the reference calls for a polished, premium design.
- Preserve the approved MY SHOP palette and each page's established visual language. Maintain legibility at small mobile sizes.
- Optimize real responsiveness, not just animation: measure app startup, tap-to-response, scrolling, API latency, and image/video loading; use pagination, local caching, thumbnails, and CDN caching where appropriate.
- Show immediate touch feedback and non-blocking placeholders while data loads. Do not falsely show success for money, gifts, or other server-authoritative transactions.
- Protect the existing Cloudflare Worker/D1/R2 and Agora/FCM integrations. Do not change schemas, bindings, or live behavior without a scoped reason and migration/regression checks.

## 6. Required task notes for current work

1. **Home header language control:** Put plain `EN` between the moon/theme control and notification bell. Keep it visible, clean like the bell icon, with no border, ring, or emoji, and no overlap.
2. **Speed:** Make MY SHOP's taps, navigation, feed, and media loading feel as responsive as possible, with measured performance improvements and no regressions.
3. **Posting limit (current temporary rule):** Each user may successfully publish one video (including a Reel), one photo post, and one text-only status per rolling 24 hours. Editing an existing post does not consume another quota. Count only successful publishes.
4. **Editing:** Users can edit their existing posts; edits update the same post and do not create a new post or consume another posting quota.

## 7. Regression and handoff

- Before delivery, verify the changed feature and run regression checks for the existing critical paths: login/session, Home and Feed, API/data persistence, Live state and audio, comments, gifts, join/invite, Admin, and push notifications as relevant.
- Check that all intended settings and placements persist after app restart and are reflected in the UI.
- Include a developer handoff with version, completed work, pending work, last checkpoint, next tasks, test evidence, and known issues.
- Never describe a feature as completed based only on a successful build or an unverified assumption.

## 8. Current feature notes (2026-10-04)

5. **Home and Live page banner rows:** Home Page 1 and Live Streaming Page 2 keep separately managed banner rows/sections. Admin can enable/disable each row, reorder banners, and hide a row. If a row is hidden, the content below moves up immediately; do not leave an empty gap. Each banner's display interval is configurable in seconds.
6. **Mini-card ads:** Provide 20 premium ready-made card designs and 20 color choices/palettes. Match the approved long, compact horizontal reference: text on the left, a real gallery image on the right, and softly rounded image-side corners. Gallery selection must set the image itself, never the click URL; store the optional destination link separately. Preview must show the selected image and actual card content. Admin separately controls display seconds and the campaign validity duration in days; the number of days is configurable, not fixed at 30. Expired cards stop displaying automatically.
7. **Mini-card animation and placement:** Use smooth, high-quality layered animation (moving light/shimmer, glow, sparkles, gentle photo zoom). Admin can independently enable/disable the card animation and the brief fire/electric-light flash along the top edge when the card appears. Keep the effect clear without obscuring the card.
8. **Moving headline strip:** Add a compact strip with the same overall dimensions as Breaking News, not a large card. It has its own separate Admin module and configuration; do not merge it with or overwrite the Home Page's existing Breaking News headline. Support multiple independent headline/text layers. Admin can add text, drag each text layer into position, set its size and color, choose a preset or custom color with a color wheel, and preview changes. Keep text and its background grouped: they enter from the right, pause at the Admin-selected point if configured, then move out to the left. Admin can enable/disable this strip and its animation separately. Add the optional top-edge flash toggle described above where applicable.
9. **Cross-page placement:** Both mini cards and moving headline strips can be assigned independently to any available page (for example Home Page 1, Page 2, Page 3, Page 4) or multiple/all pages. Placement controls stay separate from Breaking News. Reuse a content item across selected pages instead of requiring duplicate copies; allow page-specific visibility, order/position and preview at that page's mobile size.
10. **Card tap behavior:** Tapping a mini card opens its configured detail view or destination link. Keep banner text concise; provide full information after the tap.
11. **Verification badge expiry:** Admin chooses the badge validity in days whenever granting/extending it. A value such as 30 is only an example; use whatever duration the Admin enters. On expiry, remove the badge automatically without affecting the user's account or posts.


## V-565 implementation checkpoint — 2026-10-04

The current complete source version is V-565, based on `V-564-MY-SHOP-SOURCE.zip`. The first implementation slice adds Admin visibility controls for the Home Page 1 and Live Page 2 banner rows, gap-free hiding, per-banner 1–30 second display time (default four seconds), and Home Page 1 Up/Down banner ordering. The Live Page 2 press-and-hold reorder remains intact. Changes are additive to D1 and preserve existing banners. Do not mark the Android build/device check complete: this workspace has no `javac`, the Gradle distribution is uncached, and the sandbox blocks the Gradle download. Run GitHub Actions on the V-565 package before release. Other mini-card/headline/post/badge features remain pending for later versions.


## Current delivery checkpoint — 2026-10-04
V-565 is the active implementation based on the complete V-564 source. The first delivered scope is Home Page 1 and Live Page 2 banner-row enable/disable with no blank gap, per-banner 1–30 second display time, and Home Page 1 Up/Down ordering (Live Page 2 drag reorder retained). Verification: Worker ESM syntax, 40 backend behavior groups, preservation guard (326 locked functions), 7 root Node tests, V565 migration checks, and Android resource preflight pass. Android APK build/device verification is blocked because `javac` is missing and Gradle 8.11.1 cannot be downloaded in this environment. Do not claim APK or production deployment success. Other approved mini-card/headline/post/badge features are still pending.
