# MY SHOP V-640 / 2.9.640 — GitHub upload

আপনার বর্তমান স্থায়ী MY-SHOP repository/pipeline-এ `V-640-MY-SHOP-FULL-SOURCE.zip` নাম অক্ষত রেখে আপলোড করুন। আগের ZIP-এর নাম বদলে V640 করবেন না। বর্তমান root workflow ও signing/Firebase/Cloudflare Secrets অক্ষত রাখুন। আগের ভাঙা V638 ZIP নতুন V640 হিসেবে ব্যবহার করবেন না। Pipeline সর্বোচ্চ V-number-এর সম্পূর্ণ ZIP নির্বাচন করবে।

Actions-এর নতুন run-এ source V640/version2.9.640, commit SHA ও signed APK artifact যাচাই করবেন। সফল Android build-এর `MY_SHOP_FINAL_RELEASE` artifact থেকে `MY_SHOP_FINAL_RELEASE.apk` পাওয়া যাবে। পুরোনো run-এর APK এই সংস্করণ নয়।

এই ZIP-এ APK নেই। স্থানীয় Android build Gradle download-এর সময় `Network is unreachable` ত্রুটিতে থেমেছে; source/SQLite checks Android build নয়। GitHub Android build সফল হলে Artifacts থেকে APK পাওয়া যাবে।

সম্পূর্ণ extracted source দিয়ে নতুন repository ব্যবহার করলে ZIP-এর `.github`-সহ সব project files root-এ দিতে হবে; একই repository-তে স্থায়ী ZIP-selection pipeline থাকলে আগের মতো ZIP আপলোডই ব্যবহার করুন। Secrets-এর প্রকৃত মান source বা chat-এ দেবেন না। নতুন signing key তৈরি করবেন না।

`MY-SHOP-DEVELOPER-HANDOFF.md`-তে পরিবর্তন, প্রকৃত পরীক্ষা ও বাকি device/production acceptance আছে। পরবর্তী পরিবর্তিত ডেলিভারি V641 হবে।
