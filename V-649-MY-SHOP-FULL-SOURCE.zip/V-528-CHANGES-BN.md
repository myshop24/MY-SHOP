# MY SHOP V-528
- Page 2 banner guide corrected to 2000×800 (5:2); six independent slots enforced and legacy duplicate rows cleaned on replacement.
- Live right rail re-centered so Music/Love/Vote/Gift/Share stay visible with balanced spacing.
- JOIN made compact to return width to the comment field; locked bottom order preserved.
- Center logo no longer floats/jumps as a full card; asset edge is masked and logo is rendered as a stable center element.
- Existing compact join-request behavior retained; user-line realtime behavior preserved.
- Audio Live Theme admin Save/Publish controls retained (wallpaper + Join Style).
- Live Summary data/top-20 flow retained pending exact visual parity pass.
