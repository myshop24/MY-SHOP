# V-627 — GitHub APK বিল্ড ও ডাউনলোড

এটি সম্পূর্ণ project source; patch নয়। এই ZIP-এ APK নেই; GitHub Android build সফল হলে Artifacts থেকে APK পাওয়া যাবে। আগের ১–১০-এর বাকি কাজ handoff-এ আছে।

১. ZIP খুলে ভেতরের সব project file, `.github`-সহ repository root-এ রাখুন। `.github/workflows/my-shop-apk.yml` অবশ্যই এই প্যাকেজেরটি হবে। এটি build-only; Worker deploy করে না।
২. আপনার বর্তমান পুরোনো main workflow শুধু ZIP আপলোড করলে Worker deploy করে তারপর APK বানায়। শুধু ZIP দিয়ে ওই workflow চালানো build-only পরীক্ষা নয়। আগে প্যাকেজের workflow বসিয়ে তারপর V627 source/ZIP দিন, অথবা আলাদা build repository-তে একই original signing setup দিন। পুরোনো source ZIP মুছতে হবে না; সর্বোচ্চ V627 নির্বাচন হবে।
৩. Original signing cache/key ও Secrets অক্ষত রাখুন। SIGNING-SETUP.md অনুযায়ী প্রয়োজনীয় original signing/Firebase Secrets সেট করুন; নতুন key তৈরি করবেন না।
৪. Actions → MY SHOP Android APK → Run workflow। লগে V-627/2.9.627 আছে নিশ্চিত করুন।
৫. সফল রান → Artifacts → MY-SHOP-V-627-APK ডাউনলোড/Extract → MY_SHOP_FINAL_RELEASE.apk।
৬. APK package/version, original certificate, commit SHA/provenance এবং hash/size মিলিয়ে নিন। ব্যর্থ রান/পুরোনো artifact নতুন APK নয়।

Source identity: MY SHOP V-627 / 2.9.627 / versionCode627। সরাসরি local build: configured environment-এ `bash tools/ci-apk-build.sh`।
