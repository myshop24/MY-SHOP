# V601 — ছোট ZIP থেকেও পূর্ণ Android build

এই ZIP-এ কোনো feature/animation/sound বাদ দেওয়া হয়নি। তৈরি করা29টি runtime file
build-এর সময় project-এর ভেতরের source থেকে পুনরায় তৈরি হয়। পুরোনো ZIP প্রয়োজন নেই।

স্থানীয় Linux/WSL প্রস্তুতি:

```bash
python3 -m venv .asset-venv
.asset-venv/bin/python -m pip install -r tools/requirements-build-assets.txt
# ffmpeg এবং fonts-dejavu-core আপনার package manager দিয়ে install করুন।
.asset-venv/bin/python tools/prepare_build_assets.py
export MYSHOP_PYTHON="$PWD/.asset-venv/bin/python"
bash gradlew :app:assembleDebug
```

Android Studio/Gradle-এর preBuild একই preparation script চালায়। Windows-এ Linux/WSL
ব্যবহার করুন অথবা উপযুক্ত Python/ffmpeg/font path প্রস্তুত করে MYSHOP_PYTHON ঠিক করুন।
GitHub Android workflow এগুলো install/setup করে; original signing/Firebase secrets
দিলে release build হয়। Assets generation সফল হওয়া signed APK সফল হওয়ার সমান নয়।

ছয় animation GIF ও বাইশ WAV sound V600-এর ফাইলের SHA256-এর সঙ্গে হুবহু মেলে।
Queen source video থেকে একই raw copy তৈরি হয়। কোনো পুরোনো ZIP/ফাইল সংগ্রহ করতে হবে না।
113টি PNG-এর বদলে WebP আছে: নাম/resource ID contract, dimensions ও RGBA pixels একই।

আবার source ZIP বানাতে tools/build-assets-manifest.json-এর generated তালিকা বাদ দিন;
source input, compressed FLAC, scripts, manifest, requirements ও .github রাখুন।
Generated output-সহ ZIP বানালে সাইজ আবার বাড়বে। Input/expected hash বদলালে deliberate
owner-approved update করুন; hash mismatch উপেক্ষা করে release দেবেন না।
