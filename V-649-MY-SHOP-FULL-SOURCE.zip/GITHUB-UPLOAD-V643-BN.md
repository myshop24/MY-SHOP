V-643-MY-SHOP-FULL-SOURCE.zip আগের স্থায়ী pipeline-এ অপরিবর্তিত আপলোড করুন। SOURCE_BUILD_ID MY SHOP V-643; 2.9.643; versionCode643। APK স্থানীয়ভাবে তৈরি হয়নি।
