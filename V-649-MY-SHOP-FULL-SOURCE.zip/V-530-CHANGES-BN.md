# V-530 — MY SHOP

## P0 fixes
- Device push notification delivery hardened end-to-end for Live and Message: FCM high-priority payload now contains both notification + data for background/terminated delivery, channel id, click action, sound, plus foreground service handling.
- MainActivity handles push deep-link extras: MESSAGE -> Chat, LIVE_* -> Audio Live Room, OFFICIAL -> Notifications.
- Manifest now declares Firebase default notification channel/icon and a dedicated MYSHOP_OPEN_PUSH action.
- App presence heartbeat tightened to 12s; server stale-online window tightened to 30s. UI-hidden/background publishes offline immediately when possible.

## P1 behavior/routing
- Side menu My Feed, My Shop and Live Streaming now route directly to their real screens instead of generic/admin placeholder routing.
- Live Page realtime list refresh reduced to ~1s while visible so a newly started Live appears much faster.

## P2 visual/data corrections
- Main Home top 3 sections are edge-to-edge: Header + Headline + 3rd menu row.
- Live Page top 2 sections remain edge-to-edge with square/full-width containers.
- Page-2 stale banner cache no longer paints deleted/old banners before server truth arrives.
- Page-2 banner parser enforces one current item per slot and keeps the current 6-slot authoritative data.
- Admin banner recommendation updated to 1500×600 (5:2), matching the live-page display aspect target.
- History now keeps Header + Headline + 3rd menu row fixed/full-width and reserves bottom navigation space.

## Release identity
- V-530 / 2.9.530 / versionCode 530.
- Worker health/version synced to V-530 / 2.9.530.

## Verification
- tools_verify_master.py: PASS
- tools/v516_preflight.py: PASS
- Worker JS syntax: PASS
- Commerce tests: 25/25 PASS
- Payout inbox tests: 12/12 PASS
- Push manifest contract checks: PASS
- Android APK compile not run locally because this source package does not contain gradle-wrapper.jar/gradlew and system Gradle is unavailable.

## Production requirements still mandatory
- GitHub secrets: MYSHOP_FIREBASE_API_KEY, MYSHOP_FIREBASE_APP_ID, MYSHOP_FIREBASE_PROJECT_ID, MYSHOP_FIREBASE_SENDER_ID.
- Cloudflare Worker secret: FCM_SERVICE_ACCOUNT_JSON.
- Real-device acceptance test must verify app-background/terminated Message and Live notifications plus online->offline transition on two devices.
