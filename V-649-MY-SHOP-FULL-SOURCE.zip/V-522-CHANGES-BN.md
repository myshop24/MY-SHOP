# V-522 CHANGES — V-521 Regression Correction Pack

## Main Home
- White reference-style 3-line hamburger; unified premium dark menu strip.
- Media / Membership / Video / General / History same-line sizing/finishing; red Video play treatment.
- Reduced headline-to-menu gap and simplified EN background.
- Photo / Video / Post constrained inside composer-field width in 3 equal segments.
- Removed lower colored three-dot post action; kept only top-right vertical ⋮.
- Bottom Live icon no longer clipped; center white dot pulse/glow remains.
- Home banner converted to smooth looping peek-carousel with auto + manual swipe.

## Home Page 2 / Live
- Bottom label: Go Live.
- Banner categories: All | Following | New | Explore only.
- Banner converted to same smooth looping peek-carousel; compact height.
- Admin banner tap opens dedicated 6-slot manager (Add/Replace, Save/Publish, Enable/Disable, Link, Gallery image, Start/End schedule, Delete).
- LIVE_NOW list refresh ~2.5 seconds for immediate room appearance.

## Start Live
- Approved premium modal implemented from reference.
- MY SHOP brand mark (MY gold / SHOP silver), stylized START LIVE.
- Name input only; no Caption field.
- Equal compact Audio and Video cards; Video shows Coming Soon.
- Cancel red; GO LIVE green.
