# MY SHOP V-542 — 31 agreed requirements and acceptance status

Base: complete V-541 source. This is a reviewable source delivery, not a verified production APK. Latest user corrections take precedence over historical V540/V541 directions.

| No. | Requirement | Status | Evidence / remaining work |
|---:|---|---|---|
| 1 | Screen-off device push first priority | BLOCKED / source correction tested | Firebase client file/env and Worker FCM secret absent locally; no attached phone. Build guard, same-project check, token ownership, notification diagnostics and receipt timestamp added. Real Message/Live lock-screen test REQUIRED. |
| 2 | Real online presence | LOCAL PASS / phone pending | Foreground heartbeat serialized; background/logout publish false; 45-second TTL tested. A green mark baked into an uploaded photo is not a live status badge. |
| 3 | Active Status privacy switch | IMPLEMENTED / local backend pass | Chat settings persists server visibility; failed save restores switch. Inbox suppresses hidden online light. |
| 4 | Approved clean Messenger | IMPLEMENTED / visual acceptance pending | White inbox, restrained blue/purple accents, compact chat. No claim that the generated mockup is a tested Android screenshot. |
| 5 | Inbox name/preview/search/unread/active row | IMPLEMENTED / device pending | Fixed 16sp single-line names, 13sp previews, inline search, unread counts; empty active row hidden; cached/error online badges cleared. |
| 6 | Conversation/media/settings | LOCAL API PASS / phone pending | 15sp bubbles, timestamps/read checks, participant-authorized photo/video/audio/file access, camera picker, voice recording; mute/profile/block/report/settings. Calls/groups are not newly fabricated. |
| 7 | Feed names and Level | IMPLEMENTED / visual pending | 20sp bold, one line, ellipsis; LV 11sp beside name; ID/date below. Existing long-name validation retained; no shrinking names. |
| 8 | Home More Apps icon | IMPLEMENTED / visual pending | Four equal colored squares, no large backing tile; 24dp view. Other peer icons unchanged. |
| 9 | Live Home More Apps parity | IMPLEMENTED / visual pending | Same drawable and 24dp size; opens the same Page 1 Quick Links. Center Live remains large. |
| 10 | Banner latest direction | IMPLEMENTED / swipe test pending | Latest instruction supersedes older left-to-right: automatic motion RIGHT TO LEFT. |
| 11 | Smooth swipe/auto/peek | IMPLEMENTED / device pending | Finger drag, 520ms eased snap, manual both directions, touch pause/resume, existing peeks. |
| 12 | One carousel row | IMPLEMENTED | Existing single main banner row retained; no second row added from the other-app reference. |
| 13 | No blank/deleted-slot default banners | LOCAL BACKEND PASS / image loading pending | Home hero displays only published occupied slots. Removed packaged default hero fallback; strict live_home folder isolation and deletion regressions retained. Broken remote assets still require real R2 inspection. |
| 14 | Dedicated Highlight Admin fee | LOCAL PASS / UI pending | Admin → Live Streaming → Highlight Fee & Host Share. Server authorizes main admin and validates settings before one atomic save. |
| 15 | Grey/selected rocket and one fee | IMPLEMENTED / device pending | Initially desaturated rocket; selected colored glow/light pulse and one admin price. Grey control disabled until config loads. Selection does not charge Coin. |
| 16 | Host share enable/percentage | LOCAL PASS | Disabled: host 0%; enabled: saved 0–100%; floor rounding in Coin; remaining value belongs to platform. Free Highlight creates no revenue. |
| 17 | Clear transparent Send | IMPLEMENTED / keyboard pending | Complete localized Send text, zero minimum padding, 52dp width, transparent background; ready color/glow only when text exists. |
| 18 | Light/Dark before language | IMPLEMENTED / device pending | Moon/sun before EN/BN/HI/AR on both home headers; persisted setting; existing backstack Activities refresh on return. |
| 19 | Whole-system four languages | PARTIAL / acceptance pending | Curated local labels on primary flows and existing login/register dictionary; selected code refreshes; Arabic RTL on standard screens. Legacy uncommon admin descriptions/errors still need a complete translation audit. Do not declare 100% language coverage. |
| 20 | No paid user-content translation | IMPLEMENTED | User posts, comments, messages and names stay original. No paid translation API or new subscription added. |
| 21 | Compact Like/Comment/Share | IMPLEMENTED / reference pending | Left-aligned wrap-content action groups, equal 22dp icons and nearby counts; no three full-width spacers. |
| 22 | Protect existing working features | LOCAL REGRESSION PASS | Existing membership, premium grants, wallet transfers, entitlements, commerce, profile privacy, banner deletion/order and self-like tests pass. No production data deployment/destructive auth SQL. |
| 23 | Reference and real functional verification | PARTIAL / phone blocked | Build/resource/SQLite/authorization/realtime tests performed. No Android emulator/physical phone, screenshots, live audio/camera/keyboard or two-device production push result can be claimed. |
| 24 | Progress/version/full package <25MB | IMPLEMENTED / archive check | V-542 / 2.9.542 / code542. Full source, earlier assets and tests retained; no APK/build output/cache/secrets in delivered source ZIP. |
| 25 | Disconnect timeout | LOCAL PASS / phone pending | A >45-second stale heartbeat renders offline. Failed inbox refresh removes stale online indicators. |
| 26 | Long-name ellipsis, fixed font, LV retained | IMPLEMENTED / visual pending | Fixed name size/weight and one-line ellipsis independent of separate level; existing validation is unchanged. |
| 27 | Single banner stationary, multi auto | IMPLEMENTED / device pending | Auto scheduled only with >1 published hero; zero slots hide row; touch pauses auto. |
| 28 | Highlight atomic payment/idempotency | LOCAL PASS / production pending | Unique request ID retained on failed client retry. Atomic reservation, host split/ledger completion, failure refund including official-source balance; durable hub dedup. Stale pending reservation refunded by existing 5-minute cron after two-minute age. Only comment hash retained in financial record, text stays realtime/ephemeral. |
| 29 | Admin-owned four-language content | LOCAL PASS / UI pending | Admin Content translations editor saves bn/en/hi/ar atomically for headline, ad title/byline, feature labels and managed titles/captions. Blank translation falls back to original; administrator must supply desired texts. Images are unchanged. |
| 30 | Dark mode throughout standard screens | IMPLEMENTED / visual pending | Neutral Home/Inbox/Profile/Wallet/dialog surfaces recolored with contrast preservation; artwork/brand colors retained. Audio Live skin remains dark. Every legacy custom dialog still needs device visual QA. |
| 31 | Per-item honest status report | IMPLEMENTED | This 31-item checklist is the handoff status. Local tests are not proof of production delivery or reference-perfect rendering. |
