# V623: নতুন ধাপের ১ নম্বর — Master Commission + V622 build fix

Owner approved2026-10-14. Continue V622 intact; do not restart/reuse version/signing secrets.

Admin → Super Admin → মূল ইউজার নিয়ন্ত্রণ: বিশেষ ID তৈরি • নতুন ইউজার-এর নিচে/ফিরে যান-এর ওপরে হলুদ বাটন, লাল লেখা মাইশপ কমিশন কয়েন & ডায়মন্ড। শিরোনাম মাইশপ কমিশন যুক্ত করুন। কয়েন বামে, ডায়মন্ড ডানে, স্টোর নিচে।

একটিই Master Enable/Disable switch, মেইন প্যানেলে। Enable সবুজ/কমিশন চালু; Disable লাল/কমিশন ফ্রি। বন্ধে সব অন্তর্ভুক্ত কমিশন0%, মূল হার সংরক্ষিত; চালুতে নিজ নিজ হার ফেরে। দিন/তারিখ/মেয়াদ বা বিভাগভিত্তিক switch নয়।

Rates: 1%,2%…30% select + Save, text input নয়। Coin লেনদেন/GOLD(visible Diamond) লেনদেন পৃথক; একই মুদ্রার সব user transfer entry একই server rate নেয়। Coin/Gold withdrawal পৃথক, additional fee। Store product prices all Diamond and retain individually edited prices. Category-specific Store commission; no extra general Diamond transfer fee. Membership, frame/ring, theme/wallpaper, Rare ID, comment style, entry animation, badge, other/bundle categories. Fixed Main Admin and pre-existing transfer purchased-source exemption preserved. Store commission applies to Diamond store checkout including purchase as a present; it is not a Live currency/catalog gift.

Gift commission excluded from Master/switch; existing gift editor/config/free-period policy remains independent. Normal/official source wallets, old Star/Level/refunds/entitlements stay preserved. Additional deduction: base100+10%=>sender110,receiver100; withdrawal1000+10%=>balance1100,payout1000 equivalent; storeprice100+10%=>110 Diamond. Confirmation shows MY SHOP Commission, not VAT. Current quotes revalidated by server; rate change before confirm rejected; pending requests keep immutable old held terms. Admin active0001/2/3, revision conflict and atomic audit.

Build fix: GiftPanel613.show uses p.levelHandler622.post(p.refreshLevel622). Both old GitHub javac errors reproduced by negative compiler test; real shipped static method compiles after fix. No build-cache/signing workaround.

Inherited V622 task4 remains basic animation quality/premium-video acceptance pending. This scope does not replace that work or claim it finished.
