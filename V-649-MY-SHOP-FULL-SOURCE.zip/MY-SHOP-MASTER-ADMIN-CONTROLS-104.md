# MY SHOP — MASTER ADMIN FEATURE CONTROLS

Latest approved user specification: 2026-10-07. This 104-control list supersedes the earlier 39/40-control inventory; overlaps remain one capability, not duplicate buttons. This is a requirement document, not a completion declaration.

1. Create / Add
2. Edit / Rename
3. Save
4. Folder / Sub-Folder
5. Name / Title
6. Description / Content
7. Duplicate / Copy
8. Bulk Actions
9. Archive / Restore
10. Delete
11. Permanent Delete
12. Add / Replace Icon
13. Emoji Support
14. Premium / Consistent Icon Style
15. Color / Gradient
16. Background / Container
17. Shape / Border / Radius
18. Shadow / Glow
19. Rotate / Flip
20. Opacity
21. SVG / PNG / WebP Support
22. High-Resolution / Vector
23. Auto Optimize / Compress
24. Auto-Fit / Auto-Center
25. Smart Scaling
26. Minimum / Maximum Size
27. Quality / Clarity Check
28. Blur / Pixelation Warning
29. Responsive Auto Size
30. Contrast / Accessibility Check
31. Drag & Drop Position
32. Snap to Grid / Item
33. Spacing / Padding / Margin
34. Align / Distribute
35. Layer / Z-Index
36. Lock / Unlock
37. Safe Area / Overflow Protection
38. Smart Auto-Layout
39. Mobile / Tablet / Screen Preview
40. Reset to Default
41. Preview
42. Enable / Disable
43. Show / Hide / Visibility
44. Coming Soon
45. Publish / Unpublish
46. Draft / Review / Approved
47. Test / Preview Mode
48. Schedule / Auto Publish / Auto Disable
49. Emergency Disable
50. Maintenance Mode
51. Link / Destination
52. Link Validation
53. Price / Offer / Finance
54. Countdown / Time
55. Target Audience / User Segment
56. Priority / Featured / Highlight
57. Limit / Quota
58. Dependency / Requirement
59. Notification / Badge
60. Active / Inactive / Press State
61. Search / Filter / Sort
62. Tags / Category
63. Unique ID / Key
64. Import / Export
65. Asset Library
66. Unused Asset Detection
67. Missing Asset Detection
68. Conflict Detection
69. Language / Translation
70. RTL / LTR Support
71. Device / Platform Availability
72. Responsive Layout
73. Missing Translation Alert
74. Admin / Moderator Permission
75. Role-Based Access Control
76. User Access Control
77. Security / Data Protection
78. Confirmation / Warning
79. Critical Action Protection
80. Change Reason / Admin Note
81. Undo / Redo
82. Rollback / Previous Version
83. Change History / Audit Log
84. Versioned Backup
85. Recovery
86. Cache / Refresh / Sync
87. Replace Without Losing Settings
88. Analytics / Performance
89. Performance Optimization
90. Image Optimization
91. Broken Link Detection
92. Expiry Alert
93. Usage Statistics
94. A/B Testing
95. Component / Template System
96. Copy Style / Paste Style
97. Smart Auto Styling
98. Approval Workflow
99. Admin Activity Alert
100. Developer / Internal Notes
101. Required Field Validation
102. Before / After Preview
103. Google Play / Privacy Compliance
104. FINAL ADMIN CONTROL RULE

## Final rule
প্রতিটি Folder, Sub-Folder, Feature, Icon, Emoji, Banner, Gift, Product ও Content-এর উপর প্রয়োজন অনুযায়ী controls প্রযোজ্য। গুরুত্বপূর্ণ action-এ server Permission + Validation + Confirmation + Audit থাকবে। Permanent Delete শুধু অনুমোদিত Admin করতে পারবে; সাধারণ Restore নেই। Financial ledger/owned data generic content controls দিয়ে delete/copy নয়। Approved locked Profile/Live design generic style controls দিয়ে বদলানো যাবে না।

## Icon quality
Custom Icon/Emoji/Image-এর Auto-Fit, Auto-Center, Smart Scaling, Resolution ও Clarity check প্রয়োজন। Stretch/pixelation এড়াতে source resolution ও dimensions অনুযায়ী bounded sizing; low-quality asset warning; accessibility contrast ও responsive preview। Rights/security validation ছাড়া media publish নয়। SVG rendering/security actual pipeline দিয়ে যাচাই করতে হবে।

## Acceptance
প্রতিটি applicable folder/control-এর implementation + server validation + permission + audit + target/regression QA evidence থাকতে হবে। Unsupported control-এ fake button নয়। বর্তমান status হিসাব evidence-based; 104 বা আগের 252 count completed কাজের সংখ্যা নয়।
