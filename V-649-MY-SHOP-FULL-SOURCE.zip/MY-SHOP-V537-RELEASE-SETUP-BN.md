# MY SHOP V-537 — GitHub APK Release Setup

## Separation

- Keep the source repository private.
- Use a separate public repository only for the friends APK, for example `OWNER/MY-SHOP-APK`.
- Do not copy the source ZIP, source code, Gradle files, or backend credentials into that public repository.

## One-time repository settings

In the private source repository, add this Actions variable:

- `MYSHOP_FRIENDS_RELEASE_REPOSITORY` — the public APK-only repository name as `OWNER/REPO`.

Add this Actions secret:

- `MYSHOP_DISTRIBUTION_TOKEN` — a fine-grained token with Contents read/write access to that APK-only repository, so Actions can create the permanent `friends-latest` release and replace its APK asset.

The signed release pipeline also needs the existing signing, Firebase, and Cloudflare secrets listed in the release workflow. The app's release APK is built from the newest V-numbered source archive in the private repository.

## Build versus publish

Run **Actions → MY SHOP APK Build and Gated Release → Run workflow**.

- Keep `publish_latest_apk` unchecked for regression build only. The workflow builds an installable QA APK artifact and runs Worker syntax and local regression tests. It does not deploy the Worker or change the friends download.
- Only after the owner says `আপডেট দাও`, check `publish_latest_apk`. That job deploys the Worker from the selected source, verifies its version, signs the matching APK, and replaces `friends-latest` in the APK-only repository.

The permanent friends APK address is:

`https://github.com/OWNER/REPO/releases/download/friends-latest/MY_SHOP_FINAL_RELEASE.apk`

Replace `OWNER/REPO` with the configured distribution repository. A private GitHub repository's Release is not a public friends download, which is why the distribution repository must contain only the APK.
