# V-638 GitHub বিল্ড সংশোধন

১. আগের স্থায়ী repository-তে V-638-MY-SHOP-FULL-SOURCE.zip অপরিবর্তিত আপলোড করুন; root workflow ও Secrets আগের মতো রাখুন।
২. Actions-এ নির্বাচিত source V-638, versionName2.9.638, versionCode638 এবং intended commit মিলিয়ে নিন।
৩. Android বিল্ড, পুরোনো signing certificate ও provenance যাচাই সফল হলে ওই run-এর MY_SHOP_FINAL_RELEASE.apk artifact ডাউনলোড করুন। ZIP-এ APK নেই।
৪. run700-এর StoryRail632 reload()/drafts636() method-reference দুটি সঠিক enclosing class দিয়ে সংশোধিত। সংশোধিত আসল method কম্পাইল ও দুই callback চালিয়ে পরীক্ষা; পুরোনো কোডে একই দুই ত্রুটি পুনরুৎপাদিত।
৫. পূর্ণ Android বিল্ড এখানে Gradle download নেটওয়ার্কে আটকে আছে। তাই সম্পূর্ণ GitHub success আগে থেকে দাবি করা হচ্ছে না।
৬. আগের ৩য় ধাপের সব কাজ এখন V-639; V-638 শুধুই বিল্ড সংশোধন।
