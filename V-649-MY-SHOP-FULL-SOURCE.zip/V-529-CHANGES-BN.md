# V-529 — MY SHOP

- Live Page/Page 2: locked two full-width top rows retained; banner height corrected to the 5:2 Page-2 guide and swipe carousel keeps previous/next peeks.
- Live cards: light premium tinted name-card backgrounds added without adding extra fields; Badge → Name → ID + Vote → Location remains locked.
- History: fixed top-header overlap and compacted list; repeated identical destinations are de-duplicated in the rendered history list.
- Banner backend: V-528 one-slot/one-banner replacement and stale duplicate cleanup retained; public Page-2 endpoint returns only latest active slot 1–6 rows.
- Device push: existing Android 13+ notification permission, FCM token registration, high-priority Message/Live channels, server push and deep-links retained and verified in source. Production delivery still requires valid Firebase client build config + Cloudflare FCM_SERVICE_ACCOUNT_JSON secret.
- Online/offline: foreground presence heartbeat + immediate background offline update retained; backend TTL-based online state and privacy flag retained.
- Version: V-529 / 2.9.529 / versionCode 529.
