# MY SHOP V-541 — Developer Handoff

সম্পূর্ণ V-540 source-এর ওপর V-541। App identity `MY SHOP V-541`, `2.9.541`, versionCode `541`; Worker `/health` ও Admin Health একই identity দেখায়। পরের source version হবে V-542। আগের ৩০টি স্থায়ী নির্দেশনা `00-MY-SHOP-DEVELOPER-INSTRUCTIONS.md`-এ রক্ষিত আছে।

## এই সংস্করণে

V-541-এর কাজের তালিকা `V-541-CHANGES-BN.md`-এ আছে। Page 2-তে শুধুমাত্র More Apps-কে Page 1-এর Quick Links-এর সঙ্গে এক করা হয়েছে। Page 2 banner-এর folder isolation/empty cache clearing ও বাম→ডান slot-order rotation, online status visibility, active-now inbox, single-price Highlight, push failure reporting এবং self-like regression সংশোধন করা হয়েছে।

## Push চালু করার শর্ত

Push code path আছে: Android high-priority data message-এ Chat/Live deep-link, Android 13+ permission, token registration, Worker FCM send ও Admin self-test। কিন্তু এই build environment-এ Firebase client build settings (`MYSHOP_FIREBASE_*`) এবং Worker secret `FCM_SERVICE_ACCOUNT_JSON` পাওয়া যায়নি। তাই এই source থেকে তৈরি local APK-তে Firebase client initialize হবে না; ফোনের screen-off অবস্থায় notification বাস্তবে পৌঁছেছে বলে এই handoff দাবি করে না। GitHub Actions build secrets ও deployed Worker secret configure করার পর Admin System Health-এ Firebase config, permission ও token registration যাচাই করে “Send Test Device Notification” চাপুন। FCM গ্রহণ মানে ফোনে দেখা নিশ্চিত হওয়া নয়—একটি বাস্তব Android device-এ lock-screen/notification shade acceptance প্রয়োজন।

## Release সীমা

Debug ও Release assemble এবং release lint সফল। Release APK unsigned, কারণ release keystore এখানে নেই। Build APK-গুলো source package-এ রাখা হয়নি। Production Worker/D1 deploy হয়নি।

## পরের ডেভেলপারের জন্য

- নতুন ফাইলের আগে এই handoff, `V541-VERIFICATION.md` ও ৩০টি developer rule পড়ুন।
- Firebase client/server secrets ছাড়া real push test complete বলা যাবে না। User-কে secret plaintext-এ source/archive-এ দিতে বলবেন না।
- Reference screenshots/video-র final visual check physical device-এ করুন—এখানে Android emulator/device acceptance চালানো হয়নি।
- ভবিষ্যৎ source delivery V-542 থেকে, একটিমাত্র পূর্ণ source ZIP, 25,000,000 byte-এর নিচে।
