# V-535 Live Room Static Audit (BN)

এই audit source-code ভিত্তিক। Real two-device RTC/device runtime test এই environment-এ করা হয়নি। V-535-এ Live Room behavior ইচ্ছাকৃতভাবে rewrite করা হয়নি; build blocker fix-এর সঙ্গে regression risk না বাড়িয়ে ভুল/মিল/অসম্পূর্ণতা নোট করা হয়েছে।

## Source অনুযায়ী যেগুলো ঠিক/উপস্থিত
1. Top host identity-এর পরেই audience/user line আছে।
2. Top-right plain X exit control আছে; Host-এর ক্ষেত্রে End flow, Audience-এর ক্ষেত্রে Leave confirmation।
3. Top compact stats-এ Viewer, Coin, Gold, Vote, Love-এর ৫টি value আছে।
4. Timer আলাদা left-aligned line হিসেবে Main Guest stage-এ আছে।
5. Default 8 guest seats 4+4 visual layout আছে; Host এবং Main Guest আলাদা visual area।
6. Right rail order source-এ Music -> Love -> Vote -> Gift -> Share।
7. Bottom row order source-এ Comment -> Send -> Mic -> Message -> JOIN/LEAVE action।
8. Speaker হলে JOIN -> LEAVE হয়; pending request state-ও দেখায়।
9. Back press Live শেষ না করে PiP/minimize চেষ্টা করে।
10. RTC token renew, publisher/listener role switch, remote-audio recovery, speaking callbacks এবং gift realtime recovery/dedupe logic আছে।
11. Main Guest empty state-এ dedicated logo asset এবং guest present হলে profile + animated halo আছে; profile photo নিজে animate না করে halo animate করার protection আছে।
12. Live Summary-তে Host card, Top 20 supporters, rank 1/2/3 premium styling, live stats data source আছে।

## Source অনুযায়ী যেগুলো reference-এর সঙ্গে এখনও mismatch / risk
1. **Comments position mismatch (High):** code comments area-কে seat grid-এর নিচে dedicated safe-zone বানিয়েছে এবং স্পষ্টভাবে বলে comments seats-এর ওপর উঠবে না। Locked reference-এ comments bottom থেকে উঠে seat area-এর ওপর দিয়ে top-seat line পর্যন্ত যাওয়ার কথা।
2. **Right rail placement risk (High):** Music/Love/Vote/Gift/Share rail `commentStage`-এর ভিতরে আছে। ফলে rail-এর vertical position comment area-এর সঙ্গে বাঁধা, central Main Guest/seat stage-এর সঙ্গে নয়। Reference-like placement drift হওয়ার সম্ভাবনা আছে।
3. **User-line overflow behavior mismatch (Medium):** source সব viewer avatar horizontal scroll-এ যোগ করে। Locked rule-এর visible-avatar cap + overflow count (`+99`/total) logic দেখা যায়নি।
4. **Comment name gender color mismatch (Medium):** standard user name বর্তমানে white; male green / female pink locked rule source-এ implement হয়নি।
5. **Dynamic extra seat cap (Medium):** default 8 visual seats-এর পরে source শুধু backend seat 10 ও 11 render করে। Accepted caller বাড়লে 12+ dynamic seat render করার generic loop নেই।
6. **Host bottom action inconsistency (Medium):** Host-এর `speakerActionButton` text এখনও `JOIN`; tap করলে শুধু বলে Host already live/use X. Locked behavior-এ JOIN audience-only হওয়া উচিত; Host-এর জন্য এই button misleading।
7. **Live Summary tabs not real tabs (Medium):** `Top 20 Supporters | Live Stats | About Host` text আছে, কিন্তু source-এ tab click/switch behavior নেই; এগুলো static label।
8. **Music permission scope needs confirmation (Low/Policy):** source Host/Room Admin-এর পাশাপাশি Main Admin/Moderator-কেও music icon দেখায়। Locked scope যদি শুধু Host + authorized Live Admin হয়, permission filter tighten করতে হবে।

## V-535 সিদ্ধান্ত
- Build failure fix-কে isolated রাখা হয়েছে।
- উপরের Live Room mismatch-গুলো audit হিসেবে নোট করা হয়েছে; এই version-এ Live Room visual/RTC behavior rewrite করা হয়নি, যাতে build-fix করতে গিয়ে working Live feature regression না হয়।
- পরের Live-focused version-এ reference side-by-side ধরে 1,2,3,4,5,6,7 items priority দিয়ে ঠিক করা উচিত।
