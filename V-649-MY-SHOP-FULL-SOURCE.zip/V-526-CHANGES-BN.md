# MY SHOP V-526 — TOP PRIORITY CORRECTION RELEASE

## Locked priority fixes
1. Live Room reference fidelity: locked Music/Love/Vote/Gift/Share and Send/Mic/Message assets from approved reference; Main Guest premium centerpiece updated and animated with existing pulse/float.
2. Device Push: FCM token registration retry hardened, foreground re-sync added, message/live channel metadata aligned, high-priority direct-boot-capable data push retained.
3. Online/Offline presence: app heartbeat tightened to 20s; backend stale online TTL tightened to 45s; background transition still publishes offline immediately.
4. Home Page 2: top/secondary headers full width, Membership/Games/Earn icon+name compact row, carousel keeps side peeks + swipe/auto-slide, LIVE NOW | Following | New | Explore same-size tab row, LIVE NOW red glow with no emoji/box/border, live cards simplified to badge/name/ID+Vote/location.

## Additional fixes
- Host setup refreshes latest server profile name before Live start to avoid stale cached name.
- Audio Live Theme manager now exposes a visible Wallpaper Save / Publish action near the wallpaper controls.

## Verification note
Source/static tests run in this environment. Full Android APK build/device FCM/RTC verification still requires CI/device because this source package does not contain a complete Gradle wrapper executable/JAR.
