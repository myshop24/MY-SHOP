# V603 owner-approved scope — 2026-10-12
1. Original video-derived high-quality membership animation; stable real portrait; same catalog/profile/Live identity. No sway-only replacement.
2. DESIGN12 exact five comment skins, smaller animated right emblems, stable real name/message. KING=QUEEN value, KING blue-silver body, Queen purple, Royal emerald, VVIP amber/black, VIP purple/silver.
3. Replace old ride visuals/catalog including rockets/airplanes with30 approved numbered designs. Preserve earned/purchased money, Admin price/days and existing purchased entitlements via explicit mapping.
4. Articulated ride animation plus sound, right-to-left; do not claim moving still-image is complete.
5. Same catalog/demo/Live renderer; avatar/name personalized; realtime entry delivery retained.
6. Admin Buy Request/grant/revoke/expiry controls retained.
7. Own Host never Top1; lifetime other-sender ranking, incumbent tie preserved; no ledger deletion.
8. Remove extra avatar corner crown/ring only; unrelated mic/RTC/notification/seat logic locked.
9. Target/regression, real compile/sign/device status separately; one full V603 source ZIP with references/input/workflows/handoff. Next delivery V604.
Source audit: static animation auto-low-memory policy + Admin image override are plausible causes; precise device root cause not instrumented yet. No Android SDK/signing supplied locally.
