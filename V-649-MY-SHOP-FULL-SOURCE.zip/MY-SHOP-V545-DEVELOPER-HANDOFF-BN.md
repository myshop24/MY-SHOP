# MY SHOP V-545 • Developer Handoff

Build identity: `MY SHOP V-545`, `versionCode 545`, `versionName 2.9.545`, Worker health `2.9.545 / V-545`.

## V545 scope

- V544 approved Live Room, theme controls and app behavior are retained.
- `.github/workflows/my-shop-apk.yml` now selects either `V-<number>-*.zip` or `MY-SHOP-V<number>-SOURCE.zip` by version, so the delivered archive name is recognized.
- The Android workflow runs the V544 Worker regression suite before building `:app:assembleDebug`, then uploads the APK as `MY-SHOP-V-545-QA-APK`.
- APK build/publish is separate from GitHub Pages. The `github-pages` artifact is not an app installer.

## How to get the V545 QA APK from GitHub

1. Upload this archive to the source repository root using the filename `V-545-MY-SHOP-SOURCE.zip`.
2. In Actions, open the upload-triggered `MY SHOP PERMANENT RELEASE PIPELINE` run for that commit. The separate `pages build and deployment` run is only Pages output.
3. Download the APK artifact from the permanent-release run if its build jobs succeed. If that run has no APK artifact, use the `MY SHOP APK Build and Gated Release` workflow from this archive after installing it at the repository root; keep `publish_latest_apk` false for QA.

## Verification and limits

- Worker JavaScript syntax and V544 Worker regression suite are checked locally; see `V545-VERIFICATION.md`.
- Android Gradle assembly cannot run in this workspace because Android SDK and Gradle are absent. No APK is included in this source archive.
- No production Worker deployment, signed-release build, permanent APK publication, or phone/two-device RTC acceptance is claimed.
- A debug APK is for testing. For an update to an existing installed release, use the established signing key and signed release pipeline.
