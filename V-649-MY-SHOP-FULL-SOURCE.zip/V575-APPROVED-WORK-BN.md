# MY SHOP — V-575 অনুমোদিত ১১টি কাজ

Owner implementation authorization: 2026-10-08 (Asia/Riyadh). Baseline V-573; V-574 was documentation only. Deliver ONE final V-575 source package after the work, not eleven intermediate ZIPs. This checklist records requirements, not completion. Track evidence and limitations in the handoff.

## ০১ — স্থায়ী Developer Rules
কাজের আগে নিয়ম পড়া বাধ্যতামূলক। Source/identity/signing/data preservation; ছবির রেফারেন্স ও সর্বশেষ কথোপকথন; scoped implementation; target + regression QA; honest status. Live Streaming Critical/High-Risk: code/design/audio/realtime/related backend পরিবর্তন, optimization বা deletion-এর আগে মালিককে স্পষ্ট জানানো, আলোচনা ও explicit approval। নতুন নির্দেশনায় historical conflict নিষ্পত্তি; অদেখা Master 01–65 পাঠ বানিয়ে নয়।

## ০২ — Header En
Moon/Sun ও Bell-এর মাঝখানে plain WHITE `En`; border/ring/emoji/box নেই; সমান alignment, মোবাইলে clipping/overlap নেই; language picker কার্যকর। Avatar নিজের Profile খুলবে। Live-কে প্রভাবিত করার আগে অনুমোদন।

## ০৩ — Bottom navigation
138656 reference-এর design/order বজায় থাকবে। শুধু MY SHOP trolley Home icon-এর সমান compact visual size; Home/Support/More এবং বড় central Live অপরিবর্তিত। Page 2 label Go Live বজায় থাকবে। Shared Live chrome-তে প্রভাব ফেললে আগে অনুমোদন।

## ০৪ — Loading (উচ্চ অগ্রাধিকার)
Immediate touch/navigation feedback; cache/dedup/bounded media loading; server request timeout/error/retry; endless loading নয়। Monetary/realtime result-এ fake success/stale balance নয়। মাপা ফল আর শুধু static code improvement আলাদা জানাতে হবে।

## ০৫ — User side menu
138609 reference অনুযায়ী compact clean menu; existing working routes preserve. Profile identity; authorized Admin entry profile area-এ, normal User-এর কাছে hidden এবং server authorization। New Hub, Earn & Reward, orders/cart/favorites/history/gallery/external/active status/website/official/share/language/privacy/terms/support/logout যেখানে supported। Admin background: wheel + 20 presets + actual Preview/Save/Publish/Cancel/Reset. Configurable menu names/icons/routes/ordering feature-এর নিজ Admin folder-এ। অসম্পূর্ণ feature safe Coming Soon।

## ০৬ — Master Admin Controls 01–104
`MY-SHOP-MASTER-ADMIN-CONTROLS-104.md` সম্পূর্ণ required inventory। Folder/subfolder/feature/icon/emoji/banner/gift/product/content-এ প্রয়োজনীয় controls, fake unsupported buttons নয়। Asset নাম/ছবি replace, ratio preserve, auto-fit/center, bounded scaling, quality/contrast warning। User Lock/Coming Soon, permitted Admin access; server enforce। একই feature-এর management একই folder। Feature Delete/Trash/Restore; authorized Permanent Delete-এ reason + confirmation + audit + dependency impact. Financial/owned records generic content delete নয়।

## ০৭ — Admin panel ও request folders
Existing source আগে audit; সঠিক logic rewrite নয়। Supplied Admin references; header/menu/folder grid/search/pin/reorder; 20 themes (10 Sun + 10 Moon); background/card wheel; zoom75/100/125/150 reset100; বাংলা/English ADMIN panel labels; Save Draft/Preview/Publish পৃথক। Same canonical request record: Withdraw/Product/User/Support request নিজ folder badge-এ; Action Center duplicate record নয়। Unread ও unresolved pending পৃথক। Opening folder unresolved badge মুছবে না। Real health/backup/audit, sensitive action-wise permission, available workflow controls।

## ০৮ — Withdraw
Withdraw Now → Coin/Gold → Admin amount catalog → conversion/deduction/net money/eligible balance/deadline → method logo (bKash/Nagad/Rocket/Bank) → number/bank info → full review → Confirm। Earned eligible only; purchased non-withdrawable; reserve atomically; operation-key idempotency। Same Admin Withdraw folder immediate notice. Admin completion requires reference number OR proof image; actual Paid separate from Pending/Review. Rejection releases exact held amount once immediately in same currency. Auditable ledger/income-expense/receipt/status. Separate Coin/Gold amounts/rates/deductions/enable-disable/reopen timestamp/processing days. Request snapshots remain stable after settings change. Fraud recovery by user ID: reason/evidence/permission/confirmation/audited compensating entry; no ledger destruction. Preserve MY SHOP Commission economy naming; withdrawal charge and legal VAT are not silently interchangeable.

## ০৯ — Profile 01–48 এবং latest corrections
138430 MY SHOP reference; Facebook শুধু details UX reference। Locked cover/photo overlap/dot/name/verified/ID/Bio/stats/actions/shortcuts/Friends/Posts/Gallery/composer; no unrelated redesign. Normal ID line Level, Feed name পাশে small Level existing logic LOCK. **LATEST override: official 0001/0002/0003 NO LEVEL, NO SPECIAL MS badge; only blue verified badge and ID.** Existing section8 special badge rule superseded. Shortcuts Wallet/Store/Join Live/Top Gifters/Summary/Links; Summary opens reference138352 gifters ranking, not wallet balance. Same gift data, top3 podium 1 center/2 left/3 right, rows4–20, Your Rank, Host ID, close, correct Profile tap. Existing Top Gifters same data source, no duplicate ledger. Message-right3dot About/Personal Details; populated permitted details below shortcuts above Friends. Per-field Public/Friends/Only Me enforced in API. Add Friend auto-follows separate relations. Own/other menus differ. Settings mandatory Notification toggle, Terms, Privacy, About MY SHOP + Community Guidelines + Account & Data → Delete Account. Complete owner verified server deletion/anonymization/retention, actual public deletion URL, privacy consistency, cancel/retry/idempotency, finance safety; no fake deployed URL. Identity sync; preserve Store/Live/Wallet/Messenger/Friend/Follow/etc.

## ১০ — Home Page 1
PART1/6 provided clauses1–38, clause38 truncated; unseen remaining text is not invented. Audit existing actual routes against received text. Media → External direct central PHOTO/AUDIO/VIDEO/EXTERNAL; Gallery+ same Media Center not personal gallery. General same destination from both entries. Membership same backend/package/history/server expiry; disable blocks new sales, keeps existing entitlement. Notification read/unread; Messenger presence and private mode; proper search/history/feed/composer/like/comment/share/context permissions. Like must NEVER create post. Official MY SHOP Page separate profile; referral one identity verified exact-once rewards; official social links single source; Help Center duplicate shortcut removed while Support preserved; TopUp Coin/Gold verified payment purchased balance, not transfer/mobile recharge. Admin backend access. Live content status/read-only audit allowed; Live change requires owner approval.

## ১১ — Admin Visual Design & Color Customization
Scope/part selection by list and Preview tap; selected part name + subtle marker। Same color wheel everywhere (no code knowledge), white/black/gray quick colors, presets। Background/card/button/text/icon/border, solid/gradient; chosen word gradient; allowed font/spacing/radius/shadow/glow; one target or explicit Apply All. Actual current full section preview; Save Draft / Publish / Cancel / Reset. Server authorization and audit; live locked areas protected. Published designs sync intended screens. Root restore/version history required; user-specific financial/security information never becomes public via styling.

## QA ও delivery
প্রতিটি visible applicable control-এর source/API/persistence/permission/failure path পরীক্ষা। Existing features preserved; original Firebase/configuration/signing workflow retained. ONE V-575 complete latest source ZIP <25,000,000 bytes if achievable without removal; measured size + current handoff + source identity। No production deploy, public release or AAB authorized by this implementation start. Device/RTC/payment/push/visual checks unavailable locally must remain explicitly pending; no false 100% claim.
