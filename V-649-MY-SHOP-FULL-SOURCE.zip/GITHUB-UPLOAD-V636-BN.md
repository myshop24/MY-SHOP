# V-636 GitHub APK

১. আগের স্থায়ী repository-তে V-636-MY-SHOP-FULL-SOURCE.zip অপরিবর্তিত আপলোড করুন। আগের root workflow ও Secrets রাখুন। নতুন repository হলে .github-সহ পুরো ZIP extract করে root-এ দিতে হবে।
২. Actions-এ selected source V-636, versionName2.9.636 ও versionCode636 এবং intended commit মিলিয়ে নিন। পুরোনো source নির্বাচন হলে নতুন ZIP নাম/commit পরীক্ষা করুন।
৩. Android build, আগের signing certificate এবং provenance যাচাই সফল হলে সেই run-এর MY_SHOP_FINAL_RELEASE.apk artifact ডাউনলোড করুন।
৪. এই ZIP পূর্ণ সোর্স; APK নেই। এখানে পূর্ণ Android build Gradle ডাউনলোডে নেটওয়ার্ক বাধায় যাচাই হয়নি, তাই GitHub-এ build-success নিশ্চিত দাবি করা হয়নি।
৫. Story upload-এর পরে ওপরের নীল ➤ Post/পোস্ট বোতাম ব্যবহার করুন। নিজের প্রকাশিত Story সম্পাদনায় Save Changes থাকবে।
৬. অবশিষ্ট যাচাই: মোবাইলে ডিজাইন/বোতাম, পূর্ণ ভাষা কভারেজ, প্রকৃত profit/source accounting ও production D1। বিস্তারিত MY-SHOP-DEVELOPER-HANDOFF.md।
