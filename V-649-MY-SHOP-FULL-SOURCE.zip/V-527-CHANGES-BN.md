# MY SHOP V-527 — BUILD REPAIR RELEASE

Release identity: V-527 / 2.9.527 / versionCode 527

## GitHub build failure repaired
- V-526 GitHub build stopped in `:app:verifyMyShopResourceReferences` before APK compilation.
- Root cause: `app/src/main/res/drawable-nodpi/testwrite` was an extension-less test file. The verifier called `substring(0, lastIndexOf('.'))`; for this file `lastIndexOf('.')` was `-1`, causing `begin 0, end -1, length 9`.
- Removed the invalid `drawable-nodpi/testwrite` file.
- Hardened the Gradle resource verifier: file-backed Android resources must have a real extension; invalid files now produce a clear `Invalid Android resource file (missing extension)` error instead of crashing with StringIndexOutOfBoundsException.

## Regression safety
- V-526 feature/UI work is preserved; this release is a targeted build-repair increment.
- V-527 source identity, Android identity, and Worker health identity are synchronized.
- Resource-reference preflight and master regression verification pass locally.
