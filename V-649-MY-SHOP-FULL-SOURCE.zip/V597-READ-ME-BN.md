# MY SHOP V-597

ZIP খুলে MY-SHOP-V597 ফোল্ডারের সব ফাইল GitHub repository-তে আপলোড করুন। .github/workflows অবশ্যই repository root-এ থাকবে।

GitHub → Actions → MY SHOP Android APK → Run workflow। সফল হলে Artifacts → MY-SHOP-V-597-APK থেকে MY_SHOP_FINAL_RELEASE.apk পাবেন। আগের original signing/Firebase secrets প্রয়োজন।

এই ফাইলে source দেওয়া হয়েছে; স্থানীয় Android SDK নেই বলে APK build হয়নি। Android compile/lint এবং ডিভাইসে UI/Live পরীক্ষা সফল হয়েছে বলে দাবি করা হচ্ছে না। বিস্তারিত: handoffs/MY-SHOP-V597-HANDOFF.md।

Level: ছোট ছোট Gift এবং Transfer দুটোই জমা হয়। মোট ১,০০,০০০ Coin = +১ Level; ১,০০০ Diamond = +১ Level। Office source-এর দ্বিগুণ নিয়ম বজায় আছে।

Live Game revenue provider নতুন করে তৈরি হয়নি; বর্তমান কমিশন engine Gift/Transfer/Withdrawal-এর জন্য। পূর্বের release মুছে বা production deploy করা হয়নি।
