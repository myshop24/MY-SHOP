# MY SHOP V-503 — Changes

- New Home Page flow aligned to supplied references 130300.png and 130335.jpg.
- Home 3-line menu contains the 10 locked features and routes through functional feature/admin controls.
- General user catalog is backend-driven and newest-first; History is backend-driven and reopenable.
- Live page uses the locked vertical live-card structure and no-live Go Live state.
- Live hamburger opens the 10-item Discover catalog; admin-managed Discover ordering/status is supported.
- Feature Admin now includes position/order plus media, link, price, offer, time-limit and Coming Soon controls.
- Generic feature pages read managed feature data from backend, including image/status/offer/price where configured.
- Version identity advanced to V-503 / 2.9.503.

Build note: local environment does not include Android SDK/Gradle wrapper JAR, so Android release compilation is delegated to the repository GitHub workflow; static source/backend checks are run before delivery.
