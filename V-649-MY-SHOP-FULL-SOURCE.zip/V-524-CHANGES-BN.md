# MY SHOP V-524 — GitHub AAPT Resource Build Repair

Release: V-524 / 2.9.524 / versionCode 524
Base: V-523

## Exact GitHub failure fixed
GitHub Actions reached Android release resource merge and failed at `:app:mergeReleaseResources` / AAPT with:

`app/src/main/res/drawable/live_main_guest_logo.png: AAPT: error: file failed to compile.`

Root cause: the file was named `.png` but its actual binary payload was JPEG/JFIF. Android AAPT resource compilation rejected the mismatched image resource.

## Fix
- Preserved the selected Main Guest artwork byte-for-byte.
- Renamed the resource file from `live_main_guest_logo.png` to `live_main_guest_logo.jpg`.
- Kept the Android resource base name unchanged, so existing code still uses `R.drawable.live_main_guest_logo`.
- Added format-signature verification for Android image resources before packaging.
- Advanced Android/backend release identity to V-524 / 2.9.524 / versionCode 524.

## Regression rule
No approved V-523 Live Room/Page 2 functionality was intentionally removed or redesigned in this build-repair release.
