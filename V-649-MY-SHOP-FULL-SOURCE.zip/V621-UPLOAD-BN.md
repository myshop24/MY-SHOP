# V-621 পূর্ণ সোর্স — GitHub APK নির্দেশনা

এই ZIP-এ APK নেই; GitHub Android build সফল হলে Artifacts থেকে APK পাওয়া যাবে। স্থানীয় বিল্ড Gradle ডাউনলোডের নেটওয়ার্ক সীমায় আটকে গেছে; সোর্স পরীক্ষা পাস করা APK বিল্ড পাস নয়।

১. আপনার myshop24/MY-SHOP repository-তে আগের permanent release pipeline বহাল রেখে root-এ V-621-MY-SHOP-FULL-SOURCE.zip আপলোড করুন। একই621নামের পরিবর্তিত দ্বিতীয়ZIP আপলোড নয়। আগের V620 source মুছবেন না।
২. পুরোনো original signing/Firebase/Cloudflare Secrets বহাল রাখুন। Keystore/password/sourceএ প্রকাশ করবেন না। আপনার root pipeline নতুনZIP বাছাই করে Worker deploy করে, তারপর signedAPK build করে; আগে Worker পরিবর্তন হবে।
৩. Actions-এর intended621run খুলুন। SOURCE MY SHOP V-621 /2.9.621, latestcommit, clean extraction এবং Android build সত্যি সফল হয়েছে কি না দেখুন। Worker deploy success একা APK success নয়।
৪. সফল runএর Artifacts থেকে একটি MY_SHOP_FINAL_RELEASE.apk পাবেন। এই621APK version/package এবং আগের signing certificate মিলিয়ে তারপর ইনস্টল করুন। পুরোনোAPK নতুন নামে নয়।
৫. unpackedproject পদ্ধতিতে ভেতরের সব files, বিশেষত .github, repositoryroot-এ দিন; .github/workflows/my-shop-apk.yml sourceworkflow ব্যবহার করে original Secrets দিয়ে Actions→MY SHOP Android APK→Run workflow। দুইreleasepipelineএকসঙ্গে চালাবেন না।
৬. অ্যাপ বন্ধ/খোলা রেখে D1 daily rows-read আগে/পরে মাপুন। quotaআগেই শেষ হলে সূচি/নতুনschemaপ্রথমবার চালু হতে reset প্রয়োজন। এইsourcequotaবাইপাস করে না। সার্ভার লগে D1_READ621 queryfingerprint ওrowsRead দেখা যাবে; privateargument/tokenলগহয়না। productionমাপছাড়া quotaসমাধান নিশ্চিত নয়।
৭. ফোনে যাচাই: live start/end→অন্যফোনেরLiveNow; গিফ্টেরপ্রাপক/ALL/Favourite/সোয়াইপ/customquantity/price/Send/Retry; সবাইঅ্যানিমেশন+কমেন্টপায়; microphone/comments/seats/Join/End/minimizeআগেরমতো। OfficeIDথেকেlevel2, সাধারণrechargelevel1, Giftথেকেআবারlevelনয়।

সম্পূর্ণ developer checkpoint: MY-SHOP-DEVELOPER-HANDOFF.md। নতুনপরিবর্তনেরপরেরversionV622।
