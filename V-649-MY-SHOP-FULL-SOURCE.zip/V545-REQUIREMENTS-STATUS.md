# V-545 • Status

| Area | V545 update | Status |
|---|---|---|
| Existing Live Room and themes | V544 approved implementation retained | Source retained; no new device QA |
| APK source selection | Accepts both V-numbered source archive name patterns | Workflow script validation pending |
| APK CI regression | V544 Worker suite added before APK build | Run locally |
| QA APK artifact | Android workflow uploads debug APK; use the Android/permanent-release run, not Pages | Requires GitHub Actions run |
| Pages artifact | Separated/documented as website output, not APK | Existing 7.91 GB Pages artifact remains outside this source change |
| Signed release APK | Requires authorized signing secrets and gated publish flow | Not built here |
| Production Worker and RTC | Requires production/device environment | Not deployed/tested |
