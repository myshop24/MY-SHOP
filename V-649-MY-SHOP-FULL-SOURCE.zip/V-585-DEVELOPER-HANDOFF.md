# MY SHOP V-585 / 2.9.585 — CURRENT HANDOFF

Owner requested new version after cancelling V584 GitHub run. Current baseline is V585; Android versionCode585, versionName2.9.585, SOURCE_BUILD_ID MY SHOP V-585, Worker identity V-585. V584 Button import/compiler fix remains unchanged; no new feature changes in this version.

## What another Developer needs
- Full Android source: app/; Worker source: backend/worker/.
- Mandatory entry instructions: AGENTS.md and MY-SHOP-DEVELOPER-INSTRUCTIONS.md.
- Existing build/signing: app/build.gradle, my-shop-release.sh, tools/ci-apk-build.sh and .github/workflows/my-shop-apk.yml. Preserve package com.myshop.app and original signing certificate. The GitHub repository's installed permanent pipeline can differ from the workflow inside this ZIP; uploading only the ZIP does not update that workflow.
- Original private signing key/passwords are NOT in this ZIP. Use the owner's existing GitHub key-restore/secrets; never generate a replacement key for updates. Required secret names are recorded in workflow/build scripts; values are not exposed here.
- This package contains source, not a newly built APK. The cancelled build produced no verified signed APK for this delivery. Full Android compilation/device QA still must be performed with the existing signing setup.
- Local regression and package checks pass; no production deployment performed here.
- Master104/all-approved-area implementation remains incomplete exactly as described below. This sequence update does not complete those tasks.

## Historical V584/V583 handoff — current identity above takes precedence

# MY SHOP V-584 / 2.9.584 — build repair handoff

Current scope: repair owner-reported V583 GitHub run656 compilation failure. AdminCatalogActivity now imports android.widget.Button. Exact two shipped button statements reproduce the four original compiler errors without the import and compile with the corrected import in a JavaCompiler fixture. Package gate now catches missing Android widget constructor imports before compilation. Full local regression and exact ZIP checks recorded internally; these are not full Android compilation or device QA.

Android versionCode584/versionName2.9.584, SOURCE_BUILD_ID and Worker health markers aligned. Original package, signing configuration/certificate check, release scripts, Firebase configuration, Cloudflare bindings and Live code preserved. This source ZIP does not contain the original private signing key or a newly built APK. Existing GitHub signing secrets/key restoration are required; no replacement key created. Preserve the existing permanent release pipeline.

No production deployment or GitHub upload performed by this repair. Prior Master104 and all-area design incomplete scope remains incomplete; this build repair does not claim those tasks complete.

## Prior V583 implementation and pending scope

# MY SHOP V-583 / 2.9.583 — source handoff

Status: build-error repair and combined Admin enhancement source; NOT completion of all four requested areas. This package contains no signed APK. VersionCode583; permanent package/signing certificate/configuration retained.

## Build failure corrected
V582 archive referenced AdminDraftReviewActivity and ProfileMenuConfig but omitted their Java files; manifest also referenced the missing Activity. Both Java files, ProfileMenuAdminActivity and manifest declarations are present here. tools/v583_package_check.py catches the actual V582 defect and validates the exact V583 archive. Gradle preBuild runs this gate. V581 impossible sibling-Activity instanceof error in MainActivity also remains corrected.

## Implemented in this combined source
1. Compact Profile Menu Root Admin editor: name/emoji, raster icon upload/URL with auto-fit/resolution warning, visibility, ordering (hold/drag or arrows), private Save Draft, explicit Publish of saved draft, actual drawer Preview, defaults, lifecycle recovery, canonical audit History/Restore Draft. Server ACL, revision race protection and atomic audit. Custom icon publication requires rights confirmation recorded in audit. Existing feature destinations/protected rows preserved.
2. Central Saved Draft Review: canonical saved Feature/Menu/Design drafts, Root ACL, existing records, search/type filters, paginated read-only metadata; no duplicate draft database and no automatic Publish. Owning editor navigation works; Live-related drafts remain locked.
3. Appearance integration: existing scopes plus Media header and Profile Settings; Draft Review opens owning design editor and relevant Home popup. Shared wheel, selected word/gradient controls, private Draft/Publish, preview, undo/redo/copy style/history retain existing behavior. Long Profile/User Menu supports240 selectable targets; other scopes120.
4. Preserved unchanged LiveHomeActivity, AudioLiveRoomActivity, Firebase config, Wrangler bindings, canonical workflow and original signing configuration. Backend preservation/regression tests pass locally. No production/deploy action executed.

## Actual verification
Full tools/v575_verify.sh suite passes: Worker/SQLite target+regressions, Menu/Draft ACL/concurrency/audit rollback/private publication, History/Restore and rights confirmation, Java source syntax, callback context, extracted shipped editor/navigation tests, resource and package preflight. Extracted final ZIP is separately rechecked. These checks do NOT replace Android type compilation or device QA.

## Remaining requested scope — not hidden
- Master104 all applicable per-folder controls remain incomplete. SVG secure rendering, some layout/translation/backup/analytics/AB, detailed folder-wide control and approval/notification coverage still need implementation/verification. Existing supported controls are not evidence that all104 are done.
- All approved screen/area design coverage and mobile/tablet/reference visual QA remain incomplete. Current named appearance scopes are bounded; locked Live/Profile layout is excluded.
- Full Android clean compile, signed APK and actual device QA NOT performed here. bash gradlew --version cannot download Gradle: Network is unreachable. Android SDK and original signing key unavailable locally. Existing GitHub build must verify actual compilation with preserved secrets/signing; no green-build guarantee.
- Production D1/R2, old Summary records, RTC/push/payment and real-device behavior are not newly certified. Do not equate fixture records with production records.

## Continue
Use V583 source as current baseline; no V-number reuse. Finish the remaining first-four requirements before declaring them complete. Preserve unaffected features and signing/data. Before any Live change, present the exact proposal and obtain explicit owner approval.
