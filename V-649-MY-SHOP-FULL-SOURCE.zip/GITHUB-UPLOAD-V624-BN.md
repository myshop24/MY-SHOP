# V624 GitHub APK পূর্ণ প্যাকেজ
এই ZIP ফাইলটি https://github.com/myshop24/MY-SHOP এর main branch-এর root-এ সরাসরি আপলোড করুন। ZIP খুলে ফাইল আলাদা আপলোড বা root workflow/script বদলাবেন না। সর্বোচ্চ V624-এর একই নামের একটিই ZIP রাখুন।
Actions → WORKER VERIFY → APK সফল হলে MY-SHOP-FINAL-V-624 artifact থেকে APK পাবেন। বিদ্যমান Signing Secrets ব্যবহার হবে। পূর্ণ source, প্রয়োজনীয় মূল assets, deterministic generated-media scripts, Gradle wrapper এবং workflows অন্তর্ভুক্ত। স্থানীয় test credentials/key/APK প্যাকেজে নেই।
