# MY SHOP V-587 — ১.৯ / ১.১০ প্রোফাইল সংশোধন

V586-এর কাজ ধরে চালানো হয়েছে। নতুন করে শুরু করা হয়নি।

১.৯: Privacy & Visibility থেকে Personal Details অথবা Posts/Media Privacy নির্বাচন; মূল তথ্য এডিট করে ফিরলে নতুন তথ্য দেখাবে, প্রস্তুত Privacy পরিবর্তন থাকবে।
১.১০: My Wallet = Coin/Gold Wallet; Store = Membership Catalog; Join Live = Join Live/Go Live নির্বাচন; Top Gifters = সংরক্ষিত Live gift-এর সর্বকালের হিসাব; View As = Public viewer-এর মতো নিজের প্রোফাইল; Social = প্রস্তুত আইকন, লিংক, Save, প্রতিটি লিংকের Public/Friends/Only Me এবং অতিরিক্ত প্ল্যাটফর্ম।

১৯টি প্রস্তুত প্ল্যাটফর্ম, সর্বোচ্চ ৫০টি পূরণ করা লিংক। পরিচিত মূল প্ল্যাটফর্মে বিদ্যমান আইকন; অন্য প্ল্যাটফর্মে পরিষ্কার scalable নামের অক্ষরের আইকন। লোড ব্যর্থ হলে Save বন্ধ থাকবে, যেন আগের লিংক ভুল করে মুছে না যায়।

CoinWithdrawalActivity ও WithdrawalCatalogAdminActivity V585-এর মূল ফাইল অপরিবর্তিত; demo amount বসানো হয়নি। Live RTC/engine/gift event handler বদলানো হয়নি।

এটি পূর্ণাঙ্গ source checkpoint, সব নির্দেশনার ১০০% সমাপ্তি বা বাস্তব ফোনে হুবহু ছবি মেলার সার্টিফিকেট নয়। বাকি কাজের সঠিক তালিকা MY-SHOP-DEVELOPER-HANDOFF.md-এ আছে। পরের ফাইল V588 হবে।
