# V-521 CHANGES — Home Reference Fidelity + Live Page 2

- Home header language control simplified to clean EN selector with no globe/ring.
- Home top menu rebuilt as premium icon-above/name-below cells with compact spacing and full Membership label.
- My Feed title made compact multi-color and stray underline removed.
- Feed identity keeps Name + smaller LV text; Photo/Video/Post remains centered.
- Feed actions normalized; comment count visible, like count visible, like-user list endpoint added, comment reply backend/UI added, and three-dot control receives three-color treatment without changing its role.
- Selected Live navigation identity retained with hot pink/red circular glow; white center dot now pulses. Navigation containers no longer clip the circular Live control.
- Live Page 2 top header matches Home identity; bottom label is Go Live using the same Live design and pulse.
- Live Page 2 Membership/Games/Earn changed to icon-above/name-below premium cells.
- Live Page 2 advertising banner height reduced; existing auto-slide + manual swipe/scroll behavior preserved.
- Active Live list stays vertical with left preview/right host information; preview URL/thumbnail is preferred when backend provides one.
- Active Live refresh runs every 2.5 seconds while Page 2 is visible so newly started/ended sessions appear/remove without manual refresh.
- Featured and Shop Live indicators render when supplied by backend.
- No-Live two-CTA state remains available.
- Backend additions are additive: post like-user listing and nested comment replies.
- Existing backend, Live Room, gifts, join, audio, admin and previous features are regression-protected.
