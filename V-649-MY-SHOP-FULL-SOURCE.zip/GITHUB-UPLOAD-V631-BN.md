# V631 — আগের মতো GitHub APK ফুল প্যাকেজ

1. V-631-MY-SHOP-FULL-SOURCE.zip না খুলে আগের MY-SHOP repository-র main/root-এ Upload files দিয়ে upload ও commit করুন।
2. আগের স্থায়ী .github/workflows/my-shop-apk.yml এবং my-shop-release.sh অক্ষত রাখুন। নতুন workflow বসাতে বা ZIP extract করতে হবে না। ZIP-এর ভেতরের build-only workflow ঐচ্ছিক পরীক্ষার উপকরণ; স্থায়ী workflow দিয়ে সেটি বদলাবেন না।
3. Actions → MY SHOP PERMANENT RELEASE PIPELINE → এই upload-এর run। Job: WORKER VERIFY -> APK। Pages build and deployment আলাদা website run।
4. সফল হলে Artifacts → MY-SHOP-FINAL-V-631 → extract → MY_SHOP_FINAL_RELEASE.apk। Upload commit, SOURCE_VERSION V-631, versionCode631/versionName2.9.631, original signature/hash মিলিয়ে নিন।
5. Original signing/Firebase/Cloudflare secrets ও cache আগের মতোই। স্থায়ী pipeline matching Worker deploy/verify করে signed APK বানায়। এই কাজের সময় production deploy বা GitHub run চালানো হয়নি।

V631-এ GitHub run #692-এর দুই Java compiler error সংশোধিত: NotificationActivity callback-এর Activity Context এবং AudioLiveRoomActivity LruCache lookup। Full Android build success local test দিয়ে দাবি করা হচ্ছে না।
