# V-541 পরিবর্তন

- পেইজ ২-এর শুধু More Apps আইকনটি Page 1-এর নিজস্ব রঙ বজায় রাখে এবং একই Quick Links প্যানেল খোলে। Home, My Shop, Live ও Support আইকনের নকশা/আচরণ বদলানো হয়নি।
- Page 2 live banner এখন কেবল `live_home` ফোল্ডারের সক্রিয় স্লট নেয়; সফল খালি রেসপন্স আগের ব্যানার ক্যাশও মুছে দেয়। অটো-স্লাইড slot order ধরে বাম থেকে ডানে চলে।
- Live comment Highlight-এ rocket ও Admin-এর একটিমাত্র coin price দেখায়। Global VAT আলাদা করে আবার যোগ হয় না; wallet থেকে ঠিক ওই একবারের amount-ই কাটা হয়। 0001/0002/0003 Main Admin-এর free privilege অক্ষুণ্ণ। Composer-এর Send button-এর জায়গা বাড়ানো হয়েছে।
- Messenger inbox-এ active-now strip যোগ হয়েছে। Fresh server heartbeat এবং Active Status visibility দুটো সত্য হলেই সবুজ dot দেখা যায়; cached inbox-কে offline দেখায়। পুরোনো D1 presence schema-তে `visible` column নিরাপদে তৈরি হয়।
- FCM delivery-এর কোনো ডিভাইস token-এ সফল response না এলে Worker আর সফল বলে না। Self-test/admin health দিয়ে client config, permission, token registration ও server-side failure আলাদা করে দেখা যায়।
- নিজের timeline post-এ Like করলে post row তৈরি হয় না; My Feed-এর নাম fixed-size, এক লাইনের profile-name policy-তে থাকে।
