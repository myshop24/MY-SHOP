# V-542 পরিবর্তন

- Firebase config file support, delivery build guard, client/server project matching, device-token account isolation, OS notification diagnostics/received timestamp.
- Foreground presence serialization, logout offline, hidden status and stale/error badge suppression.
- Compact Messenger inbox/search, chat media/camera/voice/files/settings, participant-only media access and bounded thumbnail decode/cache.
- Feed fixed one-line name + small adjacent LV; compact left Like/Comment/Share.
- Same compact four-square More Apps on Page 1/2; prior peer navigation retained.
- Published-only hero slots, no bundled placeholder banner, right-to-left automatic motion, finger drag/paused auto and eased snap.
- Dedicated Admin Highlight fee and host-share controls; selected rocket and transparent readable Send; atomic save/payment/refund/idempotency/host ledger.
- Persistent moon/sun toggle before language; primary four-language system labels and Admin-owned translations. Legacy full language coverage still partial.
- Full prior source retained; 50 V542 Worker behavior tests plus previous regression suites; honest device/production blockers documented.
