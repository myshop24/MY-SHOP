# V-542 যাচাই রিপোর্ট

এই প্যাকেজ সম্পূর্ণ সোর্স; এটি signed APK নয়।

## স্থানীয় যাচাই
- Android Debug ও Release compilation/package: final build log সংযুক্ত।
- V542 Worker behavior: 50 PASS।
- V541 regression: 28 PASS।
- V540 SQLite regression: 17 PASS।
- V430 SQLite regression: 31 PASS।
- Commerce / payout-inbox / profile module tests: 25 / 12 / 6 PASS।
- Java/resource preflight: PASS, 134 Java files।
- SQLite বাস্তব; authentication, R2 ও FCM বাহ্যিক সংযোগ test doubles।
- Push configuration guard: Firebase client config অনুপস্থিত হলে -PrequirePush build প্রত্যাশিতভাবে আটকে দেয়।

## যা নিশ্চিত করা যায়নি
- কোনো বাস্তব ফোন বা emulator সংযুক্ত ছিল না। স্ক্রিন বন্ধ রেখে notification sound/receipt, keyboard layout, camera, call/streaming এবং reference অনুযায়ী প্রতিটি screen-এর visual acceptance পরীক্ষা হয়নি।
- Firebase client config, Worker service-account credentials ও release signing এখানে দেওয়া হয়নি। Production push কার্যকর হয়েছে বলে দাবি করা হচ্ছে না।
- প্রধান UI-তে চার ভাষার dictionary আছে; পুরোনো সব admin/error label-এর পূর্ণ translation audit এখনও অসম্পূর্ণ। ব্যবহারকারীর লেখা অনুবাদের paid service যোগ করা হয়নি।
- Backend-এর নতুন endpoint/schema/requestId এবং Android source একই release হিসাবে deploy করতে হবে।

৩১টি নির্দেশনার পৃথক ফল: V542-REQUIREMENTS-STATUS.md। সেটআপ ও ফোনের acceptance test: MY-SHOP-V542-DEVELOPER-HANDOFF-BN.md। আগের সফল local build-এর পর account cache সংশোধনের final build-এ একটি variable-scope compile error ধরা পড়ে; তা সংশোধিত। চূড়ান্ত সফল build log-ই প্রমাণ হিসেবে ব্যবহার করুন।
