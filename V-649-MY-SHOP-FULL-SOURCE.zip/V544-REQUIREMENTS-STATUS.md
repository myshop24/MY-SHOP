# V-544 • যাচাই ও অবশিষ্ট কাজ

| অংশ | V544-তে যা করা হয়েছে | যাচাই |
|---|---|---|
| লাইভ রুম | Comment–Game–Mic–More; Comment থেকে আলাদা Rocket/Send composer; ডান rail Love–Vote–Gift–animated Join; center halo থেকে দাঁত/বাইরের wave সরানো; পাঁচটি viewer avatar ও `+99`; host ID বদলে LV/Follow; Coin/Gold/Vote ও লাল timer | Java source delimiter check; হাতে source review। Android UI build/phone preview করা যায়নি |
| X / Live close | Host X সরাসরি এক-ট্যাপ end request পাঠায়; server response না এলে retry করে; audience X leave confirmation | Android/runtime বা production API-তে পরীক্ষা হয়নি |
| সবাই একসাথে শুনবে | Agora live-broadcast profile, microphone publish, `autoSubscribeAudio`, remote audio recovery/publish controls আগের মতো রাখা | SDK/runtime পাওয়া যায়নি; দুই ফোনে কথা/latency যাচাই বাকি |
| থিম | S1–S10 Sun reference palettes; L11 Pure White; Moon দশটি অপরিবর্তিত; no-code light/dark color picker; preview/save/publish/reset; global revision-based refresh | Worker SQLite suite: 63 checks PASS; Android view render/build হয়নি |
| থিম sync | API draft ও published color আলাদা রাখে; no-store response; app foreground-এ প্রায় 12 সেকেন্ডে refresh; প্রকাশিত রঙ পাল্টালে খোলা non-live screen reload | Local Worker behavior suite PASS; production Worker deploy এবং দুই user account পরীক্ষা বাকি |

## গুরুত্বপূর্ণ সীমা

- এই workspace-এ Gradle/Android SDK নেই। তাই Android APK assemble বা APK হাতে দেওয়া সম্ভব হয়নি।
- কোনো ডিভাইস/এমুলেটর সংযুক্ত ছিল না। Join animation, keyboard, mic routing, audible latency, X-এর live server effect বাস্তবে পরীক্ষা হয়নি।
- Worker source-এ custom theme storage ও version 2.9.544 আছে, কিন্তু production Worker deploy করা হয়নি। Publish sync ব্যবহারকারীদের কাছে যেতে V544 Worker deploy এবং Admin থেকে PUBLISH করতে হবে।
- V544-এর deliverable হলো সম্পূর্ণ source ZIP, APK নয়।
