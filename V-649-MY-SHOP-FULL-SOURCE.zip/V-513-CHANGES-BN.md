# MY SHOP V-515 — Build Stabilization & Release Hardening

## Base
V-512 editable Android/Cloudflare source. No APK used as development base.

## Build fixes
- Fixed WatchHistoryActivity record overload mismatch.
- Added safe TextView helper overload compatibility for color/size argument ordering.
- Kept/verified weight() layout helper availability.
- Made LiveHomeAdminActivity date/time dialogs explicitly use Android framework classes.
- Normalized all Java Android R resource references to dot syntax.
- Kept BackendClient historyAdd contract aligned with WatchHistory.

## Release identity
- SOURCE_BUILD_ID: MY SHOP V-515
- VERSION_NAME: 2.9.515
- Android versionCode: 513
- Worker health identity: V-515 / 2.9.515

## Verification target
GitHub Actions must still perform the authoritative Android compile, signing, backend deployment/health check and final APK verification. This source package must not be called a successful APK release until that runner completes successfully.
