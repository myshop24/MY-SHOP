# MY SHOP V‑438 — কাজের তালিকা

এই কথোপকথনের নির্দেশনা অনুযায়ী Android ও Backend সোর্স পরিবর্তন করা হয়েছে।
**Clean build সফল। ফোনে বাস্তব পরীক্ষা বাকি — ⚠️ NOT RUNTIME VERIFIED।**

১. **গ্যালারি থেকে পণ্য:** আগের ছবির লিংকের পাশাপাশি গ্যালারি বাছাই, Preview, Upload ও Save যুক্ত হয়েছে।

২. **Quick Links:** জোড়ায় জোড়ায় দুই সারি; ১৪টি হলে উপরে ৭টি ও নিচে ৭টি। দুই সারি একসঙ্গে স্ক্রল হবে।

৩. **আইকন:** Home ও Live বিভাগের জন্য ২২টি নতুন রঙিন, পরিষ্কার vector icon। অ্যাডমিনের দেওয়া নিজস্ব ছবি ব্যবহার করা যাবে।

৪. **নোটিফিকেশন:** মেসেজ ও Live alert-এর সেটিংস নির্দেশনা, সঠিক Chat/Live খোলার ব্যবস্থা ও ত্রুটি সামলানো উন্নত হয়েছে। মোবাইলে popup পৌঁছানো যাচাই করতে Firebase সংযোগ ও আসল ফোন প্রয়োজন।

৫. **Ride:** Demo ও Live Join-এ একই animation/sound ব্যবস্থা। ১২টি আলাদা সাউন্ড যুক্ত হয়েছে; অ্যাডমিন নিজের সাউন্ড আপলোড করতে পারবেন।

৬. **Membership:** মাঝখানে ইউজারের ছবি স্থির রেখে ডানা, আলো ও ঝিলিকের অ্যানিমেশন। অনুমোদিত Membership Live Join-এ অন্যদের কাছেও দেখানোর কোড যুক্ত হয়েছে।

৭. **Wallpaper:** গ্যালারি Upload, ১০৮০×২৪০০ px / ৯:২০ সাইজ, Crop/Zoom ও Live Room Demo। ছোট ছবিতে Demo নিজে থেকেই চালু হবে। কেনার পর অনুমোদন হলে আগের Live background বদলাবে।

৮. **পরীক্ষা:** Debug এবং unsigned Release APK build সফল; lint-এ ০ error। ৯১টি Backend/লেনদেন পরীক্ষা এবং Quick Links-এর ২০১টি আকারের পরীক্ষা পাস। ফোনে দুই ইউজারের Live/পুশ পরীক্ষা বাকি।

৯. **অগ্রগতি:** কাজ, ধরা পড়া সমস্যা, সংশোধন ও পরীক্ষার অগ্রগতি চ্যাটে জানানো হয়েছে।

১০. **আলাদা Admin:** Membership, Ride, Wallpaper, Frame, Badge ইত্যাদির আলাদা grid catalog। একটি পণ্য খুললে তার ফর্ম দেখা যাবে। Requests ও Income-এর আলাদা পৃষ্ঠা আছে।

১১. **ID দিয়ে নিয়ন্ত্রণ:** ID সার্চ → নাম/ছবি যাচাই → ইউজার নির্বাচন → পণ্য নির্বাচন → Grant। সক্রিয় ফিচার আলাদাভাবে Remove করা যাবে। ক্রয়ের request Approve/Reject থাকবে। Direct Grant-এ কয়েন কাটবে না।

১২. **রং ও লেখা:** রঙিন catalog, দুই কলামের মোবাইল grid, বড় label ও প্রয়োজনমতো একাধিক লাইনের heading। ফোনের বিভিন্ন মাপ ও বড় font-এ চূড়ান্ত visual পরীক্ষা বাকি।

## APK-তে ফল পেতে

এই ZIP-এর **V‑438 Worker ও Android—দুটিই** ব্যবহার করতে হবে। চালু সার্ভার পরীক্ষার সময় V‑437 ছিল। আগের GitHub release workflow ও signing ব্যবস্থা অপরিবর্তিত আছে।

বিদ্যমান release repository-তে এই নতুন ZIP দিয়ে আগের workflow চালালে একই Worker deploy ও signed APK তৈরির ধাপ চলবে। Push-এর জন্য বিদ্যমান Firebase CI configuration ও Worker-এর FCM secret ঠিক থাকতে হবে। এই কাজের সময় production deploy, আসল signing key দিয়ে APK তৈরি বা ফোনে পরীক্ষা করা হয়নি।

পূর্ণ নির্দেশনা ও পরীক্ষার রিপোর্ট ZIP-এর `MY-SHOP-DEVELOPER-HANDOFF.md` এবং `verification/v438/`-এ আছে।
