package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

/** V-61: Admin-only local CRUD shell. Production shared CRUD still requires the configured backend. */
public class AdminManagementActivity extends AppCompatActivity {
    private boolean moderatorOnly;
    private LinearLayout listBox;
    private String activeType = "banners";
    private static final int PICK_MEDIA = 7001;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        moderatorOnly=getIntent().getBooleanExtra("moderator_only",false);
        if (moderatorOnly ? !SessionManager.isModerator(this) : !SessionManager.isAdmin(this)) { finish(); return; }
        buildUi();
    }

    private void buildUi() {
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(10,10,10,8); root.setBackgroundColor(0xFFF8F9FC);
        TextView title=new TextView(this); title.setText(moderatorOnly?"Moderator Controls":"Admin Panel — Upload / Edit / Delete"); title.setTextSize(20); title.setTextColor(0xFF6224E1); title.setTypeface(null,1); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,56));
        if(moderatorOnly){ addAction(root,"Ban User ID",()->toast("Ban action requires backend authorization.")); addAction(root,"Kick User",()->toast("Kick action requires backend authorization.")); addAction(root,"Close Live",()->toast("Close Live requires backend authorization.")); }
        else {
            LinearLayout tabs=new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL);
            String[] names={"Banners","Breaking News","Gallery","Social","Live TV"}; String[] types={"banners","breaking_news","gallery","social_links","live_tv"};
            for(int i=0;i<names.length;i++){ final String t=types[i]; Button b=new Button(this); b.setText(names[i]); b.setAllCaps(false); b.setTextSize(11); b.setOnClickListener(v->{activeType=t; refreshList();}); tabs.addView(b,new LinearLayout.LayoutParams(0,52,1)); }
            root.addView(tabs);
            LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
            Button add=new Button(this); add.setText("＋ Add / Upload"); add.setAllCaps(false); add.setOnClickListener(v->addItem());
            Button refresh=new Button(this); refresh.setText("Refresh"); refresh.setOnClickListener(v->refreshList());
            actions.addView(add,new LinearLayout.LayoutParams(0,52,1)); actions.addView(refresh,new LinearLayout.LayoutParams(0,52,1)); root.addView(actions);
            ScrollView scroll=new ScrollView(this); listBox=new LinearLayout(this); listBox.setOrientation(LinearLayout.VERTICAL); scroll.addView(listBox); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
            Button back=new Button(this); back.setText("Back"); back.setOnClickListener(v->finish()); root.addView(back,new LinearLayout.LayoutParams(-1,50)); refreshList();
        }
        setContentView(root);
    }

    private void addAction(LinearLayout root,String label,final Runnable r){ Button b=new Button(this); b.setText(label); b.setAllCaps(false); b.setOnClickListener(v->r.run()); root.addView(b,new LinearLayout.LayoutParams(-1,58)); }

    private void addItem(){
        if(!AdminContentStore.canUse(this)){toast("Admin permission required.");return;}
        if("gallery".equals(activeType) || "banners".equals(activeType)){
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(i,PICK_MEDIA); return;
        }
        final EditText input=new EditText(this); input.setHint("Enter content");
        new AlertDialog.Builder(this).setTitle("Add " + activeType).setView(input).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String s=input.getText().toString().trim(); if(!s.isEmpty()){AdminContentStore.add(this,activeType,s,s);refreshList();toast("Saved successfully");}}).show();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==PICK_MEDIA && resultCode==RESULT_OK && data!=null && data.getData()!=null){ Uri uri=data.getData(); try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){} AdminContentStore.add(this,activeType,uri.toString(),uri.toString()); refreshList(); toast("Uploaded successfully"); }}

    private void editItem(AdminContentStore.Item item){
        EditText input=new EditText(this); input.setSingleLine(true); input.setText(item.title);
        new AlertDialog.Builder(this).setTitle("Edit " + activeType).setView(input).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String s=input.getText().toString().trim(); if(!s.isEmpty() && AdminContentStore.update(this,activeType,item.id,s,item.value)){refreshList();toast("Updated successfully");}}).show();
    }

    private void refreshList(){ if(listBox==null)return; listBox.removeAllViews(); List<AdminContentStore.Item> items=AdminContentStore.list(this,activeType); if(items.isEmpty()){TextView e=new TextView(this);e.setText("No items yet. Use Add / Upload.");e.setGravity(Gravity.CENTER);e.setPadding(12,24,12,24);listBox.addView(e);return;} for(AdminContentStore.Item item:items){ LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); TextView t=new TextView(this); t.setText(item.title); t.setTextSize(13); t.setPadding(8,4,8,4); Button edit=new Button(this);edit.setText("Edit");edit.setOnClickListener(v->editItem(item)); Button del=new Button(this);del.setText("Delete");del.setOnClickListener(v->{if(AdminContentStore.delete(this,activeType,item.id)){refreshList();toast("Deleted successfully");}}); row.addView(t,new LinearLayout.LayoutParams(0,58,1));row.addView(edit,new LinearLayout.LayoutParams(80,52));row.addView(del,new LinearLayout.LayoutParams(86,52));listBox.addView(row); }}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
