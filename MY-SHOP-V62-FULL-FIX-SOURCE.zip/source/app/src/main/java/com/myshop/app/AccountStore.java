package com.myshop.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Locale;
import java.util.Map;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Local account cache/prototype only. Production source of truth must be a backend.
 * One permanent 4-digit User ID stays attached to an account. Login accepts:
 * email, mobile number, or the permanent User ID. Authentication also repairs a
 * missing email/mobile index by scanning the account records, so an app update
 * cannot break an otherwise valid local account merely because an index key changed.
 */
public final class AccountStore {
    private static final String PREFS = "myshop_accounts_v2";
    private static final String PREFIX = "acct_";
    private static final String HASH_PREFIX = "pbkdf2$";
    private static final SecureRandom RNG = new SecureRandom();

    private AccountStore() {}

    public static boolean canCreate(Context context, String email, String mobile) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String emailKey = canonicalEmail(email);
        String mobileKey = canonicalMobile(mobile);
        return (emailKey.isEmpty() || !p.contains(PREFIX + "email_" + emailKey))
                && (mobileKey.isEmpty() || !p.contains(PREFIX + "mobile_" + mobileKey));
    }

    public static boolean create(Context context, String userId, String name,
                                 String email, String mobile, String password) {
        return createWithSecurity(context, userId, name, email, mobile, password, "", "", "", "", "", "");
    }

    public static boolean createWithSecurity(Context context, String userId, String name,
                                 String email, String mobile, String password,
                                 String question1, String answer1,
                                 String question2, String answer2,
                                 String question3, String answer3) {
        String uid = userId == null ? "" : userId.trim();
        String emailKey = canonicalEmail(email);
        String mobileKey = canonicalMobile(mobile);
        if (!isFourDigit(uid) || (emailKey.isEmpty() && mobileKey.isEmpty())) return false;
        if (password == null || password.length() < 6) return false;

        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (p.contains(PREFIX + "uid_" + uid + "_password_hash")) return false;
        if ((!emailKey.isEmpty() && p.contains(PREFIX + "email_" + emailKey))
                || (!mobileKey.isEmpty() && p.contains(PREFIX + "mobile_" + mobileKey))) {
            return false;
        }

        String record = PREFIX + "uid_" + uid;
        SharedPreferences.Editor e = p.edit()
                .putString(record + "_user_id", uid)
                .putString(record + "_name", name == null ? "" : name)
                .putString(record + "_email", email == null ? "" : email)
                .putString(record + "_mobile", mobile == null ? "" : mobile)
                .putString(record + "_password_hash", hashPassword(password))
                .putString(record + "_security_q1", question1 == null ? "" : question1)
                .putString(record + "_security_a1", hashAnswer(answer1))
                .putString(record + "_security_q2", question2 == null ? "" : question2)
                .putString(record + "_security_a2", hashAnswer(answer2))
                .putString(record + "_security_q3", question3 == null ? "" : question3)
                .putString(record + "_security_a3", hashAnswer(answer3));
        if (!emailKey.isEmpty()) e.putString(PREFIX + "email_" + emailKey, uid);
        if (!mobileKey.isEmpty()) e.putString(PREFIX + "mobile_" + mobileKey, uid);
        e.commit();
        return true;
    }

    public static String findExistingUserId(Context context, String email, String mobile) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String e = canonicalEmail(email), m = canonicalMobile(mobile);
        String uid = !e.isEmpty() ? p.getString(PREFIX + "email_" + e, "") : "";
        if (!uid.isEmpty() && exists(context, uid)) return uid;
        uid = !m.isEmpty() ? p.getString(PREFIX + "mobile_" + m, "") : "";
        if (!uid.isEmpty() && exists(context, uid)) return uid;
        return "";
    }

    public static boolean exists(Context context, String userId) {
        String uid = userId == null ? "" : userId.trim();
        if (!isFourDigit(uid)) return false;
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return p.contains(PREFIX + "uid_" + uid + "_password_hash");
    }

    public static Account authenticate(Context context, String identifier, String password) {
        String value = identifier == null ? "" : identifier.trim();
        if (value.isEmpty() || password == null) return null;

        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String userId = resolveUserId(p, value);
        if (userId.isEmpty()) return null;

        String record = PREFIX + "uid_" + userId;
        String stored = p.getString(record + "_password_hash", "");
        if (!verifyPassword(password, stored)) return null;
        if (stored.startsWith("sha256:")) {
            p.edit().putString(record + "_password_hash", hashPassword(password)).commit();
        }
        return new Account(userId,
                p.getString(record + "_name", ""),
                p.getString(record + "_email", ""),
                p.getString(record + "_mobile", ""));
    }

    private static String resolveUserId(SharedPreferences p, String value) {
        // 1) Permanent User ID login (e.g. 0427).
        if (isFourDigit(value) && p.contains(PREFIX + "uid_" + value + "_password_hash")) {
            return value;
        }

        // 2) Normal indexed email/mobile login.
        String indexed = value.contains("@")
                ? p.getString(PREFIX + "email_" + canonicalEmail(value), "")
                : p.getString(PREFIX + "mobile_" + canonicalMobile(value), "");
        if (!indexed.isEmpty()) return indexed;

        // 3) Legacy V-24 style direct key fallback.
        String oldBase = PREFIX + (value.contains("@") ? canonicalEmail(value) : canonicalMobile(value));
        String legacyId = p.getString(oldBase + "_user_id", "");
        if (!legacyId.isEmpty()) {
            migrateLegacyRecord(p, oldBase, legacyId);
            return legacyId;
        }

        // 4) Repair a missing index by scanning authoritative local account records.
        // This is intentionally read-only except for rebuilding the missing index.
        Map<String, ?> all = p.getAll();
        String emailKey = canonicalEmail(value);
        String mobileKey = canonicalMobile(value);
        for (Map.Entry<String, ?> entry : all.entrySet()) {
            String key = entry.getKey();
            if (!key.startsWith(PREFIX + "uid_") || !key.endsWith("_user_id")) continue;
            String uid = String.valueOf(entry.getValue());
            if (!isFourDigit(uid)) continue;
            String email = p.getString(PREFIX + "uid_" + uid + "_email", "");
            String mobile = p.getString(PREFIX + "uid_" + uid + "_mobile", "");
            if ((!emailKey.isEmpty() && canonicalEmail(email).equals(emailKey))
                    || (!mobileKey.isEmpty() && canonicalMobile(mobile).equals(mobileKey))) {
                SharedPreferences.Editor repair = p.edit();
                if (!emailKey.isEmpty()) repair.putString(PREFIX + "email_" + emailKey, uid);
                if (!mobileKey.isEmpty()) repair.putString(PREFIX + "mobile_" + mobileKey, uid);
                repair.commit();
                return uid;
            }
        }
        return "";
    }

    private static void migrateLegacyRecord(SharedPreferences p, String oldBase, String userId) {
        String record = PREFIX + "uid_" + userId;
        SharedPreferences.Editor e = p.edit()
                .putString(record + "_user_id", userId)
                .putString(record + "_name", p.getString(oldBase + "_name", ""))
                .putString(record + "_email", p.getString(oldBase + "_email", ""))
                .putString(record + "_mobile", p.getString(oldBase + "_mobile", ""))
                .putString(record + "_password_hash", p.getString(oldBase + "_password_hash", ""));
        String email = p.getString(record + "_email", "");
        String mobile = p.getString(record + "_mobile", "");
        if (!email.isEmpty()) e.putString(PREFIX + "email_" + canonicalEmail(email), userId);
        if (!mobile.isEmpty()) e.putString(PREFIX + "mobile_" + canonicalMobile(mobile), userId);
        e.commit();
    }

    private static boolean isFourDigit(String value) {
        return value != null && value.matches("[0-9]{4}");
    }

    private static String canonicalEmail(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.US);
    }

    private static String canonicalMobile(String value) {
        return value == null ? "" : value.replaceAll("[^0-9+]", "");
    }

    private static String hashPassword(String password) {
        try {
            byte[] salt = new byte[16];
            RNG.nextBytes(salt);
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 120000, 256);
            byte[] derived = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            spec.clearPassword();
            return HASH_PREFIX + hex(salt) + "$" + hex(derived);
        } catch (Exception e) {
            throw new IllegalStateException("Secure password hashing unavailable", e);
        }
    }

    private static boolean verifyPassword(String password, String stored) {
        try {
            if (stored.startsWith(HASH_PREFIX)) {
                String[] parts = stored.split("\\$", -1);
                if (parts.length != 3) return false;
                byte[] salt = unhex(parts[1]);
                byte[] expected = unhex(parts[2]);
                PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 120000, expected.length * 8);
                byte[] actual = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
                spec.clearPassword();
                return MessageDigest.isEqual(expected, actual);
            }
            if (stored.startsWith("sha256:")) return stored.equals("sha256:" + sha256(password));
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private static String hashAnswer(String value) {
        return "sha256:" + sha256(value == null ? "" : value.trim().toLowerCase(Locale.US));
    }

    private static boolean verifyAnswer(String value, String stored) {
        return stored != null && stored.equals(hashAnswer(value));
    }

    private static String sha256(String value) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return hex(
                    md.digest(
                            (value == null ? "" : value)
                                    .getBytes(StandardCharsets.UTF_8)
                    )
            );
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(
                    "SHA-256 algorithm is unavailable",
                    e
            );
        }
    }

    private static String hex(byte[] data) {
        StringBuilder out = new StringBuilder(data.length * 2);
        for (byte b : data) out.append(String.format(Locale.US, "%02x", b));
        return out.toString();
    }

    private static byte[] unhex(String s) {
        byte[] out = new byte[s.length() / 2];
        for (int i = 0; i < out.length; i++) out[i] = (byte) Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16);
        return out;
    }


    public static String[] getSecurityQuestions(Context context, String identifier) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String uid = resolveUserId(p, identifier == null ? "" : identifier.trim());
        if (uid.isEmpty()) return new String[0];
        String record = PREFIX + "uid_" + uid;
        return new String[]{p.getString(record + "_security_q1", ""), p.getString(record + "_security_q2", ""), p.getString(record + "_security_q3", "")};
    }

    public static boolean resetPasswordWithSecurity(Context context, String identifier, String a1, String a2, String a3, String newPassword) {
        if (newPassword == null || newPassword.length() < 6) return false;
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String uid = resolveUserId(p, identifier == null ? "" : identifier.trim());
        if (uid.isEmpty()) return false;
        String record = PREFIX + "uid_" + uid;
        int correct = 0;
        if (a1 != null && !a1.trim().isEmpty() && verifyAnswer(a1, p.getString(record + "_security_a1", ""))) correct++;
        if (a2 != null && !a2.trim().isEmpty() && verifyAnswer(a2, p.getString(record + "_security_a2", ""))) correct++;
        if (a3 != null && !a3.trim().isEmpty() && verifyAnswer(a3, p.getString(record + "_security_a3", ""))) correct++;
        if (correct < 2) return false;
        return p.edit().putString(record + "_password_hash", hashPassword(newPassword)).commit();
    }

    public static final class Account {
        public final String userId;
        public final String name;
        public final String email;
        public final String mobile;
        Account(String userId, String name, String email, String mobile) {
            this.userId = userId; this.name = name; this.email = email; this.mobile = mobile;
        }
    }
}
