-- MY SHOP V-62 Cloudflare D1 schema
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL DEFAULT '',
  email TEXT UNIQUE,
  mobile TEXT UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'USER',
  language TEXT NOT NULL DEFAULT 'bn',
  profile_photo_key TEXT,
  bio TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS security_questions (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  q1 TEXT NOT NULL DEFAULT '', a1_hash TEXT NOT NULL DEFAULT '',
  q2 TEXT NOT NULL DEFAULT '', a2_hash TEXT NOT NULL DEFAULT '',
  q3 TEXT NOT NULL DEFAULT '', a3_hash TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS content_items (
  id TEXT PRIMARY KEY, type TEXT NOT NULL, title TEXT NOT NULL DEFAULT '', value TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1, sort_order INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_mobile ON users(mobile);
CREATE INDEX IF NOT EXISTS idx_content_type ON content_items(type, active, sort_order);
