// MY SHOP V-62 backend foundation.
// Deploy only after the owner creates the Worker/D1/R2 resources in their Cloudflare account.
// Never put Cloudflare passwords or API tokens in the app source.

const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status, headers: { "content-type": "application/json; charset=utf-8", "access-control-allow-origin": "*" }
});

function now() { return new Date().toISOString(); }

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "OPTIONS") return new Response(null, { headers: { "access-control-allow-origin": "*", "access-control-allow-methods": "GET,POST,PUT,DELETE,OPTIONS", "access-control-allow-headers": "content-type,authorization" } });
    try {
      if (url.pathname === "/api/health") return json({ ok: true, version: "V-62" });
      if (url.pathname === "/api/content" && request.method === "GET") {
        const type = url.searchParams.get("type") || "breaking_news";
        const { results } = await env.DB.prepare("SELECT id,type,title,value,active,sort_order FROM content_items WHERE type=? AND active=1 ORDER BY sort_order,id").bind(type).all();
        return json({ ok: true, items: results });
      }
      if (url.pathname === "/api/profile" && request.method === "GET") {
        const profileId = url.searchParams.get("profileId") || "";
        const user = await env.DB.prepare("SELECT id,profile_id,name,email,mobile,role,language,profile_photo_key,bio FROM users WHERE profile_id=?").bind(profileId).first();
        return user ? json({ ok:true, user }) : json({ ok:false, error:"USER_NOT_FOUND" },404);
      }
      return json({ ok:false, error:"NOT_IMPLEMENTED" },404);
    } catch (e) {
      return json({ ok:false, error:"SERVER_ERROR" },500);
    }
  }
};
