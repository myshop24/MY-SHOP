# MY SHOP V-62 Backend

Owner-side setup only: create a Cloudflare Worker, D1 database and R2 bucket in the owner's account. Do not share passwords/API tokens.

1. Create D1 database `my-shop-v62` and apply `schema.sql`.
2. Create R2 bucket `my-shop-v62-media`.
3. Put the returned D1 database ID into `wrangler.toml`.
4. Deploy the Worker.
5. Store the Worker HTTPS URL in the Android app's backend configuration.
6. Before production auth is enabled, add signed-session/JWT verification and admin permission middleware.

Permanent Profile ID is stored in D1 with a UNIQUE constraint. App version changes must never generate a new profile ID.
