# V656 — GitHub upload size repair
Baseline: exact delivered V655. Scope: source delivery size and sequential release identity only.
All V655 files are retained. Two static WebP atlases are re-encoded at high quality; dimensions, alpha, cell layout, names and paths stay unchanged. RGB is lossy, not pixel-identical. No image generation/redesign, cropping, frame/audio removal, or runtime feature change. Compression measurements: verification/V656-IMAGE-COMPRESSION.json.
Live/RTC/Gift/Cricket implementations are identical to V655; Worker differences are only version identity. Original signing identity and dependencies retained.
Tests: source byte preservation manifest, image decode/dimensions/alpha and visual comparison, ZIP CRC/exact round-trip and strict <25,000,000-byte gate. These are packaging checks, not a new Android compile or phone test. V655's device/Gift/production acceptance remains pending. No APK built locally and no production deployment.
Build: use existing root GitHub Actions workflow; upload V-656-MY-SHOP-FULL-SOURCE.zip unchanged to repository root, commit, then Actions > MY SHOP Android APK. Existing signing/Firebase Secrets are still required; see the retained V655 handoff below. Successful build must produce and verify exact version 2.9.656 / code656 in Artifacts; source ZIP upload alone does not prove success. Do not upload a renamed old APK.
Next changed delivery: V657. Continue from V656, do not restart V654/655.

---
Retained V655 implementation and setup details:

# MY SHOP V655 / 2.9.655 — source delivery

Baseline is the actually delivered V654 full-source ZIP, not V653. V654 is preserved. Latest owner scope is V655-APPROVED-WORK-BN.md. New changed release after this delivery must be V656.

## What changed
- Normal Gift chooser now rejects missing/unconfirmed receipts instead of closing as if successful. Lost/error responses can recover the authenticated sender's exact committed receipt via read-only receipt655 endpoint; original liveGiftSend and catalog financial functions are hash-locked to V654. Comment failure no longer prevents effect dispatch. Existing nonce retry, balances, prices and normal fees retained. Commission WORDING removed, total debit still shown.
- Compact Cricket board has both team names/numbers in the same score strip, green innings, unambiguous overs, small grips, line-size choices and horizontal scroll. Board/player/sponsor panels have local drag/resize and vertical scroll. Empty large player cards removed. Sponsor retained with authoritative profile. Line long-press selects small/normal/large; panel grip moves/resizes. Local layout namespace655 intentionally resets oversized654 defaults.
- Cricket Catalog entry is small icon/label with corner info marker. Existing PanelDesign system used under isolated game_hub655 scope for admin templates/background; no fake future games. Public native Bengali/English guide begins with Host opening board and covers setup through recovery. Private administrative powers are omitted. Added controller-only resetRun655; Ball Reset still clears both inputs. Core engine/privacy/innings/account logic retained.
- Host header avatar/name now opens existing profile bottom sheet. Coin/Diamond Top20 untouched. Profile names overflow left-to-right using cached layout. Occupied audio/main/video seats show names; empty chairs retain original design. Camera-off fallback is circular; camera surfaces/RTC/guest consent paths retained. Decorative ring remains at rest; speech pulse respects mute; mute badge visible.
- Retired decorative MOVING_MIC is hidden from selector/list and renderer (old stored rows kept for compatibility). Ads publish/save reports invalid/expired schedules and missing page selections. Existing actual product, expiry, draft/published and permissions are retained.
- Coin Box claim/eligibility backend unchanged; valid claim presentation now box/burst + native bounded coin shower and amount. Effects clear with session end. Lucky is separate from Coin Box.
- Lucky tab order Coin/Diamond/Lucky/Favourite. Five generated flower baskets50k/100k/200k/300k/500k. Atomic SQL batch debit/credit/value ledger and nonce receipt; deterministic equal distribution incl fresh host/sender; integer remainder assigned by sorted user ID. No extra Lucky fee. Official-source units conserved. Stale/removed users excluded, snapshot fixed before transaction;1000 recipients cap. All costs/default eligibility disclosed in confirmation. Native32-particle six-second flower effect; max one active Lucky visual per Activity. Uses existing announcement transport/global shared snapshot, no separate Lucky polling; no per-viewer Lucky receipt query when no relevant event exists. Coin/Diamond original categories remain.
- Runtime build repacks148 WAV sounds into FLAC, verifying decoded PCM equality, saves23,677,565 bytes of raw resource payload (39,290,630 →15,613,065). No original sound/generator removed. CI builds ARM64 (`-PmyshopAbi=arm64-v8a`) for owner's phone; local default supports both ARM64/ARMv7. Use `-PmyshopAbi=armeabi-v7a` for32-bit phones. No emulator x86 libraries in delivered CI APK. Do not distribute ARM64 APK to32-bit devices. High-res GIF/WebP originals and full Agora SDK retained; final APK size is UNMEASURED.

## Verification and limits
See verification/V655-RESULTS.json and V655-PREBUILD-GATES.json for actual counts. Node engine/SQLite tests, compiled Gift retry/dispatch, source syntax/context/lambda checks and protected boundary hashes are separate from Android/device acceptance. Baseline manifests record every shipped original file and scoped changes. No original code/runtime asset removed. Two byte-identical historical documents consolidated into their canonical handoffs; references updated. Generated/cache/build outputs are excluded from source package and recreated from included inputs.

IMPORTANT: the reported physical-phone Gift failure root cause is NOT conclusively established. Source safeguards/receipt recovery and tests do NOT prove it is fixed on the phone. Ads production configuration and live responses were not accessed; schedule inversion/expiry is visible in provided video, no blanket outage-resolution claim.

No Android APK was built here: Gradle8.11.1 download fails Network is unreachable; Android SDK/original signing identity unavailable. No GitHub run, signed artifact, actual phone, RTC/load/UI gesture/multi-device acceptance or production deployment performed. Do not say100% complete or phone crash resolved. The approved visual mockups are not real Android screenshots. Per-line scaling, circle positioning, touch targets, video reattachment and weak-network recovery require phone tests. Existing all-app Play/Billing/privacy/moderation review is not complete.

## Build and setup
Read GITHUB-UPLOAD-V655-BN.md. JDK17, Gradle8.11.1, SDK/build-tools36, Node22+ (node:sqlite), Python3.12 + tools/requirements-build-assets.txt, ffmpeg/fonts. From project root:
1. `bash tools/prepare-build-assets.sh` recreates byte/pixel-checked originals.
2. `python3 tools/prepare_runtime655.py` creates checked lossless build-only FLAC resources (also automatic dependency of Android preBuild).
3. `bash tools/v655_target_verify.sh` and `node --test --test-concurrency=2 tests/*.test.mjs tests/*.spec.cjs`.
4. Full CI uses tools/ci-apk-build.sh: clean Android unit tests/release/lint; original certificate/package/version/commit/provenance checks and655 DEX/ABI/atlas/no-WAV check. One MY_SHOP_FINAL_RELEASE.apk artifact only after successful signed build.
Signing/Firebase secret NAMES/setup in upload guide. No secret values or replacement keystore included. Never replace the original signing identity.
Matching backend source is REQUIRED for receipt/Lucky/new run-reset/game-hub settings. Existing Cricket migration0066, plus additive0067_v655_lucky.sql; preserve D1/R2/Agora bindings. Migrations/deploy must be a reviewed operation, not an implicit upload of Android sources. Existing old app endpoints retained. App update alone does not deploy Worker.

## Next steps
1. Run GitHub Android build and resolve any actual type/resource/lint/test errors. Verify commit, original signing cert, package/version and655 markers from exact downloaded APK, measure download and installed size.
2. Reproduce normal Gift video case on affected phone with logcat + receipt response and ledger comparison; confirm sender debit/recipient credit, both users' comments/animations/audio, no crash, same-nonce retry and loss-of-response recovery.
3. Test Lucky two phones + Host, duplicate concurrent sends, insufficient balance, reconnect/background/end during request, fresh/stale/removed members, sender-inclusion and deterministic remainders. Owner may choose different sender eligibility later; do not silently change issued receipts.
4. Test compact Cricket role layouts, controller changes, real sponsor, rules info marker, line-size/scroll/grips on small phones; all secret payload/score/recovery regressions. Real layout is pending approval after APK check.
5. Full Live regressions: original chairs, RTC camera consent/publish, audio, names/mute, membership frames, comments, normal gifts/sounds, invite/join/vote/love/music/minimize/reconnect/end/moderation. Measure device CPU/memory/network/load and all148 FLAC sounds.
6. Store homepage remained an unselected proposal, existing storefront/catalog retained. Future entertainment proposals not automatically added.
