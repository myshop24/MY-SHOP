# V656 — GitHub upload size repair
Baseline: exact delivered V655. Scope: source delivery size and sequential release identity only.
All V655 files are retained. Two static WebP atlases are re-encoded at high quality; dimensions, alpha, cell layout, names and paths stay unchanged. RGB is lossy, not pixel-identical. No image generation/redesign, cropping, frame/audio removal, or runtime feature change. Compression measurements: verification/V656-IMAGE-COMPRESSION.json.
Live/RTC/Gift/Cricket implementations are identical to V655; Worker differences are only version identity. Original signing identity and dependencies retained.
Tests: source byte preservation manifest, image decode/dimensions/alpha and visual comparison, ZIP CRC/exact round-trip and strict <25,000,000-byte gate. These are packaging checks, not a new Android compile or phone test. V655's device/Gift/production acceptance remains pending. No APK built locally and no production deployment.
Build: use existing root GitHub Actions workflow; upload V-656-MY-SHOP-FULL-SOURCE.zip unchanged to repository root, commit, then Actions > MY SHOP Android APK. Existing signing/Firebase Secrets are still required; see the retained V655 handoff below. Successful build must produce and verify exact version 2.9.656 / code656 in Artifacts; source ZIP upload alone does not prove success. Do not upload a renamed old APK.
Next changed delivery: V657. Continue from V656, do not restart V654/655.

Historical checkpoint:
V655 /2.9.655 owner-authorized source checkpoint. See CURRENT-WORK-CHECKPOINT.md and current developer handoff. Source/test results are not an APK or real-phone acceptance. No deployment. Next changed delivery656 after655.
