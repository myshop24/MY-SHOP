# MY SHOP Developer Handoff — V-306

## Version
V-306 / Android 2.9.306

## Completed
- Narrow compile-only correction in `ProfileSocialActivity.mediaTile()`.
- Media URL, normalized media type, and caption are immutable before the tile click lambda.
- `photo` continues to behave as `image`; viewer behavior is unchanged.

## Preserved V-305 final scope
- Dedicated Host above + unchanged 12-seat 6+6 User/Guest board.
- Admin Locker update persistence.
- Share Profile visible + share action.
- Four compact premium Quick Tools in one row.
- Quick Tools logic/balance/member/items/backend preserved.
- Photos/Videos/Reels real media grid; Timeline and Back navigation preserved.

## Protected / unchanged
- Existing permanent signing key / PK and signing workflow.
- Cloudflare D1/R2 bindings, schema, IDs, and storage behavior.
- Existing working Live/Host/seat functions outside the requested scope.
- Master workflow source-lock and safety guards.

## Validation checkpoint
- Source identity: `SOURCE_BUILD_ID=MY SHOP V-306`.
- Android identity: `versionCode 306`, `versionName 2.9.306`.
- Compile-blocking mutable lambda capture removed.
- Full Android release compilation must still be confirmed by the GitHub Actions Android environment.

## Next checkpoint
Run the existing permanent GitHub Actions build and verify compile -> exactly one APK -> permanent-key signing -> final upload.
