package com.myshop.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

/**
 * V-165: permanent USER MENU rule.
 * Profile belongs to the main dashboard left side and is never duplicated in this hamburger screen. The hamburger screen contains user features only.
 * This activity NEVER opens an Admin panel, even for an Admin account.
 */
public class UserMenuActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(247,248,252), DARK=Color.rgb(24,29,62), BLUE=Color.rgb(46,47,190), PURPLE=Color.rgb(83,32,180), RED=Color.rgb(210,45,55), MUTED=Color.rgb(95,99,115);

    @Override protected void onCreate(Bundle b){super.onCreate(b); build();}

    private void build(){
        LinearLayout root=col();
        root.setBackgroundColor(BG);
        root.setPadding(dp(12),dp(10),dp(12),dp(16));

        LinearLayout title=row();
        TextView close=button("‹",DARK,22); close.setOnClickListener(v->finish()); title.addView(close,lp(dp(40),dp(42)));
        TextView t=txt("MY SHOP",18,DARK,true); t.setGravity(Gravity.CENTER_VERTICAL); title.addView(t,weight(1,dp(42)));
        TextView lang=txt("🌐 "+code(),BLUE,9,true); lang.setGravity(Gravity.CENTER); lang.setBackground(bg(Color.rgb(245,246,255),Color.TRANSPARENT,12)); lang.setOnClickListener(v->LanguageManager.showPicker(this,()->recreate())); title.addView(lang,lp(dp(62),dp(38)));
        root.addView(title,lp(-1,dp(48)));

        TextView label=txt("USER MENU",11,PURPLE,true); label.setPadding(dp(4),dp(4),0,dp(6)); root.addView(label,lp(-1,dp(30)));
        EditText search=new EditText(this); search.setHint("Search"); search.setSingleLine(true); search.setTextSize(13); search.setPadding(dp(12),0,dp(12),0); search.setBackground(bg(Color.WHITE,Color.rgb(225,227,235),12)); root.addView(search,lp(-1,dp(46)));

        ScrollView scroll=new ScrollView(this); scroll.setVerticalScrollBarEnabled(false); scroll.setFillViewport(false);
        LinearLayout list=col();
        add(list,"HOME","Main dashboard",R.drawable.dash_action_feed,()->finish());
        add(list,"MY SHOP","Shop and products",R.drawable.dash_feat_shop,()->open("MY SHOP","my_shop"));
        add(list,"GALLERY","Photo • Audio • Video",R.drawable.dash_feat_gallery,()->startActivity(new Intent(this,GalleryActivity.class)));
        add(list,"EXTERNAL MOVIE","External movie links",R.drawable.dash_feat_movie,()->open("EXTERNAL MOVIE","external_movie"));
        add(list,"GO LIVE","Start a live stream",R.drawable.dash_action_go,()->open("GO LIVE","go_live"));
        add(list,"JOIN LIVE","Join a live stream",R.drawable.dash_action_live,()->open("JOIN LIVE","live_now"));
        add(list,"EARN & REWARD","Coins, gifts and rewards",R.drawable.dash_feat_reward,()->open("EARN & REWARD","earn_reward"));
        add(list,"LIVE TV","Live TV channels",R.drawable.dash_feat_tv,()->open("LIVE TV","live_tv"));
        add(list,"LIVE","Watch live streams",R.drawable.dash_action_live,()->open("LIVE","live_now"));
        add(list,"SOCIAL MEDIA","Facebook • YouTube • TikTok • Instagram",R.drawable.feature_social_selected,()->open("SOCIAL MEDIA","social_media"));
        add(list,"CHAT","Chat and messages",android.R.drawable.ic_dialog_email,()->open("CHAT","chat"));
        add(list,"MUSIC","Music",android.R.drawable.ic_media_play,()->open("MUSIC","music"));
        add(list,"BREAKING NEWS","Latest headlines",android.R.drawable.ic_dialog_info,()->open("BREAKING NEWS","breaking_news"));
        add(list,"MORE APPS","Facebook • Page • YouTube • WhatsApp • imo • Instagram • Telegram",R.drawable.dash_feat_apps,()->open("MORE","more_apps"));
        add(list,"SHARE APP","Share MY SHOP",R.drawable.feature_share_selected,()->shareApp());
        add(list,"HELP & SUPPORT","WhatsApp customer support",android.R.drawable.ic_menu_help,()->open("CUSTOMER SUPPORT","help_support"));
        add(list,"JOBS","Jobs and opportunities",android.R.drawable.ic_menu_agenda,()->open("JOBS","jobs"));
        add(list,"COUPON","Coupons and offers",android.R.drawable.ic_menu_save,()->open("COUPON","coupon"));
        add(list,"BOOKING","Bookings",android.R.drawable.ic_menu_my_calendar,()->open("BOOKING","booking"));
        add(list,"WALLET","Wallet and coins",android.R.drawable.ic_menu_view,()->open("WALLET","wallet"));
        add(list,"SETTINGS","App settings",android.R.drawable.ic_menu_manage,()->open("SETTINGS","settings"));
        add(list,"LANGUAGE","বাংলা • English • हिन्दी • العربية",android.R.drawable.ic_menu_manage,()->LanguageManager.showPicker(this,()->recreate()));
        add(list,"LOGOUT","Sign out of this device",android.R.drawable.ic_lock_power_off,()->logout());
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence q,int st,int b,int c){String ql=q.toString().trim().toLowerCase(); for(int i=0;i<list.getChildCount();i++){View v=list.getChildAt(i);Object tag=v.getTag();String title=tag==null?"":String.valueOf(tag);v.setVisibility(ql.isEmpty()||title.toLowerCase().contains(ql)?View.VISIBLE:View.GONE);}} public void afterTextChanged(android.text.Editable e){}});
        scroll.addView(list,new ScrollView.LayoutParams(-1,-2));
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    private void add(LinearLayout list,String title,String desc,int icon,Runnable action){
        LinearLayout c=col(); c.setPadding(dp(8),dp(5),dp(8),dp(5)); c.setBackground(bg(Color.WHITE,Color.rgb(230,232,238),12));
        LinearLayout.LayoutParams cp=lp(-1,dp(64)); cp.bottomMargin=dp(6); c.setLayoutParams(cp);
        LinearLayout r=row(); ImageView iv=new ImageView(this); iv.setImageResource(icon); iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE); r.addView(iv,lp(dp(42),dp(48)));
        LinearLayout b=col(); b.setPadding(dp(8),0,dp(4),0); TextView a=txt(title,11.5f,DARK,true); a.setGravity(Gravity.CENTER_VERTICAL); b.addView(a,lp(-1,dp(25))); TextView d=txt(desc,8.5f,MUTED,false); d.setGravity(Gravity.CENTER_VERTICAL); d.setSingleLine(true); d.setEllipsize(android.text.TextUtils.TruncateAt.END); b.addView(d,lp(-1,dp(22))); r.addView(b,weight(1,dp(48))); TextView go=txt("›",BLUE,20,true); go.setGravity(Gravity.CENTER); r.addView(go,lp(dp(28),dp(48))); c.addView(r,lp(-1,dp(48))); c.setTag(title); c.setOnClickListener(v->action.run()); list.addView(c);
    }

    private void open(String title,String key){ Intent i=new Intent(this,FeatureActivity.class); i.putExtra("title",title); i.putExtra("feature_key",key); i.putExtra("user_menu",true); startActivity(i); }
    private void openCustomerSupport(){
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(org.json.JSONObject d){ org.json.JSONArray a=d.optJSONArray("managedLinks"); String url=""; if(a!=null)for(int i=0;i<a.length();i++){org.json.JSONObject x=a.optJSONObject(i);if(x!=null&&"help_support".equals(x.optString("category",""))){String u=x.optString("url","").trim();if(FeatureRegistry.isSafeHttpUrl(u)){url=u;break;}}} final String target=url; runOnUiThread(()->{if(!target.isEmpty()){try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(target)));}catch(Exception e){Toast.makeText(UserMenuActivity.this,"Unable to open support.",Toast.LENGTH_SHORT).show();}}else Toast.makeText(UserMenuActivity.this,"Customer support is not configured yet.",Toast.LENGTH_SHORT).show();}); }
            public void onError(String m){runOnUiThread(()->Toast.makeText(UserMenuActivity.this,"Customer support unavailable.",Toast.LENGTH_SHORT).show());}
        });
    }
    private void shareApp(){try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"MY SHOP");i.putExtra(Intent.EXTRA_TEXT,"MY SHOP — https://rapid-bush-62ea.myshopsatkania.workers.dev");startActivity(Intent.createChooser(i,"Share MY SHOP"));}catch(Exception e){Toast.makeText(this,"Share is not available.",Toast.LENGTH_SHORT).show();}}
    private void logout(){String token=SessionManager.getToken(this);SessionManager.clear(this);Intent i=new Intent(this,LoginActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(i);if(token!=null&&!token.isEmpty())BackendClient.logout(token,new BackendClient.Callback(){public void onSuccess(org.json.JSONObject d){}public void onError(String m){}});}
    private void loadRemoteImage(ImageView target,String url){new Thread(()->{try{java.net.HttpURLConnection c=(java.net.HttpURLConnection)new java.net.URL(url).openConnection();c.setConnectTimeout(3000);c.setReadTimeout(5000);try(java.io.InputStream in=c.getInputStream()){android.graphics.Bitmap bm=android.graphics.BitmapFactory.decodeStream(in);if(bm!=null)runOnUiThread(()->target.setImageBitmap(bm));}}catch(Exception ignored){}}).start();}
    private String code(){String l=LanguageManager.get(this);if(LanguageManager.EN.equals(l))return "EN";if(LanguageManager.HI.equals(l))return "HI";if(LanguageManager.AR.equals(l))return "AR";return "বাং";}
    private TextView button(String s,int c,float z){TextView b=new TextView(this);b.setText(s);b.setTextColor(c);b.setTextSize(z);b.setGravity(Gravity.CENTER);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return b;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView txt(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}
    private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}
    private View topWrap(View v,int m){v.setLayoutParams(top(lp(-1,dp(32)),m));return v;}
    private GradientDrawable bg(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
