package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** Shared Login entry point for USER / MODERATOR / ADMIN. */
public class LoginActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            if (SessionManager.isLoggedIn(this) && !SessionManager.getUserId(this).isEmpty()) {
                // Only restore a session that has a coherent local profile. Otherwise require a fresh login.
                String uid = SessionManager.getUserId(this);
                String profile = getSharedPreferences("myshop_session", MODE_PRIVATE).getString("full_name", "");
                if (!profile.trim().isEmpty()) { openMain(); return; }
                SessionManager.clear(this);
            }
            setContentView(R.layout.activity_login);
            findViewById(R.id.createAccountButton).setOnClickListener(v ->
                    startActivity(new Intent(this, RegisterActivity.class)));
            findViewById(R.id.loginButton).setOnClickListener(v -> login());
            findViewById(R.id.forgotButton).setOnClickListener(v ->
                    Toast.makeText(this, "Password reset will be connected to the secure backend.", Toast.LENGTH_LONG).show());
        } catch (Throwable t) {
            // Never let a Login screen initialization failure terminate the app silently.
            Toast.makeText(this, "MY SHOP Login could not be loaded. Please try again.", Toast.LENGTH_LONG).show();
        }
    }

    private void login() {
        try {
            EditText id = findViewById(R.id.loginId);
            EditText password = findViewById(R.id.loginPassword);
            String identifier = id == null ? "" : id.getText().toString().trim();
            String pass = password == null ? "" : password.getText().toString();

            if (identifier.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Email/Mobile and Password are required.", Toast.LENGTH_SHORT).show();
                return;
            }

            AccountStore.Account account = AccountStore.authenticate(this, identifier, pass);
            if (account == null) {
                Toast.makeText(this, "Login failed. Check your Email/Mobile and Password.", Toast.LENGTH_LONG).show();
                return;
            }

            // Role resolution remains server-owned. This local prototype never grants Admin by UI matching.
            SessionManager.setSession(this, Role.USER, account.userId);
            SessionManager.saveProfile(this, account.name, account.email, account.mobile);
            openMain();
        } catch (Throwable t) {
            Toast.makeText(this, "Login failed safely. Your account data was not changed.", Toast.LENGTH_LONG).show();
        }
    }

    private void openMain() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}
