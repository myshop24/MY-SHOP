# MY SHOP V-90

V-90 is the controlled MY SHOP build baseline.

## Identity
- Package: `com.myshop.app`
- Version code: `90`
- Version name: `2.9.90`
- Launcher: `com.myshop.app.LoginActivity`

## First objective
1. APK builds successfully.
2. APK installs and launches.
3. Login screen opens.
4. Dashboard opens without clipping or broken layout.
5. Dashboard is then refined for full mobile-screen fitting before feature work continues.

## Build requirements
GitHub Actions provisions Java 17, Android SDK 35, Build Tools 35.0.0 and Gradle 8.11.1. A permanent release keystore must be supplied through GitHub Secrets.
