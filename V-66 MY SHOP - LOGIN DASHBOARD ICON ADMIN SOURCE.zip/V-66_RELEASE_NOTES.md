# MY SHOP V-66 — Login + Dashboard + MS Icon + Admin

- Final Login baseline updated to the approved compact design.
- Default language is English; selector cycles বাংলা → English → हिन्दी → العربية.
- Existing authenticated account/session continues to the Main Dashboard with the same permanent Profile ID.
- Main Dashboard rebuilt to the approved mobile structure: header, 2 banners, wide banner, 3 promos, Breaking News (17sp), 4 Live cards, Live/Go Live/My Feed, 8 feature tiles and fixed Home/Live/Store/Chat/More navigation.
- Admin uses the same Main Dashboard; only role-gated Admin Controls are exposed.
- Admin Controls cover Banner, Breaking News, Gallery/Media, Social Links, My Shop, TV/External and Moderator management.
- MS launcher icon remains the supplied myshop_icon.png and is referenced by the application manifest.
- Version: 2.9.66 / versionCode 66.

Build note: this environment does not contain Gradle/Android SDK, so APK compilation is not claimed here. GitHub Actions workflow remains the authoritative build/one-APK verification path.
