package com.myshop.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Map;

public final class LanguageManager {
    public static final String BN = "bn";
    public static final String EN = "en";
    public static final String HI = "hi";
    public static final String AR = "ar";

    private static final String PREFS = "myshop_settings";
    private static final String KEY_LANGUAGE = "language";

    private static final Map<String, Map<String, String>> TEXT = new HashMap<>();

    static {
        Map<String, String> en = new HashMap<>();
        en.put("search", "Search for products, live, users, posts...");
        en.put("breaking", "BREAKING NEWS");
        en.put("liveNow", "LIVE NOW");
        en.put("seeAll", "See all");
        en.put("live", "LIVE");
        en.put("goLive", "GO LIVE");
        en.put("feed", "MY FEED");
        en.put("shop", "MY SHOP");
        en.put("gallery", "GALLERY");
        en.put("movie", "EXTERNAL MOVIE");
        en.put("tv", "LIVE TV");
        en.put("social", "SOCIAL MEDIA");
        en.put("reward", "EARN & REWARD");
        en.put("share", "SHARE");
        en.put("apps", "MORE APPS");
        en.put("chat", "Chat");
        en.put("home", "Home");
        en.put("store", "Store");
        en.put("more", "More");
        en.put("menu", "Menu");
        en.put("language", "Language");
        en.put("login", "Login");
        en.put("register", "Create Account");
        en.put("notifications", "Notifications");
        en.put("noConfig", "This feature is ready for its next module.");
        TEXT.put(EN, en);

        Map<String, String> bn = new HashMap<>();
        bn.put("search", "পণ্য, লাইভ, ইউজার, পোস্ট খুঁজুন...");
        bn.put("breaking", "ব্রেকিং নিউজ");
        bn.put("liveNow", "লাইভ এখন চলছে");
        bn.put("seeAll", "সব দেখুন");
        bn.put("live", "লাইভ");
        bn.put("goLive", "লাইভ যান");
        bn.put("feed", "MY FEED");
        bn.put("shop", "MY SHOP");
        bn.put("gallery", "গ্যালারি");
        bn.put("movie", "এক্সটার্নাল মুভি");
        bn.put("tv", "লাইভ টিভি");
        bn.put("social", "সোশ্যাল মিডিয়া");
        bn.put("reward", "আয় ও পুরস্কার");
        bn.put("share", "শেয়ার");
        bn.put("apps", "আরও অ্যাপস");
        bn.put("chat", "চ্যাট");
        bn.put("home", "হোম");
        bn.put("store", "স্টোর");
        bn.put("more", "আরও");
        bn.put("menu", "মেনু");
        bn.put("language", "ভাষা");
        bn.put("login", "লগইন");
        bn.put("register", "অ্যাকাউন্ট খুলুন");
        bn.put("notifications", "নোটিফিকেশন");
        bn.put("noConfig", "এই ফিচারের পরের মডিউল প্রস্তুত করা হচ্ছে।");
        TEXT.put(BN, bn);

        Map<String, String> hi = new HashMap<>();
        hi.put("search", "प्रोडक्ट, लाइव, यूज़र, पोस्ट खोजें...");
        hi.put("breaking", "ब्रेकिंग न्यूज़"); hi.put("liveNow", "अभी लाइव"); hi.put("seeAll", "सब देखें");
        hi.put("live", "लाइव"); hi.put("goLive", "लाइव जाएँ"); hi.put("feed", "MY FEED"); hi.put("shop", "MY SHOP");
        hi.put("gallery", "गैलरी"); hi.put("movie", "एक्सटर्नल मूवी"); hi.put("tv", "लाइव टीवी"); hi.put("social", "सोशल मीडिया");
        hi.put("reward", "कमाएँ और रिवॉर्ड"); hi.put("share", "शेयर"); hi.put("apps", "और ऐप्स"); hi.put("chat", "चैट");
        hi.put("home", "होम"); hi.put("store", "स्टोर"); hi.put("more", "और"); hi.put("menu", "मेनू"); hi.put("language", "भाषा");
        hi.put("login", "लॉगिन"); hi.put("register", "अकाउंट बनाएँ"); hi.put("notifications", "नोटिफिकेशन");
        hi.put("noConfig", "यह फीचर अपने अगले मॉड्यूल के लिए तैयार है।"); TEXT.put(HI, hi);

        Map<String, String> ar = new HashMap<>();
        ar.put("search", "ابحث عن المنتجات والبث والمستخدمين والمنشورات...");
        ar.put("breaking", "أخبار عاجلة"); ar.put("liveNow", "مباشر الآن"); ar.put("seeAll", "عرض الكل");
        ar.put("live", "مباشر"); ar.put("goLive", "ابدأ البث"); ar.put("feed", "MY FEED"); ar.put("shop", "MY SHOP");
        ar.put("gallery", "المعرض"); ar.put("movie", "فيلم خارجي"); ar.put("tv", "تلفزيون مباشر"); ar.put("social", "التواصل الاجتماعي");
        ar.put("reward", "اربح ومكافآت"); ar.put("share", "مشاركة"); ar.put("apps", "المزيد من التطبيقات"); ar.put("chat", "دردشة");
        ar.put("home", "الرئيسية"); ar.put("store", "المتجر"); ar.put("more", "المزيد"); ar.put("menu", "القائمة"); ar.put("language", "اللغة");
        ar.put("login", "تسجيل الدخول"); ar.put("register", "إنشاء حساب"); ar.put("notifications", "الإشعارات");
        ar.put("noConfig", "هذه الميزة جاهزة للوحدة التالية."); TEXT.put(AR, ar);
    }

    private LanguageManager() {}

    public static String get(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LANGUAGE, EN);
    }

    public static void set(Context context, String language) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_LANGUAGE, language).apply();
    }

    public static String t(Context context, String key) {
        String lang = get(context);
        Map<String, String> map = TEXT.get(lang);
        if (map == null) map = TEXT.get(BN);
        String value = map.get(key);
        return value == null ? key : value;
    }
}
