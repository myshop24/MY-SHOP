# MY SHOP Developer Handoff — V-434

## Release identity

- Version: V-434
- Android versionName: 434
- Android versionCode: 434
- SOURCE_BUILD_ID: `MY-SHOP-V-434-20260919-ec2811f7cf5a`
- Target branch: `myshop24-patch-1`

## Completed

- Preserved the V-433 Backend Worker source and migrations without functional changes.
- Added the mandatory root-level `SOURCE_BUILD_ID.txt` required by the permanent release pipeline.
- Updated the upload note and release identity to V-434.

## Pending

- Upload/extract this package into the repository root so `SOURCE_BUILD_ID.txt` and `backend/worker/...` exist as direct repository paths.
- Run `MY SHOP PERMANENT RELEASE PIPELINE` from the resulting V-434 commit.
- Verify the workflow commit SHA and SOURCE_BUILD_ID match this package.
- Confirm the produced signed release APK reports versionName 434 and versionCode 434 before distribution.

## Last checkpoint

- Backend Worker source SHA-256: `ec2811f7cf5aa61e21fc539abd66619c350983110630de8e935e2d8dc0150b92`
- The earlier V-433 pipeline stopped before APK build because `SOURCE_BUILD_ID.txt` was absent.

## Next tasks

1. Commit the V-434 package contents to `myshop24-patch-1`.
2. Let the release workflow finish without cancelling it.
3. Verify artifact timestamp/hash and install-test the single signed release APK.

## Known issues

- This ZIP contains the Backend Worker update package, not a complete standalone Android project. The repository's existing Android source and release workflow are still required to build the APK.
- If the Android project has a different preassigned versionCode/versionName sequence, update it consistently before release; do not reuse a previously published versionCode.
