# MY SHOP DEVELOPER HANDOFF — V-271

Current source: **V-271** (`versionCode 271`, `versionName 2.9.271`).

V-271 is the verified implementation successor to V-270. It fixes the gap where the requested dashboard/admin polish was not visibly reflected in the installed build. The source now contains explicit Breaking News size controls and visual color pickers, dashboard visual color pickers, and enlarged/polished Live/New User cards matching the approved reference while preserving real backend behavior and existing feed/navigation functions.

GitHub identity must remain exact: `SOURCE_BUILD_ID.txt = MY SHOP V-271`, `SOURCE_VERSION_NAME.txt = 2.9.271`.

# MY SHOP DEVELOPER HANDOFF

Current source: **V-270** (`versionCode 270`, `versionName 2.9.270`).

## Checkpoint
V-270 is the corrected successor to V-269. It fixes the permanent GitHub Actions source identity gate by using the exact `SOURCE_BUILD_ID.txt = MY SHOP V-270`, and synchronizes Android and Worker identity to V-270.

## Preserved approved scope
- Premium Dashboard proportions and clean responsive alignment.
- Breaking News intentionally scrolls right-to-left; Admin font size and visual text/background color controls remain.
- LIVE STREAMING Go Live / Join Live design and locked top flow remain.
- Dynamic Live-first → newest-user fallback remains.
- Approved circular profile + NEW/LIVE badge + green dot + Name/Level/ID + full-width friend action card style remains.
- MY Feed, Quick Links, banners, notifications/messages and existing backend/social functionality remain protected.

## Next build
Upload this V-270 ZIP to the repository and run the permanent GitHub Actions workflow. Do not modify the master workflow or signing secrets for this identity correction.
