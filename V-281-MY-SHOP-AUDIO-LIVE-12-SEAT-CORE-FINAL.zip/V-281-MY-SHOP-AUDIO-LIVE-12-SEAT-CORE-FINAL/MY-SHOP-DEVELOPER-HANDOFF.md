# MY SHOP Developer Handoff — V-281

Final Live baseline implementation phase started.

- High-quality Audio Live is priority #1.
- 12 authoritative speaking seats: seat 1 Host, 2–12 Speaker/Guest.
- Audience remains outside seats.
- Backend endpoints added for room state, Request to Speak, Host Accept/Reject, automatic free-seat assignment, and Leave Seat.
- Dashboard approved Go Live 35% / Join Live 65% flow is preserved.
- Video Live remains OFF / Coming Soon scope.
- RTC media transport is intentionally not falsely marked complete: production voice requires Agora/equivalent credentials and secure token service.
- Never place RTC App Certificate/secret in APK or public repository.
- Preserve all approved existing MY SHOP features.
