# MY SHOP V-67 — LOGIN + DASHBOARD + MS ICON + ADMIN CORRECTIVE BUILD

- Uses the supplied MS blue/gold shopping-bag icon as the Android launcher icon.
- Login now uses the same MS icon instead of the old orange cart branding.
- Login language selector defaults to English and cycles: বাংলা → English → हिन्दी → العربية.
- Create Account accepts either Email OR Mobile; OTP/verification-code flow is not used.
- Permanent four-digit local Profile IDs start at 0100 and are never rewritten by normal login.
- Three security questions are stored; Forgot Password resets when ANY TWO of the THREE answers match.
- Admin identities are role-detected from the normal Login: myshopsatkania@gmail.com, touhidsatkania@gmail.com, 01860626700.
- No separate Admin login or Admin dashboard. Admin management is hidden behind role permission.
- Admin controls cover banner groups (maximum 6 per group), unlimited Breaking News text, Gallery/Media, Social links, My Shop, TV, 12 External folders, moderator list (maximum 5), and emergency password reset.
- Main Dashboard retains the approved mobile structure and adds the MS icon/brand, profile avatar, and four reference live-card images.
- Breaking News remains 17sp.
- Every V-67 build must produce exactly ONE release APK and version 2.9.67.
