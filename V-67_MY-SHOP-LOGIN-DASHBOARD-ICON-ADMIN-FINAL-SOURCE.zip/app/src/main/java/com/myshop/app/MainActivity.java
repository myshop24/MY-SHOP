package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/** MY SHOP V-66: approved Main Dashboard structure. Admin uses the same dashboard. */
public class MainActivity extends AppCompatActivity {
    private static final int BG = Color.rgb(249, 250, 252);
    private static final int TEXT = Color.rgb(25, 29, 38);
    private static final int PURPLE = Color.rgb(101, 31, 222);
    private static final int RED = Color.rgb(237, 28, 48);
    private static final int PINK = Color.rgb(218, 23, 112);
    private static final int MAX = 6;
    private static final long SLIDE_MS = 3500L;
    private final Handler handler = new Handler();
    private final ImageView[] banners = new ImageView[3];
    private int bannerIndex = 0;
    private final int[] left = {R.drawable.banner_top_left_1,R.drawable.banner_top_left_2,R.drawable.banner_top_left_3,R.drawable.banner_top_left_4,R.drawable.banner_top_left_5,R.drawable.banner_top_left_6};
    private final int[] right = {R.drawable.banner_top_right_1,R.drawable.banner_top_right_2,R.drawable.banner_top_right_3,R.drawable.banner_top_right_4,R.drawable.banner_top_right_5,R.drawable.banner_top_right_6};
    private final int[] wide = {R.drawable.banner_wide_1,R.drawable.banner_wide_2,R.drawable.banner_wide_3,R.drawable.banner_wide_4,R.drawable.banner_wide_5,R.drawable.banner_wide_6};

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        try { setContentView(buildDashboard()); startCarousel(); }
        catch (Throwable t) { setContentView(buildSafeHome()); }
    }

    private int dp(int v){ return Math.round(v * getResources().getDisplayMetrics().density); }
    private LinearLayout.LayoutParams lp(int w,int h){ return new LinearLayout.LayoutParams(w,h); }
    private LinearLayout.LayoutParams wt(float w,int h){ return new LinearLayout.LayoutParams(0,h,w); }

    private View buildDashboard() {
        LinearLayout root = column();
        root.setBackgroundColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout content = column();
        content.setPadding(dp(10),dp(6),dp(10),dp(7));

        // Approved mobile header: menu + MS icon/brand + search + notification + profile.
        LinearLayout header = row();
        header.setBackground(round(Color.WHITE,0xFFE1E3E9,dp(22)));
        Button menu = iconButton("☰", TEXT, 23);
        menu.setBackgroundColor(Color.TRANSPARENT);
        header.addView(menu, lp(dp(46),dp(52)));

        ImageView brandIcon = new ImageView(this);
        brandIcon.setImageResource(R.drawable.myshop_icon);
        brandIcon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        brandIcon.setContentDescription("MY SHOP");
        header.addView(brandIcon, lp(dp(42),dp(42)));

        TextView brand = text("MY SHOP",PURPLE,15,true);
        brand.setGravity(Gravity.CENTER_VERTICAL);
        header.addView(brand, lp(dp(88),dp(50)));

        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(12);
        search.setHint(LanguageManager.t(this,"search"));
        search.setPadding(dp(8),0,dp(6),0);
        search.setBackground(round(0xFFF8F9FC,0xFFE1E3E9,dp(18)));
        header.addView(search, wt(1,dp(42)));

        TextView bell = iconPill("♧", TEXT, 19);
        bell.setBackgroundColor(Color.TRANSPARENT);
        header.addView(bell, lp(dp(42),dp(50)));

        ImageView avatar = new ImageView(this);
        avatar.setImageResource(R.drawable.myshop_profile_avatar);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatar.setClipToOutline(true);
        avatar.setContentDescription("Profile");
        header.addView(avatar, lp(dp(44),dp(44)));

        menu.setOnClickListener(v -> startActivity(new Intent(this, AccountActivity.class)));
        bell.setOnClickListener(v -> openFeature("Notifications","notifications"));
        avatar.setOnClickListener(v -> startActivity(new Intent(this,AccountActivity.class)));
        content.addView(header,lp(-1,dp(58)));

        int screen = getResources().getDisplayMetrics().widthPixels;
        int sideH = Math.max(dp(92), Math.round((screen-dp(26))*0.245f));
        LinearLayout top = row();
        banners[0]=banner(left[0]); banners[1]=banner(right[0]);
        top.addView(banners[0],wt(1,sideH)); top.addView(space(dp(7),1)); top.addView(banners[1],wt(1,sideH));
        content.addView(top,lp(-1,sideH));
        TextView dots = text("●  ●  ●  ●  ●  ●",PURPLE,11,true); dots.setGravity(Gravity.CENTER); dots.setLetterSpacing(0.16f);
        content.addView(dots,lp(-1,dp(24)));

        int wideH = Math.max(dp(110), Math.round((screen-dp(20))*0.27f));
        banners[2]=banner(wide[0]);
        LinearLayout.LayoutParams wideP=lp(-1,wideH); wideP.bottomMargin=dp(7); content.addView(banners[2],wideP);

        // Three compact promo cards.
        LinearLayout promos=row();
        promos.addView(promo("SUMMER COLLECTION\nNEW ARRIVAL","🕶",0xFF145BEA,"summer"),wt(1,dp(104)));
        promos.addView(space(dp(6),1));
        promos.addView(promo("EXCLUSIVE DEAL\n25% OFF","👜",0xFF14933B,"deal"),wt(1,dp(104)));
        promos.addView(space(dp(6),1));
        promos.addView(promo("BEAUTY CARE\n20% OFF","💄",0xFFD21682,"beauty"),wt(1,dp(104)));
        content.addView(promos,lp(-1,dp(104)));

        String news=getSharedPreferences("myshop_admin",MODE_PRIVATE).getString("breaking_news","বাংলাদেশে আজ স্বর্ণের দাম আবার কমলো  ☀️");
        TextView breaking=card("●  BREAKING NEWS     |     "+news+"     ›",Color.WHITE,TEXT,17,true);
        breaking.setGravity(Gravity.CENTER_VERTICAL); breaking.setPadding(dp(9),0,dp(8),0);
        LinearLayout.LayoutParams bp=lp(-1,dp(52)); bp.topMargin=dp(7); content.addView(breaking,bp);
        breaking.setOnClickListener(v->openFeature("BREAKING NEWS","breaking_news"));

        LinearLayout lh=row(); lh.addView(text("🔴  "+LanguageManager.t(this,"liveNow"),TEXT,15,true),wt(1,dp(38)));
        TextView va=text(LanguageManager.t(this,"seeAll")+"  ›",PINK,13,true); va.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT); lh.addView(va,lp(dp(70),dp(38))); va.setOnClickListener(v->openFeature("LIVE NOW","live_now")); content.addView(lh,lp(-1,dp(38)));

        // Exactly four live cards, matching the approved mobile reference.
        LinearLayout lives=row();
        int[] liveImages={R.drawable.live_card_1,R.drawable.live_card_2,R.drawable.live_card_3,R.drawable.live_card_4};
        String[] names={"Cute Girl Live","Music Live","Gaming Live","Talk & Fun"};
        String[] handles={"@sweet_girl","@singer_boy","@pro_gamer","@funny_boy"};
        String[] views={"12.5K","8.2K","5.1K","2.7K"};
        for(int i=0;i<4;i++){
            ImageView c=liveCardImage(liveImages[i],names[i]);
            lives.addView(c,wt(1,dp(190))); if(i<3) lives.addView(space(dp(5),1));
        }
        content.addView(lives,lp(-1,dp(194)));

        // Live / Go Live / My Feed row.
        LinearLayout action=row();
        action.addView(featureTile("◉","LIVE","লাইভ দেখুন",PURPLE,"live_now"),wt(1,dp(88)));
        action.addView(goLiveTile(),wt(1,dp(100)));
        action.addView(featureTile("My","feed","আপনার ফিড দেখুন",PURPLE,"my_feed"),wt(1,dp(88)));
        content.addView(action,lp(-1,dp(100)));

        // Eight approved feature tiles, 4 x 2.
        content.addView(featureGrid(),lp(-1,dp(182)));

        scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        // Fixed bottom navigation.
        LinearLayout nav=row(); nav.setPadding(dp(3),dp(3),dp(3),dp(3)); nav.setBackground(round(Color.WHITE,0xFFE1E3EA,dp(26)));
        Button home=navButton("⌂\nHome",PURPLE), live=navButton("◉\nLive",TEXT), store=navButton("🛒\nStore",PURPLE), chat=navButton("◌\nChat",TEXT), more=navButton("⊙\nMore",TEXT);
        nav.addView(home,wt(1,dp(64))); nav.addView(live,wt(1,dp(64))); nav.addView(store,wt(1,dp(64))); nav.addView(chat,wt(1,dp(64))); nav.addView(more,wt(1,dp(64)));
        root.addView(nav,lp(-1,dp(72)));
        home.setOnClickListener(v->{}); live.setOnClickListener(v->openFeature("LIVE","live_now")); store.setOnClickListener(v->openFeature("MY SHOP","my_shop")); chat.setOnClickListener(v->openFeature("CHAT","chat")); more.setOnClickListener(v->startActivity(new Intent(this,AccountActivity.class)));
        return root;
    }

    private LinearLayout featureGrid(){
        LinearLayout grid=column();
        LinearLayout r1=row(), r2=row();
        addFeatureImage(r1,R.drawable.feature_my_shop_selected,LanguageManager.t(this,"shop"),"my_shop");
        addFeatureImage(r1,R.drawable.feature_gallery_selected,LanguageManager.t(this,"gallery"),"gallery");
        addFeatureImage(r1,R.drawable.feature_external_selected,LanguageManager.t(this,"movie"),"external_movie");
        addFeatureImage(r1,R.drawable.feature_live_tv_selected,LanguageManager.t(this,"tv"),"live_tv");
        addFeatureImage(r2,R.drawable.feature_social_selected,LanguageManager.t(this,"social"),"social_media");
        addFeatureImage(r2,R.drawable.feature_earn_selected,LanguageManager.t(this,"reward"),"earn_reward");
        addFeatureImage(r2,R.drawable.feature_share_selected,LanguageManager.t(this,"share"),"share");
        addFeatureImage(r2,R.drawable.feature_my_feed_selected,LanguageManager.t(this,"apps"),"more_apps");
        grid.addView(r1,lp(-1,dp(88))); grid.addView(r2,lp(-1,dp(88))); return grid;
    }

    private void addFeatureImage(LinearLayout row,int res,String title,String key){
        ImageView v=new ImageView(this); v.setImageResource(res); v.setScaleType(ImageView.ScaleType.CENTER_CROP); v.setBackground(round(Color.WHITE,0xFFE1E3EA,dp(13))); v.setClipToOutline(true); v.setContentDescription(title); v.setOnClickListener(x->openFeature(title,key));
        LinearLayout.LayoutParams p=wt(1,dp(82)); p.setMargins(dp(2),dp(2),dp(2),dp(2)); row.addView(v,p);
    }

    private TextView promo(String label,String icon,int color,String key){
        TextView v=text(label+"\n\n"+icon,color==0?Color.WHITE:Color.WHITE,12,true); v.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL); v.setPadding(dp(9),0,dp(5),0); v.setBackground(round(color, color,dp(14))); v.setOnClickListener(x->openFeature(label,key)); return v;
    }

    private ImageView liveCardImage(int res,String name){
        ImageView v=new ImageView(this);
        v.setImageResource(res);
        v.setScaleType(ImageView.ScaleType.CENTER_CROP);
        v.setBackground(round(Color.WHITE,0xFFE1E3EA,dp(15)));
        v.setClipToOutline(true);
        v.setContentDescription(name);
        v.setOnClickListener(x->openFeature(name,"live_room"));
        return v;
    }

    private TextView liveCard(String name,String handle,String views,int bg){
        TextView v=text("LIVE\n👁 "+views+"\n"+name+"\n"+handle,Color.WHITE,11,true); v.setGravity(Gravity.BOTTOM|Gravity.LEFT); v.setPadding(dp(7),dp(8),dp(4),dp(8)); v.setBackground(round(bg,0xFFE2E4EA,dp(15))); v.setOnClickListener(x->openFeature(name,"live_room")); return v;
    }

    private TextView featureTile(String big,String title,String sub,int color,String key){
        TextView v=text(big+"  "+title+"\n"+sub, color,13,true); v.setGravity(Gravity.CENTER); v.setBackground(round(Color.WHITE,0xFFE1E3EA,dp(14))); v.setOnClickListener(x->openFeature(title,key)); return v;
    }
    private TextView goLiveTile(){ TextView v=text("●\nGO LIVE\nনিজে লাইভ যান",RED,13,true); v.setGravity(Gravity.CENTER); v.setBackground(round(Color.WHITE,0xFFE1E3EA,dp(14))); v.setOnClickListener(x->openFeature("GO LIVE","go_live")); return v; }
    private ImageView banner(int res){ ImageView v=new ImageView(this); v.setImageResource(res); v.setScaleType(ImageView.ScaleType.CENTER_CROP); v.setBackground(round(Color.WHITE,0xFFE1E3EA,dp(14))); v.setClipToOutline(true); return v; }
    private Button navButton(String s,int c){ return plainButton(s,c,11); }
    private Button iconButton(String s,int c,float size){ return plainButton(s,c,size); }
    private TextView iconPill(String s,int c,float size){ TextView v=text(s,c,size,true); v.setGravity(Gravity.CENTER); v.setBackground(round(Color.WHITE,0xFFE1E3EA,dp(16))); return v; }
    private Button plainButton(String s,int c,float size){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setTextColor(c); b.setTextSize(size); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setBackground(round(Color.WHITE,0xFFE1E3EA,dp(14))); return b; }
    private TextView card(String s,int bg,int fg,float size,boolean bold){ TextView v=text(s,fg,size,bold); v.setBackground(round(bg,0xFFE1E3EA,dp(14))); return v; }
    private TextView text(String s,int c,float size,boolean bold){ TextView v=new TextView(this); v.setText(s); v.setTextColor(c); v.setTextSize(size); if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v; }
    private LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout column(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private View space(int w,int h){ View v=new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(w,h)); return v; }
    private GradientDrawable round(int fill,int stroke,int radius){ GradientDrawable g=new GradientDrawable(); g.setColor(fill); g.setCornerRadius(radius); g.setStroke(dp(1),stroke); return g; }
    private void startCarousel(){ handler.postDelayed(new Runnable(){ public void run(){ bannerIndex=(bannerIndex+1)%MAX; banners[0].setImageResource(left[bannerIndex]); banners[1].setImageResource(right[bannerIndex]); banners[2].setImageResource(wide[bannerIndex]); handler.postDelayed(this,SLIDE_MS); }},SLIDE_MS); }
    private void openFeature(String title,String key){ Intent i=new Intent(this,FeatureActivity.class); i.putExtra("title",title); i.putExtra("feature_key",key); startActivity(i); }
    private View buildSafeHome(){ LinearLayout r=column(); r.setGravity(Gravity.CENTER); r.setBackgroundColor(BG); TextView t=text("MY SHOP\nHome Dashboard",PURPLE,25,true); t.setGravity(Gravity.CENTER); r.addView(t,lp(-1,-2)); Button retry=plainButton("OPEN DASHBOARD",PURPLE,15); retry.setOnClickListener(v->recreate()); r.addView(retry,lp(-1,dp(64))); return r; }
    @Override protected void onDestroy(){ handler.removeCallbacksAndMessages(null); super.onDestroy(); }
}
