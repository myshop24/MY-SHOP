package com.myshop.app;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;

/**
 * MY SHOP V-67: hidden, role-gated management screen.
 * There is no separate Admin dashboard. Admins use the same Main Dashboard and
 * reach these controls only after the normal Login identifies their role.
 */
public class AdminManagementActivity extends androidx.appcompat.app.AppCompatActivity {
    private SharedPreferences p;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        if(!SessionManager.isAdmin(this)){
            Toast.makeText(this,"Admin access required.",Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        p=getSharedPreferences("myshop_admin",MODE_PRIVATE);
        buildUi();
    }

    private void buildUi(){
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18,20,18,18);
        root.setBackgroundColor(getColor(R.color.myshop_bg));

        TextView title=new TextView(this);
        title.setText("MY SHOP • ADMIN CONTROLS");
        title.setTextSize(21);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null,1);
        root.addView(title,new LinearLayout.LayoutParams(-1,64));

        TextView who=new TextView(this);
        who.setText("Role: ADMIN\nProfile ID: "+SessionManager.getUserId(this));
        who.setTextSize(14);
        root.addView(who,new LinearLayout.LayoutParams(-1,58));

        add(root,"Banner • Add / Edit / Delete • 6 per folder",v->showBannerManager());
        add(root,"Breaking News • Add / Edit / Delete • Unlimited",v->editText("Breaking News",p.getString("breaking_news","বাংলাদেশে আজ স্বর্ণের দাম আবার কমলো ☀️"),"breaking_news"));
        add(root,"Gallery / Media • Photo / Audio / Video",v->showEditable("gallery_media","Gallery / Media items",p.getString("gallery_media","")));
        add(root,"Social Links • Facebook / Page / Messenger / WhatsApp / imo / YouTube / Telegram",v->showSocial());
        add(root,"My Shop • Website / Buy & Sell Link",v->showUrl("my_shop","MY SHOP URL",p.getString("url_my_shop",p.getString("shop_url",""))));
        add(root,"TV • Add / Edit / Delete",v->showUrl("live_tv","LIVE TV URL",p.getString("url_live_tv","")));
        add(root,"External • 12 Link Folders",v->showExternal());
        add(root,"Moderator Management • Maximum 5",v->showModerators());
        add(root,"Emergency Password Reset • Main Admin",v->showAdminReset());

        Button back=new Button(this);
        back.setText("BACK TO SAME MAIN DASHBOARD");
        back.setOnClickListener(v->finish());
        root.addView(back,new LinearLayout.LayoutParams(-1,58));
        setContentView(root);
    }

    private void add(LinearLayout root,String s,android.view.View.OnClickListener l){
        Button b=new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        root.addView(b,new LinearLayout.LayoutParams(-1,58));
    }

    private void showBannerManager(){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(field("Top-left banner folder (max 6)",p.getString("banner_top_left_urls","")));
        box.addView(field("Top-right banner folder (max 6)",p.getString("banner_top_right_urls","")));
        box.addView(field("Wide banner folder (max 6)",p.getString("banner_wide_urls","")));
        new AlertDialog.Builder(this).setTitle("Banner Management • 6 each")
                .setMessage("Use one URL per line. The Dashboard rotates each folder automatically.")
                .setView(box).setNegativeButton("CANCEL",null)
                .setPositiveButton("SAVE",(d,w)->{
                    EditText a=(EditText)box.getChildAt(0), b=(EditText)box.getChildAt(1), c=(EditText)box.getChildAt(2);
                    p.edit().putString("banner_top_left_urls",limitLines(a.getText().toString(),6))
                            .putString("banner_top_right_urls",limitLines(b.getText().toString(),6))
                            .putString("banner_wide_urls",limitLines(c.getText().toString(),6)).apply();
                    Toast.makeText(this,"Banner settings saved.",Toast.LENGTH_SHORT).show();
                }).show();
    }

    private String limitLines(String value,int max){
        String[] lines=value.split("\\R");
        StringBuilder out=new StringBuilder();
        int count=0;
        for(String line:lines){
            if(line.trim().isEmpty()) continue;
            if(count++>=max) break;
            if(out.length()>0) out.append("\n");
            out.append(line.trim());
        }
        return out.toString();
    }

    private EditText field(String hint,String value){
        EditText e=new EditText(this);
        e.setHint(hint); e.setText(value); e.setSingleLine(false); e.setMinLines(2);
        return e;
    }

    private void editText(String title,String initial,String key){
        EditText e=field(title,initial);
        new AlertDialog.Builder(this).setTitle(title).setView(e).setNegativeButton("CANCEL",null)
                .setPositiveButton("SAVE",(d,w)->{
                    p.edit().putString(key,e.getText().toString().trim()).apply();
                    Toast.makeText(this,"Saved.",Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void showEditable(String key,String title,String initial){ editText(title,initial,key); }

    private void showUrl(String key,String title,String initial){
        EditText e=field(title,initial);
        new AlertDialog.Builder(this).setTitle(title).setView(e).setNegativeButton("CANCEL",null)
                .setPositiveButton("SAVE",(d,w)->{
                    String url=e.getText().toString().trim();
                    if(!url.isEmpty() && !FeatureRegistry.isSafeHttpUrl(url)){
                        Toast.makeText(this,"Use http:// or https:// link.",Toast.LENGTH_LONG).show();
                        return;
                    }
                    p.edit().putString("url_"+key,url).putString(key+"_url",url).apply();
                    getSharedPreferences("myshop_remote_config",MODE_PRIVATE).edit().putString("url_"+key,url).apply();
                    Toast.makeText(this,"Link saved.",Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void showSocial(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        String[] keys={"facebook","facebook_page","messenger","whatsapp","imo","youtube","telegram"};
        String[] labels={"Facebook","Facebook Page","Messenger","WhatsApp","imo","YouTube","Telegram"};
        EditText[] fields=new EditText[keys.length];
        for(int i=0;i<keys.length;i++){ fields[i]=field(labels[i],p.getString("social_"+keys[i],"")); box.addView(fields[i]); }
        new AlertDialog.Builder(this).setTitle("Social Links").setView(box).setNegativeButton("CANCEL",null)
                .setPositiveButton("SAVE",(d,w)->{
                    SharedPreferences.Editor e=p.edit();
                    SharedPreferences.Editor r=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).edit();
                    for(int i=0;i<keys.length;i++){
                        String url=fields[i].getText().toString().trim();
                        if(!url.isEmpty() && !FeatureRegistry.isSafeHttpUrl(url)) continue;
                        e.putString("social_"+keys[i],url);
                        r.putString("url_social_"+keys[i],url);
                    }
                    r.apply(); e.apply();
                    Toast.makeText(this,"Social links saved.",Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void showExternal(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        EditText[] fields=new EditText[12];
        for(int i=0;i<12;i++){ fields[i]=field("Folder "+(i+1)+" URL / caption",p.getString("external_"+(i+1),"")); box.addView(fields[i]); }
        new AlertDialog.Builder(this).setTitle("External • 12 Folders").setView(box).setNegativeButton("CANCEL",null)
                .setPositiveButton("SAVE",(d,w)->{
                    SharedPreferences.Editor e=p.edit();
                    for(int i=0;i<12;i++) e.putString("external_"+(i+1),fields[i].getText().toString().trim());
                    e.apply();
                    Toast.makeText(this,"12 external folders saved.",Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void showModerators(){
        EditText e=field("Moderator Profile IDs (one per line, maximum 5)",p.getString("moderator_ids",""));
        new AlertDialog.Builder(this).setTitle("Moderator Management")
                .setMessage("Moderators may handle live close, ID ban and kick-out only. They cannot edit content or Admin settings.")
                .setView(e).setNegativeButton("CANCEL",null)
                .setPositiveButton("SAVE",(d,w)->{
                    String limited=limitLines(e.getText().toString(),5);
                    p.edit().putString("moderator_ids",limited).apply();
                    Toast.makeText(this,"Moderator list saved (max 5).",Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void showAdminReset(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        EditText uid=field("User Profile ID (4 digits)","");
        EditText np=field("New password (6+ characters)","");
        np.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(uid); box.addView(np);
        new AlertDialog.Builder(this).setTitle("Main Admin Password Reset").setView(box).setNegativeButton("CANCEL",null)
                .setPositiveButton("RESET",(d,w)->{
                    boolean ok=AccountStore.adminResetPassword(this,uid.getText().toString().trim(),np.getText().toString());
                    Toast.makeText(this,ok?"Password reset successfully. Permanent Profile ID unchanged.":"Reset failed.",Toast.LENGTH_LONG).show();
                }).show();
    }
}
