# MY SHOP Developer Handoff — V-368

## Version
- Build: MY SHOP V-368
- Android: versionCode 368 / versionName 2.9.368
- Base: V-367-MY-SHOP-LIVE-GUEST-CONTROL-FIX

## Completed
1. Seated-user Gift routing fixed at seat level.
2. Seat moderation action menu consolidated with role-appropriate controls.
3. Guest self Leave Call/Leave Seat reachable from own occupied seat.
4. Speaking user indication moved to profile/avatar ring + mic badge and driven by Agora active-speaker events.
5. Host header/User Line alignment compacted.
6. Live Home multi-banner compatibility/recovery hardened.
7. Go Live / Join Live redesigned equal 50/50 with approved premium color direction.

## Pending / device acceptance
- Build in GitHub/Android toolchain.
- Two-device test: Host + seated guest + audience.
- Verify seat Gift actually credits the selected seated recipient.
- Verify Leave Call returns speaker to audience.
- Verify speaker ring/mic changes when each participant speaks.
- Verify Mute/Unmute/Kick/Block/Remove/Room Admin permissions on real accounts.
- Verify 2–6 Live Home banners continuously rotate and counter matches published banners.

## Phase
Targeted Live interaction + Live Home UX stabilization.

## Last checkpoint
Static/source validation complete in container; real Android runtime not available here.

## Next tasks
Use real-device video/log only for any remaining behavior issue; do not redesign unrelated working modules.

## Known issues / limitations
Full Android Gradle compile and real microphone/speaker/network behavior cannot be claimed PASS in this container.
