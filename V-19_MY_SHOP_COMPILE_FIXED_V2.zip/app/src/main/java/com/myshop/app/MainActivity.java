package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private final Handler handler = new Handler();
    private int bannerIndex = 0;
    private int bannerCount = 6;
    private long sliderIntervalMs = 3500L;

    private RemoteConfigSnapshot configSnapshot;
    private TextView bannerLabel;
    private TextView bannerDots;
    private EditText searchBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bindViews();
        loadConfig();
        applyLanguage();
        setupInteractions();
        startSlider();
    }

    private void bindViews() {
        bannerLabel = findViewById(R.id.bannerLabel);
        bannerDots = findViewById(R.id.bannerDots);
        searchBox = findViewById(R.id.searchBox);
    }

    private void applyLanguage() {
        if (searchBox != null) {
            searchBox.setHint(LanguageManager.t(this, "search"));
        }

        TextView breakingNews = findViewById(R.id.breakingNews);
        if (breakingNews != null) {
            breakingNews.setText(
                    "🔴 " + LanguageManager.t(this, "breaking")
                            + "  |  Welcome to MY SHOP"
            );
        }

        TextView liveNowTitle = findViewById(R.id.liveNowTitle);
        if (liveNowTitle != null) {
            liveNowTitle.setText(
                    "🔴 " + LanguageManager.t(this, "liveNow")
                            + "    " + LanguageManager.t(this, "seeAll") + " ›"
            );
        }

        setButtonText(R.id.liveButton, "🔴 " + LanguageManager.t(this, "live"));
        setButtonText(R.id.goLiveButton, "🎥 " + LanguageManager.t(this, "goLive"));
        setButtonText(R.id.feedButton, LanguageManager.t(this, "feed"));
        setButtonText(R.id.shopButton, "🛒 " + LanguageManager.t(this, "shop"));
        setButtonText(R.id.galleryButton, "🖼️ " + LanguageManager.t(this, "gallery"));
        setButtonText(R.id.movieButton, "🎬 " + LanguageManager.t(this, "movie"));
        setButtonText(R.id.tvButton, "📺 " + LanguageManager.t(this, "tv"));
        setButtonText(R.id.socialButton, "📱 " + LanguageManager.t(this, "social"));
        setButtonText(R.id.rewardButton, "🎁 " + LanguageManager.t(this, "reward"));
        setButtonText(R.id.shareButton, "🔗 " + LanguageManager.t(this, "share"));
        setButtonText(R.id.appsButton, "📱 " + LanguageManager.t(this, "apps"));
        setButtonText(R.id.homeNav, "⌂ " + LanguageManager.t(this, "home"));
        setButtonText(R.id.liveNav, "◉ " + LanguageManager.t(this, "live"));
        setButtonText(R.id.storeNav, "🛒 " + LanguageManager.t(this, "store"));
        setButtonText(R.id.chatNav, "💬 " + LanguageManager.t(this, "chat"));
        setButtonText(R.id.moreNav, "••• " + LanguageManager.t(this, "more"));
    }

    private void setButtonText(int id, String text) {
        Button button = findViewById(id);
        if (button != null) {
            button.setText(text);
        }
    }

    private void loadConfig() {
        String json = RemoteConfigManager.getCachedConfig(this);
        configSnapshot = RemoteConfigSnapshot.parse(json);

        if (configSnapshot == null) {
            bannerCount = 6;
            sliderIntervalMs = 3500L;
            return;
        }

        bannerCount = Math.max(
                1,
                Math.min(6, configSnapshot.maxBannersPerSection)
        );

        sliderIntervalMs = Math.max(
                1000L,
                configSnapshot.sliderIntervalMs
        );
    }

    private void setupInteractions() {
        findViewById(R.id.menuButton).setOnClickListener(v -> showMenu());
        findViewById(R.id.notificationButton).setOnClickListener(v -> showNotifications());
        findViewById(R.id.moreButton).setOnClickListener(v -> showMore());

        findViewById(R.id.homeNav).setOnClickListener(v -> recreate());

        findViewById(R.id.goLiveButton).setOnClickListener(
                v -> openFeature("GO LIVE", "go_live")
        );
        findViewById(R.id.liveButton).setOnClickListener(
                v -> openFeature("LIVE", "live_now")
        );
        findViewById(R.id.feedButton).setOnClickListener(
                v -> openFeature("MY FEED", "my_feed")
        );
        findViewById(R.id.shopButton).setOnClickListener(
                v -> openFeature("MY SHOP", "my_shop")
        );
        findViewById(R.id.galleryButton).setOnClickListener(
                v -> openFeature("GALLERY", "gallery")
        );
        findViewById(R.id.movieButton).setOnClickListener(
                v -> openFeature("EXTERNAL MOVIE", "external_movie")
        );
        findViewById(R.id.tvButton).setOnClickListener(
                v -> openFeature("LIVE TV", "live_tv")
        );
        findViewById(R.id.socialButton).setOnClickListener(
                v -> openFeature("SOCIAL MEDIA", "social_media")
        );
        findViewById(R.id.rewardButton).setOnClickListener(
                v -> openFeature("EARN & REWARD", "earn_reward")
        );
        findViewById(R.id.shareButton).setOnClickListener(v -> shareApp());
        findViewById(R.id.appsButton).setOnClickListener(
                v -> openFeature("MORE APPS", "more_apps")
        );

        findViewById(R.id.chatNav).setOnClickListener(
                v -> openFeature("CHAT", "chat")
        );
        findViewById(R.id.liveNav).setOnClickListener(
                v -> openFeature("LIVE", "live_now")
        );
        findViewById(R.id.storeNav).setOnClickListener(
                v -> openFeature("MY SHOP", "my_shop")
        );
        findViewById(R.id.moreNav).setOnClickListener(v -> showMore());

        if (searchBox != null) {
            searchBox.setSingleLine(true);
            searchBox.setImeOptions(EditorInfo.IME_ACTION_SEARCH);

            searchBox.setOnEditorActionListener((v, actionId, event) -> {
                boolean enterPressed = event != null
                        && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                        && event.getAction() == KeyEvent.ACTION_DOWN;

                if (actionId == EditorInfo.IME_ACTION_SEARCH || enterPressed) {
                    String query = searchBox.getText().toString().trim();

                    if (!query.isEmpty()) {
                        Toast.makeText(
                                MainActivity.this,
                                "Search ready: " + query,
                                Toast.LENGTH_SHORT
                        ).show();
                    }

                    return true;
                }

                return false;
            });
        }
    }

    private void showMenu() {
        String[] items = {
                "👤 Account & Settings",
                LanguageManager.t(this, "login"),
                LanguageManager.t(this, "register"),
                LanguageManager.t(this, "language")
        };

        new AlertDialog.Builder(this)
                .setTitle(LanguageManager.t(this, "menu"))
                .setItems(items, (dialog, which) -> {
                    if (which == 0) {
                        startActivity(new Intent(this, AccountActivity.class));
                    } else if (which == 1) {
                        startActivity(new Intent(this, LoginActivity.class));
                    } else if (which == 2) {
                        startActivity(new Intent(this, RegisterActivity.class));
                    } else {
                        showLanguagePicker();
                    }
                })
                .show();
    }

    private void showLanguagePicker() {
        String[] labels = {"বাংলা", "English", "हिन्दी", "العربية"};
        String[] codes = {
                LanguageManager.BN,
                LanguageManager.EN,
                LanguageManager.HI,
                LanguageManager.AR
        };

        int checked = 0;
        String current = LanguageManager.get(this);

        for (int i = 0; i < codes.length; i++) {
            if (codes[i].equals(current)) {
                checked = i;
                break;
            }
        }

        final int[] selected = {checked};

        new AlertDialog.Builder(this)
                .setTitle(LanguageManager.t(this, "language"))
                .setSingleChoiceItems(
                        labels,
                        checked,
                        (dialog, which) -> selected[0] = which
                )
                .setPositiveButton(
                        "OK",
                        (dialog, which) -> {
                            LanguageManager.set(this, codes[selected[0]]);
                            recreate();
                        }
                )
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showNotifications() {
        new AlertDialog.Builder(this)
                .setTitle(LanguageManager.t(this, "notifications"))
                .setMessage(
                        "3 new notifications\n"
                                + "• Welcome to MY SHOP\n"
                                + "• Your dashboard is ready\n"
                                + "• More live features are coming"
                )
                .setPositiveButton("OK", null)
                .show();
    }

    private void showMore() {
        if (SessionManager.isAdmin(this)) {
            showAdminControls();
            return;
        }

        if (SessionManager.isModerator(this)) {
            showModeratorControls();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle(LanguageManager.t(this, "more"))
                .setItems(
                        new String[]{
                                LanguageManager.t(this, "language"),
                                LanguageManager.t(this, "login"),
                                LanguageManager.t(this, "register")
                        },
                        (dialog, which) -> {
                            if (which == 0) {
                                showLanguagePicker();
                            } else if (which == 1) {
                                startActivity(new Intent(this, LoginActivity.class));
                            } else {
                                startActivity(new Intent(this, RegisterActivity.class));
                            }
                        }
                )
                .show();
    }

    private void showAdminControls() {
        startActivity(new Intent(this, AdminManagementActivity.class));
    }

    private void showModeratorControls() {
        startActivity(
                new Intent(this, AdminManagementActivity.class)
                        .putExtra("moderator_only", true)
        );
    }

    private void openFeature(String title, String key) {
        Intent intent = new Intent(this, FeatureActivity.class)
                .putExtra("title", title);

        String configuredUrl = FeatureRegistry.getUrl(this, key);

        if (configuredUrl != null && !configuredUrl.trim().isEmpty()) {
            intent.putExtra("url", configuredUrl);
        }

        startActivity(intent);
    }

    private void shareApp() {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(
                Intent.EXTRA_TEXT,
                "MY SHOP — Shop Smart, Live Better"
        );

        startActivity(
                Intent.createChooser(send, "Share MY SHOP")
        );
    }

    private void startSlider() {
        Runnable slider = new Runnable() {
            @Override
            public void run() {
                if (bannerCount < 1) {
                    bannerCount = 1;
                }

                bannerIndex = (bannerIndex + 1) % bannerCount;
                renderBanner();
                handler.postDelayed(this, sliderIntervalMs);
            }
        };

        handler.postDelayed(slider, sliderIntervalMs);
        renderBanner();
    }

    private void renderBanner() {
        if (bannerLabel != null) {
            bannerLabel.setText(
                    "MY SHOP\nBanner "
                            + (bannerIndex + 1)
                            + " / "
                            + bannerCount
            );
        }

        if (bannerDots != null) {
            StringBuilder dots = new StringBuilder();

            for (int i = 0; i < bannerCount; i++) {
                dots.append(i == bannerIndex ? "●" : "○");

                if (i < bannerCount - 1) {
                    dots.append("  ");
                }
            }

            bannerDots.setText(dots.toString());
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
