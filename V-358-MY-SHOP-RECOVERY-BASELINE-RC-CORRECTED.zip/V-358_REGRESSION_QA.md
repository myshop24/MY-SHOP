# V-358 Regression QA

- [PASS] Source restored from supplied V-355 baseline.
- [PASS] No functional app-source differences intentionally introduced.
- [PASS] versionCode/versionName updated to 358 / 2.9.358.
- [PASS] SOURCE_BUILD_ID / SOURCE_VERSION_NAME aligned.
- [PASS] Existing backend/schema/assets retained from V-355.
- [NEEDS DEVICE] Install/launch/runtime crash verification.
- [NEEDS LOGCAT IF CRASHES] Capture Android FATAL EXCEPTION stack trace for root-cause repair.
- [NEEDS BUILD ENVIRONMENT] Supplied source archive does not contain a Gradle launcher (`gradlew`), so an APK cannot be compiled in this environment from this package as-is.
