# MY SHOP V-358 — Recovery Baseline

- Recovery source is based on V-355, the supplied pre-V-356 baseline.
- V-356 introduced no functional source changes versus V-355; only release/version metadata differed.
- V-358 intentionally avoids adding new functional changes while restoring the V-355 source baseline under a new version identity.
- Android versionCode: 358
- Android versionName: 2.9.358
- No backend schema, D1/R2 binding, Live Gift, Coin/Gold Coin, Live Room, seat, dashboard, or admin behavior was intentionally changed.

## Important validation status
A real-device crash cannot be proven fixed from source comparison alone because the supplied project has no `gradlew` launcher and no crash stack trace/logcat was supplied. This is therefore a regression-safe recovery baseline, not a claim that an unknown runtime crash root cause has been repaired.
