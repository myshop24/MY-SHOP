# MY SHOP Developer Handoff — V-301

## Current version
V-301 (versionCode 301 / versionName 2.9.301)

## Completed in V-301
- Bottom Navigation full-width edge fit plus smooth hide-on-scroll / show-on-return behavior.
- Personal Timeline cards upgraded toward Facebook-style social presentation, using the same real post records as MY FEED.
- React count changed to latest-24-hour activity count and kept inside the React control.
- Feed comment Worker path hardened against schema/write failures.
- Live room state refresh accelerated; audience now detects host-ended room instead of indefinite reconnect state.
- Dashboard and Live List refresh active live rooms faster.
- Gift / Join Request floating buttons made explicitly touchable and above overlays.
- Existing Host Accept/Decline and Host Invite -> User Accept/Decline pathways preserved and allowed to surface faster through room polling.
- Live-end summary UI made compact.
- Production D1 theme migration ordering corrected for old `myshop_live_themes` tables missing `coin_price`.
- Live Wallpaper Admin now states 1080x1920 px / 9:16 recommendation and has clearer text layout.
- Main Admin Hub folder cards have improved spacing/readability.

## Preserved / do not regress
- Cloudflare D1 + R2 bindings/schema names and storage integration.
- Permanent user identity records.
- Existing Dashboard structure and approved color identity.
- Admin-only controls and permissions.
- 12-seat Audio Live architecture (Host + 11 speakers).
- Existing live request/invite API contracts.
- MY FEED source and Profile post source remain shared real backend post data.
- Android applicationId and release signing configuration.

## Validation state
- Worker JavaScript syntax check passed.
- Changed Java sources passed delimiter and syntax-pattern checks.
- Local APK compile unavailable because this archive has no Gradle wrapper executable/JAR and the execution environment has no Gradle installation.

## Next checkpoint
Run the existing GitHub Actions Android build/deploy pipeline, then device-test: bottom nav scroll, Timeline posts, Feed react/comment, two-device Live request/invite, Gift panel, live end propagation, and old-D1 Live Theme Admin opening.
