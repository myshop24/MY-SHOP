# MY SHOP V-301 Release Notes

## Scope implemented from this round

1. Bottom Navigation full-width alignment and scroll behavior
   - Removed unnecessary left/right outer margin from the bottom navigation shell.
   - Added smooth hide-on-down-scroll and restore-on-up-scroll behavior.
   - Preserved Android system bottom inset handling and existing nav actions.

2. Facebook-style personal Timeline improvement
   - Timeline post cards now show profile identity/header, date, readable caption/media, social counts and action row.
   - React is actionable inside Timeline and updates the React button/count.
   - Timeline comment composer posts through the real Feed comment API.
   - Existing MY FEED / profile media viewer data source is preserved (no duplicate post table).

3. Feed React / Comment / Live critical fixes
   - React activity count is calculated for the latest 24 hours and displayed inside the React control.
   - Feed comment endpoint now initializes required schema safely and returns a controlled error instead of an unhandled Worker failure.
   - Audio Live room sync interval reduced to 2 seconds for request/invite/seat/viewer state.
   - Host-ended live is detected by audience clients; the room exits instead of staying in a reconnect loop.
   - Dashboard active-live row and Live List refresh faster so ended rooms disappear promptly.
   - Gift and Join Request floating controls are explicitly clickable/focusable and raised above overlays.
   - Existing two-way request flow is preserved: Audience -> Host request -> Accept/Decline -> seat; Host -> Audience invite -> Accept/Decline -> seat.
   - Live-end summary is compact instead of a long vertical list.

4. Admin Panel / Audio Live Theme fixes
   - Fixed old-production D1 live theme migration ordering: `coin_price` is added before queries/inserts reference it.
   - Added visible wallpaper guide: recommended 1080x1920 px, 9:16, JPG/PNG.
   - Improved Live Theme Admin text spacing/readability.
   - Improved main Admin Hub folder card spacing, line-height and readable description area.

## Regression-safety rule
Targeted changes were made on existing flows. D1/R2 bindings, existing identifiers, core user records, signing config, package/application ID, and existing Admin/Feed/Live navigation were not renamed or removed.

## Build note
The uploaded source package does not contain a `gradlew` executable or `gradle-wrapper.jar`, and system Gradle is not installed in this environment. Therefore an Android APK compile could not be executed locally. Java delimiter/syntax-oriented checks and Worker `node --check` were performed; final Android compile should run through the repository's configured GitHub Actions/Gradle environment.
