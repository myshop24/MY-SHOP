package com.myshop.app;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.view.View;
import android.widget.ImageView;

/** Large fixed rail bounds/click target. No media decoder, audio, network or wallet work. */
final class AnimatedGiftButton667 extends ImageView {
 private final Box box;
 AnimatedGiftButton667(Context c){super(c);box=new Box();setImageDrawable(box);}
 private void sync(){if(box!=null)box.active(isAttachedToWindow()&&isShown()&&getWindowVisibility()==VISIBLE);}
 @Override protected void onAttachedToWindow(){super.onAttachedToWindow();sync();}
 @Override protected void onDetachedFromWindow(){box.active(false);super.onDetachedFromWindow();}
 @Override protected void onWindowVisibilityChanged(int visibility){super.onWindowVisibilityChanged(visibility);sync();}
 @Override protected void onVisibilityChanged(View changed,int visibility){super.onVisibilityChanged(changed,visibility);sync();}
 static final class Box extends Drawable implements Runnable {
  private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private final Path sparkle=new Path();
  private final Shader purple=new LinearGradient(7,14,32,38,new int[]{0xffffb3ef,0xffd82cdb,0xff6134bd},null,Shader.TileMode.CLAMP);
  private final Shader gold=new LinearGradient(14,0,24,38,new int[]{0xfffff6c2,0xffffce52,0xffd78c22},null,Shader.TileMode.CLAMP);
  private boolean running;private long began;private int alpha=255;private ColorFilter filter;
  void active(boolean enabled){if(running==enabled)return;running=enabled;unscheduleSelf(this);if(enabled){began=SystemClock.uptimeMillis();invalidateSelf();scheduleSelf(this,SystemClock.uptimeMillis()+50);}}
  public void run(){if(!running)return;invalidateSelf();scheduleSelf(this,SystemClock.uptimeMillis()+50);}
  static float open(long elapsed){float t=(elapsed%3600);if(t>=1600)return 0;return Math.max(0,Math.min(1,Math.min(t/300f,(1600-t)/300f)));}
  public void draw(Canvas c){Rect b=getBounds();float size=Math.min(b.width(),b.height());if(size<=0)return;int save=c.save();c.translate(b.exactCenterX()-size/2,b.exactCenterY()-size/2);c.scale(size/40,size/40);c.clipRect(0,0,40,40);
   long elapsed=running?SystemClock.uptimeMillis()-began:0;float lift=open(elapsed);p.setStyle(Paint.Style.FILL);p.setColorFilter(filter);p.setColor(Color.WHITE);p.setAlpha(alpha);
   // Rear cavity and rising items stay inside the original icon's viewport.
   p.setShader(null);p.setColor(0xff69258b);p.setAlpha(alpha);c.drawRoundRect(7,21,33,28,3,3,p);
   p.setAlpha(alpha);p.setColor(Color.WHITE);p.setShader(purple);c.drawRoundRect(7,24,33,37,3,3,p);p.setShader(gold);c.drawRect(17,24,23,37,p);
   int lid=c.save();c.translate(0,-lift*6);c.rotate(-lift*6,9,18);p.setShader(purple);c.drawRoundRect(4,17,36,24,2,2,p);p.setShader(gold);c.drawRect(17,17,23,24,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.7f);c.drawOval(8,9,20,18,p);c.drawOval(20,9,32,18,p);p.setStyle(Paint.Style.FILL);c.restoreToCount(lid);
   // Three flowers rise by less than a third of the box, settle on its front, then fade.
   float time=elapsed%3600;for(int i=0;i<3;i++){float phase=(time-340-i*90)/1050f;if(phase<=0||phase>=1)continue;float rise=phase<.4f?phase/.4f:1-(phase-.4f)/.6f;float x=12+i*8+(float)Math.sin(phase*3.14+i)*2,y=24-8*rise+(phase>.4f?(phase-.4f)*12:0);int opacity=Math.round(alpha*Math.min(1,Math.min(phase*8,(1-phase)*5)));flower(c,x,y,2.5f,i==1?0xffa6ecff:0xffff9dcf,opacity);}
   p.setShader(null);p.setColor(0xfffff5ce);p.setAlpha(alpha);star(c,35,5,3);c.restoreToCount(save);
  }
  private void flower(Canvas c,float x,float y,float r,int color,int opacity){p.setShader(null);p.setColor(color);p.setAlpha(opacity);for(int k=0;k<5;k++){double angle=k*Math.PI*2/5;c.drawCircle(x+(float)Math.cos(angle)*r*.65f,y+(float)Math.sin(angle)*r*.65f,r*.58f,p);}p.setColor(0xffffdf70);p.setAlpha(opacity);c.drawCircle(x,y,r*.38f,p);}
  private void star(Canvas c,float x,float y,float radius){sparkle.reset();sparkle.moveTo(x,y-radius);sparkle.lineTo(x+radius*.28f,y-radius*.28f);sparkle.lineTo(x+radius,y);sparkle.lineTo(x+radius*.28f,y+radius*.28f);sparkle.lineTo(x,y+radius);sparkle.lineTo(x-radius*.28f,y+radius*.28f);sparkle.lineTo(x-radius,y);sparkle.lineTo(x-radius*.28f,y-radius*.28f);sparkle.close();c.drawPath(sparkle,p);}
  public void setAlpha(int value){alpha=value;invalidateSelf();}public void setColorFilter(ColorFilter value){filter=value;invalidateSelf();}public int getOpacity(){return PixelFormat.TRANSLUCENT;}
  public int getIntrinsicWidth(){return 40;}public int getIntrinsicHeight(){return 40;}
 }
}
