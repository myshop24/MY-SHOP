package com.myshop.app;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
/** The identical animation and sound renderer is used by catalog Demo and Live entry. */
public final class RideEffectView extends FrameLayout {
 private final JSONObject item;private final boolean autoplay;private final boolean liveEntry671;private final View art;
 private final ManagedSoundPlayer sound=new ManagedSoundPlayer();private ObjectAnimator movement;private boolean attached,playing,liveConsumed671;
 private Runnable completion665;public void setCompletion665(Runnable callback){completion665=callback;}
 private VideoView video;private android.media.MediaPlayer preparedPlayer;private boolean prepared,firstFrame667,rendered667;private String videoUrl667="";private ArticulatedRideView mechanical;private RoadsterView671 roadster671;
 public RideEffectView(Context c,JSONObject data,boolean autoplay){this(c,data,autoplay,false);}
 public RideEffectView(Context c,JSONObject data,boolean autoplay,boolean liveEntry){super(c);item=data;this.autoplay=autoplay;liveEntry671=liveEntry;setClipChildren(true);
  String url=item.optString("animation_url","");if(url.isEmpty())url=item.optString("preview_url","");
  if(RideAssets.slot(item)>=0&&!RideAssets.video(item)){String code671=item.optString("item_code",item.optString("code"));FrameLayout group=new FrameLayout(c);if(RideAssets.slot(item)==10&&code671.matches("R665_CAR_(RED|BLUE|BLACK|WHITE|GOLD)")){roadster671=new RoadsterView671(c,code671);roadster671.onReady(this::videoReady667,()->{if(attached&&playing)complete.run();});group.addView(roadster671,new LayoutParams(-1,-1));}else{mechanical=new ArticulatedRideView(c,RideAssets.slot(item));mechanical.setColor665(code671);group.addView(mechanical,new LayoutParams(-1,-1));}LinearLayout tag=new LinearLayout(c);tag.setGravity(Gravity.CENTER);ImageView portrait=new ImageView(c);portrait.setImageResource(R.drawable.myshop_profile_avatar);String avatar=item.optString("avatar_url",liveEntry671?"":SessionManager.getAvatarUrl(c));if(!avatar.isEmpty())AnimatedAssetLoader.load(portrait,avatar,false);tag.addView(portrait,new LinearLayout.LayoutParams(dp(28),dp(28)));TextView name=new TextView(c);name.setText(item.optString("full_name",liveEntry671?item.optString("user_id","User"):SessionManager.getFullName(c))+" "+UiStrings.label(c,UiStrings.ui636("has joined")));name.setTextColor(Color.WHITE);name.setTextSize(11);name.setSingleLine(true);tag.addView(name);group.addView(tag,new LayoutParams(-2,dp(30),Gravity.TOP|Gravity.CENTER_HORIZONTAL));art=group;}
  else if(!url.isEmpty()&&RideAssets.video(item)){video=new VideoView(c);videoUrl667=url;
   video.setOnPreparedListener(mp->{if(!attached){return;}prepared=true;preparedPlayer=mp;mp.setLooping(false);float level=playing&&RideAssets.sound(c,item).isEmpty()?volume667()/100f:0;mp.setVolume(level,level);if(playing)video.start();});
   video.setOnInfoListener((mp,what,extra)->{if(what==android.media.MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START&&attached&&playing&&!firstFrame667){rendered667=true;videoReady667();}return false;});
   video.setOnCompletionListener(mp->{if(attached&&playing)complete.run();});video.setOnErrorListener((mp,what,extra)->{if(attached&&playing)complete.run();return true;});art=video;}
  else if(!url.isEmpty()||RideAssets.art(item)!=0){ImageView image=new ImageView(c);image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);if(!url.isEmpty())AnimatedAssetLoader.load(image,url,true);else image.setImageResource(RideAssets.art(item));art=image;}
  else{TextView symbol=new TextView(c);symbol.setText(RideAssets.symbol(item));symbol.setTextSize(82);symbol.setGravity(Gravity.CENTER);symbol.setTextColor(Color.WHITE);art=symbol;}
  addView(art,new LayoutParams(-1,-1));setContentDescription(item.optString("title","Ride entry"));
 }
 public void replay(){if(liveEntry671&&liveConsumed671)return;stop();if(!attached)return;playing=true;firstFrame667=false;if(mechanical!=null)mechanical.setMoving(true);if(video!=null){video.seekTo(0);if(preparedPlayer!=null){float level=RideAssets.sound(getContext(),item).isEmpty()?volume667()/100f:0;preparedPlayer.setVolume(level,level);}video.start();if(rendered667)videoReady667();}else if(roadster671!=null)roadster671.play(effectDuration665(),item.optInt("animation_speed",55));else playSound();
  int ms=Math.max(800,Math.min(15000,item.optInt("effect_duration_ms",3500)));float distance=Math.max(getWidth(),dp(180));
  float travel=.40f-Math.max(1,Math.min(100,item.optInt("animation_speed",55)))*.003f;if(roadster671!=null){art.setTranslationX(distance);movement=ObjectAnimator.ofFloat(art,"translationX",distance,-distance);}else if(video==null)movement=ObjectAnimator.ofPropertyValuesHolder(art,android.animation.PropertyValuesHolder.ofKeyframe("translationX",android.animation.Keyframe.ofFloat(0,distance),android.animation.Keyframe.ofFloat(travel,0),android.animation.Keyframe.ofFloat(1-travel,0),android.animation.Keyframe.ofFloat(1,-distance)));if(movement!=null){movement.setDuration(ms);if(roadster671!=null){final float exponent671=.55f+Math.max(1,Math.min(100,item.optInt("animation_speed",55)))*.009f;movement.setInterpolator(input->1f-(float)Math.pow(1f-input,exponent671));}else movement.setInterpolator(new android.view.animation.LinearInterpolator());if(roadster671==null)movement.start();}
  if(video==null&&roadster671==null)postDelayed(complete,ms);else if(!firstFrame667)postDelayed(complete,15000);
 }
 private void videoReady667(){if(!attached||!playing||firstFrame667)return;firstFrame667=true;if(roadster671!=null&&movement!=null)movement.start();playSound();removeCallbacks(complete);postDelayed(complete,effectDuration665());}
 private int effectDuration665(){return Math.max(800,Math.min(15000,item.optInt("effect_duration_ms",3500)));}
 private final Runnable complete=this::complete671;
 private void complete671(){removeCallbacks(complete667());if(!playing)return;playing=false;if(liveEntry671)liveConsumed671=true;if(movement!=null){movement.cancel();movement=null;}if(mechanical!=null)mechanical.setMoving(false);if(roadster671!=null)roadster671.stop();sound.stop();if(video!=null)try{video.pause();}catch(Exception ignored){}if(completion665!=null)completion665.run();}
 private Runnable complete667(){return complete;}
 private int volume667(){return item.optInt("sound_enabled",1)==0?0:Math.max(0,Math.min(100,item.optInt("sound_volume",90)));}
 private void playSound(){if(!attached||!playing||volume667()==0)return;String url=RideAssets.sound(getContext(),item);if(!url.isEmpty())sound.play(getContext(),url,volume667(),item.optInt("sound_duration_ms",3000),message->android.util.Log.w("MYSHOP_RIDE",message));}
 public void stop(){removeCallbacks(start667);removeCallbacks(complete);playing=false;if(mechanical!=null)mechanical.setMoving(false);if(roadster671!=null)roadster671.stop();sound.stop();if(movement!=null){movement.cancel();movement=null;}art.setTranslationX(0);if(video!=null)try{video.pause();}catch(Exception ignored){}}
 private final Runnable start667=this::startPlayback667;
 private void startPlayback667(){if(attached&&autoplay&&(!liveEntry671||!liveConsumed671))replay();}
 @Override protected void onAttachedToWindow(){super.onAttachedToWindow();attached=true;if(video!=null&&!prepared)video.setVideoURI(android.net.Uri.parse(videoUrl667));if(autoplay)post(start667);else if(mechanical!=null)mechanical.setMoving(true);}
 @Override protected void onDetachedFromWindow(){attached=false;if(liveEntry671)liveConsumed671=true;stop();if(video!=null){video.stopPlayback();prepared=false;rendered667=false;preparedPlayer=null;}super.onDetachedFromWindow();}
 @Override public void onWindowFocusChanged(boolean focus){super.onWindowFocusChanged(focus);if(!focus){if(liveEntry671){removeCallbacks(start667);if(playing)complete.run();else if(!liveConsumed671){liveConsumed671=true;stop();if(completion665!=null)completion665.run();}}else stop();}else if(attached&&!liveEntry671){if(autoplay){removeCallbacks(start667);post(start667);}else if(mechanical!=null)mechanical.setMoving(true);}}
 private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
}
