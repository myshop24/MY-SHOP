package com.myshop.app;
import android.content.Context;import android.graphics.*;import android.os.SystemClock;import android.view.View;
/** Local vector light trails: bounded 30fps, no decoder/network, pauses when hidden. */
final class GuardianHalo671 extends View {
 private final Paint p=new Paint(3);private final RectF oval=new RectF();private boolean attached;
 GuardianHalo671(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
 @Override protected void onAttachedToWindow(){super.onAttachedToWindow();attached=true;invalidate();}
 @Override protected void onDetachedFromWindow(){attached=false;super.onDetachedFromWindow();}
 @Override protected void onWindowVisibilityChanged(int v){super.onWindowVisibilityChanged(v);if(v==VISIBLE)invalidate();}
 @Override protected void onVisibilityChanged(View v,int visibility){super.onVisibilityChanged(v,visibility);if(visibility==VISIBLE)invalidate();}
 @Override protected void onDraw(Canvas c){super.onDraw(c);float side=Math.min(getWidth(),getHeight()),cx=getWidth()/2f,cy=getHeight()/2f,r=side*.36f,t=(SystemClock.uptimeMillis()%12000)/12000f;
 p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(side*.012f);p.setColor(0xff89eaff);p.setShadowLayer(side*.035f,0,0,0xff36d8ff);c.drawCircle(cx,cy,r,p);p.clearShadowLayer();
 p.setStrokeWidth(side*.006f);p.setColor(0xffecc47a);c.drawCircle(cx,cy,r*1.19f,p);
 int save=c.save();c.rotate(t*360,cx,cy);p.setShader(new SweepGradient(cx,cy,new int[]{0x001360ff,0xff498aff,0xffecdcff,0xffc466ff,0x001360ff},null));p.setStrokeWidth(side*.021f);oval.set(cx-r*1.10f,cy-r*1.10f,cx+r*1.10f,cy+r*1.10f);c.drawArc(oval,0,270,false,p);p.setShader(null);c.restoreToCount(save);
 p.setStyle(Paint.Style.FILL);for(int i=0;i<14;i++){double angle=(t*(i%2==0?1:-1)+i/14f)*Math.PI*2;float rr=r*(1.08f+.16f*(float)Math.sin(angle*3+i));p.setColor(i%3==0?0xffffdc86:0xffa8efff);p.setAlpha(110+(int)(120*(.5+.5*Math.sin(angle*2))));float x=cx+(float)Math.cos(angle)*rr,y=cy+(float)Math.sin(angle)*rr,s=side*(i%3==0?.014f:.007f);c.drawCircle(x,y,s,p);}
 p.setAlpha(255);if(attached&&isShown()&&getWindowVisibility()==VISIBLE)postInvalidateDelayed(33);
 }
}
