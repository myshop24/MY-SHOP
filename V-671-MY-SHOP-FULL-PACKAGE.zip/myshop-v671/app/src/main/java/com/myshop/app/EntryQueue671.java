package com.myshop.app;
import java.util.*;import org.json.*;
/** Accept in ascending event order; never advance beyond an event that did not fit. */
final class EntryQueue671 {
 static long offer(JSONArray events,ArrayDeque<JSONObject> queue,long cursor){
  if(events==null)return cursor;TreeMap<Long,JSONObject> sorted=new TreeMap<>();
  for(int i=0;i<events.length();i++){JSONObject event=events.optJSONObject(i);if(event!=null){long id=event.optLong("id");if(id>cursor)sorted.put(id,event);}}
  for(Map.Entry<Long,JSONObject> e:sorted.entrySet()){if(queue.size()>=32)break;queue.addLast(e.getValue());cursor=e.getKey();}return cursor;
 }
 private EntryQueue671(){}
}
