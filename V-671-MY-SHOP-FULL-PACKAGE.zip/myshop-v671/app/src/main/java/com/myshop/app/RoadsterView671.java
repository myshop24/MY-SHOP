package com.myshop.app;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.opengl.GLES20;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.SystemClock;
import android.view.TextureView;
import java.io.IOException;
import java.nio.FloatBuffer;
import javax.microedition.khronos.egl.*;

/** Original parametric 3D candidate. TextureView preserves normal view stacking over RTC.
 * One bounded render thread per visible scene, no network and no second video decoder.
 * New colour drafts only; existing catalog IDs, purchases and custom videos are untouched.
 */
final class RoadsterView671 extends TextureView implements TextureView.SurfaceTextureListener {
    private static final int FRAME_MS=42; // <=24fps; no unlimited draw loop in Live.
    private Renderer renderer;
    private volatile boolean requested;
    private volatile int duration=3500, speed=55, run;
    private final float[] colour;
    private Runnable firstFrame, failure;
    RoadsterView671(Context context,String code){
        super(context);setOpaque(false);setSurfaceTextureListener(this);
        colour=code.endsWith("_RED")?new float[]{.65f,.035f,.075f}:code.endsWith("_BLUE")?new float[]{.025f,.19f,.68f}:code.endsWith("_BLACK")?new float[]{.027f,.035f,.052f}:code.endsWith("_WHITE")?new float[]{.72f,.79f,.88f}:new float[]{.88f,.44f,.035f};
        setContentDescription("Original three-dimensional roadster entrance");
    }
    void onReady(Runnable ready,Runnable error){firstFrame=ready;failure=error;}
    void play(int milliseconds,int animationSpeed){speed=Math.max(1,Math.min(100,animationSpeed));duration=Math.max(800,Math.min(15000,milliseconds));requested=true;run++;Renderer r=renderer;if(r!=null)r.wake();}
    void stop(){requested=false;Renderer r=renderer;if(r!=null)r.pause();}
    @Override public void onSurfaceTextureAvailable(SurfaceTexture surface,int width,int height){
        renderer=new Renderer(surface,width,height);renderer.begin();
    }
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture surface,int width,int height){Renderer r=renderer;if(r!=null){r.width=width;r.height=height;r.wake();}}
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture surface){
        Renderer r=renderer;renderer=null;if(r!=null)r.close();else surface.release();return false; // EGL owner releases after destroying its window.
    }
    @Override public void onSurfaceTextureUpdated(SurfaceTexture surface){}
    @Override protected void onDetachedFromWindow(){stop();super.onDetachedFromWindow();}

    private final class Renderer {
        final SurfaceTexture surface;final HandlerThread thread=new HandlerThread("MYSHOP-Roadster671");Handler handler;
        volatile int width,height;volatile boolean closed;EGL10 egl;EGLDisplay display;EGLContext context;EGLSurface window;
        int program,position,normal,camera,stretch,spin,pivot,axis,base,kind;FloatBuffer vertices;RoadsterMesh671.Part[] batches;int lastRun=-1;long epoch;boolean initialized;
        Renderer(SurfaceTexture surface,int width,int height){this.surface=surface;this.width=width;this.height=height;}
        void begin(){thread.start();handler=new Handler(thread.getLooper());handler.post(()->{try{initialize();initialized=true;draw.run();}catch(Exception|OutOfMemoryError error){failed();}});}
        void wake(){Handler h=handler;if(h!=null&&!closed)h.post(()->{h.removeCallbacks(draw);h.removeCallbacks(drawAgain);if(initialized)draw.run();});}
        void pause(){Handler h=handler;if(h!=null)h.post(()->{h.removeCallbacks(draw);h.removeCallbacks(drawAgain);});}
        void close(){closed=true;Handler h=handler;if(h!=null){h.removeCallbacksAndMessages(null);h.post(()->{cleanup();surface.release();thread.quitSafely();});}}
        void failed(){if(!closed){requested=false;post(()->{if(renderer==this&&failure!=null)failure.run();});}cleanup();}
        void initialize() throws IOException {
            egl=(EGL10)EGLContext.getEGL();display=egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
            if(display==EGL10.EGL_NO_DISPLAY||!egl.eglInitialize(display,new int[2]))throw new IOException("EGL display");
            EGLConfig[] configs=new EGLConfig[1];int[] count=new int[1];
            int[] attributes={EGL10.EGL_RED_SIZE,8,EGL10.EGL_GREEN_SIZE,8,EGL10.EGL_BLUE_SIZE,8,EGL10.EGL_ALPHA_SIZE,8,EGL10.EGL_DEPTH_SIZE,16,0x3040,4,EGL10.EGL_SURFACE_TYPE,EGL10.EGL_WINDOW_BIT,EGL10.EGL_NONE};
            if(!egl.eglChooseConfig(display,attributes,configs,1,count)||count[0]==0)throw new IOException("EGL config");
            context=egl.eglCreateContext(display,configs[0],EGL10.EGL_NO_CONTEXT,new int[]{0x3098,2,EGL10.EGL_NONE});
            window=egl.eglCreateWindowSurface(display,configs[0],surface,null);
            if(context==EGL10.EGL_NO_CONTEXT||window==EGL10.EGL_NO_SURFACE||!egl.eglMakeCurrent(display,window,window,context))throw new IOException("EGL window");
            program=GLES20.glCreateProgram();int vs=shader(GLES20.GL_VERTEX_SHADER,VERTEX),fs=shader(GLES20.GL_FRAGMENT_SHADER,FRAGMENT);
            GLES20.glAttachShader(program,vs);GLES20.glAttachShader(program,fs);GLES20.glLinkProgram(program);GLES20.glDeleteShader(vs);GLES20.glDeleteShader(fs);
            int[] ok=new int[1];GLES20.glGetProgramiv(program,GLES20.GL_LINK_STATUS,ok,0);if(ok[0]==0)throw new IOException("Roadster shader link");
            position=GLES20.glGetAttribLocation(program,"aPosition");normal=GLES20.glGetAttribLocation(program,"aNormal");camera=GLES20.glGetUniformLocation(program,"uCamera");stretch=GLES20.glGetUniformLocation(program,"uStretch");spin=GLES20.glGetUniformLocation(program,"uSpin");pivot=GLES20.glGetUniformLocation(program,"uPivot");axis=GLES20.glGetUniformLocation(program,"uAxis");base=GLES20.glGetUniformLocation(program,"uBase");kind=GLES20.glGetUniformLocation(program,"uKind");
            RoadsterMesh671 model=RoadsterMesh671.read(getContext().getAssets().open("rides671/roadster.mesh.bin"));vertices=model.vertices;batches=model.parts;
            GLES20.glEnable(GLES20.GL_DEPTH_TEST);GLES20.glDepthFunc(GLES20.GL_LEQUAL);GLES20.glEnable(GLES20.GL_BLEND);GLES20.glBlendFuncSeparate(GLES20.GL_SRC_ALPHA,GLES20.GL_ONE_MINUS_SRC_ALPHA,GLES20.GL_ONE,GLES20.GL_ONE_MINUS_SRC_ALPHA);
        }
        final Runnable draw=this::draw671;
        private void draw671(){
            if(closed||!initialized)return;handler.removeCallbacks(drawAgain);
            try{
                int currentRun=run;boolean playing=requested;if(currentRun!=lastRun){lastRun=currentRun;epoch=SystemClock.uptimeMillis();}
                float t=playing?Math.min(1,(SystemClock.uptimeMillis()-epoch)/(float)duration):.5f;
                GLES20.glViewport(0,0,Math.max(1,width),Math.max(1,height));GLES20.glClearColor(0,0,0,0);GLES20.glDepthMask(true);GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT);GLES20.glUseProgram(program);
                float yaw=.58f+.12f*(float)Math.sin(t*Math.PI),pitch=.25f,cy=(float)Math.cos(yaw),sy=(float)Math.sin(yaw),cp=(float)Math.cos(pitch),sp=(float)Math.sin(pitch);
                float[] rotation={cy,sy*sp,sy*cp,0,cp,-sp,-sy,cy*sp,cy*cp};GLES20.glUniformMatrix3fv(camera,1,false,rotation,0);
                float approach=.78f+.30f*t;GLES20.glUniform2f(stretch,.30f*approach,.30f*approach*Math.max(1,width)/Math.max(1,height));
                vertices.position(0);GLES20.glVertexAttribPointer(position,3,GLES20.GL_FLOAT,false,24,vertices);GLES20.glEnableVertexAttribArray(position);vertices.position(3);GLES20.glVertexAttribPointer(normal,3,GLES20.GL_FLOAT,false,24,vertices);GLES20.glEnableVertexAttribArray(normal);
                for(RoadsterMesh671.Part batch:batches){
                    int m=batch.material,g=batch.group;float[] rgb=m==0?colour:MATERIALS[m];GLES20.glUniform3fv(base,1,rgb,0);GLES20.glUniform1i(kind,m);GLES20.glDepthMask(m!=5);
                    float a=g==0?0:-t*(12f+speed*.2f);GLES20.glUniform2f(spin,(float)Math.cos(a),(float)Math.sin(a));GLES20.glUniform3f(pivot,g<=2?-1.61f:1.58f,.52f,0);GLES20.glUniform3f(axis,0,0,1);
                    GLES20.glDrawElements(GLES20.GL_TRIANGLES,batch.count,GLES20.GL_UNSIGNED_SHORT,batch.indices);
                }
                GLES20.glDepthMask(true);if(!egl.eglSwapBuffers(display,window))throw new IOException("Roadster surface lost");
                if(playing&&currentRun!=notified){notified=currentRun;post(()->{if(renderer==this&&requested&&run==currentRun&&firstFrame!=null)firstFrame.run();});}
                if(requested&&!closed)handler.postDelayed(drawAgain,FRAME_MS);
            }catch(Exception|OutOfMemoryError error){failed();}
        }
        private int notified=-1;
        private final Runnable drawAgain=()->draw.run();
        void cleanup(){initialized=false;if(egl!=null&&display!=null&&display!=EGL10.EGL_NO_DISPLAY){if(program!=0){GLES20.glDeleteProgram(program);program=0;}egl.eglMakeCurrent(display,EGL10.EGL_NO_SURFACE,EGL10.EGL_NO_SURFACE,EGL10.EGL_NO_CONTEXT);if(window!=null&&window!=EGL10.EGL_NO_SURFACE)egl.eglDestroySurface(display,window);if(context!=null&&context!=EGL10.EGL_NO_CONTEXT)egl.eglDestroyContext(display,context);egl.eglTerminate(display);}display=null;vertices=null;batches=null;}
    }
    private static int shader(int type,String source) throws IOException {int shader=GLES20.glCreateShader(type);GLES20.glShaderSource(shader,source);GLES20.glCompileShader(shader);int[] ok=new int[1];GLES20.glGetShaderiv(shader,GLES20.GL_COMPILE_STATUS,ok,0);if(ok[0]==0){GLES20.glDeleteShader(shader);throw new IOException("Roadster shader compile");}return shader;}
    private static final float[][] MATERIALS={{0,0,0},{.012f,.018f,.024f},{.62f,.68f,.76f},{.72f,.9f,1},{.16f,.055f,.026f},{.006f,.023f,.041f},{.017f,.021f,.026f},{.18f,.20f,.23f},{.45f,.015f,.025f}};
    private static final String VERTEX="attribute vec3 aPosition;attribute vec3 aNormal;uniform mat3 uCamera;uniform vec2 uStretch;uniform vec2 uSpin;uniform vec3 uPivot;uniform vec3 uAxis;varying vec3 vNormal;vec3 turn(vec3 v){return v*uSpin.x+cross(uAxis,v)*uSpin.y+uAxis*dot(uAxis,v)*(1.-uSpin.x);}void main(){vec3 p=uPivot+turn(aPosition-uPivot);vec3 n=turn(aNormal);vec3 q=uCamera*p;vNormal=uCamera*n;gl_Position=vec4(q.x*uStretch.x,q.y*uStretch.y-.28,q.z*.10,1.0);}";
    private static final String FRAGMENT="precision mediump float;varying vec3 vNormal;uniform vec3 uBase;uniform int uKind;void main(){vec3 n=normalize(vNormal);vec3 eye=vec3(0.,0.,-1.);if(dot(n,eye)<0.)n=-n;vec3 light=normalize(vec3(-.25,.82,-.51));float dl=max(0.,dot(n,light));float nv=max(0.,dot(n,eye));vec3 r=2.*nv*n-eye;float sky=clamp(r.y*.5+.5,0.,1.);vec3 env=vec3(.025,.04,.08)+vec3(.30,.38,.50)*sky;float band=exp(-pow((r.y-.36-r.x*.18)/.085,2.));float strip=exp(-pow((r.x+.60)/.10,2.))*clamp(r.y+.1,0.,1.);env+=vec3(band*1.5+strip*.5);vec3 rgb=uBase*(.28+.65*dl);float alpha=1.;if(uKind==0||uKind==2)rgb=uBase*(.20+.30*dl)+env*(uBase*.9+.07);if(uKind==3)rgb=vec3(1.,1.22,1.5);if(uKind==5){rgb=uBase*.55+env*(.16+.4*pow(1.-nv,5.));alpha=.42;}rgb=pow(vec3(1.)-exp(-max(rgb,vec3(0.))*1.6),vec3(1./2.2));gl_FragColor=vec4(rgb,alpha);}";
}
