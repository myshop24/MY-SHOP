package com.myshop.app;
/** Full-screen host privacy is driven by camera state, never microphone mute. */
final class FullVideo671 {
 static boolean themeOnly(String view,boolean duel,boolean hostTile,boolean cameraOff){return "FULL".equals(view)&&!duel&&hostTile&&cameraOff;}
 static int commentInset(int stageTop,int stageHeight,int thirdSeatBottom,int gap){return Math.max(0,Math.min(Math.max(0,stageHeight),thirdSeatBottom+Math.max(0,gap)-stageTop));}
 private FullVideo671(){}
}
