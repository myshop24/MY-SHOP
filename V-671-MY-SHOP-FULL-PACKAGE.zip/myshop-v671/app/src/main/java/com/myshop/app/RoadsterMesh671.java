package com.myshop.app;
import java.io.*;
import java.nio.*;
import java.util.Arrays;
import java.util.zip.GZIPInputStream;
/** Bounded local mesh decoder, independent of Android and GPU; original 3D source only. */
final class RoadsterMesh671 {
 final FloatBuffer vertices;final Part[] parts;final int vertexCount;
 private RoadsterMesh671(FloatBuffer v,Part[] p,int n){vertices=v;parts=p;vertexCount=n;}
 static final class Part {final int group,material,count;final ShortBuffer indices;Part(int g,int m,int n,ShortBuffer i){group=g;material=m;count=n;indices=i;}}
 static RoadsterMesh671 read(InputStream source) throws IOException {
  try(DataInputStream in=new DataInputStream(new GZIPInputStream(source))){
   byte[] magic=new byte[8];in.readFully(magic);if(!Arrays.equals(magic,new byte[]{77,83,82,54,55,49,0,1}))throw new IOException("Roadster mesh header");
   int n=in.readInt(),count=in.readInt();if(n<1||n>65535||count<1||count>64)throw new IOException("Roadster mesh bounds");
   FloatBuffer vertices=ByteBuffer.allocateDirect(n*24).order(ByteOrder.nativeOrder()).asFloatBuffer();
   for(int i=0;i<n*6;i++){float value=in.readFloat();if(Float.isNaN(value)||Float.isInfinite(value)||Math.abs(value)>100)throw new IOException("Roadster vertex");vertices.put(value);}vertices.position(0);
   Part[] parts=new Part[count];int total=0;
   for(int i=0;i<count;i++){
    int group=in.readUnsignedByte(),material=in.readUnsignedByte(),size=in.readInt();if(group>4||material>8||size<3||size>300000||size%3!=0||(total+=size)>450000)throw new IOException("Roadster part bounds");
    ShortBuffer indices=ByteBuffer.allocateDirect(size*2).order(ByteOrder.nativeOrder()).asShortBuffer();for(int j=0;j<size;j++){int index=in.readUnsignedShort();if(index>=n)throw new IOException("Roadster index");indices.put((short)index);}indices.position(0);parts[i]=new Part(group,material,size,indices);
   }
   if(in.read()!=-1)throw new IOException("Roadster trailing bytes");return new RoadsterMesh671(vertices,parts,n);
  }
 }
}
