# MY SHOP V-671

একটি GitHub-upload source package: **V-671-MY-SHOP-FULL-PACKAGE.zip**।
কাজ02,03,06,17; Guardian Remove শুধু Admin। Rider-এর আগের কাজ রাখা হয়েছে,19 করা হয়নি।

প্রথমে `GITHUB-UPLOAD-V671-BN.md` এবং `MY-SHOP-DEVELOPER-HANDOFF.md` পড়ুন।
Android release assembly/lint/APK contents verification পাস। মূল signing key এখানে নেই; ZIP-এ APK নেই। GitHub-এর original signing দিয়ে সফল Android build হলে নতুন APK পাবেন। Physical phone/Agora পরীক্ষা হয়নি।

Source version671 /2.9.671 /com.myshop.app। প্রয়োজনীয় media generators ও hash-verified baseline restore included; build-এ internet/dependencies লাগবে। কখনো নতুন signing key বানিয়ে পুরোনো install/update identity বদলাবেন না।
