# V-671 — একটিই ফাইল আপলোড করবেন

**V-671-MY-SHOP-FULL-PACKAGE.zip** না খুলে আগের MY-SHOP repository-র root-এ **Add file → Upload files → Commit** করুন। এটি patch নয়; পুরো current source project package। আপনার আগের permanent pipeline এই FULL-PACKAGE নাম এবং সবচেয়ে বড় V-number নির্বাচন সমর্থন করে। APK পাওয়া যাবে সফল Android run-এর **Artifacts** থেকে। নতুন APK-তে versionCode671/versionName2.9.671 এবং মূল signing certificate মিলতে হবে।

এই ZIP-এ APK নেই। লোকালে unsigned release assembly, lint এবং APK contents পরীক্ষা পাস হয়েছে; original signing key এখানে ছিল না। কোনো পুরোনো APK নতুন নামে দেওয়া হয়নি। GitHub-এর আগের signing Secrets/cache অপরিবর্তিত রাখবেন। নতুন key বানাবেন না।

আপনার ডাটা বাঁচাতে ZIP একবার upload করুন, সফল হলে APK একবার download করুন। Source ZIP25MB-এর নিচে; বর্তমান পূর্ণ-media APK প্রায়312MB,25MB নয়। Wi-Fi পেলে APK নামাতে পারেন।

মূল repository-র permanent workflow আগে থেকেই Worker deploy করে। সোর্স ZIP upload-এ root workflow নিজে বদলায় না; ভিতরের build-only workflow তার বিকল্প হিসেবে নিজে install হয় না। নতুন Guardian/Theme API-র জন্য একইV671 Worker প্রয়োজন। এই কাজ থেকে কোনো remote deploy করা হয়নি।

## কোথায় কী ব্যবহার করবেন

1. **Guardian:** Live-এর মূল MS চিহ্ন→1/2/3মাসের দাম দেখুন। ছবি থাকলে tap→profile; More→Guardian→তালিকা। Admin Panel→Guardian→Host ID লিখে list খুলুন→Remove/Restore। অন্যরা করতে পারবেন না। Admin plan-এ দাম দিয়ে Enable/Publish করতে হবে। ক্যাটালগ background-ও এখান থেকে upload/Save করুন। Remove শুধু প্রদর্শন বন্ধ করে; কেনা মেয়াদ/হিস্ট্রি থাকে। লাইভে পরিবর্তন সর্বোচ্চ চলতি30-second refresh-এ আসে।
2. **Gift:** Live-এর ডানের বড় box icon আগের Send panel-ই খুলবে; animation নিজে চলবে, আলাদা setting দরকার নেই।
3. **Free Wallpaper:** Admin Panel→Audio / Video Live Themes→AUDIO/VIDEO→Wallpaper/Animated Wallpaper→1–6slot→media upload→preview→Enable→Save/Publish। প্রতিটি mode-এ6+6=12; দুই mode-এ24। Paid wallpaper-এর জন্য আগের Wallpaper Management-এ price/days/Publish থাকবে।
4. **ব্যবহারকারী:** Profile→My Collection→Theme→ছবি/ভিডিও preview→Confirm। ফ্রি enabled slot কিনতে হবে না। বর্তমান24-hour choice reset এবং paid expiry আগের নিয়মে থাকে। ভিডিও থিম সম্পূর্ণ নীরব।
5. **ফুলস্ক্রিন:** VIDEO Live→More→Layout→Host full screen। ক্যামেরা বন্ধ করলে মাঝের portrait যাবে, থিম থাকবে; ডানে3চেয়ার থাকবে। শুধু mic mute করলে camera/video বন্ধ হবে না। Comments3নম্বর seat-এর নিচে থাকবে।

19সহ অন্য নতুন কাজ এই release-এ নেই। Rider-এর আগে করা partial কাজ রাখা হয়েছে। কোনো physical-phone বা live Agora পরীক্ষা করা হয়নি।

Developer: exact status/proofs/dependencies are in MY-SHOP-DEVELOPER-HANDOFF.md and verification/V671-RESULTS.json. Repackage with `python3 tools/pack_source671.py OUTPUT.zip`; optional free `zopfli` tightens standard ZIP compression. Existing bundles must never be overwritten.
