# MY SHOP Developer Handoff — V-292

## Current version
- App/source version: **V-292**
- versionName: **2.9.292**
- Base: **V-291**
- Scope: **Right-side action spacing polish only**

## Completed in V-292
1. Preserved the approved Live Room layout and all V-291 bottom safe-area behavior.
2. Kept the right-side action order exactly: **Request → Gift → React → Share**.
3. Added a light **8dp vertical gap** between Gift, React, and Share (and naturally between Request→Gift through Gift's top margin) so the circular actions no longer visually touch.
4. Increased only the floating action container height from **180dp to 192dp** so the new spacing fits without clipping.
5. No seat, Host, Guest, timer, comments, bottom row, backend room logic, wallet, dashboard, feed, profile, or RTC behavior was redesigned in this version.
6. Preserved role rule: **Host = End**, **Audience/User = Join**.

## Locked approved Live Room rules
- Host information stays at top-left.
- Six users remain on the same Host/header line when available, with the overflow arrow/control at the corner per approved design.
- Timer stays under Host information on the left.
- Guest profile/emblem remains centered with neutral golden animated/laurel treatment and **no crown**.
- Ten speaker positions remain **5 + 5**. Occupied position = user profile; empty position = golden sofa.
- Right side remains **Request → Gift → React → Share**.
- Bottom row remains **Comment → Send → colored Mic → highlighted Join/End**, fully above Android system navigation/gesture controls.
- Do not restore the old extra bottom icon bar.

## Backend / schema
- No schema or API behavior change in V-292.
- Worker version/build health markers updated to **2.9.292 / V-292** only.
- Existing Live seat architecture (Host seat 1, speaker positions 2–11) remains unchanged.

## Testing / verification
- Worker JavaScript syntax: verify with `node --check backend/worker/src/index.js`.
- AndroidManifest XML: parse verification required.
- Version identity and packaged ZIP integrity: verify before delivery.
- Full Android APK compile is **not claimed** unless a complete Android/Gradle build actually runs successfully.

## NEXT START HERE
1. Build V-292 in GitHub Actions / Android toolchain.
2. On a real phone, confirm right-side Request/Gift/React/Share circles have a small clean gap and remain easy to tap.
3. Confirm bottom Comment/Send/Mic/Join-or-End row remains clearly above Android navigation/gesture controls.
4. Confirm Host still sees **End**, audience sees **Join**.
5. If all UI checks pass, continue the Audio Live RTC/Agora integration phase without redesigning the approved Live Room.
