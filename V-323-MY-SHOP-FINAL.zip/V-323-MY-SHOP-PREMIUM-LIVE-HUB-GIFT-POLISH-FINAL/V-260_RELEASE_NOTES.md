# V-260 — Dashboard Lock + Quick Links Polish

- Dashboard header through Go Live / Join Live remains fixed/locked.
- Scrolling begins from the Live/New User profile-card section downward.
- Quick Links visual polish updated to match the approved dashboard reference, especially the Page icon treatment.
- Existing lower dashboard sections and behavior are preserved.
- Release identity corrected and locked to V-260 across SOURCE_BUILD_ID, SOURCE_VERSION_NAME, Android versionCode/versionName, and Worker health/build markers.
