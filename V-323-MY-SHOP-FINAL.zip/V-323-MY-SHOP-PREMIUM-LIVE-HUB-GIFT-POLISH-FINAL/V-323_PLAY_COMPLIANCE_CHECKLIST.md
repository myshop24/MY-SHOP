# V-323 Google Play Compliance Checklist

- PASS (source): targetSdk/compileSdk remain 36.
- PASS (source): Android 13+ POST_NOTIFICATIONS is requested at runtime; notification permission remains user controlled.
- PASS (source): notification tap uses an internal explicit ChatActivity intent; no exported chat component required.
- PASS (source): no Firebase/service-account secrets are bundled.
- PASS (preserved): Live comments remain transient/session-scoped rather than permanent history.
- PASS (preserved): Coin/Gold Coin catalogs and existing Play Billing dependency remain present.
- NEEDS DEVICE TEST: notification display on lock screen/background/force-stopped behavior depends on Android/OEM/user settings and Firebase delivery.
- NEEDS CLOUD SETUP: Firebase project credentials + Worker FCM service-account secret.
- NEEDS RELEASE QA: signed release APK/AAB, Play Billing purchase paths, privacy/Data Safety declarations, UGC moderation/report/block, account deletion, ads, microphone disclosure, and current Play Console policy forms.
