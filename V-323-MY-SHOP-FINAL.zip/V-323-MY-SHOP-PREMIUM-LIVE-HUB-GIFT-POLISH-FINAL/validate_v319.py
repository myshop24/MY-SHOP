from pathlib import Path
import re, subprocess, xml.etree.ElementTree as ET, sqlite3, sys, hashlib
ROOT=Path(__file__).resolve().parent
checks=[]
def check(name, cond, detail=''):
    checks.append((name,bool(cond),detail))
def txt(rel):
    return (ROOT/rel).read_text(encoding='utf-8',errors='replace')

build=txt('app/build.gradle')
admin=txt('app/src/main/java/com/myshop/app/LiveGiftAdminActivity.java')
live=txt('app/src/main/java/com/myshop/app/AudioLiveRoomActivity.java')
anim=txt('app/src/main/java/com/myshop/app/CatalogGiftAnimator.java')
loader=txt('app/src/main/java/com/myshop/app/AnimatedAssetLoader.java')
hub=txt('app/src/main/java/com/myshop/app/AdminHubActivity.java')
backend=txt('backend/worker/src/index.js')
wr=txt('backend/worker/wrangler.toml')
workflow=txt('.github/workflows/my-shop-apk.yml')
manifest=txt('app/src/main/AndroidManifest.xml')

# Version/build identity
check('SOURCE_BUILD_ID = MY SHOP V-319', txt('SOURCE_BUILD_ID.txt').strip()=='MY SHOP V-319')
check('SOURCE_VERSION_NAME = 2.9.319', txt('SOURCE_VERSION_NAME.txt').strip()=='2.9.319')
check('Android versionCode = 319', bool(re.search(r'\bversionCode\s+319\b',build)))
check('Android versionName = 2.9.319', 'versionName "2.9.319"' in build or "versionName '2.9.319'" in build)
check('compileSdk/targetSdk 36 retained', 'compileSdk 36' in build and 'targetSdk 36' in build)
check('Worker health identity = V-319 / 2.9.319', backend.count("version:'2.9.319',build:'V-319'")>=2)
check('GitHub workflow label = V-319', 'AUTO-BUILD V-319' in workflow)

# User-reported compile fix
check('AudioLiveRoomActivity explicitly imports GridLayout', 'import android.widget.GridLayout;' in live)
check('Gift Store still uses GridLayout after import fix', 'final GridLayout grid=new GridLayout(this)' in live and 'GridLayout.LayoutParams gp' in live and 'GridLayout.spec' in live)
check('No accidental GridLayout class removal', live.count('GridLayout')>=8)

# Admin Catalog UI / controls
check('Admin hub exact Gift Coin & Gold Coin Catalog entry retained', 'Gift Coin & Gold Coin Catalog' in hub and 'live_gifts' in hub)
check('Separate Gift Coin and Gold Coin tabs retained', '1  🪙  GIFT COIN' in admin and '2  👑  GOLD COIN' in admin)
check('Add New Gift retained for both tabs', 'ADD NEW' in admin and 'selectedCurrency' in admin)
check('Catalog Animation ON/OFF control exists', 'Catalog Animation ON' in admin and 'catalogEnabled' in admin)
check('Catalog Animation Type selector exists', 'CATALOG_TYPES' in admin and all(x in admin for x in ['AUTO','PULSE','BOUNCE','FLOAT','GLOW','SPARKLE','ROTATE','SLIDE']))
check('Catalog Preview Size is 0–100', 'Preview Size 0–100%' in admin and 'catalogSize=slider(68)' in admin)
check('Catalog Strength is 0–100', 'Animation Strength 0–100%' in admin and 'catalogStrength=slider(42)' in admin)
check('Catalog Speed is 0–100', 'Animation Speed 0–100%' in admin and 'catalogSpeed=slider(45)' in admin)
check('Catalog Glow/Particle is 0–100', 'Glow / Particle 0–100%' in admin and 'catalogGlow=slider(35)' in admin)
check('Catalog Loop ON/OFF exists', 'Loop ON' in admin and 'catalogLoop' in admin)
check('Custom Catalog Animation upload exists', 'Add/Replace Catalog Animation' in admin and 'catalog_animation' in admin and 'catalogAnimationUrl' in admin)
check('Catalog Preview/Test action exists', 'PREVIEW / TEST' in admin and 'previewCatalogEditor' in admin)
check('Catalog settings save/publish payload exists', all(x in admin for x in ['catalogAnimationEnabled','catalogAnimationType','catalogPreviewSize','catalogAnimationStrength','catalogAnimationSpeed','catalogGlowParticle','catalogLoop','catalogAnimationUrl']))
check('Live Send Animation stays separate', 'LIVE SEND ANIMATION size 0–100%' in admin and 'animationScale' in admin)
check('Sound Volume stays separate', 'SOUND volume 0–100%' in admin and 'soundVolume' in admin)
check('Price/order/Edit/Save/Delete retained', all(x in admin for x in ['Catalog position / order','✏ Edit','💾 SAVE','🗑 DELETE','price']))

# Backend additive schema and upgrade path
fields={
 'catalog_animation_enabled':'DEFAULT 1',
 'catalog_animation_type':"DEFAULT 'AUTO'",
 'catalog_preview_size':'DEFAULT 68',
 'catalog_animation_strength':'DEFAULT 42',
 'catalog_animation_speed':'DEFAULT 45',
 'catalog_glow_particle':'DEFAULT 35',
 'catalog_loop':'DEFAULT 1',
 'catalog_animation_url':"DEFAULT ''",
}
for field, default in fields.items():
    check(f'D1 additive field {field}', f'ADD COLUMN {field}' in backend and default in backend[backend.find(f'ADD COLUMN {field}'):backend.find(f'ADD COLUMN {field}')+180])
check('Backend Admin save reads all catalog controls', all(x in backend for x in ['b.catalogAnimationEnabled','b.catalogAnimationType','b.catalogPreviewSize','b.catalogAnimationStrength','b.catalogAnimationSpeed','b.catalogGlowParticle','b.catalogLoop','b.catalogAnimationUrl']))

# D1 prepared-statement placeholder integrity for Admin save INSERT/UPDATE.
try:
    fn=backend[backend.index('async function adminLiveGiftSave'):backend.index('async function adminLiveGiftDelete')]
    pairs=re.findall(r"env\.DB\.prepare\(`([^`]+)`\)\.bind\(([^;]+?)\)\.(?:run|first)",fn)
    critical=[(q,b) for q,b in pairs if q.lstrip().startswith(('INSERT INTO myshop_live_gifts','UPDATE myshop_live_gifts SET'))]
    ok_pairs=len(critical)==2 and all(q.count('?')==len([x for x in b.split(',')]) for q,b in critical)
    check('Admin Gift D1 INSERT/UPDATE placeholder counts match binds',ok_pairs,str([(q.count('?'),len(b.split(','))) for q,b in critical]))
except Exception as e:
    check('Admin Gift D1 INSERT/UPDATE placeholder counts match binds',False,str(e))
check('Backend clamps catalog 0–100 fields', backend.count('Math.max(0,Math.min(100')>=5)
check('Coin/Gold currency lock preserved', 'GIFT_CURRENCY_LOCKED' in backend and "['COIN','GOLD'].includes(currency)" in backend)
check('Live catalog remains backend-authoritative SELECT *', 'SELECT * FROM myshop_live_gifts WHERE enabled=1' in backend)

# Existing gifts get defaults test in SQLite using the additive DDL contract.
try:
    con=sqlite3.connect(':memory:'); c=con.cursor()
    c.execute("CREATE TABLE myshop_live_gifts(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,currency TEXT NOT NULL,price INTEGER NOT NULL DEFAULT 1)")
    c.execute("INSERT INTO myshop_live_gifts(name,currency,price) VALUES('Rose','COIN',10)")
    ddls=[
      "ALTER TABLE myshop_live_gifts ADD COLUMN catalog_animation_enabled INTEGER NOT NULL DEFAULT 1",
      "ALTER TABLE myshop_live_gifts ADD COLUMN catalog_animation_type TEXT NOT NULL DEFAULT 'AUTO'",
      "ALTER TABLE myshop_live_gifts ADD COLUMN catalog_preview_size INTEGER NOT NULL DEFAULT 68",
      "ALTER TABLE myshop_live_gifts ADD COLUMN catalog_animation_strength INTEGER NOT NULL DEFAULT 42",
      "ALTER TABLE myshop_live_gifts ADD COLUMN catalog_animation_speed INTEGER NOT NULL DEFAULT 45",
      "ALTER TABLE myshop_live_gifts ADD COLUMN catalog_glow_particle INTEGER NOT NULL DEFAULT 35",
      "ALTER TABLE myshop_live_gifts ADD COLUMN catalog_loop INTEGER NOT NULL DEFAULT 1",
      "ALTER TABLE myshop_live_gifts ADD COLUMN catalog_animation_url TEXT NOT NULL DEFAULT ''",
    ]
    for q in ddls: c.execute(q)
    row=c.execute('SELECT catalog_animation_enabled,catalog_animation_type,catalog_preview_size,catalog_animation_strength,catalog_animation_speed,catalog_glow_particle,catalog_loop,catalog_animation_url FROM myshop_live_gifts').fetchone()
    check('Existing gift rows receive animated catalog defaults', row==(1,'AUTO',68,42,45,35,1,''), repr(row))
except Exception as e:
    check('Existing gift rows receive animated catalog defaults', False, str(e))

# Live catalog animation behavior
check('CatalogGiftAnimator class included', (ROOT/'app/src/main/java/com/myshop/app/CatalogGiftAnimator.java').exists())
check('AUTO maps existing gift names to sensible effects', all(x in anim for x in ['heart','teddy','chocolate','rose','jet','car','diamond','crown','star','castle']))
check('Catalog custom animated asset preferred in Live grid', 'catalog_animation_url' in live and 'AnimatedAssetLoader.load(icon,catalogAsset,false)' in live)
check('Catalog preview size changes real icon dp', 'CatalogGiftAnimator.iconDp(g)' in live)
check('Visible-only animation guard exists', 'Rect.intersects(scrollRect,artRect)' in live and 'setOnScrollChangeListener' in live)
check('Off-screen preview animation is stopped', 'CatalogGiftAnimator.stop(art' in live)
check('Low-RAM device animation caps exist', 'isLowRamDevice()' in anim and 'Math.min(strength,36)' in anim and 'Math.min(glow,20)' in anim)
check('Original AnimatedAssetLoader API preserved', 'public static void load(ImageView view,String url){ load(view,url,true); }' in loader)
check('Catalog loader can disable autoplay until visible', 'load(ImageView view,String url,boolean autoplay)' in loader and 'if(autoplay)' in loader)

# Preserve V-318 send path
check('Reference-video select -> one shared SEND flow retained', 'Tap a gift once → press Send' in live and 'final Button sendButton' in live and 'chosen[0]=g' in live)
check('Success closes panel before full Live effect', live.find('giftStoreDialog.dismiss()',live.find('private void openGiftChart')) < live.find('showGiftEffect(effectGift,d)',live.find('private void openGiftChart')))
check('Duplicate suppression retained', 'renderedGiftEventIds.add(sentEventId)' in live and 'idx_live_gift_nonce' in backend)
check('Live send animation consumes separate animation_scale', 'giftScale(gift)' in live and 'giftArtPx(scale)' in live)
check('Live sound consumes separate sound_volume', 'gift.optInt("sound_volume",85)/100f' in live)

# Backend/binding/regression safety
check('D1 binding preserved', 'binding = "DB"' in wr and 'database_name = "my-shop-db"' in wr and '15b6acd2-0e82-4bd8-95fb-bee6fc08936c' in wr)
check('R2 binding preserved', 'binding = "MEDIA"' in wr and 'bucket_name = "my-shop-media"' in wr)
check('Play Billing dependency retained', 'com.android.billingclient:billing:9.1.0' in build)
check('Gift Admin remains non-exported in manifest', '.LiveGiftAdminActivity' in manifest and 'android:exported="false"' in manifest[manifest.find('.LiveGiftAdminActivity')-40:manifest.find('.LiveGiftAdminActivity')+100])
check('Gift Admin remains session-gated', 'if(!SessionManager.isAdmin(this)){finish();return;}' in admin)

# Worker JS syntax
r=subprocess.run(['node','--check',str(ROOT/'backend/worker/src/index.js')],capture_output=True,text=True)
check('Worker JavaScript syntax (node --check)', r.returncode==0, (r.stderr or r.stdout).strip())

# Android XML parse
xml_bad=[]
for p in [ROOT/'app/src/main/AndroidManifest.xml', *ROOT.glob('app/src/main/res/**/*.xml')]:
    try: ET.parse(p)
    except Exception as e: xml_bad.append(f'{p.relative_to(ROOT)}:{e}')
check('Manifest/resources XML parse', not xml_bad, '; '.join(xml_bad[:5]))

# Java parser smoke; Android classes are unavailable locally, so only parser diagnostics are release-blocking here.
parse_patterns=["';' expected",'illegal start','not a statement','reached end of file while parsing','class, interface, enum, or record expected',') expected','} expected','unclosed','identifier expected','orphaned','else without','try without','catch without','finally without']
java_bad=[]
for rel in ['app/src/main/java/com/myshop/app/LiveGiftAdminActivity.java','app/src/main/java/com/myshop/app/AudioLiveRoomActivity.java','app/src/main/java/com/myshop/app/CatalogGiftAnimator.java','app/src/main/java/com/myshop/app/AnimatedAssetLoader.java','app/src/main/java/com/myshop/app/AdminHubActivity.java']:
    rr=subprocess.run(['javac','-proc:none','-Xmaxerrs','2500',str(ROOT/rel)],capture_output=True,text=True)
    out=(rr.stdout+'\n'+rr.stderr).lower()
    hits=[q for q in parse_patterns if q.lower() in out]
    if hits: java_bad.append(f'{rel}: {hits}')
check('Modified Java parser smoke has no syntax diagnostics', not java_bad, '; '.join(java_bad))

# Conflict markers and critical file existence
conf=[]
for p in ROOT.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.java','.js','.xml','.gradle','.yml','.toml'}:
        s=p.read_text(errors='ignore')
        if '<<<<<<< ' in s or '>>>>>>> ' in s or '\n=======' in s: conf.append(str(p.relative_to(ROOT)))
check('No merge conflict markers', not conf, ', '.join(conf[:6]))
check('V-319 handoff/release/compliance docs included', all((ROOT/x).exists() for x in ['V-319_RELEASE_NOTES.md','V-319_PLAY_COMPLIANCE_QA.md','MY-SHOP-DEVELOPER-HANDOFF.md']))

ok=sum(1 for _,v,_ in checks if v); total=len(checks)
for name,v,detail in checks:
    print(('PASS' if v else 'FAIL')+' - '+name+((' :: '+detail) if detail else ''))
print(f'RESULT {ok}/{total} PASS')
if ok!=total: sys.exit(1)
