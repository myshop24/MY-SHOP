# MY SHOP V-279

- Rebuilt the LIVE STREAMING dashboard strip to match the approved compact reference more closely.
- Final action ratio remains Go Live 35% / Join Live 65%.
- Replaced the bar-style live marker with a stationary broadcast-signal treatment.
- Broadcast signal now uses a stronger blink/glow cycle only: no bounce, translation, rotation, or scale movement.
- Reduced title/subtitle/button sizing and spacing to prevent clipping/overflow on narrow Android screens.
- Preserved existing Go Live, Join Live, Admin long-press, backend, feed, and navigation behavior.
