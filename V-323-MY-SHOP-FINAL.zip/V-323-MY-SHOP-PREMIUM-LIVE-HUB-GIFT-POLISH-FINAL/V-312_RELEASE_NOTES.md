# MY SHOP V-312
- Fixed V-311 compile regression: restored showSummary(JSONObject) and renderPremiumState(JSONObject).
- Real Live Gift Store: published backend gifts appear in Live Room with preview, name, currency and price.
- Send Gift performs real backend transaction: sender spendable Coin/Gold is checked/debited and creator earnings credited.
- Gift event/ledger and Live animation response preserved.
- Admin Live Gift Manager supports Add/Edit/Delete/Publish plus separate preview image, animation and sound upload to configured media storage.
- Gift Creator Earnings now receives full gift unit value; MY SHOP service fee is applied at Creator Earnings cash-out, avoiding double fee.
- V-311 End Live/comment/startup-ad fixes preserved.
- Google Play compliance gate #1 remains mandatory.
