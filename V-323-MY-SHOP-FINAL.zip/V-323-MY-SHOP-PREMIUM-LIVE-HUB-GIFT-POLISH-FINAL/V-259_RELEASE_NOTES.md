# V-259 — Startup + Dashboard Polish

Base: V-258 stable successful build/runtime checkpoint.

Implemented only the two requested corrections:
1. Startup: richer local MY SHOP animation, ad preparation behind the animation, and cross-fade only after media is ready so no white/blank bridge appears before the Admin startup ad. Existing V-258 crash-recovery guard remains intact.
2. Dashboard UI: live user row height/padding fixed so Friend/Requested/Respond controls are fully visible; Name + Lv badge are compact and centered with controlled ellipsis; Quick Links alignment/icon spacing polished; fifth Quick Link is Earn with reward icon/key.

Do not regress V-258 startup stability or unrelated features.
