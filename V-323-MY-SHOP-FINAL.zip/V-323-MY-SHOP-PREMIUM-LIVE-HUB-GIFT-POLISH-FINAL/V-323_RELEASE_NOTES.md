# MY SHOP V-323 — 47 Instruction Live/Push Polish

## Implemented source changes
- Preserved the established 12-seat Live Room (6 + 6) and MY SHOP navy/purple/blue/cyan identity.
- Premium seat artwork/depth and clearer occupied/empty treatment without changing seat count or seat logic.
- Gift effect no longer overlays gift-name or sender→receiver banner; configured animation scale controls a larger screen footprint; configured sound volume drives playback with safe LoudnessEnhancer gain.
- Live comments keep optimistic local send and now avoid unnecessary full-list rebuilds when payload is unchanged.
- Live join/leave/request/invite/speaker/seat/gift activity is scoped by the current unique live session ID. Old-session activity is not returned to a new live.
- Join Request and Host Invite flows add duplicate/idempotency protection and user-friendly client error mapping.
- Host can move an accepted/invited speaker to a chosen guest seat (2–12) with locked/occupied validation. Existing Special Guest control remains.
- Messenger/WhatsApp-style message push source added: FCM token registration, Android notification channels/permission, sender title + message preview, conversation grouping, and notification tap into ChatActivity.

## External runtime setup required
Push delivery while the app is backgrounded/closed requires Firebase credentials at build/deploy time. Android build variables: `MYSHOP_FIREBASE_API_KEY`, `MYSHOP_FIREBASE_APP_ID`, `MYSHOP_FIREBASE_PROJECT_ID`, `MYSHOP_FIREBASE_SENDER_ID`. Cloudflare Worker secret: `FCM_SERVICE_ACCOUNT_JSON`. Secrets are intentionally NOT included in this ZIP.

## Regression protection
Coin/Gold Coin catalogs/economy, Admin gift CRUD, existing D1/R2 bindings, Live 12-seat structure, and existing backend routes are preserved.
