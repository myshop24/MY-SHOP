# MY SHOP V-305 Release Notes

Version: **MY SHOP V-305**  
Android: **versionCode 305 / versionName 2.9.305**  
Worker marker: **V-305 / 2.9.305**

## User-approved 6-point scope
1. **Host position correction only:** the dedicated Host stays at the very top; the existing 12-seat 6+6 user/guest board is preserved. Host identity is filtered from the seat board so it is not duplicated in a user seat.
2. **Admin Locker survives normal APK upgrades:** the existing local hash/salt configuration remains in SharedPreferences and is mirrored into the stable session preference namespace for migration safety. No plaintext credentials and no D1/R2 schema dependency were added.
3. **Share Profile visibility:** the Profile share control now has a clear high-contrast `Share Profile` label while keeping the existing native Android share action.
4. **Quick Tools premium compact redesign:** My Coins, Gold Coin, Badge / Member and My Items are all visible together in one non-scrolling row, with smaller responsive premium cards.
5. **Quick Tools functions preserved:** existing wallet, badge/member and owned-item actions/backend calls are unchanged.
6. **Photos / Videos / Reels rendering fix:** the profile media grid now gives tiles explicit responsive widths so media cards cannot collapse to zero width inside GridLayout/ScrollView; image/video/reel viewer behavior remains intact.

## Regression locks
- Existing 12-seat visual arrangement remains 6 + 6.
- Existing Live request/invite/gift/theme/moderation flows are preserved.
- Profile Timeline and Back navigation are preserved.
- Cloudflare D1/R2 bindings, application ID and GitHub build workflow are unchanged.
- Live comments remain temporary/session-only; this build does not add permanent Live-comment storage.
