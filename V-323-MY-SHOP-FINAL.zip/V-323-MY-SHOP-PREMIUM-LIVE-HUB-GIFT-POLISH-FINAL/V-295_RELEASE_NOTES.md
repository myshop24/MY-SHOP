# MY SHOP V-295 — Live + Admin Finance + Locker

## Implemented
1. Live bottom safe-area lifted further so comment/send/mic/end controls stay above Android navigation/gesture area.
2. Comment composer now has one Highlight ✨ control only; the second emoji control was removed.
3. Host setup uses **Live Name** + **Caption**. Live Name is shown in the live room while permanent User ID remains unchanged. Caption is a thin, single-line, colored premium chip and can be edited by the host while live.
4. Live Name policy is server authoritative: one free change per 24 hours; earlier changes cost **5,000 Coin**, deducted from the host and recorded as MY SHOP platform income.
5. Live reactions are stored as an aggregate count only. UI uses compact display (2K, 10K, 1M). Every 10,000 reactions grants the host **+1,000 Coin** exactly once per milestone (10K, 20K, 30K...).
6. Main Admin Locker added: first-time setup with Admin Password + Security Question/Answer; one unlock opens the full Admin session; no repeated password per folder. Recovery: Security Answer, then owner recovery requiring any two of the three configured secret owner identifiers.
7. Server-side admin gate is enforced for `/v1/admin/*` routes through the authenticated admin session. Gate unlock expires after 8 hours or logout/app-process reset.
8. Premium Finance center added to Admin: Today totals, All-Time totals, VAT/fee totals, category-by-category breakdown, recent transaction detail, configurable VAT/service-charge percent, and user-ID investigation.
9. User investigation returns transaction summary/history plus retained message archive. User-side message deletion is soft-delete-for-user and does not erase the admin archive.
10. MY SHOP value ledger remains the source for platform fee/VAT, Live Name fee, Gift/Transfer value flow, Highlight and React reward audit.

## Backend migration
Deploy `backend/worker/migrations/0012_v295_admin_gate_live_name_react_audit.sql` with the V-295 Worker.

## Safety / integrity
- Permanent User ID is not changed by Live Name.
- Main Admin IDs remain protected.
- D1/R2 bindings are preserved.
- React rewards use a stored milestone checkpoint to prevent duplicate payment after refresh/reconnect.
- Admin message review is audit/support functionality; production policy should disclose retention to users and follow applicable retention/privacy law.
