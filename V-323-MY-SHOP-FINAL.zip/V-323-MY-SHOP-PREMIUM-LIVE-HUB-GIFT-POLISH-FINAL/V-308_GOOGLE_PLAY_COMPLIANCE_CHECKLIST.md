# V-308 — Google Play Compliance Checklist

Status legend: `PASS-CODE` = implemented/validated in source; `CONSOLE` = owner must configure Play/Google/Cloudflare; `DEVICE` = must be tested on signed build/device; `CONTENT` = owner must supply real legal/support content.

| Area | Status | V-308 checkpoint |
|---|---|---|
| targetSdk / compileSdk 36 | PASS-CODE | Android config remains API 36. |
| versionCode/versionName | PASS-CODE | 308 / 2.9.308. |
| Play Billing dependency | PASS-CODE | `com.android.billingclient:billing:9.1.0`. |
| User-paid digital goods | PASS-CODE | Google Play flow; legacy direct-money Worker paths disabled. |
| Server purchase verification | PASS-CODE | Android Publisher API verification before entitlement. |
| Replay/double-credit guard | PASS-CODE | unique token hash + atomic D1 entitlement/token batch. |
| Play product IDs | CONSOLE | Create/activate products and map every paid catalog item. |
| Publisher API service account | CONSOLE | Add `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` GitHub secret. |
| Account deletion in app | PASS-CODE | Settings & Privacy → Delete My Account. |
| Account deletion web path | PASS-CODE/DEVICE | Worker `/account-deletion`; verify after deployment. |
| Privacy Policy in app/web | PASS-CODE/CONTENT | Legal pages exist; add real owner support contact before Production. |
| Registration consent | PASS-CODE | unchecked by default; Terms/Privacy links available. |
| UGC report user/content | PASS-CODE | Profile/Feed/Comment/Chat/Live report flow. |
| Block user | PASS-CODE | backend-enforced across key social paths. |
| Admin moderation queue | PASS-CODE | Admin Safety board + Worker report queue. |
| Startup ad dismiss control | PASS-CODE/DEVICE | visible Skip; 1–4 sec Admin setting preserved. |
| Microphone permission | PASS-CODE/DEVICE | runtime permission used for Audio Live; verify deny/retry UX. |
| Broad storage permission | PASS-CODE | only legacy WRITE_EXTERNAL_STORAGE with maxSdk 28. |
| Android backup of app auth state | PASS-CODE | `allowBackup=false`. |
| Data Safety form | CONSOLE | Complete from actual production behavior/inventory. |
| Financial features declaration | CONSOLE | Review wallet/reward/payout declarations. |
| Ads declaration | CONSOLE | Answer according to startup-ad production behavior. |
| Content rating / UGC declarations | CONSOLE | Complete accurately. |
| App access for reviewer | CONSOLE | Supply working login/test instructions. |
| Internal Play Billing test | DEVICE | Required before Production. |
| Live/Feed/Profile regression | DEVICE | Build + multi-user/device QA required. |
| Permanent 4-digit ID non-reassignment | PASS-CODE | Account deletion anonymizes/deactivates; does not recycle ID. |
| D1/R2 bindings preserved | PASS-CODE | production binding names/IDs unchanged. |
