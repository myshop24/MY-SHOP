# MY SHOP V-297 Release Notes

## Base
V-296-MY-SHOP-PROFILE-LIVE-ADMIN-CORRECTIONS-FINAL

## Version identity
- SOURCE_BUILD_ID: MY SHOP V-297
- Android versionCode: 297
- Android versionName: 2.9.297
- Worker health/build identity: V-297 / 2.9.297

## V-297 implementation focus
- Preserved V-296 backend/storage/account contracts while applying the 31-point master scope refinements.
- Corrected bottom-navigation safe-area behavior to avoid double inset / excessive lift.
- Reworked Admin Gate/Locker presentation into a premium, keyboard-safe one-password session flow.
- Added Bengali-first Admin labels/descriptions in the updated management surfaces.
- Added Audio Live wallpaper Gallery/File upload flow with preview and visual color picker; media upload continues through the existing R2 path.
- Added Startup Ad guidance and validation UI for recommended 1080x1920 (9:16), minimum 720x1280, preview and crop warning without stretch.
- Added premium Edit Profile page and in-app Profile media viewer/player/share flow.
- Strengthened Live comment/session presentation and summary/timer handling.
- Added V-297 two-way Live speaker invitation flow: audience Join Request -> Host Accept, and Host Invite -> User Accept/Decline.
- Expanded Live speaker allocator to Seats 2–12 while keeping Seat 1 reserved for Host, with session-scoped pending requests/invites and expiry handling.
- Added D1 migration 0014_v297_live_invites_12seat.sql.

## Important runtime limitation
The source contains real backend room/request/invite/seat state transitions, but the V-296 base does not contain an Agora RTC SDK/audio-engine integration. Therefore V-297 must not be described as having verified real-time voice transport until RTC SDK credentials/token/channel integration is added and tested on devices.

## Release verification performed in this environment
- Cloudflare Worker JavaScript syntax: PASS (`node --check`).
- Android resource XML + Manifest parse: PASS (87 XML resources plus Manifest).
- V-297 source/build identity markers: PASS.
- Full Android APK/AAB compile: NOT RUN — Gradle/Android SDK runtime is not installed in this execution environment.

## Required release checks outside this environment
- Run the repository GitHub Actions Android build/signing workflow.
- Apply D1 migration 0014 before exercising the new invite/session flow.
- Verify D1/R2 health and Worker V-297 identity after deploy.
- Device QA on gesture navigation and 3-button navigation.
- Live QA for session isolation, request/accept, host invite/accept/decline, seat-full behavior, expiry and reconnect.
- Play Console pre-launch report and Data safety/privacy review before production release.
