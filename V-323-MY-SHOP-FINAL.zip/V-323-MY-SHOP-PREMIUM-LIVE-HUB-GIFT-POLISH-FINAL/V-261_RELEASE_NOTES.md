# V-261 — Premium Header + Feed Readability Polish

Base: V-260 successful build source.

## Completed
- Removed only the square MS logo from the dashboard header.
- Kept the profile photo fully visible and shifted the MY SHOP wordmark slightly right.
- MY is larger/deep-blue; SHOP is bright orange, slightly lower and only slightly smaller, matching the user-approved reference.
- Strengthened the subtitle: Shop • Social • Live • Earn.
- Preserved language, notification badge, message button, live controls and all existing functions.
- Increased MY FEED post readability: larger profile photo, name, metadata, status text, line spacing and action buttons.
- Feed cards remain responsive/auto-height; photo/video media use the available width without changing dashboard section order.
- Polished live/new-user card spacing and Quick Links icon/title balance, preserving the approved Page icon and all link behavior.
- Preserved V-260 fixed/scroll behavior: Header through Go Live / Join Live stays fixed; scrolling begins at the Live/New User profile area.

## Release identity
- SOURCE_BUILD_ID: MY SHOP V-261
- SOURCE_VERSION_NAME: 2.9.261
- Android versionCode: 261
- Android versionName: 2.9.261
- Worker version/build: 2.9.261 / V-261

## Build-safety rule
V-261 is a unique release number. Any correction after delivery must use V-263; never create V-261-FIXED or another V-261 source ZIP.
