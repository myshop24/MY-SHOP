# Current Release — MY SHOP V-321

V-321 is a version-identity correction release based directly on V-320. It preserves the V-320 Premium Live Hub, Live Room polish, Gift Coin / Gold Coin catalog behavior, backend logic, D1/R2 bindings, and existing working app features. No intentional product-feature redesign is included in this correction.

Current release documents:
- `V-321_RELEASE_NOTES.md`
- `V-321_VALIDATION_REPORT.txt`
- `V-321_PLAY_COMPLIANCE_QA.md`
- `MY-SHOP-DEVELOPER-HANDOFF.md`

Build identity: `MY SHOP V-321` / Android `2.9.321` / versionCode `321`.
Source package name: `V-321-MY-SHOP-PREMIUM-LIVE-HUB-GIFT-POLISH-FINAL.zip`.
