# MY SHOP V-256 — Five Requested Corrections

Base: **V-255-MY-SHOP-BUILD-IDENTITY-FIX**  
Android: **versionCode 256 / versionName 2.9.256**  
Worker identity: **V-256 / 2.9.256**

## 1. Dashboard: New People removed, Quick Links moved up
- Removed the standalone **New People** block from the dashboard view tree.
- Moved the existing **Quick Links** section into that exact position.
- Preserved Quick Links destinations, labels, See All behavior, and backend/admin behavior.
- Kept New People data loading only because the existing Live Streaming section needs it as the offline fallback; it is no longer rendered as a separate dashboard section.

## 2. LIVE STREAMING title polish
- LIVE STREAMING uses strong per-letter mixed colors with a subtle glow.
- Both side live signal symbols are closer to the title and use gentle scale/alpha/color animation.
- Animation is intentionally soft rather than flashing.
- Go Live / Join Live logic and Live/See All behavior are preserved.

## 3. Startup white-screen removal + premium opening
- Launcher window now has a branded gradient background instead of a white preview.
- Added a MY SHOP logo/brand opening animation while startup-ad configuration loads in parallel.
- The branded layer stays visible until image/video ad media is actually ready, then crossfades to the Admin ad.
- Startup image/video media is cached locally when possible. Existing config cache is preserved across the V-255 -> V-256 update.
- Admin startup ad remains image/video capable with link target, On/Off and the existing **1–6 second** duration range.
- Network/media failure uses a bounded failsafe and enters Login instead of leaving a blank screen.

## 4. Friend Request / Notification / Profile sync
- Incoming Friend Request notifications now expose **Accept** and **Decline** actions while pending.
- Sent requests expose **Cancel** in Friend Requests and on the target profile.
- Incoming profile state exposes a direct Accept/Decline response dialog.
- Accepted requests remain in the backend as ACCEPTED; Decline, Cancel and Unfriend update persistent backend state.
- Notification API now returns the current Friend Request state from the backend, so stale request notifications do not pretend to be pending.
- Friend/follower/following counts continue to come from real backend tables and profile actions refresh returned stats.
- Added FRIEND_UPDATE notification support for decline/update state.

## 5. Icon / button / readability / smoothness polish
- Corrected the visible Cart icon mapping in the main user menu.
- Increased key dashboard Quick Link, bottom navigation and Live user text/icon readability.
- Friend, notification and people action buttons now have clearer semantic symbols and larger touch/readability targets.
- Added safe global UI polish for buttons/clickable text: minimum readable sizes, touch targets, ripple/haptic feedback, and semantic button symbols where labels are unambiguous.
- Existing MY SHOP design, navigation and business logic are preserved; this is a polish pass, not a redesign.

## Verification performed on source
- Worker JavaScript syntax: `node --check` — PASS.
- Android manifest/resources XML parsing — PASS.
- Modified Java sources were parsed by `javac`; no Java syntax-structure errors were detected (Android SDK classes are not installed in this workspace, so Android symbol resolution/compilation cannot be completed locally).
- Friend Request notification SQL was smoke-tested against SQLite with a pending request and returned `PENDING` as expected.
- Source identity/version markers are V-256 / 2.9.256.

## Required deployment validation
For true end-to-end runtime proof, deploy the **V-256 Worker and V-256 APK from this same source** and let the existing GitHub Actions Android build compile/sign the APK. The local workspace does not contain Android SDK/Gradle wrapper binaries, so this release does not claim a local APK compile that was not actually run.
