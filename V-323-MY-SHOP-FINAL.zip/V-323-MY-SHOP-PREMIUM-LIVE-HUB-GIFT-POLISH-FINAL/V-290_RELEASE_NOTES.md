# MY SHOP V-290 Release Notes

## Final approved Audio Live Room controls + animated Guest frame
- Preserves the approved Host row: Host identity on the left, up to 6 active users on the same line to the right, then one `>` control for the rest.
- Removes the old extra bottom icon bar that was falling into the Android system-navigation area.
- Keeps the comment composer in its existing safe vertical position and makes it compact.
- Bottom row is now: Comment → Send → colored Mic → highlighted Join/End.
- Right-side vertical controls are now: Request → Gift → React → Share.
- Join is highlighted with a premium purple/pink background without oversized text.
- Mic has a distinct blue/cyan premium treatment.
- Removes the `SPECIAL GUEST` text.
- Guest profile remains centered and receives a neutral golden animated laurel/glow frame; no crown is used so the frame is gender-neutral.
- Timer remains `HH:MM` with no seconds and is moved to the far left under the Host profile/info area.
- Preserves 10 speaker positions in exact 5 + 5 arrangement; empty seats remain golden sofas.
- Preserves no-scroll/single-screen Live Room architecture and existing backend seat positions 2–11.

## Reference assets
Reference-only files are stored under `docs/reference/`; they are not Android runtime assets.
