# MY SHOP V-255 — Build Identity Permanent Fix

- Fixes V-254 GitHub failure: exact `SOURCE_BUILD_ID.txt` is now `MY SHOP V-255`.
- Locks Android to versionCode 255 / versionName 2.9.255.
- Locks all active Worker health/build markers to V-255 / 2.9.255.
- Retains all V-254 UI/social/startup/Quick Links corrections unchanged.
