# MY SHOP V-266

- versionCode: 266
- versionName: 2.9.266
- Base: V-265 slim premium auth release.
- Compile fix: replaced invalid Android XML attribute `android:hintTextColor` with `android:textColorHint` in both login EditText controls.
- No intended feature removal or design rollback.
