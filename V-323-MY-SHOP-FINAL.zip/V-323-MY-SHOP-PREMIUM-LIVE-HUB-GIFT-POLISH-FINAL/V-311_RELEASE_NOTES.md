# MY SHOP V-311 — FINAL

## Developer Instructions Notice #1 — Google Play Compliance
Mandatory release gate remains active. Existing V-310 Play-safe Coin/Gold Coin, Creator Earnings, MY SHOP Service Fee, non-withdrawable spendable balances, Privacy/Data Safety/UGC/account-deletion requirements remain preserved.

## Completed in V-311
1. End Live first-tap reliability
   - End state locks immediately after host confirmation.
   - Live heartbeat/reconnect loop stops before teardown.
   - Stale refresh callbacks cannot put an ending room back into Reconnecting.
   - Backend /v1/live/end remains idempotent and the client automatically retries without requiring a second user tap.
   - Ended room cannot be reactivated by the periodic presence heartbeat.

2. Live comment instant display
   - Normal comments are rendered optimistically on the Live board immediately on Send.
   - Multiple comments no longer need to wait for a previous comment round-trip.
   - Server reconciliation removes the optimistic pending item after acknowledgement.

3. Live comments strictly ephemeral
   - New normal Live comments are NOT inserted into D1 and are NOT written to R2.
   - New highlighted Live comment text is also held only in the ephemeral active-room buffer.
   - Coin transaction audit for a paid highlight stores only transactional metadata, not the comment text.
   - Ephemeral buffers are session-scoped/capped and cleared when Live ends.
   - Legacy D1 comment tables are retained only for backward-compatible cleanup of rows created by older versions; V-311 does not write new Live comment text there.

4. Startup Advertisement full-image fix
   - Full Image is default using FIT/CONTAIN behavior.
   - Entire image remains visible without side/text crop.
   - Empty area uses a soft blurred copy of the same image behind the full image.
   - Admin can select Full Image or Fill Screen.
   - Admin recommendation updated to 1080 x 2400 (20:9), while 1080 x 1920 remains fully viewable in Full Image mode.
   - Display mode is saved remotely with dashboard ad configuration.

## Regression safety
- Existing Live seat layout, Host/Guest flow, Join Request/Invite, mic, gifts, Coin/Gold Coin, Creator Earnings, D1/R2 bindings and existing app navigation are preserved.
