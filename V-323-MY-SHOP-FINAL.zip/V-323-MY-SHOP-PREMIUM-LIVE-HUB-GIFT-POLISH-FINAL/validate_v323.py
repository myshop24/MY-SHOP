from pathlib import Path
import re, subprocess, xml.etree.ElementTree as ET, sys
ROOT=Path(__file__).resolve().parent
checks=[]
def ck(name, cond, detail=''):
    checks.append((name,bool(cond),detail))
def txt(rel):
    return (ROOT/rel).read_text(encoding='utf-8',errors='replace')

build=txt('app/build.gradle')
worker=txt('backend/worker/src/index.js')
workflow=txt('.github/workflows/my-shop-apk.yml')
wr=txt('backend/worker/wrangler.toml')
live=txt('app/src/main/java/com/myshop/app/AudioLiveRoomActivity.java')
home=txt('app/src/main/java/com/myshop/app/LiveHomeActivity.java')
admin=txt('app/src/main/java/com/myshop/app/LiveGiftAdminActivity.java')
manifest=txt('app/src/main/AndroidManifest.xml')

# Identity
ck('SOURCE_BUILD_ID = MY SHOP V-323', txt('SOURCE_BUILD_ID.txt').strip()=='MY SHOP V-323')
ck('SOURCE_VERSION_NAME = V-323 package', txt('SOURCE_VERSION_NAME.txt').strip()=='V-323-MY-SHOP-PREMIUM-LIVE-HUB-GIFT-POLISH-FINAL')
ck('Android versionCode = 323', bool(re.search(r'\bversionCode\s+322\b', build)))
ck('Android versionName = 2.9.323', bool(re.search(r'\bversionName\s+["\']2\.9\.322["\']', build)))
ck('compileSdk / targetSdk 36 preserved', 'compileSdk 36' in build and 'targetSdk 36' in build)
ck('Worker has exactly two active V-323 health markers', worker.count("version:'2.9.323',build:'V-323'")==2)
ck('No active Worker V-319 health marker remains', "version:'2.9.319',build:'V-319'" not in worker)
ck('Workflow display label = V-323', workflow.startswith('name: MY SHOP STABLE PERMANENT AUTO-BUILD V-323'))
ck('Workflow dynamic SOURCE_VERSION guard preserved', 'grep -Fqx "MY SHOP V-$SOURCE_VERSION" "$BUILD_ID_FILE"' in workflow)
ck('Workflow Android version lock preserved', "f'versionCode {ver}'" in workflow and "f\"versionName '2.9.{ver}'\"" in workflow)

# Backend/bindings
ck('D1 binding preserved', 'binding = "DB"' in wr and 'database_name = "my-shop-db"' in wr and '15b6acd2-0e82-4bd8-95fb-bee6fc08936c' in wr)
ck('R2 binding preserved', 'binding = "MEDIA"' in wr and 'bucket_name = "my-shop-media"' in wr)
ck('Backend URL preserved', 'https://rapid-bush-62ea.myshopsatkania.workers.dev' in build and 'https://rapid-bush-62ea.myshopsatkania.workers.dev' in workflow)

# V-320 feature/regression locks
ck('LiveHomeActivity remains declared', '.LiveHomeActivity' in manifest)
ck('Live Hub real LIVE_NOW discovery preserved', 'BackendClient.liveDiscover' in home and 'LIVE_NOW' in home)
ck('Live Hub real TRENDING discovery preserved', 'BackendClient.liveDiscover' in home and 'TRENDING' in home)
ck('Live Hub new-user backend path preserved', 'BackendClient.newPeople' in home)
ck('Guest seat 6+6 structure lock preserved', 'int[] counts={6,6}' in live)
ck('Gift Store GridLayout compile import preserved', 'import android.widget.GridLayout;' in live)
ck('Gift Admin session gate preserved', 'if(!SessionManager.isAdmin(this)){finish();return;}' in admin)
ck('Play Billing dependency preserved', 'com.android.billingclient:billing:9.1.0' in build)

# Syntax / XML / conflicts
r=subprocess.run(['node','--check',str(ROOT/'backend/worker/src/index.js')],capture_output=True,text=True)
ck('Worker JavaScript syntax', r.returncode==0, (r.stderr or r.stdout).strip())
xml_bad=[]
for p in [ROOT/'app/src/main/AndroidManifest.xml', *ROOT.glob('app/src/main/res/**/*.xml')]:
    try: ET.parse(p)
    except Exception as e: xml_bad.append(f'{p.relative_to(ROOT)}:{e}')
ck('Manifest/resources XML parse', not xml_bad, '; '.join(xml_bad[:5]))
conf=[]
for p in ROOT.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.java','.js','.xml','.gradle','.yml','.yaml','.toml'}:
        s=p.read_text(encoding='utf-8',errors='ignore')
        if '<<<<<<< ' in s or '>>>>>>> ' in s or '\n=======' in s: conf.append(str(p.relative_to(ROOT)))
ck('No merge conflict markers', not conf, ', '.join(conf[:6]))

# Release docs
ck('V-323 release docs present', all((ROOT/x).exists() for x in ['V-323_RELEASE_NOTES.md','V-323_PLAY_COMPLIANCE_QA.md','MY-SHOP-DEVELOPER-HANDOFF.md','V-323_CHANGED_FILES.txt']))

ok=sum(v for _,v,_ in checks); total=len(checks)
for name,v,detail in checks:
    print(('PASS' if v else 'FAIL')+' - '+name+((' :: '+detail) if detail else ''))
print(f'RESULT {ok}/{total} PASS')
if ok!=total: sys.exit(1)
