# MY SHOP Developer Handoff — V-286

Current version: **V-286 / 2.9.286**
Base: V-285 Premium Audio Live Master Batch.

## Completed in V-286 — No-Scroll Compact Live Room
- Removed unnecessary large Live Room header copy; top area is compact with LIVE duration/listener info and top-right X.
- Host moved higher and kept circular-avatar horizontal identity layout.
- 10-seat authoritative model preserved: Seat 1 Host + Seats 2–10 speakers.
- Speaker seats changed from 3 rows to compact 2-row layout (5 + 4) and reduced height.
- Special Guest remains centered below Host and above speaker seats.
- Live comments now use remaining screen height dynamically; outer Live Room no longer uses a vertical ScrollView.
- Bottom controls are a compact single-row bar.
- React + Gift are separated as lower-right floating actions; Gift is UI placeholder until secure gift/coin ledger phase.
- Theme is no longer a normal user control; Host reaches Theme from Host Room Controls.
- Top-right X: audience leaves room; Host gets End Live confirmation.
- Premium custom Live Type launcher replaces the plain Choose Live Type list dialog: Audio Live prominent, Video Live marked Coming Soon.
- Guitar Blue wallpaper remains default with dark readability overlay.
- Latest user reference video 122024.mp4 is the primary layout/spacing behavior reference; do not copy proprietary UI/code.

## NEXT START HERE
1. Install/build V-286 and visually verify no-scroll fit on the owner's target Android phone and at common display/font scales.
2. Fix only any device-specific clipping/IME overlap discovered by APK test; preserve 10-seat 2-row layout.
3. Pre-Agora backend regression QA: seat lock, special guest, requests, started_at timer, viewer heartbeat/stale cleanup, room config/theme persistence.
4. Then begin real RTC Audio integration (Agora/equivalent): secure Worker-issued token, Host/Speaker publish, Audience subscribe, mic, reconnect, speaking/network callbacks.
5. Never place RTC App Certificate/secret in APK or public repository.

## Locked rules
- Host upper-left; circular avatar; Name → ID/LV → Coin/Gold beside it.
- Special Guest centered below Host and above seats.
- 10 seats total, 2 compact speaker rows, comments prioritized, no room-level vertical scrolling.
- React/Gift right-lower floating; remaining controls bottom single row.
- User theme control hidden; Host/Admin controls theme.
- Live Chat public; Messenger private.
- Preserve Dashboard and existing Feed/Profile/Friends/Notifications/Messenger/Admin/Wallet features.

## Testing limitation
Static/package checks are performed here. A full Android APK compile is only claimed if Gradle/Android build tooling is actually available and run successfully. Real RTC voice is NOT implemented in V-286.
