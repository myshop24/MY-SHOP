# MY SHOP V-283 — Audio Live Room Visibility + Regression-Safe UI Fix

- Preserves all V-282 functionality and previous approved dashboard/features.
- Fixes the Audio Live room collapsing to an almost empty panel while backend room state is still loading or unavailable.
- Always renders the approved 12-seat room immediately: Seat 1 Host, Seats 2–12 open speaker seats.
- Keeps backend authoritative; server room state replaces the local visual skeleton when sync succeeds.
- Adds visible room sync state instead of silently hiding the seat area on backend/network errors.
- Adds a clearer premium control strip and keeps Join Requests / Request to Speak behavior intact.
- No Feed/Profile/Friends/Notification/Messenger/Admin/Wallet/Startup Media feature removed or redesigned.
- Agora/RTC media transport is not hard-coded yet; this release prepares the stable room UI/core for the real RTC connection step.
