# MY SHOP Developer Handoff — V-285

Current version: **V-285 / 2.9.285**
Base: V-284 Premium Live Room batch.

## Completed in V-285
- Converted Live Room assignment/UI to 10-seat authority: Seat 1 Host + Seats 2–10 Speakers.
- Compact 3-row speaker sofa grid, larger visible public Live Comments area.
- Host horizontal premium identity layout, circular avatars, centered circular Special Guest spotlight.
- Audience top-right close control separated from Host End Live.
- Backend-based Live duration (`started_at`) that survives refresh/reconnect.
- Room title/topic setup before Host starts Live.
- Seat lock/unlock with locked-seat exclusion from automatic assignment.
- Participant mic/network/speaking state fields and premium speaking-glow UI hook.
- Join/leave activity notices, real public Live comments, share count and Follow Host action.
- Pinned room announcement and Admin-managed Live theme schema/API; bundled Guitar Blue wallpaper is default.
- Live end summary: duration, peak viewers, total unique listeners in session, shares.
- Viewer heartbeat/peak tracking and stale-viewer behavior preserved.

## Important technical checkpoint
High-quality real-time voice transport (Agora/equivalent RTC) is still a separate provider integration phase. V-285 provides the authoritative room/state/UI hooks for speaking/network/mic state but does not falsely emulate a real RTC audio engine. Provider secrets must stay server-side; never place certificates/secrets in APK or public repo.

## Preserve
Do not remove existing Dashboard, Feed, Profile, Friends/Followers, Notifications, Messenger, Admin, Wallet, Badges, Startup Media, D1/R2 bindings, or Live navigation.
