# MY SHOP V-313

- Coin and Gold Coin remain separate currencies and separate Live Gift catalogs.
- Functional default gift catalog is seeded when the catalog is empty; Admin can replace preview/animation assets and edit/delete/publish gifts.
- User Gift/ID transfer: configurable MY SHOP Service Fee (default 10%); Admin/Official sender exempt.
- Star/Level: 100,000 Coin = 1 Star; 1,000 Gold Coin = 1 Star; normal receipt +1 Level/Star; Official Admin grant +2 Levels/Star.
- Admin finance audit stores value transactions plus Star/Level ledger.
- Coin/Gold user wallet removes ADMIN/REWARD button; shows balance and compact Withdraw for eligible Creator Earnings only.
- End Live is first-tap authoritative locally with idempotent backend auto-retry.
- Existing Startup Advertisement Admin Panel keeps Full Image default, 1080x2400 recommendation, Full Image/Fill Screen, responsive FIT/CONTAIN and Skip behavior.
- Paid digital Coin/Gold purchase remains disabled in this Play release; do not enable without compliant Google Play Billing and purchased-value provenance safeguards.
