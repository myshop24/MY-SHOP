# MY SHOP V-300 — Recovery / Stability Build

V-300 is a fix-first recovery build based on V-299. No new product feature is intentionally added beyond restoring requested behavior and making the Admin Locker local-only.

## Fixed scope
1. Admin Panel remains admin-only; the second Admin Locker is now app-local and does not require D1/R2/Cloudflare manual setup. Password/recovery answer are salted PBKDF2 hashes; backend ADMIN role remains authoritative.
2. Normal Login/Register flow is preserved; Admin Locker is only opened from the Admin Panel route.
3. Profile Settings gear/header receives real status-bar safe-area spacing and a larger touch target.
4. Own profile now renders recent Timeline posts directly under the composer; successful text/photo/video posts refresh that inline Timeline immediately while remaining in MY FEED.
5. Audio Live seat surface is balanced as 6 + 6 = 12 total authoritative seats, with Seat 1 Host and Seats 2–12 speakers.
6. Legacy D1 `myshop_live_themes` schema compatibility runs before any query/insert touches newly-added columns, preventing the widespread `table myshop_live_themes has no column ...` failure. Migration is non-destructive.
7. End Live summary is restored/enriched (start/end time, duration, peak viewers, listeners, shares, reacts, comments, gifts, reward). A local fallback summary is shown if server summary fetch fails.
8. Dashboard bottom navigation is lowered toward the real bottom safe-area so it no longer appears excessively floating.
9. D1/R2 bindings, user identity, existing user/content data and signing workflow guards are preserved; no DROP/TRUNCATE/reset migration was added.

## Release identity
- SOURCE_BUILD_ID: MY SHOP V-300
- SOURCE_VERSION_NAME: 2.9.300
- Android versionCode: 300
- Android versionName: 2.9.300
- Worker health/build marker: V-300 / 2.9.300

## Validation in preparation environment
- Worker JavaScript syntax: PASS (`node --check`).
- Modified XML parse: PASS.
- Legacy live-theme migration simulated against a minimal old SQLite schema: PASS.
- Changed Java files: brace balance PASS and javac syntax-pattern scan found no parser-level syntax errors. Full Android compilation still must run in the existing GitHub Actions build environment.
