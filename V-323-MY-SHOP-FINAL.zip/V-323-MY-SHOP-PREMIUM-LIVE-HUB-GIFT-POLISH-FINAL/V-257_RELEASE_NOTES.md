# MY SHOP V-257 — Startup Runtime Crash Hotfix

Base: **V-256-MY-SHOP-5-FIXES-FINAL**
Android: **versionCode 257 / versionName 2.9.257**
Worker identity: **V-257 / 2.9.257**

## Why this hotfix exists
The user-provided runtime video shows Android launching MY SHOP, displaying the system splash, and then returning to the home screen before the app UI appears. That is a startup runtime failure, not a normal network/ad delay.

## Focused fix
- Removed the new V-256 global `Application`/`UiPolish` lifecycle hook from app startup. V-256's screen-specific UI/icon/readability changes remain in the actual activities.
- Restored the proven V-255 `StartupAdActivity` runtime flow as the base startup implementation.
- Kept MY SHOP branded launcher background so Android does not need a plain white preview.
- Simplified Android 12+ splash configuration to the branded background and default app icon instead of extra custom splash attributes.
- Added a defensive fail-open around startup UI creation: if startup/ad UI throws unexpectedly, the app attempts to open Login rather than closing.
- Preserved V-256 Problems 1, 2, 4 and 5 changes and the Admin startup-ad feature path.

## Validation performed in this workspace
- Android manifest/resources XML parse: PASS.
- Worker JavaScript syntax (`node --check`): PASS.
- V-257 identity/version markers: PASS.
- ZIP integrity test: PASS after packaging.

## Required device validation
Build the V-257 APK with the existing GitHub Actions workflow and install it. Runtime proof requires a real Android launch test because this workspace has no Android SDK/emulator/device logcat.
