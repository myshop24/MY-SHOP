# MY SHOP V-284 — Premium Audio Live Room Batch

This release is additive and based on V-283. Existing Dashboard/Feed/Profile/Friends/Followers/Notifications/Messenger/Admin/Wallet/Badge/Startup Media behavior is intentionally preserved.

## Batch implemented
1. Go Live type selector: Audio Live / Video Live.
2. Video Live remains OFF and shows `Video Live — Coming Soon`; Audio Live is available.
3. 12-seat model preserved: Seat 1 Host; Seats 2–12 speaker sofas.
4. Empty speaker seats use sofa-style presentation; occupied seats show user identity/mic state.
5. Host stays fixed at the upper-left Host card.
6. Center premium Special Guest Spotlight; only Host can promote/remove a seated speaker.
7. Host/Special Guest/Speaker display supports Name, ID, Level, Coin and Gold Coin from backend room state.
8. Request → Accept/Decline → first available speaker seat remains backend-authoritative.
9. Viewer/listener count is de-duplicated with viewer heartbeat records; stale viewer records self-expire.
10. Live room resilience: 5-second presence/state heartbeat, weak-network reconnect status, host-end cleanup of seats/requests/viewers/meta, and bottom controls arranged in two fit-safe rows.

## Security / ownership
Live room state remains server authoritative. No client-only permission is treated as security. No RTC secret is embedded in the APK.

## Not yet claimed
Real Agora/equivalent RTC audio transport is not included in this batch. The app/backend live-room foundation is prepared for that next stage.
