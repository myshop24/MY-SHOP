# MY SHOP V-307 — 32 Point QA Checklist

Legend: **SOURCE FIXED** = implemented/guarded in this package. **PRESERVED** = existing working code intentionally retained. **DEVICE/BACKEND QA** = final production/device behavior still requires the release APK + production Worker test.

1. Live End server-confirmed — **SOURCE FIXED**. `/v1/live/end` confirms inactive presence before closing UI.
2. Viewer/Peak count — **SOURCE FIXED**. Active viewers are recounted and peak updated; **DEVICE/BACKEND QA** for production concurrency.
3. Discover/Join Live endless loading — **SOURCE FIXED**. Cache-first + empty/retry state.
4. Store/Coin transparency — **SOURCE FIXED**. Opaque window/root background.
5. Photos/media count but blank grid — **SOURCE FIXED/POLISHED**. Cache-first media grid and nonblank unavailable-media state; **DEVICE/BACKEND QA** with real R2 URLs.
6. Store categories cut off — **SOURCE FIXED**. Compact category chips/titles.
7. Long loading states — **SOURCE FIXED** in Live/Store/Profile/Inbox via cache-first/empty/retry behavior; **DEVICE QA** for network conditions.
8. Blank purple/startup bridge — **PRESERVED** existing branded StartupAd dark bridge; **DEVICE QA** for cold start/navigation transitions.
9. Live banner title crowding — **SOURCE FIXED** with compact single Live Home entry.
10. Dashboard Live banner → Live Home; Go/Join inside — **SOURCE FIXED**.
11. Dashboard density/polish — **SOURCE FIXED LOCALLY** without structural redesign.
12. Quick Link labels cut — **SOURCE FIXED** with two-line labels.
13. Bottom nav too high/big — **SOURCE FIXED** compact/lower safe-area placement while preserving navigation.
14. New User card crowding — **PRESERVED/LOCAL POLISH**; backend behavior retained; **DEVICE QA** across screen sizes.
15. Admin/settings ghost overlay — **PRESERVED** opaque Admin root; **DEVICE QA** on exact transition seen in recording.
16. Message giant Refresh — **SOURCE FIXED** compact refresh while real-time polling remains.
17. Raw timestamps — **SOURCE FIXED** with `UiTime.relative` in Inbox/Chat/Profile/Feed/comments.
18. Conversation row compact/social — **PRESERVED/POLISHED**; cached real-time rows retained.
19. Search / New Message — **SOURCE FIXED**.
20. Profile overall good structure — **PRESERVED**; no redesign.
21. Email privacy — **PRESERVED + GUARDED**. Public profile backend does not expose email.
22. Timeline social structure — **PRESERVED** existing react/comment/share plus relative time; **DEVICE QA** for interaction UI.
23. Timeline ↔ Photos media sync — **SOURCE FIXED/PRESERVED** through same profile content/media endpoint + cache; **BACKEND QA** with production posts.
24. Photos/Videos grid + viewer + Save/Download — **SOURCE FIXED**; **DEVICE QA** for Android storage/download behavior.
25. Host separate + 12 User Seats — **PRESERVED/VALIDATED**. No seat redesign.
26. Live connection state clearer — **PRESERVED/POLISHED**; **DEVICE QA** with Agora/network reconnect.
27. Viewer count clearer — **SOURCE FIXED** visible viewer + Peak strip.
28. Join Request badge/panel — **PRESERVED/VALIDATED IN SOURCE**; **LIVE MULTI-DEVICE QA** required.
29. Host Invite to Call — **PRESERVED/VALIDATED IN SOURCE**; **LIVE MULTI-DEVICE QA** required.
30. Persistent mic state — **PRESERVED** current mic UI/state; **AGORA DEVICE QA** required.
31. Live comments temporary only — **PRESERVED/VALIDATED**; no R2 persistence in Live comment path.
32. Live Summary backend-confirmed — **SOURCE FIXED**. Summary is requested after confirmed server close, enriched backend summary preferred; **BACKEND QA** for real gifts/followers/viewer totals.

## Protected regression checks
- Cloudflare D1/R2 bindings/schema/storage behavior not renamed or removed.
- Permanent signing/PK and release workflow not changed.
- V-306 Profile/Host/Locker corrections carried forward.
- Main Dashboard approved architecture not redesigned.
- Existing Friend/Follow, Notifications, Feed, Admin CRUD and Live moderation code preserved unless directly touched above.
