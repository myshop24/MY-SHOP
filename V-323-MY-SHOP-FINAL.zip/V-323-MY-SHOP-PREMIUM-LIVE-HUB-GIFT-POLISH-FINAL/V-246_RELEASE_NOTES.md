# MY SHOP V-246

Priority implementation pass after V-245 verification feedback.

1. Admin Hub now exposes visible dedicated entries for Animated Badge/User ID Grant, ROYAL/VVIP/VIP Membership, Coin/Gold Coin Catalog, and App Open Image/Video Ad instead of hiding the work behind one generic wallet row.
2. Dynamic catalog editor remains backend-authoritative: animation asset upload to R2, preview/animation URL, money/Coin price, units, duration, benefits, priority, enable/disable, limited edition, and manual User ID grant.
3. Premium user pages remain separate and catalog-driven (ROYAL -> VVIP -> VIP), with animated emblem, price/duration and privileges.
4. Startup ad manager remains remote/admin-driven; feed media fixes remain included from V-245 and are carried forward for device verification.
5. Coin and Gold Coin remain separate catalog item types and wallet grants.

Do not call this device-verified until the GitHub APK is built and tested on-device.
