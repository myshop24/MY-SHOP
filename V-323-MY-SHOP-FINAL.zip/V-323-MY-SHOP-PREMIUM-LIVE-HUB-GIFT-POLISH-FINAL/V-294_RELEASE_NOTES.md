# MY SHOP Developer Handoff — V-294

## Current version
- Build: **V-294**
- Version name: **2.9.294**
- Base: V-293

## Completed in V-294
1. Admin-configurable platform fee/VAT foundation for Gift and user-to-user Coin/Gold transfer, with immutable value ledger and sender→receiver audit fields.
2. Fixed Main Admin IDs remain 0001/0002/0003; moderator/room-admin separation from V-293 is preserved.
3. Public Live Gift Summary + Top Supporters (Top 1–20) API and persistent Host live summary enrichment.
4. Comment composer Emoji button is now ACTUALLY attached inside the input at the far-right; native IME/emoji-capable keyboard is opened.
5. Paid Highlight Comment: Admin price (default 1000 Coin), Main Admin + assigned MY SHOP Moderators free, server-authoritative deduction, queue data, RIGHT→LEFT middle-screen animation.
6. Pinned Host Notice remains supported.
7. Slow Mode + duplicate-comment anti-spam backend foundation.
8. Gift Combo count/streak foundation.
9. Top Supporter rank data for badges/priority rendering.
10. Royal/VVIP/VIP tier lookup foundation for entry effects / priority.
11. Live Summary enriched with total gift value/count/supporters/comments and Top 20.
12. Moderation audit log foundation for Main Admin review.
13. Gift/highlight queue-compatible event data to avoid overlapping premium effects.

## Locked behavior preserved
- Host + 10 speaker sofas (5+5), Guitar Blue, no-scroll single-screen.
- Host sees End; Audience sees Join.
- Right rail Request → Gift → React → Share with V-292 spacing.
- Main Admin IDs: 0001, 0002, 0003.
- Up to 5 MY SHOP Moderators and up to 5 Host Room Admins.
- Room Admin remains room-scoped and does not gain global block/permanent-ban power.
- Muted user is listen + gift only; no comments or join requests.

## NEXT START HERE
1. Deploy migration `0011_v294_finance_highlight_summary_premium.sql` before/with Worker deployment.
2. Wire Main Admin UI screens for Finance Config/Summary, Moderator Audit, and full Top Supporter/Gift Summary cards.
3. Finish production animated Gift renderer (Lottie/WebM), sound playback, full animation queue, and Gift receiver picker UI.
4. Add richer live participant priority rendering: current-day/session supporters, then present historical Top supporters, then Royal → VVIP → VIP → others.
5. Real RTC/Agora audio is still pending; do not claim RTC production readiness.

## Verification limitations
- Worker JavaScript syntax should be checked with `node --check`.
- Migration should be tested in SQLite against a representative V-293 schema.
- AndroidManifest should be XML parsed.
- No APK compile claim unless Gradle wrapper/build environment is actually available and succeeds.
