# MY SHOP V-303 — Live Room Interaction Fixes

Implemented from the user's Problem #1 video review:

1. Live duration timer now displays HH:MM:SS and no longer appears frozen during the first minute.
2. Live comments render as separate premium bubbles/cards instead of one shared box.
3. Comment text is larger and begins on one line as `Name  LV.x : comment`, wrapping naturally only when needed.
4. Gift tap opens an immediate loading panel; the catalog is cached for instant subsequent opens.
5. Muted microphone state shows a red crossed-mic indicator on the local mic control and on occupied speaker/host avatars.
6. Join Requests appear to the Host as a compact inline request card with Accept/Decline, while the full request list remains available. Backend request lookup is hardened for current/legacy session-id rows.
7. Active speaker avatar ring pulses when `speaking=1`. A lightweight local voice-activity detector publishes speaking state for Host/Speaker clients when microphone permission is granted.
8. Live room refresh cadence tightened from 2.0s to 1.2s for request/state responsiveness.

Regression safety: 12-seat layout, existing Live invite/request APIs, gifts, themes, D1/R2 bindings, signing workflow, and dashboard navigation are preserved.
