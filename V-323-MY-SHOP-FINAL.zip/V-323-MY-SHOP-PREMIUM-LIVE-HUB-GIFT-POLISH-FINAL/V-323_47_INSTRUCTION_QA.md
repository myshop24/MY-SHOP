# V-323 — 47 Instruction QA Matrix

> `SOURCE PASS` means the required source path/check is present. `DEVICE QA` / `CLOUD+DEVICE QA` is intentionally not claimed as runtime PASS until a real build, deployed Worker/RTC/FCM, and Android device test are performed.

| # | Requirement | Status | Note |
|---:|---|---|---|
| 1 | Premium finishing is implemented as a dedicated Live Room polish layer | SOURCE PASS / DEVICE QA | Visual quality still requires device review. |
| 2 | Reference quality used without copying another app | SOURCE PASS / DEVICE QA | Original MY SHOP UI/code preserved. |
| 3 | MY SHOP navy/purple/blue/cyan with premium gold treatment | SOURCE PASS / DEVICE QA |  |
| 4 | 12-seat structure preserved | SOURCE PASS |  |
| 5 | Guest seat arrangement remains 6 + 6 | SOURCE PASS |  |
| 6 | Flat sofa replaced with premium seat artwork | SOURCE PASS / DEVICE QA |  |
| 7 | Seat depth/glow/shadow/elevation treatment | SOURCE PASS / DEVICE QA |  |
| 8 | Empty/occupied seats have distinct rendering | SOURCE PASS / DEVICE QA |  |
| 9 | Occupied seat profile/name/level/status rendering | SOURCE PASS / DEVICE QA |  |
| 10 | Host area remains prominent and separate | SOURCE PASS / DEVICE QA |  |
| 11 | Seat area blended with layered background | SOURCE PASS / DEVICE QA |  |
| 12 | Reduced flat-box look through gradient/glass layers | SOURCE PASS / DEVICE QA |  |
| 13 | Layered live ambience/background depth | SOURCE PASS / DEVICE QA |  |
| 14 | Top room/profile info compact premium area | SOURCE PASS / DEVICE QA |  |
| 15 | Announcement/host/comments/controls share design language | SOURCE PASS / DEVICE QA |  |
| 16 | Consistent typography/radius/shadow/glow component helpers | SOURCE PASS / DEVICE QA |  |
| 17 | Comment/Send/Mic/End controls use premium component styling | SOURCE PASS / DEVICE QA |  |
| 18 | Gift Store premium dark/glass treatment | SOURCE PASS / DEVICE QA |  |
| 19 | Gift Store avoids nested heavy form styling | SOURCE PASS / DEVICE QA |  |
| 20 | Gift art receives larger tile/visual space | SOURCE PASS / DEVICE QA |  |
| 21 | Animated/3D-style remote asset support preserved | SOURCE PASS |  |
| 22 | Gift art is rendered as prominent image/animation | SOURCE PASS / DEVICE QA |  |
| 23 | Gift categories/tabs premium navigation | SOURCE PASS / DEVICE QA |  |
| 24 | Coin and Gold Coin catalogs remain separate | SOURCE PASS |  |
| 25 | Admin gift Add/Edit/Delete/Save/Publish/price/order preserved | SOURCE PASS |  |
| 26 | Gift effect footprint scales to meaningful screen size | SOURCE PASS / DEVICE QA |  |
| 27 | Multi-stage animation + particles/glow + exit | SOURCE PASS / DEVICE QA |  |
| 28 | Admin Animation Scale 0-100 drives actual effect size | SOURCE PASS |  |
| 29 | Admin Sound Volume 0-100 drives playback | SOURCE PASS |  |
| 30 | Successful send dismisses store and starts local effect immediately after backend ack | SOURCE PASS / DEVICE QA | Network latency still requires device/backend measurement. |
| 31 | Gift activity appears in session live comments/activity | SOURCE PASS |  |
| 32 | Main gift overlay contains no gift-name/sender banner | SOURCE PASS |  |
| 33 | Gift sound strengthened safely while respecting configured volume | SOURCE PASS / DEVICE QA | Perceived loudness/clipping requires device/audio QA. |
| 34 | INVALID_REQUEST is converted to friendly user message | SOURCE PASS |  |
| 35 | Join Request is session-scoped and reaches Host request panel | SOURCE PASS / DEVICE QA |  |
| 36 | Host Accept promotes user to speaker/free guest seat | SOURCE PASS / DEVICE QA |  |
| 37 | Host can move accepted/invited speaker to specific guest seat | SOURCE PASS / DEVICE QA |  |
| 38 | Host can Invite to Call from audience | SOURCE PASS / DEVICE QA |  |
| 39 | Invite Accept/Decline/expiry keeps role correctly | SOURCE PASS / DEVICE QA |  |
| 40 | Seat/role/mic state supplied through shared room state | SOURCE PASS / DEVICE QA |  |
| 41 | Join/invite validation and duplicate/idempotency handling | SOURCE PASS |  |
| 42 | Own comment appears optimistically before server refresh | SOURCE PASS |  |
| 43 | Comments use real-time room refresh / ephemeral endpoint | SOURCE PASS / DEVICE QA |  |
| 44 | Comment board skips unnecessary full rebuild to reduce flicker | SOURCE PASS / DEVICE QA |  |
| 45 | Current Live join activity is session-scoped and chronologically rendered | SOURCE PASS |  |
| 46 | Previous Live transient activity isolated/discarded by unique session | SOURCE PASS |  |
| 47 | Messenger/WhatsApp-style real message push notification foundation | SOURCE PASS / CLOUD+DEVICE QA | Requires Firebase secrets, Worker deploy, background/lock-screen device test; force-stop behavior remains Android controlled. |

**Source checks: 47/47 present.**

## Runtime gates
- Local container does not currently contain Gradle 8.11.1 / gradle-wrapper.jar, so an APK compile cannot honestly be marked PASS here.
- The included GitHub workflow installs Gradle 8.11.1 and now requires the V-323 Firebase build secrets before release.
- Production push requires `FCM_SERVICE_ACCOUNT_JSON` as a Worker secret; no secret values are included in this source ZIP.
- Live RTC/seat/mic timing, animation appearance, audio loudness and notification behavior require real-device/deployed-backend QA.
