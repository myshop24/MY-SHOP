# MY SHOP V-308 — Google Play Compliance + Safety Update

Base: V-307 Full Stability + Live Home. The approved Main Dashboard structure, Live Home flow, Host + 12 user seats, Feed, Profile, D1/R2 bindings and owner signing workflow are preserved.

## Implemented

- Android version bumped to `versionCode 308` / `versionName 2.9.308`.
- Google Play Billing Library `9.1.0` added for user-paid digital goods.
- Coin / Gold Coin / Badge / Membership real-money purchase UI routes to Google Play checkout.
- Legacy direct real-money digital-purchase Worker endpoints now reject with `DIRECT_DIGITAL_PAYMENT_DISABLED`.
- Existing Coin-balance purchases remain internal virtual-currency spending; bKash/Nagad remain only for user withdrawal/payout requests.
- Paid Admin catalog items require a Google Play Product ID.
- Purchase tokens are verified server-side using Android Publisher API before any entitlement is granted.
- Entitlement + unique purchase-token record use one D1 batch to reduce duplicate-credit/replay risk.
- In-app `Delete My Account` added under Settings & Privacy with password + `DELETE` confirmation.
- Public Worker pages added: `/privacy`, `/terms`, `/account-deletion`.
- External account-deletion request form added and stored for owner review.
- Registration consent is default-unchecked; Terms/Privacy/Delete information is directly accessible.
- User Report + Block actions added to Profile, Feed/Comments, Chat and Live UI.
- Block is backend-enforced for messages, Feed/Video visibility/interactions, Friend/Follow and profile access.
- Admin Safety board added for safety reports and external deletion-request review.
- Startup ad retains visible Skip control and existing 1–4 second Admin duration control.
- Android backup disabled (`allowBackup=false`) to reduce accidental credential/session backup exposure.
- Worker deep health reports whether Play Billing secret is configured without exposing the secret.
- GitHub release workflow now requires `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` and deploys it into the same immutable Worker version.

## Deliberately preserved

- Current MY SHOP Main Dashboard design/flow.
- Dashboard → Live Home → Go Live / Join Live flow.
- Host position + 12 User Seat live-room model.
- Audio Live comment ephemerality.
- Permanent MY SHOP numeric ID non-reassignment rule.
- Existing Cloudflare D1 database and R2 bucket names/bindings.
- Admin-only CRUD and local Admin Locker protections.
- Existing permanent Android signing-key workflow.

## Manual production setup still required

See `V-308_PLAY_CONSOLE_SETUP.md` and `V-308_GOOGLE_PLAY_COMPLIANCE_CHECKLIST.md`. Code cannot create Play Console products, Google service-account permissions, Play declarations, or review credentials automatically.
