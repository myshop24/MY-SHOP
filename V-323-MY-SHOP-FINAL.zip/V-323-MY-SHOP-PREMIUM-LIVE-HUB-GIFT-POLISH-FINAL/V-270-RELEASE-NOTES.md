# MY SHOP V-270 — Source Identity Gate Fix

- Corrected permanent workflow identity: `SOURCE_BUILD_ID.txt` is exactly `MY SHOP V-270`.
- Android identity: `versionCode 270`, `versionName 2.9.270`.
- Worker health/build identity: `2.9.270` / `V-270`.
- Preserves all V-269 approved premium Dashboard polish, right-to-left Breaking News behavior, Admin font/color controls, Live/New User cards, MY Feed and existing functionality.
- This release supersedes V-269 after its source identity mismatch at the GitHub Actions gate.
