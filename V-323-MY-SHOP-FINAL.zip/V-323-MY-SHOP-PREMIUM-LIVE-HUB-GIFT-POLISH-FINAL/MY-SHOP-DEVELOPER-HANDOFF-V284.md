# MY SHOP Developer Handoff — V-284

Current checkpoint: V-284.
Base: V-283 Audio Live Room Visibility Fix.

Completed in this checkpoint: Go Live type selector, Video Coming Soon gate, premium Host-left + Special Guest-center layout, sofa speaker seats, live identity/wallet display, Host Special Guest actions, request/seat flow preservation, de-duplicated viewer heartbeat/count, room cleanup/reconnect status, and fit-safe live controls.

Preservation rule: do not redesign or remove the approved Dashboard or existing Feed/Profile/Friends/Followers/Notification/Messenger/Admin/Wallet/Badge/Startup Media functionality. Keep Seat 1 Host and Seats 2–12 speaker architecture unless owner explicitly changes it.

Next major checkpoint: integrate secure Agora/equivalent RTC audio transport with server-issued token/session flow and real-device quality tests. Keep Video Live OFF until Audio Live is stable and approved.

Identity: SOURCE_BUILD_ID=MY SHOP V-284; SOURCE_VERSION_NAME=2.9.284; Android versionCode=284; versionName=2.9.284; Worker health build=V-284/version=2.9.284.
