# V-272 Verification Checklist

- [x] SOURCE_BUILD_ID = MY SHOP V-272
- [x] Android versionCode = 272
- [x] Android versionName = 2.9.272
- [x] Worker health identity = V-272 / 2.9.272
- [x] Add Friend card parent height exceeds content height (no bottom clipping)
- [x] Breaking News A−/A+ and current sp controls present in source
- [x] Breaking News text/background visual pickers + HEX present in source
- [x] Dashboard palette save + fetch + ThemeConfig cache + recreate path present
- [x] Authenticated /v1/auth/password/change endpoint verifies current password
- [x] Forgot/reset continues to verify security answer and invalidates sessions
- [x] Account Password / Reset button opens working dialogs instead of placeholder Toast
