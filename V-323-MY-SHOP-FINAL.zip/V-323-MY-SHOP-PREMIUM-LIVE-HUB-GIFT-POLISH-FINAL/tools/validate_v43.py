from pathlib import Path
import json, re, sys
ROOT = Path(__file__).resolve().parents[1]
errors=[]
b=ROOT/'app/build.gradle'
bs=b.read_text(encoding='utf-8')
if 'versionCode 43' not in bs or "versionName '2.9.43'" not in bs: errors.append('Version is not 28/2.15.0')
if "applicationId 'com.myshop.app'" not in bs: errors.append('applicationId mismatch')
uid=(ROOT/'app/src/main/java/com/myshop/app/UserIdManager.java').read_text(encoding='utf-8')
if 'RANDOM' in uid or 'Random' in uid: errors.append('Random ID allocation remains')
if 'FIRST_ID = 100' not in uid: errors.append('Sequential start 0100 missing')
acct=(ROOT/'app/src/main/java/com/myshop/app/AccountStore.java').read_text(encoding='utf-8')
if 'canCreate' not in acct: errors.append('Duplicate account preflight missing')
reg=(ROOT/'app/src/main/java/com/myshop/app/RegisterActivity.java').read_text(encoding='utf-8')
if 'peekNextLocalId' not in reg or 'commitLocalAllocation' not in reg: errors.append('Registration serial allocation flow missing')
for p in ROOT.rglob('*.java'):
    txt=p.read_text(encoding='utf-8',errors='ignore')
    for bad in ['OWNER_EMAIL_1_REMOVED','OWNER_EMAIL_2_REMOVED','OWNER_EMAIL_2_REMOVED','OWNER_MOBILE_REMOVED']:
        if bad in txt: errors.append(f'Admin identifier embedded in Java: {bad}')
manifest=(ROOT/'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
if 'android:name=".LoginActivity" android:exported="true"' not in manifest: errors.append('LoginActivity launcher missing')
# Java R.id references must exist in XML resources.
ids=set()
for xml in (ROOT/'app/src/main/res').rglob('*.xml'):
    txt=xml.read_text(encoding='utf-8', errors='ignore')
    ids.update(re.findall(r'android:id=\"@\+id/([A-Za-z0-9_]+)\"', txt))
    ids.update(re.findall(r'@id/([A-Za-z0-9_]+)', txt))
for pth in (ROOT/'app/src/main/java').rglob('*.java'):
    txt=pth.read_text(encoding='utf-8', errors='ignore')
    for rid in re.findall(r'R\.id\.([A-Za-z0-9_]+)', txt):
        if rid not in ids:
            errors.append(f'Missing resource id: {rid} referenced by {pth}')

login=(ROOT/'app/src/main/java/com/myshop/app/LoginActivity.java').read_text(encoding='utf-8')
if 'import android.widget.Button;' not in login:
    errors.append('LoginActivity Button import missing')
if 'showLoginFallback' not in login or 'setContentView(scroll)' not in login:
    errors.append('LoginActivity safe fallback missing')
if 'finish();' not in login:
    errors.append('LoginActivity does not finish after successful MainActivity transition')

if errors:
 print('VALIDATION FAILED'); print('\n'.join(errors)); sys.exit(1)
print('V-43 static validation OK')
