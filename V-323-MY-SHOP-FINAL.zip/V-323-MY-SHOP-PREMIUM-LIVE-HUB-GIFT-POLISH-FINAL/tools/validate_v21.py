from pathlib import Path
import json, re, sys
ROOT = Path(__file__).resolve().parents[1]
errors = []
required = [
    ROOT / 'app/build.gradle',
    ROOT / 'app/src/main/AndroidManifest.xml',
    ROOT / 'app/src/main/assets/feature_config.json',
    ROOT / 'app/src/main/assets/final_feature_inventory.json',
]
for p in required:
    if not p.exists():
        errors.append(f'Missing: {p}')
for p in ROOT.rglob('*.json'):
    if '.git' in p.parts or 'build' in p.parts:
        continue
    try:
        json.loads(p.read_text(encoding='utf-8'))
    except Exception as e:
        errors.append(f'Invalid JSON {p}: {e}')
text = '\n'.join(p.read_text(encoding='utf-8', errors='ignore') for p in ROOT.rglob('*.java'))
for bad in ['OWNER_EMAIL_1_REMOVED', 'OWNER_EMAIL_2_REMOVED', 'OWNER_MOBILE_REMOVED']:
    if bad in text:
        errors.append(f'Admin identifier embedded in Java: {bad}')
b = ROOT / 'app/build.gradle'
bs = b.read_text(encoding='utf-8')
if 'versionCode 21' not in bs or "versionName '2.10.0'" not in bs:
    errors.append('Version is not 21/2.10.0')
if "applicationId 'com.myshop.app'" not in bs:
    errors.append('applicationId is not com.myshop.app')
if 'applicationIdSuffix' in bs:
    errors.append('applicationIdSuffix must not be present for V-21')
inv = json.loads((ROOT/'app/src/main/assets/final_feature_inventory.json').read_text(encoding='utf-8'))
if inv.get('version') != 21:
    errors.append('Inventory version mismatch')
if errors:
    print('VALIDATION FAILED')
    print('\n'.join(errors))
    sys.exit(1)
print('V-21 validation OK')
