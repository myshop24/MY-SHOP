from pathlib import Path
import json, re, zipfile

ROOT = Path(__file__).resolve().parents[1]
required = [
    'settings.gradle','build.gradle','gradle.properties','app/build.gradle',
    'app/src/main/AndroidManifest.xml','app/src/main/java/com/myshop/app/MainActivity.java',
    'app/src/main/java/com/myshop/app/LoginActivity.java','app/src/main/java/com/myshop/app/RegisterActivity.java',
    'app/src/main/assets/feature_config.json','backend/contracts/ADMIN_AUTH_CONTRACT.json',
    'backend/roles/ROLE_CONTRACT.json','backend/remote-config/BANNER_SCHEMA.json',
    '.github/workflows/android-apk.yml'
]
for item in required:
    assert (ROOT/item).is_file(), f'Missing required file: {item}'

# Validate JSON
for p in ROOT.rglob('*.json'):
    if 'build' in p.parts: continue
    with p.open(encoding='utf-8') as f: json.load(f)

# Version consistency
app_gradle=(ROOT/'app/build.gradle').read_text(encoding='utf-8')
assert re.search(r'versionCode\s+17\b', app_gradle)
assert "versionName '2.6.0'" in app_gradle

# Banner safety
cfg=json.loads((ROOT/'app/src/main/assets/feature_config.json').read_text(encoding='utf-8'))
max_banners=int(cfg.get('maxBannersPerSection', 6))
assert 1 <= max_banners <= 6
assert int(cfg.get('sliderIntervalMs', 3500)) >= 1000

# No admin identifiers in app source
source_ext={'.java','.kt','.xml','.gradle','.json'}
for p in ROOT.rglob('*'):
    if p.suffix in source_ext and 'build' not in p.parts and '.git' not in p.parts and 'backend' not in p.parts:
        s=p.read_text(encoding='utf-8', errors='ignore').lower()
        for secret in ('OWNER_EMAIL_1_REMOVED','OWNER_EMAIL_2_REMOVED','OWNER_MOBILE_REMOVED'):
            assert secret not in s, f'Credential literal found in {p}'

# CI safeguards
wf=(ROOT/'.github/workflows/android-apk.yml').read_text(encoding='utf-8')
for needle in ['android-actions/setup-android@v3','platforms;android-35','build-tools;35.0.0',':app:lintDebug',':app:assembleDebug',':app:assembleRelease','unzip -t','actions/upload-artifact@v4']:
    assert needle in wf, f'Missing build safeguard: {needle}'

print('V-17 validation OK')
