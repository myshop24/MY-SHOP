import json, re, sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
errors=[]
def req(rel):
    p=root/rel
    if not p.exists(): errors.append(f'Missing: {rel}')
    return p
for rel in ['settings.gradle','build.gradle','app/build.gradle','app/src/main/AndroidManifest.xml','app/src/main/assets/feature_config.json','.github/workflows/android-apk.yml']:
    req(rel)
for p in (root/'backend').rglob('*.json'):
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'Invalid JSON {p.relative_to(root)}: {e}')
try:
    cfg=json.loads((root/'app/src/main/assets/feature_config.json').read_text(encoding='utf-8'))
    banners=cfg.get('banners',[])
    if len(banners)>6: errors.append('More than 6 banners in local config')
    if cfg.get('maxBannersPerSection',6)>6: errors.append('maxBannersPerSection exceeds 6')
    interval=cfg.get('sliderIntervalMs',3500)
    if not 1000 <= interval <= 60000: errors.append('sliderIntervalMs out of safe range')
except Exception as e: errors.append(f'Invalid feature config: {e}')
gradle=(root/'app/build.gradle').read_text(encoding='utf-8')
m=re.search(r'versionCode\s+(\d+)',gradle); 
if not m or m.group(1)!='13': errors.append('versionCode must be 13')
if 'OWNER_EMAIL_1_REMOVED' in ''.join(p.read_text(errors='ignore') for p in (root/'app/src/main').rglob('*') if p.is_file()):
    errors.append('Admin email must not be hard-coded in app source/resources')
print('V-13 validation:', 'OK' if not errors else 'FAILED')
if errors:
    for e in errors: print(' -',e)
    sys.exit(1)
