from pathlib import Path
import re, subprocess, sys, hashlib, xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
BASE=Path('/mnt/data/v303_pristine/V-303-MY-SHOP-LIVE-ROOM-INTERACTION-FIX-FINAL')
checks=[]
def ck(name, ok, detail=''):
    checks.append((name,bool(ok),detail))

def text(rel): return (ROOT/rel).read_text(encoding='utf-8')

audio=text('app/src/main/java/com/myshop/app/AudioLiveRoomActivity.java')
backend=text('backend/worker/src/index.js')
bc=text('app/src/main/java/com/myshop/app/BackendClient.java')
creator=text('app/src/main/java/com/myshop/app/CreatorCenterActivity.java')
livelist=text('app/src/main/java/com/myshop/app/LiveListActivity.java')
main=text('app/src/main/java/com/myshop/app/MainActivity.java')
profile=text('app/src/main/java/com/myshop/app/UserProfileActivity.java')
manifest=text('app/src/main/AndroidManifest.xml')

ck('identity build', text('SOURCE_BUILD_ID.txt').strip()=='MY SHOP V-304')
ck('identity version', text('SOURCE_VERSION_NAME.txt').strip()=='2.9.304')
gradle=text('app/build.gradle')
ck('android version', 'versionCode 304' in gradle and 'versionName "2.9.304"' in gradle)
ck('applicationId preserved', "applicationId 'com.myshop.app'" in gradle)
ck('worker markers', backend.count("version:'2.9.304',build:'V-304'")>=2)

# 30 requested source paths
feature_patterns=[
('01 Instant Live Comment Send', [('a','sendLiveComment('),('a','pendingComments.put')]),
('02 Duplicate Comment Protection', [('a','commentSending'),('b','client_nonce'),('b','duplicateSuppressed')]),
('03 Temporary Live Comments', [('b','DELETE FROM myshop_live_comments WHERE host_id=? AND session_id=?'),('b','LIMIT 80'),('b',"datetime(created_at)<datetime('now','-1 hour')")]),
('04 Premium Comment Bubbles', [('a','LV."+level+" : '),('a','commentsList.addView')]),
('05 Fresh Session Timer', [('a','activeSessionId'),('a','serverElapsedSec'),('b','elapsedSeconds')]),
('06 Rejoin/End Timer Isolation', [('a','activeSessionId="";serverElapsedSec=0;serverElapsedSyncMs=0'),('b','sessionId=crypto.randomUUID()')]),
('07 Instant Gift Panel', [('a','prefetchGiftCatalog()'),('a','cachedGiftCatalog')]),
('08 Join Request Flow', [('a','Join Requests'),('bc','liveRequestAction'),('b','liveRequestAction')]),
('09 Host Invite Flow', [('a','Invite to Call'),('bc','liveInviteAction'),('b','liveInviteAction')]),
('10 Red Crossed Mic', [('a','🎙✕'),('a','Color.rgb(255,82,94)')]),
('11 Active Speaker Animation', [('a','ObjectAnimator.ofFloat(frame,"scaleX"'),('a','speaking')]),
('12 Live Goal', [('a','Live Goal'),('b','goal_type'),('b','goal_target')]),
('13 Hourly Top / Top Supporter', [('b','hourlyTop'),('b','topSupporters'),('a','hourlyTop')]),
('14 VIP/VVIP/ROYAL Experience', [('a','ROYAL'),('a','VVIP'),('a','VIP'),('b','myshop_live_entry_events')]),
('15 Mini Profile Card', [('a','showMiniProfile'),('a','Follow'),('a','Message')]),
('16 Host Moderator System', [('a','Add as Room Admin'),('b','myshop_live_room_admins')]),
('17 Pinned Notice', [('a','Pinned announcement'),('b','pinned_message')]),
('18 Quality + Reconnect', [('a','Reconnecting…'),('a','networkQuality()'),('b','network_quality')]),
('19 Welcome / Rules', [('a','Welcome / Rules'),('b','welcome_message')]),
('20 End Summary + Follow', [('a','LIVE SUMMARY'),('a','Follow Host'),('b','newFollowers')]),
('21 Fan Club', [('a','Fan Club'),('b','myshop_live_fan_club')]),
('22 Room + Host Level', [('a','hostLiveLevel'),('a','roomLevel'),('b','hostLiveLevel'),('b','roomLevel')]),
('23 Advanced Gifts', [('a','COMBO'),('a','showGiftEffect'),('b','combo')]),
('24 Creator Center', [('creator','Creator Center'),('b','liveCreatorCenter'),('profile','CreatorCenterActivity')]),
('25 Live Shop', [('a','LIVE SHOP'),('b','pinned_product_id'),('a','Pin Shop Item')]),
('26 Discover + Ranking', [('livelist','DISCOVER LIVE'),('livelist','TOP_SUPPORTERS'),('b','liveDiscover')]),
('27 Dashboard Premium Hierarchy', [('main','Go Live  •  Connect  •  Shop  •  Earn'),('main','LIVE STREAMING')]),
('28 PK/Battle Foundation', [('a','PK / Battle'),('b','myshop_live_pk_rounds'),('b','livePkAction')]),
('29 Achievement/Milestone', [('a','renderMilestones'),('b','milestones'),('creator','ACHIEVEMENTS')]),
('30 Scheduled Live + Reminder', [('a','Schedule Live'),('b','myshop_live_schedules'),('b','myshop_live_reminders'),('b','LIVE_SCHEDULE_START')]),
]
texts={'a':audio,'b':backend,'bc':bc,'creator':creator,'livelist':livelist,'main':main,'profile':profile}
for name,pats in feature_patterns:
    missing=[p for src,p in pats if p not in texts[src]]
    ck(name, not missing, 'missing: '+', '.join(missing) if missing else '')

# 12-seat lock
ck('12-seat architecture', 'CHECK(seat_no BETWEEN 1 AND 12)' in backend and 'int[] counts={6,6}' in audio and 'n<=12' in audio)
ck('creator activity manifest', '.CreatorCenterActivity' in manifest)

# Worker syntax
r=subprocess.run(['node','--check',str(ROOT/'backend/worker/src/index.js')],text=True,capture_output=True)
ck('Worker JavaScript syntax', r.returncode==0, (r.stderr or r.stdout).strip())

# XML parse all source XML
xml_errors=[]
for p in (ROOT/'app/src/main').rglob('*.xml'):
    try: ET.parse(p)
    except Exception as e: xml_errors.append(f'{p.relative_to(ROOT)}: {e}')
ck('Android XML parse', not xml_errors, '; '.join(xml_errors[:5]))

# Java syntax-only proxy: javac has no Android SDK classpath here, so unresolved Android symbols are expected.
changed=[
'AudioLiveRoomActivity.java','BackendClient.java','CreatorCenterActivity.java','LiveListActivity.java','MainActivity.java','UserProfileActivity.java']
java_dir=ROOT/'app/src/main/java/com/myshop/app'
cmd=['javac','-proc:none','-Xmaxerrs','5000']+[str(java_dir/f) for f in changed]
r=subprocess.run(cmd,text=True,capture_output=True)
err=r.stderr
syntax_terms=["';' expected",'illegal start of expression','illegal start of type','reached end of file while parsing',"')' expected", "'}' expected",'not a statement','else without if','unclosed string literal','unclosed character literal']
syntax_hits=[line for line in err.splitlines() if any(term in line for term in syntax_terms)]
ck('Changed Java parser/syntax scan', not syntax_hits, '\n'.join(syntax_hits[:10]))

# Protected config exact hash compared with V-303 source basis if available
protected=['.github/workflows/my-shop-apk.yml','backend/worker/wrangler.toml','settings.gradle','build.gradle','gradle.properties']
if BASE.exists():
    for rel in protected:
        a=(BASE/rel).read_bytes(); b=(ROOT/rel).read_bytes(); ck('Protected unchanged: '+rel,hashlib.sha256(a).digest()==hashlib.sha256(b).digest())
else:
    ck('Protected V-303 comparison',False,'V-303 comparison tree not present')

# app gradle only expected version deltas
if BASE.exists():
    old=text('app/build.gradle') if False else (BASE/'app/build.gradle').read_text()
    normalized=re.sub(r'versionCode\s+304','versionCode 303',gradle)
    normalized=re.sub(r'versionName\s+"2\.9\.304"','versionName "2.9.303"',normalized)
    ck('app/build.gradle version-only delta', normalized==old)

# No R2 use for text live comment handler
comment_section=backend[backend.find('async function liveComment('):backend.find('async function liveThemes(')]
ck('Live comment text does not use R2', 'env.MEDIA' not in comment_section and '.put(' not in comment_section.replace('JSON',''))

failed=[x for x in checks if not x[1]]
for name,ok,detail in checks:
    print(('PASS' if ok else 'FAIL')+' | '+name+((' | '+detail) if detail else ''))
print(f'RESULT | {len(checks)-len(failed)}/{len(checks)} checks passed')
sys.exit(1 if failed else 0)
