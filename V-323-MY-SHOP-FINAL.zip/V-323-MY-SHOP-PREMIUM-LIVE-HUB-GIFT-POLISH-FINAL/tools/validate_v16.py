from pathlib import Path
import json, re, zipfile

ROOT = Path(__file__).resolve().parents[1]
required = [
    'settings.gradle','build.gradle','gradle.properties','app/build.gradle',
    'app/src/main/AndroidManifest.xml','app/src/main/java/com/myshop/app/MainActivity.java',
    'app/src/main/java/com/myshop/app/LoginActivity.java','app/src/main/java/com/myshop/app/RegisterActivity.java',
    'app/src/main/assets/feature_config.json','backend/contracts/ADMIN_AUTH_CONTRACT.json',
    'backend/roles/ROLE_CONTRACT.json','backend/remote-config/BANNER_SCHEMA.json',
    '.github/workflows/android-apk.yml'
]
for item in required:
    assert (ROOT/item).is_file(), f'Missing required file: {item}'

# Validate all JSON
for p in ROOT.rglob('*.json'):
    if 'build' in p.parts: continue
    with p.open(encoding='utf-8') as f: json.load(f)

# Banner maximum and timing
cfg=json.loads((ROOT/'app/src/main/assets/feature_config.json').read_text(encoding='utf-8'))
assert 1 <= int(cfg.get('maxBannersPerSection', 6)) <= 6
assert int(cfg.get('sliderIntervalMs', 3500)) >= 1000

# No obvious admin credential literals in Java/Kotlin/XML
source_ext={'.java','.kt','.xml'}
for p in ROOT.rglob('*'):
    if p.suffix in source_ext and 'build' not in p.parts:
        s=p.read_text(encoding='utf-8', errors='ignore').lower()
        assert 'OWNER_EMAIL_1_REMOVED' not in s
        assert 'OWNER_EMAIL_2_REMOVED' not in s
        assert 'OWNER_MOBILE_REMOVED' not in s

# Workflow must build both APK variants and validate outputs
wf=(ROOT/'.github/workflows/android-apk.yml').read_text(encoding='utf-8')
for needle in [':app:assembleDebug', ':app:assembleRelease', 'unzip -t', 'actions/upload-artifact@v4']:
    assert needle in wf, f'Missing build safeguard: {needle}'

print('V-16 validation OK')
