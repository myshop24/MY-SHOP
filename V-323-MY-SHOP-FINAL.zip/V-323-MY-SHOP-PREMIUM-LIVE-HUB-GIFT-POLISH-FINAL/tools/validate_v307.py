#!/usr/bin/env python3
from pathlib import Path
import re, sys, subprocess, xml.etree.ElementTree as ET
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
def rd(p): return (root/p).read_text(encoding='utf-8')
def check(name, cond):
    print(('PASS' if cond else 'FAIL')+' | '+name)
    return bool(cond)
all_ok=True
app=rd(Path('app/build.gradle')); main=rd(Path('app/src/main/java/com/myshop/app/MainActivity.java')); live=rd(Path('app/src/main/java/com/myshop/app/AudioLiveRoomActivity.java')); worker=rd(Path('backend/worker/src/index.js'))
all_ok &= check('V-307 source identity', rd(Path('SOURCE_BUILD_ID.txt')).strip()=='MY SHOP V-307')
all_ok &= check('Android versionCode 307', bool(re.search(r'\bversionCode\s+307\b',app)))
all_ok &= check('Android versionName 2.9.307', 'versionName "2.9.307"' in app or "versionName '2.9.307'" in app)
all_ok &= check('Worker V-307 health identity', "version:'2.9.307',build:'V-307'" in worker)
ET.parse(root/'app/src/main/AndroidManifest.xml'); all_ok &= check('Android XML parses', True)
manifest=rd(Path('app/src/main/AndroidManifest.xml'))
all_ok &= check('LiveHomeActivity registered', '.LiveHomeActivity' in manifest)
live_section=main[main.index('private View liveStreamingSection()'):main.index('private View liveProfilesSection()')]
all_ok &= check('Dashboard Live section uses Live Home CTA', 'ENTER LIVE HOME' in live_section and 'LiveHomeActivity.class' in live_section)
all_ok &= check('Dashboard does not directly launch Go/Join', 'showPremiumLiveLauncher()' not in live_section and 'LiveListActivity.class' not in live_section)
lh=rd(Path('app/src/main/java/com/myshop/app/LiveHomeActivity.java'))
all_ok &= check('Live Home owns Go Live + Join Live', 'Go Live' in lh and 'Join Live' in lh and 'AudioLiveRoomActivity.class' in lh and 'LiveListActivity.class' in lh)
all_ok &= check('Real Following live category', "category==='FOLLOWING'" in worker and '{"Following","FOLLOWING"}' in lh)
all_ok &= check('Server-confirmed End Live endpoint', "p==='/v1/live/end'" in worker and 'async function liveEnd' in worker and 'BackendClient.endLive' in live)
all_ok &= check('No false local-close message', 'Live closed locally' not in live)
all_ok &= check('Viewer count recalculated from active viewers', 'viewerNow' in worker and 'peak_viewers=MAX' in worker)
all_ok &= check('Viewer + peak visible in room UI', '👁 "+d.optInt("viewerCount",0)+" • Peak "+d.optInt("peakViewers",0)' in live)
all_ok &= check('12-seat architecture preserved', 'for(int seatNo=1;seatNo<=12;seatNo++)' in live or 'for(int n=1;n<=12;n++)' in live or '12-seat' in live)
all_ok &= check('Join request preserved', 'liveSpeakRequest' in live and 'showJoinRequestsDialog' in live)
all_ok &= check('Host invite preserved', 'liveInvite(' in live and 'showIncomingInvite' in live)
all_ok &= check('Temporary live comment path preserved', '/v1/live/comment' in worker and 'env.MEDIA.put' not in worker[worker.index('async function liveComment'):worker.index('async function liveReact')])
store=rd(Path('app/src/main/java/com/myshop/app/StoreActivity.java'))
all_ok &= check('Store opaque + cache-first', 'ColorDrawable(Color.rgb(7,9,22))' in store and 'myshop_store_cache' in store)
all_ok &= check('Compact Store category chips', 'dp(64)' in store and '{"GOLD","GOLD"}' in store)
prof=rd(Path('app/src/main/java/com/myshop/app/ProfileSocialActivity.java')); viewer=rd(Path('app/src/main/java/com/myshop/app/ProfileMediaViewerActivity.java'))
all_ok &= check('Profile media cache/grid preserved', 'myshop_profile_content' in prof and 'renderMediaGrid' in prof)
all_ok &= check('Profile media Save/Download added', 'private void saveMedia()' in viewer and 'DownloadManager' in viewer)
inbox=rd(Path('app/src/main/java/com/myshop/app/InboxActivity.java')); chat=rd(Path('app/src/main/java/com/myshop/app/ChatActivity.java'))
all_ok &= check('Messages search + new message', 'searchMessages()' in inbox and 'newMessage()' in inbox)
all_ok &= check('Relative time across social UI', 'UiTime.relative' in inbox and 'UiTime.relative' in chat and 'UiTime.relative' in prof and 'UiTime.relative' in main)
all_ok &= check('Quick Links no forced single line', 't.setSingleLine(false); t.setMaxLines(2)' in main)
all_ok &= check('Compact bottom nav safe area', 'dp(64),Gravity.BOTTOM' in main and 'bi-dp(6)' in main)
# Public profile route should not expose email.
pp_start=worker.index('async function publicUserProfile') if 'async function publicUserProfile' in worker else -1
pp_end=worker.find('\nasync function',pp_start+1) if pp_start>=0 else -1
public_profile=worker[pp_start:pp_end] if pp_start>=0 else ''
all_ok &= check('Public profile email privacy', 'email' not in public_profile.lower())
# Node syntax validation.
r=subprocess.run(['node','--check',str(root/'backend/worker/src/index.js')],capture_output=True,text=True)
all_ok &= check('Worker JavaScript syntax', r.returncode==0)
print('RESULT | '+('PASS' if all_ok else 'FAIL'))
sys.exit(0 if all_ok else 1)
