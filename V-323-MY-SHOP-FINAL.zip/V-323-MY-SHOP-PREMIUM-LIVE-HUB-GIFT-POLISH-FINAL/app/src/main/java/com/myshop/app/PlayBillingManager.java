package com.myshop.app;

import android.app.Activity;
import android.widget.Toast;
import com.android.billingclient.api.*;
import java.util.*;
import org.json.JSONObject;

/** V-308 Google Play Billing gate for user-paid digital goods.
 * Entitlements are NEVER granted on-device. A purchase token must be verified by the Worker first.
 */
public final class PlayBillingManager implements PurchasesUpdatedListener {
    private final Activity activity;
    private final BillingClient client;
    private final Map<String,Long> catalogByProduct=new HashMap<>();

    public PlayBillingManager(Activity activity){
        this.activity=activity;
        client=BillingClient.newBuilder(activity)
                .setListener(this)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .enableAutoServiceReconnection()
                .build();
    }

    public void purchase(JSONObject item){
        if(item==null)return;
        final long catalogId=item.optLong("id",0);
        final String productId=item.optString("play_product_id","").trim();
        if(catalogId<=0||productId.isEmpty()){toast("Google Play Product ID is not configured for this item.");return;}
        catalogByProduct.put(productId,catalogId);
        BackendClient.playBillingReady(SessionManager.getToken(activity),catalogId,productId,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){activity.runOnUiThread(()->connect(()->queryAndLaunch(productId)));}
            public void onError(String m){activity.runOnUiThread(()->toast(m));}
        });
    }

    private void connect(final Runnable ready){
        if(client.isReady()){ready.run();return;}
        client.startConnection(new BillingClientStateListener(){
            @Override public void onBillingSetupFinished(BillingResult r){
                if(r.getResponseCode()==BillingClient.BillingResponseCode.OK)ready.run();
                else toast("Google Play Billing unavailable: "+r.getDebugMessage());
            }
            @Override public void onBillingServiceDisconnected(){ /* automatic reconnection is enabled */ }
        });
    }

    private void queryAndLaunch(String productId){
        QueryProductDetailsParams.Product q=QueryProductDetailsParams.Product.newBuilder()
                .setProductId(productId).setProductType(BillingClient.ProductType.INAPP).build();
        QueryProductDetailsParams params=QueryProductDetailsParams.newBuilder().setProductList(Collections.singletonList(q)).build();
        client.queryProductDetailsAsync(params,new ProductDetailsResponseListener(){
            @Override public void onProductDetailsResponse(BillingResult result, QueryProductDetailsResult detailsResult){
                if(result.getResponseCode()!=BillingClient.BillingResponseCode.OK){toast("Play product lookup failed: "+result.getDebugMessage());return;}
                List<ProductDetails> list=detailsResult.getProductDetailsList();
                if(list==null||list.isEmpty()){toast("This Google Play product is not active for the current release/account.");return;}
                ProductDetails details=list.get(0);
                BillingFlowParams.ProductDetailsParams.Builder pb=BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(details);
                List<ProductDetails.OneTimePurchaseOfferDetails> offers=details.getOneTimePurchaseOfferDetailsList();
                if(offers!=null&&!offers.isEmpty()&&offers.get(0).getOfferToken()!=null&&!offers.get(0).getOfferToken().isEmpty())pb.setOfferToken(offers.get(0).getOfferToken());
                BillingFlowParams flow=BillingFlowParams.newBuilder().setProductDetailsParamsList(Collections.singletonList(pb.build())).build();
                BillingResult lr=client.launchBillingFlow(activity,flow);
                if(lr.getResponseCode()!=BillingClient.BillingResponseCode.OK)toast("Google Play checkout could not start: "+lr.getDebugMessage());
            }
        });
    }

    @Override public void onPurchasesUpdated(BillingResult result,List<Purchase> purchases){
        if(result.getResponseCode()==BillingClient.BillingResponseCode.USER_CANCELED)return;
        if(result.getResponseCode()!=BillingClient.BillingResponseCode.OK){toast("Google Play purchase: "+result.getDebugMessage());return;}
        if(purchases!=null)for(Purchase p:purchases)processPurchase(p);
    }

    private void processPurchase(Purchase p){
        if(p==null)return;
        if(p.getPurchaseState()==Purchase.PurchaseState.PENDING){toast("Google Play purchase is pending. It will activate after payment completes.");return;}
        if(p.getPurchaseState()!=Purchase.PurchaseState.PURCHASED)return;
        List<String> products=p.getProducts();
        if(products==null||products.isEmpty())return;
        for(String productId:products){
            long catalogId=catalogByProduct.containsKey(productId)?catalogByProduct.get(productId):0L;
            BackendClient.playPurchaseVerify(SessionManager.getToken(activity),catalogId,productId,p.getPurchaseToken(),new BackendClient.Callback(){
                public void onSuccess(JSONObject d){activity.runOnUiThread(()->consumeVerified(p,d.optBoolean("alreadyProcessed",false)));}
                public void onError(String m){activity.runOnUiThread(()->toast("Purchase not activated: "+m));}
            });
        }
    }

    private void consumeVerified(Purchase p,boolean alreadyProcessed){
        ConsumeParams cp=ConsumeParams.newBuilder().setPurchaseToken(p.getPurchaseToken()).build();
        client.consumeAsync(cp,(result,token)->activity.runOnUiThread(()->{
            if(result.getResponseCode()==BillingClient.BillingResponseCode.OK)toast(alreadyProcessed?"Purchase already verified.":"✓ Google Play purchase verified and activated.");
            else toast("Purchase activated. Play cleanup will retry automatically.");
        }));
    }

    /** Recovers completed-but-not-yet-processed one-time purchases after reconnect/reinstall. */
    public void recoverPurchases(){
        if(SessionManager.getToken(activity).isEmpty())return;
        connect(()->client.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build(),(result,purchases)->{
            if(result.getResponseCode()==BillingClient.BillingResponseCode.OK&&purchases!=null)for(Purchase p:purchases)processPurchase(p);
        }));
    }

    public void close(){try{client.endConnection();}catch(Exception ignored){}}
    private void toast(String s){activity.runOnUiThread(()->Toast.makeText(activity,s,Toast.LENGTH_LONG).show());}
}
