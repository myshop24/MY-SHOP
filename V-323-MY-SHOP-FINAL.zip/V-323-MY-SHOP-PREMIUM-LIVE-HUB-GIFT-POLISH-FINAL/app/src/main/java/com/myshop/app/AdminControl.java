package com.myshop.app;

import android.content.Context;
import android.widget.Toast;

/**
 * Admin actions are intentionally permission-gated here.
 * Actual persistence and authorization belong to the backend.
 */
public final class AdminControl {
    private AdminControl() {}

    public static boolean requireAdmin(Context context) {
        if (SessionManager.isAdmin(context)) return true;
        Toast.makeText(context, "অ্যাডমিন অনুমতি প্রয়োজন।", Toast.LENGTH_SHORT).show();
        return false;
    }

    public static boolean canModerate(Context context) {
        return SessionManager.isAdmin(context) || SessionManager.isModerator(context);
    }
}
