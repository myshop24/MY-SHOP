package com.myshop.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.widget.EditText;
import android.widget.Toast;
import org.json.JSONObject;

/** Reusable end-user UGC safety controls for Profile, Feed, Chat and Live. */
public final class SafetyActions {
    private SafetyActions(){}
    public static void show(Activity a,String userId,String contentType,String contentId){
        String uid=userId==null?"":userId.trim();
        if(uid.isEmpty()||uid.equals(SessionManager.getUserId(a))){Toast.makeText(a,"Safety actions are for other users/content.",Toast.LENGTH_SHORT).show();return;}
        new AlertDialog.Builder(a).setTitle("Safety • User ID "+uid)
                .setItems(new String[]{"⚑ Report","⛔ Block User"},(d,w)->{if(w==0)report(a,uid,contentType,contentId);else confirmBlock(a,uid);})
                .setNegativeButton("Cancel",null).show();
    }
    private static void report(Activity a,String uid,String type,String contentId){
        final String[] labels={"Spam","Harassment or bullying","Scam / fraud","Hate or abusive content","Inappropriate content","Other"};
        final String[] keys={"SPAM","HARASSMENT","SCAM_FRAUD","HATE_ABUSE","INAPPROPRIATE","OTHER"};
        new AlertDialog.Builder(a).setTitle("Why are you reporting this?").setItems(labels,(d,w)->{
            EditText details=new EditText(a);details.setHint("Optional details");details.setMinLines(2);details.setMaxLines(5);
            new AlertDialog.Builder(a).setTitle(labels[w]).setMessage("The report will be sent to MY SHOP moderation. The reported user is not told who submitted it.")
                    .setView(details).setNegativeButton("Cancel",null).setPositiveButton("SUBMIT",(q,z)->BackendClient.report(SessionManager.getToken(a),uid,type,contentId,keys[w],details.getText().toString(),new BackendClient.Callback(){
                        public void onSuccess(JSONObject x){a.runOnUiThread(()->Toast.makeText(a,"✓ Report submitted",Toast.LENGTH_LONG).show());}
                        public void onError(String m){a.runOnUiThread(()->Toast.makeText(a,m,Toast.LENGTH_LONG).show());}
                    })).show();
        }).show();
    }
    private static void confirmBlock(Activity a,String uid){
        new AlertDialog.Builder(a).setTitle("Block this user?").setMessage("Blocking prevents direct messaging and removes friend/follow connections between you. You can unblock later from Settings & Privacy → Block List.")
                .setNegativeButton("Cancel",null).setPositiveButton("BLOCK",(d,w)->BackendClient.blockUser(SessionManager.getToken(a),uid,true,new BackendClient.Callback(){
                    public void onSuccess(JSONObject x){a.runOnUiThread(()->Toast.makeText(a,"✓ User blocked",Toast.LENGTH_LONG).show());}
                    public void onError(String m){a.runOnUiThread(()->Toast.makeText(a,m,Toast.LENGTH_LONG).show());}
                })).show();
    }
}
