package com.myshop.app;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;

/** V-315: clear Admin -> User Coin/Gold/Badge grant flow with recipient preview and receipt. */
public class AdminWalletActivity extends androidx.appcompat.app.AppCompatActivity {
  private EditText userId, units, days, note;
  private Spinner type, code;
  private TextView preview;
  private Button verify, grant;
  private String verifiedUserId="";

  @Override protected void onCreate(Bundle b){
    super.onCreate(b);
    if(!SessionManager.isAdmin(this)||!SessionManager.isAdminGateUnlocked()){finish();return;}
    build();
  }

  private void build(){
    ScrollView sv=new ScrollView(this); sv.setFillViewport(true);
    LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setPadding(dp(16),dp(18),dp(16),dp(30)); r.setBackgroundColor(Color.rgb(246,248,253));

    TextView h=t("🪙  ইউজারকে Coin / Gold দিন",24,true); r.addView(h);
    TextView sub=t("সহজ ৩ ধাপ: ① User ID যাচাই  ② Coin/Gold ও পরিমাণ দিন  ③ Preview দেখে Confirm করুন। Admin/Official grant-এ MY SHOP Service Fee = 0%।",12,false); sub.setTextColor(Color.rgb(92,101,125)); sub.setPadding(0,dp(8),0,dp(14)); r.addView(sub);

    LinearLayout s1=card();
    s1.addView(step("①  ইউজার খুঁজুন", "যে MY SHOP User ID-তে দিতে চান, সেই ৪ সংখ্যার ID লিখুন।"));
    userId=e("যেমন: 1234"); userId.setInputType(InputType.TYPE_CLASS_NUMBER); s1.addView(userId,lp(-1,dp(52)));
    verify=button("🔎  USER ID যাচাই করুন",Color.rgb(37,99,235)); verify.setOnClickListener(v->verifyUser()); s1.addView(verify,lp(-1,dp(50)));
    preview=t("এখনো কোনো User যাচাই করা হয়নি।",12,false); preview.setTextColor(Color.rgb(92,101,125)); preview.setPadding(dp(10),dp(10),dp(10),dp(10)); preview.setBackground(round(Color.rgb(247,249,255),14)); s1.addView(preview,lp(-1,-2));
    r.addView(s1,lp(-1,-2));

    LinearLayout s2=card();
    s2.addView(step("②  কী দিতে চান", "Coin বা Gold Coin নির্বাচন করে পরিমাণ লিখুন। Badge/Membership-এর পুরোনো grant-ও এখানে রাখা হয়েছে।"));
    type=new Spinner(this); type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"COIN","GOLD","BADGE"})); s2.addView(type,lp(-1,dp(52)));
    code=new Spinner(this); code.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"COIN","GOLD","BLUE","VIP","VVIP","ROYAL"})); s2.addView(code,lp(-1,dp(52)));
    units=e("পরিমাণ / Units"); units.setInputType(InputType.TYPE_CLASS_NUMBER); units.setText("1"); s2.addView(units,lp(-1,dp(52)));
    days=e("Badge মেয়াদ: ০ = Permanent"); days.setInputType(InputType.TYPE_CLASS_NUMBER); days.setText("0"); s2.addView(days,lp(-1,dp(52)));
    note=e("ঐচ্ছিক নোট / Official reference"); s2.addView(note,lp(-1,dp(58)));
    r.addView(s2,lp(-1,-2));

    LinearLayout s3=card();
    s3.addView(step("③  নিশ্চিত করুন", "ভুল User-কে না যায়—Confirm-এর আগে User ID ও পরিমাণ আবার দেখানো হবে।"));
    grant=button("✓  CONFIRM & GRANT",Color.rgb(91,33,182)); grant.setEnabled(false); grant.setAlpha(.45f); grant.setOnClickListener(v->grant()); s3.addView(grant,lp(-1,dp(54)));
    TextView rule=t("Official rule: 100,000 Coin = 1⭐ • 1,000 Gold Coin = 1⭐ • Admin/Official প্রতি 1⭐ = +2 Level • Service Fee 0%",11,false); rule.setTextColor(Color.rgb(97,75,155)); s3.addView(rule);
    r.addView(s3,lp(-1,-2));

    Button back=button("←  ফিরে যান",Color.rgb(85,94,115)); back.setOnClickListener(v->finish()); r.addView(back,lp(-1,dp(48)));
    sv.addView(r); setContentView(sv);

    userId.setOnFocusChangeListener((v,has)->{ if(has && !userId.getText().toString().trim().equals(verifiedUserId)) invalidateVerify(); });
  }

  private void verifyUser(){
    final String uid=userId.getText().toString().trim();
    if(uid.length()!=4){toast("সঠিক ৪ সংখ্যার MY SHOP User ID দিন।");return;}
    verify.setEnabled(false); verify.setText("যাচাই হচ্ছে…");
    BackendClient.adminWalletPreview(SessionManager.getToken(this),uid,new BackendClient.Callback(){
      public void onSuccess(JSONObject o){runOnUiThread(()->{
        verifiedUserId=uid; JSONObject u=o.optJSONObject("user"); String name=u==null?"MY SHOP User":u.optString("name","MY SHOP User");
        preview.setText("✓ User পাওয়া গেছে\n\nনাম: "+name+"\nUser ID: "+uid+"\nCoin: "+o.optLong("coinBalance",0)+"\nGold Coin: "+o.optLong("goldBalance",0)+"\n⭐ Stars: "+o.optLong("stars",0)+"   •   Level: "+o.optLong("level",0));
        preview.setTextColor(Color.rgb(19,112,76)); grant.setEnabled(true); grant.setAlpha(1f); verify.setEnabled(true); verify.setText("✓ USER VERIFIED • আবার যাচাই");
      });}
      public void onError(String m){runOnUiThread(()->{invalidateVerify(); preview.setText("User পাওয়া যায়নি বা যাচাই করা যায়নি।\n"+m); preview.setTextColor(Color.rgb(190,45,62)); verify.setEnabled(true); verify.setText("🔎  USER ID যাচাই করুন");});}
    });
  }

  private void invalidateVerify(){ verifiedUserId=""; if(grant!=null){grant.setEnabled(false);grant.setAlpha(.45f);} }

  private void grant(){
    final String uid=userId.getText().toString().trim();
    int u=num(units.getText().toString()), d=num(days.getText().toString());
    final String ty=String.valueOf(type.getSelectedItem()), c=String.valueOf(code.getSelectedItem());
    if(!uid.equals(verifiedUserId)){toast("আগে User ID যাচাই করুন।");return;}
    if(u<=0){toast("সঠিক পরিমাণ দিন।");return;}
    String starHint="";
    if("COIN".equals(ty)) starHint="\nStar: প্রতি 100,000 Coin = 1⭐";
    if("GOLD".equals(ty)) starHint="\nStar: প্রতি 1,000 Gold Coin = 1⭐";
    new AlertDialog.Builder(this).setTitle("Official Grant নিশ্চিত করুন")
      .setMessage("User ID: "+uid+"\nType: "+ty+"\nAmount: "+u+"\nService Fee: 0%"+starHint+"\n\nConfirm করলে সঙ্গে সঙ্গে backend balance update হবে।")
      .setNegativeButton("বাতিল",null)
      .setPositiveButton("CONFIRM",(x,w)->{
        grant.setEnabled(false); grant.setText("Grant হচ্ছে…");
        BackendClient.adminWalletGrant(SessionManager.getToken(this),uid,ty,c,u,d,note.getText().toString(),new BackendClient.Callback(){
          public void onSuccess(JSONObject o){runOnUiThread(()->{
            grant.setEnabled(true); grant.setText("✓  CONFIRM & GRANT");
            String receipt="✓ Grant সফল হয়েছে\n\nReference: "+o.optString("reference","OFFICIAL_ADMIN_GRANT")+"\nUser ID: "+o.optString("userId",uid)+"\nAmount: "+o.optLong("units",u)+" "+ty+"\nService Fee: "+o.optInt("serviceFeePercent",0)+"%\n⭐ Added: "+o.optLong("starsAdded",0)+"\nLevel Added: +"+o.optLong("levelsAdded",0)+"\n\nNew Coin Balance: "+o.optLong("coinBalance",0)+"\nNew Gold Balance: "+o.optLong("goldBalance",0)+"\nCurrent Level: "+o.optLong("level",0);
            new AlertDialog.Builder(AdminWalletActivity.this).setTitle("MY SHOP Grant Receipt").setMessage(receipt).setPositiveButton("OK",null).show();
            verifyUser();
          });}
          public void onError(String m){runOnUiThread(()->{grant.setEnabled(true);grant.setText("✓  CONFIRM & GRANT");toast(m);});}
        });
      }).show();
  }

  private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(14),dp(14),dp(14),dp(14));c.setBackground(round(Color.WHITE,18));return c;}
  private TextView step(String a,String b){TextView x=t(a+"\n"+b,13,true);x.setLineSpacing(dp(2),1f);x.setPadding(0,0,0,dp(10));return x;}
  private Button button(String s,int color){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setAllCaps(false);b.setBackground(round(color,14));return b;}
  private GradientDrawable round(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
  private int num(String s){try{return Integer.parseInt(s.trim());}catch(Exception e){return 0;}}
  private EditText e(String h){EditText x=new EditText(this);x.setHint(h);x.setTextSize(13);x.setSingleLine(true);x.setPadding(dp(12),0,dp(12),0);x.setBackground(round(Color.rgb(243,246,252),12));return x;}
  private TextView t(String s,int z,boolean b){TextView x=new TextView(this);x.setText(s);x.setTextSize(z);x.setTextColor(Color.rgb(22,28,55));if(b)x.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return x;}
  private LinearLayout.LayoutParams lp(int w,int h){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.bottomMargin=dp(10);p.topMargin=dp(3);return p;}
  private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
