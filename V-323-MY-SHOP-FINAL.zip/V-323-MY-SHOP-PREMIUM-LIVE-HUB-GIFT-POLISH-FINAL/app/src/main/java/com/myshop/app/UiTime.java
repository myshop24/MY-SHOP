package com.myshop.app;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Small UI-only formatter for backend UTC timestamps. */
public final class UiTime {
    private UiTime() {}
    public static String relative(String raw){
        if(raw==null||raw.trim().isEmpty()) return "";
        String value=raw.trim();
        String[] patterns={"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd'T'HH:mm:ss.SSS'Z'","yyyy-MM-dd'T'HH:mm:ss'Z'"};
        for(String pattern:patterns){
            try{
                SimpleDateFormat f=new SimpleDateFormat(pattern,Locale.US);
                f.setTimeZone(TimeZone.getTimeZone("UTC"));
                Date d=f.parse(value);
                if(d==null) continue;
                long sec=Math.max(0,(System.currentTimeMillis()-d.getTime())/1000L);
                if(sec<45) return "Just now";
                if(sec<3600) return (sec/60)+"m ago";
                if(sec<86400) return (sec/3600)+"h ago";
                if(sec<172800) return "Yesterday";
                if(sec<604800) return (sec/86400)+"d ago";
                return new SimpleDateFormat("MMM d",Locale.getDefault()).format(d);
            }catch(Exception ignored){}
        }
        return value;
    }
}
