package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import androidx.appcompat.app.AppCompatActivity;
import java.io.InputStream;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

/** V-124 Gallery Manager — Photo / Audio / Video, R2 upload, caption save/edit, delete. */
public class GalleryAdminActivity extends AppCompatActivity {
    private String folder="photo"; private LinearLayout list; private final ArrayList<JSONObject> rows=new ArrayList<>();
    private final int PURPLE=Color.rgb(83,32,180),GREEN=Color.rgb(17,139,88),RED=Color.rgb(210,45,55),BLUE=Color.rgb(31,73,210),BG=Color.rgb(246,248,252);
    @Override protected void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)){finish();return;}build();load();}
    private void buildRefresh(){build();load();}
    private void build(){
        LinearLayout root=col();root.setPadding(dp(12),dp(12),dp(12),dp(18));root.setBackgroundColor(BG);
        TextView h=txt("MY SHOP • গ্যালারি ম্যানেজার",22,Color.rgb(20,28,60),true);h.setGravity(Gravity.CENTER);root.addView(h,lp(-1,dp(48)));
        TextView n=txt("R2 স্টোরেজ • ছবি / অডিও / ভিডিও • শুধু এডমিন",11,Color.DKGRAY,false);n.setGravity(Gravity.CENTER);root.addView(n,lp(-1,dp(28)));
        LinearLayout tabs=row();String[] fs={"photo","audio","video"};String[] ls={"ছবি","অডিও","ভিডিও"};for(int i=0;i<3;i++){final String f=fs[i];tabs.addView(action(ls[i],f.equals(folder)?PURPLE:Color.DKGRAY,()->{folder=f;buildRefresh();}),wt(1));if(i<2)tabs.addView(gap(),lp(dp(5),1));}root.addView(tabs,lp(-1,dp(42)));
        TextView add=action("＋  যোগ / আপলোড "+folder.toUpperCase(),GREEN,()->pick());root.addView(add,lp(-1,dp(44)));
        list=col();ScrollView sv=new ScrollView(this);sv.addView(list);root.addView(sv,lp(-1,0,1));
        root.addView(action("ফিরে যান",Color.rgb(20,28,60),()->finish()),lp(-1,dp(44)));setContentView(root);
    }
    private void load(){BackendClient.adminMediaList(SessionManager.getToken(this),folder,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{rows.clear();try{JSONArray a=d.optJSONArray("media");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x!=null&&folder.equalsIgnoreCase(x.optString("folder","")))rows.add(x);}render();}catch(Exception e){toast("গ্যালারি পড়তে সমস্যা");}});}public void onError(String m){runOnUiThread(()->toast("Gallery "+folder.toUpperCase()+" লোড ব্যর্থ: "+m));}});}
    private void render(){list.removeAllViews();if(rows.isEmpty()){TextView e=txt("No "+folder.toUpperCase()+" মিডিয়া নেই। যোগ / আপলোড চাপুন "+folder.toUpperCase()+".",13,Color.DKGRAY,false);e.setPadding(dp(8),dp(30),dp(8),dp(30));list.addView(e);return;}for(JSONObject x:rows){final long id=x.optLong("id",0);LinearLayout card=col();card.setPadding(dp(10),dp(8),dp(10),dp(8));card.setBackground(bg(Color.WHITE,Color.rgb(224,226,235),8));
        TextView title=txt(x.optString("title","নামহীন"),14,Color.rgb(20,28,60),true);card.addView(title,lp(-1,dp(26)));
        TextView type=txt(x.optString("media_type",folder),9,Color.GRAY,false);card.addView(type,lp(-1,dp(20)));
        EditText caption=field("ক্যাপশন");caption.setText(x.optString("caption",""));card.addView(caption,lp(-1,dp(44)));
        LinearLayout a=row();String url=x.optString("media_url","");String preview=folder.equals("photo")?"ছবি দেখুন":folder.equals("audio")?"অডিও চালান":"ভিডিও চালান";a.addView(action(preview,PURPLE,()->openMedia(url)),wt(1));a.addView(gap(),lp(dp(5),1));a.addView(action("সংরক্ষণ",GREEN,()->save(id,x.optString("title",""),caption.getText().toString())),wt(1));card.addView(a,lp(-1,dp(42))); LinearLayout b=row();b.addView(action("✏ শিরোনাম সম্পাদনা",BLUE,()->editTitle(id,x.optString("title",""),caption.getText().toString())),wt(1));b.addView(gap(),lp(dp(5),1));b.addView(action("মুছুন",RED,()->confirmDelete(id)),wt(1));card.addView(b,lp(-1,dp(42)));
        TextView u=txt(x.optString("media_url",""),9,Color.GRAY,false);u.setMaxLines(1);card.addView(u,lp(-1,dp(22)));list.addView(card,lp(-1,-2));Space sp=new Space(this);list.addView(sp,lp(1,dp(7)));
    }}
    private void openMedia(String url){if(url==null||url.isEmpty()){toast("মিডিয়া URL পাওয়া যায়নি");return;}try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){toast("উপযুক্ত প্লেয়ার/ভিউয়ার পাওয়া যায়নি।");}}
    private void save(long id,String oldশিরোনাম,String caption){BackendClient.adminMediaUpdate(SessionManager.getToken(this),id,oldশিরোনাম,caption,new BackendClient.Callback(){public void onSuccess(JSONObject d){toast("✓ সংরক্ষণ হয়েছে");load();}public void onError(String m){toast("সংরক্ষণ ব্যর্থ: "+m);}});}
    private void editTitle(long id,String title,String caption){EditText e=field("শিরোনাম");e.setText(title);new AlertDialog.Builder(this).setTitle("মিডিয়া সম্পাদনা").setView(e).setPositiveButton("সংরক্ষণ",(d,w)->save(id,e.getText().toString().trim(),caption)).setNegativeButton("বাতিল",null).show();}
    private void confirmDelete(long id){new AlertDialog.Builder(this).setTitle("মিডিয়া মুছবেন?").setMessage("এতে Gallery record এবং সংশ্লিষ্ট R2 file মুছে যাবে।").setPositiveButton("মুছুন",(d,w)->BackendClient.adminMediaDelete(SessionManager.getToken(this),id,new BackendClient.Callback(){public void onSuccess(JSONObject x){toast("✓ মুছে ফেলা হয়েছে");load();}public void onError(String m){toast("মুছতে ব্যর্থ: "+m);}})).setNegativeButton("বাতিল",null).show();}
    private void pick(){String mime=folder.equals("photo")?"image/*":folder.equals("audio")?"audio/*":"video/*";Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType(mime);i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,700);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r!=700||c!=RESULT_OK||d==null||d.getData()==null)return;Uri u=d.getData();try{if((d.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION)!=0)getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}showMeta(u);}
    private void showMeta(Uri uri){LinearLayout box=col();EditText title=field("শিরোনাম");EditText cap=field("ক্যাপশন");box.addView(title);box.addView(cap);new AlertDialog.Builder(this).setTitle("আপলোড বিভাগ: "+folder.toUpperCase()).setView(box).setPositiveButton("আপলোড",(x,w)->upload(uri,title.getText().toString(),cap.getText().toString())).setNegativeButton("বাতিল",null).show();}
    private String fallbackMime(){return "photo".equals(folder)?"image/jpeg":"audio".equals(folder)?"audio/mpeg":"video/mp4";}
    private void upload(Uri uri,String title,String cap){try{InputStream in=getContentResolver().openInputStream(uri);String mime=getContentResolver().getType(uri);BackendClient.adminMediaUpload(SessionManager.getToken(this),in,-1,fileName(uri),mime==null?fallbackMime():mime,folder,title,cap,rows.size()+1,new BackendClient.Callback(){public void onSuccess(JSONObject d){toast("✓ R2-তে আপলোড হয়েছে");load();}public void onError(String m){toast("আপলোড ব্যর্থ: "+m);}});}catch(Exception e){toast("নির্বাচিত ফাইল খোলা যায়নি।");}}
    private String fileName(Uri u){Cursor c=getContentResolver().query(u,null,null,null,null);if(c!=null)try{int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(c.moveToFirst()&&i>=0)return c.getString(i);}finally{c.close();}return "media";}
    private TextView action(String s,int c,Runnable r){TextView t=txt(s,10.5f,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setBackground(bg(c,c,7));t.setOnClickListener(v->r.run());return t;}
    private EditText field(String h){EditText e=new EditText(this);e.setHint(h);e.setSingleLine(true);e.setTextSize(12);e.setPadding(dp(10),0,dp(10),0);e.setBackground(bg(Color.WHITE,Color.rgb(215,218,228),7));return e;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private View gap(){return new View(this);}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams lp(int w,int h,float wt){return new LinearLayout.LayoutParams(w,h,wt);}private LinearLayout.LayoutParams wt(float w){return new LinearLayout.LayoutParams(0,dp(42),w);}private GradientDrawable bg(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;}private TextView txt(String s,float z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
}
