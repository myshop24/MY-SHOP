package com.myshop.app;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;

/** V-253 four-agent directory. Each agent is Admin-managed with photo/name/link. */
public class AgentActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(248,249,253),NAVY=Color.rgb(18,32,75),BLUE=Color.rgb(46,47,190),PURPLE=Color.rgb(91,38,214),MUTED=Color.rgb(105,111,130);
    private LinearLayout body;
    @Override protected void onCreate(Bundle b){super.onCreate(b);build();load();}
    private void build(){ScrollView sv=new ScrollView(this);LinearLayout root=col();root.setPadding(dp(12),dp(10),dp(12),dp(22));root.setBackgroundColor(BG);LinearLayout h=row();TextView back=txt("‹",NAVY,30,true);back.setGravity(Gravity.CENTER);back.setOnClickListener(v->finish());h.addView(back,lp(dp(44),dp(46)));LinearLayout hb=col();hb.addView(txt("MY SHOP Agents",NAVY,20,true),lp(-1,dp(26)));hb.addView(txt("Up to 4 verified contact links",MUTED,9,false),lp(-1,dp(18)));h.addView(hb,weight(1,dp(46)));root.addView(h,lp(-1,dp(50)));body=col();root.addView(body,top(lp(-1,-2),8));sv.addView(root,new ScrollView.LayoutParams(-1,-2));setContentView(sv);}
    private void load(){BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->render(d.optJSONArray("managedLinks")));}public void onError(String m){runOnUiThread(()->render(null));}});}
    private void render(JSONArray a){body.removeAllViews();JSONObject[] slots=new JSONObject[4];if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;String cat=x.optString("category","");if(cat.startsWith("feature_agent_slot_")){try{int n=Integer.parseInt(cat.substring("feature_agent_slot_".length()));if(n>=1&&n<=4)slots[n-1]=x;}catch(Exception ignored){}}}
        for(int i=0;i<4;i++){final int slot=i+1;JSONObject x=slots[i];boolean active=x!=null&&x.optInt("active",1)==1;if(!active&&!SessionManager.isAdmin(this))continue;String name=x==null?"Agent "+slot:x.optString("title","Agent "+slot);String cap=x==null?"Admin can add this agent":x.optString("caption","");String link=x==null?"":x.optString("url","");String image=x==null?"":x.optString("image_url",x.optString("imageUrl",""));LinearLayout c=row();c.setPadding(dp(10),dp(9),dp(10),dp(9));c.setBackground(round(Color.WHITE,Color.rgb(225,229,240),16));ImageView av=new ImageView(this);av.setImageResource(R.drawable.myshop_profile_avatar);av.setScaleType(ImageView.ScaleType.CENTER_CROP);av.setClipToOutline(true);av.setBackground(round(Color.rgb(241,243,249),Color.rgb(224,228,238),32));if(!image.isEmpty())loadImage(av,image);c.addView(av,lp(dp(64),dp(64)));LinearLayout tx=col();tx.setPadding(dp(9),0,0,0);tx.addView(txt(name,NAVY,13,true),lp(-1,dp(28)));tx.addView(txt(cap.isEmpty()?"MY SHOP Agent":cap,MUTED,9,false),lp(-1,dp(24)));c.addView(tx,weight(1,dp(64)));TextView action=txt(SessionManager.isAdmin(this)?"EDIT":"CHAT ›",SessionManager.isAdmin(this)?PURPLE:BLUE,10,true);action.setGravity(Gravity.CENTER);c.addView(action,lp(dp(72),dp(48)));c.setAlpha(active?1f:.55f);c.setOnClickListener(v->{if(SessionManager.isAdmin(this)){Intent q=new Intent(this,AdminSectionActivity.class);q.putExtra("section","feature_card");q.putExtra("managed_category","feature_agent_slot_"+slot);q.putExtra("managed_title","AGENT "+slot);q.putExtra("admin_context",true);startActivity(q);return;}if(FeatureRegistry.isSafeHttpUrl(link)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(link)));}catch(Exception ignored){}}});body.addView(c,lp(-1,dp(84)));body.addView(gap(),lp(1,dp(8)));}}
    private void loadImage(ImageView v,String u){Executors.newSingleThreadExecutor().execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(6000);c.setReadTimeout(8000);try(InputStream in=c.getInputStream()){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null)runOnUiThread(()->v.setImageBitmap(b));}c.disconnect();}catch(Exception ignored){}});}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private TextView txt(String s,int c,float z,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}private View gap(){return new View(this);}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}private GradientDrawable round(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
