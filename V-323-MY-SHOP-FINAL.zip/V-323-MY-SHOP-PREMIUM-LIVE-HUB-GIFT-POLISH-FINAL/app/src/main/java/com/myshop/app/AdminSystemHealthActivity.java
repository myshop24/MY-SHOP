package com.myshop.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import org.json.JSONObject;

/** V-187: Admin-only production diagnostic board. */
public class AdminSystemHealthActivity extends androidx.appcompat.app.AppCompatActivity {
  private TextView out;
  @Override protected void onCreate(Bundle b){super.onCreate(b); if(!SessionManager.isAdmin(this)){finish();return;} build(); load();}
  private void build(){
    LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(14),dp(12),dp(14),dp(18)); root.setBackgroundColor(Color.rgb(246,248,252));
    TextView h=txt("সিস্টেম স্বাস্থ্য / পরীক্ষা",20,true); h.setGravity(Gravity.CENTER); root.addView(h,lp(-1,dp(48)));
    TextView note=txt("এখানেই আসল সমস্যা দেখা যাবে: সক্রিয় Worker, D1, স্কিমা, D1 লেখা, R2 এবং R2 লেখা।",11,false); root.addView(note,lp(-1,dp(50)));
    Button refresh=new Button(this); refresh.setText("আবার পরীক্ষা করুন"); refresh.setOnClickListener(v->load()); root.addView(refresh,lp(-1,dp(46)));
    ScrollView sv=new ScrollView(this); out=txt("পরীক্ষা চলছে…",11,false); out.setPadding(dp(8),dp(10),dp(8),dp(10)); sv.addView(out); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
    Button back=new Button(this); back.setText("ফিরে যান"); back.setOnClickListener(v->finish()); root.addView(back,lp(-1,dp(46))); setContentView(root);
  }
  private void load(){BackendClient.adminSystemHealth(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->out.setText(pretty(d)));}public void onError(String m){runOnUiThread(()->out.setText("❌ পরীক্ষা ব্যর্থ\n\n"+m));}});}
  private String pretty(JSONObject d){return d.toString().replace(",","\n\n").replace("{","{\n").replace("}","\n}");}
  private TextView txt(String s,float z,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(Color.rgb(22,28,55));if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
  private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
