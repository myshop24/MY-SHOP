package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;

/** V-253 Gallery + External hub requested by MY SHOP. */
public class MediaHubActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(248,249,253),NAVY=Color.rgb(18,32,75),BLUE=Color.rgb(46,47,190),PURPLE=Color.rgb(91,38,214),MUTED=Color.rgb(105,111,130);
    private LinearLayout external;
    @Override protected void onCreate(Bundle b){super.onCreate(b);build();load();}
    private void build(){
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);LinearLayout root=col();root.setPadding(dp(12),dp(10),dp(12),dp(20));root.setBackgroundColor(BG);
        LinearLayout h=row();TextView back=txt("‹",NAVY,30,true);back.setGravity(Gravity.CENTER);back.setOnClickListener(v->finish());h.addView(back,lp(dp(44),dp(46)));LinearLayout hb=col();hb.addView(txt("Gallery + External",NAVY,20,true),lp(-1,dp(26)));hb.addView(txt("Photo • Audio • Video • External links",MUTED,9,false),lp(-1,dp(18)));h.addView(hb,weight(1,dp(46)));root.addView(h,lp(-1,dp(50)));
        LinearLayout tabs=row();tabs.addView(galleryCard("📷","Photos","photo"),weight(1,dp(104)));tabs.addView(gap(),lp(dp(6),1));tabs.addView(galleryCard("🎵","Audio","audio"),weight(1,dp(104)));tabs.addView(gap(),lp(dp(6),1));tabs.addView(galleryCard("🎬","Videos","video"),weight(1,dp(104)));root.addView(tabs,top(lp(-1,dp(104)),8));
        LinearLayout eh=row();eh.addView(txt("External",NAVY,16,true),weight(1,dp(42)));if(SessionManager.isAdmin(this)){TextView edit=txt("Admin Edit",BLUE,10,true);edit.setGravity(Gravity.CENTER);edit.setOnClickListener(v->{Intent i=new Intent(this,AdminSectionActivity.class);i.putExtra("section","external_movie");i.putExtra("admin_context",true);startActivity(i);});eh.addView(edit,lp(dp(90),dp(42)));}root.addView(eh,top(lp(-1,dp(42)),10));
        external=col();root.addView(external,lp(-1,-2));sv.addView(root,new ScrollView.LayoutParams(-1,-2));setContentView(sv);
    }
    private View galleryCard(String icon,String title,String folder){LinearLayout c=col();c.setGravity(Gravity.CENTER);c.setPadding(dp(5),dp(8),dp(5),dp(7));c.setBackground(round(Color.WHITE,Color.rgb(225,229,240),16));TextView i=txt(icon,NAVY,26,true);i.setGravity(Gravity.CENTER);c.addView(i,lp(-1,dp(50)));TextView t=txt(title,NAVY,11,true);t.setGravity(Gravity.CENTER);c.addView(t,lp(-1,dp(28)));c.setOnClickListener(v->{Intent q=new Intent(this,GalleryActivity.class);q.putExtra("folder",folder);startActivity(q);});return c;}
    private void load(){BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->render(d.optJSONArray("managedLinks")));}public void onError(String m){runOnUiThread(()->render(null));}});}
    private void render(JSONArray a){external.removeAllViews();int count=0;if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null||x.optInt("active",1)!=1)continue;String cat=x.optString("category","").toLowerCase();if(!(cat.equals("external_movie")||cat.equals("more_apps")||cat.startsWith("external_")||cat.startsWith("media_external")))continue;addExternal(x);count++;}if(count==0){TextView empty=txt("No external links configured yet.",MUTED,11,false);empty.setGravity(Gravity.CENTER);empty.setPadding(0,dp(28),0,dp(28));external.addView(empty,lp(-1,-2));}}
    private void addExternal(JSONObject x){String title=x.optString("title","External Link");String cap=x.optString("caption","");String url=x.optString("url","");String image=x.optString("image_url",x.optString("imageUrl",""));String iconUrl=x.optString("icon_url",x.optString("iconUrl",""));LinearLayout c=row();c.setPadding(dp(10),dp(8),dp(10),dp(8));c.setBackground(round(Color.WHITE,Color.rgb(225,229,240),14));ImageView icon=new ImageView(this);icon.setImageResource(R.drawable.ui_movie_hd);icon.setScaleType(ImageView.ScaleType.CENTER_CROP);icon.setClipToOutline(true);icon.setBackground(round(Color.rgb(246,247,252),Color.rgb(230,232,240),14));if(!image.isEmpty())loadImage(icon,image);else if(!iconUrl.isEmpty())loadImage(icon,iconUrl);c.addView(icon,lp(dp(52),dp(52)));LinearLayout text=col();text.addView(txt(title,NAVY,12,true),lp(-1,dp(26)));text.addView(txt(cap.isEmpty()?"Open external content":cap,MUTED,9,false),lp(-1,dp(24)));c.addView(text,weight(1,dp(52)));TextView arrow=txt("›",BLUE,25,true);arrow.setGravity(Gravity.CENTER);c.addView(arrow,lp(dp(34),dp(52)));c.setOnClickListener(v->{if(FeatureRegistry.isSafeHttpUrl(url)){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}}});external.addView(c,lp(-1,dp(68)));external.addView(gap(),lp(1,dp(7)));}
    private void loadImage(ImageView v,String u){Executors.newSingleThreadExecutor().execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();c.setConnectTimeout(6000);c.setReadTimeout(8000);try(InputStream in=c.getInputStream()){Bitmap b=BitmapFactory.decodeStream(in);if(b!=null)runOnUiThread(()->v.setImageBitmap(b));}c.disconnect();}catch(Exception ignored){}});}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private TextView txt(String s,int c,float z,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}private View gap(){return new View(this);}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}private GradientDrawable round(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
