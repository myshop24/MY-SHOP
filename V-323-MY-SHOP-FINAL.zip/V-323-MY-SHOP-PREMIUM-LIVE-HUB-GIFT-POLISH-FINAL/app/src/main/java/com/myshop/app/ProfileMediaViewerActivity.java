package com.myshop.app;

import android.content.Intent;
import android.app.DownloadManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

/** V-297 in-app profile photo/video viewer with Android share sheet. */
public class ProfileMediaViewerActivity extends AppCompatActivity {
    private String url="",type="image",caption="";
    @Override protected void onCreate(Bundle b){super.onCreate(b);url=getIntent().getStringExtra("url");type=getIntent().getStringExtra("type");caption=getIntent().getStringExtra("caption");if(url==null)url="";if(type==null)type="image";if(caption==null)caption="";setContentView(build());}
    private View build(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(5,6,13));root.setPadding(dp(10),dp(8),dp(10),dp(12));LinearLayout h=new LinearLayout(this);h.setOrientation(LinearLayout.HORIZONTAL);h.setGravity(Gravity.CENTER_VERTICAL);Button back=btn("‹");back.setTextSize(28);back.setOnClickListener(v->finish());h.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));TextView title=new TextView(this);title.setText("video".equals(type)?"Video":"Photo");title.setTextColor(Color.WHITE);title.setTextSize(17);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);h.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));Button save=btn("Save");save.setOnClickListener(v->saveMedia());h.addView(save,new LinearLayout.LayoutParams(dp(70),dp(44)));Button share=btn("Share");share.setOnClickListener(v->share());h.addView(share,new LinearLayout.LayoutParams(dp(78),dp(44)));root.addView(h,new LinearLayout.LayoutParams(-1,dp(52)));
        FrameLayout media=new FrameLayout(this);if("video".equals(type)||"reel".equals(type)||"short".equals(type)){VideoView vv=new VideoView(this);vv.setVideoURI(Uri.parse(url));MediaController mc=new MediaController(this);mc.setAnchorView(vv);vv.setMediaController(mc);vv.setOnPreparedListener(mp->{mp.setLooping(false);vv.start();});vv.setOnErrorListener((m,w,e)->{Toast.makeText(this,"Video play করা যায়নি",Toast.LENGTH_SHORT).show();return true;});media.addView(vv,new FrameLayout.LayoutParams(-1,-1));}else{ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_INSIDE);im.setBackgroundColor(Color.BLACK);AnimatedAssetLoader.load(im,url);media.addView(im,new FrameLayout.LayoutParams(-1,-1));}root.addView(media,new LinearLayout.LayoutParams(-1,0,1));if(!caption.trim().isEmpty()){TextView c=new TextView(this);c.setText(caption);c.setTextColor(Color.WHITE);c.setTextSize(13);c.setPadding(dp(8),dp(9),dp(8),dp(4));root.addView(c,new LinearLayout.LayoutParams(-1,-2));}return root;}
    private void share(){Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");String s=(caption.trim().isEmpty()?"MY SHOP media":caption.trim())+(url.isEmpty()?"":"\n"+url);i.putExtra(Intent.EXTRA_TEXT,s);startActivity(Intent.createChooser(i,"Share with"));}
    private void saveMedia(){if(url.trim().isEmpty()){Toast.makeText(this,"Media URL unavailable",Toast.LENGTH_SHORT).show();return;}try{boolean video="video".equalsIgnoreCase(type)||"reel".equalsIgnoreCase(type)||"short".equalsIgnoreCase(type);String ext=video?".mp4":".jpg";String name="MYSHOP_"+System.currentTimeMillis()+ext;DownloadManager.Request req=new DownloadManager.Request(Uri.parse(url));req.setTitle(video?"Saving MY SHOP video":"Saving MY SHOP photo");req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);req.setDestinationInExternalPublicDir(video?Environment.DIRECTORY_MOVIES:Environment.DIRECTORY_PICTURES,name);DownloadManager dm=(DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE);if(dm!=null){dm.enqueue(req);Toast.makeText(this,"Save started",Toast.LENGTH_SHORT).show();}else Toast.makeText(this,"Save unavailable",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Could not save media",Toast.LENGTH_SHORT).show();}}
    private Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackgroundColor(Color.TRANSPARENT);b.setMinHeight(0);b.setMinWidth(0);return b;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
