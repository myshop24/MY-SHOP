package com.myshop.app;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Locale;

/** V-248: MY SHOP in-app audio playback. Never opens Chrome for Gallery audio. */
public class AudioPlayerActivity extends AppCompatActivity {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private SeekBar seek;
    private TextView status,time;
    private Button play;
    private String url="";
    private boolean prepared=false,seeking=false;
    private final Runnable tick=new Runnable(){public void run(){if(player!=null&&prepared&&!seeking){try{int p=player.getCurrentPosition(),d=Math.max(1,player.getDuration());seek.setMax(d);seek.setProgress(p);time.setText(fmt(p)+" / "+fmt(d));}catch(Exception ignored){}}handler.postDelayed(this,500);}};

    @Override protected void onCreate(Bundle b){super.onCreate(b);url=getIntent().getStringExtra("url");String title=getIntent().getStringExtra("title");if(url==null)url="";if(title==null||title.trim().isEmpty())title="MY SHOP Audio";setContentView(build(title));prepare();}

    private View build(String title){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER_HORIZONTAL);root.setPadding(dp(18),dp(24),dp(18),dp(24));root.setBackgroundColor(Color.rgb(8,10,24));
        LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.HORIZONTAL);head.setGravity(Gravity.CENTER_VERTICAL);Button back=button("‹",Color.TRANSPARENT);back.setTextSize(30);back.setOnClickListener(v->finish());head.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));TextView h=text(title,21,true);h.setSingleLine(true);head.addView(h,new LinearLayout.LayoutParams(0,dp(48),1));root.addView(head,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView icon=text("♫",54,true);icon.setGravity(Gravity.CENTER);icon.setBackground(round(Color.rgb(74,35,172),Color.rgb(156,91,255),30));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(dp(132),dp(132));ip.topMargin=dp(42);root.addView(icon,ip);
        status=text("Loading audio…",12,false);status.setTextColor(Color.rgb(175,183,215));status.setGravity(Gravity.CENTER);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(40));sp.topMargin=dp(22);root.addView(status,sp);
        seek=new SeekBar(this);seek.setMax(100);seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){seeking=true;}public void onStopTrackingTouch(SeekBar s){if(player!=null&&prepared)try{player.seekTo(s.getProgress());}catch(Exception ignored){}seeking=false;}public void onProgressChanged(SeekBar s,int p,boolean from){}});root.addView(seek,new LinearLayout.LayoutParams(-1,dp(44)));
        time=text("00:00 / 00:00",11,false);time.setTextColor(Color.rgb(186,194,224));time.setGravity(Gravity.CENTER);root.addView(time,new LinearLayout.LayoutParams(-1,dp(30)));
        play=button("▶  Play",Color.rgb(104,45,236));play.setEnabled(false);play.setOnClickListener(v->toggle());LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(54));pp.topMargin=dp(14);root.addView(play,pp);
        TextView note=text("Audio plays inside MY SHOP",10,false);note.setTextColor(Color.rgb(122,132,170));note.setGravity(Gravity.CENTER);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,dp(38));np.topMargin=dp(8);root.addView(note,np);return root;
    }
    private void prepare(){if(url.trim().isEmpty()){status.setText("Audio URL unavailable");return;}try{player=new MediaPlayer();player.setAudioStreamType(AudioManager.STREAM_MUSIC);player.setDataSource(url);player.setOnPreparedListener(mp->{prepared=true;play.setEnabled(true);seek.setMax(Math.max(1,mp.getDuration()));status.setText("Ready");time.setText("00:00 / "+fmt(mp.getDuration()));handler.post(tick);});player.setOnCompletionListener(mp->{play.setText("▶  Play again");status.setText("Finished");seek.setProgress(seek.getMax());});player.setOnErrorListener((mp,what,extra)->{prepared=false;play.setEnabled(false);status.setText("Audio could not be played");return true;});player.prepareAsync();}catch(Exception e){status.setText("Audio could not be opened");}}
    private void toggle(){if(player==null||!prepared)return;try{if(player.isPlaying()){player.pause();play.setText("▶  Play");status.setText("Paused");}else{if(player.getCurrentPosition()>=Math.max(1,player.getDuration()-500))player.seekTo(0);player.start();play.setText("❚❚  Pause");status.setText("Playing");}}catch(Exception e){status.setText("Playback error");}}
    private String fmt(int ms){int sec=Math.max(0,ms/1000);return String.format(Locale.US,"%02d:%02d",sec/60,sec%60);}
    @Override protected void onDestroy(){handler.removeCallbacks(tick);if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}super.onDestroy();}
    private TextView text(String s,float z,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(z);if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return t;}
    private Button button(String s,int bg){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setMinHeight(0);b.setMinWidth(0);b.setBackground(bg==Color.TRANSPARENT?null:round(bg,bg,15));return b;}
    private GradientDrawable round(int fill,int stroke,int r){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(r));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
