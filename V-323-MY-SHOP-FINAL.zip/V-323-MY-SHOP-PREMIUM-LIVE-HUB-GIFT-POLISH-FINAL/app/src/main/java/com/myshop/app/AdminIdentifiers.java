package com.myshop.app;

/**
 * V-296 client-side admin ID helper. Owner email/mobile secrets are never embedded in the APK.
 * Real ADMIN authorization always comes from the backend session role.
 */
public final class AdminIdentifiers {
    private AdminIdentifiers() {}
    public static boolean isAdminIdentifier(String value) { return adminIdFor(value) != null; }
    public static String adminIdFor(String value) {
        if (value == null) return null;
        String v=value.trim();
        return (v.equals("0001")||v.equals("0002")||v.equals("0003")) ? v : null;
    }
}
