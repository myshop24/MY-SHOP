package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;

/** V-308 Play compliance legal center: Terms, Privacy Policy and Account Deletion. */
public class LegalActivity extends androidx.appcompat.app.AppCompatActivity {
    public static final String TYPE="type";
    public static final String TERMS="terms", PRIVACY="privacy", DELETE="delete";
    private final int BG=Color.rgb(247,249,254), NAVY=Color.rgb(22,29,63), MUTED=Color.rgb(88,100,132), BLUE=Color.rgb(43,89,221);

    @Override protected void onCreate(Bundle b){super.onCreate(b);build();}

    private void build(){
        String type=getIntent().getStringExtra(TYPE); if(type==null)type=PRIVACY;
        final String selectedType=type;
        ScrollView sv=new ScrollView(this); LinearLayout root=col(); root.setPadding(dp(16),dp(18),dp(16),dp(32)); root.setBackgroundColor(BG);
        LinearLayout h=row(); TextView back=t("‹",30,NAVY,true); back.setGravity(Gravity.CENTER); back.setOnClickListener(v->finish()); h.addView(back,lp(dp(46),dp(46)));
        TextView title=t(title(selectedType),21,NAVY,true); h.addView(title,wt(1)); root.addView(h);
        TextView body=t(body(selectedType),12,NAVY,false); body.setLineSpacing(0f,1.25f); body.setPadding(dp(14),dp(14),dp(14),dp(14)); body.setBackground(round(Color.WHITE,Color.rgb(222,227,240),16)); root.addView(body,top(lp(-1,-2),12));
        TextView open=t("Open official web page",12,Color.WHITE,true); open.setGravity(Gravity.CENTER); open.setBackground(round(BLUE,BLUE,14)); open.setOnClickListener(v->open(selectedType)); root.addView(open,top(lp(-1,dp(50)),12));
        if(DELETE.equals(selectedType)){
            TextView note=t("For an account you can still sign in to, use Settings & Privacy → Delete My Account. The web page is the external deletion-request path required for users who cannot use the app.",11,MUTED,false); note.setPadding(dp(8),dp(10),dp(8),0); root.addView(note);
        }
        sv.addView(root); setContentView(sv);
    }

    private String title(String t){if(TERMS.equals(t))return "Terms & Conditions";if(DELETE.equals(t))return "Account Deletion";return "Privacy Policy";}
    private String body(String t){
        if(TERMS.equals(t)) return "By using MY SHOP you agree to use the service lawfully and respectfully. You may not abuse other users, impersonate others, attempt unauthorized access, or misuse Live, Feed, Chat, Store or other features. Digital purchases distributed through Google Play use Google Play Billing. Community content may be moderated or removed when it violates safety rules or applicable law.\n\nThe current online Terms page is the controlling version and can be updated when product or legal requirements change.";
        if(DELETE.equals(t)) return "MY SHOP provides an in-app path and an external web path to request account deletion. Deletion removes or anonymizes account profile data and associated personal data that is not required to be retained. A non-public immutable internal user identifier and minimal security, anti-fraud, transaction or legal records may be retained only where necessary for security, financial reconciliation, abuse prevention or legal obligations. Retained data is not reused to recreate a deleted public profile.\n\nIf you can sign in, the fastest path is Settings & Privacy → Delete My Account.";
        return "MY SHOP may process information you provide when creating and using an account, such as name, email or mobile number, profile information, posts and media, messages, Live interaction data, purchase/transaction references and technical data needed to operate and secure the service. Microphone access is requested only for audio Live features.\n\nWe use data to provide account, social, Live, Store, moderation, security and support features. We do not sell your personal information to advertisers. You can control profile visibility, report or block users, and request account deletion.\n\nAccount deletion removes or anonymizes data except limited records that must be retained for security, anti-fraud, financial reconciliation or legal obligations. The online Privacy Policy is the controlling version and should be kept consistent with the Google Play Data safety form.";
    }
    private void open(String type){
        String path=TERMS.equals(type)?"/terms":DELETE.equals(type)?"/account-deletion":"/privacy";
        try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(BuildConfig.MYSHOP_BACKEND_URL+path)));}catch(Exception e){Toast.makeText(this,"Unable to open web page.",Toast.LENGTH_LONG).show();}
    }
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;} private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private TextView t(String s,float z,int c,boolean b){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);if(b)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;} private GradientDrawable round(int f,int st,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));g.setStroke(dp(1),st);return g;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams wt(float w){return new LinearLayout.LayoutParams(0,-2,w);} private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;} private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
