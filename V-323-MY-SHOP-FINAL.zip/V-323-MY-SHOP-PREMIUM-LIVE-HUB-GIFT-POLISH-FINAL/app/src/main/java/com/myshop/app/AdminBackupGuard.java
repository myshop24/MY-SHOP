package com.myshop.app;

import android.content.Context;
import android.widget.Toast;

/** Backup/restore is deliberately Admin-only. Authoritative backups belong on the server. */
public final class AdminBackupGuard {
    private AdminBackupGuard() {}

    public static boolean requireAdmin(Context context) {
        if (SessionManager.isAdmin(context)) return true;
        Toast.makeText(context, "শুধু মূল অ্যাডমিন ব্যাকআপ বা পুনরুদ্ধার করতে পারবেন।", Toast.LENGTH_LONG).show();
        return false;
    }

    public static boolean canRestore(Context context) {
        return SessionManager.isAdmin(context);
    }
}
