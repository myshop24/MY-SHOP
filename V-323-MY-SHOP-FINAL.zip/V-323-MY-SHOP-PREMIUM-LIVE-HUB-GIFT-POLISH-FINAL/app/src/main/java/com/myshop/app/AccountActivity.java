package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

/**
 * MY SHOP V-296 compact social profile + dedicated Wallet / Settings pages.
 * Account identity stays backend-authoritative. User ID is read-only and is never edited here.
 */
public class AccountActivity extends AppCompatActivity {
    private static final int PICK_AVATAR=7001, PICK_COVER=7002, PICK_PROFILE_PHOTO=7003, PICK_PROFILE_VIDEO=7004;
    private final ExecutorService imageIo=Executors.newFixedThreadPool(2);
    private ImageView avatar,cover,activeBadgeAnimation,profileComposerAvatar; private LinearLayout profileTimelineList; private TextView profileTimelineStatus; private EditText profileComposerText; private Uri pendingProfilePostUri; private String pendingProfilePostType="image"; private TextView name,id,contact,bio,coins,gold,membershipStatus,membershipExpiry,profileVip,profileTierBadge,profileMemberLine,profileLevelBadge,friendsCount,followersCount,followingCount,likesCount; private Button quickCoins,quickLevel,quickVip,quickGifts;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        avatar=findViewById(R.id.profileAvatar); cover=findViewById(R.id.profileCover); activeBadgeAnimation=findViewById(R.id.activeBadgeAnimation); name=findViewById(R.id.profileName); id=findViewById(R.id.profileId);
        contact=findViewById(R.id.profileContact); bio=findViewById(R.id.profileBio); coins=findViewById(R.id.coinBalance); gold=findViewById(R.id.goldBalance); membershipStatus=findViewById(R.id.membershipStatus);
        membershipExpiry=findViewById(R.id.membershipExpiry); profileVip=findViewById(R.id.profileVip); profileTierBadge=findViewById(R.id.profileTierBadge); profileMemberLine=findViewById(R.id.profileMemberLine); profileLevelBadge=findViewById(R.id.profileLevelBadge);
        friendsCount=findViewById(R.id.friendsCount); followersCount=findViewById(R.id.followersCount); followingCount=findViewById(R.id.followingCount); likesCount=findViewById(R.id.likesCount); quickCoins=findViewById(R.id.buyCoinsButton); quickLevel=findViewById(R.id.myLiveButton); quickVip=findViewById(R.id.membershipButton); quickGifts=findViewById(R.id.giftHistoryButton);
        profileComposerAvatar=findViewById(R.id.profileComposerAvatar); profileComposerText=findViewById(R.id.profileComposerText);
        profileTimelineList=findViewById(R.id.profileTimelineList); profileTimelineStatus=findViewById(R.id.profileTimelineStatus);
        View accountRoot=findViewById(R.id.accountRoot);
        if(accountRoot!=null){accountRoot.setOnApplyWindowInsetsListener((v,insets)->{int top=insets==null?0:insets.getSystemWindowInsetTop();v.setPadding(dp(10),Math.max(dp(10),top+dp(8)),dp(10),dp(24));return insets;});accountRoot.post(accountRoot::requestApplyInsets);}
        renderLocal(); loadMe(); loadCoins(); loadWallet(); loadSocialStats(); loadGiftCount(); loadTimelinePreview();

        findViewById(R.id.profileBack).setOnClickListener(v -> finish());
        findViewById(R.id.profileSettings).setOnClickListener(v -> startActivity(new Intent(this,ProfileSettingsActivity.class)));
        findViewById(R.id.changeAvatarButton).setOnClickListener(v -> chooseAvatar());
        findViewById(R.id.changeCoverButton).setOnClickListener(v -> coverActions());
        findViewById(R.id.profileButton).setOnClickListener(v -> editProfile()); findViewById(R.id.editBioButton).setOnClickListener(v -> editProfile());
        findViewById(R.id.profileShareButton).setOnClickListener(v -> shareProfile());
        findViewById(R.id.buyCoinsButton).setOnClickListener(v -> startActivity(new Intent(this,CoinWalletActivity.class)));
        findViewById(R.id.buyGoldButton).setOnClickListener(v -> startActivity(new Intent(this,GoldWalletActivity.class)));
        findViewById(R.id.membershipButton).setOnClickListener(v -> {Intent i=new Intent(this,StoreActivity.class);i.putExtra("category","BADGE");startActivity(i);});
        findViewById(R.id.withdrawButton).setOnClickListener(v -> startActivity(new Intent(this,CoinWalletActivity.class)));
        findViewById(R.id.coinHistoryButton).setOnClickListener(v -> showCoinHistory());
        findViewById(R.id.giftHistoryButton).setOnClickListener(v -> startActivity(new Intent(this,MyItemsActivity.class)));
        findViewById(R.id.sendGiftButton).setOnClickListener(v -> Toast.makeText(this,"Live room খুলে Broadcast-এ Gift পাঠানো যাবে।",Toast.LENGTH_LONG).show());
        findViewById(R.id.myLiveButton).setOnClickListener(v -> showLevelInfo()); View openLive=findViewById(R.id.openMyLiveButton); if(openLive!=null)openLive.setOnClickListener(v->startActivity(new Intent(this,MainActivity.class)));
        findViewById(R.id.passwordButton).setOnClickListener(v -> showPasswordSecurityDialog());
        Switch notifications=findViewById(R.id.notificationSwitch);
        notifications.setChecked(getPreferences(MODE_PRIVATE).getBoolean("notifications",true));
        notifications.setOnCheckedChangeListener((button,checked)->getPreferences(MODE_PRIVATE).edit().putBoolean("notifications",checked).apply());
        findViewById(R.id.reportButton).setOnClickListener(v -> Toast.makeText(this,"Support and report tools can be connected to the backend without changing your account data.",Toast.LENGTH_LONG).show());
        findViewById(R.id.blockButton).setOnClickListener(v -> Toast.makeText(this,"Block List",Toast.LENGTH_SHORT).show());
        findViewById(R.id.historyButton).setOnClickListener(v -> Toast.makeText(this,"History",Toast.LENGTH_SHORT).show());
        findViewById(R.id.galleryButton).setOnClickListener(v -> startActivity(new Intent(this,GalleryActivity.class)));
        findViewById(R.id.timelineButton).setOnClickListener(v -> openProfileSocial("posts"));
        findViewById(R.id.mediaGalleryButton).setOnClickListener(v -> openProfileSocial("videos")); View photos=findViewById(R.id.photosTabButton); if(photos!=null)photos.setOnClickListener(v->openProfileSocial("photos")); View reels=findViewById(R.id.reelsTabButton); if(reels!=null)reels.setOnClickListener(v->openProfileSocial("reels"));
        findViewById(R.id.privacyButton).setOnClickListener(v -> openProfileSocial("about"));
        findViewById(R.id.profilePhotoPostButton).setOnClickListener(v->pickProfilePost("image")); findViewById(R.id.profileVideoPostButton).setOnClickListener(v->pickProfilePost("video")); findViewById(R.id.profilePostButton).setOnClickListener(v->submitProfileTextPost());
        findViewById(R.id.logoutButton).setOnClickListener(v -> logout());
        smoothButtons(R.id.changeAvatarButton,R.id.changeCoverButton,R.id.profileButton,R.id.profileShareButton,R.id.buyCoinsButton,R.id.buyGoldButton,R.id.membershipButton,R.id.withdrawButton,R.id.coinHistoryButton,R.id.giftHistoryButton,R.id.sendGiftButton,R.id.myLiveButton,R.id.timelineButton,R.id.mediaGalleryButton,R.id.privacyButton,R.id.logoutButton,R.id.editBioButton,R.id.photosTabButton,R.id.reelsTabButton,R.id.openMyLiveButton);
    }

    @Override protected void onResume(){super.onResume();if(coins!=null){loadCoins();loadWallet();loadSocialStats();loadGiftCount();loadTimelinePreview();}}

    private void openProfileSocial(String tab){Intent q=new Intent(this,ProfileSocialActivity.class);q.putExtra("userId",SessionManager.getUserId(this));q.putExtra("tab",tab);startActivity(q);}

    private void renderLocal(){
        String uid=SessionManager.getUserId(this); String n=getPrefs("full_name"); String e=getPrefs("email"); String m=getPrefs("mobile"); String b=SessionManager.getBio(this);
        name.setText(n.isEmpty()?"MY SHOP User":n); id.setText("MY SHOP ID  •  "+(uid.isEmpty()?"Not assigned":uid));
        contact.setText(!e.isEmpty()?e:(!m.isEmpty()?m:"")); bio.setText(b); bio.setVisibility(b.isEmpty()?View.GONE:View.VISIBLE);
        String av=SessionManager.getAvatarUrl(this); if(!av.isEmpty()){ loadImage(av,avatar); if(profileComposerAvatar!=null)loadImage(av,profileComposerAvatar); }
        String cv=SessionManager.getCoverUrl(this); if(!cv.isEmpty()) loadImage(cv,cover); else cover.setImageDrawable(null);
    }
    private String getPrefs(String key){return getSharedPreferences("myshop_session",MODE_PRIVATE).getString(key,"");}

    private void loadMe(){String token=SessionManager.getToken(this); if(token.isEmpty())return; BackendClient.me(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{try{JSONObject u=d.optJSONObject("user");if(u==null)return;SessionManager.saveProfile(AccountActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""),u.optString("avatarUrl",""),u.optString("coverUrl",SessionManager.getCoverUrl(AccountActivity.this)),u.optString("bio",""));renderLocal();}catch(Exception ignored){}});}public void onError(String m){}});}
    private void loadCoins(){String token=SessionManager.getToken(this); if(token.isEmpty()){coins.setText("0 Coins");if(quickCoins!=null)quickCoins.setText("🪙\nMy Coins\n0");applyLevel(0,0,100000,0);return;} BackendClient.coins(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{long bal=d.optLong("balance",0);coins.setText(String.format("%,d Coins",bal));if(quickCoins!=null)quickCoins.setText("🪙\nMy Coins\n"+String.format("%,d",bal));applyLevel(d.optInt("level",0),d.optLong("totalPurchasedCoins",0),d.optLong("nextLevelAt",100000),d.optInt("levelProgress",0));});}public void onError(String m){runOnUiThread(()->{coins.setText("0 Coins");if(quickCoins!=null)quickCoins.setText("🪙\nMy Coins\n0");applyLevel(0,0,100000,0);});}});}

    private void editProfile(){ startActivity(new Intent(this,EditProfileActivity.class)); }

    private void chooseAvatar(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_AVATAR);}

    private void coverActions(){
        boolean has=!SessionManager.getCoverUrl(this).isEmpty();
        String[] actions=has?new String[]{"Choose new cover photo","Remove cover photo"}:new String[]{"Add cover photo"};
        new AlertDialog.Builder(this).setTitle("Cover Photo").setItems(actions,(d,which)->{
            if(has&&which==1){
                BackendClient.deleteCover(SessionManager.getToken(this),new BackendClient.Callback(){
                    public void onSuccess(JSONObject x){JSONObject u=x.optJSONObject("user"); if(u!=null){SessionManager.saveProfile(AccountActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""),u.optString("avatarUrl",""),u.optString("coverUrl",""),u.optString("bio","")); renderLocal();} Toast.makeText(AccountActivity.this,"Cover photo removed.",Toast.LENGTH_SHORT).show();}
                    public void onError(String m){Toast.makeText(AccountActivity.this,m,Toast.LENGTH_LONG).show();}
                });
            }else chooseCover();
        }).show();
    }

    private void chooseCover(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_COVER);}

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        if(requestCode==PICK_PROFILE_PHOTO||requestCode==PICK_PROFILE_VIDEO){uploadProfileMedia(data.getData(),requestCode==PICK_PROFILE_VIDEO?"video":"image");return;}
        if(requestCode!=PICK_AVATAR&&requestCode!=PICK_COVER)return;
        Uri uri=data.getData();
        try{
            InputStream in=getContentResolver().openInputStream(uri); String mime=getContentResolver().getType(uri); String fileName=requestCode==PICK_COVER?"cover.jpg":"avatar.jpg"; if(mime!=null&&mime.contains("png"))fileName=requestCode==PICK_COVER?"cover.png":"avatar.png";
            BackendClient.Callback cb=new BackendClient.Callback(){
                public void onSuccess(JSONObject d){try{JSONObject u=d.optJSONObject("user"); if(u==null)throw new Exception("missing user"); SessionManager.saveProfile(AccountActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""),u.optString("avatarUrl",""),u.optString("coverUrl",SessionManager.getCoverUrl(AccountActivity.this)),u.optString("bio","")); renderLocal(); Toast.makeText(AccountActivity.this,requestCode==PICK_COVER?"Cover photo updated.":"Profile photo updated.",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(AccountActivity.this,"Photo response invalid.",Toast.LENGTH_SHORT).show();}}
                public void onError(String m){Toast.makeText(AccountActivity.this,m,Toast.LENGTH_LONG).show();}
            };
            if(requestCode==PICK_COVER)BackendClient.uploadCover(SessionManager.getToken(this),in,fileName,mime==null?"image/jpeg":mime,cb);
            else BackendClient.uploadAvatar(SessionManager.getToken(this),in,fileName,mime==null?"image/jpeg":mime,cb);
        }catch(Exception e){Toast.makeText(this,"Could not open selected photo.",Toast.LENGTH_SHORT).show();}
    }

    private void pickProfilePost(String type){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("video".equals(type)?"video/*":"image/*");startActivityForResult(i,"video".equals(type)?PICK_PROFILE_VIDEO:PICK_PROFILE_PHOTO);}
    private void submitProfileTextPost(){String cap=profileComposerText==null?"":profileComposerText.getText().toString().trim();if(cap.isEmpty()){Toast.makeText(this,"Write something first.",Toast.LENGTH_SHORT).show();return;}BackendClient.feedText(SessionManager.getToken(this),cap,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{profileComposerText.setText("");Toast.makeText(AccountActivity.this,"Posted to MY FEED and your Timeline",Toast.LENGTH_SHORT).show();loadTimelinePreview();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AccountActivity.this,m,Toast.LENGTH_LONG).show());}});}
    private void uploadProfileMedia(Uri uri,String type){try{String mime=getContentResolver().getType(uri);String fileName=("video".equals(type)?"profile-video.mp4":"profile-photo.jpg");InputStream in=getContentResolver().openInputStream(uri);String cap=profileComposerText==null?"":profileComposerText.getText().toString().trim();BackendClient.feedUpload(SessionManager.getToken(this),in,fileName,mime==null?("video".equals(type)?"video/mp4":"image/jpeg"):mime,type,cap,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{if(profileComposerText!=null)profileComposerText.setText("");Toast.makeText(AccountActivity.this,"Posted to MY FEED and your Timeline",Toast.LENGTH_SHORT).show();loadTimelinePreview();});}public void onError(String m){runOnUiThread(()->Toast.makeText(AccountActivity.this,m,Toast.LENGTH_LONG).show());}});}catch(Exception e){Toast.makeText(this,"Could not open selected media.",Toast.LENGTH_SHORT).show();}}

    private void loadTimelinePreview(){
        if(profileTimelineList==null||profileTimelineStatus==null)return;
        String uid=SessionManager.getUserId(this); if(uid==null||uid.isEmpty()){profileTimelineStatus.setText("Timeline unavailable");return;}
        profileTimelineStatus.setText("Loading your posts…");
        BackendClient.userPosts(SessionManager.getToken(this),uid,"all",new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                profileTimelineList.removeAllViews();
                org.json.JSONArray a=d.optJSONArray("posts");
                if(a==null||a.length()==0){profileTimelineStatus.setText("No timeline posts yet.");return;}
                profileTimelineStatus.setText(a.length()+" post"+(a.length()==1?"":"s"));
                int max=Math.min(20,a.length());
                for(int i=0;i<max;i++){JSONObject p=a.optJSONObject(i);if(p!=null)profileTimelineList.addView(timelineCard(p));}
            });}
            public void onError(String m){runOnUiThread(()->profileTimelineStatus.setText("Timeline could not refresh."));}
        });
    }

    private View timelineCard(JSONObject p){
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(12),dp(10),dp(12),dp(10));c.setBackgroundResource(R.drawable.profile_social_tile);
        String cap=p.optString("caption","").trim(); if(!cap.isEmpty()){TextView t=new TextView(this);t.setText(cap);t.setTextColor(Color.rgb(37,49,80));t.setTextSize(11);c.addView(t,new LinearLayout.LayoutParams(-1,-2));}
        String type=p.optString("mediaType","text"),url=p.optString("mediaUrl","").trim();
        if("image".equals(type)&&!url.isEmpty()){ImageView im=new ImageView(this);im.setScaleType(ImageView.ScaleType.CENTER_CROP);c.addView(im,new LinearLayout.LayoutParams(-1,dp(220)));AnimatedAssetLoader.load(im,url);}
        else if(!url.isEmpty()&&("video".equals(type)||"reel".equals(type)||"short".equals(type))){Button b=new Button(this);b.setText("▶  Play video");b.setAllCaps(false);b.setOnClickListener(v->{Intent q=new Intent(this,ProfileMediaViewerActivity.class);q.putExtra("url",url);q.putExtra("type",type);q.putExtra("caption",cap);startActivity(q);});c.addView(b,new LinearLayout.LayoutParams(-1,dp(44)));}
        TextView meta=new TextView(this);meta.setText("♡ "+p.optInt("likeCount",0)+"    💬 "+p.optInt("commentCount",0)+"    "+p.optString("createdAt",""));meta.setTextColor(Color.rgb(104,115,143));meta.setTextSize(8.5f);meta.setPadding(0,dp(7),0,0);c.addView(meta,new LinearLayout.LayoutParams(-1,dp(30)));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(8);c.setLayoutParams(lp);return c;
    }

    private void loadImage(String url,ImageView target){imageIo.execute(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(4000);c.setReadTimeout(6000);Bitmap b=BitmapFactory.decodeStream(c.getInputStream());if(b!=null)runOnUiThread(()->{target.setAlpha(.45f);target.setImageBitmap(b);target.animate().alpha(1f).setDuration(140).start();});}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}});}

    private void loadGiftCount(){String token=SessionManager.getToken(this);if(token.isEmpty()||quickGifts==null)return;BackendClient.ownedItems(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->{org.json.JSONArray a=d.optJSONArray("items");int n=a==null?0:a.length();quickGifts.setText("🎒\nMy Items\n"+n);});}public void onError(String m){quickGifts.setText("🎒\nMy Items");}});}
    private void showLevelInfo(){String label=profileLevelBadge==null?"LV.0":profileLevelBadge.getText().toString();new AlertDialog.Builder(this).setTitle("MY SHOP Level").setMessage(label+"\n\n100,000 Coin = 1 Star • 1,000 Gold Coin = 1 Star. User-origin gifts/transfers add +1 Level per Star; Admin/Official-origin grants add +2 Levels per Star.").setPositiveButton("OK",null).show();}

    private void showCoinHistory(){
        BackendClient.coins(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                StringBuilder s=new StringBuilder(); s.append("Current balance: ").append(String.format("%,d",d.optLong("balance",0))).append(" Coins\n\n");
                org.json.JSONArray a=d.optJSONArray("transactions"); if(a==null||a.length()==0)s.append("No coin transactions yet."); else for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;s.append(x.optString("kind","Transaction")).append("  ").append(x.optInt("amount",0)>=0?"+":"").append(x.optInt("amount",0)).append(" coins\n").append(x.optString("created_at","")).append("\n\n");}
                new AlertDialog.Builder(AccountActivity.this).setTitle("🪙 Coin History").setMessage(s.toString()).setPositiveButton("CLOSE",null).show();
            }
            public void onError(String m){Toast.makeText(AccountActivity.this,m,Toast.LENGTH_LONG).show();}
        });
    }
    private void showGiftHistory(){
        BackendClient.giftHistory(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                StringBuilder s=new StringBuilder(); org.json.JSONArray a=d.optJSONArray("gifts"); if(a==null||a.length()==0)s.append("No gift transactions yet."); else for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;boolean sent=SessionManager.getUserId(AccountActivity.this).equals(x.optString("sender_user_id",""));s.append(sent?"Gift sent → ":"Gift received ← ").append(x.optInt("coins",0)).append(" coins\n").append(x.optString("gift_code","Gift")).append(" • ").append(x.optString("created_at","")).append("\n\n");}
                new AlertDialog.Builder(AccountActivity.this).setTitle("🎁 Gift History").setMessage(s.toString()).setPositiveButton("CLOSE",null).show();
            }
            public void onError(String m){Toast.makeText(AccountActivity.this,m,Toast.LENGTH_LONG).show();}
        });
    }

    private void buyCoinsDialog(){
        Intent i=new Intent(this,StoreActivity.class);i.putExtra("category","COIN");startActivity(i);
    }

    private void loadWallet(){
        String token=SessionManager.getToken(this); if(token.isEmpty())return;
        BackendClient.walletProfile(token,new BackendClient.Callback(){ public void onSuccess(JSONObject d){ runOnUiThread(()->{
            gold.setText(String.format("%,d Gold",d.optLong("goldBalance",0))); Button goldQuick=findViewById(R.id.buyGoldButton); if(goldQuick!=null)goldQuick.setText("🥇\nGold Coin\n"+String.format("%,d",d.optLong("goldBalance",0)));
            org.json.JSONArray badges=d.optJSONArray("badges");
            JSONObject active=(badges!=null&&badges.length()>0)?badges.optJSONObject(0):null;
            String code="FREE"; String expiry=""; String source="";
            if(active!=null){
                code=active.optString("badge_code",active.optString("badgeCode","FREE")).trim().toUpperCase();
                expiry=active.optString("expires_at",active.optString("expiresAt","")).trim();
                source=active.optString("source","").trim();
                String anim=active.optString("animation_url",active.optString("animationUrl","")).trim();
                String prev=active.optString("preview_url",active.optString("previewUrl","")).trim();
                if(activeBadgeAnimation!=null){ activeBadgeAnimation.setVisibility(View.VISIBLE); AnimatedAssetLoader.load(activeBadgeAnimation,!anim.isEmpty()?anim:prev); }
            } else if(activeBadgeAnimation!=null) activeBadgeAnimation.setVisibility(View.GONE);
            applyPremiumTier(code,expiry,source);
            applyLevel(d.optInt("level",0),d.optLong("totalPurchasedCoins",0),d.optLong("nextLevelAt",100000),d.optInt("levelProgress",0));
        }); } public void onError(String m){runOnUiThread(()->applyPremiumTier("FREE","",""));} });
    }


    private void applyLevel(int level,long purchased,long nextAt,int progress){
        if(profileLevelBadge==null)return;
        profileLevelBadge.setText("LV."+Math.max(0,level));
        profileLevelBadge.setContentDescription("Level "+Math.max(0,level)+" • "+String.format("%,d",Math.max(0,purchased))+" purchased coins");
        profileLevelBadge.setVisibility(View.VISIBLE);
        if(quickLevel!=null)quickLevel.setText("My Level\nLV."+Math.max(0,level));profileLevelBadge.clearAnimation();
    }

    private void loadSocialStats(){
        String token=SessionManager.getToken(this); if(token.isEmpty())return;
        BackendClient.socialStats(token,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{JSONObject st=d.optJSONObject("stats");if(st==null)return;animateCount(friendsCount,st.optInt("friends",0));animateCount(followersCount,st.optInt("followers",0));animateCount(followingCount,st.optInt("following",0));if(likesCount!=null)animateCount(likesCount,st.optInt("likes",st.optInt("postLikes",0)));});}
            public void onError(String m){}
        });
    }

    private void animateCount(TextView target,int value){
        target.animate().alpha(.45f).setDuration(70).withEndAction(()->{target.setText(String.valueOf(value));target.animate().alpha(1f).setDuration(120).start();}).start();
    }

    private void applyPremiumTier(String code,String expiry,String source){
        if(code==null||code.trim().isEmpty())code="FREE"; code=code.trim().toUpperCase();
        String label; int start,end,text;
        switch(code){
            case "ROYAL": label="ROYAL"; start=Color.rgb(255,214,96); end=Color.rgb(202,130,16); text=Color.rgb(45,27,0); break;
            case "VVIP": label="VVIP"; start=Color.rgb(233,103,255); end=Color.rgb(126,58,255); text=Color.WHITE; break;
            case "VIP": label="VIP"; start=Color.rgb(255,205,87); end=Color.rgb(255,154,66); text=Color.rgb(42,25,0); break;
            case "BLUE": label="BLUE ✓"; start=Color.rgb(72,157,255); end=Color.rgb(50,92,238); text=Color.WHITE; break;
            default: label="FREE MEMBER"; start=Color.rgb(52,38,85); end=Color.rgb(38,43,73); text=Color.rgb(220,225,243); code="FREE";
        }
        profileMemberLine.setText(label);if(quickVip!=null)quickVip.setText("👑\nBadge / Member\n"+(code.equals("FREE")?"None":label));
        profileMemberLine.setTextColor(text); profileMemberLine.setBackground(tierBackground(start,end));
        membershipStatus.setText(code.equals("FREE")?"Free Member":label+" Membership");
        if(code.equals("FREE")){
            membershipExpiry.setText("Blue • VIP • VVIP • Royal");
            profileVip.setVisibility(View.GONE); profileTierBadge.setVisibility(View.GONE);
        }else{
            String exp=expiry.isEmpty()?"No expiry":("Valid until  "+prettyDate(expiry));
            if(!source.isEmpty())exp += "  •  "+source.replace('_',' ');
            membershipExpiry.setText(exp);
            profileVip.setText(label); profileTierBadge.setText(label);
            profileVip.setTextColor(text); profileTierBadge.setTextColor(text);
            profileVip.setBackground(tierBackground(start,end)); profileTierBadge.setBackground(tierBackground(start,end));
            profileVip.setVisibility(View.GONE); profileTierBadge.setVisibility(View.VISIBLE);
            pulse(profileTierBadge);
        }
    }

    private GradientDrawable tierBackground(int start,int end){
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{start,end});
        g.setCornerRadius(dp(14)); g.setStroke(dp(1),Color.argb(150,255,255,255)); return g;
    }
    private void pulse(View v){
        v.clearAnimation();
        ObjectAnimator a=ObjectAnimator.ofFloat(v,"alpha",0.78f,1f); a.setDuration(1250); a.setRepeatCount(ValueAnimator.INFINITE); a.setRepeatMode(ValueAnimator.REVERSE); a.start();
    }
    private String prettyDate(String s){
        if(s==null)return ""; s=s.trim(); if(s.length()>=10)return s.substring(0,10); return s;
    }
    private void smoothButtons(int... ids){
        for(int id:ids){View v=findViewById(id);if(v==null)continue;v.setOnTouchListener((x,e)->{if(e.getAction()==android.view.MotionEvent.ACTION_DOWN)x.animate().scaleX(.97f).scaleY(.97f).alpha(.9f).setDuration(70).start();else if(e.getAction()==android.view.MotionEvent.ACTION_UP||e.getAction()==android.view.MotionEvent.ACTION_CANCEL)x.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(110).start();return false;});}
    }

    @Override protected void onDestroy(){imageIo.shutdownNow();super.onDestroy();}

    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}

    private void buyGoldDialog(){
        Intent i=new Intent(this,StoreActivity.class);i.putExtra("category","GOLD");startActivity(i);
    }

    private void membershipDialog(){
        Intent i=new Intent(this,StoreActivity.class);i.putExtra("category","BADGE");startActivity(i);
    }

    private void withdrawalDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(36,8,36,8); EditText g=input("Gold Coin amount","");g.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); EditText a=input("bKash/Nagad account number",""); box.addView(g);box.addView(a);
        String[] methods={"bKash","Nagad"}; new AlertDialog.Builder(this).setTitle("Withdraw Gold Coin").setView(box).setSingleChoiceItems(methods,0,null).setPositiveButton("Submit",(d,w)->{int selected=((AlertDialog)d).getListView().getCheckedItemPosition();int amount=toInt(g.getText().toString());if(amount<=0||a.getText().toString().trim().isEmpty()){Toast.makeText(this,"Enter amount and account number.",Toast.LENGTH_SHORT).show();return;}BackendClient.requestGoldWithdrawal(SessionManager.getToken(this),amount,selected==1?"nagad":"bkash",a.getText().toString().trim(),"Profile withdrawal",new BackendClient.Callback(){public void onSuccess(JSONObject x){Toast.makeText(AccountActivity.this,"Withdrawal request submitted.",Toast.LENGTH_LONG).show();loadWallet();}public void onError(String m){Toast.makeText(AccountActivity.this,m,Toast.LENGTH_LONG).show();}});}).setNegativeButton("Cancel",null).show();
    }
    private EditText input(String hint,String initial){EditText e=new EditText(this);e.setHint(hint);e.setText(initial==null?"":initial);e.setSingleLine(true);e.setPadding(dp(12),dp(8),dp(12),dp(8));return e;}

    private int toInt(String s){try{return Integer.parseInt(s.trim());}catch(Exception e){return 0;}}

    private void showPasswordSecurityDialog(){
        final String[] options={"Change Password","Forgot / Reset Password"};
        new AlertDialog.Builder(this).setTitle("🔐 Password / Reset").setItems(options,(d,which)->{
            if(which==0)showChangePasswordDialog(); else showForgotPasswordDialog();
        }).setNegativeButton("CANCEL",null).show();
    }

    private EditText passwordInput(String hint){
        EditText x=input(hint,"");
        x.setSingleLine(true);
        x.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return x;
    }

    private void showChangePasswordDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(36,8,36,0);
        EditText current=passwordInput("Current Password");
        EditText next=passwordInput("New Password (minimum 6 characters)");
        EditText confirm=passwordInput("Confirm New Password");
        box.addView(current);box.addView(next);box.addView(confirm);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Change Password").setView(box).setNegativeButton("CANCEL",null).setPositiveButton("CHANGE",null).create();
        dlg.setOnShowListener(q->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String old=current.getText().toString(),np=next.getText().toString(),cp=confirm.getText().toString();
            if(old.isEmpty()){current.setError("Enter current password");return;}
            if(np.length()<6){next.setError("Use at least 6 characters");return;}
            if(!np.equals(cp)){confirm.setError("Passwords do not match");return;}
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            BackendClient.changePassword(SessionManager.getToken(this),old,np,new BackendClient.Callback(){
                public void onSuccess(JSONObject d){runOnUiThread(()->{dlg.dismiss();new AlertDialog.Builder(AccountActivity.this).setTitle("Password changed").setMessage("Your password was changed securely. For your protection, sign in again with the new password.").setCancelable(false).setPositiveButton("SIGN IN",(x,w)->{SessionManager.clear(AccountActivity.this);Intent i=new Intent(AccountActivity.this,LoginActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(i);finish();}).show();});}
                public void onError(String m){runOnUiThread(()->{dlg.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);String msg=m==null?"Password change failed":m;if(msg.contains("CURRENT_PASSWORD_INCORRECT"))msg="Current password is incorrect.";else if(msg.contains("PASSWORD_UNCHANGED"))msg="New password must be different.";Toast.makeText(AccountActivity.this,msg,Toast.LENGTH_LONG).show();});}
            });
        }));
        dlg.show();
    }

    private void showForgotPasswordDialog(){
        final String identifier=SessionManager.getUserId(this);
        if(identifier==null||identifier.trim().isEmpty()){Toast.makeText(this,"MY SHOP ID is unavailable.",Toast.LENGTH_LONG).show();return;}
        BackendClient.securityQuestions(identifier,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->{
                String question=d.optString("question","Security question");
                LinearLayout box=new LinearLayout(AccountActivity.this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(36,8,36,0);
                TextView qv=new TextView(AccountActivity.this);qv.setText(question);qv.setTextSize(15);qv.setTextColor(Color.rgb(22,28,55));qv.setPadding(0,0,0,10);
                EditText answer=input("Security Answer","");answer.setSingleLine(true);
                EditText next=passwordInput("New Password (minimum 6 characters)");
                EditText confirm=passwordInput("Confirm New Password");
                box.addView(qv);box.addView(answer);box.addView(next);box.addView(confirm);
                AlertDialog dlg=new AlertDialog.Builder(AccountActivity.this).setTitle("Reset Password • ID "+identifier).setView(box).setNegativeButton("CANCEL",null).setPositiveButton("RESET",null).create();
                dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                    String a=answer.getText().toString().trim(),np=next.getText().toString(),cp=confirm.getText().toString();
                    if(a.isEmpty()){answer.setError("Enter security answer");return;}
                    if(np.length()<6){next.setError("Use at least 6 characters");return;}
                    if(!np.equals(cp)){confirm.setError("Passwords do not match");return;}
                    dlg.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                    BackendClient.resetPassword(identifier,a,np,new BackendClient.Callback(){
                        public void onSuccess(JSONObject r){runOnUiThread(()->{dlg.dismiss();new AlertDialog.Builder(AccountActivity.this).setTitle("Password reset").setMessage("Your password was reset securely. Sign in again with the new password.").setCancelable(false).setPositiveButton("SIGN IN",(z,w)->{SessionManager.clear(AccountActivity.this);Intent i=new Intent(AccountActivity.this,LoginActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(i);finish();}).show();});}
                        public void onError(String m){runOnUiThread(()->{dlg.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);String msg=m==null?"Reset failed":m;if(msg.contains("ANSWER_NOT_MATCHED"))msg="Security answer did not match.";Toast.makeText(AccountActivity.this,msg,Toast.LENGTH_LONG).show();});}
                    });
                }));
                dlg.show();
            });}
            public void onError(String m){runOnUiThread(()->Toast.makeText(AccountActivity.this,"Could not load the security question.",Toast.LENGTH_LONG).show());}
        });
    }

    private void shareProfile(){ try{Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"MY SHOP Profile");String uid=SessionManager.getUserId(this);String display=name==null?"MY SHOP User":name.getText().toString();i.putExtra(Intent.EXTRA_TEXT,display+" • MY SHOP ID "+uid+"\nMY SHOP — https://rapid-bush-62ea.myshopsatkania.workers.dev");startActivity(Intent.createChooser(i,"Share Profile"));}catch(Exception e){Toast.makeText(this,"Share is not available.",Toast.LENGTH_SHORT).show();}}

    private void logout(){String token=SessionManager.getToken(this);SessionManager.clear(this);Intent i=new Intent(this,LoginActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);startActivity(i);if(!token.isEmpty())BackendClient.logout(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){}public void onError(String m){}});}
}
