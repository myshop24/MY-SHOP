package com.myshop.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.ActivityManager;
import android.content.Context;
import android.graphics.drawable.AnimatedImageDrawable;
import android.os.Build;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import org.json.JSONObject;
import java.util.Locale;
import java.util.WeakHashMap;

/** V-319 lightweight, admin-configurable idle animation for Gift Store catalog tiles. */
public final class CatalogGiftAnimator {
    private static final WeakHashMap<ImageView, AnimatorSet> RUNNING = new WeakHashMap<>();
    private CatalogGiftAnimator() {}

    public static int clamp(JSONObject g, String key, int fallback) {
        return Math.max(0, Math.min(100, g == null ? fallback : g.optInt(key, fallback)));
    }

    public static boolean enabled(JSONObject g) {
        return g != null && g.optInt("catalog_animation_enabled", 1) == 1;
    }

    public static String resolvedType(JSONObject g) {
        String raw = g == null ? "AUTO" : g.optString("catalog_animation_type", "AUTO");
        String type = raw == null ? "AUTO" : raw.trim().toUpperCase(Locale.US);
        if (!"AUTO".equals(type)) return type;
        String n = g == null ? "" : g.optString("name", "").toLowerCase(Locale.US);
        if (n.contains("heart")) return "PULSE";
        if (n.contains("teddy") || n.contains("chocolate")) return "BOUNCE";
        if (n.contains("rose") || n.contains("jet")) return "FLOAT";
        if (n.contains("car")) return "SLIDE";
        if (n.contains("diamond") || n.contains("crown") || n.contains("star")) return "SPARKLE";
        if (n.contains("castle")) return "GLOW";
        return "PULSE";
    }

    public static int iconDp(JSONObject g) {
        int p = clamp(g, "catalog_preview_size", 68);
        return 42 + Math.round(p * 0.20f); // 42dp..62dp, safe inside a 66dp preview box.
    }

    public static void start(ImageView art, TextView sparkle, JSONObject g) {
        if (art == null || !enabled(g)) { stop(art, sparkle); return; }
        AnimatorSet existing = RUNNING.get(art);
        if (existing != null && existing.isRunning()) { startAnimatedDrawable(art); return; }
        stop(art, sparkle);

        int strength = clamp(g, "catalog_animation_strength", 42);
        int speed = clamp(g, "catalog_animation_speed", 45);
        int glow = clamp(g, "catalog_glow_particle", 35);
        ActivityManager am=(ActivityManager)art.getContext().getSystemService(Context.ACTIVITY_SERVICE);
        boolean lowRam=am!=null&&am.isLowRamDevice();
        if(lowRam){strength=Math.min(strength,36);speed=Math.min(speed,48);glow=Math.min(glow,20);}
        boolean loop = g.optInt("catalog_loop", 1) == 1;
        float s = strength / 100f;
        long duration = Math.max(520L, 1900L - speed * 12L);
        String type = resolvedType(g);
        float density = art.getResources().getDisplayMetrics().density;

        ObjectAnimator a;
        ObjectAnimator b = null;
        if ("BOUNCE".equals(type)) {
            a = ObjectAnimator.ofFloat(art, View.TRANSLATION_Y, 0f, -(3f + 10f * s) * density, 0f);
        } else if ("FLOAT".equals(type)) {
            a = ObjectAnimator.ofFloat(art, View.TRANSLATION_Y, (2f + 4f * s) * density, -(3f + 7f * s) * density, (2f + 4f * s) * density);
            b = ObjectAnimator.ofFloat(art, View.ROTATION, -(1.5f + 3f * s), 1.5f + 3f * s, -(1.5f + 3f * s));
        } else if ("ROTATE".equals(type)) {
            a = ObjectAnimator.ofFloat(art, View.ROTATION, -(4f + 9f * s), 4f + 9f * s, -(4f + 9f * s));
        } else if ("SLIDE".equals(type)) {
            a = ObjectAnimator.ofFloat(art, View.TRANSLATION_X, -(2f + 6f * s) * density, (2f + 6f * s) * density, -(2f + 6f * s) * density);
            b = ObjectAnimator.ofFloat(art, View.SCALE_X, 1f, 1f + .04f * s, 1f);
        } else if ("GLOW".equals(type)) {
            a = ObjectAnimator.ofFloat(art, View.ALPHA, .80f, 1f, .80f);
            b = ObjectAnimator.ofFloat(art, View.SCALE_X, 1f, 1f + .055f * s, 1f);
        } else if ("SPARKLE".equals(type)) {
            a = ObjectAnimator.ofFloat(art, View.SCALE_X, .98f, 1f + .08f * s, .98f);
            b = ObjectAnimator.ofFloat(art, View.ROTATION, -(2f + 5f * s), 2f + 5f * s, -(2f + 5f * s));
        } else { // PULSE and safe fallback
            a = ObjectAnimator.ofFloat(art, View.SCALE_X, .98f, 1f + .09f * s, .98f);
            b = ObjectAnimator.ofFloat(art, View.SCALE_Y, .98f, 1f + .09f * s, .98f);
        }

        a.setDuration(duration); a.setRepeatCount(loop ? ValueAnimator.INFINITE : 0); a.setRepeatMode(ValueAnimator.RESTART);
        AnimatorSet set = new AnimatorSet();
        if (b != null) { b.setDuration(duration); b.setRepeatCount(loop ? ValueAnimator.INFINITE : 0); b.setRepeatMode(ValueAnimator.RESTART); set.playTogether(a,b); }
        else set.play(a);
        if (sparkle != null) {
            sparkle.setText(glow >= 70 ? "✦  ✧  ✦" : glow >= 30 ? "✦   ✧" : "✦");
            sparkle.setVisibility(glow <= 0 ? View.INVISIBLE : View.VISIBLE);
            ObjectAnimator sp = ObjectAnimator.ofFloat(sparkle, View.ALPHA, .12f, Math.min(.95f,.25f+glow/120f), .12f);
            sp.setDuration(Math.max(420L,duration-120L));sp.setRepeatCount(loop?ValueAnimator.INFINITE:0);sp.setRepeatMode(ValueAnimator.RESTART);
            set.playTogether(sp);
        }
        set.addListener(new AnimatorListenerAdapter(){@Override public void onAnimationEnd(Animator animation){if(RUNNING.get(art)==animation)RUNNING.remove(art);}});
        RUNNING.put(art,set);set.start();startAnimatedDrawable(art);if(!loop)art.postDelayed(()->stopAnimatedDrawable(art),duration+120L);
    }

    public static void stop(ImageView art, TextView sparkle) {
        if (art == null) return;
        AnimatorSet set = RUNNING.remove(art); if (set != null) set.cancel();
        art.setTranslationX(0f);art.setTranslationY(0f);art.setRotation(0f);art.setScaleX(1f);art.setScaleY(1f);art.setAlpha(1f);
        if (sparkle != null) { sparkle.animate().cancel(); sparkle.setAlpha(.12f); }
        stopAnimatedDrawable(art);
    }

    public static void startAnimatedDrawable(ImageView art) {
        if (Build.VERSION.SDK_INT >= 28 && art != null && art.getDrawable() instanceof AnimatedImageDrawable) {
            AnimatedImageDrawable d=(AnimatedImageDrawable)art.getDrawable(); if(!d.isRunning())d.start();
        }
    }
    public static void stopAnimatedDrawable(ImageView art) {
        if (Build.VERSION.SDK_INT >= 28 && art != null && art.getDrawable() instanceof AnimatedImageDrawable) {
            AnimatedImageDrawable d=(AnimatedImageDrawable)art.getDrawable(); if(d.isRunning())d.stop();
        }
    }
}
