package com.myshop.app;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.view.ViewGroup;
import android.view.Gravity;
import android.graphics.Color;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    
    @Override protected void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_register); findViewById(R.id.backLoginButton).setOnClickListener(v->finish()); findViewById(R.id.languageButton).setOnClickListener(v->LanguageManager.showPicker(this,this::applyLanguage)); setupSpinner(); ((CheckBox)findViewById(R.id.terms)).setChecked(false); findViewById(R.id.termsLink).setOnClickListener(v->openLegal(LegalActivity.TERMS)); findViewById(R.id.privacyLink).setOnClickListener(v->openLegal(LegalActivity.PRIVACY)); findViewById(R.id.deleteInfoLink).setOnClickListener(v->openLegal(LegalActivity.DELETE)); findViewById(R.id.createButton).setOnClickListener(v->createAccount()); findViewById(R.id.googleRegisterButton).setOnClickListener(v->showSocialUpcoming("GOOGLE")); findViewById(R.id.facebookRegisterButton).setOnClickListener(v->showSocialUpcoming("FACEBOOK")); applyLanguage(); }

    private void setupSpinner(){
        Spinner s=findViewById(R.id.securityQuestion); int pos=s.getSelectedItemPosition(); if(pos<0)pos=0;
        ArrayAdapter<String> a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,LanguageManager.securityQuestionOptions(this)){
            private TextView style(View v, boolean dropdown){
                TextView t=(TextView)v; t.setTextColor(Color.rgb(14,39,79)); t.setTextSize(dropdown?15f:16f); t.setTypeface(null,android.graphics.Typeface.BOLD); t.setGravity(Gravity.CENTER_VERTICAL); t.setSingleLine(false); t.setPadding(dp(12),dp(9),dp(12),dp(9));
                if(dropdown)t.setBackgroundColor(Color.WHITE); return t;
            }
            @Override public View getView(int position, View convertView, ViewGroup parent){return style(super.getView(position,convertView,parent),false);}
            @Override public View getDropDownView(int position, View convertView, ViewGroup parent){return style(super.getDropDownView(position,convertView,parent),true);}
        };
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); s.setAdapter(a); if(pos<a.getCount())s.setSelection(pos);
    }

    private void applyLanguage(){
        ((Button)findViewById(R.id.languageButton)).setText("🌐  "+languageLabel());
        ((TextView)findViewById(R.id.registerTitle)).setText(LanguageManager.t(this,"register"));
        ((TextView)findViewById(R.id.registerSubtitle)).setText(LanguageManager.t(this,"createSubtitle"));
        ((EditText)findViewById(R.id.fullName)).setHint(LanguageManager.t(this,"fullName"));
        ((EditText)findViewById(R.id.email)).setHint(LanguageManager.t(this,"email"));
        ((EditText)findViewById(R.id.mobile)).setHint(LanguageManager.t(this,"mobile"));
        ((EditText)findViewById(R.id.password)).setHint(LanguageManager.t(this,"password"));
        ((EditText)findViewById(R.id.confirmPassword)).setHint(LanguageManager.t(this,"confirm"));
        ((TextView)findViewById(R.id.securityTitle)).setText(LanguageManager.t(this,"security"));
        ((TextView)findViewById(R.id.securityHint)).setText(LanguageManager.t(this,"securityHint"));
        ((EditText)findViewById(R.id.securityAnswer)).setHint(LanguageManager.t(this,"answer1"));
        ((CheckBox)findViewById(R.id.terms)).setText(LanguageManager.t(this,"terms")); ((Button)findViewById(R.id.createButton)).setText(LanguageManager.t(this,"register")); ((Button)findViewById(R.id.backLoginButton)).setText(LanguageManager.t(this,"alreadyLogin"));
        setupSpinner();
    }


    private void openLegal(String type){Intent i=new Intent(this,LegalActivity.class);i.putExtra(LegalActivity.TYPE,type);startActivity(i);}

    private void showSocialUpcoming(String provider){
        final Toast notice=Toast.makeText(this,"✦  "+provider+" SIGN UP  •  UPCOMING  ✦",Toast.LENGTH_SHORT);
        View view=notice.getView();
        if(view!=null){android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,new int[]{Color.rgb(0,190,255),Color.rgb(124,58,237),Color.rgb(255,122,0)});bg.setCornerRadius(dp(24));view.setBackground(bg);view.setPadding(dp(20),dp(12),dp(20),dp(12));view.setAlpha(0f);view.setScaleX(.96f);view.setScaleY(.96f);view.animate().alpha(1f).scaleX(1.04f).scaleY(1.04f).setDuration(180).withEndAction(()->view.animate().scaleX(1f).scaleY(1f).setDuration(160).start()).start();}
        notice.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL,0,dp(92));notice.show();
    }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    private String languageLabel(){String l=LanguageManager.get(this);return LanguageManager.EN.equals(l)?"English":LanguageManager.HI.equals(l)?"हिन्दी":LanguageManager.AR.equals(l)?"العربية":"বাংলা";}

    private void createAccount(){
        EditText name=findViewById(R.id.fullName),email=findViewById(R.id.email),mobile=findViewById(R.id.mobile),pass=findViewById(R.id.password),confirm=findViewById(R.id.confirmPassword); CheckBox terms=findViewById(R.id.terms);
        String nv=name.getText().toString().trim(),ev=email.getText().toString().trim(),mv=mobile.getText().toString().trim(),pw=pass.getText().toString();
        Spinner securityQuestion=findViewById(R.id.securityQuestion); int selected=securityQuestion.getSelectedItemPosition();
        String question=LanguageManager.securityQuestionKey(selected);
        String answer=((EditText)findViewById(R.id.securityAnswer)).getText().toString().trim();
        if(nv.isEmpty()){toast("Full Name is required.");return;} if(ev.isEmpty()&&mv.isEmpty()){toast("Email অথবা Mobile Number যেকোনো একটি দিন।");return;} if(!ev.isEmpty()&&!Patterns.EMAIL_ADDRESS.matcher(ev).matches()){toast("Enter a valid email address.");return;} if(pw.length()<6||!pw.equals(confirm.getText().toString())){toast("Use 6+ characters and make both passwords match.");return;} if(!terms.isChecked()){toast("Please accept the Terms & Conditions.");return;} if(selected==0||question.isEmpty()){toast("একটি Security Question নির্বাচন করুন।");return;} if(answer.isEmpty()){toast("Security Answer দিন।");return;}
        if(!BackendClient.configured()){toast("Backend URL এখনো সেট করা হয়নি।");return;} findViewById(R.id.createButton).setEnabled(false);
        BackendClient.register(nv,ev,mv,pw,question,answer,new BackendClient.Callback(){public void onSuccess(org.json.JSONObject data){try{org.json.JSONObject u=data.getJSONObject("user");String id=u.optString("userId","");Role role=Role.valueOf(u.optString("role","USER"));SessionManager.setRemoteSession(RegisterActivity.this,data.optString("token",""),role,id);SessionManager.saveProfile(RegisterActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""));Toast.makeText(RegisterActivity.this,"Account created. Your permanent User ID: "+id,Toast.LENGTH_LONG).show();Intent in=new Intent(RegisterActivity.this,MainActivity.class);in.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(in);finish();}catch(Exception e){toast("Server response invalid.");findViewById(R.id.createButton).setEnabled(true);}} public void onError(String m){toast(m);findViewById(R.id.createButton).setEnabled(true);}});
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
