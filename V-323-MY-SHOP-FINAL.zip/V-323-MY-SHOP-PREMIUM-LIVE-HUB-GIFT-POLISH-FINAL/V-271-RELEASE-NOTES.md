# MY SHOP V-271 — Verified Dashboard/Admin Implementation

- Based on V-270 and keeps the V-270 identity correction.
- Breaking News Admin controls are now explicit and prominent: A− SMALLER / A+ BIGGER with current sp value, live preview, visual RGB color pickers, HEX fields, Edit/Save/Delete.
- Added visual color pickers for Dashboard BG, Primary Blue, Purple and Pink/Magenta in addition to HEX fields.
- Breaking News marquee/right-to-left behavior remains unchanged; only size/colors are remotely controlled.
- Live/New User dashboard cards were enlarged and rebalanced to match the approved reference: larger circular avatar, NEW/LIVE badge, online dot, better Name+Level line, ID and full-width friend action.
- Requested state remains tappable to cancel a pending outgoing request; incoming request opens response flow.
- Four dashboard user slots remain responsive and use real backend Live users first, newest users when offline.
- Existing Dashboard flow, banner, Quick Links, MY Feed, notifications/messages and previous functions are preserved.
- Android identity: versionCode 271 / versionName 2.9.271. Worker identity: V-271 / 2.9.271.
