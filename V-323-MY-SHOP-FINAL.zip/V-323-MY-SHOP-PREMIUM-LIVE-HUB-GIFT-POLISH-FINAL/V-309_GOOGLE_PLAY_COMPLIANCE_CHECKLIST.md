# V-309 — Google Play Compliance QA Checklist

Status legend: `PASS-CODE` = implemented/validated in source; `NEEDS CONSOLE SETUP` = owner must configure Play/Google/Cloudflare; `NEEDS DEVICE QA` = signed-build/device testing required; `NEEDS WEBSITE/CONTENT` = owner must supply/verify public legal/support content.

| Area | Status | V-309 checkpoint |
|---|---|---|
| targetSdk / compileSdk 36 | PASS-CODE | Android config remains API 36, matching the Play requirement effective Aug 31, 2026 for standard new apps/updates. |
| versionCode/versionName | PASS-CODE | 309 / 2.9.309. |
| LegalActivity lambda compile fix | PASS-CODE | Click listener captures final `selectedType`; V-308 effectively-final compiler failure removed. |
| Play Billing dependency | PASS-CODE | `com.android.billingclient:billing:9.1.0` preserved. |
| User-paid digital goods | PASS-CODE | Google Play flow preserved; legacy direct-money digital purchase paths remain disabled. |
| Server purchase verification | PASS-CODE | Android Publisher API verification preserved. |
| Play product IDs | NEEDS CONSOLE SETUP | Products must exist and match paid Admin catalog product IDs. |
| Publisher API service account | NEEDS CONSOLE SETUP | `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` remains required by workflow. |
| Account deletion in app | PASS-CODE | Settings & Privacy → Delete My Account preserved. |
| Account deletion web path | PASS-CODE / NEEDS DEVICE QA | Worker `/account-deletion`; verify HTTP 200 after deployment. |
| Privacy / Terms pages | PASS-CODE / NEEDS WEBSITE/CONTENT | Public routes preserved; production owner/support contact must be real and current. |
| UGC report / block / moderation | PASS-CODE | V-308 protections preserved. |
| Startup ad dismiss control | PASS-CODE / NEEDS DEVICE QA | Skip control and 1–4 second Admin duration preserved. |
| Microphone/media/storage handling | PASS-CODE / NEEDS DEVICE QA | Existing permission design preserved; device denial/retry and media save flows still need release QA. |
| Data Safety declaration | NEEDS CONSOLE SETUP | Must match actual production behavior/SDKs. |
| Financial features declaration | NEEDS CONSOLE SETUP | Review wallet/reward/payout behavior in Play Console. |
| Ads declaration | NEEDS CONSOLE SETUP | Declare according to production startup-ad behavior. |
| Content rating / App access | NEEDS CONSOLE SETUP | Complete accurately and provide reviewer access/instructions. |
| Package/signing/update compatibility | PASS-CODE / NEEDS DEVICE QA | `applicationId` unchanged; permanent signing workflow preserved; signed update validation remains release gate. |
| D1/R2 bindings | PASS-CODE | Production binding names/IDs unchanged. |
| Live/Feed/Profile regression | NEEDS DEVICE QA | Full signed multi-user/device regression required before Production. |
