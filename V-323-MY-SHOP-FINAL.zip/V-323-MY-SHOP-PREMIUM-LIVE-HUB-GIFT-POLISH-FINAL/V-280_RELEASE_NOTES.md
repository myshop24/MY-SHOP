# MY SHOP V-280 — REAL LIVE FOUNDATION

- Go Live now opens the real Audio Live Room flow and publishes live presence to backend.
- Join Live opens a real-time backend-driven list of active live hosts only.
- Tapping a live host opens that exact host room.
- No fake/static live entries are shown in Join Live.
- Host heartbeat keeps live presence fresh; End Live removes presence.
- Audience join/leave updates viewer count server-side.
- Live room shows 12-seat premium audio-room foundation and host/audience controls.
- User ID displays with LV.x.
- Level rule: every 100,000 lifetime purchased coins = +1 level; spending coins does not reduce level.
- Level calculation excludes ordinary admin/store grants and uses completed purchase transaction kinds.
- RTC audio transport (Agora token/SDK) remains credential-gated and is not falsely marked active without server-side Agora configuration.
