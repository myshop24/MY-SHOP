# MY SHOP V-273 — Three Priority UI Fixes

1. Profile header: user name, ID and contact are anchored below the cover-photo boundary while the avatar may still overlap the cover. This prevents name/cover overlap on responsive screens.
2. Breaking News admin: clear integer font-size control using `−  13 px  +`, one-step increments, live preview, existing server save and runtime application preserved.
3. Dashboard people cards: removed NEW/LIVE overlay badges; name is a dedicated line; compact metadata line is `🆔 ID   👑 Lv.N`; purple level background removed; vertical gaps tightened; friend-request behavior and real backend data preserved.

No NEW/LIVE overlay label is used on profile images. Existing dynamic live/new-user selection behavior remains unchanged.
