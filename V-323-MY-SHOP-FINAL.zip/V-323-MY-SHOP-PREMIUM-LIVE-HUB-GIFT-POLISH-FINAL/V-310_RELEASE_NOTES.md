# MY SHOP V-310 — Play-safe Coin / Gold Coin & Creator Cash Out

## Mandatory Developer Notice #1 — Google Play Compliance / Rejection Prevention
Before every release, any Google Play rejection risk must be fixed and regression-tested.

## V-310 changes
- Paid Buy Coin / Buy Gold Coin UI is disabled for this Play release.
- Admin can grant Coin/Gold Coin as bonus/reward; these balances are spendable only and not cash-withdrawable.
- Live Gift receiver value now credits a separate Creator Earnings ledger instead of normal spendable Coin/Gold balance.
- Cash Out accepts only Creator Earnings, enforced server-side.
- MY SHOP Service Fee is Admin-configurable; default 10%.
- Example: gross 100,000 eligible earning units -> 10,000 Service Fee -> 90,000 net.
- Reference conversion is 100,000 units = Tk 600; after 10% fee, 90,000 net = Tk 540.
- Cash Out requests support bKash/Nagad and remain Pending for MY SHOP payout review.
- Purchased/bonus/spendable balances are never used by the withdrawal endpoint.
- Existing D1/R2 bindings and existing working features are preserved.

## Important
Coin/Gold Coin are MY SHOP virtual units; Admin does not need to buy or upload a stock of coins. Admin grants are created by the backend and audited.
