# MY SHOP V-297 — Master 32-Point Checklist

Base: V-296
Target: V-297 / Android versionCode 297 / versionName 2.9.297

1. Admin Locker Functional Fix
2. Admin Locker Premium Design
3. Bottom Navigation Safe Position
4. New Live = New Comment Session
5. Highlight Comment Rule
6. Live Name + Caption
7. Live Name 24-Hour Rule / 5,000 Coin
8. Live React Reward (10K milestone = +1,000 Coin)
9. Compact Profile Redesign
10. Settings & Privacy separate page
11. MY COINS Wallet
12. Gold Coin separate Wallet
13. Badge / Membership separate system
14. Live Theme / Wallpaper Store
15. Avatar Frame — Live Only
16. My Items / Inventory
17. Store Structure
18. Admin Panel Premium Rework
19. Automatic Finance Dashboard
20. VAT / Service Charge
21. User ID Investigation Center
22. Backend Preservation (D1/R2/API/identity/balances/live)
23. Google Play Readiness
24. Delivery + QA Rule
25. Bottom Navigation Height Correction — one system inset + small safe gap only
26. Admin Gate Full Visual Redesign
27. Audio Live Wallpaper Upload — Gallery/File -> R2 -> Preview -> Replace/Remove -> Save/Publish + visual color picker
28. Admin Panel Bengali + simple field descriptions
29. Live Comment UI + Highlight row + real timer + premium End Summary
30. Profile Timeline / Media / Share / Edit / Settings Fix
31. Startup/App Open Ad Size Guidance — 1080x1920 9:16 recommended, minimum 720x1280, preview/crop warning/no stretch
32. Live Join Request + Host Invite two-way speaker flow — User request -> Host accept -> seat; Host invite from audience -> User accept -> seat; session-scoped, 12-seat safe allocation

## Interpretation rule
Items 25–31 refine earlier items; they do not cancel them. Item 32 is additive.
