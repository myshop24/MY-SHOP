# MY SHOP V-272 — Four Critical Fixes

1. New User / Live fallback cards: fixed bottom clipping by increasing the live/new-user section and card row heights; full Add Friend / Requested / Respond button is visible.
2. Breaking News Admin: explicit A− / current sp / A+ controls plus separate visual Background and Text color pickers + HEX fields. Right-to-left ticker behavior remains unchanged.
3. Dashboard Theme: server-saved Dashboard BG / Primary Blue / Purple / Pink-Magenta are cached and trigger a deterministic dashboard rebuild; key live/new-user/dashboard accent components now consume the configured palette.
4. Password / Reset: Account & Security now provides secure authenticated Change Password and Security Question Reset flows. Passwords are never exposed; backend PBKDF2 hashing remains authoritative; successful changes invalidate sessions and require sign-in again.

Version identity: V-272 / 2.9.272 / versionCode 272.
