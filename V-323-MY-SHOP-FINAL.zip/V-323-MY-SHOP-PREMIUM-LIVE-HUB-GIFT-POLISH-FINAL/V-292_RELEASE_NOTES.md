# MY SHOP V-292 Release Notes

- Added light vertical spacing between the right-side Live Room actions.
- Order remains: Request → Gift → React → Share.
- Preserved V-291 bottom safe-area fix and all approved Live Room layout/behavior.
- No backend/schema behavior change; version markers updated to V-292 / 2.9.292.
