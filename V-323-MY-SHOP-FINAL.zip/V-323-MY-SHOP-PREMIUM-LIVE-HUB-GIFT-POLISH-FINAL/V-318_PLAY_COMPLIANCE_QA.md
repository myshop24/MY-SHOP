# MY SHOP V-318 — Google Play Compliance QA

Date checked: 2026-09-10

- PASS (source): compileSdk/targetSdk 36. Google Play requires Android 16 / API 36 for new mobile app submissions and app updates from 2026-08-31.
- PASS (source): Google Play Billing 9.1.0 dependency and purchase manager remain present for in-app digital goods/virtual currency.
- PASS (source preservation): UGC report/block/moderation code was not removed or weakened by V-318.
- PASS (source): Gift Admin is non-exported and gated by Admin session check.
- PASS (source): only existing INTERNET, RECORD_AUDIO, ACCESS_NETWORK_STATE and legacy maxSdk28 WRITE_EXTERNAL_STORAGE permissions remain; V-318 adds no new sensitive permission.
- PASS (source): D1/R2 bindings, account identity preservation and soft-delete gift history behavior remain intact.
- NEEDS PLAY CONSOLE / WEBSITE VERIFICATION: current Data Safety answers, privacy-policy URL, account-deletion URL/process, content rating, age audience settings, UGC moderation operations and all required declarations must match the production app/backend.
- NEEDS PRODUCT CONFIG VERIFICATION: Coin/Gold/Membership digital purchase SKUs offered in a Play-distributed build must remain routed through permitted Google Play Billing flows unless a current policy exception/program applies. Creator cash-out is a separate earned-value payout flow and must not be presented as an alternative purchase path for digital goods.

This checklist is a release-safety review, not a guarantee of Google Play approval.
