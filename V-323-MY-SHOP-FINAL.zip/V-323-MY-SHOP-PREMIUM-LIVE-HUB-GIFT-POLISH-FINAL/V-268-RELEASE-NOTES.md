# MY SHOP V-268 — Premium Auth + Locked User Cards + Remote Breaking News Style

## Completed
- Applied the approved final MY shop LIVE logo to the Android launcher icon and Auth hero logo.
- Premium Login board refreshed while preserving existing Email/Mobile/ID + Password authentication and Forgot Password flow.
- Premium Create Account board refreshed while preserving existing registration/backend/session behavior.
- Security Question selector is now a high-contrast white component with dark readable selected/drop-down text.
- Google and Facebook buttons are visible on Login and Create Account. Both intentionally show the premium animated `UPCOMING` notice; no OAuth is enabled yet.
- Dashboard user/friend action buttons use one fixed, reusable shell for `Friend`, `Respond`, `Requested`, and `Friends`, with single-line locked text to prevent overflow/layout breaking.
- Existing Facebook-style cover photo and real backend Friends / Followers / Following profile counts are preserved.
- Breaking News Admin now controls headline font size (10sp–24sp), headline text color, and headline background color with preview.
- Breaking News font/background settings are persisted to backend `dashboard_config`, so future style changes do not require a new APK.
- Worker schema repair is additive for the two new Breaking News color columns.

## Locked behavior
- Breaking News user UI remains animated 📣 + headline only.
- Existing app authentication, social/friend backend, profile cover/count logic, dashboard navigation, banners, feed and admin security must not regress.
- User card internal structure and action-button shell are fixed/reusable and must not be resized by future dashboard features.

## Build identity
- Version: 2.9.268
- Version code: 268
- Source build: MY SHOP V-268
