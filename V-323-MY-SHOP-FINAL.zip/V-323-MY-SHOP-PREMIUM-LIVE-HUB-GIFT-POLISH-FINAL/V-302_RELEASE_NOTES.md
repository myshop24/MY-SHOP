# MY SHOP V-302 Release Notes

## Purpose
V-302 promotes the corrected Bottom Navigation compile-fix package to the next release version requested by the owner.

## Preserved fixes
- Bottom Navigation `bottomNav` scope/reference compile correction is retained.
- Bottom Navigation full-width intent and smooth scroll hide/show behavior are retained.
- V-301 stability/live/timeline/admin fixes remain in the source.

## Version identity
- SOURCE_BUILD_ID: `MY SHOP V-302`
- SOURCE_VERSION_NAME: `2.9.302`
- Android versionCode: `302`
- Android versionName: `2.9.302`
- Worker health/build marker: `2.9.302` / `V-302`

## Safety
- Master GitHub Actions workflow unchanged.
- Permanent signing setup unchanged.
- Cloudflare D1/R2 configuration unchanged.
- No intentional redesign/removal of existing working features.
