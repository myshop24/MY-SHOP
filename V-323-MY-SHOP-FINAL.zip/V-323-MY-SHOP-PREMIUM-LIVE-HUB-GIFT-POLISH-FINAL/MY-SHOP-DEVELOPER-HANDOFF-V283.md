# MY SHOP Developer Handoff — V-283

Current checkpoint: V-283.

Completed in this version: regression-safe 12-seat Audio Live Room visibility fix based on the recorded V-282 test. The room now shows all 12 seats immediately even before backend room state finishes loading, while backend data remains authoritative after sync.

Preserve without redesign: Dashboard, LIVE STREAMING gateway, Feed, Profile, Friends/Followers, Notifications, Messenger, Admin, Wallet, Badge, Startup Media and all previously approved functions.

Next phase: connect secure real-time RTC audio (Agora/equivalent) after service credentials/token endpoint are configured. Do not place RTC App Certificate or private secrets inside the APK.
