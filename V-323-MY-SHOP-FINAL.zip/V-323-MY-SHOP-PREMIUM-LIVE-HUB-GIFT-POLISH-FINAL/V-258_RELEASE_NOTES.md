# MY SHOP V-258 — Startup Runtime Recovery

Base: **V-257-MY-SHOP-STARTUP-CRASH-HOTFIX**
Version: **2.9.258** (`versionCode 258`)

## Why V-258 exists
Real-device video from V-257 shows the app drawing the MY SHOP startup splash and then returning to the Android home screen before Login/Dashboard appears. That means the previous V-257 protection was incomplete: it protected the immediate `onCreate()` block but a later startup/ad handoff or LoginActivity failure could still terminate the visible task.

## V-258 changes
- Reworked `StartupAdActivity` as a guarded runtime launcher.
- Wrapped delayed startup/ad flow and media callbacks with fail-open handling.
- The launcher is no longer finished immediately when handing off to LoginActivity.
- Added a Login UI readiness marker. If LoginActivity crashes before drawing, StartupAdActivity becomes visible again and shows an in-place recovery login instead of dropping to the phone home screen.
- Added a minimal built-in recovery login using the existing backend/session flow.
- Successful login clears the launcher/login back stack before opening MainActivity.
- Removed the V-257 `values-v31` launcher-theme override and returned to a simple stable launcher theme with a non-white MY SHOP background.
- Existing Admin startup Image/Video ad loading, target link, cache and duration behavior are preserved.
- Existing V-256/V-257 Dashboard, LIVE STREAMING, Friend Request/Profile Sync, and UI polish changes are preserved.

## Scope protection
No feature outside startup/login runtime recovery was intentionally redesigned in V-258.

## Validation available in this workspace
- XML parse check
- Worker JavaScript syntax check
- Version identity check
- Java source parser-level sanity check (full Android compile requires Android SDK/GitHub Actions)
- ZIP integrity and SHA-256

Final runtime proof still requires installing the GitHub-built APK on the real Android device.

## Build identity correction
- Corrected `SOURCE_BUILD_ID.txt` from stale `MY SHOP V-257` to exact `MY SHOP V-258`.
- Corrected `SOURCE_VERSION_NAME.txt` to `2.9.258`.
- Corrected Worker health/build metadata to V-258.
- This resolves the GitHub Actions `SOURCE_BUILD_ID mismatch` preflight failure seen before Android compilation.
