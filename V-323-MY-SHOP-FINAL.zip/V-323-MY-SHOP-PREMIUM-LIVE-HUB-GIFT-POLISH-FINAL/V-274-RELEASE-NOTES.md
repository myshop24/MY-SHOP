# V-274 — Breaking News Font Control + Real App Online Presence

## Completed
1. **Breaking News font-size control made explicitly visible and reliable**
   - `BREAKING NEWS FONT SIZE` now has an always-visible `− / current px / +` controller.
   - Range remains 10–24.
   - `−` and `+` immediately update the live preview.
   - Save sends `breakingNewsTextSize` to the backend; Dashboard reads the saved value at runtime, so no APK update is needed for later size changes.

2. **New User / Live user green-dot behavior corrected**
   - Removed unconditional/static green dots from Dashboard profile cards.
   - A single **small 7dp green dot** appears only when backend `online=true`.
   - Online state is driven by real MY SHOP foreground presence, not fake data and not Live-stream status.
   - New `POST /v1/app/presence` endpoint + `myshop_app_presence` table.
   - Android application lifecycle sends foreground/background presence and a 30-second heartbeat.
   - Backend expires stale online state after 90 seconds if a process disappears without a clean background event.
   - Dashboard profile presence refreshes every 30 seconds while the Dashboard is visible; cached people data is forced offline so stale green dots are never shown.

## Verification targets
- Font buttons visibly render under the heading and clamp to 10–24.
- Live preview updates on every +/- tap.
- Save path preserves server-side size field.
- Dashboard consumes `breaking_news_text_size`.
- Offline/new users render **no green dot**.
- Foreground online users render **one small dot only**.
