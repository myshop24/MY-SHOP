-- MY SHOP V-284 premium live room additive schema.
CREATE TABLE IF NOT EXISTS myshop_live_viewers (
  host_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(host_id,user_id)
);
CREATE TABLE IF NOT EXISTS myshop_live_room_meta (
  host_id TEXT PRIMARY KEY,
  special_guest_id TEXT,
  locked INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
