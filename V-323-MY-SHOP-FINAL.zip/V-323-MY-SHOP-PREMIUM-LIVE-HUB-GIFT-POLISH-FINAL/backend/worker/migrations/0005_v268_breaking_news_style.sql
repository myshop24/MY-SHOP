-- V-268 additive Breaking News remote-style controls.
ALTER TABLE dashboard_config ADD COLUMN breaking_news_bg_color TEXT NOT NULL DEFAULT '#FFEFF7';
ALTER TABLE dashboard_config ADD COLUMN breaking_news_text_color TEXT NOT NULL DEFAULT '#414662';
