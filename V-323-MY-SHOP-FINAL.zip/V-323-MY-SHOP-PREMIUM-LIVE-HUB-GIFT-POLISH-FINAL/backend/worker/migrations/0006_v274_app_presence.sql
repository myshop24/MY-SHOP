-- V-274 real MY SHOP foreground/online presence.
CREATE TABLE IF NOT EXISTS myshop_app_presence (
  user_id TEXT PRIMARY KEY,
  active INTEGER NOT NULL DEFAULT 0,
  last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_myshop_app_presence_active ON myshop_app_presence(active,last_seen DESC);
