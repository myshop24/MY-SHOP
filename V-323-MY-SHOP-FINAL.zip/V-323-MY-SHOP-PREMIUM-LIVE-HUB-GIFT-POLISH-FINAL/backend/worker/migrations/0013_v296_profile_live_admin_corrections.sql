-- MY SHOP V-296: store ownership + Coin withdrawal tables.
-- Live session_id columns are added idempotently by ensureLiveRoomSchema() because
-- production V-295 may already have received those columns at runtime.

CREATE TABLE IF NOT EXISTS myshop_owned_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  catalog_id INTEGER NOT NULL,
  item_type TEXT NOT NULL,
  item_code TEXT NOT NULL,
  equipped INTEGER NOT NULL DEFAULT 0,
  expires_at TEXT,
  source TEXT NOT NULL DEFAULT 'PURCHASE',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id,catalog_id)
);
CREATE INDEX IF NOT EXISTS idx_owned_items_user ON myshop_owned_items(user_id,item_type,equipped,created_at);

CREATE TABLE IF NOT EXISTS myshop_coin_withdraw_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  coin_amount INTEGER NOT NULL,
  payment_method TEXT NOT NULL,
  account TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'PENDING',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_coin_withdraw_user ON myshop_coin_withdraw_requests(user_id,id);
