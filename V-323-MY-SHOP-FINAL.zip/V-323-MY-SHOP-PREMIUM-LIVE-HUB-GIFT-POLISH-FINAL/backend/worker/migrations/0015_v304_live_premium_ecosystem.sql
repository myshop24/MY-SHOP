-- MY SHOP V-304 premium live ecosystem (additive / idempotent where supported)
-- Runtime ensureLiveRoomSchema performs safe CREATE/ALTER with duplicate-column guards.

CREATE TABLE IF NOT EXISTS myshop_live_fan_club (
  host_id TEXT NOT NULL, user_id TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
  points INTEGER NOT NULL DEFAULT 0, joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(host_id,user_id)
);
CREATE INDEX IF NOT EXISTS idx_live_fan_club_host ON myshop_live_fan_club(host_id,active,points);

CREATE TABLE IF NOT EXISTS myshop_live_schedules (
  id INTEGER PRIMARY KEY AUTOINCREMENT, host_id TEXT NOT NULL, title TEXT NOT NULL, topic TEXT NOT NULL DEFAULT '',
  scheduled_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'SCHEDULED',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_live_schedules_host ON myshop_live_schedules(host_id,status,scheduled_at);

CREATE TABLE IF NOT EXISTS myshop_live_reminders (
  schedule_id INTEGER NOT NULL, user_id TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(schedule_id,user_id)
);

CREATE TABLE IF NOT EXISTS myshop_live_pk_rounds (
  id INTEGER PRIMARY KEY AUTOINCREMENT, host_a TEXT NOT NULL, host_b TEXT NOT NULL,
  session_a TEXT NOT NULL DEFAULT '', session_b TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'PENDING',
  started_at TEXT, ended_at TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_live_pk_hosts ON myshop_live_pk_rounds(host_a,host_b,status,created_at);
