-- V-293: repair live_room_meta title schema and add live gift/moderation tables.
ALTER TABLE myshop_live_room_meta ADD COLUMN title TEXT NOT NULL DEFAULT 'Let''s Talk Together';
CREATE TABLE IF NOT EXISTS myshop_live_room_admins (
  host_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(host_id,user_id)
);
CREATE TABLE IF NOT EXISTS myshop_live_sanctions (
  host_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT 'NONE',
  reason TEXT NOT NULL DEFAULT '',
  updated_by TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(host_id,user_id)
);
CREATE TABLE IF NOT EXISTS myshop_live_gifts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  currency TEXT NOT NULL CHECK(currency IN ('COIN','GOLD')),
  price INTEGER NOT NULL DEFAULT 1,
  preview_url TEXT NOT NULL DEFAULT '',
  animation_url TEXT NOT NULL DEFAULT '',
  animation_mime TEXT NOT NULL DEFAULT '',
  animation_enabled INTEGER NOT NULL DEFAULT 1,
  sound_url TEXT NOT NULL DEFAULT '',
  sound_enabled INTEGER NOT NULL DEFAULT 1,
  sound_volume INTEGER NOT NULL DEFAULT 70,
  size_mode TEXT NOT NULL DEFAULT 'MEDIUM',
  sort_order INTEGER NOT NULL DEFAULT 100,
  enabled INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS myshop_live_gift_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  host_id TEXT NOT NULL,
  sender_id TEXT NOT NULL,
  receiver_id TEXT NOT NULL,
  gift_id INTEGER NOT NULL,
  currency TEXT NOT NULL,
  price INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'COMPLETED',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS myshop_global_bans (
  user_id TEXT PRIMARY KEY,
  reason TEXT NOT NULL DEFAULT '',
  permanent INTEGER NOT NULL DEFAULT 1,
  banned_by TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
