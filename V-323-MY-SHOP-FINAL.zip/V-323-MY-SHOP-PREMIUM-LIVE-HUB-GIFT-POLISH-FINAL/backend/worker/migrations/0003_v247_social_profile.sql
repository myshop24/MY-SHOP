-- MY SHOP V-247 durable social-profile schema record.
-- Runtime repair in index.js remains authoritative for legacy databases and adds
-- cover_url / cover_object_key only when those columns are missing.

CREATE TABLE IF NOT EXISTS myshop_follows (
  follower_id TEXT NOT NULL,
  following_id TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(follower_id, following_id),
  CHECK(follower_id <> following_id)
);

CREATE INDEX IF NOT EXISTS idx_myshop_follows_following
  ON myshop_follows(following_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_myshop_follows_follower
  ON myshop_follows(follower_id, created_at DESC);

CREATE TABLE IF NOT EXISTS myshop_schema_meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO myshop_schema_meta(key,value,updated_at)
VALUES('v247_social_profile','247',CURRENT_TIMESTAMP)
ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=CURRENT_TIMESTAMP;
