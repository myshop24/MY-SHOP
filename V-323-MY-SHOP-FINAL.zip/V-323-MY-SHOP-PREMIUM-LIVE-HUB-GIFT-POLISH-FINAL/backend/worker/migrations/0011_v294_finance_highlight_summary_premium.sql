-- MY SHOP V-294: finance ledger, highlight comments, audit, slow mode, entry/combo settings
CREATE TABLE IF NOT EXISTS myshop_finance_config (id INTEGER PRIMARY KEY CHECK(id=1),platform_fee_percent REAL NOT NULL DEFAULT 10.0,highlight_comment_coin_price INTEGER NOT NULL DEFAULT 1000,updated_by TEXT NOT NULL DEFAULT '0001',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
INSERT OR IGNORE INTO myshop_finance_config(id,platform_fee_percent,highlight_comment_coin_price,updated_by) VALUES(1,10.0,1000,'0001');
CREATE TABLE IF NOT EXISTS myshop_value_ledger (id INTEGER PRIMARY KEY AUTOINCREMENT,tx_type TEXT NOT NULL,currency TEXT NOT NULL CHECK(currency IN ('COIN','GOLD')),sender_id TEXT NOT NULL,receiver_id TEXT NOT NULL DEFAULT '',host_id TEXT NOT NULL DEFAULT '',gift_id INTEGER NOT NULL DEFAULT 0,gross_amount INTEGER NOT NULL,fee_percent REAL NOT NULL DEFAULT 0,fee_amount INTEGER NOT NULL DEFAULT 0,net_amount INTEGER NOT NULL DEFAULT 0,platform_amount INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'COMPLETED',reference TEXT NOT NULL DEFAULT '',metadata TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_value_ledger_sender ON myshop_value_ledger(sender_id,created_at,id);
CREATE INDEX IF NOT EXISTS idx_value_ledger_receiver ON myshop_value_ledger(receiver_id,created_at,id);
CREATE INDEX IF NOT EXISTS idx_value_ledger_host ON myshop_value_ledger(host_id,created_at,id);
CREATE TABLE IF NOT EXISTS myshop_live_highlight_comments (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,user_id TEXT NOT NULL,message TEXT NOT NULL,coin_cost INTEGER NOT NULL DEFAULT 0,free_privilege INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'QUEUED',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS myshop_live_moderation_audit (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,actor_id TEXT NOT NULL,target_id TEXT NOT NULL,action TEXT NOT NULL,reason TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS myshop_live_entry_events (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,user_id TEXT NOT NULL,tier TEXT NOT NULL DEFAULT 'STANDARD',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
ALTER TABLE myshop_live_room_meta ADD COLUMN slow_mode_seconds INTEGER NOT NULL DEFAULT 0;
ALTER TABLE myshop_live_room_meta ADD COLUMN entry_effects_enabled INTEGER NOT NULL DEFAULT 1;
ALTER TABLE myshop_live_room_meta ADD COLUMN gift_combo_enabled INTEGER NOT NULL DEFAULT 1;
