-- MY SHOP V-285 Premium Audio Live master batch.
-- Additive migration; keeps existing V-284 tables/data intact while limiting active assignment to Seats 1-10 in Worker logic.
ALTER TABLE myshop_live_seats ADD COLUMN mic_on INTEGER NOT NULL DEFAULT 1;
ALTER TABLE myshop_live_seats ADD COLUMN speaking INTEGER NOT NULL DEFAULT 0;
ALTER TABLE myshop_live_seats ADD COLUMN network_quality TEXT NOT NULL DEFAULT 'GOOD';
ALTER TABLE myshop_live_room_meta ADD COLUMN title TEXT NOT NULL DEFAULT 'Let''s Talk Together';
ALTER TABLE myshop_live_room_meta ADD COLUMN topic TEXT NOT NULL DEFAULT 'Audio Live';
ALTER TABLE myshop_live_room_meta ADD COLUMN started_at TEXT;
ALTER TABLE myshop_live_room_meta ADD COLUMN peak_viewers INTEGER NOT NULL DEFAULT 0;
ALTER TABLE myshop_live_room_meta ADD COLUMN share_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE myshop_live_room_meta ADD COLUMN pinned_message TEXT NOT NULL DEFAULT '';
ALTER TABLE myshop_live_room_meta ADD COLUMN theme_key TEXT NOT NULL DEFAULT 'GUITAR_BLUE';
CREATE TABLE IF NOT EXISTS myshop_live_seat_locks (host_id TEXT NOT NULL,seat_no INTEGER NOT NULL,locked INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(host_id,seat_no));
CREATE TABLE IF NOT EXISTS myshop_live_events (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,user_id TEXT,event_type TEXT NOT NULL,message TEXT NOT NULL DEFAULT '',created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS myshop_live_comments (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,user_id TEXT NOT NULL,message TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS myshop_live_listener_seen (host_id TEXT NOT NULL,started_at TEXT NOT NULL,user_id TEXT NOT NULL,PRIMARY KEY(host_id,started_at,user_id));
CREATE TABLE IF NOT EXISTS myshop_live_history (id INTEGER PRIMARY KEY AUTOINCREMENT,host_id TEXT NOT NULL,title TEXT,topic TEXT,started_at TEXT,ended_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,duration_seconds INTEGER NOT NULL DEFAULT 0,peak_viewers INTEGER NOT NULL DEFAULT 0,total_listeners INTEGER NOT NULL DEFAULT 0,share_count INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS myshop_live_themes (theme_key TEXT PRIMARY KEY,name TEXT NOT NULL,background_url TEXT NOT NULL DEFAULT '',accent TEXT NOT NULL DEFAULT '#8A2BE2',enabled INTEGER NOT NULL DEFAULT 1,sort_order INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
INSERT OR IGNORE INTO myshop_live_themes(theme_key,name,background_url,accent,enabled,sort_order) VALUES('GUITAR_BLUE','Guitar Blue','','#5B67FF',1,0);
DELETE FROM myshop_live_seats WHERE seat_no > 10;
DELETE FROM myshop_live_seat_locks WHERE seat_no > 10;
