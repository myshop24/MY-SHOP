-- MY SHOP V-297: 12-seat Audio Live + two-way host/user call invitations.
PRAGMA foreign_keys=OFF;

ALTER TABLE myshop_live_seats RENAME TO myshop_live_seats_v296_backup;
CREATE TABLE myshop_live_seats (
  host_id TEXT NOT NULL,
  seat_no INTEGER NOT NULL,
  user_id TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'SPEAKER',
  muted INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  mic_on INTEGER NOT NULL DEFAULT 1,
  speaking INTEGER NOT NULL DEFAULT 0,
  network_quality TEXT NOT NULL DEFAULT 'GOOD',
  PRIMARY KEY(host_id,seat_no),
  UNIQUE(host_id,user_id),
  CHECK(seat_no BETWEEN 1 AND 12)
);
INSERT INTO myshop_live_seats(host_id,seat_no,user_id,role,muted,updated_at,mic_on,speaking,network_quality)
SELECT host_id,seat_no,user_id,role,muted,updated_at,COALESCE(mic_on,1),COALESCE(speaking,0),COALESCE(network_quality,'GOOD')
FROM myshop_live_seats_v296_backup WHERE seat_no BETWEEN 1 AND 12;
DROP TABLE myshop_live_seats_v296_backup;

CREATE TABLE IF NOT EXISTS myshop_live_invites (
  host_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  session_id TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'PENDING',
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(host_id,user_id,session_id)
);
CREATE INDEX IF NOT EXISTS idx_live_invites_user ON myshop_live_invites(user_id,status,expires_at);
DELETE FROM myshop_live_seat_locks WHERE seat_no>12;
PRAGMA foreign_keys=ON;

-- Session-scope join requests too, so stale requests can never carry into a new Live.
ALTER TABLE myshop_live_requests ADD COLUMN session_id TEXT NOT NULL DEFAULT '';
CREATE INDEX IF NOT EXISTS idx_live_requests_session ON myshop_live_requests(host_id,session_id,status,updated_at);
