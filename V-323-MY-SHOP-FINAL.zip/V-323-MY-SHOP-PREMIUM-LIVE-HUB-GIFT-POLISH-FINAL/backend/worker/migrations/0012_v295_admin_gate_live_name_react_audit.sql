-- MY SHOP V-295: Admin Locker, live-name policy, compact react milestones, message retention foundation
CREATE TABLE IF NOT EXISTS myshop_live_name_policy (
  user_id TEXT PRIMARY KEY,
  live_name TEXT NOT NULL,
  changed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS myshop_admin_gate (
  id INTEGER PRIMARY KEY CHECK(id=1),
  password_hash TEXT NOT NULL,
  security_question TEXT NOT NULL,
  security_answer_hash TEXT NOT NULL,
  updated_by TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS myshop_admin_gate_sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  unlocked_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
ALTER TABLE myshop_live_room_meta ADD COLUMN react_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE myshop_live_room_meta ADD COLUMN react_reward_milestone INTEGER NOT NULL DEFAULT 0;
ALTER TABLE myshop_messages ADD COLUMN hidden_from_sender INTEGER NOT NULL DEFAULT 0;
ALTER TABLE myshop_messages ADD COLUMN hidden_from_receiver INTEGER NOT NULL DEFAULT 0;
