-- MY SHOP V-248 additive migration
ALTER TABLE social_links ADD COLUMN icon_url TEXT NOT NULL DEFAULT '';
ALTER TABLE social_links ADD COLUMN image_url TEXT NOT NULL DEFAULT '';
CREATE TABLE IF NOT EXISTS myshop_live_presence (user_id TEXT PRIMARY KEY,active INTEGER NOT NULL DEFAULT 0,viewer_count INTEGER NOT NULL DEFAULT 0,last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_myshop_live_active ON myshop_live_presence(active,last_seen DESC);
CREATE TABLE IF NOT EXISTS myshop_profile_privacy (user_id TEXT PRIMARY KEY,posts_visibility TEXT NOT NULL DEFAULT 'PUBLIC',media_visibility TEXT NOT NULL DEFAULT 'PUBLIC',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
