-- MY SHOP V-308 • Google Play compliance + safety • additive only
CREATE TABLE IF NOT EXISTS myshop_safety_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT, reporter_id TEXT NOT NULL, target_user_id TEXT NOT NULL DEFAULT '',
  content_type TEXT NOT NULL, content_id TEXT NOT NULL DEFAULT '', reason TEXT NOT NULL, details TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'OPEN', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_myshop_safety_reports_status ON myshop_safety_reports(status,created_at DESC,id DESC);
CREATE INDEX IF NOT EXISTS idx_myshop_safety_reports_target ON myshop_safety_reports(target_user_id,created_at DESC,id DESC);
CREATE TABLE IF NOT EXISTS myshop_account_deletion_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL DEFAULT '', identifier TEXT NOT NULL DEFAULT '', contact TEXT NOT NULL DEFAULT '',
  reason TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'OPEN', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_myshop_account_deletion_requests_status ON myshop_account_deletion_requests(status,created_at DESC,id DESC);
CREATE TABLE IF NOT EXISTS myshop_play_purchases (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL, catalog_id INTEGER NOT NULL, play_product_id TEXT NOT NULL,
  purchase_token_hash TEXT NOT NULL UNIQUE, order_id TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'VERIFIED',
  google_payload TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_myshop_play_purchases_user ON myshop_play_purchases(user_id,created_at DESC,id DESC);
-- D1/SQLite does not support ADD COLUMN IF NOT EXISTS; runtime bootstrap performs this idempotently:
-- ALTER TABLE myshop_store_catalog ADD COLUMN play_product_id TEXT NOT NULL DEFAULT '';
