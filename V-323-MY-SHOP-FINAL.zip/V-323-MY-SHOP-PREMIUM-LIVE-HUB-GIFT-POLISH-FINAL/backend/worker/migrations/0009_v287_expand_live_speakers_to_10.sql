-- MY SHOP V-287: expand authoritative speaker sofa positions to 10 (seat_no 2..11).
-- Rebuild is required because the previous table CHECK constrained seat_no to <=10.
PRAGMA foreign_keys=OFF;
ALTER TABLE myshop_live_seats RENAME TO myshop_live_seats_v286_backup;
CREATE TABLE myshop_live_seats (
  host_id TEXT NOT NULL, seat_no INTEGER NOT NULL, user_id TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'SPEAKER', muted INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, mic_on INTEGER NOT NULL DEFAULT 1,
  speaking INTEGER NOT NULL DEFAULT 0, network_quality TEXT NOT NULL DEFAULT 'GOOD',
  PRIMARY KEY(host_id,seat_no), UNIQUE(host_id,user_id), CHECK(seat_no BETWEEN 1 AND 11)
);
INSERT INTO myshop_live_seats(host_id,seat_no,user_id,role,muted,updated_at,mic_on,speaking,network_quality)
SELECT host_id,seat_no,user_id,role,muted,updated_at,mic_on,speaking,network_quality FROM myshop_live_seats_v286_backup WHERE seat_no BETWEEN 1 AND 11;
DROP TABLE myshop_live_seats_v286_backup;
DELETE FROM myshop_live_seat_locks WHERE seat_no>11;
PRAGMA foreign_keys=ON;
