# MY SHOP V-314 — Google Play Compliance QA

| Check | Status | Note |
|---|---|---|
| compileSdk / targetSdk | PASS | 36 / 36 retained |
| Billing Library dependency | PASS | Billing 9.1.0 retained |
| Direct real-money digital purchase bypass | PASS | Worker still returns DIRECT_DIGITAL_PAYMENT_DISABLED for direct digital purchase routes |
| Creator Earnings separation | PASS | `myshop_creator_earnings` remains present |
| Spendable Coin/Gold cash withdrawal safeguard | PASS (source rule) | Withdrawal UI describes Creator Earnings-only cash-out; preserve this server-side rule |
| Startup ad sizing/display controls | PASS | 1080×2400 guidance, Full Image default, FIT/CONTAIN; existing dismiss/Skip behavior preserved |
| Admin login / authorization | PASS | AdminGate source unchanged from V-313; backend admin-role path preserved |
| UGC moderation / safety routes | PASS (preserved) | Safety/Admin moderation modules remain routed |
| Manifest permission review | PASS for current scope | INTERNET, RECORD_AUDIO, ACCESS_NETWORK_STATE, legacy WRITE_EXTERNAL_STORAGE maxSdk 28 |
| Public privacy contact | NEEDS WEBSITE/OWNER DETAIL | Before production publication, expose a real owner/developer/privacy contact in the public Privacy Policy or linked support surface; do not invent one in source |
| Play Console Data Safety / Financial Features / Ads / Content Rating / App Access | NEEDS CONSOLE SETUP | Must match actual production behavior |
| Full signed AAB build | NEEDS BUILD PIPELINE | Source snapshot has no executable Gradle wrapper; verify in GitHub Actions/Android build |

This checklist reduces rejection risk but does not guarantee Google Play approval; final review is controlled by Google.
