# V-308 — Play Console / Google Cloud / Cloudflare Setup

These are release prerequisites, not optional polish.

## 1. Google Play products

For every catalog item with a real-money price, create an active one-time in-app product in Play Console. The exact Product ID must match the value entered in MY SHOP Admin → Coin/Gold/Badge catalog → `Google Play Product ID`.

Examples of naming style only: `coin_1000`, `gold_500`, `vip_30d`, `vvip_30d`, `royal_30d`. Use the IDs you actually create; do not copy examples blindly.

After products exist, open each paid Admin catalog item, set the matching Product ID, preview, then Save/Publish.

## 2. Android Publisher API service account

Create/choose a Google Cloud service account for MY SHOP, enable the Android Publisher API, and grant only the Play Console permissions needed to verify purchases for `com.myshop.app`.

Export the service-account JSON securely. Never commit it to the repository or ZIP.

## 3. GitHub secret required by the V-308 workflow

Repository → Settings → Secrets and variables → Actions → New repository secret:

`GOOGLE_PLAY_SERVICE_ACCOUNT_JSON`

Value: the complete service-account JSON.

The release workflow intentionally stops if this secret is missing. It uploads the secret together with the exact Worker source version so a newer Worker cannot accidentally lose Billing verification.

Existing required secrets remain unchanged, including Cloudflare credentials, health probe key and Android signing secrets.

## 4. Worker URLs for Play Console

After V-308 Worker is deployed:

- Privacy Policy: `https://rapid-bush-62ea.myshopsatkania.workers.dev/privacy`
- Account deletion: `https://rapid-bush-62ea.myshopsatkania.workers.dev/account-deletion`
- Terms: `https://rapid-bush-62ea.myshopsatkania.workers.dev/terms`

Open all three in a normal browser before submitting the Play release. They must return public HTTP 200 pages.

## 5. Privacy-policy owner contact

Before production review, add the real MY SHOP owner/support contact details to the Privacy Policy. V-308 intentionally does not invent an email address or phone number.

## 6. Play Console declarations

Review and submit accurate answers for:

- Data Safety
- Financial features / wallet / rewards / payout features, where Play Console asks for them
- Ads declaration (startup advertisement system)
- Content rating
- User-generated content / social features where applicable
- App access: provide a working review account/instructions because MY SHOP requires login for many features

Use `V-308_DATA_SAFETY_INVENTORY.md` as a source-code inventory, but the final Play Console answers must match the production configuration and any third-party SDK behavior.

## 7. Test before Production

Use Internal testing first. Confirm with a licensed tester/test payment method:

1. Play product details load.
2. Google Play checkout opens.
3. Completed purchase is verified by Worker.
4. Entitlement appears once only.
5. App restart recovers a completed/unprocessed purchase.
6. Cancelled/pending purchase does not grant entitlement early.
7. Direct bKash/Nagad digital purchase UI is absent.
8. Withdrawal/payout requests remain separate from purchases.
9. Delete Account works and signs the user out.
10. Report/Block works across Feed, Profile, Chat and Live.
