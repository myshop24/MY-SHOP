# V-282 — SOURCE IDENTITY SYNCHRONIZATION FIX

This release preserves V-281 functionality and fixes the GitHub Actions preflight failure caused by a stale `SOURCE_BUILD_ID.txt` / `SOURCE_VERSION_NAME.txt`.

Current synchronized identity:
- ZIP release: V-282
- SOURCE_BUILD_ID: MY SHOP V-282
- SOURCE_VERSION_NAME: 2.9.282
- Android: versionCode 282 / versionName 2.9.282
- Worker: version 2.9.282 / build V-282

No approved Live/Dashboard/Feed/Profile/Messenger/Admin functionality is intentionally removed in this identity-only repair.
