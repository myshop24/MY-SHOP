# MY SHOP V-252 — Profile + Coin Level Polish

## Completed
- Reworked the own-profile header toward the approved social-profile mockup.
- Increased cover-photo presence and avatar overlap.
- Removed the large visual gap between the name and identity badges.
- Added a persistent `Lv. N` badge immediately beside the user's name.
- Added the same level badge to public user profiles so every ID can show its level.
- Preserved editable cover photo, editable avatar, Edit Profile, Share Profile, social counts, wallet, membership, timeline/media/privacy and account controls.
- Profile uses a cleaner light social identity surface while keeping MY SHOP purple/blue premium accents.

## Coin Level Rule
- Every account starts at `Lv. 0`.
- Each cumulative 100,000 credited/purchased Coins adds one level.
- 100,000 total purchased Coins = Lv. 1.
- 200,000 total purchased Coins = Lv. 2.
- 300,000 total purchased Coins = Lv. 3, and so on.
- Level is calculated from completed positive coin-credit transactions used by the current purchase/grant fulfilment pipeline, not from the spendable balance, so spending Coins does not reduce the earned level.

## Backend/API
- `/v1/coins` now returns `level`, `totalPurchasedCoins`, `nextLevelAt`, and `levelProgress`.
- `/v1/wallet/profile` returns the same level metadata.
- `/v1/users/profile` returns public `level` and `totalPurchasedCoins` for profile rendering.

## Verification
- Android XML parse: PASS.
- Worker JavaScript syntax: PASS.
- V-252 source/version/feature checks: PASS.
