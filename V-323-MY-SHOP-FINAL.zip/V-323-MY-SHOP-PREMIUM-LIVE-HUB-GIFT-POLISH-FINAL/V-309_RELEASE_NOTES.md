# MY SHOP V-309 — LegalActivity Compile Fix

Base: V-308 Google Play Compliance + Safety. This is a narrow compile/stability release; existing dashboard, Live, Feed, Profile, Cloudflare D1/R2, Play Billing, safety/moderation, and permanent signing workflow are preserved.

## Fixed

- Fixed `LegalActivity.java` Java lambda compilation failure (`local variables referenced from a lambda expression must be final or effectively final`).
- After resolving the nullable intent value, V-309 captures it as `final String selectedType` and uses that immutable value in the click listener and related legal-page rendering.
- No legal-page behavior or URLs were changed.

## Version / release identity

- Android: `versionCode 309` / `versionName 2.9.309`.
- Source identity: `MY SHOP V-309`.
- Worker health/build markers updated to `2.9.309` / `V-309`.
- GitHub workflow display/guard labels updated to V-309 without changing the protected build/sign/deploy logic.

## Preserved

- Approved MY SHOP Dashboard and Live Home behavior.
- Host + 12 user-seat Audio Live model.
- Existing Cloudflare D1/R2 bindings/schema and user-ID permanence rules.
- Google Play Billing 9.1.0 gate and server verification.
- Account deletion, Privacy/Terms pages, UGC Report/Block, Admin Safety tools.
- Permanent Android signing key restore/signing workflow.

## Build note

The exact compiler error visible in the V-308 GitHub Actions log is removed in source. Full signed Android `assembleRelease` remains the GitHub release workflow gate because the local artifact environment does not include the Android SDK/Gradle wrapper.
