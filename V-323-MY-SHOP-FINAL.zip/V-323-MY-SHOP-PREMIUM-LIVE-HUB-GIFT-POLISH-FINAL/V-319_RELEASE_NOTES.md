# MY SHOP V-319 — Animated Gift Catalog + Compile Fix

Base: V-318
Android: versionCode 319 / versionName 2.9.319
Worker: V-319

## Completed
- Fixed the GitHub compile failure shown by the user: `AudioLiveRoomActivity.java` now explicitly imports `android.widget.GridLayout`, covering the GridLayout references in the Gift Store grid/layout params.
- Added a separate **Catalog Preview Animation** layer for Live Gift Store tiles; it does not replace or weaken the existing full Live Send animation.
- Existing Gift Coin and Gold Coin gifts automatically receive catalog-animation defaults through additive D1 schema columns, so old published gifts become animated after the V-319 Worker schema initializes.
- Default type `AUTO` maps known existing gifts to sensible motion: Heart=pulse, Teddy/Chocolate=bounce, Rose/Jet=float, Car=slide, Diamond/Crown/Star=sparkle, Castle=glow; unknown gifts use a safe pulse.
- Added Admin controls per gift: Catalog Animation ON/OFF, type, Preview Size 0–100, Strength 0–100, Speed 0–100, Glow/Particle 0–100, Loop ON/OFF, custom Catalog GIF/WebP asset, Preview/Test, Save/Publish.
- Admin Coin and Gold Coin catalogs both expose the same controls; currency-lock protection remains unchanged.
- Live Gift Store uses the Admin-saved catalog settings from D1. Custom catalog animation URL is preferred for the tile; otherwise existing preview art is motion-animated locally.
- Visible-only performance guard: on-screen gift tiles animate; off-screen tile animations are stopped and restart when visible again.
- Low-RAM devices automatically cap catalog motion strength/glow for smoother scrolling.
- Existing reference-video flow is preserved: select gift -> one shared SEND -> successful backend response -> panel closes -> local full animation + sound immediately; remote delivery/dedupe remain unchanged.
- Existing Live Send Animation Size 0–100 and Sound Volume 0–100 remain separate from catalog-preview controls.
- D1 `my-shop-db`, R2 `MEDIA / my-shop-media`, Google Play Billing dependency, Admin gate, gift soft-delete/history, and Coin/Gold separation are preserved.

## Release gate
Source-level validation is recorded in `V-319_VALIDATION_REPORT.txt`.
This editing container does not contain Android SDK platform files / an executable project Gradle wrapper, so local APK/AAB compilation is not claimed. The included GitHub workflow remains the real Android compile/sign/upload gate.
