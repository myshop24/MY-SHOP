# MY SHOP V-253 — Five Corrections

Base: V-252, implementing the five user corrections recorded after V-251.

1. Dashboard hero/banner now uses a Facebook-cover-style 2.63:1 full-width display. Remote/portrait images fill the banner using center-crop without stretch. Banner Admin now shows the exact recommended HERO creative size: **1640 × 624 px (2.63:1)**.
2. Banner correction is applied in both user-side rendering and Admin guidance/preview so the earlier unresolved full-width/size-label issue is addressed together.
3. Live/New-user cards under Go Live / Join Live now show a compact backend level badge beside each name. Worker payloads for `/v1/live/profiles` and `/v1/people/new` include the real cumulative coin-purchase level.
4. Added a Quick Links section with 5 primary shortcuts: Facebook Page, Customer Support, MY SHOP Website, Gallery + External, See All. Admin can configure links/icons/images through existing managed feature cards. See All contains Earn & Reward, MY SHOP, Share App, Agent, and other shortcuts. Added a 4-agent directory with Admin-managed photo/name/link per agent, plus a Gallery + External hub for Photo/Audio/Video and icon-backed external links.
5. Rebuilt the owner Profile layout to match the approved wider social-profile reference: wider cover, overlapping avatar, compact name + level + VIP row, Friends/Following/Followers/Likes row, bio/edit, Edit/Share actions, compact Coins/Gifts/Level/VIP/Wallet strip, Posts/Photos/Videos/Reels/About tabs, preview media row, while preserving wallet/account/security functions below.

Build/version: `versionCode 253`, `versionName 2.9.253`.
