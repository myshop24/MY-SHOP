# MY SHOP V-307 Release Notes

Version: **MY SHOP V-307**  
Android: **versionCode 307 / versionName 2.9.307**  
Base: V-306 Profile/Host/Locker compile-fix final.

## Main rule preserved
The approved MY SHOP Main Dashboard structure is not redesigned. Header, Breaking News, Live section position, users, ads, Quick Links, MY Feed, and bottom navigation functions remain in their established flow. V-307 changes the Live entry behavior and applies localized stability/polish only.

## V-307 core changes
- Dashboard Live section now opens one dedicated **Live Home** entry instead of launching Go Live / Join Live directly.
- New `LiveHomeActivity`: real Live Now discovery, Go Live, Join Live, Following/Popular/New filters, and real new-user fallback when no live room is available.
- Join Live uses real backend rooms with short cache-first rendering and proper empty/error states.
- Host End Live now requires server-confirmed closure before summary; false `Live closed locally` fallback removed.
- Live viewer count is recalculated from active viewer presence and peak viewer is refreshed server-side.
- Live room UI visibly shows current viewers and Peak.
- Host-above + existing 12 User/Guest seat architecture, Join Request, Host Invite, mic state, moderation, and temporary Live comments are preserved.
- Store/Coin screen forced opaque, category chips compacted, and catalog made cache-first with retry state.
- Profile content/media made cache-first; photo/video viewer adds Save/Download via Android DownloadManager.
- Inbox keeps real-time polling/cache while adding compact refresh, Search, New Message, and relative timestamps.
- Chat/Profile/Feed timestamps use user-friendly relative time.
- Quick Link labels can use two lines instead of being forcibly clipped.
- Bottom navigation is slightly more compact/lower while preserving all existing destinations.
- Public profile email remains private; public profile backend output does not expose email.
- Existing Friend/Follow real backend counters and relationship actions are preserved.
- Existing Startup branded dark bridge and opaque Admin screens are preserved.

## Validation completed in source package
- `tools/validate_v307.py` passes all V-307 source guards.
- Worker JavaScript passes `node --check`.
- Android manifest XML parses.
- Existing V-304 validator confirms protected 12-seat architecture, temporary Live comments, Worker syntax, Android XML, and Java parser/syntax scan; old exact-label assertions intentionally differ because V-307 introduces Live Home/Join Live wording.

## Build note
This source package does not include a local `gradlew` launcher and the current offline environment has no system Gradle/Android SDK, so a full Android Gradle assemble was not executed locally. The included GitHub Actions workflow already provisions Gradle **8.11.1** and runs `gradle clean :app:assembleRelease`, which remains the release compile/signing checkpoint.
