# MY SHOP V-296 Release Notes

## Scope completed
V-296 is the correction/polish pass for the approved 24-point scope.

### Admin Locker
- Rebuilt the first-time Admin Locker setup so Password, Security Question and Security Answer can be entered and saved.
- Added preset security questions plus Custom Question, show/hide password, clear validation and premium Create/Unlock controls.
- Admin password is required once at the main Admin Gate; the unlocked admin session is reused inside the Admin Panel.
- Forgot Password supports Security Question recovery and the approved 2-of-3 Owner ID recovery path.
- Raw owner email/mobile recovery identifiers are not embedded in the APK/source; backend comparison uses SHA-256 hashes.

### Live Streaming corrections
- New live activation creates a unique live session ID.
- Live comments are scoped to the current session so old comments do not appear in a new live.
- Highlight comments are scoped to the current session and only recently queued highlights are returned, preventing repeated replay after refresh/reconnect. One purchase creates one highlight event.
- Preserved Live Name + compact one-line Caption behavior, 24-hour Live Name policy and 5,000 Coin early-change fee.
- Preserved 10K react milestone = 1,000 Coin reward with milestone dedupe and compact K/M display.

### Dashboard bottom navigation
- Bottom Home/Store/Video/Support/More card is physically lifted above Android gesture/3-button system UI using the real bottom window inset plus extra spacing.

### Profile / Wallet / Store
- Rebuilt the main Profile into a compact social-profile layout and removed the long Account/Security stack from the main page.
- Added dedicated Settings & Privacy page.
- Added dedicated MY COINS wallet with balance, Buy Coins, Coin Withdraw, Earned/Spent and history.
- Added dedicated Gold Coin wallet and history.
- Added My Items / Inventory for purchased Live-only Avatar Frames and Live Themes/Wallpapers.
- Badge/Membership remains account/ID entitlement; Live-only frames/themes do not decorate the normal profile avatar.
- Store now has clear category folders: Coin, Gold Coin, Badge/Member, Avatar Frame, Live Theme, Live Gifts, My Items.
- Store backend supports Frame/Theme/Wallpaper/Gift catalog types and owned-item entitlement/equip state.

### Admin management and finance
- Admin Store adds Avatar Frame, Live Theme, Wallpaper and Gift product types.
- Added clear Add New, Edit, Save/Publish, Enable/Disable and soft Delete actions; delete confirmation preserves existing ownership/history.
- Live Gift manager buttons were polished and destructive Delete is visually distinct.
- Preserved premium Admin Finance overview: Today, All-Time, category ledgers, VAT/Service Charge control, User ID investigation and retained message archive.
- Store Coin purchases now calculate the configurable platform VAT/service charge server-side and record the platform portion in the value ledger.

### Backend / migrations
- Added V-296 migration for owned items and Coin withdrawal requests.
- Session columns are added idempotently at runtime to avoid migration failure on databases already touched by V-295 runtime schema repair.
- Added owned item and Coin withdrawal APIs.

## Version
- versionCode: 296
- versionName: 2.9.296
- Worker health build: V-296 / 2.9.296
- targetSdk: 36
- compileSdk: 36
