# MY SHOP V-278 Release Notes

Base: V-277.

Changes requested from device QA:
- LIVE STREAMING visual structure remains the approved premium reference.
- Left live/broadcast signal no longer scales, rotates, or jumps. It now stays fixed and uses a strong smooth blink/glow cycle only.
- Go Live remains 35% and Join Live remains 65%; both keep subtle premium animation, with Join Live more prominent but without harsh bouncing.
- Bottom navigation is raised slightly above the device bottom edge to improve tap accessibility while preserving the dark floating premium design and existing navigation actions.
- Existing backend/API behavior, live presence, D1/R2 bindings, feed functionality, and admin long-press controls are preserved.
