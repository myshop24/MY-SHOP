# MY SHOP V-247 — Profile Social + Cover + Startup Safety

Built forward from the preserved V-246 full-project source. V-246 Dynamic Animated Badge/Admin Grant and the separate ROYAL, VVIP and VIP premium pages are retained.

## Implemented in V-247
- Backend-authoritative Friends / Followers / Following counts on own and public profiles.
- Follow / Unfollow API and public-profile button; accepted friends are counted for both users and Unfriend updates both sides.
- Facebook-style profile cover photo: Add / Change / Remove, R2-backed, shown on own and public profile.
- Startup Admin Ad controls keep Image/Video, Add/Edit/Delete/Save, optional link and strict 1–4 second duration, and now expose ON/OFF on both upload and saved-slot editing.
- Startup fail-open hardening: cached remote config for fast launch, short config/media watchdogs, no required bundled ad, and immediate app entry when media/config is missing, slow or failed. The selected 1–4 second countdown starts only after the creative is actually ready.
- Smooth press/fade feedback and network-action disabling for the new profile actions.
- Additive D1/runtime schema repair for cover fields and follows; no Permanent User ID mutation or destructive user migration.

## Explicitly not reopened in this pass
The older Home video thumbnail/playback + Photo/Video download task was removed from the current scope by the user. Existing carried-forward media code is preserved, not reworked here.

## Validation status
- Worker JavaScript syntax checked with `node --check`.
- Android XML resources parsed successfully.
- V-247 source identity/version markers checked.
- Full Android APK/device verification still requires the repository GitHub Actions build and on-device test; do not call this device-verified before that evidence exists.
