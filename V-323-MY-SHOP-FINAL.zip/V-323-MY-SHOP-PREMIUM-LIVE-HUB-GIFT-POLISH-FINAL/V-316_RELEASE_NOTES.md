# MY SHOP V-316 — Real Live Gift Starter Pack

## Completed
- Added 5 real Coin gifts: Rose (10), Heart (20), Teddy (50), Chocolate Gift (100), Star (200).
- Added 5 real Gold Coin gifts: Diamond (1,000), Royal Crown (2,000), Sports Car (5,000), Private Jet (10,000), Royal Castle (20,000).
- Bundled original local PNG gift artwork for all 10 gifts so the gift store/effects work even when Admin has not uploaded remote media.
- Bundled 10 original short WAV sound cues and mapped one sound to each starter gift.
- Live-board gift effects now animate by gift type (rise/pulse/bounce/spin/fly-through/reveal) and play the configured sound volume.
- Remote Admin preview/animation/sound URLs still override bundled fallback assets, preserving the existing Admin Gift Manager.
- Gift events are now included in Live room state for ~12 seconds so Host, speakers and audience receive/play the same completed gift event during the live polling loop.
- Sender-side duplicate playback is prevented with event-id tracking.
- Existing real gift transaction path is preserved: correct Coin/Gold wallet validation and debit, creator earnings credit, value ledger, Star/Level application and combo calculation.
- Added production-safe D1 migration for older `myshop_finance_config` schemas missing `coin_units_per_600_taka` and related columns, preventing the reported missing-column error.

## Regression safety
- Existing D1/R2 bindings and table names were not renamed or removed.
- Existing Live seat/request/invite/comment/theme/PK/moderation flows were left intact.
- Admin can still upload/replace gift preview, animation and sound files through R2.
- Existing custom/published gifts remain supported.

## Live test checklist
1. Join a real Audio Live from two devices/accounts.
2. Open Gift Store on the sender and confirm Coin / Gold Coin tabs and balances.
3. Send each Coin starter gift and verify Coin balance decreases only.
4. Send each Gold starter gift and verify Gold Coin balance decreases only.
5. Confirm sender, host and second viewer see the gift effect within the live refresh window.
6. Confirm each starter gift plays its own short sound cue.
7. Confirm insufficient balance returns an error and no effect/ledger credit occurs.
8. Confirm custom Admin-uploaded animation/sound still overrides bundled fallback.

## Build note
- Worker JavaScript syntax checked with `node --check`.
- This environment does not contain an Android SDK/Gradle installation, so APK compilation could not be executed locally; the repository GitHub build workflow remains the release compile gate.
