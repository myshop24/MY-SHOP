# V-308 — Data Safety Inventory (source-code audit aid)

This is an implementation inventory, not a substitute for the final Play Console Data Safety questionnaire. Verify production behavior and every SDK before submitting.

## Data the service can process

- Account identifiers: permanent MY SHOP user ID, name, email and/or mobile number.
- Authentication/security: password hash, security-question answers as hashes, session tokens.
- Profile data: avatar, cover, bio, profile/social settings.
- User-generated content: Feed text, photos, videos, Gallery media, comments.
- Social graph: friend requests/friendships, follows, block relationships.
- Private communication: direct messages.
- Live service data: room/host/seat state, join/invite state, viewer presence, reactions, temporary Live comments, microphone audio handled by the RTC path while participating in Audio Live.
- Purchase/entitlement data: Play product ID, hashed purchase token, Play order/verification payload, owned digital items, Coin/Gold transactions.
- Payout/withdrawal requests: requested amount, payout method and account supplied by user.
- Safety/moderation: user reports, report reason/details, moderation state.
- Account deletion: deletion request identifier/contact until processed; these fields are cleared when authenticated deletion completes for a matched account.
- Operational data: limited network/app/server timestamps and health/security logs required to run and protect the service.

## Storage / transmission paths found in source

- Cloudflare D1: account, social, content metadata, messages, wallet/entitlement, safety and moderation records.
- Cloudflare R2: user-uploaded media and managed media assets.
- Google Play / Android Publisher API: user-paid digital purchase transaction verification.
- RTC provider path: Audio Live real-time media when enabled/configured.

## Account deletion behavior

Authenticated deletion removes or anonymizes profile/contact information, sessions, private messages, owned user content/media references, social links, presence/live state and notification data where implemented. R2 user-owned media is deleted where object keys are known.

A non-public immutable MY SHOP ID and minimal security/fraud-prevention/transaction/payout/legal records may be retained when necessary. The ID is never reassigned to another person.

## Items to confirm in Play Console

- Whether each collected data type is required or optional.
- Whether any data is shared with a service provider under Play's Data Safety definitions.
- Encryption in transit for all production endpoints.
- Deletion/retention policy text matches actual operations.
- RTC provider data handling and any analytics/crash SDKs present in the final build.
- Startup ad provider/data handling if a third-party ad network is later added.
