# MY SHOP V-244 — Dynamic Premium Catalog

- Admin-controlled Coin / Gold Coin / Badge / Membership catalog.
- Backend-authoritative money and Coin pricing; APK no longer asks users to invent prices.
- ROYAL → VVIP → VIP display priority.
- Admin can upload animated WebP/GIF/PNG/JSON badge assets to R2.
- Admin can set title, code, type, units, price, Coin price, duration, benefits, priority, limited-edition and enabled state.
- Admin Catalog grant binds a product to a 4-digit User ID.
- Granted badge/membership becomes a backend entitlement and loads automatically on Profile.
- Profile supports animated WebP/GIF display using Android native AnimatedImageDrawable (API 28+) with fallback.
- Users can open My Badges and select the active display badge.
- Catalog purchases use Product ID; server looks up authoritative price/units/duration.
- Existing wallet/manual grant foundation preserved.
