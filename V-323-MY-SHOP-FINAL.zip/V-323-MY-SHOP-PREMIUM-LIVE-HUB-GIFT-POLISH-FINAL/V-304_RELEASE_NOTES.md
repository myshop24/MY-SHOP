# MY SHOP V-304 Release Notes

Version: **MY SHOP V-304**  
Android: **versionCode 304 / versionName 2.9.304**  
Worker marker: **V-304 / 2.9.304**

## V-304 Master 30-Point Scope
1. Instant Live Comment Send with optimistic local feedback.
2. Duplicate comment protection using one-tap UI lock plus client nonce/server de-duplication.
3. Live comments are transient session data only; no retained Live-comment history. Active-session rows are capped/cleaned and deleted on Live End.
4. Separate premium comment bubbles with readable `Name LV.x : Comment` format.
5. Fresh timer per live session using the current session ID/server elapsed time.
6. Rejoin uses only the active session; local timer state is cleared on end/destroy.
7. Gift catalog prefetch and immediate Gift panel response.
8. Join Request reaches Host with Accept/Decline controls.
9. Host can invite audience users to the speaker/call flow; invited user can Accept/Decline.
10. Muted microphone shows a red crossed-mic marker.
11. Active speaker gets an animated avatar ring.
12. Live Goal: Coin / Supporters / Minutes / Viewers targets.
13. Hourly Top + Top Supporters data and room display.
14. VIP/VVIP/ROYAL room treatment: entry, name/chat/seat styling.
15. In-room Mini Profile actions.
16. Host Room Moderator controls are preserved and surfaced.
17. Host pinned notice/comment control.
18. Network quality indicator + reconnect state/recovery UI.
19. Room Welcome / Rules configuration.
20. Live End summary + audience Follow Host prompt.
21. Fan Club / Supporter Club with points/member ranking.
22. Host Live Level + Room Level calculations/display.
23. Advanced Gift presentation: combo/streak + large/rare gift spotlight + Top Gifter support.
24. Creator Profile/Creator Center analytics, live history and supporter metrics; Live comments are not stored there.
25. Live Shop product pinning and in-room product CTA.
26. Discover/Ranking screen: Live Now, Friends, New Host, Trending, Top Supporters, Shop Live, Talk Room.
27. Dashboard Live hierarchy wording/polish while preserving the approved existing dashboard structure.
28. Friendly PK/Battle foundation with invite/accept/decline/end and gift-value scoring.
29. Live achievements/milestone celebration UI and Creator Center achievements.
30. Scheduled Live + Remind Me + notification on matched scheduled-live start.

## Regression locks
- Preserve 12-seat Audio Live architecture and existing role/request/invite controls.
- Preserve Feed/Profile/Shop existing working flows.
- Preserve application ID, master GitHub workflow, Cloudflare D1/R2 binding names/IDs, and existing project ownership/signing setup.
- Do not permanently store Live-room comment history.

## Verification boundary
Source-level/static validation is included in `V-304_VALIDATION_REPORT.txt`. Full Android APK compilation and real multi-device RTC/network behavior require the repository GitHub Actions/Android toolchain and device testing; this local environment has no Android SDK/Gradle wrapper executable, so those are not falsely marked as locally compile-passed.
