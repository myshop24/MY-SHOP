# MY SHOP V-265

- versionCode: 265
- versionName: 2.9.265
- Build-size cleanup release based on V-264.
- Removed non-runtime design-reference images to keep the source ZIP below GitHub's web-upload size limit.
- Premium Login/Create Account UI and Google UPCOMING behavior are preserved.
