# MY SHOP V-289 Release Notes

V-289 implements the owner's final approved premium Audio Live Room layout without redesigning the Dashboard or changing the core backend contract.

## Live Room visual/layout corrections
- Host block is compact and border-free; profile + name/ID/LV/Coin/Gold remain at the upper-left.
- The active-user strip is on the SAME horizontal line as the Host name block, on its right side.
- Exactly 6 active user profiles can be shown directly in that header strip. Remaining users open from one `>` control at the far-right.
- Removed the separate second audience/user row below the Host.
- Special Guest stays centered below the Host/user line.
- HH:MM timer is physically to the LEFT of the Special Guest profile icon.
- `✨ SPECIAL GUEST ✨` is directly BELOW the guest icon.
- Removed the old helper text (`Host can spotlight a speaker here`).
- Speaker stage remains exactly 10 positions, 5 + 5. Occupied positions show a circular user profile; empty positions show the golden sofa. No visible seat-number text.
- Gift and React are vertical: Gift above React, attached to the right side of the comments area immediately above the comment composer.
- Bottom controls are one compact row and remain fully visible within the no-scroll single-screen room.
- Audience Request-to-Speak moved into the bottom compact controls to avoid unnecessary vertical crowding.

## Data/behavior
- Header active users are driven by real `viewerProfiles` data; no fake users are inserted.
- `>` opens the full active-user list.
- Existing backend seat range 2–11 (10 speakers) remains unchanged.
- Existing room comments, pin, themes, share, moderation hooks, live state, reconnect state, and live summary are preserved.
- Audio RTC (Agora/equivalent) is still a future integration phase; this release is UI/state/backend preparation, not production RTC voice transport.

## Version identity
- SOURCE_BUILD_ID: MY SHOP V-289
- SOURCE_VERSION_NAME: 2.9.289
- Android versionCode: 289
- Android versionName: 2.9.289
- Worker health identity: 2.9.289 / V-289

## Migration
No new D1 schema migration is added in V-289. Historical migration `0009_v287_expand_live_speakers_to_10.sql` remains unchanged and must not be renamed.
