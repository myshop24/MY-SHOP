# V-320 Google Play Compliance QA

- PASS (source): compileSdk 36 / targetSdk 36 retained for 2026 mobile app-update target API requirement.
- PASS (source): package name and release signing configuration path preserved.
- PASS (source): Google Play Billing dependency remains present for digital-goods purchase support.
- PASS (regression): this UI release does not add a new sensitive permission.
- PASS (regression): existing UGC/report/block/moderation code paths were not removed.
- NEEDS BUILD: signed APK/AAB verification must run in GitHub Actions / Android SDK environment.
- NEEDS PLAY CONSOLE: Data Safety, content rating, financial features, ads, account deletion and store-listing declarations must match the production configuration at submission time.
- NEEDS RUNTIME QA: verify microphone/media/storage behavior and all digital purchase paths on the release build.
