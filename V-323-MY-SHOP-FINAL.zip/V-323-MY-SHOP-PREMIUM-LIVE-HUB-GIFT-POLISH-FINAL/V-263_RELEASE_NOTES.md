# MY SHOP V-263 — LIVE CONTROLS + BRANDING POLISH

Base: V-261-MY-SHOP-PREMIUM-HEADER-FEED-POLISH-FINAL

## Completed
- Live Streaming fixed area remains locked through Go Live / Join Live.
- Go Live / Join Live controls made more compact with side breathing space and a clearer gap before the live/new-user row.
- Preserved 35% Go Live / 65% Join Live proportions and both click flows.
- Reduced pulse scale so the controls feel premium instead of visually covering the profiles below.
- Updated MY SHOP launcher/install icon to the user-approved blue-MY/orange-SHOP dark LIVE icon.
- Added dark branded startup theme to avoid a bright/white opening bridge.
- Splash now uses the approved icon plus blue MY / orange SHOP wordmark and Shop • Social • Live • Earn tagline.
- Preserved Admin-controlled startup image/video ad flow and fail-safe handoff.
- Enforced the approved startup-ad duration safety cap at 4 seconds.
- Version bumped to versionCode 263 / versionName 2.9.263.

## Protected behavior
- Header/profile/EN/notification/message behavior unchanged.
- Scrolling still starts at the Live/New Users row; bottom navigation remains fixed.
- Live/New User backend behavior and friend actions unchanged.
- Dashboard banner, Quick Links, MY Feed and existing APIs are not redesigned.

## Build checkpoint
Static source validation is included. Final signed APK compilation remains GitHub Actions' job when this ZIP is uploaded as the newest V-numbered source.
