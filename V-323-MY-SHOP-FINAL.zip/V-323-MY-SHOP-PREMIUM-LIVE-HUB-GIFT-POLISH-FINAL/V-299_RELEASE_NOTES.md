# MY SHOP V-299 Release Notes

V-299 is the corrected compile-fix release based on the V-297 32-point implementation.

## Included fixes
- Keeps the V-298 Java compile fixes: missing `input(...)` helper and missing `ViewGroup` import correction.
- Sets `SOURCE_BUILD_ID.txt` to exactly `MY SHOP V-299`.
- Sets `SOURCE_VERSION_NAME.txt` to `2.9.299`.
- Sets Android `versionCode 299` and `versionName 2.9.299`.
- Updates Worker health/build markers to `V-299 / 2.9.299`.
- Keeps the release safety guard intact; workflow YML is not modified.
