# MY SHOP V-318 — Instant Gift + Premium Coin/Gold Catalog

Base: V-317
Android: versionCode 318 / versionName 2.9.318
Worker: V-318

## Completed
- Rebuilt Live Gift Store to the approved reference flow: tap one gift -> selected highlight -> one shared SEND button.
- Successful backend acknowledgement immediately closes Gift Store and starts sender animation + sound without the old 90 ms delay.
- Remote gift propagation remains event-based in parallel; client nonce + event-ID dedupe prevents duplicate rendering.
- Gift event polling tightened to 350 ms while the normal room refresh remains separate.
- Gift animation scale is now true Admin 0–100 and is used by Live playback; high values can cover most of the Live board.
- Premium gift effect strengthened with scale motion, particles, glow, gift-specific multi-stage motion and clean fade exit.
- Per-gift sound volume is true Admin 0–100 and used at playback.
- Bundled starter gift sounds were normalized to ~88% peak headroom; default volume is 85% for stronger audible playback without clipping.
- Admin main entry renamed to “Gift Coin & Gold Coin Catalog”.
- Separate Gift Coin and Gold Coin catalog tabs remain independent.
- Each Admin gift card exposes price, order/position, animation size, volume, publish/animation/sound toggles, sound add/replace/preview/delete, image/animation, Edit, Save and Delete.
- Prominent Add New Gift action included for both catalogs.
- Admin saves continue to use D1/R2-backed remote configuration; routine price/media/sound/volume/scale/order/publish changes do not require an APK update.
- Worker gift-send response path shortened: critical debit/credit/event/ledger work completes first; noncritical level/fan follow-up is delegated with waitUntil when available.
- Existing Cloudflare D1/R2 bindings, soft-delete history safety, server-authoritative gift price and Coin/Gold separation preserved.

## Release gate
Source-level validation: 40/40 PASS.
Android APK/AAB compile/install was not run locally because this editing container has no Android SDK or executable project Gradle wrapper. The included GitHub workflow remains the actual compile/deploy gate.
