# MY SHOP V-317 — Live Gift + Level + Admin Catalog

Base: V-316
Android: versionCode 317 / versionName 2.9.317
Worker: V-317

## Completed scope
- Official/Admin Star rule: 100,000 Coin = 1 Star and 1,000 Gold Coin = 1 Star; each Official Star adds +2 Levels.
- Normal user-origin Gift/Transfer rule: same Star thresholds; each normal Star adds +1 Level.
- One-time legacy reconciliation repairs pre-V-317 Admin grants without asking Admin to grant the same value again.
- Level source is backend-driven. Feed/Profile show plain LV.x. Live Room shows Live Level marker + LV.x.
- Successful Live Gift Send closes the Gift Store before effect playback; failed sends keep the Store open.
- Live Gift events have client nonce dedupe and a faster lightweight event channel for room propagation.
- High-animation gift presentation upgraded with responsive sizing, particles/glow/multi-stage motion and per-gift sound.
- 5 Coin starter gifts and 5 Gold Coin starter gifts remain separate catalogs.
- Admin Gift Manager has separate Coin / Gold Coin catalogs.
- Every gift card exposes image/name/current price, Save/Edit/Delete/Publish controls.
- Server-side current price is authoritative at Send time.
- Per-gift sound: add/change/test/remove/on-off and 0–100 volume with Mute/Low/Medium/High presets.
- Per-gift animation size: Small / Medium / Large / Full Screen.
- Gift image/animation/sound/price/volume/size/publish are backend/R2/D1 driven so routine changes do not require an APK update.
- Deleted gifts are soft-deleted so historical transactions remain intact.
- Coin and Gold gift currency is locked on edit to prevent cross-catalog mixing.

## Test priority after GitHub build/deploy
1. Existing user with a historical 100,000 Official Coin grant should resolve to +2 earned Levels (without granting again).
2. Send Rose and verify: success -> Store closes -> animation + sound visible on sender and other Live participant.
3. Change Rose price in Admin, Save, reopen Live Gift Store and verify the exact new price is used server-side.
4. Repeat with a Gold Coin gift.
5. Change one gift sound, volume and animation size in Admin and verify Live updates without APK change.
