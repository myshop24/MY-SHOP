# V-287 Release Notes
Premium Audio Live visual correction: 5+5 golden speaker sofas, audience avatar row, HH:MM Special Guest timer, red power leave/end button, Gift-over-React stack, and premium Start Audio Live setup dialog. Real RTC remains pending.
