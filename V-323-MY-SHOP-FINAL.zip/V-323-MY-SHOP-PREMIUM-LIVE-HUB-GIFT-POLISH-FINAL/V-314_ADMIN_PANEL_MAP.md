# V-314 Admin Control Center Map

This file documents the visible folder organization only; it does not replace backend permissions.

## Finance & Accounting
- Transactions & Earnings → AdminFinanceActivity
- Payment Methods → AdminSectionActivity / payment_methods
- Coin • Gold Coin Catalog → AdminStoreActivity

## Live Streaming
- Live Gift Manager → LiveGiftAdminActivity
- Audio Live Themes → LiveThemeAdminActivity

## Membership & Badges
- Animated Badges • ID Grant → AdminStoreActivity
- ROYAL • VVIP • VIP → AdminStoreActivity

## Dashboard & Content
- Banner Management → BannerAdminActivity
- Gallery Management → GalleryAdminActivity
- Dashboard Ads → DashboardAdsAdminActivity
- Dashboard • Breaking News → AdminSectionActivity / dashboard
- Feature Management → AdminSectionActivity / features
- Dashboard Feature Slots → AdminSectionActivity / dynamic_content
- Social Links → AdminSectionActivity / social
- Live TV → AdminSectionActivity / live_tv
- External Movie → AdminSectionActivity / external_movie
- More Apps → AdminSectionActivity / more_apps
- Startup Advertisement → DashboardAdsAdminActivity / startup_ad

## Community & Safety
- Moderator / Admin → AdminSectionActivity / moderators
- MY FEED Moderation → FeedModerationActivity
- Customer Support → AdminSectionActivity / help_support
- Safety Reports • Account Deletion → AdminSafetyActivity

## System
- System Health / Test → AdminSystemHealthActivity
