from pathlib import Path
import re, subprocess, xml.etree.ElementTree as ET, wave, struct, hashlib, sys
ROOT=Path('/mnt/data/V-318-MY-SHOP-INSTANT-GIFT-CATALOG-FINAL')
checks=[]
def check(name, cond, detail=''):
    checks.append((name,bool(cond),detail))

def txt(p): return (ROOT/p).read_text(encoding='utf-8',errors='replace')

build=txt('app/build.gradle')
admin=txt('app/src/main/java/com/myshop/app/LiveGiftAdminActivity.java')
live=txt('app/src/main/java/com/myshop/app/AudioLiveRoomActivity.java')
hub=txt('app/src/main/java/com/myshop/app/AdminHubActivity.java')
backend=txt('backend/worker/src/index.js')
wr=txt('backend/worker/wrangler.toml')
workflow=txt('.github/workflows/my-shop-apk.yml')

check('SOURCE_BUILD_ID = MY SHOP V-318', txt('SOURCE_BUILD_ID.txt').strip()=='MY SHOP V-318')
check('SOURCE_VERSION_NAME = 2.9.318', txt('SOURCE_VERSION_NAME.txt').strip()=='2.9.318')
check('Android versionCode = 318', bool(re.search(r'\bversionCode\s+318\b',build)))
check('Android versionName = 2.9.318', 'versionName "2.9.318"' in build or "versionName '2.9.318'" in build)
check('compileSdk/targetSdk = API 36', 'compileSdk 36' in build and 'targetSdk 36' in build)
check('GitHub workflow labels V-318', 'AUTO-BUILD V-318' in workflow)
check('Admin hub exposes exact Gift Coin & Gold Coin Catalog entry', 'Gift Coin & Gold Coin Catalog' in hub and 'live_gifts' in hub)
check('Admin catalog has separate Gift Coin and Gold Coin tabs', '1  🪙  GIFT COIN' in admin and '2  👑  GOLD COIN' in admin)
check('Admin has Add New Gift action', 'ADD NEW' in admin and 'clearEditor(true)' in admin)
check('Each gift card has Edit / Save / Delete controls', '✏ Edit' in admin and '💾 SAVE' in admin and '🗑 DELETE' in admin)
check('Admin per-gift price + catalog order fields', 'Catalog position / order' in admin and 'Price' in admin and 'sortOrder' in admin)
check('Admin sound add/replace/preview/delete/on-off controls', all(s in admin for s in ['Add Sound','Replace','▶ Preview','Delete Sound','CheckBox pub','soundEnabled']))
check('Admin sound volume is true 0–100 slider', 'volume.setMax(100)' in admin and 'vb.setMax(100)' in admin and 'soundVolume' in admin)
check('Admin animation size is true 0–100 slider', 'animationScale.setMax(100)' in admin and 'sb.setMax(100)' in admin and 'animationScale' in admin)
check('Live Gift Store uses select-first shared Send button', 'Tap a gift once → press Send' in live and 'final Button sendButton' in live and 'chosen[0]=g' in live)
check('Old per-card Gift SEND flow removed from openGiftChart', live[live.index('private void openGiftChart'):live.index('private android.graphics.drawable.GradientDrawable giftTileBg')].count('setOnClickListener')>=4 and 'action("SEND"' not in live[live.index('private void openGiftChart'):live.index('private android.graphics.drawable.GradientDrawable giftTileBg')])
check('Successful send dismisses panel before local effect', live.find('giftStoreDialog.dismiss()', live.index('private void openGiftChart')) < live.find('showGiftEffect(effectGift,d)', live.index('private void openGiftChart')))
check('No old 90ms delayed Gift effect path', 'postDelayed(()->showGiftEffect' not in live and '90L' not in live[live.index('private void openGiftChart'):live.index('private android.graphics.drawable.GradientDrawable giftTileBg')])
check('Duplicate event suppression retained', 'renderedGiftEventIds.add(sentEventId)' in live and 'clientNonce' in backend and 'idx_live_gift_nonce' in backend)
check('Remote gift polling accelerated', bool(re.search(r'GIFT_POLL_MS\s*=\s*350L', live)) or '350L' in live[:10000])
check('Backend stores animation_scale 0–100', 'animation_scale INTEGER NOT NULL DEFAULT 70' in backend and 'animationScale??70' in backend)
check('Backend fast acknowledgement + background post-processing', 'fastAck:true' in backend and 'ctx.waitUntil(afterSend())' in backend)
check('Live remote event query includes animation_scale and volume', 'g.animation_scale' in backend and 'g.sound_volume' in backend)
check('Live playback consumes animation_scale', 'giftScale(gift)' in live and 'giftArtPx(scale)' in live)
check('Live playback consumes sound_volume', 'gift.optInt("sound_volume",85)/100f' in live)
check('Premium animation has particles/glow/multi-stage paths', 'addGiftParticles' in live and 'ObjectAnimator.ofFloat(glow' in live and 'animateGiftArt' in live)
check('Gift currency catalogs remain independent', 'GIFT_CURRENCY_LOCKED' in backend and "['COIN','GOLD'].includes(currency)" in backend)
check('Admin routine changes are backend/D1/R2 driven', '/v1/admin/live/gifts/save' in txt('app/src/main/java/com/myshop/app/BackendClient.java') and '/v1/admin/live/gifts/asset/upload' in txt('app/src/main/java/com/myshop/app/BackendClient.java'))
check('D1 binding preserved', 'binding = "DB"' in wr and 'database_name = "my-shop-db"' in wr)
check('R2 MEDIA binding preserved', 'binding = "MEDIA"' in wr and 'bucket_name = "my-shop-media"' in wr)
check('Play Billing dependency remains present', 'com.android.billingclient:billing:9.1.0' in build)
check('LiveGiftAdminActivity remains admin-only', 'if(!SessionManager.isAdmin(this)){finish();return;}' in admin)
check('LiveGiftAdminActivity manifest entry preserved', '.LiveGiftAdminActivity' in txt('app/src/main/AndroidManifest.xml'))

# Worker JS syntax
r=subprocess.run(['node','--check',str(ROOT/'backend/worker/src/index.js')],capture_output=True,text=True)
check('Worker JavaScript syntax (node --check)', r.returncode==0, (r.stderr or r.stdout).strip())

# XML parse
xml_bad=[]
for p in [ROOT/'app/src/main/AndroidManifest.xml', *ROOT.glob('app/src/main/res/**/*.xml')]:
    try: ET.parse(p)
    except Exception as e: xml_bad.append(f'{p.relative_to(ROOT)}: {e}')
check('Android Manifest/resources XML parse', not xml_bad, '; '.join(xml_bad[:5]))

# Java parse-smoke: javac reports symbol resolution errors without Android SDK; reject only parser errors.
parse_patterns=["';' expected",'illegal start','not a statement','reached end of file while parsing','class, interface, enum, or record expected',') expected','} expected','unclosed','identifier expected','orphaned','else without','try without','catch without','finally without']
java_bad=[]
for rel in ['app/src/main/java/com/myshop/app/LiveGiftAdminActivity.java','app/src/main/java/com/myshop/app/AudioLiveRoomActivity.java','app/src/main/java/com/myshop/app/AdminHubActivity.java']:
    p=ROOT/rel
    rr=subprocess.run(['javac','-proc:none','-Xmaxerrs','2000',str(p)],capture_output=True,text=True)
    out=(rr.stdout+'\n'+rr.stderr).lower()
    hits=[q for q in parse_patterns if q.lower() in out]
    if hits: java_bad.append(f'{rel}: {hits}')
check('Modified Java parser smoke (no syntax diagnostics)', not java_bad, '; '.join(java_bad))

# Merge conflict markers
conf=[]
for p in ROOT.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.java','.js','.xml','.gradle','.yml','.toml'}:
        try: s=p.read_text(errors='ignore')
        except: continue
        if '<<<<<<< ' in s or '>>>>>>> ' in s or '\n=======' in s: conf.append(str(p.relative_to(ROOT)))
check('No merge-conflict markers in active text source', not conf, ', '.join(conf[:5]))

# Gift images and sounds
try:
    from PIL import Image
    imgs=list((ROOT/'app/src/main/res/drawable-nodpi').glob('gift_*.png'))
    bad=[]
    for p in imgs:
        try:
            with Image.open(p) as im: im.verify()
        except Exception as e: bad.append(f'{p.name}:{e}')
    check('Bundled gift image assets readable', len(imgs)>=10 and not bad, f'{len(imgs)} files; '+','.join(bad[:3]))
except Exception as e:
    check('Bundled gift image assets readable', False, str(e))

snd=list((ROOT/'app/src/main/res/raw').glob('gift_*_sound.wav'))
snd_bad=[]; stats=[]
for p in snd:
    try:
        with wave.open(str(p),'rb') as w:
            sw=w.getsampwidth(); n=w.getnframes(); data=w.readframes(n); fr=w.getframerate(); ch=w.getnchannels()
        # signed PCM peak
        if sw==2:
            vals=struct.unpack('<'+'h'*(len(data)//2),data); peak=max(abs(v) for v in vals)/(2**15-1)
        elif sw==1:
            vals=[b-128 for b in data]; peak=max(abs(v) for v in vals)/127
        else: peak=0
        stats.append((p.name,peak,sw,ch,fr))
        if peak>0.92 or peak<0.80: snd_bad.append(f'{p.name}:peak={peak:.3f}')
    except Exception as e: snd_bad.append(f'{p.name}:{e}')
check('10 bundled Gift sounds normalized with safe headroom', len(snd)>=10 and not snd_bad, '; '.join(snd_bad[:5]) or ', '.join(f'{n}:{pk*100:.1f}%' for n,pk,*_ in stats))

# exact altered files guard against accidental broad rewrite: compare expected set later docs excluded
base=Path('/mnt/data/myshop_v317/V-317-MY-SHOP-LIVE-GIFT-LEVEL-ADMIN-FINAL')
expected_prefixes={
'.github/workflows/my-shop-apk.yml','SOURCE_BUILD_ID.txt','SOURCE_VERSION_NAME.txt','app/build.gradle',
'app/src/main/java/com/myshop/app/AdminHubActivity.java','app/src/main/java/com/myshop/app/AudioLiveRoomActivity.java','app/src/main/java/com/myshop/app/LiveGiftAdminActivity.java','backend/worker/src/index.js'
}
# raw sounds expected
for p in snd: expected_prefixes.add(str(p.relative_to(ROOT)))
changed=[]
for p in ROOT.rglob('*'):
    if not p.is_file(): continue
    rel=str(p.relative_to(ROOT))
    bp=base/rel
    if bp.exists():
        if hashlib.sha256(p.read_bytes()).digest()!=hashlib.sha256(bp.read_bytes()).digest(): changed.append(rel)
# before release-doc creation, require no unexpected changes
unexpected=[x for x in changed if x not in expected_prefixes and not x.startswith('V-318_') and x not in {'README.md','MY-SHOP-DEVELOPER-HANDOFF.md'}]
check('Regression-safety changed-file scope has no unexpected source edits', not unexpected, ', '.join(unexpected[:10]))

ok=sum(1 for _,v,_ in checks if v); total=len(checks)
for name,v,detail in checks:
    print(('PASS' if v else 'FAIL')+' - '+name+((' :: '+detail) if detail else ''))
print(f'RESULT {ok}/{total} PASS')
if ok!=total: sys.exit(1)
