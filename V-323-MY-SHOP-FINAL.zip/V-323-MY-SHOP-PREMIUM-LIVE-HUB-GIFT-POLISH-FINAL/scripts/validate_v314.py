from pathlib import Path
import re, hashlib, sys
root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/myshop/app'
checks=[]
def ck(name, ok):
    checks.append((name,bool(ok)))

gradle=(root/'app/build.gradle').read_text()
hub=(java/'AdminHubActivity.java').read_text()
store=(java/'AdminStoreActivity.java').read_text()
gift=(java/'LiveGiftAdminActivity.java').read_text()
section=(java/'AdminSectionActivity.java').read_text()
finance=(java/'AdminFinanceActivity.java').read_text()
ads=(java/'DashboardAdsAdminActivity.java').read_text()
worker=(root/'backend/worker/src/index.js').read_text()

ck('versionCode 314', 'versionCode 314' in gradle)
ck('versionName 2.9.314', 'versionName "2.9.314"' in gradle)
ck('source build identity', (root/'SOURCE_BUILD_ID.txt').read_text().strip()=='MY SHOP V-314')
ck('premium Admin Control Center', 'premium Admin Control Center' in hub and 'Manage Your App' in hub)
ck('folder categories', all(x in hub for x in ['Finance & Accounting','Live Streaming','Membership & Badges','Dashboard & Content','Community & Safety','System']))
ck('admin search', 'Search a feature or setting' in hub)
ck('admin language selector', 'LanguageManager.showPicker' in hub)
ck('collapsible folders', 'body.setVisibility' in hub and 'categoryFolder' in hub)
ck('no fake Orders module', 'Orders' not in hub)
for mode in ['finance_center','banner','gallery','ads','dashboard','features','dynamic_content','social','live_tv','external_movie','more_apps','payment_methods','moderators','feed_moderation','help_support','system_health','wallet_badge','startup_ads','live_themes','live_gifts','safety_reports']:
    ck('route '+mode, ('"'+mode+'"') in hub)
ck('Admin Store numbered flow', all(x in store for x in ['Item Identity','Value • Units • Duration','Benefits • Image • Animation','Preview • Save • Publish','Official Grant to User ID']))
ck('Live Gift numbered flow', all(x in gift for x in ['Gift Identity','Image • Animation • Sound','Enable • Preview • Publish','Published / Draft Gifts']))
ck('Coin/Gold gift currency remains', 'new String[]{"COIN","GOLD"}' in gift)
ck('Admin section language access', 'LanguageManager.showPicker' in section)
ck('Finance language access', 'LanguageManager.showPicker' in finance)
ck('Startup 1080x2400 guidance', '1080 × 2400' in ads or '1080×2400' in ads)
ck('Startup Full Image default', 'FULL_IMAGE' in ads and 'FIT / CONTAIN' in ads)
ck('targetSdk 36', 'targetSdk 36' in gradle)
ck('compileSdk 36', 'compileSdk 36' in gradle)
ck('worker D1 binding usage retained', 'env.DB' in worker)
ck('worker R2/media usage retained', 'env.MEDIA' in worker or 'MEDIA' in worker)

for name,ok in checks:
    print(('PASS' if ok else 'FAIL')+' | '+name)
failed=[n for n,o in checks if not o]
print(f'\nTOTAL: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    sys.exit(1)
