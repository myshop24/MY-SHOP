from pathlib import Path
import re, sys, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
checks=[]
def ck(name, cond):
    checks.append((name,bool(cond)))
    print(('PASS' if cond else 'FAIL')+'  '+name)

grad=(root/'app/build.gradle').read_text()
worker=(root/'backend/worker/src/index.js').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
reg=(root/'app/src/main/res/layout/activity_register.xml').read_text()
store=(root/'app/src/main/java/com/myshop/app/StoreActivity.java').read_text()
billing=(root/'app/src/main/java/com/myshop/app/PlayBillingManager.java').read_text()
settings=(root/'app/src/main/java/com/myshop/app/ProfileSettingsActivity.java').read_text()
chat=(root/'app/src/main/java/com/myshop/app/ChatActivity.java').read_text()
live=(root/'app/src/main/java/com/myshop/app/AudioLiveRoomActivity.java').read_text()
startup=(root/'app/src/main/java/com/myshop/app/StartupAdActivity.java').read_text()
workflow=(root/'.github/workflows/my-shop-apk.yml').read_text()

ck('versionCode 309', bool(re.search(r'\bversionCode\s+309\b',grad)))
ck('versionName 2.9.309', 'versionName "2.9.309"' in grad or "versionName '2.9.309'" in grad)
ck('Play Billing 9.1.0', "com.android.billingclient:billing:9.1.0" in grad)
ck('Play Billing manager', 'class PlayBillingManager' in billing and 'playPurchaseVerify' in billing)
ck('Store uses Google Play for money', 'BUY WITH GOOGLE PLAY' in store and 'billing.purchase' in store)
ck('direct digital money backend disabled', worker.count('DIRECT_DIGITAL_PAYMENT_DISABLED') >= 3)
ck('server purchase verification', '/purchases/productsv2/tokens/' in worker and 'purchaseStateContext' in worker)
ck('atomic Play grant', 'playGrantAtomic' in worker and 'env.DB.batch(q)' in worker)
ck('account delete endpoint', "/v1/account/delete" in worker and 'Delete My Account' in settings)
ck('web delete path', "/account-deletion" in worker and 'accountDeletionPage' in worker)
ck('privacy + terms paths', "p==='/privacy'" in worker and "p==='/terms'" in worker)
ck('registration unchecked', 'android:checked="false"' in reg)
ck('safety report endpoint', '/v1/safety/report' in worker and 'SafetyActions.show' in chat)
ck('backend blocking', 'safetyIsBlocked' in worker and "error:'BLOCKED_USER'" in worker)
ck('admin safety board', 'AdminSafetyActivity' in manifest and '/v1/admin/safety/reports' in worker)
ck('startup ad Skip', 'setText("Skip")' in startup and 'skip.setOnClickListener' in startup)
ck('host + 12 user seats preserved', 'CHECK(seat_no BETWEEN 1 AND 12)' in worker)
ck('Live account safety action', 'Report / Block Account' in live)
ck('D1 binding preserved', 'database_name = "my-shop-db"' in (root/'backend/worker/wrangler.toml').read_text())
ck('R2 binding preserved', 'bucket_name = "my-shop-media"' in (root/'backend/worker/wrangler.toml').read_text())
ck('Android backup disabled', 'android:allowBackup="false"' in manifest)
ck('workflow requires Play service account', 'GOOGLE_PLAY_SERVICE_ACCOUNT_JSON' in workflow and "playBilling')=='configured'" in workflow)
# XML parse all source XML
xml_ok=True
for f in (root/'app/src/main').rglob('*.xml'):
    try: ET.parse(f)
    except Exception as e:
        print('XML ERROR',f,e); xml_ok=False
ck('all Android XML parses', xml_ok)
# Ensure old client direct purchase helpers have no call sites outside BackendClient.
java=list((root/'app/src/main/java/com/myshop/app').glob('*.java'))
leaks=[]
for f in java:
    if f.name=='BackendClient.java': continue
    t=f.read_text(errors='ignore')
    if 'requestCoinPurchase(' in t or 'requestWalletPurchase(' in t:
        leaks.append(f.name)
ck('no direct digital-money helper call sites', not leaks)
if leaks: print('LEAK FILES',leaks)

failed=[n for n,v in checks if not v]
# V-309 compile regression guard
legal=(root/'app/src/main/java/com/myshop/app/LegalActivity.java').read_text()
ck('LegalActivity final selectedType', 'final String selectedType=type;' in legal and 'v->open(selectedType)' in legal and 'v->open(type)' not in legal)
ck('V-309 source build identity', (root/'SOURCE_BUILD_ID.txt').read_text().strip()=='MY SHOP V-309' and (root/'SOURCE_VERSION_NAME.txt').read_text().strip()=='2.9.309')
ck('Worker V-309 health identity', worker.count("version:'2.9.309',build:'V-309'") >= 2)
failed=[n for n,v in checks if not v]
print(f'\nV-309 checks: {len(checks)-len(failed)}/{len(checks)} PASS')
if failed:
    print('FAILED:',failed)
    sys.exit(1)
