# MY SHOP V-254 — Four Critical Corrections

Base: V-253.

1. Dashboard quick links no longer duplicate a separate More Apps shortcut. The existing shortcut row is the configurable primary row; See All opens extended actions including Earn & Reward, MY SHOP, Share App and Agent.
2. Startup flow now shows a premium MY SHOP animated opening first, then the Admin-configured image/video startup ad (1–6 seconds) with a visible Skip control, with fail-open behavior and no intentional black blank stage.
3. Profile now has a MY FEED composer between wallet/level strip and content tabs. Text/photo/video posts are submitted through the same feed backend, then open the owner's Posts/Photos/Videos view. Profile content tabs route by the selected user: Posts, Photos, Videos, Reels, About.
4. Critical social relationship state fix: real social stats include Friends, Followers, Following and Likes; outgoing pending requests are listed and cancellable; public profiles visibly expose Cancel Request / Unfriend / Unfollow; Accept/Decline remains available for incoming requests. Backend state is persistent and stats are recalculated from database rows.

Verification performed in this environment: Worker JavaScript syntax, Android XML parse, Java brace/integrity guards, required endpoint/UI marker checks, ZIP integrity.
