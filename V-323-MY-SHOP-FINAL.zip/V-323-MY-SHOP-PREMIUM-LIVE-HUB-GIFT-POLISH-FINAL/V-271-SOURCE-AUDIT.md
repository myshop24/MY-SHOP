# V-271 Source Audit

Audit of V-270 found that backend/server support for Breaking News font size and colors already existed, but the installed screenshot did not expose those controls. V-271 makes them explicit in AdminSectionActivity and adds missing visual pickers for the four dashboard theme colors.

The V-270 Live/New User cards used a 54dp avatar inside a 64dp shell and a 124dp row, which explained the compressed look. V-271 increases the avatar to 66dp, shell to 78dp, row/card height to roughly 148–150dp, increases name/level/ID/action readability, and keeps four responsive slots.

The backend already supports `breaking_news_text_size`, `breaking_news_bg_color`, `breaking_news_text_color`, and friend-request cancellation. These are preserved.
