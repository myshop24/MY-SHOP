MY SHOP — GitHub Pipeline + One APK Fix

এই প্যাকেজে ২টি repository-root file আছে:
1) my-shop-release.sh
2) .github/workflows/my-shop-apk.yml

কাজ:
- Highest V-number duplicate ZIP থাকলে build আর fail করবে না; সবচেয়ে নতুন committed ZIP deterministicভাবে নেয়।
- Release folder শেষে শুধু MY_SHOP_FINAL_RELEASE.apk রাখে।
- GitHub Artifact-এ শুধু একটিই installable APK upload হয়।
- SHA-256 এবং build identity Job Summary-তে verification হিসেবে লেখা হয়, user-facing artifact file হিসেবে নয়।

ব্যবহার:
ZIP extract করে উপরের ২টি file একই path-এ GitHub repository-তে replace/upload করুন।
বর্তমান V-392 source ZIP দুটো delete করা বাধ্যতামূলক নয়; তবে পরের source অবশ্যই V-393 হবে।
