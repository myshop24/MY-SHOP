# MY SHOP Developer Handoff — V-291

## Current version
- App/source version: **V-291**
- versionName: **2.9.291**
- Base: V-290 final approved Live Room.

## Completed in V-291
- Fixed the actual MY SHOP Live Room bottom controls so they stay fully visible and clickable above the Android system navigation / gesture area.
- Preserved the approved single-row layout: **Comment → Send → colored Mic → highlighted Join/End**.
- Added runtime bottom WindowInsets handling with an extra safety gap.
- Preserved right vertical controls exactly: **Request → Gift → React → Share**.
- Preserved Host, timer, animated crown-free golden Guest frame, 10 sofas in 5+5, pinned announcement, comments area, wallpaper and existing backend behavior.
- No old extra bottom icon strip was reintroduced.

## NEXT START HERE
1. Build V-291 in GitHub Actions / Android toolchain.
2. Test on at least one 3-button-navigation phone and one gesture-navigation phone.
3. Confirm the entire Comment / Send / Mic / Join-End row is visible, not overlapped, and every control is tappable.
4. If a device still overlaps the controls, inspect its WindowInsets values before changing any approved Live Room layout positions.
5. Continue RTC/Agora integration only after this visual regression is confirmed.

## Locked visual rules
- Do not move or redesign the approved Live Room elements without owner approval.
- Bottom row remains in its current location conceptually; safe-area padding moves it only enough to avoid Android system UI.
- Right rail order remains Request, Gift, React, Share.
- Guest frame has no crown and no SPECIAL GUEST text.
- Timer remains under Host information at the left.
- 10 speaker positions remain 5 + 5.

## Testing limitation
- Source-level checks can be run here, but no claim of a successful Android APK compile is made unless an Android Gradle build actually runs successfully.
