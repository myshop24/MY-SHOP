package com.myshop.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;

/** V-129 admin-only folder menu. Each folder opens its own focused detail board. */
public class AdminHubActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(246,248,252), DARK=Color.rgb(22,28,55), MUTED=Color.rgb(100,106,122);
    private final int[] COLORS={Color.rgb(83,32,180),Color.rgb(31,73,210),Color.rgb(17,139,88),Color.rgb(220,92,38),Color.rgb(180,35,105),Color.rgb(32,125,145),Color.rgb(110,73,185),Color.rgb(210,45,55),Color.rgb(55,95,170),Color.rgb(25,130,95)};

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        String uid=SessionManager.getUserId(this);
        if(AdminIdentifiers.isAdminIdentifier(uid)) SessionManager.setRemoteSession(this,SessionManager.getToken(this),Role.ADMIN,AdminIdentifiers.adminIdFor(uid));
        if(!SessionManager.isAdmin(this)){finish();return;}
        build();
    }

    private void build(){
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true);
        LinearLayout root=col(); root.setBackgroundColor(BG); root.setPadding(dp(12),dp(10),dp(12),dp(20));

        LinearLayout head=row(); head.setPadding(dp(4),dp(4),dp(4),dp(6));
        Button back=button("‹",DARK,28); back.setOnClickListener(v->finish()); head.addView(back,lp(dp(42),dp(46)));
        LinearLayout hb=col(); hb.addView(txt("MY SHOP",20,DARK,true),lp(-1,dp(24))); hb.addView(txt("ADMIN CONTROL CENTER",9,MUTED,true),lp(-1,dp(18))); head.addView(hb,weight(1));
        TextView profile=txt("PROFILE • ADMIN",8,Color.WHITE,true); profile.setGravity(Gravity.CENTER); profile.setSingleLine(true); profile.setBackground(round(DARK,Color.TRANSPARENT,12)); profile.setOnClickListener(v->startActivity(new android.content.Intent(this,AccountActivity.class))); head.addView(profile,lp(dp(104),dp(34)));
        TextView logout=txt("LOGOUT",8,Color.WHITE,true); logout.setGravity(Gravity.CENTER); logout.setSingleLine(true); logout.setBackground(round(Color.rgb(210,45,55),Color.TRANSPARENT,12)); logout.setOnClickListener(v->logout()); head.addView(logout,lp(dp(68),dp(34))); root.addView(head,lp(-1,dp(54)));

        LinearLayout info=card(); info.addView(txt("🔐  ADMIN ONLY",11,Color.WHITE,true),lp(-1,dp(24))); info.addView(txt("এই তালিকার কোনো Admin অপশন সাধারণ User-এর মেনুতে দেখানো হয় না। একটি ফোল্ডারে চাপলে শুধু সেই কাজের বিস্তারিত বোর্ড খুলবে।",11,Color.WHITE,false),lp(-1,-2)); info.setBackground(round(DARK,DARK,12)); root.addView(info,lp(-1,-2));
        LinearLayout strip=row(); strip.setPadding(dp(8),dp(6),dp(8),dp(6));
        strip.addView(statusChip("SECURE ADMIN",COLORS[0]),weight(1));
        strip.addView(statusChip("6 HERO",COLORS[1]),weight(1));
        strip.addView(statusChip("6 ADS/FOLDER",COLORS[3]),weight(1));
        root.addView(strip,lp(-1,dp(48)));
        TextView label=txt("প্রধান বিভাগসমূহ",15,DARK,true); label.setPadding(dp(4),dp(16),dp(4),dp(8)); root.addView(label,lp(-1,dp(40)));

        addFolder(root,"01","ব্যানার ম্যানেজমেন্ট","Hero ৬টি • প্রতিটি ফোল্ডারে সর্বোচ্চ ৬টি Ads • Upload • Edit • Save • Delete",0,"banner");
        addFolder(root,"02","গ্যালারি ম্যানেজমেন্ট","Photo • Audio • Video • ফোনের Gallery থেকে Upload • Caption • Edit • Save • Delete",1,"gallery");
        addFolder(root,"03","ড্যাশবোর্ড বিজ্ঞাপন","প্রতিটি ফোল্ডারের ১–৬ Ads • Image/Video • Link • Add/Edit/Save/Delete",2,"ads");
        addFolder(root,"04","ড্যাশবোর্ড / ব্রেকিং নিউজ","শিরোনাম • Dashboard URL • Breaking News • Save / Edit",2,"dashboard");
        addFolder(root,"05","ফিচার ম্যানেজমেন্ট","প্রতিটি Feature-এর নাম • Icon • Link • Show / Hide • Save",3,"features");
        addFolder(root,"05A","ড্যাশবোর্ড ছোট Feature Slots","Existing circular/live row • Slot 1–6 • Name • Image • Caption • Link • Add/Edit/Save/Delete",3,"dynamic_content");
        addFolder(root,"06","সোশ্যাল লিংক","Facebook • YouTube • TikTok • Instagram • WhatsApp ইত্যাদি",4,"social");
        addFolder(root,"07","LIVE TV","Channel Name • Link • Icon • Show / Hide • Save / Delete",5,"live_tv");
        addFolder(root,"08","EXTERNAL MOVIE","Movie Name • Link • Icon • Show / Hide • Save / Delete",6,"external_movie");
        addFolder(root,"09","MORE APPS","App Name • Link • Icon • Show / Hide • Save / Delete",7,"more_apps");
        addFolder(root,"10","PAYMENT METHODS","Payment Name • Link / Value • Show / Hide • Save / Delete",8,"payment_methods");
        addFolder(root,"11","MODERATOR / ADMIN","Moderator ID • Add / Remove • Admin security",9,"moderators");
        addFolder(root,"12","MY FEED MODERATION","কুরুচিপূর্ণ পোস্ট দেখা • Delete • Moderation record",1,"feed_moderation");
        addFolder(root,"13","CUSTOMER SUPPORT","WhatsApp • imo • Facebook • Website • Image/Icon • Add/Edit/Save/Delete",5,"help_support");
        addFolder(root,"14","SYSTEM HEALTH / DIAGNOSTICS","Active Worker • D1 schema/write • R2 read/write • exact error",0,"system_health");
        addFolder(root,"15","ANIMATED BADGE • USER ID GRANT","Upload animation • Preview • Price/Duration • Publish • Grant to User ID • Profile auto display",6,"wallet_badge");
        addFolder(root,"16","ROYAL • VVIP • VIP MEMBERSHIP","Separate premium pages • emblem • price • duration • privileges • Buy/Request",5,"wallet_badge");
        addFolder(root,"17","COIN • GOLD COIN CATALOG","Admin sets package units • ৳ price • Coin price • enable/disable",3,"wallet_badge");
        addFolder(root,"18","APP OPEN IMAGE / VIDEO AD","Add/Edit/Delete/Save • ON/OFF • Image/Video • 1s/2s/3s/4s • link",2,"startup_ads");
        addFolder(root,"19","AUDIO LIVE THEME / BACKGROUND","Add/Edit/Delete/Save • ON/OFF • Theme key • Background URL • Accent • Publish without APK update",6,"live_themes");

        TextView safe=txt("✓  User data, authentication records এবং Permanent User ID এই Panel থেকে reset/delete করা হয় না।",10,MUTED,false); safe.setPadding(dp(5),dp(14),dp(5),dp(4)); root.addView(safe,lp(-1,dp(48)));
        root.addView(actionBar("LOGOUT • BACK TO LOGIN",Color.rgb(210,45,55),()->logout()),lp(-1,dp(44)));
        sv.addView(root); setContentView(sv);
    }

    private TextView actionBar(String text,int color,Runnable r){ TextView t=txt(text,10,Color.WHITE,true); t.setGravity(Gravity.CENTER); t.setBackground(round(color,color,10)); t.setOnClickListener(v->r.run()); return t; }

    private void logout(){ String token=SessionManager.getToken(this); SessionManager.clear(this); android.content.Intent i=new android.content.Intent(this,LoginActivity.class); i.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP|android.content.Intent.FLAG_ACTIVITY_NEW_TASK|android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK); startActivity(i); if(token!=null&&!token.isEmpty()) BackendClient.logout(token,new BackendClient.Callback(){public void onSuccess(JSONObject d){} public void onError(String m){}}); }

    private TextView statusChip(String text,int color){ TextView t=txt(text,9,Color.WHITE,true); t.setGravity(Gravity.CENTER); t.setBackground(round(color,color,12)); return t; }

    private void addFolder(LinearLayout root,String no,String title,String desc,int ci,String mode){
        LinearLayout c=card();
        LinearLayout r=row(); TextView num=txt(no,12,Color.WHITE,true); num.setGravity(Gravity.CENTER); num.setBackground(round(COLORS[ci],COLORS[ci],14)); r.addView(num,lp(dp(42),dp(42)));
        LinearLayout b=col(); b.setPadding(dp(10),0,dp(5),0); b.addView(txt(title,13,DARK,true),lp(-1,dp(23))); TextView d=txt(desc,9,MUTED,false); d.setMaxLines(2); b.addView(d,lp(-1,dp(34))); r.addView(b,weight(1));
        TextView go=txt("খুলুন  ›",10,COLORS[ci],true); go.setGravity(Gravity.CENTER); r.addView(go,lp(dp(62),dp(42))); c.addView(r,lp(-1,dp(58)));
        c.setOnClickListener(v->open(mode)); c.setOnTouchListener((v,e)->{if(e.getAction()==android.view.MotionEvent.ACTION_DOWN)v.animate().scaleX(.985f).scaleY(.985f).alpha(.92f).setDuration(60).start();else if(e.getAction()==android.view.MotionEvent.ACTION_UP||e.getAction()==android.view.MotionEvent.ACTION_CANCEL)v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(100).start();return false;}); root.addView(c,lp(-1,-2));
    }

    private void open(String mode){
        if("banner".equals(mode)){startActivity(new android.content.Intent(this,BannerAdminActivity.class));return;}
        if("gallery".equals(mode)){startActivity(new android.content.Intent(this,GalleryAdminActivity.class));return;}
        if("ads".equals(mode)){startActivity(new android.content.Intent(this,DashboardAdsAdminActivity.class));return;}
        if("startup_ads".equals(mode)){android.content.Intent i=new android.content.Intent(this,DashboardAdsAdminActivity.class);i.putExtra("box_key","startup_ad");i.putExtra("box_title","APP OPEN IMAGE / VIDEO AD");startActivity(i);return;}
        if("feed_moderation".equals(mode)){startActivity(new android.content.Intent(this,FeedModerationActivity.class));return;}
        if("system_health".equals(mode)){startActivity(new android.content.Intent(this,AdminSystemHealthActivity.class));return;}
        if("wallet_badge".equals(mode)){startActivity(new android.content.Intent(this,AdminStoreActivity.class));return;}
        if("live_themes".equals(mode)){startActivity(new android.content.Intent(this,LiveThemeAdminActivity.class));return;}
        android.content.Intent i=new android.content.Intent(this,AdminSectionActivity.class); i.putExtra("section",mode); i.putExtra("admin_context",true); startActivity(i);
    }

    private LinearLayout card(){LinearLayout c=col();c.setPadding(dp(10),dp(8),dp(10),dp(8));c.setBackground(round(Color.WHITE,Color.rgb(224,226,235),12));c.setElevation(dp(1));LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(7);c.setLayoutParams(p);return c;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;} private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private Button button(String s,int c,float z){Button b=new Button(this);b.setText(s);b.setTextColor(c);b.setTextSize(z);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackgroundColor(Color.TRANSPARENT);b.setPadding(0,0,0,0);return b;}
    private TextView txt(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private GradientDrawable round(int fill,int stroke,int r){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(r));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} private LinearLayout.LayoutParams weight(float w){return new LinearLayout.LayoutParams(0,dp(52),w);} private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
