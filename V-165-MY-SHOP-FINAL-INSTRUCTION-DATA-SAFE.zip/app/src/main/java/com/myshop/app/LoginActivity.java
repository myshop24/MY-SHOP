package com.myshop.app;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.app.AlertDialog;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** V-72 login: approved MY SHOP reference, email/mobile/4-digit ID, no OTP. */
public class LoginActivity extends android.app.Activity {
    private EditText loginId, loginPassword;
    private TextView welcome, forgot, create;
    private CheckBox remember;
    private Button language;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // V-79 launcher hardening: if an old/broken resource or cached state causes
        // the reference login layout to fail during inflation, never leave the app
        // with a blank/crashing launcher. Build a minimal recovery login instead.
        try {
            setContentView(R.layout.activity_login);
            String existingId = SessionManager.getUserId(this);
            String token = SessionManager.getToken(this);
            if (SessionManager.isLoggedIn(this) && !existingId.isEmpty() && !token.isEmpty() && BackendClient.configured()) {
                BackendClient.me(token, new BackendClient.Callback() {
                    public void onSuccess(org.json.JSONObject data) { startActivity(new Intent(LoginActivity.this, MainActivity.class)); finish(); }
                    public void onError(String message) { SessionManager.clear(LoginActivity.this); bindViews(); applyLanguage(); }
                });
                return;
            }
            bindViews();
            applyLanguage();
        } catch (Throwable ignored) {
            buildRecoveryLogin();
        }
    }

    private void buildRecoveryLogin() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(32), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(248,249,252));

        TextView title = new TextView(this);
        title.setText("MY SHOP");
        title.setTextColor(Color.rgb(92,35,214));
        title.setTextSize(30);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setGravity(android.view.Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(70)));

        EditText id = new EditText(this);
        id.setHint("Email / Mobile / User ID");
        id.setSingleLine(true);
        root.addView(id, new LinearLayout.LayoutParams(-1, dp(58)));

        EditText pass = new EditText(this);
        pass.setHint("Password");
        pass.setSingleLine(true);
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(58));
        pp.topMargin = dp(10);
        root.addView(pass, pp);

        Button login = new Button(this);
        login.setText("LOGIN");
        login.setAllCaps(false);
        login.setTextColor(Color.WHITE);
        login.setTextSize(17);
        login.setBackground(roundRecovery(Color.rgb(27,99,220), dp(14)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(60));
        lp.topMargin = dp(16);
        root.addView(login, lp);
        login.setOnClickListener(v -> {
            String identifier = id.getText().toString().trim();
            String password = pass.getText().toString();
            if (identifier.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Login ID and Password are required.", Toast.LENGTH_SHORT).show();
                return;
            }
            try {
                if (!BackendClient.configured()) { Toast.makeText(this, "Backend URL এখনো সেট করা হয়নি।", Toast.LENGTH_LONG).show(); return; }
                BackendClient.login(identifier, password, new BackendClient.Callback() {
                    public void onSuccess(org.json.JSONObject data) {
                        try { org.json.JSONObject u=data.getJSONObject("user"); Role role=Role.valueOf(u.optString("role","USER")); String uid=u.optString("userId",""); SessionManager.setRemoteSession(LoginActivity.this,data.optString("token",""),role,uid); SessionManager.saveProfile(LoginActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile","")); startActivity(new Intent(LoginActivity.this,MainActivity.class)); finish(); } catch(Exception e){ Toast.makeText(LoginActivity.this,"Login response invalid.",Toast.LENGTH_LONG).show(); }
                    }
                    public void onError(String message) { Toast.makeText(LoginActivity.this,message,Toast.LENGTH_LONG).show(); }
                });
            } catch (Throwable t) {
                Toast.makeText(this, "Login failed safely. Please try again.", Toast.LENGTH_LONG).show();
            }
        });

        TextView create = new TextView(this);
        create.setText("＋  CREATE ACCOUNT");
        create.setTextColor(Color.rgb(30,97,197));
        create.setTextSize(16);
        create.setGravity(android.view.Gravity.CENTER);
        create.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
        root.addView(create, new LinearLayout.LayoutParams(-1, dp(60)));

        setContentView(root);
    }

    private android.graphics.drawable.GradientDrawable roundRecovery(int fill, int radius) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radius);
        return g;
    }

    private void bindViews() {
        loginId = findViewById(R.id.loginId);
        loginPassword = findViewById(R.id.loginPassword);
        remember = findViewById(R.id.rememberMe);
        welcome = findViewById(R.id.welcomeText);
        forgot = findViewById(R.id.forgotButton);
        create = findViewById(R.id.createAccountButton);
        language = findViewById(R.id.languageButton);
        Button login = findViewById(R.id.loginButton);
        ImageButton toggle = findViewById(R.id.passwordToggle);

        language.setOnClickListener(v -> LanguageManager.showPicker(this, this::applyLanguage));
        create.setOnClickListener(v -> startActivity(new Intent(this, RegisterActivity.class)));
        forgot.setOnClickListener(v -> showPasswordResetBox());
        login.setOnClickListener(v -> login());
        toggle.setOnClickListener(v -> {
            int pos = loginPassword.getSelectionStart();
            boolean hidden = (loginPassword.getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) != 0;
            loginPassword.setInputType(InputType.TYPE_CLASS_TEXT | (hidden ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_TEXT_VARIATION_PASSWORD));
            loginPassword.setSelection(Math.max(0, pos));
        });
    }

    private void applyLanguage() {
        if (welcome == null) return;
        welcome.setText(LanguageManager.t(this, "welcome"));
        forgot.setText(LanguageManager.t(this, "forgot"));
        create.setText("＋  " + LanguageManager.t(this, "register"));
        remember.setText(LanguageManager.t(this, "remember"));
        language.setText("🌐  " + languageLabel());
        ((Button)findViewById(R.id.loginButton)).setText(LanguageManager.t(this, "login"));
        ((TextView)findViewById(R.id.orText)).setText(LanguageManager.t(this, "or"));
        loginId.setHint("Login / Email / Mobile / ID");
        loginPassword.setHint("Password");
    }

    private String languageLabel() {
        String l = LanguageManager.get(this);
        if (LanguageManager.EN.equals(l)) return "English";
        if (LanguageManager.HI.equals(l)) return "हिन्दी";
        if (LanguageManager.AR.equals(l)) return "العربية";
        return "বাংলা";
    }

    private void showPasswordResetBox() {
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(8), dp(18), dp(8));

        TextView info = new TextView(this);
        info.setText("Enter your Email / Mobile / Permanent ID. Your saved security question will appear. Give the correct answer, then set a new password.");
        info.setTextColor(Color.DKGRAY); info.setTextSize(14); box.addView(info);

        EditText identifier = field("Email / Mobile / Permanent ID"); box.addView(identifier);
        TextView question = questionLabel(); question.setVisibility(TextView.GONE); box.addView(question);
        EditText answer = field("Security Answer"); answer.setVisibility(EditText.GONE); box.addView(answer);
        EditText np = field("New Password"); np.setInputType(129); np.setVisibility(EditText.GONE); box.addView(np);
        EditText cp = field("Confirm New Password"); cp.setInputType(129); cp.setVisibility(EditText.GONE); box.addView(cp);

        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Forgot Password").setView(box)
                .setNegativeButton("Cancel", null).setPositiveButton("CONTINUE", null).create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String id = identifier.getText().toString().trim();
            if (id.isEmpty()) { Toast.makeText(this,"Email, Mobile or Permanent ID is required.",Toast.LENGTH_SHORT).show(); return; }
            if (question.getVisibility() == TextView.GONE) {
                if (!BackendClient.configured()) { Toast.makeText(this,"Backend URL এখনো সেট করা হয়নি।",Toast.LENGTH_LONG).show(); return; }
                BackendClient.securityQuestions(id,new BackendClient.Callback(){
                    public void onSuccess(org.json.JSONObject data){
                        String q=data.optString("question","");
                        if(q.isEmpty()){Toast.makeText(LoginActivity.this,"Security question unavailable.",Toast.LENGTH_LONG).show();return;}
                        question.setText("Security Question: "+LanguageManager.securityQuestionText(LoginActivity.this,q));
                        question.setVisibility(TextView.VISIBLE); answer.setVisibility(EditText.VISIBLE); np.setVisibility(EditText.VISIBLE); cp.setVisibility(EditText.VISIBLE);
                        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setText("RESET PASSWORD");
                    }
                    public void onError(String message){Toast.makeText(LoginActivity.this,message,Toast.LENGTH_LONG).show();}
                });
                return;
            }
            String pass=np.getText().toString();
            if(pass.length()<6 || !pass.equals(cp.getText().toString())){Toast.makeText(this,"Use 6+ characters and make both passwords match.",Toast.LENGTH_SHORT).show();return;}
            String a=answer.getText().toString().trim(); if(a.isEmpty()){Toast.makeText(this,"Security Answer is required.",Toast.LENGTH_SHORT).show();return;}
            if(!BackendClient.configured()){Toast.makeText(this,"Backend URL এখনো সেট করা হয়নি।",Toast.LENGTH_LONG).show();return;}
            BackendClient.resetPassword(id,a,pass,new BackendClient.Callback(){
                public void onSuccess(org.json.JSONObject data){Toast.makeText(LoginActivity.this,"Password reset successful. Your Permanent ID remains unchanged.",Toast.LENGTH_LONG).show();dialog.dismiss();}
                public void onError(String message){Toast.makeText(LoginActivity.this,message,Toast.LENGTH_LONG).show();}
            });
        }));
        dialog.show();
    }

    private TextView questionLabel() {
        TextView q = new TextView(this);
        q.setTextColor(Color.rgb(30, 70, 130));
        q.setTextSize(14);
        q.setPadding(dp(8), dp(8), dp(8), dp(2));
        return q;
    }

    private EditText field(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true); e.setPadding(dp(10),0,dp(10),0); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52)); p.topMargin=dp(6); e.setLayoutParams(p); return e; }
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}

    private void login() {
        String identifier = loginId.getText().toString().trim(), pass = loginPassword.getText().toString();
        if(identifier.isEmpty()||pass.isEmpty()){Toast.makeText(this,"Login ID and Password are required.",Toast.LENGTH_SHORT).show();return;}
        try {
            if (!BackendClient.configured()) { Toast.makeText(this,"Backend URL এখনো সেট করা হয়নি।",Toast.LENGTH_LONG).show(); return; }
            BackendClient.login(identifier,pass,new BackendClient.Callback(){
                public void onSuccess(org.json.JSONObject data){ try{ org.json.JSONObject u=data.getJSONObject("user"); Role role=Role.valueOf(u.optString("role","USER")); String uid=u.optString("userId",""); SessionManager.setRemoteSession(LoginActivity.this,data.optString("token",""),role,uid); SessionManager.saveProfile(LoginActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile","")); Intent i=new Intent(LoginActivity.this,MainActivity.class); i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP); startActivity(i); finish(); }catch(Exception e){Toast.makeText(LoginActivity.this,"Login response invalid.",Toast.LENGTH_LONG).show();}}
                public void onError(String message){Toast.makeText(LoginActivity.this,message,Toast.LENGTH_LONG).show();}
            });
        } catch(Throwable t){Toast.makeText(this,"Login failed safely. Your account data was not changed.",Toast.LENGTH_LONG).show();}
    }
}
