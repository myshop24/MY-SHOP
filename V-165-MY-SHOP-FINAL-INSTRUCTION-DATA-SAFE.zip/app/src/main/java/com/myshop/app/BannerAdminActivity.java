package com.myshop.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.io.InputStream;
import org.json.JSONArray;
import org.json.JSONObject;

/** V-133 Admin Banner Manager — phone picker + edit/save/delete for 6 Hero + 3 Promo slots. */
public class BannerAdminActivity extends androidx.appcompat.app.AppCompatActivity {
    private LinearLayout list; private String folder; private int slot;
    private final int PURPLE=Color.rgb(83,32,180),GREEN=Color.rgb(17,139,88),RED=Color.rgb(210,45,55),BLUE=Color.rgb(31,73,210),BG=Color.rgb(246,248,252),DARK=Color.rgb(20,28,60);
    @Override protected void onCreate(Bundle b){super.onCreate(b);if(!SessionManager.isAdmin(this)){finish();return;}build();load();}
    private void build(){
        LinearLayout root=col();root.setPadding(dp(12),dp(12),dp(12),dp(18));root.setBackgroundColor(BG);
        TextView h=txt("MY SHOP  •  BANNER MANAGER",22,DARK,true);h.setGravity(Gravity.CENTER);root.addView(h,lp(-1,dp(48)));
        TextView n=txt("6 Hero + 3 Promo  •  Admin only  •  Phone Gallery",11,Color.DKGRAY,false);n.setGravity(Gravity.CENTER);root.addView(n,lp(-1,dp(28)));
        list=col();ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(list);root.addView(sv,lp(-1,0,1));
        root.addView(action("BACK",DARK,()->finish()),lp(-1,dp(46)));setContentView(root);
    }
    private void load(){
        BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){
            public void onSuccess(JSONObject d){runOnUiThread(()->render(d.optJSONArray("banners")));}
            public void onError(String m){runOnUiThread(()->{render(null);toast("Server config unavailable: "+m);});}
        });
    }
    private void render(JSONArray a){
        list.removeAllViews(); JSONObject[] h=new JSONObject[6],p=new JSONObject[3];
        if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.optJSONObject(i);if(x==null)continue;int sl=x.optInt("slot",0);String f=x.optString("folder","");if("hero".equalsIgnoreCase(f)&&sl>=1&&sl<=6)h[sl-1]=x;if("promo".equalsIgnoreCase(f)&&sl>=1&&sl<=3)p[sl-1]=x;}
        list.addView(section("HERO BANNERS  •  6"));for(int i=0;i<6;i++)slotCard("hero",i+1,"Hero Banner "+(i+1),h[i]);
        list.addView(section("PROMO BANNERS  •  3"));for(int i=0;i<3;i++)slotCard("promo",i+1,"Promo Banner "+(i+1),p[i]);
    }
    private void slotCard(String f,int sl,String label,JSONObject x){
        boolean exists=x!=null; String caption=exists?x.optString("caption",""):"";
        LinearLayout card=col();card.setPadding(dp(10),dp(10),dp(10),dp(10));card.setBackground(bg(Color.WHITE,Color.rgb(224,226,235),10));
        TextView name=txt(label+(exists?"  •  SAVED":"  •  EMPTY"),14,DARK,true);card.addView(name,lp(-1,dp(28)));
        TextView state=txt(exists?"Banner loaded. Tap CHANGE PHOTO to replace it.":"No banner yet. Tap CHANGE PHOTO to choose from your phone gallery.",10,Color.DKGRAY,false);state.setMaxLines(2);card.addView(state,lp(-1,dp(38)));
        EditText cap=field("Caption / headline");cap.setText(caption);card.addView(cap,lp(-1,dp(48)));
        LinearLayout a=row();
        a.addView(action("CHANGE PHOTO",PURPLE,()->{folder=f;slot=sl;pick();}),wt(1));a.addView(gap(),lp(dp(5),1));
        a.addView(action("EDIT",BLUE,()->editCaption(f,sl,cap.getText().toString())),wt(1));a.addView(gap(),lp(dp(5),1));
        a.addView(action("SAVE",GREEN,()->saveCaption(f,sl,cap.getText().toString().trim())),wt(1));card.addView(a,lp(-1,dp(44)));
        LinearLayout b=row();b.setPadding(0,dp(6),0,0);TextView del=action("DELETE BANNER",RED,()->confirmDelete(f,sl));b.addView(del,lp(-1,dp(42)));card.addView(b,lp(-1,dp(48)));
        list.addView(card,lp(-1,-2));Space sp=new Space(this);list.addView(sp,lp(1,dp(8)));
    }
    private void editCaption(String f,int sl,String current){EditText e=field("Caption / headline");e.setText(current);new AlertDialog.Builder(this).setTitle("Edit "+f.toUpperCase()+" "+sl).setView(e).setPositiveButton("SAVE",(d,w)->saveCaption(f,sl,e.getText().toString().trim())).setNegativeButton("CANCEL",null).show();}
    private void pick(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(i,800);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r!=800||c!=RESULT_OK||d==null||d.getData()==null)return;Uri u=d.getData();try{if((d.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0)getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}upload(u);}
    private void upload(Uri u){showUploadCaption(u);}
    private void showUploadCaption(Uri u){
        EditText cap=field("Caption / headline (optional)");
        new AlertDialog.Builder(this).setTitle("Upload "+folder.toUpperCase()+" "+slot)
            .setView(cap).setPositiveButton("UPLOAD",(d,w)->doUpload(u,cap.getText().toString().trim()))
            .setNegativeButton("CANCEL",null).show();
    }
    private void doUpload(Uri u,String caption){try{InputStream in=getContentResolver().openInputStream(u);String mime=getContentResolver().getType(u);BackendClient.adminBannerUpload(SessionManager.getToken(this),in,"banner.jpg",mime==null?"image/jpeg":mime,folder,slot,caption,new BackendClient.Callback(){public void onSuccess(JSONObject d){toast("✓ Banner uploaded + caption saved");load();}public void onError(String m){toast("Upload failed: "+m);}});}catch(Exception e){toast("Cannot open selected photo.");}}
    private void saveCaption(String f,int sl,String cap){BackendClient.adminBannerUpdate(SessionManager.getToken(this),f,sl,cap,new BackendClient.Callback(){public void onSuccess(JSONObject d){toast("✓ Caption saved");load();}public void onError(String m){toast("Save failed: "+m);}});}
    private void confirmDelete(String f,int sl){new AlertDialog.Builder(this).setTitle("Delete banner?").setMessage("This removes the selected banner slot and its R2 object.").setPositiveButton("DELETE",(d,w)->BackendClient.adminBannerDelete(SessionManager.getToken(this),f,sl,new BackendClient.Callback(){public void onSuccess(JSONObject x){toast("✓ Deleted");load();}public void onError(String m){toast("Delete failed: "+m);}})).setNegativeButton("CANCEL",null).show();}
    private TextView section(String s){TextView t=txt(s,14,PURPLE,true);t.setPadding(dp(3),dp(10),0,dp(7));return t;}
    private TextView action(String s,int c,Runnable r){TextView t=txt(s,10.5f,Color.WHITE,true);t.setGravity(Gravity.CENTER);t.setBackground(bg(c,c,7));t.setOnClickListener(v->r.run());return t;}
    private EditText field(String h){EditText e=new EditText(this);e.setHint(h);e.setSingleLine(true);e.setTextSize(12);e.setPadding(dp(10),0,dp(10),0);e.setBackground(bg(Color.WHITE,Color.rgb(215,218,228),7));return e;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}private View gap(){return new View(this);}private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private LinearLayout.LayoutParams lp(int w,int h,float wt){return new LinearLayout.LayoutParams(w,h,wt);}private LinearLayout.LayoutParams wt(float w){return new LinearLayout.LayoutParams(0,dp(44),w);}private GradientDrawable bg(int f,int s,int r){GradientDrawable g=new GradientDrawable();g.setColor(f);g.setCornerRadius(dp(r));if(s!=Color.TRANSPARENT)g.setStroke(dp(1),s);return g;}private TextView txt(String s,float z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(b)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
}
