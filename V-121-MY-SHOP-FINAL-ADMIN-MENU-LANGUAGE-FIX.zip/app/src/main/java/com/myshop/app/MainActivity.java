package com.myshop.app;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * MY SHOP V-120 dashboard.
 * Final dashboard layout follows the approved reference: compact header/hero area,
 * full-width breaking news, live cards, 4x2 premium feature grid, fixed 5-item nav.
 * Remote content is additive: no auth/database reset or destructive migration occurs here.
 */
public class MainActivity extends androidx.appcompat.app.AppCompatActivity {
    private final int BG=Color.rgb(248,249,253), BLUE=Color.rgb(46,47,190), NAVY=Color.rgb(18,32,75), DARK=Color.rgb(35,38,52), RED=Color.rgb(238,35,52), GREEN=Color.rgb(24,169,98);
    private final Handler handler=new Handler();
    private int slide=0;
    private ImageView hero;
    private ImageView[] promoViews=new ImageView[3];
    private String[] remoteHeroUrls=new String[6];
    private String[] remotePromoUrls=new String[3];
    private TextView dots,newsText;
    private final int[] heroImgs={R.drawable.banner_wide_1,R.drawable.banner_wide_2,R.drawable.banner_wide_3,R.drawable.banner_wide_4,R.drawable.banner_wide_5,R.drawable.banner_wide_6};
    private final int[] left={R.drawable.banner_top_left_1,R.drawable.banner_top_left_2,R.drawable.banner_top_left_3,R.drawable.banner_top_left_4,R.drawable.banner_top_left_5,R.drawable.banner_top_left_6};
    private final int[] right={R.drawable.banner_top_right_1,R.drawable.banner_top_right_2,R.drawable.banner_top_right_3,R.drawable.banner_top_right_4,R.drawable.banner_top_right_5,R.drawable.banner_top_right_6};
    private final int[] live={R.drawable.dash_live1,R.drawable.dash_live2,R.drawable.dash_live3,R.drawable.dash_live4};
    private final String[] featureKeys={"my_feed","live_now","go_live","live_tv","my_shop","external_movie","gallery","social_media"};
    private final String[] featureTitles={"MY FEED","LIVE","GO LIVE","LIVE TV","MY SHOP","EXTERNAL MOVIE","GALLERY","SOCIAL MEDIA"};
    private final int[] featureIcons={R.drawable.dash_action_feed,R.drawable.dash_action_live,R.drawable.dash_action_go,R.drawable.dash_feat_tv,R.drawable.dash_feat_shop,R.drawable.dash_feat_movie,R.drawable.dash_feat_gallery,R.drawable.dash_feat_social};
    private final boolean[] featureActive=new boolean[8];
    private final String[] featureRemoteTitles=new String[8];
    private final String[] featureRemoteUrls=new String[8];
    private final String[] featureRemoteIcons=new String[8];
    private final FrameLayout[] featureCards=new FrameLayout[8];
    private final TextView[] featureLabels=new TextView[8];
    private final TextView[] featureGlyphs=new TextView[8];
    private final ImageView[] featureRemoteImageViews=new ImageView[8];

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        for(int i=0;i<featureActive.length;i++) featureActive[i]=true;
        setContentView(build());
        loadRemote();
        startCarousel();
    }

    private View build(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(BG);
        ScrollView sv=new ScrollView(this); sv.setVerticalScrollBarEnabled(false); sv.setFillViewport(true);
        LinearLayout page=col(); page.setPadding(dp(12),dp(8),dp(12),dp(94));
        page.addView(header(),lp(-1,dp(58)));
        hero=pic(heroImgs[0]); page.addView(hero,top(lp(-1,dp(126)),6));
        dots=text("●   ○   ○   ○   ○   ○",BLUE,10,true); dots.setGravity(Gravity.CENTER); page.addView(dots,lp(-1,dp(18)));
        page.addView(triplePromos(),top(lp(-1,dp(76)),1));
        page.addView(breaking(),top(lp(-1,dp(36)),4));
        page.addView(sectionTitle("🔴  LIVE NOW",true),top(lp(-1,dp(28)),3));
        page.addView(liveRow(),lp(-1,dp(102)));
        page.addView(finalFeatureGrid(),top(lp(-1,-2),7));
        sv.addView(page,new ScrollView.LayoutParams(-1,-2));
        root.addView(sv,new FrameLayout.LayoutParams(-1,-1));
        FrameLayout.LayoutParams navLp=new FrameLayout.LayoutParams(-1,dp(66),Gravity.BOTTOM); navLp.setMargins(dp(6),0,dp(6),dp(18)); root.addView(bottom(),navLp);
        return root;
    }

    private View header(){
        LinearLayout h=row(); h.setGravity(Gravity.CENTER_VERTICAL); h.setPadding(dp(2),0,dp(2),0);
        h.setBackground(round(Color.WHITE,Color.TRANSPARENT,dp(22)));
        Button menu=icon("☰",NAVY,25);
        menu.setOnClickListener(v->resolveMenuDestination());
        h.addView(menu,lp(dp(42),dp(54)));
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.myshop_icon); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); h.addView(logo,lp(dp(46),dp(52)));
        TextView brand=text("MY SHOP",Color.rgb(24,28,70),16,true); brand.setGravity(Gravity.CENTER_VERTICAL); h.addView(brand,weight(0.70f,dp(50)));
        EditText search=new EditText(this); search.setSingleLine(true); search.setTextSize(11); search.setHint(LanguageManager.t(this,"search")); search.setPadding(dp(10),0,dp(6),0); search.setBackground(round(Color.WHITE,Color.rgb(228,229,235),dp(24))); h.addView(search,weight(1.0f,dp(42)));
        TextView lang=text("🌐  "+languageCode(),BLUE,8.5f,true); lang.setGravity(Gravity.CENTER); lang.setSingleLine(true); lang.setBackground(round(Color.rgb(245,246,255),Color.TRANSPARENT,dp(12))); lang.setOnClickListener(v->LanguageManager.showPicker(this,()->recreate())); h.addView(lang,lp(dp(48),dp(38)));
        Button bell=icon("♧",NAVY,23); bell.setOnClickListener(v->toast("Notifications")); h.addView(bell,lp(dp(38),dp(50)));
        ImageView av=new ImageView(this); av.setImageResource(R.drawable.myshop_profile_avatar); av.setScaleType(ImageView.ScaleType.CENTER_CROP); av.setBackground(round(Color.WHITE,Color.TRANSPARENT,dp(20))); av.setClipToOutline(true); av.setOnClickListener(v->startActivity(new android.content.Intent(this,AccountActivity.class))); h.addView(av,lp(dp(40),dp(40)));
        return h;
    }

    private View triplePromos(){
        LinearLayout r=row(); ImageView a=pic(left[0]),b=pic(right[0]),c=pic(R.drawable.banner_wide_2);
        promoViews[0]=a; promoViews[1]=b; promoViews[2]=c;
        r.addView(a,weight(1,dp(74))); r.addView(space(),lp(dp(6),1)); r.addView(b,weight(1,dp(74))); r.addView(space(),lp(dp(6),1)); r.addView(c,weight(1,dp(74)));
        return r;
    }

    private View breaking(){
        LinearLayout b=row(); b.setPadding(dp(2),dp(2),dp(2),dp(2)); b.setBackground(round(Color.WHITE,Color.TRANSPARENT,dp(12)));
        TextView l=text(LanguageManager.t(this,"breaking"),Color.WHITE,7.5f,true); l.setGravity(Gravity.CENTER); l.setSingleLine(true); l.setBackground(round(RED,RED,dp(7))); b.addView(l,lp(dp(82),dp(28)));
        TextView speaker=text("◀",RED,13,true); speaker.setGravity(Gravity.CENTER); b.addView(speaker,lp(dp(30),dp(28)));
        newsText=text("বাংলাদেশে আজ স্বর্ণের দাম কিছুটা কমেছে...",Color.rgb(20,45,110),10.5f,true); newsText.setGravity(Gravity.CENTER_VERTICAL); newsText.setSingleLine(true); newsText.setEllipsize(TextUtils.TruncateAt.MARQUEE); newsText.setMarqueeRepeatLimit(-1); newsText.setSelected(true); newsText.setPadding(dp(4),0,dp(2),0); b.addView(newsText,weight(1,dp(28)));

        return b;
    }

    private View sectionTitle(String title,boolean all){
        LinearLayout h=row(); h.addView(text(title,DARK,13,true),weight(1,dp(28)));
        if(all){TextView a=text("View All",BLUE,9.5f,true);a.setGravity(Gravity.CENTER);a.setOnClickListener(v->openFeature("LIVE NOW","live_now"));h.addView(a,lp(dp(58),dp(28)));}
        return h;
    }

    private View liveRow(){
        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false);
        LinearLayout r=row();
        for(int i=0;i<4;i++){
            ImageView v=pic(live[i]); final int idx=i; v.setOnClickListener(x->openFeature("LIVE "+(idx+1),"live_now"));
            r.addView(v,lp(dp(122),dp(100))); if(i<3)r.addView(space(),lp(dp(6),1));
        }
        hs.addView(r,new HorizontalScrollView.LayoutParams(-2,-1)); return hs;
    }

    /** Final approved lower dashboard: exactly 8 feature cards in a 4x2 layout. */
    private View finalFeatureGrid(){
        LinearLayout grid=col();
        for(int row=0;row<2;row++){
            LinearLayout r=row();
            for(int col=0;col<4;col++){
                int idx=row*4+col;
                View card=featureCard(idx);
                r.addView(card,weight(1,dp(64)));
                if(col<3)r.addView(space(),lp(dp(5),1));
            }
            grid.addView(r,lp(-1,dp(64)));
            if(row==0) grid.addView(space(),lp(1,dp(6)));
        }
        return grid;
    }

    private View featureCard(final int idx){
        FrameLayout card=new FrameLayout(this);
        featureCards[idx]=card;
        boolean accent=(idx==0||idx==4);
        card.setBackground(round(accent?Color.rgb(82,39,198):Color.WHITE,Color.TRANSPARENT,dp(14)));
        card.setElevation(dp(2));
        card.setVisibility(featureActive[idx]?View.VISIBLE:View.GONE);
        LinearLayout content=col(); content.setGravity(Gravity.CENTER); content.setPadding(dp(6),dp(5),dp(6),dp(4));
        String[] glyphs={"▤","◉","▶","▣","🛒","▶","▧","●●"};
        FrameLayout iconHolder=new FrameLayout(this);
        if(!accent) iconHolder.setBackground(round(Color.rgb(247,248,255),Color.TRANSPARENT,dp(12)));
        ImageView builtInIcon=new ImageView(this);
        builtInIcon.setImageResource(featureIcons[idx]);
        builtInIcon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        featureRemoteImageViews[idx]=builtInIcon;
        iconHolder.addView(builtInIcon,new FrameLayout.LayoutParams(-1,-1));
        content.addView(iconHolder,lp(-1,dp(34)));
        String label=featureRemoteTitles[idx]==null||featureRemoteTitles[idx].trim().isEmpty()?featureTitles[idx]:featureRemoteTitles[idx];
        TextView t=text(label,accent?Color.WHITE:DARK,9.5f,true); t.setGravity(Gravity.CENTER); t.setSingleLine(true); t.setEllipsize(TextUtils.TruncateAt.END); featureLabels[idx]=t; content.addView(t,lp(-1,dp(20)));
        card.addView(content,new FrameLayout.LayoutParams(-1,-1));
        final String key=featureKeys[idx]; card.setOnClickListener(v->openFeature(featureLabels[idx].getText().toString(),key));
        return card;
    }

    private View bottom(){
        LinearLayout n=row(); n.setPadding(dp(4),dp(2),dp(4),dp(2)); n.setBackground(round(Color.WHITE,Color.TRANSPARENT,dp(18))); n.setElevation(dp(6));
        n.addView(navItem("⌂",LanguageManager.t(this,"home"),true,"home"),weight(1,dp(54)));
        n.addView(navItem("◉",LanguageManager.t(this,"live"),false,"live"),weight(1,dp(54)));
        FrameLayout store=new FrameLayout(this); store.setPadding(dp(4),dp(0),dp(4),dp(0));
        LinearLayout bubble=col(); bubble.setGravity(Gravity.CENTER); bubble.setBackground(round(BLUE,Color.WHITE,dp(28))); bubble.setElevation(dp(6));
        TextView si=text("▢",Color.WHITE,21,true); si.setGravity(Gravity.CENTER); bubble.addView(si,lp(-1,dp(28)));
        TextView st=text(LanguageManager.t(this,"store"),Color.WHITE,7.5f,true); st.setGravity(Gravity.CENTER); bubble.addView(st,lp(-1,dp(17)));
        bubble.setOnClickListener(v->openFeature("MY SHOP","my_shop")); store.addView(bubble,new FrameLayout.LayoutParams(dp(62),dp(62),Gravity.CENTER));
        n.addView(store,weight(1,dp(54)));
        n.addView(navItem("💬",LanguageManager.t(this,"chat"),false,"chat"),weight(1,dp(54)));
        n.addView(navItem("▦",LanguageManager.t(this,"more"),false,"more"),weight(1,dp(54)));
        return n;
    }

    private View navItem(String glyph,String label,boolean active,String key){
        LinearLayout item=col(); item.setGravity(Gravity.CENTER);
        TextView g=text(glyph,active?BLUE:Color.rgb(55,57,68),19,true); g.setGravity(Gravity.CENTER); item.addView(g,lp(-1,dp(28)));
        TextView t=text(label,active?BLUE:Color.rgb(55,57,68),7.5f,active); t.setGravity(Gravity.CENTER); item.addView(t,lp(-1,dp(18)));
        if(active){ TextView line=text("━━━━",BLUE,6,true); line.setGravity(Gravity.CENTER); item.addView(line,lp(-1,dp(7))); }
        item.setOnClickListener(v->{ if("live".equals(key))openFeature("LIVE","live_now"); else if("chat".equals(key))openFeature("CHAT","chat"); else if("more".equals(key))openFeature("MORE","more"); });
        return item;
    }

    private String languageCode(){
        String l=LanguageManager.get(this);
        if(LanguageManager.EN.equals(l)) return "EN";
        if(LanguageManager.HI.equals(l)) return "HI";
        if(LanguageManager.AR.equals(l)) return "AR";
        return "বাং";
    }

    private void resolveMenuDestination(){
        String token=SessionManager.getToken(this);
        String uid=SessionManager.getUserId(this);
        if(AdminIdentifiers.isAdminIdentifier(uid)){
            SessionManager.setRemoteSession(this,token,Role.ADMIN,AdminIdentifiers.adminIdFor(uid));
            startActivity(new android.content.Intent(this,AdminManagementActivity.class));
            return;
        }
        if(token==null||token.isEmpty()){
            startActivity(new android.content.Intent(this,AccountActivity.class));
            return;
        }
        if(SessionManager.isAdmin(this)){
            startActivity(new android.content.Intent(this,AdminManagementActivity.class));
            return;
        }
        BackendClient.me(token,new BackendClient.Callback(){
            public void onSuccess(JSONObject d){
                runOnUiThread(()->{
                    try{
                        JSONObject u=d.optJSONObject("user");
                        String role=u==null?"USER":u.optString("role","USER");
                        String uid=u==null?SessionManager.getUserId(MainActivity.this):u.optString("userId",SessionManager.getUserId(MainActivity.this));
                        if("ADMIN".equalsIgnoreCase(role)){
                            SessionManager.setRemoteSession(MainActivity.this,token,Role.ADMIN,uid);
                            if(u!=null) SessionManager.saveProfile(MainActivity.this,u.optString("name",""),u.optString("email",""),u.optString("mobile",""));
                            startActivity(new android.content.Intent(MainActivity.this,AdminManagementActivity.class));
                        }else startActivity(new android.content.Intent(MainActivity.this,AccountActivity.class));
                    }catch(Exception e){ startActivity(new android.content.Intent(MainActivity.this,AccountActivity.class)); }
                });
            }
            public void onError(String m){ runOnUiThread(()->{ toast("Admin access check failed"); startActivity(new android.content.Intent(MainActivity.this,AccountActivity.class)); }); }
        });
    }

    private void loadRemote(){BackendClient.dashboard(SessionManager.getToken(this),new BackendClient.Callback(){public void onSuccess(JSONObject d){runOnUiThread(()->applyRemote(d));}public void onError(String m){}});}

    private void applyRemote(JSONObject d){
        try{
            JSONObject c=d.optJSONObject("config");
            if(c!=null){
                String n=c.optString("breaking_news","").trim(); if(!n.isEmpty()&&newsText!=null) newsText.setText(n);
                saveRemoteUrl("my_shop",c.optString("my_shop_url","")); saveRemoteUrl("live_tv",c.optString("live_tv_url","")); saveRemoteUrl("external_movie",c.optString("external_movie_url","")); saveRemoteUrl("chat",c.optString("chat_url",""));
            }
            JSONArray banners=d.optJSONArray("banners");
            if(banners!=null){for(int i=0;i<banners.length();i++){JSONObject o=banners.optJSONObject(i);if(o==null)continue;String folder=o.optString("folder","");int slot=o.optInt("slot",0);String url=o.optString("image_url","").trim();if(url.isEmpty())continue;if("hero".equalsIgnoreCase(folder)&&slot>=1&&slot<=6){remoteHeroUrls[slot-1]=url;if(slot==slide+1)loadRemoteImage(hero,url);}else if("promo".equalsIgnoreCase(folder)&&slot>=1&&slot<=3){remotePromoUrls[slot-1]=url;loadRemoteImage(promoViews[slot-1],url);}}}
            JSONArray social=d.optJSONArray("socialLinks"); if(social!=null){for(int i=0;i<social.length();i++){JSONObject o=social.optJSONObject(i);if(o==null)continue;String url=o.optString("url","").trim();if(!url.isEmpty())getSharedPreferences("myshop_remote_config",MODE_PRIVATE).edit().putString("social_"+o.optString("platform","").toLowerCase(),url).apply();}}
            JSONArray gallery=d.optJSONArray("gallery"); if(gallery!=null&&gallery.length()>0){JSONObject g=gallery.optJSONObject(0);saveRemoteUrl("gallery",g==null?"":g.optString("media_url",""));}
            JSONArray features=d.optJSONArray("featureButtons");
            if(features!=null){for(int i=0;i<features.length();i++){JSONObject f=features.optJSONObject(i);if(f==null)continue;String key=f.optString("key","");for(int j=0;j<featureKeys.length;j++)if(featureKeys[j].equals(key)){featureActive[j]=f.optInt("active",1)==1;featureRemoteTitles[j]=f.optString("title","");featureRemoteUrls[j]=f.optString("target_url","");featureRemoteIcons[j]=f.optString("icon_url","");if(!featureRemoteUrls[j].isEmpty())saveRemoteUrl(key,featureRemoteUrls[j]);}}}
        }catch(Exception ignored){}
        refreshFeatureGridIfNeeded();
    }

    private void refreshFeatureGridIfNeeded(){
        for(int i=0;i<featureKeys.length;i++){
            if(featureCards[i]==null) continue;
            boolean accent=(i==0||i==4);
            featureCards[i].setVisibility(featureActive[i]?View.VISIBLE:View.GONE);
            featureCards[i].setBackground(round(accent?Color.rgb(82,39,198):Color.WHITE,Color.TRANSPARENT,dp(14)));
            if(featureLabels[i]!=null){
                String label=featureRemoteTitles[i]==null||featureRemoteTitles[i].trim().isEmpty()?featureTitles[i]:featureRemoteTitles[i];
                featureLabels[i].setText(label); featureLabels[i].setTextColor(accent?Color.WHITE:DARK);
            }
            if(featureRemoteImageViews[i]!=null){
                featureRemoteImageViews[i].setVisibility(View.VISIBLE);
                if(featureRemoteIcons[i]!=null&&!featureRemoteIcons[i].trim().isEmpty()){
                    loadRemoteImage(featureRemoteImageViews[i],featureRemoteIcons[i]);
                } else {
                    featureRemoteImageViews[i].setImageResource(featureIcons[i]);
                }
            }
        }
    }

    private void saveRemoteUrl(String key,String url){if(url!=null&&!url.trim().isEmpty())getSharedPreferences("myshop_remote_config",MODE_PRIVATE).edit().putString("url_"+key,url.trim()).apply();}
    private void loadRemoteImage(ImageView target,String url){Executors.newSingleThreadExecutor().execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(8000);c.setReadTimeout(10000);c.setInstanceFollowRedirects(true);try(InputStream in=c.getInputStream()){Bitmap bm=BitmapFactory.decodeStream(in);if(bm!=null)runOnUiThread(()->target.setImageBitmap(bm));}}catch(Exception ignored){}});}
    private void startCarousel(){handler.postDelayed(new Runnable(){public void run(){slide=(slide+1)%6;if(remoteHeroUrls[slide]!=null&&!remoteHeroUrls[slide].isEmpty())loadRemoteImage(hero,remoteHeroUrls[slide]);else hero.setImageResource(heroImgs[slide]);StringBuilder s=new StringBuilder();for(int i=0;i<6;i++){s.append(i==slide?"●":"○");if(i<5)s.append("   ");}dots.setText(s.toString());handler.postDelayed(this,3500);}},3500);}
    private void openFeature(String title,String key){try{android.content.Intent i=new android.content.Intent(this,FeatureActivity.class);i.putExtra("title",title);i.putExtra("feature_key",key);String url=featureRemoteUrl(key);if(url.isEmpty())url=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("url_"+key,"");if("social_media".equals(key)&&url.isEmpty())url=getSharedPreferences("myshop_remote_config",MODE_PRIVATE).getString("social_facebook","");if(FeatureRegistry.isSafeHttpUrl(url))i.putExtra("url",url);else{url=FeatureRegistry.getUrl(this,key);if(FeatureRegistry.isSafeHttpUrl(url))i.putExtra("url",url);}startActivity(i);}catch(Throwable t){toast(title+" is ready.");}}
    private String featureRemoteUrl(String key){for(int i=0;i<featureKeys.length;i++)if(featureKeys[i].equals(key))return featureRemoteUrls[i]==null?"":featureRemoteUrls[i].trim();return "";}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private ImageView pic(int r){ImageView v=new ImageView(this);v.setImageResource(r);v.setScaleType(ImageView.ScaleType.FIT_XY);v.setBackgroundColor(Color.TRANSPARENT);v.setClipToOutline(false);return v;}
    private Button icon(String s,int c,float z){Button b=new Button(this);b.setText(s);b.setTextColor(c);b.setTextSize(z);b.setGravity(Gravity.CENTER);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setPadding(0,0,0,0);b.setBackgroundColor(Color.TRANSPARENT);return b;}
    private TextView text(String s,int c,float z,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(c);t.setTextSize(z);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private View space(){return new View(this);}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams weight(float w,int h){return new LinearLayout.LayoutParams(0,h,w);}
    private LinearLayout.LayoutParams top(LinearLayout.LayoutParams p,int m){p.topMargin=dp(m);return p;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private GradientDrawable round(int fill,int stroke,int rad){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(rad));if(stroke!=Color.TRANSPARENT)g.setStroke(dp(1),stroke);return g;}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
}
