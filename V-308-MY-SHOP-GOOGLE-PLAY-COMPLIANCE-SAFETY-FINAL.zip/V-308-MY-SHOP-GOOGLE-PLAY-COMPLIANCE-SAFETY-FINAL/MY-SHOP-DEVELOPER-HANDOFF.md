# MY SHOP Developer Handoff — V-308

## Version
- Build: V-308
- Android: versionCode 308, versionName 2.9.308
- Base: V-307 Full Stability + Live Home
- Phase: Google Play Compliance + Safety

## Completed in this version
1. Google Play Billing 9.1.0 user-paid digital purchase gate.
2. Server-side Google Play purchase verification and replay protection.
3. Direct real-money digital bKash/Nagad/QR purchase paths disabled for Play build behavior.
4. Existing payout/withdrawal bKash/Nagad paths preserved as payout functions, not purchase checkout.
5. Admin catalog Google Play Product ID field/validation.
6. In-app account deletion with password + DELETE confirmation.
7. Public Privacy / Terms / Account Deletion Worker pages.
8. External deletion-request intake + Admin review board.
9. Registration legal consent unchecked by default with clickable legal links.
10. User Report + Block on Profile, Feed/Comments, Chat and Live.
11. Backend Block enforcement for messages, social relationships, Feed/Video visibility/interactions and profile access.
12. Admin Safety Reports queue with Resolve/Dismiss.
13. Android app backup disabled.
14. GitHub release workflow requires/preserves Google Play service-account Worker secret.
15. V-308 source compliance guard added to workflow.

## Protected / unchanged
- Approved Main Dashboard structure.
- Dashboard → Live Home navigation.
- Host + 12 User Seats.
- Existing D1 database binding: `my-shop-db`.
- Existing R2 binding/bucket: `MEDIA` / `my-shop-media`.
- User core numeric ID remains permanent and is never reassigned.
- Admin CRUD and local Admin Locker behavior.
- Permanent Android signing key workflow.

## Production setup required before a V-308 paid release can pass its own workflow
- GitHub Actions secret: `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON`.
- Correct Android Publisher API/Play Console service-account permissions.
- Active Play one-time products matching every paid catalog `play_product_id`.
- Real owner/support contact added to Privacy Policy.
- Play Console Data Safety, financial features, ads, content rating, UGC and App Access declarations.

## Deployment checkpoint
The workflow creates an immutable Worker version and promotes that exact version to 100%, then validates `/health`, `/health/deep`, D1/R2 write probes and content-write suite before building the APK. V-308 additionally requires `/health/deep` to report `playBilling=\"configured\"`.

## Device / end-to-end QA still required
- Signed release assemble via the repository workflow.
- Licensed Play tester: completed / cancelled / pending / restored one-time purchases.
- Verify Coin/Gold/Badge/Membership appears exactly once after Worker verification.
- Delete-account production D1/R2 cleanup on a disposable test account.
- Web deletion form + Admin Safety board review.
- Report/Block across two disposable users.
- Live multi-user/Agora reconnect and 12-seat regression.

## Known constraint
The current local artifact environment does not contain Android SDK/Gradle, so full Android `assembleRelease` cannot be performed locally. The repository workflow installs Android SDK 36 + Gradle 8.11.1 and is the release compile gate.
