package com.myshop.app;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.MediaPlayer;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import org.json.JSONObject;

/** One muted decoder for the selected room/expanded demo, never for catalog tiles. */
public final class AnimatedWallpaper665 extends FrameLayout implements TextureView.SurfaceTextureListener {
    private final ImageView poster;
    private final TextureView texture;
    private final String url,fit;
    private MediaPlayer player;
    private Surface surface;
    private boolean attached,prepared,active665=true;public void setActive665(boolean active){active665=active;if(!active)release();else start();}
    private int videoWidth,videoHeight;
    public static boolean video(String url){return url!=null&&url.matches("(?i).*\\.(mp4|webm|m4v)(\\?.*)?$");}
    public static boolean enabled(Context c){android.app.ActivityManager am=(android.app.ActivityManager)c.getSystemService(Context.ACTIVITY_SERVICE);return c.getSharedPreferences("live665",0).getBoolean("animatedWallpaper",am==null||!am.isLowRamDevice());}
    public AnimatedWallpaper665(Context c,JSONObject item){super(c);url=item.optString("animation_url",item.optString("background_url"));fit=item.optString("fit_mode","CENTER_CROP");poster=new ImageView(c);poster.setScaleType(ImageView.ScaleType.CENTER_CROP);poster.setImageResource(R.drawable.live_room_default_wallpaper);addView(poster,new LayoutParams(-1,-1));String preview=item.optString("preview_url");if(!preview.isEmpty()&&!video(preview))AnimatedAssetLoader.load(poster,preview,true);texture=new TextureView(c);texture.setOpaque(false);texture.setSurfaceTextureListener(this);addView(texture,new LayoutParams(-1,-1));setContentDescription("Muted animated live wallpaper");}
    private void start(){if(!attached||!active665||!texture.isAvailable()||player!=null||!enabled(getContext()))return;try{MediaPlayer next=new MediaPlayer();player=next;surface=new Surface(texture.getSurfaceTexture());next.setSurface(surface);next.setVolume(0,0);next.setLooping(true);if(url.startsWith("asset://")){try(android.content.res.AssetFileDescriptor fd=getContext().getAssets().openFd(url.substring(8))){next.setDataSource(fd.getFileDescriptor(),fd.getStartOffset(),fd.getLength());}}else if(url.startsWith("https://"))next.setDataSource(url);else throw new java.io.IOException("Unsupported wallpaper URL");next.setOnPreparedListener(mp->{if(mp!=player)return;prepared=true;videoWidth=mp.getVideoWidth();videoHeight=mp.getVideoHeight();transform();if(attached&&active665&&getWindowVisibility()==View.VISIBLE)mp.start();});next.setOnInfoListener((mp,what,extra)->{if(what==MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START)poster.setVisibility(GONE);return false;});next.setOnErrorListener((mp,what,extra)->{release();return true;});next.prepareAsync();}catch(Exception e){release();}}
    private void transform(){int w=texture.getWidth(),h=texture.getHeight();if(w<=0||h<=0||videoWidth<=0||videoHeight<=0)return;float sx=1,sy=1;if(!"FILL".equalsIgnoreCase(fit)){float scale="FIT".equalsIgnoreCase(fit)?Math.min(w/(float)videoWidth,h/(float)videoHeight):Math.max(w/(float)videoWidth,h/(float)videoHeight);sx=scale*videoWidth/w;sy=scale*videoHeight/h;}Matrix m=new Matrix();m.setScale(sx,sy,w/2f,h/2f);texture.setTransform(m);}
    private void release(){prepared=false;if(player!=null){MediaPlayer old=player;player=null;old.setOnPreparedListener(null);old.setOnErrorListener(null);old.setOnInfoListener(null);try{old.release();}catch(Exception ignored){}}if(surface!=null){surface.release();surface=null;}poster.setVisibility(VISIBLE);}
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();attached=true;start();}
    @Override protected void onDetachedFromWindow(){attached=false;release();super.onDetachedFromWindow();}
    @Override protected void onWindowVisibilityChanged(int visibility){super.onWindowVisibilityChanged(visibility);if(player!=null&&prepared){if(visibility==VISIBLE)player.start();else player.pause();}else if(visibility==VISIBLE&&texture!=null)start();}
    @Override public void onSurfaceTextureAvailable(SurfaceTexture s,int w,int h){start();}
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture s,int w,int h){transform();}
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture s){release();return true;}
    @Override public void onSurfaceTextureUpdated(SurfaceTexture s){}
}
