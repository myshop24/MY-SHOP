# MY SHOP V-331 — Focused Completion Fix

## Target scope only
1. Admin navigation: premium dark left sidebar based on approved reference; removed obsolete/dead Coin / Gold Coin Purchase Packages menu entry.
2. Menu routing: Gift Coin Catalog opens COIN catalog; Gold Coin Catalog opens GOLD catalog; finance/wallet/media/ads/badges/live entries route to their working admin screens.
3. Message heads-up notification hardening: new high-importance message channel id, sound/vibration defaults, direct Chat deep-link retained.
4. Live Start push: backend now sends a real FCM data push to registered Android installs when a host starts a new live; Android uses a dedicated high-importance Live Alerts channel and tapping opens the host's Audio Live Room.
5. Gift sound editor: direct phone audio picker, no visible sound-URL field, larger visible trim/waveform panel, selected-audio duration labels, robust MediaPlayer preview, trim seek + duration + volume, and upload only on Save.

## Protected / unchanged
- Main Home Dashboard structure and approved design.
- AdminWalletActivity / Give Coin-Gold grant flow.
- Live 12-seat + separate Host architecture.
- Existing D1 schema; no destructive schema change.
- Gift transaction/economy rules.

## Required verification
- CI Android build: NEEDS CI TEST (wrapper JAR is absent in source archive).
- Real-device heads-up notifications: NEEDS DEVICE + production Firebase/Worker secret TEST.
- Real-device sound picker/preview/upload + waveform visibility: NEEDS DEVICE TEST.
- Sidebar visual comparison with approved reference: NEEDS DEVICE VISUAL QA.
